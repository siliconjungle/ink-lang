# Planning corpus report

Target `javascript`, effort `quick`, compiler `f2924975a3cc`, knowledge snapshot `2dc13a0c2b23`.

| Measure | Value |
|---|---:|
| Programs compiled | 3 / 3 |
| With an admitted rewrite alternative | 1 |
| With any knowledge-backed alternative | 1 |
| Selecting an alternative under defaults | 0 |
| Stopped by the time budget | 3 |
| Median planning seconds | 117.293 |
| Laws admitted (in 2+ programs) | 1 (0) |
| Representations admitted | 0 |

## Programs

| Program | Seconds | Stop | Matched | Admitted | Rejected | Unchecked | Rewrite alts | Last gate |
|---|---:|---|---:|---:|---:|---:|---:|---|
| sequence-every | 117 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| index-membership | 117 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| incremental-distinct | 82 | time | 0 | 0 | 0 | 0 | 3 | profitability |

## Near misses

Checker rejection gates: none

| Failed premise shape | Rejections | Programs |
|---|---:|---|

| Failed premise as instantiated in the program | Rejections | Programs |
|---|---:|---|

## Where planning time went

| Recipe | Seconds | Share |
|---|---:|---:|
| database-source-algorithms | 0.86 | 100% |
| compact-observer | 0.0 | 0% |
| representation-products | 0.0 | 0% |
| first-order-choices | 0.0 | 0% |
| migration-bridges | 0.0 | 0% |
| residual-execution-carriers | 0.0 | 0% |
| graph-resources | 0.0 | 0% |
| all-published-packages | 0.0 | 0% |
| semantic-laws | 0.0 | 0% |
| whole-action-coalescing | 0.0 | 0% |
| index | 0.0 | 0% |
| grouped-index | 0.0 | 0% |
| direct | 0.0 | 0% |
| refresh-on-query | 0.0 | 0% |
| representation-5 | 0.0 | 0% |

## Admitted knowledge by program

| Entry | Kind | Programs |
|---|---|---|
| 7069b2b125e492c9 | law | incremental-distinct |

Observed default planning on a fixed corpus; no proof, applicability or profitability authority.
