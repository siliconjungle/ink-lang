const __sumSpecs=new Map([["[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"kind":"ref","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"kind":"ref","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}}],["[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"kind":"ref","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"kind":"ref","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}}],["[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"kind":"ref","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"kind":"ref","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}}],["[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"kind":"ref","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"kind":"ref","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}]]);
// Private tag/payload cells implement fixed, checked sum codec meanings.
// Helpers never accept public values and never choose a representation.
function __sumKey(type){
 const k=type.kind;
 if(k==='ref'||k==='record'&&typeof type.name==='string')return JSON.stringify(['named',type.name]);
 const tree=t=>JSON.parse(__sumKey(t));
 switch(k){
  case 'list':case 'vector':case 'option':return JSON.stringify([k,type.size??null,tree(type.element)]);
  case 'result':return JSON.stringify([k,tree(type.ok),tree(type.error)]);
  case 'record':return JSON.stringify([k,type.fields.map(f=>[f.name,tree(f.type)])]);
  case 'enum':return JSON.stringify([k,type.variants]);
  default:return JSON.stringify([k]);
 }
}
const __sumNodes=new Map();
function __sumNode(type){
 const key=__sumKey(type);let node=__sumNodes.get(key);if(node)return node;
 node={selected:__sumSpecs.has(key),result:type.kind==='result',error:null};__sumNodes.set(key,node);
 if(node.result)node.error=__sumNode(type.error);return node;
}
const __sumRoots=new Map([...__sumSpecs].map(([key,type])=>[key,__sumNode(type)]));
function __sumMake(key,ok,value){
 const node=__sumRoots.get(key);if(!node)return ok?{Ok:value}:{Err:value};
 if(ok)return {tag:0,payload:value};
 const original=value;
 let tail=node.error,index=1;
 while(tail.result){
  if(tail.selected)return {tag:index+value.tag,payload:value.payload,tail:original};
  if(Object.hasOwn(value,'Ok'))return {tag:index,payload:value.Ok,tail:original};
  value=value.Err;tail=tail.error;index++;
 }
 return {tag:index,payload:value,tail:original};
}
function __sumRestore(node,index,payload){
 if(!node.result)return payload;
 if(node.selected)return {tag:index,payload};
 return index===0?{Ok:payload}:{Err:__sumRestore(node.error,index-1,payload)};
}
const __sumViews=new WeakMap();
function __sumView(key,value){
 const node=__sumRoots.get(key);if(!node)return value;
 let views=__sumViews.get(value);if(!views){views=new Map();__sumViews.set(value,views);}
 if(views.has(key))return views.get(key);
 const view=value.tag===0?{Ok:value.payload}:{Err:Object.hasOwn(value,'tail')?value.tail:__sumRestore(node.error,value.tag-1,value.payload)};
 views.set(key,view);return view;
}
const __recordElisions=new Set(["__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2","__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19","__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e","__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7","__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8","ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"]);
const __nativeF32=false;
// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
// Native binary32 lane for pure modules. Explicit NaN payloads remain tagged;
// arithmetic canonicalizes NaNs just as __bits does in the exact-bit lane.
const __nfValue = value => typeof value === 'number' ? Math.fround(value) : value;
// Number operands have already been normalised at their typed read or producer.
const __nfNumber = value => typeof value === 'number' ? value : __float(value.F32Bits);
const __nfBits = value => typeof value === 'number' ? __bits(value) : value.F32Bits;
const __nfFromBits = bits => (bits & 0x7fffffff)>0x7f800000 ? {F32Bits:bits} : __float(bits);
const __nfNeg = value => typeof value === 'number' && !Number.isNaN(value) ? -value : {F32Bits:(__nfBits(value) ^ 0x80000000) >>> 0};
const __nfOutput = value => {const n=typeof value==='number'?Math.fround(value):__float(value.F32Bits);return Number.isFinite(n)?n:{F32Bits:__nfBits(value)};};
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output, capture=false) {
  const convert=__representationRaw(type,output,capture);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':capture?'capture:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output, capture) {
  switch (type.kind) {
    case 'ref': {
      let resolved;
      return (value,context)=>(resolved??=__representation(__namedTypes[type.name],output,capture))(value,context);
    }
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output,capture);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output,capture),err=__representation(type.error,output,capture);
      const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);
      if(flat)return output?(value,context)=>{const v=__sumView(key,value);return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};}:(v,context)=>Object.hasOwn(v,'Ok')?__sumMake(key,true,ok(v.Ok,context)):__sumMake(key,false,err(v.Err,context));
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f32': if(typeof __nativeF32!=='undefined'&&__nativeF32)return output?__nfOutput:capture?__nfValue:__identity;
      return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output,capture);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){
        if(!type.fields.length)return ()=>undefined; // lexically unconsumed projected input
        const field=type.fields[0],child=__representation(field.type,output,capture);
        return output?(value,context)=>({[field.name]:child(value,context)}):(value,context)=>child(value[field.name],context);
      }
      const fields = type.fields.map(field => [field.name, __representation(field.type, output,capture)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
function __stateWord(value){
 if(typeof value==='number'&&!Number.isSafeInteger(value))throw Error('u64 requires an exact integer');
 if(!['bigint','number','string'].includes(typeof value)||typeof value==='string'&&!/^(0|[1-9][0-9]*)$/.test(value))throw Error('invalid u64');
 const n=BigInt(value);if(n<0n||n>18446744073709551615n)throw Error('invalid u64');return n;
}
// Compile the capture traversal once. Each invocation still validates and owns
// every public container; no host value is retained between calls.
const __stateCaptures=new WeakMap();
function __stateCapture(type){
 const prior=__stateCaptures.get(type);if(prior)return prior;
 const capture=__compileStateCapture(type);__stateCaptures.set(type,capture);return capture;
}
function __compileStateCapture(type){
 const limited=copy=>(value,budget={cells:1000000},depth=0)=>{
  if(depth>64||--budget.cells<0)throw Error('state input resource limit');
  return copy(value,budget,depth);
 };
 const tagged=(value,tag)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
 switch(type.kind){
  case 'ref':{
   // Resolve lazily so recursive schemas compile to recursive validators rather
   // than reverting to descriptor interpretation at every referenced node.
   let resolved;
   return limited((value,budget,depth)=>(resolved??=__stateCapture(__namedTypes[type.name]))(value,budget,depth+1));
  }
  case 'u32':case 'i32':{
   const min=type.kind==='u32'?0:-2147483648,max=type.kind==='u32'?4294967295:2147483647;
   return limited(value=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;});
  }
  case 'u64':return limited(__stateWord);
  case 'bool':return limited(value=>{if(typeof value!=='boolean')throw Error('invalid Bool');return value;});
  case 'unit':return limited(value=>{if(value!==null)throw Error('invalid Unit');return null;});
  case 'string':return limited(value=>{if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;});
  case 'enum':return limited(value=>{if(!type.variants.includes(value))throw Error('invalid enum');return value;});
  case 'id':return limited(value=>{if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();});
  case 'list':case 'vector':{
   const item=__stateCapture(type.element),size=type.kind==='vector'?type.size:null;
   return limited((value,budget,depth)=>{
    if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
    if(size!==null&&value.length!==size)throw Error('invalid vector length');
    const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=item(value[i],budget,depth+1);return out;
   });
  }
  case 'record':{
   const fields=type.fields.map(f=>[f.name,__stateCapture(f.type)]);
   if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name)))return limited((value,budget,depth)=>{const [name,copy]=fields[0];if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,name))throw Error('invalid record');return copy(value[name],budget,depth+1);});
   return limited((value,budget,depth)=>{
    if(!value||typeof value!=='object'||Array.isArray(value)||!fields.every(([name])=>Object.hasOwn(value,name)))throw Error('invalid record');
    const out={};for(const [name,copy]of fields){const field=copy(value[name],budget,depth+1);if(name==='__proto__')Object.defineProperty(out,name,{value:field,writable:true,enumerable:true,configurable:true});else out[name]=field;}return out;
   });
  }
  case 'option':{
   const item=__stateCapture(type.element);
   return limited((value,budget,depth)=>{if(tagged(value,'Some'))return {Some:item(value.Some,budget,depth+1)};if(tagged(value,'None')&&value.None===null)return {None:null};throw Error('invalid Option');});
  }
  case 'result':{
   const ok=__stateCapture(type.ok),err=__stateCapture(type.error);
   return limited((value,budget,depth)=>{if(tagged(value,'Ok'))return {Ok:ok(value.Ok,budget,depth+1)};if(tagged(value,'Err'))return {Err:err(value.Err,budget,depth+1)};throw Error('invalid Result');});
  }
  default:return (value,budget,depth)=>__stateInput(value,type,budget,depth);
 }
}
function __stateInput(value,type,budget={cells:1000000},depth=0){
  if(depth>64||--budget.cells<0)throw Error('state input resource limit');
  const input=(v,t)=>__stateInput(v,t,budget,depth+1);
  const integer=(min,max)=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;};
  const tagged=tag=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
  switch(type.kind){
    case 'ref':return input(value,__namedTypes[type.name]);
    case 'u32':return integer(0,4294967295);
    case 'i32':return integer(-2147483648,2147483647);
    case 'u64':return __stateWord(value);
    case 'int':{
      if(typeof value==='bigint')return value;
      if(!tagged('Int')||typeof value.Int!=='string'||!/^(-?[0-9]+)$/.test(value.Int))throw Error('invalid Int');return BigInt(value.Int);
    }
    case 'f32':{
      if(typeof value==='number'&&Number.isFinite(value)){const bits=__bits(value);if((bits&0x7fffffff)===0x7f800000)throw Error('f32 overflow requires F32Bits');return bits;}
      if(!tagged('F32Bits')||!Number.isInteger(value.F32Bits)||value.F32Bits<0||value.F32Bits>4294967295)throw Error('invalid f32');return value.F32Bits;
    }
    case 'bool':if(typeof value!=='boolean')throw Error('invalid Bool');return value;
    case 'unit':if(value!==null)throw Error('invalid Unit');return null;
    case 'string':if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;
    case 'id':if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();
    case 'enum':if(!type.variants.includes(value))throw Error('invalid enum');return value;
    case 'list':case 'vector':{
      if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
      if(type.kind==='vector'&&value.length!==type.size)throw Error('invalid vector length');
      return Array.from(value,v=>input(v,type.element));
    }
    case 'record':if(!value||typeof value!=='object'||Array.isArray(value)||!type.fields.every(f=>Object.hasOwn(value,f.name)))throw Error('invalid record');if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){const f=type.fields[0];return input(value[f.name],f.type);}return Object.fromEntries(type.fields.map(f=>[f.name,input(value[f.name],f.type)]));
    case 'option':if(tagged('Some'))return {Some:input(value.Some,type.element)};if(tagged('None')&&value.None===null)return {None:null};throw Error('invalid Option');
    case 'result':{const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);if(tagged('Ok')){const child=input(value.Ok,type.ok);return flat?__sumMake(key,true,child):{Ok:child};}if(tagged('Err')){const child=input(value.Err,type.error);return flat?__sumMake(key,false,child):{Err:child};}throw Error('invalid Result');}
    default:throw Error('unsupported public value type');
  }
}
// Mutable host replies must not retain references into compiled state or its outbox.
// State results must own mutable containers. Compile the declared schema once:
// scalars need no structured clone, while nested records/lists remain detached.
function __ownershipSchema(type){
 // Nominal references and expanded declarations name the same checked sort.
 // Distinct source records retain distinct keys even if a layout erases them.
 if(type.kind==='ref'||type.kind==='record'&&type.name)return ['named',type.name];
 switch(type.kind){
  case 'list':case 'vector':return [type.kind,type.size??null,__ownershipSchema(type.element)];
  case 'option':return ['option',__ownershipSchema(type.element)];
  case 'result':return ['result',__ownershipSchema(type.ok),__ownershipSchema(type.error)];
  case 'record':return ['record',type.fields.map(f=>[f.name,__ownershipSchema(f.type)])];
  default:return type;
 }
}
function __ownedResult(copy,nested,type){
 const key='owned-state:'+JSON.stringify(__ownershipSchema(type));
 let schema=__conversionKeys.get(key);
 if(!schema){schema={};__conversionKeys.set(key,schema);}
 const owned=(value,context)=>{
  if(!context&&!nested)return copy(value,null);
  const memo=context||new WeakMap();
  if(value===null||typeof value!=='object')return copy(value,memo);
  let entries=memo.get(schema);if(!entries){entries=new WeakMap();memo.set(schema,entries);}
  if(entries.has(value))return entries.get(value);
  const result=copy(value,memo);entries.set(value,result);return result;
 };
 owned.container=true;return owned;
}
function __stateResult(type){
 switch(type.kind){
  case 'ref':{let resolved;const copy=(value,context)=>(resolved??=__stateResult(__namedTypes[type.name]))(value,context);copy.container=true;return copy;}
  case 'record':{if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){const f=type.fields[0],copy=__stateResult(f.type);return __ownedResult((value,context)=>({[f.name]:copy(value,context)}),copy.container,type);}const fields=type.fields.map(f=>[f.name,__stateResult(f.type)]);return __ownedResult((value,context)=>Object.fromEntries(fields.map(([name,copy])=>[name,copy(value[name],context)])),fields.some(([,copy])=>copy.container),type);}
  case 'list':case 'vector':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Array.from(value,item=>copy(item,context)),copy.container,type);}
  case 'option':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Object.hasOwn(value,'Some')?{Some:copy(value.Some,context)}:{None:null},copy.container,type);}
  case 'result':{const ok=__stateResult(type.ok),err=__stateResult(type.error),key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);return __ownedResult((value,context)=>{const v=flat?__sumView(key,value):value;return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};},ok.container||err.container,type);}
  default:return __representation(type,true);
 }
}
function __stateOutput(value,type){return __stateResult(type)(value);}
const __u64 = n => BigInt.asUintN(64, n);
function __div(a, b, fallback, signed, remainder) {
  if (b === 0 || b === 0n || (signed && a === -2147483648 && b === -1)) return fallback();
  return typeof a === 'bigint' ? (remainder ? a % b : a / b) :
    ((remainder ? a % b : Math.trunc(a / b)) + 0); // integer zero has no sign
}
function __at(xs, index, fallback) { return index < xs.length ? xs[index] : fallback(); }
// Ordinary arrays retain the declared result element type when input is typed.
function __map(xs, fn) {
  const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = fn(xs[i], i);
  return out;
}
function __filter(xs, fn) {
  const out = [];
  for (let i = 0; i < xs.length; i++) if (fn(xs[i])) out.push(xs[i]);
  return out;
}
function __concat(xs, ys) {
  const left = xs.length, right = ys.length, out = new Array(left + right);
  for (let i = 0; i < left; i++) out[i] = xs[i];
  for (let i = 0; i < right; i++) out[left + i] = ys[i];
  return out;
}
function __zip(xs, ys, fn) {
  const n = Math.min(xs.length, ys.length), out = new Array(n);
  for (let i = 0; i < n; i++) out[i] = fn(xs[i], ys[i]);
  return out;
}
function __repeat(n, initial, fn) { let value = initial; for (let i = 0; i < n; i++) value = fn(i, value); return value; }
function __foldr(xs, initial, fn) { let value = initial; for (let i = xs.length - 1; i >= 0; i--) value = fn(xs[i], value); return value; }
function __scan(xs, zero, add) {
  let value = zero; const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = value = add(value, xs[i]);
  return out;
}
const __sort = xs => Array.from(xs).sort((a,b) => a < b ? -1 : a > b ? 1 : 0);
// Fixed primitives; no cross-invocation host caches.
function __ink_round_even(x){if(!Number.isFinite(x)||Math.abs(x)>=8388608)return x;const a=Math.abs(x),i=Math.floor(a),r=a-i;const y=i+Number(r>0.5||(r===0.5&&i%2===1));return x<0||Object.is(x,-0)?-y:y;}
// Direct BigInt -> binary32 avoids double rounding through binary64.
function __ink_big_float(x){if(x===0n)return 0;const neg=x<0n;if(neg)x=-x;let e=x.toString(2).length-1;if(e<=23)return Number(neg?-x:x);const shift=BigInt(e-23),mask=(1n<<shift)-1n;let q=x>>shift;const rem=x&mask,half=1n<<(shift-1n);if(rem>half||(rem===half&&(q&1n)!==0n))q++;if(q===16777216n){q>>=1n;e++;}if(e>127)return neg?-Infinity:Infinity;return (neg?-1:1)*Number(q)*2**(e-23);}
function __ink_from_float(x,t){x=Math.trunc(x);if(!Number.isFinite(x))return {None:null};const valid=t==='i32'?x>=-2147483648&&x<2147483648:x>=0&&x<(t==='u32'?4294967296:18446744073709551616);return valid?{Some:t==='u64'?BigInt(x):x===0?0:x}:{None:null};}
function __ink_count(x,n,width){if(width===64){x=BigInt.asUintN(64,x);if(n==='popcount'){let count=0;while(x){x&=x-1n;count++;}return count;}if(x===0n)return 64;if(n==='leading_zeros')return 64-x.toString(2).length;let count=0;while((x&1n)===0n){x>>=1n;count++;}return count;}x>>>=0;if(n==='leading_zeros')return Math.clz32(x);if(n==='trailing_zeros')return x===0?32:31-Math.clz32((x&-x)>>>0);x=x-((x>>>1)&0x55555555);x=(x&0x33333333)+((x>>>2)&0x33333333);return Math.imul((x+(x>>>4))&0x0f0f0f0f,0x01010101)>>>24;}
const __ink_encoder=new TextEncoder(),__ink_decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const __ink_bytes=s=>__ink_encoder.encode(s);
const __ink_boundary=(b,i)=>i<=b.length&&(i===b.length||(b[i]&0xc0)!==0x80);
function __ink_byte_at(s,i){const b=__ink_bytes(s);return i<b.length?{Some:b[i]}:{None:null};}
function __ink_slice(s,a,z){const b=__ink_bytes(s);return a<=z&&__ink_boundary(b,a)&&__ink_boundary(b,z)?{Some:__ink_decoder.decode(b.subarray(a,z))}:{None:null};}
function __ink_concat(a,b){const s=a+b;if(__ink_bytes(s).length>4294967295)throw Error('String exceeds U32 byte length');return s;}
function __ink_find(s,needle,from){const b=__ink_bytes(s);if(!__ink_boundary(b,from))return {None:null};const tail=__ink_decoder.decode(b.subarray(from)),i=tail.indexOf(needle);return i<0?{None:null}:{Some:from+__ink_bytes(tail.slice(0,i)).length};}

function __ink_int_from_float(x){return Number.isFinite(x)?{Some:BigInt(Math.trunc(x))}:{None:null};}
// Fixed word semantics, including arithmetic signed right shift. Shift and
// rotation counts wrap modulo width; no source-pattern optimisation lives here.
function __word(op,a,b,bits) {
  const width=BigInt(Math.abs(bits)), k=BigInt(b??0)%width;
  const x=BigInt(a), y=BigInt(b??0), unsigned=BigInt.asUintN(Number(width),x);
  let r;
  switch(op) {
    case 'word_not':r=~x;break;
    case 'word_and':r=x&y;break;
    case 'word_or':r=x|y;break;
    case 'word_xor':r=x^y;break;
    case 'wrapping_shl':r=x<<k;break;
    case 'wrapping_shr':r=x>>k;break;
    case 'rotate_left':r=(unsigned<<k)|(unsigned>>(width-k));break;
    case 'rotate_right':r=(unsigned>>k)|(unsigned<<(width-k));break;
    default:throw new Error('unknown word operation');
  }
  r=bits<0?BigInt.asIntN(Number(width),r):BigInt.asUintN(Number(width),r);
  return bits===64?r:Number(r);
}
function __fn0(v0,v1,v2){
const v3=v0;
const v4=v1;
const v5=v2;
return __fn16(v3,v4,v5);}
function __fn1(v6){
return v6;}
function __fn2(){
return __sumMake("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",true ,({}));}
function __fn3(v7){
return __sumMake("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",true ,v7));}
function __fn4(v8){
return __sumMake("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",true ,v8)));}
function __fn5(v9){
return __sumMake("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",true ,v9))));}
function __fn6(v10){
return __sumMake("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",false ,({Ok:v10})))));}
function __fn7(v11){
return __sumMake("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",false ,({Err:v11})))));}
function __fn8(v12,v13){
const v14=v12;
let v15=({None:null});
for(let v16=v14.length-1;v16>=0;v16--){
const v17=v14[v16];
const v18=v17;
const v19=v18["key"];
const v20=v13;
let v21;if((v19===v20)){
const v22=v17;
v21=({Some:v22["value"]});}else{
v21=v15;}
v15=v21;
}
return v15;}
function __fn9(v23,v24){
const v25=v23;
const v26=v25;
const v27=__sumView("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",v26);
let v28;if(Object.hasOwn(v27,"Ok")){
const v29=v27["Ok"];
v28=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject"});}else{
const v30=v27["Err"];
const v31=__sumView("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",v30);
let v32;if(Object.hasOwn(v31,"Ok")){
const v33=v31["Ok"];
const v34=v33;
const v35=v34;
v32=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject"});}else{
const v36=v31["Err"];
const v37=__sumView("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",v36);
let v38;if(Object.hasOwn(v37,"Ok")){
const v39=v37["Ok"];
const v40=v39;
const v41=v40;
v38=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject"});}else{
const v42=v37["Err"];
const v43=__sumView("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",v42);
let v44;if(Object.hasOwn(v43,"Ok")){
const v45=v43["Ok"];
const v46=v45;
const v47=v46;
v44=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject"});}else{
const v48=v43["Err"];
const v49=v48;
let v50;if(Object.hasOwn(v49,"Ok")){
const v51=v49["Ok"];
const v52=v51;
const v53=v52;
v50=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject"});}else{
const v54=v49["Err"];
const v55=v54;
const v56=v55;
const v57=v56;
const v58=v57;
const v59=v24;
v50=({Ok:__fn8(v58,v59)});}
v44=v50;}
v38=v44;}
v32=v38;}
v28=v32;}
return v28;}
function __fn10(v60){
const v61=v60;
const v62=v61;
const v63=__sumView("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",v62);
let v64;if(Object.hasOwn(v63,"Ok")){
const v65=v63["Ok"];
v64=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject"});}else{
const v66=v63["Err"];
const v67=__sumView("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",v66);
let v68;if(Object.hasOwn(v67,"Ok")){
const v69=v67["Ok"];
const v70=v69;
const v71=v70;
v68=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject"});}else{
const v72=v67["Err"];
const v73=__sumView("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",v72);
let v74;if(Object.hasOwn(v73,"Ok")){
const v75=v73["Ok"];
const v76=v75;
const v77=v76;
v74=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject"});}else{
const v78=v73["Err"];
const v79=__sumView("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",v78);
let v80;if(Object.hasOwn(v79,"Ok")){
const v81=v79["Ok"];
const v82=v81;
const v83=v82;
v80=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject"});}else{
const v84=v79["Err"];
const v85=v84;
let v86;if(Object.hasOwn(v85,"Ok")){
const v87=v85["Ok"];
const v88=v87;
const v89=v88;
v86=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject"});}else{
const v90=v85["Err"];
const v91=v90;
const v92=v91;
const v93=v92;
v86=({Ok:v93});}
v80=v86;}
v74=v80;}
v68=v74;}
v64=v68;}
return v64;}
function __fn11(v94){
const v95=v94;
const v96=v95;
const v97=__sumView("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",v96);
let v98;if(Object.hasOwn(v97,"Ok")){
const v99=v97["Ok"];
v98=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray"});}else{
const v100=v97["Err"];
const v101=__sumView("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",v100);
let v102;if(Object.hasOwn(v101,"Ok")){
const v103=v101["Ok"];
const v104=v103;
const v105=v104;
v102=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray"});}else{
const v106=v101["Err"];
const v107=__sumView("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",v106);
let v108;if(Object.hasOwn(v107,"Ok")){
const v109=v107["Ok"];
const v110=v109;
const v111=v110;
v108=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray"});}else{
const v112=v107["Err"];
const v113=__sumView("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",v112);
let v114;if(Object.hasOwn(v113,"Ok")){
const v115=v113["Ok"];
const v116=v115;
const v117=v116;
v114=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray"});}else{
const v118=v113["Err"];
const v119=v118;
let v120;if(Object.hasOwn(v119,"Ok")){
const v121=v119["Ok"];
const v122=v121;
const v123=v122;
v120=({Ok:v123});}else{
const v124=v119["Err"];
const v125=v124;
const v126=v125;
const v127=v126;
v120=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray"});}
v114=v120;}
v108=v114;}
v102=v108;}
v98=v102;}
return v98;}
function __fn12(v128){
const v129=v128;
const v130=v129;
const v131=__sumView("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",v130);
let v132;if(Object.hasOwn(v131,"Ok")){
const v133=v131["Ok"];
v132=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"});}else{
const v134=v131["Err"];
const v135=__sumView("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",v134);
let v136;if(Object.hasOwn(v135,"Ok")){
const v137=v135["Ok"];
const v138=v137;
const v139=v138;
v136=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"});}else{
const v140=v135["Err"];
const v141=__sumView("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",v140);
let v142;if(Object.hasOwn(v141,"Ok")){
const v143=v141["Ok"];
const v144=v143;
const v145=v144;
v142=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"});}else{
const v146=v141["Err"];
const v147=__sumView("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",v146);
let v148;if(Object.hasOwn(v147,"Ok")){
const v149=v147["Ok"];
const v150=v149;
const v151=v150;
v148=({Ok:v151});}else{
const v152=v147["Err"];
const v153=v152;
let v154;if(Object.hasOwn(v153,"Ok")){
const v155=v153["Ok"];
const v156=v155;
const v157=v156;
v154=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"});}else{
const v158=v153["Err"];
const v159=v158;
const v160=v159;
const v161=v160;
v154=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"});}
v148=v154;}
v142=v148;}
v136=v142;}
v132=v136;}
return v132;}
function __fn13(v162){
const v163=v162;
const v164=v163;
const v165=__sumView("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",v164);
let v166;if(Object.hasOwn(v165,"Ok")){
const v167=v165["Ok"];
v166=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber"});}else{
const v168=v165["Err"];
const v169=__sumView("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",v168);
let v170;if(Object.hasOwn(v169,"Ok")){
const v171=v169["Ok"];
const v172=v171;
const v173=v172;
v170=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber"});}else{
const v174=v169["Err"];
const v175=__sumView("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",v174);
let v176;if(Object.hasOwn(v175,"Ok")){
const v177=v175["Ok"];
const v178=v177;
const v179=v178;
v176=({Ok:v179});}else{
const v180=v175["Err"];
const v181=__sumView("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",v180);
let v182;if(Object.hasOwn(v181,"Ok")){
const v183=v181["Ok"];
const v184=v183;
const v185=v184;
v182=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber"});}else{
const v186=v181["Err"];
const v187=v186;
let v188;if(Object.hasOwn(v187,"Ok")){
const v189=v187["Ok"];
const v190=v189;
const v191=v190;
v188=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber"});}else{
const v192=v187["Err"];
const v193=v192;
const v194=v193;
const v195=v194;
v188=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber"});}
v182=v188;}
v176=v182;}
v170=v176;}
v166=v170;}
return v166;}
function __fn14(v196){
const v197=v196;
const v198=v197;
const v199=__sumView("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",v198);
let v200;if(Object.hasOwn(v199,"Ok")){
const v201=v199["Ok"];
v200=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean"});}else{
const v202=v199["Err"];
const v203=__sumView("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",v202);
let v204;if(Object.hasOwn(v203,"Ok")){
const v205=v203["Ok"];
const v206=v205;
const v207=v206;
v204=({Ok:v207});}else{
const v208=v203["Err"];
const v209=__sumView("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",v208);
let v210;if(Object.hasOwn(v209,"Ok")){
const v211=v209["Ok"];
const v212=v211;
const v213=v212;
v210=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean"});}else{
const v214=v209["Err"];
const v215=__sumView("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",v214);
let v216;if(Object.hasOwn(v215,"Ok")){
const v217=v215["Ok"];
const v218=v217;
const v219=v218;
v216=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean"});}else{
const v220=v215["Err"];
const v221=v220;
let v222;if(Object.hasOwn(v221,"Ok")){
const v223=v221["Ok"];
const v224=v223;
const v225=v224;
v222=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean"});}else{
const v226=v221["Err"];
const v227=v226;
const v228=v227;
const v229=v228;
v222=({Err:"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean"});}
v216=v222;}
v210=v216;}
v204=v210;}
v200=v204;}
return v200;}
function __fn15(v230,v231,v232){
const v233=v231;
const v234=v232;
const v235=({["key"]:v233,["value"]:v234});
const v236=[v235];
const v237=v230;
const v238=v237.length;
const v239=[];
for(let v240=0;v240<v238;v240++){
const v241=v237[v240];
const v242=v241;
const v243=v242["key"];
const v244=v231;
if(!(v243===v244)){v239.push(v241);}
}
const v245=v239;
const v246=v236.length;
const v247=v245.length;
const v248=new Array(v246+v247);
for(let v249=0;v249<v246;v249++){v248[v249]=v236[v249];}
for(let v250=0;v250<v247;v250++){v248[v246+v250]=v245[v250];}
return v248;}
function __fn16(v251,v252,v253){
const v254=v251;
const v255=__fn10(v254);
let v256;if(Object.hasOwn(v255,"Ok")){
const v257=v255["Ok"];
const v258=v257;
const v259=v258;
const v260=v252;
const v261=v253;
v256=({Ok:__sumMake("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",false ,({Err:__fn15(v259,v260,v261)})))))});}else{
const v262=v255["Err"];
v256=({Err:v262});}
return v256;}
function __fn17(v263,v264){
const v265=v263;
const v266=__fn10(v265);
let v267;if(Object.hasOwn(v266,"Ok")){
const v268=v266["Ok"];
const v269=v268;
const v270=v269;
const v271=v270.length;
const v272=[];
for(let v273=0;v273<v271;v273++){
const v274=v270[v273];
const v275=v274;
const v276=v275["key"];
const v277=v264;
if(!(v276===v277)){v272.push(v274);}
}
v267=({Ok:__sumMake("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",false ,({Err:v272})))))});}else{
const v278=v266["Err"];
v267=({Err:v278});}
return v267;}
function __fn18(v279,v280){
const v281=v279;
const v282=__fn10(v281);
let v283;if(Object.hasOwn(v282,"Ok")){
const v284=v282["Ok"];
const v285=v284;
const v286=v285;
const v287=v286.length;
const v288=[];
for(let v289=0;v289<v287;v289++){
const v290=v286[v289];
const v291=v280;
let v292=false;
for(let v293=0;v293<v291.length;v293++){
const v294=v291[v293];
const v295=v292;
let v296=v295;if(!v296){
const v297=v294;
const v298=v290;
const v299=v298["key"];
v296=(v297===v299);}
v292=v296;
}
if(v292){v288.push(v290);}
}
v283=({Ok:__sumMake("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",false ,__sumMake("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",false ,({Err:v288})))))});}else{
const v300=v282["Err"];
v283=({Err:v300});}
return v283;}
function __into15(v301,v302,v303,v304){
const v305=v302;
const v306=v303;
const v307=({["key"]:v305,["value"]:v306});
const v308=[v307];
const v309=v301;
const v310=v309.length;
const v311=[];
for(let v312=0;v312<v310;v312++){
const v313=v309[v312];
const v314=v313;
const v315=v314["key"];
const v316=v302;
if(!(v315===v316)){v311.push(v313);}
}
const v317=v311;
const v318=v308.length;
const v319=v317.length;
for(let v320=0;v320<v318;v320++){
v304[0+v320]=__intoOutput15(v308[v320]);
}
for(let v321=0;v321<v319;v321++){
v304[v318+v321]=__intoOutput15(v317[v321]);
}
const v322=v318+v319;
return v322;}
const __namedTypes={"Row":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"active","type":{"kind":"bool"}},{"name":"metadata","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"Row"},"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"},"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"kind":"ref","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"},"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"},"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"kind":"ref","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"},"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"},"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}};
// Portable snapshot ABI shared with native/Wasm. Hashing uses Web Crypto.
function __snapshotLimits(limits={}){
 const result={bytes:64*1024*1024,values:1000000,depth:128,...limits};
 for(const k of ['bytes','values','depth'])if(!Number.isSafeInteger(result[k])||result[k]<0||result[k]>(k==='depth'?128:k==='values'?1000000:64*1024*1024))throw Error('invalid snapshot limits');
 return result;
}
const __hash=async bytes=>new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256',bytes));
function __snapshotWriter(limits){
 const out=[];let left=limits.values,maxDepth=0;
 function bytes(xs){if(xs.length>limits.bytes-out.length)throw Error('snapshot byte limit exceeded');for(const x of xs)out.push(x);}
 function integer(n,size){n=BigInt(n);for(let i=0;i<size;i++){bytes([Number(n&255n)]);n>>=8n;}}
 function raw(xs){integer(xs.length,8);bytes(xs);}
 function value(v,t,depth=0,bindings=[]){maxDepth=Math.max(maxDepth,depth);if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{value(v,t.body,depth+1,bindings);}finally{bindings.pop();}break;
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');value(v,bound[1],depth+1,bindings);break;}
  case 'unit':break;case 'bool':bytes([v?1:0]);break;
  case 'u32':case 'i32':case 'f32':integer(v,4);break;case 'u64':integer(v,8);break;
  case 'vector':if(v.length!==t.size)throw Error('vector dimension mismatch');for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'int':{let n=v<0n?-v:v;const xs=[];while(n){if(xs.length>=4096)throw Error('snapshot Int exceeds size limit');xs.push(Number(n&255n));n>>=8n;}bytes([v===0n?0:v>0n?1:2]);raw(xs);break;}
  case 'string':raw(__encoder.encode(v));break;
  case 'id':integer(BigInt('0x'+v),16);break;
  case 'enum':integer(t.variants.indexOf(v),4);break;
  case 'record':for(const f of t.fields)value(t.elided?v:v[f.name],f.type,depth+1,bindings);break;
  case 'list':if(v.length>left)throw Error('snapshot value limit exceeded');integer(v.length,8);for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'option':if(Object.hasOwn(v,'Some')){bytes([1]);value(v.Some,t.element,depth+1,bindings);}else bytes([0]);break;
  case 'result':{const branch=t.sum_key?__sumView(t.sum_key,v):v;if(Object.hasOwn(branch,'Ok')){bytes([0]);value(branch.Ok,t.ok,depth+1,bindings);}else{bytes([1]);value(branch.Err,t.error,depth+1,bindings);}break;}
  default:throw Error('unsupported snapshot type');
 }}
 return {bytes,integer,raw,value,charge(cells,depth){left-=cells;if(left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');},get maxDepth(){return maxDepth;},get left(){return left;},finish:()=>new Uint8Array(out)};
}
async function __snapshotEncode(meta,state,options){
 const limits=__snapshotLimits(options),w=__snapshotWriter(limits);
 w.integer(state.version,8);
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const rows=[...state.tables[r.index].entries()].sort((a,b)=>__keyCompare(a[0],b[0],r.key));if(rows.length>Math.floor(w.left/2))throw Error('snapshot row limit exceeded');w.integer(rows.length,8);for(const [k,v]of rows){
  if(!meta.snapshotRows){w.value(k,r.snapshotKey??r.key);w.value(v,r.snapshotValue??r.value);continue;}
  const cache=state.snapshotRows[r.index];let packed=cache.get(k);
  if(!packed){const row=__snapshotWriter(limits);row.value(k,r.snapshotKey??r.key);row.value(v,r.snapshotValue??r.value);packed={bytes:row.finish(),cells:limits.values-row.left,depth:row.maxDepth};cache.set(k,packed);}
  w.charge(packed.cells,packed.depth);w.bytes(packed.bytes);
 }}
 w.integer(state.outbox.length,8);
 for(const e of state.outbox){const channel=meta.events.findIndex(t=>t.name===e.channel);w.integer(e.commit,8);w.integer(e.position,8);w.integer(channel,4);w.value(e.value,meta.events[channel].snapshotType??meta.events[channel].type);}
 const payload=w.finish(),header=__snapshotWriter(limits);header.bytes([86,76,83,84,65,84,69,0,1,0,1,0]);header.bytes(meta.snapshot.program);header.bytes(meta.snapshot.schema);header.integer(payload.length,8);header.bytes(payload);
 const bytes=header.finish();if(bytes.length+32>limits.bytes)throw Error('snapshot byte limit exceeded');const digest=await __hash(bytes);const result=new Uint8Array(bytes.length+32);result.set(bytes);result.set(digest,bytes.length);return result;
}
async function __snapshotDecode(meta,input,options){
 const limits=__snapshotLimits(options);
 if(!(input instanceof Uint8Array)&&!Array.isArray(input))throw Error('expected snapshot bytes');
 if(input.length>limits.bytes||input.length<116)throw Error('snapshot byte length invalid');
 if(Array.isArray(input)&&input.some(b=>!Number.isInteger(b)||b<0||b>255))throw Error('invalid snapshot bytes');
 const bytes=new Uint8Array(input); // capture before asynchronous integrity work
 function same(a,b){return a.length===b.length&&a.every((v,i)=>v===b[i]);}
 if(!same(bytes.subarray(0,12),[86,76,83,84,65,84,69,0,1,0,1,0]))throw Error('snapshot format or semantics version mismatch');
 if(!same(bytes.subarray(12,44),meta.snapshot.program)||!same(bytes.subarray(44,76),meta.snapshot.schema))throw Error('snapshot program or schema identity mismatch');
 const end=bytes.length-32,digest=await __hash(bytes.subarray(0,end));if(!same(digest,bytes.subarray(end)))throw Error('snapshot integrity check failed');
 let at=76,left=limits.values;
 function take(n){if(!Number.isSafeInteger(n)||n<0||n>end-at)throw Error('truncated snapshot');const x=bytes.subarray(at,at+n);at+=n;return x;}
 function integer(size){const xs=take(size);let n=0n;for(let i=size-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return n;}
 function length(){const n=integer(8);if(n>BigInt(Number.MAX_SAFE_INTEGER))throw Error('snapshot length not addressable');return Number(n);}
 function sequence(){const n=length();if(n>left)throw Error('snapshot value limit exceeded');return n;}
 function raw(){return take(length());}
 const n=length();if(n!==end-84)throw Error('snapshot payload length mismatch');
 function value(t,depth=0,bindings=[]){if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{return value(t.body,depth+1,bindings);}finally{bindings.pop();}
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');return value(bound[1],depth+1,bindings);}
  case 'unit':return null;case 'bool':{const b=take(1)[0];if(b>1)throw Error('invalid Bool tag');return b===1;}
  case 'u32':case 'f32':return Number(integer(4));case 'i32':return Number(BigInt.asIntN(32,integer(4)));case 'u64':return integer(8);
  case 'vector':{const xs=[];for(let i=0;i<t.size;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'int':{const sign=take(1)[0],xs=raw();if(xs.length>4096)throw Error('snapshot Int exceeds size limit');if(!((sign===0&&xs.length===0)||((sign===1||sign===2)&&xs.length>0&&xs[xs.length-1]!==0)))throw Error('noncanonical signed integer');let n=0n;for(let i=xs.length-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return sign===2?-n:n;}
  case 'string':return new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(raw());
  case 'id':return integer(16).toString(16).padStart(32,'0');
  case 'enum':{const i=Number(integer(4));if(i>=t.variants.length)throw Error('invalid enum tag');return t.variants[i];}
  case 'record':if(t.elided)return value(t.fields[0].type,depth+1,bindings);return Object.fromEntries(t.fields.map(f=>[f.name,value(f.type,depth+1,bindings)]));
  case 'list':{const n=sequence(),xs=[];for(let i=0;i<n;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'option':{const tag=take(1)[0];if(tag===0)return {None:null};if(tag===1)return {Some:value(t.element,depth+1,bindings)};throw Error('invalid Option tag');}
  case 'result':{const tag=take(1)[0];if(tag===0){const child=value(t.ok,depth+1,bindings);return t.sum_key?__sumMake(t.sum_key,true,child):{Ok:child};}if(tag===1){const child=value(t.error,depth+1,bindings);return t.sum_key?__sumMake(t.sum_key,false,child):{Err:child};}throw Error('invalid Result tag');}
  default:throw Error('unsupported snapshot type');
 }}
 const version=integer(8),tables=meta.roots.map(()=>new Map());
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const n=sequence();if(n>Math.floor(left/2))throw Error('snapshot row limit exceeded');let prior;for(let i=0;i<n;i++){const k=value(r.snapshotKey??r.key),v=value(r.snapshotValue??r.value);if(i&&__keyCompare(prior,k,r.key)>=0)throw Error('duplicate or unordered snapshot key');tables[r.index].set(k,v);prior=k;}}
 const count=sequence(),outbox=[];let prior;
 for(let i=0;i<count;i++){const commit=integer(8),position=integer(8),channel=Number(integer(4));if(!meta.events[channel])throw Error('unknown snapshot event channel');const v=value(meta.events[channel].snapshotType??meta.events[channel].type);if(commit===0n||commit>version||(prior&&(commit<prior.commit||(commit===prior.commit&&position<=prior.position))))throw Error('invalid snapshot event sequence');const e={commit,position,channel:meta.events[channel].name,value:v};outbox.push(e);prior=e;}
 if(at!==end)throw Error('trailing snapshot payload');return {version,tables,outbox};
}
// Fixed subscription lifecycle. Root/output edges derive from checked source;
// values and ownership codecs are compiled from each query's declared type.
function __createObservers(prepare){
 const subscriptions=new Map(),byRoot=new Map(),errors=[],directRoots=[];
 let pending=[],spare=[];
 let next=0,held=0,flushing=false;
 function report(s,error,phase){errors.push({query:s?.query??null,error,phase});if(s?.onError)try{s.onError(error);}catch(e){errors.push({query:s.query,error:e,phase:'error-handler'});}}
 function flush(initialPasses=0){
  if(held||flushing||!pending.length)return;
  flushing=true;let passes=initialPasses;
  try{
   while(pending.length&&!held){
    if(++passes>1024){report(null,Error('subscription publication budget exhausted'),'publication');break;}
    const affected=pending;pending=spare;spare=affected;
    for(const s of affected)s.queued=false;
    // Snapshot every affected value before consumers run. Deliveries reside in
    // the stable subscription slots; no per-delivery tuple is allocated.
    for(const s of affected){if(!s.active)continue;s.deliver=false;
     try{if(s.pair){const a=s.pairState?s.pairState.keeps[s.keep0]:s.read0(),b=s.pairState?s.pairState.keeps[s.keep1]:s.read1();if(s.value0!==a||s.value1!==b){s.value0=a;s.value1=b;s.delivery0=a;s.delivery1=b;s.deliver=true;}}else{const value=s.capture(s.read());if(!s.equal(s.value,value)){s.value=value;s.delivery=value;s.deliver=true;}}}
     catch(e){report(s,e,'query');}
    }
    for(const s of affected){if(!s.active||!s.deliver)continue;const value=s.delivery;s.deliver=false;s.delivery=undefined;
     try{if(s.pair)s.callback(s.delivery0,s.delivery1);else s.callback(s.output(value));}catch(e){report(s,e,'listener');}
    }
    affected.length=0;
   }
  }finally{flushing=false;}
 }
 function install(query,q,callback,{immediate=true,onError}={}){
  if(typeof callback!=='function'||onError!==undefined&&typeof onError!=='function')throw TypeError('subscription callback');
  const s={...q,id:next++,query,callback,onError,active:true,queued:false,deliver:false,delivery:undefined};
  if(s.pair){s.value0=s.pairState?s.pairState.keeps[s.keep0]:s.read0();s.value1=s.pairState?s.pairState.keeps[s.keep1]:s.read1();}else{s.value=s.capture(s.read());}subscriptions.set(s.id,s);
  for(const root of s.roots){let ids=byRoot.get(root);if(!ids)byRoot.set(root,ids=[]);ids.push(s);directRoots[root]=ids.length===1&&s.pairState?s:null;}
  const dispose=()=>{if(!subscriptions.delete(s.id))return;s.active=false;for(const root of s.roots){const ids=byRoot.get(root);ids.splice(ids.indexOf(s),1);directRoots[root]=ids.length===1&&ids[0].pairState?ids[0]:null;if(!ids.length)byRoot.delete(root);}};
  if(immediate)try{if(s.pair)callback(s.value0,s.value1);else callback(s.output(s.value));}catch(e){dispose();throw e;}
  return dispose;
 }
 function enqueueRoot(root,outputs,epoch){
  const slots=byRoot.get(root);if(!slots)return;
  for(let i=0;i<slots.length;i++){
   const s=slots[i];if(s.queued)continue;
   if(outputs!==null&&s.outputs?.length){
    let changed=false;for(let j=0;j<s.outputs.length;j++)if(epoch?outputs[s.outputs[j]]===epoch:outputs.has(s.outputs[j])){changed=true;break;}
    if(!changed)continue;
   }
   s.queued=true;pending.push(s);
  }
 }
 return {
  directRoots,
  get active(){return subscriptions.size!==0;},
  subscribe(query,args,callback,options){return install(query,prepare(query,args),callback,options);},
  subscribeGroup(queries,callback,options){
   if(!Array.isArray(queries)||!queries.length)throw TypeError('subscription group requires queries');
   const qs=queries.map(q=>typeof q==='string'?prepare(q,[]):prepare(q.query,q.args??[]));
   const roots=[...new Set(qs.flatMap(q=>q.roots))];
   // An unknown dependency forces ordinary root invalidation for the group.
   const outputs=qs.every(q=>q.outputs?.length)?[...new Set(qs.flatMap(q=>q.outputs))]:[];
   const scalar=qs.every(q=>q.scalar),direct=qs.every(q=>q.direct);
   return install(queries,{roots,outputs,read:direct?()=>qs.map(q=>q.direct()):()=>qs.map(q=>q.read()),capture:scalar?values=>values:values=>values.map((v,i)=>qs[i].capture(v)),output:scalar?values=>values.slice():values=>values.map((v,i)=>qs[i].output(v)),equal:scalar?(a,b)=>a.every((v,i)=>v===b[i]):(a,b)=>a.every((v,i)=>qs[i].equal(v,b[i]))},callback,options);
  },
  subscribeValues(queries,callback,options){
   if(!Array.isArray(queries)||!queries.length)throw TypeError('subscription group requires queries');
   if(typeof callback!=='function')throw TypeError('subscription callback');
   const qs=queries.map(q=>typeof q==='string'?prepare(q,[]):prepare(q.query,q.args??[]));
   if(qs.length===2&&qs.every(q=>q.scalar)){
    const roots=[...new Set(qs.flatMap(q=>q.roots))],outputs=qs.every(q=>q.outputs?.length)?[...new Set(qs.flatMap(q=>q.outputs))]:[];
    const pairState=qs[0].committed&&qs[1].committed&&qs[0].committed.state===qs[1].committed.state?qs[0].committed.state:null;
    return install(queries,{roots,outputs,pair:true,pairState,keep0:qs[0].committed?.keep,keep1:qs[1].committed?.keep,read0:qs[0].direct||qs[0].read,read1:qs[1].direct||qs[1].read},callback,options);
   }
   return this.subscribeGroup(queries,values=>callback(...values),options);
  },
  commit(roots,outputs=null){
   if(!subscriptions.size)return;
   for(const root of roots)enqueueRoot(root,outputs,false);
   flush();
  },
  // A checked single-root action supplies a reusable array of changed outputs.
  // No root carrier, Set, affected-ID array or Map lookup per delivery is needed.
  commitRoot(root,outputs=null,epoch=0){
   if(!subscriptions.size)return;
   const s=directRoots[root];
   // The one-consumer schedule reads its committed slots exactly once. It also
   // handles held/reentrant publication without reconstructing output flags.
   if(s){
    const a=s.pairState.keeps[s.keep0],b=s.pairState.keeps[s.keep1];
    if(s.value0===a&&s.value1===b)return;
    if(!held&&!flushing&&!pending.length){
     s.value0=a;s.value1=b;flushing=true;
     try{s.callback(a,b);}catch(e){report(s,e,'listener');}finally{flushing=false;}
     flush(1);return;
    }
    if(!s.queued){s.queued=true;pending.push(s);}flush();return;
   }
   enqueueRoot(root,outputs,epoch);flush();
  },
  hold(){held++;return pending.slice();},
  release(){if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  rollback(mark){for(const s of pending)s.queued=false;pending.length=0;for(const s of mark)if(s.active&&!s.queued){s.queued=true;pending.push(s);}if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  batch(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('batch callback must be synchronous');held++;
   try{const value=callback();if(value&&typeof value.then==='function')throw TypeError('state batch callback must be synchronous');return value;}
   finally{held--;flush();}
  },
  flush,takeErrors(){return errors.splice(0);}
 };
}
function __versionWord(v){return typeof v==='number'?BigInt(v):v;}
function __storedCommit(meta,v){return meta.compactCommits&&v<=9007199254740991n?Number(v):v;}
function __nextCommit(v){return typeof v==='number'&&v<9007199254740991?v+1:BigInt(v)+1n;}
// Private column event log. Public records and portable event ordering are unchanged.
// Private event storage. Public events and portable snapshots keep their ordinary
// ordered records. Chunks bound array growth and retain no per-event record.
class __EventColumns {
 constructor(channels,compact=false){this.channels=channels;this.compact=compact;this.commits=[];this.values=[];this.positions=null;this.channelValues=channels.length===1?null:[];}
 get length(){return this.commits.length;}
 set length(n){if(!Number.isSafeInteger(n)||n<0||n>this.length)throw Error('event log truncate');this.commits.length=n;this.values.length=n;if(this.positions)this.positions.length=n;if(this.channelValues)this.channelValues.length=n;}
 append(commit,position,channel,value){const i=this.commits.length;this.commits.push(commit);this.values.push(value);if(this.channelValues)this.channelValues.push(channel);if(position!==0n&&!this.positions)this.positions=new Array(i).fill(0n);if(this.positions)this.positions.push(position);}
 push(e){this.append(this.compact&&e.commit<=9007199254740991n?Number(e.commit):e.commit,e.position,e.channel,e.value);return this.length;}
 at(i){if(i<0)i+=this.length;if(i<0||i>=this.length)return undefined;return {commit:__versionWord(this.commits[i]),position:this.positions?this.positions[i]:0n,channel:this.channelValues?this.channelValues[i]:this.channels[0],value:this.values[i]};}
 *[Symbol.iterator](){for(let i=0;i<this.length;i++)yield this.at(i);}
 map(f){const out=new Array(this.length);for(let i=0;i<this.length;i++)out[i]=f(this.at(i),i);return out;}
 filter(f){const out=new __EventColumns(this.channels,this.compact);for(let i=0;i<this.length;i++){const e=this.at(i);if(f(e,i))out.push(e);}return out;}
}
function __eventLog(meta,events=[]){
 if(!meta.eventColumns)return meta.compactCommits?events.map(e=>({...e,commit:__storedCommit(meta,e.commit)})):events;
 const log=new __EventColumns(meta.events.map(e=>e.name),meta.compactCommits);for(const e of events)log.append(__storedCommit(meta,e.commit),e.position,e.channel,e.value);return log;
}
// CALLER CONTRACT: arguments must match declared types; malformed data may throw or corrupt state.
// Fixed state primitives used by emitted action bodies, without an AST evaluator.
class __Abort {constructor(value){this.value=value;}}
function __preflightError(message){throw Error(message);}
function __try(value){if(Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value.Ok;}
function __nested(value,change){if(change && Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value;}
function __equal(a,b){if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object')return false;const ak=Object.keys(a),bk=Object.keys(b);return ak.length===bk.length&&ak.every(k=>Object.hasOwn(b,k)&&__equal(a[k],b[k]));}
function __checked(op,a,b,bits){const x=BigInt(a),y=BigInt(b),n=op==='checked_add'?x+y:op==='checked_sub'?x-y:x*y;const min=bits===-32?-2147483648n:0n,max=bits===-32?2147483648n:1n<<BigInt(bits);return n<min||n>=max?{Err:'ArithmeticError.Overflow'}:{Ok:Math.abs(bits)===32?Number(n):n};}
function __okOr(value,error){return Object.hasOwn(value,'Some')?{Ok:value.Some}:{Err:error};}
function __mapValue(value,kind,method,fn){
 if(kind==='list')return value[method](fn);
 if(kind==='option')return Object.hasOwn(value,'Some')?{Some:fn(value.Some)}:{None:null};
 const tag=method==='map_err'?'Err':'Ok';return Object.hasOwn(value,tag)?{[tag]:fn(value[tag])}:value;
}
const __encoder=new TextEncoder();
function __tick(ctx){if(--ctx.fuel<0)throw Error('Ink state execution budget exhausted');}
function __keyCompare(a,b,type){
 if(type.kind==='string'){let i=0,j=0;while(i<a.length&&j<b.length){const x=a.codePointAt(i),y=b.codePointAt(j);if(x!==y)return x-y;i+=x>65535?2:1;j+=y>65535?2:1;}return (i<a.length?1:0)-(j<b.length?1:0);}
 return a<b?-1:a>b?1:0;
}
// A table's ordered key view is reused until membership changes. Values are
// fetched at traversal time, so replacement never leaves stale row payloads.
const __tableOrder=new WeakMap();
function __keyPosition(keys,key,type){let low=0,high=keys.length;while(low<high){const middle=(low+high)>>>1;if(__keyCompare(keys[middle],key,type)<0)low=middle+1;else high=middle;}return low;}
function __tableMembership(rt,index,key,present){
 const view=__tableOrder.get(rt.tables[index]);if(!view)return;
 const at=__keyPosition(view.keys,key,rt.meta.roots[index].key);
 if((at<view.keys.length&&view.keys[at]===key)===present)view.pending.delete(key);
 else view.pending.set(key,present);
}
function __orderedKeys(rt,index){
 const table=rt.tables[index],type=rt.meta.roots[index].key;let view=__tableOrder.get(table);
 if(!view){view={keys:[...table.keys()].sort((a,b)=>__keyCompare(a,b,type)),pending:new Map()};__tableOrder.set(table,view);}
 if(view.pending.size){
  const changes=[...view.pending.keys()].sort((a,b)=>__keyCompare(a,b,type)),merged=[];let i=0,j=0;
  while(i<view.keys.length||j<changes.length){
   if(j===changes.length||(i<view.keys.length&&__keyCompare(view.keys[i],changes[j],type)<0))merged.push(view.keys[i++]);
   else{const key=changes[j++];if(i<view.keys.length&&view.keys[i]===key)i++;if(view.pending.get(key))merged.push(key);}
  }
  view.keys=merged;view.pending.clear();
 }
 const keys=view.keys;
 const cell=rt.cell;
 if(cell&&cell.index===index&&table.has(cell.key)!==(cell.next!==undefined)){
  if(cell.next===undefined)return keys.filter(k=>k!==cell.key);
  return [...keys,cell.key].sort((a,b)=>__keyCompare(a,b,rt.meta.roots[index].key));
 }
 return keys;
}
function __cellGet(rt,index,key){const cell=rt.cell;return cell&&cell.index===index&&cell.key===key?cell.next:rt.tables[index].get(key);}
function __readTable(rt,index){const cell=rt.cell;if(!cell||cell.index!==index)return rt.tables[index];const table=new Map(rt.tables[index]);if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);return table;}
// The first before-image of each cell suffices for whole-transaction rollback.
function __remember(rt,index,key,present,value){if(rt.cellMode)return;if(!rt.seen[index].has(key)){rt.seen[index].add(key);rt.undo.push([index,key,present,value]);}}
// Only scalar keeps are retained. Reverse edges come from checked source effects.
// Before-images preserve cached values across failed actions; host rollback and
// restore discard caches rather than serializing them into logical snapshots.
function __invalidateKeeps(rt,index){
 if(rt.observers?.active)rt.changedRoots.add(index);
 if(!rt.keeps||rt.cellMode)return;
 for(const keep of rt.meta.keepInvalidations[index]){
  if(!rt.keepDirty[keep]){rt.keepDirty[keep]=1;rt.keepUndoIndices[rt.keepUndoCount++]=keep;rt.keepBefore[keep]=rt.keeps[keep];}
  rt.keeps[keep]=undefined;
 }
}
function __restoreKeeps(rt){for(let i=rt.keepUndoCount-1;i>=0;i--){const keep=rt.keepUndoIndices[i];rt.keeps[keep]=rt.keepBefore[keep];}}
function __clearKeepJournal(rt){for(let i=0;i<rt.keepUndoCount;i++){const keep=rt.keepUndoIndices[i];rt.keepDirty[keep]=0;rt.keepBefore[keep]=undefined;}rt.keepUndoCount=0;}
function __rebuildViews(rt){
 for(const view of rt.views){let value=view.zero;for(const [key,row]of rt.tables[view.root])value=view.combine(value,view.contribution(key,row));rt.keeps[view.keep]=value;}
}
function __viewValue(view,value,key,oldValue,newValue){
 if(oldValue===undefined)return view.insert?view.insert(value,key,newValue):view.combine(value,view.contribution(key,newValue));
 if(newValue===undefined)return view.remove?view.remove(value,key,oldValue):view.combine(value,view.inverse(view.contribution(key,oldValue)));
 return view.replace?view.replace(value,key,oldValue,newValue):view.combine(view.combine(value,view.inverse(view.contribution(key,oldValue))),view.contribution(key,newValue));
}
function __updateViews(rt,index,key,oldValue,newValue){
 if(rt.viewsByRoot[index].length===0)return null;
 const updates=rt.viewNext;
 for(const view of rt.viewsByRoot[index])updates[view.keep]=__viewValue(view,rt.keeps[view.keep],key,oldValue,newValue);
 return updates;
}
function __installViews(rt,updates,index){if(updates)for(const view of rt.viewsByRoot[index])rt.keeps[view.keep]=updates[view.keep];}
function __pendingView(rt,view){
 const keep=view.keep;
 if(rt.pendingValues[keep]===undefined){
  const cell=rt.cell;
  rt.pendingValues[keep]=__viewValue(view,rt.keeps[keep],cell.key,cell.prior,cell.next);
  rt.pendingIndices.push(keep);
 }
 return rt.pendingValues[keep];
}
function __prepareCell(rt){if(rt.cell){const prepare=rt.views.prepareRoots?.[rt.cell.index];if(prepare)prepare(rt,rt.cell);else for(const view of rt.viewsByRoot[rt.cell.index])__pendingView(rt,view);}}
function __invalidateSnapshotRow(rt,index,key){rt.snapshotRows?.[index].delete(key);}
function __writeCell(rt,index,key,next,prior){
 if(rt.cellMode){if(rt.cell)throw Error('checked single-cell bound exceeded');rt.cell={index,key,next,prior};}
 else{const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);if(rt.changeTracking)__recordChange(rt,index,key,prior,next);if((prior!==undefined)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);if(next===undefined)table.delete(key);else table.set(key,next);}
}
function __commitCell(rt){
 const cell=rt.cell;if(!cell)return;
 const table=rt.tables[cell.index];__invalidateSnapshotRow(rt,cell.index,cell.key);
 if(rt.changeTracking)__recordChange(rt,cell.index,cell.key,cell.prior,cell.next);
 if((cell.prior!==undefined)!==(cell.next!==undefined))__tableMembership(rt,cell.index,cell.key,cell.next!==undefined);
 if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);
 for(const keep of rt.meta.keepInvalidations[cell.index])rt.keeps[keep]=rt.pendingValues[keep];
 rt.cell=null;
}
// Preflight scratch has no logical state or rollback obligations. Definitions
// are the same admitted group operations used by ordinary cell maintenance.
function __prepareDirect(rt,index,key,prior,next){
 const prepare=rt.views.directRoots?.[index];
 if(prepare)prepare(rt,key,prior,next);
 else for(const view of rt.viewsByRoot[index])rt.viewNext[view.keep]=__viewValue(view,rt.keeps[view.keep],key,prior,next);
}
function __storeDirect(rt,index,key,prior,next,slot){
 const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);
 if((prior!==undefined)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);
 if(rt.changeTracking)__recordChange(rt,index,key,prior,next);
 if(slot===undefined){if(next===undefined)table.delete(key);else table.set(key,next);}
 else{
  // The checked preflight lookup retains the dense slot until this commit.
  // No callback or source write can intervene; sparse keys retain exact identity.
  if(slot<0){if(next===undefined)table.sparse.delete(key);else table.sparse.set(key,next);}else table.dense[slot]=next;
  if(prior===undefined&&next!==undefined)table.members.add(key);else if(prior!==undefined&&next===undefined)table.members.delete(key);
 }
}
function __commitDirect(rt,index,key,prior,next,slot){
 __storeDirect(rt,index,key,prior,next,slot);
 const publishOutputs=rt.meta.outputPublication&&rt.observers.active&&!rt.observers.directRoots[index];
 if(publishOutputs&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}

 for(const keep of rt.meta.keepInvalidations[index]){
  const value=rt.viewByKeep[keep]?rt.viewNext[keep]:undefined;
  if(publishOutputs)rt.changedOutputs[keep]=rt.keeps[keep]!==value?rt.changedOutputEpoch:0;
  rt.keeps[keep]=value;
 }
}
function __emit(rt,channel,value){
 if(rt.eventCount++===0){rt.eventChannel=channel;rt.eventValue=value;}
 else rt.staged.push([channel,value]);
}
// Checked prefix capacities are at most 2^20. Number conversion is exact
// inside that prefix; rounding a wide word cannot move it into the prefix.
// Wide keys retain their original full-width value in the sparse fallback.
class __DenseTable{
 constructor(capacity){this.limit=capacity;this.dense=[];for(let i=0;i<capacity;i++)this.dense.push(undefined);this.sparse=new Map();this.members=new Set();}
 slot(key){const i=Number(key);return Number.isInteger(i)&&i>=0&&i<this.limit?i:-1;}
 get size(){return this.members.size;}
 get(key){const i=this.slot(key);return i<0?this.sparse.get(key):this.dense[i];}
 has(key){return this.get(key)!==undefined;}
 set(key,value){const i=this.slot(key),present=i<0?this.sparse.has(key):this.dense[i]!==undefined;if(i<0)this.sparse.set(key,value);else this.dense[i]=value;if(!present)this.members.add(key);return this;}
 delete(key){const i=this.slot(key);if(i<0)this.sparse.delete(key);else this.dense[i]=undefined;return this.members.delete(key);}
 keys(){return this.members.keys();}
 *values(){for(const key of this.members)yield this.get(key);}
 *entries(){for(const key of this.members)yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
class __ColumnTable {
 constructor(root){
  this.limit=root.columnPrefix.capacity;this.keyBig=root.key.kind==='u64';
  this.fields=root.value.fields;this.exactNumbers=root.columnPrefix.exactNumbers;
  this.present=new Uint8Array(this.limit);this.count=0;this.sparse=new Map();
  this.lanes=this.fields.map(f=>f.type.kind==='u64'?(this.exactNumbers?new Float64Array(this.limit):new BigUint64Array(this.limit)):f.type.kind==='i32'?new Int32Array(this.limit):f.type.kind==='bool'?new Uint8Array(this.limit):new Uint32Array(this.limit));
  this.wide=this.fields.map(f=>f.type.kind==='u64'&&this.exactNumbers?new Map():null);
 }
 slot(key){const i=Number(key);return Number.isInteger(i)&&i>=0&&i<this.limit?i:-1;}
 get size(){return this.count+this.sparse.size;}
 has(key){const i=this.slot(key);return i<0?this.sparse.has(key):this.present[i]!==0;}
 get(key){const i=this.slot(key);if(i<0)return this.sparse.get(key);if(!this.present[i])return undefined;const row=Object.create(null);for(let j=0;j<this.fields.length;j++){const f=this.fields[j],v=this.lanes[j][i];row[f.name]=f.type.kind==='bool'?v!==0:f.type.kind==='u64'&&this.exactNumbers?(this.wide[j].get(i)??BigInt(v)):v;}return row;}
 set(key,row){const i=this.slot(key);if(i<0){this.sparse.set(key,row);return this;}for(let j=0;j<this.fields.length;j++){const f=this.fields[j],v=row[f.name];if(f.type.kind==='u64'&&this.exactNumbers){if(v<=9007199254740991n){this.lanes[j][i]=Number(v);this.wide[j].delete(i);}else{this.lanes[j][i]=0;this.wide[j].set(i,v);}}else this.lanes[j][i]=f.type.kind==='bool'?Number(v):v;}if(!this.present[i]){this.present[i]=1;this.count++;}return this;}
 delete(key){const i=this.slot(key);if(i<0)return this.sparse.delete(key);if(!this.present[i])return false;this.present[i]=0;this.count--;for(const wide of this.wide)wide?.delete(i);return true;}
 *keys(){for(let i=0;i<this.limit;i++)if(this.present[i])yield this.keyBig?BigInt(i):i;yield* this.sparse.keys();}
 *values(){for(const key of this.keys())yield this.get(key);}
 *entries(){for(const key of this.keys())yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
function __newTables(meta,prefixes,old){return meta.roots.map((root,i)=>{const t=root.columnPrefix?new __ColumnTable(root):prefixes[i]?new __DenseTable(prefixes[i]):new Map();if(old)for(const [k,v]of old[i])t.set(k,v);return t;});}
function __cachedKeep(ctx,rt,index,compute){
 if(rt.cell&&rt.meta.keepInvalidations[rt.cell.index].includes(index)){
  const view=rt.viewByKeep[index];
  if(view)return __pendingView(rt,view);
  if(rt.pendingValues[index]===undefined){rt.pendingValues[index]=compute(ctx,rt);rt.pendingIndices.push(index);}
  return rt.pendingValues[index];
 }
 const prior=rt.keeps[index];if(prior!==undefined)return prior;
 const value=compute(ctx,rt);rt.keeps[index]=value;return value;
}
function __tableContains(rt,index,key){return __cellGet(rt,index,key)!==undefined;}
function __tableGet(rt,index,key){const value=__cellGet(rt,index,key);return value===undefined?{None:null}:{Some:value};}
function __tablePut(rt,index,key,next,mode=0){
 const prior=rt.tables[index].get(key),present=prior!==undefined;
 if(mode===1&&present)throw Error('insert key already present');
 if(mode===2&&!present)throw Error('replace key absent');
 if(present&&__stateRootEquals[index](prior,next))return null;
 const updates=rt.cellMode?null:__updateViews(rt,index,key,prior,next);
 __invalidateKeeps(rt,index);__remember(rt,index,key,present,prior);
 __writeCell(rt,index,key,next,prior);__installViews(rt,updates,index);return null;
}
function __tableRemove(rt,index,key){
 const value=rt.tables[index].get(key);
 if(value===undefined)return {None:null};
 const updates=rt.cellMode?null:__updateViews(rt,index,key,value,undefined);
 __invalidateKeeps(rt,index);__remember(rt,index,key,true,value);
 __writeCell(rt,index,key,undefined,value);__installViews(rt,updates,index);return {Some:value};
}
function __table(rt,index,method,args){
 const key=args[0];
 if(method==='get')return __tableGet(rt,index,key);
 if(method==='contains')return __tableContains(rt,index,key);
 const table=rt.tables[index];
 if(method==='values'||method==='keys'){const keys=__orderedKeys(rt,index);return method==='keys'?keys.slice():keys.map(k=>__cellGet(rt,index,k));}
 if(method==='intersect_table'){const current=__readTable(rt,index),other=__readTable(rt,args[0]),small=current.size<=other.size?current:other,large=small===current?other:current;const result=[];for(const k of small.keys())if(large.has(k))result.push(k);return result.sort((a,b)=>__keyCompare(a,b,rt.meta.roots[index].key));}
 if(method==='intersect_keys'){const selected=new Set(args[0]);return __orderedKeys(rt,index).filter(k=>selected.has(k));}
 if(method==='put_many'){const keys=args[0],values=args[1];if(keys.length!==values.length)return {Err:'table bulk length mismatch'};for(let i=0;i<keys.length;i++)__table(rt,index,'put',[keys[i],values[i]]);return {Ok:null};}
 if(method==='remove_many'){for(const k of args[0])__table(rt,index,'remove',[k]);return null;}
 if(method==='remove')return __tableRemove(rt,index,key);
 return __tablePut(rt,index,key,args[1],method==='insert'?1:method==='replace'?2:0);
}

function __rollback(rt,mark){for(let i=rt.undo.length-1;i>=mark;i--){const [index,key,present,value]=rt.undo[i];const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);if(table.has(key)!==present)__tableMembership(rt,index,key,present);if(present)table.set(key,value);else table.delete(key);}rt.undo.length=mark;}
function __recordChange(rt,index,key,prior,next){rt.changeLog.push([index,key,prior,next]);}
function __createState(meta,implementations,captures=null,views=[],prefixes=[]){
 const rt={meta,tables:__newTables(meta,prefixes),version:meta.compactCommits?0:0n,outbox:__eventLog(meta),staged:[],busy:false,undo:[],seen:meta.roots.map(()=>new Set()),host:null,keeps:new Array(meta.keeps.length),keepDirty:meta.keeps.length?new Uint8Array(meta.keeps.length):null,keepUndoIndices:meta.keeps.length?new Uint32Array(meta.keeps.length):null,keepUndoCount:0};
 rt.views=views;rt.viewsByRoot=meta.roots.map((_,root)=>views.filter(v=>v.root===root));__rebuildViews(rt);
 rt.viewByKeep=new Array(meta.keeps.length);for(const view of views)rt.viewByKeep[view.keep]=view;
 rt.pendingIndices=[];rt.pendingValues=new Array(meta.keeps.length);
 rt.eventCount=0;rt.eventChannel=null;rt.eventValue=null;
 rt.viewNext=new Array(meta.keeps.length);rt.cell=null;rt.cellMode=false;rt.ctx={fuel:100000000};
 rt.keepBefore=meta.keeps.length?new Array(meta.keeps.length):null;
 rt.changedRoots=new Set();rt.changedOutputs=new Array(meta.keeps.length).fill(0);rt.changedOutputEpoch=0;
 rt.snapshotRows=meta.snapshotRows?meta.roots.map(()=>new Map()):null;
 rt.changeTracking=false;rt.changeLog=[];rt.changeEpoch=0;rt.changeTokens=new Map();
 const actionMap=new Map(meta.actions.map(a=>[a.name,{...a,inputs:captures?captures[a.index]:a.params.map(p=>__stateCapture(p.type)),output:__stateResult(a.result)}]));
 const eventOutput=new Map(meta.events.map(e=>[e.name,__stateResult(e.type)]));
 rt.eventOutput=eventOutput;
 const prepared=new WeakMap();
 const observers=rt.observers=__createObservers((name,args)=>{
  const a=actionMap.get(name);if(!a||a.change)throw Error('subscription requires a readonly query');
  const captured=a.inputs.map((convert,i)=>convert(args[i]));
  const publicArgs=captured.map((v,i)=>__stateResult(a.params[i].type)(v));
  const scalar=['u64','u32','i32','bool','string','unit','enum','id'].includes(a.result.kind);
  return {scalar,committed:scalar&&a.directKeep!==null&&a.directKeep!==undefined?{state:rt,keep:a.directKeep}:null,direct:scalar&&a.directKeep!==null&&a.directKeep!==undefined?()=>rt.keeps[a.directKeep]:null,roots:a.roots,outputs:rt.meta.outputPublication&&a.directKeep!==null&&a.directKeep!==undefined?[a.directKeep]:[],read:!a.precondition&&a.params.length===0?readZero(a,true):()=>run(a,publicArgs,null,null,true),capture:scalar?v=>v:__stateCapture(a.result),output:scalar?v=>v:a.output,equal:__stateQueryEquals[a.index]};
 });
 function invoke(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);return run(a,args);}
 function readZero(a,resultOnly){
  const implementation=implementations[a.index],output=a.output,fresh=a.freshResult;
  if(resultOnly&&fresh&&__stateDirectReadFactories[a.index])return __stateDirectReadFactories[a.index](rt);
  if(a.directKeep!==null&&a.directKeep!==undefined)return ()=>{
   if(rt.busy)throw Error('state operation already in progress');
   const value=rt.keeps[a.directKeep],result=fresh?value:output(value);
   return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};
  };
  return ()=>{
   if(rt.busy)throw Error('state operation already in progress');rt.busy=true;rt.ctx.fuel=100000000;
   try{const value=implementation(rt.ctx,rt),result=fresh?value:output(value);return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};}
   finally{rt.busy=false;}
  };
 }
 function read(a,args,inputs,output,resultOnly,owned=false){
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  rt.busy=true;
  try{const value=implementations[a.index](ctx,rt,...captured),result=a.freshResult?value:(output||a.output)(value);return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};}
  finally{rt.busy=false;}
 }
 function begin(a){
  if(rt.busy)throw Error('state operation already in progress');
  rt.ctx.fuel=100000000;
  rt.actionMark=rt.undo.length;rt.actionVersion=rt.version;rt.actionOutbox=rt.outbox;rt.actionOutboxLength=rt.outbox.length;rt.actionChangeMark=rt.changeLog.length;
  rt.busy=true;rt.cellMode=a.singleCell&&!rt.host;rt.staged.length=0;rt.eventCount=0;rt.changedRoots.clear();rt.actionSuccessful=false;
 }
 function complete(a,value,output,resultOnly){
  const result=a.freshResult?value:(output||a.output)(value);
  const version=rt.actionVersion;
  if(a.fallible && (a.flatFailure?value.tag!==0:Object.hasOwn(value,'Err'))){rt.changeLog.length=rt.actionChangeMark;__rollback(rt,rt.actionMark);__restoreKeeps(rt);if(rt.host?.strict)rt.host.failure=Object.assign(Error('transaction action failed'),{action:a.name,result});return resultOnly?result:{result,committed:false,version:__versionWord(version),events:[]};}
  if(version===18446744073709551615n)throw Error('commit sequence exhausted');
  const next=rt.meta.compactCommits?__nextCommit(version):version+1n;
  const publicNext=resultOnly?null:__versionWord(next);
  __prepareCell(rt);
  const events=resultOnly?null:new Array(rt.eventCount);
  if(rt.eventCount){
   const channel=rt.eventChannel,value=rt.eventValue;
   rt.outbox.push({commit:next,position:0n,channel,value});
   if(events)events[0]={commit:publicNext,position:0n,channel,value:eventOutput.get(channel)(value)};
   for(let i=0;i<rt.staged.length;i++){
    const [channel,value]=rt.staged[i],position=BigInt(i+1);
    rt.outbox.push({commit:next,position,channel,value});
    if(events)events[i+1]={commit:publicNext,position,channel,value:eventOutput.get(channel)(value)};
   }
  }
  __commitCell(rt);rt.version=next;rt.actionSuccessful=true;
  return resultOnly?result:{result,committed:true,version:publicNext,events};
 }
 function abort(e){
  rt.changeLog.length=rt.actionChangeMark;__rollback(rt,rt.actionMark);__restoreKeeps(rt);rt.version=rt.actionVersion;rt.outbox=rt.actionOutbox;rt.outbox.length=rt.actionOutboxLength;if(rt.host?.strict)rt.host.failure=e;throw e;
 }
 function end(){
  const successful=rt.actionSuccessful,single=rt.cellMode;
  rt.cell=null;rt.cellMode=false;rt.staged.length=0;rt.eventCount=0;rt.eventChannel=null;rt.eventValue=null;
  for(const keep of rt.pendingIndices)rt.pendingValues[keep]=undefined;rt.pendingIndices.length=0;
  if(!single){__clearKeepJournal(rt);for(const seen of rt.seen)seen.clear();if(!rt.host)rt.undo.length=0;}
  rt.actionOutbox=null;rt.busy=false;
  if(successful)observers.commit(rt.changedRoots);
 }
 function run(a,args,inputs=null,output=null,resultOnly=false,owned=false){
  if(a.kernels&&!rt.host){
   if(rt.busy)throw Error('state operation already in progress');
   const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
   return a.kernels[resultOnly?1:0](...captured);
  }
  if(!a.change)return read(a,args,inputs,output,resultOnly,owned);
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  begin(a);
  try{return complete(a,implementations[a.index](ctx,rt,...captured),output,resultOnly);}
  catch(e){return abort(e);}
  finally{end();}
 }

 for(const a of actionMap.values())if(__statePreflightFactories[a.index]){
  // run() supplies module-owned captured values; bound native entries still capture composites.
  a.kernels=[false,true].map(only=>__statePreflightFactories[a.index](run,a,a.inputs,a.output,only,rt,begin,complete,abort,end,true));
 }
 return Object.freeze({
  subscribeValues(queries,callback,options){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribeValues(queries,callback,options);},
  subscribeGroup(queries,callback,options){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribeGroup(queries,callback,options);},
  subscribe(...args){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribe(...args);},
  batch:observers.batch,flushSubscriptions:observers.flush,takeSubscriptionErrors:observers.takeErrors,
  transaction(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('transaction callback must be synchronous');this.beginTransaction();rt.host.strict=true;
   try{const value=callback(this);if(value&&typeof value.then==='function')throw TypeError('state transaction callback must be synchronous');this.commitTransaction();return value;}catch(e){this.rollbackTransaction();throw e;}
  },
  invoke,invoke_json:invoke,
  prepare(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);const captured=a.inputs.map((convert,i)=>convert(args[i])),token=Object.freeze({});prepared.set(token,{action:a,args:captured});return token;},
  invokePrepared(token){const packet=prepared.get(token);if(!packet)throw Error('invalid prepared state call');return run(packet.action,packet.args,null,null,false,true);},
  // A prebound typed entrypoint: scalar arguments obey the native caller contract.
  // Composite arguments still capture owned input; events remain in the outbox.
  bind(name,{resultOnly=false}={}){
   const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);
   const inputs=a.params.map((p,i)=>['u32','i32','u64','bool','unit','string','f32','id','enum','int'].includes(p.type.kind)?__representation(p.type,false):a.inputs[i]);
   if(!a.change&&!a.precondition&&inputs.length===0)return readZero(a,resultOnly);
   return (__statePreflightFactories[a.index]||__stateBoundFactories[a.index])(run,a,inputs,a.output,resultOnly,rt,begin,complete,abort,end);
  },
  beginTransaction(){if(rt.busy||rt.host||rt.undo.length)throw Error('transaction already in progress');rt.host={version:rt.version,outbox:rt.outbox,length:rt.outbox.length,keeps:rt.keeps.slice(),changeMark:rt.changeLog.length,notificationMark:observers.hold()};return true;},
  commitTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');if(rt.host.failure)throw rt.host.failure;rt.host=null;rt.undo.length=0;observers.release();},
  rollbackTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');__rollback(rt,0);rt.version=rt.host.version;rt.outbox=rt.host.outbox;rt.outbox.length=rt.host.length;rt.keeps=rt.host.keeps;rt.changeLog.length=rt.host.changeMark;rt.changeEpoch++;const mark=rt.host.notificationMark;rt.host=null;observers.rollback(mark);},
  changeToken(){
   if(rt.busy||rt.host)throw Error('change token requires transaction boundary');
   const token=Object.freeze({});rt.changeTracking=true;rt.changeTokens.set(token,{epoch:rt.changeEpoch,index:rt.changeLog.length,version:__versionWord(rt.version)});return token;
  },
  releaseChangeToken(token){rt.changeTokens.delete(token);if(!rt.changeTokens.size){rt.changeTracking=false;rt.changeLog.length=0;}},
  changesSince(token){
   if(rt.busy||rt.host)throw Error('changes require transaction boundary');
   const mark=rt.changeTokens.get(token);if(!mark||mark.epoch!==rt.changeEpoch)throw Error('invalid change token lineage');
   const roots=new Map();
   for(let i=mark.index;i<rt.changeLog.length;i++){
    const [root,key,before,after]=rt.changeLog[i];let cells=roots.get(root);if(!cells)roots.set(root,cells=new Map());
    const prior=cells.get(key);if(prior)prior.after=after;else cells.set(key,{before,after});
   }
   const changes=[];
   const codecs=rt.changeOutputs??=meta.roots.map(schema=>({key:__stateResult(schema.key),row:__stateResult(schema.value)}));
   for(const [root,cells]of roots){const schema=meta.roots[root],keyOut=codecs[root].key,rowOut=codecs[root].row;
    for(const [key,{before,after}]of cells){if(before===undefined&&after===undefined||before!==undefined&&after!==undefined&&__stateRootEquals[root](before,after))continue;
     changes.push({table:schema.name,key:keyOut(key),before:before===undefined?{None:null}:{Some:rowOut(before)},after:after===undefined?{None:null}:{Some:rowOut(after)}});
    }
   }
   return {from:mark.version,to:__versionWord(rt.version),changes};
  },
  get version(){return __versionWord(rt.version);},
  get outbox(){return rt.outbox.map(e=>({...e,commit:__versionWord(e.commit),value:eventOutput.get(e.channel)(e.value)}));},
  acknowledgeThrough(commit,position){if(rt.busy)throw Error('state operation already in progress');commit=__stateWord(commit);position=__stateWord(position);const last=rt.outbox.at(-1);if(!last)return;const lastCommit=__versionWord(last.commit);if(lastCommit<commit||(lastCommit===commit&&last.position<=position)){if(rt.host)rt.outbox=__eventLog(meta);else rt.outbox.length=0;return;}rt.outbox=rt.outbox.filter(e=>{const c=__versionWord(e.commit);return c>commit||(c===commit&&e.position>position);});},
  async invokeAsync(name,args){
   if(typeof __parallelInvokeAsync!=='function')return invoke(name,args);
   if(rt.busy||rt.host)throw Error('parallel state call requires transaction boundary');const captured=structuredClone(args);rt.busy=true;observers.hold();let completed=false;
   try{const snapshot=await __snapshotEncode(meta,rt);const reply=await __parallelInvokeAsync(name,captured,snapshot);const s=await __snapshotDecode(meta,reply.snapshot);const candidate={...rt,tables:__newTables(meta,prefixes,s.tables),keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);rt.tables=candidate.tables;rt.version=__storedCommit(meta,s.version);rt.outbox=__eventLog(meta,s.outbox);rt.keeps=candidate.keeps;if(rt.snapshotRows)rt.snapshotRows=meta.roots.map(()=>new Map());rt.changeEpoch++;rt.changeLog.length=0;completed=true;return reply.value;}finally{rt.busy=false;if(completed)observers.commit(meta.roots.map((_,i)=>i));observers.release();}
  },
  checkpoint(limits){if(rt.busy)throw Error('checkpoint requires transaction boundary');return __snapshotEncode(meta,rt,limits);},
  async restore(bytes,limits){if(rt.host)throw Error('restore during transaction');if(rt.busy)throw Error('restore requires transaction boundary');rt.busy=true;rt.ctx.fuel=100000000;observers.hold();let restored=false;try{const s=await __snapshotDecode(meta,bytes,limits);const candidate={...rt,tables:__newTables(meta,prefixes,s.tables),version:__storedCommit(meta,s.version),outbox:s.outbox,keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);for(const name of meta.invariantChecks||[]){const a=actionMap.get(name);if(implementations[a.index](rt.ctx,candidate)!==true)throw Error('snapshot violates state invariant');}rt.tables=candidate.tables;rt.version=__storedCommit(meta,s.version);rt.outbox=__eventLog(meta,s.outbox);rt.keeps=candidate.keeps;if(rt.snapshotRows)rt.snapshotRows=meta.roots.map(()=>new Map());rt.changeEpoch++;rt.changeLog.length=0;restored=true;}finally{rt.busy=false;if(restored)observers.commit(meta.roots.map((_,i)=>i));observers.release();}},
 });
}
function __action0(ctx,rt,s0,s1,s2){__tick(ctx);try{__tick(ctx);__tablePut(rt,0,s0,s1,0);__tick(ctx);__emit(rt,"seen",(s1)["value"]);__tick(ctx);if(s2){__tick(ctx);return ({Err:"Error.Failed"});}else{}__tick(ctx);return ({Ok:null});}catch(e){if(e instanceof __Abort)return ({Err:e.value});throw e;}}
function __action1(ctx,rt,s3,s4){__tick(ctx);try{__tick(ctx);__tableRemove(rt,0,s3);__tick(ctx);__emit(rt,"seen",0);__tick(ctx);if(s4){__tick(ctx);return ({Err:"Error.Failed"});}else{}__tick(ctx);return ({Ok:null});}catch(e){if(e instanceof __Abort)return ({Err:e.value});throw e;}}
function __action2(ctx,rt){__tick(ctx);__tick(ctx);return (__mapValue(__mapValue(__table(rt,0,"values",[]),"list","filter",(s5)=>{__tick(ctx);return (s5)["active"];}),"list","map",(s6)=>{__tick(ctx);return (s6)["value"];})).reduce((a,b)=>{__tick(ctx);return (((a) + (b)) >>> 0);},0);}
function __action3(ctx,rt,s7){__tick(ctx);__tick(ctx);return __tableGet(rt,0,s7);}
function __stateCommitRoot0(rt,key,prior,next,slot){__storeDirect(rt,0,key,prior,next,slot);const publish=rt.meta.outputPublication&&rt.observers.active&&!rt.observers.directRoots[0];if(publish&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}}
const __stateDirectReadFactories=[null,null,null,null];
function __stateValueEqual14(a,b){if(a===b)return true;if(a.length!==b.length)return false;for(let i=0;i<a.length;i++)if(!(__stateValueEqual15(a[i],b[i])))return false;return true;}
function __stateValueEqual12(a,b){if(a===b)return true;if(a.length!==b.length)return false;for(let i=0;i<a.length;i++)if(!(__stateValueEqual1(a[i],b[i])))return false;return true;}
function __stateValueEqual0(a,b){if(a===b)return true;return (a["value"]===b["value"])&&(a["active"]===b["active"])&&__stateValueEqual1(a["metadata"],b["metadata"]);}
function __stateValueEqual9(a,b){return (a===b);}
function __stateValueEqual13(a,b){return __stateValueEqual14(a,b);}
function __stateValueEqual7(a,b){return (a===b);}
function __stateValueEqual5(a,b){return (a===b);}
function __stateValueEqual11(a,b){return __stateValueEqual12(a,b);}
function __stateValueEqual3(a,b){if(a===b)return true;return true;}
function __stateValueEqual15(a,b){if(a===b)return true;return (a["key"]===b["key"])&&__stateValueEqual1(a["value"],b["value"]);}
function __stateValueEqual1(a,b){return __stateValueEqual2(a,b);}
function __stateValueEqual17(a,b){if(a===b)return true;const x=Object.hasOwn(a,'Some');return x===Object.hasOwn(b,'Some')&&(!x||__stateValueEqual0(a.Some,b.Some));}
function __stateValueEqual16(a,b){if(a===b)return true;const xv=a,yv=b,x=Object.hasOwn(xv,'Ok');return x===Object.hasOwn(yv,'Ok')&&(x?(xv.Ok===yv.Ok):(xv.Err===yv.Err));}
function __stateValueEqual8(a,b){if(a===b)return true;const xv=__sumView("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",a),yv=__sumView("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",b),x=Object.hasOwn(xv,'Ok');return x===Object.hasOwn(yv,'Ok')&&(x?__stateValueEqual9(xv.Ok,yv.Ok):__stateValueEqual10(xv.Err,yv.Err));}
function __stateValueEqual6(a,b){if(a===b)return true;const xv=__sumView("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",a),yv=__sumView("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",b),x=Object.hasOwn(xv,'Ok');return x===Object.hasOwn(yv,'Ok')&&(x?__stateValueEqual7(xv.Ok,yv.Ok):__stateValueEqual8(xv.Err,yv.Err));}
function __stateValueEqual4(a,b){if(a===b)return true;const xv=__sumView("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",a),yv=__sumView("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",b),x=Object.hasOwn(xv,'Ok');return x===Object.hasOwn(yv,'Ok')&&(x?__stateValueEqual5(xv.Ok,yv.Ok):__stateValueEqual6(xv.Err,yv.Err));}
function __stateValueEqual10(a,b){if(a===b)return true;const xv=a,yv=b,x=Object.hasOwn(xv,'Ok');return x===Object.hasOwn(yv,'Ok')&&(x?__stateValueEqual11(xv.Ok,yv.Ok):__stateValueEqual13(xv.Err,yv.Err));}
function __stateValueEqual2(a,b){if(a===b)return true;const xv=__sumView("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",a),yv=__sumView("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",b),x=Object.hasOwn(xv,'Ok');return x===Object.hasOwn(yv,'Ok')&&(x?__stateValueEqual3(xv.Ok,yv.Ok):__stateValueEqual4(xv.Err,yv.Err));}
function __ownedInput12(value,budget={cells:1000000},depth=0){if(depth>64||--budget.cells<0)throw Error('state input resource limit');if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=__ownedInput13(value[i],budget,depth+1);return out;}
function __ownedInput9(value,budget={cells:1000000},depth=0){if(depth>64||--budget.cells<0)throw Error('state input resource limit');if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=__ownedInput10(value[i],budget,depth+1);return out;}
function __ownedInput3(value,budget={cells:1000000},depth=0){if(depth>64||--budget.cells<0)throw Error('state input resource limit');let cursor=value;if(!cursor||typeof cursor!=='object'||Array.isArray(cursor))throw Error('invalid Result');const keys0=Object.keys(cursor);if(keys0.length!==1)throw Error('invalid Result');const tag0=keys0[0];if(tag0==='Ok')return {tag:0,payload:__ownedInput4(cursor.Ok,budget,depth+1)};if(tag0!=='Err')throw Error('invalid Result');cursor=cursor.Err;if(depth+1>64||--budget.cells<0)throw Error('state input resource limit');if(!cursor||typeof cursor!=='object'||Array.isArray(cursor))throw Error('invalid Result');const keys1=Object.keys(cursor);if(keys1.length!==1)throw Error('invalid Result');const tag1=keys1[0];if(tag1==='Ok')return {tag:1,payload:__ownedInput5(cursor.Ok,budget,depth+2)};if(tag1!=='Err')throw Error('invalid Result');cursor=cursor.Err;if(depth+2>64||--budget.cells<0)throw Error('state input resource limit');if(!cursor||typeof cursor!=='object'||Array.isArray(cursor))throw Error('invalid Result');const keys2=Object.keys(cursor);if(keys2.length!==1)throw Error('invalid Result');const tag2=keys2[0];if(tag2==='Ok')return {tag:2,payload:__ownedInput6(cursor.Ok,budget,depth+3)};if(tag2!=='Err')throw Error('invalid Result');cursor=cursor.Err;if(depth+3>64||--budget.cells<0)throw Error('state input resource limit');if(!cursor||typeof cursor!=='object'||Array.isArray(cursor))throw Error('invalid Result');const keys3=Object.keys(cursor);if(keys3.length!==1)throw Error('invalid Result');const tag3=keys3[0];if(tag3==='Ok')return {tag:3,payload:__ownedInput7(cursor.Ok,budget,depth+4)};if(tag3!=='Err')throw Error('invalid Result');cursor=cursor.Err;if(depth+4>64||--budget.cells<0)throw Error('state input resource limit');if(!cursor||typeof cursor!=='object'||Array.isArray(cursor))throw Error('invalid Result');const keys4=Object.keys(cursor);if(keys4.length!==1)throw Error('invalid Result');const tag4=keys4[0];if(tag4==='Ok')return {tag:4,payload:__ownedInput8(cursor.Ok,budget,depth+5)};if(tag4!=='Err')throw Error('invalid Result');return {tag:5,payload:__ownedInput11(cursor.Err,budget,depth+5)};}
function __ownedInput4(value,budget={cells:1000000},depth=0){if(depth>64||--budget.cells<0)throw Error('state input resource limit');if(!value||typeof value!=='object'||Array.isArray(value))throw Error('invalid record');return {};}
function __ownedInput11(value,budget={cells:1000000},depth=0){if(depth>64||--budget.cells<0)throw Error('state input resource limit');if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,"item0"))throw Error('invalid record');const field0=__ownedInput12(value["item0"],budget,depth+1);return field0;}
function __ownedInput8(value,budget={cells:1000000},depth=0){if(depth>64||--budget.cells<0)throw Error('state input resource limit');if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,"item0"))throw Error('invalid record');const field0=__ownedInput9(value["item0"],budget,depth+1);return field0;}
function __ownedInput5(value,budget={cells:1000000},depth=0){if(depth>64||--budget.cells<0)throw Error('state input resource limit');if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,"item0"))throw Error('invalid record');let field0=value["item0"];if(depth+1>64||--budget.cells<0)throw Error('state input resource limit');if(typeof field0!=='boolean')throw Error('invalid Bool');return field0;}
function __ownedInput7(value,budget={cells:1000000},depth=0){if(depth>64||--budget.cells<0)throw Error('state input resource limit');if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,"item0"))throw Error('invalid record');let field0=value["item0"];if(depth+1>64||--budget.cells<0)throw Error('state input resource limit');if(typeof field0!=='string'||!field0.isWellFormed())throw Error('invalid String');return field0;}
function __ownedInput6(value,budget={cells:1000000},depth=0){if(depth>64||--budget.cells<0)throw Error('state input resource limit');if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,"item0"))throw Error('invalid record');let field0=value["item0"];if(depth+1>64||--budget.cells<0)throw Error('state input resource limit');if(typeof field0!=='string'||!field0.isWellFormed())throw Error('invalid String');return field0;}
function __ownedInput13(value,budget={cells:1000000},depth=0){if(depth>64||--budget.cells<0)throw Error('state input resource limit');if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,"key")||!Object.hasOwn(value,"value"))throw Error('invalid record');let field0=value["key"];if(depth+1>64||--budget.cells<0)throw Error('state input resource limit');if(typeof field0!=='string'||!field0.isWellFormed())throw Error('invalid String');const field1=__ownedInput10(value["value"],budget,depth+1);return {["key"]:field0,["value"]:field1};}
function __ownedInput2(value,budget={cells:1000000},depth=0){if(depth>64||--budget.cells<0)throw Error('state input resource limit');if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,"payload"))throw Error('invalid record');const field0=__ownedInput3(value["payload"],budget,depth+1);return field0;}
function __ownedInput1(value,budget={cells:1000000},depth=0){if(depth>64||--budget.cells<0)throw Error('state input resource limit');if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,"value")||!Object.hasOwn(value,"active")||!Object.hasOwn(value,"metadata"))throw Error('invalid record');let field0=value["value"];if(depth+1>64||--budget.cells<0)throw Error('state input resource limit');if(typeof field0!=='number'||!Number.isInteger(field0)||field0<0||field0>4294967295)throw Error('invalid u32');if(field0===0)field0=0;let field1=value["active"];if(depth+1>64||--budget.cells<0)throw Error('state input resource limit');if(typeof field1!=='boolean')throw Error('invalid Bool');const field2=__ownedInput2(value["metadata"],budget,depth+1);return {["value"]:field0,["active"]:field1,["metadata"]:field2};}
function __ownedInput14(value,budget={cells:1000000},depth=0){let scalar=value;if(depth>64||--budget.cells<0)throw Error('state input resource limit');if(typeof scalar!=='boolean')throw Error('invalid Bool');return scalar;}
function __ownedInput10(value,budget={cells:1000000},depth=0){if(depth>64||--budget.cells<0)throw Error('state input resource limit');return __ownedInput2(value,budget,depth+1);}
function __ownedInput0(value,budget={cells:1000000},depth=0){let scalar=value;if(depth>64||--budget.cells<0)throw Error('state input resource limit');if(typeof scalar!=='string'||!scalar.isWellFormed())throw Error('invalid String');return scalar;}
const __stateQueryEquals=[(a,b)=>__stateValueEqual16(a,b),(a,b)=>__stateValueEqual16(a,b),(a,b)=>(a===b),(a,b)=>__stateValueEqual17(a,b)];
const __stateRootEquals=[(a,b)=>__stateValueEqual0(a,b)];
const __stateBoundFactories=[(run,a,inputs,output,only,rt,begin,complete,abort,end)=>a.precondition?(p0,p1,p2)=>run(a,[inputs[0](p0),inputs[1](p1),inputs[2](p2)],null,output,only,true):(p0,p1,p2)=>{const b0=inputs[0](p0);const b1=inputs[1](p1);const b2=inputs[2](p2);begin(a);try{return complete(a,__action0(rt.ctx,rt,b0,b1,b2),output,only);}catch(e){return abort(e);}finally{end();}},(run,a,inputs,output,only,rt,begin,complete,abort,end)=>a.precondition?(p0,p1)=>run(a,[inputs[0](p0),inputs[1](p1)],null,output,only,true):(p0,p1)=>{const b0=inputs[0](p0);const b1=inputs[1](p1);begin(a);try{return complete(a,__action1(rt.ctx,rt,b0,b1),output,only);}catch(e){return abort(e);}finally{end();}},(run,a,inputs,output,only)=>()=>run(a,[],null,output,only,true),(run,a,inputs,output,only)=>(p0)=>run(a,[inputs[0](p0)],null,output,only,true)];const __statePreflightFactories=[(run,a,inputs,output,only,rt,begin,complete,abort,end,ownedInputs=false)=>{const fallback=ownedInputs?(p0,p1,p2)=>run(a,[p0,p1,p2],null,output,only,true):((run,a,inputs,output,only,rt,begin,complete,abort,end)=>a.precondition?(p0,p1,p2)=>run(a,[inputs[0](p0),inputs[1](p1),inputs[2](p2)],null,output,only,true):(p0,p1,p2)=>{const b0=inputs[0](p0);const b1=inputs[1](p1);const b2=inputs[2](p2);begin(a);try{return complete(a,__action0(rt.ctx,rt,b0,b1,b2),output,only);}catch(e){return abort(e);}finally{end();}})(run,a,inputs,output,only,rt,begin,complete,abort,end);const prepare=rt.views.directRoots?.[0];const __dense0=rt.tables[0] instanceof __DenseTable;return (p0,p1,p2)=>{if(rt.host)return fallback(p0,p1,p2);if(rt.busy)throw Error('state operation already in progress');const b0=p0;const b1=ownedInputs?p1:inputs[1](p1);const b2=p2;rt.busy=true;let __released=false;let __stageRoot=-1,__stageKey,__stagePrior,__stageNext,__stageSlot,__stageChanged=false,__eventChannel=null,__eventValue;try{let value;__inkBody:{(__stageRoot=0,__stageKey=b0,__stageNext=b1,__stageSlot=__dense0?rt.tables[0].slot(__stageKey):undefined,__stagePrior=__stageSlot===undefined?rt.tables[0].get(__stageKey):__stageSlot<0?rt.tables[0].sparse.get(__stageKey):rt.tables[0].dense[__stageSlot],null,__stageChanged=__stagePrior===undefined?__stageNext!==undefined:__stageNext===undefined||!__stateRootEquals[0](__stagePrior,__stageNext),null);__eventChannel="seen";__eventValue=(b1)["value"];if(b2){value=({Err:"Error.Failed"});break __inkBody;}else{}value=({Ok:null});break __inkBody;}const result=value;if(Object.hasOwn(value,'Err'))return only?result:{result,committed:false,version:__versionWord(rt.version),events:[]};if(rt.version===18446744073709551615n)throw Error('commit sequence exhausted');const next=rt.version+1n;const publicNext=only?null:__versionWord(next);if(__stageChanged){if(prepare)prepare(rt,__stageKey,__stagePrior,__stageNext);}let event=null;if(__eventChannel!==null)event={commit:next,position:0n,channel:__eventChannel,value:__eventValue};const events=only?null:event?[{...event,commit:publicNext,value:rt.eventOutput.get(__eventChannel)(__eventValue)}]:[];if(__stageChanged){__stateCommitRoot0(rt,__stageKey,__stagePrior,__stageNext,__stageSlot);}if(event)rt.outbox.push(event);rt.version=next;rt.busy=false;__released=true;if(__stageChanged&&rt.observers.active)rt.observers.commitRoot(__stageRoot,rt.meta.outputPublication?rt.changedOutputs:null,rt.changedOutputEpoch);return only?result:{result,committed:true,version:publicNext,events};}finally{if(!__released)rt.busy=false;}};},(run,a,inputs,output,only,rt,begin,complete,abort,end,ownedInputs=false)=>{const fallback=ownedInputs?(p0,p1)=>run(a,[p0,p1],null,output,only,true):((run,a,inputs,output,only,rt,begin,complete,abort,end)=>a.precondition?(p0,p1)=>run(a,[inputs[0](p0),inputs[1](p1)],null,output,only,true):(p0,p1)=>{const b0=inputs[0](p0);const b1=inputs[1](p1);begin(a);try{return complete(a,__action1(rt.ctx,rt,b0,b1),output,only);}catch(e){return abort(e);}finally{end();}})(run,a,inputs,output,only,rt,begin,complete,abort,end);const prepare=rt.views.directRoots?.[0];const __dense0=rt.tables[0] instanceof __DenseTable;return (p0,p1)=>{if(rt.host)return fallback(p0,p1);if(rt.busy)throw Error('state operation already in progress');const b0=p0;const b1=p1;rt.busy=true;let __released=false;let __stageRoot=-1,__stageKey,__stagePrior,__stageNext,__stageSlot,__stageChanged=false,__eventChannel=null,__eventValue;try{let value;__inkBody:{(__stageRoot=0,__stageKey=b0,__stageNext=undefined,__stageSlot=__dense0?rt.tables[0].slot(__stageKey):undefined,__stagePrior=__stageSlot===undefined?rt.tables[0].get(__stageKey):__stageSlot<0?rt.tables[0].sparse.get(__stageKey):rt.tables[0].dense[__stageSlot],null,__stageChanged=__stagePrior===undefined?__stageNext!==undefined:__stageNext===undefined||!__stateRootEquals[0](__stagePrior,__stageNext),(__stagePrior===undefined?{None:null}:{Some:__stagePrior}));__eventChannel="seen";__eventValue=0;if(b1){value=({Err:"Error.Failed"});break __inkBody;}else{}value=({Ok:null});break __inkBody;}const result=value;if(Object.hasOwn(value,'Err'))return only?result:{result,committed:false,version:__versionWord(rt.version),events:[]};if(rt.version===18446744073709551615n)throw Error('commit sequence exhausted');const next=rt.version+1n;const publicNext=only?null:__versionWord(next);if(__stageChanged){if(prepare)prepare(rt,__stageKey,__stagePrior,__stageNext);}let event=null;if(__eventChannel!==null)event={commit:next,position:0n,channel:__eventChannel,value:__eventValue};const events=only?null:event?[{...event,commit:publicNext,value:rt.eventOutput.get(__eventChannel)(__eventValue)}]:[];if(__stageChanged){__stateCommitRoot0(rt,__stageKey,__stagePrior,__stageNext,__stageSlot);}if(event)rt.outbox.push(event);rt.version=next;rt.busy=false;__released=true;if(__stageChanged&&rt.observers.active)rt.observers.commitRoot(__stageRoot,rt.meta.outputPublication?rt.changedOutputs:null,rt.changedOutputEpoch);return only?result:{result,committed:true,version:publicNext,events};}finally{if(!__released)rt.busy=false;}};},null,null];
const __stateMetadata={"actions":[{"change":true,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":true,"index":0,"name":"put","params":[{"name":"key","type":{"kind":"string"}},{"name":"row","type":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"active","type":{"kind":"bool"}},{"name":"metadata","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"Row"}},{"name":"fail","type":{"kind":"bool"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"Error","variants":["Error.Failed"]},"kind":"result","ok":{"kind":"unit"}},"roots":[0],"singleCell":true},{"change":true,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":true,"index":1,"name":"erase","params":[{"name":"key","type":{"kind":"string"}},{"name":"fail","type":{"kind":"bool"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"Error","variants":["Error.Failed"]},"kind":"result","ok":{"kind":"unit"}},"roots":[0],"singleCell":true},{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":true,"index":2,"name":"total","params":[],"precondition":null,"result":{"kind":"u32"},"roots":[0],"singleCell":true},{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":3,"name":"row","params":[{"name":"key","type":{"kind":"string"}}],"precondition":null,"result":{"element":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"active","type":{"kind":"bool"}},{"name":"metadata","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"Row"},"kind":"option"},"roots":[0],"singleCell":true}],"compactCommits":false,"eventColumns":false,"events":[{"name":"seen","snapshotType":{"kind":"u32"},"type":{"kind":"u32"}}],"invariantChecks":[],"keepInvalidations":[[]],"keeps":[],"outputPublication":false,"roots":[{"key":{"kind":"string"},"name":"Rows","snapshotKey":{"kind":"string"},"snapshotValue":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"active","type":{"kind":"bool"}},{"name":"metadata","type":{"body":{"elided":true,"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"body":{"elided":true,"fields":[{"name":"item0","type":{"element":{"body":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record"},"kind":"bind","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record"},"kind":"bind","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"body":{"elided":true,"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record"},"kind":"bind","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"elided":true,"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record"},"sum_key":"[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]"},"kind":"result","ok":{"elided":true,"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record"},"sum_key":"[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]"},"kind":"result","ok":{"elided":true,"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record"},"sum_key":"[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]"},"kind":"result","ok":{"fields":[],"kind":"record"},"sum_key":"[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]"}}],"kind":"record"},"kind":"bind","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record"},"value":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"active","type":{"kind":"bool"}},{"name":"metadata","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"Row"}}],"snapshot":{"program":[170,2,160,201,22,34,6,102,106,120,127,195,108,222,134,87,107,18,249,205,65,4,204,37,145,133,33,239,56,73,0,121],"schema":[215,31,142,65,238,22,48,236,29,237,247,185,248,201,46,30,164,196,64,247,0,243,34,135,232,15,229,166,43,18,34,88]},"snapshotRows":false};const __actions=[__action0,__action1,__action2,__action3];const __stateInputCaptures=[[__ownedInput0,__ownedInput1,__ownedInput14],[__ownedInput0,__ownedInput14],[],[__ownedInput0]];
export function createState(){return __createState(__stateMetadata,__actions,__stateInputCaptures);}
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"011e1e96f60d9e2e64eeb79b7ac93de4adf862c65bdd7014ef43f59ffa24996c","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"f32_storage":"exact-u32-bits","functions":[{"destination":null,"index":0,"internal":false,"name":"set_document","parallel":false,"params":[{"name":"document","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}},{"destination":null,"index":1,"internal":false,"name":"identity","parallel":false,"params":[{"name":"document","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"precondition":null,"result":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"destination":null,"index":2,"internal":false,"name":"ink_m5c5479101d38cd5d28f66110c880ad28b6ee3ee64fddb98300dda927c645c107","parallel":false,"params":[],"precondition":null,"result":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"destination":null,"index":3,"internal":false,"name":"ink_mbf312e22e5ab893385ef1935f8250f16e090d4da8dd41bc1577df1ba636fdc13","parallel":false,"params":[{"name":"value","type":{"kind":"bool"}}],"precondition":null,"result":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"destination":null,"index":4,"internal":false,"name":"ink_mee36d9721e4db57ba82a41d18344d03b18dc98a5d22319238b436d9aa6c8a6c1","parallel":false,"params":[{"name":"token","type":{"kind":"string"}}],"precondition":null,"result":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"destination":null,"index":5,"internal":false,"name":"ink_mca67a4ea249e8eba3cf6e453e86dd061695d9d9afaf7edcf587f8cd1cbc055c9","parallel":false,"params":[{"name":"value","type":{"kind":"string"}}],"precondition":null,"result":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"destination":null,"index":6,"internal":false,"name":"ink_me5c9745ee2d98ddc2c32843ec24ea225963aff43ce357055dd9a61b18d1d4982","parallel":false,"params":[{"name":"values","type":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"precondition":null,"result":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"destination":null,"index":7,"internal":false,"name":"ink_mb0e8aa1d34f7cc5fc940000b63bdc043068202b64206a7da02cade0c4e386a22","parallel":false,"params":[{"name":"members","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"precondition":null,"result":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"destination":null,"index":8,"internal":false,"name":"ink_m2383a37c8f0f060d8454d784560b1928c68c5b404b4b5fd5bfff2e7fa4fddcbe","parallel":false,"params":[{"name":"members","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}},{"name":"key","type":{"kind":"string"}}],"precondition":null,"result":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"option"}},{"destination":null,"index":9,"internal":false,"name":"ink_m5d18bbf4cd5236cf3a3bce3bc0ef39b2ca5d48cc74c98fd149a78715c7abf0fc","parallel":false,"params":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"name":"key","type":{"kind":"string"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"option"}}},{"destination":null,"index":10,"internal":false,"name":"ink_md87d2855f042e634a3f3b8c068533029f73d510386d43bf00bc9d0bcd07e5c8c","parallel":false,"params":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}},{"destination":null,"index":11,"internal":false,"name":"ink_m20157316281aa2312519e1609fa4690b136f16e4ef71773eb2a47a1fa3a406de","parallel":false,"params":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}},{"destination":null,"index":12,"internal":false,"name":"ink_me72555cbb304777e5aa4f9e3c006554a0e08baef4b0d7d5315bbdb8d73619005","parallel":false,"params":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"kind":"string"}}},{"destination":null,"index":13,"internal":false,"name":"ink_m0799e9661dd281b944df2c23f24248caf4bf5ffd20f6d9a7e2fe778ce1a073d2","parallel":false,"params":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"kind":"string"}}},{"destination":null,"index":14,"internal":false,"name":"ink_m992ba36e5bbedf39b7f14a42b10f872b6c0c9a2ea93b89b3fc52f4d549687c80","parallel":false,"params":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"kind":"bool"}}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":15,"internal":false,"name":"ink_md6609e67dc544a99f2a87bd888df500ffda6c2a250ac3bb96e169677f36aa0ca","parallel":false,"params":[{"name":"members","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}},{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"precondition":null,"result":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}},{"destination":null,"index":16,"internal":false,"name":"ink_mad008ef4986d9f0222e8592e1b0d53b594ed67eab0548e67ceabe4308ff8638b","parallel":false,"params":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"name":"key","type":{"kind":"string"}},{"name":"replacement","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}},{"destination":null,"index":17,"internal":false,"name":"ink_m6daa56a5bc5a861d85247ffa7c539a517219bed2c2c205e9798247b46093c271","parallel":false,"params":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"name":"key","type":{"kind":"string"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}},{"destination":null,"index":18,"internal":false,"name":"ink_m55d79925938089d1d4f5680a132089bb2dbc200f324c50670835f2f3730f3837","parallel":false,"params":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"name":"keys","type":{"element":{"kind":"string"},"kind":"list"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}}],"named_types":{"Row":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"active","type":{"kind":"bool"}},{"name":"metadata","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"Row"},"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"},"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"kind":"ref","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"},"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"},"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"kind":"ref","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"},"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"},"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"private_record_elisions":["__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2","__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19","__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e","__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7","__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8","ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"],"private_sum_spines":[{"Result":[{"Named":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"},{"Result":[{"Named":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"},{"Named":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"}]}]},{"Result":[{"Named":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"},{"Result":[{"Named":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"},{"Result":[{"Named":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"},{"Named":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"}]}]}]},{"Result":[{"Named":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"},{"Result":[{"Named":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"},{"Result":[{"Named":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"},{"Result":[{"Named":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"},{"Named":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"}]}]}]}]},{"Result":[{"Named":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"},{"Result":[{"Named":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"},{"Result":[{"Named":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"},{"Result":[{"Named":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"},{"Result":[{"Named":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"},{"Named":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"}]}]}]}]}]}],"schema":1,"state":{"actions":[{"change":true,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":true,"index":0,"name":"put","params":[{"name":"key","type":{"kind":"string"}},{"name":"row","type":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"active","type":{"kind":"bool"}},{"name":"metadata","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"Row"}},{"name":"fail","type":{"kind":"bool"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"Error","variants":["Error.Failed"]},"kind":"result","ok":{"kind":"unit"}},"roots":[0],"singleCell":true},{"change":true,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":true,"index":1,"name":"erase","params":[{"name":"key","type":{"kind":"string"}},{"name":"fail","type":{"kind":"bool"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"Error","variants":["Error.Failed"]},"kind":"result","ok":{"kind":"unit"}},"roots":[0],"singleCell":true},{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":true,"index":2,"name":"total","params":[],"precondition":null,"result":{"kind":"u32"},"roots":[0],"singleCell":true},{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":3,"name":"row","params":[{"name":"key","type":{"kind":"string"}}],"precondition":null,"result":{"element":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"active","type":{"kind":"bool"}},{"name":"metadata","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"Row"},"kind":"option"},"roots":[0],"singleCell":true}],"compactCommits":false,"eventColumns":false,"events":[{"name":"seen","snapshotType":{"kind":"u32"},"type":{"kind":"u32"}}],"invariantChecks":[],"keepInvalidations":[[]],"keeps":[],"outputPublication":false,"roots":[{"key":{"kind":"string"},"name":"Rows","snapshotKey":{"kind":"string"},"snapshotValue":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"active","type":{"kind":"bool"}},{"name":"metadata","type":{"body":{"elided":true,"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"body":{"elided":true,"fields":[{"name":"item0","type":{"element":{"body":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record"},"kind":"bind","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record"},"kind":"bind","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"body":{"elided":true,"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record"},"kind":"bind","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"elided":true,"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record"},"sum_key":"[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]"},"kind":"result","ok":{"elided":true,"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record"},"sum_key":"[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]"},"kind":"result","ok":{"elided":true,"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record"},"sum_key":"[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]"},"kind":"result","ok":{"fields":[],"kind":"record"},"sum_key":"[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]"}}],"kind":"record"},"kind":"bind","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record"},"value":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"active","type":{"kind":"bool"}},{"name":"metadata","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"Row"}}],"snapshot":{"program":[170,2,160,201,22,34,6,102,106,120,127,195,108,222,134,87,107,18,249,205,65,4,204,37,145,133,33,239,56,73,0,121],"schema":[215,31,142,65,238,22,48,236,29,237,247,185,248,201,46,30,164,196,64,247,0,243,34,135,232,15,229,166,43,18,34,88]},"snapshotRows":false},"wire":{"format":"ink-value-wire-v1","functions":{"identity":{"arguments":{"format":"ink-value-wire-v1","identity":"d3d791c0090ff618145067c5c8bd7302c45c5444b41643c3d24aa8f7416bcea1","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"document","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"cde2342294b5d22d550a478382af229c83cb7f43fc3b018dcd529ebfc8a284ba","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}},"ink_m0799e9661dd281b944df2c23f24248caf4bf5ffd20f6d9a7e2fe778ce1a073d2":{"arguments":{"format":"ink-value-wire-v1","identity":"999994f83a090f57c5b729be3ebc6a78ab2d71614a5942a4bafedb7df6fd1c68","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"e24d959ababfea7ff89fb11b86077069a10d5bcee2e219f87130e9817ff587e1","named":{},"root":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"kind":"string"}}}},"ink_m20157316281aa2312519e1609fa4690b136f16e4ef71773eb2a47a1fa3a406de":{"arguments":{"format":"ink-value-wire-v1","identity":"999994f83a090f57c5b729be3ebc6a78ab2d71614a5942a4bafedb7df6fd1c68","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"bbc92730c4d69116e391c2fb18422a1876181431d200628bd1ba3ee68c42e237","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}}},"ink_m2383a37c8f0f060d8454d784560b1928c68c5b404b4b5fd5bfff2e7fa4fddcbe":{"arguments":{"format":"ink-value-wire-v1","identity":"efa6cdb28c046e3dc55ebf0adece8509300aa163daf0657df94c290cde7bb29e","named":{"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"members","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}},{"name":"key","type":{"kind":"string"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fca6ee2ed4d9b81404327cbe773b519441d1d81486d2bc394fb759a7d795d6cf","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"option"}}},"ink_m55d79925938089d1d4f5680a132089bb2dbc200f324c50670835f2f3730f3837":{"arguments":{"format":"ink-value-wire-v1","identity":"c81bddc5f58061bca25e8a98786d225fbeacc0d14ab23e485f2ac5652914ca5d","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"name":"keys","type":{"element":{"kind":"string"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"7009644bf1bd80a4b5df84e49ccd1b83630a5a3bb97fd1654953e69fcfd52fa2","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}}},"ink_m5c5479101d38cd5d28f66110c880ad28b6ee3ee64fddb98300dda927c645c107":{"arguments":{"format":"ink-value-wire-v1","identity":"3720cf83cb9a672c0c70e7f80cfe0abe0bf9b7df73d40a9def0c7436234026b2","named":{},"root":{"fields":[],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"cde2342294b5d22d550a478382af229c83cb7f43fc3b018dcd529ebfc8a284ba","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}},"ink_m5d18bbf4cd5236cf3a3bce3bc0ef39b2ca5d48cc74c98fd149a78715c7abf0fc":{"arguments":{"format":"ink-value-wire-v1","identity":"e0fd935fe30c0a3925545388c1ee24c117fb2fa931b5ee823fe4a607393286b2","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"name":"key","type":{"kind":"string"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"26cf663a2b8c3c836b1e7a7a83e9e1cd115b0d1d1cae8bc3feca9e205abcc0ea","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"option"}}}},"ink_m6daa56a5bc5a861d85247ffa7c539a517219bed2c2c205e9798247b46093c271":{"arguments":{"format":"ink-value-wire-v1","identity":"e0fd935fe30c0a3925545388c1ee24c117fb2fa931b5ee823fe4a607393286b2","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"name":"key","type":{"kind":"string"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"7009644bf1bd80a4b5df84e49ccd1b83630a5a3bb97fd1654953e69fcfd52fa2","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}}},"ink_m992ba36e5bbedf39b7f14a42b10f872b6c0c9a2ea93b89b3fc52f4d549687c80":{"arguments":{"format":"ink-value-wire-v1","identity":"999994f83a090f57c5b729be3ebc6a78ab2d71614a5942a4bafedb7df6fd1c68","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"85402867d4e17348f13331ff7950cadaf3a880baf9a3257dda65baae17bc3dc6","named":{},"root":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"kind":"bool"}}}},"ink_mad008ef4986d9f0222e8592e1b0d53b594ed67eab0548e67ceabe4308ff8638b":{"arguments":{"format":"ink-value-wire-v1","identity":"84b998083d21e20e00637080143e299c47336742266a8fcb8252e322c986b306","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"name":"key","type":{"kind":"string"}},{"name":"replacement","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"7009644bf1bd80a4b5df84e49ccd1b83630a5a3bb97fd1654953e69fcfd52fa2","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}}},"ink_mb0e8aa1d34f7cc5fc940000b63bdc043068202b64206a7da02cade0c4e386a22":{"arguments":{"format":"ink-value-wire-v1","identity":"bbb379e277d6b460a0f9b8674480d674413e01f92d0409f754ac0b7fb228c9ed","named":{"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"members","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"cde2342294b5d22d550a478382af229c83cb7f43fc3b018dcd529ebfc8a284ba","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}},"ink_mbf312e22e5ab893385ef1935f8250f16e090d4da8dd41bc1577df1ba636fdc13":{"arguments":{"format":"ink-value-wire-v1","identity":"6b3d0195ef2c386b261eec6dcf7ff025126e09d574445703806ad22aeb1c44a6","named":{},"root":{"fields":[{"name":"value","type":{"kind":"bool"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"cde2342294b5d22d550a478382af229c83cb7f43fc3b018dcd529ebfc8a284ba","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}},"ink_mca67a4ea249e8eba3cf6e453e86dd061695d9d9afaf7edcf587f8cd1cbc055c9":{"arguments":{"format":"ink-value-wire-v1","identity":"9cfa9fda5c8479d6a1f3dcbd84badb6f4c8c44593fa7472b40f9732abe82eec3","named":{},"root":{"fields":[{"name":"value","type":{"kind":"string"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"cde2342294b5d22d550a478382af229c83cb7f43fc3b018dcd529ebfc8a284ba","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}},"ink_md6609e67dc544a99f2a87bd888df500ffda6c2a250ac3bb96e169677f36aa0ca":{"arguments":{"format":"ink-value-wire-v1","identity":"3d53a49fdbf9c1f06dae4677eb6ee89a8d118b8b47f44d5774e2129be34d7063","named":{"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"members","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}},{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"2b5b92cf8b137fa488f335d974dfd980de30e6aa85fefd6ad847da102cf7cb93","named":{"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}},"ink_md87d2855f042e634a3f3b8c068533029f73d510386d43bf00bc9d0bcd07e5c8c":{"arguments":{"format":"ink-value-wire-v1","identity":"999994f83a090f57c5b729be3ebc6a78ab2d71614a5942a4bafedb7df6fd1c68","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"31c4fe41eb6c3b7dcfc985f701b759a14acb5d2bfa5f13ee2bc29d20c5baa6ac","named":{"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}}},"ink_me5c9745ee2d98ddc2c32843ec24ea225963aff43ce357055dd9a61b18d1d4982":{"arguments":{"format":"ink-value-wire-v1","identity":"799b4490fb0a0ca59d1db14f2c2d32908b1bc537830d3fea3f14e37370464360","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"values","type":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"cde2342294b5d22d550a478382af229c83cb7f43fc3b018dcd529ebfc8a284ba","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}},"ink_me72555cbb304777e5aa4f9e3c006554a0e08baef4b0d7d5315bbdb8d73619005":{"arguments":{"format":"ink-value-wire-v1","identity":"999994f83a090f57c5b729be3ebc6a78ab2d71614a5942a4bafedb7df6fd1c68","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"e24d959ababfea7ff89fb11b86077069a10d5bcee2e219f87130e9817ff587e1","named":{},"root":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"kind":"string"}}}},"ink_mee36d9721e4db57ba82a41d18344d03b18dc98a5d22319238b436d9aa6c8a6c1":{"arguments":{"format":"ink-value-wire-v1","identity":"9e5a22adedd7402800f200b09bf661e677194b9d568e7b4b5be4331d15388662","named":{},"root":{"fields":[{"name":"token","type":{"kind":"string"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"cde2342294b5d22d550a478382af229c83cb7f43fc3b018dcd529ebfc8a284ba","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}},"set_document":{"arguments":{"format":"ink-value-wire-v1","identity":"27aee69f3c0a91c6ea7c31334f9be952533862738e8114c60aa8eda0eeb66bb4","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"fields":[{"name":"document","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"7009644bf1bd80a4b5df84e49ccd1b83630a5a3bb97fd1654953e69fcfd52fa2","named":{"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},"root":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}}}}}};
const __implementations=[__fn0,__fn1,__fn2,__fn3,__fn4,__fn5,__fn6,__fn7,__fn8,__fn9,__fn10,__fn11,__fn12,__fn13,__fn14,__fn15,__fn16,__fn17,__fn18];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
const __inputTypes=[{"capture":[false,true,true],"types":[{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},{"kind":"string"},{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}]},{"capture":[true],"types":[{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}]},{"capture":[],"types":[]},{"capture":[true],"types":[{"kind":"bool"}]},{"capture":[true],"types":[{"kind":"string"}]},{"capture":[true],"types":[{"kind":"string"}]},{"capture":[true],"types":[{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}]},{"capture":[true],"types":[{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}]},{"capture":[false,true],"types":[{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"},{"kind":"string"}]},{"capture":[false,true],"types":[{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},{"kind":"string"}]},{"capture":[false],"types":[{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}]},{"capture":[false],"types":[{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}]},{"capture":[false],"types":[{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}]},{"capture":[false],"types":[{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}]},{"capture":[false],"types":[{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}]},{"capture":[true,true,true],"types":[{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"},{"kind":"string"},{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}]},{"capture":[false,true,true],"types":[{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},{"kind":"string"},{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}]},{"capture":[false,true],"types":[{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},{"kind":"string"}]},{"capture":[false,true],"types":[{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},{"element":{"kind":"string"},"kind":"list"}]}];

// Descriptor work occurs once at module initialisation, never per word-list call.
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=> {
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const output=__representation(f.result,true);
  const body=__implementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
  const needsInput=input.some(c=>c!==__identity);
  const entry=!needsInput && output===__identity ? implementation :
    (...args)=>{const context=new WeakMap();return output(implementation(...(needsInput ? args.map((v,i)=>input[i](v,context)) : args)),context);};
  return [f.name,entry];
})));
export function call(name,args) { return functions[name](...args); }
// Shared bounded binary codec; generated code supplies exact descriptors.
export const valueWireFormat='ink-value-wire-v1';
// A connection agrees on the complete value schema before using this format.
// Version byte + schema-directed fields; schema identity is out of band.
export const compactValueWireFormat='ink-value-session-v1';
const wireMagic=Uint8Array.of(73,78,75,86,65,76,0,1);
const wireEncoder=new TextEncoder(),wireDecoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const wireDefaults=Object.freeze({bytes:16777216,nodes:1000000,depth:128}),wireDefaultOptions=Object.freeze({});
const wireDecimal=s=>typeof s==='string'&&/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(s);
function wireLimits(options){if(options===wireDefaultOptions||options===wireDefaults)return wireDefaults;const l={...wireDefaults,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>wireDefaults[k])throw Error('wire hard resource limit');return l;}
const wireFloat=new DataView(new ArrayBuffer(4));
function wireDecodeText(bytes,start,end){
 if(end-start<=16){let text='';for(let i=start;i<end;i++){const byte=bytes[i];if(byte>=128)return wireDecoder.decode(bytes.subarray(start,end));text+=String.fromCharCode(byte);}return text;}
 return wireDecoder.decode(bytes.subarray(start,end));
}
function wireUtf8Length(text){let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const wireOwn=(v,k)=>v!==null&&typeof v==='object'&&Object.hasOwn(v,k);
const wireTagged=(v,k)=>wireOwn(v,k)&&Object.keys(v).length===1;
const wireCanonical=v=>Array.isArray(v)?'['+v.map(wireCanonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort((a,b)=>{const x=Array.from(a,c=>c.codePointAt(0)),y=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]-y[i];return x.length-y.length;}).map(k=>JSON.stringify(k)+':'+wireCanonical(v[k])).join(',')+'}':JSON.stringify(v);
export async function createValueCodec(root,named={}){
 const used=new Set(),budget={nodes:100000};
 function check(t,d=0){
  if(d>64||--budget.nodes<0)throw Error('wire descriptor limit');
  const keys={u32:['kind'],u64:['kind'],i32:['kind'],f32:['kind'],bool:['kind'],unit:['kind'],string:['kind'],int:['kind'],id:['kind','name'],ref:['kind','name'],enum:['kind','name','variants'],record:['kind','name','fields'],list:['kind','element'],option:['kind','element'],vector:['kind','element','size'],result:['kind','ok','error']}[t?.kind];
  if(!keys||Object.keys(t).length!==keys.length||keys.some(k=>!Object.hasOwn(t,k)))throw Error('invalid wire descriptor');
  if(keys.includes('name')&&(typeof t.name!=='string'||!t.name.isWellFormed()))throw Error('invalid descriptor name');
  if(t.kind==='ref'){if(!used.has(t.name)){used.add(t.name);if(named[t.name]?.kind!=='record'||named[t.name].name!==t.name)throw Error('unresolved wire reference');check(named[t.name],d+1);}}
  if(t.kind==='record'){if(!Array.isArray(t.fields))throw Error('wire fields');const names=new Set();for(const f of t.fields){if(Object.keys(f).length!==2||typeof f.name!=='string'||!f.name.isWellFormed()||names.has(f.name))throw Error('duplicate wire field');names.add(f.name);check(f.type,d+1);}}
  if(t.kind==='enum'&&(!Array.isArray(t.variants)||!t.variants.length||t.variants.length>64||t.variants.some(v=>typeof v!=='string'||!v.isWellFormed())||new Set(t.variants).size!==t.variants.length))throw Error('wire enum');
  if(['list','vector','option'].includes(t.kind)){if(t.kind==='vector'&&(!Number.isInteger(t.size)||t.size<1||t.size>64))throw Error('wire vector');check(t.element,d+1);}
  if(t.kind==='result'){check(t.ok,d+1);check(t.error,d+1);}
 }
 check(root);const names=Object.fromEntries([...used].sort().map(k=>[k,named[k]]));
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',wireEncoder.encode(wireCanonical({format:valueWireFormat,root,named:names}))));
 return new ValueCodec({format:valueWireFormat,root,named:names,identity:Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('')});
}
// Resolve immutable descriptor edges once. Logical validation traverses the
// literal schema; single-child nodes use a loop rather than recursive closures.
function wireValuePlan(codec){
 const seen=new WeakMap();let remaining=100000;
 const build=type=>{
  const t=codec.resolve(type);if(seen.has(t))return seen.get(t);
  if(--remaining<0)throw Error('wire descriptor limit');const p={kind:t.kind,type:t,decode:null,decodeCompact:null};seen.set(t,p);
  if(t.kind==='record')p.fields=t.fields.map(f=>({name:f.name,plan:build(f.type)}));
  if(t.kind==='list'||t.kind==='vector'||t.kind==='option')p.element=build(t.element);
  if(t.kind==='result'){p.ok=build(t.ok);p.error=build(t.error);}
  return p;
 };return build(codec.descriptor.root);
}
function wireBindDecodePlan(root,compact=false){
 const seen=new Set(),pending=[root];let flags=0;
 while(pending.length){
  const p=pending.pop();if(seen.has(p))continue;seen.add(p);if(compact)p.decodeCompact=compactDecodeOperation(p);else p.decode=wireDecodeOperation(p);
  if(p.fields?.length>4)flags|=1;
  if(p.kind==='u32'||p.kind==='i32'||p.kind==='u64'||p.kind==='f32')flags|=2;
  if(p.fields)for(const f of p.fields)pending.push(f.plan);
  if(p.element)pending.push(p.element);
  if(p.ok){pending.push(p.ok);pending.push(p.error);}
 }
 return flags|4;
}
// Select literal descriptor operations once, without runtime source generation
// or eval. Recursive edges call the completed plan. The generic scanner remains
// the visitor/validation path and an independent materialisation implementation.
function wireReadOperation(p){
 const t=p.type;
 let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':read=(r,end)=>{r.size(end,4);const value={F32Bits:r.view.getUint32(r.cursor,true)};r.cursor=end;return value;};break;
  case 'u64':read=(r,end)=>{r.size(end,8);const value=r.view.getBigUint64(r.cursor,true);r.cursor=end;return value;};break;
  case 'string':read=(r,end)=>r.text(end);break;
  case 'int':read=(r,end)=>{const text=r.text(end);if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=(r,end)=>{const text=r.text(end);if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=(r,end)=>{const text=r.text(end);if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{
    if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;
    if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');
    const values=new Array(n);for(let i=0;i<n;i++)values[i]=element.decode(r,end,d+1);return values;
   };break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1)});break;
    case 2:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1)});break;
    case 3:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1)});break;
    case 4:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1),[fs[3].name]:fs[3].plan.decode(r,end,d+1)});break;
    default:read=(r,end,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decode(r,end,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,end,d)=>{const tag=r.tag(end);return tag?{Some:p.element.decode(r,end,d+1)}:{None:null};};break;
  case 'result':read=(r,end,d)=>r.tag(end)?{Err:p.error.decode(r,end,d+1)}:{Ok:p.ok.decode(r,end,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function wireDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=wireReadOperation(field.plan),name=field.name;
  return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),childEnd=r.enter(end,d+1),item=read(r,childEnd,d+1);if(r.cursor!==childEnd)throw Error('trailing wire frame bytes');const value={[name]:item};if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
 }
 const read=wireReadOperation(p);
 return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
}
class WireDecodeCursor{
 constructor(bytes,view,limits){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
// Bind literal validation and postorder visitation once for every descriptor.
// No logical carriers are allocated; projection still validates every child.
function wireScanPlan(root){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,scan:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.scan=wireScanOperation(p);return p;
 };
 return build(root);
}
function wireScanOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':case 'u64':{const size=p.kind==='f32'?4:8;read=(r,end)=>{r.size(end,size);r.cursor=end;};break;}
  case 'string':read=(r,end)=>{let i=r.cursor;while(i<end&&r.bytes[i]<128)i++;if(i<end)wireDecoder.decode(r.bytes.subarray(r.cursor,end));r.cursor=end;};break;
  case 'int':case 'id':case 'enum':read=(r,end)=>{const text=r.text(end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');for(let i=0;i<n;i++)element.scan(r,end,d+1);};break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>{};break;
    case 1:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);};break;
    case 2:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);};break;
    case 3:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);};break;
    case 4:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);fs[3].plan.scan(r,end,d+1);};break;
    default:read=(r,end,d)=>{for(const f of fs)f.plan.scan(r,end,d+1);};
   }break;
  }
  case 'option':read=(r,end,d)=>{if(r.tag(end))p.element.scan(r,end,d+1);};break;
  case 'result':read=(r,end,d)=>{(r.tag(end)?p.error:p.ok).scan(r,end,d+1);};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return (r,parentEnd,d)=>{
  const end=r.enter(parentEnd,d),start=r.cursor,value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');
  const visitor=r.visitor;if(visitor&&(!r.selected||r.selected.has(t.name))){if(r.spans)visitor(t,r.bytes,start,end,d);else visitor(t,r.bytes.subarray(start,end),d);}
  return value;
 };
}
// Separate methods keep decoding's cursor callsites monomorphic. Both cursors
// are checked against the independent generic scanner and malformed fixtures.
class WireScanCursor{
 constructor(bytes,view,limits,visitor,selected,spans){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.visitor=visitor;this.selected=selected;this.spans=spans;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
function compactReadOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=()=>null;break;
  case 'bool':read=r=>{r.require(1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':case 'i32':read=r=>{r.require(4);const n=p.kind==='u32'?r.view.getUint32(r.cursor,true):r.view.getInt32(r.cursor,true);r.cursor+=4;return n;};break;
  case 'f32':read=r=>{r.require(4);const n=r.view.getUint32(r.cursor,true);r.cursor+=4;return {F32Bits:n};};break;
  case 'u64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return n;};break;
  case 'string':read=r=>r.text();break;
  case 'int':read=r=>{const text=r.text();if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=r=>{const text=r.text();if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=r=>{const text=r.text();if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':read=(r,d)=>{const n=r.count();if(n>r.remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');const values=new Array(n);for(let i=0;i<n;i++)values[i]=p.element.decodeCompact(r,d+1);return values;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1)});break;
    case 2:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1)});break;
    case 3:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1)});break;
    case 4:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1),[fs[3].name]:fs[3].plan.decodeCompact(r,d+1)});break;
    default:read=(r,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decodeCompact(r,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,d)=>r.tag()?{Some:p.element.decodeCompact(r,d+1)}:{None:null};break;
  case 'result':read=(r,d)=>r.tag()?{Err:p.error.decodeCompact(r,d+1)}:{Ok:p.ok.decodeCompact(r,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function compactDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=compactReadOperation(field.plan),name=field.name;
  return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');if(d+1>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return {[name]:read(r,d+1)};};
 }
 const read=compactReadOperation(p);
 return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return read(r,d);};
}
class CompactDecodeCursor{
 constructor(bytes,limits,flags){this.bytes=bytes;this.view=flags&2?new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength):null;this.cursor=1;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 require(n){if(n>this.bytes.length-this.cursor)throw Error('truncated compact value');}
 count(){
  if(this.cursor>=this.bytes.length)throw Error('truncated compact value');
  const first=this.bytes[this.cursor++];if(first<128)return first;
  let value=first&127,scale=128;
  for(let i=1;i<5;i++){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const byte=this.bytes[this.cursor++];if(i===4&&byte>15)throw Error('compact count overflow');value+=(byte&127)*scale;if(byte<128){if(byte===0)throw Error('noncanonical compact count');return value;}scale*=128;}throw Error('compact count overflow');
 }
 tag(){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const tag=this.bytes[this.cursor++];if(tag>1)throw Error('wire sum tag');return tag;}
 text(){const n=this.count();this.require(n);const start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
function wireInvalidValue(){throw Error('invalid value for wire schema');}
// Capture has the canonical logical meaning of decode(encode(value)), without
// allocating wire bytes. A separate plan leaves validation/decoder hot shapes
// unchanged and never retains host input containers between calls.
function wireCapturePlan(root,checked=true){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,capture:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({name:f.name,plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.capture=checked?wireCaptureOperation(p):wireCopyOperation(p);return p;
 };return build(root);
}
function wireCaptureOperation(p){
 const t=p.type;let copy;
 switch(p.kind){
  case 'unit':copy=v=>{if(v!==null)wireInvalidValue();return null;};break;
  case 'bool':copy=(v,r)=>{if(typeof v!=='boolean')wireInvalidValue();r.add(1);return v;};break;
  case 'u32':case 'i32':{
   const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
   copy=(v,r)=>{if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();r.add(4);return v===0?0:v;};break;
  }
  case 'u64':copy=(v,r)=>{const kind=typeof v;if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();r.add(8);return n;};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'string':case 'int':case 'id':case 'enum':copy=(v,r)=>{const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;if(typeof text!=='string'||!text.isWellFormed()||text.length>r.limit)wireInvalidValue();if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();r.add(wireUtf8Length(text));return p.kind==='int'?{Int:text}:text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   copy=(v,r,d)=>{if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();const n=v.length;if(n>r.remaining||size!==null&&n!==size)wireInvalidValue();r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=element.capture(v[i],r,d+1);return out;};break;
  }
  case 'record':{
   const fs=p.fields;let fields;
   switch(fs.length){
    case 0:fields=()=>({});break;
    case 1:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:fields=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }
   copy=(v,r,d)=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();for(const f of fs)if(!wireOwn(v,f.name))wireInvalidValue();return fields(v,r,d);};break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'None')&&v.None===null)return {None:null};if(wireTagged(v,'Some'))return {Some:p.element.capture(v.Some,r,d+1)};wireInvalidValue();};break;
  case 'result':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'Ok'))return {Ok:p.ok.capture(v.Ok,r,d+1)};if(wireTagged(v,'Err'))return {Err:p.error.capture(v.Err,r,d+1)};wireInvalidValue();};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
class WireCaptureCursor{
 constructor(limits){this.remaining=limits.nodes;this.depth=limits.depth;this.limit=limits.bytes;this.bytes=40;this.add(0);}
 add(n){this.bytes+=n;if(this.bytes>this.limit)throw Error('wire byte limit');}
 enter(depth,bytes){if(depth>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.add(bytes);}
 text(value){if(value.length>this.limit)throw Error('wire byte limit');this.add(wireUtf8Length(value));}
}
// Literal lowerers share this fixed resource policy with logical capture.
export function createValueCaptureBudget(options=wireDefaultOptions){return new WireCaptureCursor(wireLimits(options));}
// The trusted-value API has the same canonical copy and ownership semantics.
// Its caller supplies a stable value accepted by validateValue. Shape/range
// checks remain at external capture boundaries; resource limits still apply.
function wireCopyOperation(p){
 let copy;
 switch(p.kind){
  case 'unit':copy=()=>null;break;
  case 'bool':copy=(v,r)=>{r.add(1);return v;};break;
  case 'u32':copy=(v,r)=>{r.add(4);return v>>>0;};break;
  case 'i32':copy=(v,r)=>{r.add(4);return v|0;};break;
  case 'u64':copy=(v,r)=>{r.add(8);return BigInt(v);};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'){wireFloat.setFloat32(0,v,true);bits=wireFloat.getUint32(0,true);}else bits=v.F32Bits;r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'string':case 'id':case 'enum':copy=(v,r)=>{r.add(wireUtf8Length(v));return v;};break;
  case 'int':copy=(v,r)=>{const text=typeof v==='bigint'?v.toString():v.Int;r.add(wireUtf8Length(text));return {Int:text};};break;
  case 'list':case 'vector':copy=(v,r,d)=>{const n=v.length;if(n>r.remaining)throw Error('wire sequence size');r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=p.element.capture(v[i],r,d+1);return out;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:copy=()=>({});break;
    case 1:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:copy=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'None')&&v.None===null?{None:null}:{Some:p.element.capture(v.Some,r,d+1)};};break;
  case 'result':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'Ok')?{Ok:p.ok.capture(v.Ok,r,d+1)}:{Err:p.error.capture(v.Err,r,d+1)};};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
// Emit the cached literal schema with one forward writer. Each value is checked
// where it is consumed; byte bounds belong to the writer, not a second size walk.
function wireEncodeValue(root,value,l,w){
 let remaining=l.nodes;const depthLimit=l.depth;
 const node=(p,v,d)=>{
  if(d>depthLimit||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type,start=w.beginNode();
  switch(p.kind){
   case 'unit':if(v!==null)wireInvalidValue();break;
   case 'bool':if(typeof v!=='boolean')wireInvalidValue();w.byte(+v);break;
   case 'u32':case 'i32':{
    const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
    if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();w.word(v>>>0);break;
   }
   case 'u64':{
    const kind=typeof v;
    if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
    const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();w.wide(n);break;
   }
   case 'f32':{
    let bits;
    if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}
    else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
    w.word(bits);break;
   }
   case 'string':case 'int':case 'id':case 'enum':{
    const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
    if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&(typeof text!=='string'||!/^[0-9a-f]{32}$/.test(text))||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
    w.text(text);break;
   }
   case 'list':case 'vector':{
    if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
    if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
    w.count(v.length);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);break;
   }
   case 'record':{
    const fs=p.fields;
    if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
    for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
    for(let i=0;i<fs.length;i++){const f=fs[i];node(f.plan,v[f.name],d+1);}break;
   }
   case 'option':{
    if(wireTagged(v,'None')&&v.None===null)w.byte(0);
    else if(wireTagged(v,'Some')){w.byte(1);node(p.element,v.Some,d+1);}else wireInvalidValue();break;
   }
   case 'result':{
    if(wireTagged(v,'Ok')){w.byte(0);node(p.ok,v.Ok,d+1);}
    else if(wireTagged(v,'Err')){w.byte(1);node(p.error,v.Err,d+1);}else wireInvalidValue();break;
   }
   default:throw Error('unsupported wire kind');
  }
  w.endNode(start);
 };
 node(root,value,0);
}
function wireCheckValue(root,value,l){
 let remaining=l.nodes,total=40;
 const add=n=>{total+=n;if(total>l.bytes)throw Error('wire byte limit');};
 const node=(p,v,d)=>{
  while(true){
   if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
   const t=p.type;
   switch(p.kind){
    case 'unit':if(v!==null)wireInvalidValue();add(4);return;
    case 'bool':if(typeof v!=='boolean')wireInvalidValue();add(5);return;
    case 'u32':case 'i32':{
     const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
     if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();add(8);return;
    }
    case 'u64':{
     const kind=typeof v;
     if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
     const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();add(12);return;
    }
    case 'f32':{
     if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();}
     else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();const bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
     add(8);return;
    }
    case 'string':case 'int':case 'id':case 'enum':{
     const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
     if(typeof text!=='string'||!text.isWellFormed()||text.length>l.bytes)wireInvalidValue();
     if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
     add(4+wireUtf8Length(text));return;
    }
    case 'list':case 'vector':{
     if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
     if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
     add(8);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);return;
    }
    case 'record':{
     const fs=p.fields;
     if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
     for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
     add(4);if(!fs.length)return;
     for(let i=0;i<fs.length-1;i++)node(fs[i].plan,v[fs[i].name],d+1);
     const f=fs[fs.length-1];p=f.plan;v=v[f.name];d++;continue;
    }
    case 'option':{
     if(wireTagged(v,'None')&&v.None===null){add(5);return;}
     if(!wireTagged(v,'Some'))wireInvalidValue();add(5);p=p.element;v=v.Some;d++;continue;
    }
    case 'result':{
     if(wireTagged(v,'Ok')){add(5);p=p.ok;v=v.Ok;}
     else if(wireTagged(v,'Err')){add(5);p=p.error;v=v.Err;}else wireInvalidValue();
     d++;continue;
    }
    default:throw Error('unsupported wire kind');
   }
  }
 };
 node(root,value,0);if(total>l.bytes)throw Error('wire byte limit');
}
// A single cursor replaces per-node child closures and {end,value} temporaries.
// Projection filters limit callback materialisation, never schema validation.
function wireScanValue(root,bytes,view,l,materialize,visitor,selected,spans){
 let cursor=40,remaining=l.nodes;
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,parentEnd,d)=>{
  if(d>l.depth||--remaining<0||cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const t=p.type,start=cursor+4,end=start+view.getUint32(cursor,true);if(end>parentEnd)throw Error('truncated wire frame');cursor=start;let value;
  switch(p.kind){
   case 'unit':if(end-start!==0)throw Error('malformed wire scalar');value=null;break;
   case 'bool':if(end-start!==1)throw Error('malformed wire scalar');if(bytes[start]>1)throw Error('invalid wire Bool');value=!!bytes[start];cursor=end;break;
   case 'u32':case 'i32':if(end-start!==4)throw Error('malformed wire scalar');value=p.kind==='u32'?view.getUint32(start,true):view.getInt32(start,true);cursor=end;break;
   case 'f32':if(end-start!==4)throw Error('malformed wire scalar');if(materialize)value={F32Bits:view.getUint32(start,true)};cursor=end;break;
   case 'u64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value=view.getBigUint64(start,true);cursor=end;break;
   case 'string':case 'int':case 'id':case 'enum':{
    if(p.kind==='string'&&!materialize){let i=start;while(i<end&&bytes[i]<128)i++;if(i<end)wireDecoder.decode(bytes.subarray(start,end));}
    else{const text=wireDecodeText(bytes,start,end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    cursor=end;break;
   }
   case 'list':case 'vector':{
    if(start+4>end)throw Error('wire list count');const n=view.getUint32(start,true);cursor+=4;
    if(n>remaining||n>Math.floor((end-cursor)/4)||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,end,d+1);if(materialize)value.push(child);}break;
   }
   case 'record':{
    const fs=p.fields;
    // Computed literal keys create own data properties even for __proto__ or
    // prototype setters. Common small records need no descriptor allocations.
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:value={};break;case 1:value={[fs[0].name]:node(fs[0].plan,end,d+1)};break;case 2:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1)};break;case 3:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1)};break;case 4:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1),[fs[3].name]:node(fs[3].plan,end,d+1)};break;}
    }else{if(materialize)value={};for(const f of fs){const child=node(f.plan,end,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}}break;
   }
   case 'option':case 'result':{
    if(start===end||bytes[cursor]>1)throw Error('wire sum tag');const tag=bytes[cursor++];
    if(p.kind==='option'&&tag===0){if(materialize)value={None:null};}
    else{const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,end,d+1);if(materialize)value={[label]:child};}break;
   }
   default:throw Error('unsupported wire kind');
  }
  if(cursor!==end)throw Error('trailing wire frame bytes');
  if(visitor&&(!selected||selected.has(t.name))){if(spans)visitor(t,bytes,start,end,d);else visitor(t,bytes.subarray(start,end),d);}
  return value;
 };
 const result=node(root,bytes.length,0);if(cursor!==bytes.length)throw Error('trailing wire bytes');return result;
}
export class ValueCodec{
 #hash;
 #header;
 #headerWords;
 #descriptor;
 #valuePlan;
 #compactCodec;
 #encoder;
 #decodeBound=0;
 #scanPlan=null;
 #capturePlan=null;
 #copyPlan=null;
 get descriptor(){return this.#descriptor;}
 constructor(descriptor){
  // This synchronous path is for compiler-generated immutable metadata. For
  // untrusted descriptors use createValueCodec and compare the computed identity.
  if(descriptor?.format!==valueWireFormat||!/^[0-9a-f]{64}$/.test(descriptor.identity))throw Error('invalid wire schema');
  this.#descriptor=structuredClone(descriptor);this.#hash=Uint8Array.from(descriptor.identity.match(/../g),s=>parseInt(s,16));
  this.#header=new Uint8Array(40);this.#header.set(wireMagic);this.#header.set(this.#hash,8);
  const headerView=new DataView(this.#header.buffer);this.#headerWords=Array.from({length:10},(_,i)=>headerView.getUint32(i*4,true));
  const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}};freeze(this.descriptor);this.#valuePlan=wireValuePlan(this);
 }
 resolve(t){for(let i=0;i<64;i++){if(t.kind!=='ref')return t;t=this.descriptor.named[t.name];if(!t)throw Error('wire reference');}throw Error('wire reference cycle');}
 validateValue(value,options=wireDefaultOptions){wireCheckValue(this.#valuePlan,value,wireLimits(options));return true;}
 capture(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#capturePlan??=wireCapturePlan(this.#valuePlan);return this.#capturePlan.capture(value,new WireCaptureCursor(limits),0);}
 copy(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#copyPlan??=wireCapturePlan(this.#valuePlan,false);return this.#copyPlan.capture(value,new WireCaptureCursor(limits),0);}
 compact(){return this.#compactCodec??=new CompactValueCodec(this);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new WireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.bytes(this.#header);wireEncodeValue(this.#valuePlan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new WireEncoder(options);w.bytes(wireMagic);w.bytes(this.#hash);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 scan(bytes,options=wireDefaultOptions,materialize=false,visitor=null,names=null,spans=false){
  const l=wireLimits(options);if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<44||bytes.length>l.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==this.#headerWords[i])throw Error('wire format or schema mismatch');
  if(names!==null&&(!Array.isArray(names)||names.length>100000||names.some(n=>typeof n!=='string')))throw Error('wire visitor names');
  if(materialize&&!visitor){this.#decodeBound||=wireBindDecodePlan(this.#valuePlan);const cursor=new WireDecodeCursor(bytes,view,l);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#valuePlan.decode(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  if(!materialize){this.#scanPlan??=wireScanPlan(this.#valuePlan);const cursor=new WireScanCursor(bytes,view,l,visitor,names===null?null:new Set(names),spans),value=this.#scanPlan.scan(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  return wireScanValue(this.#valuePlan,bytes,view,l,materialize,visitor,names===null?null:new Set(names),spans);
 }
 visit(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names);}
 visitSpans(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names,true);}
 validate(bytes,options=wireDefaultOptions){this.scan(bytes,options,false);return true;}
 decode(bytes,options=wireDefaultOptions){return this.scan(bytes,options,true);}
}

// Bounded forward emission avoids building and repeatedly joining child buffers.
class WireEncoder{
 #data=new Uint8Array(256);#view=new DataView(this.#data.buffer);#at=0;#remaining;#depth=0;#byteLimit;#depthLimit;
 active=false;
 constructor(options){this.reset(options);}
 reset(options){const limits=wireLimits(options);this.#byteLimit=limits.bytes;this.#depthLimit=limits.depth;this.#remaining=limits.nodes;this.#depth=0;this.#at=0;this.active=true;}
 get capacity(){return this.#data.length;}
 get position(){return this.#at;}
 beginNode(){const at=this.#at;this.word(0);return at;}
 endNode(at){this.patchWord(at,this.#at-at-4);}
 count(n){this.word(n);}
 beginCount(){const at=this.position;this.count(0);return at;}
 endCount(at,n){this.patchWord(at,n);}
 #reserve(size){
  const end=this.#at+size;if(end>this.#byteLimit)throw Error('wire byte limit');
  if(end>this.#data.length){const next=new Uint8Array(Math.min(this.#byteLimit,Math.max(end,this.#data.length*2)));next.set(this.#data.subarray(0,this.#at));this.#data=next;this.#view=new DataView(next.buffer);}
  return end;
 }
 bytes(bytes){const end=this.#reserve(bytes.length);this.#data.set(bytes,this.#at);this.#at=end;}
 byte(n){if(!Number.isInteger(n)||n<0||n>255)throw Error('wire byte range');this.#reserve(1);this.#data[this.#at++]=n;}
 word(n){if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire word range');const end=this.#reserve(4);this.#view.setUint32(this.#at,n,true);this.#at=end;}
 wide(n){if(typeof n!=='bigint'||n<0n||n>18446744073709551615n)throw Error('wire wide range');const end=this.#reserve(8);this.#view.setBigUint64(this.#at,n,true);this.#at=end;}
 text(text,count=false){
  if(typeof text!=='string')throw Error('wire Unicode');
  if(text.length<=16){
   let ascii=true;for(let i=0;i<text.length;i++)if(text.charCodeAt(i)>=128){ascii=false;break;}
   if(ascii){if(count)this.count(text.length);const end=this.#reserve(text.length);for(let i=0;i<text.length;i++)this.#data[this.#at+i]=text.charCodeAt(i);this.#at=end;return;}
  }
  if(!text.isWellFormed())throw Error('wire Unicode');const size=wireUtf8Length(text);if(count)this.count(size);
  const end=this.#reserve(size),r=wireEncoder.encodeInto(text,this.#data.subarray(this.#at,end));if(r.read!==text.length||r.written!==size)throw Error('wire UTF-8 size');this.#at=end;
 }
 patchWord(at,n){if(!Number.isInteger(at)||at<0||at+4>this.#at||!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire patch offset');this.#view.setUint32(at,n,true);}
 patchByte(at,n){if(!Number.isInteger(at)||at<0||at>=this.#at||!Number.isInteger(n)||n<0||n>255)throw Error('wire patch offset');this.#data[at]=n;}
 replace(at,removed,bytes){
  if(!Number.isInteger(at)||!Number.isInteger(removed)||at<0||removed<0||at+removed>this.#at||!(bytes instanceof Uint8Array))throw Error('wire replacement range');
  const extra=bytes.length-removed,end=extra>0?this.#reserve(extra):this.#at+extra;
  this.#data.copyWithin(at+bytes.length,at+removed,this.#at);this.#data.set(bytes,at);this.#at=end;
 }
 // Literal generated writers use balanced frames without per-node callbacks.
 // An exception abandons this invocation; encodeWith never reuses its writer.
 openFrame(){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;return at;}
 closeFrame(at){if(this.#depth===0)throw Error('wire frame boundary');this.#depth--;this.endNode(at);}
 frame(emit){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;try{emit(this);}finally{this.#depth--;}this.endNode(at);}
 reorder(start,spans){
  const sorted=spans.slice().sort((a,b)=>a[0]-b[0]);let at=start;
  for(const [a,b] of sorted){if(!Number.isInteger(a)||!Number.isInteger(b)||a!==at||b<a)throw Error('wire span permutation');at=b;}
  if(start<0||start>this.#at||at!==this.#at)throw Error('wire span permutation');
  if(spans.every((s,i)=>s===sorted[i]))return;
  const copy=this.#data.slice(start,this.#at);at=start;for(const [a,b] of spans){this.#data.set(copy.subarray(a-start,b-start),at);at+=b-a;}
 }
 finish(){if(this.#depth!==0)throw Error('wire frame boundary');return this.#data.slice(0,this.#at);}
}

class CompactWireEncoder extends WireEncoder{
 beginNode(){return 0;}
 endNode(){}
 endCount(at,n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  if(n<128){this.patchByte(at,n);return;}
  const bytes=[];while(n>=128){bytes.push(n%128+128);n=Math.floor(n/128);}bytes.push(n);this.replace(at,1,Uint8Array.from(bytes));
 }
 count(n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  while(n>=128){this.byte(n%128+128);n=Math.floor(n/128);}this.byte(n);
 }
 text(text){super.text(text,true);}
}

function compactScanValue(root,bytes,l,materialize){
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let cursor=1,remaining=l.nodes;
 const require=n=>{if(n>bytes.length-cursor)throw Error('truncated compact value');};
 const count=()=>{
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   require(1);const byte=bytes[cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }throw Error('compact count overflow');
 };
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,d)=>{
  if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type;let value;
  switch(p.kind){
   case 'unit':return null;
   case 'bool':require(1);if(bytes[cursor]>1)throw Error('invalid wire Bool');return !!bytes[cursor++];
   case 'u32':case 'i32':require(4);value=p.kind==='u32'?view.getUint32(cursor,true):view.getInt32(cursor,true);cursor+=4;return value;
   case 'f32':require(4);if(materialize)value={F32Bits:view.getUint32(cursor,true)};cursor+=4;return value;
   case 'u64':require(8);if(materialize)value=view.getBigUint64(cursor,true);cursor+=8;return value;
   case 'string':case 'int':case 'id':case 'enum':{
    const n=count();require(n);const start=cursor;cursor+=n;
    if(p.kind==='string'&&!materialize){let i=start;while(i<cursor&&bytes[i]<128)i++;if(i<cursor)wireDecoder.decode(bytes.subarray(start,cursor));}
    else{const text=wireDecodeText(bytes,start,cursor);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    return value;
   }
   case 'list':case 'vector':{
    const n=count();if(n>remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,d+1);if(materialize)value.push(child);}return value;
   }
   case 'record':{
    const fs=p.fields;
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:return {};case 1:return {[fs[0].name]:node(fs[0].plan,d+1)};case 2:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1)};case 3:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1)};case 4:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1),[fs[3].name]:node(fs[3].plan,d+1)};}
    }
    if(materialize)value={};for(const f of fs){const child=node(f.plan,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}return value;
   }
   case 'option':case 'result':{
    require(1);const tag=bytes[cursor++];if(tag>1)throw Error('wire sum tag');
    if(p.kind==='option'&&tag===0)return materialize?{None:null}:undefined;
    const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,d+1);
    return materialize?{[label]:child}:undefined;
   }
   default:throw Error('unsupported wire kind');
  }
 };
 const value=node(root,0);if(cursor!==bytes.length)throw Error('trailing compact bytes');return value;
}

// General transport codec, independent of source rewrites and checkpoints.
// The sender/receiver must negotiate this exact identity and format. There is
// deliberately no claim that the bytes themselves identify their schema.
export class CompactValueCodec{
 #source;#plan;#encoder;#decodeBound=0;
 get format(){return compactValueWireFormat;}
 get identity(){return this.#source.descriptor.identity;}
 constructor(valueCodec){if(!(valueCodec instanceof ValueCodec))throw Error('compact codec requires a checked value codec');this.#source=valueCodec;this.#plan=wireValuePlan(valueCodec);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new CompactWireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.byte(1);wireEncodeValue(this.#plan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new CompactWireEncoder(options);w.byte(1);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 #scan(bytes,options,materialize){
  const l=wireLimits(options);
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<1||bytes.length>l.bytes)throw Error('wire byte limit or header');
  if(bytes[0]!==1)throw Error('compact format mismatch');
  if(materialize){this.#decodeBound||=wireBindDecodePlan(this.#plan,true);const cursor=new CompactDecodeCursor(bytes,l,this.#decodeBound);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#plan.decodeCompact(cursor,0);if(cursor.cursor!==bytes.length)throw Error('trailing compact bytes');return value;}
  return compactScanValue(this.#plan,bytes,l,materialize);
 }
 decode(bytes,options=wireDefaultOptions){return this.#scan(bytes,options,true);}
 validate(bytes,options=wireDefaultOptions){this.#scan(bytes,options,false);return true;}
}

// Compiler materialisers consume already validated bytes synchronously. This
// factory is for trusted emitted code, not untrusted descriptor/callback data.
// The complete generic validator runs before any compiler reader is invoked.
class ValidatedValueReader{
 constructor(bytes,compact){this.bytes=bytes;this.view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);this.cursor=compact?1:40;this.compact=compact;}
 frame(){if(this.compact)return 0;const end=this.cursor+4+this.view.getUint32(this.cursor,true);this.cursor+=4;return end;}
 finish(end){if(!this.compact&&this.cursor!==end)throw Error('compiled reader frame mismatch');}
 byte(){return this.bytes[this.cursor++];}
 word(){const n=this.view.getUint32(this.cursor,true);this.cursor+=4;return n;}
 signed(){const n=this.view.getInt32(this.cursor,true);this.cursor+=4;return n;}
 wide(){const n=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return n;}
 count(){if(!this.compact)return this.word();let n=0,scale=1,byte;do{byte=this.byte();n+=(byte&127)*scale;scale*=128;}while(byte>=128);return n;}
 text(end){const n=this.compact?this.count():end-this.cursor,start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
class CompiledCompactValueCodec extends CompactValueCodec{
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,true),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
}
class CompiledValueCodec extends ValueCodec{
 #read;#compiledCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,false),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
 compact(){return this.#compiledCompact??=new CompiledCompactValueCodec(this,this.#read);}
}
export function createCompiledValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new CompiledValueCodec(descriptor,read);}

// Trusted literal materialisers may use this checked reader to validate and
// construct in one traversal. The emitter must use frame/finish at every source
// node, typed text reads and counted sequence reads; arbitrary callbacks do not
// establish a schema correspondence proof. The independent scanner remains the
// validation oracle and the original factory retains its pre-validation path.
function literalValueHeader(identity){
 const bytes=new Uint8Array(40);bytes.set(wireMagic);
 for(let i=0;i<32;i++)bytes[i+8]=parseInt(identity.slice(i*2,i*2+2),16);
 const view=new DataView(bytes.buffer),words=new Uint32Array(10);
 for(let i=0;i<10;i++)words[i]=view.getUint32(i*4,true);
 return words;
}
class CheckedLiteralValueReader {
 constructor(bytes,header,compact,limits){
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<(compact?1:44)||bytes.length>limits.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  if(compact){if(bytes[0]!==1)throw Error('compact format mismatch');}
  else for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==header[i])throw Error('wire format or schema mismatch');
  this.bytes=bytes;this.view=view;
  this.cursor=compact?1:40;this.compact=compact;this.remaining=limits.nodes;this.depth=limits.depth;this.ends=[];
 }
 require(n){if(this.cursor+n>(this.ends.at(-1)??this.bytes.length))throw Error('truncated wire frame');}
 frame(){
  if(this.ends.length>this.depth||--this.remaining<0)throw Error('wire node or depth limit');
  let end=this.bytes.length;
  if(!this.compact){this.require(4);end=this.cursor+4+this.view.getUint32(this.cursor,true);this.require(end-this.cursor);this.cursor+=4;}
  this.ends.push(end);return this.compact?0:end;
 }
 finish(end){
  if(!this.ends.length||!this.compact&&(this.ends.at(-1)!==end||this.cursor!==end))throw Error('compiled reader frame mismatch');
  this.ends.pop();
 }
 byte(){this.require(1);const value=this.bytes[this.cursor++];if(value>1)throw Error('wire sum tag or Bool');return value;}
 word(){this.require(4);const value=this.view.getUint32(this.cursor,true);this.cursor+=4;return value;}
 signed(){this.require(4);const value=this.view.getInt32(this.cursor,true);this.cursor+=4;return value;}
 wide(){this.require(8);const value=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return value;}
 rawCount(){
  if(!this.compact)return this.word();
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   this.require(1);const byte=this.bytes[this.cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }
  throw Error('compact count overflow');
 }
 count(size){
  const value=this.rawCount();
  if(value>this.remaining||size!==undefined&&value!==size)throw Error('wire sequence size');
  return value;
 }
 text(end,kind='string',variants){
  const size=this.compact?this.rawCount():end-this.cursor;
  this.require(size);const start=this.cursor;this.cursor+=size;
  const value=wireDecodeText(this.bytes,start,this.cursor);
  if(kind==='int'&&!wireDecimal(value)||kind==='id'&&!/^[0-9a-f]{32}$/.test(value)||kind==='enum'&&!variants.includes(value))throw Error('malformed wire text');
  return value;
 }
 complete(){if(this.ends.length||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
class FusedCompactValueCodec extends CompactValueCodec {
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedLiteralValueReader(bytes,null,true,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
}
class FusedValueCodec extends ValueCodec {
 #read;#header;#fusedCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;this.#header=literalValueHeader(this.descriptor.identity);}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedLiteralValueReader(bytes,this.#header,false,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
 compact(){return this.#fusedCompact??=new FusedCompactValueCodec(this,this.#read);}
}
export function createFusedValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new FusedValueCodec(descriptor,read);}
// JSON text is a boundary adapter to an ordinary recursive Ink datatype.
// No JavaScript Number conversion occurs for JSON numeric tokens.
export function jsonNumberToken(s){return typeof s==='string'&&/^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/.test(s);}
// JSON numeric tokens have an ASCII grammar. Check validated UTF-8 spans
// directly, preserving exact lexemes without allocating a decoded String.
function jsonNumberSpan(bytes,lo,hi){
 let at=lo;if(bytes[at]===45)at++;
 if(at>=hi)return false;
 if(bytes[at]===48)at++;
 else{if(bytes[at]<49||bytes[at]>57)return false;do{at++;}while(at<hi&&bytes[at]>=48&&bytes[at]<=57);}
 if(at<hi&&bytes[at]===46){const start=++at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 if(at<hi&&(bytes[at]===69||bytes[at]===101)){at++;if(at<hi&&(bytes[at]===43||bytes[at]===45))at++;const start=at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 return at===hi;
}
const jsonWireEncoder=new TextEncoder();
// Scalar conversion completes before writer callbacks; no per-value byte array.
const jsonFloatScratch=new DataView(new ArrayBuffer(4));
function jsonUtf8Length(text){if(text.length>16&&!/[^\x00-\x7f]/.test(text))return text.length;let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const jsonLimits={bytes:16777216,nodes:1000000,depth:128};
function checkedJsonLimits(options){const l={...jsonLimits,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>jsonLimits[k])throw Error('JSON hard resource limit');return l;}
function jsonVariant(index,item){let payload=index===0?{}:{item0:item};if(index<5)payload={Ok:payload};for(let i=0;i<index;i++)payload={Err:payload};return {payload};}
export function parseJson(text,options={}){return parseJsonValue(text,options,null);}
function parseJsonValue(text,options,boundary){
 const p=new JsonWireReader(text,options);
 const value=(d,wireDepth=0)=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){boundary?.node(0,wireDepth);p.at+=4;return jsonVariant(0,null);}if(c==='t'&&text.startsWith('true',p.at)){boundary?.node(1,wireDepth);p.at+=4;return jsonVariant(1,true);}if(c==='f'&&text.startsWith('false',p.at)){boundary?.node(1,wireDepth);p.at+=5;return jsonVariant(1,false);}
  if(c==='"'){boundary?.node(3,wireDepth);const item=p.string();boundary?.text(item);return jsonVariant(3,item);}
  if(c==='['){boundary?.node(4,wireDepth);p.at++;const xs=[];if(!p.eat(']'))while(true){xs.push(value(d+1,wireDepth+8));if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}return jsonVariant(4,xs);}
  if(c==='{'){boundary?.node(5,wireDepth);p.at++;const xs=[],seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary?.member(key,wireDepth);if(!p.eat(':'))throw Error('JSON object colon');xs.push({key,value:value(d+1,wireDepth+9)});if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}return jsonVariant(5,xs);}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();boundary?.node(2,wireDepth);boundary?.text(token);return jsonVariant(2,token);}
  throw Error('invalid JSON value');
 };
 const out=value(0);p.finish();return out;
}
export function stringifyJson(value,options={}){return stringifyJsonValue(value,options,null);}
function stringifyJsonValue(value,options,boundary){
 const l=checkedJsonLimits(options);let remaining=l.nodes,bytes=0,output='';
 const emit=s=>{bytes+=jsonUtf8Length(s);if(bytes>l.bytes)throw Error('JSON byte limit');output+=s;};
 const write=(v,d,wireDepth=0)=>{
  if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');if(!v||Object.keys(v).length!==1||!Object.hasOwn(v,'payload'))throw Error('invalid JSON record');let p=v.payload,index=0;
  while(index<5&&p&&Object.hasOwn(p,'Err')){if(Object.keys(p).length!==1||boundary&&Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Err;index++;}
  if(index<5){if(!p||Object.keys(p).length!==1||!Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Ok;}
  if(!p||Object.keys(p).length!==(index===0?0:1)||index>0&&!Object.hasOwn(p,'item0'))throw Error('invalid JSON payload');const item=p.item0;boundary?.node(index,wireDepth);
  switch(index){
   case 0:emit('null');break;
   case 1:if(typeof item!=='boolean')throw Error('invalid JSON Boolean');emit(item?'true':'false');break;
   case 2:if(!jsonNumberToken(item))throw Error('invalid JSON number');boundary?.text(item);emit(item);break;
   case 3:if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary?.text(item);emit(JSON.stringify(item));break;
   case 4:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Array');const count=item.length;let visited=0;emit('[');item.forEach((x,i)=>{visited++;if(i)emit(',');write(x,d+1,wireDepth+8);});if(visited!==count)throw Error('invalid JSON Array');emit(']');break;}
   case 5:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Object');const count=item.length,seen=new Set();let visited=0;emit('{');item.forEach((m,i)=>{visited++;if(!m||Object.keys(m).length!==2||typeof m.key!=='string'||!m.key.isWellFormed()||!Object.hasOwn(m,'value')||boundary&&!Object.hasOwn(m,'key'))throw Error('invalid JSON member');if(seen.has(m.key))throw Error('duplicate JSON object key');seen.add(m.key);boundary?.member(m.key,wireDepth);if(i)emit(',');emit(JSON.stringify(m.key));emit(':');write(m.value,d+1,wireDepth+9);});if(visited!==count)throw Error('invalid JSON Object');emit('}');break;}
  }
 };write(value,0);return output;
}
// The adapter's schema is the fixed recursive JSON library shape checked by
// JsonCodec. Charge its ordinary record/sum/list wire nodes while parsing or
// rendering, rather than interpreting and walking the completed tree again.
function jsonBoundaryBudget(options){
 const l=checkedJsonLimits(options);let remaining=l.nodes,total=40;
 const charge=(nodes,bytes,depth)=>{remaining-=nodes;total+=bytes;if(remaining<0||depth>l.depth)throw Error('wire node or depth limit');if(total>l.bytes)throw Error('wire byte limit');};
 return {
  node(index,depth){charge(index===0?3:index<4?index+4:8,index===0?13:index===1?23:index===2?27:index===3?32:41,depth+(index===0?2:index<4?index+3:7));},
  text(text){charge(0,jsonUtf8Length(text),0);},
  member(key,depth){charge(2,8+jsonUtf8Length(key),depth+9);},
 };
}
function jsonSameSchema(a,b){
 if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;
 const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>Object.hasOwn(b,k)&&jsonSameSchema(a[k],b[k]));
}
// Host-object conversion is opt-in and JavaScript-only. Inspect data properties
// rather than invoking getters/toJSON; reflection is not a sandbox for proxies.
function jsonJSKeys(value){
 if(!value||typeof value!=='object')throw Error('expected a plain JavaScript object');
 const prototype=Object.getPrototypeOf(value);
 if(prototype!==Object.prototype&&prototype!==null)throw Error('expected a plain JavaScript object');
 const keys=Reflect.ownKeys(value);
 if(keys.some(k=>typeof k!=='string'))throw Error('JavaScript symbol keys are unsupported');
 return keys;
}
function jsonJSData(value,key){
 const property=Object.getOwnPropertyDescriptor(value,key);
 if(!property||!property.enumerable||!Object.hasOwn(property,'value'))throw Error('expected an enumerable own data property');
 return property.value;
}
function jsonJSRecord(value,names){
 const keys=jsonJSKeys(value);
 if(keys.length!==names.length||keys.some(k=>!names.includes(k)))throw Error('invalid JSON record or variant');
}
function jsonJSArray(value,remaining){
 if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype)throw Error('expected a plain JavaScript array');
 const length=value.length;
 if(length>remaining)throw Error('JSON node limit');
 const keys=Reflect.ownKeys(value);
 if(keys.length!==length+1||keys.some(k=>typeof k!=='string'||k!=='length'&&(!/^(0|[1-9][0-9]*)$/.test(k)||Number(k)>=length)))throw Error('sparse or decorated JavaScript arrays are unsupported');
 return length;
}
function jsonFromJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),active=new WeakSet();let remaining=limits.nodes;
 const text=value=>{if(!value.isWellFormed())throw Error('invalid JSON Unicode');boundary.text(value);return value;};
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  if(value===null){boundary.node(0,wireDepth);return jsonVariant(0);}
  switch(typeof value){
   case 'boolean':boundary.node(1,wireDepth);return jsonVariant(1,value);
   case 'string':boundary.node(3,wireDepth);return jsonVariant(3,text(value));
   case 'number':
    if(!Number.isFinite(value))throw Error('non-finite JavaScript numbers are unsupported');
    boundary.node(2,wireDepth);return jsonVariant(2,text(Object.is(value,-0)?'-0':String(value)));
   case 'bigint':boundary.node(2,wireDepth);return jsonVariant(2,text(String(value)));
   case 'object':break;
   default:throw Error('unsupported JavaScript value');
  }
  if(active.has(value))throw Error('cyclic JavaScript value');
  active.add(value);
  try{
   if(Array.isArray(value)){
    boundary.node(4,wireDepth);const count=jsonJSArray(value,remaining),items=[];
    for(let i=0;i<count;i++)items.push(visit(jsonJSData(value,String(i)),depth+1,wireDepth+8));
    return jsonVariant(4,items);
   }
   boundary.node(5,wireDepth);const keys=jsonJSKeys(value),members=[];
   if(keys.length>remaining)throw Error('JSON node limit');
   for(const key of keys){
    if(!key.isWellFormed())throw Error('invalid JSON Unicode');
    boundary.member(key,wireDepth);
    members.push({key,value:visit(jsonJSData(value,key),depth+1,wireDepth+9)});
   }
   return jsonVariant(5,members);
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
function jsonDecimalKey(token){
 const [,sign,whole,fraction='',exponent='0']=/^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(token);
 const digits=(whole+fraction).replace(/^0+/,'');
 if(!digits)return '0';
 const trimmed=digits.replace(/0+$/,'');
 return sign+trimmed+'e'+(Number(exponent)-fraction.length+digits.length-trimmed.length);
}
function jsonToJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),mode=options?.numbers??'number',active=new WeakSet();let remaining=limits.nodes;
 if(!['number','bigint','string'].includes(mode))throw Error('unknown JavaScript number policy');
 const number=token=>{
  if(!jsonNumberToken(token))throw Error('invalid JSON number');
  boundary.text(token);
  if(mode==='string')return token;
  if(mode==='bigint')return BigInt(jsonInteger(token,4096));
  const result=Number(token);
  if(!Number.isFinite(result)||jsonDecimalKey(token)!==jsonDecimalKey(String(result)))throw Error('JSON number loses precision as JavaScript Number; choose numbers: bigint or string');
  return result;
 };
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  jsonJSRecord(value,['payload']);
  if(active.has(value))throw Error('cyclic JSON value');
  active.add(value);
  try{
   let payload=jsonJSData(value,'payload'),index=0;
   while(index<5&&Object.hasOwn(payload,'Err')){jsonJSRecord(payload,['Err']);payload=jsonJSData(payload,'Err');index++;}
   if(index<5){jsonJSRecord(payload,['Ok']);payload=jsonJSData(payload,'Ok');}
   jsonJSRecord(payload,index===0?[]:['item0']);boundary.node(index,wireDepth);
   const item=index===0?null:jsonJSData(payload,'item0');
   if(index===0)return null;
   if(index===1){if(typeof item!=='boolean')throw Error('invalid JSON Boolean');return item;}
   if(index===2)return number(item);
   if(index===3){if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary.text(item);return item;}
   const count=jsonJSArray(item,remaining);
   if(index===4){const out=[];for(let i=0;i<count;i++)out.push(visit(jsonJSData(item,String(i)),depth+1,wireDepth+8));return out;}
   const out={},seen=new Set();
   for(let i=0;i<count;i++){
    const member=jsonJSData(item,String(i));jsonJSRecord(member,['key','value']);const key=jsonJSData(member,'key');
    if(typeof key!=='string'||!key.isWellFormed())throw Error('invalid JSON member key');
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary.member(key,wireDepth);
    Object.defineProperty(out,key,{value:visit(jsonJSData(member,'value'),depth+1,wireDepth+9),enumerable:true,writable:true,configurable:true});
   }
   return out;
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
const jsonConstructionPaths=Object.freeze(Array.from({length:6},(_,index)=>Object.freeze([0,...Array(index).fill(1),...(index<5?[0]:[]),0])));
function parseJsonConstructed(text,options,builder){
 const p=new JsonWireReader(text,options);
 const paths=jsonConstructionPaths;
 const fused=typeof builder.openPath==='function';
 const begin=index=>{if(fused){builder.openPath(paths[index]);return;}for(const choice of paths[index])builder.open(choice);};
 const end=index=>{for(let i=0;i<(fused?1:index<5?index+3:7);i++)builder.close();};
 const leaf=(index,item)=>{if(typeof builder.scalarPath==='function'){builder.scalarPath(paths[index],item);return;}begin(index);builder.scalar(item);end(index);};
 const value=d=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){p.at+=4;if(typeof builder.emptyPath==='function')builder.emptyPath(paths[0]);else{begin(0);end(0);}return;}
  if(c==='t'&&text.startsWith('true',p.at)){p.at+=4;leaf(1,true);return;}
  if(c==='f'&&text.startsWith('false',p.at)){p.at+=5;leaf(1,false);return;}
  if(c==='"'){leaf(3,p.string());return;}
  if(c==='['){begin(4);builder.open(0);p.at++;if(!p.eat(']'))while(true){value(d+1);if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}builder.close();end(4);return;}
  if(c==='{'){begin(5);builder.open(0);p.at++;const seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');builder.open(0);builder.scalar(key);value(d+1);builder.close();if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}builder.close();end(5);return;}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();leaf(2,token);return;}
  throw Error('invalid JSON value');
 };
 value(0);p.finish();return builder.finish();
}
const jsonCompiledRenderers=new WeakMap();
function compiledJsonRenderer(json,codec,unwrap){
 if(typeof codec?.reducer!=='function')throw Error('compiled JSON reduction unavailable');
 const source=codec.resolve(codec.descriptor.root),root=json.values.descriptor.root;
 const selected=unwrap&&source.kind==='result'?codec.resolve(source.ok):source;
 if(!jsonSameSchema(root,selected)||unwrap&&source.kind!=='result')throw Error('compiled JSON schema mismatch');
 let variants=root.fields[0].type;const roles=new Map([[root.name,'root']]);
 let member;
 for(let index=0;index<6;index++){
  const branch=index<5?variants.ok:variants;roles.set(branch.name,index);
  if(index===5){member=branch.fields[0].type.element.name;roles.set(member,'member');}
  if(index<5)variants=variants.error;
 }
 const nodeRoles=new Map();
 return codec.reducer((node,index)=>{
  const role=roles.get(node.name);nodeRoles.set(index,role);
  if(node.kind==='record'){
   if(role==='root')return value=>value;
   if(role==='member')return (key,value,context)=>{
    const text=context.add(JSON.stringify(key)+':')+value,seen=context.members;
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);return text;
   };
   if(role===0)return context=>context.add('null');
   if(role===1)return (value,context)=>context.add(value?'true':'false');
   if(role===2)return (token,context)=>{if(!jsonNumberToken(token))throw Error('invalid JSON number');return context.add(token);};
   if(role===3)return (value,context)=>context.add(JSON.stringify(value));
   if(role===4)return (value,context)=>{context.add('[]');return '['+value+']';};
   if(role===5)return (value,context)=>{context.add('{}');return '{'+value+'}';};
   return ()=>null;
  }
  if(node.kind==='list'||node.kind==='vector'){
   const members=nodeRoles.get(node.children[0])==='member';
   return {
    start:(_length,context)=>{
     const out={text:'',parent:members?context.members:null};
     if(members)context.members=new Set();return out;
    },
    step:(out,value,index,context)=>{out.text+=(index?context.add(','):'')+value;return out;},
    finish:(out,context)=>{if(members)context.members=out.parent;return out.text;},
   };
  }
  if(node.kind==='result'){
   // A Result<Json,E> boundary is explicitly requested by the caller. Ordinary
   // JSON's own sums only propagate an already rendered branch.
   if(unwrap&&nodeRoles.get(node.children[0])==='root')return (tag,value)=>{if(tag)throw Error('JSON result is Err');return value;};
   return (_tag,value)=>value;
  }
  if(node.kind==='string')return value=>{if(!value.isWellFormed())throw Error('invalid JSON String');return value;};
  return value=>value;
 });
}
export class JsonCodec{
 constructor(valueCodec){
  const root=valueCodec.descriptor.root,fields=root.fields;if(root.kind!=='record'||!Array.isArray(fields)||fields.length!==1||fields[0].name!=='payload')throw Error('JSON schema payload');let sum=fields[0].type;
  for(let i=0;i<6;i++){
   if(i<5&&sum.kind!=='result')throw Error('JSON schema sum');const branch=i<5?sum.ok:sum,fs=branch.fields;
   if(branch.kind!=='record'||!Array.isArray(fs)||fs.length!==(i?1:0)||i&&fs[0].name!=='item0')throw Error('JSON schema branch');
   if(i){const t=fs[0].type;if(i===1&&t.kind!=='bool'||(i===2||i===3)&&t.kind!=='string'||i===4&&(t.kind!=='list'||t.element.kind!=='ref'||t.element.name!==root.name))throw Error('JSON schema variant');if(i===5){const mf=t.element?.fields;if(t.kind!=='list'||t.element?.kind!=='record'||!Array.isArray(mf)||mf.length!==2||mf[0].name!=='key'||mf[0].type.kind!=='string'||mf[1].name!=='value'||mf[1].type.kind!=='ref'||mf[1].type.name!==root.name)throw Error('JSON schema member');}}
   if(i===2)this.numberBranch=branch.name;if(i===5)this.objectBranch=branch.name;
   if(i<5)sum=sum.error;
  }if(!jsonSameSchema(root,valueCodec.resolve({kind:'ref',name:root.name})))throw Error('JSON recursive schema mismatch');this.values=valueCodec;
 }
 parse(text,options={}){return parseJsonValue(text,options,jsonBoundaryBudget(options));}
 parseCompiled(codec,text,options={}){
  if(codec?.identity!==this.values.descriptor.identity||typeof codec.builder!=='function')throw Error('compiled JSON schema mismatch');
  const builder=codec.builder(options);try{return parseJsonConstructed(text,options,builder);}catch(error){builder.abort();throw error;}
 }
 stringify(value,options={}){return stringifyJsonValue(value,options,jsonBoundaryBudget(options));}
 stringifyCompiled(codec,handle,options={}){
  const limits=checkedJsonLimits(options),unwrap=options.unwrapResult===true;
  let codecs=jsonCompiledRenderers.get(this);if(!codecs)jsonCompiledRenderers.set(this,codecs=new WeakMap());
  let renderers=codecs.get(codec);if(!renderers)codecs.set(codec,renderers=new Map());
  let render=renderers.get(unwrap);if(!render)renderers.set(unwrap,render=compiledJsonRenderer(this,codec,unwrap));
  let bytes=0;const context={add(text){bytes+=jsonUtf8Length(text);if(bytes>limits.bytes)throw Error('JSON byte limit');return text;}};
  const text=render(handle,context,limits);
  return text;
 }
 fromJS(value,options={}){return jsonFromJS(value,options);}
 toJS(value,options={}){return jsonToJS(value,options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,false);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,false,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,true);}
 validateBinary(bytes,options={}){
  const decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});let view;
  this.values.visitSpans(bytes,(type,data,start,end)=>{
   view??=new DataView(data.buffer,data.byteOffset,data.byteLength);
   if(type.name===this.numberBranch){const length=view.getUint32(start,true);if(!jsonNumberSpan(data,start+4,start+4+length))throw Error('invalid JSON number token');}
   if(type.name===this.objectBranch){const listEnd=start+4+view.getUint32(start,true),count=view.getUint32(start+4,true),seen=new Set();let at=start+8;for(let i=0;i<count;i++){const memberEnd=at+4+view.getUint32(at,true),keyStart=at+8,keyEnd=keyStart+view.getUint32(at+4,true),key=decoder.decode(data.subarray(keyStart,keyEnd));if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);at=memberEnd;}if(at!==listEnd)throw Error('invalid JSON object frame');}
  },options,[this.numberBranch,this.objectBranch]);return true;

 }
}
function jsonUnpack(value){let p=value.payload,i=0;while(i<5&&Object.hasOwn(p,'Err')){p=p.Err;i++;}return [i,(i<5?p.Ok:p).item0];}
function jsonInteger(token,limit){
 if(!jsonNumberToken(token))throw Error('invalid JSON number');const negative=token[0]==='-',raw=negative?token.slice(1):token,[mantissa,exp='0']=raw.split(/[eE]/);let digits=mantissa.replace('.','');if(/^0+$/.test(digits))return '0';const exponent=Number(exp),fraction=mantissa.includes('.')?mantissa.length-mantissa.indexOf('.')-1:0,shift=exponent-fraction;
 if(!Number.isSafeInteger(exponent)||!Number.isSafeInteger(shift))throw Error('JSON integer exponent limit');
 if(shift<0){const cut=-shift;if(cut>=digits.length||!/^[0]+$/.test(digits.slice(-cut)))throw Error('JSON number is not an integer');digits=digits.slice(0,-cut);}else{if(digits.length+shift>limit)throw Error('JSON integer magnitude limit');digits+='0'.repeat(shift);}
 digits=digits.replace(/^0+/,'');if(digits.length>limit)throw Error('JSON integer magnitude limit');return (negative?'-':'')+digits;
}
export class TypedJsonCodec{
 constructor(valueCodec){this.values=valueCodec;}
 decode(document,options={}){
  // Validate JSON-specific invariants before interpreting any tagged/record
  // shape, including duplicated names and malformed numeric tokens.
  stringifyJson(document,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const read=(type,value,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type),[kind,item]=jsonUnpack(value);const fail=()=>{throw Error('JSON does not match '+t.kind);};
   switch(t.kind){
    case 'unit':if(kind!==0)fail();return null;
    case 'bool':if(kind!==1)fail();return item;
    case 'u32':case 'u64':case 'i32':case 'int':{if(kind!==2)fail();const text=jsonInteger(item,t.kind==='int'?4096:t.kind==='u64'?20:10);return t.kind==='int'?{Int:text}:t.kind==='u64'?BigInt(text):Number(text);}
    case 'f32':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(4));b.setFloat32(0,n,true);if(!Number.isFinite(b.getFloat32(0,true)))throw Error('JSON f32 overflow');return {F32Bits:b.getUint32(0,true)};}
    case 'string':case 'enum':case 'id':if(kind!==3)fail();return item;
    case 'list':case 'vector':if(kind!==4)fail();return item.map(x=>read(t.element,x,d+1));
    case 'record':{if(kind!==5||item.length!==t.fields.length)throw Error('unknown or missing JSON record field');const fields=new Map(item.map(m=>[m.key,m.value])),out={};for(const f of t.fields){if(!fields.has(f.name))throw Error('missing JSON record field');Object.defineProperty(out,f.name,{value:read(f.type,fields.get(f.name),d+1),writable:true,enumerable:true,configurable:true});}return out;}
    case 'option':case 'result':{if(kind!==5||item.length!==1)fail();const m=item[0];if(t.kind==='option'&&m.key==='None'&&jsonUnpack(m.value)[0]===0)return {None:null};const child=t.kind==='option'&&m.key==='Some'?t.element:t.kind==='result'&&m.key==='Ok'?t.ok:t.kind==='result'&&m.key==='Err'?t.error:null;if(!child)fail();return {[m.key]:read(child,m.value,d+1)};}
    default:fail();
   }
  };
  const out=read(this.values.descriptor.root,document,0);this.values.validateValue(out,options);return out;
 }
 encode(value,options={}){
  this.values.validateValue(value,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const write=(type,v,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type);
   switch(t.kind){
    case 'unit':return jsonVariant(0);
    case 'bool':return jsonVariant(1,v);
    case 'u32':case 'u64':case 'i32':return jsonVariant(2,String(v));
    case 'int':return jsonVariant(2,typeof v==='bigint'?String(v):v.Int);
    case 'f32':{let n;if(typeof v==='number')n=Math.fround(v);else{const b=new DataView(new ArrayBuffer(4));b.setUint32(0,v.F32Bits,true);n=b.getFloat32(0,true);}if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'string':case 'id':case 'enum':return jsonVariant(3,v);
    case 'list':case 'vector':return jsonVariant(4,Array.from(v,x=>write(t.element,x,d+1)));
    case 'record':return jsonVariant(5,t.fields.map(f=>({key:f.name,value:write(f.type,v[f.name],d+1)})));
    case 'option':return jsonVariant(5,[Object.hasOwn(v,'Some')?{key:'Some',value:write(t.element,v.Some,d+1)}:{key:'None',value:jsonVariant(0)}]);
    case 'result':return jsonVariant(5,[Object.hasOwn(v,'Ok')?{key:'Ok',value:write(t.ok,v.Ok,d+1)}:{key:'Err',value:write(t.error,v.Err,d+1)}]);
    default:throw Error('unsupported typed JSON descriptor');
   }
  };return write(this.values.descriptor.root,value,0);
 }
 parse(text,options={}){return this.decode(parseJson(text,options),options);}
 stringify(value,options={}){return stringifyJson(this.encode(value,options),options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,true);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,true,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,false);}
}

// Token reader shared by schema-directed and arbitrary-JSON wire emission.
class JsonWireReader{
 constructor(text,options){this.l=checkedJsonLimits(options);if(typeof text!=='string'||!text.isWellFormed()||text.length>this.l.bytes||jsonUtf8Length(text)>this.l.bytes)throw Error('JSON byte or Unicode limit');this.text=text;this.at=0;this.remaining=this.l.nodes;}
 ws(){while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(c!==32&&c!==9&&c!==10&&c!==13)break;this.at++;}}
 peek(){this.ws();return this.text[this.at];}
 eat(c){this.ws();if(this.text[this.at]===c){this.at++;return true;}return false;}
 node(d){if(d>this.l.depth||--this.remaining<0)throw Error('JSON node or depth limit');}
 string(){
  this.ws();const start=this.at;if(this.text[start]!=='"')throw Error('expected JSON string');
  const end=this.text.indexOf('"',start+1);if(end<0)throw Error('unterminated JSON string');
  const raw=this.text.slice(start+1,end);
  if(!raw.includes('\\')&&!/[\x00-\x1f]/.test(raw)){this.at=end+1;return raw;}
  this.at=start+1;while(this.at<this.text.length){if(this.text[this.at]==='"'){this.at++;const v=JSON.parse(this.text.slice(start,this.at));if(!v.isWellFormed())throw Error('invalid JSON Unicode');return v;}if(this.text[this.at]==='\\')this.at+=2;else this.at++;}throw Error('unterminated JSON string');
 }
 number(){const start=this.at;while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(!(c>=48&&c<=57||c===45||c===43||c===46||c===101||c===69))break;this.at++;}const token=this.text.slice(start,this.at);if(!jsonNumberToken(token))throw Error('invalid JSON number');return token;}
 leaf(d){this.node(d);const c=this.peek();if(c==='n'&&this.text.startsWith('null',this.at)){this.at+=4;return null;}if(c==='t'&&this.text.startsWith('true',this.at)){this.at+=4;return true;}if(c==='f'&&this.text.startsWith('false',this.at)){this.at+=5;return false;}if(c==='"')return this.string();if(c==='-'||c>='0'&&c<='9')return this.number();throw Error('invalid JSON scalar');}
 finish(){this.ws();if(this.at!==this.text.length)throw Error('trailing JSON text');}
}
function streamJsonBinary(values,text,options,typed,compact=false){
 const p=new JsonWireReader(text,options),utf8=jsonWireEncoder;
 const list=(w,open,close,item)=>{if(!p.eat(open))throw Error('JSON container shape');const at=w.beginCount();let count=0;if(!p.eat(close))while(true){item(w);count++;if(p.eat(close))break;if(!p.eat(','))throw Error('JSON container separator');}w.endCount(at,count);};
 const variant=(w,index,level,emit)=>{if(level<index)w.frame(w=>{w.byte(1);variant(w,index,level+1,emit);});else if(index<5)w.frame(w=>{w.byte(0);w.frame(emit);});else w.frame(emit);};
 const json=(w,d)=>{
  const ch=p.peek(),index=ch==='n'?0:ch==='t'||ch==='f'?1:ch==='-'||ch>='0'&&ch<='9'?2:ch==='"'?3:ch==='['?4:ch==='{'?5:-1;if(index<0)throw Error('invalid JSON value');
  const leaf=index<4?p.leaf(d):null;if(index>=4)p.node(d);
  w.frame(w=>variant(w,index,0,w=>{
   if(index===0)return;if(index===1){w.frame(w=>w.byte(+leaf));return;}
   if(index===2||index===3){w.frame(w=>w.text(leaf));return;}
   w.frame(w=>{if(index===4)list(w,'[',']',w=>json(w,d+1));else{const seen=new Set();list(w,'{','}',w=>{const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');w.frame(w=>{w.frame(w=>w.text(key));json(w,d+1);});});}});
  }));
 };
 const read=(type,w,d)=>{
  const t=values.resolve(type);w.frame(w=>{
   if(t.kind==='list'||t.kind==='vector'){p.node(d);list(w,'[',']',w=>read(t.element,w,d+1));return;}
   if(t.kind==='record'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON record');const start=w.position,spans=new Array(t.fields.length).fill(null);
    if(!p.eat('}'))while(true){const key=p.string(),i=t.fields.findIndex(f=>f.name===key);if(i<0)throw Error('unknown JSON record field');if(spans[i])throw Error('duplicate JSON record field');if(!p.eat(':'))throw Error('JSON record colon');const at=w.position;read(t.fields[i].type,w,d+1);spans[i]=[at,w.position];if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON record separator');}
    if(spans.some(s=>s===null))throw Error('missing JSON record field');w.reorder(start,spans);return;
   }
   if(t.kind==='option'||t.kind==='result'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON tagged value');const key=p.string();if(!p.eat(':'))throw Error('JSON tag colon');
    if(t.kind==='option'&&key==='None'){if(p.leaf(d+1)!==null)throw Error('JSON None payload');w.byte(0);}
    else{const child=t.kind==='option'&&key==='Some'?t.element:t.kind==='result'&&key==='Ok'?t.ok:t.kind==='result'&&key==='Err'?t.error:null;if(!child)throw Error('invalid JSON tag');w.byte(key==='Ok'?0:1);read(child,w,d+1);}
    if(!p.eat('}'))throw Error('expected exactly one JSON tag');return;
   }
   const ch=p.peek(),v=p.leaf(d),bad=()=>{throw Error('JSON does not match '+t.kind);};
   if(t.kind==='unit'){if(v!==null)bad();return;}
   if(t.kind==='bool'){if(typeof v!=='boolean')bad();w.byte(+v);return;}
   if(['string','id','enum'].includes(t.kind)){if(ch!=='"')bad();w.text(v);return;}
   if(ch!=='-'&&!(ch>='0'&&ch<='9'))bad();
   if(t.kind==='int'){w.text(jsonInteger(v,4096));return;}
   if(t.kind==='f32'){jsonFloatScratch.setFloat32(0,Number(v),true);if(!Number.isFinite(jsonFloatScratch.getFloat32(0,true)))throw Error('JSON f32 overflow');w.word(jsonFloatScratch.getUint32(0,true));}
   else{const n=BigInt(jsonInteger(v,t.kind==='u64'?20:10));if(t.kind==='u64'){if(n<0n||n>18446744073709551615n)bad();w.wide(n);}else if(t.kind==='u32'){if(n<0n||n>4294967295n)bad();w.word(Number(n));}else if(t.kind==='i32'){if(n< -2147483648n||n>2147483647n)bad();w.word(Number(n)>>>0);}else bad();}
  });
 };
 return (compact?values.compact():values).encodeWith(w=>{if(typed)read(values.descriptor.root,w,0);else json(w,0);p.finish();},options);
}

// Render validated bytes in a single traversal; only the final text is owned.
function streamWireJsonText(values,bytes,options,library){
 values.validate(bytes,options);const l=checkedJsonLimits(options),parts=[];let size=0,remaining=l.nodes;const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 const emit=s=>{size+=jsonUtf8Length(s);if(size>l.bytes)throw Error('JSON byte limit');parts.push(s);};
 const string=s=>emit(JSON.stringify(s));const node=d=>{if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');};
 const frame=(type,at)=>{const t=values.resolve(type),start=at+4,end=start+dv.getUint32(at,true);return{t,start,end};};
 const json=(type,at,d)=>{
  node(d);let root=frame(type,at),sum=frame(root.t.fields[0].type,root.start),index=0;
  while(index<5){const err=bytes[sum.start];sum=frame(err?sum.t.error:sum.t.ok,sum.start+1);if(!err)break;index++;}
  if(index===0){emit('null');return root.end;}
  const item=frame(sum.t.fields[0].type,sum.start);
  if(index===1)emit(bytes[item.start]?'true':'false');
  else if(index===2){const token=decoder.decode(bytes.subarray(item.start,item.end));if(!jsonNumberToken(token))throw Error('invalid JSON number token');emit(token);}
  else if(index===3)string(decoder.decode(bytes.subarray(item.start,item.end)));
  else{const count=dv.getUint32(item.start,true);let p=item.start+4;emit(index===4?'[':'{');const seen=new Set();for(let i=0;i<count;i++){if(i)emit(',');if(index===4)p=json(item.t.element,p,d+1);else{const member=frame(item.t.element,p),key=frame(member.t.fields[0].type,member.start),name=decoder.decode(bytes.subarray(key.start,key.end));if(seen.has(name))throw Error('duplicate JSON object key');seen.add(name);string(name);emit(':');json(member.t.fields[1].type,key.end,d+1);p=member.end;}}emit(index===4?']':'}');}
  return root.end;
 };
 const typed=(type,at,d)=>{
  node(d);const f=frame(type,at),t=f.t;let p=f.start;
  switch(t.kind){
   case 'unit':emit('null');break;
   case 'bool':emit(bytes[p]?'true':'false');break;
   case 'u32':emit(String(dv.getUint32(p,true)));break;
   case 'u64':emit(String(dv.getBigUint64(p,true)));break;
   case 'i32':emit(String(dv.getInt32(p,true)));break;
   case 'f32':{const n=dv.getFloat32(p,true);if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'int':emit(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'string':case 'id':case 'enum':string(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'list':case 'vector':{const n=dv.getUint32(p,true);p+=4;emit('[');for(let i=0;i<n;i++){if(i)emit(',');p=typed(t.element,p,d+1);}emit(']');break;}
   case 'record':emit('{');for(let i=0;i<t.fields.length;i++){if(i)emit(',');const field=t.fields[i];string(field.name);emit(':');p=typed(field.type,p,d+1);}emit('}');break;
   case 'option':case 'result':{const tag=bytes[p++],key=t.kind==='option'?(tag?'Some':'None'):tag?'Err':'Ok';emit('{');string(key);emit(':');if(t.kind==='option'&&!tag){node(d+1);emit('null');}else typed(t.kind==='option'?t.element:tag?t.error:t.ok,p,d+1);emit('}');break;}
   default:throw Error('unsupported typed JSON descriptor');
  }return f.end;
 };
 if(library)json(values.descriptor.root,40,0);else typed(values.descriptor.root,40,0);return parts.join('');
}

/** Owned, optional read view of arbitrary JSON. Auxiliary indexes contain member
 * offsets only. Logical order, exact number tokens and missing/null remain intact.
 * This does not transparently replace any compiled Ink action or its state.
 */
export function createJsonLookup(text,{stepEntries=16,minReads=4,maxEntries=4096,maxObjects=64,maxIndexBytes=262144,...limits}={}){
 for(const [v,max]of [[stepEntries,4096],[minReads,1000000],[maxEntries,1000000],[maxObjects,256],[maxIndexBytes,16777216]])if(!Number.isSafeInteger(v)||v<0||v>max)throw Error('JSON index budget');
 let root=parseJson(text,limits),indexes=new Map(),entries=0,indexBytes=0;
 const stats={reads:0,writes:0,scanned_members:0,index_hits:0,built_entries:0,invalidations:0};
 function parts(path){
  if(!Array.isArray(path))throw Error('JSON lookup path');const n=path.length;if(n>128)throw Error('JSON lookup path');
  const owned=[];for(let i=0;i<n;i++){const d=Object.getOwnPropertyDescriptor(path,String(i));if(!d||!Object.hasOwn(d,'value'))throw Error('JSON lookup path');const p=d.value;if(!(typeof p==='string'&&p.isWellFormed()&&p.length<=4096)&&!(Number.isSafeInteger(p)&&p>=0))throw Error('JSON lookup path');owned.push(p);}return owned;
 }
 function variant(value){let p=value.payload,index=0;while(index<5&&Object.hasOwn(p,'Err')){p=p.Err;index++;}return {index,item:(index<5?p.Ok:p).item0};}
 function resolve(document,path,indexed){
  let value=document,budget=stepEntries;
  for(let depth=0;depth<path.length;depth++){
   const part=path[depth],v=variant(value);
   if(typeof part==='number'){
    if(v.index!==4)throw Error('expected JSON array');if(part>=v.item.length)return {found:false};value=v.item[part];continue;
   }
   if(v.index!==5)throw Error('expected JSON object');
   const prefix=path.slice(0,depth),key=JSON.stringify(prefix),overhead=128+prefix.reduce((n,p)=>n+(typeof p==='string'?16+p.length*2:8),0);let idx=indexed?indexes.get(key):null;
   if(indexed&&!idx&&indexes.size<maxObjects&&indexBytes+overhead<=maxIndexBytes){idx={path:prefix,reads:0,cursor:0,keys:new Map(),bytes:overhead};indexes.set(key,idx);indexBytes+=overhead;}
   if(idx){
    idx.reads++;
    if(idx.reads>=minReads)while(budget>0&&idx.cursor<v.item.length&&entries<maxEntries){
     const member=v.item[idx.cursor],bytes=64+member.key.length*2;
     if(indexBytes+bytes>maxIndexBytes)break;
     idx.keys.set(member.key,idx.cursor++);idx.bytes+=bytes;indexBytes+=bytes;entries++;stats.built_entries++;budget--;
    }
    if(idx.keys.has(part)){stats.index_hits++;value=v.item[idx.keys.get(part)].value;continue;}
   }
   let found=false;
   for(let i=idx?.cursor??0;i<v.item.length;i++){if(indexed)stats.scanned_members++;if(v.item[i].key===part){value=v.item[i].value;found=true;break;}}
   if(!found)return {found:false};
  }
  return {found:true,value};
 }
 return {
  lookup(path){stats.reads++;const r=resolve(root,parts(path),true);return r.found?{found:true,value:structuredClone(r.value)}:r;},
  set(path,key,text){
   path=parts(path);if(typeof key!=='string'||!key.isWellFormed())throw Error('JSON object key');
   const replacement=parseJson(text,limits),next=structuredClone(root),r=resolve(next,path,false);
   if(!r.found)throw Error('JSON update path missing');const object=variant(r.value);if(object.index!==5)throw Error('expected JSON object');
   const members=[{key,value:replacement},...object.item.filter(m=>m.key!==key)];
   // Validate the complete resulting document before publishing a write.
   let payload=r.value.payload;for(let i=0;i<5;i++)payload=payload.Err;payload.item0=members;
   stringifyJson(next,limits);root=next;stats.writes++;
   for(const [id,idx]of indexes)if(idx.path.length>=path.length&&path.every((p,i)=>p===idx.path[i])){entries-=idx.keys.size;indexBytes-=idx.bytes;indexes.delete(id);stats.invalidations++;}
  },
  replace(text){const next=parseJson(text,limits);root=next;stats.writes++;stats.invalidations+=indexes.size;indexes.clear();entries=0;indexBytes=0;},
  stringify(){return stringifyJson(root,limits);},
  stats(){return {...stats,index_entries:entries,index_objects:indexes.size,index_bytes:indexBytes};}
 };
}
function __ownedValue19(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue20(value[i],budget,depth+1);return out;}
function __ownedValue13(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue14(value[i],budget,depth+1);return out;}
function __ownedValue27(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue1(value[i],budget,depth+1);return out;}
function __ownedValue16(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__ownedValue1(value.Some,budget,depth+1)};}
function __ownedValue24(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue25(value[i],budget,depth+1);return out;}
function __ownedValue10(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue11(value[i],budget,depth+1);return out;}
function __ownedValue2(value,budget,depth){budget.enter(depth,5);switch(value.tag){case 0:{return {Ok:__ownedValue3(value.payload,budget,depth+1)};}case 1:{budget.enter(depth+1,5);return {Err:{Ok:__ownedValue4(value.payload,budget,depth+2)}};}case 2:{budget.enter(depth+1,5);budget.enter(depth+2,5);return {Err:{Err:{Ok:__ownedValue6(value.payload,budget,depth+3)}}};}case 3:{budget.enter(depth+1,5);budget.enter(depth+2,5);budget.enter(depth+3,5);return {Err:{Err:{Err:{Ok:__ownedValue8(value.payload,budget,depth+4)}}}};}case 4:{budget.enter(depth+1,5);budget.enter(depth+2,5);budget.enter(depth+3,5);budget.enter(depth+4,5);return {Err:{Err:{Err:{Err:{Ok:__ownedValue9(value.payload,budget,depth+5)}}}}};}case 5:{budget.enter(depth+1,5);budget.enter(depth+2,5);budget.enter(depth+3,5);budget.enter(depth+4,5);return {Err:{Err:{Err:{Err:{Err:__ownedValue12(value.payload,budget,depth+5)}}}}};}default:throw Error('private sum tag');}}
function __ownedValue22(value,budget,depth){budget.enter(depth,5);switch(value.tag){case 0:{return {Ok:__ownedValue3(value.payload,budget,depth+1)};}case 1:{budget.enter(depth+1,5);return {Err:{Ok:__ownedValue4(value.payload,budget,depth+2)}};}case 2:{budget.enter(depth+1,5);budget.enter(depth+2,5);return {Err:{Err:{Ok:__ownedValue6(value.payload,budget,depth+3)}}};}case 3:{budget.enter(depth+1,5);budget.enter(depth+2,5);budget.enter(depth+3,5);return {Err:{Err:{Err:{Ok:__ownedValue8(value.payload,budget,depth+4)}}}};}case 4:{budget.enter(depth+1,5);budget.enter(depth+2,5);budget.enter(depth+3,5);budget.enter(depth+4,5);return {Err:{Err:{Err:{Err:{Ok:__ownedValue9(value.payload,budget,depth+5)}}}}};}case 5:{budget.enter(depth+1,5);budget.enter(depth+2,5);budget.enter(depth+3,5);budget.enter(depth+4,5);return {Err:{Err:{Err:{Err:{Err:__ownedValue23(value.payload,budget,depth+5)}}}}};}default:throw Error('private sum tag');}}
function __ownedValue18(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue19(value.Ok,budget,depth+1)}:{Err:__ownedValue15(value.Err,budget,depth+1)};}
function __ownedValue26(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue27(value.Ok,budget,depth+1)}:{Err:__ownedValue15(value.Err,budget,depth+1)};}
function __ownedValue17(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue16(value.Ok,budget,depth+1)}:{Err:__ownedValue15(value.Err,budget,depth+1)};}
function __ownedValue0(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue1(value.Ok,budget,depth+1)}:{Err:__ownedValue15(value.Err,budget,depth+1)};}
function __ownedValue29(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue5(value.Ok,budget,depth+1)}:{Err:__ownedValue15(value.Err,budget,depth+1)};}
function __ownedValue28(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue7(value.Ok,budget,depth+1)}:{Err:__ownedValue15(value.Err,budget,depth+1)};}
function __ownedValue3(value,budget,depth){budget.enter(depth,4);return {};}
function __ownedValue12(value,budget,depth){budget.enter(depth,4);return {["item0"]:__ownedValue13(value,budget,depth+1)};}
function __ownedValue23(value,budget,depth){budget.enter(depth,4);return {["item0"]:__ownedValue24(value,budget,depth+1)};}
function __ownedValue9(value,budget,depth){budget.enter(depth,4);return {["item0"]:__ownedValue10(value,budget,depth+1)};}
function __ownedValue4(value,budget,depth){budget.enter(depth,4);return {["item0"]:__ownedValue5(value,budget,depth+1)};}
function __ownedValue8(value,budget,depth){budget.enter(depth,4);return {["item0"]:__ownedValue7(value,budget,depth+1)};}
function __ownedValue6(value,budget,depth){budget.enter(depth,4);return {["item0"]:__ownedValue7(value,budget,depth+1)};}
function __ownedValue20(value,budget,depth){budget.enter(depth,4);return {["key"]:__ownedValue7(value["key"],budget,depth+1),["value"]:__ownedValue21(value["value"],budget,depth+1)};}
function __ownedValue14(value,budget,depth){budget.enter(depth,4);return {["key"]:__ownedValue7(value["key"],budget,depth+1),["value"]:__ownedValue11(value["value"],budget,depth+1)};}
function __ownedValue1(value,budget,depth){budget.enter(depth,4);return {["payload"]:__ownedValue2(value,budget,depth+1)};}
function __ownedValue21(value,budget,depth){budget.enter(depth,4);return {["payload"]:__ownedValue22(value,budget,depth+1)};}
function __ownedValue5(value,budget,depth){budget.enter(depth,5);return value;}
function __ownedValue15(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __ownedValue25(value,budget,depth){return __ownedValue20(value,budget,depth);}
function __ownedValue11(value,budget,depth){return __ownedValue1(value,budget,depth);}
function __ownedValue7(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
const __ownedFunctions=Object.freeze(Object.fromEntries([["set_document",__ownedValue0],["identity",__ownedValue1],["ink_m5c5479101d38cd5d28f66110c880ad28b6ee3ee64fddb98300dda927c645c107",__ownedValue1],["ink_mbf312e22e5ab893385ef1935f8250f16e090d4da8dd41bc1577df1ba636fdc13",__ownedValue1],["ink_mee36d9721e4db57ba82a41d18344d03b18dc98a5d22319238b436d9aa6c8a6c1",__ownedValue1],["ink_mca67a4ea249e8eba3cf6e453e86dd061695d9d9afaf7edcf587f8cd1cbc055c9",__ownedValue1],["ink_me5c9745ee2d98ddc2c32843ec24ea225963aff43ce357055dd9a61b18d1d4982",__ownedValue1],["ink_mb0e8aa1d34f7cc5fc940000b63bdc043068202b64206a7da02cade0c4e386a22",__ownedValue1],["ink_m2383a37c8f0f060d8454d784560b1928c68c5b404b4b5fd5bfff2e7fa4fddcbe",__ownedValue16],["ink_m5d18bbf4cd5236cf3a3bce3bc0ef39b2ca5d48cc74c98fd149a78715c7abf0fc",__ownedValue17],["ink_md87d2855f042e634a3f3b8c068533029f73d510386d43bf00bc9d0bcd07e5c8c",__ownedValue18],["ink_m20157316281aa2312519e1609fa4690b136f16e4ef71773eb2a47a1fa3a406de",__ownedValue26],["ink_me72555cbb304777e5aa4f9e3c006554a0e08baef4b0d7d5315bbdb8d73619005",__ownedValue28],["ink_m0799e9661dd281b944df2c23f24248caf4bf5ffd20f6d9a7e2fe778ce1a073d2",__ownedValue28],["ink_m992ba36e5bbedf39b7f14a42b10f872b6c0c9a2ea93b89b3fc52f4d549687c80",__ownedValue29],["ink_md6609e67dc544a99f2a87bd888df500ffda6c2a250ac3bb96e169677f36aa0ca",__ownedValue19],["ink_mad008ef4986d9f0222e8592e1b0d53b594ed67eab0548e67ceabe4308ff8638b",__ownedValue0],["ink_m6daa56a5bc5a861d85247ffa7c539a517219bed2c2c205e9798247b46093c271",__ownedValue0],["ink_m55d79925938089d1d4f5680a132089bb2dbc200f324c50670835f2f3730f3837",__ownedValue0]]));
function __wireValue24(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue25(reader);reader.finish(end);return value;}
function __wireValue16(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue17(reader);reader.finish(end);return value;}
function __wireValue22(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue1(reader);reader.finish(end);return value;}
function __wireValue34(reader){const end=reader.frame();const value=reader.byte()?{Some:__wireValue1(reader)}:{None:null};reader.finish(end);return value;}
function __wireValue33(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue25(reader);reader.finish(end);return value;}
function __wireValue14(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue1(reader);reader.finish(end);return value;}
function __wireValue36(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue9(reader);reader.finish(end);return value;}
function __wireValue2(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue4(reader)}:{Ok:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue27(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue28(reader)}:{Ok:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue4(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue7(reader)}:{Ok:__wireValue5(reader)};reader.finish(end);return value;}
function __wireValue28(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue29(reader)}:{Ok:__wireValue5(reader)};reader.finish(end);return value;}
function __wireValue7(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue10(reader)}:{Ok:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue29(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue30(reader)}:{Ok:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue10(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue12(reader)}:{Ok:__wireValue11(reader)};reader.finish(end);return value;}
function __wireValue30(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue31(reader)}:{Ok:__wireValue11(reader)};reader.finish(end);return value;}
function __wireValue12(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue15(reader)}:{Ok:__wireValue13(reader)};reader.finish(end);return value;}
function __wireValue31(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue32(reader)}:{Ok:__wireValue13(reader)};reader.finish(end);return value;}
function __wireValue47(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue20(reader)}:{Ok:__wireValue24(reader)};reader.finish(end);return value;}
function __wireValue21(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue20(reader)}:{Ok:__wireValue22(reader)};reader.finish(end);return value;}
function __wireValue40(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue20(reader)}:{Ok:__wireValue34(reader)};reader.finish(end);return value;}
function __wireValue37(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue20(reader)}:{Ok:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue41(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue20(reader)}:{Ok:__wireValue6(reader)};reader.finish(end);return value;}
function __wireValue19(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue20(reader)}:{Ok:__wireValue9(reader)};reader.finish(end);return value;}
function __wireValue3(reader){const end=reader.frame();const value={};reader.finish(end);return value;}
function __wireValue38(reader){const end=reader.frame();const value={};reader.finish(end);return value;}
function __wireValue50(reader){const end=reader.frame();const value={["document"]:__wireValue1(reader),["key"]:__wireValue9(reader),["value"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue0(reader){const end=reader.frame();const value={["document"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue15(reader){const end=reader.frame();const value={["item0"]:__wireValue16(reader)};reader.finish(end);return value;}
function __wireValue32(reader){const end=reader.frame();const value={["item0"]:__wireValue33(reader)};reader.finish(end);return value;}
function __wireValue13(reader){const end=reader.frame();const value={["item0"]:__wireValue14(reader)};reader.finish(end);return value;}
function __wireValue5(reader){const end=reader.frame();const value={["item0"]:__wireValue6(reader)};reader.finish(end);return value;}
function __wireValue11(reader){const end=reader.frame();const value={["item0"]:__wireValue9(reader)};reader.finish(end);return value;}
function __wireValue8(reader){const end=reader.frame();const value={["item0"]:__wireValue9(reader)};reader.finish(end);return value;}
function __wireValue25(reader){const end=reader.frame();const value={["key"]:__wireValue9(reader),["value"]:__wireValue26(reader)};reader.finish(end);return value;}
function __wireValue17(reader){const end=reader.frame();const value={["key"]:__wireValue9(reader),["value"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue46(reader){const end=reader.frame();const value={["members"]:__wireValue24(reader),["key"]:__wireValue9(reader),["value"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue23(reader){const end=reader.frame();const value={["members"]:__wireValue24(reader),["key"]:__wireValue9(reader)};reader.finish(end);return value;}
function __wireValue43(reader){const end=reader.frame();const value={["members"]:__wireValue24(reader)};reader.finish(end);return value;}
function __wireValue1(reader){const end=reader.frame();const value={["payload"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue26(reader){const end=reader.frame();const value={["payload"]:__wireValue27(reader)};reader.finish(end);return value;}
function __wireValue49(reader){const end=reader.frame();const value={["token"]:__wireValue9(reader)};reader.finish(end);return value;}
function __wireValue42(reader){const end=reader.frame();const value={["value"]:__wireValue1(reader),["key"]:__wireValue9(reader),["replacement"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue39(reader){const end=reader.frame();const value={["value"]:__wireValue1(reader),["key"]:__wireValue9(reader)};reader.finish(end);return value;}
function __wireValue35(reader){const end=reader.frame();const value={["value"]:__wireValue1(reader),["keys"]:__wireValue36(reader)};reader.finish(end);return value;}
function __wireValue18(reader){const end=reader.frame();const value={["value"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue44(reader){const end=reader.frame();const value={["value"]:__wireValue6(reader)};reader.finish(end);return value;}
function __wireValue45(reader){const end=reader.frame();const value={["value"]:__wireValue9(reader)};reader.finish(end);return value;}
function __wireValue48(reader){const end=reader.frame();const value={["values"]:__wireValue22(reader)};reader.finish(end);return value;}
function __wireValue6(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
const __wireValue20Variants=Object.freeze(["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]);
function __wireValue20(reader){const end=reader.frame();const value=reader.text(end,"enum",__wireValue20Variants);reader.finish(end);return value;}
function __wireValue9(reader){const end=reader.frame();const value=reader.text(end,"string");reader.finish(end);return value;}
const __wireReaders=Object.freeze(Object.fromEntries([["identity",[__wireValue0,__wireValue1]],["ink_m0799e9661dd281b944df2c23f24248caf4bf5ffd20f6d9a7e2fe778ce1a073d2",[__wireValue18,__wireValue19]],["ink_m20157316281aa2312519e1609fa4690b136f16e4ef71773eb2a47a1fa3a406de",[__wireValue18,__wireValue21]],["ink_m2383a37c8f0f060d8454d784560b1928c68c5b404b4b5fd5bfff2e7fa4fddcbe",[__wireValue23,__wireValue34]],["ink_m55d79925938089d1d4f5680a132089bb2dbc200f324c50670835f2f3730f3837",[__wireValue35,__wireValue37]],["ink_m5c5479101d38cd5d28f66110c880ad28b6ee3ee64fddb98300dda927c645c107",[__wireValue38,__wireValue1]],["ink_m5d18bbf4cd5236cf3a3bce3bc0ef39b2ca5d48cc74c98fd149a78715c7abf0fc",[__wireValue39,__wireValue40]],["ink_m6daa56a5bc5a861d85247ffa7c539a517219bed2c2c205e9798247b46093c271",[__wireValue39,__wireValue37]],["ink_m992ba36e5bbedf39b7f14a42b10f872b6c0c9a2ea93b89b3fc52f4d549687c80",[__wireValue18,__wireValue41]],["ink_mad008ef4986d9f0222e8592e1b0d53b594ed67eab0548e67ceabe4308ff8638b",[__wireValue42,__wireValue37]],["ink_mb0e8aa1d34f7cc5fc940000b63bdc043068202b64206a7da02cade0c4e386a22",[__wireValue43,__wireValue1]],["ink_mbf312e22e5ab893385ef1935f8250f16e090d4da8dd41bc1577df1ba636fdc13",[__wireValue44,__wireValue1]],["ink_mca67a4ea249e8eba3cf6e453e86dd061695d9d9afaf7edcf587f8cd1cbc055c9",[__wireValue45,__wireValue1]],["ink_md6609e67dc544a99f2a87bd888df500ffda6c2a250ac3bb96e169677f36aa0ca",[__wireValue46,__wireValue24]],["ink_md87d2855f042e634a3f3b8c068533029f73d510386d43bf00bc9d0bcd07e5c8c",[__wireValue18,__wireValue47]],["ink_me5c9745ee2d98ddc2c32843ec24ea225963aff43ce357055dd9a61b18d1d4982",[__wireValue48,__wireValue1]],["ink_me72555cbb304777e5aa4f9e3c006554a0e08baef4b0d7d5315bbdb8d73619005",[__wireValue18,__wireValue19]],["ink_mee36d9721e4db57ba82a41d18344d03b18dc98a5d22319238b436d9aa6c8a6c1",[__wireValue49,__wireValue1]],["set_document",[__wireValue50,__wireValue37]]]));

const __ownedImplementations=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>{
 const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
 const body=__implementations[f.index];
 const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
 return [f.name,input.every(c=>c===__identity)?implementation:(...args)=>{const context=new WeakMap();return implementation(...args.map((v,i)=>input[i](v,context)));}];
})));

export const valueCodecs=(()=>{const codecs={};for(const [name,s] of Object.entries(metadata.wire.functions)){if(s.unsupported)continue;let value;Object.defineProperty(codecs,name,{enumerable:true,get:()=>value??=(Object.freeze(Object.hasOwn(__wireReaders,name)?{arguments:createCompiledValueCodec(s.arguments,__wireReaders[name][0]),result:createCompiledValueCodec(s.result,__wireReaders[name][1])}:{arguments:new ValueCodec(s.arguments),result:new ValueCodec(s.result)}))});}return Object.freeze(codecs);})();
function __callEncoded(name,bytes,limits,compact){
 const f=metadata.functions.find(f=>f.name===name&&!f.internal),codecs=valueCodecs[name];
 if(!f||!codecs)throw Error('unsupported binary function');
 const input=compact?codecs.arguments.compact():codecs.arguments,output=compact?codecs.result.compact():codecs.result;
 const entry=__compiledEntries.get(name);
 if(entry){
  const slot=compact?1:0;
  entry.argumentCodecs[slot]??=(entry.boundaryReaders[slot]?createFusedValueCodec:createCompiledValueCodec)(metadata.wire.functions[name].arguments,entry.arguments);
  const decoder=entry.argumentCodecs[slot];
  const values=(compact?decoder.compact():decoder).decode(bytes,limits),args=f.params.map(p=>values[p.name]);
  if(entry.precondition!==null&&__implementations[entry.precondition](...args)!==true)throw Error('contract precondition failed');
  return __compiledEncodeResult(entry,__implementations[entry.index](...args),limits,compact);
 }
 const values=input.decode(bytes,limits);
 const result=call(name,f.params.map(p=>values[p.name]));
 return output.encode(result,limits);
}
export function callBinary(name,bytes,limits={}){return __callEncoded(name,bytes,limits,false);}
export function callCompact(name,bytes,limits={}){return __callEncoded(name,bytes,limits,true);}
// Same stable, well-typed caller inputs as call; the result owns every container.
// The checked source return type justifies trusted copying, not arbitrary input.
export function callOwned(name,args,limits={}){
 if(!Object.hasOwn(__ownedFunctions,name)||!Object.hasOwn(functions,name))throw Error('unsupported owned function');
 const result=__ownedImplementations[name](...args);return __ownedFunctions[name](result,createValueCaptureBudget(limits),0);
}
function __privateCapture16(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture17(value[i],budget,depth+1);return out;}
function __privateCapture11(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture12(value[i],budget,depth+1);return out;}
function __privateCapture15(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture0(value[i],budget,depth+1);return out;}
function __privateCapture22(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if((value!==null&&typeof value==='object'&&Object.hasOwn(value,'None')&&Object.keys(value).length===1)&&value.None===null)return {None:null};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Some')&&Object.keys(value).length===1)return {Some:__privateCapture0(value.Some,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture21(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture17(value[i],budget,depth+1);return out;}
function __privateCapture9(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture0(value[i],budget,depth+1);return out;}
function __privateCapture28(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture6(value[i],budget,depth+1);return out;}
function __privateCapture1(value,budget,depth=0){budget.enter(depth,4);let cursor=value;budget.add(1);if(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Ok')&&Object.keys(cursor).length===1)return {tag:0,payload:__privateCapture2(cursor.Ok,budget,depth+1)};if(!(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Err')&&Object.keys(cursor).length===1)){throw Error('invalid value for wire schema');}cursor=cursor.Err;budget.enter(depth+1,4);budget.add(1);if(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Ok')&&Object.keys(cursor).length===1)return {tag:1,payload:__privateCapture3(cursor.Ok,budget,depth+2)};if(!(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Err')&&Object.keys(cursor).length===1)){throw Error('invalid value for wire schema');}cursor=cursor.Err;budget.enter(depth+2,4);budget.add(1);if(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Ok')&&Object.keys(cursor).length===1)return {tag:2,payload:__privateCapture5(cursor.Ok,budget,depth+3)};if(!(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Err')&&Object.keys(cursor).length===1)){throw Error('invalid value for wire schema');}cursor=cursor.Err;budget.enter(depth+3,4);budget.add(1);if(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Ok')&&Object.keys(cursor).length===1)return {tag:3,payload:__privateCapture7(cursor.Ok,budget,depth+4)};if(!(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Err')&&Object.keys(cursor).length===1)){throw Error('invalid value for wire schema');}cursor=cursor.Err;budget.enter(depth+4,4);budget.add(1);if(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Ok')&&Object.keys(cursor).length===1)return {tag:4,payload:__privateCapture8(cursor.Ok,budget,depth+5)};if(!(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Err')&&Object.keys(cursor).length===1)){throw Error('invalid value for wire schema');}return {tag:5,payload:__privateCapture10(cursor.Err,budget,depth+5)};}
function __privateCapture19(value,budget,depth=0){budget.enter(depth,4);let cursor=value;budget.add(1);if(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Ok')&&Object.keys(cursor).length===1)return {tag:0,payload:__privateCapture2(cursor.Ok,budget,depth+1)};if(!(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Err')&&Object.keys(cursor).length===1)){throw Error('invalid value for wire schema');}cursor=cursor.Err;budget.enter(depth+1,4);budget.add(1);if(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Ok')&&Object.keys(cursor).length===1)return {tag:1,payload:__privateCapture3(cursor.Ok,budget,depth+2)};if(!(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Err')&&Object.keys(cursor).length===1)){throw Error('invalid value for wire schema');}cursor=cursor.Err;budget.enter(depth+2,4);budget.add(1);if(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Ok')&&Object.keys(cursor).length===1)return {tag:2,payload:__privateCapture5(cursor.Ok,budget,depth+3)};if(!(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Err')&&Object.keys(cursor).length===1)){throw Error('invalid value for wire schema');}cursor=cursor.Err;budget.enter(depth+3,4);budget.add(1);if(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Ok')&&Object.keys(cursor).length===1)return {tag:3,payload:__privateCapture7(cursor.Ok,budget,depth+4)};if(!(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Err')&&Object.keys(cursor).length===1)){throw Error('invalid value for wire schema');}cursor=cursor.Err;budget.enter(depth+4,4);budget.add(1);if(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Ok')&&Object.keys(cursor).length===1)return {tag:4,payload:__privateCapture8(cursor.Ok,budget,depth+5)};if(!(cursor!==null&&typeof cursor==='object'&&Object.hasOwn(cursor,'Err')&&Object.keys(cursor).length===1)){throw Error('invalid value for wire schema');}return {tag:5,payload:__privateCapture20(cursor.Err,budget,depth+5)};}
function __privateCapture24(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture16(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture14(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture25(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture15(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture14(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture23(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture22(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture14(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture13(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture0(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture14(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture27(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture4(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture14(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture26(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture6(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture14(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture2(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==0){throw Error('invalid value for wire schema');}return {};}
function __privateCapture10(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==1){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"item0")){throw Error('invalid value for wire schema');}return __privateCapture11(value["item0"],budget,depth+1);}
function __privateCapture20(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==1){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"item0")){throw Error('invalid value for wire schema');}return __privateCapture21(value["item0"],budget,depth+1);}
function __privateCapture8(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==1){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"item0")){throw Error('invalid value for wire schema');}return __privateCapture9(value["item0"],budget,depth+1);}
function __privateCapture3(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==1){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"item0")){throw Error('invalid value for wire schema');}return __privateCapture4(value["item0"],budget,depth+1);}
function __privateCapture7(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==1){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"item0")){throw Error('invalid value for wire schema');}return __privateCapture6(value["item0"],budget,depth+1);}
function __privateCapture5(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==1){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"item0")){throw Error('invalid value for wire schema');}return __privateCapture6(value["item0"],budget,depth+1);}
function __privateCapture17(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"key")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}return {["key"]:__privateCapture6(value["key"],budget,depth+1),["value"]:__privateCapture18(value["value"],budget,depth+1)};}
function __privateCapture12(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"key")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}return {["key"]:__privateCapture6(value["key"],budget,depth+1),["value"]:__privateCapture0(value["value"],budget,depth+1)};}
function __privateCapture0(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==1){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"payload")){throw Error('invalid value for wire schema');}return __privateCapture1(value["payload"],budget,depth+1);}
function __privateCapture18(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==1){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"payload")){throw Error('invalid value for wire schema');}return __privateCapture19(value["payload"],budget,depth+1);}
function __privateCapture4(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='boolean'){throw Error('invalid value for wire schema');}budget.add(1);return value;}
function __privateCapture14(value,budget,depth=0){budget.enter(depth,4);const text=value;if(typeof text!=='string'||!text.isWellFormed()||text.length>budget.limit){throw Error('invalid value for wire schema');}if(!["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"].includes(text)){throw Error('invalid value for wire schema');}budget.text(text);return text;}
function __privateCapture6(value,budget,depth=0){budget.enter(depth,4);const text=value;if(typeof text!=='string'||!text.isWellFormed()||text.length>budget.limit){throw Error('invalid value for wire schema');}budget.text(text);return text;}
function __privateWireValue23(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue24(reader);reader.finish(end);return value;}
function __privateWireValue11(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue12(reader);reader.finish(end);return value;}
function __privateWireValue21(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue0(reader);reader.finish(end);return value;}
function __privateWireValue30(reader){const end=reader.frame();const value=reader.byte()?{Some:__privateWireValue0(reader)}:{None:null};reader.finish(end);return value;}
function __privateWireValue28(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue24(reader);reader.finish(end);return value;}
function __privateWireValue9(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue0(reader);reader.finish(end);return value;}
function __privateWireValue41(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue6(reader);reader.finish(end);return value;}
function __privateWireValue1(reader){const end=reader.frame();let value;if(reader.byte()===0){value={tag:0,payload:__privateWireValue2(reader)};}else{const end1=reader.frame();if(reader.byte()===0){value={tag:1,payload:__privateWireValue3(reader)};}else{const end2=reader.frame();if(reader.byte()===0){value={tag:2,payload:__privateWireValue5(reader)};}else{const end3=reader.frame();if(reader.byte()===0){value={tag:3,payload:__privateWireValue7(reader)};}else{const end4=reader.frame();if(reader.byte()===0){value={tag:4,payload:__privateWireValue8(reader)};}else{value={tag:5,payload:__privateWireValue10(reader)};}reader.finish(end4);}reader.finish(end3);}reader.finish(end2);}reader.finish(end1);}reader.finish(end);return value;}
function __privateWireValue26(reader){const end=reader.frame();let value;if(reader.byte()===0){value={tag:0,payload:__privateWireValue2(reader)};}else{const end1=reader.frame();if(reader.byte()===0){value={tag:1,payload:__privateWireValue3(reader)};}else{const end2=reader.frame();if(reader.byte()===0){value={tag:2,payload:__privateWireValue5(reader)};}else{const end3=reader.frame();if(reader.byte()===0){value={tag:3,payload:__privateWireValue7(reader)};}else{const end4=reader.frame();if(reader.byte()===0){value={tag:4,payload:__privateWireValue8(reader)};}else{value={tag:5,payload:__privateWireValue27(reader)};}reader.finish(end4);}reader.finish(end3);}reader.finish(end2);}reader.finish(end1);}reader.finish(end);return value;}
function __privateWireValue34(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue14(reader)}:{Ok:__privateWireValue23(reader)};reader.finish(end);return value;}
function __privateWireValue36(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue14(reader)}:{Ok:__privateWireValue21(reader)};reader.finish(end);return value;}
function __privateWireValue32(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue14(reader)}:{Ok:__privateWireValue30(reader)};reader.finish(end);return value;}
function __privateWireValue13(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue14(reader)}:{Ok:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue38(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue14(reader)}:{Ok:__privateWireValue4(reader)};reader.finish(end);return value;}
function __privateWireValue37(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue14(reader)}:{Ok:__privateWireValue6(reader)};reader.finish(end);return value;}
function __privateWireValue2(reader){const end=reader.frame();const value={};reader.finish(end);return value;}
function __privateWireValue17(reader){const end=reader.frame();const value={};reader.finish(end);return value;}
function __privateWireValue15(reader){const end=reader.frame();const value={["document"]:__privateWireValue0(reader),["key"]:__privateWireValue6(reader),["value"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue16(reader){const end=reader.frame();const value={["document"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue10(reader){const end=reader.frame(),value=__privateWireValue11(reader);reader.finish(end);return value;}
function __privateWireValue27(reader){const end=reader.frame(),value=__privateWireValue28(reader);reader.finish(end);return value;}
function __privateWireValue8(reader){const end=reader.frame(),value=__privateWireValue9(reader);reader.finish(end);return value;}
function __privateWireValue3(reader){const end=reader.frame(),value=__privateWireValue4(reader);reader.finish(end);return value;}
function __privateWireValue7(reader){const end=reader.frame(),value=__privateWireValue6(reader);reader.finish(end);return value;}
function __privateWireValue5(reader){const end=reader.frame(),value=__privateWireValue6(reader);reader.finish(end);return value;}
function __privateWireValue24(reader){const end=reader.frame();const value={["key"]:__privateWireValue6(reader),["value"]:__privateWireValue25(reader)};reader.finish(end);return value;}
function __privateWireValue12(reader){const end=reader.frame();const value={["key"]:__privateWireValue6(reader),["value"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue39(reader){const end=reader.frame();const value={["members"]:__privateWireValue23(reader),["key"]:__privateWireValue6(reader),["value"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue31(reader){const end=reader.frame();const value={["members"]:__privateWireValue23(reader),["key"]:__privateWireValue6(reader)};reader.finish(end);return value;}
function __privateWireValue29(reader){const end=reader.frame();const value={["members"]:__privateWireValue23(reader)};reader.finish(end);return value;}
function __privateWireValue0(reader){const end=reader.frame(),value=__privateWireValue1(reader);reader.finish(end);return value;}
function __privateWireValue25(reader){const end=reader.frame(),value=__privateWireValue26(reader);reader.finish(end);return value;}
function __privateWireValue19(reader){const end=reader.frame();const value={["token"]:__privateWireValue6(reader)};reader.finish(end);return value;}
function __privateWireValue40(reader){const end=reader.frame();const value={["value"]:__privateWireValue0(reader),["key"]:__privateWireValue6(reader),["replacement"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue33(reader){const end=reader.frame();const value={["value"]:__privateWireValue0(reader),["key"]:__privateWireValue6(reader)};reader.finish(end);return value;}
function __privateWireValue42(reader){const end=reader.frame();const value={["value"]:__privateWireValue0(reader),["keys"]:__privateWireValue41(reader)};reader.finish(end);return value;}
function __privateWireValue35(reader){const end=reader.frame();const value={["value"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue18(reader){const end=reader.frame();const value={["value"]:__privateWireValue4(reader)};reader.finish(end);return value;}
function __privateWireValue20(reader){const end=reader.frame();const value={["value"]:__privateWireValue6(reader)};reader.finish(end);return value;}
function __privateWireValue22(reader){const end=reader.frame();const value={["values"]:__privateWireValue21(reader)};reader.finish(end);return value;}
function __privateWireValue4(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
const __privateWireValue14Variants=Object.freeze(["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]);
function __privateWireValue14(reader){const end=reader.frame();const value=reader.text(end,"enum",__privateWireValue14Variants);reader.finish(end);return value;}
function __privateWireValue6(reader){const end=reader.frame();const value=reader.text(end,"string");reader.finish(end);return value;}
function __compiledOwnedValue17(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue18(value[i],budget,depth+1);return out;}
function __compiledOwnedValue12(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue13(value[i],budget,depth+1);return out;}
function __compiledOwnedValue16(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue0(value[i],budget,depth+1);return out;}
function __compiledOwnedValue24(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__compiledOwnedValue0(value.Some,budget,depth+1)};}
function __compiledOwnedValue22(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue23(value[i],budget,depth+1);return out;}
function __compiledOwnedValue9(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue10(value[i],budget,depth+1);return out;}
function __compiledOwnedValue30(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue6(value[i],budget,depth+1);return out;}
function __compiledOwnedValue1(value,budget,depth){budget.enter(depth,5);switch(value.tag){case 0:{return {Ok:__compiledOwnedValue2(value.payload,budget,depth+1)};}case 1:{budget.enter(depth+1,5);return {Err:{Ok:__compiledOwnedValue3(value.payload,budget,depth+2)}};}case 2:{budget.enter(depth+1,5);budget.enter(depth+2,5);return {Err:{Err:{Ok:__compiledOwnedValue5(value.payload,budget,depth+3)}}};}case 3:{budget.enter(depth+1,5);budget.enter(depth+2,5);budget.enter(depth+3,5);return {Err:{Err:{Err:{Ok:__compiledOwnedValue7(value.payload,budget,depth+4)}}}};}case 4:{budget.enter(depth+1,5);budget.enter(depth+2,5);budget.enter(depth+3,5);budget.enter(depth+4,5);return {Err:{Err:{Err:{Err:{Ok:__compiledOwnedValue8(value.payload,budget,depth+5)}}}}};}case 5:{budget.enter(depth+1,5);budget.enter(depth+2,5);budget.enter(depth+3,5);budget.enter(depth+4,5);return {Err:{Err:{Err:{Err:{Err:__compiledOwnedValue11(value.payload,budget,depth+5)}}}}};}default:throw Error('private sum tag');}}
function __compiledOwnedValue20(value,budget,depth){budget.enter(depth,5);switch(value.tag){case 0:{return {Ok:__compiledOwnedValue2(value.payload,budget,depth+1)};}case 1:{budget.enter(depth+1,5);return {Err:{Ok:__compiledOwnedValue3(value.payload,budget,depth+2)}};}case 2:{budget.enter(depth+1,5);budget.enter(depth+2,5);return {Err:{Err:{Ok:__compiledOwnedValue5(value.payload,budget,depth+3)}}};}case 3:{budget.enter(depth+1,5);budget.enter(depth+2,5);budget.enter(depth+3,5);return {Err:{Err:{Err:{Ok:__compiledOwnedValue7(value.payload,budget,depth+4)}}}};}case 4:{budget.enter(depth+1,5);budget.enter(depth+2,5);budget.enter(depth+3,5);budget.enter(depth+4,5);return {Err:{Err:{Err:{Err:{Ok:__compiledOwnedValue8(value.payload,budget,depth+5)}}}}};}case 5:{budget.enter(depth+1,5);budget.enter(depth+2,5);budget.enter(depth+3,5);budget.enter(depth+4,5);return {Err:{Err:{Err:{Err:{Err:__compiledOwnedValue21(value.payload,budget,depth+5)}}}}};}default:throw Error('private sum tag');}}
function __compiledOwnedValue26(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue17(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue15(value.Err,budget,depth+1)};}
function __compiledOwnedValue27(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue16(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue15(value.Err,budget,depth+1)};}
function __compiledOwnedValue25(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue24(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue15(value.Err,budget,depth+1)};}
function __compiledOwnedValue14(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue0(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue15(value.Err,budget,depth+1)};}
function __compiledOwnedValue29(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue4(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue15(value.Err,budget,depth+1)};}
function __compiledOwnedValue28(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue6(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue15(value.Err,budget,depth+1)};}
function __compiledOwnedValue2(value,budget,depth){budget.enter(depth,4);return {};}
function __compiledOwnedValue11(value,budget,depth){budget.enter(depth,4);return {["item0"]:__compiledOwnedValue12(value,budget,depth+1)};}
function __compiledOwnedValue21(value,budget,depth){budget.enter(depth,4);return {["item0"]:__compiledOwnedValue22(value,budget,depth+1)};}
function __compiledOwnedValue8(value,budget,depth){budget.enter(depth,4);return {["item0"]:__compiledOwnedValue9(value,budget,depth+1)};}
function __compiledOwnedValue3(value,budget,depth){budget.enter(depth,4);return {["item0"]:__compiledOwnedValue4(value,budget,depth+1)};}
function __compiledOwnedValue7(value,budget,depth){budget.enter(depth,4);return {["item0"]:__compiledOwnedValue6(value,budget,depth+1)};}
function __compiledOwnedValue5(value,budget,depth){budget.enter(depth,4);return {["item0"]:__compiledOwnedValue6(value,budget,depth+1)};}
function __compiledOwnedValue18(value,budget,depth){budget.enter(depth,4);return {["key"]:__compiledOwnedValue6(value["key"],budget,depth+1),["value"]:__compiledOwnedValue19(value["value"],budget,depth+1)};}
function __compiledOwnedValue13(value,budget,depth){budget.enter(depth,4);return {["key"]:__compiledOwnedValue6(value["key"],budget,depth+1),["value"]:__compiledOwnedValue10(value["value"],budget,depth+1)};}
function __compiledOwnedValue0(value,budget,depth){budget.enter(depth,4);return {["payload"]:__compiledOwnedValue1(value,budget,depth+1)};}
function __compiledOwnedValue19(value,budget,depth){budget.enter(depth,4);return {["payload"]:__compiledOwnedValue20(value,budget,depth+1)};}
function __compiledOwnedValue4(value,budget,depth){budget.enter(depth,5);return value;}
function __compiledOwnedValue15(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __compiledOwnedValue23(value,budget,depth){return __compiledOwnedValue18(value,budget,depth);}
function __compiledOwnedValue10(value,budget,depth){return __compiledOwnedValue0(value,budget,depth);}
function __compiledOwnedValue6(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __privateWireWrite16(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite17(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite11(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite12(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite15(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite0(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite22(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Some')){writer.byte(1);__privateWireWrite0(writer,value.Some,compact);}else{writer.byte(0);}writer.closeFrame(frame);}
function __privateWireWrite21(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite17(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite9(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite0(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite28(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite6(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite1(writer,value,compact){const frame=writer.openFrame();switch(value.tag){case 0:{writer.byte(0);__privateWireWrite2(writer,value.payload,compact);break;}case 1:{writer.byte(1);{const frame=writer.openFrame();writer.byte(0);__privateWireWrite3(writer,value.payload,compact);writer.closeFrame(frame);}break;}case 2:{writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(0);__privateWireWrite5(writer,value.payload,compact);writer.closeFrame(frame);}writer.closeFrame(frame);}break;}case 3:{writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(0);__privateWireWrite7(writer,value.payload,compact);writer.closeFrame(frame);}writer.closeFrame(frame);}writer.closeFrame(frame);}break;}case 4:{writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(0);__privateWireWrite8(writer,value.payload,compact);writer.closeFrame(frame);}writer.closeFrame(frame);}writer.closeFrame(frame);}writer.closeFrame(frame);}break;}case 5:{writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(1);__privateWireWrite10(writer,value.payload,compact);writer.closeFrame(frame);}writer.closeFrame(frame);}writer.closeFrame(frame);}writer.closeFrame(frame);}break;}default:throw Error('private sum tag');}writer.closeFrame(frame);}
function __privateWireWrite19(writer,value,compact){const frame=writer.openFrame();switch(value.tag){case 0:{writer.byte(0);__privateWireWrite2(writer,value.payload,compact);break;}case 1:{writer.byte(1);{const frame=writer.openFrame();writer.byte(0);__privateWireWrite3(writer,value.payload,compact);writer.closeFrame(frame);}break;}case 2:{writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(0);__privateWireWrite5(writer,value.payload,compact);writer.closeFrame(frame);}writer.closeFrame(frame);}break;}case 3:{writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(0);__privateWireWrite7(writer,value.payload,compact);writer.closeFrame(frame);}writer.closeFrame(frame);}writer.closeFrame(frame);}break;}case 4:{writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(0);__privateWireWrite8(writer,value.payload,compact);writer.closeFrame(frame);}writer.closeFrame(frame);}writer.closeFrame(frame);}writer.closeFrame(frame);}break;}case 5:{writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(1);{const frame=writer.openFrame();writer.byte(1);__privateWireWrite20(writer,value.payload,compact);writer.closeFrame(frame);}writer.closeFrame(frame);}writer.closeFrame(frame);}writer.closeFrame(frame);}break;}default:throw Error('private sum tag');}writer.closeFrame(frame);}
function __privateWireWrite24(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite16(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite14(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite25(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite15(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite14(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite23(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite22(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite14(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite13(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite0(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite14(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite27(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite4(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite14(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite26(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite6(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite14(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite2(writer,value,compact){const frame=writer.openFrame();writer.closeFrame(frame);}
function __privateWireWrite10(writer,value,compact){const frame=writer.openFrame();__privateWireWrite11(writer,value,compact);writer.closeFrame(frame);}
function __privateWireWrite20(writer,value,compact){const frame=writer.openFrame();__privateWireWrite21(writer,value,compact);writer.closeFrame(frame);}
function __privateWireWrite8(writer,value,compact){const frame=writer.openFrame();__privateWireWrite9(writer,value,compact);writer.closeFrame(frame);}
function __privateWireWrite3(writer,value,compact){const frame=writer.openFrame();__privateWireWrite4(writer,value,compact);writer.closeFrame(frame);}
function __privateWireWrite7(writer,value,compact){const frame=writer.openFrame();__privateWireWrite6(writer,value,compact);writer.closeFrame(frame);}
function __privateWireWrite5(writer,value,compact){const frame=writer.openFrame();__privateWireWrite6(writer,value,compact);writer.closeFrame(frame);}
function __privateWireWrite17(writer,value,compact){const frame=writer.openFrame();__privateWireWrite6(writer,value["key"],compact);__privateWireWrite18(writer,value["value"],compact);writer.closeFrame(frame);}
function __privateWireWrite12(writer,value,compact){const frame=writer.openFrame();__privateWireWrite6(writer,value["key"],compact);__privateWireWrite0(writer,value["value"],compact);writer.closeFrame(frame);}
function __privateWireWrite0(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value,compact);writer.closeFrame(frame);}
function __privateWireWrite18(writer,value,compact){const frame=writer.openFrame();__privateWireWrite19(writer,value,compact);writer.closeFrame(frame);}
function __privateWireWrite4(writer,value,compact){const frame=writer.openFrame();writer.byte(value?1:0);writer.closeFrame(frame);}
function __privateWireWrite14(writer,value,compact){const frame=writer.openFrame();writer.text(value,compact);writer.closeFrame(frame);}
function __privateWireWrite6(writer,value,compact){const frame=writer.openFrame();writer.text(value,compact);writer.closeFrame(frame);}
// Handles have no mutable private payload surface. Membership and type identity
// are checked by this module's closure; copied/foreign objects cannot forge them.
const __compiledHandles=new WeakMap();
const __compiledBindings=new WeakMap();
function __compiledHandle(identity,value){
 const handle=Object.freeze(Object.create(null));
 __compiledHandles.set(handle,{identity,value});return handle;
}
function __compiledUnwrap(handle,identity){
 const entry=__compiledHandles.get(handle);
 if(!entry||entry.identity!==identity)throw Error('compiled value type or owner mismatch');
 return entry.value;
}
// Emit the portable schema's framing/scalar events without creating a buffer
// or exposing private composite nodes. Only this wrapper receives callbacks
// from the literal writer; host visitors never receive those closures.
function __compiledValueEvents(sink,limits){
 const methods=['begin','end','byte','word','wide','text','count'];
 for(const name of methods)if(typeof sink?.[name]!=='function')throw Error('compiled value visitor method: '+name);
 const budget=createValueCaptureBudget(limits);let depth=0,closed=false;
 const active=()=>{if(closed)throw Error('compiled value visitor is closed');};
 const writer=Object.freeze({
  openFrame(){active();budget.enter(depth,4);depth++;sink.begin();return 0;}
  ,closeFrame(){active();if(depth===0)throw Error('wire frame boundary');try{sink.end();}finally{depth--;}}
  ,frame(emit){active();budget.enter(depth,4);depth++;sink.begin();try{emit();sink.end();}finally{depth--;}}
  ,byte(value){active();budget.add(1);sink.byte(value);}
  ,word(value){active();budget.add(4);sink.word(value);}
  ,wide(value){active();budget.add(8);sink.wide(value);}
  ,text(value){active();budget.text(value);sink.text(value);}
  ,count(value){active();budget.add(4);if(value>budget.remaining)throw Error('wire sequence size');sink.count(value);}
 });
 return {writer,close(){closed=true;}};
}
function __compiledReduction(factory,root,reduce,identity){
 if(typeof factory!=='function')throw Error('compiled reduction factory');
 const reducers=[],seen=new Set(),nodes=__reductionNodes();
 const prepare=index=>{
  if(seen.has(index))return;seen.add(index);
  const node=nodes[index];
  for(const child of node.children)prepare(child);
  const reducer=factory(node,index);
  if(node.kind==='list'||node.kind==='vector'){
   const start=reducer?.start,step=reducer?.step,finish=reducer?.finish;
   if(typeof start!=='function'||typeof step!=='function'||typeof finish!=='function')throw Error('compiled collection reduction');
   reducers[index]=Object.freeze({start,step,finish});
  }else{
   if(typeof reducer!=='function')throw Error('compiled value reduction');
   reducers[index]=reducer;
  }
 };
 prepare(root);Object.freeze(reducers);
 return Object.freeze(function(handle,context,limits={}){
  const value=__compiledUnwrap(handle,identity),budget=createValueCaptureBudget(limits);
  return reduce(value,reducers,budget,0,context);
 });
}
function __compiledCodec(schema,capture,read,write,copy,constructorRoot,reductionRoot,reduce,portableFused=false,compactFused=false){
 const privateCodec=createCompiledValueCodec(schema,read),publicCodec=privateCodec;
 let fusedCodec;const fused=()=>fusedCodec??=createFusedValueCodec(schema,read);
 const identity=schema.identity;
 const codec=Object.freeze({
  identity,
  descriptor:publicCodec.descriptor,
  resolve(type){return publicCodec.resolve(type);},
  capture(value,limits={}){
   return __compiledHandle(identity,capture(value,createValueCaptureBudget(limits),0));
  },
  decode(bytes,limits={}){return __compiledHandle(identity,(portableFused?fused():privateCodec).decode(bytes,limits));},
  decodeCompact(bytes,limits={}){return __compiledHandle(identity,(compactFused?fused():privateCodec).compact().decode(bytes,limits));},
  decodeFused(bytes,limits={}){return __compiledHandle(identity,fused().decode(bytes,limits));},
  decodeCompactFused(bytes,limits={}){return __compiledHandle(identity,fused().compact().decode(bytes,limits));},
  encode(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.encodeWith(writer=>write(writer,value,false),limits);},
  encodeCompact(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.compact().encodeWith(writer=>write(writer,value,true),limits);},
  materialize(handle,limits={}){return copy(__compiledUnwrap(handle,identity),createValueCaptureBudget(limits),0);},
  builder(limits={}){return __valueBuilder(__constructorNodes(),constructorRoot,identity,limits);},
  reducer(factory){return __compiledReduction(factory,reductionRoot,reduce,identity);},
  visit(handle,sink,limits={}){
   const value=__compiledUnwrap(handle,identity),events=__compiledValueEvents(sink,limits);
   try{write(events.writer,value,false);}finally{events.close();}
  },
 });
 __compiledBindings.set(codec,{publicCodec,write,capture});return codec;
}

function __compiledEncodeResult(entry,value,limits,compact){
 const {publicCodec,write}=__compiledBindings.get(entry.result());
 return (compact?publicCodec.compact():publicCodec).encodeWith(writer=>write(writer,value,compact),limits);
}
let __constructorNodesValue;function __constructorNodes(){return __constructorNodesValue??=[{kind:'record',fields:["payload"],patterns:[{bytes:4,label:"record",children:[1],childDepth:1,transparent:true,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>(values[0])}]},{kind:'result',flat:(tag,payload)=>({tag,payload}),patterns:[{bytes:5,label:"Ok",children:[2],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(__sumMake("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",true ,values[0]))},{bytes:5,label:"Err",children:[3],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(__sumMake("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",false ,values[0]))}]},{kind:'record',fields:[],patterns:[{bytes:4,label:"record",children:[],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({})}]},{kind:'result',flat:(tag,payload)=>({tag,payload}),patterns:[{bytes:5,label:"Ok",children:[4],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(__sumMake("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",true ,values[0]))},{bytes:5,label:"Err",children:[6],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(__sumMake("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",false ,values[0]))}]},{kind:'record',fields:["item0"],patterns:[{bytes:4,label:"record",children:[5],childDepth:1,transparent:true,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>(values[0])}]},{kind:"bool",scalar:__privateCapture4},{kind:'result',flat:(tag,payload)=>({tag,payload}),patterns:[{bytes:5,label:"Ok",children:[7],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(__sumMake("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",true ,values[0]))},{bytes:5,label:"Err",children:[9],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(__sumMake("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",false ,values[0]))}]},{kind:'record',fields:["item0"],patterns:[{bytes:4,label:"record",children:[8],childDepth:1,transparent:true,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>(values[0])}]},{kind:"string",scalar:__privateCapture6},{kind:'result',flat:(tag,payload)=>({tag,payload}),patterns:[{bytes:5,label:"Ok",children:[10],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(__sumMake("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",true ,values[0]))},{bytes:5,label:"Err",children:[11],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(__sumMake("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",false ,values[0]))}]},{kind:'record',fields:["item0"],patterns:[{bytes:4,label:"record",children:[8],childDepth:1,transparent:true,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>(values[0])}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[12],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[14],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'record',fields:["item0"],patterns:[{bytes:4,label:"record",children:[13],childDepth:1,transparent:true,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>(values[0])}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[0],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["item0"],patterns:[{bytes:4,label:"record",children:[15],childDepth:1,transparent:true,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>(values[0])}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[16],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["key","value"],patterns:[{bytes:4,label:"record",children:[8,0],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["key"]:values[0],["value"]:values[1]})}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[0],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[18],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:"enum",scalar:__privateCapture14},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[0],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[21],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["key","value"],patterns:[{bytes:4,label:"record",children:[8,22],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["key"]:values[0],["value"]:values[1]})}]},{kind:'record',fields:["payload"],patterns:[{bytes:4,label:"record",children:[23],childDepth:1,transparent:true,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>(values[0])}]},{kind:'result',flat:(tag,payload)=>({tag,payload}),patterns:[{bytes:5,label:"Ok",children:[2],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(__sumMake("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",true ,values[0]))},{bytes:5,label:"Err",children:[24],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(__sumMake("[\"result\",[\"named\",\"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550\"],[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]]",false ,values[0]))}]},{kind:'result',flat:(tag,payload)=>({tag,payload}),patterns:[{bytes:5,label:"Ok",children:[4],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(__sumMake("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",true ,values[0]))},{bytes:5,label:"Err",children:[25],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(__sumMake("[\"result\",[\"named\",\"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7\"],[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]]",false ,values[0]))}]},{kind:'result',flat:(tag,payload)=>({tag,payload}),patterns:[{bytes:5,label:"Ok",children:[7],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(__sumMake("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",true ,values[0]))},{bytes:5,label:"Err",children:[26],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(__sumMake("[\"result\",[\"named\",\"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e\"],[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]]",false ,values[0]))}]},{kind:'result',flat:(tag,payload)=>({tag,payload}),patterns:[{bytes:5,label:"Ok",children:[10],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(__sumMake("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",true ,values[0]))},{bytes:5,label:"Err",children:[27],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(__sumMake("[\"result\",[\"named\",\"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2\"],[\"result\",[\"named\",\"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8\"],[\"named\",\"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19\"]]]",false ,values[0]))}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[12],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[28],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'record',fields:["item0"],patterns:[{bytes:4,label:"record",children:[29],childDepth:1,transparent:true,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>(values[0])}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[21],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'option',patterns:[{bytes:5,label:"None",children:[],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({None:null})},{bytes:5,label:"Some",children:[0],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({Some:values[0]})}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[30],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[18],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[20],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[18],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[19],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[18],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[8],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[18],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[5],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[18],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[8],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]}];}
// Typed input construction only: plans contain literal constructor/capture
// functions emitted from source schemas. No source expression evaluator.
// All frames and private values remain in this closure; callers receive only
// an owned opaque handle after one complete, well-typed root is constructed.
const __constructorPaths=new WeakMap();
function __valueBuilder(nodes,root,identity,limits){
 const budget=createValueCaptureBudget(limits),frames=[];
 let result,targetNode,targetDepth,complete=false,closed=false,failed=false,busy=false;
 const fail=message=>{failed=true;frames.length=0;result=undefined;throw Error(message);};
 const active=()=>{if(failed||closed)throw Error('value builder is closed');};
 const expected=()=>{
  if(!frames.length){if(complete)fail('value builder root already complete');targetNode=root;targetDepth=0;return;}
  const frame=frames.at(-1),position=frame.values.length;
  if(!frame.pattern.sequence&&position>=frame.pattern.children.length)fail('value builder constructor is full');
  targetNode=frame.pattern.sequence?frame.pattern.children[0]:frame.pattern.children[position];targetDepth=frame.depth+frame.pattern.childDepth;
 };
 const accept=value=>{
  if(frames.length)frames.at(-1).values.push(value);
  else{result=value;complete=true;}
 };
 const execute=(operation,first,second)=>{
  active();if(busy)throw Error('value builder operation already active');busy=true;
  try{return operation(first,second);}catch(error){failed=true;frames.length=0;result=undefined;throw error;}finally{busy=false;}
 };
 // Compile and cache constructor paths independently of the session's values.
 const pathPlan=(choices,startNode,startDepth)=>{
   if(!Array.isArray(choices)||choices.length===0||choices.length>128)fail('invalid value builder path');
   let cache=__constructorPaths.get(nodes);if(!cache){cache=new WeakMap();__constructorPaths.set(nodes,cache);}
   let entries=cache.get(choices),saved=entries?.get(startNode);
   if(saved)return saved;
   const path=[],charges=[];let node=startNode,depth=startDepth;
   for(let i=0;i<choices.length;i++){
    const choice=choices[i],patterns=nodes[node].patterns;
    if(!Number.isSafeInteger(choice)||choice<0||!patterns||choice>=patterns.length)fail('invalid value builder constructor');
    const pattern=patterns[choice];charges.push([pattern,depth-startDepth]);path.push({pattern,node:nodes[node]});
    if(i+1<choices.length){if(pattern.sequence||pattern.children.length!==1)fail('value builder path is not unary');node=pattern.children[0];depth+=pattern.childDepth;}
   }
   const terminal=path.at(-1).pattern;
   // Compose literal constructor functions once per path, instead of
   // allocating and interpreting another recursive closure for every value.
   const compose=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=args=>args[0];
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=args=>p.make([inner(args)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?compose(last+1):args=>args[0]):compose(last);
     return args=>node.flat(index,payload(args));
    }
    const inner=at+1<path.length?compose(at+1):null;
    if(pattern.transparent)return inner??(args=>args[0]);
    return inner?args=>pattern.make([inner(args)]):pattern.make;
   };
   const make=compose(0);
   // Scalar paths use the same literal constructors, but pass the leaf
   // directly through erased records and flat sums. No temporary argument
   // array is needed at those edges. Ordinary constructors keep their array
   // calling convention; no private value reaches the public builder API.
   const composeScalar=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=value=>value;
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=value=>p.make([inner(value)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?composeScalar(last+1):value=>value):composeScalar(last);
     return value=>node.flat(index,payload(value));
    }
    const inner=at+1<path.length?composeScalar(at+1):null;
    if(pattern.transparent)return inner??(value=>value);
    return inner?value=>pattern.make([inner(value)]):value=>pattern.make([value]);
   };
   const scalar=composeScalar(0);
   const pattern={...terminal,make};
   // Only frozen arrays of ordinary data properties can key reusable plans.
   // Mutable arrays and frozen accessor arrays retain checked per-call paths.
   const fixed=charges.every(([p])=>Number.isSafeInteger(p.bytes)&&p.bytes>=4);
   const plan={pattern,scalar,charges,offset:depth-startDepth,bytes:fixed?charges.reduce((n,[p])=>n+p.bytes,0):null};
   let reusable=Object.isFrozen(choices);
   for(let i=0;reusable&&i<choices.length;i++){const field=Object.getOwnPropertyDescriptor(choices,String(i));reusable=!!field&&Object.hasOwn(field,'value');}
   if(reusable){
    if(!entries){entries=new Map();cache.set(choices,entries);}entries.set(startNode,plan);
   }
   return plan;
 };
 const chargePath=(plan,depth)=>{
  // Each emitted constructor consumes one node and a fixed frame/tag cost.
  // Only take the combined charge when every original check would succeed.
  // Replaying the original order retains the exact first failure otherwise.
  if(plan.bytes!==null&&depth+plan.offset<=budget.depth&&plan.charges.length<=budget.remaining&&budget.bytes+plan.bytes<=budget.limit){
   budget.remaining-=plan.charges.length;budget.bytes+=plan.bytes;return;
  }
  for(const [pattern,offset]of plan.charges)pattern.charge(budget,depth+offset);
 };
 // Operations are allocated once per session, and share expected-node
 // scratch only while the existing reentrancy guard is held.
 const openOperation=(choice)=>{
   expected();const node=nodes[targetNode];
   if(!Number.isSafeInteger(choice)||choice<0||!node.patterns||choice>=node.patterns.length)fail('invalid value builder constructor');
   const pattern=node.patterns[choice];pattern.charge(budget,targetDepth);
   frames.push({pattern,depth:targetDepth,values:[]});
 };
 const openPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth);
   chargePath(plan,targetDepth);
   frames.push({pattern:plan.pattern,depth:targetDepth+plan.offset,values:[]});
 };
 const scalarPathOperation=(choices,value)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==1)fail('value builder path has no scalar leaf');
   const capture=nodes[pattern.children[0]].scalar;
   if(typeof capture!=='function')fail('value builder path has no scalar leaf');
   chargePath(plan,targetDepth);
   const leaf=capture(value,budget,targetDepth+plan.offset+pattern.childDepth);
   accept(plan.scalar(leaf));
 };
 const emptyPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==0)fail('value builder path is not empty');
   chargePath(plan,targetDepth);accept(pattern.make([]));
 };
 const scalarOperation=(value)=>{
   expected();const capture=nodes[targetNode].scalar;
   if(typeof capture!=='function')fail('value builder expects a constructor');
   accept(capture(value,budget,targetDepth));
 };
 const closeOperation=()=>{
   if(!frames.length)fail('value builder has no open constructor');
   const frame=frames.at(-1),pattern=frame.pattern,count=frame.values.length;
   if(!pattern.sequence&&count!==pattern.children.length||pattern.size!==undefined&&count!==pattern.size)fail('value builder constructor arity');
   if(pattern.sequence&&count>budget.limit)fail('wire sequence size');
   const value=pattern.make(frame.values);
   frames.pop();accept(value);
 };
 const finishOperation=()=>{
   if(frames.length||!complete)fail('value builder root is incomplete');
   closed=true;const handle=__compiledHandle(identity,result);result=undefined;return handle;
 };
 const api=Object.freeze({
  open(choice){return execute(openOperation,choice);},
  // Charge every source constructor even when unary paths share one frame.
  openPath(choices){return execute(openPathOperation,choices);},
  // Complete the path and leaf without intermediate session frames.
  scalarPath(choices,value){return execute(scalarPathOperation,choices,value);},
  emptyPath(choices){return execute(emptyPathOperation,choices);},
  scalar(value){return execute(scalarOperation,value);},
  close(){return execute(closeOperation);},
  finish(){return execute(finishOperation);},
  abort(){if(busy)throw Error('value builder operation already active');failed=true;frames.length=0;result=undefined;},
 });
 return api;
}
function __reduceValue0(value,r,b,d,c){b.enter(d,4);return r[0](__reduceValue1(value,r,b,d+1,c),c);}
function __reduceValue1(value,r,b,d,c){b.enter(d,5);switch(value.tag){case 0:{return r[1](0,__reduceValue2(value.payload,r,b,d+1,c),c);}case 1:{b.enter(d+1,5);return r[1](1,r[3](0,__reduceValue4(value.payload,r,b,d+2,c),c),c);}case 2:{b.enter(d+1,5);b.enter(d+2,5);return r[1](1,r[3](1,r[6](0,__reduceValue7(value.payload,r,b,d+3,c),c),c),c);}case 3:{b.enter(d+1,5);b.enter(d+2,5);b.enter(d+3,5);return r[1](1,r[3](1,r[6](1,r[9](0,__reduceValue10(value.payload,r,b,d+4,c),c),c),c),c);}case 4:{b.enter(d+1,5);b.enter(d+2,5);b.enter(d+3,5);b.enter(d+4,5);return r[1](1,r[3](1,r[6](1,r[9](1,r[11](0,__reduceValue12(value.payload,r,b,d+5,c),c),c),c),c),c);}case 5:{b.enter(d+1,5);b.enter(d+2,5);b.enter(d+3,5);b.enter(d+4,5);return r[1](1,r[3](1,r[6](1,r[9](1,r[11](1,__reduceValue14(value.payload,r,b,d+5,c),c),c),c),c),c);}default:throw Error('private sum tag');}}
function __reduceValue2(value,r,b,d,c){b.enter(d,4);return r[2](c);}
function __reduceValue3(value,r,b,d,c){b.enter(d,5);switch(value.tag){case 0:{return r[3](0,__reduceValue4(value.payload,r,b,d+1,c),c);}case 1:{b.enter(d+1,5);return r[3](1,r[6](0,__reduceValue7(value.payload,r,b,d+2,c),c),c);}case 2:{b.enter(d+1,5);b.enter(d+2,5);return r[3](1,r[6](1,r[9](0,__reduceValue10(value.payload,r,b,d+3,c),c),c),c);}case 3:{b.enter(d+1,5);b.enter(d+2,5);b.enter(d+3,5);return r[3](1,r[6](1,r[9](1,r[11](0,__reduceValue12(value.payload,r,b,d+4,c),c),c),c),c);}case 4:{b.enter(d+1,5);b.enter(d+2,5);b.enter(d+3,5);return r[3](1,r[6](1,r[9](1,r[11](1,__reduceValue14(value.payload,r,b,d+4,c),c),c),c),c);}default:throw Error('private sum tag');}}
function __reduceValue4(value,r,b,d,c){b.enter(d,4);return r[4](__reduceValue5(value,r,b,d+1,c),c);}
function __reduceValue5(value,r,b,d,c){b.enter(d,5);return r[5](value,c);}
function __reduceValue6(value,r,b,d,c){b.enter(d,5);switch(value.tag){case 0:{return r[6](0,__reduceValue7(value.payload,r,b,d+1,c),c);}case 1:{b.enter(d+1,5);return r[6](1,r[9](0,__reduceValue10(value.payload,r,b,d+2,c),c),c);}case 2:{b.enter(d+1,5);b.enter(d+2,5);return r[6](1,r[9](1,r[11](0,__reduceValue12(value.payload,r,b,d+3,c),c),c),c);}case 3:{b.enter(d+1,5);b.enter(d+2,5);return r[6](1,r[9](1,r[11](1,__reduceValue14(value.payload,r,b,d+3,c),c),c),c);}default:throw Error('private sum tag');}}
function __reduceValue7(value,r,b,d,c){b.enter(d,4);return r[7](__reduceValue8(value,r,b,d+1,c),c);}
function __reduceValue8(value,r,b,d,c){b.enter(d,4);b.text(value);return r[8](value,c);}
function __reduceValue9(value,r,b,d,c){b.enter(d,5);switch(value.tag){case 0:{return r[9](0,__reduceValue10(value.payload,r,b,d+1,c),c);}case 1:{b.enter(d+1,5);return r[9](1,r[11](0,__reduceValue12(value.payload,r,b,d+2,c),c),c);}case 2:{b.enter(d+1,5);return r[9](1,r[11](1,__reduceValue14(value.payload,r,b,d+2,c),c),c);}default:throw Error('private sum tag');}}
function __reduceValue10(value,r,b,d,c){b.enter(d,4);return r[10](__reduceValue8(value,r,b,d+1,c),c);}
function __reduceValue11(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[11](0,__reduceValue12(value.Ok,r,b,d+1,c),c):r[11](1,__reduceValue14(value.Err,r,b,d+1,c),c);}
function __reduceValue12(value,r,b,d,c){b.enter(d,4);return r[12](__reduceValue13(value,r,b,d+1,c),c);}
function __reduceValue13(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[13];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue0(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue14(value,r,b,d,c){b.enter(d,4);return r[14](__reduceValue15(value,r,b,d+1,c),c);}
function __reduceValue15(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[15];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue16(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue16(value,r,b,d,c){b.enter(d,4);return r[16](__reduceValue8(value["key"],r,b,d+1,c),__reduceValue0(value["value"],r,b,d+1,c),c);}
function __reduceValue17(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[17](0,__reduceValue0(value.Ok,r,b,d+1,c),c):r[17](1,__reduceValue18(value.Err,r,b,d+1,c),c);}
function __reduceValue18(value,r,b,d,c){b.enter(d,4);b.text(value);return r[18](value,c);}
function __reduceValue19(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[19];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue0(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue20(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[20];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue21(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue21(value,r,b,d,c){b.enter(d,4);return r[21](__reduceValue8(value["key"],r,b,d+1,c),__reduceValue22(value["value"],r,b,d+1,c),c);}
function __reduceValue22(value,r,b,d,c){b.enter(d,4);return r[22](__reduceValue23(value,r,b,d+1,c),c);}
function __reduceValue23(value,r,b,d,c){b.enter(d,5);switch(value.tag){case 0:{return r[23](0,__reduceValue2(value.payload,r,b,d+1,c),c);}case 1:{b.enter(d+1,5);return r[23](1,r[24](0,__reduceValue4(value.payload,r,b,d+2,c),c),c);}case 2:{b.enter(d+1,5);b.enter(d+2,5);return r[23](1,r[24](1,r[25](0,__reduceValue7(value.payload,r,b,d+3,c),c),c),c);}case 3:{b.enter(d+1,5);b.enter(d+2,5);b.enter(d+3,5);return r[23](1,r[24](1,r[25](1,r[26](0,__reduceValue10(value.payload,r,b,d+4,c),c),c),c),c);}case 4:{b.enter(d+1,5);b.enter(d+2,5);b.enter(d+3,5);b.enter(d+4,5);return r[23](1,r[24](1,r[25](1,r[26](1,r[27](0,__reduceValue12(value.payload,r,b,d+5,c),c),c),c),c),c);}case 5:{b.enter(d+1,5);b.enter(d+2,5);b.enter(d+3,5);b.enter(d+4,5);return r[23](1,r[24](1,r[25](1,r[26](1,r[27](1,__reduceValue28(value.payload,r,b,d+5,c),c),c),c),c),c);}default:throw Error('private sum tag');}}
function __reduceValue24(value,r,b,d,c){b.enter(d,5);switch(value.tag){case 0:{return r[24](0,__reduceValue4(value.payload,r,b,d+1,c),c);}case 1:{b.enter(d+1,5);return r[24](1,r[25](0,__reduceValue7(value.payload,r,b,d+2,c),c),c);}case 2:{b.enter(d+1,5);b.enter(d+2,5);return r[24](1,r[25](1,r[26](0,__reduceValue10(value.payload,r,b,d+3,c),c),c),c);}case 3:{b.enter(d+1,5);b.enter(d+2,5);b.enter(d+3,5);return r[24](1,r[25](1,r[26](1,r[27](0,__reduceValue12(value.payload,r,b,d+4,c),c),c),c),c);}case 4:{b.enter(d+1,5);b.enter(d+2,5);b.enter(d+3,5);return r[24](1,r[25](1,r[26](1,r[27](1,__reduceValue28(value.payload,r,b,d+4,c),c),c),c),c);}default:throw Error('private sum tag');}}
function __reduceValue25(value,r,b,d,c){b.enter(d,5);switch(value.tag){case 0:{return r[25](0,__reduceValue7(value.payload,r,b,d+1,c),c);}case 1:{b.enter(d+1,5);return r[25](1,r[26](0,__reduceValue10(value.payload,r,b,d+2,c),c),c);}case 2:{b.enter(d+1,5);b.enter(d+2,5);return r[25](1,r[26](1,r[27](0,__reduceValue12(value.payload,r,b,d+3,c),c),c),c);}case 3:{b.enter(d+1,5);b.enter(d+2,5);return r[25](1,r[26](1,r[27](1,__reduceValue28(value.payload,r,b,d+3,c),c),c),c);}default:throw Error('private sum tag');}}
function __reduceValue26(value,r,b,d,c){b.enter(d,5);switch(value.tag){case 0:{return r[26](0,__reduceValue10(value.payload,r,b,d+1,c),c);}case 1:{b.enter(d+1,5);return r[26](1,r[27](0,__reduceValue12(value.payload,r,b,d+2,c),c),c);}case 2:{b.enter(d+1,5);return r[26](1,r[27](1,__reduceValue28(value.payload,r,b,d+2,c),c),c);}default:throw Error('private sum tag');}}
function __reduceValue27(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[27](0,__reduceValue12(value.Ok,r,b,d+1,c),c):r[27](1,__reduceValue28(value.Err,r,b,d+1,c),c);}
function __reduceValue28(value,r,b,d,c){b.enter(d,4);return r[28](__reduceValue29(value,r,b,d+1,c),c);}
function __reduceValue29(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[29];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue21(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue30(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'None')&&value.None===null?r[30](0,null,c):r[30](1,__reduceValue0(value.Some,r,b,d+1,c),c);}
function __reduceValue31(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[31](0,__reduceValue30(value.Ok,r,b,d+1,c),c):r[31](1,__reduceValue18(value.Err,r,b,d+1,c),c);}
function __reduceValue32(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[32](0,__reduceValue20(value.Ok,r,b,d+1,c),c):r[32](1,__reduceValue18(value.Err,r,b,d+1,c),c);}
function __reduceValue33(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[33](0,__reduceValue19(value.Ok,r,b,d+1,c),c):r[33](1,__reduceValue18(value.Err,r,b,d+1,c),c);}
function __reduceValue34(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[34](0,__reduceValue8(value.Ok,r,b,d+1,c),c):r[34](1,__reduceValue18(value.Err,r,b,d+1,c),c);}
function __reduceValue35(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[35](0,__reduceValue5(value.Ok,r,b,d+1,c),c):r[35](1,__reduceValue18(value.Err,r,b,d+1,c),c);}
function __reduceValue36(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[36];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue8(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
let __reductionNodeCache;function __reductionNodes(){return __reductionNodeCache??=Object.freeze([Object.freeze({"children":Object.freeze([1]),"fields":Object.freeze(["payload"]),"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}),Object.freeze({"children":Object.freeze([2,3]),"kind":"result"}),Object.freeze({"children":Object.freeze([]),"fields":Object.freeze([]),"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}),Object.freeze({"children":Object.freeze([4,6]),"kind":"result"}),Object.freeze({"children":Object.freeze([5]),"fields":Object.freeze(["item0"]),"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}),Object.freeze({"children":Object.freeze([]),"kind":"bool"}),Object.freeze({"children":Object.freeze([7,9]),"kind":"result"}),Object.freeze({"children":Object.freeze([8]),"fields":Object.freeze(["item0"]),"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}),Object.freeze({"children":Object.freeze([]),"kind":"string"}),Object.freeze({"children":Object.freeze([10,11]),"kind":"result"}),Object.freeze({"children":Object.freeze([8]),"fields":Object.freeze(["item0"]),"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}),Object.freeze({"children":Object.freeze([12,14]),"kind":"result"}),Object.freeze({"children":Object.freeze([13]),"fields":Object.freeze(["item0"]),"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}),Object.freeze({"children":Object.freeze([0]),"kind":"list"}),Object.freeze({"children":Object.freeze([15]),"fields":Object.freeze(["item0"]),"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"}),Object.freeze({"children":Object.freeze([16]),"kind":"list"}),Object.freeze({"children":Object.freeze([8,0]),"fields":Object.freeze(["key","value"]),"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"}),Object.freeze({"children":Object.freeze([0,18]),"kind":"result"}),Object.freeze({"children":Object.freeze([]),"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb"}),Object.freeze({"children":Object.freeze([0]),"kind":"list"}),Object.freeze({"children":Object.freeze([21]),"kind":"list"}),Object.freeze({"children":Object.freeze([8,22]),"fields":Object.freeze(["key","value"]),"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"}),Object.freeze({"children":Object.freeze([23]),"fields":Object.freeze(["payload"]),"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}),Object.freeze({"children":Object.freeze([2,24]),"kind":"result"}),Object.freeze({"children":Object.freeze([4,25]),"kind":"result"}),Object.freeze({"children":Object.freeze([7,26]),"kind":"result"}),Object.freeze({"children":Object.freeze([10,27]),"kind":"result"}),Object.freeze({"children":Object.freeze([12,28]),"kind":"result"}),Object.freeze({"children":Object.freeze([29]),"fields":Object.freeze(["item0"]),"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"}),Object.freeze({"children":Object.freeze([21]),"kind":"list"}),Object.freeze({"children":Object.freeze([0]),"kind":"option"}),Object.freeze({"children":Object.freeze([30,18]),"kind":"result"}),Object.freeze({"children":Object.freeze([20,18]),"kind":"result"}),Object.freeze({"children":Object.freeze([19,18]),"kind":"result"}),Object.freeze({"children":Object.freeze([8,18]),"kind":"result"}),Object.freeze({"children":Object.freeze([5,18]),"kind":"result"}),Object.freeze({"children":Object.freeze([8]),"kind":"list"})]);}
function __compiledNamed2(){return {"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}};}
function __compiledNamed0(){return {"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}};}
function __compiledNamed1(){return {};}
let __compiledCodec0Value;function __compiledCodec0(){return __compiledCodec0Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"cde2342294b5d22d550a478382af229c83cb7f43fc3b018dcd529ebfc8a284ba","named":__compiledNamed0(),"root":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}},__privateCapture0,__privateWireValue0,__privateWireWrite0,__compiledOwnedValue0,0,0,__reduceValue0,false,false);}
let __compiledCodec1Value;function __compiledCodec1(){return __compiledCodec1Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"1cdb97f14e69255770652db593f88ce0009f937c28d02381f37b2c643dc1470e","named":__compiledNamed1(),"root":{"kind":"string"}},__privateCapture6,__privateWireValue6,__privateWireWrite6,__compiledOwnedValue6,8,8,__reduceValue8,false,false);}
let __compiledCodec2Value;function __compiledCodec2(){return __compiledCodec2Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"7009644bf1bd80a4b5df84e49ccd1b83630a5a3bb97fd1654953e69fcfd52fa2","named":__compiledNamed0(),"root":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}},__privateCapture13,__privateWireValue13,__privateWireWrite13,__compiledOwnedValue14,17,17,__reduceValue17,false,false);}
let __compiledCodec3Value;function __compiledCodec3(){return __compiledCodec3Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":__compiledNamed1(),"root":{"kind":"bool"}},__privateCapture4,__privateWireValue4,__privateWireWrite4,__compiledOwnedValue4,5,5,__reduceValue5,false,false);}
let __compiledCodec4Value;function __compiledCodec4(){return __compiledCodec4Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"f3deedf371618bda8636c527a95ba05bec0206ae775b9bf747168469496666fb","named":__compiledNamed0(),"root":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}},__privateCapture15,__privateWireValue21,__privateWireWrite15,__compiledOwnedValue16,19,19,__reduceValue19,false,false);}
let __compiledCodec5Value;function __compiledCodec5(){return __compiledCodec5Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"2b5b92cf8b137fa488f335d974dfd980de30e6aa85fefd6ad847da102cf7cb93","named":__compiledNamed2(),"root":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}},__privateCapture16,__privateWireValue23,__privateWireWrite16,__compiledOwnedValue17,20,20,__reduceValue20,false,false);}
let __compiledCodec6Value;function __compiledCodec6(){return __compiledCodec6Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fca6ee2ed4d9b81404327cbe773b519441d1d81486d2bc394fb759a7d795d6cf","named":__compiledNamed0(),"root":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"option"}},__privateCapture22,__privateWireValue30,__privateWireWrite22,__compiledOwnedValue24,30,30,__reduceValue30,false,false);}
let __compiledCodec7Value;function __compiledCodec7(){return __compiledCodec7Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"26cf663a2b8c3c836b1e7a7a83e9e1cd115b0d1d1cae8bc3feca9e205abcc0ea","named":__compiledNamed0(),"root":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"option"}}},__privateCapture23,__privateWireValue32,__privateWireWrite23,__compiledOwnedValue25,31,31,__reduceValue31,false,false);}
let __compiledCodec8Value;function __compiledCodec8(){return __compiledCodec8Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"31c4fe41eb6c3b7dcfc985f701b759a14acb5d2bfa5f13ee2bc29d20c5baa6ac","named":__compiledNamed2(),"root":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}},__privateCapture24,__privateWireValue34,__privateWireWrite24,__compiledOwnedValue26,32,32,__reduceValue32,false,false);}
let __compiledCodec9Value;function __compiledCodec9(){return __compiledCodec9Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"bbc92730c4d69116e391c2fb18422a1876181431d200628bd1ba3ee68c42e237","named":__compiledNamed0(),"root":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"element":{"fields":[{"name":"payload","type":{"error":{"error":{"error":{"error":{"error":{"fields":[{"name":"item0","type":{"element":{"fields":[{"name":"key","type":{"kind":"string"}},{"name":"value","type":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"}}],"kind":"record","name":"ink_m823309142b2685b3a65d1c240843dcfed7c1e6a964f2bd941ba741adb1a384ce"},"kind":"list"}}],"kind":"record","name":"__ink_payload_78bdb60e43bbf3d610e8c872cdcf4babee88d930550a58c7f150b03b655eda19"},"kind":"result","ok":{"fields":[{"name":"item0","type":{"element":{"kind":"ref","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}],"kind":"record","name":"__ink_payload_dcbf99b07cb62cbb8182f115cec1fac21e0a41bfd60fa5f2457127913327b1c8"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_34632bbd9a8f7a60bed4b0ed3a45d7a5adfc2900c7a8d37f4469b76a609fa5e2"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"string"}}],"kind":"record","name":"__ink_payload_a82bf7eb015d981339eb3e20eeff3358ebb91e9aa8e78dab18648569bd18706e"}},"kind":"result","ok":{"fields":[{"name":"item0","type":{"kind":"bool"}}],"kind":"record","name":"__ink_payload_bff999f8a2a326529afcad49253e4e2a1fd440bbdd336be755288693fe5957e7"}},"kind":"result","ok":{"fields":[],"kind":"record","name":"__ink_payload_dd3f88ecb1e96c7ceee99cebd542718942d6e2ff44637670e6aa06aeb54b2550"}}}],"kind":"record","name":"ink_mb8980dfd2092455f08e830a4f6c2980fe2b118f1f2b6966e921b3afccfceb634"},"kind":"list"}}},__privateCapture25,__privateWireValue36,__privateWireWrite25,__compiledOwnedValue27,33,33,__reduceValue33,false,false);}
let __compiledCodec10Value;function __compiledCodec10(){return __compiledCodec10Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"e24d959ababfea7ff89fb11b86077069a10d5bcee2e219f87130e9817ff587e1","named":__compiledNamed1(),"root":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"kind":"string"}}},__privateCapture26,__privateWireValue37,__privateWireWrite26,__compiledOwnedValue28,34,34,__reduceValue34,false,false);}
let __compiledCodec11Value;function __compiledCodec11(){return __compiledCodec11Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"85402867d4e17348f13331ff7950cadaf3a880baf9a3257dda65baae17bc3dc6","named":__compiledNamed1(),"root":{"error":{"kind":"enum","name":"ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb","variants":["ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedObject","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedArray","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedBoolean","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedNumber","ink_ma6ccc711a182f5a2575b68a1630ea86a855fb78b15dea9e6d788c583eee3a4eb.ExpectedString"]},"kind":"result","ok":{"kind":"bool"}}},__privateCapture27,__privateWireValue38,__privateWireWrite27,__compiledOwnedValue29,35,35,__reduceValue35,false,false);}
let __compiledCodec12Value;function __compiledCodec12(){return __compiledCodec12Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"58408de5fc8c7b1431dedd42ef85e98eb7de952a72933a484b63224ad8e28dbf","named":__compiledNamed1(),"root":{"element":{"kind":"string"},"kind":"list"}},__privateCapture28,__privateWireValue41,__privateWireWrite28,__compiledOwnedValue30,36,36,__reduceValue36,false,false);}
const __compiledEntries=new Map([["set_document",{index:0,params:[__compiledCodec0,__compiledCodec1,__compiledCodec0],result:__compiledCodec2,arguments:__privateWireValue15,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["identity",{index:1,params:[__compiledCodec0],result:__compiledCodec0,arguments:__privateWireValue16,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_m5c5479101d38cd5d28f66110c880ad28b6ee3ee64fddb98300dda927c645c107",{index:2,params:[],result:__compiledCodec0,arguments:__privateWireValue17,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_mbf312e22e5ab893385ef1935f8250f16e090d4da8dd41bc1577df1ba636fdc13",{index:3,params:[__compiledCodec3],result:__compiledCodec0,arguments:__privateWireValue18,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_mee36d9721e4db57ba82a41d18344d03b18dc98a5d22319238b436d9aa6c8a6c1",{index:4,params:[__compiledCodec1],result:__compiledCodec0,arguments:__privateWireValue19,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_mca67a4ea249e8eba3cf6e453e86dd061695d9d9afaf7edcf587f8cd1cbc055c9",{index:5,params:[__compiledCodec1],result:__compiledCodec0,arguments:__privateWireValue20,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_me5c9745ee2d98ddc2c32843ec24ea225963aff43ce357055dd9a61b18d1d4982",{index:6,params:[__compiledCodec4],result:__compiledCodec0,arguments:__privateWireValue22,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_mb0e8aa1d34f7cc5fc940000b63bdc043068202b64206a7da02cade0c4e386a22",{index:7,params:[__compiledCodec5],result:__compiledCodec0,arguments:__privateWireValue29,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_m2383a37c8f0f060d8454d784560b1928c68c5b404b4b5fd5bfff2e7fa4fddcbe",{index:8,params:[__compiledCodec5,__compiledCodec1],result:__compiledCodec6,arguments:__privateWireValue31,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_m5d18bbf4cd5236cf3a3bce3bc0ef39b2ca5d48cc74c98fd149a78715c7abf0fc",{index:9,params:[__compiledCodec0,__compiledCodec1],result:__compiledCodec7,arguments:__privateWireValue33,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_md87d2855f042e634a3f3b8c068533029f73d510386d43bf00bc9d0bcd07e5c8c",{index:10,params:[__compiledCodec0],result:__compiledCodec8,arguments:__privateWireValue35,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_m20157316281aa2312519e1609fa4690b136f16e4ef71773eb2a47a1fa3a406de",{index:11,params:[__compiledCodec0],result:__compiledCodec9,arguments:__privateWireValue35,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_me72555cbb304777e5aa4f9e3c006554a0e08baef4b0d7d5315bbdb8d73619005",{index:12,params:[__compiledCodec0],result:__compiledCodec10,arguments:__privateWireValue35,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_m0799e9661dd281b944df2c23f24248caf4bf5ffd20f6d9a7e2fe778ce1a073d2",{index:13,params:[__compiledCodec0],result:__compiledCodec10,arguments:__privateWireValue35,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_m992ba36e5bbedf39b7f14a42b10f872b6c0c9a2ea93b89b3fc52f4d549687c80",{index:14,params:[__compiledCodec0],result:__compiledCodec11,arguments:__privateWireValue35,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_md6609e67dc544a99f2a87bd888df500ffda6c2a250ac3bb96e169677f36aa0ca",{index:15,params:[__compiledCodec5,__compiledCodec1,__compiledCodec0],result:__compiledCodec5,arguments:__privateWireValue39,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_mad008ef4986d9f0222e8592e1b0d53b594ed67eab0548e67ceabe4308ff8638b",{index:16,params:[__compiledCodec0,__compiledCodec1,__compiledCodec0],result:__compiledCodec2,arguments:__privateWireValue40,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_m6daa56a5bc5a861d85247ffa7c539a517219bed2c2c205e9798247b46093c271",{index:17,params:[__compiledCodec0,__compiledCodec1],result:__compiledCodec2,arguments:__privateWireValue33,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}],["ink_m55d79925938089d1d4f5680a132089bb2dbc200f324c50670835f2f3730f3837",{index:18,params:[__compiledCodec0,__compiledCodec12],result:__compiledCodec2,arguments:__privateWireValue42,argumentCodecs:[null,null],boundaryReaders:[false,false],precondition:null}]]);

export const compiledValues=Object.freeze(Object.fromEntries([...__compiledEntries].map(([name,entry])=>[name,Object.freeze({get params(){return Object.freeze(entry.params.map(codec=>codec()));},get result(){return entry.result();}})])));
export function callCompiled(name,args){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(args)||args.length!==entry.params.length)throw Error('unsupported compiled call');
 const values=entry.params.map((codec,i)=>__compiledUnwrap(args[i],codec().identity));
 if(entry.precondition!==null&&__implementations[entry.precondition](...values)!==true)throw Error('contract precondition failed');
 return __compiledHandle(entry.result().identity,__implementations[entry.index](...values));
}
const __intoOutput15=__representation(metadata.functions[15].result.element,true);
const __intoImplementations=[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,__into15,null,null,null];

export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>{
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const body=__intoImplementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args.slice(0,f.params.length))!==true)throw Error('contract precondition failed');return body(...args);};
  const entry=input.every(c=>c===__identity)?implementation:(...values)=>{const context=new WeakMap();return implementation(...input.map((convert,i)=>convert(values[i],context)),values[f.params.length]);};
  return [f.name,entry];
})));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
