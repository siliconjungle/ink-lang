const __nullaryNodes=[];
function __nullaryNode(c){return __nullaryNodes[c]??=({c,a:[]});}
function __node(c,a){return a.length===0?__nullaryNode(c):{c,a};}
const __deepCall=Symbol('private direct-call depth');let __directDepth=0;
function __run(call){const stack=[call];let result;while(stack.length){const frame=stack[stack.length-1],step=frame.next(result);if(step.done){result=step.value;stack.pop();}else{result=undefined;stack.push(step.value);}}return result;}
const __fpView=new DataView(new ArrayBuffer(4));
function __fpNumber(bits){__fpView.setUint32(0,Number(BigInt.asUintN(32,bits)),true);return __fpView.getFloat32(0,true);}
function __fpWord(op,a,b){
 if(op==='neg')return BigInt.asUintN(32,a)^2147483648n;
 const x=__fpNumber(a),y=__fpNumber(b);
 switch(op){case '==':return x===y;case '!=':return x!==y;case '<':return x<y;case '<=':return x<=y;case '>':return x>y;case '>=':return x>=y;}
 const value=op==='+'?x+y:op==='-'?x-y:op==='*'?x*y:undefined;
 if(value===undefined)throw Error('binary32 operator');if(Number.isNaN(value))return 2143289344n;__fpView.setFloat32(0,value,true);return BigInt(__fpView.getUint32(0,true));
}
function d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0){let v0;switch(a0.c){
case 0:{
const v2=0n;
v0=v2;break;}
case 1:{
const v3=1n;
v0=v3;break;}
case 2:{
v0=a0.a[6];break;}
default:throw Error('literal constructor projection');}
return v0;}
function* d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1){const v10=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v12=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a1);
const v9=(v10)<(v12);
let v8;if(v9){
const v14=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
v8=v14;}else{
const v16=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a1);
v8=v16;}
const v20=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v22=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a1);
const v19=(v20)<(v22);
let v18;if(v19){
const v24=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a1);
v18=v24;}else{
const v26=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
v18=v26;}
const v29=yield d_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0);
const v31=yield d_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a1);
const v28=BigInt.asUintN(64,(v29)+(v31));
const v34=yield d_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0);
const v36=yield d_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a1);
const v33=BigInt.asUintN(64,(v34)+(v36));
const v41=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v43=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v40=(v41)<(v43);
let v39;if(v40){
const v45=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
v39=v45;}else{
const v47=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
v39=v47;}
const v49=1n;
const v38=BigInt.asUintN(64,(v39)+(v49));
const v5=__node(2,[a0,a1,v8,v18,v28,v33,v38]);
return v5;}
function* d_14b1c60245cb25b6473dae8947e9201876796fa199c6cdd20ee3a2661b7317b0(a0,a1,a2){const v52=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a2);
const v54=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v51=(v52)<(v54);
let v50;if(v51){
let v56;switch(a1.c){
case 0:{
const v59=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v58=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v59,a2);
v56=v58;break;}
case 1:{
const v64=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v63=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v64,a2);
v56=v63;break;}
case 2:{
const v69=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1.a[0]);
const v72=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1.a[1],a2);
const v68=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v69,v72);
v56=v68;break;}
default:throw Error('literal constructor projection');}
v50=v56;}else{
const v76=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v75=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v76,a2);
v50=v75;}
return v50;}
function d_186b6350f974a9daf5c57b97446437bb2cabe2a9241d8e38d84e02980089fef8(a0){let v80;switch(a0.c){
case 0:{
v80=a0.a[3];break;}
case 1:{
v80=a0.a[2];break;}
default:throw Error('literal constructor projection');}
return v80;}
function* d_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0){let v84;switch(a0.c){
case 0:{
const v86=__nullaryNode(0);
v84=v86;break;}
case 1:{
let v88;switch(a0.a[0].c){
case 0:{
v88=a0.a[0].a[1];break;}
default:throw Error('literal constructor projection');}
let v87;if(v88){
const v93=yield d_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0.a[1]);
const v91=__node(1,[a0.a[0],v93]);
v87=v91;}else{
const v95=yield d_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0.a[1]);
v87=v95;}
v84=v87;break;}
default:throw Error('literal constructor projection');}
return v84;}
function* d_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(a0){let v97;switch(a0.c){
case 0:{
const v99=__nullaryNode(0);
v97=v99;break;}
case 1:{
let v103;switch(a0.a[0].c){
case 0:{
v103=a0.a[0].a[0];break;}
default:throw Error('literal constructor projection');}
const v106=0n;
const v102=BigInt.asUintN(64,(v103)*(v106));
const v107=1n;
const v101=BigInt.asUintN(64,(v102)+(v107));
const v108=yield d_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(a0.a[1]);
const v100=__node(1,[v101,v108]);
v97=v100;break;}
default:throw Error('literal constructor projection');}
return v97;}
function* d_2227a6ba7041bd43fcef1b26000ccf84bfe9666af2f812e03de515c517d771d0(a0){let v110;switch(a0.c){
case 0:{
const v116=yield d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[3]);
const v112=__node(0,[a0.a[0],a0.a[1],a0.a[2],v116,a0.a[4]]);
v110=v112;break;}
case 1:{
const v122=yield d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[2]);
const v119=__node(1,[a0.a[0],a0.a[1],v122]);
v110=v119;break;}
default:throw Error('literal constructor projection');}
return v110;}
function* d_2937ee59437d4727fd243a664a281a6018453ca819aede4e91f0a7d9bda2ca12(a0){const v129=0n;
const v131=__nullaryNode(0);
const v128=__node(1,[v129,a0,v131]);
const v127=yield d_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(v128);
const v126=yield d_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(v127);
const v125=yield d_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(v126);
const v124=yield d_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(v125);
return v124;}
function* d_2a975b3a5fe826968db8619175ac9f0dfbf3be2c770a2eab7b9bb32e684cf01b(a0){const v137=0n;
const v139=__nullaryNode(0);
const v136=__node(1,[v137,a0,v139]);
const v135=yield d_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(v136);
const v134=yield d_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(v135);
const v133=yield d_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(v134);
const v132=yield d_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(v133);
return v132;}
function* d_2d15d039af07da09e966dbb56adcd73b313da516d054674d5f55c495085b08bd(a0){let v140;switch(a0.c){
case 0:{
const v146=yield d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[3]);
const v142=__node(0,[a0.a[0],a0.a[1],a0.a[2],v146,a0.a[4]]);
v140=v142;break;}
case 1:{
const v152=yield d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[2]);
const v149=__node(1,[a0.a[0],a0.a[1],v152]);
v140=v149;break;}
default:throw Error('literal constructor projection');}
return v140;}
function d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0){let v154;switch(a0.c){
case 0:{
const v156=0n;
v154=v156;break;}
case 1:{
v154=a0.a[0];break;}
case 2:{
v154=a0.a[3];break;}
default:throw Error('literal constructor projection');}
return v154;}
function* d_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(a0){let v159;switch(a0.c){
case 0:{
const v162=yield d_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0.a[0]);
const v161=__node(0,[v162]);
v159=v161;break;}
default:throw Error('literal constructor projection');}
return v159;}
function* d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(a0,a1){const v166=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v169=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v171=1n;
const v168=BigInt.asUintN(64,(v169)+(v171));
const v165=(v166)>(v168);
let v164;if(v165){
const v172=yield d_dd9122cd0ef5414b8f184fc5a412c2e0c7b9002cb5d701ef49dc7b9f5465679c(a0,a1);
v164=v172;}else{
const v175=yield d_5772432f10e31d0ddf159e9ab757ef7042f15ed47699a0c380e996b8cda2529c(a0,a1);
v164=v175;}
return v164;}
function* d_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(a0){let v178;switch(a0.c){
case 0:{
const v180=__nullaryNode(0);
v178=v180;break;}
case 1:{
let v182;switch(a0.a[0].c){
case 0:{
v182=a0.a[0].a[0];break;}
default:throw Error('literal constructor projection');}
const v185=yield d_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(a0.a[1]);
const v181=__node(1,[v182,v185]);
v178=v181;break;}
default:throw Error('literal constructor projection');}
return v178;}
function* d_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(a0,a1,a2,a3,a4,a5){let v187;switch(a0.c){
case 0:{
const v191=yield d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v190;switch(v191.c){
case 0:{
const v194=false;
v190=v194;break;}
case 1:{
const v195=true;
v190=v195;break;}
default:throw Error('literal constructor projection');}
let v189;if(v190){
const v198=yield d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v197;switch(v198.c){
case 0:{
const v201=false;
v197=v201;break;}
case 1:{
const v202=true;
v197=v202;break;}
default:throw Error('literal constructor projection');}
let v196;if(v197){
let v203;if(a5){
const v207=__nullaryNode(0);
const v206=__node(1,[v207]);
const v208=false;
const v210=__node(0,[a0.a[0]]);
const v212=__nullaryNode(0);
const v205=__node(0,[v206,v208,a1,v210,v212]);
v203=v205;}else{
const v216=18446744073709551615n;
const v214=(a1)===(v216);
let v213;if(v214){
const v218=1n;
const v220=__node(0,[a0.a[0]]);
const v217=__node(1,[v218,a1,v220]);
v213=v217;}else{
const v224=__nullaryNode(0);
const v223=__node(0,[v224]);
const v225=true;
const v228=1n;
const v226=BigInt.asUintN(64,(a1)+(v228));
const v233=__node(0,[a3,a4]);
const v230=yield d_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[0],a2,v233);
const v229=__node(0,[v230]);
const v237=__node(0,[a3]);
const v239=__nullaryNode(0);
const v236=__node(1,[v237,v239]);
const v222=__node(0,[v223,v225,v226,v229,v236]);
v213=v222;}
v203=v213;}
v196=v203;}else{
const v241=2n;
const v243=__node(0,[a0.a[0]]);
const v240=__node(1,[v241,a1,v243]);
v196=v240;}
v189=v196;}else{
const v247=yield d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v246;switch(v247.c){
case 0:{
const v250=false;
v246=v250;break;}
case 1:{
const v251=true;
v246=v251;break;}
default:throw Error('literal constructor projection');}
let v245;if(v246){
const v253=2n;
const v255=__node(0,[a0.a[0]]);
const v252=__node(1,[v253,a1,v255]);
v245=v252;}else{
let v257;if(a5){
const v261=__nullaryNode(0);
const v260=__node(1,[v261]);
const v262=false;
const v264=__node(0,[a0.a[0]]);
const v266=__nullaryNode(0);
const v259=__node(0,[v260,v262,a1,v264,v266]);
v257=v259;}else{
const v270=18446744073709551615n;
const v268=(a1)===(v270);
let v267;if(v268){
const v272=1n;
const v274=__node(0,[a0.a[0]]);
const v271=__node(1,[v272,a1,v274]);
v267=v271;}else{
const v278=__nullaryNode(0);
const v277=__node(0,[v278]);
const v279=true;
const v282=1n;
const v280=BigInt.asUintN(64,(a1)+(v282));
const v287=__node(0,[a3,a4]);
const v284=yield d_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[0],a2,v287);
const v283=__node(0,[v284]);
const v291=__node(0,[a3]);
const v293=__nullaryNode(0);
const v290=__node(1,[v291,v293]);
const v276=__node(0,[v277,v279,v280,v283,v290]);
v267=v276;}
v257=v267;}
v245=v257;}
v189=v245;}
v187=v189;break;}
default:throw Error('literal constructor projection');}
return v187;}
function* d_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0){let v294;switch(a0.c){
case 0:{
const v296=__nullaryNode(0);
v294=v296;break;}
case 1:{
const v300=__nullaryNode(0);
const v297=__node(1,[a0.a[0],a0.a[1],v300]);
v294=v297;break;}
case 2:{
const v302=yield d_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[0]);
const v304=yield d_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[1]);
const v301=yield d_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(v302,v304);
v294=v301;break;}
default:throw Error('literal constructor projection');}
return v294;}
function* d_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0){let v306;switch(a0.c){
case 0:{
const v308=0n;
v306=v308;break;}
case 1:{
const v309=yield d_2937ee59437d4727fd243a664a281a6018453ca819aede4e91f0a7d9bda2ca12(a0.a[1]);
v306=v309;break;}
case 2:{
v306=a0.a[4];break;}
default:throw Error('literal constructor projection');}
return v306;}
function d_4d9946ad9a037d55daebbf6b4f332ecf1e985eca512336e0f0bb06e1d923e74d(a0){let v312;switch(a0.c){
case 0:{
v312=a0.a[3];break;}
case 1:{
v312=a0.a[2];break;}
default:throw Error('literal constructor projection');}
return v312;}
function* d_5772432f10e31d0ddf159e9ab757ef7042f15ed47699a0c380e996b8cda2529c(a0,a1){const v318=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v321=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v323=1n;
const v320=BigInt.asUintN(64,(v321)+(v323));
const v317=(v318)>(v320);
let v316;if(v317){
let v324;switch(a1.c){
case 0:{
const v326=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v324=v326;break;}
case 1:{
const v329=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v324=v329;break;}
case 2:{
const v332=yield d_14b1c60245cb25b6473dae8947e9201876796fa199c6cdd20ee3a2661b7317b0(a0,a1.a[0],a1.a[1]);
v324=v332;break;}
default:throw Error('literal constructor projection');}
v316=v324;}else{
const v336=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v316=v336;}
return v316;}
function* d_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0,a1){const v343=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v341=(a1)<(v343);
const v347=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v345=(a1)>(v347);
const v340=(v341)||(v345);
let v339;if(v340){
v339=a0;}else{
let v350;switch(a0.c){
case 0:{
const v352=__nullaryNode(0);
v350=v352;break;}
case 1:{
const v354=(a1)===(a0.a[0]);
let v353;if(v354){
const v357=__nullaryNode(0);
v353=v357;}else{
const v358=__node(1,[a0.a[0],a0.a[1]]);
v353=v358;}
v350=v353;break;}
case 2:{
const v362=yield d_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[0],a1);
const v365=yield d_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[1],a1);
const v361=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v362,v365);
v350=v361;break;}
default:throw Error('literal constructor projection');}
v339=v350;}
return v339;}
function* d_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1){let v368;switch(a0.c){
case 0:{
const v371=yield d_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0.a[0]);
const v373=false;
const v375=__node(0,[a0.a[0]]);
const v377=__nullaryNode(0);
const v370=__node(0,[v371,v373,a1,v375,v377]);
v368=v370;break;}
default:throw Error('literal constructor projection');}
return v368;}
function* d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0,a1){const v382=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v380=(a1)<(v382);
const v386=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v384=(a1)>(v386);
const v379=(v380)||(v384);
let v378;if(v379){
const v388=__nullaryNode(0);
v378=v388;}else{
let v389;switch(a0.c){
case 0:{
const v391=__nullaryNode(0);
v389=v391;break;}
case 1:{
const v393=(a1)===(a0.a[0]);
let v392;if(v393){
const v396=__node(1,[a0.a[1]]);
v392=v396;}else{
const v398=__nullaryNode(0);
v392=v398;}
v389=v392;break;}
case 2:{
const v400=yield d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a1);
const v403=yield d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[1],a1);
const v399=d_b786cd3d542360e36d11a412339399f2084fa0e5a8bec5ab1461e548f657f81d(v400,v403);
v389=v399;break;}
default:throw Error('literal constructor projection');}
v378=v389;}
return v378;}
function* d_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0){let v406;switch(a0.c){
case 0:{
const v408=__nullaryNode(0);
v406=v408;break;}
case 1:{
let v410;switch(a0.a[0].c){
case 0:{
v410=a0.a[0].a[1];break;}
default:throw Error('literal constructor projection');}
let v409;if(v410){
const v415=yield d_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0.a[1]);
const v413=__node(1,[a0.a[0],v415]);
v409=v413;}else{
const v417=yield d_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0.a[1]);
v409=v417;}
v406=v409;break;}
default:throw Error('literal constructor projection');}
return v406;}
function* d_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(a0){let v419;switch(a0.c){
case 0:{
const v421=__nullaryNode(0);
v419=v421;break;}
case 1:{
const v424=yield d_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(a0.a[2]);
const v422=__node(1,[a0.a[1],v424]);
v419=v422;break;}
default:throw Error('literal constructor projection');}
return v419;}
function* d_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(a0,a1){let v426;switch(a0.c){
case 0:{
v426=a1;break;}
case 1:{
const v432=yield d_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(a0.a[2],a1);
const v429=__node(1,[a0.a[0],a0.a[1],v432]);
v426=v429;break;}
default:throw Error('literal constructor projection');}
return v426;}
function* d_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(a0,a1,a2,a3){let v435;switch(a0.c){
case 0:{
let v437;if(a3){
const v441=__nullaryNode(0);
const v440=__node(1,[v441]);
const v442=false;
const v444=__node(0,[a0.a[0]]);
const v446=__nullaryNode(0);
const v439=__node(0,[v440,v442,a1,v444,v446]);
v437=v439;}else{
const v450=18446744073709551615n;
const v448=(a1)===(v450);
let v447;if(v448){
const v452=1n;
const v454=__node(0,[a0.a[0]]);
const v451=__node(1,[v452,a1,v454]);
v447=v451;}else{
const v458=__nullaryNode(0);
const v457=__node(0,[v458]);
const v459=true;
const v462=1n;
const v460=BigInt.asUintN(64,(a1)+(v462));
const v464=yield d_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[0],a2);
const v463=__node(0,[v464]);
const v468=__node(0,[a2]);
const v470=__nullaryNode(0);
const v467=__node(1,[v468,v470]);
const v456=__node(0,[v457,v459,v460,v463,v467]);
v447=v456;}
v437=v447;}
v435=v437;break;}
default:throw Error('literal constructor projection');}
return v435;}
function* d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0){let v471;switch(a0.c){
case 0:{
const v474=yield d_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[0]);
const v473=__node(0,[v474]);
v471=v473;break;}
default:throw Error('literal constructor projection');}
return v471;}
function d_b786cd3d542360e36d11a412339399f2084fa0e5a8bec5ab1461e548f657f81d(a0,a1){let v476;switch(a0.c){
case 0:{
v476=a1;break;}
case 1:{
const v479=__node(1,[a0.a[0]]);
v476=v479;break;}
default:throw Error('literal constructor projection');}
return v476;}
function* d_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0){let v481;switch(a0.c){
case 0:{
const v483=0n;
v481=v483;break;}
case 1:{
const v484=yield d_2a975b3a5fe826968db8619175ac9f0dfbf3be2c770a2eab7b9bb32e684cf01b(a0.a[1]);
v481=v484;break;}
case 2:{
v481=a0.a[5];break;}
default:throw Error('literal constructor projection');}
return v481;}
function* d_c7ad7bdf333846cfdaf9c1cef5bcc98d8b1f5a0ca3c654237e21162cd70e16f6(a0,a1,a2){const v489=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v491=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v488=(v489)<(v491);
let v487;if(v488){
let v493;switch(a1.c){
case 0:{
const v497=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v495=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v497);
v493=v495;break;}
case 1:{
const v502=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v500=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v502);
v493=v500;break;}
case 2:{
const v506=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1.a[0]);
const v509=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1.a[1],a2);
const v505=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v506,v509);
v493=v505;break;}
default:throw Error('literal constructor projection');}
v487=v493;}else{
const v514=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v512=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v514);
v487=v512;}
return v487;}
function d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0){let v517;switch(a0.c){
case 0:{
const v519=18446744073709551615n;
v517=v519;break;}
case 1:{
v517=a0.a[0];break;}
case 2:{
v517=a0.a[2];break;}
default:throw Error('literal constructor projection');}
return v517;}
function* d_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0,a1,a2){const v526=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v524=(a1)<(v526);
const v530=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v528=(a1)>(v530);
const v523=(v524)||(v528);
let v522;if(v523){
v522=a0;}else{
let v533;switch(a0.c){
case 0:{
const v535=__nullaryNode(0);
v533=v535;break;}
case 1:{
const v537=(a1)===(a0.a[0]);
let v536;if(v537){
const v540=__node(1,[a0.a[0],a2]);
v536=v540;}else{
const v543=__node(1,[a0.a[0],a0.a[1]]);
v536=v543;}
v533=v536;break;}
case 2:{
const v547=yield d_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[0],a1,a2);
const v551=yield d_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[1],a1,a2);
const v546=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v547,v551);
v533=v546;break;}
default:throw Error('literal constructor projection');}
v522=v533;}
return v522;}
function* d_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(a0,a1,a2){let v555;switch(a0.c){
case 0:{
const v557=__node(1,[a1,a2]);
v555=v557;break;}
case 1:{
const v561=__node(1,[a1,a2]);
const v564=__node(1,[a0.a[0],a0.a[1]]);
const v560=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v561,v564);
v555=v560;break;}
case 2:{
const v568=yield d_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(a0.a[0],a1,a2);
const v567=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v568,a0.a[1]);
v555=v567;break;}
default:throw Error('literal constructor projection');}
return v555;}
function* d_dd9122cd0ef5414b8f184fc5a412c2e0c7b9002cb5d701ef49dc7b9f5465679c(a0,a1){const v575=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v578=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v580=1n;
const v577=BigInt.asUintN(64,(v578)+(v580));
const v574=(v575)>(v577);
let v573;if(v574){
let v581;switch(a0.c){
case 0:{
const v583=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v581=v583;break;}
case 1:{
const v586=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v581=v586;break;}
case 2:{
const v589=yield d_c7ad7bdf333846cfdaf9c1cef5bcc98d8b1f5a0ca3c654237e21162cd70e16f6(a0.a[0],a0.a[1],a1);
v581=v589;break;}
default:throw Error('literal constructor projection');}
v573=v581;}else{
const v593=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v573=v593;}
return v573;}
function* d_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0){let v596;switch(a0.c){
case 0:{
const v598=__nullaryNode(0);
v596=v598;break;}
case 1:{
const v600=yield d_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0.a[2]);
const v599=yield d_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(v600,a0.a[0],a0.a[1]);
v596=v599;break;}
default:throw Error('literal constructor projection');}
return v596;}
function* d_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1){let v604;switch(a0.c){
case 0:{
const v607=yield d_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0.a[0]);
const v609=false;
const v611=__node(0,[a0.a[0]]);
const v613=__nullaryNode(0);
const v606=__node(0,[v607,v609,a1,v611,v613]);
v604=v606;break;}
default:throw Error('literal constructor projection');}
return v604;}
function* d_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(a0){let v614;switch(a0.c){
case 0:{
const v616=0n;
v614=v616;break;}
case 1:{
const v619=yield d_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(a0.a[1]);
const v617=BigInt.asUintN(64,(a0.a[0])+(v619));
v614=v617;break;}
default:throw Error('literal constructor projection');}
return v614;}
function* d_e76afcdc421fd94b92ff9f51242ab3db38cff4e5f27b705ee3645613843bcfc2(a0){let v621;switch(a0.c){
case 0:{
const v627=yield d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[3]);
const v623=__node(0,[a0.a[0],a0.a[1],a0.a[2],v627,a0.a[4]]);
v621=v623;break;}
case 1:{
const v633=yield d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[2]);
const v630=__node(1,[a0.a[0],a0.a[1],v633]);
v621=v630;break;}
default:throw Error('literal constructor projection');}
return v621;}
function* d_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0,a1,a2){let v635;switch(a0.c){
case 0:{
const v637=__node(1,[a1,a2]);
v635=v637;break;}
case 1:{
const v641=(a1)<(a0.a[0]);
let v640;if(v641){
const v645=__node(1,[a1,a2]);
const v648=__node(1,[a0.a[0],a0.a[1]]);
const v644=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v645,v648);
v640=v644;}else{
const v652=__node(1,[a0.a[0],a0.a[1]]);
const v655=__node(1,[a1,a2]);
const v651=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v652,v655);
v640=v651;}
v635=v640;break;}
case 2:{
const v661=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0.a[0]);
const v659=(a1)<(v661);
let v658;if(v659){
const v664=yield d_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[0],a1,a2);
const v663=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v664,a0.a[1]);
v658=v663;}else{
const v671=yield d_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[1],a1,a2);
const v669=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(a0.a[0],v671);
v658=v669;}
v635=v658;break;}
default:throw Error('literal constructor projection');}
return v635;}
function* d_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(a0){let v675;switch(a0.c){
case 0:{
const v677=0n;
v675=v677;break;}
case 1:{
const v680=yield d_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(a0.a[1]);
const v678=BigInt.asUintN(64,(a0.a[0])+(v680));
v675=v678;break;}
default:throw Error('literal constructor projection');}
return v675;}
function dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v5=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v7=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a1);
const v4=(v5)<(v7);
let v3;if(v4){
const v9=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
v3=v9;}else{
const v11=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a1);
v3=v11;}
const v15=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v17=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a1);
const v14=(v15)<(v17);
let v13;if(v14){
const v19=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a1);
v13=v19;}else{
const v21=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
v13=v21;}
const v24=dFast_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0);
const v26=dFast_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a1);
const v23=BigInt.asUintN(64,(v24)+(v26));
const v29=dFast_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0);
const v31=dFast_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a1);
const v28=BigInt.asUintN(64,(v29)+(v31));
const v36=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v38=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v35=(v36)<(v38);
let v34;if(v35){
const v40=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
v34=v40;}else{
const v42=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
v34=v42;}
const v44=1n;
const v33=BigInt.asUintN(64,(v34)+(v44));
const v0=__node(2,[a0,a1,v3,v13,v23,v28,v33]);
return v0;}finally{__directDepth--;}}
function dFast_14b1c60245cb25b6473dae8947e9201876796fa199c6cdd20ee3a2661b7317b0(a0,a1,a2){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v47=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a2);
const v49=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v46=(v47)<(v49);
let v45;if(v46){
let v51;switch(a1.c){
case 0:{
const v54=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v53=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v54,a2);
v51=v53;break;}
case 1:{
const v59=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v58=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v59,a2);
v51=v58;break;}
case 2:{
const v64=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1.a[0]);
const v67=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1.a[1],a2);
const v63=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v64,v67);
v51=v63;break;}
default:throw Error('literal constructor projection');}
v45=v51;}else{
const v71=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v70=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v71,a2);
v45=v70;}
return v45;}finally{__directDepth--;}}
function dFast_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v75;switch(a0.c){
case 0:{
const v77=__nullaryNode(0);
v75=v77;break;}
case 1:{
let v79;switch(a0.a[0].c){
case 0:{
v79=a0.a[0].a[1];break;}
default:throw Error('literal constructor projection');}
let v78;if(v79){
const v84=dFast_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0.a[1]);
const v82=__node(1,[a0.a[0],v84]);
v78=v82;}else{
const v86=dFast_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0.a[1]);
v78=v86;}
v75=v78;break;}
default:throw Error('literal constructor projection');}
return v75;}finally{__directDepth--;}}
function dFast_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v88;switch(a0.c){
case 0:{
const v90=__nullaryNode(0);
v88=v90;break;}
case 1:{
let v94;switch(a0.a[0].c){
case 0:{
v94=a0.a[0].a[0];break;}
default:throw Error('literal constructor projection');}
const v97=0n;
const v93=BigInt.asUintN(64,(v94)*(v97));
const v98=1n;
const v92=BigInt.asUintN(64,(v93)+(v98));
const v99=dFast_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(a0.a[1]);
const v91=__node(1,[v92,v99]);
v88=v91;break;}
default:throw Error('literal constructor projection');}
return v88;}finally{__directDepth--;}}
function dFast_2227a6ba7041bd43fcef1b26000ccf84bfe9666af2f812e03de515c517d771d0(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v101;switch(a0.c){
case 0:{
const v107=dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[3]);
const v103=__node(0,[a0.a[0],a0.a[1],a0.a[2],v107,a0.a[4]]);
v101=v103;break;}
case 1:{
const v113=dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[2]);
const v110=__node(1,[a0.a[0],a0.a[1],v113]);
v101=v110;break;}
default:throw Error('literal constructor projection');}
return v101;}finally{__directDepth--;}}
function dFast_2937ee59437d4727fd243a664a281a6018453ca819aede4e91f0a7d9bda2ca12(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v120=0n;
const v122=__nullaryNode(0);
const v119=__node(1,[v120,a0,v122]);
const v118=dFast_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(v119);
const v117=dFast_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(v118);
const v116=dFast_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(v117);
const v115=dFast_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(v116);
return v115;}finally{__directDepth--;}}
function dFast_2a975b3a5fe826968db8619175ac9f0dfbf3be2c770a2eab7b9bb32e684cf01b(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v128=0n;
const v130=__nullaryNode(0);
const v127=__node(1,[v128,a0,v130]);
const v126=dFast_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(v127);
const v125=dFast_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(v126);
const v124=dFast_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(v125);
const v123=dFast_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(v124);
return v123;}finally{__directDepth--;}}
function dFast_2d15d039af07da09e966dbb56adcd73b313da516d054674d5f55c495085b08bd(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v131;switch(a0.c){
case 0:{
const v137=dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[3]);
const v133=__node(0,[a0.a[0],a0.a[1],a0.a[2],v137,a0.a[4]]);
v131=v133;break;}
case 1:{
const v143=dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[2]);
const v140=__node(1,[a0.a[0],a0.a[1],v143]);
v131=v140;break;}
default:throw Error('literal constructor projection');}
return v131;}finally{__directDepth--;}}
function dFast_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v145;switch(a0.c){
case 0:{
const v148=dFast_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0.a[0]);
const v147=__node(0,[v148]);
v145=v147;break;}
default:throw Error('literal constructor projection');}
return v145;}finally{__directDepth--;}}
function dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v152=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v155=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v157=1n;
const v154=BigInt.asUintN(64,(v155)+(v157));
const v151=(v152)>(v154);
let v150;if(v151){
const v158=dFast_dd9122cd0ef5414b8f184fc5a412c2e0c7b9002cb5d701ef49dc7b9f5465679c(a0,a1);
v150=v158;}else{
const v161=dFast_5772432f10e31d0ddf159e9ab757ef7042f15ed47699a0c380e996b8cda2529c(a0,a1);
v150=v161;}
return v150;}finally{__directDepth--;}}
function dFast_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v164;switch(a0.c){
case 0:{
const v166=__nullaryNode(0);
v164=v166;break;}
case 1:{
let v168;switch(a0.a[0].c){
case 0:{
v168=a0.a[0].a[0];break;}
default:throw Error('literal constructor projection');}
const v171=dFast_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(a0.a[1]);
const v167=__node(1,[v168,v171]);
v164=v167;break;}
default:throw Error('literal constructor projection');}
return v164;}finally{__directDepth--;}}
function dFast_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(a0,a1,a2,a3,a4,a5){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v173;switch(a0.c){
case 0:{
const v177=dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v176;switch(v177.c){
case 0:{
const v180=false;
v176=v180;break;}
case 1:{
const v181=true;
v176=v181;break;}
default:throw Error('literal constructor projection');}
let v175;if(v176){
const v184=dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v183;switch(v184.c){
case 0:{
const v187=false;
v183=v187;break;}
case 1:{
const v188=true;
v183=v188;break;}
default:throw Error('literal constructor projection');}
let v182;if(v183){
let v189;if(a5){
const v193=__nullaryNode(0);
const v192=__node(1,[v193]);
const v194=false;
const v196=__node(0,[a0.a[0]]);
const v198=__nullaryNode(0);
const v191=__node(0,[v192,v194,a1,v196,v198]);
v189=v191;}else{
const v202=18446744073709551615n;
const v200=(a1)===(v202);
let v199;if(v200){
const v204=1n;
const v206=__node(0,[a0.a[0]]);
const v203=__node(1,[v204,a1,v206]);
v199=v203;}else{
const v210=__nullaryNode(0);
const v209=__node(0,[v210]);
const v211=true;
const v214=1n;
const v212=BigInt.asUintN(64,(a1)+(v214));
const v219=__node(0,[a3,a4]);
const v216=dFast_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[0],a2,v219);
const v215=__node(0,[v216]);
const v223=__node(0,[a3]);
const v225=__nullaryNode(0);
const v222=__node(1,[v223,v225]);
const v208=__node(0,[v209,v211,v212,v215,v222]);
v199=v208;}
v189=v199;}
v182=v189;}else{
const v227=2n;
const v229=__node(0,[a0.a[0]]);
const v226=__node(1,[v227,a1,v229]);
v182=v226;}
v175=v182;}else{
const v233=dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v232;switch(v233.c){
case 0:{
const v236=false;
v232=v236;break;}
case 1:{
const v237=true;
v232=v237;break;}
default:throw Error('literal constructor projection');}
let v231;if(v232){
const v239=2n;
const v241=__node(0,[a0.a[0]]);
const v238=__node(1,[v239,a1,v241]);
v231=v238;}else{
let v243;if(a5){
const v247=__nullaryNode(0);
const v246=__node(1,[v247]);
const v248=false;
const v250=__node(0,[a0.a[0]]);
const v252=__nullaryNode(0);
const v245=__node(0,[v246,v248,a1,v250,v252]);
v243=v245;}else{
const v256=18446744073709551615n;
const v254=(a1)===(v256);
let v253;if(v254){
const v258=1n;
const v260=__node(0,[a0.a[0]]);
const v257=__node(1,[v258,a1,v260]);
v253=v257;}else{
const v264=__nullaryNode(0);
const v263=__node(0,[v264]);
const v265=true;
const v268=1n;
const v266=BigInt.asUintN(64,(a1)+(v268));
const v273=__node(0,[a3,a4]);
const v270=dFast_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[0],a2,v273);
const v269=__node(0,[v270]);
const v277=__node(0,[a3]);
const v279=__nullaryNode(0);
const v276=__node(1,[v277,v279]);
const v262=__node(0,[v263,v265,v266,v269,v276]);
v253=v262;}
v243=v253;}
v231=v243;}
v175=v231;}
v173=v175;break;}
default:throw Error('literal constructor projection');}
return v173;}finally{__directDepth--;}}
function dFast_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v280;switch(a0.c){
case 0:{
const v282=__nullaryNode(0);
v280=v282;break;}
case 1:{
const v286=__nullaryNode(0);
const v283=__node(1,[a0.a[0],a0.a[1],v286]);
v280=v283;break;}
case 2:{
const v288=dFast_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[0]);
const v290=dFast_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[1]);
const v287=dFast_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(v288,v290);
v280=v287;break;}
default:throw Error('literal constructor projection');}
return v280;}finally{__directDepth--;}}
function dFast_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v292;switch(a0.c){
case 0:{
const v294=0n;
v292=v294;break;}
case 1:{
const v295=dFast_2937ee59437d4727fd243a664a281a6018453ca819aede4e91f0a7d9bda2ca12(a0.a[1]);
v292=v295;break;}
case 2:{
v292=a0.a[4];break;}
default:throw Error('literal constructor projection');}
return v292;}finally{__directDepth--;}}
function dFast_5772432f10e31d0ddf159e9ab757ef7042f15ed47699a0c380e996b8cda2529c(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v300=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v303=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v305=1n;
const v302=BigInt.asUintN(64,(v303)+(v305));
const v299=(v300)>(v302);
let v298;if(v299){
let v306;switch(a1.c){
case 0:{
const v308=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v306=v308;break;}
case 1:{
const v311=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v306=v311;break;}
case 2:{
const v314=dFast_14b1c60245cb25b6473dae8947e9201876796fa199c6cdd20ee3a2661b7317b0(a0,a1.a[0],a1.a[1]);
v306=v314;break;}
default:throw Error('literal constructor projection');}
v298=v306;}else{
const v318=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v298=v318;}
return v298;}finally{__directDepth--;}}
function dFast_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v325=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v323=(a1)<(v325);
const v329=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v327=(a1)>(v329);
const v322=(v323)||(v327);
let v321;if(v322){
v321=a0;}else{
let v332;switch(a0.c){
case 0:{
const v334=__nullaryNode(0);
v332=v334;break;}
case 1:{
const v336=(a1)===(a0.a[0]);
let v335;if(v336){
const v339=__nullaryNode(0);
v335=v339;}else{
const v340=__node(1,[a0.a[0],a0.a[1]]);
v335=v340;}
v332=v335;break;}
case 2:{
const v344=dFast_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[0],a1);
const v347=dFast_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[1],a1);
const v343=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v344,v347);
v332=v343;break;}
default:throw Error('literal constructor projection');}
v321=v332;}
return v321;}finally{__directDepth--;}}
function dFast_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v350;switch(a0.c){
case 0:{
const v353=dFast_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0.a[0]);
const v355=false;
const v357=__node(0,[a0.a[0]]);
const v359=__nullaryNode(0);
const v352=__node(0,[v353,v355,a1,v357,v359]);
v350=v352;break;}
default:throw Error('literal constructor projection');}
return v350;}finally{__directDepth--;}}
function dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v364=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v362=(a1)<(v364);
const v368=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v366=(a1)>(v368);
const v361=(v362)||(v366);
let v360;if(v361){
const v370=__nullaryNode(0);
v360=v370;}else{
let v371;switch(a0.c){
case 0:{
const v373=__nullaryNode(0);
v371=v373;break;}
case 1:{
const v375=(a1)===(a0.a[0]);
let v374;if(v375){
const v378=__node(1,[a0.a[1]]);
v374=v378;}else{
const v380=__nullaryNode(0);
v374=v380;}
v371=v374;break;}
case 2:{
const v382=dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a1);
const v385=dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[1],a1);
const v381=d_b786cd3d542360e36d11a412339399f2084fa0e5a8bec5ab1461e548f657f81d(v382,v385);
v371=v381;break;}
default:throw Error('literal constructor projection');}
v360=v371;}
return v360;}finally{__directDepth--;}}
function dFast_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v388;switch(a0.c){
case 0:{
const v390=__nullaryNode(0);
v388=v390;break;}
case 1:{
let v392;switch(a0.a[0].c){
case 0:{
v392=a0.a[0].a[1];break;}
default:throw Error('literal constructor projection');}
let v391;if(v392){
const v397=dFast_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0.a[1]);
const v395=__node(1,[a0.a[0],v397]);
v391=v395;}else{
const v399=dFast_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0.a[1]);
v391=v399;}
v388=v391;break;}
default:throw Error('literal constructor projection');}
return v388;}finally{__directDepth--;}}
function dFast_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v401;switch(a0.c){
case 0:{
const v403=__nullaryNode(0);
v401=v403;break;}
case 1:{
const v406=dFast_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(a0.a[2]);
const v404=__node(1,[a0.a[1],v406]);
v401=v404;break;}
default:throw Error('literal constructor projection');}
return v401;}finally{__directDepth--;}}
function dFast_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v408;switch(a0.c){
case 0:{
v408=a1;break;}
case 1:{
const v414=dFast_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(a0.a[2],a1);
const v411=__node(1,[a0.a[0],a0.a[1],v414]);
v408=v411;break;}
default:throw Error('literal constructor projection');}
return v408;}finally{__directDepth--;}}
function dFast_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(a0,a1,a2,a3){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v417;switch(a0.c){
case 0:{
let v419;if(a3){
const v423=__nullaryNode(0);
const v422=__node(1,[v423]);
const v424=false;
const v426=__node(0,[a0.a[0]]);
const v428=__nullaryNode(0);
const v421=__node(0,[v422,v424,a1,v426,v428]);
v419=v421;}else{
const v432=18446744073709551615n;
const v430=(a1)===(v432);
let v429;if(v430){
const v434=1n;
const v436=__node(0,[a0.a[0]]);
const v433=__node(1,[v434,a1,v436]);
v429=v433;}else{
const v440=__nullaryNode(0);
const v439=__node(0,[v440]);
const v441=true;
const v444=1n;
const v442=BigInt.asUintN(64,(a1)+(v444));
const v446=dFast_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[0],a2);
const v445=__node(0,[v446]);
const v450=__node(0,[a2]);
const v452=__nullaryNode(0);
const v449=__node(1,[v450,v452]);
const v438=__node(0,[v439,v441,v442,v445,v449]);
v429=v438;}
v419=v429;}
v417=v419;break;}
default:throw Error('literal constructor projection');}
return v417;}finally{__directDepth--;}}
function dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v453;switch(a0.c){
case 0:{
const v456=dFast_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[0]);
const v455=__node(0,[v456]);
v453=v455;break;}
default:throw Error('literal constructor projection');}
return v453;}finally{__directDepth--;}}
function dFast_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v458;switch(a0.c){
case 0:{
const v460=0n;
v458=v460;break;}
case 1:{
const v461=dFast_2a975b3a5fe826968db8619175ac9f0dfbf3be2c770a2eab7b9bb32e684cf01b(a0.a[1]);
v458=v461;break;}
case 2:{
v458=a0.a[5];break;}
default:throw Error('literal constructor projection');}
return v458;}finally{__directDepth--;}}
function dFast_c7ad7bdf333846cfdaf9c1cef5bcc98d8b1f5a0ca3c654237e21162cd70e16f6(a0,a1,a2){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v466=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v468=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v465=(v466)<(v468);
let v464;if(v465){
let v470;switch(a1.c){
case 0:{
const v474=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v472=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v474);
v470=v472;break;}
case 1:{
const v479=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v477=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v479);
v470=v477;break;}
case 2:{
const v483=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1.a[0]);
const v486=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1.a[1],a2);
const v482=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v483,v486);
v470=v482;break;}
default:throw Error('literal constructor projection');}
v464=v470;}else{
const v491=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v489=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v491);
v464=v489;}
return v464;}finally{__directDepth--;}}
function dFast_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0,a1,a2){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v498=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v496=(a1)<(v498);
const v502=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v500=(a1)>(v502);
const v495=(v496)||(v500);
let v494;if(v495){
v494=a0;}else{
let v505;switch(a0.c){
case 0:{
const v507=__nullaryNode(0);
v505=v507;break;}
case 1:{
const v509=(a1)===(a0.a[0]);
let v508;if(v509){
const v512=__node(1,[a0.a[0],a2]);
v508=v512;}else{
const v515=__node(1,[a0.a[0],a0.a[1]]);
v508=v515;}
v505=v508;break;}
case 2:{
const v519=dFast_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[0],a1,a2);
const v523=dFast_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[1],a1,a2);
const v518=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v519,v523);
v505=v518;break;}
default:throw Error('literal constructor projection');}
v494=v505;}
return v494;}finally{__directDepth--;}}
function dFast_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(a0,a1,a2){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v527;switch(a0.c){
case 0:{
const v529=__node(1,[a1,a2]);
v527=v529;break;}
case 1:{
const v533=__node(1,[a1,a2]);
const v536=__node(1,[a0.a[0],a0.a[1]]);
const v532=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v533,v536);
v527=v532;break;}
case 2:{
const v540=dFast_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(a0.a[0],a1,a2);
const v539=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v540,a0.a[1]);
v527=v539;break;}
default:throw Error('literal constructor projection');}
return v527;}finally{__directDepth--;}}
function dFast_dd9122cd0ef5414b8f184fc5a412c2e0c7b9002cb5d701ef49dc7b9f5465679c(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v547=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v550=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v552=1n;
const v549=BigInt.asUintN(64,(v550)+(v552));
const v546=(v547)>(v549);
let v545;if(v546){
let v553;switch(a0.c){
case 0:{
const v555=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v553=v555;break;}
case 1:{
const v558=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v553=v558;break;}
case 2:{
const v561=dFast_c7ad7bdf333846cfdaf9c1cef5bcc98d8b1f5a0ca3c654237e21162cd70e16f6(a0.a[0],a0.a[1],a1);
v553=v561;break;}
default:throw Error('literal constructor projection');}
v545=v553;}else{
const v565=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v545=v565;}
return v545;}finally{__directDepth--;}}
function dFast_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v568;switch(a0.c){
case 0:{
const v570=__nullaryNode(0);
v568=v570;break;}
case 1:{
const v572=dFast_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0.a[2]);
const v571=dFast_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(v572,a0.a[0],a0.a[1]);
v568=v571;break;}
default:throw Error('literal constructor projection');}
return v568;}finally{__directDepth--;}}
function dFast_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v576;switch(a0.c){
case 0:{
const v579=dFast_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0.a[0]);
const v581=false;
const v583=__node(0,[a0.a[0]]);
const v585=__nullaryNode(0);
const v578=__node(0,[v579,v581,a1,v583,v585]);
v576=v578;break;}
default:throw Error('literal constructor projection');}
return v576;}finally{__directDepth--;}}
function dFast_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v586;switch(a0.c){
case 0:{
const v588=0n;
v586=v588;break;}
case 1:{
const v591=dFast_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(a0.a[1]);
const v589=BigInt.asUintN(64,(a0.a[0])+(v591));
v586=v589;break;}
default:throw Error('literal constructor projection');}
return v586;}finally{__directDepth--;}}
function dFast_e76afcdc421fd94b92ff9f51242ab3db38cff4e5f27b705ee3645613843bcfc2(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v593;switch(a0.c){
case 0:{
const v599=dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[3]);
const v595=__node(0,[a0.a[0],a0.a[1],a0.a[2],v599,a0.a[4]]);
v593=v595;break;}
case 1:{
const v605=dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[2]);
const v602=__node(1,[a0.a[0],a0.a[1],v605]);
v593=v602;break;}
default:throw Error('literal constructor projection');}
return v593;}finally{__directDepth--;}}
function dFast_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0,a1,a2){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v607;switch(a0.c){
case 0:{
const v609=__node(1,[a1,a2]);
v607=v609;break;}
case 1:{
const v613=(a1)<(a0.a[0]);
let v612;if(v613){
const v617=__node(1,[a1,a2]);
const v620=__node(1,[a0.a[0],a0.a[1]]);
const v616=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v617,v620);
v612=v616;}else{
const v624=__node(1,[a0.a[0],a0.a[1]]);
const v627=__node(1,[a1,a2]);
const v623=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v624,v627);
v612=v623;}
v607=v612;break;}
case 2:{
const v633=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0.a[0]);
const v631=(a1)<(v633);
let v630;if(v631){
const v636=dFast_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[0],a1,a2);
const v635=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v636,a0.a[1]);
v630=v635;}else{
const v643=dFast_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[1],a1,a2);
const v641=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(a0.a[0],v643);
v630=v641;}
v607=v630;break;}
default:throw Error('literal constructor projection');}
return v607;}finally{__directDepth--;}}
function dFast_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v647;switch(a0.c){
case 0:{
const v649=0n;
v647=v649;break;}
case 1:{
const v652=dFast_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(a0.a[1]);
const v650=BigInt.asUintN(64,(a0.a[0])+(v652));
v647=v650;break;}
default:throw Error('literal constructor projection');}
return v647;}finally{__directDepth--;}}
function f_186b6350f974a9daf5c57b97446437bb2cabe2a9241d8e38d84e02980089fef8(a0){return d_186b6350f974a9daf5c57b97446437bb2cabe2a9241d8e38d84e02980089fef8(a0);}
function f_2227a6ba7041bd43fcef1b26000ccf84bfe9666af2f812e03de515c517d771d0(a0){try{return dFast_2227a6ba7041bd43fcef1b26000ccf84bfe9666af2f812e03de515c517d771d0(a0);}catch(error){if(error!==__deepCall)throw error;return __run(d_2227a6ba7041bd43fcef1b26000ccf84bfe9666af2f812e03de515c517d771d0(a0));}}
function f_2d15d039af07da09e966dbb56adcd73b313da516d054674d5f55c495085b08bd(a0){try{return dFast_2d15d039af07da09e966dbb56adcd73b313da516d054674d5f55c495085b08bd(a0);}catch(error){if(error!==__deepCall)throw error;return __run(d_2d15d039af07da09e966dbb56adcd73b313da516d054674d5f55c495085b08bd(a0));}}
function f_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(a0){try{return dFast_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(a0);}catch(error){if(error!==__deepCall)throw error;return __run(d_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(a0));}}
function f_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(a0,a1,a2,a3,a4,a5){try{return dFast_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(a0,a1,a2,a3,a4,a5);}catch(error){if(error!==__deepCall)throw error;return __run(d_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(a0,a1,a2,a3,a4,a5));}}
function f_4d9946ad9a037d55daebbf6b4f332ecf1e985eca512336e0f0bb06e1d923e74d(a0){return d_4d9946ad9a037d55daebbf6b4f332ecf1e985eca512336e0f0bb06e1d923e74d(a0);}
function f_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1){try{return dFast_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1);}catch(error){if(error!==__deepCall)throw error;return __run(d_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1));}}
function f_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(a0,a1,a2,a3){try{return dFast_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(a0,a1,a2,a3);}catch(error){if(error!==__deepCall)throw error;return __run(d_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(a0,a1,a2,a3));}}
function f_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0){try{return dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0);}catch(error){if(error!==__deepCall)throw error;return __run(d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0));}}
function f_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1){try{return dFast_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1);}catch(error){if(error!==__deepCall)throw error;return __run(d_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1));}}
function f_e76afcdc421fd94b92ff9f51242ab3db38cff4e5f27b705ee3645613843bcfc2(a0){try{return dFast_e76afcdc421fd94b92ff9f51242ab3db38cff4e5f27b705ee3645613843bcfc2(a0);}catch(error){if(error!==__deepCall)throw error;return __run(d_e76afcdc421fd94b92ff9f51242ab3db38cff4e5f27b705ee3645613843bcfc2(a0));}}
const __encoder=new TextEncoder();
function __keyCompare(a,b){if(typeof a==='string'&&typeof b==='string'){const x=__encoder.encode(a),y=__encoder.encode(b);for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]<y[i]?-1:1;return x.length-y.length;}return a<b?-1:a>b?1:0;}

// Portable snapshot ABI shared with native/Wasm. Hashing uses Web Crypto.
function __snapshotLimits(limits={}){
 const result={bytes:64*1024*1024,values:1000000,depth:128,...limits};
 for(const k of ['bytes','values','depth'])if(!Number.isSafeInteger(result[k])||result[k]<0||result[k]>(k==='depth'?128:k==='values'?1000000:64*1024*1024))throw Error('invalid snapshot limits');
 return result;
}
const __hash=async bytes=>new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256',bytes));
function __snapshotWriter(limits){
 const out=[];let left=limits.values;
 function bytes(xs){if(xs.length>limits.bytes-out.length)throw Error('snapshot byte limit exceeded');for(const x of xs)out.push(x);}
 function integer(n,size){n=BigInt(n);for(let i=0;i<size;i++){bytes([Number(n&255n)]);n>>=8n;}}
 function raw(xs){integer(xs.length,8);bytes(xs);}
 function value(v,t,depth=0,bindings=[]){if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{value(v,t.body,depth+1,bindings);}finally{bindings.pop();}break;
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');value(v,bound[1],depth+1,bindings);break;}
  case 'unit':break;case 'bool':bytes([v?1:0]);break;
  case 'u32':case 'i32':case 'f32':integer(v,4);break;case 'u64':integer(v,8);break;
  case 'vector':if(v.length!==t.size)throw Error('vector dimension mismatch');for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'int':{let n=v<0n?-v:v;const xs=[];while(n){if(xs.length>=4096)throw Error('snapshot Int exceeds size limit');xs.push(Number(n&255n));n>>=8n;}bytes([v===0n?0:v>0n?1:2]);raw(xs);break;}
  case 'string':raw(__encoder.encode(v));break;
  case 'id':integer(BigInt('0x'+v),16);break;
  case 'enum':integer(t.variants.indexOf(v),4);break;
  case 'record':for(const f of t.fields)value(v[f.name],f.type,depth+1,bindings);break;
  case 'list':if(v.length>left)throw Error('snapshot value limit exceeded');integer(v.length,8);for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'option':if(Object.hasOwn(v,'Some')){bytes([1]);value(v.Some,t.element,depth+1,bindings);}else bytes([0]);break;
  case 'result':if(Object.hasOwn(v,'Ok')){bytes([0]);value(v.Ok,t.ok,depth+1,bindings);}else{bytes([1]);value(v.Err,t.error,depth+1,bindings);}break;
  default:throw Error('unsupported snapshot type');
 }}
 return {bytes,integer,raw,value,get left(){return left;},finish:()=>new Uint8Array(out)};
}
async function __snapshotEncode(meta,state,options){
 const limits=__snapshotLimits(options),w=__snapshotWriter(limits);
 w.integer(state.version,8);
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const rows=[...state.tables[r.index].entries()].sort((a,b)=>__keyCompare(a[0],b[0],r.key));if(rows.length>Math.floor(w.left/2))throw Error('snapshot row limit exceeded');w.integer(rows.length,8);for(const [k,v]of rows){w.value(k,r.snapshotKey??r.key);w.value(v,r.snapshotValue??r.value);}}
 w.integer(state.outbox.length,8);
 for(const e of state.outbox){const channel=meta.events.findIndex(t=>t.name===e.channel);w.integer(e.commit,8);w.integer(e.position,8);w.integer(channel,4);w.value(e.value,meta.events[channel].snapshotType??meta.events[channel].type);}
 const payload=w.finish(),header=__snapshotWriter(limits);header.bytes([86,76,83,84,65,84,69,0,1,0,1,0]);header.bytes(meta.snapshot.program);header.bytes(meta.snapshot.schema);header.integer(payload.length,8);header.bytes(payload);
 const bytes=header.finish();if(bytes.length+32>limits.bytes)throw Error('snapshot byte limit exceeded');const digest=await __hash(bytes);const result=new Uint8Array(bytes.length+32);result.set(bytes);result.set(digest,bytes.length);return result;
}
async function __snapshotDecode(meta,input,options){
 const limits=__snapshotLimits(options);
 if(!(input instanceof Uint8Array)&&!Array.isArray(input))throw Error('expected snapshot bytes');
 if(input.length>limits.bytes||input.length<116)throw Error('snapshot byte length invalid');
 if(Array.isArray(input)&&input.some(b=>!Number.isInteger(b)||b<0||b>255))throw Error('invalid snapshot bytes');
 const bytes=new Uint8Array(input); // capture before asynchronous integrity work
 function same(a,b){return a.length===b.length&&a.every((v,i)=>v===b[i]);}
 if(!same(bytes.subarray(0,12),[86,76,83,84,65,84,69,0,1,0,1,0]))throw Error('snapshot format or semantics version mismatch');
 if(!same(bytes.subarray(12,44),meta.snapshot.program)||!same(bytes.subarray(44,76),meta.snapshot.schema))throw Error('snapshot program or schema identity mismatch');
 const end=bytes.length-32,digest=await __hash(bytes.subarray(0,end));if(!same(digest,bytes.subarray(end)))throw Error('snapshot integrity check failed');
 let at=76,left=limits.values;
 function take(n){if(!Number.isSafeInteger(n)||n<0||n>end-at)throw Error('truncated snapshot');const x=bytes.subarray(at,at+n);at+=n;return x;}
 function integer(size){const xs=take(size);let n=0n;for(let i=size-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return n;}
 function length(){const n=integer(8);if(n>BigInt(Number.MAX_SAFE_INTEGER))throw Error('snapshot length not addressable');return Number(n);}
 function sequence(){const n=length();if(n>left)throw Error('snapshot value limit exceeded');return n;}
 function raw(){return take(length());}
 const n=length();if(n!==end-84)throw Error('snapshot payload length mismatch');
 function value(t,depth=0,bindings=[]){if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{return value(t.body,depth+1,bindings);}finally{bindings.pop();}
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');return value(bound[1],depth+1,bindings);}
  case 'unit':return null;case 'bool':{const b=take(1)[0];if(b>1)throw Error('invalid Bool tag');return b===1;}
  case 'u32':case 'f32':return Number(integer(4));case 'i32':return Number(BigInt.asIntN(32,integer(4)));case 'u64':return integer(8);
  case 'vector':{const xs=[];for(let i=0;i<t.size;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'int':{const sign=take(1)[0],xs=raw();if(xs.length>4096)throw Error('snapshot Int exceeds size limit');if(!((sign===0&&xs.length===0)||((sign===1||sign===2)&&xs.length>0&&xs[xs.length-1]!==0)))throw Error('noncanonical signed integer');let n=0n;for(let i=xs.length-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return sign===2?-n:n;}
  case 'string':return new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(raw());
  case 'id':return integer(16).toString(16).padStart(32,'0');
  case 'enum':{const i=Number(integer(4));if(i>=t.variants.length)throw Error('invalid enum tag');return t.variants[i];}
  case 'record':return Object.fromEntries(t.fields.map(f=>[f.name,value(f.type,depth+1,bindings)]));
  case 'list':{const n=sequence(),xs=[];for(let i=0;i<n;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'option':{const tag=take(1)[0];if(tag===0)return {None:null};if(tag===1)return {Some:value(t.element,depth+1,bindings)};throw Error('invalid Option tag');}
  case 'result':{const tag=take(1)[0];if(tag===0)return {Ok:value(t.ok,depth+1,bindings)};if(tag===1)return {Err:value(t.error,depth+1,bindings)};throw Error('invalid Result tag');}
  default:throw Error('unsupported snapshot type');
 }}
 const version=integer(8),tables=meta.roots.map(()=>new Map());
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const n=sequence();if(n>Math.floor(left/2))throw Error('snapshot row limit exceeded');let prior;for(let i=0;i<n;i++){const k=value(r.snapshotKey??r.key),v=value(r.snapshotValue??r.value);if(i&&__keyCompare(prior,k,r.key)>=0)throw Error('duplicate or unordered snapshot key');tables[r.index].set(k,v);prior=k;}}
 const count=sequence(),outbox=[];let prior;
 for(let i=0;i<count;i++){const commit=integer(8),position=integer(8),channel=Number(integer(4));if(!meta.events[channel])throw Error('unknown snapshot event channel');const v=value(meta.events[channel].snapshotType??meta.events[channel].type);if(commit===0n||commit>version||(prior&&(commit<prior.commit||(commit===prior.commit&&position<=prior.position))))throw Error('invalid snapshot event sequence');const e={commit,position,channel:meta.events[channel].name,value:v};outbox.push(e);prior=e;}
 if(at!==end)throw Error('trailing snapshot payload');return {version,tables,outbox};
}
function read_0(v,d=0,internal=false){return v;}
function write_0(v,d=0,snapshot=false){return v;}
function read_1(v,d=0,internal=false){return v;}
function write_1(v,d=0,snapshot=false){return v;}
function read_2(v,d=0,internal=false){return __node(0,[]);}
function write_2(v,d=0,snapshot=false){return null;}
function read_3(v,d=0,internal=false){let tail=__node(0,[]);for(let i=v.length-1;i>=0;i--)tail=__node(1,[read_1(v[i],d+1,internal),tail]);return tail;}
function write_3(v,d=0,snapshot=false){let cursor=v;const xs=[];while(cursor.c!==0){xs.push(write_1(cursor.a[0],d+1,snapshot));cursor=cursor.a[1];}return xs;}
function read_4(v,d=0,internal=false){let tail=__node(0,[]);for(let i=v.length-1;i>=0;i--)tail=__node(1,[read_6(v[i],d+1,internal),tail]);return tail;}
function write_4(v,d=0,snapshot=false){let cursor=v;const xs=[];while(cursor.c!==0){xs.push(write_6(cursor.a[0],d+1,snapshot));cursor=cursor.a[1];}return xs;}
function read_5(v,d=0,internal=false){switch(v){case "Error.Failed":return __node(0,[]);default:return undefined;}}
function write_5(v,d=0,snapshot=false){return ["Error.Failed"][v.c];}
function read_6(v,d=0,internal=false){return __node(0,[read_1(v["value"],d+1,internal),read_0(v["active"],d+1,internal)]);}
function write_6(v,d=0,snapshot=false){return Object.fromEntries([["value",write_1(v.a[0],d+1,snapshot)],["active",write_0(v.a[1],d+1,snapshot)]]);}
function read_7(v,d=0,internal=false){if(Object.hasOwn(v,'Some'))return __node(1,[read_6(v.Some,d+1,internal)]);return __node(0,[]);}
function write_7(v,d=0,snapshot=false){return v.c===0?{None:null}:{Some:write_6(v.a[0],d+1,snapshot)};}
function read_8(v,d=0,internal=false){if(Object.hasOwn(v,'Ok'))return __node(0,[read_2(v.Ok,d+1,internal)]);return __node(1,[read_5(v.Err,d+1,internal)]);}
function write_8(v,d=0,snapshot=false){return v.c===0?{Ok:write_2(v.a[0],d+1,snapshot)}:{Err:write_5(v.a[0],d+1,snapshot)};}
const __meta={"events":[{"name":"seen","snapshotType":{"kind":"u64"},"type":{"kind":"u64"}}],"roots":[{"key":{"kind":"u64"},"name":"Rows","snapshotKey":{"kind":"u64"},"snapshotValue":{"fields":[{"name":"value","type":{"kind":"u64"}},{"name":"active","type":{"kind":"bool"}}],"kind":"record"},"value":{"fields":[{"name":"value","type":{"kind":"u64"}},{"name":"active","type":{"kind":"bool"}}],"kind":"record","name":"Row"}}],"snapshot":{"program":[52,20,97,227,197,216,139,58,45,98,73,196,205,50,83,26,202,227,210,13,109,164,33,109,207,238,49,79,213,123,165,218],"schema":[217,47,159,252,204,85,237,70,76,82,248,36,231,99,128,206,40,43,134,247,81,235,124,169,208,7,125,5,136,138,247,164]}};
function __fromTables(tables){const roots=[];
{const rows=[...tables[0].entries()];let prior,tail=__node(0,[]);for(let j=rows.length-1;j>=0;j--){const [key,value]=rows[j];tail=__node(1,[read_1(key,0,true),read_6(value,0,true),tail]);}roots.push(tail);}
return __node(0,roots);}
function __tables(logical){const tables=[];
{let cursor=logical.a[0],prior;const rows=new Map();while(cursor.c!==0){const [key,value,tail]=cursor.a;rows.set(write_1(key,0,true),write_6(value,0,true));cursor=tail;}tables.push(rows);}
return tables;}
function __events(list){const events=[];let cursor=list;while(cursor.c!==0){const [event,tail]=cursor.a;switch(event.c){
case 0:events.push(["seen", write_1(event.a[0],0,true), write_1(event.a[0],0,false)]);break;
default:throw Error('unknown source event');}cursor=tail;}return events;}
// CALLER CONTRACT: arguments must have declared types and canonical values.
// Malformed data may throw, produce wrong results or corrupt state.
export function createState(){let version=0n,outbox=[],busy=false,transaction=null;
const initial=__node(0,[__node(0,[])]);let physical=f_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(initial);
const preconditions={};
function boundary(){if(busy)throw Error('state operation already in progress');}
function invoke_native(name,args,resultOnly=false){boundary();if(preconditions[name] && invoke_native(preconditions[name],args,true)!==true)throw Error('contract precondition failed');switch(name){
case "put":{
const a0=read_1(args[0],0);
const a1=read_1(args[1],0);
const a2=read_0(args[2],0);
const a3=read_0(args[3],0);
const executed=f_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(physical,version,a0,a1,a2,a3);const observed=f_e76afcdc421fd94b92ff9f51242ab3db38cff4e5f27b705ee3645613843bcfc2(executed),next=f_4d9946ad9a037d55daebbf6b4f332ecf1e985eca512336e0f0bb06e1d923e74d(executed);if(observed.c===1)throw Error('commit sequence exhausted');const [reply,committed,newVersion,,events]=observed.a;const result=write_8(reply,0,false),staged=__events(events),published=[];
if(committed){for(let i=0;i<staged.length;i++){const [channel,value,publicValue]=staged[i];outbox.push({commit:newVersion,position:BigInt(i),channel,value});if(!resultOnly)published.push({commit:newVersion,position:BigInt(i),channel,value:publicValue});}}physical=next;version=newVersion;return resultOnly?result:{result,committed,version,events:published};}
case "erase":{
const a0=read_1(args[0],0);
const a1=read_0(args[1],0);
const executed=f_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(physical,version,a0,a1);const observed=f_e76afcdc421fd94b92ff9f51242ab3db38cff4e5f27b705ee3645613843bcfc2(executed),next=f_4d9946ad9a037d55daebbf6b4f332ecf1e985eca512336e0f0bb06e1d923e74d(executed);if(observed.c===1)throw Error('commit sequence exhausted');const [reply,committed,newVersion,,events]=observed.a;const result=write_8(reply,0,false),staged=__events(events),published=[];
if(committed){for(let i=0;i<staged.length;i++){const [channel,value,publicValue]=staged[i];outbox.push({commit:newVersion,position:BigInt(i),channel,value});if(!resultOnly)published.push({commit:newVersion,position:BigInt(i),channel,value:publicValue});}}physical=next;version=newVersion;return resultOnly?result:{result,committed,version,events:published};}
case "total_query":{
const executed=f_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(physical,version);const observed=f_2d15d039af07da09e966dbb56adcd73b313da516d054674d5f55c495085b08bd(executed),next=f_186b6350f974a9daf5c57b97446437bb2cabe2a9241d8e38d84e02980089fef8(executed);if(observed.c===1)throw Error('commit sequence exhausted');const [reply,committed,newVersion,,events]=observed.a;const result=write_1(reply,0,false),staged=__events(events),published=[];
if(committed){for(let i=0;i<staged.length;i++){const [channel,value,publicValue]=staged[i];outbox.push({commit:newVersion,position:BigInt(i),channel,value});if(!resultOnly)published.push({commit:newVersion,position:BigInt(i),channel,value:publicValue});}}physical=next;version=newVersion;return resultOnly?result:{result,committed,version,events:published};}
case "count_query":{
const executed=f_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(physical,version);const observed=f_2227a6ba7041bd43fcef1b26000ccf84bfe9666af2f812e03de515c517d771d0(executed),next=f_186b6350f974a9daf5c57b97446437bb2cabe2a9241d8e38d84e02980089fef8(executed);if(observed.c===1)throw Error('commit sequence exhausted');const [reply,committed,newVersion,,events]=observed.a;const result=write_1(reply,0,false),staged=__events(events),published=[];
if(committed){for(let i=0;i<staged.length;i++){const [channel,value,publicValue]=staged[i];outbox.push({commit:newVersion,position:BigInt(i),channel,value});if(!resultOnly)published.push({commit:newVersion,position:BigInt(i),channel,value:publicValue});}}physical=next;version=newVersion;return resultOnly?result:{result,committed,version,events:published};}
default:throw Error(`unknown action ${name}`);}}
async function invoke_json(name,args){return invoke_native(name,args);}
const actionNames=new Set(["put","erase","total_query","count_query"]);
return Object.freeze({invoke:invoke_json,invoke_json,bind(name,{resultOnly=false}={}){if(!actionNames.has(name))throw Error(`unknown action ${name}`);return (...args)=>invoke_native(name,args,resultOnly);},beginTransaction(){boundary();if(transaction)throw Error('state transaction already in progress');transaction={physical,version,outbox,length:outbox.length};return true;},commitTransaction(){boundary();if(!transaction)throw Error('no state transaction');transaction=null;},rollbackTransaction(){boundary();if(!transaction)throw Error('no state transaction');physical=transaction.physical;version=transaction.version;outbox=transaction.outbox;outbox.length=transaction.length;transaction=null;},get version(){return version;},get outbox(){return outbox.map(e=>({...e,value:__publicEvent(e.channel,e.value)}));},acknowledge_through(commit,position){boundary();commit=BigInt(commit);position=BigInt(position);outbox=outbox.filter(e=>e.commit>commit||(e.commit===commit&&e.position>position));},async checkpoint(limits){boundary();
const logical=f_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(physical);return __snapshotEncode(__meta,{version,tables:__tables(logical),outbox},limits);},async restore(bytes,limits){boundary();if(transaction)throw Error('restore during state transaction');busy=true;try{const saved=await __snapshotDecode(__meta,bytes,limits);const logical=__fromTables(saved.tables);
const next=f_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(logical);
physical=next;version=saved.version;outbox=saved.outbox;}finally{busy=false;}}});}
function __publicEvent(channel,value){switch(channel){
case "seen":return write_1(read_1(value,0,true),0,false);
default:throw Error('unknown source event');}}
