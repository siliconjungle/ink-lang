const __nullaryNodes=[];
function __nullaryNode(c){return __nullaryNodes[c]??=({c,a:[]});}
function __node(c,a){return a.length===0?__nullaryNode(c):{c,a};}
const __deepCall=Symbol('private direct-call depth');let __directDepth=0;
function __run(call){const stack=[call];let result;while(stack.length){const frame=stack[stack.length-1],step=frame.next(result);if(step.done){result=step.value;stack.pop();}else{result=undefined;stack.push(step.value);}}return result;}
const __fpView=new DataView(new ArrayBuffer(4));
function __fpNumber(bits){__fpView.setUint32(0,Number(BigInt.asUintN(32,bits)),true);return __fpView.getFloat32(0,true);}
function __fpWord(op,a,b){
 if(op==='neg')return BigInt.asUintN(32,a)^2147483648n;
 const x=__fpNumber(a),y=__fpNumber(b);
 switch(op){case '==':return x===y;case '!=':return x!==y;case '<':return x<y;case '<=':return x<=y;case '>':return x>y;case '>=':return x>=y;}
 const value=op==='+'?x+y:op==='-'?x-y:op==='*'?x*y:undefined;
 if(value===undefined)throw Error('binary32 operator');if(Number.isNaN(value))return 2143289344n;__fpView.setFloat32(0,value,true);return BigInt(__fpView.getUint32(0,true));
}
function d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0){let v0;switch(a0.c){
case 0:{
const v2=0n;
v0=v2;break;}
case 1:{
const v3=1n;
v0=v3;break;}
case 2:{
v0=a0.a[6];break;}
default:throw Error('literal constructor projection');}
return v0;}
function* d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1){const v10=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v12=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a1);
const v9=(v10)<(v12);
let v8;if(v9){
const v14=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
v8=v14;}else{
const v16=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a1);
v8=v16;}
const v20=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v22=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a1);
const v19=(v20)<(v22);
let v18;if(v19){
const v24=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a1);
v18=v24;}else{
const v26=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
v18=v26;}
const v29=yield d_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0);
const v31=yield d_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a1);
const v28=BigInt.asUintN(64,(v29)+(v31));
const v34=yield d_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0);
const v36=yield d_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a1);
const v33=BigInt.asUintN(64,(v34)+(v36));
const v41=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v43=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v40=(v41)<(v43);
let v39;if(v40){
const v45=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
v39=v45;}else{
const v47=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
v39=v47;}
const v49=1n;
const v38=BigInt.asUintN(64,(v39)+(v49));
const v5=__node(2,[a0,a1,v8,v18,v28,v33,v38]);
return v5;}
function* d_14b1c60245cb25b6473dae8947e9201876796fa199c6cdd20ee3a2661b7317b0(a0,a1,a2){const v52=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a2);
const v54=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v51=(v52)<(v54);
let v50;if(v51){
let v56;switch(a1.c){
case 0:{
const v59=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v58=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v59,a2);
v56=v58;break;}
case 1:{
const v64=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v63=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v64,a2);
v56=v63;break;}
case 2:{
const v69=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1.a[0]);
const v72=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1.a[1],a2);
const v68=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v69,v72);
v56=v68;break;}
default:throw Error('literal constructor projection');}
v50=v56;}else{
const v76=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v75=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v76,a2);
v50=v75;}
return v50;}
function d_186b6350f974a9daf5c57b97446437bb2cabe2a9241d8e38d84e02980089fef8(a0){let v80;switch(a0.c){
case 0:{
v80=a0.a[3];break;}
case 1:{
v80=a0.a[2];break;}
default:throw Error('literal constructor projection');}
return v80;}
function* d_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0){let v84;switch(a0.c){
case 0:{
const v86=__nullaryNode(0);
v84=v86;break;}
case 1:{
let v88;switch(a0.a[0].c){
case 0:{
v88=a0.a[0].a[1];break;}
default:throw Error('literal constructor projection');}
let v87;if(v88){
const v93=yield d_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0.a[1]);
const v91=__node(1,[a0.a[0],v93]);
v87=v91;}else{
const v95=yield d_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0.a[1]);
v87=v95;}
v84=v87;break;}
default:throw Error('literal constructor projection');}
return v84;}
function* d_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(a0){let v97;switch(a0.c){
case 0:{
const v99=__nullaryNode(0);
v97=v99;break;}
case 1:{
let v103;switch(a0.a[0].c){
case 0:{
v103=a0.a[0].a[0];break;}
default:throw Error('literal constructor projection');}
const v106=0n;
const v102=BigInt.asUintN(64,(v103)*(v106));
const v107=1n;
const v101=BigInt.asUintN(64,(v102)+(v107));
const v108=yield d_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(a0.a[1]);
const v100=__node(1,[v101,v108]);
v97=v100;break;}
default:throw Error('literal constructor projection');}
return v97;}
function* d_2937ee59437d4727fd243a664a281a6018453ca819aede4e91f0a7d9bda2ca12(a0){const v115=0n;
const v117=__nullaryNode(0);
const v114=__node(1,[v115,a0,v117]);
const v113=yield d_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(v114);
const v112=yield d_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(v113);
const v111=yield d_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(v112);
const v110=yield d_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(v111);
return v110;}
function* d_2a975b3a5fe826968db8619175ac9f0dfbf3be2c770a2eab7b9bb32e684cf01b(a0){const v123=0n;
const v125=__nullaryNode(0);
const v122=__node(1,[v123,a0,v125]);
const v121=yield d_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(v122);
const v120=yield d_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(v121);
const v119=yield d_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(v120);
const v118=yield d_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(v119);
return v118;}
function d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0){let v126;switch(a0.c){
case 0:{
const v128=0n;
v126=v128;break;}
case 1:{
v126=a0.a[0];break;}
case 2:{
v126=a0.a[3];break;}
default:throw Error('literal constructor projection');}
return v126;}
function* d_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(a0){let v131;switch(a0.c){
case 0:{
const v134=yield d_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0.a[0]);
const v133=__node(0,[v134]);
v131=v133;break;}
default:throw Error('literal constructor projection');}
return v131;}
function* d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(a0,a1){const v138=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v141=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v143=1n;
const v140=BigInt.asUintN(64,(v141)+(v143));
const v137=(v138)>(v140);
let v136;if(v137){
const v144=yield d_dd9122cd0ef5414b8f184fc5a412c2e0c7b9002cb5d701ef49dc7b9f5465679c(a0,a1);
v136=v144;}else{
const v147=yield d_5772432f10e31d0ddf159e9ab757ef7042f15ed47699a0c380e996b8cda2529c(a0,a1);
v136=v147;}
return v136;}
function* d_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(a0){let v150;switch(a0.c){
case 0:{
const v152=__nullaryNode(0);
v150=v152;break;}
case 1:{
let v154;switch(a0.a[0].c){
case 0:{
v154=a0.a[0].a[0];break;}
default:throw Error('literal constructor projection');}
const v157=yield d_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(a0.a[1]);
const v153=__node(1,[v154,v157]);
v150=v153;break;}
default:throw Error('literal constructor projection');}
return v150;}
function* d_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(a0,a1,a2,a3,a4,a5){let v159;switch(a0.c){
case 0:{
const v163=yield d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v162;switch(v163.c){
case 0:{
const v166=false;
v162=v166;break;}
case 1:{
const v167=true;
v162=v167;break;}
default:throw Error('literal constructor projection');}
let v161;if(v162){
const v170=yield d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v169;switch(v170.c){
case 0:{
const v173=false;
v169=v173;break;}
case 1:{
const v174=true;
v169=v174;break;}
default:throw Error('literal constructor projection');}
let v168;if(v169){
let v175;if(a5){
const v179=__nullaryNode(0);
const v178=__node(1,[v179]);
const v180=false;
const v182=__node(0,[a0.a[0]]);
const v184=__nullaryNode(0);
const v177=__node(0,[v178,v180,a1,v182,v184]);
v175=v177;}else{
const v188=18446744073709551615n;
const v186=(a1)===(v188);
let v185;if(v186){
const v190=1n;
const v192=__node(0,[a0.a[0]]);
const v189=__node(1,[v190,a1,v192]);
v185=v189;}else{
const v196=__nullaryNode(0);
const v195=__node(0,[v196]);
const v197=true;
const v200=1n;
const v198=BigInt.asUintN(64,(a1)+(v200));
const v205=__node(0,[a3,a4]);
const v202=yield d_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[0],a2,v205);
const v201=__node(0,[v202]);
const v209=__node(0,[a3]);
const v211=__nullaryNode(0);
const v208=__node(1,[v209,v211]);
const v194=__node(0,[v195,v197,v198,v201,v208]);
v185=v194;}
v175=v185;}
v168=v175;}else{
const v213=2n;
const v215=__node(0,[a0.a[0]]);
const v212=__node(1,[v213,a1,v215]);
v168=v212;}
v161=v168;}else{
const v219=yield d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v218;switch(v219.c){
case 0:{
const v222=false;
v218=v222;break;}
case 1:{
const v223=true;
v218=v223;break;}
default:throw Error('literal constructor projection');}
let v217;if(v218){
const v225=2n;
const v227=__node(0,[a0.a[0]]);
const v224=__node(1,[v225,a1,v227]);
v217=v224;}else{
let v229;if(a5){
const v233=__nullaryNode(0);
const v232=__node(1,[v233]);
const v234=false;
const v236=__node(0,[a0.a[0]]);
const v238=__nullaryNode(0);
const v231=__node(0,[v232,v234,a1,v236,v238]);
v229=v231;}else{
const v242=18446744073709551615n;
const v240=(a1)===(v242);
let v239;if(v240){
const v244=1n;
const v246=__node(0,[a0.a[0]]);
const v243=__node(1,[v244,a1,v246]);
v239=v243;}else{
const v250=__nullaryNode(0);
const v249=__node(0,[v250]);
const v251=true;
const v254=1n;
const v252=BigInt.asUintN(64,(a1)+(v254));
const v259=__node(0,[a3,a4]);
const v256=yield d_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[0],a2,v259);
const v255=__node(0,[v256]);
const v263=__node(0,[a3]);
const v265=__nullaryNode(0);
const v262=__node(1,[v263,v265]);
const v248=__node(0,[v249,v251,v252,v255,v262]);
v239=v248;}
v229=v239;}
v217=v229;}
v161=v217;}
v159=v161;break;}
default:throw Error('literal constructor projection');}
return v159;}
function* d_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0){let v266;switch(a0.c){
case 0:{
const v268=__nullaryNode(0);
v266=v268;break;}
case 1:{
const v272=__nullaryNode(0);
const v269=__node(1,[a0.a[0],a0.a[1],v272]);
v266=v269;break;}
case 2:{
const v274=yield d_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[0]);
const v276=yield d_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[1]);
const v273=yield d_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(v274,v276);
v266=v273;break;}
default:throw Error('literal constructor projection');}
return v266;}
function* d_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0){let v278;switch(a0.c){
case 0:{
const v280=0n;
v278=v280;break;}
case 1:{
const v281=yield d_2937ee59437d4727fd243a664a281a6018453ca819aede4e91f0a7d9bda2ca12(a0.a[1]);
v278=v281;break;}
case 2:{
v278=a0.a[4];break;}
default:throw Error('literal constructor projection');}
return v278;}
function d_4d9946ad9a037d55daebbf6b4f332ecf1e985eca512336e0f0bb06e1d923e74d(a0){let v284;switch(a0.c){
case 0:{
v284=a0.a[3];break;}
case 1:{
v284=a0.a[2];break;}
default:throw Error('literal constructor projection');}
return v284;}
function d_51991d73b93f2b8d1001d6179127db8fada9c9afc1e66821b78767b1a730d1a7(a0){let v288;switch(a0.c){
case 0:{
const v290=__node(0,[a0.a[0],a0.a[1],a0.a[2],a0.a[4]]);
v288=v290;break;}
case 1:{
const v295=__node(1,[a0.a[0],a0.a[1]]);
v288=v295;break;}
default:throw Error('literal constructor projection');}
return v288;}
function* d_5772432f10e31d0ddf159e9ab757ef7042f15ed47699a0c380e996b8cda2529c(a0,a1){const v300=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v303=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v305=1n;
const v302=BigInt.asUintN(64,(v303)+(v305));
const v299=(v300)>(v302);
let v298;if(v299){
let v306;switch(a1.c){
case 0:{
const v308=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v306=v308;break;}
case 1:{
const v311=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v306=v311;break;}
case 2:{
const v314=yield d_14b1c60245cb25b6473dae8947e9201876796fa199c6cdd20ee3a2661b7317b0(a0,a1.a[0],a1.a[1]);
v306=v314;break;}
default:throw Error('literal constructor projection');}
v298=v306;}else{
const v318=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v298=v318;}
return v298;}
function* d_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0,a1){const v325=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v323=(a1)<(v325);
const v329=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v327=(a1)>(v329);
const v322=(v323)||(v327);
let v321;if(v322){
v321=a0;}else{
let v332;switch(a0.c){
case 0:{
const v334=__nullaryNode(0);
v332=v334;break;}
case 1:{
const v336=(a1)===(a0.a[0]);
let v335;if(v336){
const v339=__nullaryNode(0);
v335=v339;}else{
const v340=__node(1,[a0.a[0],a0.a[1]]);
v335=v340;}
v332=v335;break;}
case 2:{
const v344=yield d_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[0],a1);
const v347=yield d_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[1],a1);
const v343=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v344,v347);
v332=v343;break;}
default:throw Error('literal constructor projection');}
v321=v332;}
return v321;}
function* d_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1){let v350;switch(a0.c){
case 0:{
const v353=yield d_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0.a[0]);
const v355=false;
const v357=__node(0,[a0.a[0]]);
const v359=__nullaryNode(0);
const v352=__node(0,[v353,v355,a1,v357,v359]);
v350=v352;break;}
default:throw Error('literal constructor projection');}
return v350;}
function* d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0,a1){const v364=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v362=(a1)<(v364);
const v368=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v366=(a1)>(v368);
const v361=(v362)||(v366);
let v360;if(v361){
const v370=__nullaryNode(0);
v360=v370;}else{
let v371;switch(a0.c){
case 0:{
const v373=__nullaryNode(0);
v371=v373;break;}
case 1:{
const v375=(a1)===(a0.a[0]);
let v374;if(v375){
const v378=__node(1,[a0.a[1]]);
v374=v378;}else{
const v380=__nullaryNode(0);
v374=v380;}
v371=v374;break;}
case 2:{
const v382=yield d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a1);
const v385=yield d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[1],a1);
const v381=d_b786cd3d542360e36d11a412339399f2084fa0e5a8bec5ab1461e548f657f81d(v382,v385);
v371=v381;break;}
default:throw Error('literal constructor projection');}
v360=v371;}
return v360;}
function* d_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0){let v388;switch(a0.c){
case 0:{
const v390=__nullaryNode(0);
v388=v390;break;}
case 1:{
let v392;switch(a0.a[0].c){
case 0:{
v392=a0.a[0].a[1];break;}
default:throw Error('literal constructor projection');}
let v391;if(v392){
const v397=yield d_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0.a[1]);
const v395=__node(1,[a0.a[0],v397]);
v391=v395;}else{
const v399=yield d_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0.a[1]);
v391=v399;}
v388=v391;break;}
default:throw Error('literal constructor projection');}
return v388;}
function* d_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(a0){let v401;switch(a0.c){
case 0:{
const v403=__nullaryNode(0);
v401=v403;break;}
case 1:{
const v406=yield d_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(a0.a[2]);
const v404=__node(1,[a0.a[1],v406]);
v401=v404;break;}
default:throw Error('literal constructor projection');}
return v401;}
function d_896be328c068c766df31a09a848605651a0bde91d601f8fb585407c4d66fc3d6(a0){let v408;switch(a0.c){
case 0:{
const v410=__node(0,[a0.a[0],a0.a[1],a0.a[2],a0.a[4]]);
v408=v410;break;}
case 1:{
const v415=__node(1,[a0.a[0],a0.a[1]]);
v408=v415;break;}
default:throw Error('literal constructor projection');}
return v408;}
function* d_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(a0,a1){let v418;switch(a0.c){
case 0:{
v418=a1;break;}
case 1:{
const v424=yield d_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(a0.a[2],a1);
const v421=__node(1,[a0.a[0],a0.a[1],v424]);
v418=v421;break;}
default:throw Error('literal constructor projection');}
return v418;}
function* d_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(a0,a1,a2,a3){let v427;switch(a0.c){
case 0:{
let v429;if(a3){
const v433=__nullaryNode(0);
const v432=__node(1,[v433]);
const v434=false;
const v436=__node(0,[a0.a[0]]);
const v438=__nullaryNode(0);
const v431=__node(0,[v432,v434,a1,v436,v438]);
v429=v431;}else{
const v442=18446744073709551615n;
const v440=(a1)===(v442);
let v439;if(v440){
const v444=1n;
const v446=__node(0,[a0.a[0]]);
const v443=__node(1,[v444,a1,v446]);
v439=v443;}else{
const v450=__nullaryNode(0);
const v449=__node(0,[v450]);
const v451=true;
const v454=1n;
const v452=BigInt.asUintN(64,(a1)+(v454));
const v456=yield d_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[0],a2);
const v455=__node(0,[v456]);
const v460=__node(0,[a2]);
const v462=__nullaryNode(0);
const v459=__node(1,[v460,v462]);
const v448=__node(0,[v449,v451,v452,v455,v459]);
v439=v448;}
v429=v439;}
v427=v429;break;}
default:throw Error('literal constructor projection');}
return v427;}
function* d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0){let v463;switch(a0.c){
case 0:{
const v466=yield d_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[0]);
const v465=__node(0,[v466]);
v463=v465;break;}
default:throw Error('literal constructor projection');}
return v463;}
function d_b786cd3d542360e36d11a412339399f2084fa0e5a8bec5ab1461e548f657f81d(a0,a1){let v468;switch(a0.c){
case 0:{
v468=a1;break;}
case 1:{
const v471=__node(1,[a0.a[0]]);
v468=v471;break;}
default:throw Error('literal constructor projection');}
return v468;}
function* d_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0){let v473;switch(a0.c){
case 0:{
const v475=0n;
v473=v475;break;}
case 1:{
const v476=yield d_2a975b3a5fe826968db8619175ac9f0dfbf3be2c770a2eab7b9bb32e684cf01b(a0.a[1]);
v473=v476;break;}
case 2:{
v473=a0.a[5];break;}
default:throw Error('literal constructor projection');}
return v473;}
function d_c7a490b328d4af7e7e805c851b135e47709dba5be887c644dc7356b711632d68(a0){let v479;switch(a0.c){
case 0:{
const v481=__node(0,[a0.a[0],a0.a[1],a0.a[2],a0.a[4]]);
v479=v481;break;}
case 1:{
const v486=__node(1,[a0.a[0],a0.a[1]]);
v479=v486;break;}
default:throw Error('literal constructor projection');}
return v479;}
function* d_c7ad7bdf333846cfdaf9c1cef5bcc98d8b1f5a0ca3c654237e21162cd70e16f6(a0,a1,a2){const v491=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v493=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v490=(v491)<(v493);
let v489;if(v490){
let v495;switch(a1.c){
case 0:{
const v499=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v497=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v499);
v495=v497;break;}
case 1:{
const v504=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v502=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v504);
v495=v502;break;}
case 2:{
const v508=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1.a[0]);
const v511=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1.a[1],a2);
const v507=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v508,v511);
v495=v507;break;}
default:throw Error('literal constructor projection');}
v489=v495;}else{
const v516=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v514=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v516);
v489=v514;}
return v489;}
function d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0){let v519;switch(a0.c){
case 0:{
const v521=18446744073709551615n;
v519=v521;break;}
case 1:{
v519=a0.a[0];break;}
case 2:{
v519=a0.a[2];break;}
default:throw Error('literal constructor projection');}
return v519;}
function* d_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0,a1,a2){const v528=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v526=(a1)<(v528);
const v532=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v530=(a1)>(v532);
const v525=(v526)||(v530);
let v524;if(v525){
v524=a0;}else{
let v535;switch(a0.c){
case 0:{
const v537=__nullaryNode(0);
v535=v537;break;}
case 1:{
const v539=(a1)===(a0.a[0]);
let v538;if(v539){
const v542=__node(1,[a0.a[0],a2]);
v538=v542;}else{
const v545=__node(1,[a0.a[0],a0.a[1]]);
v538=v545;}
v535=v538;break;}
case 2:{
const v549=yield d_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[0],a1,a2);
const v553=yield d_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[1],a1,a2);
const v548=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v549,v553);
v535=v548;break;}
default:throw Error('literal constructor projection');}
v524=v535;}
return v524;}
function* d_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(a0,a1,a2){let v557;switch(a0.c){
case 0:{
const v559=__node(1,[a1,a2]);
v557=v559;break;}
case 1:{
const v563=__node(1,[a1,a2]);
const v566=__node(1,[a0.a[0],a0.a[1]]);
const v562=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v563,v566);
v557=v562;break;}
case 2:{
const v570=yield d_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(a0.a[0],a1,a2);
const v569=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v570,a0.a[1]);
v557=v569;break;}
default:throw Error('literal constructor projection');}
return v557;}
function* d_dd9122cd0ef5414b8f184fc5a412c2e0c7b9002cb5d701ef49dc7b9f5465679c(a0,a1){const v577=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v580=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v582=1n;
const v579=BigInt.asUintN(64,(v580)+(v582));
const v576=(v577)>(v579);
let v575;if(v576){
let v583;switch(a0.c){
case 0:{
const v585=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v583=v585;break;}
case 1:{
const v588=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v583=v588;break;}
case 2:{
const v591=yield d_c7ad7bdf333846cfdaf9c1cef5bcc98d8b1f5a0ca3c654237e21162cd70e16f6(a0.a[0],a0.a[1],a1);
v583=v591;break;}
default:throw Error('literal constructor projection');}
v575=v583;}else{
const v595=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v575=v595;}
return v575;}
function* d_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0){let v598;switch(a0.c){
case 0:{
const v600=__nullaryNode(0);
v598=v600;break;}
case 1:{
const v602=yield d_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0.a[2]);
const v601=yield d_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(v602,a0.a[0],a0.a[1]);
v598=v601;break;}
default:throw Error('literal constructor projection');}
return v598;}
function* d_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1){let v606;switch(a0.c){
case 0:{
const v609=yield d_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0.a[0]);
const v611=false;
const v613=__node(0,[a0.a[0]]);
const v615=__nullaryNode(0);
const v608=__node(0,[v609,v611,a1,v613,v615]);
v606=v608;break;}
default:throw Error('literal constructor projection');}
return v606;}
function* d_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(a0){let v616;switch(a0.c){
case 0:{
const v618=0n;
v616=v618;break;}
case 1:{
const v621=yield d_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(a0.a[1]);
const v619=BigInt.asUintN(64,(a0.a[0])+(v621));
v616=v619;break;}
default:throw Error('literal constructor projection');}
return v616;}
function* d_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0,a1,a2){let v623;switch(a0.c){
case 0:{
const v625=__node(1,[a1,a2]);
v623=v625;break;}
case 1:{
const v629=(a1)<(a0.a[0]);
let v628;if(v629){
const v633=__node(1,[a1,a2]);
const v636=__node(1,[a0.a[0],a0.a[1]]);
const v632=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v633,v636);
v628=v632;}else{
const v640=__node(1,[a0.a[0],a0.a[1]]);
const v643=__node(1,[a1,a2]);
const v639=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v640,v643);
v628=v639;}
v623=v628;break;}
case 2:{
const v649=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0.a[0]);
const v647=(a1)<(v649);
let v646;if(v647){
const v652=yield d_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[0],a1,a2);
const v651=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v652,a0.a[1]);
v646=v651;}else{
const v659=yield d_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[1],a1,a2);
const v657=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(a0.a[0],v659);
v646=v657;}
v623=v646;break;}
default:throw Error('literal constructor projection');}
return v623;}
function* d_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(a0){let v663;switch(a0.c){
case 0:{
const v665=0n;
v663=v665;break;}
case 1:{
const v668=yield d_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(a0.a[1]);
const v666=BigInt.asUintN(64,(a0.a[0])+(v668));
v663=v666;break;}
default:throw Error('literal constructor projection');}
return v663;}
function dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v5=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v7=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a1);
const v4=(v5)<(v7);
let v3;if(v4){
const v9=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
v3=v9;}else{
const v11=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a1);
v3=v11;}
const v15=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v17=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a1);
const v14=(v15)<(v17);
let v13;if(v14){
const v19=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a1);
v13=v19;}else{
const v21=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
v13=v21;}
const v24=dFast_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0);
const v26=dFast_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a1);
const v23=BigInt.asUintN(64,(v24)+(v26));
const v29=dFast_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0);
const v31=dFast_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a1);
const v28=BigInt.asUintN(64,(v29)+(v31));
const v36=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v38=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v35=(v36)<(v38);
let v34;if(v35){
const v40=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
v34=v40;}else{
const v42=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
v34=v42;}
const v44=1n;
const v33=BigInt.asUintN(64,(v34)+(v44));
const v0=__node(2,[a0,a1,v3,v13,v23,v28,v33]);
return v0;}finally{__directDepth--;}}
function dFast_14b1c60245cb25b6473dae8947e9201876796fa199c6cdd20ee3a2661b7317b0(a0,a1,a2){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v47=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a2);
const v49=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v46=(v47)<(v49);
let v45;if(v46){
let v51;switch(a1.c){
case 0:{
const v54=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v53=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v54,a2);
v51=v53;break;}
case 1:{
const v59=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v58=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v59,a2);
v51=v58;break;}
case 2:{
const v64=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1.a[0]);
const v67=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1.a[1],a2);
const v63=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v64,v67);
v51=v63;break;}
default:throw Error('literal constructor projection');}
v45=v51;}else{
const v71=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v70=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v71,a2);
v45=v70;}
return v45;}finally{__directDepth--;}}
function dFast_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v75;switch(a0.c){
case 0:{
const v77=__nullaryNode(0);
v75=v77;break;}
case 1:{
let v79;switch(a0.a[0].c){
case 0:{
v79=a0.a[0].a[1];break;}
default:throw Error('literal constructor projection');}
let v78;if(v79){
const v84=dFast_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0.a[1]);
const v82=__node(1,[a0.a[0],v84]);
v78=v82;}else{
const v86=dFast_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0.a[1]);
v78=v86;}
v75=v78;break;}
default:throw Error('literal constructor projection');}
return v75;}finally{__directDepth--;}}
function dFast_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v88;switch(a0.c){
case 0:{
const v90=__nullaryNode(0);
v88=v90;break;}
case 1:{
let v94;switch(a0.a[0].c){
case 0:{
v94=a0.a[0].a[0];break;}
default:throw Error('literal constructor projection');}
const v97=0n;
const v93=BigInt.asUintN(64,(v94)*(v97));
const v98=1n;
const v92=BigInt.asUintN(64,(v93)+(v98));
const v99=dFast_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(a0.a[1]);
const v91=__node(1,[v92,v99]);
v88=v91;break;}
default:throw Error('literal constructor projection');}
return v88;}finally{__directDepth--;}}
function dFast_2937ee59437d4727fd243a664a281a6018453ca819aede4e91f0a7d9bda2ca12(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v106=0n;
const v108=__nullaryNode(0);
const v105=__node(1,[v106,a0,v108]);
const v104=dFast_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(v105);
const v103=dFast_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(v104);
const v102=dFast_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(v103);
const v101=dFast_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(v102);
return v101;}finally{__directDepth--;}}
function dFast_2a975b3a5fe826968db8619175ac9f0dfbf3be2c770a2eab7b9bb32e684cf01b(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v114=0n;
const v116=__nullaryNode(0);
const v113=__node(1,[v114,a0,v116]);
const v112=dFast_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(v113);
const v111=dFast_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(v112);
const v110=dFast_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(v111);
const v109=dFast_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(v110);
return v109;}finally{__directDepth--;}}
function dFast_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v117;switch(a0.c){
case 0:{
const v120=dFast_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0.a[0]);
const v119=__node(0,[v120]);
v117=v119;break;}
default:throw Error('literal constructor projection');}
return v117;}finally{__directDepth--;}}
function dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v124=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v127=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v129=1n;
const v126=BigInt.asUintN(64,(v127)+(v129));
const v123=(v124)>(v126);
let v122;if(v123){
const v130=dFast_dd9122cd0ef5414b8f184fc5a412c2e0c7b9002cb5d701ef49dc7b9f5465679c(a0,a1);
v122=v130;}else{
const v133=dFast_5772432f10e31d0ddf159e9ab757ef7042f15ed47699a0c380e996b8cda2529c(a0,a1);
v122=v133;}
return v122;}finally{__directDepth--;}}
function dFast_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v136;switch(a0.c){
case 0:{
const v138=__nullaryNode(0);
v136=v138;break;}
case 1:{
let v140;switch(a0.a[0].c){
case 0:{
v140=a0.a[0].a[0];break;}
default:throw Error('literal constructor projection');}
const v143=dFast_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(a0.a[1]);
const v139=__node(1,[v140,v143]);
v136=v139;break;}
default:throw Error('literal constructor projection');}
return v136;}finally{__directDepth--;}}
function dFast_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(a0,a1,a2,a3,a4,a5){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v145;switch(a0.c){
case 0:{
const v149=dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v148;switch(v149.c){
case 0:{
const v152=false;
v148=v152;break;}
case 1:{
const v153=true;
v148=v153;break;}
default:throw Error('literal constructor projection');}
let v147;if(v148){
const v156=dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v155;switch(v156.c){
case 0:{
const v159=false;
v155=v159;break;}
case 1:{
const v160=true;
v155=v160;break;}
default:throw Error('literal constructor projection');}
let v154;if(v155){
let v161;if(a5){
const v165=__nullaryNode(0);
const v164=__node(1,[v165]);
const v166=false;
const v168=__node(0,[a0.a[0]]);
const v170=__nullaryNode(0);
const v163=__node(0,[v164,v166,a1,v168,v170]);
v161=v163;}else{
const v174=18446744073709551615n;
const v172=(a1)===(v174);
let v171;if(v172){
const v176=1n;
const v178=__node(0,[a0.a[0]]);
const v175=__node(1,[v176,a1,v178]);
v171=v175;}else{
const v182=__nullaryNode(0);
const v181=__node(0,[v182]);
const v183=true;
const v186=1n;
const v184=BigInt.asUintN(64,(a1)+(v186));
const v191=__node(0,[a3,a4]);
const v188=dFast_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[0],a2,v191);
const v187=__node(0,[v188]);
const v195=__node(0,[a3]);
const v197=__nullaryNode(0);
const v194=__node(1,[v195,v197]);
const v180=__node(0,[v181,v183,v184,v187,v194]);
v171=v180;}
v161=v171;}
v154=v161;}else{
const v199=2n;
const v201=__node(0,[a0.a[0]]);
const v198=__node(1,[v199,a1,v201]);
v154=v198;}
v147=v154;}else{
const v205=dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v204;switch(v205.c){
case 0:{
const v208=false;
v204=v208;break;}
case 1:{
const v209=true;
v204=v209;break;}
default:throw Error('literal constructor projection');}
let v203;if(v204){
const v211=2n;
const v213=__node(0,[a0.a[0]]);
const v210=__node(1,[v211,a1,v213]);
v203=v210;}else{
let v215;if(a5){
const v219=__nullaryNode(0);
const v218=__node(1,[v219]);
const v220=false;
const v222=__node(0,[a0.a[0]]);
const v224=__nullaryNode(0);
const v217=__node(0,[v218,v220,a1,v222,v224]);
v215=v217;}else{
const v228=18446744073709551615n;
const v226=(a1)===(v228);
let v225;if(v226){
const v230=1n;
const v232=__node(0,[a0.a[0]]);
const v229=__node(1,[v230,a1,v232]);
v225=v229;}else{
const v236=__nullaryNode(0);
const v235=__node(0,[v236]);
const v237=true;
const v240=1n;
const v238=BigInt.asUintN(64,(a1)+(v240));
const v245=__node(0,[a3,a4]);
const v242=dFast_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[0],a2,v245);
const v241=__node(0,[v242]);
const v249=__node(0,[a3]);
const v251=__nullaryNode(0);
const v248=__node(1,[v249,v251]);
const v234=__node(0,[v235,v237,v238,v241,v248]);
v225=v234;}
v215=v225;}
v203=v215;}
v147=v203;}
v145=v147;break;}
default:throw Error('literal constructor projection');}
return v145;}finally{__directDepth--;}}
function dFast_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v252;switch(a0.c){
case 0:{
const v254=__nullaryNode(0);
v252=v254;break;}
case 1:{
const v258=__nullaryNode(0);
const v255=__node(1,[a0.a[0],a0.a[1],v258]);
v252=v255;break;}
case 2:{
const v260=dFast_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[0]);
const v262=dFast_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[1]);
const v259=dFast_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(v260,v262);
v252=v259;break;}
default:throw Error('literal constructor projection');}
return v252;}finally{__directDepth--;}}
function dFast_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v264;switch(a0.c){
case 0:{
const v266=0n;
v264=v266;break;}
case 1:{
const v267=dFast_2937ee59437d4727fd243a664a281a6018453ca819aede4e91f0a7d9bda2ca12(a0.a[1]);
v264=v267;break;}
case 2:{
v264=a0.a[4];break;}
default:throw Error('literal constructor projection');}
return v264;}finally{__directDepth--;}}
function dFast_5772432f10e31d0ddf159e9ab757ef7042f15ed47699a0c380e996b8cda2529c(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v272=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v275=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v277=1n;
const v274=BigInt.asUintN(64,(v275)+(v277));
const v271=(v272)>(v274);
let v270;if(v271){
let v278;switch(a1.c){
case 0:{
const v280=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v278=v280;break;}
case 1:{
const v283=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v278=v283;break;}
case 2:{
const v286=dFast_14b1c60245cb25b6473dae8947e9201876796fa199c6cdd20ee3a2661b7317b0(a0,a1.a[0],a1.a[1]);
v278=v286;break;}
default:throw Error('literal constructor projection');}
v270=v278;}else{
const v290=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v270=v290;}
return v270;}finally{__directDepth--;}}
function dFast_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v297=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v295=(a1)<(v297);
const v301=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v299=(a1)>(v301);
const v294=(v295)||(v299);
let v293;if(v294){
v293=a0;}else{
let v304;switch(a0.c){
case 0:{
const v306=__nullaryNode(0);
v304=v306;break;}
case 1:{
const v308=(a1)===(a0.a[0]);
let v307;if(v308){
const v311=__nullaryNode(0);
v307=v311;}else{
const v312=__node(1,[a0.a[0],a0.a[1]]);
v307=v312;}
v304=v307;break;}
case 2:{
const v316=dFast_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[0],a1);
const v319=dFast_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[1],a1);
const v315=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v316,v319);
v304=v315;break;}
default:throw Error('literal constructor projection');}
v293=v304;}
return v293;}finally{__directDepth--;}}
function dFast_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v322;switch(a0.c){
case 0:{
const v325=dFast_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0.a[0]);
const v327=false;
const v329=__node(0,[a0.a[0]]);
const v331=__nullaryNode(0);
const v324=__node(0,[v325,v327,a1,v329,v331]);
v322=v324;break;}
default:throw Error('literal constructor projection');}
return v322;}finally{__directDepth--;}}
function dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v336=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v334=(a1)<(v336);
const v340=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v338=(a1)>(v340);
const v333=(v334)||(v338);
let v332;if(v333){
const v342=__nullaryNode(0);
v332=v342;}else{
let v343;switch(a0.c){
case 0:{
const v345=__nullaryNode(0);
v343=v345;break;}
case 1:{
const v347=(a1)===(a0.a[0]);
let v346;if(v347){
const v350=__node(1,[a0.a[1]]);
v346=v350;}else{
const v352=__nullaryNode(0);
v346=v352;}
v343=v346;break;}
case 2:{
const v354=dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a1);
const v357=dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[1],a1);
const v353=d_b786cd3d542360e36d11a412339399f2084fa0e5a8bec5ab1461e548f657f81d(v354,v357);
v343=v353;break;}
default:throw Error('literal constructor projection');}
v332=v343;}
return v332;}finally{__directDepth--;}}
function dFast_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v360;switch(a0.c){
case 0:{
const v362=__nullaryNode(0);
v360=v362;break;}
case 1:{
let v364;switch(a0.a[0].c){
case 0:{
v364=a0.a[0].a[1];break;}
default:throw Error('literal constructor projection');}
let v363;if(v364){
const v369=dFast_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0.a[1]);
const v367=__node(1,[a0.a[0],v369]);
v363=v367;}else{
const v371=dFast_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0.a[1]);
v363=v371;}
v360=v363;break;}
default:throw Error('literal constructor projection');}
return v360;}finally{__directDepth--;}}
function dFast_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v373;switch(a0.c){
case 0:{
const v375=__nullaryNode(0);
v373=v375;break;}
case 1:{
const v378=dFast_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(a0.a[2]);
const v376=__node(1,[a0.a[1],v378]);
v373=v376;break;}
default:throw Error('literal constructor projection');}
return v373;}finally{__directDepth--;}}
function dFast_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v380;switch(a0.c){
case 0:{
v380=a1;break;}
case 1:{
const v386=dFast_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(a0.a[2],a1);
const v383=__node(1,[a0.a[0],a0.a[1],v386]);
v380=v383;break;}
default:throw Error('literal constructor projection');}
return v380;}finally{__directDepth--;}}
function dFast_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(a0,a1,a2,a3){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v389;switch(a0.c){
case 0:{
let v391;if(a3){
const v395=__nullaryNode(0);
const v394=__node(1,[v395]);
const v396=false;
const v398=__node(0,[a0.a[0]]);
const v400=__nullaryNode(0);
const v393=__node(0,[v394,v396,a1,v398,v400]);
v391=v393;}else{
const v404=18446744073709551615n;
const v402=(a1)===(v404);
let v401;if(v402){
const v406=1n;
const v408=__node(0,[a0.a[0]]);
const v405=__node(1,[v406,a1,v408]);
v401=v405;}else{
const v412=__nullaryNode(0);
const v411=__node(0,[v412]);
const v413=true;
const v416=1n;
const v414=BigInt.asUintN(64,(a1)+(v416));
const v418=dFast_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[0],a2);
const v417=__node(0,[v418]);
const v422=__node(0,[a2]);
const v424=__nullaryNode(0);
const v421=__node(1,[v422,v424]);
const v410=__node(0,[v411,v413,v414,v417,v421]);
v401=v410;}
v391=v401;}
v389=v391;break;}
default:throw Error('literal constructor projection');}
return v389;}finally{__directDepth--;}}
function dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v425;switch(a0.c){
case 0:{
const v428=dFast_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[0]);
const v427=__node(0,[v428]);
v425=v427;break;}
default:throw Error('literal constructor projection');}
return v425;}finally{__directDepth--;}}
function dFast_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v430;switch(a0.c){
case 0:{
const v432=0n;
v430=v432;break;}
case 1:{
const v433=dFast_2a975b3a5fe826968db8619175ac9f0dfbf3be2c770a2eab7b9bb32e684cf01b(a0.a[1]);
v430=v433;break;}
case 2:{
v430=a0.a[5];break;}
default:throw Error('literal constructor projection');}
return v430;}finally{__directDepth--;}}
function dFast_c7ad7bdf333846cfdaf9c1cef5bcc98d8b1f5a0ca3c654237e21162cd70e16f6(a0,a1,a2){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v438=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v440=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v437=(v438)<(v440);
let v436;if(v437){
let v442;switch(a1.c){
case 0:{
const v446=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v444=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v446);
v442=v444;break;}
case 1:{
const v451=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v449=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v451);
v442=v449;break;}
case 2:{
const v455=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1.a[0]);
const v458=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1.a[1],a2);
const v454=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v455,v458);
v442=v454;break;}
default:throw Error('literal constructor projection');}
v436=v442;}else{
const v463=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v461=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v463);
v436=v461;}
return v436;}finally{__directDepth--;}}
function dFast_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0,a1,a2){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v470=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v468=(a1)<(v470);
const v474=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v472=(a1)>(v474);
const v467=(v468)||(v472);
let v466;if(v467){
v466=a0;}else{
let v477;switch(a0.c){
case 0:{
const v479=__nullaryNode(0);
v477=v479;break;}
case 1:{
const v481=(a1)===(a0.a[0]);
let v480;if(v481){
const v484=__node(1,[a0.a[0],a2]);
v480=v484;}else{
const v487=__node(1,[a0.a[0],a0.a[1]]);
v480=v487;}
v477=v480;break;}
case 2:{
const v491=dFast_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[0],a1,a2);
const v495=dFast_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[1],a1,a2);
const v490=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v491,v495);
v477=v490;break;}
default:throw Error('literal constructor projection');}
v466=v477;}
return v466;}finally{__directDepth--;}}
function dFast_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(a0,a1,a2){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v499;switch(a0.c){
case 0:{
const v501=__node(1,[a1,a2]);
v499=v501;break;}
case 1:{
const v505=__node(1,[a1,a2]);
const v508=__node(1,[a0.a[0],a0.a[1]]);
const v504=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v505,v508);
v499=v504;break;}
case 2:{
const v512=dFast_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(a0.a[0],a1,a2);
const v511=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v512,a0.a[1]);
v499=v511;break;}
default:throw Error('literal constructor projection');}
return v499;}finally{__directDepth--;}}
function dFast_dd9122cd0ef5414b8f184fc5a412c2e0c7b9002cb5d701ef49dc7b9f5465679c(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v519=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v522=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v524=1n;
const v521=BigInt.asUintN(64,(v522)+(v524));
const v518=(v519)>(v521);
let v517;if(v518){
let v525;switch(a0.c){
case 0:{
const v527=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v525=v527;break;}
case 1:{
const v530=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v525=v530;break;}
case 2:{
const v533=dFast_c7ad7bdf333846cfdaf9c1cef5bcc98d8b1f5a0ca3c654237e21162cd70e16f6(a0.a[0],a0.a[1],a1);
v525=v533;break;}
default:throw Error('literal constructor projection');}
v517=v525;}else{
const v537=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v517=v537;}
return v517;}finally{__directDepth--;}}
function dFast_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v540;switch(a0.c){
case 0:{
const v542=__nullaryNode(0);
v540=v542;break;}
case 1:{
const v544=dFast_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0.a[2]);
const v543=dFast_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(v544,a0.a[0],a0.a[1]);
v540=v543;break;}
default:throw Error('literal constructor projection');}
return v540;}finally{__directDepth--;}}
function dFast_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v548;switch(a0.c){
case 0:{
const v551=dFast_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0.a[0]);
const v553=false;
const v555=__node(0,[a0.a[0]]);
const v557=__nullaryNode(0);
const v550=__node(0,[v551,v553,a1,v555,v557]);
v548=v550;break;}
default:throw Error('literal constructor projection');}
return v548;}finally{__directDepth--;}}
function dFast_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v558;switch(a0.c){
case 0:{
const v560=0n;
v558=v560;break;}
case 1:{
const v563=dFast_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(a0.a[1]);
const v561=BigInt.asUintN(64,(a0.a[0])+(v563));
v558=v561;break;}
default:throw Error('literal constructor projection');}
return v558;}finally{__directDepth--;}}
function dFast_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0,a1,a2){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v565;switch(a0.c){
case 0:{
const v567=__node(1,[a1,a2]);
v565=v567;break;}
case 1:{
const v571=(a1)<(a0.a[0]);
let v570;if(v571){
const v575=__node(1,[a1,a2]);
const v578=__node(1,[a0.a[0],a0.a[1]]);
const v574=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v575,v578);
v570=v574;}else{
const v582=__node(1,[a0.a[0],a0.a[1]]);
const v585=__node(1,[a1,a2]);
const v581=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v582,v585);
v570=v581;}
v565=v570;break;}
case 2:{
const v591=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0.a[0]);
const v589=(a1)<(v591);
let v588;if(v589){
const v594=dFast_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[0],a1,a2);
const v593=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v594,a0.a[1]);
v588=v593;}else{
const v601=dFast_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[1],a1,a2);
const v599=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(a0.a[0],v601);
v588=v599;}
v565=v588;break;}
default:throw Error('literal constructor projection');}
return v565;}finally{__directDepth--;}}
function dFast_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v605;switch(a0.c){
case 0:{
const v607=0n;
v605=v607;break;}
case 1:{
const v610=dFast_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(a0.a[1]);
const v608=BigInt.asUintN(64,(a0.a[0])+(v610));
v605=v608;break;}
default:throw Error('literal constructor projection');}
return v605;}finally{__directDepth--;}}
function f_186b6350f974a9daf5c57b97446437bb2cabe2a9241d8e38d84e02980089fef8(a0){return d_186b6350f974a9daf5c57b97446437bb2cabe2a9241d8e38d84e02980089fef8(a0);}
function f_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(a0){try{return dFast_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(a0);}catch(error){if(error!==__deepCall)throw error;return __run(d_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(a0));}}
function f_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(a0,a1,a2,a3,a4,a5){try{return dFast_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(a0,a1,a2,a3,a4,a5);}catch(error){if(error!==__deepCall)throw error;return __run(d_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(a0,a1,a2,a3,a4,a5));}}
function f_4d9946ad9a037d55daebbf6b4f332ecf1e985eca512336e0f0bb06e1d923e74d(a0){return d_4d9946ad9a037d55daebbf6b4f332ecf1e985eca512336e0f0bb06e1d923e74d(a0);}
function f_51991d73b93f2b8d1001d6179127db8fada9c9afc1e66821b78767b1a730d1a7(a0){return d_51991d73b93f2b8d1001d6179127db8fada9c9afc1e66821b78767b1a730d1a7(a0);}
function f_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1){try{return dFast_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1);}catch(error){if(error!==__deepCall)throw error;return __run(d_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1));}}
function f_896be328c068c766df31a09a848605651a0bde91d601f8fb585407c4d66fc3d6(a0){return d_896be328c068c766df31a09a848605651a0bde91d601f8fb585407c4d66fc3d6(a0);}
function f_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(a0,a1,a2,a3){try{return dFast_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(a0,a1,a2,a3);}catch(error){if(error!==__deepCall)throw error;return __run(d_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(a0,a1,a2,a3));}}
function f_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0){try{return dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0);}catch(error){if(error!==__deepCall)throw error;return __run(d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0));}}
function f_c7a490b328d4af7e7e805c851b135e47709dba5be887c644dc7356b711632d68(a0){return d_c7a490b328d4af7e7e805c851b135e47709dba5be887c644dc7356b711632d68(a0);}
function f_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1){try{return dFast_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1);}catch(error){if(error!==__deepCall)throw error;return __run(d_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1));}}
const __encoder=new TextEncoder();
function __keyCompare(a,b){if(typeof a==='string'&&typeof b==='string'){const x=__encoder.encode(a),y=__encoder.encode(b);for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]<y[i]?-1:1;return x.length-y.length;}return a<b?-1:a>b?1:0;}

// Portable snapshot ABI shared with native/Wasm. Hashing uses Web Crypto.
function __snapshotLimits(limits={}){
 const result={bytes:64*1024*1024,values:1000000,depth:128,...limits};
 for(const k of ['bytes','values','depth'])if(!Number.isSafeInteger(result[k])||result[k]<0||result[k]>(k==='depth'?128:k==='values'?1000000:64*1024*1024))throw Error('invalid snapshot limits');
 return result;
}
const __hash=async bytes=>new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256',bytes));
function __snapshotWriter(limits){
 const out=[];let left=limits.values;
 function bytes(xs){if(xs.length>limits.bytes-out.length)throw Error('snapshot byte limit exceeded');for(const x of xs)out.push(x);}
 function integer(n,size){n=BigInt(n);for(let i=0;i<size;i++){bytes([Number(n&255n)]);n>>=8n;}}
 function raw(xs){integer(xs.length,8);bytes(xs);}
 function value(v,t,depth=0,bindings=[]){if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{value(v,t.body,depth+1,bindings);}finally{bindings.pop();}break;
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');value(v,bound[1],depth+1,bindings);break;}
  case 'unit':break;case 'bool':bytes([v?1:0]);break;
  case 'u32':case 'i32':case 'f32':integer(v,4);break;case 'u64':integer(v,8);break;
  case 'vector':if(v.length!==t.size)throw Error('vector dimension mismatch');for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'int':{let n=v<0n?-v:v;const xs=[];while(n){if(xs.length>=4096)throw Error('snapshot Int exceeds size limit');xs.push(Number(n&255n));n>>=8n;}bytes([v===0n?0:v>0n?1:2]);raw(xs);break;}
  case 'string':raw(__encoder.encode(v));break;
  case 'id':integer(BigInt('0x'+v),16);break;
  case 'enum':integer(t.variants.indexOf(v),4);break;
  case 'record':for(const f of t.fields)value(v[f.name],f.type,depth+1,bindings);break;
  case 'list':if(v.length>left)throw Error('snapshot value limit exceeded');integer(v.length,8);for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'option':if(Object.hasOwn(v,'Some')){bytes([1]);value(v.Some,t.element,depth+1,bindings);}else bytes([0]);break;
  case 'result':if(Object.hasOwn(v,'Ok')){bytes([0]);value(v.Ok,t.ok,depth+1,bindings);}else{bytes([1]);value(v.Err,t.error,depth+1,bindings);}break;
  default:throw Error('unsupported snapshot type');
 }}
 return {bytes,integer,raw,value,get left(){return left;},finish:()=>new Uint8Array(out)};
}
async function __snapshotEncode(meta,state,options){
 const limits=__snapshotLimits(options),w=__snapshotWriter(limits);
 w.integer(state.version,8);
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const rows=[...state.tables[r.index].entries()].sort((a,b)=>__keyCompare(a[0],b[0],r.key));if(rows.length>Math.floor(w.left/2))throw Error('snapshot row limit exceeded');w.integer(rows.length,8);for(const [k,v]of rows){w.value(k,r.snapshotKey??r.key);w.value(v,r.snapshotValue??r.value);}}
 w.integer(state.outbox.length,8);
 for(const e of state.outbox){const channel=meta.events.findIndex(t=>t.name===e.channel);w.integer(e.commit,8);w.integer(e.position,8);w.integer(channel,4);w.value(e.value,meta.events[channel].snapshotType??meta.events[channel].type);}
 const payload=w.finish(),header=__snapshotWriter(limits);header.bytes([86,76,83,84,65,84,69,0,1,0,1,0]);header.bytes(meta.snapshot.program);header.bytes(meta.snapshot.schema);header.integer(payload.length,8);header.bytes(payload);
 const bytes=header.finish();if(bytes.length+32>limits.bytes)throw Error('snapshot byte limit exceeded');const digest=await __hash(bytes);const result=new Uint8Array(bytes.length+32);result.set(bytes);result.set(digest,bytes.length);return result;
}
async function __snapshotDecode(meta,input,options){
 const limits=__snapshotLimits(options);
 if(!(input instanceof Uint8Array)&&!Array.isArray(input))throw Error('expected snapshot bytes');
 if(input.length>limits.bytes||input.length<116)throw Error('snapshot byte length invalid');
 if(Array.isArray(input)&&input.some(b=>!Number.isInteger(b)||b<0||b>255))throw Error('invalid snapshot bytes');
 const bytes=new Uint8Array(input); // capture before asynchronous integrity work
 function same(a,b){return a.length===b.length&&a.every((v,i)=>v===b[i]);}
 if(!same(bytes.subarray(0,12),[86,76,83,84,65,84,69,0,1,0,1,0]))throw Error('snapshot format or semantics version mismatch');
 if(!same(bytes.subarray(12,44),meta.snapshot.program)||!same(bytes.subarray(44,76),meta.snapshot.schema))throw Error('snapshot program or schema identity mismatch');
 const end=bytes.length-32,digest=await __hash(bytes.subarray(0,end));if(!same(digest,bytes.subarray(end)))throw Error('snapshot integrity check failed');
 let at=76,left=limits.values;
 function take(n){if(!Number.isSafeInteger(n)||n<0||n>end-at)throw Error('truncated snapshot');const x=bytes.subarray(at,at+n);at+=n;return x;}
 function integer(size){const xs=take(size);let n=0n;for(let i=size-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return n;}
 function length(){const n=integer(8);if(n>BigInt(Number.MAX_SAFE_INTEGER))throw Error('snapshot length not addressable');return Number(n);}
 function sequence(){const n=length();if(n>left)throw Error('snapshot value limit exceeded');return n;}
 function raw(){return take(length());}
 const n=length();if(n!==end-84)throw Error('snapshot payload length mismatch');
 function value(t,depth=0,bindings=[]){if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{return value(t.body,depth+1,bindings);}finally{bindings.pop();}
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');return value(bound[1],depth+1,bindings);}
  case 'unit':return null;case 'bool':{const b=take(1)[0];if(b>1)throw Error('invalid Bool tag');return b===1;}
  case 'u32':case 'f32':return Number(integer(4));case 'i32':return Number(BigInt.asIntN(32,integer(4)));case 'u64':return integer(8);
  case 'vector':{const xs=[];for(let i=0;i<t.size;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'int':{const sign=take(1)[0],xs=raw();if(xs.length>4096)throw Error('snapshot Int exceeds size limit');if(!((sign===0&&xs.length===0)||((sign===1||sign===2)&&xs.length>0&&xs[xs.length-1]!==0)))throw Error('noncanonical signed integer');let n=0n;for(let i=xs.length-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return sign===2?-n:n;}
  case 'string':return new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(raw());
  case 'id':return integer(16).toString(16).padStart(32,'0');
  case 'enum':{const i=Number(integer(4));if(i>=t.variants.length)throw Error('invalid enum tag');return t.variants[i];}
  case 'record':return Object.fromEntries(t.fields.map(f=>[f.name,value(f.type,depth+1,bindings)]));
  case 'list':{const n=sequence(),xs=[];for(let i=0;i<n;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'option':{const tag=take(1)[0];if(tag===0)return {None:null};if(tag===1)return {Some:value(t.element,depth+1,bindings)};throw Error('invalid Option tag');}
  case 'result':{const tag=take(1)[0];if(tag===0)return {Ok:value(t.ok,depth+1,bindings)};if(tag===1)return {Err:value(t.error,depth+1,bindings)};throw Error('invalid Result tag');}
  default:throw Error('unsupported snapshot type');
 }}
 const version=integer(8),tables=meta.roots.map(()=>new Map());
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const n=sequence();if(n>Math.floor(left/2))throw Error('snapshot row limit exceeded');let prior;for(let i=0;i<n;i++){const k=value(r.snapshotKey??r.key),v=value(r.snapshotValue??r.value);if(i&&__keyCompare(prior,k,r.key)>=0)throw Error('duplicate or unordered snapshot key');tables[r.index].set(k,v);prior=k;}}
 const count=sequence(),outbox=[];let prior;
 for(let i=0;i<count;i++){const commit=integer(8),position=integer(8),channel=Number(integer(4));if(!meta.events[channel])throw Error('unknown snapshot event channel');const v=value(meta.events[channel].snapshotType??meta.events[channel].type);if(commit===0n||commit>version||(prior&&(commit<prior.commit||(commit===prior.commit&&position<=prior.position))))throw Error('invalid snapshot event sequence');const e={commit,position,channel:meta.events[channel].name,value:v};outbox.push(e);prior=e;}
 if(at!==end)throw Error('trailing snapshot payload');return {version,tables,outbox};
}
function read_0(v,d=0,internal=false){return v;}
function write_0(v,d=0,snapshot=false){return v;}
function read_1(v,d=0,internal=false){return v;}
function write_1(v,d=0,snapshot=false){return v;}
function read_2(v,d=0,internal=false){return __node(0,[]);}
function write_2(v,d=0,snapshot=false){return null;}
function read_3(v,d=0,internal=false){let tail=__node(0,[]);for(let i=v.length-1;i>=0;i--)tail=__node(1,[read_1(v[i],d+1,internal),tail]);return tail;}
function write_3(v,d=0,snapshot=false){let cursor=v;const xs=[];while(cursor.c!==0){xs.push(write_1(cursor.a[0],d+1,snapshot));cursor=cursor.a[1];}return xs;}
function read_4(v,d=0,internal=false){let tail=__node(0,[]);for(let i=v.length-1;i>=0;i--)tail=__node(1,[read_6(v[i],d+1,internal),tail]);return tail;}
function write_4(v,d=0,snapshot=false){let cursor=v;const xs=[];while(cursor.c!==0){xs.push(write_6(cursor.a[0],d+1,snapshot));cursor=cursor.a[1];}return xs;}
function read_5(v,d=0,internal=false){switch(v){case "Error.Failed":return __node(0,[]);default:return undefined;}}
function write_5(v,d=0,snapshot=false){return ["Error.Failed"][v.c];}
function read_6(v,d=0,internal=false){return __node(0,[read_1(v["value"],d+1,internal),read_0(v["active"],d+1,internal)]);}
function write_6(v,d=0,snapshot=false){return Object.fromEntries([["value",write_1(v.a[0],d+1,snapshot)],["active",write_0(v.a[1],d+1,snapshot)]]);}
function read_7(v,d=0,internal=false){if(Object.hasOwn(v,'Some'))return __node(1,[read_6(v.Some,d+1,internal)]);return __node(0,[]);}
function write_7(v,d=0,snapshot=false){return v.c===0?{None:null}:{Some:write_6(v.a[0],d+1,snapshot)};}
function read_8(v,d=0,internal=false){if(Object.hasOwn(v,'Ok'))return __node(0,[read_2(v.Ok,d+1,internal)]);return __node(1,[read_5(v.Err,d+1,internal)]);}
function write_8(v,d=0,snapshot=false){return v.c===0?{Ok:write_2(v.a[0],d+1,snapshot)}:{Err:write_5(v.a[0],d+1,snapshot)};}
const __meta={"events":[{"name":"seen","snapshotType":{"kind":"u64"},"type":{"kind":"u64"}}],"roots":[{"key":{"kind":"u64"},"name":"Rows","snapshotKey":{"kind":"u64"},"snapshotValue":{"fields":[{"name":"value","type":{"kind":"u64"}},{"name":"active","type":{"kind":"bool"}}],"kind":"record"},"value":{"fields":[{"name":"value","type":{"kind":"u64"}},{"name":"active","type":{"kind":"bool"}}],"kind":"record","name":"Row"}}],"snapshot":{"program":[52,20,97,227,197,216,139,58,45,98,73,196,205,50,83,26,202,227,210,13,109,164,33,109,207,238,49,79,213,123,165,218],"schema":[217,47,159,252,204,85,237,70,76,82,248,36,231,99,128,206,40,43,134,247,81,235,124,169,208,7,125,5,136,138,247,164]}};
function __fromTables(tables){const roots=[];
{const rows=[...tables[0].entries()];let prior,tail=__node(0,[]);for(let j=rows.length-1;j>=0;j--){const [key,value]=rows[j];tail=__node(1,[read_1(key,0,true),read_6(value,0,true),tail]);}roots.push(tail);}
return __node(0,roots);}
function __tables(logical){const tables=[];
{let cursor=logical.a[0],prior;const rows=new Map();while(cursor.c!==0){const [key,value,tail]=cursor.a;rows.set(write_1(key,0,true),write_6(value,0,true));cursor=tail;}tables.push(rows);}
return tables;}
function __events(list){const events=[];let cursor=list;while(cursor.c!==0){const [event,tail]=cursor.a;switch(event.c){
case 0:events.push(["seen", write_1(event.a[0],0,true), write_1(event.a[0],0,false)]);break;
default:throw Error('unknown source event');}cursor=tail;}return events;}
// CALLER CONTRACT: arguments must have declared types and canonical values.
// Malformed data may throw, produce wrong results or corrupt state.
export function createState(){let version=0n,outbox=[],busy=false,transaction=null;
const initial=__node(0,[__node(0,[])]);let physical=f_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(initial);
const preconditions={};
function boundary(){if(busy)throw Error('state operation already in progress');}
function invoke_native(name,args,resultOnly=false){boundary();if(preconditions[name] && invoke_native(preconditions[name],args,true)!==true)throw Error('contract precondition failed');switch(name){
case "put":{
const a0=read_1(args[0],0);
const a1=read_1(args[1],0);
const a2=read_0(args[2],0);
const a3=read_0(args[3],0);
const executed=f_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(physical,version,a0,a1,a2,a3);const observed=f_c7a490b328d4af7e7e805c851b135e47709dba5be887c644dc7356b711632d68(executed),next=f_4d9946ad9a037d55daebbf6b4f332ecf1e985eca512336e0f0bb06e1d923e74d(executed);if(observed.c===1)throw Error('commit sequence exhausted');const [reply,committed,newVersion,events]=observed.a;const result=write_8(reply,0,false),staged=__events(events),published=[];
if(committed){for(let i=0;i<staged.length;i++){const [channel,value,publicValue]=staged[i];outbox.push({commit:newVersion,position:BigInt(i),channel,value});if(!resultOnly)published.push({commit:newVersion,position:BigInt(i),channel,value:publicValue});}}physical=next;version=newVersion;return resultOnly?result:{result,committed,version,events:published};}
case "erase":{
const a0=read_1(args[0],0);
const a1=read_0(args[1],0);
const executed=f_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(physical,version,a0,a1);const observed=f_c7a490b328d4af7e7e805c851b135e47709dba5be887c644dc7356b711632d68(executed),next=f_4d9946ad9a037d55daebbf6b4f332ecf1e985eca512336e0f0bb06e1d923e74d(executed);if(observed.c===1)throw Error('commit sequence exhausted');const [reply,committed,newVersion,events]=observed.a;const result=write_8(reply,0,false),staged=__events(events),published=[];
if(committed){for(let i=0;i<staged.length;i++){const [channel,value,publicValue]=staged[i];outbox.push({commit:newVersion,position:BigInt(i),channel,value});if(!resultOnly)published.push({commit:newVersion,position:BigInt(i),channel,value:publicValue});}}physical=next;version=newVersion;return resultOnly?result:{result,committed,version,events:published};}
case "total_query":{
const executed=f_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(physical,version);const observed=f_896be328c068c766df31a09a848605651a0bde91d601f8fb585407c4d66fc3d6(executed),next=f_186b6350f974a9daf5c57b97446437bb2cabe2a9241d8e38d84e02980089fef8(executed);if(observed.c===1)throw Error('commit sequence exhausted');const [reply,committed,newVersion,events]=observed.a;const result=write_1(reply,0,false),staged=__events(events),published=[];
if(committed){for(let i=0;i<staged.length;i++){const [channel,value,publicValue]=staged[i];outbox.push({commit:newVersion,position:BigInt(i),channel,value});if(!resultOnly)published.push({commit:newVersion,position:BigInt(i),channel,value:publicValue});}}physical=next;version=newVersion;return resultOnly?result:{result,committed,version,events:published};}
case "count_query":{
const executed=f_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(physical,version);const observed=f_51991d73b93f2b8d1001d6179127db8fada9c9afc1e66821b78767b1a730d1a7(executed),next=f_186b6350f974a9daf5c57b97446437bb2cabe2a9241d8e38d84e02980089fef8(executed);if(observed.c===1)throw Error('commit sequence exhausted');const [reply,committed,newVersion,events]=observed.a;const result=write_1(reply,0,false),staged=__events(events),published=[];
if(committed){for(let i=0;i<staged.length;i++){const [channel,value,publicValue]=staged[i];outbox.push({commit:newVersion,position:BigInt(i),channel,value});if(!resultOnly)published.push({commit:newVersion,position:BigInt(i),channel,value:publicValue});}}physical=next;version=newVersion;return resultOnly?result:{result,committed,version,events:published};}
default:throw Error(`unknown action ${name}`);}}
async function invoke_json(name,args){return invoke_native(name,args);}
const actionNames=new Set(["put","erase","total_query","count_query"]);
return Object.freeze({invoke:invoke_json,invoke_json,bind(name,{resultOnly=false}={}){if(!actionNames.has(name))throw Error(`unknown action ${name}`);return (...args)=>invoke_native(name,args,resultOnly);},beginTransaction(){boundary();if(transaction)throw Error('state transaction already in progress');transaction={physical,version,outbox,length:outbox.length};return true;},commitTransaction(){boundary();if(!transaction)throw Error('no state transaction');transaction=null;},rollbackTransaction(){boundary();if(!transaction)throw Error('no state transaction');physical=transaction.physical;version=transaction.version;outbox=transaction.outbox;outbox.length=transaction.length;transaction=null;},get version(){return version;},get outbox(){return outbox.map(e=>({...e,value:__publicEvent(e.channel,e.value)}));},acknowledge_through(commit,position){boundary();commit=BigInt(commit);position=BigInt(position);outbox=outbox.filter(e=>e.commit>commit||(e.commit===commit&&e.position>position));},async checkpoint(limits){boundary();
const logical=f_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(physical);return __snapshotEncode(__meta,{version,tables:__tables(logical),outbox},limits);},async restore(bytes,limits){boundary();if(transaction)throw Error('restore during state transaction');busy=true;try{const saved=await __snapshotDecode(__meta,bytes,limits);const logical=__fromTables(saved.tables);
const next=f_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(logical);
physical=next;version=saved.version;outbox=saved.outbox;}finally{busy=false;}}});}
function __publicEvent(channel,value){switch(channel){
case "seen":return write_1(read_1(value,0,true),0,false);
default:throw Error('unknown source event');}}
