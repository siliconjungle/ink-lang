const __recordElisions=new Set([]);
const __nativeF32=false;
// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
// Binary64 uses native Numbers for finite arithmetic and immutable private
// tags only where a NaN's exact payload must survive non-arithmetic operations.
const __doubleView=new DataView(new ArrayBuffer(8));
const __double=bits=>{__doubleView.setBigUint64(0,bits,true);return __doubleView.getFloat64(0,true);};
const __doubleBits=number=>{if(Number.isNaN(number))return 0x7ff8000000000000n;__doubleView.setFloat64(0,number,true);return __doubleView.getBigUint64(0,true);};
const __dfNumber=value=>typeof value==='number'?value:__double(BigInt(value.F64Bits));
const __dfBits=value=>typeof value==='number'?__doubleBits(value):BigInt(value.F64Bits);
const __dfFromBits=bits=>(bits&0x7fffffffffffffffn)>0x7ff0000000000000n?Object.freeze({F64Bits:bits.toString()}):__double(bits);
const __dfInput=value=>typeof value==='number'?value:__dfFromBits(BigInt(value.F64Bits));
const __dfNeg=value=>typeof value==='number'&&!Number.isNaN(value)?-value:__dfFromBits(__dfBits(value)^0x8000000000000000n);
const __dfOutput=value=>{const n=__dfNumber(value);return Number.isFinite(n)?n:{F64Bits:__dfBits(value).toString()};};
const __dfCapture=value=>{
 if(typeof value==='number'&&Number.isFinite(value))return value;
 if(!value||typeof value!=='object'||Object.keys(value).length!==1||!Object.hasOwn(value,'F64Bits'))throw Error('invalid f64');const text=value.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid f64');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');return __dfFromBits(bits);
};
// Native binary32 lane for pure modules. Explicit NaN payloads remain tagged;
// arithmetic canonicalizes NaNs just as __bits does in the exact-bit lane.
const __nfValue = value => typeof value === 'number' ? Math.fround(value) : value;
// Number operands have already been normalised at their typed read or producer.
const __nfNumber = value => typeof value === 'number' ? value : __float(value.F32Bits);
const __nfBits = value => typeof value === 'number' ? __bits(value) : value.F32Bits;
const __nfFromBits = bits => (bits & 0x7fffffff)>0x7f800000 ? {F32Bits:bits} : __float(bits);
const __nfNeg = value => typeof value === 'number' && !Number.isNaN(value) ? -value : {F32Bits:(__nfBits(value) ^ 0x80000000) >>> 0};
const __nfOutput = value => {const n=typeof value==='number'?Math.fround(value):__float(value.F32Bits);return Number.isFinite(n)?n:{F32Bits:__nfBits(value)};};
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output, capture=false) {
  const convert=__representationRaw(type,output,capture);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':capture?'capture:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output, capture) {
  switch (type.kind) {
    case 'ref': {
      let resolved;
      return (value,context)=>(resolved??=__representation(__namedTypes[type.name],output,capture))(value,context);
    }
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output,capture);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output,capture),err=__representation(type.error,output,capture);
      const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);
      if(flat)return output?(value,context)=>{const v=__sumView(key,value);return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};}:(v,context)=>Object.hasOwn(v,'Ok')?__sumMake(key,true,ok(v.Ok,context)):__sumMake(key,false,err(v.Err,context));
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f64':return output?__dfOutput:__dfInput;
    case 'f32': if(typeof __nativeF32!=='undefined'&&__nativeF32)return output?__nfOutput:capture?__nfValue:__identity;
      return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output,capture);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){
        if(!type.fields.length)return ()=>undefined; // lexically unconsumed projected input
        const field=type.fields[0],child=__representation(field.type,output,capture);
        return output?(value,context)=>({[field.name]:child(value,context)}):(value,context)=>child(value[field.name],context);
      }
      const fields = type.fields.map(field => [field.name, __representation(field.type, output,capture)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
function __stateWord(value){
 if(typeof value==='number'&&!Number.isSafeInteger(value))throw Error('u64 requires an exact integer');
 if(!['bigint','number','string'].includes(typeof value)||typeof value==='string'&&!/^(0|[1-9][0-9]*)$/.test(value))throw Error('invalid u64');
 const n=BigInt(value);if(n<0n||n>18446744073709551615n)throw Error('invalid u64');return n;
}
// Compile the capture traversal once. Each invocation still validates and owns
// every public container; no host value is retained between calls.
const __stateCaptures=new WeakMap();
function __stateCapture(type){
 const prior=__stateCaptures.get(type);if(prior)return prior;
 const capture=__compileStateCapture(type);__stateCaptures.set(type,capture);return capture;
}
function __compileStateCapture(type){
 const limited=copy=>(value,budget={cells:1000000},depth=0)=>{
  if(depth>64||--budget.cells<0)throw Error('state input resource limit');
  return copy(value,budget,depth);
 };
 const tagged=(value,tag)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
 switch(type.kind){
  case 'ref':{
   // Resolve lazily so recursive schemas compile to recursive validators rather
   // than reverting to descriptor interpretation at every referenced node.
   let resolved;
   return limited((value,budget,depth)=>(resolved??=__stateCapture(__namedTypes[type.name]))(value,budget,depth+1));
  }
  case 'u32':case 'i32':{
   const min=type.kind==='u32'?0:-2147483648,max=type.kind==='u32'?4294967295:2147483647;
   return limited(value=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;});
  }
  case 'u64':return limited(__stateWord);
  case 'f64':return limited(__dfCapture);
  case 'bool':return limited(value=>{if(typeof value!=='boolean')throw Error('invalid Bool');return value;});
  case 'unit':return limited(value=>{if(value!==null)throw Error('invalid Unit');return null;});
  case 'string':return limited(value=>{if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;});
  case 'enum':return limited(value=>{if(!type.variants.includes(value))throw Error('invalid enum');return value;});
  case 'id':return limited(value=>{if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();});
  case 'list':case 'vector':{
   const item=__stateCapture(type.element),size=type.kind==='vector'?type.size:null;
   return limited((value,budget,depth)=>{
    if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
    if(size!==null&&value.length!==size)throw Error('invalid vector length');
    const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=item(value[i],budget,depth+1);return out;
   });
  }
  case 'record':{
   const fields=type.fields.map(f=>[f.name,__stateCapture(f.type)]);
   if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name)))return limited((value,budget,depth)=>{const [name,copy]=fields[0];if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,name))throw Error('invalid record');return copy(value[name],budget,depth+1);});
   return limited((value,budget,depth)=>{
    if(!value||typeof value!=='object'||Array.isArray(value)||!fields.every(([name])=>Object.hasOwn(value,name)))throw Error('invalid record');
    const out={};for(const [name,copy]of fields){const field=copy(value[name],budget,depth+1);if(name==='__proto__')Object.defineProperty(out,name,{value:field,writable:true,enumerable:true,configurable:true});else out[name]=field;}return out;
   });
  }
  case 'option':{
   const item=__stateCapture(type.element);
   return limited((value,budget,depth)=>{if(tagged(value,'Some'))return {Some:item(value.Some,budget,depth+1)};if(tagged(value,'None')&&value.None===null)return {None:null};throw Error('invalid Option');});
  }
  case 'result':{
   const ok=__stateCapture(type.ok),err=__stateCapture(type.error);
   return limited((value,budget,depth)=>{if(tagged(value,'Ok'))return {Ok:ok(value.Ok,budget,depth+1)};if(tagged(value,'Err'))return {Err:err(value.Err,budget,depth+1)};throw Error('invalid Result');});
  }
  default:return (value,budget,depth)=>__stateInput(value,type,budget,depth);
 }
}
function __stateInput(value,type,budget={cells:1000000},depth=0,maxDepth=64){
  if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');
  const input=(v,t)=>__stateInput(v,t,budget,depth+1,maxDepth);
  const integer=(min,max)=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;};
  const tagged=tag=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
  switch(type.kind){
    case 'ref':return input(value,__namedTypes[type.name]);
    case 'u32':return integer(0,4294967295);
    case 'i32':return integer(-2147483648,2147483647);
    case 'u64':return __stateWord(value);
    case 'int':{
      if(typeof value==='bigint')return value;
      if(!tagged('Int')||typeof value.Int!=='string'||!/^(-?[0-9]+)$/.test(value.Int))throw Error('invalid Int');return BigInt(value.Int);
    }
    case 'f64':return __dfCapture(value);
    case 'f32':{
      if(typeof value==='number'&&Number.isFinite(value)){const bits=__bits(value);if((bits&0x7fffffff)===0x7f800000)throw Error('f32 overflow requires F32Bits');return bits;}
      if(!tagged('F32Bits')||!Number.isInteger(value.F32Bits)||value.F32Bits<0||value.F32Bits>4294967295)throw Error('invalid f32');return value.F32Bits;
    }
    case 'bool':if(typeof value!=='boolean')throw Error('invalid Bool');return value;
    case 'unit':if(value!==null)throw Error('invalid Unit');return null;
    case 'string':if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;
    case 'id':if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();
    case 'enum':if(!type.variants.includes(value))throw Error('invalid enum');return value;
    case 'list':case 'vector':{
      if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
      if(type.kind==='vector'&&value.length!==type.size)throw Error('invalid vector length');
      return Array.from(value,v=>input(v,type.element));
    }
    case 'record':if(!value||typeof value!=='object'||Array.isArray(value)||!type.fields.every(f=>Object.hasOwn(value,f.name)))throw Error('invalid record');if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){const f=type.fields[0];return input(value[f.name],f.type);}return Object.fromEntries(type.fields.map(f=>[f.name,input(value[f.name],f.type)]));
    case 'option':if(tagged('Some'))return {Some:input(value.Some,type.element)};if(tagged('None')&&value.None===null)return {None:null};throw Error('invalid Option');
    case 'result':{const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);if(tagged('Ok')){const child=input(value.Ok,type.ok);return flat?__sumMake(key,true,child):{Ok:child};}if(tagged('Err')){const child=input(value.Err,type.error);return flat?__sumMake(key,false,child):{Err:child};}throw Error('invalid Result');}
    default:throw Error('unsupported public value type');
  }
}
// Mutable host replies must not retain references into compiled state or its outbox.
// State results must own mutable containers. Compile the declared schema once:
// scalars need no structured clone, while nested records/lists remain detached.
function __ownershipSchema(type){
 // Nominal references and expanded declarations name the same checked sort.
 // Distinct source records retain distinct keys even if a layout erases them.
 if(type.kind==='ref'||type.kind==='record'&&type.name)return ['named',type.name];
 switch(type.kind){
  case 'list':case 'vector':return [type.kind,type.size??null,__ownershipSchema(type.element)];
  case 'option':return ['option',__ownershipSchema(type.element)];
  case 'result':return ['result',__ownershipSchema(type.ok),__ownershipSchema(type.error)];
  case 'record':return ['record',type.fields.map(f=>[f.name,__ownershipSchema(f.type)])];
  default:return type;
 }
}
function __ownedResult(copy,nested,type){
 const key='owned-state:'+JSON.stringify(__ownershipSchema(type));
 let schema=__conversionKeys.get(key);
 if(!schema){schema={};__conversionKeys.set(key,schema);}
 const owned=(value,context)=>{
  if(!context&&!nested)return copy(value,null);
  const memo=context||new WeakMap();
  if(value===null||typeof value!=='object')return copy(value,memo);
  let entries=memo.get(schema);if(!entries){entries=new WeakMap();memo.set(schema,entries);}
  if(entries.has(value))return entries.get(value);
  const result=copy(value,memo);entries.set(value,result);return result;
 };
 owned.container=true;return owned;
}
function __stateResult(type){
 switch(type.kind){
  case 'ref':{let resolved;const copy=(value,context)=>(resolved??=__stateResult(__namedTypes[type.name]))(value,context);copy.container=true;return copy;}
  case 'record':{if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){const f=type.fields[0],copy=__stateResult(f.type);return __ownedResult((value,context)=>({[f.name]:copy(value,context)}),copy.container,type);}const fields=type.fields.map(f=>[f.name,__stateResult(f.type)]);return __ownedResult((value,context)=>Object.fromEntries(fields.map(([name,copy])=>[name,copy(value[name],context)])),fields.some(([,copy])=>copy.container),type);}
  case 'list':case 'vector':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Array.from(value,item=>copy(item,context)),copy.container,type);}
  case 'option':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Object.hasOwn(value,'Some')?{Some:copy(value.Some,context)}:{None:null},copy.container,type);}
  case 'result':{const ok=__stateResult(type.ok),err=__stateResult(type.error),key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);return __ownedResult((value,context)=>{const v=flat?__sumView(key,value):value;return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};},ok.container||err.container,type);}
  default:return __representation(type,true);
 }
}
function __stateOutput(value,type){return __stateResult(type)(value);}
const __u64 = n => BigInt.asUintN(64, n);
function __div(a, b, fallback, signed, remainder) {
  if (b === 0 || b === 0n || (signed && a === -2147483648 && b === -1)) return fallback();
  return typeof a === 'bigint' ? (remainder ? a % b : a / b) :
    ((remainder ? a % b : Math.trunc(a / b)) + 0); // integer zero has no sign
}
function __at(xs, index, fallback) { return index < xs.length ? xs[index] : fallback(); }
// Ordinary arrays retain the declared result element type when input is typed.
function __map(xs, fn) {
  const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = fn(xs[i], i);
  return out;
}
function __filter(xs, fn) {
  const out = [];
  for (let i = 0; i < xs.length; i++) if (fn(xs[i])) out.push(xs[i]);
  return out;
}
function __concat(xs, ys) {
  const left = xs.length, right = ys.length, out = new Array(left + right);
  for (let i = 0; i < left; i++) out[i] = xs[i];
  for (let i = 0; i < right; i++) out[left + i] = ys[i];
  return out;
}
function __zip(xs, ys, fn) {
  const n = Math.min(xs.length, ys.length), out = new Array(n);
  for (let i = 0; i < n; i++) out[i] = fn(xs[i], ys[i]);
  return out;
}
function __repeat(n, initial, fn) { let value = initial; for (let i = 0; i < n; i++) value = fn(i, value); return value; }
function __foldr(xs, initial, fn) { let value = initial; for (let i = xs.length - 1; i >= 0; i--) value = fn(xs[i], value); return value; }
function __scan(xs, zero, add) {
  let value = zero; const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = value = add(value, xs[i]);
  return out;
}
const __sort = xs => Array.from(xs).sort((a,b) => a < b ? -1 : a > b ? 1 : 0);

function __wordSort(xs,Storage){
 const sorted=Storage.from(xs).sort(),out=new Array(sorted.length);
 for(let i=0;i<sorted.length;i++)out[i]=sorted[i];
 return out;
}
// Affine buffers expose bounded disjoint ranges over one allocation. Source
// ownership prevents retaining a parent; growth detaches shared ranges.
// Elements cannot own temporary storage: they are immutable logical values.
// Copy the slot array when acquiring ownership, never the reachable records.
class __InkBuffer {
 constructor(data,start=0,end=data.length,shared=false){this.data=data;this.start=start;this.end=end;this.shared=shared;}
 get length(){return this.end-this.start;}
 set length(n){this.end=this.start+Math.min(this.length,n);if(!this.shared&&this.start===0)this.data.length=this.end;}
 item(i){return this.data[this.start+i];}
 range(start,count){const begin=this.start+Math.min(start,this.length);return new __InkBuffer(this.data,begin,begin+Math.min(count,this.end-begin),true);}
 set(i,v){if(i<this.length)this.data[this.start+i]=v;return this;}
 swap(a,b){if(a<this.length&&b<this.length){const x=this.item(a);this.set(a,this.item(b));this.set(b,x);}return this;}
 fill_range(start,count,value){start=Math.min(start,this.length);count=Math.min(count,this.length-start);this.data.fill(value,this.start+start,this.start+start+count);return this;}
 copy_within(source,destination,count){source=Math.min(source,this.length);destination=Math.min(destination,this.length);count=Math.min(count,this.length-source,this.length-destination);this.data.copyWithin(this.start+destination,this.start+source,this.start+source+count);return this;}
 detach(){if(this.shared||this.start!==0||this.end!==this.data.length){this.data=this.data.slice(this.start,this.end);this.start=0;this.end=this.data.length;this.shared=false;}}
 push(v){if(this.length>=4294967295)throw Error('buffer length exhausted');this.detach();this.data.push(v);this.end++;return this;}
 pop(){this.length=Math.max(0,this.length-1);return this;}
 truncate(n){this.length=Math.min(this.length,n);return this;}
 slice(start=0,end=this.length){return this.data.slice(this.start+start,this.start+Math.min(end,this.length));}
 freeze(){return this.start===0&&this.end===this.data.length?this.data:this.data.slice(this.start,this.end);}
 *[Symbol.iterator](){for(let i=this.start;i<this.end;i++)yield this.data[i];}
}
function __bufferSplit(x,at){const cut=x.start+Math.min(at,x.length);x.shared=true;return [new __InkBuffer(x.data,x.start,cut,true),new __InkBuffer(x.data,cut,x.end,true)];}
function __bufferAppend(a,b){
 if(a.length+b.length>4294967295)throw Error('buffer length exhausted');
 if(a.data===b.data&&a.end===b.start)return new __InkBuffer(a.data,a.start,b.end,a.start!==0||b.end!==a.data.length);
 a.detach();for(const item of b)a.push(item);return a;
}

function __repeat_until(limit,acc,stop,step){for(let i=0;i<limit;i++){if(stop(acc))break;acc=step(i,acc);}return acc;}
function __bufferFill(n,v){return new __InkBuffer(new Array(n).fill(v));}
function __mapGet(m,k,f){return m.has(k)?m.get(k):f();}
function __mapEntries(m,keys){return [...m.entries()].sort(([a],[b])=>a<b?-1:a>b?1:0).map(([k,v])=>keys?k:v);}
function __tempSet(x,k,v,map){x.set(k,v);return x;}
function __bufferSwap(x,a,b){return x.swap(a,b);}
function __tempEdit(x,op,...args){if(op==='push'){x.push(args[0]);}else if(op==='pop')x.pop();else if(op==='truncate')x.truncate(args[0]);else if(op==='remove')x.delete(args[0]);return x;}
// Fixed word semantics, including arithmetic signed right shift. Shift and
// rotation counts wrap modulo width; no source-pattern optimisation lives here.
function __word(op,a,b,bits) {
  const width=BigInt(Math.abs(bits)), k=BigInt(b??0)%width;
  const x=BigInt(a), y=BigInt(b??0), unsigned=BigInt.asUintN(Number(width),x);
  let r;
  switch(op) {
    case 'word_widen_u32_to_u64':case 'word_narrow_u64_to_u32':r=x;break;
    case 'word_not':r=~x;break;
    case 'word_and':r=x&y;break;
    case 'word_or':r=x|y;break;
    case 'word_xor':r=x^y;break;
    case 'wrapping_shl':r=x<<k;break;
    case 'wrapping_shr':r=x>>k;break;
    case 'rotate_left':r=(unsigned<<k)|(unsigned>>(width-k));break;
    case 'rotate_right':r=(unsigned>>k)|(unsigned<<(width-k));break;
    default:throw new Error('unknown word operation');
  }
  r=bits<0?BigInt.asIntN(Number(width),r):BigInt.asUintN(Number(width),r);
  return bits===64?r:Number(r);
}
// Rotations evaluate each operand once. Counts wrap modulo the width.
function __rotl32(a,k){k&=31;return (a<<k)|(a>>>((32-k)&31));}
function __rotr32(a,k){k&=31;return (a>>>k)|(a<<((32-k)&31));}
function __rotl64(a,k){const n=BigInt(k&63);return BigInt.asUintN(64,(a<<n)|(a>>((64n-n)&63n)));}
function __rotr64(a,k){const n=BigInt(k&63);return BigInt.asUintN(64,(a>>n)|(a<<((64n-n)&63n)));}
function __fn0(v0,v1,v2){
let v3=v2;
for(let v4=0;v4<v0.length;v4++){
const v5=v0[v4];
const v6="Op.Scale";
let v7;if((v5===v6)){
const v8=v3;
const v9=v1["scale"];
v7=__bits(__float(v8) * __float(v9));}else{
const v10="Op.Bias";
let v11;if((v5===v10)){
const v12=v3;
const v13=v1["bias"];
v11=__bits(__float(v12) + __float(v13));}else{
const v14="Op.Relu";
let v15;if((v5===v14)){
const v16=v3;
const v17=0;
let v18;if(((__float(v16)) > (__float(v17)))){
v18=v3;}else{
v18=0;}
v15=v18;}else{
v15=v3;}
v11=v15;}
v7=v11;}
v3=v7;
}
return v3;}
function __fn1(v19){
const v20=Number.isFinite(__float(v19["scale"]));
let v21=v20;if(v21){
const v22=v19["scale"];
const v23=1048576000;
v21=((__float(v22)) >= (__float(v23)));}
const v24=v21;
let v25=v24;if(v25){
const v26=v19["scale"];
const v27=1065353216;
v25=((__float(v26)) <= (__float(v27)));}
const v28=v25;
let v29=v28;if(v29){
v29=Number.isFinite(__float(v19["bias"]));}
const v30=v29;
let v31=v30;if(v31){
const v32=v19["bias"];
const v33=0;
v31=((__float(v32)) >= (__float(v33)));}
const v34=v31;
let v35=v34;if(v35){
const v36=v19["bias"];
const v37=1056964608;
v35=((__float(v36)) <= (__float(v37)));}
return v35;}
function __fn2(v38){
const v39=(v38["samples"]).length;
const v40=0;
const v41=((v39) > (v40));
let v42=v41;if(v42){
const v43=(v38["samples"]).length;
const v44=32;
v42=((v43) <= (v44));}
const v45=v42;
let v46=v45;if(v46){
v46=Number.isFinite(__float(v38["instruction_cost"]));}
const v47=v46;
let v48=v47;if(v48){
const v49=v38["instruction_cost"];
const v50=0;
v48=((__float(v49)) >= (__float(v50)));}
const v51=v48;
let v52=v51;if(v52){
const v53=v38["instruction_cost"];
const v54=1008981770;
v52=((__float(v53)) <= (__float(v54)));}
const v55=v52;
let v56=v55;if(v56){
const v57=v38["samples"];
let v58=true;
for(let v59=0;v59<v57.length;v59++){
const v60=v57[v59];
const v61=v58;
let v62=v61;if(v62){
v62=Number.isFinite(__float(v60["input"]));}
const v63=v62;
let v64=v63;if(v64){
const v65=v60["input"];
const v66=1082130432;
const v67=((v66 ^ 2147483648) >>> 0);
v64=((__float(v65)) >= (__float(v67)));}
const v68=v64;
let v69=v68;if(v69){
const v70=v60["input"];
const v71=1082130432;
v69=((__float(v70)) <= (__float(v71)));}
const v72=v69;
let v73=v72;if(v73){
v73=Number.isFinite(__float(v60["target"]));}
const v74=v73;
let v75=v74;if(v75){
const v76=v60["target"];
const v77=1107296256;
const v78=((v77 ^ 2147483648) >>> 0);
v75=((__float(v76)) >= (__float(v78)));}
const v79=v75;
let v80=v79;if(v80){
const v81=v60["target"];
const v82=1107296256;
v80=((__float(v81)) <= (__float(v82)));}
v58=v80;
}
v56=v58;}
return v56;}
function __fn3(v83,v84,v85){
const v86=v85["input"];
const v87=__fn0(v83,v84,v86);
const v88=v85["target"];
const v89=__bits(__float(v87) - __float(v88));
return __bits(__float(v89) * __float(v89));}
function __fn4(v90,v91,v92){
const v93=v92["samples"];
let v94=0;
for(let v95=0;v95<v93.length;v95++){
const v96=v93[v95];
const v97=v94;
const v98=__fn3(v90,v91,v96);
v94=__bits(__float(v97) + __float(v98));
}
const v99=v94;
let v100=0;
for(let v101=0;v101<v90.length;v101++){
const v102=v90[v101];
const v103=v100;
const v104="Op.Identity";
let v105;if((v102===v104)){
v105=0;}else{
v105=1065353216;}
const v106=v105;
v100=__bits(__float(v103) + __float(v106));
}
const v107=v100;
const v108=__bits((__float(v99))/(__float(__bits((v92["samples"]).length))));
const v109=v92["instruction_cost"];
const v110=__bits(__float(v109) * __float(v107));
return __bits(__float(v108) + __float(v110));}
function __fn5(v111){
const v112=0;
let v113;if(v112<v111.length){v113=v111[v112];}else{
v113=1065353216;}
const v114=v113;
const v115=1;
let v116;if(v115<v111.length){v116=v111[v115];}else{
v116=1065353216;}
const v117=v116;
const v118=2;
let v119;if(v118<v111.length){v119=v111[v118];}else{
v119=1065353216;}
const v120=v119;
const v121=3;
let v122;if(v121<v111.length){v122=v111[v121];}else{
v122=1065353216;}
const v123=v122;
const v124=({["identity"]:v114,["scale"]:v117,["bias"]:v120,["relu"]:v123});
const v125=4;
let v126;if(v125<v111.length){v126=v111[v125];}else{
v126=1065353216;}
const v127=v126;
const v128=5;
let v129;if(v128<v111.length){v129=v111[v128];}else{
v129=1065353216;}
const v130=v129;
const v131=6;
let v132;if(v131<v111.length){v132=v111[v131];}else{
v132=1065353216;}
const v133=v132;
const v134=7;
let v135;if(v134<v111.length){v135=v111[v134];}else{
v135=1065353216;}
const v136=v135;
const v137=({["identity"]:v127,["scale"]:v130,["bias"]:v133,["relu"]:v136});
const v138=8;
let v139;if(v138<v111.length){v139=v111[v138];}else{
v139=1065353216;}
const v140=v139;
const v141=9;
let v142;if(v141<v111.length){v142=v111[v141];}else{
v142=1065353216;}
const v143=v142;
const v144=10;
let v145;if(v144<v111.length){v145=v111[v144];}else{
v145=1065353216;}
const v146=v145;
const v147=11;
let v148;if(v147<v111.length){v148=v111[v147];}else{
v148=1065353216;}
const v149=v148;
const v150=({["identity"]:v140,["scale"]:v143,["bias"]:v146,["relu"]:v149});
const v151=12;
let v152;if(v151<v111.length){v152=v111[v151];}else{
v152=1065353216;}
const v153=v152;
const v154=13;
let v155;if(v154<v111.length){v155=v111[v154];}else{
v155=1065353216;}
const v156=v155;
const v157=14;
let v158;if(v157<v111.length){v158=v111[v157];}else{
v158=1065353216;}
const v159=v158;
const v160=15;
let v161;if(v160<v111.length){v161=v111[v160];}else{
v161=1065353216;}
const v162=v161;
const v163=({["identity"]:v153,["scale"]:v156,["bias"]:v159,["relu"]:v162});
return ({["a"]:v124,["b"]:v137,["c"]:v150,["d"]:v163});}
function __fn6(v164){
const v165=v164["a"];
const v166=v165["identity"];
const v167=v164["a"];
const v168=v167["scale"];
const v169=v164["a"];
const v170=v169["bias"];
const v171=v164["a"];
const v172=v171["relu"];
const v173=v164["b"];
const v174=v173["identity"];
const v175=v164["b"];
const v176=v175["scale"];
const v177=v164["b"];
const v178=v177["bias"];
const v179=v164["b"];
const v180=v179["relu"];
const v181=v164["c"];
const v182=v181["identity"];
const v183=v164["c"];
const v184=v183["scale"];
const v185=v164["c"];
const v186=v185["bias"];
const v187=v164["c"];
const v188=v187["relu"];
const v189=v164["d"];
const v190=v189["identity"];
const v191=v164["d"];
const v192=v191["scale"];
const v193=v164["d"];
const v194=v193["bias"];
const v195=v164["d"];
const v196=v195["relu"];
return [v166,v168,v170,v172,v174,v176,v178,v180,v182,v184,v186,v188,v190,v192,v194,v196];}
function __fn7(v197,v198){
const v199=v198["slot"];
const v200=0;
let v201;if((v199===v200)){
v201=v197["a"];}else{
const v202=v198["slot"];
const v203=1;
let v204;if((v202===v203)){
v204=v197["b"];}else{
const v205=v198["slot"];
const v206=2;
let v207;if((v205===v206)){
v207=v197["c"];}else{
v207=v197["d"];}
v204=v207;}
v201=v204;}
const v208=v201;
const v209=v198["operation"];
const v210=0;
let v211;if((v209===v210)){
v211=v208["identity"];}else{
const v212=v198["operation"];
const v213=1;
let v214;if((v212===v213)){
v214=v208["scale"];}else{
const v215=v198["operation"];
const v216=2;
let v217;if((v215===v216)){
v217=v208["bias"];}else{
v217=v208["relu"];}
v214=v217;}
v211=v214;}
const v218=v211;
const v219=__bits(__float(v218) * __float(v218));
const v220=1036831949;
return __bits(__float(v219) + __float(v220));}
function __fn8(v221){
const v222=0;
let v223;if((v221===v222)){
v223="Op.Identity";}else{
const v224=1;
let v225;if((v221===v224)){
v225="Op.Scale";}else{
const v226=2;
let v227;if((v221===v226)){
v227="Op.Bias";}else{
v227="Op.Relu";}
v225=v227;}
v223=v225;}
return v223;}
function __fn9(v228,v229){
const v230=0;
const v232=1;
const v234=2;
const v236=3;
const v239=0;
let v240;
let v241;
let v242;
let v243;
if((v229===v239)){
const v244=v228["a"];
v240=v244["identity"];
v241=v244["scale"];
v242=v244["bias"];
v243=v244["relu"];
}else{
const v245=1;
let v246;
let v247;
let v248;
let v249;
if((v229===v245)){
const v250=v228["b"];
v246=v250["identity"];
v247=v250["scale"];
v248=v250["bias"];
v249=v250["relu"];
}else{
const v251=2;
let v252;
let v253;
let v254;
let v255;
if((v229===v251)){
const v256=v228["c"];
v252=v256["identity"];
v253=v256["scale"];
v254=v256["bias"];
v255=v256["relu"];
}else{
const v257=v228["d"];
v252=v257["identity"];
v253=v257["scale"];
v254=v257["bias"];
v255=v257["relu"];
}
v246=v252;
v247=v253;
v248=v254;
v249=v255;
}
v240=v246;
v241=v247;
v242=v248;
v243=v249;
}
const v259=0;
let v260;if((v230===v259)){
v260=v240;}else{
const v261=1;
let v262;if((v230===v261)){
v262=v241;}else{
const v263=2;
let v264;if((v230===v263)){
v264=v242;}else{
v264=v243;}
v262=v264;}
v260=v262;}
const v265=v260;
const v266=__bits(__float(v265) * __float(v265));
const v267=1036831949;
const v268=__bits(__float(v266) + __float(v267));
const v270=0;
let v271;
let v272;
let v273;
let v274;
if((v229===v270)){
const v275=v228["a"];
v271=v275["identity"];
v272=v275["scale"];
v273=v275["bias"];
v274=v275["relu"];
}else{
const v276=1;
let v277;
let v278;
let v279;
let v280;
if((v229===v276)){
const v281=v228["b"];
v277=v281["identity"];
v278=v281["scale"];
v279=v281["bias"];
v280=v281["relu"];
}else{
const v282=2;
let v283;
let v284;
let v285;
let v286;
if((v229===v282)){
const v287=v228["c"];
v283=v287["identity"];
v284=v287["scale"];
v285=v287["bias"];
v286=v287["relu"];
}else{
const v288=v228["d"];
v283=v288["identity"];
v284=v288["scale"];
v285=v288["bias"];
v286=v288["relu"];
}
v277=v283;
v278=v284;
v279=v285;
v280=v286;
}
v271=v277;
v272=v278;
v273=v279;
v274=v280;
}
const v290=0;
let v291;if((v232===v290)){
v291=v271;}else{
const v292=1;
let v293;if((v232===v292)){
v293=v272;}else{
const v294=2;
let v295;if((v232===v294)){
v295=v273;}else{
v295=v274;}
v293=v295;}
v291=v293;}
const v296=v291;
const v297=__bits(__float(v296) * __float(v296));
const v298=1036831949;
const v299=__bits(__float(v297) + __float(v298));
const v301=0;
let v302;
let v303;
let v304;
let v305;
if((v229===v301)){
const v306=v228["a"];
v302=v306["identity"];
v303=v306["scale"];
v304=v306["bias"];
v305=v306["relu"];
}else{
const v307=1;
let v308;
let v309;
let v310;
let v311;
if((v229===v307)){
const v312=v228["b"];
v308=v312["identity"];
v309=v312["scale"];
v310=v312["bias"];
v311=v312["relu"];
}else{
const v313=2;
let v314;
let v315;
let v316;
let v317;
if((v229===v313)){
const v318=v228["c"];
v314=v318["identity"];
v315=v318["scale"];
v316=v318["bias"];
v317=v318["relu"];
}else{
const v319=v228["d"];
v314=v319["identity"];
v315=v319["scale"];
v316=v319["bias"];
v317=v319["relu"];
}
v308=v314;
v309=v315;
v310=v316;
v311=v317;
}
v302=v308;
v303=v309;
v304=v310;
v305=v311;
}
const v321=0;
let v322;if((v234===v321)){
v322=v302;}else{
const v323=1;
let v324;if((v234===v323)){
v324=v303;}else{
const v325=2;
let v326;if((v234===v325)){
v326=v304;}else{
v326=v305;}
v324=v326;}
v322=v324;}
const v327=v322;
const v328=__bits(__float(v327) * __float(v327));
const v329=1036831949;
const v330=__bits(__float(v328) + __float(v329));
const v332=0;
let v333;
let v334;
let v335;
let v336;
if((v229===v332)){
const v337=v228["a"];
v333=v337["identity"];
v334=v337["scale"];
v335=v337["bias"];
v336=v337["relu"];
}else{
const v338=1;
let v339;
let v340;
let v341;
let v342;
if((v229===v338)){
const v343=v228["b"];
v339=v343["identity"];
v340=v343["scale"];
v341=v343["bias"];
v342=v343["relu"];
}else{
const v344=2;
let v345;
let v346;
let v347;
let v348;
if((v229===v344)){
const v349=v228["c"];
v345=v349["identity"];
v346=v349["scale"];
v347=v349["bias"];
v348=v349["relu"];
}else{
const v350=v228["d"];
v345=v350["identity"];
v346=v350["scale"];
v347=v350["bias"];
v348=v350["relu"];
}
v339=v345;
v340=v346;
v341=v347;
v342=v348;
}
v333=v339;
v334=v340;
v335=v341;
v336=v342;
}
const v352=0;
let v353;if((v236===v352)){
v353=v333;}else{
const v354=1;
let v355;if((v236===v354)){
v355=v334;}else{
const v356=2;
let v357;if((v236===v356)){
v357=v335;}else{
v357=v336;}
v355=v357;}
v353=v355;}
const v358=v353;
const v359=__bits(__float(v358) * __float(v358));
const v360=1036831949;
const v361=__bits(__float(v359) + __float(v360));
const v362=[v268,v299,v330,v361];
const v364=v228["a"];
const v365=v364["identity"];
const v366=1065353216;
const v367=0;
const v368=0;
const v369=0;
const v370=0;
const v371=0;
const v372=0;
const v373=0;
const v374=0;
const v375=0;
const v376=0;
const v377=0;
const v378=0;
const v379=0;
const v380=0;
const v381=0;
const v382=({["value"]:v365,["tangent_0"]:v366,["tangent_1"]:v367,["tangent_2"]:v368,["tangent_3"]:v369,["tangent_4"]:v370,["tangent_5"]:v371,["tangent_6"]:v372,["tangent_7"]:v373,["tangent_8"]:v374,["tangent_9"]:v375,["tangent_10"]:v376,["tangent_11"]:v377,["tangent_12"]:v378,["tangent_13"]:v379,["tangent_14"]:v380,["tangent_15"]:v381});
const v383=v228["a"];
const v384=v383["scale"];
const v385=0;
const v386=1065353216;
const v387=0;
const v388=0;
const v389=0;
const v390=0;
const v391=0;
const v392=0;
const v393=0;
const v394=0;
const v395=0;
const v396=0;
const v397=0;
const v398=0;
const v399=0;
const v400=0;
const v401=({["value"]:v384,["tangent_0"]:v385,["tangent_1"]:v386,["tangent_2"]:v387,["tangent_3"]:v388,["tangent_4"]:v389,["tangent_5"]:v390,["tangent_6"]:v391,["tangent_7"]:v392,["tangent_8"]:v393,["tangent_9"]:v394,["tangent_10"]:v395,["tangent_11"]:v396,["tangent_12"]:v397,["tangent_13"]:v398,["tangent_14"]:v399,["tangent_15"]:v400});
const v402=v228["a"];
const v403=v402["bias"];
const v404=0;
const v405=0;
const v406=1065353216;
const v407=0;
const v408=0;
const v409=0;
const v410=0;
const v411=0;
const v412=0;
const v413=0;
const v414=0;
const v415=0;
const v416=0;
const v417=0;
const v418=0;
const v419=0;
const v420=({["value"]:v403,["tangent_0"]:v404,["tangent_1"]:v405,["tangent_2"]:v406,["tangent_3"]:v407,["tangent_4"]:v408,["tangent_5"]:v409,["tangent_6"]:v410,["tangent_7"]:v411,["tangent_8"]:v412,["tangent_9"]:v413,["tangent_10"]:v414,["tangent_11"]:v415,["tangent_12"]:v416,["tangent_13"]:v417,["tangent_14"]:v418,["tangent_15"]:v419});
const v421=v228["a"];
const v422=v421["relu"];
const v423=0;
const v424=0;
const v425=0;
const v426=1065353216;
const v427=0;
const v428=0;
const v429=0;
const v430=0;
const v431=0;
const v432=0;
const v433=0;
const v434=0;
const v435=0;
const v436=0;
const v437=0;
const v438=0;
const v439=({["value"]:v422,["tangent_0"]:v423,["tangent_1"]:v424,["tangent_2"]:v425,["tangent_3"]:v426,["tangent_4"]:v427,["tangent_5"]:v428,["tangent_6"]:v429,["tangent_7"]:v430,["tangent_8"]:v431,["tangent_9"]:v432,["tangent_10"]:v433,["tangent_11"]:v434,["tangent_12"]:v435,["tangent_13"]:v436,["tangent_14"]:v437,["tangent_15"]:v438});
const v440=({["identity"]:v382,["scale"]:v401,["bias"]:v420,["relu"]:v439});
const v441=v228["b"];
const v442=v441["identity"];
const v443=0;
const v444=0;
const v445=0;
const v446=0;
const v447=1065353216;
const v448=0;
const v449=0;
const v450=0;
const v451=0;
const v452=0;
const v453=0;
const v454=0;
const v455=0;
const v456=0;
const v457=0;
const v458=0;
const v459=({["value"]:v442,["tangent_0"]:v443,["tangent_1"]:v444,["tangent_2"]:v445,["tangent_3"]:v446,["tangent_4"]:v447,["tangent_5"]:v448,["tangent_6"]:v449,["tangent_7"]:v450,["tangent_8"]:v451,["tangent_9"]:v452,["tangent_10"]:v453,["tangent_11"]:v454,["tangent_12"]:v455,["tangent_13"]:v456,["tangent_14"]:v457,["tangent_15"]:v458});
const v460=v228["b"];
const v461=v460["scale"];
const v462=0;
const v463=0;
const v464=0;
const v465=0;
const v466=0;
const v467=1065353216;
const v468=0;
const v469=0;
const v470=0;
const v471=0;
const v472=0;
const v473=0;
const v474=0;
const v475=0;
const v476=0;
const v477=0;
const v478=({["value"]:v461,["tangent_0"]:v462,["tangent_1"]:v463,["tangent_2"]:v464,["tangent_3"]:v465,["tangent_4"]:v466,["tangent_5"]:v467,["tangent_6"]:v468,["tangent_7"]:v469,["tangent_8"]:v470,["tangent_9"]:v471,["tangent_10"]:v472,["tangent_11"]:v473,["tangent_12"]:v474,["tangent_13"]:v475,["tangent_14"]:v476,["tangent_15"]:v477});
const v479=v228["b"];
const v480=v479["bias"];
const v481=0;
const v482=0;
const v483=0;
const v484=0;
const v485=0;
const v486=0;
const v487=1065353216;
const v488=0;
const v489=0;
const v490=0;
const v491=0;
const v492=0;
const v493=0;
const v494=0;
const v495=0;
const v496=0;
const v497=({["value"]:v480,["tangent_0"]:v481,["tangent_1"]:v482,["tangent_2"]:v483,["tangent_3"]:v484,["tangent_4"]:v485,["tangent_5"]:v486,["tangent_6"]:v487,["tangent_7"]:v488,["tangent_8"]:v489,["tangent_9"]:v490,["tangent_10"]:v491,["tangent_11"]:v492,["tangent_12"]:v493,["tangent_13"]:v494,["tangent_14"]:v495,["tangent_15"]:v496});
const v498=v228["b"];
const v499=v498["relu"];
const v500=0;
const v501=0;
const v502=0;
const v503=0;
const v504=0;
const v505=0;
const v506=0;
const v507=1065353216;
const v508=0;
const v509=0;
const v510=0;
const v511=0;
const v512=0;
const v513=0;
const v514=0;
const v515=0;
const v516=({["value"]:v499,["tangent_0"]:v500,["tangent_1"]:v501,["tangent_2"]:v502,["tangent_3"]:v503,["tangent_4"]:v504,["tangent_5"]:v505,["tangent_6"]:v506,["tangent_7"]:v507,["tangent_8"]:v508,["tangent_9"]:v509,["tangent_10"]:v510,["tangent_11"]:v511,["tangent_12"]:v512,["tangent_13"]:v513,["tangent_14"]:v514,["tangent_15"]:v515});
const v517=({["identity"]:v459,["scale"]:v478,["bias"]:v497,["relu"]:v516});
const v518=v228["c"];
const v519=v518["identity"];
const v520=0;
const v521=0;
const v522=0;
const v523=0;
const v524=0;
const v525=0;
const v526=0;
const v527=0;
const v528=1065353216;
const v529=0;
const v530=0;
const v531=0;
const v532=0;
const v533=0;
const v534=0;
const v535=0;
const v536=({["value"]:v519,["tangent_0"]:v520,["tangent_1"]:v521,["tangent_2"]:v522,["tangent_3"]:v523,["tangent_4"]:v524,["tangent_5"]:v525,["tangent_6"]:v526,["tangent_7"]:v527,["tangent_8"]:v528,["tangent_9"]:v529,["tangent_10"]:v530,["tangent_11"]:v531,["tangent_12"]:v532,["tangent_13"]:v533,["tangent_14"]:v534,["tangent_15"]:v535});
const v537=v228["c"];
const v538=v537["scale"];
const v539=0;
const v540=0;
const v541=0;
const v542=0;
const v543=0;
const v544=0;
const v545=0;
const v546=0;
const v547=0;
const v548=1065353216;
const v549=0;
const v550=0;
const v551=0;
const v552=0;
const v553=0;
const v554=0;
const v555=({["value"]:v538,["tangent_0"]:v539,["tangent_1"]:v540,["tangent_2"]:v541,["tangent_3"]:v542,["tangent_4"]:v543,["tangent_5"]:v544,["tangent_6"]:v545,["tangent_7"]:v546,["tangent_8"]:v547,["tangent_9"]:v548,["tangent_10"]:v549,["tangent_11"]:v550,["tangent_12"]:v551,["tangent_13"]:v552,["tangent_14"]:v553,["tangent_15"]:v554});
const v556=v228["c"];
const v557=v556["bias"];
const v558=0;
const v559=0;
const v560=0;
const v561=0;
const v562=0;
const v563=0;
const v564=0;
const v565=0;
const v566=0;
const v567=0;
const v568=1065353216;
const v569=0;
const v570=0;
const v571=0;
const v572=0;
const v573=0;
const v574=({["value"]:v557,["tangent_0"]:v558,["tangent_1"]:v559,["tangent_2"]:v560,["tangent_3"]:v561,["tangent_4"]:v562,["tangent_5"]:v563,["tangent_6"]:v564,["tangent_7"]:v565,["tangent_8"]:v566,["tangent_9"]:v567,["tangent_10"]:v568,["tangent_11"]:v569,["tangent_12"]:v570,["tangent_13"]:v571,["tangent_14"]:v572,["tangent_15"]:v573});
const v575=v228["c"];
const v576=v575["relu"];
const v577=0;
const v578=0;
const v579=0;
const v580=0;
const v581=0;
const v582=0;
const v583=0;
const v584=0;
const v585=0;
const v586=0;
const v587=0;
const v588=1065353216;
const v589=0;
const v590=0;
const v591=0;
const v592=0;
const v593=({["value"]:v576,["tangent_0"]:v577,["tangent_1"]:v578,["tangent_2"]:v579,["tangent_3"]:v580,["tangent_4"]:v581,["tangent_5"]:v582,["tangent_6"]:v583,["tangent_7"]:v584,["tangent_8"]:v585,["tangent_9"]:v586,["tangent_10"]:v587,["tangent_11"]:v588,["tangent_12"]:v589,["tangent_13"]:v590,["tangent_14"]:v591,["tangent_15"]:v592});
const v594=({["identity"]:v536,["scale"]:v555,["bias"]:v574,["relu"]:v593});
const v595=v228["d"];
const v596=v595["identity"];
const v597=0;
const v598=0;
const v599=0;
const v600=0;
const v601=0;
const v602=0;
const v603=0;
const v604=0;
const v605=0;
const v606=0;
const v607=0;
const v608=0;
const v609=1065353216;
const v610=0;
const v611=0;
const v612=0;
const v613=({["value"]:v596,["tangent_0"]:v597,["tangent_1"]:v598,["tangent_2"]:v599,["tangent_3"]:v600,["tangent_4"]:v601,["tangent_5"]:v602,["tangent_6"]:v603,["tangent_7"]:v604,["tangent_8"]:v605,["tangent_9"]:v606,["tangent_10"]:v607,["tangent_11"]:v608,["tangent_12"]:v609,["tangent_13"]:v610,["tangent_14"]:v611,["tangent_15"]:v612});
const v614=v228["d"];
const v615=v614["scale"];
const v616=0;
const v617=0;
const v618=0;
const v619=0;
const v620=0;
const v621=0;
const v622=0;
const v623=0;
const v624=0;
const v625=0;
const v626=0;
const v627=0;
const v628=0;
const v629=1065353216;
const v630=0;
const v631=0;
const v632=({["value"]:v615,["tangent_0"]:v616,["tangent_1"]:v617,["tangent_2"]:v618,["tangent_3"]:v619,["tangent_4"]:v620,["tangent_5"]:v621,["tangent_6"]:v622,["tangent_7"]:v623,["tangent_8"]:v624,["tangent_9"]:v625,["tangent_10"]:v626,["tangent_11"]:v627,["tangent_12"]:v628,["tangent_13"]:v629,["tangent_14"]:v630,["tangent_15"]:v631});
const v633=v228["d"];
const v634=v633["bias"];
const v635=0;
const v636=0;
const v637=0;
const v638=0;
const v639=0;
const v640=0;
const v641=0;
const v642=0;
const v643=0;
const v644=0;
const v645=0;
const v646=0;
const v647=0;
const v648=0;
const v649=1065353216;
const v650=0;
const v651=({["value"]:v634,["tangent_0"]:v635,["tangent_1"]:v636,["tangent_2"]:v637,["tangent_3"]:v638,["tangent_4"]:v639,["tangent_5"]:v640,["tangent_6"]:v641,["tangent_7"]:v642,["tangent_8"]:v643,["tangent_9"]:v644,["tangent_10"]:v645,["tangent_11"]:v646,["tangent_12"]:v647,["tangent_13"]:v648,["tangent_14"]:v649,["tangent_15"]:v650});
const v652=v228["d"];
const v653=v652["relu"];
const v654=0;
const v655=0;
const v656=0;
const v657=0;
const v658=0;
const v659=0;
const v660=0;
const v661=0;
const v662=0;
const v663=0;
const v664=0;
const v665=0;
const v666=0;
const v667=0;
const v668=0;
const v669=1065353216;
const v670=({["value"]:v653,["tangent_0"]:v654,["tangent_1"]:v655,["tangent_2"]:v656,["tangent_3"]:v657,["tangent_4"]:v658,["tangent_5"]:v659,["tangent_6"]:v660,["tangent_7"]:v661,["tangent_8"]:v662,["tangent_9"]:v663,["tangent_10"]:v664,["tangent_11"]:v665,["tangent_12"]:v666,["tangent_13"]:v667,["tangent_14"]:v668,["tangent_15"]:v669});
const v671=({["identity"]:v613,["scale"]:v632,["bias"]:v651,["relu"]:v670});
const v674=0;
let v675;
let v676;
let v677;
let v678;
if((v229===v674)){
v675=v440["identity"];
v676=v440["scale"];
v677=v440["bias"];
v678=v440["relu"];
}else{
const v679=1;
let v680;
let v681;
let v682;
let v683;
if((v229===v679)){
v680=v517["identity"];
v681=v517["scale"];
v682=v517["bias"];
v683=v517["relu"];
}else{
const v684=2;
let v685;
let v686;
let v687;
let v688;
if((v229===v684)){
v685=v594["identity"];
v686=v594["scale"];
v687=v594["bias"];
v688=v594["relu"];
}else{
v685=v671["identity"];
v686=v671["scale"];
v687=v671["bias"];
v688=v671["relu"];
}
v680=v685;
v681=v686;
v682=v687;
v683=v688;
}
v675=v680;
v676=v681;
v677=v682;
v678=v683;
}
const v690=0;
let v691;
let v692;
let v693;
let v694;
let v695;
let v696;
let v697;
let v698;
let v699;
let v700;
let v701;
let v702;
let v703;
let v704;
let v705;
let v706;
let v707;
if((v230===v690)){
const v708=v675;
v691=v708["value"];
v692=v708["tangent_0"];
v693=v708["tangent_1"];
v694=v708["tangent_2"];
v695=v708["tangent_3"];
v696=v708["tangent_4"];
v697=v708["tangent_5"];
v698=v708["tangent_6"];
v699=v708["tangent_7"];
v700=v708["tangent_8"];
v701=v708["tangent_9"];
v702=v708["tangent_10"];
v703=v708["tangent_11"];
v704=v708["tangent_12"];
v705=v708["tangent_13"];
v706=v708["tangent_14"];
v707=v708["tangent_15"];
}else{
const v709=1;
let v710;
let v711;
let v712;
let v713;
let v714;
let v715;
let v716;
let v717;
let v718;
let v719;
let v720;
let v721;
let v722;
let v723;
let v724;
let v725;
let v726;
if((v230===v709)){
const v727=v676;
v710=v727["value"];
v711=v727["tangent_0"];
v712=v727["tangent_1"];
v713=v727["tangent_2"];
v714=v727["tangent_3"];
v715=v727["tangent_4"];
v716=v727["tangent_5"];
v717=v727["tangent_6"];
v718=v727["tangent_7"];
v719=v727["tangent_8"];
v720=v727["tangent_9"];
v721=v727["tangent_10"];
v722=v727["tangent_11"];
v723=v727["tangent_12"];
v724=v727["tangent_13"];
v725=v727["tangent_14"];
v726=v727["tangent_15"];
}else{
const v728=2;
let v729;
let v730;
let v731;
let v732;
let v733;
let v734;
let v735;
let v736;
let v737;
let v738;
let v739;
let v740;
let v741;
let v742;
let v743;
let v744;
let v745;
if((v230===v728)){
const v746=v677;
v729=v746["value"];
v730=v746["tangent_0"];
v731=v746["tangent_1"];
v732=v746["tangent_2"];
v733=v746["tangent_3"];
v734=v746["tangent_4"];
v735=v746["tangent_5"];
v736=v746["tangent_6"];
v737=v746["tangent_7"];
v738=v746["tangent_8"];
v739=v746["tangent_9"];
v740=v746["tangent_10"];
v741=v746["tangent_11"];
v742=v746["tangent_12"];
v743=v746["tangent_13"];
v744=v746["tangent_14"];
v745=v746["tangent_15"];
}else{
const v747=v678;
v729=v747["value"];
v730=v747["tangent_0"];
v731=v747["tangent_1"];
v732=v747["tangent_2"];
v733=v747["tangent_3"];
v734=v747["tangent_4"];
v735=v747["tangent_5"];
v736=v747["tangent_6"];
v737=v747["tangent_7"];
v738=v747["tangent_8"];
v739=v747["tangent_9"];
v740=v747["tangent_10"];
v741=v747["tangent_11"];
v742=v747["tangent_12"];
v743=v747["tangent_13"];
v744=v747["tangent_14"];
v745=v747["tangent_15"];
}
v710=v729;
v711=v730;
v712=v731;
v713=v732;
v714=v733;
v715=v734;
v716=v735;
v717=v736;
v718=v737;
v719=v738;
v720=v739;
v721=v740;
v722=v741;
v723=v742;
v724=v743;
v725=v744;
v726=v745;
}
v691=v710;
v692=v711;
v693=v712;
v694=v713;
v695=v714;
v696=v715;
v697=v716;
v698=v717;
v699=v718;
v700=v719;
v701=v720;
v702=v721;
v703=v722;
v704=v723;
v705=v724;
v706=v725;
v707=v726;
}
const v749=v691;
const v750=v691;
const v751=__bits(__float(v749) * __float(v750));
const v752=v692;
const v753=v691;
const v754=__bits(__float(v752) * __float(v753));
const v755=v691;
const v756=v692;
const v757=__bits(__float(v755) * __float(v756));
const v758=__bits(__float(v754) + __float(v757));
const v759=v693;
const v760=v691;
const v761=__bits(__float(v759) * __float(v760));
const v762=v691;
const v763=v693;
const v764=__bits(__float(v762) * __float(v763));
const v765=__bits(__float(v761) + __float(v764));
const v766=v694;
const v767=v691;
const v768=__bits(__float(v766) * __float(v767));
const v769=v691;
const v770=v694;
const v771=__bits(__float(v769) * __float(v770));
const v772=__bits(__float(v768) + __float(v771));
const v773=v695;
const v774=v691;
const v775=__bits(__float(v773) * __float(v774));
const v776=v691;
const v777=v695;
const v778=__bits(__float(v776) * __float(v777));
const v779=__bits(__float(v775) + __float(v778));
const v780=v696;
const v781=v691;
const v782=__bits(__float(v780) * __float(v781));
const v783=v691;
const v784=v696;
const v785=__bits(__float(v783) * __float(v784));
const v786=__bits(__float(v782) + __float(v785));
const v787=v697;
const v788=v691;
const v789=__bits(__float(v787) * __float(v788));
const v790=v691;
const v791=v697;
const v792=__bits(__float(v790) * __float(v791));
const v793=__bits(__float(v789) + __float(v792));
const v794=v698;
const v795=v691;
const v796=__bits(__float(v794) * __float(v795));
const v797=v691;
const v798=v698;
const v799=__bits(__float(v797) * __float(v798));
const v800=__bits(__float(v796) + __float(v799));
const v801=v699;
const v802=v691;
const v803=__bits(__float(v801) * __float(v802));
const v804=v691;
const v805=v699;
const v806=__bits(__float(v804) * __float(v805));
const v807=__bits(__float(v803) + __float(v806));
const v808=v700;
const v809=v691;
const v810=__bits(__float(v808) * __float(v809));
const v811=v691;
const v812=v700;
const v813=__bits(__float(v811) * __float(v812));
const v814=__bits(__float(v810) + __float(v813));
const v815=v701;
const v816=v691;
const v817=__bits(__float(v815) * __float(v816));
const v818=v691;
const v819=v701;
const v820=__bits(__float(v818) * __float(v819));
const v821=__bits(__float(v817) + __float(v820));
const v822=v702;
const v823=v691;
const v824=__bits(__float(v822) * __float(v823));
const v825=v691;
const v826=v702;
const v827=__bits(__float(v825) * __float(v826));
const v828=__bits(__float(v824) + __float(v827));
const v829=v703;
const v830=v691;
const v831=__bits(__float(v829) * __float(v830));
const v832=v691;
const v833=v703;
const v834=__bits(__float(v832) * __float(v833));
const v835=__bits(__float(v831) + __float(v834));
const v836=v704;
const v837=v691;
const v838=__bits(__float(v836) * __float(v837));
const v839=v691;
const v840=v704;
const v841=__bits(__float(v839) * __float(v840));
const v842=__bits(__float(v838) + __float(v841));
const v843=v705;
const v844=v691;
const v845=__bits(__float(v843) * __float(v844));
const v846=v691;
const v847=v705;
const v848=__bits(__float(v846) * __float(v847));
const v849=__bits(__float(v845) + __float(v848));
const v850=v706;
const v851=v691;
const v852=__bits(__float(v850) * __float(v851));
const v853=v691;
const v854=v706;
const v855=__bits(__float(v853) * __float(v854));
const v856=__bits(__float(v852) + __float(v855));
const v857=v707;
const v858=v691;
const v859=__bits(__float(v857) * __float(v858));
const v860=v691;
const v861=v707;
const v862=__bits(__float(v860) * __float(v861));
const v863=__bits(__float(v859) + __float(v862));
const v865=1036831949;
const v866=0;
const v867=0;
const v868=0;
const v869=0;
const v870=0;
const v871=0;
const v872=0;
const v873=0;
const v874=0;
const v875=0;
const v876=0;
const v877=0;
const v878=0;
const v879=0;
const v880=0;
const v881=0;
const v883=__bits(__float(v751) + __float(v865));
const v884=__bits(__float(v758) + __float(v866));
const v885=__bits(__float(v765) + __float(v867));
const v886=__bits(__float(v772) + __float(v868));
const v887=__bits(__float(v779) + __float(v869));
const v888=__bits(__float(v786) + __float(v870));
const v889=__bits(__float(v793) + __float(v871));
const v890=__bits(__float(v800) + __float(v872));
const v891=__bits(__float(v807) + __float(v873));
const v892=__bits(__float(v814) + __float(v874));
const v893=__bits(__float(v821) + __float(v875));
const v894=__bits(__float(v828) + __float(v876));
const v895=__bits(__float(v835) + __float(v877));
const v896=__bits(__float(v842) + __float(v878));
const v897=__bits(__float(v849) + __float(v879));
const v898=__bits(__float(v856) + __float(v880));
const v899=__bits(__float(v863) + __float(v881));
const v901=({["identity"]:v884,["scale"]:v885,["bias"]:v886,["relu"]:v887});
const v902=({["identity"]:v888,["scale"]:v889,["bias"]:v890,["relu"]:v891});
const v903=({["identity"]:v892,["scale"]:v893,["bias"]:v894,["relu"]:v895});
const v904=({["identity"]:v896,["scale"]:v897,["bias"]:v898,["relu"]:v899});
const v906=v901["identity"];
const v907=v901["scale"];
const v908=v901["bias"];
const v909=v901["relu"];
const v910=v902["identity"];
const v911=v902["scale"];
const v912=v902["bias"];
const v913=v902["relu"];
const v914=v903["identity"];
const v915=v903["scale"];
const v916=v903["bias"];
const v917=v903["relu"];
const v918=v904["identity"];
const v919=v904["scale"];
const v920=v904["bias"];
const v921=v904["relu"];
const v922=[v906,v907,v908,v909,v910,v911,v912,v913,v914,v915,v916,v917,v918,v919,v920,v921];
const v924=v228["a"];
const v925=v924["identity"];
const v926=1065353216;
const v927=0;
const v928=0;
const v929=0;
const v930=0;
const v931=0;
const v932=0;
const v933=0;
const v934=0;
const v935=0;
const v936=0;
const v937=0;
const v938=0;
const v939=0;
const v940=0;
const v941=0;
const v942=({["value"]:v925,["tangent_0"]:v926,["tangent_1"]:v927,["tangent_2"]:v928,["tangent_3"]:v929,["tangent_4"]:v930,["tangent_5"]:v931,["tangent_6"]:v932,["tangent_7"]:v933,["tangent_8"]:v934,["tangent_9"]:v935,["tangent_10"]:v936,["tangent_11"]:v937,["tangent_12"]:v938,["tangent_13"]:v939,["tangent_14"]:v940,["tangent_15"]:v941});
const v943=v228["a"];
const v944=v943["scale"];
const v945=0;
const v946=1065353216;
const v947=0;
const v948=0;
const v949=0;
const v950=0;
const v951=0;
const v952=0;
const v953=0;
const v954=0;
const v955=0;
const v956=0;
const v957=0;
const v958=0;
const v959=0;
const v960=0;
const v961=({["value"]:v944,["tangent_0"]:v945,["tangent_1"]:v946,["tangent_2"]:v947,["tangent_3"]:v948,["tangent_4"]:v949,["tangent_5"]:v950,["tangent_6"]:v951,["tangent_7"]:v952,["tangent_8"]:v953,["tangent_9"]:v954,["tangent_10"]:v955,["tangent_11"]:v956,["tangent_12"]:v957,["tangent_13"]:v958,["tangent_14"]:v959,["tangent_15"]:v960});
const v962=v228["a"];
const v963=v962["bias"];
const v964=0;
const v965=0;
const v966=1065353216;
const v967=0;
const v968=0;
const v969=0;
const v970=0;
const v971=0;
const v972=0;
const v973=0;
const v974=0;
const v975=0;
const v976=0;
const v977=0;
const v978=0;
const v979=0;
const v980=({["value"]:v963,["tangent_0"]:v964,["tangent_1"]:v965,["tangent_2"]:v966,["tangent_3"]:v967,["tangent_4"]:v968,["tangent_5"]:v969,["tangent_6"]:v970,["tangent_7"]:v971,["tangent_8"]:v972,["tangent_9"]:v973,["tangent_10"]:v974,["tangent_11"]:v975,["tangent_12"]:v976,["tangent_13"]:v977,["tangent_14"]:v978,["tangent_15"]:v979});
const v981=v228["a"];
const v982=v981["relu"];
const v983=0;
const v984=0;
const v985=0;
const v986=1065353216;
const v987=0;
const v988=0;
const v989=0;
const v990=0;
const v991=0;
const v992=0;
const v993=0;
const v994=0;
const v995=0;
const v996=0;
const v997=0;
const v998=0;
const v999=({["value"]:v982,["tangent_0"]:v983,["tangent_1"]:v984,["tangent_2"]:v985,["tangent_3"]:v986,["tangent_4"]:v987,["tangent_5"]:v988,["tangent_6"]:v989,["tangent_7"]:v990,["tangent_8"]:v991,["tangent_9"]:v992,["tangent_10"]:v993,["tangent_11"]:v994,["tangent_12"]:v995,["tangent_13"]:v996,["tangent_14"]:v997,["tangent_15"]:v998});
const v1000=({["identity"]:v942,["scale"]:v961,["bias"]:v980,["relu"]:v999});
const v1001=v228["b"];
const v1002=v1001["identity"];
const v1003=0;
const v1004=0;
const v1005=0;
const v1006=0;
const v1007=1065353216;
const v1008=0;
const v1009=0;
const v1010=0;
const v1011=0;
const v1012=0;
const v1013=0;
const v1014=0;
const v1015=0;
const v1016=0;
const v1017=0;
const v1018=0;
const v1019=({["value"]:v1002,["tangent_0"]:v1003,["tangent_1"]:v1004,["tangent_2"]:v1005,["tangent_3"]:v1006,["tangent_4"]:v1007,["tangent_5"]:v1008,["tangent_6"]:v1009,["tangent_7"]:v1010,["tangent_8"]:v1011,["tangent_9"]:v1012,["tangent_10"]:v1013,["tangent_11"]:v1014,["tangent_12"]:v1015,["tangent_13"]:v1016,["tangent_14"]:v1017,["tangent_15"]:v1018});
const v1020=v228["b"];
const v1021=v1020["scale"];
const v1022=0;
const v1023=0;
const v1024=0;
const v1025=0;
const v1026=0;
const v1027=1065353216;
const v1028=0;
const v1029=0;
const v1030=0;
const v1031=0;
const v1032=0;
const v1033=0;
const v1034=0;
const v1035=0;
const v1036=0;
const v1037=0;
const v1038=({["value"]:v1021,["tangent_0"]:v1022,["tangent_1"]:v1023,["tangent_2"]:v1024,["tangent_3"]:v1025,["tangent_4"]:v1026,["tangent_5"]:v1027,["tangent_6"]:v1028,["tangent_7"]:v1029,["tangent_8"]:v1030,["tangent_9"]:v1031,["tangent_10"]:v1032,["tangent_11"]:v1033,["tangent_12"]:v1034,["tangent_13"]:v1035,["tangent_14"]:v1036,["tangent_15"]:v1037});
const v1039=v228["b"];
const v1040=v1039["bias"];
const v1041=0;
const v1042=0;
const v1043=0;
const v1044=0;
const v1045=0;
const v1046=0;
const v1047=1065353216;
const v1048=0;
const v1049=0;
const v1050=0;
const v1051=0;
const v1052=0;
const v1053=0;
const v1054=0;
const v1055=0;
const v1056=0;
const v1057=({["value"]:v1040,["tangent_0"]:v1041,["tangent_1"]:v1042,["tangent_2"]:v1043,["tangent_3"]:v1044,["tangent_4"]:v1045,["tangent_5"]:v1046,["tangent_6"]:v1047,["tangent_7"]:v1048,["tangent_8"]:v1049,["tangent_9"]:v1050,["tangent_10"]:v1051,["tangent_11"]:v1052,["tangent_12"]:v1053,["tangent_13"]:v1054,["tangent_14"]:v1055,["tangent_15"]:v1056});
const v1058=v228["b"];
const v1059=v1058["relu"];
const v1060=0;
const v1061=0;
const v1062=0;
const v1063=0;
const v1064=0;
const v1065=0;
const v1066=0;
const v1067=1065353216;
const v1068=0;
const v1069=0;
const v1070=0;
const v1071=0;
const v1072=0;
const v1073=0;
const v1074=0;
const v1075=0;
const v1076=({["value"]:v1059,["tangent_0"]:v1060,["tangent_1"]:v1061,["tangent_2"]:v1062,["tangent_3"]:v1063,["tangent_4"]:v1064,["tangent_5"]:v1065,["tangent_6"]:v1066,["tangent_7"]:v1067,["tangent_8"]:v1068,["tangent_9"]:v1069,["tangent_10"]:v1070,["tangent_11"]:v1071,["tangent_12"]:v1072,["tangent_13"]:v1073,["tangent_14"]:v1074,["tangent_15"]:v1075});
const v1077=({["identity"]:v1019,["scale"]:v1038,["bias"]:v1057,["relu"]:v1076});
const v1078=v228["c"];
const v1079=v1078["identity"];
const v1080=0;
const v1081=0;
const v1082=0;
const v1083=0;
const v1084=0;
const v1085=0;
const v1086=0;
const v1087=0;
const v1088=1065353216;
const v1089=0;
const v1090=0;
const v1091=0;
const v1092=0;
const v1093=0;
const v1094=0;
const v1095=0;
const v1096=({["value"]:v1079,["tangent_0"]:v1080,["tangent_1"]:v1081,["tangent_2"]:v1082,["tangent_3"]:v1083,["tangent_4"]:v1084,["tangent_5"]:v1085,["tangent_6"]:v1086,["tangent_7"]:v1087,["tangent_8"]:v1088,["tangent_9"]:v1089,["tangent_10"]:v1090,["tangent_11"]:v1091,["tangent_12"]:v1092,["tangent_13"]:v1093,["tangent_14"]:v1094,["tangent_15"]:v1095});
const v1097=v228["c"];
const v1098=v1097["scale"];
const v1099=0;
const v1100=0;
const v1101=0;
const v1102=0;
const v1103=0;
const v1104=0;
const v1105=0;
const v1106=0;
const v1107=0;
const v1108=1065353216;
const v1109=0;
const v1110=0;
const v1111=0;
const v1112=0;
const v1113=0;
const v1114=0;
const v1115=({["value"]:v1098,["tangent_0"]:v1099,["tangent_1"]:v1100,["tangent_2"]:v1101,["tangent_3"]:v1102,["tangent_4"]:v1103,["tangent_5"]:v1104,["tangent_6"]:v1105,["tangent_7"]:v1106,["tangent_8"]:v1107,["tangent_9"]:v1108,["tangent_10"]:v1109,["tangent_11"]:v1110,["tangent_12"]:v1111,["tangent_13"]:v1112,["tangent_14"]:v1113,["tangent_15"]:v1114});
const v1116=v228["c"];
const v1117=v1116["bias"];
const v1118=0;
const v1119=0;
const v1120=0;
const v1121=0;
const v1122=0;
const v1123=0;
const v1124=0;
const v1125=0;
const v1126=0;
const v1127=0;
const v1128=1065353216;
const v1129=0;
const v1130=0;
const v1131=0;
const v1132=0;
const v1133=0;
const v1134=({["value"]:v1117,["tangent_0"]:v1118,["tangent_1"]:v1119,["tangent_2"]:v1120,["tangent_3"]:v1121,["tangent_4"]:v1122,["tangent_5"]:v1123,["tangent_6"]:v1124,["tangent_7"]:v1125,["tangent_8"]:v1126,["tangent_9"]:v1127,["tangent_10"]:v1128,["tangent_11"]:v1129,["tangent_12"]:v1130,["tangent_13"]:v1131,["tangent_14"]:v1132,["tangent_15"]:v1133});
const v1135=v228["c"];
const v1136=v1135["relu"];
const v1137=0;
const v1138=0;
const v1139=0;
const v1140=0;
const v1141=0;
const v1142=0;
const v1143=0;
const v1144=0;
const v1145=0;
const v1146=0;
const v1147=0;
const v1148=1065353216;
const v1149=0;
const v1150=0;
const v1151=0;
const v1152=0;
const v1153=({["value"]:v1136,["tangent_0"]:v1137,["tangent_1"]:v1138,["tangent_2"]:v1139,["tangent_3"]:v1140,["tangent_4"]:v1141,["tangent_5"]:v1142,["tangent_6"]:v1143,["tangent_7"]:v1144,["tangent_8"]:v1145,["tangent_9"]:v1146,["tangent_10"]:v1147,["tangent_11"]:v1148,["tangent_12"]:v1149,["tangent_13"]:v1150,["tangent_14"]:v1151,["tangent_15"]:v1152});
const v1154=({["identity"]:v1096,["scale"]:v1115,["bias"]:v1134,["relu"]:v1153});
const v1155=v228["d"];
const v1156=v1155["identity"];
const v1157=0;
const v1158=0;
const v1159=0;
const v1160=0;
const v1161=0;
const v1162=0;
const v1163=0;
const v1164=0;
const v1165=0;
const v1166=0;
const v1167=0;
const v1168=0;
const v1169=1065353216;
const v1170=0;
const v1171=0;
const v1172=0;
const v1173=({["value"]:v1156,["tangent_0"]:v1157,["tangent_1"]:v1158,["tangent_2"]:v1159,["tangent_3"]:v1160,["tangent_4"]:v1161,["tangent_5"]:v1162,["tangent_6"]:v1163,["tangent_7"]:v1164,["tangent_8"]:v1165,["tangent_9"]:v1166,["tangent_10"]:v1167,["tangent_11"]:v1168,["tangent_12"]:v1169,["tangent_13"]:v1170,["tangent_14"]:v1171,["tangent_15"]:v1172});
const v1174=v228["d"];
const v1175=v1174["scale"];
const v1176=0;
const v1177=0;
const v1178=0;
const v1179=0;
const v1180=0;
const v1181=0;
const v1182=0;
const v1183=0;
const v1184=0;
const v1185=0;
const v1186=0;
const v1187=0;
const v1188=0;
const v1189=1065353216;
const v1190=0;
const v1191=0;
const v1192=({["value"]:v1175,["tangent_0"]:v1176,["tangent_1"]:v1177,["tangent_2"]:v1178,["tangent_3"]:v1179,["tangent_4"]:v1180,["tangent_5"]:v1181,["tangent_6"]:v1182,["tangent_7"]:v1183,["tangent_8"]:v1184,["tangent_9"]:v1185,["tangent_10"]:v1186,["tangent_11"]:v1187,["tangent_12"]:v1188,["tangent_13"]:v1189,["tangent_14"]:v1190,["tangent_15"]:v1191});
const v1193=v228["d"];
const v1194=v1193["bias"];
const v1195=0;
const v1196=0;
const v1197=0;
const v1198=0;
const v1199=0;
const v1200=0;
const v1201=0;
const v1202=0;
const v1203=0;
const v1204=0;
const v1205=0;
const v1206=0;
const v1207=0;
const v1208=0;
const v1209=1065353216;
const v1210=0;
const v1211=({["value"]:v1194,["tangent_0"]:v1195,["tangent_1"]:v1196,["tangent_2"]:v1197,["tangent_3"]:v1198,["tangent_4"]:v1199,["tangent_5"]:v1200,["tangent_6"]:v1201,["tangent_7"]:v1202,["tangent_8"]:v1203,["tangent_9"]:v1204,["tangent_10"]:v1205,["tangent_11"]:v1206,["tangent_12"]:v1207,["tangent_13"]:v1208,["tangent_14"]:v1209,["tangent_15"]:v1210});
const v1212=v228["d"];
const v1213=v1212["relu"];
const v1214=0;
const v1215=0;
const v1216=0;
const v1217=0;
const v1218=0;
const v1219=0;
const v1220=0;
const v1221=0;
const v1222=0;
const v1223=0;
const v1224=0;
const v1225=0;
const v1226=0;
const v1227=0;
const v1228=0;
const v1229=1065353216;
const v1230=({["value"]:v1213,["tangent_0"]:v1214,["tangent_1"]:v1215,["tangent_2"]:v1216,["tangent_3"]:v1217,["tangent_4"]:v1218,["tangent_5"]:v1219,["tangent_6"]:v1220,["tangent_7"]:v1221,["tangent_8"]:v1222,["tangent_9"]:v1223,["tangent_10"]:v1224,["tangent_11"]:v1225,["tangent_12"]:v1226,["tangent_13"]:v1227,["tangent_14"]:v1228,["tangent_15"]:v1229});
const v1231=({["identity"]:v1173,["scale"]:v1192,["bias"]:v1211,["relu"]:v1230});
const v1234=0;
let v1235;
let v1236;
let v1237;
let v1238;
if((v229===v1234)){
v1235=v1000["identity"];
v1236=v1000["scale"];
v1237=v1000["bias"];
v1238=v1000["relu"];
}else{
const v1239=1;
let v1240;
let v1241;
let v1242;
let v1243;
if((v229===v1239)){
v1240=v1077["identity"];
v1241=v1077["scale"];
v1242=v1077["bias"];
v1243=v1077["relu"];
}else{
const v1244=2;
let v1245;
let v1246;
let v1247;
let v1248;
if((v229===v1244)){
v1245=v1154["identity"];
v1246=v1154["scale"];
v1247=v1154["bias"];
v1248=v1154["relu"];
}else{
v1245=v1231["identity"];
v1246=v1231["scale"];
v1247=v1231["bias"];
v1248=v1231["relu"];
}
v1240=v1245;
v1241=v1246;
v1242=v1247;
v1243=v1248;
}
v1235=v1240;
v1236=v1241;
v1237=v1242;
v1238=v1243;
}
const v1250=0;
let v1251;
let v1252;
let v1253;
let v1254;
let v1255;
let v1256;
let v1257;
let v1258;
let v1259;
let v1260;
let v1261;
let v1262;
let v1263;
let v1264;
let v1265;
let v1266;
let v1267;
if((v232===v1250)){
const v1268=v1235;
v1251=v1268["value"];
v1252=v1268["tangent_0"];
v1253=v1268["tangent_1"];
v1254=v1268["tangent_2"];
v1255=v1268["tangent_3"];
v1256=v1268["tangent_4"];
v1257=v1268["tangent_5"];
v1258=v1268["tangent_6"];
v1259=v1268["tangent_7"];
v1260=v1268["tangent_8"];
v1261=v1268["tangent_9"];
v1262=v1268["tangent_10"];
v1263=v1268["tangent_11"];
v1264=v1268["tangent_12"];
v1265=v1268["tangent_13"];
v1266=v1268["tangent_14"];
v1267=v1268["tangent_15"];
}else{
const v1269=1;
let v1270;
let v1271;
let v1272;
let v1273;
let v1274;
let v1275;
let v1276;
let v1277;
let v1278;
let v1279;
let v1280;
let v1281;
let v1282;
let v1283;
let v1284;
let v1285;
let v1286;
if((v232===v1269)){
const v1287=v1236;
v1270=v1287["value"];
v1271=v1287["tangent_0"];
v1272=v1287["tangent_1"];
v1273=v1287["tangent_2"];
v1274=v1287["tangent_3"];
v1275=v1287["tangent_4"];
v1276=v1287["tangent_5"];
v1277=v1287["tangent_6"];
v1278=v1287["tangent_7"];
v1279=v1287["tangent_8"];
v1280=v1287["tangent_9"];
v1281=v1287["tangent_10"];
v1282=v1287["tangent_11"];
v1283=v1287["tangent_12"];
v1284=v1287["tangent_13"];
v1285=v1287["tangent_14"];
v1286=v1287["tangent_15"];
}else{
const v1288=2;
let v1289;
let v1290;
let v1291;
let v1292;
let v1293;
let v1294;
let v1295;
let v1296;
let v1297;
let v1298;
let v1299;
let v1300;
let v1301;
let v1302;
let v1303;
let v1304;
let v1305;
if((v232===v1288)){
const v1306=v1237;
v1289=v1306["value"];
v1290=v1306["tangent_0"];
v1291=v1306["tangent_1"];
v1292=v1306["tangent_2"];
v1293=v1306["tangent_3"];
v1294=v1306["tangent_4"];
v1295=v1306["tangent_5"];
v1296=v1306["tangent_6"];
v1297=v1306["tangent_7"];
v1298=v1306["tangent_8"];
v1299=v1306["tangent_9"];
v1300=v1306["tangent_10"];
v1301=v1306["tangent_11"];
v1302=v1306["tangent_12"];
v1303=v1306["tangent_13"];
v1304=v1306["tangent_14"];
v1305=v1306["tangent_15"];
}else{
const v1307=v1238;
v1289=v1307["value"];
v1290=v1307["tangent_0"];
v1291=v1307["tangent_1"];
v1292=v1307["tangent_2"];
v1293=v1307["tangent_3"];
v1294=v1307["tangent_4"];
v1295=v1307["tangent_5"];
v1296=v1307["tangent_6"];
v1297=v1307["tangent_7"];
v1298=v1307["tangent_8"];
v1299=v1307["tangent_9"];
v1300=v1307["tangent_10"];
v1301=v1307["tangent_11"];
v1302=v1307["tangent_12"];
v1303=v1307["tangent_13"];
v1304=v1307["tangent_14"];
v1305=v1307["tangent_15"];
}
v1270=v1289;
v1271=v1290;
v1272=v1291;
v1273=v1292;
v1274=v1293;
v1275=v1294;
v1276=v1295;
v1277=v1296;
v1278=v1297;
v1279=v1298;
v1280=v1299;
v1281=v1300;
v1282=v1301;
v1283=v1302;
v1284=v1303;
v1285=v1304;
v1286=v1305;
}
v1251=v1270;
v1252=v1271;
v1253=v1272;
v1254=v1273;
v1255=v1274;
v1256=v1275;
v1257=v1276;
v1258=v1277;
v1259=v1278;
v1260=v1279;
v1261=v1280;
v1262=v1281;
v1263=v1282;
v1264=v1283;
v1265=v1284;
v1266=v1285;
v1267=v1286;
}
const v1309=v1251;
const v1310=v1251;
const v1311=__bits(__float(v1309) * __float(v1310));
const v1312=v1252;
const v1313=v1251;
const v1314=__bits(__float(v1312) * __float(v1313));
const v1315=v1251;
const v1316=v1252;
const v1317=__bits(__float(v1315) * __float(v1316));
const v1318=__bits(__float(v1314) + __float(v1317));
const v1319=v1253;
const v1320=v1251;
const v1321=__bits(__float(v1319) * __float(v1320));
const v1322=v1251;
const v1323=v1253;
const v1324=__bits(__float(v1322) * __float(v1323));
const v1325=__bits(__float(v1321) + __float(v1324));
const v1326=v1254;
const v1327=v1251;
const v1328=__bits(__float(v1326) * __float(v1327));
const v1329=v1251;
const v1330=v1254;
const v1331=__bits(__float(v1329) * __float(v1330));
const v1332=__bits(__float(v1328) + __float(v1331));
const v1333=v1255;
const v1334=v1251;
const v1335=__bits(__float(v1333) * __float(v1334));
const v1336=v1251;
const v1337=v1255;
const v1338=__bits(__float(v1336) * __float(v1337));
const v1339=__bits(__float(v1335) + __float(v1338));
const v1340=v1256;
const v1341=v1251;
const v1342=__bits(__float(v1340) * __float(v1341));
const v1343=v1251;
const v1344=v1256;
const v1345=__bits(__float(v1343) * __float(v1344));
const v1346=__bits(__float(v1342) + __float(v1345));
const v1347=v1257;
const v1348=v1251;
const v1349=__bits(__float(v1347) * __float(v1348));
const v1350=v1251;
const v1351=v1257;
const v1352=__bits(__float(v1350) * __float(v1351));
const v1353=__bits(__float(v1349) + __float(v1352));
const v1354=v1258;
const v1355=v1251;
const v1356=__bits(__float(v1354) * __float(v1355));
const v1357=v1251;
const v1358=v1258;
const v1359=__bits(__float(v1357) * __float(v1358));
const v1360=__bits(__float(v1356) + __float(v1359));
const v1361=v1259;
const v1362=v1251;
const v1363=__bits(__float(v1361) * __float(v1362));
const v1364=v1251;
const v1365=v1259;
const v1366=__bits(__float(v1364) * __float(v1365));
const v1367=__bits(__float(v1363) + __float(v1366));
const v1368=v1260;
const v1369=v1251;
const v1370=__bits(__float(v1368) * __float(v1369));
const v1371=v1251;
const v1372=v1260;
const v1373=__bits(__float(v1371) * __float(v1372));
const v1374=__bits(__float(v1370) + __float(v1373));
const v1375=v1261;
const v1376=v1251;
const v1377=__bits(__float(v1375) * __float(v1376));
const v1378=v1251;
const v1379=v1261;
const v1380=__bits(__float(v1378) * __float(v1379));
const v1381=__bits(__float(v1377) + __float(v1380));
const v1382=v1262;
const v1383=v1251;
const v1384=__bits(__float(v1382) * __float(v1383));
const v1385=v1251;
const v1386=v1262;
const v1387=__bits(__float(v1385) * __float(v1386));
const v1388=__bits(__float(v1384) + __float(v1387));
const v1389=v1263;
const v1390=v1251;
const v1391=__bits(__float(v1389) * __float(v1390));
const v1392=v1251;
const v1393=v1263;
const v1394=__bits(__float(v1392) * __float(v1393));
const v1395=__bits(__float(v1391) + __float(v1394));
const v1396=v1264;
const v1397=v1251;
const v1398=__bits(__float(v1396) * __float(v1397));
const v1399=v1251;
const v1400=v1264;
const v1401=__bits(__float(v1399) * __float(v1400));
const v1402=__bits(__float(v1398) + __float(v1401));
const v1403=v1265;
const v1404=v1251;
const v1405=__bits(__float(v1403) * __float(v1404));
const v1406=v1251;
const v1407=v1265;
const v1408=__bits(__float(v1406) * __float(v1407));
const v1409=__bits(__float(v1405) + __float(v1408));
const v1410=v1266;
const v1411=v1251;
const v1412=__bits(__float(v1410) * __float(v1411));
const v1413=v1251;
const v1414=v1266;
const v1415=__bits(__float(v1413) * __float(v1414));
const v1416=__bits(__float(v1412) + __float(v1415));
const v1417=v1267;
const v1418=v1251;
const v1419=__bits(__float(v1417) * __float(v1418));
const v1420=v1251;
const v1421=v1267;
const v1422=__bits(__float(v1420) * __float(v1421));
const v1423=__bits(__float(v1419) + __float(v1422));
const v1425=1036831949;
const v1426=0;
const v1427=0;
const v1428=0;
const v1429=0;
const v1430=0;
const v1431=0;
const v1432=0;
const v1433=0;
const v1434=0;
const v1435=0;
const v1436=0;
const v1437=0;
const v1438=0;
const v1439=0;
const v1440=0;
const v1441=0;
const v1443=__bits(__float(v1311) + __float(v1425));
const v1444=__bits(__float(v1318) + __float(v1426));
const v1445=__bits(__float(v1325) + __float(v1427));
const v1446=__bits(__float(v1332) + __float(v1428));
const v1447=__bits(__float(v1339) + __float(v1429));
const v1448=__bits(__float(v1346) + __float(v1430));
const v1449=__bits(__float(v1353) + __float(v1431));
const v1450=__bits(__float(v1360) + __float(v1432));
const v1451=__bits(__float(v1367) + __float(v1433));
const v1452=__bits(__float(v1374) + __float(v1434));
const v1453=__bits(__float(v1381) + __float(v1435));
const v1454=__bits(__float(v1388) + __float(v1436));
const v1455=__bits(__float(v1395) + __float(v1437));
const v1456=__bits(__float(v1402) + __float(v1438));
const v1457=__bits(__float(v1409) + __float(v1439));
const v1458=__bits(__float(v1416) + __float(v1440));
const v1459=__bits(__float(v1423) + __float(v1441));
const v1461=({["identity"]:v1444,["scale"]:v1445,["bias"]:v1446,["relu"]:v1447});
const v1462=({["identity"]:v1448,["scale"]:v1449,["bias"]:v1450,["relu"]:v1451});
const v1463=({["identity"]:v1452,["scale"]:v1453,["bias"]:v1454,["relu"]:v1455});
const v1464=({["identity"]:v1456,["scale"]:v1457,["bias"]:v1458,["relu"]:v1459});
const v1466=v1461["identity"];
const v1467=v1461["scale"];
const v1468=v1461["bias"];
const v1469=v1461["relu"];
const v1470=v1462["identity"];
const v1471=v1462["scale"];
const v1472=v1462["bias"];
const v1473=v1462["relu"];
const v1474=v1463["identity"];
const v1475=v1463["scale"];
const v1476=v1463["bias"];
const v1477=v1463["relu"];
const v1478=v1464["identity"];
const v1479=v1464["scale"];
const v1480=v1464["bias"];
const v1481=v1464["relu"];
const v1482=[v1466,v1467,v1468,v1469,v1470,v1471,v1472,v1473,v1474,v1475,v1476,v1477,v1478,v1479,v1480,v1481];
const v1484=v228["a"];
const v1485=v1484["identity"];
const v1486=1065353216;
const v1487=0;
const v1488=0;
const v1489=0;
const v1490=0;
const v1491=0;
const v1492=0;
const v1493=0;
const v1494=0;
const v1495=0;
const v1496=0;
const v1497=0;
const v1498=0;
const v1499=0;
const v1500=0;
const v1501=0;
const v1502=({["value"]:v1485,["tangent_0"]:v1486,["tangent_1"]:v1487,["tangent_2"]:v1488,["tangent_3"]:v1489,["tangent_4"]:v1490,["tangent_5"]:v1491,["tangent_6"]:v1492,["tangent_7"]:v1493,["tangent_8"]:v1494,["tangent_9"]:v1495,["tangent_10"]:v1496,["tangent_11"]:v1497,["tangent_12"]:v1498,["tangent_13"]:v1499,["tangent_14"]:v1500,["tangent_15"]:v1501});
const v1503=v228["a"];
const v1504=v1503["scale"];
const v1505=0;
const v1506=1065353216;
const v1507=0;
const v1508=0;
const v1509=0;
const v1510=0;
const v1511=0;
const v1512=0;
const v1513=0;
const v1514=0;
const v1515=0;
const v1516=0;
const v1517=0;
const v1518=0;
const v1519=0;
const v1520=0;
const v1521=({["value"]:v1504,["tangent_0"]:v1505,["tangent_1"]:v1506,["tangent_2"]:v1507,["tangent_3"]:v1508,["tangent_4"]:v1509,["tangent_5"]:v1510,["tangent_6"]:v1511,["tangent_7"]:v1512,["tangent_8"]:v1513,["tangent_9"]:v1514,["tangent_10"]:v1515,["tangent_11"]:v1516,["tangent_12"]:v1517,["tangent_13"]:v1518,["tangent_14"]:v1519,["tangent_15"]:v1520});
const v1522=v228["a"];
const v1523=v1522["bias"];
const v1524=0;
const v1525=0;
const v1526=1065353216;
const v1527=0;
const v1528=0;
const v1529=0;
const v1530=0;
const v1531=0;
const v1532=0;
const v1533=0;
const v1534=0;
const v1535=0;
const v1536=0;
const v1537=0;
const v1538=0;
const v1539=0;
const v1540=({["value"]:v1523,["tangent_0"]:v1524,["tangent_1"]:v1525,["tangent_2"]:v1526,["tangent_3"]:v1527,["tangent_4"]:v1528,["tangent_5"]:v1529,["tangent_6"]:v1530,["tangent_7"]:v1531,["tangent_8"]:v1532,["tangent_9"]:v1533,["tangent_10"]:v1534,["tangent_11"]:v1535,["tangent_12"]:v1536,["tangent_13"]:v1537,["tangent_14"]:v1538,["tangent_15"]:v1539});
const v1541=v228["a"];
const v1542=v1541["relu"];
const v1543=0;
const v1544=0;
const v1545=0;
const v1546=1065353216;
const v1547=0;
const v1548=0;
const v1549=0;
const v1550=0;
const v1551=0;
const v1552=0;
const v1553=0;
const v1554=0;
const v1555=0;
const v1556=0;
const v1557=0;
const v1558=0;
const v1559=({["value"]:v1542,["tangent_0"]:v1543,["tangent_1"]:v1544,["tangent_2"]:v1545,["tangent_3"]:v1546,["tangent_4"]:v1547,["tangent_5"]:v1548,["tangent_6"]:v1549,["tangent_7"]:v1550,["tangent_8"]:v1551,["tangent_9"]:v1552,["tangent_10"]:v1553,["tangent_11"]:v1554,["tangent_12"]:v1555,["tangent_13"]:v1556,["tangent_14"]:v1557,["tangent_15"]:v1558});
const v1560=({["identity"]:v1502,["scale"]:v1521,["bias"]:v1540,["relu"]:v1559});
const v1561=v228["b"];
const v1562=v1561["identity"];
const v1563=0;
const v1564=0;
const v1565=0;
const v1566=0;
const v1567=1065353216;
const v1568=0;
const v1569=0;
const v1570=0;
const v1571=0;
const v1572=0;
const v1573=0;
const v1574=0;
const v1575=0;
const v1576=0;
const v1577=0;
const v1578=0;
const v1579=({["value"]:v1562,["tangent_0"]:v1563,["tangent_1"]:v1564,["tangent_2"]:v1565,["tangent_3"]:v1566,["tangent_4"]:v1567,["tangent_5"]:v1568,["tangent_6"]:v1569,["tangent_7"]:v1570,["tangent_8"]:v1571,["tangent_9"]:v1572,["tangent_10"]:v1573,["tangent_11"]:v1574,["tangent_12"]:v1575,["tangent_13"]:v1576,["tangent_14"]:v1577,["tangent_15"]:v1578});
const v1580=v228["b"];
const v1581=v1580["scale"];
const v1582=0;
const v1583=0;
const v1584=0;
const v1585=0;
const v1586=0;
const v1587=1065353216;
const v1588=0;
const v1589=0;
const v1590=0;
const v1591=0;
const v1592=0;
const v1593=0;
const v1594=0;
const v1595=0;
const v1596=0;
const v1597=0;
const v1598=({["value"]:v1581,["tangent_0"]:v1582,["tangent_1"]:v1583,["tangent_2"]:v1584,["tangent_3"]:v1585,["tangent_4"]:v1586,["tangent_5"]:v1587,["tangent_6"]:v1588,["tangent_7"]:v1589,["tangent_8"]:v1590,["tangent_9"]:v1591,["tangent_10"]:v1592,["tangent_11"]:v1593,["tangent_12"]:v1594,["tangent_13"]:v1595,["tangent_14"]:v1596,["tangent_15"]:v1597});
const v1599=v228["b"];
const v1600=v1599["bias"];
const v1601=0;
const v1602=0;
const v1603=0;
const v1604=0;
const v1605=0;
const v1606=0;
const v1607=1065353216;
const v1608=0;
const v1609=0;
const v1610=0;
const v1611=0;
const v1612=0;
const v1613=0;
const v1614=0;
const v1615=0;
const v1616=0;
const v1617=({["value"]:v1600,["tangent_0"]:v1601,["tangent_1"]:v1602,["tangent_2"]:v1603,["tangent_3"]:v1604,["tangent_4"]:v1605,["tangent_5"]:v1606,["tangent_6"]:v1607,["tangent_7"]:v1608,["tangent_8"]:v1609,["tangent_9"]:v1610,["tangent_10"]:v1611,["tangent_11"]:v1612,["tangent_12"]:v1613,["tangent_13"]:v1614,["tangent_14"]:v1615,["tangent_15"]:v1616});
const v1618=v228["b"];
const v1619=v1618["relu"];
const v1620=0;
const v1621=0;
const v1622=0;
const v1623=0;
const v1624=0;
const v1625=0;
const v1626=0;
const v1627=1065353216;
const v1628=0;
const v1629=0;
const v1630=0;
const v1631=0;
const v1632=0;
const v1633=0;
const v1634=0;
const v1635=0;
const v1636=({["value"]:v1619,["tangent_0"]:v1620,["tangent_1"]:v1621,["tangent_2"]:v1622,["tangent_3"]:v1623,["tangent_4"]:v1624,["tangent_5"]:v1625,["tangent_6"]:v1626,["tangent_7"]:v1627,["tangent_8"]:v1628,["tangent_9"]:v1629,["tangent_10"]:v1630,["tangent_11"]:v1631,["tangent_12"]:v1632,["tangent_13"]:v1633,["tangent_14"]:v1634,["tangent_15"]:v1635});
const v1637=({["identity"]:v1579,["scale"]:v1598,["bias"]:v1617,["relu"]:v1636});
const v1638=v228["c"];
const v1639=v1638["identity"];
const v1640=0;
const v1641=0;
const v1642=0;
const v1643=0;
const v1644=0;
const v1645=0;
const v1646=0;
const v1647=0;
const v1648=1065353216;
const v1649=0;
const v1650=0;
const v1651=0;
const v1652=0;
const v1653=0;
const v1654=0;
const v1655=0;
const v1656=({["value"]:v1639,["tangent_0"]:v1640,["tangent_1"]:v1641,["tangent_2"]:v1642,["tangent_3"]:v1643,["tangent_4"]:v1644,["tangent_5"]:v1645,["tangent_6"]:v1646,["tangent_7"]:v1647,["tangent_8"]:v1648,["tangent_9"]:v1649,["tangent_10"]:v1650,["tangent_11"]:v1651,["tangent_12"]:v1652,["tangent_13"]:v1653,["tangent_14"]:v1654,["tangent_15"]:v1655});
const v1657=v228["c"];
const v1658=v1657["scale"];
const v1659=0;
const v1660=0;
const v1661=0;
const v1662=0;
const v1663=0;
const v1664=0;
const v1665=0;
const v1666=0;
const v1667=0;
const v1668=1065353216;
const v1669=0;
const v1670=0;
const v1671=0;
const v1672=0;
const v1673=0;
const v1674=0;
const v1675=({["value"]:v1658,["tangent_0"]:v1659,["tangent_1"]:v1660,["tangent_2"]:v1661,["tangent_3"]:v1662,["tangent_4"]:v1663,["tangent_5"]:v1664,["tangent_6"]:v1665,["tangent_7"]:v1666,["tangent_8"]:v1667,["tangent_9"]:v1668,["tangent_10"]:v1669,["tangent_11"]:v1670,["tangent_12"]:v1671,["tangent_13"]:v1672,["tangent_14"]:v1673,["tangent_15"]:v1674});
const v1676=v228["c"];
const v1677=v1676["bias"];
const v1678=0;
const v1679=0;
const v1680=0;
const v1681=0;
const v1682=0;
const v1683=0;
const v1684=0;
const v1685=0;
const v1686=0;
const v1687=0;
const v1688=1065353216;
const v1689=0;
const v1690=0;
const v1691=0;
const v1692=0;
const v1693=0;
const v1694=({["value"]:v1677,["tangent_0"]:v1678,["tangent_1"]:v1679,["tangent_2"]:v1680,["tangent_3"]:v1681,["tangent_4"]:v1682,["tangent_5"]:v1683,["tangent_6"]:v1684,["tangent_7"]:v1685,["tangent_8"]:v1686,["tangent_9"]:v1687,["tangent_10"]:v1688,["tangent_11"]:v1689,["tangent_12"]:v1690,["tangent_13"]:v1691,["tangent_14"]:v1692,["tangent_15"]:v1693});
const v1695=v228["c"];
const v1696=v1695["relu"];
const v1697=0;
const v1698=0;
const v1699=0;
const v1700=0;
const v1701=0;
const v1702=0;
const v1703=0;
const v1704=0;
const v1705=0;
const v1706=0;
const v1707=0;
const v1708=1065353216;
const v1709=0;
const v1710=0;
const v1711=0;
const v1712=0;
const v1713=({["value"]:v1696,["tangent_0"]:v1697,["tangent_1"]:v1698,["tangent_2"]:v1699,["tangent_3"]:v1700,["tangent_4"]:v1701,["tangent_5"]:v1702,["tangent_6"]:v1703,["tangent_7"]:v1704,["tangent_8"]:v1705,["tangent_9"]:v1706,["tangent_10"]:v1707,["tangent_11"]:v1708,["tangent_12"]:v1709,["tangent_13"]:v1710,["tangent_14"]:v1711,["tangent_15"]:v1712});
const v1714=({["identity"]:v1656,["scale"]:v1675,["bias"]:v1694,["relu"]:v1713});
const v1715=v228["d"];
const v1716=v1715["identity"];
const v1717=0;
const v1718=0;
const v1719=0;
const v1720=0;
const v1721=0;
const v1722=0;
const v1723=0;
const v1724=0;
const v1725=0;
const v1726=0;
const v1727=0;
const v1728=0;
const v1729=1065353216;
const v1730=0;
const v1731=0;
const v1732=0;
const v1733=({["value"]:v1716,["tangent_0"]:v1717,["tangent_1"]:v1718,["tangent_2"]:v1719,["tangent_3"]:v1720,["tangent_4"]:v1721,["tangent_5"]:v1722,["tangent_6"]:v1723,["tangent_7"]:v1724,["tangent_8"]:v1725,["tangent_9"]:v1726,["tangent_10"]:v1727,["tangent_11"]:v1728,["tangent_12"]:v1729,["tangent_13"]:v1730,["tangent_14"]:v1731,["tangent_15"]:v1732});
const v1734=v228["d"];
const v1735=v1734["scale"];
const v1736=0;
const v1737=0;
const v1738=0;
const v1739=0;
const v1740=0;
const v1741=0;
const v1742=0;
const v1743=0;
const v1744=0;
const v1745=0;
const v1746=0;
const v1747=0;
const v1748=0;
const v1749=1065353216;
const v1750=0;
const v1751=0;
const v1752=({["value"]:v1735,["tangent_0"]:v1736,["tangent_1"]:v1737,["tangent_2"]:v1738,["tangent_3"]:v1739,["tangent_4"]:v1740,["tangent_5"]:v1741,["tangent_6"]:v1742,["tangent_7"]:v1743,["tangent_8"]:v1744,["tangent_9"]:v1745,["tangent_10"]:v1746,["tangent_11"]:v1747,["tangent_12"]:v1748,["tangent_13"]:v1749,["tangent_14"]:v1750,["tangent_15"]:v1751});
const v1753=v228["d"];
const v1754=v1753["bias"];
const v1755=0;
const v1756=0;
const v1757=0;
const v1758=0;
const v1759=0;
const v1760=0;
const v1761=0;
const v1762=0;
const v1763=0;
const v1764=0;
const v1765=0;
const v1766=0;
const v1767=0;
const v1768=0;
const v1769=1065353216;
const v1770=0;
const v1771=({["value"]:v1754,["tangent_0"]:v1755,["tangent_1"]:v1756,["tangent_2"]:v1757,["tangent_3"]:v1758,["tangent_4"]:v1759,["tangent_5"]:v1760,["tangent_6"]:v1761,["tangent_7"]:v1762,["tangent_8"]:v1763,["tangent_9"]:v1764,["tangent_10"]:v1765,["tangent_11"]:v1766,["tangent_12"]:v1767,["tangent_13"]:v1768,["tangent_14"]:v1769,["tangent_15"]:v1770});
const v1772=v228["d"];
const v1773=v1772["relu"];
const v1774=0;
const v1775=0;
const v1776=0;
const v1777=0;
const v1778=0;
const v1779=0;
const v1780=0;
const v1781=0;
const v1782=0;
const v1783=0;
const v1784=0;
const v1785=0;
const v1786=0;
const v1787=0;
const v1788=0;
const v1789=1065353216;
const v1790=({["value"]:v1773,["tangent_0"]:v1774,["tangent_1"]:v1775,["tangent_2"]:v1776,["tangent_3"]:v1777,["tangent_4"]:v1778,["tangent_5"]:v1779,["tangent_6"]:v1780,["tangent_7"]:v1781,["tangent_8"]:v1782,["tangent_9"]:v1783,["tangent_10"]:v1784,["tangent_11"]:v1785,["tangent_12"]:v1786,["tangent_13"]:v1787,["tangent_14"]:v1788,["tangent_15"]:v1789});
const v1791=({["identity"]:v1733,["scale"]:v1752,["bias"]:v1771,["relu"]:v1790});
const v1794=0;
let v1795;
let v1796;
let v1797;
let v1798;
if((v229===v1794)){
v1795=v1560["identity"];
v1796=v1560["scale"];
v1797=v1560["bias"];
v1798=v1560["relu"];
}else{
const v1799=1;
let v1800;
let v1801;
let v1802;
let v1803;
if((v229===v1799)){
v1800=v1637["identity"];
v1801=v1637["scale"];
v1802=v1637["bias"];
v1803=v1637["relu"];
}else{
const v1804=2;
let v1805;
let v1806;
let v1807;
let v1808;
if((v229===v1804)){
v1805=v1714["identity"];
v1806=v1714["scale"];
v1807=v1714["bias"];
v1808=v1714["relu"];
}else{
v1805=v1791["identity"];
v1806=v1791["scale"];
v1807=v1791["bias"];
v1808=v1791["relu"];
}
v1800=v1805;
v1801=v1806;
v1802=v1807;
v1803=v1808;
}
v1795=v1800;
v1796=v1801;
v1797=v1802;
v1798=v1803;
}
const v1810=0;
let v1811;
let v1812;
let v1813;
let v1814;
let v1815;
let v1816;
let v1817;
let v1818;
let v1819;
let v1820;
let v1821;
let v1822;
let v1823;
let v1824;
let v1825;
let v1826;
let v1827;
if((v234===v1810)){
const v1828=v1795;
v1811=v1828["value"];
v1812=v1828["tangent_0"];
v1813=v1828["tangent_1"];
v1814=v1828["tangent_2"];
v1815=v1828["tangent_3"];
v1816=v1828["tangent_4"];
v1817=v1828["tangent_5"];
v1818=v1828["tangent_6"];
v1819=v1828["tangent_7"];
v1820=v1828["tangent_8"];
v1821=v1828["tangent_9"];
v1822=v1828["tangent_10"];
v1823=v1828["tangent_11"];
v1824=v1828["tangent_12"];
v1825=v1828["tangent_13"];
v1826=v1828["tangent_14"];
v1827=v1828["tangent_15"];
}else{
const v1829=1;
let v1830;
let v1831;
let v1832;
let v1833;
let v1834;
let v1835;
let v1836;
let v1837;
let v1838;
let v1839;
let v1840;
let v1841;
let v1842;
let v1843;
let v1844;
let v1845;
let v1846;
if((v234===v1829)){
const v1847=v1796;
v1830=v1847["value"];
v1831=v1847["tangent_0"];
v1832=v1847["tangent_1"];
v1833=v1847["tangent_2"];
v1834=v1847["tangent_3"];
v1835=v1847["tangent_4"];
v1836=v1847["tangent_5"];
v1837=v1847["tangent_6"];
v1838=v1847["tangent_7"];
v1839=v1847["tangent_8"];
v1840=v1847["tangent_9"];
v1841=v1847["tangent_10"];
v1842=v1847["tangent_11"];
v1843=v1847["tangent_12"];
v1844=v1847["tangent_13"];
v1845=v1847["tangent_14"];
v1846=v1847["tangent_15"];
}else{
const v1848=2;
let v1849;
let v1850;
let v1851;
let v1852;
let v1853;
let v1854;
let v1855;
let v1856;
let v1857;
let v1858;
let v1859;
let v1860;
let v1861;
let v1862;
let v1863;
let v1864;
let v1865;
if((v234===v1848)){
const v1866=v1797;
v1849=v1866["value"];
v1850=v1866["tangent_0"];
v1851=v1866["tangent_1"];
v1852=v1866["tangent_2"];
v1853=v1866["tangent_3"];
v1854=v1866["tangent_4"];
v1855=v1866["tangent_5"];
v1856=v1866["tangent_6"];
v1857=v1866["tangent_7"];
v1858=v1866["tangent_8"];
v1859=v1866["tangent_9"];
v1860=v1866["tangent_10"];
v1861=v1866["tangent_11"];
v1862=v1866["tangent_12"];
v1863=v1866["tangent_13"];
v1864=v1866["tangent_14"];
v1865=v1866["tangent_15"];
}else{
const v1867=v1798;
v1849=v1867["value"];
v1850=v1867["tangent_0"];
v1851=v1867["tangent_1"];
v1852=v1867["tangent_2"];
v1853=v1867["tangent_3"];
v1854=v1867["tangent_4"];
v1855=v1867["tangent_5"];
v1856=v1867["tangent_6"];
v1857=v1867["tangent_7"];
v1858=v1867["tangent_8"];
v1859=v1867["tangent_9"];
v1860=v1867["tangent_10"];
v1861=v1867["tangent_11"];
v1862=v1867["tangent_12"];
v1863=v1867["tangent_13"];
v1864=v1867["tangent_14"];
v1865=v1867["tangent_15"];
}
v1830=v1849;
v1831=v1850;
v1832=v1851;
v1833=v1852;
v1834=v1853;
v1835=v1854;
v1836=v1855;
v1837=v1856;
v1838=v1857;
v1839=v1858;
v1840=v1859;
v1841=v1860;
v1842=v1861;
v1843=v1862;
v1844=v1863;
v1845=v1864;
v1846=v1865;
}
v1811=v1830;
v1812=v1831;
v1813=v1832;
v1814=v1833;
v1815=v1834;
v1816=v1835;
v1817=v1836;
v1818=v1837;
v1819=v1838;
v1820=v1839;
v1821=v1840;
v1822=v1841;
v1823=v1842;
v1824=v1843;
v1825=v1844;
v1826=v1845;
v1827=v1846;
}
const v1869=v1811;
const v1870=v1811;
const v1871=__bits(__float(v1869) * __float(v1870));
const v1872=v1812;
const v1873=v1811;
const v1874=__bits(__float(v1872) * __float(v1873));
const v1875=v1811;
const v1876=v1812;
const v1877=__bits(__float(v1875) * __float(v1876));
const v1878=__bits(__float(v1874) + __float(v1877));
const v1879=v1813;
const v1880=v1811;
const v1881=__bits(__float(v1879) * __float(v1880));
const v1882=v1811;
const v1883=v1813;
const v1884=__bits(__float(v1882) * __float(v1883));
const v1885=__bits(__float(v1881) + __float(v1884));
const v1886=v1814;
const v1887=v1811;
const v1888=__bits(__float(v1886) * __float(v1887));
const v1889=v1811;
const v1890=v1814;
const v1891=__bits(__float(v1889) * __float(v1890));
const v1892=__bits(__float(v1888) + __float(v1891));
const v1893=v1815;
const v1894=v1811;
const v1895=__bits(__float(v1893) * __float(v1894));
const v1896=v1811;
const v1897=v1815;
const v1898=__bits(__float(v1896) * __float(v1897));
const v1899=__bits(__float(v1895) + __float(v1898));
const v1900=v1816;
const v1901=v1811;
const v1902=__bits(__float(v1900) * __float(v1901));
const v1903=v1811;
const v1904=v1816;
const v1905=__bits(__float(v1903) * __float(v1904));
const v1906=__bits(__float(v1902) + __float(v1905));
const v1907=v1817;
const v1908=v1811;
const v1909=__bits(__float(v1907) * __float(v1908));
const v1910=v1811;
const v1911=v1817;
const v1912=__bits(__float(v1910) * __float(v1911));
const v1913=__bits(__float(v1909) + __float(v1912));
const v1914=v1818;
const v1915=v1811;
const v1916=__bits(__float(v1914) * __float(v1915));
const v1917=v1811;
const v1918=v1818;
const v1919=__bits(__float(v1917) * __float(v1918));
const v1920=__bits(__float(v1916) + __float(v1919));
const v1921=v1819;
const v1922=v1811;
const v1923=__bits(__float(v1921) * __float(v1922));
const v1924=v1811;
const v1925=v1819;
const v1926=__bits(__float(v1924) * __float(v1925));
const v1927=__bits(__float(v1923) + __float(v1926));
const v1928=v1820;
const v1929=v1811;
const v1930=__bits(__float(v1928) * __float(v1929));
const v1931=v1811;
const v1932=v1820;
const v1933=__bits(__float(v1931) * __float(v1932));
const v1934=__bits(__float(v1930) + __float(v1933));
const v1935=v1821;
const v1936=v1811;
const v1937=__bits(__float(v1935) * __float(v1936));
const v1938=v1811;
const v1939=v1821;
const v1940=__bits(__float(v1938) * __float(v1939));
const v1941=__bits(__float(v1937) + __float(v1940));
const v1942=v1822;
const v1943=v1811;
const v1944=__bits(__float(v1942) * __float(v1943));
const v1945=v1811;
const v1946=v1822;
const v1947=__bits(__float(v1945) * __float(v1946));
const v1948=__bits(__float(v1944) + __float(v1947));
const v1949=v1823;
const v1950=v1811;
const v1951=__bits(__float(v1949) * __float(v1950));
const v1952=v1811;
const v1953=v1823;
const v1954=__bits(__float(v1952) * __float(v1953));
const v1955=__bits(__float(v1951) + __float(v1954));
const v1956=v1824;
const v1957=v1811;
const v1958=__bits(__float(v1956) * __float(v1957));
const v1959=v1811;
const v1960=v1824;
const v1961=__bits(__float(v1959) * __float(v1960));
const v1962=__bits(__float(v1958) + __float(v1961));
const v1963=v1825;
const v1964=v1811;
const v1965=__bits(__float(v1963) * __float(v1964));
const v1966=v1811;
const v1967=v1825;
const v1968=__bits(__float(v1966) * __float(v1967));
const v1969=__bits(__float(v1965) + __float(v1968));
const v1970=v1826;
const v1971=v1811;
const v1972=__bits(__float(v1970) * __float(v1971));
const v1973=v1811;
const v1974=v1826;
const v1975=__bits(__float(v1973) * __float(v1974));
const v1976=__bits(__float(v1972) + __float(v1975));
const v1977=v1827;
const v1978=v1811;
const v1979=__bits(__float(v1977) * __float(v1978));
const v1980=v1811;
const v1981=v1827;
const v1982=__bits(__float(v1980) * __float(v1981));
const v1983=__bits(__float(v1979) + __float(v1982));
const v1985=1036831949;
const v1986=0;
const v1987=0;
const v1988=0;
const v1989=0;
const v1990=0;
const v1991=0;
const v1992=0;
const v1993=0;
const v1994=0;
const v1995=0;
const v1996=0;
const v1997=0;
const v1998=0;
const v1999=0;
const v2000=0;
const v2001=0;
const v2003=__bits(__float(v1871) + __float(v1985));
const v2004=__bits(__float(v1878) + __float(v1986));
const v2005=__bits(__float(v1885) + __float(v1987));
const v2006=__bits(__float(v1892) + __float(v1988));
const v2007=__bits(__float(v1899) + __float(v1989));
const v2008=__bits(__float(v1906) + __float(v1990));
const v2009=__bits(__float(v1913) + __float(v1991));
const v2010=__bits(__float(v1920) + __float(v1992));
const v2011=__bits(__float(v1927) + __float(v1993));
const v2012=__bits(__float(v1934) + __float(v1994));
const v2013=__bits(__float(v1941) + __float(v1995));
const v2014=__bits(__float(v1948) + __float(v1996));
const v2015=__bits(__float(v1955) + __float(v1997));
const v2016=__bits(__float(v1962) + __float(v1998));
const v2017=__bits(__float(v1969) + __float(v1999));
const v2018=__bits(__float(v1976) + __float(v2000));
const v2019=__bits(__float(v1983) + __float(v2001));
const v2021=({["identity"]:v2004,["scale"]:v2005,["bias"]:v2006,["relu"]:v2007});
const v2022=({["identity"]:v2008,["scale"]:v2009,["bias"]:v2010,["relu"]:v2011});
const v2023=({["identity"]:v2012,["scale"]:v2013,["bias"]:v2014,["relu"]:v2015});
const v2024=({["identity"]:v2016,["scale"]:v2017,["bias"]:v2018,["relu"]:v2019});
const v2026=v2021["identity"];
const v2027=v2021["scale"];
const v2028=v2021["bias"];
const v2029=v2021["relu"];
const v2030=v2022["identity"];
const v2031=v2022["scale"];
const v2032=v2022["bias"];
const v2033=v2022["relu"];
const v2034=v2023["identity"];
const v2035=v2023["scale"];
const v2036=v2023["bias"];
const v2037=v2023["relu"];
const v2038=v2024["identity"];
const v2039=v2024["scale"];
const v2040=v2024["bias"];
const v2041=v2024["relu"];
const v2042=[v2026,v2027,v2028,v2029,v2030,v2031,v2032,v2033,v2034,v2035,v2036,v2037,v2038,v2039,v2040,v2041];
const v2044=v228["a"];
const v2045=v2044["identity"];
const v2046=1065353216;
const v2047=0;
const v2048=0;
const v2049=0;
const v2050=0;
const v2051=0;
const v2052=0;
const v2053=0;
const v2054=0;
const v2055=0;
const v2056=0;
const v2057=0;
const v2058=0;
const v2059=0;
const v2060=0;
const v2061=0;
const v2062=({["value"]:v2045,["tangent_0"]:v2046,["tangent_1"]:v2047,["tangent_2"]:v2048,["tangent_3"]:v2049,["tangent_4"]:v2050,["tangent_5"]:v2051,["tangent_6"]:v2052,["tangent_7"]:v2053,["tangent_8"]:v2054,["tangent_9"]:v2055,["tangent_10"]:v2056,["tangent_11"]:v2057,["tangent_12"]:v2058,["tangent_13"]:v2059,["tangent_14"]:v2060,["tangent_15"]:v2061});
const v2063=v228["a"];
const v2064=v2063["scale"];
const v2065=0;
const v2066=1065353216;
const v2067=0;
const v2068=0;
const v2069=0;
const v2070=0;
const v2071=0;
const v2072=0;
const v2073=0;
const v2074=0;
const v2075=0;
const v2076=0;
const v2077=0;
const v2078=0;
const v2079=0;
const v2080=0;
const v2081=({["value"]:v2064,["tangent_0"]:v2065,["tangent_1"]:v2066,["tangent_2"]:v2067,["tangent_3"]:v2068,["tangent_4"]:v2069,["tangent_5"]:v2070,["tangent_6"]:v2071,["tangent_7"]:v2072,["tangent_8"]:v2073,["tangent_9"]:v2074,["tangent_10"]:v2075,["tangent_11"]:v2076,["tangent_12"]:v2077,["tangent_13"]:v2078,["tangent_14"]:v2079,["tangent_15"]:v2080});
const v2082=v228["a"];
const v2083=v2082["bias"];
const v2084=0;
const v2085=0;
const v2086=1065353216;
const v2087=0;
const v2088=0;
const v2089=0;
const v2090=0;
const v2091=0;
const v2092=0;
const v2093=0;
const v2094=0;
const v2095=0;
const v2096=0;
const v2097=0;
const v2098=0;
const v2099=0;
const v2100=({["value"]:v2083,["tangent_0"]:v2084,["tangent_1"]:v2085,["tangent_2"]:v2086,["tangent_3"]:v2087,["tangent_4"]:v2088,["tangent_5"]:v2089,["tangent_6"]:v2090,["tangent_7"]:v2091,["tangent_8"]:v2092,["tangent_9"]:v2093,["tangent_10"]:v2094,["tangent_11"]:v2095,["tangent_12"]:v2096,["tangent_13"]:v2097,["tangent_14"]:v2098,["tangent_15"]:v2099});
const v2101=v228["a"];
const v2102=v2101["relu"];
const v2103=0;
const v2104=0;
const v2105=0;
const v2106=1065353216;
const v2107=0;
const v2108=0;
const v2109=0;
const v2110=0;
const v2111=0;
const v2112=0;
const v2113=0;
const v2114=0;
const v2115=0;
const v2116=0;
const v2117=0;
const v2118=0;
const v2119=({["value"]:v2102,["tangent_0"]:v2103,["tangent_1"]:v2104,["tangent_2"]:v2105,["tangent_3"]:v2106,["tangent_4"]:v2107,["tangent_5"]:v2108,["tangent_6"]:v2109,["tangent_7"]:v2110,["tangent_8"]:v2111,["tangent_9"]:v2112,["tangent_10"]:v2113,["tangent_11"]:v2114,["tangent_12"]:v2115,["tangent_13"]:v2116,["tangent_14"]:v2117,["tangent_15"]:v2118});
const v2120=({["identity"]:v2062,["scale"]:v2081,["bias"]:v2100,["relu"]:v2119});
const v2121=v228["b"];
const v2122=v2121["identity"];
const v2123=0;
const v2124=0;
const v2125=0;
const v2126=0;
const v2127=1065353216;
const v2128=0;
const v2129=0;
const v2130=0;
const v2131=0;
const v2132=0;
const v2133=0;
const v2134=0;
const v2135=0;
const v2136=0;
const v2137=0;
const v2138=0;
const v2139=({["value"]:v2122,["tangent_0"]:v2123,["tangent_1"]:v2124,["tangent_2"]:v2125,["tangent_3"]:v2126,["tangent_4"]:v2127,["tangent_5"]:v2128,["tangent_6"]:v2129,["tangent_7"]:v2130,["tangent_8"]:v2131,["tangent_9"]:v2132,["tangent_10"]:v2133,["tangent_11"]:v2134,["tangent_12"]:v2135,["tangent_13"]:v2136,["tangent_14"]:v2137,["tangent_15"]:v2138});
const v2140=v228["b"];
const v2141=v2140["scale"];
const v2142=0;
const v2143=0;
const v2144=0;
const v2145=0;
const v2146=0;
const v2147=1065353216;
const v2148=0;
const v2149=0;
const v2150=0;
const v2151=0;
const v2152=0;
const v2153=0;
const v2154=0;
const v2155=0;
const v2156=0;
const v2157=0;
const v2158=({["value"]:v2141,["tangent_0"]:v2142,["tangent_1"]:v2143,["tangent_2"]:v2144,["tangent_3"]:v2145,["tangent_4"]:v2146,["tangent_5"]:v2147,["tangent_6"]:v2148,["tangent_7"]:v2149,["tangent_8"]:v2150,["tangent_9"]:v2151,["tangent_10"]:v2152,["tangent_11"]:v2153,["tangent_12"]:v2154,["tangent_13"]:v2155,["tangent_14"]:v2156,["tangent_15"]:v2157});
const v2159=v228["b"];
const v2160=v2159["bias"];
const v2161=0;
const v2162=0;
const v2163=0;
const v2164=0;
const v2165=0;
const v2166=0;
const v2167=1065353216;
const v2168=0;
const v2169=0;
const v2170=0;
const v2171=0;
const v2172=0;
const v2173=0;
const v2174=0;
const v2175=0;
const v2176=0;
const v2177=({["value"]:v2160,["tangent_0"]:v2161,["tangent_1"]:v2162,["tangent_2"]:v2163,["tangent_3"]:v2164,["tangent_4"]:v2165,["tangent_5"]:v2166,["tangent_6"]:v2167,["tangent_7"]:v2168,["tangent_8"]:v2169,["tangent_9"]:v2170,["tangent_10"]:v2171,["tangent_11"]:v2172,["tangent_12"]:v2173,["tangent_13"]:v2174,["tangent_14"]:v2175,["tangent_15"]:v2176});
const v2178=v228["b"];
const v2179=v2178["relu"];
const v2180=0;
const v2181=0;
const v2182=0;
const v2183=0;
const v2184=0;
const v2185=0;
const v2186=0;
const v2187=1065353216;
const v2188=0;
const v2189=0;
const v2190=0;
const v2191=0;
const v2192=0;
const v2193=0;
const v2194=0;
const v2195=0;
const v2196=({["value"]:v2179,["tangent_0"]:v2180,["tangent_1"]:v2181,["tangent_2"]:v2182,["tangent_3"]:v2183,["tangent_4"]:v2184,["tangent_5"]:v2185,["tangent_6"]:v2186,["tangent_7"]:v2187,["tangent_8"]:v2188,["tangent_9"]:v2189,["tangent_10"]:v2190,["tangent_11"]:v2191,["tangent_12"]:v2192,["tangent_13"]:v2193,["tangent_14"]:v2194,["tangent_15"]:v2195});
const v2197=({["identity"]:v2139,["scale"]:v2158,["bias"]:v2177,["relu"]:v2196});
const v2198=v228["c"];
const v2199=v2198["identity"];
const v2200=0;
const v2201=0;
const v2202=0;
const v2203=0;
const v2204=0;
const v2205=0;
const v2206=0;
const v2207=0;
const v2208=1065353216;
const v2209=0;
const v2210=0;
const v2211=0;
const v2212=0;
const v2213=0;
const v2214=0;
const v2215=0;
const v2216=({["value"]:v2199,["tangent_0"]:v2200,["tangent_1"]:v2201,["tangent_2"]:v2202,["tangent_3"]:v2203,["tangent_4"]:v2204,["tangent_5"]:v2205,["tangent_6"]:v2206,["tangent_7"]:v2207,["tangent_8"]:v2208,["tangent_9"]:v2209,["tangent_10"]:v2210,["tangent_11"]:v2211,["tangent_12"]:v2212,["tangent_13"]:v2213,["tangent_14"]:v2214,["tangent_15"]:v2215});
const v2217=v228["c"];
const v2218=v2217["scale"];
const v2219=0;
const v2220=0;
const v2221=0;
const v2222=0;
const v2223=0;
const v2224=0;
const v2225=0;
const v2226=0;
const v2227=0;
const v2228=1065353216;
const v2229=0;
const v2230=0;
const v2231=0;
const v2232=0;
const v2233=0;
const v2234=0;
const v2235=({["value"]:v2218,["tangent_0"]:v2219,["tangent_1"]:v2220,["tangent_2"]:v2221,["tangent_3"]:v2222,["tangent_4"]:v2223,["tangent_5"]:v2224,["tangent_6"]:v2225,["tangent_7"]:v2226,["tangent_8"]:v2227,["tangent_9"]:v2228,["tangent_10"]:v2229,["tangent_11"]:v2230,["tangent_12"]:v2231,["tangent_13"]:v2232,["tangent_14"]:v2233,["tangent_15"]:v2234});
const v2236=v228["c"];
const v2237=v2236["bias"];
const v2238=0;
const v2239=0;
const v2240=0;
const v2241=0;
const v2242=0;
const v2243=0;
const v2244=0;
const v2245=0;
const v2246=0;
const v2247=0;
const v2248=1065353216;
const v2249=0;
const v2250=0;
const v2251=0;
const v2252=0;
const v2253=0;
const v2254=({["value"]:v2237,["tangent_0"]:v2238,["tangent_1"]:v2239,["tangent_2"]:v2240,["tangent_3"]:v2241,["tangent_4"]:v2242,["tangent_5"]:v2243,["tangent_6"]:v2244,["tangent_7"]:v2245,["tangent_8"]:v2246,["tangent_9"]:v2247,["tangent_10"]:v2248,["tangent_11"]:v2249,["tangent_12"]:v2250,["tangent_13"]:v2251,["tangent_14"]:v2252,["tangent_15"]:v2253});
const v2255=v228["c"];
const v2256=v2255["relu"];
const v2257=0;
const v2258=0;
const v2259=0;
const v2260=0;
const v2261=0;
const v2262=0;
const v2263=0;
const v2264=0;
const v2265=0;
const v2266=0;
const v2267=0;
const v2268=1065353216;
const v2269=0;
const v2270=0;
const v2271=0;
const v2272=0;
const v2273=({["value"]:v2256,["tangent_0"]:v2257,["tangent_1"]:v2258,["tangent_2"]:v2259,["tangent_3"]:v2260,["tangent_4"]:v2261,["tangent_5"]:v2262,["tangent_6"]:v2263,["tangent_7"]:v2264,["tangent_8"]:v2265,["tangent_9"]:v2266,["tangent_10"]:v2267,["tangent_11"]:v2268,["tangent_12"]:v2269,["tangent_13"]:v2270,["tangent_14"]:v2271,["tangent_15"]:v2272});
const v2274=({["identity"]:v2216,["scale"]:v2235,["bias"]:v2254,["relu"]:v2273});
const v2275=v228["d"];
const v2276=v2275["identity"];
const v2277=0;
const v2278=0;
const v2279=0;
const v2280=0;
const v2281=0;
const v2282=0;
const v2283=0;
const v2284=0;
const v2285=0;
const v2286=0;
const v2287=0;
const v2288=0;
const v2289=1065353216;
const v2290=0;
const v2291=0;
const v2292=0;
const v2293=({["value"]:v2276,["tangent_0"]:v2277,["tangent_1"]:v2278,["tangent_2"]:v2279,["tangent_3"]:v2280,["tangent_4"]:v2281,["tangent_5"]:v2282,["tangent_6"]:v2283,["tangent_7"]:v2284,["tangent_8"]:v2285,["tangent_9"]:v2286,["tangent_10"]:v2287,["tangent_11"]:v2288,["tangent_12"]:v2289,["tangent_13"]:v2290,["tangent_14"]:v2291,["tangent_15"]:v2292});
const v2294=v228["d"];
const v2295=v2294["scale"];
const v2296=0;
const v2297=0;
const v2298=0;
const v2299=0;
const v2300=0;
const v2301=0;
const v2302=0;
const v2303=0;
const v2304=0;
const v2305=0;
const v2306=0;
const v2307=0;
const v2308=0;
const v2309=1065353216;
const v2310=0;
const v2311=0;
const v2312=({["value"]:v2295,["tangent_0"]:v2296,["tangent_1"]:v2297,["tangent_2"]:v2298,["tangent_3"]:v2299,["tangent_4"]:v2300,["tangent_5"]:v2301,["tangent_6"]:v2302,["tangent_7"]:v2303,["tangent_8"]:v2304,["tangent_9"]:v2305,["tangent_10"]:v2306,["tangent_11"]:v2307,["tangent_12"]:v2308,["tangent_13"]:v2309,["tangent_14"]:v2310,["tangent_15"]:v2311});
const v2313=v228["d"];
const v2314=v2313["bias"];
const v2315=0;
const v2316=0;
const v2317=0;
const v2318=0;
const v2319=0;
const v2320=0;
const v2321=0;
const v2322=0;
const v2323=0;
const v2324=0;
const v2325=0;
const v2326=0;
const v2327=0;
const v2328=0;
const v2329=1065353216;
const v2330=0;
const v2331=({["value"]:v2314,["tangent_0"]:v2315,["tangent_1"]:v2316,["tangent_2"]:v2317,["tangent_3"]:v2318,["tangent_4"]:v2319,["tangent_5"]:v2320,["tangent_6"]:v2321,["tangent_7"]:v2322,["tangent_8"]:v2323,["tangent_9"]:v2324,["tangent_10"]:v2325,["tangent_11"]:v2326,["tangent_12"]:v2327,["tangent_13"]:v2328,["tangent_14"]:v2329,["tangent_15"]:v2330});
const v2332=v228["d"];
const v2333=v2332["relu"];
const v2334=0;
const v2335=0;
const v2336=0;
const v2337=0;
const v2338=0;
const v2339=0;
const v2340=0;
const v2341=0;
const v2342=0;
const v2343=0;
const v2344=0;
const v2345=0;
const v2346=0;
const v2347=0;
const v2348=0;
const v2349=1065353216;
const v2350=({["value"]:v2333,["tangent_0"]:v2334,["tangent_1"]:v2335,["tangent_2"]:v2336,["tangent_3"]:v2337,["tangent_4"]:v2338,["tangent_5"]:v2339,["tangent_6"]:v2340,["tangent_7"]:v2341,["tangent_8"]:v2342,["tangent_9"]:v2343,["tangent_10"]:v2344,["tangent_11"]:v2345,["tangent_12"]:v2346,["tangent_13"]:v2347,["tangent_14"]:v2348,["tangent_15"]:v2349});
const v2351=({["identity"]:v2293,["scale"]:v2312,["bias"]:v2331,["relu"]:v2350});
const v2354=0;
let v2355;
let v2356;
let v2357;
let v2358;
if((v229===v2354)){
v2355=v2120["identity"];
v2356=v2120["scale"];
v2357=v2120["bias"];
v2358=v2120["relu"];
}else{
const v2359=1;
let v2360;
let v2361;
let v2362;
let v2363;
if((v229===v2359)){
v2360=v2197["identity"];
v2361=v2197["scale"];
v2362=v2197["bias"];
v2363=v2197["relu"];
}else{
const v2364=2;
let v2365;
let v2366;
let v2367;
let v2368;
if((v229===v2364)){
v2365=v2274["identity"];
v2366=v2274["scale"];
v2367=v2274["bias"];
v2368=v2274["relu"];
}else{
v2365=v2351["identity"];
v2366=v2351["scale"];
v2367=v2351["bias"];
v2368=v2351["relu"];
}
v2360=v2365;
v2361=v2366;
v2362=v2367;
v2363=v2368;
}
v2355=v2360;
v2356=v2361;
v2357=v2362;
v2358=v2363;
}
const v2370=0;
let v2371;
let v2372;
let v2373;
let v2374;
let v2375;
let v2376;
let v2377;
let v2378;
let v2379;
let v2380;
let v2381;
let v2382;
let v2383;
let v2384;
let v2385;
let v2386;
let v2387;
if((v236===v2370)){
const v2388=v2355;
v2371=v2388["value"];
v2372=v2388["tangent_0"];
v2373=v2388["tangent_1"];
v2374=v2388["tangent_2"];
v2375=v2388["tangent_3"];
v2376=v2388["tangent_4"];
v2377=v2388["tangent_5"];
v2378=v2388["tangent_6"];
v2379=v2388["tangent_7"];
v2380=v2388["tangent_8"];
v2381=v2388["tangent_9"];
v2382=v2388["tangent_10"];
v2383=v2388["tangent_11"];
v2384=v2388["tangent_12"];
v2385=v2388["tangent_13"];
v2386=v2388["tangent_14"];
v2387=v2388["tangent_15"];
}else{
const v2389=1;
let v2390;
let v2391;
let v2392;
let v2393;
let v2394;
let v2395;
let v2396;
let v2397;
let v2398;
let v2399;
let v2400;
let v2401;
let v2402;
let v2403;
let v2404;
let v2405;
let v2406;
if((v236===v2389)){
const v2407=v2356;
v2390=v2407["value"];
v2391=v2407["tangent_0"];
v2392=v2407["tangent_1"];
v2393=v2407["tangent_2"];
v2394=v2407["tangent_3"];
v2395=v2407["tangent_4"];
v2396=v2407["tangent_5"];
v2397=v2407["tangent_6"];
v2398=v2407["tangent_7"];
v2399=v2407["tangent_8"];
v2400=v2407["tangent_9"];
v2401=v2407["tangent_10"];
v2402=v2407["tangent_11"];
v2403=v2407["tangent_12"];
v2404=v2407["tangent_13"];
v2405=v2407["tangent_14"];
v2406=v2407["tangent_15"];
}else{
const v2408=2;
let v2409;
let v2410;
let v2411;
let v2412;
let v2413;
let v2414;
let v2415;
let v2416;
let v2417;
let v2418;
let v2419;
let v2420;
let v2421;
let v2422;
let v2423;
let v2424;
let v2425;
if((v236===v2408)){
const v2426=v2357;
v2409=v2426["value"];
v2410=v2426["tangent_0"];
v2411=v2426["tangent_1"];
v2412=v2426["tangent_2"];
v2413=v2426["tangent_3"];
v2414=v2426["tangent_4"];
v2415=v2426["tangent_5"];
v2416=v2426["tangent_6"];
v2417=v2426["tangent_7"];
v2418=v2426["tangent_8"];
v2419=v2426["tangent_9"];
v2420=v2426["tangent_10"];
v2421=v2426["tangent_11"];
v2422=v2426["tangent_12"];
v2423=v2426["tangent_13"];
v2424=v2426["tangent_14"];
v2425=v2426["tangent_15"];
}else{
const v2427=v2358;
v2409=v2427["value"];
v2410=v2427["tangent_0"];
v2411=v2427["tangent_1"];
v2412=v2427["tangent_2"];
v2413=v2427["tangent_3"];
v2414=v2427["tangent_4"];
v2415=v2427["tangent_5"];
v2416=v2427["tangent_6"];
v2417=v2427["tangent_7"];
v2418=v2427["tangent_8"];
v2419=v2427["tangent_9"];
v2420=v2427["tangent_10"];
v2421=v2427["tangent_11"];
v2422=v2427["tangent_12"];
v2423=v2427["tangent_13"];
v2424=v2427["tangent_14"];
v2425=v2427["tangent_15"];
}
v2390=v2409;
v2391=v2410;
v2392=v2411;
v2393=v2412;
v2394=v2413;
v2395=v2414;
v2396=v2415;
v2397=v2416;
v2398=v2417;
v2399=v2418;
v2400=v2419;
v2401=v2420;
v2402=v2421;
v2403=v2422;
v2404=v2423;
v2405=v2424;
v2406=v2425;
}
v2371=v2390;
v2372=v2391;
v2373=v2392;
v2374=v2393;
v2375=v2394;
v2376=v2395;
v2377=v2396;
v2378=v2397;
v2379=v2398;
v2380=v2399;
v2381=v2400;
v2382=v2401;
v2383=v2402;
v2384=v2403;
v2385=v2404;
v2386=v2405;
v2387=v2406;
}
const v2429=v2371;
const v2430=v2371;
const v2431=__bits(__float(v2429) * __float(v2430));
const v2432=v2372;
const v2433=v2371;
const v2434=__bits(__float(v2432) * __float(v2433));
const v2435=v2371;
const v2436=v2372;
const v2437=__bits(__float(v2435) * __float(v2436));
const v2438=__bits(__float(v2434) + __float(v2437));
const v2439=v2373;
const v2440=v2371;
const v2441=__bits(__float(v2439) * __float(v2440));
const v2442=v2371;
const v2443=v2373;
const v2444=__bits(__float(v2442) * __float(v2443));
const v2445=__bits(__float(v2441) + __float(v2444));
const v2446=v2374;
const v2447=v2371;
const v2448=__bits(__float(v2446) * __float(v2447));
const v2449=v2371;
const v2450=v2374;
const v2451=__bits(__float(v2449) * __float(v2450));
const v2452=__bits(__float(v2448) + __float(v2451));
const v2453=v2375;
const v2454=v2371;
const v2455=__bits(__float(v2453) * __float(v2454));
const v2456=v2371;
const v2457=v2375;
const v2458=__bits(__float(v2456) * __float(v2457));
const v2459=__bits(__float(v2455) + __float(v2458));
const v2460=v2376;
const v2461=v2371;
const v2462=__bits(__float(v2460) * __float(v2461));
const v2463=v2371;
const v2464=v2376;
const v2465=__bits(__float(v2463) * __float(v2464));
const v2466=__bits(__float(v2462) + __float(v2465));
const v2467=v2377;
const v2468=v2371;
const v2469=__bits(__float(v2467) * __float(v2468));
const v2470=v2371;
const v2471=v2377;
const v2472=__bits(__float(v2470) * __float(v2471));
const v2473=__bits(__float(v2469) + __float(v2472));
const v2474=v2378;
const v2475=v2371;
const v2476=__bits(__float(v2474) * __float(v2475));
const v2477=v2371;
const v2478=v2378;
const v2479=__bits(__float(v2477) * __float(v2478));
const v2480=__bits(__float(v2476) + __float(v2479));
const v2481=v2379;
const v2482=v2371;
const v2483=__bits(__float(v2481) * __float(v2482));
const v2484=v2371;
const v2485=v2379;
const v2486=__bits(__float(v2484) * __float(v2485));
const v2487=__bits(__float(v2483) + __float(v2486));
const v2488=v2380;
const v2489=v2371;
const v2490=__bits(__float(v2488) * __float(v2489));
const v2491=v2371;
const v2492=v2380;
const v2493=__bits(__float(v2491) * __float(v2492));
const v2494=__bits(__float(v2490) + __float(v2493));
const v2495=v2381;
const v2496=v2371;
const v2497=__bits(__float(v2495) * __float(v2496));
const v2498=v2371;
const v2499=v2381;
const v2500=__bits(__float(v2498) * __float(v2499));
const v2501=__bits(__float(v2497) + __float(v2500));
const v2502=v2382;
const v2503=v2371;
const v2504=__bits(__float(v2502) * __float(v2503));
const v2505=v2371;
const v2506=v2382;
const v2507=__bits(__float(v2505) * __float(v2506));
const v2508=__bits(__float(v2504) + __float(v2507));
const v2509=v2383;
const v2510=v2371;
const v2511=__bits(__float(v2509) * __float(v2510));
const v2512=v2371;
const v2513=v2383;
const v2514=__bits(__float(v2512) * __float(v2513));
const v2515=__bits(__float(v2511) + __float(v2514));
const v2516=v2384;
const v2517=v2371;
const v2518=__bits(__float(v2516) * __float(v2517));
const v2519=v2371;
const v2520=v2384;
const v2521=__bits(__float(v2519) * __float(v2520));
const v2522=__bits(__float(v2518) + __float(v2521));
const v2523=v2385;
const v2524=v2371;
const v2525=__bits(__float(v2523) * __float(v2524));
const v2526=v2371;
const v2527=v2385;
const v2528=__bits(__float(v2526) * __float(v2527));
const v2529=__bits(__float(v2525) + __float(v2528));
const v2530=v2386;
const v2531=v2371;
const v2532=__bits(__float(v2530) * __float(v2531));
const v2533=v2371;
const v2534=v2386;
const v2535=__bits(__float(v2533) * __float(v2534));
const v2536=__bits(__float(v2532) + __float(v2535));
const v2537=v2387;
const v2538=v2371;
const v2539=__bits(__float(v2537) * __float(v2538));
const v2540=v2371;
const v2541=v2387;
const v2542=__bits(__float(v2540) * __float(v2541));
const v2543=__bits(__float(v2539) + __float(v2542));
const v2545=1036831949;
const v2546=0;
const v2547=0;
const v2548=0;
const v2549=0;
const v2550=0;
const v2551=0;
const v2552=0;
const v2553=0;
const v2554=0;
const v2555=0;
const v2556=0;
const v2557=0;
const v2558=0;
const v2559=0;
const v2560=0;
const v2561=0;
const v2563=__bits(__float(v2431) + __float(v2545));
const v2564=__bits(__float(v2438) + __float(v2546));
const v2565=__bits(__float(v2445) + __float(v2547));
const v2566=__bits(__float(v2452) + __float(v2548));
const v2567=__bits(__float(v2459) + __float(v2549));
const v2568=__bits(__float(v2466) + __float(v2550));
const v2569=__bits(__float(v2473) + __float(v2551));
const v2570=__bits(__float(v2480) + __float(v2552));
const v2571=__bits(__float(v2487) + __float(v2553));
const v2572=__bits(__float(v2494) + __float(v2554));
const v2573=__bits(__float(v2501) + __float(v2555));
const v2574=__bits(__float(v2508) + __float(v2556));
const v2575=__bits(__float(v2515) + __float(v2557));
const v2576=__bits(__float(v2522) + __float(v2558));
const v2577=__bits(__float(v2529) + __float(v2559));
const v2578=__bits(__float(v2536) + __float(v2560));
const v2579=__bits(__float(v2543) + __float(v2561));
const v2581=({["identity"]:v2564,["scale"]:v2565,["bias"]:v2566,["relu"]:v2567});
const v2582=({["identity"]:v2568,["scale"]:v2569,["bias"]:v2570,["relu"]:v2571});
const v2583=({["identity"]:v2572,["scale"]:v2573,["bias"]:v2574,["relu"]:v2575});
const v2584=({["identity"]:v2576,["scale"]:v2577,["bias"]:v2578,["relu"]:v2579});
const v2586=v2581["identity"];
const v2587=v2581["scale"];
const v2588=v2581["bias"];
const v2589=v2581["relu"];
const v2590=v2582["identity"];
const v2591=v2582["scale"];
const v2592=v2582["bias"];
const v2593=v2582["relu"];
const v2594=v2583["identity"];
const v2595=v2583["scale"];
const v2596=v2583["bias"];
const v2597=v2583["relu"];
const v2598=v2584["identity"];
const v2599=v2584["scale"];
const v2600=v2584["bias"];
const v2601=v2584["relu"];
const v2602=[v2586,v2587,v2588,v2589,v2590,v2591,v2592,v2593,v2594,v2595,v2596,v2597,v2598,v2599,v2600,v2601];
const v2603=[v922,v1482,v2042,v2602];
return ({["masses"]:v362,["derivatives"]:v2603});}
function __fn10(v2604,v2605,v2606,v2607){
let v2608;if(Object.hasOwn(v2604,"Ok")){
const v2609=v2604["Ok"];
const v2610=__fn9(v2606,v2605);
const v2611=v2610["masses"];
const v2612=v2610["derivatives"];
const v2613=true;
const v2614=true;
const v2615=true;
const v2616=true;
const v2617=[v2613,v2614,v2615,v2616];
let v2618;if(v2605<v2607.length){v2618=v2607[v2605];}else{
const v2619=1065353216;
v2618=((v2619 ^ 2147483648) >>> 0);}
const v2620=v2618;
const v2621=__fn25(v2611,v2612,v2617,v2620);
let v2622;if(Object.hasOwn(v2621,"Ok")){
const v2623=v2621["Ok"];
const v2624=v2609["choices"];
const v2625=v2623["action"];
const v2626=__fn8(v2625);
const v2627=[v2626];
const v2628=v2624.length;
const v2629=v2627.length;
const v2630=new Array(v2628+v2629);
for(let v2631=0;v2631<v2628;v2631++){v2630[v2631]=v2624[v2631];}
for(let v2632=0;v2632<v2629;v2632++){v2630[v2628+v2632]=v2627[v2632];}
const v2633=v2609["decisions"];
const v2634=[v2623];
const v2635=v2633.length;
const v2636=v2634.length;
const v2637=new Array(v2635+v2636);
for(let v2638=0;v2638<v2635;v2638++){v2637[v2638]=v2633[v2638];}
for(let v2639=0;v2639<v2636;v2639++){v2637[v2635+v2639]=v2634[v2639];}
v2622=({Ok:({["choices"]:v2630,["decisions"]:v2637})});}else{
const v2640=v2621["Err"];
v2622=({Err:v2640});}
v2608=v2622;}else{
const v2641=v2604["Err"];
v2608=({Err:v2641});}
return v2608;}
function __fn11(v2642,v2643){
const v2644=(v2642).length;
const v2645=16;
const v2646=!(v2644===v2645);
let v2647=v2646;if(!v2647){
const v2648=(v2643).length;
const v2649=4;
v2647=!(v2648===v2649);}
let v2650;if(v2647){
v2650=({Err:"policy shape"});}else{
const v2651=__fn5(v2642);
const v2652=0;
const v2653=1;
const v2654=2;
const v2655=3;
const v2656=[v2652,v2653,v2654,v2655];
const v2657=[];
const v2658=[];
const v2659=({Ok:({["choices"]:v2657,["decisions"]:v2658})});
let v2660=v2659;
for(let v2661=0;v2661<v2656.length;v2661++){
const v2662=(v2656[v2661]>>>0);
const v2663=v2660;
v2660=__fn10(v2663,v2662,v2651,v2643);
}
const v2664=v2660;
let v2665;if(Object.hasOwn(v2664,"Ok")){
const v2666=v2664["Ok"];
const v2667=[];
let v2668=v2667;
for(let v2669=0;v2669<8;v2669++){
const v2670=(v2669>>>0);
const v2671=v2668;
const v2672=v2666["choices"];
const v2673=v2671.length;
const v2674=v2672.length;
const v2675=new Array(v2673+v2674);
for(let v2676=0;v2676<v2673;v2676++){v2675[v2676]=v2671[v2676];}
for(let v2677=0;v2677<v2674;v2677++){v2675[v2673+v2677]=v2672[v2677];}
v2668=v2675;}
const v2678=v2668;
const v2679=v2666["decisions"];
v2665=({Ok:({["code"]:v2678,["decisions"]:v2679})});}else{
const v2680=v2664["Err"];
v2665=({Err:v2680});}
v2650=v2665;}
return v2650;}
function __fn12(v2681){
const v2682=1065353216;
return __bits((__float(((v2681 ^ 2147483648) >>> 0)))/(__float(__bits(__float(v2682) + __float(v2681)))));}
function __fn13(v2683){
const v2684="Op.Identity";
let v2685;if((v2683===v2684)){
v2685=0;}else{
const v2686="Op.Scale";
let v2687;if((v2683===v2686)){
v2687=1;}else{
const v2688="Op.Bias";
let v2689;if((v2683===v2688)){
v2689=2;}else{
v2689=3;}
v2687=v2689;}
v2685=v2687;}
return v2685;}
function __fn14(v2690,v2691,v2692,v2693){
let v2694;if(Object.hasOwn(v2690,"Ok")){
const v2695=v2690["Ok"];
const v2696=__fn9(v2692,v2691);
const v2697=v2696["masses"];
const v2698=v2696["derivatives"];
const v2699=true;
const v2700=true;
const v2701=true;
const v2702=true;
const v2703=[v2699,v2700,v2701,v2702];
let v2704;if(v2691<v2693.length){v2704=v2693[v2691];}else{
v2704="Op.Identity";}
const v2705=v2704;
const v2706=__fn13(v2705);
const v2707=__fn26(v2697,v2698,v2703,v2706);
let v2708;if(Object.hasOwn(v2707,"Ok")){
const v2709=v2707["Ok"];
const v2710=[v2709];
const v2711=v2695.length;
const v2712=v2710.length;
const v2713=new Array(v2711+v2712);
for(let v2714=0;v2714<v2711;v2714++){v2713[v2714]=v2695[v2714];}
for(let v2715=0;v2715<v2712;v2715++){v2713[v2711+v2715]=v2710[v2715];}
v2708=({Ok:v2713});}else{
const v2716=v2707["Err"];
v2708=({Err:v2716});}
v2694=v2708;}else{
const v2717=v2690["Err"];
v2694=({Err:v2717});}
return v2694;}
function __fn15(v2718,v2719,v2720,v2721,v2722){
const v2723=(v2719).length;
const v2724=32;
let v2725;if((v2723===v2724)){
const v2726=0;
const v2727=1;
const v2728=2;
const v2729=3;
const v2730=[v2726,v2727,v2728,v2729];
const v2731=({Ok:[]});
const v2732=__fn5(v2718);
let v2733=v2731;
for(let v2734=0;v2734<v2730.length;v2734++){
const v2735=(v2730[v2734]>>>0);
const v2736=v2733;
v2733=__fn14(v2736,v2735,v2732,v2719);
}
const v2737=v2733;
let v2738;if(Object.hasOwn(v2737,"Ok")){
const v2739=v2737["Ok"];
const v2740=1065353216;
const v2741=0;
v2738=__fn31(v2739,v2740,v2741);}else{
const v2742=v2737["Err"];
v2738=({Err:v2742});}
v2725=v2738;}else{
const v2743=__fn12(v2721);
const v2744=__fn12(v2722);
v2725=__fn31(v2720,v2743,v2744);}
return v2725;}
function __fn16(v2745){
const v2746=__fn35(v2745);
let v2747=v2746;if(v2747){
const v2748=(v2745["weights"]).length;
const v2749=16;
v2747=(v2748===v2749);}
const v2750=v2747;
let v2751=v2750;if(v2751){
const v2752=v2745["weights"];
let v2753=true;
for(let v2754=0;v2754<v2752.length;v2754++){
const v2755=v2752[v2754];
const v2756=v2753;
let v2757=v2756;if(v2757){
const v2758=1090519040;
const v2759=((v2758 ^ 2147483648) >>> 0);
v2757=((__float(v2755)) >= (__float(v2759)));}
const v2760=v2757;
let v2761=v2760;if(v2761){
const v2762=1090519040;
v2761=((__float(v2755)) <= (__float(v2762)));}
v2753=v2761;
}
v2751=v2753;}
return v2751;}
function __fn17(v2763){
const v2764=v2763.length;
const v2765=new Array(v2764);
for(let v2766=0;v2766<v2764;v2766++){
const v2767=v2763[v2766];
const v2768=__bits(__float(v2767) * __float(v2767));
const v2769=1056964608;
v2765[v2766]=__bits(__float(v2768) + __float(v2769));
}
return v2765;}
function __fn18(v2770){
let v2771=true;
for(let v2772=0;v2772<v2770.length;v2772++){
const v2773=v2770[v2772];
const v2774=v2771;
let v2775=v2774;if(v2775){
v2775=Number.isFinite(__float(v2773));}
v2771=v2775;
}
return v2771;}
function __fn19(v2776,v2777){
const v2778=0;
const v2779=0;
let v2780=({["i"]:v2779,["maximum"]:v2778});
for(let v2781=0;v2781<v2776.length;v2781++){
const v2782=v2776[v2781];
const v2783=v2780;
const v2784=v2783["i"];
const v2785=v2780;
const v2786=v2785["maximum"];
let v2787;if(v2784<v2777.length){v2787=v2777[v2784];}else{
v2787=false;}
const v2788=v2787;
let v2789=v2788;if(v2789){
v2789=((__float(v2782)) > (__float(v2786)));}
let v2790;if(v2789){
const v2791=1;
const v2792=(((v2784) + (v2791)) >>> 0);
v2790=({["i"]:v2792,["maximum"]:v2782});}else{
const v2793=1;
const v2794=(((v2784) + (v2793)) >>> 0);
v2790=({["i"]:v2794,["maximum"]:v2786});}
v2780=v2790;
}
const v2795=v2780;
const v2796=v2795["i"];
const v2797=v2795["maximum"];
return v2797;}
function __fn20(v2798,v2799){
const v2800=(v2798).length;
const v2801=0;
const v2802=(v2800===v2801);
let v2803=v2802;if(!v2803){
const v2804=(v2798).length;
const v2805=256;
v2803=((v2804) > (v2805));}
const v2806=v2803;
let v2807=v2806;if(!v2807){
const v2808=(v2799).length;
const v2809=(v2798).length;
v2807=!(v2808===v2809);}
const v2810=v2807;
let v2811=v2810;if(!v2811){
const v2812=__fn18(v2798);
const v2813=false;
v2811=(v2812===v2813);}
const v2814=v2811;
let v2815=v2814;if(!v2815){
let v2816=true;
for(let v2817=0;v2817<v2798.length;v2817++){
const v2818=v2798[v2817];
const v2819=v2816;
let v2820=v2819;if(v2820){
const v2821=0;
v2820=((__float(v2818)) >= (__float(v2821)));}
v2816=v2820;
}
const v2822=v2816;
const v2823=false;
v2815=(v2822===v2823);}
let v2824;if(v2815){
v2824=({Err:"policy shape or mass domain"});}else{
const v2825=__fn19(v2798,v2799);
const v2826=0;
let v2827;if(((__float(v2825)) === (__float(v2826)))){
v2827=({Err:"no positive allowed policy mass"});}else{
const v2828=new __InkBuffer([]);
const v2829=0;
let v2830=({["i"]:v2829,["out"]:v2828});
for(let v2831=0;v2831<v2798.length;v2831++){
const v2832=v2798[v2831];
const v2833=v2830;
const v2834=v2833["i"];
const v2835=v2830;
const v2836=v2835["out"];
let v2837;if(v2834<v2799.length){v2837=v2799[v2834];}else{
v2837=false;}
let v2838;if(v2837){
v2838=__bits((__float(v2832))/(__float(v2825)));}else{
v2838=0;}
const v2839=v2838;
const v2840=__tempEdit(v2836,"push",v2839);
const v2841=1;
const v2842=(((v2834) + (v2841)) >>> 0);
v2830=({["i"]:v2842,["out"]:v2840});
}
const v2843=v2830;
const v2844=v2843["i"];
const v2845=v2843["out"];
v2827=({Ok:v2845.freeze()});}
v2824=v2827;}
return v2824;}
function __fn21(v2846,v2847){
const v2848=__fn20(v2846,v2847);
let v2849;if(Object.hasOwn(v2848,"Ok")){
const v2850=v2848["Ok"];
let v2851=0;
for(let v2852=0;v2852<v2850.length;v2852++){
const v2853=v2850[v2852];
const v2854=v2851;
v2851=__bits(__float(v2854) + __float(v2853));
}
const v2855=v2851;
const v2856=v2850.length;
const v2857=new Array(v2856);
for(let v2858=0;v2858<v2856;v2858++){
const v2859=v2850[v2858];
v2857[v2858]=__bits((__float(v2859))/(__float(v2855)));
}
v2849=({Ok:v2857});}else{
const v2860=v2848["Err"];
v2849=({Err:v2860});}
return v2849;}
function __fn22(v2861,v2862,v2863){
const v2864=__bits(__float(v2862) * __float(v2863));
const v2865=0;
const v2866=0;
const v2867=false;
const v2868=0;
let v2869=({["accumulated"]:v2865,["found"]:v2867,["i"]:v2868,["selected"]:v2866});
for(let v2870=0;v2870<v2861.length;v2870++){
const v2871=v2861[v2870];
const v2872=v2869;
const v2873=v2872["accumulated"];
const v2874=v2869;
const v2875=v2874["found"];
const v2876=v2869;
const v2877=v2876["i"];
const v2878=v2869;
const v2879=v2878["selected"];
const v2880=0;
const v2881=((__float(v2871)) > (__float(v2880)));
let v2882=v2881;if(v2882){
const v2883=false;
v2882=(v2875===v2883);}
let v2884;if(v2882){
const v2885=__bits(__float(v2873) + __float(v2871));
const v2886=0;
const v2887=((__float(v2871)) > (__float(v2886)));
let v2888=v2887;if(v2888){
const v2889=false;
v2888=(v2875===v2889);}
const v2890=v2888;
let v2891=v2890;if(v2891){
v2891=((__float(v2864)) < (__float(v2885)));}
let v2892;if(v2891){
const v2893=true;
const v2894=1;
const v2895=(((v2877) + (v2894)) >>> 0);
v2892=({["accumulated"]:v2885,["found"]:v2893,["i"]:v2895,["selected"]:v2877});}else{
const v2896=1;
const v2897=(((v2877) + (v2896)) >>> 0);
v2892=({["accumulated"]:v2885,["found"]:v2875,["i"]:v2897,["selected"]:v2877});}
v2884=v2892;}else{
const v2898=__bits(__float(v2873) + __float(v2871));
const v2899=0;
const v2900=((__float(v2871)) > (__float(v2899)));
let v2901=v2900;if(v2901){
const v2902=false;
v2901=(v2875===v2902);}
const v2903=v2901;
let v2904=v2903;if(v2904){
v2904=((__float(v2864)) < (__float(v2898)));}
let v2905;if(v2904){
const v2906=true;
const v2907=1;
const v2908=(((v2877) + (v2907)) >>> 0);
v2905=({["accumulated"]:v2898,["found"]:v2906,["i"]:v2908,["selected"]:v2877});}else{
const v2909=1;
const v2910=(((v2877) + (v2909)) >>> 0);
v2905=({["accumulated"]:v2898,["found"]:v2875,["i"]:v2910,["selected"]:v2879});}
v2884=v2905;}
v2869=v2884;
}
const v2911=v2869;
const v2912=v2911["accumulated"];
const v2913=v2911["found"];
const v2914=v2911["i"];
const v2915=v2911["selected"];
return v2915;}
function __fn23(v2916,v2917,v2918,v2919){
const v2920=0;
let v2921;if(v2920<v2916.length){v2921=v2916[v2920];}else{
v2921=[];}
const v2922=v2921;
const v2923=v2922.length;
const v2924=new Array(v2923);
for(let v2925=0;v2925<v2923;v2925++){
const v2926=v2922[v2925];
v2924[v2925]=0;
}
const v2927=0;
let v2928=({["correction"]:v2924,["i"]:v2927});
for(let v2929=0;v2929<v2916.length;v2929++){
const v2930=v2916[v2929];
const v2931=v2928;
const v2932=v2931["correction"];
const v2933=v2928;
const v2934=v2933["i"];
let v2935;if(v2934<v2917.length){v2935=v2917[v2934];}else{
v2935=false;}
let v2936;if(v2935){
const v2937=Math.min(v2932.length,v2930.length);
const v2938=new Array(v2937);
for(let v2939=0;v2939<v2937;v2939++){
const v2940=v2932[v2939];
const v2941=v2930[v2939];
const v2942=__bits((__float(__bits((__float(v2941))/(__float(v2918)))))/(__float(v2919)));
v2938[v2939]=__bits(__float(v2940) + __float(v2942));
}
const v2943=1;
const v2944=(((v2934) + (v2943)) >>> 0);
v2936=({["correction"]:v2938,["i"]:v2944});}else{
const v2945=1;
const v2946=(((v2934) + (v2945)) >>> 0);
v2936=({["correction"]:v2932,["i"]:v2946});}
v2928=v2936;
}
const v2947=v2928;
const v2948=v2947["correction"];
const v2949=v2947["i"];
return v2948;}
function __fn24(v2950,v2951,v2952,v2953,v2954){
let v2955;if(v2954<v2950.length){v2955=v2950[v2954];}else{
v2955=0;}
const v2956=v2955;
const v2957=__fn19(v2950,v2952);
const v2958=__fn23(v2951,v2952,v2957,v2953);
let v2959;if(v2954<v2951.length){v2959=v2951[v2954];}else{
v2959=[];}
const v2960=v2959;
const v2961=Math.min(v2960.length,v2958.length);
const v2962=new Array(v2961);
for(let v2963=0;v2963<v2961;v2963++){
const v2964=v2960[v2963];
const v2965=v2958[v2963];
const v2966=__bits((__float(v2964))/(__float(v2956)));
v2962[v2963]=__bits(__float(v2966) - __float(v2965));
}
return v2962;}
function __fn25(v2967,v2968,v2969,v2970){
const v2971=__fn20(v2967,v2969);
let v2972;if(Object.hasOwn(v2971,"Ok")){
const v2973=v2971["Ok"];
const v2974=0;
let v2975;if(v2974<v2968.length){v2975=v2968[v2974];}else{
v2975=[];}
const v2976=(v2975).length;
const v2977=Number.isFinite(__float(v2970));
const v2978=false;
const v2979=(v2977===v2978);
let v2980=v2979;if(!v2980){
const v2981=0;
v2980=((__float(v2970)) < (__float(v2981)));}
const v2982=v2980;
let v2983=v2982;if(!v2983){
const v2984=1065353216;
v2983=((__float(v2970)) >= (__float(v2984)));}
const v2985=v2983;
let v2986=v2985;if(!v2986){
const v2987=(v2968).length;
const v2988=(v2967).length;
v2986=!(v2987===v2988);}
const v2989=v2986;
let v2990=v2989;if(!v2990){
const v2991=0;
v2990=(v2976===v2991);}
const v2992=v2990;
let v2993=v2992;if(!v2993){
const v2994=4096;
v2993=((v2976) > (v2994));}
const v2995=v2993;
let v2996=v2995;if(!v2996){
const v2997=(v2967).length;
const v2998=65536;
let v2999;if(v2976===0 ){
v2999=0;}else{
v2999=(Math.trunc(v2998/v2976)+0);}
const v3000=v2999;
v2996=((v2997) > (v3000));}
let v3001;if(v2996){
v3001=({Err:"policy sampling or derivative shape"});}else{
let v3002=true;
for(let v3003=0;v3003<v2968.length;v3003++){
const v3004=v2968[v3003];
const v3005=v3002;
let v3006=v3005;if(v3006){
const v3007=(v3004).length;
v3006=(v3007===v2976);}
const v3008=v3006;
let v3009=v3008;if(v3009){
v3009=__fn18(v3004);}
v3002=v3009;
}
const v3010=v3002;
const v3011=false;
let v3012;if((v3010===v3011)){
v3012=({Err:"policy derivative domain"});}else{
let v3013=0;
for(let v3014=0;v3014<v2973.length;v3014++){
const v3015=v2973[v3014];
const v3016=v3013;
v3013=__bits(__float(v3016) + __float(v3015));
}
const v3017=v3013;
const v3018=__fn22(v2973,v2970,v3017);
const v3019=__fn24(v2967,v2968,v2969,v3017,v3018);
let v3020;if(v3018<v2973.length){v3020=v2973[v3018];}else{
v3020=0;}
const v3021=__bits((__float(v3020))/(__float(v3017)));
const v3022=__fn18(v3019);
const v3023=false;
const v3024=(v3022===v3023);
let v3025=v3024;if(!v3025){
const v3026=0;
v3025=((__float(v3021)) <= (__float(v3026)));}
let v3027;if(v3025){
v3027=({Err:"nonfinite policy score or probability underflow"});}else{
v3027=({Ok:({["action"]:v3018,["probability"]:v3021,["score"]:v3019})});}
v3012=v3027;}
v3001=v3012;}
v2972=v3001;}else{
const v3028=v2971["Err"];
v2972=({Err:v3028});}
return v2972;}
function __fn26(v3029,v3030,v3031,v3032){
const v3033=__fn20(v3029,v3031);
let v3034;if(Object.hasOwn(v3033,"Ok")){
const v3035=v3033["Ok"];
const v3036=0;
let v3037;if(v3036<v3030.length){v3037=v3030[v3036];}else{
v3037=[];}
const v3038=(v3037).length;
const v3039=(v3030).length;
const v3040=(v3029).length;
const v3041=!(v3039===v3040);
let v3042=v3041;if(!v3042){
const v3043=0;
v3042=(v3038===v3043);}
const v3044=v3042;
let v3045=v3044;if(!v3045){
const v3046=4096;
v3045=((v3038) > (v3046));}
const v3047=v3045;
let v3048=v3047;if(!v3048){
const v3049=(v3029).length;
const v3050=65536;
let v3051;if(v3038===0 ){
v3051=0;}else{
v3051=(Math.trunc(v3050/v3038)+0);}
const v3052=v3051;
v3048=((v3049) > (v3052));}
const v3053=v3048;
let v3054=v3053;if(!v3054){
const v3055=(v3029).length;
v3054=((v3032) >= (v3055));}
const v3056=v3054;
let v3057=v3056;if(!v3057){
let v3058;if(v3032<v3031.length){v3058=v3031[v3032];}else{
v3058=false;}
const v3059=v3058;
const v3060=false;
v3057=(v3059===v3060);}
const v3061=v3057;
let v3062=v3061;if(!v3062){
let v3063;if(v3032<v3035.length){v3063=v3035[v3032];}else{
v3063=0;}
const v3064=v3063;
const v3065=0;
v3062=((__float(v3064)) <= (__float(v3065)));}
let v3066;if(v3062){
v3066=({Err:"policy selected action or derivative shape"});}else{
let v3067=true;
for(let v3068=0;v3068<v3030.length;v3068++){
const v3069=v3030[v3068];
const v3070=v3067;
let v3071=v3070;if(v3071){
const v3072=(v3069).length;
v3071=(v3072===v3038);}
const v3073=v3071;
let v3074=v3073;if(v3074){
v3074=__fn18(v3069);}
v3067=v3074;
}
const v3075=v3067;
const v3076=false;
let v3077;if((v3075===v3076)){
v3077=({Err:"policy derivative domain"});}else{
let v3078=0;
for(let v3079=0;v3079<v3035.length;v3079++){
const v3080=v3035[v3079];
const v3081=v3078;
v3078=__bits(__float(v3081) + __float(v3080));
}
const v3082=v3078;
const v3083=__fn24(v3029,v3030,v3031,v3082,v3032);
let v3084;if(v3032<v3035.length){v3084=v3035[v3032];}else{
v3084=0;}
const v3085=__bits((__float(v3084))/(__float(v3082)));
const v3086=__fn18(v3083);
const v3087=false;
const v3088=(v3086===v3087);
let v3089=v3088;if(!v3089){
const v3090=0;
v3089=((__float(v3085)) <= (__float(v3090)));}
let v3091;if(v3089){
v3091=({Err:"nonfinite policy score or probability underflow"});}else{
v3091=({Ok:({["action"]:v3032,["probability"]:v3085,["score"]:v3083})});}
v3077=v3091;}
v3066=v3077;}
v3034=v3066;}else{
const v3092=v3033["Err"];
v3034=({Err:v3092});}
return v3034;}
function __fn27(v3093,v3094,v3095){
const v3096=Number.isFinite(__float(v3094));
const v3097=false;
const v3098=(v3096===v3097);
let v3099=v3098;if(!v3099){
const v3100=Number.isFinite(__float(v3095));
const v3101=false;
v3099=(v3100===v3101);}
const v3102=v3099;
let v3103=v3102;if(!v3103){
const v3104=Number.isFinite(__float(v3093["probability"]));
const v3105=false;
v3103=(v3104===v3105);}
const v3106=v3103;
let v3107=v3106;if(!v3107){
const v3108=v3093["probability"];
const v3109=0;
v3107=((__float(v3108)) <= (__float(v3109)));}
const v3110=v3107;
let v3111=v3110;if(!v3111){
const v3112=v3093["probability"];
const v3113=1065353216;
v3111=((__float(v3112)) > (__float(v3113)));}
const v3114=v3111;
let v3115=v3114;if(!v3115){
const v3116=(v3093["score"]).length;
const v3117=0;
v3115=(v3116===v3117);}
const v3118=v3115;
let v3119=v3118;if(!v3119){
const v3120=(v3093["score"]).length;
const v3121=4096;
v3119=((v3120) > (v3121));}
const v3122=v3119;
let v3123=v3122;if(!v3123){
const v3124=v3093["score"];
const v3125=__fn18(v3124);
const v3126=false;
v3123=(v3125===v3126);}
let v3127;if(v3123){
v3127=({Err:"policy feedback domain"});}else{
const v3128=__bits(__float(v3094) - __float(v3095));
const v3129=v3093["score"];
const v3130=v3129.length;
const v3131=new Array(v3130);
for(let v3132=0;v3132<v3130;v3132++){
const v3133=v3129[v3132];
const v3134=((v3128 ^ 2147483648) >>> 0);
v3131[v3132]=__bits(__float(v3134) * __float(v3133));
}
const v3135=Number.isFinite(__float(v3128));
const v3136=false;
const v3137=(v3135===v3136);
let v3138=v3137;if(!v3138){
const v3139=__fn18(v3131);
const v3140=false;
v3138=(v3139===v3140);}
let v3141;if(v3138){
v3141=({Err:"nonfinite policy gradient"});}else{
v3141=({Ok:v3131});}
v3127=v3141;}
return v3127;}
function __fn28(v3142,v3143,v3144,v3145){
let v3146;if(Object.hasOwn(v3142,"Ok")){
const v3147=v3142["Ok"];
const v3148=__fn27(v3143,v3144,v3145);
let v3149;if(Object.hasOwn(v3148,"Ok")){
const v3150=v3148["Ok"];
const v3151=(v3147).length;
const v3152=(v3150).length;
let v3153;if(!(v3151===v3152)){
v3153=({Err:"trajectory parameter shape"});}else{
const v3154=Math.min(v3147.length,v3150.length);
const v3155=new Array(v3154);
for(let v3156=0;v3156<v3154;v3156++){
const v3157=v3147[v3156];
const v3158=v3150[v3156];
v3155[v3156]=__bits(__float(v3157) + __float(v3158));
}
const v3159=__fn18(v3155);
const v3160=false;
let v3161;if((v3159===v3160)){
v3161=({Err:"nonfinite trajectory gradient"});}else{
v3161=({Ok:v3155});}
v3153=v3161;}
v3149=v3153;}else{
const v3162=v3148["Err"];
v3149=({Err:v3162});}
v3146=v3149;}else{
const v3163=v3142["Err"];
v3146=({Err:v3163});}
return v3146;}
function __fn29(v3164,v3165,v3166){
const v3167=0;
let v3168;if(v3167<v3164.length){v3168=v3164[v3167];}else{
const v3169=0;
const v3170=0;
const v3171=[];
v3168=({["action"]:v3169,["probability"]:v3170,["score"]:v3171});}
const v3172=v3168;
const v3173=(v3172["score"]).length;
const v3174=(v3164).length;
const v3175=0;
const v3176=(v3174===v3175);
let v3177=v3176;if(!v3177){
const v3178=(v3164).length;
const v3179=4096;
v3177=((v3178) > (v3179));}
const v3180=v3177;
let v3181=v3180;if(!v3181){
const v3182=(v3165).length;
const v3183=(v3164).length;
v3181=!(v3182===v3183);}
const v3184=v3181;
let v3185=v3184;if(!v3185){
const v3186=(v3166).length;
const v3187=(v3164).length;
v3185=!(v3186===v3187);}
const v3188=v3185;
let v3189=v3188;if(!v3189){
const v3190=0;
v3189=(v3173===v3190);}
const v3191=v3189;
let v3192=v3191;if(!v3192){
const v3193=4096;
v3192=((v3173) > (v3193));}
const v3194=v3192;
let v3195=v3194;if(!v3195){
const v3196=(v3164).length;
const v3197=65536;
let v3198;if(v3173===0 ){
v3198=0;}else{
v3198=(Math.trunc(v3197/v3173)+0);}
const v3199=v3198;
v3195=((v3196) > (v3199));}
let v3200;if(v3195){
v3200=({Err:"trajectory shape"});}else{
const v3201=v3172["score"];
const v3202=v3201.length;
const v3203=new Array(v3202);
for(let v3204=0;v3204<v3202;v3204++){
const v3205=v3201[v3204];
v3203[v3204]=0;
}
const v3206=({Ok:v3203});
const v3207=0;
let v3208=({["accumulator"]:v3206,["i"]:v3207});
for(let v3209=0;v3209<v3164.length;v3209++){
const v3210=v3164[v3209];
const v3211=v3208;
const v3212=v3211["accumulator"];
const v3213=v3208;
const v3214=v3213["i"];
let v3215;if(v3214<v3165.length){v3215=v3165[v3214];}else{
v3215=0;}
const v3216=v3215;
let v3217;if(v3214<v3166.length){v3217=v3166[v3214];}else{
v3217=0;}
const v3218=v3217;
const v3219=__fn28(v3212,v3210,v3216,v3218);
const v3220=1;
const v3221=(((v3214) + (v3220)) >>> 0);
v3208=({["accumulator"]:v3219,["i"]:v3221});
}
const v3222=v3208;
const v3223=v3222["accumulator"];
const v3224=v3222["i"];
v3200=v3223;}
return v3200;}
function __fn30(v3225,v3226,v3227){
const v3228=__fn29(v3225,v3226,v3227);
let v3229;if(Object.hasOwn(v3228,"Ok")){
const v3230=v3228["Ok"];
const v3231=v3230.length;
const v3232=new Array(v3231);
for(let v3233=0;v3233<v3231;v3233++){
const v3234=v3230[v3233];
v3232[v3233]=__bits((__float(v3234))/(__float(__bits((v3225).length))));
}
v3229=({Ok:v3232});}else{
const v3235=v3228["Err"];
v3229=({Err:v3235});}
return v3229;}
function __fn31(v3236,v3237,v3238){
const v3239=v3236.length;
const v3240=new Array(v3239);
for(let v3241=0;v3241<v3239;v3241++){
const v3242=v3236[v3241];
v3240[v3241]=v3237;
}
const v3243=v3236.length;
const v3244=new Array(v3243);
for(let v3245=0;v3245<v3243;v3245++){
const v3246=v3236[v3245];
v3244[v3245]=v3238;
}
return __fn29(v3236,v3240,v3244);}
function __fn32(v3247,v3248,v3249){
const v3250=(v3247).length;
const v3251=4096;
const v3252=((v3250) > (v3251));
let v3253=v3252;if(!v3253){
const v3254=__fn18(v3247);
const v3255=false;
v3253=(v3254===v3255);}
const v3256=v3253;
let v3257=v3256;if(!v3257){
const v3258=Number.isFinite(__float(v3248));
const v3259=false;
v3257=(v3258===v3259);}
const v3260=v3257;
let v3261=v3260;if(!v3261){
const v3262=0;
v3261=((__float(v3248)) < (__float(v3262)));}
const v3263=v3261;
let v3264=v3263;if(!v3264){
const v3265=1065353216;
v3264=((__float(v3248)) > (__float(v3265)));}
const v3266=v3264;
let v3267=v3266;if(!v3267){
const v3268=Number.isFinite(__float(v3249));
const v3269=false;
v3267=(v3268===v3269);}
let v3270;if(v3267){
v3270=({Err:"return domain"});}else{
const v3271=new __InkBuffer([]);
const v3272=0;
let v3273=({["i"]:v3272,["next"]:v3249,["reversed"]:v3271});
for(let v3274=0;v3274<v3247.length;v3274++){
const v3275=v3247[v3274];
const v3276=v3273;
const v3277=v3276["i"];
const v3278=v3273;
const v3279=v3278["next"];
const v3280=v3273;
const v3281=v3280["reversed"];
const v3282=(v3247).length;
const v3283=1;
const v3284=(((v3282) - (v3283)) >>> 0);
const v3285=(((v3284) - (v3277)) >>> 0);
let v3286;if(v3285<v3247.length){v3286=v3247[v3285];}else{
v3286=0;}
const v3287=v3286;
const v3288=__bits(__float(v3248) * __float(v3279));
const v3289=__bits(__float(v3287) + __float(v3288));
const v3290=__tempEdit(v3281,"push",v3289);
const v3291=1;
const v3292=(((v3277) + (v3291)) >>> 0);
v3273=({["i"]:v3292,["next"]:v3289,["reversed"]:v3290});
}
const v3293=v3273;
const v3294=v3293["i"];
const v3295=v3293["next"];
const v3296=v3293["reversed"];
const v3297=v3296.freeze();
const v3298=__fn18(v3297);
const v3299=false;
let v3300;if((v3298===v3299)){
v3300=({Err:"nonfinite return"});}else{
const v3301=new __InkBuffer([]);
const v3302=0;
let v3303=({["i"]:v3302,["out"]:v3301});
for(let v3304=0;v3304<v3297.length;v3304++){
const v3305=v3297[v3304];
const v3306=v3303;
const v3307=v3306["i"];
const v3308=v3303;
const v3309=v3308["out"];
const v3310=(v3297).length;
const v3311=1;
const v3312=(((v3310) - (v3311)) >>> 0);
const v3313=(((v3312) - (v3307)) >>> 0);
let v3314;if(v3313<v3297.length){v3314=v3297[v3313];}else{
v3314=0;}
const v3315=v3314;
const v3316=__tempEdit(v3309,"push",v3315);
const v3317=1;
const v3318=(((v3307) + (v3317)) >>> 0);
v3303=({["i"]:v3318,["out"]:v3316});
}
const v3319=v3303;
const v3320=v3319["i"];
const v3321=v3319["out"];
v3300=({Ok:v3321.freeze()});}
v3270=v3300;}
return v3270;}
function __fn33(v3322){
const v3323=1063675494;
const v3324=1065336439;
const v3325=841731191;
const v3326=0;
const v3327=1065353216;
return ({["rate"]:v3322,["first_decay"]:v3323,["second_decay"]:v3324,["epsilon"]:v3325,["weight_decay"]:v3326,["norm_limit"]:v3327});}
function __fn34(v3328){
let v3329=true;
for(let v3330=0;v3330<v3328.length;v3330++){
const v3331=v3328[v3330];
const v3332=v3329;
let v3333=v3332;if(v3333){
v3333=Number.isFinite(__float(v3331));}
v3329=v3333;
}
return v3329;}
function __fn35(v3334){
const v3335=(v3334["weights"]).length;
const v3336=(v3334["first"]).length;
const v3337=(v3335===v3336);
let v3338=v3337;if(v3338){
const v3339=(v3334["weights"]).length;
const v3340=(v3334["second"]).length;
v3338=(v3339===v3340);}
const v3341=v3338;
let v3342=v3341;if(v3342){
const v3343=v3334["weights"];
v3342=__fn34(v3343);}
const v3344=v3342;
let v3345=v3344;if(v3345){
const v3346=v3334["first"];
v3345=__fn34(v3346);}
const v3347=v3345;
let v3348=v3347;if(v3348){
const v3349=v3334["second"];
v3348=__fn34(v3349);}
const v3350=v3348;
let v3351=v3350;if(v3351){
const v3352=v3334["second"];
let v3353=true;
for(let v3354=0;v3354<v3352.length;v3354++){
const v3355=v3352[v3354];
const v3356=v3353;
let v3357=v3356;if(v3357){
const v3358=0;
v3357=((__float(v3355)) >= (__float(v3358)));}
v3353=v3357;
}
v3351=v3353;}
const v3359=v3351;
let v3360=v3359;if(v3360){
const v3361=v3334["first_power"];
const v3362=0;
v3360=((__float(v3361)) >= (__float(v3362)));}
const v3363=v3360;
let v3364=v3363;if(v3364){
const v3365=v3334["first_power"];
const v3366=1065353216;
v3364=((__float(v3365)) <= (__float(v3366)));}
const v3367=v3364;
let v3368=v3367;if(v3368){
const v3369=v3334["second_power"];
const v3370=0;
v3368=((__float(v3369)) >= (__float(v3370)));}
const v3371=v3368;
let v3372=v3371;if(v3372){
const v3373=v3334["second_power"];
const v3374=1065353216;
v3372=((__float(v3373)) <= (__float(v3374)));}
return v3372;}
function __fn36(v3375){
const v3376=__fn34(v3375);
const v3377=false;
let v3378;if((v3376===v3377)){
v3378=({Err:"nonfinite weights"});}else{
const v3379=v3375.length;
const v3380=new Array(v3379);
for(let v3381=0;v3381<v3379;v3381++){
const v3382=v3375[v3381];
v3380[v3381]=0;
}
const v3383=0;
const v3384=1065353216;
const v3385=1065353216;
v3378=({Ok:({["weights"]:v3375,["first"]:v3380,["second"]:v3380,["steps"]:v3383,["first_power"]:v3384,["second_power"]:v3385})});}
return v3378;}
function __fn37(v3386){
const v3387=Number.isFinite(__float(v3386["rate"]));
let v3388=v3387;if(v3388){
const v3389=v3386["rate"];
const v3390=0;
v3388=((__float(v3389)) > (__float(v3390)));}
const v3391=v3388;
let v3392=v3391;if(v3392){
const v3393=v3386["first_decay"];
const v3394=0;
v3392=((__float(v3393)) >= (__float(v3394)));}
const v3395=v3392;
let v3396=v3395;if(v3396){
const v3397=v3386["first_decay"];
const v3398=1065353216;
v3396=((__float(v3397)) < (__float(v3398)));}
const v3399=v3396;
let v3400=v3399;if(v3400){
const v3401=v3386["second_decay"];
const v3402=0;
v3400=((__float(v3401)) >= (__float(v3402)));}
const v3403=v3400;
let v3404=v3403;if(v3404){
const v3405=v3386["second_decay"];
const v3406=1065353216;
v3404=((__float(v3405)) < (__float(v3406)));}
const v3407=v3404;
let v3408=v3407;if(v3408){
v3408=Number.isFinite(__float(v3386["epsilon"]));}
const v3409=v3408;
let v3410=v3409;if(v3410){
const v3411=v3386["epsilon"];
const v3412=0;
v3410=((__float(v3411)) > (__float(v3412)));}
const v3413=v3410;
let v3414=v3413;if(v3414){
v3414=Number.isFinite(__float(v3386["weight_decay"]));}
const v3415=v3414;
let v3416=v3415;if(v3416){
const v3417=v3386["weight_decay"];
const v3418=0;
v3416=((__float(v3417)) >= (__float(v3418)));}
const v3419=v3416;
let v3420=v3419;if(v3420){
v3420=Number.isFinite(__float(v3386["norm_limit"]));}
const v3421=v3420;
let v3422=v3421;if(v3422){
const v3423=v3386["norm_limit"];
const v3424=0;
v3422=((__float(v3423)) >= (__float(v3424)));}
return v3422;}
function __fn38(v3425){
const v3426=0;
let v3427;if(((__float(v3425)) < (__float(v3426)))){
v3427=((v3425 ^ 2147483648) >>> 0);}else{
v3427=v3425;}
return v3427;}
function __fn39(v3428,v3429){
const v3430=0;
let v3431;if(((__float(v3429)) === (__float(v3430)))){
v3431=1065353216;}else{
let v3432=0;
for(let v3433=0;v3433<v3428.length;v3433++){
const v3434=v3428[v3433];
const v3435=__fn38(v3434);
const v3436=v3432;
let v3437;if(((__float(v3435)) > (__float(v3436)))){
v3437=__fn38(v3434);}else{
v3437=v3432;}
v3432=v3437;
}
const v3438=v3432;
const v3439=0;
let v3440;if(((__float(v3438)) === (__float(v3439)))){
v3440=1065353216;}else{
let v3441=0;
for(let v3442=0;v3442<v3428.length;v3442++){
const v3443=v3428[v3442];
const v3444=v3441;
const v3445=__bits((__float(v3443))/(__float(v3438)));
const v3446=__bits((__float(v3443))/(__float(v3438)));
const v3447=__bits(__float(v3445) * __float(v3446));
v3441=__bits(__float(v3444) + __float(v3447));
}
const v3448=v3441;
const v3449=__bits((__float(__bits((__float(v3429))/(__float(v3438)))))/(__float(__bits(Math.sqrt(__float(v3448))))));
const v3450=1065353216;
let v3451;if(((__float(v3449)) < (__float(v3450)))){
v3451=v3449;}else{
v3451=1065353216;}
v3440=v3451;}
v3431=v3440;}
return v3431;}
function __fn40(v3452,v3453,v3454,v3455,v3456,v3457){
const v3458=v3457["rate"];
const v3459=1065353216;
const v3460=__bits((__float(v3453))/(__float(__bits(__float(v3459) - __float(v3455)))));
const v3461=1065353216;
const v3462=__bits(Math.sqrt(__float(__bits((__float(v3454))/(__float(__bits(__float(v3461) - __float(v3456))))))));
const v3463=v3457["epsilon"];
const v3464=__bits((__float(__bits(__float(v3458) * __float(v3460))))/(__float(__bits(__float(v3462) + __float(v3463)))));
return __bits(__float(v3452) - __float(v3464));}
function __fn41(v3465,v3466,v3467){
const v3468=__fn35(v3465);
const v3469=false;
const v3470=(v3468===v3469);
let v3471=v3470;if(!v3471){
const v3472=__fn37(v3467);
const v3473=false;
v3471=(v3472===v3473);}
const v3474=v3471;
let v3475=v3474;if(!v3475){
const v3476=(v3466).length;
const v3477=(v3465["weights"]).length;
v3475=!(v3476===v3477);}
const v3478=v3475;
let v3479=v3478;if(!v3479){
const v3480=__fn34(v3466);
const v3481=false;
v3479=(v3480===v3481);}
const v3482=v3479;
let v3483=v3482;if(!v3483){
const v3484=v3465["steps"];
const v3485=4294967295;
v3483=(v3484===v3485);}
let v3486;if(v3483){
v3486=({Err:"optimizer domain"});}else{
const v3487=new __InkBuffer([]);
const v3488=0;
let v3489=({["adjusted"]:v3487,["i"]:v3488});
for(let v3490=0;v3490<v3466.length;v3490++){
const v3491=v3466[v3490];
const v3492=v3489;
const v3493=v3492["adjusted"];
const v3494=v3489;
const v3495=v3494["i"];
const v3496=v3467["weight_decay"];
const v3497=v3465["weights"];
let v3498;if(v3495<v3497.length){v3498=v3497[v3495];}else{
v3498=0;}
const v3499=v3498;
const v3500=__bits(__float(v3496) * __float(v3499));
const v3501=__bits(__float(v3491) + __float(v3500));
const v3502=__tempEdit(v3493,"push",v3501);
const v3503=1;
const v3504=(((v3495) + (v3503)) >>> 0);
v3489=({["adjusted"]:v3502,["i"]:v3504});
}
const v3505=v3489;
const v3506=v3505["adjusted"];
const v3507=v3505["i"];
const v3508=v3506.freeze();
const v3509=__fn34(v3508);
const v3510=false;
let v3511;if((v3509===v3510)){
v3511=({Err:"nonfinite gradient"});}else{
const v3512=v3467["norm_limit"];
const v3513=__fn39(v3508,v3512);
const v3514=v3465["first_power"];
const v3515=v3467["first_decay"];
const v3516=__bits(__float(v3514) * __float(v3515));
const v3517=v3465["second_power"];
const v3518=v3467["second_decay"];
const v3519=__bits(__float(v3517) * __float(v3518));
const v3520=new __InkBuffer([]);
const v3521=new __InkBuffer([]);
const v3522=new __InkBuffer([]);
const v3523=0;
let v3524=({["first"]:v3521,["i"]:v3523,["second"]:v3522,["weights"]:v3520});
for(let v3525=0;v3525<v3508.length;v3525++){
const v3526=v3508[v3525];
const v3527=v3524;
const v3528=v3527["first"];
const v3529=v3524;
const v3530=v3529["i"];
const v3531=v3524;
const v3532=v3531["second"];
const v3533=v3524;
const v3534=v3533["weights"];
const v3535=__bits(__float(v3526) * __float(v3513));
const v3536=v3467["first_decay"];
const v3537=v3465["first"];
let v3538;if(v3530<v3537.length){v3538=v3537[v3530];}else{
v3538=0;}
const v3539=v3538;
const v3540=__bits(__float(v3536) * __float(v3539));
const v3541=1065353216;
const v3542=v3467["first_decay"];
const v3543=__bits(__float(v3541) - __float(v3542));
const v3544=__bits(__float(v3543) * __float(v3535));
const v3545=__bits(__float(v3540) + __float(v3544));
const v3546=v3467["second_decay"];
const v3547=v3465["second"];
let v3548;if(v3530<v3547.length){v3548=v3547[v3530];}else{
v3548=0;}
const v3549=v3548;
const v3550=__bits(__float(v3546) * __float(v3549));
const v3551=1065353216;
const v3552=v3467["second_decay"];
const v3553=__bits(__float(v3551) - __float(v3552));
const v3554=__bits(__float(v3553) * __float(v3535));
const v3555=__bits(__float(v3554) * __float(v3535));
const v3556=__bits(__float(v3550) + __float(v3555));
const v3557=v3465["weights"];
let v3558;if(v3530<v3557.length){v3558=v3557[v3530];}else{
v3558=0;}
const v3559=v3558;
const v3560=__fn40(v3559,v3545,v3556,v3516,v3519,v3467);
const v3561=__tempEdit(v3534,"push",v3560);
const v3562=__tempEdit(v3528,"push",v3545);
const v3563=__tempEdit(v3532,"push",v3556);
const v3564=1;
const v3565=(((v3530) + (v3564)) >>> 0);
v3524=({["first"]:v3562,["i"]:v3565,["second"]:v3563,["weights"]:v3561});
}
const v3566=v3524;
const v3567=v3566["first"];
const v3568=v3566["i"];
const v3569=v3566["second"];
const v3570=v3566["weights"];
const v3571=v3570.freeze();
const v3572=v3567.freeze();
const v3573=v3569.freeze();
const v3574=v3465["steps"];
const v3575=1;
const v3576=(((v3574) + (v3575)) >>> 0);
const v3578=({["weights"]:v3571,["first"]:v3572,["second"]:v3573,["steps"]:v3576,["first_power"]:v3516,["second_power"]:v3519});
const v3579=__fn35(v3578);
const v3580=false;
let v3581;if((v3579===v3580)){
v3581=({Err:"nonfinite optimizer update"});}else{
v3581=({Ok:({["weights"]:v3571,["first"]:v3572,["second"]:v3573,["steps"]:v3576,["first_power"]:v3516,["second_power"]:v3519})});}
v3511=v3581;}
v3486=v3511;}
return v3486;}
function __fn42(v3582,v3583){
const v3584=v3583["slot"];
const v3585=0;
let v3586;if((v3584===v3585)){
v3586=v3582["a"];}else{
const v3587=v3583["slot"];
const v3588=1;
let v3589;if((v3587===v3588)){
v3589=v3582["b"];}else{
const v3590=v3583["slot"];
const v3591=2;
let v3592;if((v3590===v3591)){
v3592=v3582["c"];}else{
v3592=v3582["d"];}
v3589=v3592;}
v3586=v3589;}
const v3593=v3586;
const v3594=v3583["operation"];
const v3595=0;
let v3596;if((v3594===v3595)){
v3596=v3593["identity"];}else{
const v3597=v3583["operation"];
const v3598=1;
let v3599;if((v3597===v3598)){
v3599=v3593["scale"];}else{
const v3600=v3583["operation"];
const v3601=2;
let v3602;if((v3600===v3601)){
v3602=v3593["bias"];}else{
v3602=v3593["relu"];}
v3599=v3602;}
v3596=v3599;}
const v3603=v3596;
const v3604=v3603["value"];
const v3605=v3603["value"];
const v3606=__bits(__float(v3604) * __float(v3605));
const v3607=v3603["tangent_0"];
const v3608=v3603["value"];
const v3609=__bits(__float(v3607) * __float(v3608));
const v3610=v3603["value"];
const v3611=v3603["tangent_0"];
const v3612=__bits(__float(v3610) * __float(v3611));
const v3613=__bits(__float(v3609) + __float(v3612));
const v3614=v3603["tangent_1"];
const v3615=v3603["value"];
const v3616=__bits(__float(v3614) * __float(v3615));
const v3617=v3603["value"];
const v3618=v3603["tangent_1"];
const v3619=__bits(__float(v3617) * __float(v3618));
const v3620=__bits(__float(v3616) + __float(v3619));
const v3621=v3603["tangent_2"];
const v3622=v3603["value"];
const v3623=__bits(__float(v3621) * __float(v3622));
const v3624=v3603["value"];
const v3625=v3603["tangent_2"];
const v3626=__bits(__float(v3624) * __float(v3625));
const v3627=__bits(__float(v3623) + __float(v3626));
const v3628=v3603["tangent_3"];
const v3629=v3603["value"];
const v3630=__bits(__float(v3628) * __float(v3629));
const v3631=v3603["value"];
const v3632=v3603["tangent_3"];
const v3633=__bits(__float(v3631) * __float(v3632));
const v3634=__bits(__float(v3630) + __float(v3633));
const v3635=v3603["tangent_4"];
const v3636=v3603["value"];
const v3637=__bits(__float(v3635) * __float(v3636));
const v3638=v3603["value"];
const v3639=v3603["tangent_4"];
const v3640=__bits(__float(v3638) * __float(v3639));
const v3641=__bits(__float(v3637) + __float(v3640));
const v3642=v3603["tangent_5"];
const v3643=v3603["value"];
const v3644=__bits(__float(v3642) * __float(v3643));
const v3645=v3603["value"];
const v3646=v3603["tangent_5"];
const v3647=__bits(__float(v3645) * __float(v3646));
const v3648=__bits(__float(v3644) + __float(v3647));
const v3649=v3603["tangent_6"];
const v3650=v3603["value"];
const v3651=__bits(__float(v3649) * __float(v3650));
const v3652=v3603["value"];
const v3653=v3603["tangent_6"];
const v3654=__bits(__float(v3652) * __float(v3653));
const v3655=__bits(__float(v3651) + __float(v3654));
const v3656=v3603["tangent_7"];
const v3657=v3603["value"];
const v3658=__bits(__float(v3656) * __float(v3657));
const v3659=v3603["value"];
const v3660=v3603["tangent_7"];
const v3661=__bits(__float(v3659) * __float(v3660));
const v3662=__bits(__float(v3658) + __float(v3661));
const v3663=v3603["tangent_8"];
const v3664=v3603["value"];
const v3665=__bits(__float(v3663) * __float(v3664));
const v3666=v3603["value"];
const v3667=v3603["tangent_8"];
const v3668=__bits(__float(v3666) * __float(v3667));
const v3669=__bits(__float(v3665) + __float(v3668));
const v3670=v3603["tangent_9"];
const v3671=v3603["value"];
const v3672=__bits(__float(v3670) * __float(v3671));
const v3673=v3603["value"];
const v3674=v3603["tangent_9"];
const v3675=__bits(__float(v3673) * __float(v3674));
const v3676=__bits(__float(v3672) + __float(v3675));
const v3677=v3603["tangent_10"];
const v3678=v3603["value"];
const v3679=__bits(__float(v3677) * __float(v3678));
const v3680=v3603["value"];
const v3681=v3603["tangent_10"];
const v3682=__bits(__float(v3680) * __float(v3681));
const v3683=__bits(__float(v3679) + __float(v3682));
const v3684=v3603["tangent_11"];
const v3685=v3603["value"];
const v3686=__bits(__float(v3684) * __float(v3685));
const v3687=v3603["value"];
const v3688=v3603["tangent_11"];
const v3689=__bits(__float(v3687) * __float(v3688));
const v3690=__bits(__float(v3686) + __float(v3689));
const v3691=v3603["tangent_12"];
const v3692=v3603["value"];
const v3693=__bits(__float(v3691) * __float(v3692));
const v3694=v3603["value"];
const v3695=v3603["tangent_12"];
const v3696=__bits(__float(v3694) * __float(v3695));
const v3697=__bits(__float(v3693) + __float(v3696));
const v3698=v3603["tangent_13"];
const v3699=v3603["value"];
const v3700=__bits(__float(v3698) * __float(v3699));
const v3701=v3603["value"];
const v3702=v3603["tangent_13"];
const v3703=__bits(__float(v3701) * __float(v3702));
const v3704=__bits(__float(v3700) + __float(v3703));
const v3705=v3603["tangent_14"];
const v3706=v3603["value"];
const v3707=__bits(__float(v3705) * __float(v3706));
const v3708=v3603["value"];
const v3709=v3603["tangent_14"];
const v3710=__bits(__float(v3708) * __float(v3709));
const v3711=__bits(__float(v3707) + __float(v3710));
const v3712=v3603["tangent_15"];
const v3713=v3603["value"];
const v3714=__bits(__float(v3712) * __float(v3713));
const v3715=v3603["value"];
const v3716=v3603["tangent_15"];
const v3717=__bits(__float(v3715) * __float(v3716));
const v3718=__bits(__float(v3714) + __float(v3717));
const v3720=1036831949;
const v3721=0;
const v3722=0;
const v3723=0;
const v3724=0;
const v3725=0;
const v3726=0;
const v3727=0;
const v3728=0;
const v3729=0;
const v3730=0;
const v3731=0;
const v3732=0;
const v3733=0;
const v3734=0;
const v3735=0;
const v3736=0;
const v3738=__bits(__float(v3606) + __float(v3720));
const v3739=__bits(__float(v3613) + __float(v3721));
const v3740=__bits(__float(v3620) + __float(v3722));
const v3741=__bits(__float(v3627) + __float(v3723));
const v3742=__bits(__float(v3634) + __float(v3724));
const v3743=__bits(__float(v3641) + __float(v3725));
const v3744=__bits(__float(v3648) + __float(v3726));
const v3745=__bits(__float(v3655) + __float(v3727));
const v3746=__bits(__float(v3662) + __float(v3728));
const v3747=__bits(__float(v3669) + __float(v3729));
const v3748=__bits(__float(v3676) + __float(v3730));
const v3749=__bits(__float(v3683) + __float(v3731));
const v3750=__bits(__float(v3690) + __float(v3732));
const v3751=__bits(__float(v3697) + __float(v3733));
const v3752=__bits(__float(v3704) + __float(v3734));
const v3753=__bits(__float(v3711) + __float(v3735));
const v3754=__bits(__float(v3718) + __float(v3736));
return ({["value"]:v3738,["tangent_0"]:v3739,["tangent_1"]:v3740,["tangent_2"]:v3741,["tangent_3"]:v3742,["tangent_4"]:v3743,["tangent_5"]:v3744,["tangent_6"]:v3745,["tangent_7"]:v3746,["tangent_8"]:v3747,["tangent_9"]:v3748,["tangent_10"]:v3749,["tangent_11"]:v3750,["tangent_12"]:v3751,["tangent_13"]:v3752,["tangent_14"]:v3753,["tangent_15"]:v3754});}
function __fn43(v3755,v3756){
const v3757=v3755["a"];
const v3758=v3757["identity"];
const v3759=1065353216;
const v3760=0;
const v3761=0;
const v3762=0;
const v3763=0;
const v3764=0;
const v3765=0;
const v3766=0;
const v3767=0;
const v3768=0;
const v3769=0;
const v3770=0;
const v3771=0;
const v3772=0;
const v3773=0;
const v3774=0;
const v3775=({["value"]:v3758,["tangent_0"]:v3759,["tangent_1"]:v3760,["tangent_2"]:v3761,["tangent_3"]:v3762,["tangent_4"]:v3763,["tangent_5"]:v3764,["tangent_6"]:v3765,["tangent_7"]:v3766,["tangent_8"]:v3767,["tangent_9"]:v3768,["tangent_10"]:v3769,["tangent_11"]:v3770,["tangent_12"]:v3771,["tangent_13"]:v3772,["tangent_14"]:v3773,["tangent_15"]:v3774});
const v3776=v3755["a"];
const v3777=v3776["scale"];
const v3778=0;
const v3779=1065353216;
const v3780=0;
const v3781=0;
const v3782=0;
const v3783=0;
const v3784=0;
const v3785=0;
const v3786=0;
const v3787=0;
const v3788=0;
const v3789=0;
const v3790=0;
const v3791=0;
const v3792=0;
const v3793=0;
const v3794=({["value"]:v3777,["tangent_0"]:v3778,["tangent_1"]:v3779,["tangent_2"]:v3780,["tangent_3"]:v3781,["tangent_4"]:v3782,["tangent_5"]:v3783,["tangent_6"]:v3784,["tangent_7"]:v3785,["tangent_8"]:v3786,["tangent_9"]:v3787,["tangent_10"]:v3788,["tangent_11"]:v3789,["tangent_12"]:v3790,["tangent_13"]:v3791,["tangent_14"]:v3792,["tangent_15"]:v3793});
const v3795=v3755["a"];
const v3796=v3795["bias"];
const v3797=0;
const v3798=0;
const v3799=1065353216;
const v3800=0;
const v3801=0;
const v3802=0;
const v3803=0;
const v3804=0;
const v3805=0;
const v3806=0;
const v3807=0;
const v3808=0;
const v3809=0;
const v3810=0;
const v3811=0;
const v3812=0;
const v3813=({["value"]:v3796,["tangent_0"]:v3797,["tangent_1"]:v3798,["tangent_2"]:v3799,["tangent_3"]:v3800,["tangent_4"]:v3801,["tangent_5"]:v3802,["tangent_6"]:v3803,["tangent_7"]:v3804,["tangent_8"]:v3805,["tangent_9"]:v3806,["tangent_10"]:v3807,["tangent_11"]:v3808,["tangent_12"]:v3809,["tangent_13"]:v3810,["tangent_14"]:v3811,["tangent_15"]:v3812});
const v3814=v3755["a"];
const v3815=v3814["relu"];
const v3816=0;
const v3817=0;
const v3818=0;
const v3819=1065353216;
const v3820=0;
const v3821=0;
const v3822=0;
const v3823=0;
const v3824=0;
const v3825=0;
const v3826=0;
const v3827=0;
const v3828=0;
const v3829=0;
const v3830=0;
const v3831=0;
const v3832=({["value"]:v3815,["tangent_0"]:v3816,["tangent_1"]:v3817,["tangent_2"]:v3818,["tangent_3"]:v3819,["tangent_4"]:v3820,["tangent_5"]:v3821,["tangent_6"]:v3822,["tangent_7"]:v3823,["tangent_8"]:v3824,["tangent_9"]:v3825,["tangent_10"]:v3826,["tangent_11"]:v3827,["tangent_12"]:v3828,["tangent_13"]:v3829,["tangent_14"]:v3830,["tangent_15"]:v3831});
const v3833=({["identity"]:v3775,["scale"]:v3794,["bias"]:v3813,["relu"]:v3832});
const v3834=v3755["b"];
const v3835=v3834["identity"];
const v3836=0;
const v3837=0;
const v3838=0;
const v3839=0;
const v3840=1065353216;
const v3841=0;
const v3842=0;
const v3843=0;
const v3844=0;
const v3845=0;
const v3846=0;
const v3847=0;
const v3848=0;
const v3849=0;
const v3850=0;
const v3851=0;
const v3852=({["value"]:v3835,["tangent_0"]:v3836,["tangent_1"]:v3837,["tangent_2"]:v3838,["tangent_3"]:v3839,["tangent_4"]:v3840,["tangent_5"]:v3841,["tangent_6"]:v3842,["tangent_7"]:v3843,["tangent_8"]:v3844,["tangent_9"]:v3845,["tangent_10"]:v3846,["tangent_11"]:v3847,["tangent_12"]:v3848,["tangent_13"]:v3849,["tangent_14"]:v3850,["tangent_15"]:v3851});
const v3853=v3755["b"];
const v3854=v3853["scale"];
const v3855=0;
const v3856=0;
const v3857=0;
const v3858=0;
const v3859=0;
const v3860=1065353216;
const v3861=0;
const v3862=0;
const v3863=0;
const v3864=0;
const v3865=0;
const v3866=0;
const v3867=0;
const v3868=0;
const v3869=0;
const v3870=0;
const v3871=({["value"]:v3854,["tangent_0"]:v3855,["tangent_1"]:v3856,["tangent_2"]:v3857,["tangent_3"]:v3858,["tangent_4"]:v3859,["tangent_5"]:v3860,["tangent_6"]:v3861,["tangent_7"]:v3862,["tangent_8"]:v3863,["tangent_9"]:v3864,["tangent_10"]:v3865,["tangent_11"]:v3866,["tangent_12"]:v3867,["tangent_13"]:v3868,["tangent_14"]:v3869,["tangent_15"]:v3870});
const v3872=v3755["b"];
const v3873=v3872["bias"];
const v3874=0;
const v3875=0;
const v3876=0;
const v3877=0;
const v3878=0;
const v3879=0;
const v3880=1065353216;
const v3881=0;
const v3882=0;
const v3883=0;
const v3884=0;
const v3885=0;
const v3886=0;
const v3887=0;
const v3888=0;
const v3889=0;
const v3890=({["value"]:v3873,["tangent_0"]:v3874,["tangent_1"]:v3875,["tangent_2"]:v3876,["tangent_3"]:v3877,["tangent_4"]:v3878,["tangent_5"]:v3879,["tangent_6"]:v3880,["tangent_7"]:v3881,["tangent_8"]:v3882,["tangent_9"]:v3883,["tangent_10"]:v3884,["tangent_11"]:v3885,["tangent_12"]:v3886,["tangent_13"]:v3887,["tangent_14"]:v3888,["tangent_15"]:v3889});
const v3891=v3755["b"];
const v3892=v3891["relu"];
const v3893=0;
const v3894=0;
const v3895=0;
const v3896=0;
const v3897=0;
const v3898=0;
const v3899=0;
const v3900=1065353216;
const v3901=0;
const v3902=0;
const v3903=0;
const v3904=0;
const v3905=0;
const v3906=0;
const v3907=0;
const v3908=0;
const v3909=({["value"]:v3892,["tangent_0"]:v3893,["tangent_1"]:v3894,["tangent_2"]:v3895,["tangent_3"]:v3896,["tangent_4"]:v3897,["tangent_5"]:v3898,["tangent_6"]:v3899,["tangent_7"]:v3900,["tangent_8"]:v3901,["tangent_9"]:v3902,["tangent_10"]:v3903,["tangent_11"]:v3904,["tangent_12"]:v3905,["tangent_13"]:v3906,["tangent_14"]:v3907,["tangent_15"]:v3908});
const v3910=({["identity"]:v3852,["scale"]:v3871,["bias"]:v3890,["relu"]:v3909});
const v3911=v3755["c"];
const v3912=v3911["identity"];
const v3913=0;
const v3914=0;
const v3915=0;
const v3916=0;
const v3917=0;
const v3918=0;
const v3919=0;
const v3920=0;
const v3921=1065353216;
const v3922=0;
const v3923=0;
const v3924=0;
const v3925=0;
const v3926=0;
const v3927=0;
const v3928=0;
const v3929=({["value"]:v3912,["tangent_0"]:v3913,["tangent_1"]:v3914,["tangent_2"]:v3915,["tangent_3"]:v3916,["tangent_4"]:v3917,["tangent_5"]:v3918,["tangent_6"]:v3919,["tangent_7"]:v3920,["tangent_8"]:v3921,["tangent_9"]:v3922,["tangent_10"]:v3923,["tangent_11"]:v3924,["tangent_12"]:v3925,["tangent_13"]:v3926,["tangent_14"]:v3927,["tangent_15"]:v3928});
const v3930=v3755["c"];
const v3931=v3930["scale"];
const v3932=0;
const v3933=0;
const v3934=0;
const v3935=0;
const v3936=0;
const v3937=0;
const v3938=0;
const v3939=0;
const v3940=0;
const v3941=1065353216;
const v3942=0;
const v3943=0;
const v3944=0;
const v3945=0;
const v3946=0;
const v3947=0;
const v3948=({["value"]:v3931,["tangent_0"]:v3932,["tangent_1"]:v3933,["tangent_2"]:v3934,["tangent_3"]:v3935,["tangent_4"]:v3936,["tangent_5"]:v3937,["tangent_6"]:v3938,["tangent_7"]:v3939,["tangent_8"]:v3940,["tangent_9"]:v3941,["tangent_10"]:v3942,["tangent_11"]:v3943,["tangent_12"]:v3944,["tangent_13"]:v3945,["tangent_14"]:v3946,["tangent_15"]:v3947});
const v3949=v3755["c"];
const v3950=v3949["bias"];
const v3951=0;
const v3952=0;
const v3953=0;
const v3954=0;
const v3955=0;
const v3956=0;
const v3957=0;
const v3958=0;
const v3959=0;
const v3960=0;
const v3961=1065353216;
const v3962=0;
const v3963=0;
const v3964=0;
const v3965=0;
const v3966=0;
const v3967=({["value"]:v3950,["tangent_0"]:v3951,["tangent_1"]:v3952,["tangent_2"]:v3953,["tangent_3"]:v3954,["tangent_4"]:v3955,["tangent_5"]:v3956,["tangent_6"]:v3957,["tangent_7"]:v3958,["tangent_8"]:v3959,["tangent_9"]:v3960,["tangent_10"]:v3961,["tangent_11"]:v3962,["tangent_12"]:v3963,["tangent_13"]:v3964,["tangent_14"]:v3965,["tangent_15"]:v3966});
const v3968=v3755["c"];
const v3969=v3968["relu"];
const v3970=0;
const v3971=0;
const v3972=0;
const v3973=0;
const v3974=0;
const v3975=0;
const v3976=0;
const v3977=0;
const v3978=0;
const v3979=0;
const v3980=0;
const v3981=1065353216;
const v3982=0;
const v3983=0;
const v3984=0;
const v3985=0;
const v3986=({["value"]:v3969,["tangent_0"]:v3970,["tangent_1"]:v3971,["tangent_2"]:v3972,["tangent_3"]:v3973,["tangent_4"]:v3974,["tangent_5"]:v3975,["tangent_6"]:v3976,["tangent_7"]:v3977,["tangent_8"]:v3978,["tangent_9"]:v3979,["tangent_10"]:v3980,["tangent_11"]:v3981,["tangent_12"]:v3982,["tangent_13"]:v3983,["tangent_14"]:v3984,["tangent_15"]:v3985});
const v3987=({["identity"]:v3929,["scale"]:v3948,["bias"]:v3967,["relu"]:v3986});
const v3988=v3755["d"];
const v3989=v3988["identity"];
const v3990=0;
const v3991=0;
const v3992=0;
const v3993=0;
const v3994=0;
const v3995=0;
const v3996=0;
const v3997=0;
const v3998=0;
const v3999=0;
const v4000=0;
const v4001=0;
const v4002=1065353216;
const v4003=0;
const v4004=0;
const v4005=0;
const v4006=({["value"]:v3989,["tangent_0"]:v3990,["tangent_1"]:v3991,["tangent_2"]:v3992,["tangent_3"]:v3993,["tangent_4"]:v3994,["tangent_5"]:v3995,["tangent_6"]:v3996,["tangent_7"]:v3997,["tangent_8"]:v3998,["tangent_9"]:v3999,["tangent_10"]:v4000,["tangent_11"]:v4001,["tangent_12"]:v4002,["tangent_13"]:v4003,["tangent_14"]:v4004,["tangent_15"]:v4005});
const v4007=v3755["d"];
const v4008=v4007["scale"];
const v4009=0;
const v4010=0;
const v4011=0;
const v4012=0;
const v4013=0;
const v4014=0;
const v4015=0;
const v4016=0;
const v4017=0;
const v4018=0;
const v4019=0;
const v4020=0;
const v4021=0;
const v4022=1065353216;
const v4023=0;
const v4024=0;
const v4025=({["value"]:v4008,["tangent_0"]:v4009,["tangent_1"]:v4010,["tangent_2"]:v4011,["tangent_3"]:v4012,["tangent_4"]:v4013,["tangent_5"]:v4014,["tangent_6"]:v4015,["tangent_7"]:v4016,["tangent_8"]:v4017,["tangent_9"]:v4018,["tangent_10"]:v4019,["tangent_11"]:v4020,["tangent_12"]:v4021,["tangent_13"]:v4022,["tangent_14"]:v4023,["tangent_15"]:v4024});
const v4026=v3755["d"];
const v4027=v4026["bias"];
const v4028=0;
const v4029=0;
const v4030=0;
const v4031=0;
const v4032=0;
const v4033=0;
const v4034=0;
const v4035=0;
const v4036=0;
const v4037=0;
const v4038=0;
const v4039=0;
const v4040=0;
const v4041=0;
const v4042=1065353216;
const v4043=0;
const v4044=({["value"]:v4027,["tangent_0"]:v4028,["tangent_1"]:v4029,["tangent_2"]:v4030,["tangent_3"]:v4031,["tangent_4"]:v4032,["tangent_5"]:v4033,["tangent_6"]:v4034,["tangent_7"]:v4035,["tangent_8"]:v4036,["tangent_9"]:v4037,["tangent_10"]:v4038,["tangent_11"]:v4039,["tangent_12"]:v4040,["tangent_13"]:v4041,["tangent_14"]:v4042,["tangent_15"]:v4043});
const v4045=v3755["d"];
const v4046=v4045["relu"];
const v4047=0;
const v4048=0;
const v4049=0;
const v4050=0;
const v4051=0;
const v4052=0;
const v4053=0;
const v4054=0;
const v4055=0;
const v4056=0;
const v4057=0;
const v4058=0;
const v4059=0;
const v4060=0;
const v4061=0;
const v4062=1065353216;
const v4063=({["value"]:v4046,["tangent_0"]:v4047,["tangent_1"]:v4048,["tangent_2"]:v4049,["tangent_3"]:v4050,["tangent_4"]:v4051,["tangent_5"]:v4052,["tangent_6"]:v4053,["tangent_7"]:v4054,["tangent_8"]:v4055,["tangent_9"]:v4056,["tangent_10"]:v4057,["tangent_11"]:v4058,["tangent_12"]:v4059,["tangent_13"]:v4060,["tangent_14"]:v4061,["tangent_15"]:v4062});
const v4064=({["identity"]:v4006,["scale"]:v4025,["bias"]:v4044,["relu"]:v4063});
const v4066=v3756["slot"];
const v4067=v3756["operation"];
const v4069=0;
let v4070;
let v4071;
let v4072;
let v4073;
if((v4066===v4069)){
v4070=v3833["identity"];
v4071=v3833["scale"];
v4072=v3833["bias"];
v4073=v3833["relu"];
}else{
const v4074=1;
let v4075;
let v4076;
let v4077;
let v4078;
if((v4066===v4074)){
v4075=v3910["identity"];
v4076=v3910["scale"];
v4077=v3910["bias"];
v4078=v3910["relu"];
}else{
const v4079=2;
let v4080;
let v4081;
let v4082;
let v4083;
if((v4066===v4079)){
v4080=v3987["identity"];
v4081=v3987["scale"];
v4082=v3987["bias"];
v4083=v3987["relu"];
}else{
v4080=v4064["identity"];
v4081=v4064["scale"];
v4082=v4064["bias"];
v4083=v4064["relu"];
}
v4075=v4080;
v4076=v4081;
v4077=v4082;
v4078=v4083;
}
v4070=v4075;
v4071=v4076;
v4072=v4077;
v4073=v4078;
}
const v4085=0;
let v4086;
let v4087;
let v4088;
let v4089;
let v4090;
let v4091;
let v4092;
let v4093;
let v4094;
let v4095;
let v4096;
let v4097;
let v4098;
let v4099;
let v4100;
let v4101;
let v4102;
if((v4067===v4085)){
const v4103=v4070;
v4086=v4103["value"];
v4087=v4103["tangent_0"];
v4088=v4103["tangent_1"];
v4089=v4103["tangent_2"];
v4090=v4103["tangent_3"];
v4091=v4103["tangent_4"];
v4092=v4103["tangent_5"];
v4093=v4103["tangent_6"];
v4094=v4103["tangent_7"];
v4095=v4103["tangent_8"];
v4096=v4103["tangent_9"];
v4097=v4103["tangent_10"];
v4098=v4103["tangent_11"];
v4099=v4103["tangent_12"];
v4100=v4103["tangent_13"];
v4101=v4103["tangent_14"];
v4102=v4103["tangent_15"];
}else{
const v4104=1;
let v4105;
let v4106;
let v4107;
let v4108;
let v4109;
let v4110;
let v4111;
let v4112;
let v4113;
let v4114;
let v4115;
let v4116;
let v4117;
let v4118;
let v4119;
let v4120;
let v4121;
if((v4067===v4104)){
const v4122=v4071;
v4105=v4122["value"];
v4106=v4122["tangent_0"];
v4107=v4122["tangent_1"];
v4108=v4122["tangent_2"];
v4109=v4122["tangent_3"];
v4110=v4122["tangent_4"];
v4111=v4122["tangent_5"];
v4112=v4122["tangent_6"];
v4113=v4122["tangent_7"];
v4114=v4122["tangent_8"];
v4115=v4122["tangent_9"];
v4116=v4122["tangent_10"];
v4117=v4122["tangent_11"];
v4118=v4122["tangent_12"];
v4119=v4122["tangent_13"];
v4120=v4122["tangent_14"];
v4121=v4122["tangent_15"];
}else{
const v4123=2;
let v4124;
let v4125;
let v4126;
let v4127;
let v4128;
let v4129;
let v4130;
let v4131;
let v4132;
let v4133;
let v4134;
let v4135;
let v4136;
let v4137;
let v4138;
let v4139;
let v4140;
if((v4067===v4123)){
const v4141=v4072;
v4124=v4141["value"];
v4125=v4141["tangent_0"];
v4126=v4141["tangent_1"];
v4127=v4141["tangent_2"];
v4128=v4141["tangent_3"];
v4129=v4141["tangent_4"];
v4130=v4141["tangent_5"];
v4131=v4141["tangent_6"];
v4132=v4141["tangent_7"];
v4133=v4141["tangent_8"];
v4134=v4141["tangent_9"];
v4135=v4141["tangent_10"];
v4136=v4141["tangent_11"];
v4137=v4141["tangent_12"];
v4138=v4141["tangent_13"];
v4139=v4141["tangent_14"];
v4140=v4141["tangent_15"];
}else{
const v4142=v4073;
v4124=v4142["value"];
v4125=v4142["tangent_0"];
v4126=v4142["tangent_1"];
v4127=v4142["tangent_2"];
v4128=v4142["tangent_3"];
v4129=v4142["tangent_4"];
v4130=v4142["tangent_5"];
v4131=v4142["tangent_6"];
v4132=v4142["tangent_7"];
v4133=v4142["tangent_8"];
v4134=v4142["tangent_9"];
v4135=v4142["tangent_10"];
v4136=v4142["tangent_11"];
v4137=v4142["tangent_12"];
v4138=v4142["tangent_13"];
v4139=v4142["tangent_14"];
v4140=v4142["tangent_15"];
}
v4105=v4124;
v4106=v4125;
v4107=v4126;
v4108=v4127;
v4109=v4128;
v4110=v4129;
v4111=v4130;
v4112=v4131;
v4113=v4132;
v4114=v4133;
v4115=v4134;
v4116=v4135;
v4117=v4136;
v4118=v4137;
v4119=v4138;
v4120=v4139;
v4121=v4140;
}
v4086=v4105;
v4087=v4106;
v4088=v4107;
v4089=v4108;
v4090=v4109;
v4091=v4110;
v4092=v4111;
v4093=v4112;
v4094=v4113;
v4095=v4114;
v4096=v4115;
v4097=v4116;
v4098=v4117;
v4099=v4118;
v4100=v4119;
v4101=v4120;
v4102=v4121;
}
const v4144=v4086;
const v4145=v4086;
const v4146=__bits(__float(v4144) * __float(v4145));
const v4147=v4087;
const v4148=v4086;
const v4149=__bits(__float(v4147) * __float(v4148));
const v4150=v4086;
const v4151=v4087;
const v4152=__bits(__float(v4150) * __float(v4151));
const v4153=__bits(__float(v4149) + __float(v4152));
const v4154=v4088;
const v4155=v4086;
const v4156=__bits(__float(v4154) * __float(v4155));
const v4157=v4086;
const v4158=v4088;
const v4159=__bits(__float(v4157) * __float(v4158));
const v4160=__bits(__float(v4156) + __float(v4159));
const v4161=v4089;
const v4162=v4086;
const v4163=__bits(__float(v4161) * __float(v4162));
const v4164=v4086;
const v4165=v4089;
const v4166=__bits(__float(v4164) * __float(v4165));
const v4167=__bits(__float(v4163) + __float(v4166));
const v4168=v4090;
const v4169=v4086;
const v4170=__bits(__float(v4168) * __float(v4169));
const v4171=v4086;
const v4172=v4090;
const v4173=__bits(__float(v4171) * __float(v4172));
const v4174=__bits(__float(v4170) + __float(v4173));
const v4175=v4091;
const v4176=v4086;
const v4177=__bits(__float(v4175) * __float(v4176));
const v4178=v4086;
const v4179=v4091;
const v4180=__bits(__float(v4178) * __float(v4179));
const v4181=__bits(__float(v4177) + __float(v4180));
const v4182=v4092;
const v4183=v4086;
const v4184=__bits(__float(v4182) * __float(v4183));
const v4185=v4086;
const v4186=v4092;
const v4187=__bits(__float(v4185) * __float(v4186));
const v4188=__bits(__float(v4184) + __float(v4187));
const v4189=v4093;
const v4190=v4086;
const v4191=__bits(__float(v4189) * __float(v4190));
const v4192=v4086;
const v4193=v4093;
const v4194=__bits(__float(v4192) * __float(v4193));
const v4195=__bits(__float(v4191) + __float(v4194));
const v4196=v4094;
const v4197=v4086;
const v4198=__bits(__float(v4196) * __float(v4197));
const v4199=v4086;
const v4200=v4094;
const v4201=__bits(__float(v4199) * __float(v4200));
const v4202=__bits(__float(v4198) + __float(v4201));
const v4203=v4095;
const v4204=v4086;
const v4205=__bits(__float(v4203) * __float(v4204));
const v4206=v4086;
const v4207=v4095;
const v4208=__bits(__float(v4206) * __float(v4207));
const v4209=__bits(__float(v4205) + __float(v4208));
const v4210=v4096;
const v4211=v4086;
const v4212=__bits(__float(v4210) * __float(v4211));
const v4213=v4086;
const v4214=v4096;
const v4215=__bits(__float(v4213) * __float(v4214));
const v4216=__bits(__float(v4212) + __float(v4215));
const v4217=v4097;
const v4218=v4086;
const v4219=__bits(__float(v4217) * __float(v4218));
const v4220=v4086;
const v4221=v4097;
const v4222=__bits(__float(v4220) * __float(v4221));
const v4223=__bits(__float(v4219) + __float(v4222));
const v4224=v4098;
const v4225=v4086;
const v4226=__bits(__float(v4224) * __float(v4225));
const v4227=v4086;
const v4228=v4098;
const v4229=__bits(__float(v4227) * __float(v4228));
const v4230=__bits(__float(v4226) + __float(v4229));
const v4231=v4099;
const v4232=v4086;
const v4233=__bits(__float(v4231) * __float(v4232));
const v4234=v4086;
const v4235=v4099;
const v4236=__bits(__float(v4234) * __float(v4235));
const v4237=__bits(__float(v4233) + __float(v4236));
const v4238=v4100;
const v4239=v4086;
const v4240=__bits(__float(v4238) * __float(v4239));
const v4241=v4086;
const v4242=v4100;
const v4243=__bits(__float(v4241) * __float(v4242));
const v4244=__bits(__float(v4240) + __float(v4243));
const v4245=v4101;
const v4246=v4086;
const v4247=__bits(__float(v4245) * __float(v4246));
const v4248=v4086;
const v4249=v4101;
const v4250=__bits(__float(v4248) * __float(v4249));
const v4251=__bits(__float(v4247) + __float(v4250));
const v4252=v4102;
const v4253=v4086;
const v4254=__bits(__float(v4252) * __float(v4253));
const v4255=v4086;
const v4256=v4102;
const v4257=__bits(__float(v4255) * __float(v4256));
const v4258=__bits(__float(v4254) + __float(v4257));
const v4260=1036831949;
const v4261=0;
const v4262=0;
const v4263=0;
const v4264=0;
const v4265=0;
const v4266=0;
const v4267=0;
const v4268=0;
const v4269=0;
const v4270=0;
const v4271=0;
const v4272=0;
const v4273=0;
const v4274=0;
const v4275=0;
const v4276=0;
const v4278=__bits(__float(v4146) + __float(v4260));
const v4279=__bits(__float(v4153) + __float(v4261));
const v4280=__bits(__float(v4160) + __float(v4262));
const v4281=__bits(__float(v4167) + __float(v4263));
const v4282=__bits(__float(v4174) + __float(v4264));
const v4283=__bits(__float(v4181) + __float(v4265));
const v4284=__bits(__float(v4188) + __float(v4266));
const v4285=__bits(__float(v4195) + __float(v4267));
const v4286=__bits(__float(v4202) + __float(v4268));
const v4287=__bits(__float(v4209) + __float(v4269));
const v4288=__bits(__float(v4216) + __float(v4270));
const v4289=__bits(__float(v4223) + __float(v4271));
const v4290=__bits(__float(v4230) + __float(v4272));
const v4291=__bits(__float(v4237) + __float(v4273));
const v4292=__bits(__float(v4244) + __float(v4274));
const v4293=__bits(__float(v4251) + __float(v4275));
const v4294=__bits(__float(v4258) + __float(v4276));
const v4296=({["identity"]:v4279,["scale"]:v4280,["bias"]:v4281,["relu"]:v4282});
const v4297=({["identity"]:v4283,["scale"]:v4284,["bias"]:v4285,["relu"]:v4286});
const v4298=({["identity"]:v4287,["scale"]:v4288,["bias"]:v4289,["relu"]:v4290});
const v4299=({["identity"]:v4291,["scale"]:v4292,["bias"]:v4293,["relu"]:v4294});
return ({["a"]:v4296,["b"]:v4297,["c"]:v4298,["d"]:v4299});}
function __fn44(v4300,v4301){
const v4302=v4300["bias"];
const v4303=__bits(__float(v4301) + __float(v4302));
const v4304=v4300["scale"];
const v4305=__bits(__float(v4303) * __float(v4304));
const v4306=0;
let v4307;if(((__float(v4305)) > (__float(v4306)))){
v4307=v4305;}else{
v4307=0;}
const v4308=v4307;
const v4309=v4300["bias"];
const v4310=__bits(__float(v4308) + __float(v4309));
const v4311=v4300["scale"];
const v4312=__bits(__float(v4310) * __float(v4311));
const v4313=0;
let v4314;if(((__float(v4312)) > (__float(v4313)))){
v4314=v4312;}else{
v4314=0;}
const v4315=v4314;
return v4315;}
function __fn45(v4316,v4317){
const v4318=__fn44(v4316,v4317);
return __fn44(v4316,v4318);}
function __fn46(v4319,v4320){
const v4321=__fn45(v4319,v4320);
return __fn45(v4319,v4321);}
function __fn47(v4322){
const v4323=1065353216;
const v4324=__bits(__float(v4322) + __float(v4323));
const v4325=1065353216;
const v4326=__bits(__float(v4324) + __float(v4325));
const v4327=0;
const v4328=__bits(__float(v4326) + __float(v4327));
const v4329=1065353216;
const v4330=__bits(__float(v4328) + __float(v4329));
const v4331=1065353216;
const v4332=__bits(__float(v4330) + __float(v4331));
const v4333=1065353216;
const v4334=__bits(__float(v4332) + __float(v4333));
const v4335=0;
const v4336=__bits(__float(v4334) + __float(v4335));
const v4337=1065353216;
const v4338=__bits(__float(v4336) + __float(v4337));
return v4338;}
function __fn48(v4339){
const v4340=__fn47(v4339);
return __fn47(v4340);}
function __fn49(v4341){
const v4342=__fn48(v4341);
return __fn48(v4342);}
function __fn50(v4343,v4344){
const v4345=v4344["samples"];
let v4346=0;
for(let v4347=0;v4347<v4345.length;v4347++){
const v4348=v4345[v4347];
const v4349=v4346;
const v4350=v4348["input"];
const v4351=__fn46(v4343,v4350);
const v4352=v4348["target"];
const v4353=__bits(__float(v4351) - __float(v4352));
const v4354=__bits(__float(v4353) * __float(v4353));
v4346=__bits(__float(v4349) + __float(v4354));
}
const v4355=v4346;
const v4356=__bits((__float(v4355))/(__float(__bits((v4344["samples"]).length))));
const v4357=v4344["instruction_cost"];
const v4358=1103101952;
const v4359=__bits(__float(v4357) * __float(v4358));
return __bits(__float(v4356) + __float(v4359));}
function __into6(v4360,v4361){
const v4362=v4360["a"];
const v4363=v4362["identity"];
const v4364=v4360["a"];
const v4365=v4364["scale"];
const v4366=v4360["a"];
const v4367=v4366["bias"];
const v4368=v4360["a"];
const v4369=v4368["relu"];
const v4370=v4360["b"];
const v4371=v4370["identity"];
const v4372=v4360["b"];
const v4373=v4372["scale"];
const v4374=v4360["b"];
const v4375=v4374["bias"];
const v4376=v4360["b"];
const v4377=v4376["relu"];
const v4378=v4360["c"];
const v4379=v4378["identity"];
const v4380=v4360["c"];
const v4381=v4380["scale"];
const v4382=v4360["c"];
const v4383=v4382["bias"];
const v4384=v4360["c"];
const v4385=v4384["relu"];
const v4386=v4360["d"];
const v4387=v4386["identity"];
const v4388=v4360["d"];
const v4389=v4388["scale"];
const v4390=v4360["d"];
const v4391=v4390["bias"];
const v4392=v4360["d"];
const v4393=v4392["relu"];
const v4394=[v4363,v4365,v4367,v4369,v4371,v4373,v4375,v4377,v4379,v4381,v4383,v4385,v4387,v4389,v4391,v4393];
const v4395=v4394.length;
for(let v4396=0;v4396<v4395;v4396++){
v4361[v4396]=__intoOutput6(v4394[v4396]);
}
return v4395;}
function __into17(v4397,v4398){
const v4399=v4397.length;
for(let v4401=0;v4401<v4399;v4401++){
const v4402=v4397[v4401];
const v4403=__bits(__float(v4402) * __float(v4402));
const v4404=1056964608;
v4398[v4401]=__intoOutput17(__bits(__float(v4403) + __float(v4404)));
}
return v4399;}
function __into23(v4405,v4406,v4407,v4408,v4409){
const v4410=0;
let v4411;if(v4410<v4405.length){v4411=v4405[v4410];}else{
v4411=[];}
const v4412=v4411;
const v4413=v4412.length;
const v4414=new Array(v4413);
for(let v4415=0;v4415<v4413;v4415++){
const v4416=v4412[v4415];
v4414[v4415]=0;
}
const v4417=0;
let v4418=({["correction"]:v4414,["i"]:v4417});
for(let v4419=0;v4419<v4405.length;v4419++){
const v4420=v4405[v4419];
const v4421=v4418;
const v4422=v4421["correction"];
const v4423=v4418;
const v4424=v4423["i"];
let v4425;if(v4424<v4406.length){v4425=v4406[v4424];}else{
v4425=false;}
let v4426;if(v4425){
const v4427=Math.min(v4422.length,v4420.length);
const v4428=new Array(v4427);
for(let v4429=0;v4429<v4427;v4429++){
const v4430=v4422[v4429];
const v4431=v4420[v4429];
const v4432=__bits((__float(__bits((__float(v4431))/(__float(v4407)))))/(__float(v4408)));
v4428[v4429]=__bits(__float(v4430) + __float(v4432));
}
const v4433=1;
const v4434=(((v4424) + (v4433)) >>> 0);
v4426=({["correction"]:v4428,["i"]:v4434});}else{
const v4435=1;
const v4436=(((v4424) + (v4435)) >>> 0);
v4426=({["correction"]:v4422,["i"]:v4436});}
v4418=v4426;
}
const v4437=v4418;
const v4438=v4437["correction"];
const v4439=v4437["i"];
const v4440=v4438.length;
for(let v4441=0;v4441<v4440;v4441++){
v4409[v4441]=__intoOutput23(v4438[v4441]);
}
return v4440;}
function __into24(v4442,v4443,v4444,v4445,v4446,v4447){
let v4448;if(v4446<v4442.length){v4448=v4442[v4446];}else{
v4448=0;}
const v4449=v4448;
const v4450=__fn19(v4442,v4444);
const v4451=__fn23(v4443,v4444,v4450,v4445);
let v4452;if(v4446<v4443.length){v4452=v4443[v4446];}else{
v4452=[];}
const v4453=v4452;
const v4454=Math.min(v4453.length,v4451.length);
for(let v4456=0;v4456<v4454;v4456++){
const v4457=v4453[v4456];
const v4458=v4451[v4456];
const v4459=__bits((__float(v4457))/(__float(v4449)));
v4447[v4456]=__intoOutput24(__bits(__float(v4459) - __float(v4458)));
}
return v4454;}
const __namedTypes={"Building":{"fields":[{"name":"choices","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}],"kind":"record","name":"Building"},"Coefficients":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"},"Distribution":{"fields":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"derivatives","type":{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"}}],"kind":"record","name":"Distribution"},"Example":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"Goal":{"fields":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}},{"name":"version","type":{"kind":"u32"}}],"kind":"record","name":"Goal"},"MassRow":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"},"Parameters":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"},"Pick":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"Pick"},"Report":{"fields":[{"name":"step","type":{"kind":"u32"}},{"name":"loss","type":{"kind":"f32"}},{"name":"best","type":{"kind":"f32"}},{"name":"accepted","type":{"kind":"bool"}},{"name":"goal_version","type":{"kind":"u32"}}],"kind":"record","name":"Report"},"Sampled":{"fields":[{"name":"code","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}],"kind":"record","name":"Sampled"},"__ink_differential_0":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"__ink_differential_2":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"},"__ink_differential_4":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"},"__ink_differential_5":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"},"__ink_differential_6":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_6"},"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_17":{"fields":[{"name":"i","type":{"kind":"u32"}},{"name":"out","type":{"kind":"temporary"}}],"kind":"record","name":"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_17"},"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_36":{"fields":[{"name":"accumulated","type":{"kind":"f32"}},{"name":"found","type":{"kind":"bool"}},{"name":"i","type":{"kind":"u32"}},{"name":"selected","type":{"kind":"u32"}}],"kind":"record","name":"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_36"},"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_5":{"fields":[{"name":"i","type":{"kind":"u32"}},{"name":"maximum","type":{"kind":"f32"}}],"kind":"record","name":"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_5"},"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_52":{"fields":[{"name":"correction","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"i","type":{"kind":"u32"}}],"kind":"record","name":"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_52"},"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_72":{"fields":[{"name":"accumulator","type":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"name":"i","type":{"kind":"u32"}}],"kind":"record","name":"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_72"},"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_87":{"fields":[{"name":"i","type":{"kind":"u32"}},{"name":"next","type":{"kind":"f32"}},{"name":"reversed","type":{"kind":"temporary"}}],"kind":"record","name":"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_87"},"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_99":{"fields":[{"name":"i","type":{"kind":"u32"}},{"name":"out","type":{"kind":"temporary"}}],"kind":"record","name":"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_99"},"__ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_24":{"fields":[{"name":"first","type":{"kind":"temporary"}},{"name":"i","type":{"kind":"u32"}},{"name":"second","type":{"kind":"temporary"}},{"name":"weights","type":{"kind":"temporary"}}],"kind":"record","name":"__ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_24"},"__ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_5":{"fields":[{"name":"adjusted","type":{"kind":"temporary"}},{"name":"i","type":{"kind":"u32"}}],"kind":"record","name":"__ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_5"},"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}},{"name":"weight_decay","type":{"kind":"f32"}},{"name":"norm_limit","type":{"kind":"f32"}}],"kind":"record","name":"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249"},"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}};
// Portable snapshot ABI shared with native/Wasm. Hashing uses Web Crypto.
function __snapshotLimits(limits={}){
 const result={bytes:64*1024*1024,values:1000000,depth:128,...limits};
 for(const k of ['bytes','values','depth'])if(!Number.isSafeInteger(result[k])||result[k]<0||result[k]>(k==='depth'?128:k==='values'?1000000:64*1024*1024))throw Error('invalid snapshot limits');
 return result;
}
const __hash=async bytes=>new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256',bytes));
function __snapshotWriter(limits){
 const out=[];let left=limits.values,maxDepth=0;
 function bytes(xs){if(xs.length>limits.bytes-out.length)throw Error('snapshot byte limit exceeded');for(const x of xs)out.push(x);}
 function integer(n,size){n=BigInt(n);for(let i=0;i<size;i++){bytes([Number(n&255n)]);n>>=8n;}}
 function raw(xs){integer(xs.length,8);bytes(xs);}
 function value(v,t,depth=0,bindings=[]){maxDepth=Math.max(maxDepth,depth);if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{value(v,t.body,depth+1,bindings);}finally{bindings.pop();}break;
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');value(v,bound[1],depth+1,bindings);break;}
  case 'unit':break;case 'bool':bytes([v?1:0]);break;
  case 'u32':case 'i32':case 'f32':integer(v,4);break;case 'u64':integer(v,8);break;
  case 'f64':integer(__dfBits(v),8);break;
  case 'vector':if(v.length!==t.size)throw Error('vector dimension mismatch');for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'int':{let n=v<0n?-v:v;const xs=[];while(n){if(xs.length>=4096)throw Error('snapshot Int exceeds size limit');xs.push(Number(n&255n));n>>=8n;}bytes([v===0n?0:v>0n?1:2]);raw(xs);break;}
  case 'string':raw(__encoder.encode(v));break;
  case 'id':integer(BigInt('0x'+v),16);break;
  case 'enum':integer(t.variants.indexOf(v),4);break;
  case 'record':for(const f of t.fields)value(t.elided?v:v[f.name],f.type,depth+1,bindings);break;
  case 'list':if(v.length>left)throw Error('snapshot value limit exceeded');integer(v.length,8);for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'option':if(Object.hasOwn(v,'Some')){bytes([1]);value(v.Some,t.element,depth+1,bindings);}else bytes([0]);break;
  case 'result':{const branch=t.sum_key?__sumView(t.sum_key,v):v;if(Object.hasOwn(branch,'Ok')){bytes([0]);value(branch.Ok,t.ok,depth+1,bindings);}else{bytes([1]);value(branch.Err,t.error,depth+1,bindings);}break;}
  default:throw Error('unsupported snapshot type');
 }}
 return {bytes,integer,raw,value,charge(cells,depth){left-=cells;if(left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');},get maxDepth(){return maxDepth;},get left(){return left;},finish:()=>new Uint8Array(out)};
}
async function __snapshotEncode(meta,state,options){
 const limits=__snapshotLimits(options),w=__snapshotWriter(limits);
 w.integer(state.version,8);
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const rows=[...state.tables[r.index].entries()].sort((a,b)=>__keyCompare(a[0],b[0],r.key));if(rows.length>Math.floor(w.left/2))throw Error('snapshot row limit exceeded');w.integer(rows.length,8);for(const [k,v]of rows){
  if(!meta.snapshotRows){w.value(k,r.snapshotKey??r.key);w.value(v,r.snapshotValue??r.value);continue;}
  const cache=state.snapshotRows[r.index];let packed=cache.get(k);
  if(!packed){const row=__snapshotWriter(limits);row.value(k,r.snapshotKey??r.key);row.value(v,r.snapshotValue??r.value);packed={bytes:row.finish(),cells:limits.values-row.left,depth:row.maxDepth};cache.set(k,packed);}
  w.charge(packed.cells,packed.depth);w.bytes(packed.bytes);
 }}
 w.integer(state.outbox.length,8);
 for(const e of state.outbox){const channel=meta.events.findIndex(t=>t.name===e.channel);w.integer(e.commit,8);w.integer(e.position,8);w.integer(channel,4);w.value(e.value,meta.events[channel].snapshotType??meta.events[channel].type);}
 const payload=w.finish(),header=__snapshotWriter(limits);header.bytes([86,76,83,84,65,84,69,0,1,0,1,0]);header.bytes(meta.snapshot.program);header.bytes(meta.snapshot.schema);header.integer(payload.length,8);header.bytes(payload);
 const bytes=header.finish();if(bytes.length+32>limits.bytes)throw Error('snapshot byte limit exceeded');const digest=await __hash(bytes);const result=new Uint8Array(bytes.length+32);result.set(bytes);result.set(digest,bytes.length);return result;
}
async function __snapshotDecode(meta,input,options){
 const limits=__snapshotLimits(options);
 if(!(input instanceof Uint8Array)&&!Array.isArray(input))throw Error('expected snapshot bytes');
 if(input.length>limits.bytes||input.length<116)throw Error('snapshot byte length invalid');
 if(Array.isArray(input)&&input.some(b=>!Number.isInteger(b)||b<0||b>255))throw Error('invalid snapshot bytes');
 const bytes=new Uint8Array(input); // capture before asynchronous integrity work
 function same(a,b){return a.length===b.length&&a.every((v,i)=>v===b[i]);}
 if(!same(bytes.subarray(0,12),[86,76,83,84,65,84,69,0,1,0,1,0]))throw Error('snapshot format or semantics version mismatch');
 if(!same(bytes.subarray(12,44),meta.snapshot.program)||!same(bytes.subarray(44,76),meta.snapshot.schema))throw Error('snapshot program or schema identity mismatch');
 const end=bytes.length-32,digest=await __hash(bytes.subarray(0,end));if(!same(digest,bytes.subarray(end)))throw Error('snapshot integrity check failed');
 let at=76,left=limits.values;
 function take(n){if(!Number.isSafeInteger(n)||n<0||n>end-at)throw Error('truncated snapshot');const x=bytes.subarray(at,at+n);at+=n;return x;}
 function integer(size){const xs=take(size);let n=0n;for(let i=size-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return n;}
 function length(){const n=integer(8);if(n>BigInt(Number.MAX_SAFE_INTEGER))throw Error('snapshot length not addressable');return Number(n);}
 function sequence(){const n=length();if(n>left)throw Error('snapshot value limit exceeded');return n;}
 function raw(){return take(length());}
 const n=length();if(n!==end-84)throw Error('snapshot payload length mismatch');
 function value(t,depth=0,bindings=[]){if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{return value(t.body,depth+1,bindings);}finally{bindings.pop();}
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');return value(bound[1],depth+1,bindings);}
  case 'unit':return null;case 'bool':{const b=take(1)[0];if(b>1)throw Error('invalid Bool tag');return b===1;}
  case 'u32':case 'f32':return Number(integer(4));case 'i32':return Number(BigInt.asIntN(32,integer(4)));case 'u64':return integer(8);
  case 'f64':return __dfFromBits(integer(8));
  case 'vector':{const xs=[];for(let i=0;i<t.size;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'int':{const sign=take(1)[0],xs=raw();if(xs.length>4096)throw Error('snapshot Int exceeds size limit');if(!((sign===0&&xs.length===0)||((sign===1||sign===2)&&xs.length>0&&xs[xs.length-1]!==0)))throw Error('noncanonical signed integer');let n=0n;for(let i=xs.length-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return sign===2?-n:n;}
  case 'string':return new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(raw());
  case 'id':return integer(16).toString(16).padStart(32,'0');
  case 'enum':{const i=Number(integer(4));if(i>=t.variants.length)throw Error('invalid enum tag');return t.variants[i];}
  case 'record':if(t.elided)return value(t.fields[0].type,depth+1,bindings);return Object.fromEntries(t.fields.map(f=>[f.name,value(f.type,depth+1,bindings)]));
  case 'list':{const n=sequence(),xs=[];for(let i=0;i<n;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'option':{const tag=take(1)[0];if(tag===0)return {None:null};if(tag===1)return {Some:value(t.element,depth+1,bindings)};throw Error('invalid Option tag');}
  case 'result':{const tag=take(1)[0];if(tag===0){const child=value(t.ok,depth+1,bindings);return t.sum_key?__sumMake(t.sum_key,true,child):{Ok:child};}if(tag===1){const child=value(t.error,depth+1,bindings);return t.sum_key?__sumMake(t.sum_key,false,child):{Err:child};}throw Error('invalid Result tag');}
  default:throw Error('unsupported snapshot type');
 }}
 const version=integer(8),tables=meta.roots.map(()=>new Map());
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const n=sequence();if(n>Math.floor(left/2))throw Error('snapshot row limit exceeded');let prior;for(let i=0;i<n;i++){const k=value(r.snapshotKey??r.key),v=value(r.snapshotValue??r.value);if(i&&__keyCompare(prior,k,r.key)>=0)throw Error('duplicate or unordered snapshot key');tables[r.index].set(k,v);prior=k;}}
 const count=sequence(),outbox=[];let prior;
 for(let i=0;i<count;i++){const commit=integer(8),position=integer(8),channel=Number(integer(4));if(!meta.events[channel])throw Error('unknown snapshot event channel');const v=value(meta.events[channel].snapshotType??meta.events[channel].type);if(commit===0n||commit>version||(prior&&(commit<prior.commit||(commit===prior.commit&&position<=prior.position))))throw Error('invalid snapshot event sequence');const e={commit,position,channel:meta.events[channel].name,value:v};outbox.push(e);prior=e;}
 if(at!==end)throw Error('trailing snapshot payload');return {version,tables,outbox};
}
// Fixed subscription lifecycle. Root/output edges derive from checked source;
// values and ownership codecs are compiled from each query's declared type.
function __createObservers(prepare){
 const subscriptions=new Map(),byRoot=new Map(),errors=[],directRoots=[],rootSchedules=[];
 let pending=[],spare=[];
 let next=0,held=0,flushing=false;
 function report(s,error,phase){errors.push({query:s?.query??null,error,phase});if(s?.onError)try{s.onError(error);}catch(e){errors.push({query:s.query,error:e,phase:'error-handler'});}}
 function flush(initialPasses=0){
  if(held||flushing||!pending.length)return;
  flushing=true;let passes=initialPasses;
  try{
   while(pending.length&&!held){
    if(++passes>1024){report(null,Error('subscription publication budget exhausted'),'publication');break;}
    const affected=pending;pending=spare;spare=affected;
    for(const s of affected)s.queued=false;
    // Snapshot every affected value before consumers run. Deliveries reside in
    // the stable subscription slots; no per-delivery tuple is allocated.
    for(const s of affected){if(!s.active)continue;s.deliver=false;
     try{if(s.pair){const a=s.pairState?s.pairState.keeps[s.keep0]:s.read0(),b=s.pairState?s.pairState.keeps[s.keep1]:s.read1();if(s.value0!==a||s.value1!==b){s.value0=a;s.value1=b;s.delivery0=a;s.delivery1=b;s.deliver=true;}}else{const value=s.capture(s.read());if(!s.equal(s.value,value)){s.value=value;s.delivery=value;s.deliver=true;}}}
     catch(e){report(s,e,'query');}
    }
    for(const s of affected){if(!s.active||!s.deliver)continue;const value=s.delivery;s.deliver=false;s.delivery=undefined;
     try{if(s.pair)s.callback(s.delivery0,s.delivery1);else s.callback(s.output(value));}catch(e){report(s,e,'listener');}
    }
    affected.length=0;
   }
  }finally{flushing=false;}
 }
 function install(query,q,callback,{immediate=true,onError}={}){
  if(typeof callback!=='function'||onError!==undefined&&typeof onError!=='function')throw TypeError('subscription callback');
  const s={...q,id:next++,query,callback,onError,active:true,queued:false,deliver:false,delivery:undefined};
  if(s.pair){s.value0=s.pairState?s.pairState.keeps[s.keep0]:s.read0();s.value1=s.pairState?s.pairState.keeps[s.keep1]:s.read1();}else{s.value=s.capture(s.read());}subscriptions.set(s.id,s);
  for(const root of s.roots){let ids=byRoot.get(root);if(!ids)byRoot.set(root,ids=[]);ids.push(s);schedule(root,ids);}
  const dispose=()=>{if(!subscriptions.delete(s.id))return;s.active=false;for(const root of s.roots){const ids=byRoot.get(root);ids.splice(ids.indexOf(s),1);schedule(root,ids);if(!ids.length)byRoot.delete(root);}};
  if(immediate)try{if(s.pair)callback(s.value0,s.value1);else callback(s.output(s.value));}catch(e){dispose();throw e;}
  return dispose;
 }
 // Bind the publication implementation when consumers change, instead of
 // rediscovering the one-consumer schedule on each source mutation.
 function schedule(root,ids){
  const s=directRoots[root]=ids.length===1&&ids[0].pairState?ids[0]:null;
  rootSchedules[root]=!ids.length?null:s?()=>publishPair(s):(outputs,epoch)=>{enqueueRoot(root,outputs,epoch);flush();};
 }
 function publishPair(s){
  const a=s.pairState.keeps[s.keep0],b=s.pairState.keeps[s.keep1];
  if(s.value0===a&&s.value1===b)return;
  if(!held&&!flushing&&!pending.length){
   s.value0=a;s.value1=b;flushing=true;
   try{s.callback(a,b);}catch(e){report(s,e,'listener');}finally{flushing=false;}
   flush(1);return;
  }
  if(!s.queued){s.queued=true;pending.push(s);}flush();
 }
 function enqueueRoot(root,outputs,epoch){
  const slots=byRoot.get(root);if(!slots)return;
  for(let i=0;i<slots.length;i++){
   const s=slots[i];if(s.queued)continue;
   if(outputs!==null&&s.outputs?.length){
    let changed=false;for(let j=0;j<s.outputs.length;j++)if(epoch?outputs[s.outputs[j]]===epoch:outputs.has(s.outputs[j])){changed=true;break;}
    if(!changed)continue;
   }
   s.queued=true;pending.push(s);
  }
 }
 return {
  directRoots,rootSchedules,
  get active(){return subscriptions.size!==0;},
  subscribe(query,args,callback,options){return install(query,prepare(query,args),callback,options);},
  subscribeGroup(queries,callback,options){
   if(!Array.isArray(queries)||!queries.length)throw TypeError('subscription group requires queries');
   const qs=queries.map(q=>typeof q==='string'?prepare(q,[]):prepare(q.query,q.args??[]));
   const roots=[...new Set(qs.flatMap(q=>q.roots))];
   // An unknown dependency forces ordinary root invalidation for the group.
   const outputs=qs.every(q=>q.outputs?.length)?[...new Set(qs.flatMap(q=>q.outputs))]:[];
   const scalar=qs.every(q=>q.scalar),direct=qs.every(q=>q.direct);
   return install(queries,{roots,outputs,read:direct?()=>qs.map(q=>q.direct()):()=>qs.map(q=>q.read()),capture:scalar?values=>values:values=>values.map((v,i)=>qs[i].capture(v)),output:scalar?values=>values.slice():values=>values.map((v,i)=>qs[i].output(v)),equal:scalar?(a,b)=>a.every((v,i)=>v===b[i]):(a,b)=>a.every((v,i)=>qs[i].equal(v,b[i]))},callback,options);
  },
  subscribeValues(queries,callback,options){
   if(!Array.isArray(queries)||!queries.length)throw TypeError('subscription group requires queries');
   if(typeof callback!=='function')throw TypeError('subscription callback');
   const qs=queries.map(q=>typeof q==='string'?prepare(q,[]):prepare(q.query,q.args??[]));
   if(qs.length===2&&qs.every(q=>q.scalar)){
    const roots=[...new Set(qs.flatMap(q=>q.roots))],outputs=qs.every(q=>q.outputs?.length)?[...new Set(qs.flatMap(q=>q.outputs))]:[];
    const pairState=qs[0].committed&&qs[1].committed&&qs[0].committed.state===qs[1].committed.state?qs[0].committed.state:null;
    return install(queries,{roots,outputs,pair:true,pairState,keep0:qs[0].committed?.keep,keep1:qs[1].committed?.keep,read0:qs[0].direct||qs[0].read,read1:qs[1].direct||qs[1].read},callback,options);
   }
   return this.subscribeGroup(queries,values=>callback(...values),options);
  },
  commit(roots,outputs=null){
   if(!subscriptions.size)return;
   for(const root of roots)enqueueRoot(root,outputs,false);
   flush();
  },
  // A checked single-root action supplies a reusable array of changed outputs.
  // No root carrier, Set, affected-ID array or Map lookup per delivery is needed.
  commitRoot(root,outputs=null,epoch=0){
   rootSchedules[root]?.(outputs,epoch);
  },
  hold(){held++;return pending.slice();},
  release(){if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  rollback(mark){for(const s of pending)s.queued=false;pending.length=0;for(const s of mark)if(s.active&&!s.queued){s.queued=true;pending.push(s);}if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  batch(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('batch callback must be synchronous');held++;
   try{const value=callback();if(value&&typeof value.then==='function')throw TypeError('state batch callback must be synchronous');return value;}
   finally{held--;flush();}
  },
  flush,takeErrors(){return errors.splice(0);}
 };
}
function __versionWord(v){return typeof v==='number'?BigInt(v):v;}
function __storedCommit(meta,v){return meta.compactCommits&&v<=9007199254740991n?Number(v):v;}
function __nextCommit(v){return typeof v==='number'&&v<9007199254740991?v+1:BigInt(v)+1n;}
// Private column event log. Public records and portable event ordering are unchanged.
// Private event storage. Public events and portable snapshots keep their ordinary
// ordered records. A selected contiguous run omits repeated commit metadata;
// gaps and duplicate commits materialise an exact literal column.
class __EventColumns {
 constructor(channels,compact=false,runs=false){this.channels=channels;this.compact=compact;this.runs=runs;this.commits=runs?null:[];this.base=undefined;this.values=[];this.positions=null;this.channelValues=channels.length===1?null:[];}
 get length(){return this.values.length;}
 set length(n){if(!Number.isSafeInteger(n)||n<0||n>this.length)throw Error('event log truncate');if(this.commits)this.commits.length=n;this.values.length=n;if(this.positions)this.positions.length=n;if(this.channelValues)this.channelValues.length=n;if(n===0){this.base=undefined;if(this.runs)this.commits=null;}}
 append(commit,position,channel,value){
  const i=this.values.length;
  if(this.commits)this.commits.push(commit);
  else if(!i)this.base=commit;
  else{
   const small=typeof this.base==='number'&&typeof commit==='number';
   const expected=small?this.base+i:__versionWord(this.base)+BigInt(i);
   if(expected!==commit){
    this.commits=[];
    for(let j=0;j<i;j++){const word=__versionWord(this.base)+BigInt(j);this.commits.push(this.compact&&word<=9007199254740991n?Number(word):word);}
    this.commits.push(commit);
   }
  }
  this.values.push(value);if(this.channelValues)this.channelValues.push(channel);if(position!==0n&&!this.positions)this.positions=new Array(i).fill(0n);if(this.positions)this.positions.push(position);
 }
 push(e){this.append(this.compact&&e.commit<=9007199254740991n?Number(e.commit):e.commit,e.position,e.channel,e.value);return this.length;}
 at(i){if(i<0)i+=this.length;if(i<0||i>=this.length)return undefined;return {commit:this.commits?__versionWord(this.commits[i]):__versionWord(this.base)+BigInt(i),position:this.positions?this.positions[i]:0n,channel:this.channelValues?this.channelValues[i]:this.channels[0],value:this.values[i]};}
 *[Symbol.iterator](){for(let i=0;i<this.length;i++)yield this.at(i);}
 map(f){const out=new Array(this.length);for(let i=0;i<this.length;i++)out[i]=f(this.at(i),i);return out;}
 filter(f){const out=new __EventColumns(this.channels,this.compact,this.runs);for(let i=0;i<this.length;i++){const e=this.at(i);if(f(e,i))out.push(e);}return out;}
}
function __eventLog(meta,events=[]){
 if(!meta.eventColumns)return meta.compactCommits?events.map(e=>({...e,commit:__storedCommit(meta,e.commit)})):events;
 const log=new __EventColumns(meta.events.map(e=>e.name),meta.compactCommits,meta.eventRuns);for(const e of events)log.append(__storedCommit(meta,e.commit),e.position,e.channel,e.value);return log;
}
// CALLER CONTRACT: arguments must match declared types; malformed data may throw or corrupt state.
// Fixed state primitives used by emitted action bodies, without an AST evaluator.
class __Abort {constructor(value){this.value=value;}}
function __preflightError(message){throw Error(message);}
function __try(value){if(Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value.Ok;}
function __nested(value,change){if(change && Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value;}
function __equal(a,b){if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object')return false;const ak=Object.keys(a),bk=Object.keys(b);return ak.length===bk.length&&ak.every(k=>Object.hasOwn(b,k)&&__equal(a[k],b[k]));}
function __checked(op,a,b,bits){const x=BigInt(a),y=BigInt(b),n=op==='checked_add'?x+y:op==='checked_sub'?x-y:x*y;const min=bits===-32?-2147483648n:0n,max=bits===-32?2147483648n:1n<<BigInt(bits);return n<min||n>=max?{Err:'ArithmeticError.Overflow'}:{Ok:Math.abs(bits)===32?Number(n):n};}
function __okOr(value,error){return Object.hasOwn(value,'Some')?{Ok:value.Some}:{Err:error};}
function __mapValue(value,kind,method,fn){
 if(kind==='list')return value[method](fn);
 if(kind==='option')return Object.hasOwn(value,'Some')?{Some:fn(value.Some)}:{None:null};
 const tag=method==='map_err'?'Err':'Ok';return Object.hasOwn(value,tag)?{[tag]:fn(value[tag])}:value;
}
const __encoder=new TextEncoder();
function __tick(ctx){if(--ctx.fuel<0)throw Error('Ink state execution budget exhausted');}
function __keyCompare(a,b,type){
 if(type.kind==='string'){let i=0,j=0;while(i<a.length&&j<b.length){const x=a.codePointAt(i),y=b.codePointAt(j);if(x!==y)return x-y;i+=x>65535?2:1;j+=y>65535?2:1;}return (i<a.length?1:0)-(j<b.length?1:0);}
 return a<b?-1:a>b?1:0;
}
// A table's ordered key view is reused until membership changes. Values are
// fetched at traversal time, so replacement never leaves stale row payloads.
const __tableOrder=new WeakMap();
function __keyPosition(keys,key,type){let low=0,high=keys.length;while(low<high){const middle=(low+high)>>>1;if(__keyCompare(keys[middle],key,type)<0)low=middle+1;else high=middle;}return low;}
function __tableMembership(rt,index,key,present){
 const view=__tableOrder.get(rt.tables[index]);if(!view)return;
 const at=__keyPosition(view.keys,key,rt.meta.roots[index].key);
 if((at<view.keys.length&&view.keys[at]===key)===present)view.pending.delete(key);
 else view.pending.set(key,present);
}
function __orderedKeys(rt,index){
 const table=rt.tables[index],type=rt.meta.roots[index].key;let view=__tableOrder.get(table);
 if(!view){view={keys:[...table.keys()].sort((a,b)=>__keyCompare(a,b,type)),pending:new Map()};__tableOrder.set(table,view);}
 if(view.pending.size){
  const changes=[...view.pending.keys()].sort((a,b)=>__keyCompare(a,b,type)),merged=[];let i=0,j=0;
  while(i<view.keys.length||j<changes.length){
   if(j===changes.length||(i<view.keys.length&&__keyCompare(view.keys[i],changes[j],type)<0))merged.push(view.keys[i++]);
   else{const key=changes[j++];if(i<view.keys.length&&view.keys[i]===key)i++;if(view.pending.get(key))merged.push(key);}
  }
  view.keys=merged;view.pending.clear();
 }
 const keys=view.keys;
 const cell=rt.cell;
 if(cell&&cell.index===index&&table.has(cell.key)!==(cell.next!==undefined)){
  if(cell.next===undefined)return keys.filter(k=>k!==cell.key);
  const at=__keyPosition(keys,cell.key,type);return [...keys.slice(0,at),cell.key,...keys.slice(at)];
 }
 return keys;
}
function __cellGet(rt,index,key){const cell=rt.cell;return cell&&cell.index===index&&cell.key===key?cell.next:rt.tables[index].get(key);}
function __readTable(rt,index){const cell=rt.cell;if(!cell||cell.index!==index)return rt.tables[index];const table=new Map(rt.tables[index]);if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);return table;}
// The first before-image of each cell suffices for whole-transaction rollback.
function __remember(rt,index,key,present,value){if(rt.cellMode)return;if(!rt.seen[index].has(key)){rt.seen[index].add(key);rt.undo.push([index,key,present,value]);}}
// Immutable keeps retain private values. Public results remain owned copies.
// Reverse edges come from checked source effects.
// Before-images preserve cached values across failed actions; host rollback and
// restore discard caches rather than serializing them into logical snapshots.
function __invalidateKeeps(rt,index){
 if(rt.observers?.active)rt.changedRoots.add(index);
 if(!rt.keeps||rt.cellMode)return;
 for(const keep of rt.meta.keepInvalidations[index]){
  if(!rt.keepDirty[keep]){rt.keepDirty[keep]=1;rt.keepUndoIndices[rt.keepUndoCount++]=keep;rt.keepBefore[keep]=rt.keeps[keep];}
  rt.keeps[keep]=undefined;
 }
}
function __restoreKeeps(rt){for(let i=rt.keepUndoCount-1;i>=0;i--){const keep=rt.keepUndoIndices[i];rt.keeps[keep]=rt.keepBefore[keep];}__refreshActiveViews(rt);}
function __clearKeepJournal(rt){for(let i=0;i<rt.keepUndoCount;i++){const keep=rt.keepUndoIndices[i];rt.keepDirty[keep]=0;rt.keepBefore[keep]=undefined;}rt.keepUndoCount=0;}
function __rebuildViews(rt){
 rt.activeViewRoots=new Uint8Array(rt.meta.roots.length);
 for(const view of rt.views){rt.keeps[view.keep]=undefined;if(!rt.meta.lazyMaintenance)__viewBase(rt,view);}
}
function __refreshActiveViews(rt){rt.activeViewRoots.fill(0);for(const view of rt.views)if(rt.keeps[view.keep]!==undefined)rt.activeViewRoots[view.root]=1;}
function __viewBase(rt,view){
 if(rt.keeps[view.keep]===undefined){let value=view.zero;for(const [key,row]of rt.tables[view.root])value=view.combine(value,view.contribution(key,row));rt.keeps[view.keep]=value;rt.activeViewRoots[view.root]=1;}
 return rt.keeps[view.keep];
}
function __viewValue(view,value,key,oldValue,newValue){
 if(oldValue===undefined)return view.insert?view.insert(value,key,newValue):view.combine(value,view.contribution(key,newValue));
 if(newValue===undefined)return view.remove?view.remove(value,key,oldValue):view.combine(value,view.inverse(view.contribution(key,oldValue)));
 return view.replace?view.replace(value,key,oldValue,newValue):view.combine(view.combine(value,view.inverse(view.contribution(key,oldValue))),view.contribution(key,newValue));
}
function __updateViews(rt,index,key,oldValue,newValue){
 if(!rt.activeViewRoots[index])return null;
 const updates=rt.viewNext;
 for(const view of rt.viewsByRoot[index])updates[view.keep]=rt.keeps[view.keep]===undefined?undefined:__viewValue(view,rt.keeps[view.keep],key,oldValue,newValue);
 return updates;
}
function __installViews(rt,updates,index){if(updates)for(const view of rt.viewsByRoot[index])rt.keeps[view.keep]=updates[view.keep];}
function __pendingView(rt,view){
 const keep=view.keep;
 if(rt.pendingValues[keep]===undefined){
  const cell=rt.cell;
  rt.pendingValues[keep]=__viewValue(view,__viewBase(rt,view),cell.key,cell.prior,cell.next);
  rt.pendingIndices.push(keep);
 }
 return rt.pendingValues[keep];
}
function __prepareCell(rt){if(rt.cell&&rt.activeViewRoots[rt.cell.index]){const prepare=rt.views.prepareRoots?.[rt.cell.index];if(prepare)prepare(rt,rt.cell);else for(const view of rt.viewsByRoot[rt.cell.index])if(rt.keeps[view.keep]!==undefined)__pendingView(rt,view);}}
function __invalidateSnapshotRow(rt,index,key){rt.snapshotRows?.[index].delete(key);}
function __writeCell(rt,index,key,next,prior){
 if(rt.cellMode){if(rt.cell)throw Error('checked single-cell bound exceeded');rt.cell={index,key,next,prior};}
 else{const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);if(rt.changeTracking)__recordChange(rt,index,key,prior,next);if((prior!==undefined)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);if(next===undefined)table.delete(key);else table.set(key,next);}
}
function __commitCell(rt){
 const cell=rt.cell;if(!cell)return;
 const table=rt.tables[cell.index];__invalidateSnapshotRow(rt,cell.index,cell.key);
 if(rt.changeTracking)__recordChange(rt,cell.index,cell.key,cell.prior,cell.next);
 if((cell.prior!==undefined)!==(cell.next!==undefined))__tableMembership(rt,cell.index,cell.key,cell.next!==undefined);
 if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);
 for(const keep of rt.meta.keepInvalidations[cell.index])rt.keeps[keep]=rt.pendingValues[keep];
 rt.cell=null;
}
// Preflight scratch has no logical state or rollback obligations. Definitions
// are the same admitted group operations used by ordinary cell maintenance.
function __prepareDirect(rt,index,key,prior,next){
 const prepare=rt.views.directRoots?.[index];
 if(prepare)prepare(rt,key,prior,next);
 else for(const view of rt.viewsByRoot[index])rt.viewNext[view.keep]=__viewValue(view,rt.keeps[view.keep],key,prior,next);
}
function __storeDirect(rt,index,key,prior,next,slot){
 const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);
 if((prior!==undefined)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);
 if(rt.changeTracking)__recordChange(rt,index,key,prior,next);
 if(slot===undefined){if(next===undefined)table.delete(key);else table.set(key,next);}
 else{
  // The checked preflight lookup retains the dense slot until this commit.
  // No callback or source write can intervene; sparse keys retain exact identity.
  if(slot<0){if(next===undefined)table.sparse.delete(key);else table.sparse.set(key,next);}else table.dense[slot]=next;
  if(prior===undefined&&next!==undefined)table.members.add(key);else if(prior!==undefined&&next===undefined)table.members.delete(key);
 }
}
function __commitDirect(rt,index,key,prior,next,slot){
 __storeDirect(rt,index,key,prior,next,slot);
 const publishOutputs=rt.meta.outputPublication&&!rt.observers.directRoots[index]&&rt.observers.active;
 if(publishOutputs&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}

 for(const keep of rt.meta.keepInvalidations[index]){
  const value=rt.viewByKeep[keep]?rt.viewNext[keep]:undefined;
  if(publishOutputs)rt.changedOutputs[keep]=rt.keeps[keep]!==value?rt.changedOutputEpoch:0;
  rt.keeps[keep]=value;
 }
}
function __emit(rt,channel,value){
 if(rt.eventCount++===0){rt.eventChannel=channel;rt.eventValue=value;}
 else rt.staged.push([channel,value]);
}
// Checked prefix capacities are at most 2^20. Number conversion is exact
// inside that prefix; rounding a wide word cannot move it into the prefix.
// Wide keys retain their original full-width value in the sparse fallback.
class __DenseTable{
 constructor(capacity){this.limit=capacity;this.dense=[];for(let i=0;i<capacity;i++)this.dense.push(undefined);this.sparse=new Map();this.members=new Set();}
 clear(){this.dense.fill(undefined);this.sparse.clear();this.members.clear();__tableOrder.delete(this);return this;}
 slot(key){const i=Number(key);return Number.isInteger(i)&&i>=0&&i<this.limit?i:-1;}
 get size(){return this.members.size;}
 get(key){const i=this.slot(key);return i<0?this.sparse.get(key):this.dense[i];}
 has(key){return this.get(key)!==undefined;}
 set(key,value){const i=this.slot(key),present=i<0?this.sparse.has(key):this.dense[i]!==undefined;if(i<0)this.sparse.set(key,value);else this.dense[i]=value;if(!present)this.members.add(key);return this;}
 delete(key){const i=this.slot(key);if(i<0)this.sparse.delete(key);else this.dense[i]=undefined;return this.members.delete(key);}
 keys(){return this.members.keys();}
 *values(){for(const key of this.members)yield this.get(key);}
 *entries(){for(const key of this.members)yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
class __ColumnTable {
 constructor(root){
  this.limit=root.columnPrefix.capacity;this.keyBig=root.key.kind==='u64';
  this.fields=root.value.fields;this.exactNumbers=root.columnPrefix.exactNumbers;
  this.present=new Uint8Array(this.limit);this.count=0;this.sparse=new Map();
  this.lanes=this.fields.map(f=>f.type.kind==='u64'?(this.exactNumbers?new Float64Array(this.limit):new BigUint64Array(this.limit)):f.type.kind==='i32'?new Int32Array(this.limit):f.type.kind==='bool'?new Uint8Array(this.limit):new Uint32Array(this.limit));
  this.wide=this.fields.map(f=>f.type.kind==='u64'&&this.exactNumbers?new Map():null);
 }
 slot(key){const i=Number(key);return Number.isInteger(i)&&i>=0&&i<this.limit?i:-1;}
 get size(){return this.count+this.sparse.size;}
 has(key){const i=this.slot(key);return i<0?this.sparse.has(key):this.present[i]!==0;}
 get(key){const i=this.slot(key);if(i<0)return this.sparse.get(key);if(!this.present[i])return undefined;const row=Object.create(null);for(let j=0;j<this.fields.length;j++){const f=this.fields[j],v=this.lanes[j][i];row[f.name]=f.type.kind==='bool'?v!==0:f.type.kind==='u64'&&this.exactNumbers?(this.wide[j].get(i)??BigInt(v)):v;}return row;}
 set(key,row){const i=this.slot(key);if(i<0){this.sparse.set(key,row);return this;}for(let j=0;j<this.fields.length;j++){const f=this.fields[j],v=row[f.name];if(f.type.kind==='u64'&&this.exactNumbers){if(v<=9007199254740991n){this.lanes[j][i]=Number(v);this.wide[j].delete(i);}else{this.lanes[j][i]=0;this.wide[j].set(i,v);}}else this.lanes[j][i]=f.type.kind==='bool'?Number(v):v;}if(!this.present[i]){this.present[i]=1;this.count++;}return this;}
 delete(key){const i=this.slot(key);if(i<0)return this.sparse.delete(key);if(!this.present[i])return false;this.present[i]=0;this.count--;for(const wide of this.wide)wide?.delete(i);return true;}
 *keys(){for(let i=0;i<this.limit;i++)if(this.present[i])yield this.keyBig?BigInt(i):i;yield* this.sparse.keys();}
 *values(){for(const key of this.keys())yield this.get(key);}
 *entries(){for(const key of this.keys())yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
function __newTables(meta,prefixes,old,spares){return meta.roots.map((root,i)=>{const prior=spares?.[i];const t=root.columnPrefix?new __ColumnTable(root):prefixes[i]?(prior instanceof __DenseTable&&prior.limit===prefixes[i]?prior.clear():new __DenseTable(prefixes[i])):new Map();if(old)for(const [k,v]of old[i])t.set(k,v);return t;});}
// Only inactive containers are reused. Consume the spare before preparation so
// a failed invariant/rebuild cannot expose its partially reconstructed contents.
// Rows remain immutable; the current logical state changes only at installation.
function __restoreTables(rt,prefixes,old){const spares=rt.restoreSpares;rt.restoreSpares=null;return __newTables(rt.meta,prefixes,old,spares);}
function __cachedKeep(ctx,rt,index,compute){
 if(rt.cell&&rt.meta.keepInvalidations[rt.cell.index].includes(index)){
  const view=rt.viewByKeep[index];
  if(view)return __pendingView(rt,view);
  if(rt.pendingValues[index]===undefined){rt.pendingValues[index]=compute(ctx,rt);rt.pendingIndices.push(index);}
  return rt.pendingValues[index];
 }
 const prior=rt.keeps[index];if(prior!==undefined)return prior;
 const view=rt.viewByKeep[index];if(view)return __viewBase(rt,view);
 const value=compute(ctx,rt);rt.keeps[index]=value;return value;
}
function __tableContains(rt,index,key){return __cellGet(rt,index,key)!==undefined;}
function __tableGet(rt,index,key){const value=__cellGet(rt,index,key);return value===undefined?{None:null}:{Some:value};}
function __tablePut(rt,index,key,next,mode=0){
 const prior=rt.tables[index].get(key),present=prior!==undefined;
 if(mode===1&&present)throw Error('insert key already present');
 if(mode===2&&!present)throw Error('replace key absent');
 if(present&&__stateRootEquals[index](prior,next))return null;
 const updates=rt.cellMode?null:__updateViews(rt,index,key,prior,next);
 __invalidateKeeps(rt,index);__remember(rt,index,key,present,prior);
 __writeCell(rt,index,key,next,prior);__installViews(rt,updates,index);return null;
}
function __tableRemove(rt,index,key){
 const value=rt.tables[index].get(key);
 if(value===undefined)return {None:null};
 const updates=rt.cellMode?null:__updateViews(rt,index,key,value,undefined);
 __invalidateKeeps(rt,index);__remember(rt,index,key,true,value);
 __writeCell(rt,index,key,undefined,value);__installViews(rt,updates,index);return {Some:value};
}
function __table(rt,index,method,args){
 const key=args[0];
 if(method==='get')return __tableGet(rt,index,key);
 if(method==='contains')return __tableContains(rt,index,key);
 const table=rt.tables[index];
 if(method==='values'||method==='keys'){const keys=__orderedKeys(rt,index);return method==='keys'?keys.slice():keys.map(k=>__cellGet(rt,index,k));}
 if(method==='intersect_table'){const current=__readTable(rt,index),other=__readTable(rt,args[0]),small=current.size<=other.size?current:other,large=small===current?other:current;const result=[];for(const k of small.keys())if(large.has(k))result.push(k);return result.sort((a,b)=>__keyCompare(a,b,rt.meta.roots[index].key));}
 if(method==='intersect_keys'){const requested=args[0],size=rt.tables[index].size;
  // Fewer requested keys than rows: look each one up instead of scanning.
  if(requested.length<size){const type=rt.meta.roots[index].key;return [...new Set(requested)].filter(k=>__cellGet(rt,index,k)!==undefined).sort((a,b)=>__keyCompare(a,b,type));}
  const selected=new Set(requested);return __orderedKeys(rt,index).filter(k=>selected.has(k));}
 if(method==='put_many'){const keys=args[0],values=args[1];if(keys.length!==values.length)return {Err:'table bulk length mismatch'};for(let i=0;i<keys.length;i++)__table(rt,index,'put',[keys[i],values[i]]);return {Ok:null};}
 if(method==='remove_many'){for(const k of args[0])__table(rt,index,'remove',[k]);return null;}
 if(method==='remove')return __tableRemove(rt,index,key);
 return __tablePut(rt,index,key,args[1],method==='insert'?1:method==='replace'?2:0);
}

function __rollback(rt,mark){for(let i=rt.undo.length-1;i>=mark;i--){const [index,key,present,value]=rt.undo[i];const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);if(table.has(key)!==present)__tableMembership(rt,index,key,present);if(present)table.set(key,value);else table.delete(key);}rt.undo.length=mark;}
function __recordChange(rt,index,key,prior,next){rt.changeLog.push([index,key,prior,next]);}
function __fixedTableBytes(root,table){
 const writer=__snapshotWriter(__snapshotLimits());
 const rows=[...table.entries()].sort((a,b)=>__keyCompare(a[0],b[0],root.key));
 writer.integer(rows.length,8);
 for(const [key,value]of rows){writer.value(key,root.snapshotKey??root.key);writer.value(value,root.snapshotValue??root.value);}
 return writer.finish();
}
function __createState(meta,implementations,captures=null,views=[],prefixes=[]){
 const rt={meta,tables:__newTables(meta,prefixes),version:meta.compactCommits?0:0n,outbox:__eventLog(meta),staged:[],busy:false,undo:[],seen:meta.roots.map(()=>new Set()),host:null,keeps:new Array(meta.keeps.length),keepDirty:meta.keeps.length?new Uint8Array(meta.keeps.length):null,keepUndoIndices:meta.keeps.length?new Uint32Array(meta.keeps.length):null,keepUndoCount:0};
 const fixed=typeof __stateFrozenFactories==='undefined'?[]:__stateFrozenFactories;
 const fixedBytes=[];
 for(let i=0;i<fixed.length;i++)if(fixed[i]){for(const [key,value]of fixed[i]())rt.tables[i].set(key,value);fixedBytes[i]=__fixedTableBytes(meta.roots[i],rt.tables[i]);}
 function checkFixed(tables){for(let i=0;i<fixedBytes.length;i++)if(fixedBytes[i]){const bytes=__fixedTableBytes(meta.roots[i],tables[i]);if(bytes.length!==fixedBytes[i].length||!bytes.every((v,n)=>v===fixedBytes[i][n]))throw Error('snapshot changes frozen state: '+meta.roots[i].name);}}
 rt.views=views;rt.viewsByRoot=meta.roots.map((_,root)=>views.filter(v=>v.root===root));__rebuildViews(rt);
 rt.viewByKeep=new Array(meta.keeps.length);for(const view of views)rt.viewByKeep[view.keep]=view;
 rt.pendingIndices=[];rt.pendingValues=new Array(meta.keeps.length);
 rt.eventCount=0;rt.eventChannel=null;rt.eventValue=null;
 rt.viewNext=new Array(meta.keeps.length);rt.cell=null;rt.cellMode=false;rt.ctx={fuel:100000000};
 rt.keepBefore=meta.keeps.length?new Array(meta.keeps.length):null;
 rt.changedRoots=new Set();rt.changedOutputs=new Array(meta.keeps.length).fill(0);rt.changedOutputEpoch=0;
 rt.snapshotRows=meta.snapshotRows?meta.roots.map(()=>new Map()):null;
 rt.restoreSpares=null;rt.changeTracking=false;rt.changeLog=[];rt.changeEpoch=0;rt.changeTokens=new Map();
 const actionMap=new Map(meta.actions.map(a=>[a.name,{...a,inputs:captures?captures[a.index]:a.params.map(p=>__stateCapture(p.type)),output:__stateResult(a.result)}]));
 const eventOutput=new Map(meta.events.map(e=>[e.name,__stateResult(e.type)]));
 rt.eventOutput=eventOutput;
 const prepared=new WeakMap();
 const observers=rt.observers=__createObservers((name,args)=>{
  const a=actionMap.get(name);if(!a||a.change)throw Error('subscription requires a readonly query');
  const captured=a.inputs.map((convert,i)=>convert(args[i]));
  const publicArgs=captured.map((v,i)=>__stateResult(a.params[i].type)(v));
  const scalar=['u64','u32','i32','bool','string','unit','enum','id'].includes(a.result.kind);
  return {scalar,committed:scalar&&a.directKeep!==null&&a.directKeep!==undefined?{state:rt,keep:a.directKeep}:null,direct:scalar&&a.directKeep!==null&&a.directKeep!==undefined?()=>rt.keeps[a.directKeep]:null,roots:a.roots,outputs:rt.meta.outputPublication&&a.directKeep!==null&&a.directKeep!==undefined?[a.directKeep]:[],read:!a.precondition&&a.params.length===0?readZero(a,true):()=>run(a,publicArgs,null,null,true),capture:scalar?v=>v:__stateCapture(a.result),output:scalar?v=>v:a.output,equal:__stateQueryEquals[a.index]};
 });
 function invoke(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);return run(a,args);}
 function readZero(a,resultOnly){
  const implementation=implementations[a.index],output=a.output,fresh=a.freshResult;
  if(resultOnly&&fresh&&__stateDirectReadFactories[a.index])return __stateDirectReadFactories[a.index](rt);
  if(a.directKeep!==null&&a.directKeep!==undefined)return ()=>{
   if(rt.busy)throw Error('state operation already in progress');
   const value=rt.keeps[a.directKeep],result=fresh?value:output(value);
   return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};
  };
  return ()=>{
   if(rt.busy)throw Error('state operation already in progress');rt.busy=true;rt.ctx.fuel=100000000;
   try{const value=implementation(rt.ctx,rt),result=fresh?value:output(value);return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};}
   finally{rt.busy=false;}
  };
 }
 function read(a,args,inputs,output,resultOnly,owned=false){
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  rt.busy=true;
  try{const value=implementations[a.index](ctx,rt,...captured),result=a.freshResult?value:(output||a.output)(value);return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};}
  finally{rt.busy=false;}
 }
 function begin(a){
  if(rt.busy)throw Error('state operation already in progress');
  rt.ctx.fuel=100000000;
  rt.actionMark=rt.undo.length;rt.actionVersion=rt.version;rt.actionOutbox=rt.outbox;rt.actionOutboxLength=rt.outbox.length;rt.actionChangeMark=rt.changeLog.length;
  rt.busy=true;rt.cellMode=a.singleCell&&!rt.host;rt.staged.length=0;rt.eventCount=0;rt.changedRoots.clear();rt.actionSuccessful=false;
 }
 function complete(a,value,output,resultOnly){
  const result=a.freshResult?value:(output||a.output)(value);
  const version=rt.actionVersion;
  if(a.fallible && (a.flatFailure?value.tag!==0:Object.hasOwn(value,'Err'))){rt.changeLog.length=rt.actionChangeMark;__rollback(rt,rt.actionMark);__restoreKeeps(rt);if(rt.host?.strict)rt.host.failure=Object.assign(Error('transaction action failed'),{action:a.name,result});return resultOnly?result:{result,committed:false,version:__versionWord(version),events:[]};}
  if(version===18446744073709551615n)throw Error('commit sequence exhausted');
  const next=rt.meta.compactCommits?__nextCommit(version):version+1n;
  const publicNext=resultOnly?null:__versionWord(next);
  __prepareCell(rt);
  const events=resultOnly?null:new Array(rt.eventCount);
  if(rt.eventCount){
   const channel=rt.eventChannel,value=rt.eventValue;
   rt.outbox.push({commit:next,position:0n,channel,value});
   if(events)events[0]={commit:publicNext,position:0n,channel,value:eventOutput.get(channel)(value)};
   for(let i=0;i<rt.staged.length;i++){
    const [channel,value]=rt.staged[i],position=BigInt(i+1);
    rt.outbox.push({commit:next,position,channel,value});
    if(events)events[i+1]={commit:publicNext,position,channel,value:eventOutput.get(channel)(value)};
   }
  }
  __commitCell(rt);rt.version=next;rt.actionSuccessful=true;
  return resultOnly?result:{result,committed:true,version:publicNext,events};
 }
 function abort(e){
  rt.changeLog.length=rt.actionChangeMark;__rollback(rt,rt.actionMark);__restoreKeeps(rt);rt.version=rt.actionVersion;rt.outbox=rt.actionOutbox;rt.outbox.length=rt.actionOutboxLength;if(rt.host?.strict)rt.host.failure=e;throw e;
 }
 function end(){
  const successful=rt.actionSuccessful,single=rt.cellMode;
  rt.cell=null;rt.cellMode=false;rt.staged.length=0;rt.eventCount=0;rt.eventChannel=null;rt.eventValue=null;
  for(const keep of rt.pendingIndices)rt.pendingValues[keep]=undefined;rt.pendingIndices.length=0;
  if(!single){__clearKeepJournal(rt);for(const seen of rt.seen)seen.clear();if(!rt.host)rt.undo.length=0;}
  rt.actionOutbox=null;rt.busy=false;
  if(successful)observers.commit(rt.changedRoots);
 }
 function run(a,args,inputs=null,output=null,resultOnly=false,owned=false){
  if(a.kernels&&!rt.host){
   if(rt.busy)throw Error('state operation already in progress');
   const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
   return a.kernels[resultOnly?1:0](...captured);
  }
  if(!a.change)return read(a,args,inputs,output,resultOnly,owned);
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  begin(a);
  try{return complete(a,implementations[a.index](ctx,rt,...captured),output,resultOnly);}
  catch(e){return abort(e);}
  finally{end();}
 }

 for(const a of actionMap.values())if(__statePreflightFactories[a.index]){
  // run() supplies module-owned captured values; bound native entries still capture composites.
  a.kernels=[false,true].map(only=>__statePreflightFactories[a.index](run,a,a.inputs,a.output,only,rt,begin,complete,abort,end,true));
 }
 return Object.freeze({
  subscribeValues(queries,callback,options){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribeValues(queries,callback,options);},
  subscribeGroup(queries,callback,options){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribeGroup(queries,callback,options);},
  subscribe(...args){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribe(...args);},
  batch:observers.batch,flushSubscriptions:observers.flush,takeSubscriptionErrors:observers.takeErrors,
  transaction(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('transaction callback must be synchronous');this.beginTransaction();rt.host.strict=true;
   try{const value=callback(this);if(value&&typeof value.then==='function')throw TypeError('state transaction callback must be synchronous');this.commitTransaction();return value;}catch(e){this.rollbackTransaction();throw e;}
  },
  invoke,invoke_json:invoke,
  prepare(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);const captured=a.inputs.map((convert,i)=>convert(args[i])),token=Object.freeze({});prepared.set(token,{action:a,args:captured});return token;},
  invokePrepared(token){const packet=prepared.get(token);if(!packet)throw Error('invalid prepared state call');return run(packet.action,packet.args,null,null,false,true);},
  // A prebound typed entrypoint: scalar arguments obey the native caller contract.
  // Composite arguments still capture owned input; events remain in the outbox.
  bind(name,{resultOnly=false}={}){
   const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);
   const inputs=a.params.map((p,i)=>['u32','i32','u64','bool','unit','string','f32','f64','id','enum','int'].includes(p.type.kind)?__representation(p.type,false):a.inputs[i]);
   if(!a.change&&!a.precondition&&inputs.length===0)return readZero(a,resultOnly);
   return (__statePreflightFactories[a.index]||__stateBoundFactories[a.index])(run,a,inputs,a.output,resultOnly,rt,begin,complete,abort,end);
  },
  beginTransaction(){if(rt.busy||rt.host||rt.undo.length)throw Error('transaction already in progress');rt.host={version:rt.version,outbox:rt.outbox,length:rt.outbox.length,keeps:rt.keeps.slice(),changeMark:rt.changeLog.length,notificationMark:observers.hold()};return true;},
  commitTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');if(rt.host.failure)throw rt.host.failure;rt.host=null;rt.undo.length=0;observers.release();},
  rollbackTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');__rollback(rt,0);rt.version=rt.host.version;rt.outbox=rt.host.outbox;rt.outbox.length=rt.host.length;rt.keeps=rt.host.keeps;__refreshActiveViews(rt);rt.changeLog.length=rt.host.changeMark;rt.changeEpoch++;const mark=rt.host.notificationMark;rt.host=null;observers.rollback(mark);},
  changeToken(){
   if(rt.busy||rt.host)throw Error('change token requires transaction boundary');
   const token=Object.freeze({});rt.changeTracking=true;rt.changeTokens.set(token,{epoch:rt.changeEpoch,index:rt.changeLog.length,version:__versionWord(rt.version)});return token;
  },
  releaseChangeToken(token){rt.changeTokens.delete(token);if(!rt.changeTokens.size){rt.changeTracking=false;rt.changeLog.length=0;}},
  changesSince(token){
   if(rt.busy||rt.host)throw Error('changes require transaction boundary');
   const mark=rt.changeTokens.get(token);if(!mark||mark.epoch!==rt.changeEpoch)throw Error('invalid change token lineage');
   const roots=new Map();
   for(let i=mark.index;i<rt.changeLog.length;i++){
    const [root,key,before,after]=rt.changeLog[i];let cells=roots.get(root);if(!cells)roots.set(root,cells=new Map());
    const prior=cells.get(key);if(prior)prior.after=after;else cells.set(key,{before,after});
   }
   const changes=[];
   const codecs=rt.changeOutputs??=meta.roots.map(schema=>({key:__stateResult(schema.key),row:__stateResult(schema.value)}));
   for(const [root,cells]of roots){const schema=meta.roots[root],keyOut=codecs[root].key,rowOut=codecs[root].row;
    for(const [key,{before,after}]of cells){if(before===undefined&&after===undefined||before!==undefined&&after!==undefined&&__stateRootEquals[root](before,after))continue;
     changes.push({table:schema.name,key:keyOut(key),before:before===undefined?{None:null}:{Some:rowOut(before)},after:after===undefined?{None:null}:{Some:rowOut(after)}});
    }
   }
   return {from:mark.version,to:__versionWord(rt.version),changes};
  },
  get version(){return __versionWord(rt.version);},
  get outbox(){return rt.outbox.map(e=>({...e,commit:__versionWord(e.commit),value:eventOutput.get(e.channel)(e.value)}));},
  acknowledgeThrough(commit,position){if(rt.busy)throw Error('state operation already in progress');commit=__stateWord(commit);position=__stateWord(position);const last=rt.outbox.at(-1);if(!last)return;const lastCommit=__versionWord(last.commit);if(lastCommit<commit||(lastCommit===commit&&last.position<=position)){if(rt.host)rt.outbox=__eventLog(meta);else rt.outbox.length=0;return;}rt.outbox=rt.outbox.filter(e=>{const c=__versionWord(e.commit);return c>commit||(c===commit&&e.position>position);});},
  async invokeAsync(name,args){
   if(typeof __parallelInvokeAsync!=='function')return invoke(name,args);
   if(rt.busy||rt.host)throw Error('parallel state call requires transaction boundary');const captured=structuredClone(args);rt.busy=true;observers.hold();let completed=false;
   try{const snapshot=await __snapshotEncode(meta,rt);const reply=await __parallelInvokeAsync(name,captured,snapshot);const s=await __snapshotDecode(meta,reply.snapshot);checkFixed(s.tables);const candidate={...rt,tables:__restoreTables(rt,prefixes,s.tables),keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);const previousTables=rt.tables;rt.tables=candidate.tables;rt.restoreSpares=previousTables.map(table=>table instanceof __DenseTable?table:null);rt.version=__storedCommit(meta,s.version);rt.outbox=__eventLog(meta,s.outbox);rt.keeps=candidate.keeps;rt.activeViewRoots=candidate.activeViewRoots;if(rt.snapshotRows)rt.snapshotRows=meta.roots.map(()=>new Map());rt.changeEpoch++;rt.changeLog.length=0;completed=true;return reply.value;}finally{rt.busy=false;if(completed)observers.commit(meta.roots.map((_,i)=>i));observers.release();}
  },
  checkpoint(limits){if(rt.busy)throw Error('checkpoint requires transaction boundary');return __snapshotEncode(meta,rt,limits);},
  async restore(bytes,limits){if(rt.host)throw Error('restore during transaction');if(rt.busy)throw Error('restore requires transaction boundary');rt.busy=true;rt.ctx.fuel=100000000;observers.hold();let restored=false;try{const s=await __snapshotDecode(meta,bytes,limits);checkFixed(s.tables);const candidate={...rt,tables:__restoreTables(rt,prefixes,s.tables),version:__storedCommit(meta,s.version),outbox:s.outbox,keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);for(const name of meta.invariantChecks||[]){const a=actionMap.get(name);if(implementations[a.index](rt.ctx,candidate)!==true)throw Error('snapshot violates state invariant');}const previousTables=rt.tables;rt.tables=candidate.tables;rt.restoreSpares=previousTables.map(table=>table instanceof __DenseTable?table:null);rt.version=__storedCommit(meta,s.version);rt.outbox=__eventLog(meta,s.outbox);rt.keeps=candidate.keeps;rt.activeViewRoots=candidate.activeViewRoots;if(rt.snapshotRows)rt.snapshotRows=meta.roots.map(()=>new Map());rt.changeEpoch++;rt.changeLog.length=0;restored=true;}finally{rt.busy=false;if(restored)observers.commit(meta.roots.map((_,i)=>i));observers.release();}},
 });
}
function __action0(ctx,rt){__tick(ctx);try{__tick(ctx);const s0=__try(__fn36([1065353216,1065353216,1065353216,1065353216,1065353216,1065353216,1065353216,1065353216,1065353216,1065353216,1065353216,1065353216,1065353216,1065353216,1065353216,1065353216]));__tick(ctx);__tablePut(rt,2,0n,s0,0);__tick(ctx);return ({Ok:null});}catch(e){if(e instanceof __Abort)return ({Err:e.value});throw e;}}
function __action1(ctx,rt,s1,s2,s3){__tick(ctx);try{__tick(ctx);const s7=((s4)=>Object.hasOwn(s4,"Some")?((s5)=>((s5)["version"]))(s4["Some"]):((s6)=>(0))(null))(__tableGet(rt,3,0n));__tick(ctx);if(((!((s3===s7))) || (((s7===4294967295))))){__tick(ctx);return ({Err:"stale goal"});}else{}__tick(ctx);const s8=({["samples"]:s1,["instruction_cost"]:s2,["version"]:(((s7) + (1)) >>> 0)});__tick(ctx);if(((__fn2(s8)===false))){__tick(ctx);return ({Err:"goal domain"});}else{}__tick(ctx);__tablePut(rt,3,0n,s8,0);__tick(ctx);const s9=__try(__nested(__action0(ctx,rt),true));__tick(ctx);return ({Ok:(s8)["version"]});}catch(e){if(e instanceof __Abort)return ({Err:e.value});throw e;}}
function __action2(ctx,rt,s10,s11){__tick(ctx);try{__tick(ctx);if(((s12)=>Object.hasOwn(s12,"Some")?((s13)=>(__fn1(s10)))(s12["Some"]):((s14)=>(__fn1(s10)))(null))(({Some:null}))){__tick(ctx);__tablePut(rt,1,0n,s10,0);__tick(ctx);__emit(rt,"updated",s10);__tick(ctx);if(s11){__tick(ctx);return ({Err:"cancel coefficient update"});}else{}__tick(ctx);return ({Ok:null});}else{__tick(ctx);return ({Err:((s15)=>Object.hasOwn(s15,"Some")?((s16)=>("coefficient domain"))(s15["Some"]):((s17)=>("coefficient domain"))(null))(({Some:null}))});}}catch(e){if(e instanceof __Abort)return ({Err:e.value});throw e;}}
function __action3(ctx,rt,s18){__tick(ctx);__tick(ctx);const s19=((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,1,0n),({["scale"]:1061158912,["bias"]:1048576000}));const s20=s18;return __bits(__float(__fn46(s19,s20)) + __float(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,4,0n),0)));}
function __action4(ctx,rt){__tick(ctx);__tick(ctx);return ["Op.Bias","Op.Scale","Op.Identity","Op.Relu","Op.Bias","Op.Scale","Op.Identity","Op.Relu","Op.Bias","Op.Scale","Op.Identity","Op.Relu","Op.Bias","Op.Scale","Op.Identity","Op.Relu","Op.Bias","Op.Scale","Op.Identity","Op.Relu","Op.Bias","Op.Scale","Op.Identity","Op.Relu","Op.Bias","Op.Scale","Op.Identity","Op.Relu","Op.Bias","Op.Scale","Op.Identity","Op.Relu"];}
function __action5(ctx,rt){__tick(ctx);try{__tick(ctx);return __okOr(__tableGet(rt,2,0n),"initialize policy");}catch(e){if(e instanceof __Abort)return ({Err:e.value});throw e;}}
function __action6(ctx,rt){__tick(ctx);try{__tick(ctx);const s21=__try(__okOr(__tableGet(rt,3,0n),"initialize target"));__tick(ctx);if(((__fn2(s21)===false))){__tick(ctx);return ({Err:"goal domain"});}else{}__tick(ctx);return ({Ok:__fn50(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,1,0n),({["scale"]:1061158912,["bias"]:1048576000})),s21)});}catch(e){if(e instanceof __Abort)return ({Err:e.value});throw e;}}
function __action7(ctx,rt,s22){__tick(ctx);__tick(ctx);__tablePut(rt,4,0n,s22,0);__tick(ctx);return null;}
function __stateCommitRoot0(rt,key,prior,next,slot){__storeDirect(rt,0,key,prior,next,slot);const publish=rt.meta.outputPublication&&!rt.observers.directRoots[0]&&rt.observers.active;if(publish&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}}
function __stateCommitRoot1(rt,key,prior,next,slot){__storeDirect(rt,1,key,prior,next,slot);const publish=rt.meta.outputPublication&&!rt.observers.directRoots[1]&&rt.observers.active;if(publish&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}}
function __stateCommitRoot2(rt,key,prior,next,slot){__storeDirect(rt,2,key,prior,next,slot);const publish=rt.meta.outputPublication&&!rt.observers.directRoots[2]&&rt.observers.active;if(publish&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}}
function __stateCommitRoot3(rt,key,prior,next,slot){__storeDirect(rt,3,key,prior,next,slot);const publish=rt.meta.outputPublication&&!rt.observers.directRoots[3]&&rt.observers.active;if(publish&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}}
function __stateCommitRoot4(rt,key,prior,next,slot){__storeDirect(rt,4,key,prior,next,slot);const publish=rt.meta.outputPublication&&!rt.observers.directRoots[4]&&rt.observers.active;if(publish&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}}
const __stateDirectReadFactories=[null,null,null,null,null,null,null,null];
function __stateValueEqual3(a,b){if(a===b)return true;if(a.length!==b.length)return false;for(let i=0;i<a.length;i++)if(!((a[i]===b[i])))return false;return true;}
function __stateValueEqual5(a,b){if(a===b)return true;if(a.length!==b.length)return false;for(let i=0;i<a.length;i++)if(!(__stateValueEqual6(a[i],b[i])))return false;return true;}
function __stateValueEqual0(a,b){if(a===b)return true;if(a.length!==b.length)return false;for(let i=0;i<a.length;i++)if(!((a[i]===b[i])))return false;return true;}
function __stateValueEqual1(a,b){if(a===b)return true;return (a["scale"]===b["scale"])&&(a["bias"]===b["bias"]);}
function __stateValueEqual6(a,b){if(a===b)return true;return (a["input"]===b["input"])&&(a["target"]===b["target"]);}
function __stateValueEqual4(a,b){if(a===b)return true;return __stateValueEqual5(a["samples"],b["samples"])&&(a["instruction_cost"]===b["instruction_cost"])&&(a["version"]===b["version"]);}
function __stateValueEqual2(a,b){if(a===b)return true;return __stateValueEqual3(a["weights"],b["weights"])&&__stateValueEqual3(a["first"],b["first"])&&__stateValueEqual3(a["second"],b["second"])&&(a["steps"]===b["steps"])&&(a["first_power"]===b["first_power"])&&(a["second_power"]===b["second_power"]);}
function __stateValueEqual10(a,b){if(a===b)return true;const xv=a,yv=b,x=Object.hasOwn(xv,'Ok');return x===Object.hasOwn(yv,'Ok')&&(x?(xv.Ok===yv.Ok):(xv.Err===yv.Err));}
function __stateValueEqual8(a,b){if(a===b)return true;const xv=a,yv=b,x=Object.hasOwn(xv,'Ok');return x===Object.hasOwn(yv,'Ok')&&(x?(xv.Ok===yv.Ok):(xv.Err===yv.Err));}
function __stateValueEqual7(a,b){if(a===b)return true;const xv=a,yv=b,x=Object.hasOwn(xv,'Ok');return x===Object.hasOwn(yv,'Ok')&&(x?(xv.Ok===yv.Ok):(xv.Err===yv.Err));}
function __stateValueEqual9(a,b){if(a===b)return true;const xv=a,yv=b,x=Object.hasOwn(xv,'Ok');return x===Object.hasOwn(yv,'Ok')&&(x?__stateValueEqual2(xv.Ok,yv.Ok):(xv.Err===yv.Err));}
function __ownedInput0(value,budget={cells:1000000},depth=0,maxDepth=64){if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=__ownedInput1(value[i],budget,depth+1,maxDepth);return out;}
function __ownedInput7(value,budget={cells:1000000},depth=0,maxDepth=64){if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=__ownedInput8(value[i],budget,depth+1,maxDepth);return out;}
function __ownedInput1(value,budget={cells:1000000},depth=0,maxDepth=64){if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,"input")||!Object.hasOwn(value,"target"))throw Error('invalid record');const field0=__ownedInput2(value["input"],budget,depth+1,maxDepth);const field1=__ownedInput2(value["target"],budget,depth+1,maxDepth);return {["input"]:field0,["target"]:field1};}
function __ownedInput4(value,budget={cells:1000000},depth=0,maxDepth=64){if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,"scale")||!Object.hasOwn(value,"bias"))throw Error('invalid record');const field0=__ownedInput2(value["scale"],budget,depth+1,maxDepth);const field1=__ownedInput2(value["bias"],budget,depth+1,maxDepth);return {["scale"]:field0,["bias"]:field1};}
function __ownedInput5(value,budget={cells:1000000},depth=0,maxDepth=64){let scalar=value;if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(typeof scalar!=='boolean')throw Error('invalid Bool');return scalar;}
const __ownedType8={"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]};
function __ownedInput8(value,budget={cells:1000000},depth=0,maxDepth=64){return __stateInput(value,__ownedType8,budget,depth,maxDepth);}
const __ownedType2={"kind":"f32"};
function __ownedInput2(value,budget={cells:1000000},depth=0,maxDepth=64){return __stateInput(value,__ownedType2,budget,depth,maxDepth);}
function __ownedInput3(value,budget={cells:1000000},depth=0,maxDepth=64){let scalar=value;if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(typeof scalar!=='number'||!Number.isInteger(scalar)||scalar<0||scalar>4294967295)throw Error('invalid u32');if(scalar===0)scalar=0;return scalar;}
function __ownedInput6(value,budget={cells:1000000},depth=0,maxDepth=64){let scalar=value;if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');scalar=__stateWord(scalar);return scalar;}
const __stateFrozenFactories=[()=>new Map(JSON.parse("[[\"0\",[\"Op.Bias\",\"Op.Scale\",\"Op.Identity\",\"Op.Relu\",\"Op.Bias\",\"Op.Scale\",\"Op.Identity\",\"Op.Relu\",\"Op.Bias\",\"Op.Scale\",\"Op.Identity\",\"Op.Relu\",\"Op.Bias\",\"Op.Scale\",\"Op.Identity\",\"Op.Relu\",\"Op.Bias\",\"Op.Scale\",\"Op.Identity\",\"Op.Relu\",\"Op.Bias\",\"Op.Scale\",\"Op.Identity\",\"Op.Relu\",\"Op.Bias\",\"Op.Scale\",\"Op.Identity\",\"Op.Relu\",\"Op.Bias\",\"Op.Scale\",\"Op.Identity\",\"Op.Relu\"]]]").map(([k,v])=>[__ownedInput6(k,{cells:1000000},0,128),__ownedInput7(v,{cells:1000000},0,128)])),null,null,null,null];
const __stateQueryEquals=[(a,b)=>__stateValueEqual7(a,b),(a,b)=>__stateValueEqual8(a,b),(a,b)=>__stateValueEqual7(a,b),(a,b)=>(a===b),(a,b)=>__stateValueEqual0(a,b),(a,b)=>__stateValueEqual9(a,b),(a,b)=>__stateValueEqual10(a,b),(a,b)=>(a===b)];
const __stateRootEquals=[(a,b)=>__stateValueEqual0(a,b),(a,b)=>__stateValueEqual1(a,b),(a,b)=>__stateValueEqual2(a,b),(a,b)=>__stateValueEqual4(a,b),(a,b)=>(a===b)];
const __stateBoundFactories=[(run,a,inputs,output,only,rt,begin,complete,abort,end)=>a.precondition?()=>run(a,[],null,output,only,true):()=>{begin(a);try{return complete(a,__action0(rt.ctx,rt),output,only);}catch(e){return abort(e);}finally{end();}},(run,a,inputs,output,only,rt,begin,complete,abort,end)=>a.precondition?(p0,p1,p2)=>run(a,[inputs[0](p0),inputs[1](p1),inputs[2](p2)],null,output,only,true):(p0,p1,p2)=>{const b0=inputs[0](p0);const b1=inputs[1](p1);const b2=inputs[2](p2);begin(a);try{return complete(a,__action1(rt.ctx,rt,b0,b1,b2),output,only);}catch(e){return abort(e);}finally{end();}},(run,a,inputs,output,only,rt,begin,complete,abort,end)=>a.precondition?(p0,p1)=>run(a,[inputs[0](p0),inputs[1](p1)],null,output,only,true):(p0,p1)=>{const b0=inputs[0](p0);const b1=inputs[1](p1);begin(a);try{return complete(a,__action2(rt.ctx,rt,b0,b1),output,only);}catch(e){return abort(e);}finally{end();}},(run,a,inputs,output,only)=>(p0)=>run(a,[inputs[0](p0)],null,output,only,true),(run,a,inputs,output,only)=>()=>run(a,[],null,output,only,true),(run,a,inputs,output,only)=>()=>run(a,[],null,output,only,true),(run,a,inputs,output,only)=>()=>run(a,[],null,output,only,true),(run,a,inputs,output,only,rt,begin,complete,abort,end)=>a.precondition?(p0)=>run(a,[inputs[0](p0)],null,output,only,true):(p0)=>{const b0=inputs[0](p0);begin(a);try{return complete(a,__action7(rt.ctx,rt,b0),output,only);}catch(e){return abort(e);}finally{end();}}];const __statePreflightFactories=[null,null,null,null,null,null,null,null];
const __stateMetadata={"actions":[{"change":true,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":true,"index":0,"name":"initialize","params":[],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"unit"}},"roots":[2],"singleCell":true},{"change":true,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":true,"index":1,"name":"retarget","params":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}},{"name":"expected","type":{"kind":"u32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"u32"}},"roots":[2,3],"singleCell":false},{"change":true,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":true,"index":2,"name":"retune","params":[{"name":"w","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"name":"fail","type":{"kind":"bool"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"unit"}},"roots":[1],"singleCell":true},{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":3,"name":"serve","params":[{"name":"input","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"},"roots":[1,4],"singleCell":true},{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":4,"name":"structure","params":[],"precondition":null,"result":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"},"roots":[],"singleCell":true},{"change":false,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":false,"index":5,"name":"policy","params":[],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}},"roots":[2],"singleCell":true},{"change":false,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":false,"index":6,"name":"loss","params":[],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"f32"}},"roots":[1,3],"singleCell":true},{"change":true,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":true,"index":7,"name":"set_live","params":[{"name":"value","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"unit"},"roots":[4],"singleCell":true}],"compactCommits":false,"eventColumns":false,"eventRuns":false,"events":[{"name":"searched","snapshotType":{"fields":[{"name":"step","type":{"kind":"u32"}},{"name":"loss","type":{"kind":"f32"}},{"name":"best","type":{"kind":"f32"}},{"name":"accepted","type":{"kind":"bool"}},{"name":"goal_version","type":{"kind":"u32"}}],"kind":"record"},"type":{"fields":[{"name":"step","type":{"kind":"u32"}},{"name":"loss","type":{"kind":"f32"}},{"name":"best","type":{"kind":"f32"}},{"name":"accepted","type":{"kind":"bool"}},{"name":"goal_version","type":{"kind":"u32"}}],"kind":"record","name":"Report"}},{"name":"updated","snapshotType":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record"},"type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}}],"invariantChecks":[],"keepInvalidations":[[],[],[],[],[]],"keeps":[],"lazyMaintenance":true,"outputPublication":false,"roots":[{"key":{"kind":"u64"},"name":"Structure","snapshotKey":{"kind":"u64"},"snapshotValue":{"element":{"kind":"enum","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"},"value":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"key":{"kind":"u64"},"name":"Weights","snapshotKey":{"kind":"u64"},"snapshotValue":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record"},"value":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"key":{"kind":"u64"},"name":"Policy","snapshotKey":{"kind":"u64"},"snapshotValue":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record"},"value":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}},{"key":{"kind":"u64"},"name":"Target","snapshotKey":{"kind":"u64"},"snapshotValue":{"fields":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}},{"name":"version","type":{"kind":"u32"}}],"kind":"record"},"value":{"fields":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}},{"name":"version","type":{"kind":"u32"}}],"kind":"record","name":"Goal"}},{"key":{"kind":"u64"},"name":"Live","snapshotKey":{"kind":"u64"},"snapshotValue":{"kind":"f32"},"value":{"kind":"f32"}}],"snapshot":{"program":[34,168,241,192,77,41,134,232,114,211,106,193,129,135,41,54,152,99,7,5,83,166,18,186,134,73,243,196,247,61,233,172],"schema":[149,165,81,3,148,102,162,137,208,7,109,190,54,120,1,205,251,216,108,170,252,52,34,249,135,101,48,190,172,82,37,69]},"snapshotRows":false};const __actions=[__action0,__action1,__action2,__action3,__action4,__action5,__action6,__action7];const __stateInputCaptures=[[],[__ownedInput0,__ownedInput2,__ownedInput3],[__ownedInput4,__ownedInput5],[__ownedInput2],[],[],[],[__ownedInput2]];
export function createState(){return __createState(__stateMetadata,__actions,__stateInputCaptures);}
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v14","core_sha256":"a4ff3fcb9ff8bb758d4a0d203990b24bc89792c48dcbfb17bd82a08303575c35","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"f32_storage":"exact-u32-bits","functions":[{"destination":null,"index":0,"internal":false,"name":"evaluate","parallel":false,"params":[{"name":"code","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"w","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"name":"input","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":1,"internal":false,"name":"coefficients_valid","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":null,"index":2,"internal":false,"name":"goal_valid","parallel":false,"params":[{"name":"g","type":{"fields":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}},{"name":"version","type":{"kind":"u32"}}],"kind":"record","name":"Goal"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":null,"index":3,"internal":false,"name":"squared_error","parallel":false,"params":[{"name":"code","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"w","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"name":"s","type":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":4,"internal":false,"name":"objective","parallel":false,"params":[{"name":"code","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"w","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"name":"g","type":{"fields":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}},{"name":"version","type":{"kind":"u32"}}],"kind":"record","name":"Goal"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":5,"internal":false,"name":"unpack","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":6,"internal":false,"name":"pack","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":7,"internal":false,"name":"mass","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}},{"name":"p","type":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"Pick"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":8,"internal":false,"name":"operation","parallel":false,"params":[{"name":"index","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]}},{"destination":null,"index":9,"internal":false,"name":"distribution","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}},{"name":"slot","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"derivatives","type":{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"}}],"kind":"record","name":"Distribution"}},{"destination":null,"index":10,"internal":false,"name":"sample_slot","parallel":false,"params":[{"name":"accumulator","type":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"choices","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}],"kind":"record","name":"Building"}}},{"name":"slot","type":{"kind":"u32"}},{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}},{"name":"units","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"choices","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}],"kind":"record","name":"Building"}}},{"destination":null,"index":11,"internal":false,"name":"sample","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"units","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"code","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}],"kind":"record","name":"Sampled"}}},{"destination":null,"index":12,"internal":false,"name":"reward","parallel":false,"params":[{"name":"loss","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":13,"internal":false,"name":"operation_index","parallel":false,"params":[{"name":"op","type":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]}}],"precondition":null,"result":{"kind":"u32"}},{"destination":null,"index":14,"internal":false,"name":"elite_slot","parallel":false,"params":[{"name":"accumulator","type":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}},{"name":"slot","type":{"kind":"u32"}},{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}},{"name":"code","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}},{"destination":null,"index":15,"internal":false,"name":"proposal_gradient","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"selected","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"sampled","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}},{"name":"loss","type":{"kind":"f32"}},{"name":"before","type":{"kind":"f32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"destination":null,"index":16,"internal":false,"name":"valid_policy","parallel":false,"params":[{"name":"p","type":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":17,"internal":false,"name":"numeric","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":18,"internal":false,"name":"ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":null,"index":19,"internal":false,"name":"ink_m28a5428efa573345218636e9cec104f24b6e8c67d7c4c0f979b255813b2abee3","parallel":false,"params":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"allowed","type":{"element":{"kind":"bool"},"kind":"list"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":20,"internal":false,"name":"ink_mfd18151b0af45b45f5b48ef5e7a09ac1294681f654e2174ae3b33183f445ef14","parallel":false,"params":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"allowed","type":{"element":{"kind":"bool"},"kind":"list"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"destination":null,"index":21,"internal":false,"name":"ink_mc05a2256079ef1f1818d13e69727dc7902cdb7f70856a671af2ba08ef190d23a","parallel":false,"params":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"allowed","type":{"element":{"kind":"bool"},"kind":"list"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"destination":null,"index":22,"internal":false,"name":"ink_m6ec6e8f9e757c220bfe2ed28cbb8dab4ec520de5ee8de5ca702cbdb805a5f910","parallel":false,"params":[{"name":"scaled","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"unit","type":{"kind":"f32"}},{"name":"total","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"u32"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":23,"internal":false,"name":"ink_maa2c8802d351b443dda0bc206d70fa9fe87756b57a84d0357e9dfb4c1e7a0667","parallel":false,"params":[{"name":"derivatives","type":{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"}},{"name":"allowed","type":{"element":{"kind":"bool"},"kind":"list"}},{"name":"maximum","type":{"kind":"f32"}},{"name":"total","type":{"kind":"f32"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":24,"internal":false,"name":"ink_m1774c4db693eebe71b1f79bce053b93633d1e1ec37196dd480b59c0248b4fbc2","parallel":false,"params":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"derivatives","type":{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"}},{"name":"allowed","type":{"element":{"kind":"bool"},"kind":"list"}},{"name":"total","type":{"kind":"f32"}},{"name":"selected","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":25,"internal":false,"name":"ink_m1fbf7ee6cef3bcca5d7d258c8606275806894b60d839126202d17f016ea87c80","parallel":false,"params":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"derivatives","type":{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"}},{"name":"allowed","type":{"element":{"kind":"bool"},"kind":"list"}},{"name":"unit","type":{"kind":"f32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"}}},{"destination":null,"index":26,"internal":false,"name":"ink_m99468fca85aa8fb996f0c891430c813d82505250d39d8e415bf27679ddc39e07","parallel":false,"params":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"derivatives","type":{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"}},{"name":"allowed","type":{"element":{"kind":"bool"},"kind":"list"}},{"name":"action","type":{"kind":"u32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"}}},{"destination":null,"index":27,"internal":false,"name":"ink_maadd6c30a027af52d851f0828eec45339d218ad3bbe73e4d8d7cdd3892e754f4","parallel":false,"params":[{"name":"decision","type":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"}},{"name":"return_value","type":{"kind":"f32"}},{"name":"baseline","type":{"kind":"f32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"destination":null,"index":28,"internal":false,"name":"ink_m696809152e57d8dfa3f01f9a3e12c048434b9f2af91ff53321ea6ceeeeca5431","parallel":false,"params":[{"name":"accumulator","type":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"name":"decision","type":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"}},{"name":"return_value","type":{"kind":"f32"}},{"name":"baseline","type":{"kind":"f32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"destination":null,"index":29,"internal":false,"name":"ink_m372cbaf2ee2bc8705fad4b5b65a9e744ea468afbe4c153f17c7da282a459d1cd","parallel":false,"params":[{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}},{"name":"return_values","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"baselines","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"destination":null,"index":30,"internal":false,"name":"ink_m43c1e2ac4d6d9a37358654ff5c1abcd42d4b01146c41a7ca617bccb074a8813b","parallel":false,"params":[{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}},{"name":"return_values","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"baselines","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"destination":null,"index":31,"internal":false,"name":"ink_m4b5ada8f7d6b3beaee6fc06bf68e61ca158cbc7664899364dff18d21555697ae","parallel":false,"params":[{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}},{"name":"return_value","type":{"kind":"f32"}},{"name":"baseline","type":{"kind":"f32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"destination":null,"index":32,"internal":false,"name":"ink_mda500f665e6078213ee2391fedf06240c651d1725327b086aa70cda14bef9a07","parallel":false,"params":[{"name":"rewards","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"discount","type":{"kind":"f32"}},{"name":"bootstrap","type":{"kind":"f32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"destination":null,"index":33,"internal":false,"name":"ink_meefc22a28d97f5bdc4100b36eeab9549241c3ef201b83c2f75111644d317833d","parallel":false,"params":[{"name":"rate","type":{"kind":"f32"}}],"precondition":null,"result":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}},{"name":"weight_decay","type":{"kind":"f32"}},{"name":"norm_limit","type":{"kind":"f32"}}],"kind":"record","name":"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249"}},{"destination":null,"index":34,"internal":false,"name":"ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":null,"index":35,"internal":false,"name":"ink_m786bdc6011aece08dbf36c5ca89c437e06ff758c9d3d242f723dde2af6ea31db","parallel":false,"params":[{"name":"state","type":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":null,"index":36,"internal":false,"name":"ink_mdfbd57a9f460147afedb262e2bfe0f6197f9b813c85277c59f5e101900063ad7","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}}},{"destination":null,"index":37,"internal":false,"name":"ink_m5226ad25deae5e47d7fb65b6b5961d46740dd4e97b54d76a24d3d0445845fe35","parallel":false,"params":[{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}},{"name":"weight_decay","type":{"kind":"f32"}},{"name":"norm_limit","type":{"kind":"f32"}}],"kind":"record","name":"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":null,"index":38,"internal":false,"name":"ink_m8abb6b2bcbe55251e0b82a28f26d7ce761729346e35019c2b60ca9b5ee22590d","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":39,"internal":false,"name":"ink_m7d03a2ed6071238ff1b69a8e56a8cb96b9dc3b095b2d939c0ccfed84ee9580b5","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"limit","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":40,"internal":false,"name":"ink_m00ba8185ca362d257d138fe1886cbc5f3acc38c4a238bef60c3d3d7fa0276eab","parallel":false,"params":[{"name":"weight","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}},{"name":"weight_decay","type":{"kind":"f32"}},{"name":"norm_limit","type":{"kind":"f32"}}],"kind":"record","name":"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":41,"internal":false,"name":"ink_m2a55f95a80595bc61d1fcab41ff00f438ff6f2057b597df20aaae3c18507d2be","parallel":false,"params":[{"name":"state","type":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}},{"name":"weight_decay","type":{"kind":"f32"}},{"name":"norm_limit","type":{"kind":"f32"}}],"kind":"record","name":"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}}},{"destination":null,"index":42,"internal":false,"name":"__ink_differential_3","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"}},{"name":"p","type":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_6"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"destination":null,"index":43,"internal":false,"name":"__ink_differential_1","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}},{"name":"p","type":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"Pick"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}},{"destination":null,"index":44,"internal":false,"name":"__frozen_proposal_3","parallel":false,"params":[{"name":"__frozen_proposal_1","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"name":"__frozen_proposal_7","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":45,"internal":false,"name":"__frozen_proposal_43","parallel":false,"params":[{"name":"__frozen_proposal_1","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"name":"__frozen_proposal_44","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":46,"internal":false,"name":"__frozen_proposal_49","parallel":false,"params":[{"name":"__frozen_proposal_1","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"name":"__frozen_proposal_50","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":47,"internal":false,"name":"__frozen_proposal_110","parallel":false,"params":[{"name":"__frozen_proposal_114","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":48,"internal":false,"name":"__frozen_proposal_150","parallel":false,"params":[{"name":"__frozen_proposal_151","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":49,"internal":false,"name":"__frozen_proposal_156","parallel":false,"params":[{"name":"__frozen_proposal_157","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":50,"internal":false,"name":"__frozen_proposal_166","parallel":false,"params":[{"name":"__frozen_proposal_53","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"name":"__frozen_proposal_54","type":{"fields":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}},{"name":"version","type":{"kind":"u32"}}],"kind":"record","name":"Goal"}}],"precondition":null,"result":{"kind":"f32"}}],"named_types":{"Building":{"fields":[{"name":"choices","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}],"kind":"record","name":"Building"},"Coefficients":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"},"Distribution":{"fields":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"derivatives","type":{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"}}],"kind":"record","name":"Distribution"},"Example":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"Goal":{"fields":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}},{"name":"version","type":{"kind":"u32"}}],"kind":"record","name":"Goal"},"MassRow":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"},"Parameters":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"},"Pick":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"Pick"},"Report":{"fields":[{"name":"step","type":{"kind":"u32"}},{"name":"loss","type":{"kind":"f32"}},{"name":"best","type":{"kind":"f32"}},{"name":"accepted","type":{"kind":"bool"}},{"name":"goal_version","type":{"kind":"u32"}}],"kind":"record","name":"Report"},"Sampled":{"fields":[{"name":"code","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}],"kind":"record","name":"Sampled"},"__ink_differential_0":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"__ink_differential_2":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"},"__ink_differential_4":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"},"__ink_differential_5":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"},"__ink_differential_6":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_6"},"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_17":{"fields":[{"name":"i","type":{"kind":"u32"}},{"name":"out","type":{"kind":"temporary"}}],"kind":"record","name":"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_17"},"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_36":{"fields":[{"name":"accumulated","type":{"kind":"f32"}},{"name":"found","type":{"kind":"bool"}},{"name":"i","type":{"kind":"u32"}},{"name":"selected","type":{"kind":"u32"}}],"kind":"record","name":"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_36"},"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_5":{"fields":[{"name":"i","type":{"kind":"u32"}},{"name":"maximum","type":{"kind":"f32"}}],"kind":"record","name":"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_5"},"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_52":{"fields":[{"name":"correction","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"i","type":{"kind":"u32"}}],"kind":"record","name":"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_52"},"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_72":{"fields":[{"name":"accumulator","type":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"name":"i","type":{"kind":"u32"}}],"kind":"record","name":"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_72"},"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_87":{"fields":[{"name":"i","type":{"kind":"u32"}},{"name":"next","type":{"kind":"f32"}},{"name":"reversed","type":{"kind":"temporary"}}],"kind":"record","name":"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_87"},"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_99":{"fields":[{"name":"i","type":{"kind":"u32"}},{"name":"out","type":{"kind":"temporary"}}],"kind":"record","name":"__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_99"},"__ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_24":{"fields":[{"name":"first","type":{"kind":"temporary"}},{"name":"i","type":{"kind":"u32"}},{"name":"second","type":{"kind":"temporary"}},{"name":"weights","type":{"kind":"temporary"}}],"kind":"record","name":"__ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_24"},"__ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_5":{"fields":[{"name":"adjusted","type":{"kind":"temporary"}},{"name":"i","type":{"kind":"u32"}}],"kind":"record","name":"__ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_5"},"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}},{"name":"weight_decay","type":{"kind":"f32"}},{"name":"norm_limit","type":{"kind":"f32"}}],"kind":"record","name":"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249"},"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}},"prepared_compiled":{"evaluation":"lazy source-order; successful bindings only","functions":[{"factory":false,"function":"evaluate","reason":"no reusable captured work"},{"factory":false,"function":"coefficients_valid","reason":"no reusable captured work"},{"factory":false,"function":"goal_valid","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"squared_error","retained_bindings":1},{"delegated_calls":0,"factory":true,"function":"objective","retained_bindings":2},{"factory":false,"function":"unpack","reason":"no reusable captured work"},{"factory":false,"function":"pack","reason":"no reusable captured work"},{"factory":false,"function":"mass","reason":"no reusable captured work"},{"factory":false,"function":"operation","reason":"no reusable captured work"},{"delegated_calls":4,"factory":true,"function":"distribution","retained_bindings":0},{"delegated_calls":2,"factory":true,"function":"sample_slot","retained_bindings":1},{"delegated_calls":0,"factory":true,"function":"sample","retained_bindings":2},{"factory":false,"function":"reward","reason":"no reusable captured work"},{"factory":false,"function":"operation_index","reason":"no reusable captured work"},{"delegated_calls":2,"factory":true,"function":"elite_slot","retained_bindings":1},{"delegated_calls":2,"factory":true,"function":"proposal_gradient","retained_bindings":1},{"factory":false,"function":"valid_policy","reason":"no reusable captured work"},{"factory":false,"function":"numeric","reason":"no reusable captured work"},{"factory":false,"function":"ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"ink_m28a5428efa573345218636e9cec104f24b6e8c67d7c4c0f979b255813b2abee3","retained_bindings":1},{"delegated_calls":1,"factory":true,"function":"ink_mfd18151b0af45b45f5b48ef5e7a09ac1294681f654e2174ae3b33183f445ef14","retained_bindings":2},{"delegated_calls":1,"factory":true,"function":"ink_mc05a2256079ef1f1818d13e69727dc7902cdb7f70856a671af2ba08ef190d23a","retained_bindings":1},{"delegated_calls":0,"factory":true,"function":"ink_m6ec6e8f9e757c220bfe2ed28cbb8dab4ec520de5ee8de5ca702cbdb805a5f910","retained_bindings":1},{"delegated_calls":0,"factory":true,"function":"ink_maa2c8802d351b443dda0bc206d70fa9fe87756b57a84d0357e9dfb4c1e7a0667","retained_bindings":2},{"delegated_calls":2,"factory":true,"function":"ink_m1774c4db693eebe71b1f79bce053b93633d1e1ec37196dd480b59c0248b4fbc2","retained_bindings":2},{"delegated_calls":3,"factory":true,"function":"ink_m1fbf7ee6cef3bcca5d7d258c8606275806894b60d839126202d17f016ea87c80","retained_bindings":6},{"delegated_calls":2,"factory":true,"function":"ink_m99468fca85aa8fb996f0c891430c813d82505250d39d8e415bf27679ddc39e07","retained_bindings":5},{"delegated_calls":0,"factory":true,"function":"ink_maadd6c30a027af52d851f0828eec45339d218ad3bbe73e4d8d7cdd3892e754f4","retained_bindings":3},{"delegated_calls":1,"factory":true,"function":"ink_m696809152e57d8dfa3f01f9a3e12c048434b9f2af91ff53321ea6ceeeeca5431","retained_bindings":2},{"delegated_calls":0,"factory":true,"function":"ink_m372cbaf2ee2bc8705fad4b5b65a9e744ea468afbe4c153f17c7da282a459d1cd","retained_bindings":3},{"delegated_calls":1,"factory":true,"function":"ink_m43c1e2ac4d6d9a37358654ff5c1abcd42d4b01146c41a7ca617bccb074a8813b","retained_bindings":0},{"delegated_calls":1,"factory":true,"function":"ink_m4b5ada8f7d6b3beaee6fc06bf68e61ca158cbc7664899364dff18d21555697ae","retained_bindings":0},{"delegated_calls":0,"factory":true,"function":"ink_mda500f665e6078213ee2391fedf06240c651d1725327b086aa70cda14bef9a07","retained_bindings":2},{"factory":false,"function":"ink_meefc22a28d97f5bdc4100b36eeab9549241c3ef201b83c2f75111644d317833d","reason":"no reusable captured work"},{"factory":false,"function":"ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96","reason":"no reusable captured work"},{"factory":false,"function":"ink_m786bdc6011aece08dbf36c5ca89c437e06ff758c9d3d242f723dde2af6ea31db","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"ink_mdfbd57a9f460147afedb262e2bfe0f6197f9b813c85277c59f5e101900063ad7","retained_bindings":2},{"factory":false,"function":"ink_m5226ad25deae5e47d7fb65b6b5961d46740dd4e97b54d76a24d3d0445845fe35","reason":"no reusable captured work"},{"factory":false,"function":"ink_m8abb6b2bcbe55251e0b82a28f26d7ce761729346e35019c2b60ca9b5ee22590d","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"ink_m7d03a2ed6071238ff1b69a8e56a8cb96b9dc3b095b2d939c0ccfed84ee9580b5","retained_bindings":2},{"factory":false,"function":"ink_m00ba8185ca362d257d138fe1886cbc5f3acc38c4a238bef60c3d3d7fa0276eab","reason":"no reusable captured work"},{"delegated_calls":1,"factory":true,"function":"ink_m2a55f95a80595bc61d1fcab41ff00f438ff6f2057b597df20aaae3c18507d2be","retained_bindings":5},{"delegated_calls":0,"factory":true,"function":"__ink_differential_3","retained_bindings":2},{"delegated_calls":1,"factory":true,"function":"__ink_differential_1","retained_bindings":1},{"factory":false,"function":"__frozen_proposal_3","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"__frozen_proposal_43","retained_bindings":1},{"delegated_calls":2,"factory":true,"function":"__frozen_proposal_49","retained_bindings":1},{"factory":false,"function":"__frozen_proposal_110","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"__frozen_proposal_150","retained_bindings":1},{"delegated_calls":2,"factory":true,"function":"__frozen_proposal_156","retained_bindings":1},{"delegated_calls":0,"factory":true,"function":"__frozen_proposal_166","retained_bindings":1}],"lifetime":"prepared token","semantics":"sealed-value-residual-v1"},"private_record_elisions":[],"private_sum_spines":[],"schema":1,"state":{"actions":[{"change":true,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":true,"index":0,"name":"initialize","params":[],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"unit"}},"roots":[2],"singleCell":true},{"change":true,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":true,"index":1,"name":"retarget","params":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}},{"name":"expected","type":{"kind":"u32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"u32"}},"roots":[2,3],"singleCell":false},{"change":true,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":true,"index":2,"name":"retune","params":[{"name":"w","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"name":"fail","type":{"kind":"bool"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"unit"}},"roots":[1],"singleCell":true},{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":3,"name":"serve","params":[{"name":"input","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"},"roots":[1,4],"singleCell":true},{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":4,"name":"structure","params":[],"precondition":null,"result":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"},"roots":[],"singleCell":true},{"change":false,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":false,"index":5,"name":"policy","params":[],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}},"roots":[2],"singleCell":true},{"change":false,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":false,"index":6,"name":"loss","params":[],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"f32"}},"roots":[1,3],"singleCell":true},{"change":true,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":true,"index":7,"name":"set_live","params":[{"name":"value","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"unit"},"roots":[4],"singleCell":true}],"compactCommits":false,"eventColumns":false,"eventRuns":false,"events":[{"name":"searched","snapshotType":{"fields":[{"name":"step","type":{"kind":"u32"}},{"name":"loss","type":{"kind":"f32"}},{"name":"best","type":{"kind":"f32"}},{"name":"accepted","type":{"kind":"bool"}},{"name":"goal_version","type":{"kind":"u32"}}],"kind":"record"},"type":{"fields":[{"name":"step","type":{"kind":"u32"}},{"name":"loss","type":{"kind":"f32"}},{"name":"best","type":{"kind":"f32"}},{"name":"accepted","type":{"kind":"bool"}},{"name":"goal_version","type":{"kind":"u32"}}],"kind":"record","name":"Report"}},{"name":"updated","snapshotType":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record"},"type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}}],"invariantChecks":[],"keepInvalidations":[[],[],[],[],[]],"keeps":[],"lazyMaintenance":true,"outputPublication":false,"roots":[{"key":{"kind":"u64"},"name":"Structure","snapshotKey":{"kind":"u64"},"snapshotValue":{"element":{"kind":"enum","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"},"value":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"key":{"kind":"u64"},"name":"Weights","snapshotKey":{"kind":"u64"},"snapshotValue":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record"},"value":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"key":{"kind":"u64"},"name":"Policy","snapshotKey":{"kind":"u64"},"snapshotValue":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record"},"value":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}},{"key":{"kind":"u64"},"name":"Target","snapshotKey":{"kind":"u64"},"snapshotValue":{"fields":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}},{"name":"version","type":{"kind":"u32"}}],"kind":"record"},"value":{"fields":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}},{"name":"version","type":{"kind":"u32"}}],"kind":"record","name":"Goal"}},{"key":{"kind":"u64"},"name":"Live","snapshotKey":{"kind":"u64"},"snapshotValue":{"kind":"f32"},"value":{"kind":"f32"}}],"snapshot":{"program":[34,168,241,192,77,41,134,232,114,211,106,193,129,135,41,54,152,99,7,5,83,166,18,186,134,73,243,196,247,61,233,172],"schema":[149,165,81,3,148,102,162,137,208,7,109,190,54,120,1,205,251,216,108,170,252,52,34,249,135,101,48,190,172,82,37,69]},"snapshotRows":false},"wire":{"format":"ink-value-wire-v1","functions":{"__frozen_proposal_110":{"arguments":{"format":"ink-value-wire-v1","identity":"94b7b47883b5592dbc005f529c85144231563d0271867c968488e2853ca9e436","named":{},"root":{"fields":[{"name":"__frozen_proposal_114","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"__frozen_proposal_150":{"arguments":{"format":"ink-value-wire-v1","identity":"d4c4c67e233aa6a4f8cdab3d8c161d42f20b89ec0305b90cdde96d6e9fa3e89a","named":{},"root":{"fields":[{"name":"__frozen_proposal_151","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"__frozen_proposal_156":{"arguments":{"format":"ink-value-wire-v1","identity":"2c4e67e3d5c8a71e0d893777256de2c5cdd68b9b7636842a4e3da619ae9b55d8","named":{},"root":{"fields":[{"name":"__frozen_proposal_157","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"__frozen_proposal_166":{"arguments":{"format":"ink-value-wire-v1","identity":"bc646f849d47d7a3f5e33b3f512a68c871646765738dd8635684631eb2c07756","named":{},"root":{"fields":[{"name":"__frozen_proposal_53","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"name":"__frozen_proposal_54","type":{"fields":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}},{"name":"version","type":{"kind":"u32"}}],"kind":"record","name":"Goal"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"__frozen_proposal_3":{"arguments":{"format":"ink-value-wire-v1","identity":"d8496a1dfc631243d68cdf58c44796bddc0819c97bc4eb4c00dd96cc302938a7","named":{},"root":{"fields":[{"name":"__frozen_proposal_1","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"name":"__frozen_proposal_7","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"__frozen_proposal_43":{"arguments":{"format":"ink-value-wire-v1","identity":"97ac925ad8664eaa6feebd807fd9bcc73be16150cb94a47e344c82a0b07c764a","named":{},"root":{"fields":[{"name":"__frozen_proposal_1","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"name":"__frozen_proposal_44","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"__frozen_proposal_49":{"arguments":{"format":"ink-value-wire-v1","identity":"2e40cf94e1cfa20ca96e07ab6184d6da87b7e0037babd42d7ef2bab7ca498d1c","named":{},"root":{"fields":[{"name":"__frozen_proposal_1","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"name":"__frozen_proposal_50","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"__ink_differential_1":{"arguments":{"format":"ink-value-wire-v1","identity":"d9a2817b6f5795592e5f12e4e54fd3af0061b7a04d8d3e55dd63c3a2e7b0558e","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}},{"name":"p","type":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"Pick"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"2af269616d48554c4ef5e8a1371afd52412f1ef4f05c2d9506bd43bfde5de326","named":{},"root":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}}},"__ink_differential_3":{"arguments":{"format":"ink-value-wire-v1","identity":"d75895cfaa56f5921632cb59e1d374ad909ca98b00fd2271f993b80ac8cdcc66","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"}},{"name":"p","type":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_6"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"cfdb397c2afc9c623de1f1010b9630cbab4a4f82a83884720c53cd04425275d8","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}},"coefficients_valid":{"arguments":{"format":"ink-value-wire-v1","identity":"2e1de3e6be85620514132feea03f80ad75ab3cacb5ac40c3715611efdc2a8a0a","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"distribution":{"arguments":{"format":"ink-value-wire-v1","identity":"28045a638724bf195eaa2c13edf966d6b852033c3212b0f890b11d2bed0a4ee0","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}},{"name":"slot","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"b58490b582e9db511b7d71c575e602c19fd38a9ce66a06065b482246605c09a9","named":{},"root":{"fields":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"derivatives","type":{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"}}],"kind":"record","name":"Distribution"}}},"elite_slot":{"arguments":{"format":"ink-value-wire-v1","identity":"ad037cb953c14f4fb546dd767f1a0d45caa23b80c581c77178aac95484198504","named":{},"root":{"fields":[{"name":"accumulator","type":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}},{"name":"slot","type":{"kind":"u32"}},{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}},{"name":"code","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"e1b825ef360a6557af5947d501dffff13bf6e9d8532025b04e5cd262660ad2e7","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}}},"evaluate":{"arguments":{"format":"ink-value-wire-v1","identity":"714e94324647680288585f759fac356df2eb522ea46759364d96efb96203f7af","named":{},"root":{"fields":[{"name":"code","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"w","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"name":"input","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"goal_valid":{"arguments":{"format":"ink-value-wire-v1","identity":"6731468a2fe00d1d59bf0460836be4378e76c6a0830598d58adbf633e915b120","named":{},"root":{"fields":[{"name":"g","type":{"fields":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}},{"name":"version","type":{"kind":"u32"}}],"kind":"record","name":"Goal"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"ink_m00ba8185ca362d257d138fe1886cbc5f3acc38c4a238bef60c3d3d7fa0276eab":{"arguments":{"format":"ink-value-wire-v1","identity":"a9d67b7a474f78841986a2160f6d9330ec73efe55bb06560a35a27a22ad078b5","named":{},"root":{"fields":[{"name":"weight","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}},{"name":"weight_decay","type":{"kind":"f32"}},{"name":"norm_limit","type":{"kind":"f32"}}],"kind":"record","name":"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"ink_m1774c4db693eebe71b1f79bce053b93633d1e1ec37196dd480b59c0248b4fbc2":{"arguments":{"format":"ink-value-wire-v1","identity":"48baf4f7fc28a2b3b5df8f3367f2d7cd4d4bccc1c64a334e7433f0c6fd503d4b","named":{},"root":{"fields":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"derivatives","type":{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"}},{"name":"allowed","type":{"element":{"kind":"bool"},"kind":"list"}},{"name":"total","type":{"kind":"f32"}},{"name":"selected","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"ink_m1fbf7ee6cef3bcca5d7d258c8606275806894b60d839126202d17f016ea87c80":{"arguments":{"format":"ink-value-wire-v1","identity":"1c83630f3139ed38673ed470f191df2b950104eaf550096543a7611da7c50d02","named":{},"root":{"fields":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"derivatives","type":{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"}},{"name":"allowed","type":{"element":{"kind":"bool"},"kind":"list"}},{"name":"unit","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"4c26cf6146a67b60bc34cb27a1b07b25ab14048bb6f0044b09b8e87179b513fa","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"}}}},"ink_m28a5428efa573345218636e9cec104f24b6e8c67d7c4c0f979b255813b2abee3":{"arguments":{"format":"ink-value-wire-v1","identity":"d02715cce4688c556e60843790a4e59e61ebaad2c9c1064929c6b794d816a06a","named":{},"root":{"fields":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"allowed","type":{"element":{"kind":"bool"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"ink_m2a55f95a80595bc61d1fcab41ff00f438ff6f2057b597df20aaae3c18507d2be":{"arguments":{"format":"ink-value-wire-v1","identity":"e0ef5b019bff93f73efd86b897d6f35ea8eb8b607d972cd47729126beaf5fafa","named":{},"root":{"fields":[{"name":"state","type":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}},{"name":"weight_decay","type":{"kind":"f32"}},{"name":"norm_limit","type":{"kind":"f32"}}],"kind":"record","name":"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"93944e72b897c9246b2efb71a34cebe025e2d57af4d472565578d66dcdc24614","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}}}},"ink_m372cbaf2ee2bc8705fad4b5b65a9e744ea468afbe4c153f17c7da282a459d1cd":{"arguments":{"format":"ink-value-wire-v1","identity":"a626656c4896f714c5263b675ceb0f0453e3cae783d93d52d880765e7164cd22","named":{},"root":{"fields":[{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}},{"name":"return_values","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"baselines","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}}},"ink_m43c1e2ac4d6d9a37358654ff5c1abcd42d4b01146c41a7ca617bccb074a8813b":{"arguments":{"format":"ink-value-wire-v1","identity":"a626656c4896f714c5263b675ceb0f0453e3cae783d93d52d880765e7164cd22","named":{},"root":{"fields":[{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}},{"name":"return_values","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"baselines","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}}},"ink_m4b5ada8f7d6b3beaee6fc06bf68e61ca158cbc7664899364dff18d21555697ae":{"arguments":{"format":"ink-value-wire-v1","identity":"46abc3d35c147b6bc27332854c2c200b359592fc034ea676178ecfaaa6e4f354","named":{},"root":{"fields":[{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}},{"name":"return_value","type":{"kind":"f32"}},{"name":"baseline","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}}},"ink_m5226ad25deae5e47d7fb65b6b5961d46740dd4e97b54d76a24d3d0445845fe35":{"arguments":{"format":"ink-value-wire-v1","identity":"d7bb8db3ffe558eca9f4f6716e44807734e18db170e874ada1038fb500fa33ad","named":{},"root":{"fields":[{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}},{"name":"weight_decay","type":{"kind":"f32"}},{"name":"norm_limit","type":{"kind":"f32"}}],"kind":"record","name":"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"ink_m696809152e57d8dfa3f01f9a3e12c048434b9f2af91ff53321ea6ceeeeca5431":{"arguments":{"format":"ink-value-wire-v1","identity":"c3638b7b9e1ad05ebcb8c60f864d4a1bbb22d0effd3343b6de51dc1abb657d20","named":{},"root":{"fields":[{"name":"accumulator","type":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"name":"decision","type":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"}},{"name":"return_value","type":{"kind":"f32"}},{"name":"baseline","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}}},"ink_m6ec6e8f9e757c220bfe2ed28cbb8dab4ec520de5ee8de5ca702cbdb805a5f910":{"arguments":{"format":"ink-value-wire-v1","identity":"ea3bdda55cda843ccb548330a20f97b77f397a07d72ef90ae77e37672fe45ca4","named":{},"root":{"fields":[{"name":"scaled","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"unit","type":{"kind":"f32"}},{"name":"total","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff","named":{},"root":{"kind":"u32"}}},"ink_m786bdc6011aece08dbf36c5ca89c437e06ff758c9d3d242f723dde2af6ea31db":{"arguments":{"format":"ink-value-wire-v1","identity":"95732fc2e08ae05f4d215e9e358781620c82dea66fab6ca4ada670422dd62463","named":{},"root":{"fields":[{"name":"state","type":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"ink_m7d03a2ed6071238ff1b69a8e56a8cb96b9dc3b095b2d939c0ccfed84ee9580b5":{"arguments":{"format":"ink-value-wire-v1","identity":"a7c17d063bba03b64d18b54cb89be038b3c836fdbf7ee6cc9644e5db742a8d67","named":{},"root":{"fields":[{"name":"xs","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"limit","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"ink_m8abb6b2bcbe55251e0b82a28f26d7ce761729346e35019c2b60ca9b5ee22590d":{"arguments":{"format":"ink-value-wire-v1","identity":"3d9fa005996e654b10e4e749ab0e2c4a9988b4ba944f21f1019c2132cbcb62b2","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"ink_m99468fca85aa8fb996f0c891430c813d82505250d39d8e415bf27679ddc39e07":{"arguments":{"format":"ink-value-wire-v1","identity":"d2aec7a161e83197cb0218fdd61843b82bc48bc0376a0e2d27cb5a10062d48ac","named":{},"root":{"fields":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"derivatives","type":{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"}},{"name":"allowed","type":{"element":{"kind":"bool"},"kind":"list"}},{"name":"action","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"4c26cf6146a67b60bc34cb27a1b07b25ab14048bb6f0044b09b8e87179b513fa","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"}}}},"ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96":{"arguments":{"format":"ink-value-wire-v1","identity":"7d522496fa90814f2f1e12091142cca8648a00e9c787d158636f57940650d4e4","named":{},"root":{"fields":[{"name":"xs","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"ink_maa2c8802d351b443dda0bc206d70fa9fe87756b57a84d0357e9dfb4c1e7a0667":{"arguments":{"format":"ink-value-wire-v1","identity":"63dc6e7ffb23fa2f492a776dfe3f26537ee473c9be45219097955b470f66c12e","named":{},"root":{"fields":[{"name":"derivatives","type":{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"}},{"name":"allowed","type":{"element":{"kind":"bool"},"kind":"list"}},{"name":"maximum","type":{"kind":"f32"}},{"name":"total","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"ink_maadd6c30a027af52d851f0828eec45339d218ad3bbe73e4d8d7cdd3892e754f4":{"arguments":{"format":"ink-value-wire-v1","identity":"2881c9ed2616bb70e9db4b1ec27ea38b7a87b36752047fc96da9ca8379b19bc6","named":{},"root":{"fields":[{"name":"decision","type":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"}},{"name":"return_value","type":{"kind":"f32"}},{"name":"baseline","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}}},"ink_mc05a2256079ef1f1818d13e69727dc7902cdb7f70856a671af2ba08ef190d23a":{"arguments":{"format":"ink-value-wire-v1","identity":"d02715cce4688c556e60843790a4e59e61ebaad2c9c1064929c6b794d816a06a","named":{},"root":{"fields":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"allowed","type":{"element":{"kind":"bool"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}}},"ink_mda500f665e6078213ee2391fedf06240c651d1725327b086aa70cda14bef9a07":{"arguments":{"format":"ink-value-wire-v1","identity":"2be6f1cb78767fdb61c1c0484a5a6b843d511c7eee041ed29a5db92ea7552629","named":{},"root":{"fields":[{"name":"rewards","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"discount","type":{"kind":"f32"}},{"name":"bootstrap","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}}},"ink_mdfbd57a9f460147afedb262e2bfe0f6197f9b813c85277c59f5e101900063ad7":{"arguments":{"format":"ink-value-wire-v1","identity":"fb0d53fcc5118c446d80e19c4ffd8b95f7979f94f7fb23149d3518375b621a75","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"93944e72b897c9246b2efb71a34cebe025e2d57af4d472565578d66dcdc24614","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}}}},"ink_meefc22a28d97f5bdc4100b36eeab9549241c3ef201b83c2f75111644d317833d":{"arguments":{"format":"ink-value-wire-v1","identity":"4748bdf2b6e86fd410744d69adce4514614c078ede8a1a3a86a717f27b6f4802","named":{},"root":{"fields":[{"name":"rate","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"ebe1deeb6dfcd30c7222004d895fd628b866b66eaba30c8067beddc0fad06e6e","named":{},"root":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}},{"name":"weight_decay","type":{"kind":"f32"}},{"name":"norm_limit","type":{"kind":"f32"}}],"kind":"record","name":"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249"}}},"ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54":{"arguments":{"format":"ink-value-wire-v1","identity":"7d522496fa90814f2f1e12091142cca8648a00e9c787d158636f57940650d4e4","named":{},"root":{"fields":[{"name":"xs","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"ink_mfd18151b0af45b45f5b48ef5e7a09ac1294681f654e2174ae3b33183f445ef14":{"arguments":{"format":"ink-value-wire-v1","identity":"d02715cce4688c556e60843790a4e59e61ebaad2c9c1064929c6b794d816a06a","named":{},"root":{"fields":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"allowed","type":{"element":{"kind":"bool"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}}},"mass":{"arguments":{"format":"ink-value-wire-v1","identity":"d9a2817b6f5795592e5f12e4e54fd3af0061b7a04d8d3e55dd63c3a2e7b0558e","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}},{"name":"p","type":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"Pick"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"numeric":{"arguments":{"format":"ink-value-wire-v1","identity":"7d522496fa90814f2f1e12091142cca8648a00e9c787d158636f57940650d4e4","named":{},"root":{"fields":[{"name":"xs","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"objective":{"arguments":{"format":"ink-value-wire-v1","identity":"73b6c3c00ad53194b4a983fbdfe4a21d2b6d7d09e0360d32bf0c48ae7e548d78","named":{},"root":{"fields":[{"name":"code","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"w","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"name":"g","type":{"fields":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}},{"name":"version","type":{"kind":"u32"}}],"kind":"record","name":"Goal"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"operation":{"arguments":{"format":"ink-value-wire-v1","identity":"b18b8e3a9b0c713996792c0169d67db393284bc0fbbe8923341264f4e701d595","named":{},"root":{"fields":[{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"b3b157bb16bd893ea71380744900064a9de9eb7c3acb99e1b5f09d5ea004acdc","named":{},"root":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]}}},"operation_index":{"arguments":{"format":"ink-value-wire-v1","identity":"67c7b08ea9bc79f73b03679d7de04a95cbe0804e8e6378cf44de5a5141901762","named":{},"root":{"fields":[{"name":"op","type":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff","named":{},"root":{"kind":"u32"}}},"pack":{"arguments":{"format":"ink-value-wire-v1","identity":"6da39b4bdc61a0dfc05cd13f33b9dff603918ce7e5f350c1a2667fd66780df45","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"proposal_gradient":{"arguments":{"format":"ink-value-wire-v1","identity":"354e9d2a1be8a2863cda9de86d7ffca9c62c80a6f98b48128fae5eea579790b8","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"selected","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"sampled","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}},{"name":"loss","type":{"kind":"f32"}},{"name":"before","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}}},"reward":{"arguments":{"format":"ink-value-wire-v1","identity":"2450f19e0e579b7c693172b8f9d966f4cb2a66f0c54c8aeddd2fc3a24094c456","named":{},"root":{"fields":[{"name":"loss","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"sample":{"arguments":{"format":"ink-value-wire-v1","identity":"557496ff636fb6b286c9734903484337d7c625c8342438da588ba6bc566acc30","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"units","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"f5fccdf188a8fa8e7f79687e82888811bdcfc6c5067f21e08583a3d045794cc3","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"code","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}],"kind":"record","name":"Sampled"}}}},"sample_slot":{"arguments":{"format":"ink-value-wire-v1","identity":"4e2e4f167d2a7ffd909bf20fcea9b4f15c0bda928c5ecc2ea7a66ff053c3a51f","named":{},"root":{"fields":[{"name":"accumulator","type":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"choices","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}],"kind":"record","name":"Building"}}},{"name":"slot","type":{"kind":"u32"}},{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}},{"name":"units","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"2031034504710782006d73b2256047567d88bffe38d126e61266c10961c7253a","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"choices","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}],"kind":"record","name":"Building"}}}},"squared_error":{"arguments":{"format":"ink-value-wire-v1","identity":"ce23998d984ebd7a5a923c4549ceab6d1453e81c138e942ab750cb78daf8862a","named":{},"root":{"fields":[{"name":"code","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"w","type":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},{"name":"s","type":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"unpack":{"arguments":{"format":"ink-value-wire-v1","identity":"7d522496fa90814f2f1e12091142cca8648a00e9c787d158636f57940650d4e4","named":{},"root":{"fields":[{"name":"xs","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"2af269616d48554c4ef5e8a1371afd52412f1ef4f05c2d9506bd43bfde5de326","named":{},"root":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}}},"valid_policy":{"arguments":{"format":"ink-value-wire-v1","identity":"da93f3054ae6844e61714614bad93fb28519ae0c770b7d7cba7e52b5f01783b8","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}}}}};
const __implementations=[__fn0,__fn1,__fn2,__fn3,__fn4,__fn5,__fn6,__fn7,__fn8,__fn9,__fn10,__fn11,__fn12,__fn13,__fn14,__fn15,__fn16,__fn17,__fn18,__fn19,__fn20,__fn21,__fn22,__fn23,__fn24,__fn25,__fn26,__fn27,__fn28,__fn29,__fn30,__fn31,__fn32,__fn33,__fn34,__fn35,__fn36,__fn37,__fn38,__fn39,__fn40,__fn41,__fn42,__fn43,__fn44,__fn45,__fn46,__fn47,__fn48,__fn49,__fn50];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
const __inputTypes=[{"capture":[true,false,true],"types":[{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"},{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"},{"kind":"f32"}]},{"capture":[false],"types":[{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}]},{"capture":[false],"types":[{"fields":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}}],"kind":"record","name":"Goal"}]},{"capture":[true,false,false],"types":[{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"},{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"},{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"}]},{"capture":[true,false,false],"types":[{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"},{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"},{"fields":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}}],"kind":"record","name":"Goal"}]},{"capture":[true],"types":[{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}]},{"capture":[false,false],"types":[{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"},{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"Pick"}]},{"capture":[true],"types":[{"kind":"u32"}]},{"capture":[false,true],"types":[{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"},{"kind":"u32"}]},{"capture":[true,true,false,true],"types":[{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"choices","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}],"kind":"record","name":"Building"}},{"kind":"u32"},{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"},{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[true,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[true],"types":[{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]}]},{"capture":[true,true,false,true],"types":[{"error":{"kind":"string"},"kind":"result","ok":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}},{"kind":"u32"},{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"},{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}]},{"capture":[true,true,true,true,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"},{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"},{"kind":"f32"},{"kind":"f32"}]},{"capture":[false],"types":[{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}]},{"capture":[true],"types":[{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[true],"types":[{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[true,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"bool"},"kind":"list"}]},{"capture":[true,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"bool"},"kind":"list"}]},{"capture":[true,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"bool"},"kind":"list"}]},{"capture":[true,true,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"kind":"f32"},{"kind":"f32"}]},{"capture":[true,true,true,true],"types":[{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"},{"element":{"kind":"bool"},"kind":"list"},{"kind":"f32"},{"kind":"f32"}]},{"capture":[true,true,true,true,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"},{"element":{"kind":"bool"},"kind":"list"},{"kind":"f32"},{"kind":"u32"}]},{"capture":[true,true,true,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"},{"element":{"kind":"bool"},"kind":"list"},{"kind":"f32"}]},{"capture":[true,true,true,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"},{"element":{"kind":"bool"},"kind":"list"},{"kind":"u32"}]},{"capture":[false,true,true],"types":[{"fields":[{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},{"kind":"f32"},{"kind":"f32"}]},{"capture":[true,false,true,true],"types":[{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}},{"fields":[{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},{"kind":"f32"},{"kind":"f32"}]},{"capture":[true,true,true],"types":[{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[true,true,true],"types":[{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[true,true,true],"types":[{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"},{"kind":"f32"},{"kind":"f32"}]},{"capture":[true,true,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"kind":"f32"},{"kind":"f32"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[true],"types":[{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[false],"types":[{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}]},{"capture":[true],"types":[{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[false],"types":[{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}},{"name":"weight_decay","type":{"kind":"f32"}},{"name":"norm_limit","type":{"kind":"f32"}}],"kind":"record","name":"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[true,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"kind":"f32"}]},{"capture":[true,true,true,true,true,false],"types":[{"kind":"f32"},{"kind":"f32"},{"kind":"f32"},{"kind":"f32"},{"kind":"f32"},{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249"}]},{"capture":[false,true,false],"types":[{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"},{"element":{"kind":"f32"},"kind":"list"},{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}},{"name":"weight_decay","type":{"kind":"f32"}},{"name":"norm_limit","type":{"kind":"f32"}}],"kind":"record","name":"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249"}]},{"capture":[false,false],"types":[{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"},{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_6"}]},{"capture":[false,false],"types":[{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"},{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"Pick"}]},{"capture":[false,true],"types":[{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"},{"kind":"f32"}]},{"capture":[false,true],"types":[{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"},{"kind":"f32"}]},{"capture":[false,true],"types":[{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"},{"kind":"f32"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[false,false],"types":[{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"},{"fields":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}}],"kind":"record","name":"Goal"}]}];

// Descriptor work occurs once at module initialisation, never per word-list call.
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=> {
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const output=__representation(f.result,true);
  const body=__implementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
  const needsInput=input.some(c=>c!==__identity);
  const entry=!needsInput && output===__identity ? implementation :
    (...args)=>{const context=new WeakMap();return output(implementation(...(needsInput ? args.map((v,i)=>input[i](v,context)) : args)),context);};
  return [f.name,entry];
})));
export function call(name,args) { return functions[name](...args); }
// Shared bounded binary codec; generated code supplies exact descriptors.
export const valueWireFormat='ink-value-wire-v1';
// A connection agrees on the complete value schema before using this format.
// Version byte + schema-directed fields; schema identity is out of band.
export const compactValueWireFormat='ink-value-session-v1';
const wireMagic=Uint8Array.of(73,78,75,86,65,76,0,1);
const wireEncoder=new TextEncoder(),wireDecoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const wireDefaults=Object.freeze({bytes:16777216,nodes:1000000,depth:128}),wireDefaultOptions=Object.freeze({});
const wireDecimal=s=>typeof s==='string'&&/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(s);
function wireLimits(options){if(options===wireDefaultOptions||options===wireDefaults)return wireDefaults;const l={...wireDefaults,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>wireDefaults[k])throw Error('wire hard resource limit');return l;}
const wireFloat=new DataView(new ArrayBuffer(4));
function wireDecodeText(bytes,start,end){
 if(end-start<=16){let text='';for(let i=start;i<end;i++){const byte=bytes[i];if(byte>=128)return wireDecoder.decode(bytes.subarray(start,end));text+=String.fromCharCode(byte);}return text;}
 return wireDecoder.decode(bytes.subarray(start,end));
}
function wireUtf8Length(text){let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const wireOwn=(v,k)=>v!==null&&typeof v==='object'&&Object.hasOwn(v,k);
const wireTagged=(v,k)=>wireOwn(v,k)&&Object.keys(v).length===1;
const wireDouble=new DataView(new ArrayBuffer(8));
function wireF64Bits(v){
 if(typeof v==='number'&&Number.isFinite(v)){wireDouble.setFloat64(0,v,true);return wireDouble.getBigUint64(0,true);}
 if(!wireTagged(v,'F64Bits'))wireInvalidValue();const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))wireInvalidValue();
 const bits=BigInt(text);if(bits>18446744073709551615n)wireInvalidValue();return bits;
}
const wireCanonical=v=>Array.isArray(v)?'['+v.map(wireCanonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort((a,b)=>{const x=Array.from(a,c=>c.codePointAt(0)),y=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]-y[i];return x.length-y.length;}).map(k=>JSON.stringify(k)+':'+wireCanonical(v[k])).join(',')+'}':JSON.stringify(v);
export async function createValueCodec(root,named={}){
 const used=new Set(),budget={nodes:100000};
 function check(t,d=0){
  if(d>64||--budget.nodes<0)throw Error('wire descriptor limit');
  const keys={u32:['kind'],u64:['kind'],i32:['kind'],f32:['kind'],f64:['kind'],bool:['kind'],unit:['kind'],string:['kind'],int:['kind'],id:['kind','name'],ref:['kind','name'],enum:['kind','name','variants'],record:['kind','name','fields'],list:['kind','element'],option:['kind','element'],vector:['kind','element','size'],result:['kind','ok','error']}[t?.kind];
  if(!keys||Object.keys(t).length!==keys.length||keys.some(k=>!Object.hasOwn(t,k)))throw Error('invalid wire descriptor');
  if(keys.includes('name')&&(typeof t.name!=='string'||!t.name.isWellFormed()))throw Error('invalid descriptor name');
  if(t.kind==='ref'){if(!used.has(t.name)){used.add(t.name);if(named[t.name]?.kind!=='record'||named[t.name].name!==t.name)throw Error('unresolved wire reference');check(named[t.name],d+1);}}
  if(t.kind==='record'){if(!Array.isArray(t.fields))throw Error('wire fields');const names=new Set();for(const f of t.fields){if(Object.keys(f).length!==2||typeof f.name!=='string'||!f.name.isWellFormed()||names.has(f.name))throw Error('duplicate wire field');names.add(f.name);check(f.type,d+1);}}
  if(t.kind==='enum'&&(!Array.isArray(t.variants)||!t.variants.length||t.variants.length>64||t.variants.some(v=>typeof v!=='string'||!v.isWellFormed())||new Set(t.variants).size!==t.variants.length))throw Error('wire enum');
  if(['list','vector','option'].includes(t.kind)){if(t.kind==='vector'&&(!Number.isInteger(t.size)||t.size<1||t.size>64))throw Error('wire vector');check(t.element,d+1);}
  if(t.kind==='result'){check(t.ok,d+1);check(t.error,d+1);}
 }
 check(root);const names=Object.fromEntries([...used].sort().map(k=>[k,named[k]]));
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',wireEncoder.encode(wireCanonical({format:valueWireFormat,root,named:names}))));
 return new ValueCodec({format:valueWireFormat,root,named:names,identity:Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('')});
}
// Resolve immutable descriptor edges once. Logical validation traverses the
// literal schema; single-child nodes use a loop rather than recursive closures.
function wireValuePlan(codec){
 const seen=new WeakMap();let remaining=100000;
 const build=type=>{
  const t=codec.resolve(type);if(seen.has(t))return seen.get(t);
  if(--remaining<0)throw Error('wire descriptor limit');const p={kind:t.kind,type:t,decode:null,decodeCompact:null};seen.set(t,p);
  if(t.kind==='record')p.fields=t.fields.map(f=>({name:f.name,plan:build(f.type)}));
  if(t.kind==='list'||t.kind==='vector'||t.kind==='option')p.element=build(t.element);
  if(t.kind==='result'){p.ok=build(t.ok);p.error=build(t.error);}
  return p;
 };return build(codec.descriptor.root);
}
function wireBindDecodePlan(root,compact=false){
 const seen=new Set(),pending=[root];let flags=0;
 while(pending.length){
  const p=pending.pop();if(seen.has(p))continue;seen.add(p);if(compact)p.decodeCompact=compactDecodeOperation(p);else p.decode=wireDecodeOperation(p);
  if(p.fields?.length>4)flags|=1;
  if(p.kind==='u32'||p.kind==='i32'||p.kind==='u64'||p.kind==='f32'||p.kind==='f64')flags|=2;
  if(p.fields)for(const f of p.fields)pending.push(f.plan);
  if(p.element)pending.push(p.element);
  if(p.ok){pending.push(p.ok);pending.push(p.error);}
 }
 return flags|4;
}
// Select literal descriptor operations once, without runtime source generation
// or eval. Recursive edges call the completed plan. The generic scanner remains
// the visitor/validation path and an independent materialisation implementation.
function wireReadOperation(p){
 const t=p.type;
 let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':read=(r,end)=>{r.size(end,4);const value={F32Bits:r.view.getUint32(r.cursor,true)};r.cursor=end;return value;};break;
  case 'f64':read=(r,end)=>{r.size(end,8);const value={F64Bits:r.view.getBigUint64(r.cursor,true).toString()};r.cursor=end;return value;};break;
  case 'u64':read=(r,end)=>{r.size(end,8);const value=r.view.getBigUint64(r.cursor,true);r.cursor=end;return value;};break;
  case 'string':read=(r,end)=>r.text(end);break;
  case 'int':read=(r,end)=>{const text=r.text(end);if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=(r,end)=>{const text=r.text(end);if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=(r,end)=>{const text=r.text(end);if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{
    if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;
    if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');
    const values=new Array(n);for(let i=0;i<n;i++)values[i]=element.decode(r,end,d+1);return values;
   };break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1)});break;
    case 2:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1)});break;
    case 3:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1)});break;
    case 4:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1),[fs[3].name]:fs[3].plan.decode(r,end,d+1)});break;
    default:read=(r,end,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decode(r,end,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,end,d)=>{const tag=r.tag(end);return tag?{Some:p.element.decode(r,end,d+1)}:{None:null};};break;
  case 'result':read=(r,end,d)=>r.tag(end)?{Err:p.error.decode(r,end,d+1)}:{Ok:p.ok.decode(r,end,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function wireDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=wireReadOperation(field.plan),name=field.name;
  return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),childEnd=r.enter(end,d+1),item=read(r,childEnd,d+1);if(r.cursor!==childEnd)throw Error('trailing wire frame bytes');const value={[name]:item};if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
 }
 const read=wireReadOperation(p);
 return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
}
class WireDecodeCursor{
 constructor(bytes,view,limits){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
// Bind literal validation and postorder visitation once for every descriptor.
// No logical carriers are allocated; projection still validates every child.
function wireScanPlan(root){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,scan:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.scan=wireScanOperation(p);return p;
 };
 return build(root);
}
function wireScanOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':case 'f64':case 'u64':{const size=p.kind==='f32'?4:8;read=(r,end)=>{r.size(end,size);r.cursor=end;};break;}
  case 'string':read=(r,end)=>{let i=r.cursor;while(i<end&&r.bytes[i]<128)i++;if(i<end)wireDecoder.decode(r.bytes.subarray(r.cursor,end));r.cursor=end;};break;
  case 'int':case 'id':case 'enum':read=(r,end)=>{const text=r.text(end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');for(let i=0;i<n;i++)element.scan(r,end,d+1);};break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>{};break;
    case 1:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);};break;
    case 2:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);};break;
    case 3:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);};break;
    case 4:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);fs[3].plan.scan(r,end,d+1);};break;
    default:read=(r,end,d)=>{for(const f of fs)f.plan.scan(r,end,d+1);};
   }break;
  }
  case 'option':read=(r,end,d)=>{if(r.tag(end))p.element.scan(r,end,d+1);};break;
  case 'result':read=(r,end,d)=>{(r.tag(end)?p.error:p.ok).scan(r,end,d+1);};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return (r,parentEnd,d)=>{
  const end=r.enter(parentEnd,d),start=r.cursor,value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');
  const visitor=r.visitor;if(visitor&&(!r.selected||r.selected.has(t.name))){if(r.spans)visitor(t,r.bytes,start,end,d);else visitor(t,r.bytes.subarray(start,end),d);}
  return value;
 };
}
// Separate methods keep decoding's cursor callsites monomorphic. Both cursors
// are checked against the independent generic scanner and malformed fixtures.
class WireScanCursor{
 constructor(bytes,view,limits,visitor,selected,spans){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.visitor=visitor;this.selected=selected;this.spans=spans;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
function compactReadOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=()=>null;break;
  case 'bool':read=r=>{r.require(1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':case 'i32':read=r=>{r.require(4);const n=p.kind==='u32'?r.view.getUint32(r.cursor,true):r.view.getInt32(r.cursor,true);r.cursor+=4;return n;};break;
  case 'f32':read=r=>{r.require(4);const n=r.view.getUint32(r.cursor,true);r.cursor+=4;return {F32Bits:n};};break;
  case 'f64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return {F64Bits:n.toString()};};break;
  case 'u64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return n;};break;
  case 'string':read=r=>r.text();break;
  case 'int':read=r=>{const text=r.text();if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=r=>{const text=r.text();if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=r=>{const text=r.text();if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':read=(r,d)=>{const n=r.count();if(n>r.remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');const values=new Array(n);for(let i=0;i<n;i++)values[i]=p.element.decodeCompact(r,d+1);return values;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1)});break;
    case 2:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1)});break;
    case 3:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1)});break;
    case 4:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1),[fs[3].name]:fs[3].plan.decodeCompact(r,d+1)});break;
    default:read=(r,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decodeCompact(r,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,d)=>r.tag()?{Some:p.element.decodeCompact(r,d+1)}:{None:null};break;
  case 'result':read=(r,d)=>r.tag()?{Err:p.error.decodeCompact(r,d+1)}:{Ok:p.ok.decodeCompact(r,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function compactDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=compactReadOperation(field.plan),name=field.name;
  return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');if(d+1>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return {[name]:read(r,d+1)};};
 }
 const read=compactReadOperation(p);
 return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return read(r,d);};
}
class CompactDecodeCursor{
 constructor(bytes,limits,flags){this.bytes=bytes;this.view=flags&2?new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength):null;this.cursor=1;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 require(n){if(n>this.bytes.length-this.cursor)throw Error('truncated compact value');}
 count(){
  if(this.cursor>=this.bytes.length)throw Error('truncated compact value');
  const first=this.bytes[this.cursor++];if(first<128)return first;
  let value=first&127,scale=128;
  for(let i=1;i<5;i++){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const byte=this.bytes[this.cursor++];if(i===4&&byte>15)throw Error('compact count overflow');value+=(byte&127)*scale;if(byte<128){if(byte===0)throw Error('noncanonical compact count');return value;}scale*=128;}throw Error('compact count overflow');
 }
 tag(){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const tag=this.bytes[this.cursor++];if(tag>1)throw Error('wire sum tag');return tag;}
 text(){const n=this.count();this.require(n);const start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
function wireInvalidValue(){throw Error('invalid value for wire schema');}
// Capture has the canonical logical meaning of decode(encode(value)), without
// allocating wire bytes. A separate plan leaves validation/decoder hot shapes
// unchanged and never retains host input containers between calls.
function wireCapturePlan(root,checked=true){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,capture:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({name:f.name,plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.capture=checked?wireCaptureOperation(p):wireCopyOperation(p);return p;
 };return build(root);
}
function wireCaptureOperation(p){
 const t=p.type;let copy;
 switch(p.kind){
  case 'unit':copy=v=>{if(v!==null)wireInvalidValue();return null;};break;
  case 'bool':copy=(v,r)=>{if(typeof v!=='boolean')wireInvalidValue();r.add(1);return v;};break;
  case 'u32':case 'i32':{
   const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
   copy=(v,r)=>{if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();r.add(4);return v===0?0:v;};break;
  }
  case 'u64':copy=(v,r)=>{const kind=typeof v;if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();r.add(8);return n;};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'int':case 'id':case 'enum':copy=(v,r)=>{const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;if(typeof text!=='string'||!text.isWellFormed()||text.length>r.limit)wireInvalidValue();if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();r.add(wireUtf8Length(text));return p.kind==='int'?{Int:text}:text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   copy=(v,r,d)=>{if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();const n=v.length;if(n>r.remaining||size!==null&&n!==size)wireInvalidValue();r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=element.capture(v[i],r,d+1);return out;};break;
  }
  case 'record':{
   const fs=p.fields;let fields;
   switch(fs.length){
    case 0:fields=()=>({});break;
    case 1:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:fields=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }
   copy=(v,r,d)=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();for(const f of fs)if(!wireOwn(v,f.name))wireInvalidValue();return fields(v,r,d);};break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'None')&&v.None===null)return {None:null};if(wireTagged(v,'Some'))return {Some:p.element.capture(v.Some,r,d+1)};wireInvalidValue();};break;
  case 'result':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'Ok'))return {Ok:p.ok.capture(v.Ok,r,d+1)};if(wireTagged(v,'Err'))return {Err:p.error.capture(v.Err,r,d+1)};wireInvalidValue();};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
class WireCaptureCursor{
 constructor(limits){this.remaining=limits.nodes;this.depth=limits.depth;this.limit=limits.bytes;this.bytes=40;this.add(0);}
 add(n){this.bytes+=n;if(this.bytes>this.limit)throw Error('wire byte limit');}
 enter(depth,bytes){if(depth>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.add(bytes);}
 text(value){if(value.length>this.limit)throw Error('wire byte limit');this.add(wireUtf8Length(value));}
}
// Literal lowerers share this fixed resource policy with logical capture.
export function createValueCaptureBudget(options=wireDefaultOptions){return new WireCaptureCursor(wireLimits(options));}
// The trusted-value API has the same canonical copy and ownership semantics.
// Its caller supplies a stable value accepted by validateValue. Shape/range
// checks remain at external capture boundaries; resource limits still apply.
function wireCopyOperation(p){
 let copy;
 switch(p.kind){
  case 'unit':copy=()=>null;break;
  case 'bool':copy=(v,r)=>{r.add(1);return v;};break;
  case 'u32':copy=(v,r)=>{r.add(4);return v>>>0;};break;
  case 'i32':copy=(v,r)=>{r.add(4);return v|0;};break;
  case 'u64':copy=(v,r)=>{r.add(8);return BigInt(v);};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'){wireFloat.setFloat32(0,v,true);bits=wireFloat.getUint32(0,true);}else bits=v.F32Bits;r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'id':case 'enum':copy=(v,r)=>{r.add(wireUtf8Length(v));return v;};break;
  case 'int':copy=(v,r)=>{const text=typeof v==='bigint'?v.toString():v.Int;r.add(wireUtf8Length(text));return {Int:text};};break;
  case 'list':case 'vector':copy=(v,r,d)=>{const n=v.length;if(n>r.remaining)throw Error('wire sequence size');r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=p.element.capture(v[i],r,d+1);return out;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:copy=()=>({});break;
    case 1:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:copy=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'None')&&v.None===null?{None:null}:{Some:p.element.capture(v.Some,r,d+1)};};break;
  case 'result':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'Ok')?{Ok:p.ok.capture(v.Ok,r,d+1)}:{Err:p.error.capture(v.Err,r,d+1)};};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
// Emit the cached literal schema with one forward writer. Each value is checked
// where it is consumed; byte bounds belong to the writer, not a second size walk.
function wireEncodeValue(root,value,l,w){
 let remaining=l.nodes;const depthLimit=l.depth;
 const node=(p,v,d)=>{
  if(d>depthLimit||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type,start=w.beginNode();
  switch(p.kind){
   case 'unit':if(v!==null)wireInvalidValue();break;
   case 'bool':if(typeof v!=='boolean')wireInvalidValue();w.byte(+v);break;
   case 'u32':case 'i32':{
    const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
    if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();w.word(v>>>0);break;
   }
   case 'u64':{
    const kind=typeof v;
    if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
    const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();w.wide(n);break;
   }
   case 'f64':w.wide(wireF64Bits(v));break;
   case 'f32':{
    let bits;
    if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}
    else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
    w.word(bits);break;
   }
   case 'string':case 'int':case 'id':case 'enum':{
    const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
    if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&(typeof text!=='string'||!/^[0-9a-f]{32}$/.test(text))||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
    w.text(text);break;
   }
   case 'list':case 'vector':{
    if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
    if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
    w.count(v.length);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);break;
   }
   case 'record':{
    const fs=p.fields;
    if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
    for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
    for(let i=0;i<fs.length;i++){const f=fs[i];node(f.plan,v[f.name],d+1);}break;
   }
   case 'option':{
    if(wireTagged(v,'None')&&v.None===null)w.byte(0);
    else if(wireTagged(v,'Some')){w.byte(1);node(p.element,v.Some,d+1);}else wireInvalidValue();break;
   }
   case 'result':{
    if(wireTagged(v,'Ok')){w.byte(0);node(p.ok,v.Ok,d+1);}
    else if(wireTagged(v,'Err')){w.byte(1);node(p.error,v.Err,d+1);}else wireInvalidValue();break;
   }
   default:throw Error('unsupported wire kind');
  }
  w.endNode(start);
 };
 node(root,value,0);
}
function wireCheckValue(root,value,l){
 let remaining=l.nodes,total=40;
 const add=n=>{total+=n;if(total>l.bytes)throw Error('wire byte limit');};
 const node=(p,v,d)=>{
  while(true){
   if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
   const t=p.type;
   switch(p.kind){
    case 'unit':if(v!==null)wireInvalidValue();add(4);return;
    case 'bool':if(typeof v!=='boolean')wireInvalidValue();add(5);return;
    case 'u32':case 'i32':{
     const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
     if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();add(8);return;
    }
    case 'u64':{
     const kind=typeof v;
     if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
     const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();add(12);return;
    }
    case 'f64':wireF64Bits(v);add(12);return;
    case 'f32':{
     if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();}
     else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();const bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
     add(8);return;
    }
    case 'string':case 'int':case 'id':case 'enum':{
     const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
     if(typeof text!=='string'||!text.isWellFormed()||text.length>l.bytes)wireInvalidValue();
     if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
     add(4+wireUtf8Length(text));return;
    }
    case 'list':case 'vector':{
     if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
     if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
     add(8);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);return;
    }
    case 'record':{
     const fs=p.fields;
     if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
     for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
     add(4);if(!fs.length)return;
     for(let i=0;i<fs.length-1;i++)node(fs[i].plan,v[fs[i].name],d+1);
     const f=fs[fs.length-1];p=f.plan;v=v[f.name];d++;continue;
    }
    case 'option':{
     if(wireTagged(v,'None')&&v.None===null){add(5);return;}
     if(!wireTagged(v,'Some'))wireInvalidValue();add(5);p=p.element;v=v.Some;d++;continue;
    }
    case 'result':{
     if(wireTagged(v,'Ok')){add(5);p=p.ok;v=v.Ok;}
     else if(wireTagged(v,'Err')){add(5);p=p.error;v=v.Err;}else wireInvalidValue();
     d++;continue;
    }
    default:throw Error('unsupported wire kind');
   }
  }
 };
 node(root,value,0);if(total>l.bytes)throw Error('wire byte limit');
}
// A single cursor replaces per-node child closures and {end,value} temporaries.
// Projection filters limit callback materialisation, never schema validation.
function wireScanValue(root,bytes,view,l,materialize,visitor,selected,spans){
 let cursor=40,remaining=l.nodes;
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,parentEnd,d)=>{
  if(d>l.depth||--remaining<0||cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const t=p.type,start=cursor+4,end=start+view.getUint32(cursor,true);if(end>parentEnd)throw Error('truncated wire frame');cursor=start;let value;
  switch(p.kind){
   case 'unit':if(end-start!==0)throw Error('malformed wire scalar');value=null;break;
   case 'bool':if(end-start!==1)throw Error('malformed wire scalar');if(bytes[start]>1)throw Error('invalid wire Bool');value=!!bytes[start];cursor=end;break;
   case 'u32':case 'i32':if(end-start!==4)throw Error('malformed wire scalar');value=p.kind==='u32'?view.getUint32(start,true):view.getInt32(start,true);cursor=end;break;
   case 'f32':if(end-start!==4)throw Error('malformed wire scalar');if(materialize)value={F32Bits:view.getUint32(start,true)};cursor=end;break;
   case 'f64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value={F64Bits:view.getBigUint64(start,true).toString()};cursor=end;break;
   case 'u64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value=view.getBigUint64(start,true);cursor=end;break;
   case 'string':case 'int':case 'id':case 'enum':{
    if(p.kind==='string'&&!materialize){let i=start;while(i<end&&bytes[i]<128)i++;if(i<end)wireDecoder.decode(bytes.subarray(start,end));}
    else{const text=wireDecodeText(bytes,start,end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    cursor=end;break;
   }
   case 'list':case 'vector':{
    if(start+4>end)throw Error('wire list count');const n=view.getUint32(start,true);cursor+=4;
    if(n>remaining||n>Math.floor((end-cursor)/4)||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,end,d+1);if(materialize)value.push(child);}break;
   }
   case 'record':{
    const fs=p.fields;
    // Computed literal keys create own data properties even for __proto__ or
    // prototype setters. Common small records need no descriptor allocations.
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:value={};break;case 1:value={[fs[0].name]:node(fs[0].plan,end,d+1)};break;case 2:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1)};break;case 3:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1)};break;case 4:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1),[fs[3].name]:node(fs[3].plan,end,d+1)};break;}
    }else{if(materialize)value={};for(const f of fs){const child=node(f.plan,end,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}}break;
   }
   case 'option':case 'result':{
    if(start===end||bytes[cursor]>1)throw Error('wire sum tag');const tag=bytes[cursor++];
    if(p.kind==='option'&&tag===0){if(materialize)value={None:null};}
    else{const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,end,d+1);if(materialize)value={[label]:child};}break;
   }
   default:throw Error('unsupported wire kind');
  }
  if(cursor!==end)throw Error('trailing wire frame bytes');
  if(visitor&&(!selected||selected.has(t.name))){if(spans)visitor(t,bytes,start,end,d);else visitor(t,bytes.subarray(start,end),d);}
  return value;
 };
 const result=node(root,bytes.length,0);if(cursor!==bytes.length)throw Error('trailing wire bytes');return result;
}
export class ValueCodec{
 #hash;
 #header;
 #headerWords;
 #descriptor;
 #valuePlan;
 #compactCodec;
 #encoder;
 #decodeBound=0;
 #scanPlan=null;
 #capturePlan=null;
 #copyPlan=null;
 get descriptor(){return this.#descriptor;}
 constructor(descriptor){
  // This synchronous path is for compiler-generated immutable metadata. For
  // untrusted descriptors use createValueCodec and compare the computed identity.
  if(descriptor?.format!==valueWireFormat||!/^[0-9a-f]{64}$/.test(descriptor.identity))throw Error('invalid wire schema');
  this.#descriptor=structuredClone(descriptor);this.#hash=Uint8Array.from(descriptor.identity.match(/../g),s=>parseInt(s,16));
  this.#header=new Uint8Array(40);this.#header.set(wireMagic);this.#header.set(this.#hash,8);
  const headerView=new DataView(this.#header.buffer);this.#headerWords=Array.from({length:10},(_,i)=>headerView.getUint32(i*4,true));
  const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}};freeze(this.descriptor);this.#valuePlan=wireValuePlan(this);
 }
 resolve(t){for(let i=0;i<64;i++){if(t.kind!=='ref')return t;t=this.descriptor.named[t.name];if(!t)throw Error('wire reference');}throw Error('wire reference cycle');}
 validateValue(value,options=wireDefaultOptions){wireCheckValue(this.#valuePlan,value,wireLimits(options));return true;}
 capture(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#capturePlan??=wireCapturePlan(this.#valuePlan);return this.#capturePlan.capture(value,new WireCaptureCursor(limits),0);}
 copy(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#copyPlan??=wireCapturePlan(this.#valuePlan,false);return this.#copyPlan.capture(value,new WireCaptureCursor(limits),0);}
 compact(){return this.#compactCodec??=new CompactValueCodec(this);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new WireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.bytes(this.#header);wireEncodeValue(this.#valuePlan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new WireEncoder(options);w.bytes(wireMagic);w.bytes(this.#hash);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 scan(bytes,options=wireDefaultOptions,materialize=false,visitor=null,names=null,spans=false){
  const l=wireLimits(options);if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<44||bytes.length>l.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==this.#headerWords[i])throw Error('wire format or schema mismatch');
  if(names!==null&&(!Array.isArray(names)||names.length>100000||names.some(n=>typeof n!=='string')))throw Error('wire visitor names');
  if(materialize&&!visitor){this.#decodeBound||=wireBindDecodePlan(this.#valuePlan);const cursor=new WireDecodeCursor(bytes,view,l);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#valuePlan.decode(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  if(!materialize){this.#scanPlan??=wireScanPlan(this.#valuePlan);const cursor=new WireScanCursor(bytes,view,l,visitor,names===null?null:new Set(names),spans),value=this.#scanPlan.scan(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  return wireScanValue(this.#valuePlan,bytes,view,l,materialize,visitor,names===null?null:new Set(names),spans);
 }
 visit(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names);}
 visitSpans(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names,true);}
 validate(bytes,options=wireDefaultOptions){this.scan(bytes,options,false);return true;}
 decode(bytes,options=wireDefaultOptions){return this.scan(bytes,options,true);}
}

// Bounded forward emission avoids building and repeatedly joining child buffers.
class WireEncoder{
 #data=new Uint8Array(256);#view=new DataView(this.#data.buffer);#at=0;#remaining;#depth=0;#byteLimit;#depthLimit;
 active=false;
 constructor(options){this.reset(options);}
 reset(options){const limits=wireLimits(options);this.#byteLimit=limits.bytes;this.#depthLimit=limits.depth;this.#remaining=limits.nodes;this.#depth=0;this.#at=0;this.active=true;}
 get capacity(){return this.#data.length;}
 get position(){return this.#at;}
 beginNode(){const at=this.#at;this.word(0);return at;}
 endNode(at){this.patchWord(at,this.#at-at-4);}
 count(n){this.word(n);}
 beginCount(){const at=this.position;this.count(0);return at;}
 endCount(at,n){this.patchWord(at,n);}
 #reserve(size){
  const end=this.#at+size;if(end>this.#byteLimit)throw Error('wire byte limit');
  if(end>this.#data.length){const next=new Uint8Array(Math.min(this.#byteLimit,Math.max(end,this.#data.length*2)));next.set(this.#data.subarray(0,this.#at));this.#data=next;this.#view=new DataView(next.buffer);}
  return end;
 }
 bytes(bytes){const end=this.#reserve(bytes.length);this.#data.set(bytes,this.#at);this.#at=end;}
 byte(n){if(!Number.isInteger(n)||n<0||n>255)throw Error('wire byte range');this.#reserve(1);this.#data[this.#at++]=n;}
 word(n){if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire word range');const end=this.#reserve(4);this.#view.setUint32(this.#at,n,true);this.#at=end;}
 wide(n){if(typeof n!=='bigint'||n<0n||n>18446744073709551615n)throw Error('wire wide range');const end=this.#reserve(8);this.#view.setBigUint64(this.#at,n,true);this.#at=end;}
 text(text,count=false){
  if(typeof text!=='string')throw Error('wire Unicode');
  if(text.length<=16){
   let ascii=true;for(let i=0;i<text.length;i++)if(text.charCodeAt(i)>=128){ascii=false;break;}
   if(ascii){if(count)this.count(text.length);const end=this.#reserve(text.length);for(let i=0;i<text.length;i++)this.#data[this.#at+i]=text.charCodeAt(i);this.#at=end;return;}
  }
  if(!text.isWellFormed())throw Error('wire Unicode');const size=wireUtf8Length(text);if(count)this.count(size);
  const end=this.#reserve(size),r=wireEncoder.encodeInto(text,this.#data.subarray(this.#at,end));if(r.read!==text.length||r.written!==size)throw Error('wire UTF-8 size');this.#at=end;
 }
 patchWord(at,n){if(!Number.isInteger(at)||at<0||at+4>this.#at||!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire patch offset');this.#view.setUint32(at,n,true);}
 patchByte(at,n){if(!Number.isInteger(at)||at<0||at>=this.#at||!Number.isInteger(n)||n<0||n>255)throw Error('wire patch offset');this.#data[at]=n;}
 replace(at,removed,bytes){
  if(!Number.isInteger(at)||!Number.isInteger(removed)||at<0||removed<0||at+removed>this.#at||!(bytes instanceof Uint8Array))throw Error('wire replacement range');
  const extra=bytes.length-removed,end=extra>0?this.#reserve(extra):this.#at+extra;
  this.#data.copyWithin(at+bytes.length,at+removed,this.#at);this.#data.set(bytes,at);this.#at=end;
 }
 // Literal generated writers use balanced frames without per-node callbacks.
 // An exception abandons this invocation; encodeWith never reuses its writer.
 openFrame(){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;return at;}
 closeFrame(at){if(this.#depth===0)throw Error('wire frame boundary');this.#depth--;this.endNode(at);}
 frame(emit){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;try{emit(this);}finally{this.#depth--;}this.endNode(at);}
 reorder(start,spans){
  const sorted=spans.slice().sort((a,b)=>a[0]-b[0]);let at=start;
  for(const [a,b] of sorted){if(!Number.isInteger(a)||!Number.isInteger(b)||a!==at||b<a)throw Error('wire span permutation');at=b;}
  if(start<0||start>this.#at||at!==this.#at)throw Error('wire span permutation');
  if(spans.every((s,i)=>s===sorted[i]))return;
  const copy=this.#data.slice(start,this.#at);at=start;for(const [a,b] of spans){this.#data.set(copy.subarray(a-start,b-start),at);at+=b-a;}
 }
 finish(){if(this.#depth!==0)throw Error('wire frame boundary');return this.#data.slice(0,this.#at);}
}

class CompactWireEncoder extends WireEncoder{
 beginNode(){return 0;}
 endNode(){}
 endCount(at,n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  if(n<128){this.patchByte(at,n);return;}
  const bytes=[];while(n>=128){bytes.push(n%128+128);n=Math.floor(n/128);}bytes.push(n);this.replace(at,1,Uint8Array.from(bytes));
 }
 count(n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  while(n>=128){this.byte(n%128+128);n=Math.floor(n/128);}this.byte(n);
 }
 text(text){super.text(text,true);}
}

function compactScanValue(root,bytes,l,materialize){
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let cursor=1,remaining=l.nodes;
 const require=n=>{if(n>bytes.length-cursor)throw Error('truncated compact value');};
 const count=()=>{
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   require(1);const byte=bytes[cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }throw Error('compact count overflow');
 };
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,d)=>{
  if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type;let value;
  switch(p.kind){
   case 'unit':return null;
   case 'bool':require(1);if(bytes[cursor]>1)throw Error('invalid wire Bool');return !!bytes[cursor++];
   case 'u32':case 'i32':require(4);value=p.kind==='u32'?view.getUint32(cursor,true):view.getInt32(cursor,true);cursor+=4;return value;
   case 'f32':require(4);if(materialize)value={F32Bits:view.getUint32(cursor,true)};cursor+=4;return value;
   case 'f64':require(8);if(materialize)value={F64Bits:view.getBigUint64(cursor,true).toString()};cursor+=8;return value;
   case 'u64':require(8);if(materialize)value=view.getBigUint64(cursor,true);cursor+=8;return value;
   case 'string':case 'int':case 'id':case 'enum':{
    const n=count();require(n);const start=cursor;cursor+=n;
    if(p.kind==='string'&&!materialize){let i=start;while(i<cursor&&bytes[i]<128)i++;if(i<cursor)wireDecoder.decode(bytes.subarray(start,cursor));}
    else{const text=wireDecodeText(bytes,start,cursor);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    return value;
   }
   case 'list':case 'vector':{
    const n=count();if(n>remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,d+1);if(materialize)value.push(child);}return value;
   }
   case 'record':{
    const fs=p.fields;
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:return {};case 1:return {[fs[0].name]:node(fs[0].plan,d+1)};case 2:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1)};case 3:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1)};case 4:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1),[fs[3].name]:node(fs[3].plan,d+1)};}
    }
    if(materialize)value={};for(const f of fs){const child=node(f.plan,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}return value;
   }
   case 'option':case 'result':{
    require(1);const tag=bytes[cursor++];if(tag>1)throw Error('wire sum tag');
    if(p.kind==='option'&&tag===0)return materialize?{None:null}:undefined;
    const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,d+1);
    return materialize?{[label]:child}:undefined;
   }
   default:throw Error('unsupported wire kind');
  }
 };
 const value=node(root,0);if(cursor!==bytes.length)throw Error('trailing compact bytes');return value;
}

// General transport codec, independent of source rewrites and checkpoints.
// The sender/receiver must negotiate this exact identity and format. There is
// deliberately no claim that the bytes themselves identify their schema.
export class CompactValueCodec{
 #source;#plan;#encoder;#decodeBound=0;
 get format(){return compactValueWireFormat;}
 get identity(){return this.#source.descriptor.identity;}
 constructor(valueCodec){if(!(valueCodec instanceof ValueCodec))throw Error('compact codec requires a checked value codec');this.#source=valueCodec;this.#plan=wireValuePlan(valueCodec);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new CompactWireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.byte(1);wireEncodeValue(this.#plan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new CompactWireEncoder(options);w.byte(1);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 #scan(bytes,options,materialize){
  const l=wireLimits(options);
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<1||bytes.length>l.bytes)throw Error('wire byte limit or header');
  if(bytes[0]!==1)throw Error('compact format mismatch');
  if(materialize){this.#decodeBound||=wireBindDecodePlan(this.#plan,true);const cursor=new CompactDecodeCursor(bytes,l,this.#decodeBound);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#plan.decodeCompact(cursor,0);if(cursor.cursor!==bytes.length)throw Error('trailing compact bytes');return value;}
  return compactScanValue(this.#plan,bytes,l,materialize);
 }
 decode(bytes,options=wireDefaultOptions){return this.#scan(bytes,options,true);}
 validate(bytes,options=wireDefaultOptions){this.#scan(bytes,options,false);return true;}
}

// Compiler materialisers consume already validated bytes synchronously. This
// factory is for trusted emitted code, not untrusted descriptor/callback data.
// The complete generic validator runs before any compiler reader is invoked.
class ValidatedValueReader{
 constructor(bytes,compact){this.bytes=bytes;this.view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);this.cursor=compact?1:40;this.compact=compact;}
 frame(){if(this.compact)return 0;const end=this.cursor+4+this.view.getUint32(this.cursor,true);this.cursor+=4;return end;}
 finish(end){if(!this.compact&&this.cursor!==end)throw Error('compiled reader frame mismatch');}
 byte(){return this.bytes[this.cursor++];}
 word(){const n=this.view.getUint32(this.cursor,true);this.cursor+=4;return n;}
 signed(){const n=this.view.getInt32(this.cursor,true);this.cursor+=4;return n;}
 wide(){const n=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return n;}
 count(){if(!this.compact)return this.word();let n=0,scale=1,byte;do{byte=this.byte();n+=(byte&127)*scale;scale*=128;}while(byte>=128);return n;}
 text(end){const n=this.compact?this.count():end-this.cursor,start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
class CompiledCompactValueCodec extends CompactValueCodec{
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,true),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
}
class CompiledValueCodec extends ValueCodec{
 #read;#compiledCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,false),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
 compact(){return this.#compiledCompact??=new CompiledCompactValueCodec(this,this.#read);}
}
export function createCompiledValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new CompiledValueCodec(descriptor,read);}

// Trusted literal materialisers may use this checked reader to validate and
// construct in one traversal. The emitter must use frame/finish at every source
// node, typed text reads and counted sequence reads; arbitrary callbacks do not
// establish a schema correspondence proof. The independent scanner remains the
// validation oracle and the original factory retains its pre-validation path.
function literalValueHeader(identity){
 const bytes=new Uint8Array(40);bytes.set(wireMagic);
 for(let i=0;i<32;i++)bytes[i+8]=parseInt(identity.slice(i*2,i*2+2),16);
 const view=new DataView(bytes.buffer),words=new Uint32Array(10);
 for(let i=0;i<10;i++)words[i]=view.getUint32(i*4,true);
 return words;
}
class CheckedLiteralValueReader {
 constructor(bytes,header,compact,limits){
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<(compact?1:44)||bytes.length>limits.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  if(compact){if(bytes[0]!==1)throw Error('compact format mismatch');}
  else for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==header[i])throw Error('wire format or schema mismatch');
  this.bytes=bytes;this.view=view;
  this.cursor=compact?1:40;this.compact=compact;this.remaining=limits.nodes;this.depth=limits.depth;this.ends=[];
 }
 require(n){if(this.cursor+n>(this.ends.at(-1)??this.bytes.length))throw Error('truncated wire frame');}
 frame(){
  if(this.ends.length>this.depth||--this.remaining<0)throw Error('wire node or depth limit');
  let end=this.bytes.length;
  if(!this.compact){this.require(4);end=this.cursor+4+this.view.getUint32(this.cursor,true);this.require(end-this.cursor);this.cursor+=4;}
  this.ends.push(end);return this.compact?0:end;
 }
 finish(end){
  if(!this.ends.length||!this.compact&&(this.ends.at(-1)!==end||this.cursor!==end))throw Error('compiled reader frame mismatch');
  this.ends.pop();
 }
 byte(){this.require(1);const value=this.bytes[this.cursor++];if(value>1)throw Error('wire sum tag or Bool');return value;}
 word(){this.require(4);const value=this.view.getUint32(this.cursor,true);this.cursor+=4;return value;}
 signed(){this.require(4);const value=this.view.getInt32(this.cursor,true);this.cursor+=4;return value;}
 wide(){this.require(8);const value=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return value;}
 rawCount(){
  if(!this.compact)return this.word();
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   this.require(1);const byte=this.bytes[this.cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }
  throw Error('compact count overflow');
 }
 count(size){
  const value=this.rawCount();
  if(value>this.remaining||size!==undefined&&value!==size)throw Error('wire sequence size');
  return value;
 }
 text(end,kind='string',variants){
  const size=this.compact?this.rawCount():end-this.cursor;
  this.require(size);const start=this.cursor;this.cursor+=size;
  const value=wireDecodeText(this.bytes,start,this.cursor);
  if(kind==='int'&&!wireDecimal(value)||kind==='id'&&!/^[0-9a-f]{32}$/.test(value)||kind==='enum'&&!variants.includes(value))throw Error('malformed wire text');
  return value;
 }
 complete(){if(this.ends.length||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
// Compact source nodes have no individual frame ends: retain the same checked
// depth/node order using a counter, with bounds against the complete buffer.
class CheckedCompactLiteralValueReader extends CheckedLiteralValueReader {
 constructor(bytes,limits){super(bytes,null,true,limits);this.level=0;}
 require(n){if(this.cursor+n>this.bytes.length)throw Error('truncated wire frame');}
 frame(){if(this.level>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.level++;return 0;}
 finish(_end){if(!this.level)throw Error('compiled reader frame mismatch');this.level--;}
 complete(){if(this.level||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
class FusedCompactValueCodec extends CompactValueCodec {
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedCompactLiteralValueReader(bytes,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
}
class FusedValueCodec extends ValueCodec {
 #read;#header;#fusedCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;this.#header=literalValueHeader(this.descriptor.identity);}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedLiteralValueReader(bytes,this.#header,false,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
 compact(){return this.#fusedCompact??=new FusedCompactValueCodec(this,this.#read);}
}
export function createFusedValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new FusedValueCodec(descriptor,read);}
// JSON text is a boundary adapter to an ordinary recursive Ink datatype.
// No JavaScript Number conversion occurs for JSON numeric tokens.
export function jsonNumberToken(s){return typeof s==='string'&&/^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/.test(s);}
// JSON numeric tokens have an ASCII grammar. Check validated UTF-8 spans
// directly, preserving exact lexemes without allocating a decoded String.
function jsonNumberSpan(bytes,lo,hi){
 let at=lo;if(bytes[at]===45)at++;
 if(at>=hi)return false;
 if(bytes[at]===48)at++;
 else{if(bytes[at]<49||bytes[at]>57)return false;do{at++;}while(at<hi&&bytes[at]>=48&&bytes[at]<=57);}
 if(at<hi&&bytes[at]===46){const start=++at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 if(at<hi&&(bytes[at]===69||bytes[at]===101)){at++;if(at<hi&&(bytes[at]===43||bytes[at]===45))at++;const start=at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 return at===hi;
}
const jsonWireEncoder=new TextEncoder();
// Scalar conversion completes before writer callbacks; no per-value byte array.
const jsonFloatScratch=new DataView(new ArrayBuffer(4));
function jsonUtf8Length(text){if(text.length>16&&!/[^\x00-\x7f]/.test(text))return text.length;let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const jsonLimits={bytes:16777216,nodes:1000000,depth:128};
const jsonQuoters=new WeakSet();
/** Explicit, bounded reuse of immutable JSON string quotes. Cache payload bytes
 * are UTF-16 storage estimates; entry caps bound separate Map/object overhead.
 * Logical output budgets are charged again on every use, including cache hits.
 */
export function createJsonQuoter({maxEntries=1024,maxBytes=131072}={}){
 if(!Number.isSafeInteger(maxEntries)||maxEntries<0||maxEntries>65536||!Number.isSafeInteger(maxBytes)||maxBytes<0||maxBytes>16777216)throw Error('JSON quote cache budget');
 const entries=new Map();let bytes=0,hits=0,misses=0;
 const token=value=>{
  const prior=entries.get(value);if(prior!==undefined){hits++;return prior;}
  if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid JSON String');
  misses++;const text=JSON.stringify(value),size=2*(value.length+text.length),quoted=Object.freeze({text,utf8Bytes:jsonUtf8Length(text)});
  if(maxEntries&&size<=maxBytes){
   while(entries.size&&(entries.size>=maxEntries||bytes+size>maxBytes)){const key=entries.keys().next().value;bytes-=2*(key.length+entries.get(key).text.length);entries.delete(key);}
   entries.set(value,quoted);bytes+=size;
  }
  return quoted;
 };
 const quoter=Object.freeze({
  token,
  quote(value){return token(value).text;},
  clear(){entries.clear();bytes=0;},
  stats(){return {entries:entries.size,payload_bytes:bytes,hits,misses};},
 });jsonQuoters.add(quoter);return quoter;
}
function checkedJsonLimits(options){const l={...jsonLimits,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>jsonLimits[k])throw Error('JSON hard resource limit');return l;}
function jsonVariant(index,item){let payload=index===0?{}:{item0:item};if(index<5)payload={Ok:payload};for(let i=0;i<index;i++)payload={Err:payload};return {payload};}
export function parseJson(text,options={}){return parseJsonValue(text,options,null);}
function parseJsonValue(text,options,boundary){
 const p=new JsonWireReader(text,options);
 const value=(d,wireDepth=0)=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){boundary?.node(0,wireDepth);p.at+=4;return jsonVariant(0,null);}if(c==='t'&&text.startsWith('true',p.at)){boundary?.node(1,wireDepth);p.at+=4;return jsonVariant(1,true);}if(c==='f'&&text.startsWith('false',p.at)){boundary?.node(1,wireDepth);p.at+=5;return jsonVariant(1,false);}
  if(c==='"'){boundary?.node(3,wireDepth);const item=p.string();boundary?.text(item);return jsonVariant(3,item);}
  if(c==='['){boundary?.node(4,wireDepth);p.at++;const xs=[];if(!p.eat(']'))while(true){xs.push(value(d+1,wireDepth+8));if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}return jsonVariant(4,xs);}
  if(c==='{'){boundary?.node(5,wireDepth);p.at++;const xs=[],seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary?.member(key,wireDepth);if(!p.eat(':'))throw Error('JSON object colon');xs.push({key,value:value(d+1,wireDepth+9)});if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}return jsonVariant(5,xs);}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();boundary?.node(2,wireDepth);boundary?.text(token);return jsonVariant(2,token);}
  throw Error('invalid JSON value');
 };
 const out=value(0);p.finish();return out;
}
export function stringifyJson(value,options={}){return stringifyJsonValue(value,options,null);}
function stringifyJsonValue(value,options,boundary){
 const l=checkedJsonLimits(options);let remaining=l.nodes,bytes=0,output='';
 const emit=s=>{bytes+=jsonUtf8Length(s);if(bytes>l.bytes)throw Error('JSON byte limit');output+=s;};
 const write=(v,d,wireDepth=0)=>{
  if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');if(!v||Object.keys(v).length!==1||!Object.hasOwn(v,'payload'))throw Error('invalid JSON record');let p=v.payload,index=0;
  while(index<5&&p&&Object.hasOwn(p,'Err')){if(Object.keys(p).length!==1||boundary&&Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Err;index++;}
  if(index<5){if(!p||Object.keys(p).length!==1||!Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Ok;}
  if(!p||Object.keys(p).length!==(index===0?0:1)||index>0&&!Object.hasOwn(p,'item0'))throw Error('invalid JSON payload');const item=p.item0;boundary?.node(index,wireDepth);
  switch(index){
   case 0:emit('null');break;
   case 1:if(typeof item!=='boolean')throw Error('invalid JSON Boolean');emit(item?'true':'false');break;
   case 2:if(!jsonNumberToken(item))throw Error('invalid JSON number');boundary?.text(item);emit(item);break;
   case 3:if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary?.text(item);emit(JSON.stringify(item));break;
   case 4:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Array');const count=item.length;let visited=0;emit('[');item.forEach((x,i)=>{visited++;if(i)emit(',');write(x,d+1,wireDepth+8);});if(visited!==count)throw Error('invalid JSON Array');emit(']');break;}
   case 5:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Object');const count=item.length,seen=new Set();let visited=0;emit('{');item.forEach((m,i)=>{visited++;if(!m||Object.keys(m).length!==2||typeof m.key!=='string'||!m.key.isWellFormed()||!Object.hasOwn(m,'value')||boundary&&!Object.hasOwn(m,'key'))throw Error('invalid JSON member');if(seen.has(m.key))throw Error('duplicate JSON object key');seen.add(m.key);boundary?.member(m.key,wireDepth);if(i)emit(',');emit(JSON.stringify(m.key));emit(':');write(m.value,d+1,wireDepth+9);});if(visited!==count)throw Error('invalid JSON Object');emit('}');break;}
  }
 };write(value,0);return output;
}
// The adapter's schema is the fixed recursive JSON library shape checked by
// JsonCodec. Charge its ordinary record/sum/list wire nodes while parsing or
// rendering, rather than interpreting and walking the completed tree again.
function jsonBoundaryBudget(options){
 const l=checkedJsonLimits(options);let remaining=l.nodes,total=40;
 const charge=(nodes,bytes,depth)=>{remaining-=nodes;total+=bytes;if(remaining<0||depth>l.depth)throw Error('wire node or depth limit');if(total>l.bytes)throw Error('wire byte limit');};
 return {
  node(index,depth){charge(index===0?3:index<4?index+4:8,index===0?13:index===1?23:index===2?27:index===3?32:41,depth+(index===0?2:index<4?index+3:7));},
  text(text){charge(0,jsonUtf8Length(text),0);},
  member(key,depth){charge(2,8+jsonUtf8Length(key),depth+9);},
 };
}
function jsonSameSchema(a,b){
 if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;
 const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>Object.hasOwn(b,k)&&jsonSameSchema(a[k],b[k]));
}
// Host-object conversion is opt-in and JavaScript-only. Inspect data properties
// rather than invoking getters/toJSON; reflection is not a sandbox for proxies.
function jsonJSKeys(value){
 if(!value||typeof value!=='object')throw Error('expected a plain JavaScript object');
 const prototype=Object.getPrototypeOf(value);
 if(prototype!==Object.prototype&&prototype!==null)throw Error('expected a plain JavaScript object');
 const keys=Reflect.ownKeys(value);
 if(keys.some(k=>typeof k!=='string'))throw Error('JavaScript symbol keys are unsupported');
 return keys;
}
function jsonJSData(value,key){
 const property=Object.getOwnPropertyDescriptor(value,key);
 if(!property||!property.enumerable||!Object.hasOwn(property,'value'))throw Error('expected an enumerable own data property');
 return property.value;
}
function jsonJSRecord(value,names){
 const keys=jsonJSKeys(value);
 if(keys.length!==names.length||keys.some(k=>!names.includes(k)))throw Error('invalid JSON record or variant');
}
function jsonJSArray(value,remaining){
 if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype)throw Error('expected a plain JavaScript array');
 const length=value.length;
 if(length>remaining)throw Error('JSON node limit');
 const keys=Reflect.ownKeys(value);
 if(keys.length!==length+1||keys.some(k=>typeof k!=='string'||k!=='length'&&(!/^(0|[1-9][0-9]*)$/.test(k)||Number(k)>=length)))throw Error('sparse or decorated JavaScript arrays are unsupported');
 return length;
}
function jsonFromJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),active=new WeakSet();let remaining=limits.nodes;
 const text=value=>{if(!value.isWellFormed())throw Error('invalid JSON Unicode');boundary.text(value);return value;};
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  if(value===null){boundary.node(0,wireDepth);return jsonVariant(0);}
  switch(typeof value){
   case 'boolean':boundary.node(1,wireDepth);return jsonVariant(1,value);
   case 'string':boundary.node(3,wireDepth);return jsonVariant(3,text(value));
   case 'number':
    if(!Number.isFinite(value))throw Error('non-finite JavaScript numbers are unsupported');
    boundary.node(2,wireDepth);return jsonVariant(2,text(Object.is(value,-0)?'-0':String(value)));
   case 'bigint':boundary.node(2,wireDepth);return jsonVariant(2,text(String(value)));
   case 'object':break;
   default:throw Error('unsupported JavaScript value');
  }
  if(active.has(value))throw Error('cyclic JavaScript value');
  active.add(value);
  try{
   if(Array.isArray(value)){
    boundary.node(4,wireDepth);const count=jsonJSArray(value,remaining),items=[];
    for(let i=0;i<count;i++)items.push(visit(jsonJSData(value,String(i)),depth+1,wireDepth+8));
    return jsonVariant(4,items);
   }
   boundary.node(5,wireDepth);const keys=jsonJSKeys(value),members=[];
   if(keys.length>remaining)throw Error('JSON node limit');
   for(const key of keys){
    if(!key.isWellFormed())throw Error('invalid JSON Unicode');
    boundary.member(key,wireDepth);
    members.push({key,value:visit(jsonJSData(value,key),depth+1,wireDepth+9)});
   }
   return jsonVariant(5,members);
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
function jsonDecimalKey(token){
 const [,sign,whole,fraction='',exponent='0']=/^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(token);
 const digits=(whole+fraction).replace(/^0+/,'');
 if(!digits)return '0';
 const trimmed=digits.replace(/0+$/,'');
 return sign+trimmed+'e'+(Number(exponent)-fraction.length+digits.length-trimmed.length);
}
function jsonToJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),mode=options?.numbers??'number',active=new WeakSet();let remaining=limits.nodes;
 if(!['number','bigint','string'].includes(mode))throw Error('unknown JavaScript number policy');
 const number=token=>{
  if(!jsonNumberToken(token))throw Error('invalid JSON number');
  boundary.text(token);
  if(mode==='string')return token;
  if(mode==='bigint')return BigInt(jsonInteger(token,4096));
  const result=Number(token);
  if(!Number.isFinite(result)||jsonDecimalKey(token)!==jsonDecimalKey(String(result)))throw Error('JSON number loses precision as JavaScript Number; choose numbers: bigint or string');
  return result;
 };
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  jsonJSRecord(value,['payload']);
  if(active.has(value))throw Error('cyclic JSON value');
  active.add(value);
  try{
   let payload=jsonJSData(value,'payload'),index=0;
   while(index<5&&Object.hasOwn(payload,'Err')){jsonJSRecord(payload,['Err']);payload=jsonJSData(payload,'Err');index++;}
   if(index<5){jsonJSRecord(payload,['Ok']);payload=jsonJSData(payload,'Ok');}
   jsonJSRecord(payload,index===0?[]:['item0']);boundary.node(index,wireDepth);
   const item=index===0?null:jsonJSData(payload,'item0');
   if(index===0)return null;
   if(index===1){if(typeof item!=='boolean')throw Error('invalid JSON Boolean');return item;}
   if(index===2)return number(item);
   if(index===3){if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary.text(item);return item;}
   const count=jsonJSArray(item,remaining);
   if(index===4){const out=[];for(let i=0;i<count;i++)out.push(visit(jsonJSData(item,String(i)),depth+1,wireDepth+8));return out;}
   const out={},seen=new Set();
   for(let i=0;i<count;i++){
    const member=jsonJSData(item,String(i));jsonJSRecord(member,['key','value']);const key=jsonJSData(member,'key');
    if(typeof key!=='string'||!key.isWellFormed())throw Error('invalid JSON member key');
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary.member(key,wireDepth);
    Object.defineProperty(out,key,{value:visit(jsonJSData(member,'value'),depth+1,wireDepth+9),enumerable:true,writable:true,configurable:true});
   }
   return out;
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
const jsonConstructionPaths=Object.freeze(Array.from({length:6},(_,index)=>Object.freeze([0,...Array(index).fill(1),...(index<5?[0]:[]),0])));
function parseJsonConstructed(text,options,builder){
 const p=new JsonWireReader(text,options);
 const paths=jsonConstructionPaths;
 const fused=typeof builder.openPath==='function';
 const begin=index=>{if(fused){builder.openPath(paths[index]);return;}for(const choice of paths[index])builder.open(choice);};
 const end=index=>{for(let i=0;i<(fused?1:index<5?index+3:7);i++)builder.close();};
 const leaf=(index,item)=>{if(typeof builder.scalarPath==='function'){builder.scalarPath(paths[index],item);return;}begin(index);builder.scalar(item);end(index);};
 const value=d=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){p.at+=4;if(typeof builder.emptyPath==='function')builder.emptyPath(paths[0]);else{begin(0);end(0);}return;}
  if(c==='t'&&text.startsWith('true',p.at)){p.at+=4;leaf(1,true);return;}
  if(c==='f'&&text.startsWith('false',p.at)){p.at+=5;leaf(1,false);return;}
  if(c==='"'){leaf(3,p.string());return;}
  if(c==='['){begin(4);builder.open(0);p.at++;if(!p.eat(']'))while(true){value(d+1);if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}builder.close();end(4);return;}
  if(c==='{'){begin(5);builder.open(0);p.at++;const seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');builder.open(0);builder.scalar(key);value(d+1);builder.close();if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}builder.close();end(5);return;}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();leaf(2,token);return;}
  throw Error('invalid JSON value');
 };
 value(0);p.finish();return builder.finish();
}
const jsonCompiledRenderers=new WeakMap();
function compiledJsonRenderer(json,codec,unwrap){
 if(typeof codec?.reducer!=='function')throw Error('compiled JSON reduction unavailable');
 const source=codec.resolve(codec.descriptor.root),root=json.values.descriptor.root;
 const selected=unwrap&&source.kind==='result'?codec.resolve(source.ok):source;
 if(!jsonSameSchema(root,selected)||unwrap&&source.kind!=='result')throw Error('compiled JSON schema mismatch');
 let variants=root.fields[0].type;const roles=new Map([[root.name,'root']]);
 let member;
 for(let index=0;index<6;index++){
  const branch=index<5?variants.ok:variants;roles.set(branch.name,index);
  if(index===5){member=branch.fields[0].type.element.name;roles.set(member,'member');}
  if(index<5)variants=variants.error;
 }
 const nodeRoles=new Map();
 return codec.reducer((node,index)=>{
  const role=roles.get(node.name);nodeRoles.set(index,role);
  if(node.kind==='record'){
   if(role==='root')return value=>value;
   if(role==='member')return (key,value,context)=>{
    const text=(context.quoter?context.quote(key,true):context.add(JSON.stringify(key)+':'))+value,seen=context.members;
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);return text;
   };
   if(role===0)return context=>context.add('null');
   if(role===1)return (value,context)=>context.add(value?'true':'false');
   if(role===2)return (token,context)=>{if(!jsonNumberToken(token))throw Error('invalid JSON number');return context.add(token);};
   if(role===3)return (value,context)=>context.quoter?context.quote(value,false):context.add(JSON.stringify(value));
   if(role===4)return (value,context)=>{context.add('[]');return '['+value+']';};
   if(role===5)return (value,context)=>{context.add('{}');return '{'+value+'}';};
   return ()=>null;
  }
  if(node.kind==='list'||node.kind==='vector'){
   const members=nodeRoles.get(node.children[0])==='member';
   return {
    start:(_length,context)=>{
     const out={text:'',parent:members?context.members:null};
     if(members)context.members=new Set();return out;
    },
    step:(out,value,index,context)=>{out.text+=(index?context.add(','):'')+value;return out;},
    finish:(out,context)=>{if(members)context.members=out.parent;return out.text;},
   };
  }
  if(node.kind==='result'){
   // A Result<Json,E> boundary is explicitly requested by the caller. Ordinary
   // JSON's own sums only propagate an already rendered branch.
   if(unwrap&&nodeRoles.get(node.children[0])==='root')return (tag,value)=>{if(tag)throw Error('JSON result is Err');return value;};
   return (_tag,value)=>value;
  }
  if(node.kind==='string')return value=>{if(!value.isWellFormed())throw Error('invalid JSON String');return value;};
  return value=>value;
 });
}
export class JsonCodec{
 constructor(valueCodec){
  const root=valueCodec.descriptor.root,fields=root.fields;if(root.kind!=='record'||!Array.isArray(fields)||fields.length!==1||fields[0].name!=='payload')throw Error('JSON schema payload');let sum=fields[0].type;
  for(let i=0;i<6;i++){
   if(i<5&&sum.kind!=='result')throw Error('JSON schema sum');const branch=i<5?sum.ok:sum,fs=branch.fields;
   if(branch.kind!=='record'||!Array.isArray(fs)||fs.length!==(i?1:0)||i&&fs[0].name!=='item0')throw Error('JSON schema branch');
   if(i){const t=fs[0].type;if(i===1&&t.kind!=='bool'||(i===2||i===3)&&t.kind!=='string'||i===4&&(t.kind!=='list'||t.element.kind!=='ref'||t.element.name!==root.name))throw Error('JSON schema variant');if(i===5){const mf=t.element?.fields;if(t.kind!=='list'||t.element?.kind!=='record'||!Array.isArray(mf)||mf.length!==2||mf[0].name!=='key'||mf[0].type.kind!=='string'||mf[1].name!=='value'||mf[1].type.kind!=='ref'||mf[1].type.name!==root.name)throw Error('JSON schema member');}}
   if(i===2)this.numberBranch=branch.name;if(i===5)this.objectBranch=branch.name;
   if(i<5)sum=sum.error;
  }if(!jsonSameSchema(root,valueCodec.resolve({kind:'ref',name:root.name})))throw Error('JSON recursive schema mismatch');this.values=valueCodec;
 }
 parse(text,options={}){return parseJsonValue(text,options,jsonBoundaryBudget(options));}
 parseCompiled(codec,text,options={}){
  if(codec?.identity!==this.values.descriptor.identity||typeof codec.builder!=='function')throw Error('compiled JSON schema mismatch');
  const builder=codec.builder(options);try{return parseJsonConstructed(text,options,builder);}catch(error){builder.abort();throw error;}
 }
 stringify(value,options={}){return stringifyJsonValue(value,options,jsonBoundaryBudget(options));}
 stringifyCompiled(codec,handle,options={}){
  const limits=checkedJsonLimits(options),unwrap=options.unwrapResult===true;
  const quoter=options.quoter;if(quoter!==undefined&&!jsonQuoters.has(quoter))throw Error('JSON quote cache owner mismatch');
  let codecs=jsonCompiledRenderers.get(this);if(!codecs)jsonCompiledRenderers.set(this,codecs=new WeakMap());
  let renderers=codecs.get(codec);if(!renderers)codecs.set(codec,renderers=new Map());
  let render=renderers.get(unwrap);if(!render)renderers.set(unwrap,render=compiledJsonRenderer(this,codec,unwrap));
  let bytes=0;const context={
   quoter,
   add(text){bytes+=jsonUtf8Length(text);if(bytes>limits.bytes)throw Error('JSON byte limit');return text;},
   quote(value,colon){
    if(!quoter)return this.add(JSON.stringify(value)+(colon?':':''));
    const token=quoter.token(value);bytes+=token.utf8Bytes+(colon?1:0);if(bytes>limits.bytes)throw Error('JSON byte limit');return token.text+(colon?':':'');
   },
  };
  const text=render(handle,context,limits);
  return text;
 }
 fromJS(value,options={}){return jsonFromJS(value,options);}
 toJS(value,options={}){return jsonToJS(value,options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,false);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,false,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,true);}
 validateBinary(bytes,options={}){
  const decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});let view;
  this.values.visitSpans(bytes,(type,data,start,end)=>{
   view??=new DataView(data.buffer,data.byteOffset,data.byteLength);
   if(type.name===this.numberBranch){const length=view.getUint32(start,true);if(!jsonNumberSpan(data,start+4,start+4+length))throw Error('invalid JSON number token');}
   if(type.name===this.objectBranch){const listEnd=start+4+view.getUint32(start,true),count=view.getUint32(start+4,true),seen=new Set();let at=start+8;for(let i=0;i<count;i++){const memberEnd=at+4+view.getUint32(at,true),keyStart=at+8,keyEnd=keyStart+view.getUint32(at+4,true),key=decoder.decode(data.subarray(keyStart,keyEnd));if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);at=memberEnd;}if(at!==listEnd)throw Error('invalid JSON object frame');}
  },options,[this.numberBranch,this.objectBranch]);return true;

 }
}
function jsonUnpack(value){let p=value.payload,i=0;while(i<5&&Object.hasOwn(p,'Err')){p=p.Err;i++;}return [i,(i<5?p.Ok:p).item0];}
function jsonInteger(token,limit){
 if(!jsonNumberToken(token))throw Error('invalid JSON number');const negative=token[0]==='-',raw=negative?token.slice(1):token,[mantissa,exp='0']=raw.split(/[eE]/);let digits=mantissa.replace('.','');if(/^0+$/.test(digits))return '0';const exponent=Number(exp),fraction=mantissa.includes('.')?mantissa.length-mantissa.indexOf('.')-1:0,shift=exponent-fraction;
 if(!Number.isSafeInteger(exponent)||!Number.isSafeInteger(shift))throw Error('JSON integer exponent limit');
 if(shift<0){const cut=-shift;if(cut>=digits.length||!/^[0]+$/.test(digits.slice(-cut)))throw Error('JSON number is not an integer');digits=digits.slice(0,-cut);}else{if(digits.length+shift>limit)throw Error('JSON integer magnitude limit');digits+='0'.repeat(shift);}
 digits=digits.replace(/^0+/,'');if(digits.length>limit)throw Error('JSON integer magnitude limit');return (negative?'-':'')+digits;
}
function jsonBinary64Value(v){
 if(typeof v==='number')return v;
 const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid F64Bits');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');
 const b=new DataView(new ArrayBuffer(8));b.setBigUint64(0,bits,true);return b.getFloat64(0,true);
}
export class TypedJsonCodec{
 constructor(valueCodec){this.values=valueCodec;}
 decode(document,options={}){
  // Validate JSON-specific invariants before interpreting any tagged/record
  // shape, including duplicated names and malformed numeric tokens.
  stringifyJson(document,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const read=(type,value,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type),[kind,item]=jsonUnpack(value);const fail=()=>{throw Error('JSON does not match '+t.kind);};
   switch(t.kind){
    case 'unit':if(kind!==0)fail();return null;
    case 'bool':if(kind!==1)fail();return item;
    case 'u32':case 'u64':case 'i32':case 'int':{if(kind!==2)fail();const text=jsonInteger(item,t.kind==='int'?4096:t.kind==='u64'?20:10);return t.kind==='int'?{Int:text}:t.kind==='u64'?BigInt(text):Number(text);}
    case 'f64':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(8));if(!Number.isFinite(n))throw Error('JSON f64 overflow');b.setFloat64(0,n,true);return {F64Bits:b.getBigUint64(0,true).toString()};}
    case 'f32':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(4));b.setFloat32(0,n,true);if(!Number.isFinite(b.getFloat32(0,true)))throw Error('JSON f32 overflow');return {F32Bits:b.getUint32(0,true)};}
    case 'string':case 'enum':case 'id':if(kind!==3)fail();return item;
    case 'list':case 'vector':if(kind!==4)fail();return item.map(x=>read(t.element,x,d+1));
    case 'record':{if(kind!==5||item.length!==t.fields.length)throw Error('unknown or missing JSON record field');const fields=new Map(item.map(m=>[m.key,m.value])),out={};for(const f of t.fields){if(!fields.has(f.name))throw Error('missing JSON record field');Object.defineProperty(out,f.name,{value:read(f.type,fields.get(f.name),d+1),writable:true,enumerable:true,configurable:true});}return out;}
    case 'option':case 'result':{if(kind!==5||item.length!==1)fail();const m=item[0];if(t.kind==='option'&&m.key==='None'&&jsonUnpack(m.value)[0]===0)return {None:null};const child=t.kind==='option'&&m.key==='Some'?t.element:t.kind==='result'&&m.key==='Ok'?t.ok:t.kind==='result'&&m.key==='Err'?t.error:null;if(!child)fail();return {[m.key]:read(child,m.value,d+1)};}
    default:fail();
   }
  };
  const out=read(this.values.descriptor.root,document,0);this.values.validateValue(out,options);return out;
 }
 encode(value,options={}){
  this.values.validateValue(value,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const write=(type,v,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type);
   switch(t.kind){
    case 'unit':return jsonVariant(0);
    case 'bool':return jsonVariant(1,v);
    case 'u32':case 'u64':case 'i32':return jsonVariant(2,String(v));
    case 'int':return jsonVariant(2,typeof v==='bigint'?String(v):v.Int);
    case 'f64':{const n=jsonBinary64Value(v);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'f32':{let n;if(typeof v==='number')n=Math.fround(v);else{const b=new DataView(new ArrayBuffer(4));b.setUint32(0,v.F32Bits,true);n=b.getFloat32(0,true);}if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'string':case 'id':case 'enum':return jsonVariant(3,v);
    case 'list':case 'vector':return jsonVariant(4,Array.from(v,x=>write(t.element,x,d+1)));
    case 'record':return jsonVariant(5,t.fields.map(f=>({key:f.name,value:write(f.type,v[f.name],d+1)})));
    case 'option':return jsonVariant(5,[Object.hasOwn(v,'Some')?{key:'Some',value:write(t.element,v.Some,d+1)}:{key:'None',value:jsonVariant(0)}]);
    case 'result':return jsonVariant(5,[Object.hasOwn(v,'Ok')?{key:'Ok',value:write(t.ok,v.Ok,d+1)}:{key:'Err',value:write(t.error,v.Err,d+1)}]);
    default:throw Error('unsupported typed JSON descriptor');
   }
  };return write(this.values.descriptor.root,value,0);
 }
 parse(text,options={}){return this.decode(parseJson(text,options),options);}
 stringify(value,options={}){return stringifyJson(this.encode(value,options),options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,true);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,true,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,false);}
}

// Token reader shared by schema-directed and arbitrary-JSON wire emission.
class JsonWireReader{
 constructor(text,options){this.l=checkedJsonLimits(options);if(typeof text!=='string'||!text.isWellFormed()||text.length>this.l.bytes||jsonUtf8Length(text)>this.l.bytes)throw Error('JSON byte or Unicode limit');this.text=text;this.at=0;this.remaining=this.l.nodes;}
 ws(){while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(c!==32&&c!==9&&c!==10&&c!==13)break;this.at++;}}
 peek(){this.ws();return this.text[this.at];}
 eat(c){this.ws();if(this.text[this.at]===c){this.at++;return true;}return false;}
 node(d){if(d>this.l.depth||--this.remaining<0)throw Error('JSON node or depth limit');}
 string(){
  this.ws();const start=this.at;if(this.text[start]!=='"')throw Error('expected JSON string');
  const end=this.text.indexOf('"',start+1);if(end<0)throw Error('unterminated JSON string');
  const raw=this.text.slice(start+1,end);
  if(!raw.includes('\\')&&!/[\x00-\x1f]/.test(raw)){this.at=end+1;return raw;}
  this.at=start+1;while(this.at<this.text.length){if(this.text[this.at]==='"'){this.at++;const v=JSON.parse(this.text.slice(start,this.at));if(!v.isWellFormed())throw Error('invalid JSON Unicode');return v;}if(this.text[this.at]==='\\')this.at+=2;else this.at++;}throw Error('unterminated JSON string');
 }
 number(){const start=this.at;while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(!(c>=48&&c<=57||c===45||c===43||c===46||c===101||c===69))break;this.at++;}const token=this.text.slice(start,this.at);if(!jsonNumberToken(token))throw Error('invalid JSON number');return token;}
 leaf(d){this.node(d);const c=this.peek();if(c==='n'&&this.text.startsWith('null',this.at)){this.at+=4;return null;}if(c==='t'&&this.text.startsWith('true',this.at)){this.at+=4;return true;}if(c==='f'&&this.text.startsWith('false',this.at)){this.at+=5;return false;}if(c==='"')return this.string();if(c==='-'||c>='0'&&c<='9')return this.number();throw Error('invalid JSON scalar');}
 finish(){this.ws();if(this.at!==this.text.length)throw Error('trailing JSON text');}
}
function streamJsonBinary(values,text,options,typed,compact=false){
 const p=new JsonWireReader(text,options),utf8=jsonWireEncoder;
 const list=(w,open,close,item)=>{if(!p.eat(open))throw Error('JSON container shape');const at=w.beginCount();let count=0;if(!p.eat(close))while(true){item(w);count++;if(p.eat(close))break;if(!p.eat(','))throw Error('JSON container separator');}w.endCount(at,count);};
 const variant=(w,index,level,emit)=>{if(level<index)w.frame(w=>{w.byte(1);variant(w,index,level+1,emit);});else if(index<5)w.frame(w=>{w.byte(0);w.frame(emit);});else w.frame(emit);};
 const json=(w,d)=>{
  const ch=p.peek(),index=ch==='n'?0:ch==='t'||ch==='f'?1:ch==='-'||ch>='0'&&ch<='9'?2:ch==='"'?3:ch==='['?4:ch==='{'?5:-1;if(index<0)throw Error('invalid JSON value');
  const leaf=index<4?p.leaf(d):null;if(index>=4)p.node(d);
  w.frame(w=>variant(w,index,0,w=>{
   if(index===0)return;if(index===1){w.frame(w=>w.byte(+leaf));return;}
   if(index===2||index===3){w.frame(w=>w.text(leaf));return;}
   w.frame(w=>{if(index===4)list(w,'[',']',w=>json(w,d+1));else{const seen=new Set();list(w,'{','}',w=>{const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');w.frame(w=>{w.frame(w=>w.text(key));json(w,d+1);});});}});
  }));
 };
 const read=(type,w,d)=>{
  const t=values.resolve(type);w.frame(w=>{
   if(t.kind==='list'||t.kind==='vector'){p.node(d);list(w,'[',']',w=>read(t.element,w,d+1));return;}
   if(t.kind==='record'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON record');const start=w.position,spans=new Array(t.fields.length).fill(null);
    if(!p.eat('}'))while(true){const key=p.string(),i=t.fields.findIndex(f=>f.name===key);if(i<0)throw Error('unknown JSON record field');if(spans[i])throw Error('duplicate JSON record field');if(!p.eat(':'))throw Error('JSON record colon');const at=w.position;read(t.fields[i].type,w,d+1);spans[i]=[at,w.position];if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON record separator');}
    if(spans.some(s=>s===null))throw Error('missing JSON record field');w.reorder(start,spans);return;
   }
   if(t.kind==='option'||t.kind==='result'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON tagged value');const key=p.string();if(!p.eat(':'))throw Error('JSON tag colon');
    if(t.kind==='option'&&key==='None'){if(p.leaf(d+1)!==null)throw Error('JSON None payload');w.byte(0);}
    else{const child=t.kind==='option'&&key==='Some'?t.element:t.kind==='result'&&key==='Ok'?t.ok:t.kind==='result'&&key==='Err'?t.error:null;if(!child)throw Error('invalid JSON tag');w.byte(key==='Ok'?0:1);read(child,w,d+1);}
    if(!p.eat('}'))throw Error('expected exactly one JSON tag');return;
   }
   const ch=p.peek(),v=p.leaf(d),bad=()=>{throw Error('JSON does not match '+t.kind);};
   if(t.kind==='unit'){if(v!==null)bad();return;}
   if(t.kind==='bool'){if(typeof v!=='boolean')bad();w.byte(+v);return;}
   if(['string','id','enum'].includes(t.kind)){if(ch!=='"')bad();w.text(v);return;}
   if(ch!=='-'&&!(ch>='0'&&ch<='9'))bad();
   if(t.kind==='int'){w.text(jsonInteger(v,4096));return;}
   if(t.kind==='f64'){const n=Number(v);if(!Number.isFinite(n))throw Error('JSON f64 overflow');const b=new DataView(new ArrayBuffer(8));b.setFloat64(0,n,true);w.wide(b.getBigUint64(0,true));}
   else if(t.kind==='f32'){jsonFloatScratch.setFloat32(0,Number(v),true);if(!Number.isFinite(jsonFloatScratch.getFloat32(0,true)))throw Error('JSON f32 overflow');w.word(jsonFloatScratch.getUint32(0,true));}
   else{const n=BigInt(jsonInteger(v,t.kind==='u64'?20:10));if(t.kind==='u64'){if(n<0n||n>18446744073709551615n)bad();w.wide(n);}else if(t.kind==='u32'){if(n<0n||n>4294967295n)bad();w.word(Number(n));}else if(t.kind==='i32'){if(n< -2147483648n||n>2147483647n)bad();w.word(Number(n)>>>0);}else bad();}
  });
 };
 return (compact?values.compact():values).encodeWith(w=>{if(typed)read(values.descriptor.root,w,0);else json(w,0);p.finish();},options);
}

// Render validated bytes in a single traversal; only the final text is owned.
function streamWireJsonText(values,bytes,options,library){
 values.validate(bytes,options);const l=checkedJsonLimits(options),parts=[];let size=0,remaining=l.nodes;const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 const emit=s=>{size+=jsonUtf8Length(s);if(size>l.bytes)throw Error('JSON byte limit');parts.push(s);};
 const string=s=>emit(JSON.stringify(s));const node=d=>{if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');};
 const frame=(type,at)=>{const t=values.resolve(type),start=at+4,end=start+dv.getUint32(at,true);return{t,start,end};};
 const json=(type,at,d)=>{
  node(d);let root=frame(type,at),sum=frame(root.t.fields[0].type,root.start),index=0;
  while(index<5){const err=bytes[sum.start];sum=frame(err?sum.t.error:sum.t.ok,sum.start+1);if(!err)break;index++;}
  if(index===0){emit('null');return root.end;}
  const item=frame(sum.t.fields[0].type,sum.start);
  if(index===1)emit(bytes[item.start]?'true':'false');
  else if(index===2){const token=decoder.decode(bytes.subarray(item.start,item.end));if(!jsonNumberToken(token))throw Error('invalid JSON number token');emit(token);}
  else if(index===3)string(decoder.decode(bytes.subarray(item.start,item.end)));
  else{const count=dv.getUint32(item.start,true);let p=item.start+4;emit(index===4?'[':'{');const seen=new Set();for(let i=0;i<count;i++){if(i)emit(',');if(index===4)p=json(item.t.element,p,d+1);else{const member=frame(item.t.element,p),key=frame(member.t.fields[0].type,member.start),name=decoder.decode(bytes.subarray(key.start,key.end));if(seen.has(name))throw Error('duplicate JSON object key');seen.add(name);string(name);emit(':');json(member.t.fields[1].type,key.end,d+1);p=member.end;}}emit(index===4?']':'}');}
  return root.end;
 };
 const typed=(type,at,d)=>{
  node(d);const f=frame(type,at),t=f.t;let p=f.start;
  switch(t.kind){
   case 'unit':emit('null');break;
   case 'bool':emit(bytes[p]?'true':'false');break;
   case 'u32':emit(String(dv.getUint32(p,true)));break;
   case 'u64':emit(String(dv.getBigUint64(p,true)));break;
   case 'i32':emit(String(dv.getInt32(p,true)));break;
   case 'f64':{const n=dv.getFloat64(p,true);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'f32':{const n=dv.getFloat32(p,true);if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'int':emit(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'string':case 'id':case 'enum':string(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'list':case 'vector':{const n=dv.getUint32(p,true);p+=4;emit('[');for(let i=0;i<n;i++){if(i)emit(',');p=typed(t.element,p,d+1);}emit(']');break;}
   case 'record':emit('{');for(let i=0;i<t.fields.length;i++){if(i)emit(',');const field=t.fields[i];string(field.name);emit(':');p=typed(field.type,p,d+1);}emit('}');break;
   case 'option':case 'result':{const tag=bytes[p++],key=t.kind==='option'?(tag?'Some':'None'):tag?'Err':'Ok';emit('{');string(key);emit(':');if(t.kind==='option'&&!tag){node(d+1);emit('null');}else typed(t.kind==='option'?t.element:tag?t.error:t.ok,p,d+1);emit('}');break;}
   default:throw Error('unsupported typed JSON descriptor');
  }return f.end;
 };
 if(library)json(values.descriptor.root,40,0);else typed(values.descriptor.root,40,0);return parts.join('');
}

/** Owned, optional read view of arbitrary JSON. Auxiliary indexes contain member
 * offsets only. Logical order, exact number tokens and missing/null remain intact.
 * This does not transparently replace any compiled Ink action or its state.
 */
export function createJsonLookup(text,{stepEntries=16,minReads=4,maxEntries=4096,maxObjects=64,maxIndexBytes=262144,...limits}={}){
 for(const [v,max]of [[stepEntries,4096],[minReads,1000000],[maxEntries,1000000],[maxObjects,256],[maxIndexBytes,16777216]])if(!Number.isSafeInteger(v)||v<0||v>max)throw Error('JSON index budget');
 let root=parseJson(text,limits),indexes=new Map(),entries=0,indexBytes=0;
 const stats={reads:0,writes:0,scanned_members:0,index_hits:0,built_entries:0,invalidations:0};
 function parts(path){
  if(!Array.isArray(path))throw Error('JSON lookup path');const n=path.length;if(n>128)throw Error('JSON lookup path');
  const owned=[];for(let i=0;i<n;i++){const d=Object.getOwnPropertyDescriptor(path,String(i));if(!d||!Object.hasOwn(d,'value'))throw Error('JSON lookup path');const p=d.value;if(!(typeof p==='string'&&p.isWellFormed()&&p.length<=4096)&&!(Number.isSafeInteger(p)&&p>=0))throw Error('JSON lookup path');owned.push(p);}return owned;
 }
 function variant(value){let p=value.payload,index=0;while(index<5&&Object.hasOwn(p,'Err')){p=p.Err;index++;}return {index,item:(index<5?p.Ok:p).item0};}
 function resolve(document,path,indexed){
  let value=document,budget=stepEntries;
  for(let depth=0;depth<path.length;depth++){
   const part=path[depth],v=variant(value);
   if(typeof part==='number'){
    if(v.index!==4)throw Error('expected JSON array');if(part>=v.item.length)return {found:false};value=v.item[part];continue;
   }
   if(v.index!==5)throw Error('expected JSON object');
   const prefix=path.slice(0,depth),key=JSON.stringify(prefix),overhead=128+prefix.reduce((n,p)=>n+(typeof p==='string'?16+p.length*2:8),0);let idx=indexed?indexes.get(key):null;
   if(indexed&&!idx&&indexes.size<maxObjects&&indexBytes+overhead<=maxIndexBytes){idx={path:prefix,reads:0,cursor:0,keys:new Map(),bytes:overhead};indexes.set(key,idx);indexBytes+=overhead;}
   if(idx){
    idx.reads++;
    if(idx.reads>=minReads)while(budget>0&&idx.cursor<v.item.length&&entries<maxEntries){
     const member=v.item[idx.cursor],bytes=64+member.key.length*2;
     if(indexBytes+bytes>maxIndexBytes)break;
     idx.keys.set(member.key,idx.cursor++);idx.bytes+=bytes;indexBytes+=bytes;entries++;stats.built_entries++;budget--;
    }
    if(idx.keys.has(part)){stats.index_hits++;value=v.item[idx.keys.get(part)].value;continue;}
   }
   let found=false;
   for(let i=idx?.cursor??0;i<v.item.length;i++){if(indexed)stats.scanned_members++;if(v.item[i].key===part){value=v.item[i].value;found=true;break;}}
   if(!found)return {found:false};
  }
  return {found:true,value};
 }
 return {
  lookup(path){stats.reads++;const r=resolve(root,parts(path),true);return r.found?{found:true,value:structuredClone(r.value)}:r;},
  set(path,key,text){
   path=parts(path);if(typeof key!=='string'||!key.isWellFormed())throw Error('JSON object key');
   const replacement=parseJson(text,limits),next=structuredClone(root),r=resolve(next,path,false);
   if(!r.found)throw Error('JSON update path missing');const object=variant(r.value);if(object.index!==5)throw Error('expected JSON object');
   const members=[{key,value:replacement},...object.item.filter(m=>m.key!==key)];
   // Validate the complete resulting document before publishing a write.
   let payload=r.value.payload;for(let i=0;i<5;i++)payload=payload.Err;payload.item0=members;
   stringifyJson(next,limits);root=next;stats.writes++;
   for(const [id,idx]of indexes)if(idx.path.length>=path.length&&path.every((p,i)=>p===idx.path[i])){entries-=idx.keys.size;indexBytes-=idx.bytes;indexes.delete(id);stats.invalidations++;}
  },
  replace(text){const next=parseJson(text,limits);root=next;stats.writes++;stats.invalidations+=indexes.size;indexes.clear();entries=0;indexBytes=0;},
  stringify(){return stringifyJson(root,limits);},
  stats(){return {...stats,index_entries:entries,index_objects:indexes.size,index_bytes:indexBytes};}
 };
}
function __ownedValue7(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue4(value[i],budget,depth+1);return out;}
function __ownedValue11(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue12(value[i],budget,depth+1);return out;}
function __ownedValue10(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue5(value[i],budget,depth+1);return out;}
function __ownedValue4(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue0(value[i],budget,depth+1);return out;}
function __ownedValue17(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue11(value.Ok,budget,depth+1)}:{Err:__ownedValue14(value.Err,budget,depth+1)};}
function __ownedValue18(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue4(value.Ok,budget,depth+1)}:{Err:__ownedValue14(value.Err,budget,depth+1)};}
function __ownedValue19(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue12(value.Ok,budget,depth+1)}:{Err:__ownedValue14(value.Err,budget,depth+1)};}
function __ownedValue8(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue9(value.Ok,budget,depth+1)}:{Err:__ownedValue14(value.Err,budget,depth+1)};}
function __ownedValue15(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue16(value.Ok,budget,depth+1)}:{Err:__ownedValue14(value.Err,budget,depth+1)};}
function __ownedValue21(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue22(value.Ok,budget,depth+1)}:{Err:__ownedValue14(value.Err,budget,depth+1)};}
function __ownedValue2(value,budget,depth){budget.enter(depth,4);return {["a"]:__ownedValue3(value["a"],budget,depth+1),["b"]:__ownedValue3(value["b"],budget,depth+1),["c"]:__ownedValue3(value["c"],budget,depth+1),["d"]:__ownedValue3(value["d"],budget,depth+1)};}
function __ownedValue12(value,budget,depth){budget.enter(depth,4);return {["action"]:__ownedValue13(value["action"],budget,depth+1),["probability"]:__ownedValue0(value["probability"],budget,depth+1),["score"]:__ownedValue4(value["score"],budget,depth+1)};}
function __ownedValue9(value,budget,depth){budget.enter(depth,4);return {["choices"]:__ownedValue10(value["choices"],budget,depth+1),["decisions"]:__ownedValue11(value["decisions"],budget,depth+1)};}
function __ownedValue16(value,budget,depth){budget.enter(depth,4);return {["code"]:__ownedValue10(value["code"],budget,depth+1),["decisions"]:__ownedValue11(value["decisions"],budget,depth+1)};}
function __ownedValue3(value,budget,depth){budget.enter(depth,4);return {["identity"]:__ownedValue0(value["identity"],budget,depth+1),["scale"]:__ownedValue0(value["scale"],budget,depth+1),["bias"]:__ownedValue0(value["bias"],budget,depth+1),["relu"]:__ownedValue0(value["relu"],budget,depth+1)};}
function __ownedValue6(value,budget,depth){budget.enter(depth,4);return {["masses"]:__ownedValue4(value["masses"],budget,depth+1),["derivatives"]:__ownedValue7(value["derivatives"],budget,depth+1)};}
function __ownedValue20(value,budget,depth){budget.enter(depth,4);return {["rate"]:__ownedValue0(value["rate"],budget,depth+1),["first_decay"]:__ownedValue0(value["first_decay"],budget,depth+1),["second_decay"]:__ownedValue0(value["second_decay"],budget,depth+1),["epsilon"]:__ownedValue0(value["epsilon"],budget,depth+1),["weight_decay"]:__ownedValue0(value["weight_decay"],budget,depth+1),["norm_limit"]:__ownedValue0(value["norm_limit"],budget,depth+1)};}
function __ownedValue23(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue0(value["value"],budget,depth+1),["tangent_0"]:__ownedValue0(value["tangent_0"],budget,depth+1),["tangent_1"]:__ownedValue0(value["tangent_1"],budget,depth+1),["tangent_2"]:__ownedValue0(value["tangent_2"],budget,depth+1),["tangent_3"]:__ownedValue0(value["tangent_3"],budget,depth+1),["tangent_4"]:__ownedValue0(value["tangent_4"],budget,depth+1),["tangent_5"]:__ownedValue0(value["tangent_5"],budget,depth+1),["tangent_6"]:__ownedValue0(value["tangent_6"],budget,depth+1),["tangent_7"]:__ownedValue0(value["tangent_7"],budget,depth+1),["tangent_8"]:__ownedValue0(value["tangent_8"],budget,depth+1),["tangent_9"]:__ownedValue0(value["tangent_9"],budget,depth+1),["tangent_10"]:__ownedValue0(value["tangent_10"],budget,depth+1),["tangent_11"]:__ownedValue0(value["tangent_11"],budget,depth+1),["tangent_12"]:__ownedValue0(value["tangent_12"],budget,depth+1),["tangent_13"]:__ownedValue0(value["tangent_13"],budget,depth+1),["tangent_14"]:__ownedValue0(value["tangent_14"],budget,depth+1),["tangent_15"]:__ownedValue0(value["tangent_15"],budget,depth+1)};}
function __ownedValue22(value,budget,depth){budget.enter(depth,4);return {["weights"]:__ownedValue4(value["weights"],budget,depth+1),["first"]:__ownedValue4(value["first"],budget,depth+1),["second"]:__ownedValue4(value["second"],budget,depth+1),["steps"]:__ownedValue13(value["steps"],budget,depth+1),["first_power"]:__ownedValue0(value["first_power"],budget,depth+1),["second_power"]:__ownedValue0(value["second_power"],budget,depth+1)};}
function __ownedValue1(value,budget,depth){budget.enter(depth,5);return value;}
function __ownedValue5(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __ownedValue0(value,budget,depth){budget.enter(depth,8);return {F32Bits:value===0?0:value};}
function __ownedValue14(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __ownedValue13(value,budget,depth){budget.enter(depth,8);return value>>>0;}
const __ownedFunctions=Object.freeze(Object.fromEntries([["evaluate",__ownedValue0],["coefficients_valid",__ownedValue1],["goal_valid",__ownedValue1],["squared_error",__ownedValue0],["objective",__ownedValue0],["unpack",__ownedValue2],["pack",__ownedValue4],["mass",__ownedValue0],["operation",__ownedValue5],["distribution",__ownedValue6],["sample_slot",__ownedValue8],["sample",__ownedValue15],["reward",__ownedValue0],["operation_index",__ownedValue13],["elite_slot",__ownedValue17],["proposal_gradient",__ownedValue18],["valid_policy",__ownedValue1],["numeric",__ownedValue4],["ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54",__ownedValue1],["ink_m28a5428efa573345218636e9cec104f24b6e8c67d7c4c0f979b255813b2abee3",__ownedValue0],["ink_mfd18151b0af45b45f5b48ef5e7a09ac1294681f654e2174ae3b33183f445ef14",__ownedValue18],["ink_mc05a2256079ef1f1818d13e69727dc7902cdb7f70856a671af2ba08ef190d23a",__ownedValue18],["ink_m6ec6e8f9e757c220bfe2ed28cbb8dab4ec520de5ee8de5ca702cbdb805a5f910",__ownedValue13],["ink_maa2c8802d351b443dda0bc206d70fa9fe87756b57a84d0357e9dfb4c1e7a0667",__ownedValue4],["ink_m1774c4db693eebe71b1f79bce053b93633d1e1ec37196dd480b59c0248b4fbc2",__ownedValue4],["ink_m1fbf7ee6cef3bcca5d7d258c8606275806894b60d839126202d17f016ea87c80",__ownedValue19],["ink_m99468fca85aa8fb996f0c891430c813d82505250d39d8e415bf27679ddc39e07",__ownedValue19],["ink_maadd6c30a027af52d851f0828eec45339d218ad3bbe73e4d8d7cdd3892e754f4",__ownedValue18],["ink_m696809152e57d8dfa3f01f9a3e12c048434b9f2af91ff53321ea6ceeeeca5431",__ownedValue18],["ink_m372cbaf2ee2bc8705fad4b5b65a9e744ea468afbe4c153f17c7da282a459d1cd",__ownedValue18],["ink_m43c1e2ac4d6d9a37358654ff5c1abcd42d4b01146c41a7ca617bccb074a8813b",__ownedValue18],["ink_m4b5ada8f7d6b3beaee6fc06bf68e61ca158cbc7664899364dff18d21555697ae",__ownedValue18],["ink_mda500f665e6078213ee2391fedf06240c651d1725327b086aa70cda14bef9a07",__ownedValue18],["ink_meefc22a28d97f5bdc4100b36eeab9549241c3ef201b83c2f75111644d317833d",__ownedValue20],["ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96",__ownedValue1],["ink_m786bdc6011aece08dbf36c5ca89c437e06ff758c9d3d242f723dde2af6ea31db",__ownedValue1],["ink_mdfbd57a9f460147afedb262e2bfe0f6197f9b813c85277c59f5e101900063ad7",__ownedValue21],["ink_m5226ad25deae5e47d7fb65b6b5961d46740dd4e97b54d76a24d3d0445845fe35",__ownedValue1],["ink_m8abb6b2bcbe55251e0b82a28f26d7ce761729346e35019c2b60ca9b5ee22590d",__ownedValue0],["ink_m7d03a2ed6071238ff1b69a8e56a8cb96b9dc3b095b2d939c0ccfed84ee9580b5",__ownedValue0],["ink_m00ba8185ca362d257d138fe1886cbc5f3acc38c4a238bef60c3d3d7fa0276eab",__ownedValue0],["ink_m2a55f95a80595bc61d1fcab41ff00f438ff6f2057b597df20aaae3c18507d2be",__ownedValue21],["__ink_differential_3",__ownedValue23],["__ink_differential_1",__ownedValue2],["__frozen_proposal_3",__ownedValue0],["__frozen_proposal_43",__ownedValue0],["__frozen_proposal_49",__ownedValue0],["__frozen_proposal_110",__ownedValue0],["__frozen_proposal_150",__ownedValue0],["__frozen_proposal_156",__ownedValue0],["__frozen_proposal_166",__ownedValue0]]));
function __wireValue27(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue26(reader);reader.finish(end);return value;}
function __wireValue30(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue31(reader);reader.finish(end);return value;}
function __wireValue7(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue8(reader);reader.finish(end);return value;}
function __wireValue40(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue23(reader);reader.finish(end);return value;}
function __wireValue33(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue34(reader);reader.finish(end);return value;}
function __wireValue26(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue1(reader);reader.finish(end);return value;}
function __wireValue29(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue32(reader)}:{Ok:__wireValue30(reader)};reader.finish(end);return value;}
function __wireValue48(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue32(reader)}:{Ok:__wireValue26(reader)};reader.finish(end);return value;}
function __wireValue42(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue32(reader)}:{Ok:__wireValue31(reader)};reader.finish(end);return value;}
function __wireValue73(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue32(reader)}:{Ok:__wireValue74(reader)};reader.finish(end);return value;}
function __wireValue70(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue32(reader)}:{Ok:__wireValue71(reader)};reader.finish(end);return value;}
function __wireValue46(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue32(reader)}:{Ok:__wireValue45(reader)};reader.finish(end);return value;}
function __wireValue11(reader){const end=reader.frame();const value={["__frozen_proposal_1"]:__wireValue5(reader),["__frozen_proposal_44"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue12(reader){const end=reader.frame();const value={["__frozen_proposal_1"]:__wireValue5(reader),["__frozen_proposal_50"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue10(reader){const end=reader.frame();const value={["__frozen_proposal_1"]:__wireValue5(reader),["__frozen_proposal_7"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue0(reader){const end=reader.frame();const value={["__frozen_proposal_114"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue2(reader){const end=reader.frame();const value={["__frozen_proposal_151"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue3(reader){const end=reader.frame();const value={["__frozen_proposal_157"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue4(reader){const end=reader.frame();const value={["__frozen_proposal_53"]:__wireValue5(reader),["__frozen_proposal_54"]:__wireValue6(reader)};reader.finish(end);return value;}
function __wireValue18(reader){const end=reader.frame();const value={["a"]:__wireValue19(reader),["b"]:__wireValue19(reader),["c"]:__wireValue19(reader),["d"]:__wireValue19(reader)};reader.finish(end);return value;}
function __wireValue14(reader){const end=reader.frame();const value={["a"]:__wireValue15(reader),["b"]:__wireValue15(reader),["c"]:__wireValue15(reader),["d"]:__wireValue15(reader)};reader.finish(end);return value;}
function __wireValue28(reader){const end=reader.frame();const value={["accumulator"]:__wireValue29(reader),["slot"]:__wireValue9(reader),["w"]:__wireValue14(reader),["code"]:__wireValue33(reader)};reader.finish(end);return value;}
function __wireValue51(reader){const end=reader.frame();const value={["accumulator"]:__wireValue48(reader),["decision"]:__wireValue31(reader),["return_value"]:__wireValue1(reader),["baseline"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue72(reader){const end=reader.frame();const value={["accumulator"]:__wireValue73(reader),["slot"]:__wireValue9(reader),["w"]:__wireValue14(reader),["units"]:__wireValue26(reader)};reader.finish(end);return value;}
function __wireValue31(reader){const end=reader.frame();const value={["action"]:__wireValue9(reader),["probability"]:__wireValue1(reader),["score"]:__wireValue26(reader)};reader.finish(end);return value;}
function __wireValue50(reader){const end=reader.frame();const value={["c"]:__wireValue38(reader)};reader.finish(end);return value;}
function __wireValue74(reader){const end=reader.frame();const value={["choices"]:__wireValue33(reader),["decisions"]:__wireValue30(reader)};reader.finish(end);return value;}
function __wireValue71(reader){const end=reader.frame();const value={["code"]:__wireValue33(reader),["decisions"]:__wireValue30(reader)};reader.finish(end);return value;}
function __wireValue63(reader){const end=reader.frame();const value={["code"]:__wireValue33(reader),["w"]:__wireValue5(reader),["g"]:__wireValue6(reader)};reader.finish(end);return value;}
function __wireValue35(reader){const end=reader.frame();const value={["code"]:__wireValue33(reader),["w"]:__wireValue5(reader),["input"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue75(reader){const end=reader.frame();const value={["code"]:__wireValue33(reader),["w"]:__wireValue5(reader),["s"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue59(reader){const end=reader.frame();const value={["decision"]:__wireValue31(reader),["return_value"]:__wireValue1(reader),["baseline"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue49(reader){const end=reader.frame();const value={["decisions"]:__wireValue30(reader),["return_value"]:__wireValue1(reader),["baseline"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue47(reader){const end=reader.frame();const value={["decisions"]:__wireValue30(reader),["return_values"]:__wireValue26(reader),["baselines"]:__wireValue26(reader)};reader.finish(end);return value;}
function __wireValue58(reader){const end=reader.frame();const value={["derivatives"]:__wireValue27(reader),["allowed"]:__wireValue40(reader),["maximum"]:__wireValue1(reader),["total"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue36(reader){const end=reader.frame();const value={["g"]:__wireValue6(reader)};reader.finish(end);return value;}
function __wireValue19(reader){const end=reader.frame();const value={["identity"]:__wireValue20(reader),["scale"]:__wireValue20(reader),["bias"]:__wireValue20(reader),["relu"]:__wireValue20(reader)};reader.finish(end);return value;}
function __wireValue15(reader){const end=reader.frame();const value={["identity"]:__wireValue1(reader),["scale"]:__wireValue1(reader),["bias"]:__wireValue1(reader),["relu"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue64(reader){const end=reader.frame();const value={["index"]:__wireValue9(reader)};reader.finish(end);return value;}
function __wireValue8(reader){const end=reader.frame();const value={["input"]:__wireValue1(reader),["target"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue68(reader){const end=reader.frame();const value={["loss"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue43(reader){const end=reader.frame();const value={["masses"]:__wireValue26(reader),["allowed"]:__wireValue40(reader)};reader.finish(end);return value;}
function __wireValue56(reader){const end=reader.frame();const value={["masses"]:__wireValue26(reader),["derivatives"]:__wireValue27(reader),["allowed"]:__wireValue40(reader),["action"]:__wireValue9(reader)};reader.finish(end);return value;}
function __wireValue39(reader){const end=reader.frame();const value={["masses"]:__wireValue26(reader),["derivatives"]:__wireValue27(reader),["allowed"]:__wireValue40(reader),["total"]:__wireValue1(reader),["selected"]:__wireValue9(reader)};reader.finish(end);return value;}
function __wireValue41(reader){const end=reader.frame();const value={["masses"]:__wireValue26(reader),["derivatives"]:__wireValue27(reader),["allowed"]:__wireValue40(reader),["unit"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue25(reader){const end=reader.frame();const value={["masses"]:__wireValue26(reader),["derivatives"]:__wireValue27(reader)};reader.finish(end);return value;}
function __wireValue65(reader){const end=reader.frame();const value={["op"]:__wireValue34(reader)};reader.finish(end);return value;}
function __wireValue76(reader){const end=reader.frame();const value={["p"]:__wireValue45(reader)};reader.finish(end);return value;}
function __wireValue38(reader){const end=reader.frame();const value={["rate"]:__wireValue1(reader),["first_decay"]:__wireValue1(reader),["second_decay"]:__wireValue1(reader),["epsilon"]:__wireValue1(reader),["weight_decay"]:__wireValue1(reader),["norm_limit"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue62(reader){const end=reader.frame();const value={["rate"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue60(reader){const end=reader.frame();const value={["rewards"]:__wireValue26(reader),["discount"]:__wireValue1(reader),["bootstrap"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue6(reader){const end=reader.frame();const value={["samples"]:__wireValue7(reader),["instruction_cost"]:__wireValue1(reader),["version"]:__wireValue9(reader)};reader.finish(end);return value;}
function __wireValue5(reader){const end=reader.frame();const value={["scale"]:__wireValue1(reader),["bias"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue52(reader){const end=reader.frame();const value={["scaled"]:__wireValue26(reader),["unit"]:__wireValue1(reader),["total"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue16(reader){const end=reader.frame();const value={["slot"]:__wireValue9(reader),["operation"]:__wireValue9(reader)};reader.finish(end);return value;}
function __wireValue21(reader){const end=reader.frame();const value={["slot"]:__wireValue9(reader),["operation"]:__wireValue9(reader)};reader.finish(end);return value;}
function __wireValue44(reader){const end=reader.frame();const value={["state"]:__wireValue45(reader),["gradient"]:__wireValue26(reader),["c"]:__wireValue38(reader)};reader.finish(end);return value;}
function __wireValue53(reader){const end=reader.frame();const value={["state"]:__wireValue45(reader)};reader.finish(end);return value;}
function __wireValue20(reader){const end=reader.frame();const value={["value"]:__wireValue1(reader),["tangent_0"]:__wireValue1(reader),["tangent_1"]:__wireValue1(reader),["tangent_2"]:__wireValue1(reader),["tangent_3"]:__wireValue1(reader),["tangent_4"]:__wireValue1(reader),["tangent_5"]:__wireValue1(reader),["tangent_6"]:__wireValue1(reader),["tangent_7"]:__wireValue1(reader),["tangent_8"]:__wireValue1(reader),["tangent_9"]:__wireValue1(reader),["tangent_10"]:__wireValue1(reader),["tangent_11"]:__wireValue1(reader),["tangent_12"]:__wireValue1(reader),["tangent_13"]:__wireValue1(reader),["tangent_14"]:__wireValue1(reader),["tangent_15"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue17(reader){const end=reader.frame();const value={["w"]:__wireValue18(reader),["p"]:__wireValue21(reader)};reader.finish(end);return value;}
function __wireValue13(reader){const end=reader.frame();const value={["w"]:__wireValue14(reader),["p"]:__wireValue16(reader)};reader.finish(end);return value;}
function __wireValue24(reader){const end=reader.frame();const value={["w"]:__wireValue14(reader),["slot"]:__wireValue9(reader)};reader.finish(end);return value;}
function __wireValue66(reader){const end=reader.frame();const value={["w"]:__wireValue14(reader)};reader.finish(end);return value;}
function __wireValue22(reader){const end=reader.frame();const value={["w"]:__wireValue5(reader)};reader.finish(end);return value;}
function __wireValue37(reader){const end=reader.frame();const value={["weight"]:__wireValue1(reader),["first"]:__wireValue1(reader),["second"]:__wireValue1(reader),["first_power"]:__wireValue1(reader),["second_power"]:__wireValue1(reader),["c"]:__wireValue38(reader)};reader.finish(end);return value;}
function __wireValue45(reader){const end=reader.frame();const value={["weights"]:__wireValue26(reader),["first"]:__wireValue26(reader),["second"]:__wireValue26(reader),["steps"]:__wireValue9(reader),["first_power"]:__wireValue1(reader),["second_power"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue67(reader){const end=reader.frame();const value={["weights"]:__wireValue26(reader),["selected"]:__wireValue33(reader),["sampled"]:__wireValue30(reader),["loss"]:__wireValue1(reader),["before"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue69(reader){const end=reader.frame();const value={["weights"]:__wireValue26(reader),["units"]:__wireValue26(reader)};reader.finish(end);return value;}
function __wireValue61(reader){const end=reader.frame();const value={["weights"]:__wireValue26(reader)};reader.finish(end);return value;}
function __wireValue55(reader){const end=reader.frame();const value={["x"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue54(reader){const end=reader.frame();const value={["xs"]:__wireValue26(reader),["limit"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue57(reader){const end=reader.frame();const value={["xs"]:__wireValue26(reader)};reader.finish(end);return value;}
function __wireValue23(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
const __wireValue34Variants=Object.freeze(["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]);
function __wireValue34(reader){const end=reader.frame();const value=reader.text(end,"enum",__wireValue34Variants);reader.finish(end);return value;}
function __wireValue1(reader){const end=reader.frame();const value={F32Bits:reader.word()};reader.finish(end);return value;}
function __wireValue32(reader){const end=reader.frame();const value=reader.text(end,"string");reader.finish(end);return value;}
function __wireValue9(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
const __wireReaders=Object.freeze(Object.fromEntries([["__frozen_proposal_110",[__wireValue0,__wireValue1]],["__frozen_proposal_150",[__wireValue2,__wireValue1]],["__frozen_proposal_156",[__wireValue3,__wireValue1]],["__frozen_proposal_166",[__wireValue4,__wireValue1]],["__frozen_proposal_3",[__wireValue10,__wireValue1]],["__frozen_proposal_43",[__wireValue11,__wireValue1]],["__frozen_proposal_49",[__wireValue12,__wireValue1]],["__ink_differential_1",[__wireValue13,__wireValue14]],["__ink_differential_3",[__wireValue17,__wireValue20]],["coefficients_valid",[__wireValue22,__wireValue23]],["distribution",[__wireValue24,__wireValue25]],["elite_slot",[__wireValue28,__wireValue29]],["evaluate",[__wireValue35,__wireValue1]],["goal_valid",[__wireValue36,__wireValue23]],["ink_m00ba8185ca362d257d138fe1886cbc5f3acc38c4a238bef60c3d3d7fa0276eab",[__wireValue37,__wireValue1]],["ink_m1774c4db693eebe71b1f79bce053b93633d1e1ec37196dd480b59c0248b4fbc2",[__wireValue39,__wireValue26]],["ink_m1fbf7ee6cef3bcca5d7d258c8606275806894b60d839126202d17f016ea87c80",[__wireValue41,__wireValue42]],["ink_m28a5428efa573345218636e9cec104f24b6e8c67d7c4c0f979b255813b2abee3",[__wireValue43,__wireValue1]],["ink_m2a55f95a80595bc61d1fcab41ff00f438ff6f2057b597df20aaae3c18507d2be",[__wireValue44,__wireValue46]],["ink_m372cbaf2ee2bc8705fad4b5b65a9e744ea468afbe4c153f17c7da282a459d1cd",[__wireValue47,__wireValue48]],["ink_m43c1e2ac4d6d9a37358654ff5c1abcd42d4b01146c41a7ca617bccb074a8813b",[__wireValue47,__wireValue48]],["ink_m4b5ada8f7d6b3beaee6fc06bf68e61ca158cbc7664899364dff18d21555697ae",[__wireValue49,__wireValue48]],["ink_m5226ad25deae5e47d7fb65b6b5961d46740dd4e97b54d76a24d3d0445845fe35",[__wireValue50,__wireValue23]],["ink_m696809152e57d8dfa3f01f9a3e12c048434b9f2af91ff53321ea6ceeeeca5431",[__wireValue51,__wireValue48]],["ink_m6ec6e8f9e757c220bfe2ed28cbb8dab4ec520de5ee8de5ca702cbdb805a5f910",[__wireValue52,__wireValue9]],["ink_m786bdc6011aece08dbf36c5ca89c437e06ff758c9d3d242f723dde2af6ea31db",[__wireValue53,__wireValue23]],["ink_m7d03a2ed6071238ff1b69a8e56a8cb96b9dc3b095b2d939c0ccfed84ee9580b5",[__wireValue54,__wireValue1]],["ink_m8abb6b2bcbe55251e0b82a28f26d7ce761729346e35019c2b60ca9b5ee22590d",[__wireValue55,__wireValue1]],["ink_m99468fca85aa8fb996f0c891430c813d82505250d39d8e415bf27679ddc39e07",[__wireValue56,__wireValue42]],["ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96",[__wireValue57,__wireValue23]],["ink_maa2c8802d351b443dda0bc206d70fa9fe87756b57a84d0357e9dfb4c1e7a0667",[__wireValue58,__wireValue26]],["ink_maadd6c30a027af52d851f0828eec45339d218ad3bbe73e4d8d7cdd3892e754f4",[__wireValue59,__wireValue48]],["ink_mc05a2256079ef1f1818d13e69727dc7902cdb7f70856a671af2ba08ef190d23a",[__wireValue43,__wireValue48]],["ink_mda500f665e6078213ee2391fedf06240c651d1725327b086aa70cda14bef9a07",[__wireValue60,__wireValue48]],["ink_mdfbd57a9f460147afedb262e2bfe0f6197f9b813c85277c59f5e101900063ad7",[__wireValue61,__wireValue46]],["ink_meefc22a28d97f5bdc4100b36eeab9549241c3ef201b83c2f75111644d317833d",[__wireValue62,__wireValue38]],["ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54",[__wireValue57,__wireValue23]],["ink_mfd18151b0af45b45f5b48ef5e7a09ac1294681f654e2174ae3b33183f445ef14",[__wireValue43,__wireValue48]],["mass",[__wireValue13,__wireValue1]],["numeric",[__wireValue57,__wireValue26]],["objective",[__wireValue63,__wireValue1]],["operation",[__wireValue64,__wireValue34]],["operation_index",[__wireValue65,__wireValue9]],["pack",[__wireValue66,__wireValue26]],["proposal_gradient",[__wireValue67,__wireValue48]],["reward",[__wireValue68,__wireValue1]],["sample",[__wireValue69,__wireValue70]],["sample_slot",[__wireValue72,__wireValue73]],["squared_error",[__wireValue75,__wireValue1]],["unpack",[__wireValue57,__wireValue14]],["valid_policy",[__wireValue76,__wireValue23]]]));

const __ownedImplementations=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>{
 const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
 const body=__implementations[f.index];
 const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
 return [f.name,input.every(c=>c===__identity)?implementation:(...args)=>{const context=new WeakMap();return implementation(...args.map((v,i)=>input[i](v,context)));}];
})));

export const valueCodecs=(()=>{const codecs={};for(const [name,s] of Object.entries(metadata.wire.functions)){if(s.unsupported)continue;let value;Object.defineProperty(codecs,name,{enumerable:true,get:()=>value??=(Object.freeze(Object.hasOwn(__wireReaders,name)?{arguments:createCompiledValueCodec(s.arguments,__wireReaders[name][0]),result:createCompiledValueCodec(s.result,__wireReaders[name][1])}:{arguments:new ValueCodec(s.arguments),result:new ValueCodec(s.result)}))});}return Object.freeze(codecs);})();
function __callEncoded(name,bytes,limits,compact){
 const f=metadata.functions.find(f=>f.name===name&&!f.internal),codecs=valueCodecs[name];
 if(!f||!codecs)throw Error('unsupported binary function');
 const input=compact?codecs.arguments.compact():codecs.arguments,output=compact?codecs.result.compact():codecs.result;
 const entry=__compiledEntries.get(name);
 if(entry){
  const slot=compact?1:0;
  entry.argumentCodecs[slot]??=(entry.boundaryReaders[slot]?createFusedValueCodec:createCompiledValueCodec)(metadata.wire.functions[name].arguments,entry.arguments);
  const decoder=entry.argumentCodecs[slot];
  const values=(compact?decoder.compact():decoder).decode(bytes,limits),args=f.params.map(p=>values[p.name]);
  if(entry.precondition!==null&&__implementations[entry.precondition](...args)!==true)throw Error('contract precondition failed');
  return __compiledEncodeResult(entry,__implementations[entry.index](...args),limits,compact);
 }
 const values=input.decode(bytes,limits);
 const result=call(name,f.params.map(p=>values[p.name]));
 return output.encode(result,limits);
}
export function callBinary(name,bytes,limits={}){return __callEncoded(name,bytes,limits,false);}
export function callCompact(name,bytes,limits={}){return __callEncoded(name,bytes,limits,true);}
// Same stable, well-typed caller inputs as call; the result owns every container.
// The checked source return type justifies trusted copying, not arbitrary input.
export function callOwned(name,args,limits={}){
 if(!Object.hasOwn(__ownedFunctions,name)||!Object.hasOwn(functions,name))throw Error('unsupported owned function');
 const result=__ownedImplementations[name](...args);return __ownedFunctions[name](result,createValueCaptureBudget(limits),0);
}
function __privateCapture14(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture9(value[i],budget,depth+1);return out;}
function __privateCapture17(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture18(value[i],budget,depth+1);return out;}
function __privateCapture6(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture7(value[i],budget,depth+1);return out;}
function __privateCapture25(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture4(value[i],budget,depth+1);return out;}
function __privateCapture0(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture1(value[i],budget,depth+1);return out;}
function __privateCapture9(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture3(value[i],budget,depth+1);return out;}
function __privateCapture22(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture17(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture19(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture23(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture9(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture19(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture26(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture18(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture19(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture15(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture16(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture19(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture20(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture21(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture19(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture28(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture24(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture19(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture29(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==4){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"c")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"d")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture30(value["a"],budget,depth+1),["b"]:__privateCapture30(value["b"],budget,depth+1),["c"]:__privateCapture30(value["c"],budget,depth+1),["d"]:__privateCapture30(value["d"],budget,depth+1)};}
function __privateCapture10(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==4){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"c")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"d")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture11(value["a"],budget,depth+1),["b"]:__privateCapture11(value["b"],budget,depth+1),["c"]:__privateCapture11(value["c"],budget,depth+1),["d"]:__privateCapture11(value["d"],budget,depth+1)};}
function __privateCapture18(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==3){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"action")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"probability")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"score")){throw Error('invalid value for wire schema');}return {["action"]:__privateCapture8(value["action"],budget,depth+1),["probability"]:__privateCapture3(value["probability"],budget,depth+1),["score"]:__privateCapture9(value["score"],budget,depth+1)};}
function __privateCapture16(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"choices")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"decisions")){throw Error('invalid value for wire schema');}return {["choices"]:__privateCapture0(value["choices"],budget,depth+1),["decisions"]:__privateCapture17(value["decisions"],budget,depth+1)};}
function __privateCapture21(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"code")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"decisions")){throw Error('invalid value for wire schema');}return {["code"]:__privateCapture0(value["code"],budget,depth+1),["decisions"]:__privateCapture17(value["decisions"],budget,depth+1)};}
function __privateCapture30(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==4){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"identity")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"scale")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"bias")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"relu")){throw Error('invalid value for wire schema');}return {["identity"]:__privateCapture31(value["identity"],budget,depth+1),["scale"]:__privateCapture31(value["scale"],budget,depth+1),["bias"]:__privateCapture31(value["bias"],budget,depth+1),["relu"]:__privateCapture31(value["relu"],budget,depth+1)};}
function __privateCapture11(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==4){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"identity")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"scale")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"bias")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"relu")){throw Error('invalid value for wire schema');}return {["identity"]:__privateCapture3(value["identity"],budget,depth+1),["scale"]:__privateCapture3(value["scale"],budget,depth+1),["bias"]:__privateCapture3(value["bias"],budget,depth+1),["relu"]:__privateCapture3(value["relu"],budget,depth+1)};}
function __privateCapture7(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"input")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"target")){throw Error('invalid value for wire schema');}return {["input"]:__privateCapture3(value["input"],budget,depth+1),["target"]:__privateCapture3(value["target"],budget,depth+1)};}
function __privateCapture13(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"masses")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"derivatives")){throw Error('invalid value for wire schema');}return {["masses"]:__privateCapture9(value["masses"],budget,depth+1),["derivatives"]:__privateCapture14(value["derivatives"],budget,depth+1)};}
function __privateCapture27(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"rate")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"first_decay")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"second_decay")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"epsilon")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"weight_decay")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"norm_limit")){throw Error('invalid value for wire schema');}return {["rate"]:__privateCapture3(value["rate"],budget,depth+1),["first_decay"]:__privateCapture3(value["first_decay"],budget,depth+1),["second_decay"]:__privateCapture3(value["second_decay"],budget,depth+1),["epsilon"]:__privateCapture3(value["epsilon"],budget,depth+1),["weight_decay"]:__privateCapture3(value["weight_decay"],budget,depth+1),["norm_limit"]:__privateCapture3(value["norm_limit"],budget,depth+1)};}
function __privateCapture5(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==3){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"samples")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"instruction_cost")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"version")){throw Error('invalid value for wire schema');}return {["samples"]:__privateCapture6(value["samples"],budget,depth+1),["instruction_cost"]:__privateCapture3(value["instruction_cost"],budget,depth+1),["version"]:__privateCapture8(value["version"],budget,depth+1)};}
function __privateCapture2(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"scale")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"bias")){throw Error('invalid value for wire schema');}return {["scale"]:__privateCapture3(value["scale"],budget,depth+1),["bias"]:__privateCapture3(value["bias"],budget,depth+1)};}
function __privateCapture12(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"slot")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"operation")){throw Error('invalid value for wire schema');}return {["slot"]:__privateCapture8(value["slot"],budget,depth+1),["operation"]:__privateCapture8(value["operation"],budget,depth+1)};}
function __privateCapture32(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"slot")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"operation")){throw Error('invalid value for wire schema');}return {["slot"]:__privateCapture8(value["slot"],budget,depth+1),["operation"]:__privateCapture8(value["operation"],budget,depth+1)};}
function __privateCapture31(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==17){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_0")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_1")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_2")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_3")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_4")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_5")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_6")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_7")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_8")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_9")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_10")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_11")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_12")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_13")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_14")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_15")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture3(value["value"],budget,depth+1),["tangent_0"]:__privateCapture3(value["tangent_0"],budget,depth+1),["tangent_1"]:__privateCapture3(value["tangent_1"],budget,depth+1),["tangent_2"]:__privateCapture3(value["tangent_2"],budget,depth+1),["tangent_3"]:__privateCapture3(value["tangent_3"],budget,depth+1),["tangent_4"]:__privateCapture3(value["tangent_4"],budget,depth+1),["tangent_5"]:__privateCapture3(value["tangent_5"],budget,depth+1),["tangent_6"]:__privateCapture3(value["tangent_6"],budget,depth+1),["tangent_7"]:__privateCapture3(value["tangent_7"],budget,depth+1),["tangent_8"]:__privateCapture3(value["tangent_8"],budget,depth+1),["tangent_9"]:__privateCapture3(value["tangent_9"],budget,depth+1),["tangent_10"]:__privateCapture3(value["tangent_10"],budget,depth+1),["tangent_11"]:__privateCapture3(value["tangent_11"],budget,depth+1),["tangent_12"]:__privateCapture3(value["tangent_12"],budget,depth+1),["tangent_13"]:__privateCapture3(value["tangent_13"],budget,depth+1),["tangent_14"]:__privateCapture3(value["tangent_14"],budget,depth+1),["tangent_15"]:__privateCapture3(value["tangent_15"],budget,depth+1)};}
function __privateCapture24(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"weights")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"first")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"second")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"steps")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"first_power")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"second_power")){throw Error('invalid value for wire schema');}return {["weights"]:__privateCapture9(value["weights"],budget,depth+1),["first"]:__privateCapture9(value["first"],budget,depth+1),["second"]:__privateCapture9(value["second"],budget,depth+1),["steps"]:__privateCapture8(value["steps"],budget,depth+1),["first_power"]:__privateCapture3(value["first_power"],budget,depth+1),["second_power"]:__privateCapture3(value["second_power"],budget,depth+1)};}
function __privateCapture4(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='boolean'){throw Error('invalid value for wire schema');}budget.add(1);return value;}
function __privateCapture1(value,budget,depth=0){budget.enter(depth,4);const text=value;if(typeof text!=='string'||!text.isWellFormed()||text.length>budget.limit){throw Error('invalid value for wire schema');}if(!["Op.Identity","Op.Scale","Op.Bias","Op.Relu"].includes(text)){throw Error('invalid value for wire schema');}budget.text(text);return text;}
function __privateCapture3(value,budget,depth=0){budget.enter(depth,4);let bits;if(typeof value==='number'&&Number.isFinite(value)){bits=__bits(value);if(!Number.isFinite(__float(bits))){throw Error('invalid value for wire schema');}}else{if(!(value!==null&&typeof value==='object'&&Object.hasOwn(value,'F32Bits')&&Object.keys(value).length===1)){throw Error('invalid value for wire schema');}bits=value.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295){throw Error('invalid value for wire schema');}}budget.add(4);return bits===0?0:bits;}
function __privateCapture19(value,budget,depth=0){budget.enter(depth,4);const text=value;if(typeof text!=='string'||!text.isWellFormed()||text.length>budget.limit){throw Error('invalid value for wire schema');}budget.text(text);return text;}
function __privateCapture8(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='number'||!Number.isInteger(value)||value<0||value>4294967295){throw Error('invalid value for wire schema');}budget.add(4);return value===0?0:value;}
function __privateWireValue23(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue14(reader);reader.finish(end);return value;}
function __privateWireValue27(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue28(reader);reader.finish(end);return value;}
function __privateWireValue8(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue9(reader);reader.finish(end);return value;}
function __privateWireValue42(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue5(reader);reader.finish(end);return value;}
function __privateWireValue0(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue1(reader);reader.finish(end);return value;}
function __privateWireValue14(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue3(reader);reader.finish(end);return value;}
function __privateWireValue36(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue29(reader)}:{Ok:__privateWireValue27(reader)};reader.finish(end);return value;}
function __privateWireValue38(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue29(reader)}:{Ok:__privateWireValue14(reader)};reader.finish(end);return value;}
function __privateWireValue47(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue29(reader)}:{Ok:__privateWireValue28(reader)};reader.finish(end);return value;}
function __privateWireValue25(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue29(reader)}:{Ok:__privateWireValue26(reader)};reader.finish(end);return value;}
function __privateWireValue31(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue29(reader)}:{Ok:__privateWireValue32(reader)};reader.finish(end);return value;}
function __privateWireValue58(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue29(reader)}:{Ok:__privateWireValue40(reader)};reader.finish(end);return value;}
function __privateWireValue71(reader){const end=reader.frame();const value={["__frozen_proposal_1"]:__privateWireValue2(reader),["__frozen_proposal_44"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue72(reader){const end=reader.frame();const value={["__frozen_proposal_1"]:__privateWireValue2(reader),["__frozen_proposal_50"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue70(reader){const end=reader.frame();const value={["__frozen_proposal_1"]:__privateWireValue2(reader),["__frozen_proposal_7"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue73(reader){const end=reader.frame();const value={["__frozen_proposal_114"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue74(reader){const end=reader.frame();const value={["__frozen_proposal_151"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue75(reader){const end=reader.frame();const value={["__frozen_proposal_157"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue76(reader){const end=reader.frame();const value={["__frozen_proposal_53"]:__privateWireValue2(reader),["__frozen_proposal_54"]:__privateWireValue7(reader)};reader.finish(end);return value;}
function __privateWireValue65(reader){const end=reader.frame();const value={["a"]:__privateWireValue66(reader),["b"]:__privateWireValue66(reader),["c"]:__privateWireValue66(reader),["d"]:__privateWireValue66(reader)};reader.finish(end);return value;}
function __privateWireValue15(reader){const end=reader.frame();const value={["a"]:__privateWireValue16(reader),["b"]:__privateWireValue16(reader),["c"]:__privateWireValue16(reader),["d"]:__privateWireValue16(reader)};reader.finish(end);return value;}
function __privateWireValue37(reader){const end=reader.frame();const value={["accumulator"]:__privateWireValue36(reader),["slot"]:__privateWireValue10(reader),["w"]:__privateWireValue15(reader),["code"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue51(reader){const end=reader.frame();const value={["accumulator"]:__privateWireValue38(reader),["decision"]:__privateWireValue28(reader),["return_value"]:__privateWireValue3(reader),["baseline"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue30(reader){const end=reader.frame();const value={["accumulator"]:__privateWireValue25(reader),["slot"]:__privateWireValue10(reader),["w"]:__privateWireValue15(reader),["units"]:__privateWireValue14(reader)};reader.finish(end);return value;}
function __privateWireValue28(reader){const end=reader.frame();const value={["action"]:__privateWireValue10(reader),["probability"]:__privateWireValue3(reader),["score"]:__privateWireValue14(reader)};reader.finish(end);return value;}
function __privateWireValue60(reader){const end=reader.frame();const value={["c"]:__privateWireValue55(reader)};reader.finish(end);return value;}
function __privateWireValue26(reader){const end=reader.frame();const value={["choices"]:__privateWireValue0(reader),["decisions"]:__privateWireValue27(reader)};reader.finish(end);return value;}
function __privateWireValue32(reader){const end=reader.frame();const value={["code"]:__privateWireValue0(reader),["decisions"]:__privateWireValue27(reader)};reader.finish(end);return value;}
function __privateWireValue13(reader){const end=reader.frame();const value={["code"]:__privateWireValue0(reader),["w"]:__privateWireValue2(reader),["g"]:__privateWireValue7(reader)};reader.finish(end);return value;}
function __privateWireValue4(reader){const end=reader.frame();const value={["code"]:__privateWireValue0(reader),["w"]:__privateWireValue2(reader),["input"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue12(reader){const end=reader.frame();const value={["code"]:__privateWireValue0(reader),["w"]:__privateWireValue2(reader),["s"]:__privateWireValue9(reader)};reader.finish(end);return value;}
function __privateWireValue50(reader){const end=reader.frame();const value={["decision"]:__privateWireValue28(reader),["return_value"]:__privateWireValue3(reader),["baseline"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue53(reader){const end=reader.frame();const value={["decisions"]:__privateWireValue27(reader),["return_value"]:__privateWireValue3(reader),["baseline"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue52(reader){const end=reader.frame();const value={["decisions"]:__privateWireValue27(reader),["return_values"]:__privateWireValue14(reader),["baselines"]:__privateWireValue14(reader)};reader.finish(end);return value;}
function __privateWireValue45(reader){const end=reader.frame();const value={["derivatives"]:__privateWireValue23(reader),["allowed"]:__privateWireValue42(reader),["maximum"]:__privateWireValue3(reader),["total"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue11(reader){const end=reader.frame();const value={["g"]:__privateWireValue7(reader)};reader.finish(end);return value;}
function __privateWireValue66(reader){const end=reader.frame();const value={["identity"]:__privateWireValue67(reader),["scale"]:__privateWireValue67(reader),["bias"]:__privateWireValue67(reader),["relu"]:__privateWireValue67(reader)};reader.finish(end);return value;}
function __privateWireValue16(reader){const end=reader.frame();const value={["identity"]:__privateWireValue3(reader),["scale"]:__privateWireValue3(reader),["bias"]:__privateWireValue3(reader),["relu"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue21(reader){const end=reader.frame();const value={["index"]:__privateWireValue10(reader)};reader.finish(end);return value;}
function __privateWireValue9(reader){const end=reader.frame();const value={["input"]:__privateWireValue3(reader),["target"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue34(reader){const end=reader.frame();const value={["loss"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue43(reader){const end=reader.frame();const value={["masses"]:__privateWireValue14(reader),["allowed"]:__privateWireValue42(reader)};reader.finish(end);return value;}
function __privateWireValue49(reader){const end=reader.frame();const value={["masses"]:__privateWireValue14(reader),["derivatives"]:__privateWireValue23(reader),["allowed"]:__privateWireValue42(reader),["action"]:__privateWireValue10(reader)};reader.finish(end);return value;}
function __privateWireValue46(reader){const end=reader.frame();const value={["masses"]:__privateWireValue14(reader),["derivatives"]:__privateWireValue23(reader),["allowed"]:__privateWireValue42(reader),["total"]:__privateWireValue3(reader),["selected"]:__privateWireValue10(reader)};reader.finish(end);return value;}
function __privateWireValue48(reader){const end=reader.frame();const value={["masses"]:__privateWireValue14(reader),["derivatives"]:__privateWireValue23(reader),["allowed"]:__privateWireValue42(reader),["unit"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue22(reader){const end=reader.frame();const value={["masses"]:__privateWireValue14(reader),["derivatives"]:__privateWireValue23(reader)};reader.finish(end);return value;}
function __privateWireValue35(reader){const end=reader.frame();const value={["op"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue41(reader){const end=reader.frame();const value={["p"]:__privateWireValue40(reader)};reader.finish(end);return value;}
function __privateWireValue55(reader){const end=reader.frame();const value={["rate"]:__privateWireValue3(reader),["first_decay"]:__privateWireValue3(reader),["second_decay"]:__privateWireValue3(reader),["epsilon"]:__privateWireValue3(reader),["weight_decay"]:__privateWireValue3(reader),["norm_limit"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue56(reader){const end=reader.frame();const value={["rate"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue54(reader){const end=reader.frame();const value={["rewards"]:__privateWireValue14(reader),["discount"]:__privateWireValue3(reader),["bootstrap"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue7(reader){const end=reader.frame();const value={["samples"]:__privateWireValue8(reader),["instruction_cost"]:__privateWireValue3(reader),["version"]:__privateWireValue10(reader)};reader.finish(end);return value;}
function __privateWireValue2(reader){const end=reader.frame();const value={["scale"]:__privateWireValue3(reader),["bias"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue44(reader){const end=reader.frame();const value={["scaled"]:__privateWireValue14(reader),["unit"]:__privateWireValue3(reader),["total"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue19(reader){const end=reader.frame();const value={["slot"]:__privateWireValue10(reader),["operation"]:__privateWireValue10(reader)};reader.finish(end);return value;}
function __privateWireValue68(reader){const end=reader.frame();const value={["slot"]:__privateWireValue10(reader),["operation"]:__privateWireValue10(reader)};reader.finish(end);return value;}
function __privateWireValue64(reader){const end=reader.frame();const value={["state"]:__privateWireValue40(reader),["gradient"]:__privateWireValue14(reader),["c"]:__privateWireValue55(reader)};reader.finish(end);return value;}
function __privateWireValue57(reader){const end=reader.frame();const value={["state"]:__privateWireValue40(reader)};reader.finish(end);return value;}
function __privateWireValue67(reader){const end=reader.frame();const value={["value"]:__privateWireValue3(reader),["tangent_0"]:__privateWireValue3(reader),["tangent_1"]:__privateWireValue3(reader),["tangent_2"]:__privateWireValue3(reader),["tangent_3"]:__privateWireValue3(reader),["tangent_4"]:__privateWireValue3(reader),["tangent_5"]:__privateWireValue3(reader),["tangent_6"]:__privateWireValue3(reader),["tangent_7"]:__privateWireValue3(reader),["tangent_8"]:__privateWireValue3(reader),["tangent_9"]:__privateWireValue3(reader),["tangent_10"]:__privateWireValue3(reader),["tangent_11"]:__privateWireValue3(reader),["tangent_12"]:__privateWireValue3(reader),["tangent_13"]:__privateWireValue3(reader),["tangent_14"]:__privateWireValue3(reader),["tangent_15"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue69(reader){const end=reader.frame();const value={["w"]:__privateWireValue65(reader),["p"]:__privateWireValue68(reader)};reader.finish(end);return value;}
function __privateWireValue20(reader){const end=reader.frame();const value={["w"]:__privateWireValue15(reader),["p"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue24(reader){const end=reader.frame();const value={["w"]:__privateWireValue15(reader),["slot"]:__privateWireValue10(reader)};reader.finish(end);return value;}
function __privateWireValue18(reader){const end=reader.frame();const value={["w"]:__privateWireValue15(reader)};reader.finish(end);return value;}
function __privateWireValue6(reader){const end=reader.frame();const value={["w"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue63(reader){const end=reader.frame();const value={["weight"]:__privateWireValue3(reader),["first"]:__privateWireValue3(reader),["second"]:__privateWireValue3(reader),["first_power"]:__privateWireValue3(reader),["second_power"]:__privateWireValue3(reader),["c"]:__privateWireValue55(reader)};reader.finish(end);return value;}
function __privateWireValue40(reader){const end=reader.frame();const value={["weights"]:__privateWireValue14(reader),["first"]:__privateWireValue14(reader),["second"]:__privateWireValue14(reader),["steps"]:__privateWireValue10(reader),["first_power"]:__privateWireValue3(reader),["second_power"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue39(reader){const end=reader.frame();const value={["weights"]:__privateWireValue14(reader),["selected"]:__privateWireValue0(reader),["sampled"]:__privateWireValue27(reader),["loss"]:__privateWireValue3(reader),["before"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue33(reader){const end=reader.frame();const value={["weights"]:__privateWireValue14(reader),["units"]:__privateWireValue14(reader)};reader.finish(end);return value;}
function __privateWireValue59(reader){const end=reader.frame();const value={["weights"]:__privateWireValue14(reader)};reader.finish(end);return value;}
function __privateWireValue61(reader){const end=reader.frame();const value={["x"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue62(reader){const end=reader.frame();const value={["xs"]:__privateWireValue14(reader),["limit"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue17(reader){const end=reader.frame();const value={["xs"]:__privateWireValue14(reader)};reader.finish(end);return value;}
function __privateWireValue5(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
const __privateWireValue1Variants=Object.freeze(["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]);
function __privateWireValue1(reader){const end=reader.frame();const value=reader.text(end,"enum",__privateWireValue1Variants);reader.finish(end);return value;}
function __privateWireValue3(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __privateWireValue29(reader){const end=reader.frame();const value=reader.text(end,"string");reader.finish(end);return value;}
function __privateWireValue10(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __compiledOwnedValue14(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue9(value[i],budget,depth+1);return out;}
function __compiledOwnedValue17(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue18(value[i],budget,depth+1);return out;}
function __compiledOwnedValue6(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue7(value[i],budget,depth+1);return out;}
function __compiledOwnedValue25(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue4(value[i],budget,depth+1);return out;}
function __compiledOwnedValue0(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue1(value[i],budget,depth+1);return out;}
function __compiledOwnedValue9(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue3(value[i],budget,depth+1);return out;}
function __compiledOwnedValue22(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue17(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue19(value.Err,budget,depth+1)};}
function __compiledOwnedValue23(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue9(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue19(value.Err,budget,depth+1)};}
function __compiledOwnedValue26(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue18(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue19(value.Err,budget,depth+1)};}
function __compiledOwnedValue15(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue16(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue19(value.Err,budget,depth+1)};}
function __compiledOwnedValue20(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue21(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue19(value.Err,budget,depth+1)};}
function __compiledOwnedValue28(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue24(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue19(value.Err,budget,depth+1)};}
function __compiledOwnedValue29(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue30(value["a"],budget,depth+1),["b"]:__compiledOwnedValue30(value["b"],budget,depth+1),["c"]:__compiledOwnedValue30(value["c"],budget,depth+1),["d"]:__compiledOwnedValue30(value["d"],budget,depth+1)};}
function __compiledOwnedValue10(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue11(value["a"],budget,depth+1),["b"]:__compiledOwnedValue11(value["b"],budget,depth+1),["c"]:__compiledOwnedValue11(value["c"],budget,depth+1),["d"]:__compiledOwnedValue11(value["d"],budget,depth+1)};}
function __compiledOwnedValue18(value,budget,depth){budget.enter(depth,4);return {["action"]:__compiledOwnedValue8(value["action"],budget,depth+1),["probability"]:__compiledOwnedValue3(value["probability"],budget,depth+1),["score"]:__compiledOwnedValue9(value["score"],budget,depth+1)};}
function __compiledOwnedValue16(value,budget,depth){budget.enter(depth,4);return {["choices"]:__compiledOwnedValue0(value["choices"],budget,depth+1),["decisions"]:__compiledOwnedValue17(value["decisions"],budget,depth+1)};}
function __compiledOwnedValue21(value,budget,depth){budget.enter(depth,4);return {["code"]:__compiledOwnedValue0(value["code"],budget,depth+1),["decisions"]:__compiledOwnedValue17(value["decisions"],budget,depth+1)};}
function __compiledOwnedValue30(value,budget,depth){budget.enter(depth,4);return {["identity"]:__compiledOwnedValue31(value["identity"],budget,depth+1),["scale"]:__compiledOwnedValue31(value["scale"],budget,depth+1),["bias"]:__compiledOwnedValue31(value["bias"],budget,depth+1),["relu"]:__compiledOwnedValue31(value["relu"],budget,depth+1)};}
function __compiledOwnedValue11(value,budget,depth){budget.enter(depth,4);return {["identity"]:__compiledOwnedValue3(value["identity"],budget,depth+1),["scale"]:__compiledOwnedValue3(value["scale"],budget,depth+1),["bias"]:__compiledOwnedValue3(value["bias"],budget,depth+1),["relu"]:__compiledOwnedValue3(value["relu"],budget,depth+1)};}
function __compiledOwnedValue7(value,budget,depth){budget.enter(depth,4);return {["input"]:__compiledOwnedValue3(value["input"],budget,depth+1),["target"]:__compiledOwnedValue3(value["target"],budget,depth+1)};}
function __compiledOwnedValue13(value,budget,depth){budget.enter(depth,4);return {["masses"]:__compiledOwnedValue9(value["masses"],budget,depth+1),["derivatives"]:__compiledOwnedValue14(value["derivatives"],budget,depth+1)};}
function __compiledOwnedValue27(value,budget,depth){budget.enter(depth,4);return {["rate"]:__compiledOwnedValue3(value["rate"],budget,depth+1),["first_decay"]:__compiledOwnedValue3(value["first_decay"],budget,depth+1),["second_decay"]:__compiledOwnedValue3(value["second_decay"],budget,depth+1),["epsilon"]:__compiledOwnedValue3(value["epsilon"],budget,depth+1),["weight_decay"]:__compiledOwnedValue3(value["weight_decay"],budget,depth+1),["norm_limit"]:__compiledOwnedValue3(value["norm_limit"],budget,depth+1)};}
function __compiledOwnedValue5(value,budget,depth){budget.enter(depth,4);return {["samples"]:__compiledOwnedValue6(value["samples"],budget,depth+1),["instruction_cost"]:__compiledOwnedValue3(value["instruction_cost"],budget,depth+1),["version"]:__compiledOwnedValue8(value["version"],budget,depth+1)};}
function __compiledOwnedValue2(value,budget,depth){budget.enter(depth,4);return {["scale"]:__compiledOwnedValue3(value["scale"],budget,depth+1),["bias"]:__compiledOwnedValue3(value["bias"],budget,depth+1)};}
function __compiledOwnedValue12(value,budget,depth){budget.enter(depth,4);return {["slot"]:__compiledOwnedValue8(value["slot"],budget,depth+1),["operation"]:__compiledOwnedValue8(value["operation"],budget,depth+1)};}
function __compiledOwnedValue32(value,budget,depth){budget.enter(depth,4);return {["slot"]:__compiledOwnedValue8(value["slot"],budget,depth+1),["operation"]:__compiledOwnedValue8(value["operation"],budget,depth+1)};}
function __compiledOwnedValue31(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue3(value["value"],budget,depth+1),["tangent_0"]:__compiledOwnedValue3(value["tangent_0"],budget,depth+1),["tangent_1"]:__compiledOwnedValue3(value["tangent_1"],budget,depth+1),["tangent_2"]:__compiledOwnedValue3(value["tangent_2"],budget,depth+1),["tangent_3"]:__compiledOwnedValue3(value["tangent_3"],budget,depth+1),["tangent_4"]:__compiledOwnedValue3(value["tangent_4"],budget,depth+1),["tangent_5"]:__compiledOwnedValue3(value["tangent_5"],budget,depth+1),["tangent_6"]:__compiledOwnedValue3(value["tangent_6"],budget,depth+1),["tangent_7"]:__compiledOwnedValue3(value["tangent_7"],budget,depth+1),["tangent_8"]:__compiledOwnedValue3(value["tangent_8"],budget,depth+1),["tangent_9"]:__compiledOwnedValue3(value["tangent_9"],budget,depth+1),["tangent_10"]:__compiledOwnedValue3(value["tangent_10"],budget,depth+1),["tangent_11"]:__compiledOwnedValue3(value["tangent_11"],budget,depth+1),["tangent_12"]:__compiledOwnedValue3(value["tangent_12"],budget,depth+1),["tangent_13"]:__compiledOwnedValue3(value["tangent_13"],budget,depth+1),["tangent_14"]:__compiledOwnedValue3(value["tangent_14"],budget,depth+1),["tangent_15"]:__compiledOwnedValue3(value["tangent_15"],budget,depth+1)};}
function __compiledOwnedValue24(value,budget,depth){budget.enter(depth,4);return {["weights"]:__compiledOwnedValue9(value["weights"],budget,depth+1),["first"]:__compiledOwnedValue9(value["first"],budget,depth+1),["second"]:__compiledOwnedValue9(value["second"],budget,depth+1),["steps"]:__compiledOwnedValue8(value["steps"],budget,depth+1),["first_power"]:__compiledOwnedValue3(value["first_power"],budget,depth+1),["second_power"]:__compiledOwnedValue3(value["second_power"],budget,depth+1)};}
function __compiledOwnedValue4(value,budget,depth){budget.enter(depth,5);return value;}
function __compiledOwnedValue1(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __compiledOwnedValue3(value,budget,depth){budget.enter(depth,8);return {F32Bits:value===0?0:value};}
function __compiledOwnedValue19(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __compiledOwnedValue8(value,budget,depth){budget.enter(depth,8);return value>>>0;}
function __privateWireWrite14(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite9(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite17(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite18(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite6(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite7(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite25(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite4(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite0(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite1(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite9(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite3(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite22(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite17(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite19(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite23(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite9(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite19(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite26(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite18(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite19(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite15(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite16(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite19(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite20(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite21(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite19(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite28(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite24(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite19(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite29(writer,value,compact){const frame=writer.openFrame();__privateWireWrite30(writer,value["a"],compact);__privateWireWrite30(writer,value["b"],compact);__privateWireWrite30(writer,value["c"],compact);__privateWireWrite30(writer,value["d"],compact);writer.closeFrame(frame);}
function __privateWireWrite10(writer,value,compact){const frame=writer.openFrame();__privateWireWrite11(writer,value["a"],compact);__privateWireWrite11(writer,value["b"],compact);__privateWireWrite11(writer,value["c"],compact);__privateWireWrite11(writer,value["d"],compact);writer.closeFrame(frame);}
function __privateWireWrite18(writer,value,compact){const frame=writer.openFrame();__privateWireWrite8(writer,value["action"],compact);__privateWireWrite3(writer,value["probability"],compact);__privateWireWrite9(writer,value["score"],compact);writer.closeFrame(frame);}
function __privateWireWrite16(writer,value,compact){const frame=writer.openFrame();__privateWireWrite0(writer,value["choices"],compact);__privateWireWrite17(writer,value["decisions"],compact);writer.closeFrame(frame);}
function __privateWireWrite21(writer,value,compact){const frame=writer.openFrame();__privateWireWrite0(writer,value["code"],compact);__privateWireWrite17(writer,value["decisions"],compact);writer.closeFrame(frame);}
function __privateWireWrite30(writer,value,compact){const frame=writer.openFrame();__privateWireWrite31(writer,value["identity"],compact);__privateWireWrite31(writer,value["scale"],compact);__privateWireWrite31(writer,value["bias"],compact);__privateWireWrite31(writer,value["relu"],compact);writer.closeFrame(frame);}
function __privateWireWrite11(writer,value,compact){const frame=writer.openFrame();__privateWireWrite3(writer,value["identity"],compact);__privateWireWrite3(writer,value["scale"],compact);__privateWireWrite3(writer,value["bias"],compact);__privateWireWrite3(writer,value["relu"],compact);writer.closeFrame(frame);}
function __privateWireWrite7(writer,value,compact){const frame=writer.openFrame();__privateWireWrite3(writer,value["input"],compact);__privateWireWrite3(writer,value["target"],compact);writer.closeFrame(frame);}
function __privateWireWrite13(writer,value,compact){const frame=writer.openFrame();__privateWireWrite9(writer,value["masses"],compact);__privateWireWrite14(writer,value["derivatives"],compact);writer.closeFrame(frame);}
function __privateWireWrite27(writer,value,compact){const frame=writer.openFrame();__privateWireWrite3(writer,value["rate"],compact);__privateWireWrite3(writer,value["first_decay"],compact);__privateWireWrite3(writer,value["second_decay"],compact);__privateWireWrite3(writer,value["epsilon"],compact);__privateWireWrite3(writer,value["weight_decay"],compact);__privateWireWrite3(writer,value["norm_limit"],compact);writer.closeFrame(frame);}
function __privateWireWrite5(writer,value,compact){const frame=writer.openFrame();__privateWireWrite6(writer,value["samples"],compact);__privateWireWrite3(writer,value["instruction_cost"],compact);__privateWireWrite8(writer,value["version"],compact);writer.closeFrame(frame);}
function __privateWireWrite2(writer,value,compact){const frame=writer.openFrame();__privateWireWrite3(writer,value["scale"],compact);__privateWireWrite3(writer,value["bias"],compact);writer.closeFrame(frame);}
function __privateWireWrite12(writer,value,compact){const frame=writer.openFrame();__privateWireWrite8(writer,value["slot"],compact);__privateWireWrite8(writer,value["operation"],compact);writer.closeFrame(frame);}
function __privateWireWrite32(writer,value,compact){const frame=writer.openFrame();__privateWireWrite8(writer,value["slot"],compact);__privateWireWrite8(writer,value["operation"],compact);writer.closeFrame(frame);}
function __privateWireWrite31(writer,value,compact){const frame=writer.openFrame();__privateWireWrite3(writer,value["value"],compact);__privateWireWrite3(writer,value["tangent_0"],compact);__privateWireWrite3(writer,value["tangent_1"],compact);__privateWireWrite3(writer,value["tangent_2"],compact);__privateWireWrite3(writer,value["tangent_3"],compact);__privateWireWrite3(writer,value["tangent_4"],compact);__privateWireWrite3(writer,value["tangent_5"],compact);__privateWireWrite3(writer,value["tangent_6"],compact);__privateWireWrite3(writer,value["tangent_7"],compact);__privateWireWrite3(writer,value["tangent_8"],compact);__privateWireWrite3(writer,value["tangent_9"],compact);__privateWireWrite3(writer,value["tangent_10"],compact);__privateWireWrite3(writer,value["tangent_11"],compact);__privateWireWrite3(writer,value["tangent_12"],compact);__privateWireWrite3(writer,value["tangent_13"],compact);__privateWireWrite3(writer,value["tangent_14"],compact);__privateWireWrite3(writer,value["tangent_15"],compact);writer.closeFrame(frame);}
function __privateWireWrite24(writer,value,compact){const frame=writer.openFrame();__privateWireWrite9(writer,value["weights"],compact);__privateWireWrite9(writer,value["first"],compact);__privateWireWrite9(writer,value["second"],compact);__privateWireWrite8(writer,value["steps"],compact);__privateWireWrite3(writer,value["first_power"],compact);__privateWireWrite3(writer,value["second_power"],compact);writer.closeFrame(frame);}
function __privateWireWrite4(writer,value,compact){const frame=writer.openFrame();writer.byte(value?1:0);writer.closeFrame(frame);}
function __privateWireWrite1(writer,value,compact){const frame=writer.openFrame();writer.text(value,compact);writer.closeFrame(frame);}
function __privateWireWrite3(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
function __privateWireWrite19(writer,value,compact){const frame=writer.openFrame();writer.text(value,compact);writer.closeFrame(frame);}
function __privateWireWrite8(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
// Handles have no mutable private payload surface. Membership and type identity
// are checked by this module's closure; copied/foreign objects cannot forge them.
const __compiledHandles=new WeakMap();
const __compiledBindings=new WeakMap();
function __compiledHandle(identity,value,guaranteed=false){
 const handle=Object.freeze(Object.create(null));
 __compiledHandles.set(handle,{identity,value,guaranteed});return handle;
}
function __compiledEntry(handle,identity){
 const entry=__compiledHandles.get(handle);
 if(!entry||entry.identity!==identity)throw Error('compiled value type or owner mismatch');
 return entry;
}
function __compiledUnwrap(handle,identity){return __compiledEntry(handle,identity).value;}
// Emit the portable schema's framing/scalar events without creating a buffer
// or exposing private composite nodes. Only this wrapper receives callbacks
// from the literal writer; host visitors never receive those closures.
function __compiledValueEvents(sink,limits){
 const methods=['begin','end','byte','word','wide','text','count'];
 for(const name of methods)if(typeof sink?.[name]!=='function')throw Error('compiled value visitor method: '+name);
 const budget=createValueCaptureBudget(limits);let depth=0,closed=false;
 const active=()=>{if(closed)throw Error('compiled value visitor is closed');};
 const writer=Object.freeze({
  openFrame(){active();budget.enter(depth,4);depth++;sink.begin();return 0;}
  ,closeFrame(){active();if(depth===0)throw Error('wire frame boundary');try{sink.end();}finally{depth--;}}
  ,frame(emit){active();budget.enter(depth,4);depth++;sink.begin();try{emit();sink.end();}finally{depth--;}}
  ,byte(value){active();budget.add(1);sink.byte(value);}
  ,word(value){active();budget.add(4);sink.word(value);}
  ,wide(value){active();budget.add(8);sink.wide(value);}
  ,text(value){active();budget.text(value);sink.text(value);}
  ,count(value){active();budget.add(4);if(value>budget.remaining)throw Error('wire sequence size');sink.count(value);}
 });
 return {writer,close(){closed=true;}};
}
function __compiledReduction(factory,root,reduce,identity){
 if(typeof factory!=='function')throw Error('compiled reduction factory');
 const reducers=[],seen=new Set(),nodes=__reductionNodes();
 const prepare=index=>{
  if(seen.has(index))return;seen.add(index);
  const node=nodes[index];
  for(const child of node.children)prepare(child);
  const reducer=factory(node,index);
  if(node.kind==='list'||node.kind==='vector'){
   const start=reducer?.start,step=reducer?.step,finish=reducer?.finish;
   if(typeof start!=='function'||typeof step!=='function'||typeof finish!=='function')throw Error('compiled collection reduction');
   reducers[index]=Object.freeze({start,step,finish});
  }else{
   if(typeof reducer!=='function')throw Error('compiled value reduction');
   reducers[index]=reducer;
  }
 };
 prepare(root);Object.freeze(reducers);
 return Object.freeze(function(handle,context,limits={}){
  const value=__compiledUnwrap(handle,identity),budget=createValueCaptureBudget(limits);
  return reduce(value,reducers,budget,0,context);
 });
}
function __compiledCodec(schema,capture,read,write,copy,constructorRoot,reductionRoot,reduce,portableFused=false,compactFused=false){
 const privateCodec=createCompiledValueCodec(schema,read),publicCodec=privateCodec;
 let fusedCodec;const fused=()=>fusedCodec??=createFusedValueCodec(schema,read);
 const identity=schema.identity;
 const codec=Object.freeze({
  identity,
  descriptor:publicCodec.descriptor,
  resolve(type){return publicCodec.resolve(type);},
  capture(value,limits={}){
   return __compiledHandle(identity,capture(value,createValueCaptureBudget(limits),0));
  },
  decode(bytes,limits={}){return __compiledHandle(identity,(portableFused?fused():privateCodec).decode(bytes,limits));},
  decodeCompact(bytes,limits={}){return __compiledHandle(identity,(compactFused?fused():privateCodec).compact().decode(bytes,limits));},
  decodeFused(bytes,limits={}){return __compiledHandle(identity,fused().decode(bytes,limits));},
  decodeCompactFused(bytes,limits={}){return __compiledHandle(identity,fused().compact().decode(bytes,limits));},
  encode(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.encodeWith(writer=>write(writer,value,false),limits);},
  encodeCompact(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.compact().encodeWith(writer=>write(writer,value,true),limits);},
  materialize(handle,limits={}){return copy(__compiledUnwrap(handle,identity),createValueCaptureBudget(limits),0);},
  builder(limits={}){return __valueBuilder(__constructorNodes(),constructorRoot,identity,limits);},
  reducer(factory){return __compiledReduction(factory,reductionRoot,reduce,identity);},
  visit(handle,sink,limits={}){
   const value=__compiledUnwrap(handle,identity),events=__compiledValueEvents(sink,limits);
   try{write(events.writer,value,false);}finally{events.close();}
  },
 });
 __compiledBindings.set(codec,{publicCodec,write,capture});return codec;
}

function __compiledEncodeResult(entry,value,limits,compact){
 const {publicCodec,write}=__compiledBindings.get(entry.result());
 return (compact?publicCodec.compact():publicCodec).encodeWith(writer=>write(writer,value,compact),limits);
}
let __constructorNodesValue;function __constructorNodes(){return __constructorNodesValue??=[{kind:"list",patterns:[{bytes:8,label:"sequence",children:[1],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:"enum",scalar:__privateCapture1},{kind:'record',fields:["scale","bias"],patterns:[{bytes:4,label:"record",children:[3,3],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["scale"]:values[0],["bias"]:values[1]})}]},{kind:"f32",scalar:__privateCapture3},{kind:"bool",scalar:__privateCapture4},{kind:'record',fields:["samples","instruction_cost","version"],patterns:[{bytes:4,label:"record",children:[6,3,8],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["samples"]:values[0],["instruction_cost"]:values[1],["version"]:values[2]})}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[7],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["input","target"],patterns:[{bytes:4,label:"record",children:[3,3],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["input"]:values[0],["target"]:values[1]})}]},{kind:"u32",scalar:__privateCapture8},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[3],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["a","b","c","d"],patterns:[{bytes:4,label:"record",children:[11,11,11,11],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1],["c"]:values[2],["d"]:values[3]})}]},{kind:'record',fields:["identity","scale","bias","relu"],patterns:[{bytes:4,label:"record",children:[3,3,3,3],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["identity"]:values[0],["scale"]:values[1],["bias"]:values[2],["relu"]:values[3]})}]},{kind:'record',fields:["slot","operation"],patterns:[{bytes:4,label:"record",children:[8,8],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["slot"]:values[0],["operation"]:values[1]})}]},{kind:'record',fields:["masses","derivatives"],patterns:[{bytes:4,label:"record",children:[9,14],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["masses"]:values[0],["derivatives"]:values[1]})}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[9],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[16],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[19],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'record',fields:["choices","decisions"],patterns:[{bytes:4,label:"record",children:[0,17],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["choices"]:values[0],["decisions"]:values[1]})}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[18],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["action","probability","score"],patterns:[{bytes:4,label:"record",children:[8,3,9],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["action"]:values[0],["probability"]:values[1],["score"]:values[2]})}]},{kind:"string",scalar:__privateCapture19},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[21],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[19],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'record',fields:["code","decisions"],patterns:[{bytes:4,label:"record",children:[0,17],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["code"]:values[0],["decisions"]:values[1]})}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[17],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[19],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[9],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[19],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'record',fields:["weights","first","second","steps","first_power","second_power"],patterns:[{bytes:4,label:"record",children:[9,9,9,8,3,3],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["weights"]:values[0],["first"]:values[1],["second"]:values[2],["steps"]:values[3],["first_power"]:values[4],["second_power"]:values[5]})}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[4],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[18],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[19],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'record',fields:["rate","first_decay","second_decay","epsilon","weight_decay","norm_limit"],patterns:[{bytes:4,label:"record",children:[3,3,3,3,3,3],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["rate"]:values[0],["first_decay"]:values[1],["second_decay"]:values[2],["epsilon"]:values[3],["weight_decay"]:values[4],["norm_limit"]:values[5]})}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[24],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[19],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'record',fields:["a","b","c","d"],patterns:[{bytes:4,label:"record",children:[30,30,30,30],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1],["c"]:values[2],["d"]:values[3]})}]},{kind:'record',fields:["identity","scale","bias","relu"],patterns:[{bytes:4,label:"record",children:[31,31,31,31],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["identity"]:values[0],["scale"]:values[1],["bias"]:values[2],["relu"]:values[3]})}]},{kind:'record',fields:["value","tangent_0","tangent_1","tangent_2","tangent_3","tangent_4","tangent_5","tangent_6","tangent_7","tangent_8","tangent_9","tangent_10","tangent_11","tangent_12","tangent_13","tangent_14","tangent_15"],patterns:[{bytes:4,label:"record",children:[3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["tangent_0"]:values[1],["tangent_1"]:values[2],["tangent_2"]:values[3],["tangent_3"]:values[4],["tangent_4"]:values[5],["tangent_5"]:values[6],["tangent_6"]:values[7],["tangent_7"]:values[8],["tangent_8"]:values[9],["tangent_9"]:values[10],["tangent_10"]:values[11],["tangent_11"]:values[12],["tangent_12"]:values[13],["tangent_13"]:values[14],["tangent_14"]:values[15],["tangent_15"]:values[16]})}]},{kind:'record',fields:["slot","operation"],patterns:[{bytes:4,label:"record",children:[8,8],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["slot"]:values[0],["operation"]:values[1]})}]}];}
// Typed input construction only: plans contain literal constructor/capture
// functions emitted from source schemas. No source expression evaluator.
// All frames and private values remain in this closure; callers receive only
// an owned opaque handle after one complete, well-typed root is constructed.
const __constructorPaths=new WeakMap();
function __valueBuilder(nodes,root,identity,limits){
 const budget=createValueCaptureBudget(limits),frames=[];
 let result,targetNode,targetDepth,complete=false,closed=false,failed=false,busy=false;
 const fail=message=>{failed=true;frames.length=0;result=undefined;throw Error(message);};
 const active=()=>{if(failed||closed)throw Error('value builder is closed');};
 const expected=()=>{
  if(!frames.length){if(complete)fail('value builder root already complete');targetNode=root;targetDepth=0;return;}
  const frame=frames.at(-1),position=frame.values.length;
  if(!frame.pattern.sequence&&position>=frame.pattern.children.length)fail('value builder constructor is full');
  targetNode=frame.pattern.sequence?frame.pattern.children[0]:frame.pattern.children[position];targetDepth=frame.depth+frame.pattern.childDepth;
 };
 const accept=value=>{
  if(frames.length)frames.at(-1).values.push(value);
  else{result=value;complete=true;}
 };
 const execute=(operation,first,second)=>{
  active();if(busy)throw Error('value builder operation already active');busy=true;
  try{return operation(first,second);}catch(error){failed=true;frames.length=0;result=undefined;throw error;}finally{busy=false;}
 };
 // Compile and cache constructor paths independently of the session's values.
 const pathPlan=(choices,startNode,startDepth)=>{
   if(!Array.isArray(choices)||choices.length===0||choices.length>128)fail('invalid value builder path');
   let cache=__constructorPaths.get(nodes);if(!cache){cache=new WeakMap();__constructorPaths.set(nodes,cache);}
   let entries=cache.get(choices),saved=entries?.get(startNode);
   if(saved)return saved;
   const path=[],charges=[];let node=startNode,depth=startDepth;
   for(let i=0;i<choices.length;i++){
    const choice=choices[i],patterns=nodes[node].patterns;
    if(!Number.isSafeInteger(choice)||choice<0||!patterns||choice>=patterns.length)fail('invalid value builder constructor');
    const pattern=patterns[choice];charges.push([pattern,depth-startDepth]);path.push({pattern,node:nodes[node]});
    if(i+1<choices.length){if(pattern.sequence||pattern.children.length!==1)fail('value builder path is not unary');node=pattern.children[0];depth+=pattern.childDepth;}
   }
   const terminal=path.at(-1).pattern;
   // Compose literal constructor functions once per path, instead of
   // allocating and interpreting another recursive closure for every value.
   const compose=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=args=>args[0];
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=args=>p.make([inner(args)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?compose(last+1):args=>args[0]):compose(last);
     return args=>node.flat(index,payload(args));
    }
    const inner=at+1<path.length?compose(at+1):null;
    if(pattern.transparent)return inner??(args=>args[0]);
    return inner?args=>pattern.make([inner(args)]):pattern.make;
   };
   const make=compose(0);
   // Scalar paths use the same literal constructors, but pass the leaf
   // directly through erased records and flat sums. No temporary argument
   // array is needed at those edges. Ordinary constructors keep their array
   // calling convention; no private value reaches the public builder API.
   const composeScalar=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=value=>value;
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=value=>p.make([inner(value)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?composeScalar(last+1):value=>value):composeScalar(last);
     return value=>node.flat(index,payload(value));
    }
    const inner=at+1<path.length?composeScalar(at+1):null;
    if(pattern.transparent)return inner??(value=>value);
    return inner?value=>pattern.make([inner(value)]):value=>pattern.make([value]);
   };
   const scalar=composeScalar(0);
   const pattern={...terminal,make};
   // Only frozen arrays of ordinary data properties can key reusable plans.
   // Mutable arrays and frozen accessor arrays retain checked per-call paths.
   const fixed=charges.every(([p])=>Number.isSafeInteger(p.bytes)&&p.bytes>=4);
   const plan={pattern,scalar,charges,offset:depth-startDepth,bytes:fixed?charges.reduce((n,[p])=>n+p.bytes,0):null};
   let reusable=Object.isFrozen(choices);
   for(let i=0;reusable&&i<choices.length;i++){const field=Object.getOwnPropertyDescriptor(choices,String(i));reusable=!!field&&Object.hasOwn(field,'value');}
   if(reusable){
    if(!entries){entries=new Map();cache.set(choices,entries);}entries.set(startNode,plan);
   }
   return plan;
 };
 const chargePath=(plan,depth)=>{
  // Each emitted constructor consumes one node and a fixed frame/tag cost.
  // Only take the combined charge when every original check would succeed.
  // Replaying the original order retains the exact first failure otherwise.
  if(plan.bytes!==null&&depth+plan.offset<=budget.depth&&plan.charges.length<=budget.remaining&&budget.bytes+plan.bytes<=budget.limit){
   budget.remaining-=plan.charges.length;budget.bytes+=plan.bytes;return;
  }
  for(const [pattern,offset]of plan.charges)pattern.charge(budget,depth+offset);
 };
 // Operations are allocated once per session, and share expected-node
 // scratch only while the existing reentrancy guard is held.
 const openOperation=(choice)=>{
   expected();const node=nodes[targetNode];
   if(!Number.isSafeInteger(choice)||choice<0||!node.patterns||choice>=node.patterns.length)fail('invalid value builder constructor');
   const pattern=node.patterns[choice];pattern.charge(budget,targetDepth);
   frames.push({pattern,depth:targetDepth,values:[]});
 };
 const openPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth);
   chargePath(plan,targetDepth);
   frames.push({pattern:plan.pattern,depth:targetDepth+plan.offset,values:[]});
 };
 const scalarPathOperation=(choices,value)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==1)fail('value builder path has no scalar leaf');
   const capture=nodes[pattern.children[0]].scalar;
   if(typeof capture!=='function')fail('value builder path has no scalar leaf');
   chargePath(plan,targetDepth);
   const leaf=capture(value,budget,targetDepth+plan.offset+pattern.childDepth);
   accept(plan.scalar(leaf));
 };
 const emptyPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==0)fail('value builder path is not empty');
   chargePath(plan,targetDepth);accept(pattern.make([]));
 };
 const scalarOperation=(value)=>{
   expected();const capture=nodes[targetNode].scalar;
   if(typeof capture!=='function')fail('value builder expects a constructor');
   accept(capture(value,budget,targetDepth));
 };
 const closeOperation=()=>{
   if(!frames.length)fail('value builder has no open constructor');
   const frame=frames.at(-1),pattern=frame.pattern,count=frame.values.length;
   if(!pattern.sequence&&count!==pattern.children.length||pattern.size!==undefined&&count!==pattern.size)fail('value builder constructor arity');
   if(pattern.sequence&&count>budget.limit)fail('wire sequence size');
   const value=pattern.make(frame.values);
   frames.pop();accept(value);
 };
 const finishOperation=()=>{
   if(frames.length||!complete)fail('value builder root is incomplete');
   closed=true;const handle=__compiledHandle(identity,result);result=undefined;return handle;
 };
 const api=Object.freeze({
  open(choice){return execute(openOperation,choice);},
  // Charge every source constructor even when unary paths share one frame.
  openPath(choices){return execute(openPathOperation,choices);},
  // Complete the path and leaf without intermediate session frames.
  scalarPath(choices,value){return execute(scalarPathOperation,choices,value);},
  emptyPath(choices){return execute(emptyPathOperation,choices);},
  scalar(value){return execute(scalarOperation,value);},
  close(){return execute(closeOperation);},
  finish(){return execute(finishOperation);},
  abort(){if(busy)throw Error('value builder operation already active');failed=true;frames.length=0;result=undefined;},
 });
 return api;
}
function __reduceValue0(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[0];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue1(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue1(value,r,b,d,c){b.enter(d,4);b.text(value);return r[1](value,c);}
function __reduceValue2(value,r,b,d,c){b.enter(d,4);return r[2](__reduceValue3(value["scale"],r,b,d+1,c),__reduceValue3(value["bias"],r,b,d+1,c),c);}
function __reduceValue3(value,r,b,d,c){b.enter(d,8);return r[3]({F32Bits:value},c);}
function __reduceValue4(value,r,b,d,c){b.enter(d,5);return r[4](value,c);}
function __reduceValue5(value,r,b,d,c){b.enter(d,4);return r[5](__reduceValue6(value["samples"],r,b,d+1,c),__reduceValue3(value["instruction_cost"],r,b,d+1,c),__reduceValue8(value["version"],r,b,d+1,c),c);}
function __reduceValue6(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[6];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue7(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue7(value,r,b,d,c){b.enter(d,4);return r[7](__reduceValue3(value["input"],r,b,d+1,c),__reduceValue3(value["target"],r,b,d+1,c),c);}
function __reduceValue8(value,r,b,d,c){b.enter(d,8);return r[8](value,c);}
function __reduceValue9(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[9];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue3(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue10(value,r,b,d,c){b.enter(d,4);return r[10](__reduceValue11(value["a"],r,b,d+1,c),__reduceValue11(value["b"],r,b,d+1,c),__reduceValue11(value["c"],r,b,d+1,c),__reduceValue11(value["d"],r,b,d+1,c),c);}
function __reduceValue11(value,r,b,d,c){b.enter(d,4);return r[11](__reduceValue3(value["identity"],r,b,d+1,c),__reduceValue3(value["scale"],r,b,d+1,c),__reduceValue3(value["bias"],r,b,d+1,c),__reduceValue3(value["relu"],r,b,d+1,c),c);}
function __reduceValue12(value,r,b,d,c){b.enter(d,4);return r[12](__reduceValue8(value["slot"],r,b,d+1,c),__reduceValue8(value["operation"],r,b,d+1,c),c);}
function __reduceValue13(value,r,b,d,c){b.enter(d,4);return r[13](__reduceValue9(value["masses"],r,b,d+1,c),__reduceValue14(value["derivatives"],r,b,d+1,c),c);}
function __reduceValue14(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[14];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue9(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue15(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[15](0,__reduceValue16(value.Ok,r,b,d+1,c),c):r[15](1,__reduceValue19(value.Err,r,b,d+1,c),c);}
function __reduceValue16(value,r,b,d,c){b.enter(d,4);return r[16](__reduceValue0(value["choices"],r,b,d+1,c),__reduceValue17(value["decisions"],r,b,d+1,c),c);}
function __reduceValue17(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[17];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue18(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue18(value,r,b,d,c){b.enter(d,4);return r[18](__reduceValue8(value["action"],r,b,d+1,c),__reduceValue3(value["probability"],r,b,d+1,c),__reduceValue9(value["score"],r,b,d+1,c),c);}
function __reduceValue19(value,r,b,d,c){b.enter(d,4);b.text(value);return r[19](value,c);}
function __reduceValue20(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[20](0,__reduceValue21(value.Ok,r,b,d+1,c),c):r[20](1,__reduceValue19(value.Err,r,b,d+1,c),c);}
function __reduceValue21(value,r,b,d,c){b.enter(d,4);return r[21](__reduceValue0(value["code"],r,b,d+1,c),__reduceValue17(value["decisions"],r,b,d+1,c),c);}
function __reduceValue22(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[22](0,__reduceValue17(value.Ok,r,b,d+1,c),c):r[22](1,__reduceValue19(value.Err,r,b,d+1,c),c);}
function __reduceValue23(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[23](0,__reduceValue9(value.Ok,r,b,d+1,c),c):r[23](1,__reduceValue19(value.Err,r,b,d+1,c),c);}
function __reduceValue24(value,r,b,d,c){b.enter(d,4);return r[24](__reduceValue9(value["weights"],r,b,d+1,c),__reduceValue9(value["first"],r,b,d+1,c),__reduceValue9(value["second"],r,b,d+1,c),__reduceValue8(value["steps"],r,b,d+1,c),__reduceValue3(value["first_power"],r,b,d+1,c),__reduceValue3(value["second_power"],r,b,d+1,c),c);}
function __reduceValue25(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[25];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue4(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue26(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[26](0,__reduceValue18(value.Ok,r,b,d+1,c),c):r[26](1,__reduceValue19(value.Err,r,b,d+1,c),c);}
function __reduceValue27(value,r,b,d,c){b.enter(d,4);return r[27](__reduceValue3(value["rate"],r,b,d+1,c),__reduceValue3(value["first_decay"],r,b,d+1,c),__reduceValue3(value["second_decay"],r,b,d+1,c),__reduceValue3(value["epsilon"],r,b,d+1,c),__reduceValue3(value["weight_decay"],r,b,d+1,c),__reduceValue3(value["norm_limit"],r,b,d+1,c),c);}
function __reduceValue28(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[28](0,__reduceValue24(value.Ok,r,b,d+1,c),c):r[28](1,__reduceValue19(value.Err,r,b,d+1,c),c);}
function __reduceValue29(value,r,b,d,c){b.enter(d,4);return r[29](__reduceValue30(value["a"],r,b,d+1,c),__reduceValue30(value["b"],r,b,d+1,c),__reduceValue30(value["c"],r,b,d+1,c),__reduceValue30(value["d"],r,b,d+1,c),c);}
function __reduceValue30(value,r,b,d,c){b.enter(d,4);return r[30](__reduceValue31(value["identity"],r,b,d+1,c),__reduceValue31(value["scale"],r,b,d+1,c),__reduceValue31(value["bias"],r,b,d+1,c),__reduceValue31(value["relu"],r,b,d+1,c),c);}
function __reduceValue31(value,r,b,d,c){b.enter(d,4);return r[31](__reduceValue3(value["value"],r,b,d+1,c),__reduceValue3(value["tangent_0"],r,b,d+1,c),__reduceValue3(value["tangent_1"],r,b,d+1,c),__reduceValue3(value["tangent_2"],r,b,d+1,c),__reduceValue3(value["tangent_3"],r,b,d+1,c),__reduceValue3(value["tangent_4"],r,b,d+1,c),__reduceValue3(value["tangent_5"],r,b,d+1,c),__reduceValue3(value["tangent_6"],r,b,d+1,c),__reduceValue3(value["tangent_7"],r,b,d+1,c),__reduceValue3(value["tangent_8"],r,b,d+1,c),__reduceValue3(value["tangent_9"],r,b,d+1,c),__reduceValue3(value["tangent_10"],r,b,d+1,c),__reduceValue3(value["tangent_11"],r,b,d+1,c),__reduceValue3(value["tangent_12"],r,b,d+1,c),__reduceValue3(value["tangent_13"],r,b,d+1,c),__reduceValue3(value["tangent_14"],r,b,d+1,c),__reduceValue3(value["tangent_15"],r,b,d+1,c),c);}
function __reduceValue32(value,r,b,d,c){b.enter(d,4);return r[32](__reduceValue8(value["slot"],r,b,d+1,c),__reduceValue8(value["operation"],r,b,d+1,c),c);}
let __reductionNodeCache;function __reductionNodes(){return __reductionNodeCache??=Object.freeze([Object.freeze({"children":Object.freeze([1]),"kind":"list"}),Object.freeze({"children":Object.freeze([]),"kind":"enum","name":"Op"}),Object.freeze({"children":Object.freeze([3,3]),"fields":Object.freeze(["scale","bias"]),"kind":"record","name":"Coefficients"}),Object.freeze({"children":Object.freeze([]),"kind":"f32"}),Object.freeze({"children":Object.freeze([]),"kind":"bool"}),Object.freeze({"children":Object.freeze([6,3,8]),"fields":Object.freeze(["samples","instruction_cost","version"]),"kind":"record","name":"Goal"}),Object.freeze({"children":Object.freeze([7]),"kind":"list"}),Object.freeze({"children":Object.freeze([3,3]),"fields":Object.freeze(["input","target"]),"kind":"record","name":"Example"}),Object.freeze({"children":Object.freeze([]),"kind":"u32"}),Object.freeze({"children":Object.freeze([3]),"kind":"list"}),Object.freeze({"children":Object.freeze([11,11,11,11]),"fields":Object.freeze(["a","b","c","d"]),"kind":"record","name":"Parameters"}),Object.freeze({"children":Object.freeze([3,3,3,3]),"fields":Object.freeze(["identity","scale","bias","relu"]),"kind":"record","name":"MassRow"}),Object.freeze({"children":Object.freeze([8,8]),"fields":Object.freeze(["slot","operation"]),"kind":"record","name":"Pick"}),Object.freeze({"children":Object.freeze([9,14]),"fields":Object.freeze(["masses","derivatives"]),"kind":"record","name":"Distribution"}),Object.freeze({"children":Object.freeze([9]),"kind":"list"}),Object.freeze({"children":Object.freeze([16,19]),"kind":"result"}),Object.freeze({"children":Object.freeze([0,17]),"fields":Object.freeze(["choices","decisions"]),"kind":"record","name":"Building"}),Object.freeze({"children":Object.freeze([18]),"kind":"list"}),Object.freeze({"children":Object.freeze([8,3,9]),"fields":Object.freeze(["action","probability","score"]),"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"}),Object.freeze({"children":Object.freeze([]),"kind":"string"}),Object.freeze({"children":Object.freeze([21,19]),"kind":"result"}),Object.freeze({"children":Object.freeze([0,17]),"fields":Object.freeze(["code","decisions"]),"kind":"record","name":"Sampled"}),Object.freeze({"children":Object.freeze([17,19]),"kind":"result"}),Object.freeze({"children":Object.freeze([9,19]),"kind":"result"}),Object.freeze({"children":Object.freeze([9,9,9,8,3,3]),"fields":Object.freeze(["weights","first","second","steps","first_power","second_power"]),"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}),Object.freeze({"children":Object.freeze([4]),"kind":"list"}),Object.freeze({"children":Object.freeze([18,19]),"kind":"result"}),Object.freeze({"children":Object.freeze([3,3,3,3,3,3]),"fields":Object.freeze(["rate","first_decay","second_decay","epsilon","weight_decay","norm_limit"]),"kind":"record","name":"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249"}),Object.freeze({"children":Object.freeze([24,19]),"kind":"result"}),Object.freeze({"children":Object.freeze([30,30,30,30]),"fields":Object.freeze(["a","b","c","d"]),"kind":"record","name":"__ink_differential_4"}),Object.freeze({"children":Object.freeze([31,31,31,31]),"fields":Object.freeze(["identity","scale","bias","relu"]),"kind":"record","name":"__ink_differential_5"}),Object.freeze({"children":Object.freeze([3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3]),"fields":Object.freeze(["value","tangent_0","tangent_1","tangent_2","tangent_3","tangent_4","tangent_5","tangent_6","tangent_7","tangent_8","tangent_9","tangent_10","tangent_11","tangent_12","tangent_13","tangent_14","tangent_15"]),"kind":"record","name":"__ink_differential_2"}),Object.freeze({"children":Object.freeze([8,8]),"fields":Object.freeze(["slot","operation"]),"kind":"record","name":"__ink_differential_6"})]);}
function __compiledNamed0(){return {};}
let __compiledCodec0Value;function __compiledCodec0(){return __compiledCodec0Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"860b49ac371fbbb1781d7fdf0db972e84422ce6c242eed38ddb691d1ad2cd2c3","named":__compiledNamed0(),"root":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},__privateCapture0,__privateWireValue0,__privateWireWrite0,__compiledOwnedValue0,0,0,__reduceValue0,false,false);}
let __compiledCodec1Value;function __compiledCodec1(){return __compiledCodec1Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"1e1ce8ebe785cb494bc9c1ea8c707ee3dc4258a2f16d5add14863dc8890901da","named":__compiledNamed0(),"root":{"fields":[{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}}],"kind":"record","name":"Coefficients"}},__privateCapture2,__privateWireValue2,__privateWireWrite2,__compiledOwnedValue2,2,2,__reduceValue2,false,false);}
let __compiledCodec2Value;function __compiledCodec2(){return __compiledCodec2Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":__compiledNamed0(),"root":{"kind":"f32"}},__privateCapture3,__privateWireValue3,__privateWireWrite3,__compiledOwnedValue3,3,3,__reduceValue3,false,false);}
let __compiledCodec3Value;function __compiledCodec3(){return __compiledCodec3Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":__compiledNamed0(),"root":{"kind":"bool"}},__privateCapture4,__privateWireValue5,__privateWireWrite4,__compiledOwnedValue4,4,4,__reduceValue4,false,false);}
let __compiledCodec4Value;function __compiledCodec4(){return __compiledCodec4Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"f287403b58469765fdd8deed7aad91c185b2b5119f4206d6d80e09c48f3a9305","named":__compiledNamed0(),"root":{"fields":[{"name":"samples","type":{"element":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"},"kind":"list"}},{"name":"instruction_cost","type":{"kind":"f32"}},{"name":"version","type":{"kind":"u32"}}],"kind":"record","name":"Goal"}},__privateCapture5,__privateWireValue7,__privateWireWrite5,__compiledOwnedValue5,5,5,__reduceValue5,false,false);}
let __compiledCodec5Value;function __compiledCodec5(){return __compiledCodec5Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fd165936dc4b66c22218903807379d236e0bac31c0cf62b070d702592d2f20af","named":__compiledNamed0(),"root":{"fields":[{"name":"input","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Example"}},__privateCapture7,__privateWireValue9,__privateWireWrite7,__compiledOwnedValue7,7,7,__reduceValue7,false,false);}
let __compiledCodec6Value;function __compiledCodec6(){return __compiledCodec6Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":__compiledNamed0(),"root":{"element":{"kind":"f32"},"kind":"list"}},__privateCapture9,__privateWireValue14,__privateWireWrite9,__compiledOwnedValue9,9,9,__reduceValue9,false,false);}
let __compiledCodec7Value;function __compiledCodec7(){return __compiledCodec7Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"2af269616d48554c4ef5e8a1371afd52412f1ef4f05c2d9506bd43bfde5de326","named":__compiledNamed0(),"root":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}},__privateCapture10,__privateWireValue15,__privateWireWrite10,__compiledOwnedValue10,10,10,__reduceValue10,false,false);}
let __compiledCodec8Value;function __compiledCodec8(){return __compiledCodec8Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"90d27c3bfbfcbfb1eb38f6a728d7bba55f35673fcf68b40398473bd2df865ec5","named":__compiledNamed0(),"root":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"Pick"}},__privateCapture12,__privateWireValue19,__privateWireWrite12,__compiledOwnedValue12,12,12,__reduceValue12,false,false);}
let __compiledCodec9Value;function __compiledCodec9(){return __compiledCodec9Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff","named":__compiledNamed0(),"root":{"kind":"u32"}},__privateCapture8,__privateWireValue10,__privateWireWrite8,__compiledOwnedValue8,8,8,__reduceValue8,false,false);}
let __compiledCodec10Value;function __compiledCodec10(){return __compiledCodec10Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"b3b157bb16bd893ea71380744900064a9de9eb7c3acb99e1b5f09d5ea004acdc","named":__compiledNamed0(),"root":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]}},__privateCapture1,__privateWireValue1,__privateWireWrite1,__compiledOwnedValue1,1,1,__reduceValue1,false,false);}
let __compiledCodec11Value;function __compiledCodec11(){return __compiledCodec11Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"b58490b582e9db511b7d71c575e602c19fd38a9ce66a06065b482246605c09a9","named":__compiledNamed0(),"root":{"fields":[{"name":"masses","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"derivatives","type":{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"}}],"kind":"record","name":"Distribution"}},__privateCapture13,__privateWireValue22,__privateWireWrite13,__compiledOwnedValue13,13,13,__reduceValue13,false,false);}
let __compiledCodec12Value;function __compiledCodec12(){return __compiledCodec12Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"2031034504710782006d73b2256047567d88bffe38d126e61266c10961c7253a","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"choices","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}],"kind":"record","name":"Building"}}},__privateCapture15,__privateWireValue25,__privateWireWrite15,__compiledOwnedValue15,15,15,__reduceValue15,false,false);}
let __compiledCodec13Value;function __compiledCodec13(){return __compiledCodec13Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"f5fccdf188a8fa8e7f79687e82888811bdcfc6c5067f21e08583a3d045794cc3","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"code","type":{"element":{"kind":"enum","name":"Op","variants":["Op.Identity","Op.Scale","Op.Bias","Op.Relu"]},"kind":"list"}},{"name":"decisions","type":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}],"kind":"record","name":"Sampled"}}},__privateCapture20,__privateWireValue31,__privateWireWrite20,__compiledOwnedValue20,20,20,__reduceValue20,false,false);}
let __compiledCodec14Value;function __compiledCodec14(){return __compiledCodec14Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"e1b825ef360a6557af5947d501dffff13bf6e9d8532025b04e5cd262660ad2e7","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}}},__privateCapture22,__privateWireValue36,__privateWireWrite22,__compiledOwnedValue22,22,22,__reduceValue22,false,false);}
let __compiledCodec15Value;function __compiledCodec15(){return __compiledCodec15Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"9ce74016ea42927196508ef07c8a7b394ee849fd215473204268c5c693b53818","named":__compiledNamed0(),"root":{"element":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"},"kind":"list"}},__privateCapture17,__privateWireValue27,__privateWireWrite17,__compiledOwnedValue17,17,17,__reduceValue17,false,false);}
let __compiledCodec16Value;function __compiledCodec16(){return __compiledCodec16Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},__privateCapture23,__privateWireValue38,__privateWireWrite23,__compiledOwnedValue23,23,23,__reduceValue23,false,false);}
let __compiledCodec17Value;function __compiledCodec17(){return __compiledCodec17Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fb51f6ef47ef23bec5fa30a1bf44674eef7e617546994700a49bccfb4c1baba3","named":__compiledNamed0(),"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}},__privateCapture24,__privateWireValue40,__privateWireWrite24,__compiledOwnedValue24,24,24,__reduceValue24,false,false);}
let __compiledCodec18Value;function __compiledCodec18(){return __compiledCodec18Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"e068b4428ffb87ff21e134eb8b1d7aa7d64685b0c2940afaabbaf063feec0fe2","named":__compiledNamed0(),"root":{"element":{"kind":"bool"},"kind":"list"}},__privateCapture25,__privateWireValue42,__privateWireWrite25,__compiledOwnedValue25,25,25,__reduceValue25,false,false);}
let __compiledCodec19Value;function __compiledCodec19(){return __compiledCodec19Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"10f1dcead19744e0a592fb45cc3a7937377e3d50ca1c195e603898f63e9b4264","named":__compiledNamed0(),"root":{"element":{"element":{"kind":"f32"},"kind":"list"},"kind":"list"}},__privateCapture14,__privateWireValue23,__privateWireWrite14,__compiledOwnedValue14,14,14,__reduceValue14,false,false);}
let __compiledCodec20Value;function __compiledCodec20(){return __compiledCodec20Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"4c26cf6146a67b60bc34cb27a1b07b25ab14048bb6f0044b09b8e87179b513fa","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"}}},__privateCapture26,__privateWireValue47,__privateWireWrite26,__compiledOwnedValue26,26,26,__reduceValue26,false,false);}
let __compiledCodec21Value;function __compiledCodec21(){return __compiledCodec21Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"6ada1b4efc795e823ba4ca0f4a68bae5507ad7785519e130f769db0e46ede73b","named":__compiledNamed0(),"root":{"fields":[{"name":"action","type":{"kind":"u32"}},{"name":"probability","type":{"kind":"f32"}},{"name":"score","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0"}},__privateCapture18,__privateWireValue28,__privateWireWrite18,__compiledOwnedValue18,18,18,__reduceValue18,false,false);}
let __compiledCodec22Value;function __compiledCodec22(){return __compiledCodec22Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"ebe1deeb6dfcd30c7222004d895fd628b866b66eaba30c8067beddc0fad06e6e","named":__compiledNamed0(),"root":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}},{"name":"weight_decay","type":{"kind":"f32"}},{"name":"norm_limit","type":{"kind":"f32"}}],"kind":"record","name":"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249"}},__privateCapture27,__privateWireValue55,__privateWireWrite27,__compiledOwnedValue27,27,27,__reduceValue27,false,false);}
let __compiledCodec23Value;function __compiledCodec23(){return __compiledCodec23Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"93944e72b897c9246b2efb71a34cebe025e2d57af4d472565578d66dcdc24614","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"first","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"second","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"steps","type":{"kind":"u32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}}],"kind":"record","name":"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab"}}},__privateCapture28,__privateWireValue58,__privateWireWrite28,__compiledOwnedValue28,28,28,__reduceValue28,false,false);}
let __compiledCodec24Value;function __compiledCodec24(){return __compiledCodec24Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"69fa1f86c0802e9ea4a81f07b4a316b84c2eea52b26d6c85b03561911588f8fd","named":__compiledNamed0(),"root":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"}},__privateCapture29,__privateWireValue65,__privateWireWrite29,__compiledOwnedValue29,29,29,__reduceValue29,false,false);}
let __compiledCodec25Value;function __compiledCodec25(){return __compiledCodec25Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"7a219422b28ff5a00294fafcdfd098ec59cb4c4d6641d22bfe7b7cecf550dfab","named":__compiledNamed0(),"root":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_6"}},__privateCapture32,__privateWireValue68,__privateWireWrite32,__compiledOwnedValue32,32,32,__reduceValue32,false,false);}
let __compiledCodec26Value;function __compiledCodec26(){return __compiledCodec26Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"cfdb397c2afc9c623de1f1010b9630cbab4a4f82a83884720c53cd04425275d8","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},__privateCapture31,__privateWireValue67,__privateWireWrite31,__compiledOwnedValue31,31,31,__reduceValue31,false,false);}
const __compiledEntries=new Map([["evaluate",{index:0,params:[__compiledCodec0,__compiledCodec1,__compiledCodec2],result:__compiledCodec2,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["coefficients_valid",{index:1,params:[__compiledCodec1],result:__compiledCodec3,arguments:__privateWireValue6,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["goal_valid",{index:2,params:[__compiledCodec4],result:__compiledCodec3,arguments:__privateWireValue11,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["squared_error",{index:3,params:[__compiledCodec0,__compiledCodec1,__compiledCodec5],result:__compiledCodec2,arguments:__privateWireValue12,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["objective",{index:4,params:[__compiledCodec0,__compiledCodec1,__compiledCodec4],result:__compiledCodec2,arguments:__privateWireValue13,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["unpack",{index:5,params:[__compiledCodec6],result:__compiledCodec7,arguments:__privateWireValue17,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["pack",{index:6,params:[__compiledCodec7],result:__compiledCodec6,arguments:__privateWireValue18,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["mass",{index:7,params:[__compiledCodec7,__compiledCodec8],result:__compiledCodec2,arguments:__privateWireValue20,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["operation",{index:8,params:[__compiledCodec9],result:__compiledCodec10,arguments:__privateWireValue21,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["distribution",{index:9,params:[__compiledCodec7,__compiledCodec9],result:__compiledCodec11,arguments:__privateWireValue24,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["sample_slot",{index:10,params:[__compiledCodec12,__compiledCodec9,__compiledCodec7,__compiledCodec6],result:__compiledCodec12,arguments:__privateWireValue30,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["sample",{index:11,params:[__compiledCodec6,__compiledCodec6],result:__compiledCodec13,arguments:__privateWireValue33,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["reward",{index:12,params:[__compiledCodec2],result:__compiledCodec2,arguments:__privateWireValue34,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["operation_index",{index:13,params:[__compiledCodec10],result:__compiledCodec9,arguments:__privateWireValue35,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["elite_slot",{index:14,params:[__compiledCodec14,__compiledCodec9,__compiledCodec7,__compiledCodec0],result:__compiledCodec14,arguments:__privateWireValue37,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["proposal_gradient",{index:15,params:[__compiledCodec6,__compiledCodec0,__compiledCodec15,__compiledCodec2,__compiledCodec2],result:__compiledCodec16,arguments:__privateWireValue39,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false],precondition:null}],["valid_policy",{index:16,params:[__compiledCodec17],result:__compiledCodec3,arguments:__privateWireValue41,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["numeric",{index:17,params:[__compiledCodec6],result:__compiledCodec6,arguments:__privateWireValue17,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54",{index:18,params:[__compiledCodec6],result:__compiledCodec3,arguments:__privateWireValue17,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["ink_m28a5428efa573345218636e9cec104f24b6e8c67d7c4c0f979b255813b2abee3",{index:19,params:[__compiledCodec6,__compiledCodec18],result:__compiledCodec2,arguments:__privateWireValue43,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["ink_mfd18151b0af45b45f5b48ef5e7a09ac1294681f654e2174ae3b33183f445ef14",{index:20,params:[__compiledCodec6,__compiledCodec18],result:__compiledCodec16,arguments:__privateWireValue43,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["ink_mc05a2256079ef1f1818d13e69727dc7902cdb7f70856a671af2ba08ef190d23a",{index:21,params:[__compiledCodec6,__compiledCodec18],result:__compiledCodec16,arguments:__privateWireValue43,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["ink_m6ec6e8f9e757c220bfe2ed28cbb8dab4ec520de5ee8de5ca702cbdb805a5f910",{index:22,params:[__compiledCodec6,__compiledCodec2,__compiledCodec2],result:__compiledCodec9,arguments:__privateWireValue44,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["ink_maa2c8802d351b443dda0bc206d70fa9fe87756b57a84d0357e9dfb4c1e7a0667",{index:23,params:[__compiledCodec19,__compiledCodec18,__compiledCodec2,__compiledCodec2],result:__compiledCodec6,arguments:__privateWireValue45,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["ink_m1774c4db693eebe71b1f79bce053b93633d1e1ec37196dd480b59c0248b4fbc2",{index:24,params:[__compiledCodec6,__compiledCodec19,__compiledCodec18,__compiledCodec2,__compiledCodec9],result:__compiledCodec6,arguments:__privateWireValue46,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false],precondition:null}],["ink_m1fbf7ee6cef3bcca5d7d258c8606275806894b60d839126202d17f016ea87c80",{index:25,params:[__compiledCodec6,__compiledCodec19,__compiledCodec18,__compiledCodec2],result:__compiledCodec20,arguments:__privateWireValue48,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["ink_m99468fca85aa8fb996f0c891430c813d82505250d39d8e415bf27679ddc39e07",{index:26,params:[__compiledCodec6,__compiledCodec19,__compiledCodec18,__compiledCodec9],result:__compiledCodec20,arguments:__privateWireValue49,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["ink_maadd6c30a027af52d851f0828eec45339d218ad3bbe73e4d8d7cdd3892e754f4",{index:27,params:[__compiledCodec21,__compiledCodec2,__compiledCodec2],result:__compiledCodec16,arguments:__privateWireValue50,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["ink_m696809152e57d8dfa3f01f9a3e12c048434b9f2af91ff53321ea6ceeeeca5431",{index:28,params:[__compiledCodec16,__compiledCodec21,__compiledCodec2,__compiledCodec2],result:__compiledCodec16,arguments:__privateWireValue51,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["ink_m372cbaf2ee2bc8705fad4b5b65a9e744ea468afbe4c153f17c7da282a459d1cd",{index:29,params:[__compiledCodec15,__compiledCodec6,__compiledCodec6],result:__compiledCodec16,arguments:__privateWireValue52,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["ink_m43c1e2ac4d6d9a37358654ff5c1abcd42d4b01146c41a7ca617bccb074a8813b",{index:30,params:[__compiledCodec15,__compiledCodec6,__compiledCodec6],result:__compiledCodec16,arguments:__privateWireValue52,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["ink_m4b5ada8f7d6b3beaee6fc06bf68e61ca158cbc7664899364dff18d21555697ae",{index:31,params:[__compiledCodec15,__compiledCodec2,__compiledCodec2],result:__compiledCodec16,arguments:__privateWireValue53,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["ink_mda500f665e6078213ee2391fedf06240c651d1725327b086aa70cda14bef9a07",{index:32,params:[__compiledCodec6,__compiledCodec2,__compiledCodec2],result:__compiledCodec16,arguments:__privateWireValue54,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["ink_meefc22a28d97f5bdc4100b36eeab9549241c3ef201b83c2f75111644d317833d",{index:33,params:[__compiledCodec2],result:__compiledCodec22,arguments:__privateWireValue56,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96",{index:34,params:[__compiledCodec6],result:__compiledCodec3,arguments:__privateWireValue17,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["ink_m786bdc6011aece08dbf36c5ca89c437e06ff758c9d3d242f723dde2af6ea31db",{index:35,params:[__compiledCodec17],result:__compiledCodec3,arguments:__privateWireValue57,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["ink_mdfbd57a9f460147afedb262e2bfe0f6197f9b813c85277c59f5e101900063ad7",{index:36,params:[__compiledCodec6],result:__compiledCodec23,arguments:__privateWireValue59,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["ink_m5226ad25deae5e47d7fb65b6b5961d46740dd4e97b54d76a24d3d0445845fe35",{index:37,params:[__compiledCodec22],result:__compiledCodec3,arguments:__privateWireValue60,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["ink_m8abb6b2bcbe55251e0b82a28f26d7ce761729346e35019c2b60ca9b5ee22590d",{index:38,params:[__compiledCodec2],result:__compiledCodec2,arguments:__privateWireValue61,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["ink_m7d03a2ed6071238ff1b69a8e56a8cb96b9dc3b095b2d939c0ccfed84ee9580b5",{index:39,params:[__compiledCodec6,__compiledCodec2],result:__compiledCodec2,arguments:__privateWireValue62,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["ink_m00ba8185ca362d257d138fe1886cbc5f3acc38c4a238bef60c3d3d7fa0276eab",{index:40,params:[__compiledCodec2,__compiledCodec2,__compiledCodec2,__compiledCodec2,__compiledCodec2,__compiledCodec22],result:__compiledCodec2,arguments:__privateWireValue63,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false,false],precondition:null}],["ink_m2a55f95a80595bc61d1fcab41ff00f438ff6f2057b597df20aaae3c18507d2be",{index:41,params:[__compiledCodec17,__compiledCodec6,__compiledCodec22],result:__compiledCodec23,arguments:__privateWireValue64,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["__ink_differential_3",{index:42,params:[__compiledCodec24,__compiledCodec25],result:__compiledCodec26,arguments:__privateWireValue69,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_1",{index:43,params:[__compiledCodec7,__compiledCodec8],result:__compiledCodec7,arguments:__privateWireValue20,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__frozen_proposal_3",{index:44,params:[__compiledCodec1,__compiledCodec2],result:__compiledCodec2,arguments:__privateWireValue70,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__frozen_proposal_43",{index:45,params:[__compiledCodec1,__compiledCodec2],result:__compiledCodec2,arguments:__privateWireValue71,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__frozen_proposal_49",{index:46,params:[__compiledCodec1,__compiledCodec2],result:__compiledCodec2,arguments:__privateWireValue72,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__frozen_proposal_110",{index:47,params:[__compiledCodec2],result:__compiledCodec2,arguments:__privateWireValue73,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["__frozen_proposal_150",{index:48,params:[__compiledCodec2],result:__compiledCodec2,arguments:__privateWireValue74,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["__frozen_proposal_156",{index:49,params:[__compiledCodec2],result:__compiledCodec2,arguments:__privateWireValue75,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["__frozen_proposal_166",{index:50,params:[__compiledCodec1,__compiledCodec4],result:__compiledCodec2,arguments:__privateWireValue76,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}]]);

export const compiledValues=Object.freeze(Object.fromEntries([...__compiledEntries].map(([name,entry])=>[name,Object.freeze({get params(){return Object.freeze(entry.params.map(codec=>codec()));},get result(){return entry.result();}})])));
function __compiledValidate(entry,owned){
 const values=owned.map(v=>v.value);
 const established=entry.onlyTypeGuards&&entry.needsInvariants.every((needed,i)=>!needed||owned[i].guaranteed);
 if(entry.precondition!==null&&!established){
  if(__implementations[entry.precondition](...values)!==true)throw Error('contract precondition failed');
  for(let i=0;i<owned.length;i++)if(entry.needsInvariants[i])owned[i].guaranteed=true;
 }
 return values;
}
export function callCompiled(name,args){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(args)||args.length!==entry.params.length)throw Error('unsupported compiled call');
 const owned=entry.params.map((codec,i)=>__compiledEntry(args[i],codec().identity)),values=__compiledValidate(entry,owned);
 // Checked source outputs satisfy their declared value interfaces. Private
 // handles expose only detached copies and never retain mutable host inputs.
 return __compiledHandle(entry.result().identity,__implementations[entry.index](...values),true);
}

// Explicit sealed-value partial application. Each token owns a bounded set of
// lexical caches; no mutable host object, global memo table or error is retained.
const __preparedCompiled=new WeakMap();
export function prepareCompiled(name,bindings){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(bindings)||bindings.length>entry.params.length)throw Error('unsupported prepared compiled call');
 const captured=new Array(entry.params.length),fixed=new Array(entry.params.length).fill(false);
 for(const binding of bindings){
  if(!Array.isArray(binding)||binding.length!==2)throw Error('prepared compiled binding');
  const [index,handle]=binding;
  if(!Number.isInteger(index)||index<0||index>=fixed.length||fixed[index])throw Error('prepared compiled parameter');
  captured[index]=__compiledEntry(handle,entry.params[index]().identity);fixed[index]=true;
 }
 const remaining=fixed.flatMap((yes,i)=>yes?[]:[i]);
 const factory=__preparedFactories.get(entry.index);
 const run=factory?factory(fixed):__implementations[entry.index];
 const token=Object.freeze(Object.create(null));
 __preparedCompiled.set(token,{entry,captured,remaining,run});return token;
}
export function callPreparedCompiled(token,args){
 const prepared=__preparedCompiled.get(token);
 if(!prepared||!Array.isArray(args)||args.length!==prepared.remaining.length)throw Error('invalid prepared compiled call');
 const {entry,captured,remaining,run}=prepared,owned=captured.slice();
 for(let i=0;i<remaining.length;i++){const at=remaining[i];owned[at]=__compiledEntry(args[i],entry.params[at]().identity);}
 const values=__compiledValidate(entry,owned);
 return __compiledHandle(entry.result().identity,run(...values),true);
}
const __intoOutput6=__representation(metadata.functions[6].result.element,true);
const __intoOutput17=__representation(metadata.functions[17].result.element,true);
const __intoOutput23=__representation(metadata.functions[23].result.element,true);
const __intoOutput24=__representation(metadata.functions[24].result.element,true);
const __intoImplementations=[null,null,null,null,null,null,__into6,null,null,null,null,null,null,null,null,null,null,__into17,null,null,null,null,null,__into23,__into24,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];

export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>{
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const body=__intoImplementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args.slice(0,f.params.length))!==true)throw Error('contract precondition failed');return body(...args);};
  const entry=input.every(c=>c===__identity)?implementation:(...values)=>{const context=new WeakMap();return implementation(...input.map((convert,i)=>convert(values[i],context)),values[f.params.length]);};
  return [f.name,entry];
})));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}

function __preparedPart(mask,path){
 for(const field of path){
  if(mask===true)return true;
  if(!mask || typeof mask!=="object")return false;
  mask=Object.hasOwn(mask.fields,field)?mask.fields[field]:false;
 }
 return mask;
}
function __preparedStable(mask,path){const part=__preparedPart(mask,path);return part===true || (!!part && part.all===true);}
function __prepareFn3(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],["input"])&&__preparedStable(fixed[2],["target"]))))return __fn3;const v4471=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],["input"])&&__preparedStable(fixed[2],["target"]);
let v4470=false,v4469;
return function(v4465,v4466,v4467){let v4468;if(v4471&&v4470){v4468=v4469;}else{
const v4472=v4467["input"];
const v4473=__fn0(v4465,v4466,v4472);
const v4474=v4467["target"];
v4468=__bits(__float(v4473) - __float(v4474));if(v4471){v4469=v4468;v4470=true;}}
const v4475=v4468;
const v4476=v4468;
return __bits(__float(v4475) * __float(v4476));};}
function __prepareFn4(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn4;const v4483=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],["samples"]);
let v4482=false,v4481;
const v4493=__preparedStable(fixed[0],[]);
let v4492=false,v4491;
return function(v4477,v4478,v4479){let v4480;if(v4483&&v4482){v4480=v4481;}else{
const v4484=v4479["samples"];
let v4485=0;
for(let v4486=0;v4486<v4484.length;v4486++){
const v4487=v4484[v4486];
const v4488=v4485;
const v4489=__fn3(v4477,v4478,v4487);
v4485=__bits(__float(v4488) + __float(v4489));
}
v4480=v4485;if(v4483){v4481=v4480;v4482=true;}}
let v4490;if(v4493&&v4492){v4490=v4491;}else{
let v4494=0;
for(let v4495=0;v4495<v4477.length;v4495++){
const v4496=v4477[v4495];
const v4497=v4494;
const v4498="Op.Identity";
let v4499;if((v4496===v4498)){
v4499=0;}else{
v4499=1065353216;}
const v4500=v4499;
v4494=__bits(__float(v4497) + __float(v4500));
}
v4490=v4494;if(v4493){v4491=v4490;v4492=true;}}
const v4501=__bits((__float(v4480))/(__float(__bits((v4479["samples"]).length))));
const v4502=v4479["instruction_cost"];
const v4503=v4490;
const v4504=__bits(__float(v4502) * __float(v4503));
return __bits(__float(v4501) + __float(v4504));};}
function __prepareFn9(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["a","bias"])&&__preparedStable(fixed[0],["a","identity"])&&__preparedStable(fixed[0],["a","relu"])&&__preparedStable(fixed[0],["a","scale"])&&__preparedStable(fixed[0],["b","bias"])&&__preparedStable(fixed[0],["b","identity"])&&__preparedStable(fixed[0],["b","relu"])&&__preparedStable(fixed[0],["b","scale"])&&__preparedStable(fixed[0],["c","bias"])&&__preparedStable(fixed[0],["c","identity"])&&__preparedStable(fixed[0],["c","relu"])&&__preparedStable(fixed[0],["c","scale"])&&__preparedStable(fixed[0],["d","bias"])&&__preparedStable(fixed[0],["d","identity"])&&__preparedStable(fixed[0],["d","relu"])&&__preparedStable(fixed[0],["d","scale"])&&__preparedStable(fixed[1],[]))))return __fn9;const v4531={all:__preparedStable(fixed[1],[]),fields:{["operation"]:true,["slot"]:fixed[1]}};
const v4534=depth<15&&__preparedFactories.has(43)&&((true));
let v4532;
let v4541;
let v4549;
let v4557;
return function(v4510,v4511){const v4513=0;
const v4512=({["slot"]:v4511,["operation"]:v4513});
const v4515=1;
const v4514=({["slot"]:v4511,["operation"]:v4515});
const v4517=2;
const v4516=({["slot"]:v4511,["operation"]:v4517});
const v4519=3;
const v4518=({["slot"]:v4511,["operation"]:v4519});
const v4520=v4512;
const v4521=__fn7(v4510,v4520);
const v4522=v4514;
const v4523=__fn7(v4510,v4522);
const v4524=v4516;
const v4525=__fn7(v4510,v4524);
const v4526=v4518;
const v4527=__fn7(v4510,v4526);
const v4528=[v4521,v4523,v4525,v4527];
const v4530=v4512;
let v4535;if(v4534){if(!v4532){const v4533=__preparedFactories.get(43);v4532=v4533([fixed[0],v4531],depth+1);}v4535=v4532(v4510,v4530);}else{v4535=__fn43(v4510,v4530);}
const v4536=v4535;
const v4538=__fn6(v4536);
const v4540=v4514;
let v4543;if(v4534){if(!v4541){const v4542=__preparedFactories.get(43);v4541=v4542([fixed[0],v4531],depth+1);}v4543=v4541(v4510,v4540);}else{v4543=__fn43(v4510,v4540);}
const v4544=v4543;
const v4546=__fn6(v4544);
const v4548=v4516;
let v4551;if(v4534){if(!v4549){const v4550=__preparedFactories.get(43);v4549=v4550([fixed[0],v4531],depth+1);}v4551=v4549(v4510,v4548);}else{v4551=__fn43(v4510,v4548);}
const v4552=v4551;
const v4554=__fn6(v4552);
const v4556=v4518;
let v4559;if(v4534){if(!v4557){const v4558=__preparedFactories.get(43);v4557=v4558([fixed[0],v4531],depth+1);}v4559=v4557(v4510,v4556);}else{v4559=__fn43(v4510,v4556);}
const v4560=v4559;
const v4562=__fn6(v4560);
const v4564=[v4538,v4546,v4554,v4562];
return ({["masses"]:v4528,["derivatives"]:v4564});};}
function __prepareFn10(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],["a","bias"])&&__preparedStable(fixed[2],["a","identity"])&&__preparedStable(fixed[2],["a","relu"])&&__preparedStable(fixed[2],["a","scale"])&&__preparedStable(fixed[2],["b","bias"])&&__preparedStable(fixed[2],["b","identity"])&&__preparedStable(fixed[2],["b","relu"])&&__preparedStable(fixed[2],["b","scale"])&&__preparedStable(fixed[2],["c","bias"])&&__preparedStable(fixed[2],["c","identity"])&&__preparedStable(fixed[2],["c","relu"])&&__preparedStable(fixed[2],["c","scale"])&&__preparedStable(fixed[2],["d","bias"])&&__preparedStable(fixed[2],["d","identity"])&&__preparedStable(fixed[2],["d","relu"])&&__preparedStable(fixed[2],["d","scale"]))))return __fn10;const v4576=__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v4575=false,v4574;
const v4579=depth<15&&__preparedFactories.has(9)&&((__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],["a","bias"])&&__preparedStable(fixed[2],["a","identity"])&&__preparedStable(fixed[2],["a","relu"])&&__preparedStable(fixed[2],["a","scale"])&&__preparedStable(fixed[2],["b","bias"])&&__preparedStable(fixed[2],["b","identity"])&&__preparedStable(fixed[2],["b","relu"])&&__preparedStable(fixed[2],["b","scale"])&&__preparedStable(fixed[2],["c","bias"])&&__preparedStable(fixed[2],["c","identity"])&&__preparedStable(fixed[2],["c","relu"])&&__preparedStable(fixed[2],["c","scale"])&&__preparedStable(fixed[2],["d","bias"])&&__preparedStable(fixed[2],["d","identity"])&&__preparedStable(fixed[2],["d","relu"])&&__preparedStable(fixed[2],["d","scale"])));
let v4577;
const v4593=__preparedStable(fixed[1],[])&&__preparedStable(fixed[3],[]);
const v4596=depth<15&&__preparedFactories.has(25)&&((__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v4594;
return function(v4566,v4567,v4568,v4569){let v4570;if(Object.hasOwn(v4566,"Ok")){
const v4571=v4566["Ok"];
const v4572=v4571;
let v4573;if(v4576&&v4575){v4573=v4574;}else{
let v4580;if(v4579){if(!v4577){const v4578=__preparedFactories.get(9);v4577=v4578([fixed[2],fixed[1]],depth+1);}v4580=v4577(v4568,v4567);}else{v4580=__fn9(v4568,v4567);}
v4573=v4580;if(v4576){v4574=v4573;v4575=true;}}
const v4581=v4573;
const v4582=v4581["masses"];
const v4583=v4573;
const v4584=v4583["derivatives"];
const v4585=true;
const v4586=true;
const v4587=true;
const v4588=true;
const v4589=[v4585,v4586,v4587,v4588];
let v4590;if(v4567<v4569.length){v4590=v4569[v4567];}else{
const v4591=1065353216;
v4590=((v4591 ^ 2147483648) >>> 0);}
const v4592=v4590;
let v4597;if(v4596){if(!v4594){const v4595=__preparedFactories.get(25);v4594=v4595([v4576,v4576,true,v4593],depth+1);}v4597=v4594(v4582,v4584,v4589,v4592);}else{v4597=__fn25(v4582,v4584,v4589,v4592);}
const v4598=v4597;
let v4599;if(Object.hasOwn(v4598,"Ok")){
const v4600=v4598["Ok"];
const v4601=v4600;
const v4602=v4572;
const v4603=v4602["choices"];
const v4604=v4601;
const v4605=v4604["action"];
const v4606=__fn8(v4605);
const v4607=[v4606];
const v4608=v4603.length;
const v4609=v4607.length;
const v4610=new Array(v4608+v4609);
for(let v4611=0;v4611<v4608;v4611++){v4610[v4611]=v4603[v4611];}
for(let v4612=0;v4612<v4609;v4612++){v4610[v4608+v4612]=v4607[v4612];}
const v4613=v4572;
const v4614=v4613["decisions"];
const v4615=v4601;
const v4616=[v4615];
const v4617=v4614.length;
const v4618=v4616.length;
const v4619=new Array(v4617+v4618);
for(let v4620=0;v4620<v4617;v4620++){v4619[v4620]=v4614[v4620];}
for(let v4621=0;v4621<v4618;v4621++){v4619[v4617+v4621]=v4616[v4621];}
v4599=({Ok:({["choices"]:v4610,["decisions"]:v4619})});}else{
const v4622=v4598["Err"];
v4599=({Err:v4622});}
v4570=v4599;}else{
const v4623=v4566["Err"];
v4570=({Err:v4623});}
return v4570;};}
function __prepareFn11(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn11;const v4637=__preparedStable(fixed[0],[]);
let v4636=false,v4635;
const v4660=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
let v4659=false,v4658;
return function(v4624,v4625){const v4626=(v4624).length;
const v4627=16;
const v4628=!(v4626===v4627);
let v4629=v4628;if(!v4629){
const v4630=(v4625).length;
const v4631=4;
v4629=!(v4630===v4631);}
const v4632=v4629;
let v4633;if(v4632){
v4633=({Err:"policy shape"});}else{
let v4634;if(v4637&&v4636){v4634=v4635;}else{
v4634=__fn5(v4624);if(v4637){v4635=v4634;v4636=true;}}
const v4639=0;
const v4640=1;
const v4641=2;
const v4642=3;
const v4638=[v4639,v4640,v4641,v4642];
const v4644=[];
const v4645=[];
const v4643=({Ok:({["choices"]:v4644,["decisions"]:v4645})});
const v4646=v4638;
let v4647=v4643;
for(let v4648=0;v4648<v4646.length;v4648++){
const v4649=(v4646[v4648]>>>0);
const v4650=v4647;
const v4651=v4634;
v4647=__fn10(v4650,v4649,v4651,v4625);
}
const v4652=v4647;
let v4653;if(Object.hasOwn(v4652,"Ok")){
const v4654=v4652["Ok"];
const v4655=v4654;
const v4656=[];
let v4657;if(v4660&&v4659){v4657=v4658;}else{
let v4661=v4656;
for(let v4662=0;v4662<8;v4662++){
const v4663=(v4662>>>0);
const v4664=v4661;
const v4665=v4655;
const v4666=v4665["choices"];
const v4667=v4664.length;
const v4668=v4666.length;
const v4669=new Array(v4667+v4668);
for(let v4670=0;v4670<v4667;v4670++){v4669[v4670]=v4664[v4670];}
for(let v4671=0;v4671<v4668;v4671++){v4669[v4667+v4671]=v4666[v4671];}
v4661=v4669;}
v4657=v4661;if(v4660){v4658=v4657;v4659=true;}}
const v4672=v4657;
const v4673=v4655;
const v4674=v4673["decisions"];
v4653=({Ok:({["code"]:v4672,["decisions"]:v4674})});}else{
const v4675=v4652["Err"];
v4653=({Err:v4675});}
v4633=v4653;}
return v4633;};}
function __prepareFn14(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],["a","bias"])&&__preparedStable(fixed[2],["a","identity"])&&__preparedStable(fixed[2],["a","relu"])&&__preparedStable(fixed[2],["a","scale"])&&__preparedStable(fixed[2],["b","bias"])&&__preparedStable(fixed[2],["b","identity"])&&__preparedStable(fixed[2],["b","relu"])&&__preparedStable(fixed[2],["b","scale"])&&__preparedStable(fixed[2],["c","bias"])&&__preparedStable(fixed[2],["c","identity"])&&__preparedStable(fixed[2],["c","relu"])&&__preparedStable(fixed[2],["c","scale"])&&__preparedStable(fixed[2],["d","bias"])&&__preparedStable(fixed[2],["d","identity"])&&__preparedStable(fixed[2],["d","relu"])&&__preparedStable(fixed[2],["d","scale"]))))return __fn14;const v4688=__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v4687=false,v4686;
const v4691=depth<15&&__preparedFactories.has(9)&&((__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],["a","bias"])&&__preparedStable(fixed[2],["a","identity"])&&__preparedStable(fixed[2],["a","relu"])&&__preparedStable(fixed[2],["a","scale"])&&__preparedStable(fixed[2],["b","bias"])&&__preparedStable(fixed[2],["b","identity"])&&__preparedStable(fixed[2],["b","relu"])&&__preparedStable(fixed[2],["b","scale"])&&__preparedStable(fixed[2],["c","bias"])&&__preparedStable(fixed[2],["c","identity"])&&__preparedStable(fixed[2],["c","relu"])&&__preparedStable(fixed[2],["c","scale"])&&__preparedStable(fixed[2],["d","bias"])&&__preparedStable(fixed[2],["d","identity"])&&__preparedStable(fixed[2],["d","relu"])&&__preparedStable(fixed[2],["d","scale"])));
let v4689;
const v4705=__preparedStable(fixed[1],[])&&__preparedStable(fixed[3],[]);
const v4708=depth<15&&__preparedFactories.has(26)&&((__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v4706;
return function(v4678,v4679,v4680,v4681){let v4682;if(Object.hasOwn(v4678,"Ok")){
const v4683=v4678["Ok"];
const v4684=v4683;
let v4685;if(v4688&&v4687){v4685=v4686;}else{
let v4692;if(v4691){if(!v4689){const v4690=__preparedFactories.get(9);v4689=v4690([fixed[2],fixed[1]],depth+1);}v4692=v4689(v4680,v4679);}else{v4692=__fn9(v4680,v4679);}
v4685=v4692;if(v4688){v4686=v4685;v4687=true;}}
const v4693=v4685;
const v4694=v4693["masses"];
const v4695=v4685;
const v4696=v4695["derivatives"];
const v4697=true;
const v4698=true;
const v4699=true;
const v4700=true;
const v4701=[v4697,v4698,v4699,v4700];
let v4702;if(v4679<v4681.length){v4702=v4681[v4679];}else{
v4702="Op.Identity";}
const v4703=v4702;
const v4704=__fn13(v4703);
let v4709;if(v4708){if(!v4706){const v4707=__preparedFactories.get(26);v4706=v4707([v4688,v4688,true,v4705],depth+1);}v4709=v4706(v4694,v4696,v4701,v4704);}else{v4709=__fn26(v4694,v4696,v4701,v4704);}
const v4710=v4709;
let v4711;if(Object.hasOwn(v4710,"Ok")){
const v4712=v4710["Ok"];
const v4713=v4712;
const v4714=v4684;
const v4715=v4713;
const v4716=[v4715];
const v4717=v4714.length;
const v4718=v4716.length;
const v4719=new Array(v4717+v4718);
for(let v4720=0;v4720<v4717;v4720++){v4719[v4720]=v4714[v4720];}
for(let v4721=0;v4721<v4718;v4721++){v4719[v4717+v4721]=v4716[v4721];}
v4711=({Ok:v4719});}else{
const v4722=v4710["Err"];
v4711=({Err:v4722});}
v4682=v4711;}else{
const v4723=v4678["Err"];
v4682=({Err:v4723});}
return v4682;};}
function __prepareFn15(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn15;const v4742=__preparedStable(fixed[0],[]);
let v4741=false,v4740;
const v4754=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
const v4759=depth<15&&__preparedFactories.has(31)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])));
let v4757;
const v4763=__preparedStable(fixed[3],[]);
const v4765=__preparedStable(fixed[4],[]);
const v4768=depth<15&&__preparedFactories.has(31)&&((__preparedStable(fixed[2],[])));
let v4766;
return function(v4724,v4725,v4726,v4727,v4728){const v4729=(v4725).length;
const v4730=32;
const v4731=(v4729===v4730);
let v4732;if(v4731){
const v4734=0;
const v4735=1;
const v4736=2;
const v4737=3;
const v4733=[v4734,v4735,v4736,v4737];
const v4738=({Ok:[]});
let v4739;if(v4742&&v4741){v4739=v4740;}else{
v4739=__fn5(v4724);if(v4742){v4740=v4739;v4741=true;}}
const v4743=v4733;
let v4744=v4738;
for(let v4745=0;v4745<v4743.length;v4745++){
const v4746=(v4743[v4745]>>>0);
const v4747=v4744;
const v4748=v4739;
v4744=__fn14(v4747,v4746,v4748,v4725);
}
const v4749=v4744;
let v4750;if(Object.hasOwn(v4749,"Ok")){
const v4751=v4749["Ok"];
const v4752=v4751;
const v4753=v4752;
const v4755=1065353216;
const v4756=0;
let v4760;if(v4759){if(!v4757){const v4758=__preparedFactories.get(31);v4757=v4758([v4754,true,true],depth+1);}v4760=v4757(v4753,v4755,v4756);}else{v4760=__fn31(v4753,v4755,v4756);}
v4750=v4760;}else{
const v4761=v4749["Err"];
v4750=({Err:v4761});}
v4732=v4750;}else{
const v4762=__fn12(v4727);
const v4764=__fn12(v4728);
let v4769;if(v4768){if(!v4766){const v4767=__preparedFactories.get(31);v4766=v4767([fixed[2],v4763,v4765],depth+1);}v4769=v4766(v4726,v4762,v4764);}else{v4769=__fn31(v4726,v4762,v4764);}
v4732=v4769;}
return v4732;};}
function __prepareFn19(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn19;const v4780=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
let v4779=false,v4778;
return function(v4773,v4774){const v4775=0;
const v4776=0;
let v4777;if(v4780&&v4779){v4777=v4778;}else{
const v4781=v4776;
const v4782=v4775;
let v4783=({["i"]:v4781,["maximum"]:v4782});
for(let v4784=0;v4784<v4773.length;v4784++){
const v4785=v4773[v4784];
const v4787=v4783;
const v4786=v4787["i"];
const v4789=v4783;
const v4788=v4789["maximum"];
const v4790=v4786;
let v4791;if(v4790<v4774.length){v4791=v4774[v4790];}else{
v4791=false;}
const v4792=v4791;
let v4793=v4792;if(v4793){
const v4794=v4788;
v4793=((__float(v4785)) > (__float(v4794)));}
const v4795=v4793;
let v4796;if(v4795){
const v4797=v4785;
const v4799=v4786;
const v4800=1;
const v4798=(((v4799) + (v4800)) >>> 0);
const v4801=v4798;
const v4802=v4797;
v4796=({["i"]:v4801,["maximum"]:v4802});}else{
const v4804=v4786;
const v4805=1;
const v4803=(((v4804) + (v4805)) >>> 0);
const v4806=v4803;
const v4807=v4788;
v4796=({["i"]:v4806,["maximum"]:v4807});}
v4783=v4796;
}
v4777=v4783;if(v4780){v4778=v4777;v4779=true;}}
const v4809=v4777;
const v4808=v4809["i"];
const v4811=v4777;
const v4810=v4811["maximum"];
return v4810;};}
function __prepareFn20(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn20;const v4817=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
let v4816=false,v4815;
let v4845=false,v4844;
const v4848=depth<15&&__preparedFactories.has(19)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])));
let v4846;
return function(v4812,v4813){let v4814;if(v4817&&v4816){v4814=v4815;}else{
const v4818=(v4812).length;
const v4819=0;
const v4820=(v4818===v4819);
let v4821=v4820;if(!v4821){
const v4822=(v4812).length;
const v4823=256;
v4821=((v4822) > (v4823));}
const v4824=v4821;
let v4825=v4824;if(!v4825){
const v4826=(v4813).length;
const v4827=(v4812).length;
v4825=!(v4826===v4827);}
const v4828=v4825;
let v4829=v4828;if(!v4829){
const v4830=__fn18(v4812);
const v4831=false;
v4829=(v4830===v4831);}
const v4832=v4829;
let v4833=v4832;if(!v4833){
let v4834=true;
for(let v4835=0;v4835<v4812.length;v4835++){
const v4836=v4812[v4835];
const v4837=v4834;
let v4838=v4837;if(v4838){
const v4839=0;
v4838=((__float(v4836)) >= (__float(v4839)));}
v4834=v4838;
}
const v4840=v4834;
const v4841=false;
v4833=(v4840===v4841);}
v4814=v4833;if(v4817){v4815=v4814;v4816=true;}}
let v4842;if(v4814){
v4842=({Err:"policy shape or mass domain"});}else{
let v4843;if(v4817&&v4845){v4843=v4844;}else{
let v4849;if(v4848){if(!v4846){const v4847=__preparedFactories.get(19);v4846=v4847([fixed[0],fixed[1]],depth+1);}v4849=v4846(v4812,v4813);}else{v4849=__fn19(v4812,v4813);}
v4843=v4849;if(v4817){v4844=v4843;v4845=true;}}
const v4850=v4843;
const v4851=0;
const v4852=((__float(v4850)) === (__float(v4851)));
let v4853;if(v4852){
v4853=({Err:"no positive allowed policy mass"});}else{
const v4854=new __InkBuffer([]);
const v4855=0;
const v4857=v4855;
const v4858=v4854;
let v4859=({["i"]:v4857,["out"]:v4858});
for(let v4860=0;v4860<v4812.length;v4860++){
const v4861=v4812[v4860];
const v4862=v4859;
const v4863=v4862["i"];
const v4864=v4859;
const v4865=v4864["out"];
let v4866;if(v4863<v4813.length){v4866=v4813[v4863];}else{
v4866=false;}
let v4867;if(v4866){
v4867=__bits((__float(v4861))/(__float(v4843)));}else{
v4867=0;}
const v4868=v4867;
const v4869=__tempEdit(v4865,"push",v4868);
const v4870=1;
const v4871=(((v4863) + (v4870)) >>> 0);
v4859=({["i"]:v4871,["out"]:v4869});
}
const v4856=v4859;
const v4873=v4856;
const v4872=v4873["i"];
const v4875=v4856;
const v4874=v4875["out"];
const v4876=v4874;
v4853=({Ok:v4876.freeze()});}
v4842=v4853;}
return v4842;};}
function __prepareFn21(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn21;const v4881=depth<15&&__preparedFactories.has(20)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])));
let v4879;
const v4890=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
let v4889=false,v4888;
return function(v4877,v4878){let v4882;if(v4881){if(!v4879){const v4880=__preparedFactories.get(20);v4879=v4880([fixed[0],fixed[1]],depth+1);}v4882=v4879(v4877,v4878);}else{v4882=__fn20(v4877,v4878);}
const v4883=v4882;
let v4884;if(Object.hasOwn(v4883,"Ok")){
const v4885=v4883["Ok"];
const v4886=v4885;
let v4887;if(v4890&&v4889){v4887=v4888;}else{
const v4891=v4886;
let v4892=0;
for(let v4893=0;v4893<v4891.length;v4893++){
const v4894=v4891[v4893];
const v4895=v4892;
v4892=__bits(__float(v4895) + __float(v4894));
}
v4887=v4892;if(v4890){v4888=v4887;v4889=true;}}
const v4896=v4886;
const v4897=v4896.length;
const v4898=new Array(v4897);
for(let v4899=0;v4899<v4897;v4899++){
const v4900=v4896[v4899];
v4898[v4899]=__bits((__float(v4900))/(__float(v4887)));
}
v4884=({Ok:v4898});}else{
const v4901=v4883["Err"];
v4884=({Err:v4901});}
return v4884;};}
function __prepareFn22(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn22;const v4913=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v4912=false,v4911;
return function(v4902,v4903,v4904){const v4905=__bits(__float(v4903) * __float(v4904));
const v4906=0;
const v4907=0;
const v4908=false;
const v4909=0;
let v4910;if(v4913&&v4912){v4910=v4911;}else{
const v4914=v4906;
const v4915=v4908;
const v4916=v4909;
const v4917=v4907;
let v4918=({["accumulated"]:v4914,["found"]:v4915,["i"]:v4916,["selected"]:v4917});
for(let v4919=0;v4919<v4902.length;v4919++){
const v4920=v4902[v4919];
const v4922=v4918;
const v4921=v4922["accumulated"];
const v4924=v4918;
const v4923=v4924["found"];
const v4926=v4918;
const v4925=v4926["i"];
const v4928=v4918;
const v4927=v4928["selected"];
const v4929=0;
const v4930=((__float(v4920)) > (__float(v4929)));
let v4931=v4930;if(v4931){
const v4932=v4923;
const v4933=false;
v4931=(v4932===v4933);}
const v4934=v4931;
let v4935;if(v4934){
const v4936=v4925;
const v4938=v4921;
const v4937=__bits(__float(v4938) + __float(v4920));
const v4939=0;
const v4940=((__float(v4920)) > (__float(v4939)));
let v4941=v4940;if(v4941){
const v4942=v4923;
const v4943=false;
v4941=(v4942===v4943);}
const v4944=v4941;
let v4945=v4944;if(v4945){
const v4946=v4905;
const v4947=v4937;
v4945=((__float(v4946)) < (__float(v4947)));}
const v4948=v4945;
let v4949;if(v4948){
const v4950=v4925;
const v4951=true;
const v4953=v4925;
const v4954=1;
const v4952=(((v4953) + (v4954)) >>> 0);
const v4955=v4937;
const v4956=v4951;
const v4957=v4952;
const v4958=v4950;
v4949=({["accumulated"]:v4955,["found"]:v4956,["i"]:v4957,["selected"]:v4958});}else{
const v4960=v4925;
const v4961=1;
const v4959=(((v4960) + (v4961)) >>> 0);
const v4962=v4937;
const v4963=v4923;
const v4964=v4959;
const v4965=v4936;
v4949=({["accumulated"]:v4962,["found"]:v4963,["i"]:v4964,["selected"]:v4965});}
v4935=v4949;}else{
const v4967=v4921;
const v4966=__bits(__float(v4967) + __float(v4920));
const v4968=0;
const v4969=((__float(v4920)) > (__float(v4968)));
let v4970=v4969;if(v4970){
const v4971=v4923;
const v4972=false;
v4970=(v4971===v4972);}
const v4973=v4970;
let v4974=v4973;if(v4974){
const v4975=v4905;
const v4976=v4966;
v4974=((__float(v4975)) < (__float(v4976)));}
const v4977=v4974;
let v4978;if(v4977){
const v4979=v4925;
const v4980=true;
const v4982=v4925;
const v4983=1;
const v4981=(((v4982) + (v4983)) >>> 0);
const v4984=v4966;
const v4985=v4980;
const v4986=v4981;
const v4987=v4979;
v4978=({["accumulated"]:v4984,["found"]:v4985,["i"]:v4986,["selected"]:v4987});}else{
const v4989=v4925;
const v4990=1;
const v4988=(((v4989) + (v4990)) >>> 0);
const v4991=v4966;
const v4992=v4923;
const v4993=v4988;
const v4994=v4927;
v4978=({["accumulated"]:v4991,["found"]:v4992,["i"]:v4993,["selected"]:v4994});}
v4935=v4978;}
v4918=v4935;
}
v4910=v4918;if(v4913){v4911=v4910;v4912=true;}}
const v4996=v4910;
const v4995=v4996["accumulated"];
const v4998=v4910;
const v4997=v4998["found"];
const v5000=v4910;
const v4999=v5000["i"];
const v5002=v4910;
const v5001=v5002["selected"];
return v5001;};}
function __prepareFn23(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn23;const v5010=__preparedStable(fixed[0],[]);
let v5009=false,v5008;
const v5021=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[]);
let v5020=false,v5019;
return function(v5003,v5004,v5005,v5006){let v5007;if(v5010&&v5009){v5007=v5008;}else{
const v5011=0;
let v5012;if(v5011<v5003.length){v5012=v5003[v5011];}else{
v5012=[];}
const v5013=v5012;
const v5014=[];for(let v5015=0;v5015<v5013.length;v5015++){
const v5016=v5013[v5015];
v5014.push(0);}
v5007=v5014;if(v5010){v5008=v5007;v5009=true;}}
const v5017=0;
let v5018;if(v5021&&v5020){v5018=v5019;}else{
const v5022=v5007;
const v5023=v5017;
let v5024=({["correction"]:v5022,["i"]:v5023});
for(let v5025=0;v5025<v5003.length;v5025++){
const v5026=v5003[v5025];
const v5028=v5024;
const v5027=v5028["correction"];
const v5030=v5024;
const v5029=v5030["i"];
const v5031=v5029;
let v5032;if(v5031<v5004.length){v5032=v5004[v5031];}else{
v5032=false;}
const v5033=v5032;
let v5034;if(v5033){
const v5036=v5027;
const v5037=Math.min(v5036.length,v5026.length);
const v5038=new Array(v5037);
for(let v5039=0;v5039<v5037;v5039++){
const v5040=v5036[v5039];
const v5041=v5026[v5039];
const v5042=__bits((__float(__bits((__float(v5041))/(__float(v5005)))))/(__float(v5006)));
v5038[v5039]=__bits(__float(v5040) + __float(v5042));
}
const v5035=v5038;
const v5044=v5029;
const v5045=1;
const v5043=(((v5044) + (v5045)) >>> 0);
const v5046=v5035;
const v5047=v5043;
v5034=({["correction"]:v5046,["i"]:v5047});}else{
const v5049=v5029;
const v5050=1;
const v5048=(((v5049) + (v5050)) >>> 0);
const v5051=v5027;
const v5052=v5048;
v5034=({["correction"]:v5051,["i"]:v5052});}
v5024=v5034;
}
v5018=v5024;if(v5021){v5019=v5018;v5020=true;}}
const v5054=v5018;
const v5053=v5054["correction"];
const v5056=v5018;
const v5055=v5056["i"];
return v5053;};}
function __prepareFn24(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[]))||(__preparedStable(fixed[1],[]))))return __fn24;const v5067=__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[]);
let v5066=false,v5065;
const v5070=depth<15&&__preparedFactories.has(19)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[])));
let v5068;
const v5075=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[]);
let v5074=false,v5073;
const v5079=depth<15&&__preparedFactories.has(23)&&((__preparedStable(fixed[1],[])));
let v5077;
return function(v5057,v5058,v5059,v5060,v5061){let v5063;if(v5061<v5057.length){v5063=v5057[v5061];}else{
v5063=0;}
const v5062=v5063;
let v5064;if(v5067&&v5066){v5064=v5065;}else{
let v5071;if(v5070){if(!v5068){const v5069=__preparedFactories.get(19);v5068=v5069([fixed[0],fixed[2]],depth+1);}v5071=v5068(v5057,v5059);}else{v5071=__fn19(v5057,v5059);}
v5064=v5071;if(v5067){v5065=v5064;v5066=true;}}
let v5072;if(v5075&&v5074){v5072=v5073;}else{
const v5076=v5064;
let v5080;if(v5079){if(!v5077){const v5078=__preparedFactories.get(23);v5077=v5078([fixed[1],fixed[2],v5067,fixed[3]],depth+1);}v5080=v5077(v5058,v5059,v5076,v5060);}else{v5080=__fn23(v5058,v5059,v5076,v5060);}
v5072=v5080;if(v5075){v5073=v5072;v5074=true;}}
let v5081;if(v5061<v5058.length){v5081=v5058[v5061];}else{
v5081=[];}
const v5082=v5081;
const v5083=v5072;
const v5084=Math.min(v5082.length,v5083.length);
const v5085=new Array(v5084);
for(let v5086=0;v5086<v5084;v5086++){
const v5087=v5082[v5086];
const v5088=v5083[v5086];
const v5089=__bits((__float(v5087))/(__float(v5062)));
v5085[v5086]=__bits(__float(v5089) - __float(v5088));
}
return v5085;};}
function __prepareFn25(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[1],[]))||(__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[]))))return __fn25;const v5096=depth<15&&__preparedFactories.has(20)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[])));
let v5094;
const v5108=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[3],[]);
let v5107=false,v5106;
const v5140=__preparedStable(fixed[1],[]);
let v5139=false,v5138;
const v5156=__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[]);
let v5155=false,v5154;
const v5165=__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[]);
let v5164=false,v5163;
const v5170=depth<15&&__preparedFactories.has(22)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[])));
let v5168;
const v5175=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[]);
let v5174=false,v5173;
const v5180=depth<15&&__preparedFactories.has(24)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[]))||(__preparedStable(fixed[1],[])));
let v5178;
let v5188=false,v5187;
return function(v5090,v5091,v5092,v5093){let v5097;if(v5096){if(!v5094){const v5095=__preparedFactories.get(20);v5094=v5095([fixed[0],fixed[2]],depth+1);}v5097=v5094(v5090,v5092);}else{v5097=__fn20(v5090,v5092);}
const v5098=v5097;
let v5099;if(Object.hasOwn(v5098,"Ok")){
const v5100=v5098["Ok"];
const v5101=v5100;
const v5103=0;
let v5104;if(v5103<v5091.length){v5104=v5091[v5103];}else{
v5104=[];}
const v5102=(v5104).length;
let v5105;if(v5108&&v5107){v5105=v5106;}else{
const v5109=Number.isFinite(__float(v5093));
const v5110=false;
const v5111=(v5109===v5110);
let v5112=v5111;if(!v5112){
const v5113=0;
v5112=((__float(v5093)) < (__float(v5113)));}
const v5114=v5112;
let v5115=v5114;if(!v5115){
const v5116=1065353216;
v5115=((__float(v5093)) >= (__float(v5116)));}
const v5117=v5115;
let v5118=v5117;if(!v5118){
const v5119=(v5091).length;
const v5120=(v5090).length;
v5118=!(v5119===v5120);}
const v5121=v5118;
let v5122=v5121;if(!v5122){
const v5123=v5102;
const v5124=0;
v5122=(v5123===v5124);}
const v5125=v5122;
let v5126=v5125;if(!v5126){
const v5127=v5102;
const v5128=4096;
v5126=((v5127) > (v5128));}
const v5129=v5126;
let v5130=v5129;if(!v5130){
const v5131=(v5090).length;
const v5132=65536;
const v5133=v5102;
let v5134;if(v5133===0 ){
v5134=0;}else{
v5134=(Math.trunc(v5132/v5133)+0);}
const v5135=v5134;
v5130=((v5131) > (v5135));}
v5105=v5130;if(v5108){v5106=v5105;v5107=true;}}
let v5136;if(v5105){
v5136=({Err:"policy sampling or derivative shape"});}else{
let v5137;if(v5140&&v5139){v5137=v5138;}else{
let v5141=true;
for(let v5142=0;v5142<v5091.length;v5142++){
const v5143=v5091[v5142];
const v5144=v5141;
let v5145=v5144;if(v5145){
const v5146=(v5143).length;
const v5147=v5102;
v5145=(v5146===v5147);}
const v5148=v5145;
let v5149=v5148;if(v5149){
v5149=__fn18(v5143);}
v5141=v5149;
}
const v5150=v5141;
const v5151=false;
v5137=(v5150===v5151);if(v5140){v5138=v5137;v5139=true;}}
let v5152;if(v5137){
v5152=({Err:"policy derivative domain"});}else{
let v5153;if(v5156&&v5155){v5153=v5154;}else{
const v5157=v5101;
let v5158=0;
for(let v5159=0;v5159<v5157.length;v5159++){
const v5160=v5157[v5159];
const v5161=v5158;
v5158=__bits(__float(v5161) + __float(v5160));
}
v5153=v5158;if(v5156){v5154=v5153;v5155=true;}}
let v5162;if(v5165&&v5164){v5162=v5163;}else{
const v5166=v5101;
const v5167=v5153;
let v5171;if(v5170){if(!v5168){const v5169=__preparedFactories.get(22);v5168=v5169([v5156,fixed[3],v5156],depth+1);}v5171=v5168(v5166,v5093,v5167);}else{v5171=__fn22(v5166,v5093,v5167);}
v5162=v5171;if(v5165){v5163=v5162;v5164=true;}}
let v5172;if(v5175&&v5174){v5172=v5173;}else{
const v5176=v5153;
const v5177=v5162;
let v5181;if(v5180){if(!v5178){const v5179=__preparedFactories.get(24);v5178=v5179([fixed[0],fixed[1],fixed[2],v5156,v5165],depth+1);}v5181=v5178(v5090,v5091,v5092,v5176,v5177);}else{v5181=__fn24(v5090,v5091,v5092,v5176,v5177);}
v5172=v5181;if(v5175){v5173=v5172;v5174=true;}}
const v5183=v5101;
const v5184=v5162;
let v5185;if(v5184<v5183.length){v5185=v5183[v5184];}else{
v5185=0;}
const v5182=__bits((__float(v5185))/(__float(v5153)));
let v5186;if(v5175&&v5188){v5186=v5187;}else{
const v5189=v5172;
const v5190=__fn18(v5189);
const v5191=false;
const v5192=(v5190===v5191);
let v5193=v5192;if(!v5193){
const v5194=v5182;
const v5195=0;
v5193=((__float(v5194)) <= (__float(v5195)));}
v5186=v5193;if(v5175){v5187=v5186;v5188=true;}}
let v5196;if(v5186){
v5196=({Err:"nonfinite policy score or probability underflow"});}else{
const v5197=v5162;
const v5198=v5182;
const v5199=v5172;
v5196=({Ok:({["action"]:v5197,["probability"]:v5198,["score"]:v5199})});}
v5152=v5196;}
v5136=v5152;}
v5099=v5136;}else{
const v5200=v5098["Err"];
v5099=({Err:v5200});}
return v5099;};}
function __prepareFn26(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[1],[]))||(__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[]))))return __fn26;const v5207=depth<15&&__preparedFactories.has(20)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[])));
let v5205;
const v5219=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[]);
let v5218=false,v5217;
const v5255=__preparedStable(fixed[1],[]);
let v5254=false,v5253;
const v5271=__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[]);
let v5270=false,v5269;
let v5279=false,v5278;
const v5283=depth<15&&__preparedFactories.has(24)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[]))||(__preparedStable(fixed[1],[])));
let v5281;
let v5290=false,v5289;
return function(v5201,v5202,v5203,v5204){let v5208;if(v5207){if(!v5205){const v5206=__preparedFactories.get(20);v5205=v5206([fixed[0],fixed[2]],depth+1);}v5208=v5205(v5201,v5203);}else{v5208=__fn20(v5201,v5203);}
const v5209=v5208;
let v5210;if(Object.hasOwn(v5209,"Ok")){
const v5211=v5209["Ok"];
const v5212=v5211;
const v5214=0;
let v5215;if(v5214<v5202.length){v5215=v5202[v5214];}else{
v5215=[];}
const v5213=(v5215).length;
let v5216;if(v5219&&v5218){v5216=v5217;}else{
const v5220=(v5202).length;
const v5221=(v5201).length;
const v5222=!(v5220===v5221);
let v5223=v5222;if(!v5223){
const v5224=v5213;
const v5225=0;
v5223=(v5224===v5225);}
const v5226=v5223;
let v5227=v5226;if(!v5227){
const v5228=v5213;
const v5229=4096;
v5227=((v5228) > (v5229));}
const v5230=v5227;
let v5231=v5230;if(!v5231){
const v5232=(v5201).length;
const v5233=65536;
const v5234=v5213;
let v5235;if(v5234===0 ){
v5235=0;}else{
v5235=(Math.trunc(v5233/v5234)+0);}
const v5236=v5235;
v5231=((v5232) > (v5236));}
const v5237=v5231;
let v5238=v5237;if(!v5238){
const v5239=(v5201).length;
v5238=((v5204) >= (v5239));}
const v5240=v5238;
let v5241=v5240;if(!v5241){
let v5242;if(v5204<v5203.length){v5242=v5203[v5204];}else{
v5242=false;}
const v5243=v5242;
const v5244=false;
v5241=(v5243===v5244);}
const v5245=v5241;
let v5246=v5245;if(!v5246){
const v5247=v5212;
let v5248;if(v5204<v5247.length){v5248=v5247[v5204];}else{
v5248=0;}
const v5249=v5248;
const v5250=0;
v5246=((__float(v5249)) <= (__float(v5250)));}
v5216=v5246;if(v5219){v5217=v5216;v5218=true;}}
let v5251;if(v5216){
v5251=({Err:"policy selected action or derivative shape"});}else{
let v5252;if(v5255&&v5254){v5252=v5253;}else{
let v5256=true;
for(let v5257=0;v5257<v5202.length;v5257++){
const v5258=v5202[v5257];
const v5259=v5256;
let v5260=v5259;if(v5260){
const v5261=(v5258).length;
const v5262=v5213;
v5260=(v5261===v5262);}
const v5263=v5260;
let v5264=v5263;if(v5264){
v5264=__fn18(v5258);}
v5256=v5264;
}
const v5265=v5256;
const v5266=false;
v5252=(v5265===v5266);if(v5255){v5253=v5252;v5254=true;}}
let v5267;if(v5252){
v5267=({Err:"policy derivative domain"});}else{
let v5268;if(v5271&&v5270){v5268=v5269;}else{
const v5272=v5212;
let v5273=0;
for(let v5274=0;v5274<v5272.length;v5274++){
const v5275=v5272[v5274];
const v5276=v5273;
v5273=__bits(__float(v5276) + __float(v5275));
}
v5268=v5273;if(v5271){v5269=v5268;v5270=true;}}
let v5277;if(v5219&&v5279){v5277=v5278;}else{
const v5280=v5268;
let v5284;if(v5283){if(!v5281){const v5282=__preparedFactories.get(24);v5281=v5282([fixed[0],fixed[1],fixed[2],v5271,fixed[3]],depth+1);}v5284=v5281(v5201,v5202,v5203,v5280,v5204);}else{v5284=__fn24(v5201,v5202,v5203,v5280,v5204);}
v5277=v5284;if(v5219){v5278=v5277;v5279=true;}}
const v5286=v5212;
let v5287;if(v5204<v5286.length){v5287=v5286[v5204];}else{
v5287=0;}
const v5285=__bits((__float(v5287))/(__float(v5268)));
let v5288;if(v5219&&v5290){v5288=v5289;}else{
const v5291=v5277;
const v5292=__fn18(v5291);
const v5293=false;
const v5294=(v5292===v5293);
let v5295=v5294;if(!v5295){
const v5296=v5285;
const v5297=0;
v5295=((__float(v5296)) <= (__float(v5297)));}
v5288=v5295;if(v5219){v5289=v5288;v5290=true;}}
let v5298;if(v5288){
v5298=({Err:"nonfinite policy score or probability underflow"});}else{
const v5299=v5285;
const v5300=v5277;
v5298=({Ok:({["action"]:v5204,["probability"]:v5299,["score"]:v5300})});}
v5267=v5298;}
v5251=v5267;}
v5210=v5251;}else{
const v5301=v5209["Err"];
v5210=({Err:v5301});}
return v5210;};}
function __prepareFn27(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["score"])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn27;const v5308=__preparedStable(fixed[0],["probability"])&&__preparedStable(fixed[0],["score"])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v5307=false,v5306;
const v5345=__preparedStable(fixed[0],["score"])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v5344=false,v5343;
let v5354=false,v5353;
return function(v5302,v5303,v5304){let v5305;if(v5308&&v5307){v5305=v5306;}else{
const v5309=Number.isFinite(__float(v5303));
const v5310=false;
const v5311=(v5309===v5310);
let v5312=v5311;if(!v5312){
const v5313=Number.isFinite(__float(v5304));
const v5314=false;
v5312=(v5313===v5314);}
const v5315=v5312;
let v5316=v5315;if(!v5316){
const v5317=Number.isFinite(__float(v5302["probability"]));
const v5318=false;
v5316=(v5317===v5318);}
const v5319=v5316;
let v5320=v5319;if(!v5320){
const v5321=v5302["probability"];
const v5322=0;
v5320=((__float(v5321)) <= (__float(v5322)));}
const v5323=v5320;
let v5324=v5323;if(!v5324){
const v5325=v5302["probability"];
const v5326=1065353216;
v5324=((__float(v5325)) > (__float(v5326)));}
const v5327=v5324;
let v5328=v5327;if(!v5328){
const v5329=(v5302["score"]).length;
const v5330=0;
v5328=(v5329===v5330);}
const v5331=v5328;
let v5332=v5331;if(!v5332){
const v5333=(v5302["score"]).length;
const v5334=4096;
v5332=((v5333) > (v5334));}
const v5335=v5332;
let v5336=v5335;if(!v5336){
const v5337=v5302["score"];
const v5338=__fn18(v5337);
const v5339=false;
v5336=(v5338===v5339);}
v5305=v5336;if(v5308){v5306=v5305;v5307=true;}}
let v5340;if(v5305){
v5340=({Err:"policy feedback domain"});}else{
const v5341=__bits(__float(v5303) - __float(v5304));
let v5342;if(v5345&&v5344){v5342=v5343;}else{
const v5346=v5302["score"];
const v5347=[];for(let v5348=0;v5348<v5346.length;v5348++){
const v5349=v5346[v5348];
const v5350=v5341;
const v5351=((v5350 ^ 2147483648) >>> 0);
v5347.push(__bits(__float(v5351) * __float(v5349)));}
v5342=v5347;if(v5345){v5343=v5342;v5344=true;}}
let v5352;if(v5345&&v5354){v5352=v5353;}else{
const v5355=Number.isFinite(__float(v5341));
const v5356=false;
const v5357=(v5355===v5356);
let v5358=v5357;if(!v5358){
const v5359=v5342;
const v5360=__fn18(v5359);
const v5361=false;
v5358=(v5360===v5361);}
v5352=v5358;if(v5345){v5353=v5352;v5354=true;}}
let v5362;if(v5352){
v5362=({Err:"nonfinite policy gradient"});}else{
v5362=({Ok:v5342});}
v5340=v5362;}
return v5340;};}
function __prepareFn28(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[1],["score"])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[]))))return __fn28;const v5372=depth<15&&__preparedFactories.has(27)&&((__preparedStable(fixed[1],["score"])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[])));
let v5370;
const v5385=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[]);
let v5384=false,v5383;
let v5395=false,v5394;
return function(v5363,v5364,v5365,v5366){let v5367;if(Object.hasOwn(v5363,"Ok")){
const v5368=v5363["Ok"];
const v5369=v5368;
let v5373;if(v5372){if(!v5370){const v5371=__preparedFactories.get(27);v5370=v5371([fixed[1],fixed[2],fixed[3]],depth+1);}v5373=v5370(v5364,v5365,v5366);}else{v5373=__fn27(v5364,v5365,v5366);}
const v5374=v5373;
let v5375;if(Object.hasOwn(v5374,"Ok")){
const v5376=v5374["Ok"];
const v5377=v5376;
const v5378=(v5369).length;
const v5379=(v5377).length;
const v5380=!(v5378===v5379);
let v5381;if(v5380){
v5381=({Err:"trajectory parameter shape"});}else{
let v5382;if(v5385&&v5384){v5382=v5383;}else{
const v5386=v5369;
const v5387=v5377;
const v5388=Math.min(v5386.length,v5387.length);
const v5389=new Array(v5388);
for(let v5390=0;v5390<v5388;v5390++){
const v5391=v5386[v5390];
const v5392=v5387[v5390];
v5389[v5390]=__bits(__float(v5391) + __float(v5392));
}
v5382=v5389;if(v5385){v5383=v5382;v5384=true;}}
let v5393;if(v5385&&v5395){v5393=v5394;}else{
const v5396=v5382;
const v5397=__fn18(v5396);
const v5398=false;
v5393=(v5397===v5398);if(v5385){v5394=v5393;v5395=true;}}
let v5399;if(v5393){
v5399=({Err:"nonfinite trajectory gradient"});}else{
v5399=({Ok:v5382});}
v5381=v5399;}
v5375=v5381;}else{
const v5400=v5374["Err"];
v5375=({Err:v5400});}
v5367=v5375;}else{
const v5401=v5363["Err"];
v5367=({Err:v5401});}
return v5367;};}
function __prepareFn29(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn29;const v5416=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v5415=false,v5414;
const v5450=__preparedStable(fixed[0],[]);
let v5449=false,v5448;
let v5460=false,v5459;
return function(v5402,v5403,v5404){const v5406=0;
let v5407;if(v5406<v5402.length){v5407=v5402[v5406];}else{
const v5408=0;
const v5409=0;
const v5410=[];
v5407=({["action"]:v5408,["probability"]:v5409,["score"]:v5410});}
const v5405=v5407;
const v5412=v5405;
const v5411=(v5412["score"]).length;
let v5413;if(v5416&&v5415){v5413=v5414;}else{
const v5417=(v5402).length;
const v5418=0;
const v5419=(v5417===v5418);
let v5420=v5419;if(!v5420){
const v5421=(v5402).length;
const v5422=4096;
v5420=((v5421) > (v5422));}
const v5423=v5420;
let v5424=v5423;if(!v5424){
const v5425=(v5403).length;
const v5426=(v5402).length;
v5424=!(v5425===v5426);}
const v5427=v5424;
let v5428=v5427;if(!v5428){
const v5429=(v5404).length;
const v5430=(v5402).length;
v5428=!(v5429===v5430);}
const v5431=v5428;
let v5432=v5431;if(!v5432){
const v5433=v5411;
const v5434=0;
v5432=(v5433===v5434);}
const v5435=v5432;
let v5436=v5435;if(!v5436){
const v5437=v5411;
const v5438=4096;
v5436=((v5437) > (v5438));}
const v5439=v5436;
let v5440=v5439;if(!v5440){
const v5441=(v5402).length;
const v5442=65536;
const v5443=v5411;
let v5444;if(v5443===0 ){
v5444=0;}else{
v5444=(Math.trunc(v5442/v5443)+0);}
const v5445=v5444;
v5440=((v5441) > (v5445));}
v5413=v5440;if(v5416){v5414=v5413;v5415=true;}}
let v5446;if(v5413){
v5446=({Err:"trajectory shape"});}else{
let v5447;if(v5450&&v5449){v5447=v5448;}else{
const v5451=v5405;
const v5452=v5451["score"];
const v5453=v5452.length;
const v5454=new Array(v5453);
for(let v5455=0;v5455<v5453;v5455++){
const v5456=v5452[v5455];
v5454[v5455]=0;
}
v5447=({Ok:v5454});if(v5450){v5448=v5447;v5449=true;}}
const v5457=0;
let v5458;if(v5416&&v5460){v5458=v5459;}else{
const v5461=v5447;
const v5462=v5457;
let v5463=({["accumulator"]:v5461,["i"]:v5462});
for(let v5464=0;v5464<v5402.length;v5464++){
const v5465=v5402[v5464];
const v5467=v5463;
const v5466=v5467["accumulator"];
const v5469=v5463;
const v5468=v5469["i"];
const v5471=v5466;
const v5472=v5468;
let v5473;if(v5472<v5403.length){v5473=v5403[v5472];}else{
v5473=0;}
const v5474=v5473;
const v5475=v5468;
let v5476;if(v5475<v5404.length){v5476=v5404[v5475];}else{
v5476=0;}
const v5477=v5476;
const v5470=__fn28(v5471,v5465,v5474,v5477);
const v5479=v5468;
const v5480=1;
const v5478=(((v5479) + (v5480)) >>> 0);
const v5481=v5470;
const v5482=v5478;
v5463=({["accumulator"]:v5481,["i"]:v5482});
}
v5458=v5463;if(v5416){v5459=v5458;v5460=true;}}
const v5484=v5458;
const v5483=v5484["accumulator"];
const v5486=v5458;
const v5485=v5486["i"];
v5446=v5483;}
return v5446;};}
function __prepareFn30(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn30;const v5492=depth<15&&__preparedFactories.has(29)&&((__preparedStable(fixed[0],[])));
let v5490;
return function(v5487,v5488,v5489){let v5493;if(v5492){if(!v5490){const v5491=__preparedFactories.get(29);v5490=v5491([fixed[0],fixed[1],fixed[2]],depth+1);}v5493=v5490(v5487,v5488,v5489);}else{v5493=__fn29(v5487,v5488,v5489);}
const v5494=v5493;
let v5495;if(Object.hasOwn(v5494,"Ok")){
const v5496=v5494["Ok"];
const v5497=v5496;
const v5498=v5497;
const v5499=v5498.length;
const v5500=new Array(v5499);
for(let v5501=0;v5501<v5499;v5501++){
const v5502=v5498[v5501];
v5500[v5501]=__bits((__float(v5502))/(__float(__bits((v5487).length))));
}
v5495=({Ok:v5500});}else{
const v5503=v5494["Err"];
v5495=({Err:v5503});}
return v5495;};}
function __prepareFn31(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn31;const v5511=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
const v5516=__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[]);
const v5519=depth<15&&__preparedFactories.has(29)&&((__preparedStable(fixed[0],[])));
let v5517;
return function(v5504,v5505,v5506){const v5507=[];for(let v5508=0;v5508<v5504.length;v5508++){
const v5509=v5504[v5508];
v5507.push(v5505);}
const v5510=v5507;
const v5512=[];for(let v5513=0;v5513<v5504.length;v5513++){
const v5514=v5504[v5513];
v5512.push(v5506);}
const v5515=v5512;
let v5520;if(v5519){if(!v5517){const v5518=__preparedFactories.get(29);v5517=v5518([fixed[0],v5511,v5516],depth+1);}v5520=v5517(v5504,v5510,v5515);}else{v5520=__fn29(v5504,v5510,v5515);}
return v5520;};}
function __prepareFn32(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn32;const v5527=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v5526=false,v5525;
let v5586=false,v5585;
return function(v5521,v5522,v5523){let v5524;if(v5527&&v5526){v5524=v5525;}else{
const v5528=(v5521).length;
const v5529=4096;
const v5530=((v5528) > (v5529));
let v5531=v5530;if(!v5531){
const v5532=__fn18(v5521);
const v5533=false;
v5531=(v5532===v5533);}
const v5534=v5531;
let v5535=v5534;if(!v5535){
const v5536=Number.isFinite(__float(v5522));
const v5537=false;
v5535=(v5536===v5537);}
const v5538=v5535;
let v5539=v5538;if(!v5539){
const v5540=0;
v5539=((__float(v5522)) < (__float(v5540)));}
const v5541=v5539;
let v5542=v5541;if(!v5542){
const v5543=1065353216;
v5542=((__float(v5522)) > (__float(v5543)));}
const v5544=v5542;
let v5545=v5544;if(!v5545){
const v5546=Number.isFinite(__float(v5523));
const v5547=false;
v5545=(v5546===v5547);}
v5524=v5545;if(v5527){v5525=v5524;v5526=true;}}
let v5548;if(v5524){
v5548=({Err:"return domain"});}else{
const v5549=new __InkBuffer([]);
const v5550=v5523;
const v5551=0;
const v5553=v5551;
const v5554=v5550;
const v5555=v5549;
let v5556=({["i"]:v5553,["next"]:v5554,["reversed"]:v5555});
for(let v5557=0;v5557<v5521.length;v5557++){
const v5558=v5521[v5557];
const v5559=v5556;
const v5560=v5559["i"];
const v5561=v5556;
const v5562=v5561["next"];
const v5563=v5556;
const v5564=v5563["reversed"];
const v5565=(v5521).length;
const v5566=1;
const v5567=(((v5565) - (v5566)) >>> 0);
const v5568=(((v5567) - (v5560)) >>> 0);
let v5569;if(v5568<v5521.length){v5569=v5521[v5568];}else{
v5569=0;}
const v5570=v5569;
const v5571=__bits(__float(v5522) * __float(v5562));
const v5572=__bits(__float(v5570) + __float(v5571));
const v5573=__tempEdit(v5564,"push",v5572);
const v5574=1;
const v5575=(((v5560) + (v5574)) >>> 0);
v5556=({["i"]:v5575,["next"]:v5572,["reversed"]:v5573});
}
const v5552=v5556;
const v5577=v5552;
const v5576=v5577["i"];
const v5579=v5552;
const v5578=v5579["next"];
const v5581=v5552;
const v5580=v5581["reversed"];
const v5583=v5580;
const v5582=v5583.freeze();
let v5584;if(v5527&&v5586){v5584=v5585;}else{
const v5587=v5582;
const v5588=__fn18(v5587);
const v5589=false;
v5584=(v5588===v5589);if(v5527){v5585=v5584;v5586=true;}}
let v5590;if(v5584){
v5590=({Err:"nonfinite return"});}else{
const v5591=new __InkBuffer([]);
const v5592=0;
const v5594=v5582;
const v5595=v5592;
const v5596=v5591;
let v5597=({["i"]:v5595,["out"]:v5596});
for(let v5598=0;v5598<v5594.length;v5598++){
const v5599=v5594[v5598];
const v5600=v5597;
const v5601=v5600["i"];
const v5602=v5597;
const v5603=v5602["out"];
const v5604=v5582;
const v5605=(v5582).length;
const v5606=1;
const v5607=(((v5605) - (v5606)) >>> 0);
const v5608=(((v5607) - (v5601)) >>> 0);
let v5609;if(v5608<v5604.length){v5609=v5604[v5608];}else{
v5609=0;}
const v5610=v5609;
const v5611=__tempEdit(v5603,"push",v5610);
const v5612=1;
const v5613=(((v5601) + (v5612)) >>> 0);
v5597=({["i"]:v5613,["out"]:v5611});
}
const v5593=v5597;
const v5615=v5593;
const v5614=v5615["i"];
const v5617=v5593;
const v5616=v5617["out"];
const v5618=v5616;
v5590=({Ok:v5618.freeze()});}
v5548=v5590;}
return v5548;};}
function __prepareFn36(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn36;const v5626=__preparedStable(fixed[0],[]);
let v5625=false,v5624;
let v5632=false,v5631;
return function(v5622){let v5623;if(v5626&&v5625){v5623=v5624;}else{
const v5627=__fn34(v5622);
const v5628=false;
v5623=(v5627===v5628);if(v5626){v5624=v5623;v5625=true;}}
let v5629;if(v5623){
v5629=({Err:"nonfinite weights"});}else{
let v5630;if(v5626&&v5632){v5630=v5631;}else{
const v5633=[];for(let v5634=0;v5634<v5622.length;v5634++){
const v5635=v5622[v5634];
v5633.push(0);}
v5630=v5633;if(v5626){v5631=v5630;v5632=true;}}
const v5636=v5630;
const v5637=v5630;
const v5638=0;
const v5639=1065353216;
const v5640=1065353216;
v5629=({Ok:({["weights"]:v5622,["first"]:v5636,["second"]:v5637,["steps"]:v5638,["first_power"]:v5639,["second_power"]:v5640})});}
return v5629;};}
function __prepareFn39(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn39;const v5651=__preparedStable(fixed[0],[]);
let v5650=false,v5649;
let v5665=false,v5664;
return function(v5643,v5644){const v5645=0;
const v5646=((__float(v5644)) === (__float(v5645)));
let v5647;if(v5646){
v5647=1065353216;}else{
let v5648;if(v5651&&v5650){v5648=v5649;}else{
let v5652=0;
for(let v5653=0;v5653<v5643.length;v5653++){
const v5654=v5643[v5653];
const v5655=__fn38(v5654);
const v5656=v5652;
const v5657=((__float(v5655)) > (__float(v5656)));
let v5658;if(v5657){
v5658=__fn38(v5654);}else{
v5658=v5652;}
v5652=v5658;
}
v5648=v5652;if(v5651){v5649=v5648;v5650=true;}}
const v5659=v5648;
const v5660=0;
const v5661=((__float(v5659)) === (__float(v5660)));
let v5662;if(v5661){
v5662=1065353216;}else{
let v5663;if(v5651&&v5665){v5663=v5664;}else{
let v5666=0;
for(let v5667=0;v5667<v5643.length;v5667++){
const v5668=v5643[v5667];
const v5669=v5666;
const v5670=__bits((__float(v5668))/(__float(v5648)));
const v5671=__bits((__float(v5668))/(__float(v5648)));
const v5672=__bits(__float(v5670) * __float(v5671));
v5666=__bits(__float(v5669) + __float(v5672));
}
v5663=v5666;if(v5651){v5664=v5663;v5665=true;}}
const v5673=__bits((__float(__bits((__float(v5644))/(__float(v5648)))))/(__float(__bits(Math.sqrt(__float(v5663))))));
const v5674=v5673;
const v5675=1065353216;
const v5676=((__float(v5674)) < (__float(v5675)));
let v5677;if(v5676){
v5677=v5673;}else{
v5677=1065353216;}
v5662=v5677;}
v5647=v5662;}
return v5647;};}
function __prepareFn41(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn41;const v5690=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v5689=false,v5688;
let v5739=false,v5738;
let v5746=false,v5745;
const v5749=__preparedPart(fixed[2],["norm_limit"]);
const v5752=depth<15&&__preparedFactories.has(39)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v5750;
let v5825=false,v5824;
let v5839=false,v5838;
return function(v5684,v5685,v5686){let v5687;if(v5690&&v5689){v5687=v5688;}else{
const v5691=__fn35(v5684);
const v5692=false;
const v5693=(v5691===v5692);
let v5694=v5693;if(!v5694){
const v5695=__fn37(v5686);
const v5696=false;
v5694=(v5695===v5696);}
const v5697=v5694;
let v5698=v5697;if(!v5698){
const v5699=(v5685).length;
const v5700=(v5684["weights"]).length;
v5698=!(v5699===v5700);}
const v5701=v5698;
let v5702=v5701;if(!v5702){
const v5703=__fn34(v5685);
const v5704=false;
v5702=(v5703===v5704);}
const v5705=v5702;
let v5706=v5705;if(!v5706){
const v5707=v5684["steps"];
const v5708=4294967295;
v5706=(v5707===v5708);}
v5687=v5706;if(v5690){v5688=v5687;v5689=true;}}
let v5709;if(v5687){
v5709=({Err:"optimizer domain"});}else{
const v5710=new __InkBuffer([]);
const v5711=0;
const v5713=v5710;
const v5714=v5711;
let v5715=({["adjusted"]:v5713,["i"]:v5714});
for(let v5716=0;v5716<v5685.length;v5716++){
const v5717=v5685[v5716];
const v5718=v5715;
const v5719=v5718["adjusted"];
const v5720=v5715;
const v5721=v5720["i"];
const v5722=v5686["weight_decay"];
const v5723=v5684["weights"];
let v5724;if(v5721<v5723.length){v5724=v5723[v5721];}else{
v5724=0;}
const v5725=v5724;
const v5726=__bits(__float(v5722) * __float(v5725));
const v5727=__bits(__float(v5717) + __float(v5726));
const v5728=__tempEdit(v5719,"push",v5727);
const v5729=1;
const v5730=(((v5721) + (v5729)) >>> 0);
v5715=({["adjusted"]:v5728,["i"]:v5730});
}
const v5712=v5715;
const v5732=v5712;
const v5731=v5732["adjusted"];
const v5734=v5712;
const v5733=v5734["i"];
const v5736=v5731;
const v5735=v5736.freeze();
let v5737;if(v5690&&v5739){v5737=v5738;}else{
const v5740=v5735;
const v5741=__fn34(v5740);
const v5742=false;
v5737=(v5741===v5742);if(v5690){v5738=v5737;v5739=true;}}
let v5743;if(v5737){
v5743=({Err:"nonfinite gradient"});}else{
let v5744;if(v5690&&v5746){v5744=v5745;}else{
const v5747=v5735;
const v5748=v5686["norm_limit"];
let v5753;if(v5752){if(!v5750){const v5751=__preparedFactories.get(39);v5750=v5751([v5690,v5749],depth+1);}v5753=v5750(v5747,v5748);}else{v5753=__fn39(v5747,v5748);}
v5744=v5753;if(v5690){v5745=v5744;v5746=true;}}
const v5755=v5684["first_power"];
const v5756=v5686["first_decay"];
const v5754=__bits(__float(v5755) * __float(v5756));
const v5758=v5684["second_power"];
const v5759=v5686["second_decay"];
const v5757=__bits(__float(v5758) * __float(v5759));
const v5760=new __InkBuffer([]);
const v5761=new __InkBuffer([]);
const v5762=new __InkBuffer([]);
const v5763=0;
const v5765=v5735;
const v5766=v5761;
const v5767=v5763;
const v5768=v5762;
const v5769=v5760;
let v5770=({["first"]:v5766,["i"]:v5767,["second"]:v5768,["weights"]:v5769});
for(let v5771=0;v5771<v5765.length;v5771++){
const v5772=v5765[v5771];
const v5773=v5770;
const v5774=v5773["first"];
const v5775=v5770;
const v5776=v5775["i"];
const v5777=v5770;
const v5778=v5777["second"];
const v5779=v5770;
const v5780=v5779["weights"];
const v5781=v5744;
const v5782=__bits(__float(v5772) * __float(v5781));
const v5783=v5686["first_decay"];
const v5784=v5684["first"];
let v5785;if(v5776<v5784.length){v5785=v5784[v5776];}else{
v5785=0;}
const v5786=v5785;
const v5787=__bits(__float(v5783) * __float(v5786));
const v5788=1065353216;
const v5789=v5686["first_decay"];
const v5790=__bits(__float(v5788) - __float(v5789));
const v5791=__bits(__float(v5790) * __float(v5782));
const v5792=__bits(__float(v5787) + __float(v5791));
const v5793=v5686["second_decay"];
const v5794=v5684["second"];
let v5795;if(v5776<v5794.length){v5795=v5794[v5776];}else{
v5795=0;}
const v5796=v5795;
const v5797=__bits(__float(v5793) * __float(v5796));
const v5798=1065353216;
const v5799=v5686["second_decay"];
const v5800=__bits(__float(v5798) - __float(v5799));
const v5801=__bits(__float(v5800) * __float(v5782));
const v5802=__bits(__float(v5801) * __float(v5782));
const v5803=__bits(__float(v5797) + __float(v5802));
const v5804=v5684["weights"];
let v5805;if(v5776<v5804.length){v5805=v5804[v5776];}else{
v5805=0;}
const v5806=v5805;
const v5807=v5754;
const v5808=v5757;
const v5809=__fn40(v5806,v5792,v5803,v5807,v5808,v5686);
const v5810=__tempEdit(v5780,"push",v5809);
const v5811=__tempEdit(v5774,"push",v5792);
const v5812=__tempEdit(v5778,"push",v5803);
const v5813=1;
const v5814=(((v5776) + (v5813)) >>> 0);
v5770=({["first"]:v5811,["i"]:v5814,["second"]:v5812,["weights"]:v5810});
}
const v5764=v5770;
const v5816=v5764;
const v5815=v5816["first"];
const v5818=v5764;
const v5817=v5818["i"];
const v5820=v5764;
const v5819=v5820["second"];
const v5822=v5764;
const v5821=v5822["weights"];
let v5823;if(v5690&&v5825){v5823=v5824;}else{
const v5826=v5821;
const v5827=v5826.freeze();
const v5828=v5815;
const v5829=v5828.freeze();
const v5830=v5819;
const v5831=v5830.freeze();
const v5832=v5684["steps"];
const v5833=1;
const v5834=(((v5832) + (v5833)) >>> 0);
const v5835=v5754;
const v5836=v5757;
v5823=({["weights"]:v5827,["first"]:v5829,["second"]:v5831,["steps"]:v5834,["first_power"]:v5835,["second_power"]:v5836});if(v5690){v5824=v5823;v5825=true;}}
let v5837;if(v5690&&v5839){v5837=v5838;}else{
const v5840=v5823;
const v5841=__fn35(v5840);
const v5842=false;
v5837=(v5841===v5842);if(v5690){v5838=v5837;v5839=true;}}
let v5843;if(v5837){
v5843=({Err:"nonfinite optimizer update"});}else{
v5843=({Ok:v5823});}
v5743=v5843;}
v5709=v5743;}
return v5709;};}
function __prepareFn42(fixed,depth=0){if(depth>=16||!((true)))return __fn42;const v5879=__preparedStable(fixed[0],["a"])&&__preparedStable(fixed[0],["b"])&&__preparedStable(fixed[0],["c"])&&__preparedStable(fixed[0],["d"])&&__preparedStable(fixed[1],["operation"])&&__preparedStable(fixed[1],["slot"]);
let v5878=false,v5877;
let v6066=false,v6065;
return function(v5844,v5845){const v5847=v5845["slot"];
const v5848=0;
const v5849=(v5847===v5848);
let v5850;if(v5849){
v5850=v5844["a"];}else{
const v5851=v5845["slot"];
const v5852=1;
const v5853=(v5851===v5852);
let v5854;if(v5853){
v5854=v5844["b"];}else{
const v5855=v5845["slot"];
const v5856=2;
const v5857=(v5855===v5856);
let v5858;if(v5857){
v5858=v5844["c"];}else{
v5858=v5844["d"];}
v5854=v5858;}
v5850=v5854;}
const v5846=v5850;
const v5860=v5845["operation"];
const v5861=0;
const v5862=(v5860===v5861);
let v5863;if(v5862){
const v5864=v5846;
v5863=v5864["identity"];}else{
const v5865=v5845["operation"];
const v5866=1;
const v5867=(v5865===v5866);
let v5868;if(v5867){
const v5869=v5846;
v5868=v5869["scale"];}else{
const v5870=v5845["operation"];
const v5871=2;
const v5872=(v5870===v5871);
let v5873;if(v5872){
const v5874=v5846;
v5873=v5874["bias"];}else{
const v5875=v5846;
v5873=v5875["relu"];}
v5868=v5873;}
v5863=v5868;}
const v5859=v5863;
let v5876;if(v5879&&v5878){v5876=v5877;}else{
const v5880=v5859;
const v5881=v5859;
const v5883=v5880;
const v5884=v5883["value"];
const v5885=v5881;
const v5886=v5885["value"];
const v5882=__bits(__float(v5884) * __float(v5886));
const v5887=v5882;
const v5888=v5880;
const v5889=v5888["tangent_0"];
const v5890=v5881;
const v5891=v5890["value"];
const v5892=__bits(__float(v5889) * __float(v5891));
const v5893=v5880;
const v5894=v5893["value"];
const v5895=v5881;
const v5896=v5895["tangent_0"];
const v5897=__bits(__float(v5894) * __float(v5896));
const v5898=__bits(__float(v5892) + __float(v5897));
const v5899=v5880;
const v5900=v5899["tangent_1"];
const v5901=v5881;
const v5902=v5901["value"];
const v5903=__bits(__float(v5900) * __float(v5902));
const v5904=v5880;
const v5905=v5904["value"];
const v5906=v5881;
const v5907=v5906["tangent_1"];
const v5908=__bits(__float(v5905) * __float(v5907));
const v5909=__bits(__float(v5903) + __float(v5908));
const v5910=v5880;
const v5911=v5910["tangent_2"];
const v5912=v5881;
const v5913=v5912["value"];
const v5914=__bits(__float(v5911) * __float(v5913));
const v5915=v5880;
const v5916=v5915["value"];
const v5917=v5881;
const v5918=v5917["tangent_2"];
const v5919=__bits(__float(v5916) * __float(v5918));
const v5920=__bits(__float(v5914) + __float(v5919));
const v5921=v5880;
const v5922=v5921["tangent_3"];
const v5923=v5881;
const v5924=v5923["value"];
const v5925=__bits(__float(v5922) * __float(v5924));
const v5926=v5880;
const v5927=v5926["value"];
const v5928=v5881;
const v5929=v5928["tangent_3"];
const v5930=__bits(__float(v5927) * __float(v5929));
const v5931=__bits(__float(v5925) + __float(v5930));
const v5932=v5880;
const v5933=v5932["tangent_4"];
const v5934=v5881;
const v5935=v5934["value"];
const v5936=__bits(__float(v5933) * __float(v5935));
const v5937=v5880;
const v5938=v5937["value"];
const v5939=v5881;
const v5940=v5939["tangent_4"];
const v5941=__bits(__float(v5938) * __float(v5940));
const v5942=__bits(__float(v5936) + __float(v5941));
const v5943=v5880;
const v5944=v5943["tangent_5"];
const v5945=v5881;
const v5946=v5945["value"];
const v5947=__bits(__float(v5944) * __float(v5946));
const v5948=v5880;
const v5949=v5948["value"];
const v5950=v5881;
const v5951=v5950["tangent_5"];
const v5952=__bits(__float(v5949) * __float(v5951));
const v5953=__bits(__float(v5947) + __float(v5952));
const v5954=v5880;
const v5955=v5954["tangent_6"];
const v5956=v5881;
const v5957=v5956["value"];
const v5958=__bits(__float(v5955) * __float(v5957));
const v5959=v5880;
const v5960=v5959["value"];
const v5961=v5881;
const v5962=v5961["tangent_6"];
const v5963=__bits(__float(v5960) * __float(v5962));
const v5964=__bits(__float(v5958) + __float(v5963));
const v5965=v5880;
const v5966=v5965["tangent_7"];
const v5967=v5881;
const v5968=v5967["value"];
const v5969=__bits(__float(v5966) * __float(v5968));
const v5970=v5880;
const v5971=v5970["value"];
const v5972=v5881;
const v5973=v5972["tangent_7"];
const v5974=__bits(__float(v5971) * __float(v5973));
const v5975=__bits(__float(v5969) + __float(v5974));
const v5976=v5880;
const v5977=v5976["tangent_8"];
const v5978=v5881;
const v5979=v5978["value"];
const v5980=__bits(__float(v5977) * __float(v5979));
const v5981=v5880;
const v5982=v5981["value"];
const v5983=v5881;
const v5984=v5983["tangent_8"];
const v5985=__bits(__float(v5982) * __float(v5984));
const v5986=__bits(__float(v5980) + __float(v5985));
const v5987=v5880;
const v5988=v5987["tangent_9"];
const v5989=v5881;
const v5990=v5989["value"];
const v5991=__bits(__float(v5988) * __float(v5990));
const v5992=v5880;
const v5993=v5992["value"];
const v5994=v5881;
const v5995=v5994["tangent_9"];
const v5996=__bits(__float(v5993) * __float(v5995));
const v5997=__bits(__float(v5991) + __float(v5996));
const v5998=v5880;
const v5999=v5998["tangent_10"];
const v6000=v5881;
const v6001=v6000["value"];
const v6002=__bits(__float(v5999) * __float(v6001));
const v6003=v5880;
const v6004=v6003["value"];
const v6005=v5881;
const v6006=v6005["tangent_10"];
const v6007=__bits(__float(v6004) * __float(v6006));
const v6008=__bits(__float(v6002) + __float(v6007));
const v6009=v5880;
const v6010=v6009["tangent_11"];
const v6011=v5881;
const v6012=v6011["value"];
const v6013=__bits(__float(v6010) * __float(v6012));
const v6014=v5880;
const v6015=v6014["value"];
const v6016=v5881;
const v6017=v6016["tangent_11"];
const v6018=__bits(__float(v6015) * __float(v6017));
const v6019=__bits(__float(v6013) + __float(v6018));
const v6020=v5880;
const v6021=v6020["tangent_12"];
const v6022=v5881;
const v6023=v6022["value"];
const v6024=__bits(__float(v6021) * __float(v6023));
const v6025=v5880;
const v6026=v6025["value"];
const v6027=v5881;
const v6028=v6027["tangent_12"];
const v6029=__bits(__float(v6026) * __float(v6028));
const v6030=__bits(__float(v6024) + __float(v6029));
const v6031=v5880;
const v6032=v6031["tangent_13"];
const v6033=v5881;
const v6034=v6033["value"];
const v6035=__bits(__float(v6032) * __float(v6034));
const v6036=v5880;
const v6037=v6036["value"];
const v6038=v5881;
const v6039=v6038["tangent_13"];
const v6040=__bits(__float(v6037) * __float(v6039));
const v6041=__bits(__float(v6035) + __float(v6040));
const v6042=v5880;
const v6043=v6042["tangent_14"];
const v6044=v5881;
const v6045=v6044["value"];
const v6046=__bits(__float(v6043) * __float(v6045));
const v6047=v5880;
const v6048=v6047["value"];
const v6049=v5881;
const v6050=v6049["tangent_14"];
const v6051=__bits(__float(v6048) * __float(v6050));
const v6052=__bits(__float(v6046) + __float(v6051));
const v6053=v5880;
const v6054=v6053["tangent_15"];
const v6055=v5881;
const v6056=v6055["value"];
const v6057=__bits(__float(v6054) * __float(v6056));
const v6058=v5880;
const v6059=v6058["value"];
const v6060=v5881;
const v6061=v6060["tangent_15"];
const v6062=__bits(__float(v6059) * __float(v6061));
const v6063=__bits(__float(v6057) + __float(v6062));
v5876=({["value"]:v5887,["tangent_0"]:v5898,["tangent_1"]:v5909,["tangent_2"]:v5920,["tangent_3"]:v5931,["tangent_4"]:v5942,["tangent_5"]:v5953,["tangent_6"]:v5964,["tangent_7"]:v5975,["tangent_8"]:v5986,["tangent_9"]:v5997,["tangent_10"]:v6008,["tangent_11"]:v6019,["tangent_12"]:v6030,["tangent_13"]:v6041,["tangent_14"]:v6052,["tangent_15"]:v6063});if(v5879){v5877=v5876;v5878=true;}}
let v6064;if(true&&v6066){v6064=v6065;}else{
const v6067=1036831949;
const v6068=0;
const v6069=0;
const v6070=0;
const v6071=0;
const v6072=0;
const v6073=0;
const v6074=0;
const v6075=0;
const v6076=0;
const v6077=0;
const v6078=0;
const v6079=0;
const v6080=0;
const v6081=0;
const v6082=0;
const v6083=0;
v6064=({["value"]:v6067,["tangent_0"]:v6068,["tangent_1"]:v6069,["tangent_2"]:v6070,["tangent_3"]:v6071,["tangent_4"]:v6072,["tangent_5"]:v6073,["tangent_6"]:v6074,["tangent_7"]:v6075,["tangent_8"]:v6076,["tangent_9"]:v6077,["tangent_10"]:v6078,["tangent_11"]:v6079,["tangent_12"]:v6080,["tangent_13"]:v6081,["tangent_14"]:v6082,["tangent_15"]:v6083});if(true){v6065=v6064;v6066=true;}}
const v6085=v5876;
const v6086=v6085["value"];
const v6087=v6064;
const v6088=v6087["value"];
const v6084=__bits(__float(v6086) + __float(v6088));
const v6089=v6084;
const v6090=v5876;
const v6091=v6090["tangent_0"];
const v6092=v6064;
const v6093=v6092["tangent_0"];
const v6094=__bits(__float(v6091) + __float(v6093));
const v6095=v5876;
const v6096=v6095["tangent_1"];
const v6097=v6064;
const v6098=v6097["tangent_1"];
const v6099=__bits(__float(v6096) + __float(v6098));
const v6100=v5876;
const v6101=v6100["tangent_2"];
const v6102=v6064;
const v6103=v6102["tangent_2"];
const v6104=__bits(__float(v6101) + __float(v6103));
const v6105=v5876;
const v6106=v6105["tangent_3"];
const v6107=v6064;
const v6108=v6107["tangent_3"];
const v6109=__bits(__float(v6106) + __float(v6108));
const v6110=v5876;
const v6111=v6110["tangent_4"];
const v6112=v6064;
const v6113=v6112["tangent_4"];
const v6114=__bits(__float(v6111) + __float(v6113));
const v6115=v5876;
const v6116=v6115["tangent_5"];
const v6117=v6064;
const v6118=v6117["tangent_5"];
const v6119=__bits(__float(v6116) + __float(v6118));
const v6120=v5876;
const v6121=v6120["tangent_6"];
const v6122=v6064;
const v6123=v6122["tangent_6"];
const v6124=__bits(__float(v6121) + __float(v6123));
const v6125=v5876;
const v6126=v6125["tangent_7"];
const v6127=v6064;
const v6128=v6127["tangent_7"];
const v6129=__bits(__float(v6126) + __float(v6128));
const v6130=v5876;
const v6131=v6130["tangent_8"];
const v6132=v6064;
const v6133=v6132["tangent_8"];
const v6134=__bits(__float(v6131) + __float(v6133));
const v6135=v5876;
const v6136=v6135["tangent_9"];
const v6137=v6064;
const v6138=v6137["tangent_9"];
const v6139=__bits(__float(v6136) + __float(v6138));
const v6140=v5876;
const v6141=v6140["tangent_10"];
const v6142=v6064;
const v6143=v6142["tangent_10"];
const v6144=__bits(__float(v6141) + __float(v6143));
const v6145=v5876;
const v6146=v6145["tangent_11"];
const v6147=v6064;
const v6148=v6147["tangent_11"];
const v6149=__bits(__float(v6146) + __float(v6148));
const v6150=v5876;
const v6151=v6150["tangent_12"];
const v6152=v6064;
const v6153=v6152["tangent_12"];
const v6154=__bits(__float(v6151) + __float(v6153));
const v6155=v5876;
const v6156=v6155["tangent_13"];
const v6157=v6064;
const v6158=v6157["tangent_13"];
const v6159=__bits(__float(v6156) + __float(v6158));
const v6160=v5876;
const v6161=v6160["tangent_14"];
const v6162=v6064;
const v6163=v6162["tangent_14"];
const v6164=__bits(__float(v6161) + __float(v6163));
const v6165=v5876;
const v6166=v6165["tangent_15"];
const v6167=v6064;
const v6168=v6167["tangent_15"];
const v6169=__bits(__float(v6166) + __float(v6168));
return ({["value"]:v6089,["tangent_0"]:v6094,["tangent_1"]:v6099,["tangent_2"]:v6104,["tangent_3"]:v6109,["tangent_4"]:v6114,["tangent_5"]:v6119,["tangent_6"]:v6124,["tangent_7"]:v6129,["tangent_8"]:v6134,["tangent_9"]:v6139,["tangent_10"]:v6144,["tangent_11"]:v6149,["tangent_12"]:v6154,["tangent_13"]:v6159,["tangent_14"]:v6164,["tangent_15"]:v6169});};}
function __prepareFn43(fixed,depth=0){if(depth>=16||!((true)))return __fn43;const v6175=__preparedStable(fixed[0],["a","bias"])&&__preparedStable(fixed[0],["a","identity"])&&__preparedStable(fixed[0],["a","relu"])&&__preparedStable(fixed[0],["a","scale"])&&__preparedStable(fixed[0],["b","bias"])&&__preparedStable(fixed[0],["b","identity"])&&__preparedStable(fixed[0],["b","relu"])&&__preparedStable(fixed[0],["b","scale"])&&__preparedStable(fixed[0],["c","bias"])&&__preparedStable(fixed[0],["c","identity"])&&__preparedStable(fixed[0],["c","relu"])&&__preparedStable(fixed[0],["c","scale"])&&__preparedStable(fixed[0],["d","bias"])&&__preparedStable(fixed[0],["d","identity"])&&__preparedStable(fixed[0],["d","relu"])&&__preparedStable(fixed[0],["d","scale"])&&__preparedStable(fixed[1],["operation"])&&__preparedStable(fixed[1],["slot"]);
let v6174=false,v6173;
const v6485=__preparedPart(fixed[0],["a","bias"]);
const v6486={all:__preparedStable(fixed[0],["a","bias"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v6485}};
const v6487=__preparedPart(fixed[0],["a","identity"]);
const v6488={all:__preparedStable(fixed[0],["a","identity"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v6487}};
const v6489=__preparedPart(fixed[0],["a","relu"]);
const v6490={all:__preparedStable(fixed[0],["a","relu"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v6489}};
const v6491=__preparedPart(fixed[0],["a","scale"]);
const v6492={all:__preparedStable(fixed[0],["a","scale"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v6491}};
const v6493={all:__preparedStable(fixed[0],["a","bias"])&&__preparedStable(fixed[0],["a","identity"])&&__preparedStable(fixed[0],["a","relu"])&&__preparedStable(fixed[0],["a","scale"]),fields:{["bias"]:v6486,["identity"]:v6488,["relu"]:v6490,["scale"]:v6492}};
const v6494=__preparedPart(fixed[0],["b","bias"]);
const v6495={all:__preparedStable(fixed[0],["b","bias"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v6494}};
const v6496=__preparedPart(fixed[0],["b","identity"]);
const v6497={all:__preparedStable(fixed[0],["b","identity"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v6496}};
const v6498=__preparedPart(fixed[0],["b","relu"]);
const v6499={all:__preparedStable(fixed[0],["b","relu"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v6498}};
const v6500=__preparedPart(fixed[0],["b","scale"]);
const v6501={all:__preparedStable(fixed[0],["b","scale"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v6500}};
const v6502={all:__preparedStable(fixed[0],["b","bias"])&&__preparedStable(fixed[0],["b","identity"])&&__preparedStable(fixed[0],["b","relu"])&&__preparedStable(fixed[0],["b","scale"]),fields:{["bias"]:v6495,["identity"]:v6497,["relu"]:v6499,["scale"]:v6501}};
const v6503=__preparedPart(fixed[0],["c","bias"]);
const v6504={all:__preparedStable(fixed[0],["c","bias"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v6503}};
const v6505=__preparedPart(fixed[0],["c","identity"]);
const v6506={all:__preparedStable(fixed[0],["c","identity"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v6505}};
const v6507=__preparedPart(fixed[0],["c","relu"]);
const v6508={all:__preparedStable(fixed[0],["c","relu"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v6507}};
const v6509=__preparedPart(fixed[0],["c","scale"]);
const v6510={all:__preparedStable(fixed[0],["c","scale"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v6509}};
const v6511={all:__preparedStable(fixed[0],["c","bias"])&&__preparedStable(fixed[0],["c","identity"])&&__preparedStable(fixed[0],["c","relu"])&&__preparedStable(fixed[0],["c","scale"]),fields:{["bias"]:v6504,["identity"]:v6506,["relu"]:v6508,["scale"]:v6510}};
const v6512=__preparedPart(fixed[0],["d","bias"]);
const v6513={all:__preparedStable(fixed[0],["d","bias"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v6512}};
const v6514=__preparedPart(fixed[0],["d","identity"]);
const v6515={all:__preparedStable(fixed[0],["d","identity"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v6514}};
const v6516=__preparedPart(fixed[0],["d","relu"]);
const v6517={all:__preparedStable(fixed[0],["d","relu"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v6516}};
const v6518=__preparedPart(fixed[0],["d","scale"]);
const v6519={all:__preparedStable(fixed[0],["d","scale"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v6518}};
const v6520={all:__preparedStable(fixed[0],["d","bias"])&&__preparedStable(fixed[0],["d","identity"])&&__preparedStable(fixed[0],["d","relu"])&&__preparedStable(fixed[0],["d","scale"]),fields:{["bias"]:v6513,["identity"]:v6515,["relu"]:v6517,["scale"]:v6519}};
const v6521={all:__preparedStable(fixed[0],["a","bias"])&&__preparedStable(fixed[0],["a","identity"])&&__preparedStable(fixed[0],["a","relu"])&&__preparedStable(fixed[0],["a","scale"])&&__preparedStable(fixed[0],["b","bias"])&&__preparedStable(fixed[0],["b","identity"])&&__preparedStable(fixed[0],["b","relu"])&&__preparedStable(fixed[0],["b","scale"])&&__preparedStable(fixed[0],["c","bias"])&&__preparedStable(fixed[0],["c","identity"])&&__preparedStable(fixed[0],["c","relu"])&&__preparedStable(fixed[0],["c","scale"])&&__preparedStable(fixed[0],["d","bias"])&&__preparedStable(fixed[0],["d","identity"])&&__preparedStable(fixed[0],["d","relu"])&&__preparedStable(fixed[0],["d","scale"]),fields:{["a"]:v6493,["b"]:v6502,["c"]:v6511,["d"]:v6520}};
const v6525=__preparedPart(fixed[1],["operation"]);
const v6526=__preparedPart(fixed[1],["slot"]);
const v6527={all:__preparedStable(fixed[1],["operation"])&&__preparedStable(fixed[1],["slot"]),fields:{["operation"]:v6525,["slot"]:v6526}};
const v6530=depth<15&&__preparedFactories.has(42)&&((true));
let v6528;
return function(v6170,v6171){let v6172;if(v6175&&v6174){v6172=v6173;}else{
const v6176=v6170["a"];
const v6177=v6176["identity"];
const v6178=1065353216;
const v6179=0;
const v6180=0;
const v6181=0;
const v6182=0;
const v6183=0;
const v6184=0;
const v6185=0;
const v6186=0;
const v6187=0;
const v6188=0;
const v6189=0;
const v6190=0;
const v6191=0;
const v6192=0;
const v6193=0;
const v6194=({["value"]:v6177,["tangent_0"]:v6178,["tangent_1"]:v6179,["tangent_2"]:v6180,["tangent_3"]:v6181,["tangent_4"]:v6182,["tangent_5"]:v6183,["tangent_6"]:v6184,["tangent_7"]:v6185,["tangent_8"]:v6186,["tangent_9"]:v6187,["tangent_10"]:v6188,["tangent_11"]:v6189,["tangent_12"]:v6190,["tangent_13"]:v6191,["tangent_14"]:v6192,["tangent_15"]:v6193});
const v6195=v6170["a"];
const v6196=v6195["scale"];
const v6197=0;
const v6198=1065353216;
const v6199=0;
const v6200=0;
const v6201=0;
const v6202=0;
const v6203=0;
const v6204=0;
const v6205=0;
const v6206=0;
const v6207=0;
const v6208=0;
const v6209=0;
const v6210=0;
const v6211=0;
const v6212=0;
const v6213=({["value"]:v6196,["tangent_0"]:v6197,["tangent_1"]:v6198,["tangent_2"]:v6199,["tangent_3"]:v6200,["tangent_4"]:v6201,["tangent_5"]:v6202,["tangent_6"]:v6203,["tangent_7"]:v6204,["tangent_8"]:v6205,["tangent_9"]:v6206,["tangent_10"]:v6207,["tangent_11"]:v6208,["tangent_12"]:v6209,["tangent_13"]:v6210,["tangent_14"]:v6211,["tangent_15"]:v6212});
const v6214=v6170["a"];
const v6215=v6214["bias"];
const v6216=0;
const v6217=0;
const v6218=1065353216;
const v6219=0;
const v6220=0;
const v6221=0;
const v6222=0;
const v6223=0;
const v6224=0;
const v6225=0;
const v6226=0;
const v6227=0;
const v6228=0;
const v6229=0;
const v6230=0;
const v6231=0;
const v6232=({["value"]:v6215,["tangent_0"]:v6216,["tangent_1"]:v6217,["tangent_2"]:v6218,["tangent_3"]:v6219,["tangent_4"]:v6220,["tangent_5"]:v6221,["tangent_6"]:v6222,["tangent_7"]:v6223,["tangent_8"]:v6224,["tangent_9"]:v6225,["tangent_10"]:v6226,["tangent_11"]:v6227,["tangent_12"]:v6228,["tangent_13"]:v6229,["tangent_14"]:v6230,["tangent_15"]:v6231});
const v6233=v6170["a"];
const v6234=v6233["relu"];
const v6235=0;
const v6236=0;
const v6237=0;
const v6238=1065353216;
const v6239=0;
const v6240=0;
const v6241=0;
const v6242=0;
const v6243=0;
const v6244=0;
const v6245=0;
const v6246=0;
const v6247=0;
const v6248=0;
const v6249=0;
const v6250=0;
const v6251=({["value"]:v6234,["tangent_0"]:v6235,["tangent_1"]:v6236,["tangent_2"]:v6237,["tangent_3"]:v6238,["tangent_4"]:v6239,["tangent_5"]:v6240,["tangent_6"]:v6241,["tangent_7"]:v6242,["tangent_8"]:v6243,["tangent_9"]:v6244,["tangent_10"]:v6245,["tangent_11"]:v6246,["tangent_12"]:v6247,["tangent_13"]:v6248,["tangent_14"]:v6249,["tangent_15"]:v6250});
const v6252=({["identity"]:v6194,["scale"]:v6213,["bias"]:v6232,["relu"]:v6251});
const v6253=v6170["b"];
const v6254=v6253["identity"];
const v6255=0;
const v6256=0;
const v6257=0;
const v6258=0;
const v6259=1065353216;
const v6260=0;
const v6261=0;
const v6262=0;
const v6263=0;
const v6264=0;
const v6265=0;
const v6266=0;
const v6267=0;
const v6268=0;
const v6269=0;
const v6270=0;
const v6271=({["value"]:v6254,["tangent_0"]:v6255,["tangent_1"]:v6256,["tangent_2"]:v6257,["tangent_3"]:v6258,["tangent_4"]:v6259,["tangent_5"]:v6260,["tangent_6"]:v6261,["tangent_7"]:v6262,["tangent_8"]:v6263,["tangent_9"]:v6264,["tangent_10"]:v6265,["tangent_11"]:v6266,["tangent_12"]:v6267,["tangent_13"]:v6268,["tangent_14"]:v6269,["tangent_15"]:v6270});
const v6272=v6170["b"];
const v6273=v6272["scale"];
const v6274=0;
const v6275=0;
const v6276=0;
const v6277=0;
const v6278=0;
const v6279=1065353216;
const v6280=0;
const v6281=0;
const v6282=0;
const v6283=0;
const v6284=0;
const v6285=0;
const v6286=0;
const v6287=0;
const v6288=0;
const v6289=0;
const v6290=({["value"]:v6273,["tangent_0"]:v6274,["tangent_1"]:v6275,["tangent_2"]:v6276,["tangent_3"]:v6277,["tangent_4"]:v6278,["tangent_5"]:v6279,["tangent_6"]:v6280,["tangent_7"]:v6281,["tangent_8"]:v6282,["tangent_9"]:v6283,["tangent_10"]:v6284,["tangent_11"]:v6285,["tangent_12"]:v6286,["tangent_13"]:v6287,["tangent_14"]:v6288,["tangent_15"]:v6289});
const v6291=v6170["b"];
const v6292=v6291["bias"];
const v6293=0;
const v6294=0;
const v6295=0;
const v6296=0;
const v6297=0;
const v6298=0;
const v6299=1065353216;
const v6300=0;
const v6301=0;
const v6302=0;
const v6303=0;
const v6304=0;
const v6305=0;
const v6306=0;
const v6307=0;
const v6308=0;
const v6309=({["value"]:v6292,["tangent_0"]:v6293,["tangent_1"]:v6294,["tangent_2"]:v6295,["tangent_3"]:v6296,["tangent_4"]:v6297,["tangent_5"]:v6298,["tangent_6"]:v6299,["tangent_7"]:v6300,["tangent_8"]:v6301,["tangent_9"]:v6302,["tangent_10"]:v6303,["tangent_11"]:v6304,["tangent_12"]:v6305,["tangent_13"]:v6306,["tangent_14"]:v6307,["tangent_15"]:v6308});
const v6310=v6170["b"];
const v6311=v6310["relu"];
const v6312=0;
const v6313=0;
const v6314=0;
const v6315=0;
const v6316=0;
const v6317=0;
const v6318=0;
const v6319=1065353216;
const v6320=0;
const v6321=0;
const v6322=0;
const v6323=0;
const v6324=0;
const v6325=0;
const v6326=0;
const v6327=0;
const v6328=({["value"]:v6311,["tangent_0"]:v6312,["tangent_1"]:v6313,["tangent_2"]:v6314,["tangent_3"]:v6315,["tangent_4"]:v6316,["tangent_5"]:v6317,["tangent_6"]:v6318,["tangent_7"]:v6319,["tangent_8"]:v6320,["tangent_9"]:v6321,["tangent_10"]:v6322,["tangent_11"]:v6323,["tangent_12"]:v6324,["tangent_13"]:v6325,["tangent_14"]:v6326,["tangent_15"]:v6327});
const v6329=({["identity"]:v6271,["scale"]:v6290,["bias"]:v6309,["relu"]:v6328});
const v6330=v6170["c"];
const v6331=v6330["identity"];
const v6332=0;
const v6333=0;
const v6334=0;
const v6335=0;
const v6336=0;
const v6337=0;
const v6338=0;
const v6339=0;
const v6340=1065353216;
const v6341=0;
const v6342=0;
const v6343=0;
const v6344=0;
const v6345=0;
const v6346=0;
const v6347=0;
const v6348=({["value"]:v6331,["tangent_0"]:v6332,["tangent_1"]:v6333,["tangent_2"]:v6334,["tangent_3"]:v6335,["tangent_4"]:v6336,["tangent_5"]:v6337,["tangent_6"]:v6338,["tangent_7"]:v6339,["tangent_8"]:v6340,["tangent_9"]:v6341,["tangent_10"]:v6342,["tangent_11"]:v6343,["tangent_12"]:v6344,["tangent_13"]:v6345,["tangent_14"]:v6346,["tangent_15"]:v6347});
const v6349=v6170["c"];
const v6350=v6349["scale"];
const v6351=0;
const v6352=0;
const v6353=0;
const v6354=0;
const v6355=0;
const v6356=0;
const v6357=0;
const v6358=0;
const v6359=0;
const v6360=1065353216;
const v6361=0;
const v6362=0;
const v6363=0;
const v6364=0;
const v6365=0;
const v6366=0;
const v6367=({["value"]:v6350,["tangent_0"]:v6351,["tangent_1"]:v6352,["tangent_2"]:v6353,["tangent_3"]:v6354,["tangent_4"]:v6355,["tangent_5"]:v6356,["tangent_6"]:v6357,["tangent_7"]:v6358,["tangent_8"]:v6359,["tangent_9"]:v6360,["tangent_10"]:v6361,["tangent_11"]:v6362,["tangent_12"]:v6363,["tangent_13"]:v6364,["tangent_14"]:v6365,["tangent_15"]:v6366});
const v6368=v6170["c"];
const v6369=v6368["bias"];
const v6370=0;
const v6371=0;
const v6372=0;
const v6373=0;
const v6374=0;
const v6375=0;
const v6376=0;
const v6377=0;
const v6378=0;
const v6379=0;
const v6380=1065353216;
const v6381=0;
const v6382=0;
const v6383=0;
const v6384=0;
const v6385=0;
const v6386=({["value"]:v6369,["tangent_0"]:v6370,["tangent_1"]:v6371,["tangent_2"]:v6372,["tangent_3"]:v6373,["tangent_4"]:v6374,["tangent_5"]:v6375,["tangent_6"]:v6376,["tangent_7"]:v6377,["tangent_8"]:v6378,["tangent_9"]:v6379,["tangent_10"]:v6380,["tangent_11"]:v6381,["tangent_12"]:v6382,["tangent_13"]:v6383,["tangent_14"]:v6384,["tangent_15"]:v6385});
const v6387=v6170["c"];
const v6388=v6387["relu"];
const v6389=0;
const v6390=0;
const v6391=0;
const v6392=0;
const v6393=0;
const v6394=0;
const v6395=0;
const v6396=0;
const v6397=0;
const v6398=0;
const v6399=0;
const v6400=1065353216;
const v6401=0;
const v6402=0;
const v6403=0;
const v6404=0;
const v6405=({["value"]:v6388,["tangent_0"]:v6389,["tangent_1"]:v6390,["tangent_2"]:v6391,["tangent_3"]:v6392,["tangent_4"]:v6393,["tangent_5"]:v6394,["tangent_6"]:v6395,["tangent_7"]:v6396,["tangent_8"]:v6397,["tangent_9"]:v6398,["tangent_10"]:v6399,["tangent_11"]:v6400,["tangent_12"]:v6401,["tangent_13"]:v6402,["tangent_14"]:v6403,["tangent_15"]:v6404});
const v6406=({["identity"]:v6348,["scale"]:v6367,["bias"]:v6386,["relu"]:v6405});
const v6407=v6170["d"];
const v6408=v6407["identity"];
const v6409=0;
const v6410=0;
const v6411=0;
const v6412=0;
const v6413=0;
const v6414=0;
const v6415=0;
const v6416=0;
const v6417=0;
const v6418=0;
const v6419=0;
const v6420=0;
const v6421=1065353216;
const v6422=0;
const v6423=0;
const v6424=0;
const v6425=({["value"]:v6408,["tangent_0"]:v6409,["tangent_1"]:v6410,["tangent_2"]:v6411,["tangent_3"]:v6412,["tangent_4"]:v6413,["tangent_5"]:v6414,["tangent_6"]:v6415,["tangent_7"]:v6416,["tangent_8"]:v6417,["tangent_9"]:v6418,["tangent_10"]:v6419,["tangent_11"]:v6420,["tangent_12"]:v6421,["tangent_13"]:v6422,["tangent_14"]:v6423,["tangent_15"]:v6424});
const v6426=v6170["d"];
const v6427=v6426["scale"];
const v6428=0;
const v6429=0;
const v6430=0;
const v6431=0;
const v6432=0;
const v6433=0;
const v6434=0;
const v6435=0;
const v6436=0;
const v6437=0;
const v6438=0;
const v6439=0;
const v6440=0;
const v6441=1065353216;
const v6442=0;
const v6443=0;
const v6444=({["value"]:v6427,["tangent_0"]:v6428,["tangent_1"]:v6429,["tangent_2"]:v6430,["tangent_3"]:v6431,["tangent_4"]:v6432,["tangent_5"]:v6433,["tangent_6"]:v6434,["tangent_7"]:v6435,["tangent_8"]:v6436,["tangent_9"]:v6437,["tangent_10"]:v6438,["tangent_11"]:v6439,["tangent_12"]:v6440,["tangent_13"]:v6441,["tangent_14"]:v6442,["tangent_15"]:v6443});
const v6445=v6170["d"];
const v6446=v6445["bias"];
const v6447=0;
const v6448=0;
const v6449=0;
const v6450=0;
const v6451=0;
const v6452=0;
const v6453=0;
const v6454=0;
const v6455=0;
const v6456=0;
const v6457=0;
const v6458=0;
const v6459=0;
const v6460=0;
const v6461=1065353216;
const v6462=0;
const v6463=({["value"]:v6446,["tangent_0"]:v6447,["tangent_1"]:v6448,["tangent_2"]:v6449,["tangent_3"]:v6450,["tangent_4"]:v6451,["tangent_5"]:v6452,["tangent_6"]:v6453,["tangent_7"]:v6454,["tangent_8"]:v6455,["tangent_9"]:v6456,["tangent_10"]:v6457,["tangent_11"]:v6458,["tangent_12"]:v6459,["tangent_13"]:v6460,["tangent_14"]:v6461,["tangent_15"]:v6462});
const v6464=v6170["d"];
const v6465=v6464["relu"];
const v6466=0;
const v6467=0;
const v6468=0;
const v6469=0;
const v6470=0;
const v6471=0;
const v6472=0;
const v6473=0;
const v6474=0;
const v6475=0;
const v6476=0;
const v6477=0;
const v6478=0;
const v6479=0;
const v6480=0;
const v6481=1065353216;
const v6482=({["value"]:v6465,["tangent_0"]:v6466,["tangent_1"]:v6467,["tangent_2"]:v6468,["tangent_3"]:v6469,["tangent_4"]:v6470,["tangent_5"]:v6471,["tangent_6"]:v6472,["tangent_7"]:v6473,["tangent_8"]:v6474,["tangent_9"]:v6475,["tangent_10"]:v6476,["tangent_11"]:v6477,["tangent_12"]:v6478,["tangent_13"]:v6479,["tangent_14"]:v6480,["tangent_15"]:v6481});
const v6483=({["identity"]:v6425,["scale"]:v6444,["bias"]:v6463,["relu"]:v6482});
const v6484=({["a"]:v6252,["b"]:v6329,["c"]:v6406,["d"]:v6483});
const v6522=v6171["slot"];
const v6523=v6171["operation"];
const v6524=({["slot"]:v6522,["operation"]:v6523});
let v6531;if(v6530){if(!v6528){const v6529=__preparedFactories.get(42);v6528=v6529([v6521,v6527],depth+1);}v6531=v6528(v6484,v6524);}else{v6531=__fn42(v6484,v6524);}
v6172=v6531;if(v6175){v6173=v6172;v6174=true;}}
const v6532=v6172;
const v6533=v6532["tangent_0"];
const v6534=v6172;
const v6535=v6534["tangent_1"];
const v6536=v6172;
const v6537=v6536["tangent_2"];
const v6538=v6172;
const v6539=v6538["tangent_3"];
const v6540=({["identity"]:v6533,["scale"]:v6535,["bias"]:v6537,["relu"]:v6539});
const v6541=v6172;
const v6542=v6541["tangent_4"];
const v6543=v6172;
const v6544=v6543["tangent_5"];
const v6545=v6172;
const v6546=v6545["tangent_6"];
const v6547=v6172;
const v6548=v6547["tangent_7"];
const v6549=({["identity"]:v6542,["scale"]:v6544,["bias"]:v6546,["relu"]:v6548});
const v6550=v6172;
const v6551=v6550["tangent_8"];
const v6552=v6172;
const v6553=v6552["tangent_9"];
const v6554=v6172;
const v6555=v6554["tangent_10"];
const v6556=v6172;
const v6557=v6556["tangent_11"];
const v6558=({["identity"]:v6551,["scale"]:v6553,["bias"]:v6555,["relu"]:v6557});
const v6559=v6172;
const v6560=v6559["tangent_12"];
const v6561=v6172;
const v6562=v6561["tangent_13"];
const v6563=v6172;
const v6564=v6563["tangent_14"];
const v6565=v6172;
const v6566=v6565["tangent_15"];
const v6567=({["identity"]:v6560,["scale"]:v6562,["bias"]:v6564,["relu"]:v6566});
return ({["a"]:v6540,["b"]:v6549,["c"]:v6558,["d"]:v6567});};}
function __prepareFn45(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn45;const v6575=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
let v6574=false,v6573;
return function(v6570,v6571){let v6572;if(v6575&&v6574){v6572=v6573;}else{
v6572=__fn44(v6570,v6571);if(v6575){v6573=v6572;v6574=true;}}
const v6576=v6572;
return __fn44(v6570,v6576);};}
function __prepareFn46(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn46;const v6582=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
let v6581=false,v6580;
const v6585=depth<15&&__preparedFactories.has(45)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])));
let v6583;
const v6588=__preparedStable(fixed[0],["bias"])&&__preparedStable(fixed[0],["scale"])&&__preparedStable(fixed[1],[]);
let v6589;
return function(v6577,v6578){let v6579;if(v6582&&v6581){v6579=v6580;}else{
let v6586;if(v6585){if(!v6583){const v6584=__preparedFactories.get(45);v6583=v6584([fixed[0],fixed[1]],depth+1);}v6586=v6583(v6577,v6578);}else{v6586=__fn45(v6577,v6578);}
v6579=v6586;if(v6582){v6580=v6579;v6581=true;}}
const v6587=v6579;
let v6591;if(v6585){if(!v6589){const v6590=__preparedFactories.get(45);v6589=v6590([fixed[0],v6588],depth+1);}v6591=v6589(v6577,v6587);}else{v6591=__fn45(v6577,v6587);}
return v6591;};}
function __prepareFn48(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn48;const v6597=__preparedStable(fixed[0],[]);
let v6596=false,v6595;
return function(v6593){let v6594;if(v6597&&v6596){v6594=v6595;}else{
v6594=__fn47(v6593);if(v6597){v6595=v6594;v6596=true;}}
const v6598=v6594;
return __fn47(v6598);};}
function __prepareFn49(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn49;const v6603=__preparedStable(fixed[0],[]);
let v6602=false,v6601;
const v6606=depth<15&&__preparedFactories.has(48)&&((__preparedStable(fixed[0],[])));
let v6604;
let v6609;
return function(v6599){let v6600;if(v6603&&v6602){v6600=v6601;}else{
let v6607;if(v6606){if(!v6604){const v6605=__preparedFactories.get(48);v6604=v6605([fixed[0]],depth+1);}v6607=v6604(v6599);}else{v6607=__fn48(v6599);}
v6600=v6607;if(v6603){v6601=v6600;v6602=true;}}
const v6608=v6600;
let v6611;if(v6606){if(!v6609){const v6610=__preparedFactories.get(48);v6609=v6610([v6603],depth+1);}v6611=v6609(v6608);}else{v6611=__fn48(v6608);}
return v6611;};}
function __prepareFn50(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],["samples"]))))return __fn50;const v6617=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],["samples"]);
let v6616=false,v6615;
return function(v6612,v6613){let v6614;if(v6617&&v6616){v6614=v6615;}else{
const v6618=v6613["samples"];
let v6619=0;
for(let v6620=0;v6620<v6618.length;v6620++){
const v6621=v6618[v6620];
const v6622=v6619;
const v6623=v6621["input"];
const v6624=__fn46(v6612,v6623);
const v6625=v6621["target"];
const v6626=__bits(__float(v6624) - __float(v6625));
const v6627=__bits(__float(v6626) * __float(v6626));
v6619=__bits(__float(v6622) + __float(v6627));
}
v6614=v6619;if(v6617){v6615=v6614;v6616=true;}}
const v6628=__bits((__float(v6614))/(__float(__bits((v6613["samples"]).length))));
const v6629=v6613["instruction_cost"];
const v6630=1103101952;
const v6631=__bits(__float(v6629) * __float(v6630));
return __bits(__float(v6628) + __float(v6631));};}
const __preparedFactories=new Map([[3,__prepareFn3],[4,__prepareFn4],[9,__prepareFn9],[10,__prepareFn10],[11,__prepareFn11],[14,__prepareFn14],[15,__prepareFn15],[19,__prepareFn19],[20,__prepareFn20],[21,__prepareFn21],[22,__prepareFn22],[23,__prepareFn23],[24,__prepareFn24],[25,__prepareFn25],[26,__prepareFn26],[27,__prepareFn27],[28,__prepareFn28],[29,__prepareFn29],[30,__prepareFn30],[31,__prepareFn31],[32,__prepareFn32],[36,__prepareFn36],[39,__prepareFn39],[41,__prepareFn41],[42,__prepareFn42],[43,__prepareFn43],[45,__prepareFn45],[46,__prepareFn46],[48,__prepareFn48],[49,__prepareFn49],[50,__prepareFn50]]);
