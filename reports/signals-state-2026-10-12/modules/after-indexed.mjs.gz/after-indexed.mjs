const __nullaryNodes=[];
function __nullaryNode(c){return __nullaryNodes[c]??=({c,a:[]});}
function __node(c,a){return a.length===0?__nullaryNode(c):{c,a};}
const __deepCall=Symbol('private direct-call depth');let __directDepth=0;
function __run(call){const stack=[call];let result;while(stack.length){const frame=stack[stack.length-1],step=frame.next(result);if(step.done){result=step.value;stack.pop();}else{result=undefined;stack.push(step.value);}}return result;}
const __fpView=new DataView(new ArrayBuffer(4));
function __fpNumber(bits){__fpView.setUint32(0,Number(BigInt.asUintN(32,bits)),true);return __fpView.getFloat32(0,true);}
function __fpWord(op,a,b){
 if(op==='neg')return BigInt.asUintN(32,a)^2147483648n;
 const x=__fpNumber(a),y=__fpNumber(b);
 switch(op){case '==':return x===y;case '!=':return x!==y;case '<':return x<y;case '<=':return x<=y;case '>':return x>y;case '>=':return x>=y;}
 const value=op==='+'?x+y:op==='-'?x-y:op==='*'?x*y:undefined;
 if(value===undefined)throw Error('binary32 operator');if(Number.isNaN(value))return 2143289344n;__fpView.setFloat32(0,value,true);return BigInt(__fpView.getUint32(0,true));
}
function d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0){let v0;switch(a0.c){
case 0:{
const v2=0n;
v0=v2;break;}
case 1:{
const v3=1n;
v0=v3;break;}
case 2:{
v0=a0.a[6];break;}
default:throw Error('literal constructor projection');}
return v0;}
function d_08d94601ac1aa2ed93b41bdd0a8554f32110869bd547d78880f4da001de33883(a0){let v5;switch(a0.c){
case 0:{
const v12=__nullaryNode(0);
const v11=__node(0,[v12]);
const v7=__node(0,[a0.a[0],a0.a[1],a0.a[2],v11,a0.a[4]]);
v5=v7;break;}
case 1:{
const v18=__nullaryNode(0);
const v17=__node(0,[v18]);
const v14=__node(1,[a0.a[0],a0.a[1],v17]);
v5=v14;break;}
default:throw Error('literal constructor projection');}
return v5;}
function* d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1){const v24=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v26=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a1);
const v23=(v24)<(v26);
let v22;if(v23){
const v28=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
v22=v28;}else{
const v30=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a1);
v22=v30;}
const v34=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v36=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a1);
const v33=(v34)<(v36);
let v32;if(v33){
const v38=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a1);
v32=v38;}else{
const v40=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
v32=v40;}
const v43=yield d_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0);
const v45=yield d_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a1);
const v42=BigInt.asUintN(64,(v43)+(v45));
const v48=yield d_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0);
const v50=yield d_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a1);
const v47=BigInt.asUintN(64,(v48)+(v50));
const v55=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v57=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v54=(v55)<(v57);
let v53;if(v54){
const v59=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
v53=v59;}else{
const v61=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
v53=v61;}
const v63=1n;
const v52=BigInt.asUintN(64,(v53)+(v63));
const v19=__node(2,[a0,a1,v22,v32,v42,v47,v52]);
return v19;}
function* d_14b1c60245cb25b6473dae8947e9201876796fa199c6cdd20ee3a2661b7317b0(a0,a1,a2){const v66=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a2);
const v68=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v65=(v66)<(v68);
let v64;if(v65){
let v70;switch(a1.c){
case 0:{
const v73=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v72=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v73,a2);
v70=v72;break;}
case 1:{
const v78=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v77=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v78,a2);
v70=v77;break;}
case 2:{
const v83=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1.a[0]);
const v86=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1.a[1],a2);
const v82=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v83,v86);
v70=v82;break;}
default:throw Error('literal constructor projection');}
v64=v70;}else{
const v90=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v89=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v90,a2);
v64=v89;}
return v64;}
function d_186b6350f974a9daf5c57b97446437bb2cabe2a9241d8e38d84e02980089fef8(a0){let v94;switch(a0.c){
case 0:{
v94=a0.a[3];break;}
case 1:{
v94=a0.a[2];break;}
default:throw Error('literal constructor projection');}
return v94;}
function* d_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0){let v98;switch(a0.c){
case 0:{
const v100=__nullaryNode(0);
v98=v100;break;}
case 1:{
let v102;switch(a0.a[0].c){
case 0:{
v102=a0.a[0].a[1];break;}
default:throw Error('literal constructor projection');}
let v101;if(v102){
const v107=yield d_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0.a[1]);
const v105=__node(1,[a0.a[0],v107]);
v101=v105;}else{
const v109=yield d_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0.a[1]);
v101=v109;}
v98=v101;break;}
default:throw Error('literal constructor projection');}
return v98;}
function* d_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(a0){let v111;switch(a0.c){
case 0:{
const v113=__nullaryNode(0);
v111=v113;break;}
case 1:{
let v117;switch(a0.a[0].c){
case 0:{
v117=a0.a[0].a[0];break;}
default:throw Error('literal constructor projection');}
const v120=0n;
const v116=BigInt.asUintN(64,(v117)*(v120));
const v121=1n;
const v115=BigInt.asUintN(64,(v116)+(v121));
const v122=yield d_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(a0.a[1]);
const v114=__node(1,[v115,v122]);
v111=v114;break;}
default:throw Error('literal constructor projection');}
return v111;}
function* d_2227a6ba7041bd43fcef1b26000ccf84bfe9666af2f812e03de515c517d771d0(a0){let v124;switch(a0.c){
case 0:{
const v130=yield d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[3]);
const v126=__node(0,[a0.a[0],a0.a[1],a0.a[2],v130,a0.a[4]]);
v124=v126;break;}
case 1:{
const v136=yield d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[2]);
const v133=__node(1,[a0.a[0],a0.a[1],v136]);
v124=v133;break;}
default:throw Error('literal constructor projection');}
return v124;}
function* d_2937ee59437d4727fd243a664a281a6018453ca819aede4e91f0a7d9bda2ca12(a0){const v143=0n;
const v145=__nullaryNode(0);
const v142=__node(1,[v143,a0,v145]);
const v141=yield d_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(v142);
const v140=yield d_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(v141);
const v139=yield d_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(v140);
const v138=yield d_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(v139);
return v138;}
function* d_2a975b3a5fe826968db8619175ac9f0dfbf3be2c770a2eab7b9bb32e684cf01b(a0){const v151=0n;
const v153=__nullaryNode(0);
const v150=__node(1,[v151,a0,v153]);
const v149=yield d_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(v150);
const v148=yield d_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(v149);
const v147=yield d_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(v148);
const v146=yield d_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(v147);
return v146;}
function* d_2d15d039af07da09e966dbb56adcd73b313da516d054674d5f55c495085b08bd(a0){let v154;switch(a0.c){
case 0:{
const v160=yield d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[3]);
const v156=__node(0,[a0.a[0],a0.a[1],a0.a[2],v160,a0.a[4]]);
v154=v156;break;}
case 1:{
const v166=yield d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[2]);
const v163=__node(1,[a0.a[0],a0.a[1],v166]);
v154=v163;break;}
default:throw Error('literal constructor projection');}
return v154;}
function d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0){let v168;switch(a0.c){
case 0:{
const v170=0n;
v168=v170;break;}
case 1:{
v168=a0.a[0];break;}
case 2:{
v168=a0.a[3];break;}
default:throw Error('literal constructor projection');}
return v168;}
function* d_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(a0){let v173;switch(a0.c){
case 0:{
const v176=yield d_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0.a[0]);
const v175=__node(0,[v176]);
v173=v175;break;}
default:throw Error('literal constructor projection');}
return v173;}
function* d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(a0,a1){const v180=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v183=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v185=1n;
const v182=BigInt.asUintN(64,(v183)+(v185));
const v179=(v180)>(v182);
let v178;if(v179){
const v186=yield d_dd9122cd0ef5414b8f184fc5a412c2e0c7b9002cb5d701ef49dc7b9f5465679c(a0,a1);
v178=v186;}else{
const v189=yield d_5772432f10e31d0ddf159e9ab757ef7042f15ed47699a0c380e996b8cda2529c(a0,a1);
v178=v189;}
return v178;}
function* d_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(a0){let v192;switch(a0.c){
case 0:{
const v194=__nullaryNode(0);
v192=v194;break;}
case 1:{
let v196;switch(a0.a[0].c){
case 0:{
v196=a0.a[0].a[0];break;}
default:throw Error('literal constructor projection');}
const v199=yield d_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(a0.a[1]);
const v195=__node(1,[v196,v199]);
v192=v195;break;}
default:throw Error('literal constructor projection');}
return v192;}
function* d_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(a0,a1,a2,a3,a4,a5){let v201;switch(a0.c){
case 0:{
const v205=yield d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v204;switch(v205.c){
case 0:{
const v208=false;
v204=v208;break;}
case 1:{
const v209=true;
v204=v209;break;}
default:throw Error('literal constructor projection');}
let v203;if(v204){
const v212=yield d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v211;switch(v212.c){
case 0:{
const v215=false;
v211=v215;break;}
case 1:{
const v216=true;
v211=v216;break;}
default:throw Error('literal constructor projection');}
let v210;if(v211){
let v217;if(a5){
const v221=__nullaryNode(0);
const v220=__node(1,[v221]);
const v222=false;
const v224=__node(0,[a0.a[0]]);
const v226=__nullaryNode(0);
const v219=__node(0,[v220,v222,a1,v224,v226]);
v217=v219;}else{
const v230=18446744073709551615n;
const v228=(a1)===(v230);
let v227;if(v228){
const v232=1n;
const v234=__node(0,[a0.a[0]]);
const v231=__node(1,[v232,a1,v234]);
v227=v231;}else{
const v238=__nullaryNode(0);
const v237=__node(0,[v238]);
const v239=true;
const v242=1n;
const v240=BigInt.asUintN(64,(a1)+(v242));
const v247=__node(0,[a3,a4]);
const v244=yield d_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[0],a2,v247);
const v243=__node(0,[v244]);
const v251=__node(0,[a3]);
const v253=__nullaryNode(0);
const v250=__node(1,[v251,v253]);
const v236=__node(0,[v237,v239,v240,v243,v250]);
v227=v236;}
v217=v227;}
v210=v217;}else{
const v255=2n;
const v257=__node(0,[a0.a[0]]);
const v254=__node(1,[v255,a1,v257]);
v210=v254;}
v203=v210;}else{
const v261=yield d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v260;switch(v261.c){
case 0:{
const v264=false;
v260=v264;break;}
case 1:{
const v265=true;
v260=v265;break;}
default:throw Error('literal constructor projection');}
let v259;if(v260){
const v267=2n;
const v269=__node(0,[a0.a[0]]);
const v266=__node(1,[v267,a1,v269]);
v259=v266;}else{
let v271;if(a5){
const v275=__nullaryNode(0);
const v274=__node(1,[v275]);
const v276=false;
const v278=__node(0,[a0.a[0]]);
const v280=__nullaryNode(0);
const v273=__node(0,[v274,v276,a1,v278,v280]);
v271=v273;}else{
const v284=18446744073709551615n;
const v282=(a1)===(v284);
let v281;if(v282){
const v286=1n;
const v288=__node(0,[a0.a[0]]);
const v285=__node(1,[v286,a1,v288]);
v281=v285;}else{
const v292=__nullaryNode(0);
const v291=__node(0,[v292]);
const v293=true;
const v296=1n;
const v294=BigInt.asUintN(64,(a1)+(v296));
const v301=__node(0,[a3,a4]);
const v298=yield d_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[0],a2,v301);
const v297=__node(0,[v298]);
const v305=__node(0,[a3]);
const v307=__nullaryNode(0);
const v304=__node(1,[v305,v307]);
const v290=__node(0,[v291,v293,v294,v297,v304]);
v281=v290;}
v271=v281;}
v259=v271;}
v203=v259;}
v201=v203;break;}
default:throw Error('literal constructor projection');}
return v201;}
function* d_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0){let v308;switch(a0.c){
case 0:{
const v310=__nullaryNode(0);
v308=v310;break;}
case 1:{
const v314=__nullaryNode(0);
const v311=__node(1,[a0.a[0],a0.a[1],v314]);
v308=v311;break;}
case 2:{
const v316=yield d_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[0]);
const v318=yield d_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[1]);
const v315=yield d_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(v316,v318);
v308=v315;break;}
default:throw Error('literal constructor projection');}
return v308;}
function* d_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0){let v320;switch(a0.c){
case 0:{
const v322=0n;
v320=v322;break;}
case 1:{
const v323=yield d_2937ee59437d4727fd243a664a281a6018453ca819aede4e91f0a7d9bda2ca12(a0.a[1]);
v320=v323;break;}
case 2:{
v320=a0.a[4];break;}
default:throw Error('literal constructor projection');}
return v320;}
function d_4d9946ad9a037d55daebbf6b4f332ecf1e985eca512336e0f0bb06e1d923e74d(a0){let v326;switch(a0.c){
case 0:{
v326=a0.a[3];break;}
case 1:{
v326=a0.a[2];break;}
default:throw Error('literal constructor projection');}
return v326;}
function* d_5772432f10e31d0ddf159e9ab757ef7042f15ed47699a0c380e996b8cda2529c(a0,a1){const v332=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v335=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v337=1n;
const v334=BigInt.asUintN(64,(v335)+(v337));
const v331=(v332)>(v334);
let v330;if(v331){
let v338;switch(a1.c){
case 0:{
const v340=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v338=v340;break;}
case 1:{
const v343=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v338=v343;break;}
case 2:{
const v346=yield d_14b1c60245cb25b6473dae8947e9201876796fa199c6cdd20ee3a2661b7317b0(a0,a1.a[0],a1.a[1]);
v338=v346;break;}
default:throw Error('literal constructor projection');}
v330=v338;}else{
const v350=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v330=v350;}
return v330;}
function* d_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0,a1){const v357=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v355=(a1)<(v357);
const v361=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v359=(a1)>(v361);
const v354=(v355)||(v359);
let v353;if(v354){
v353=a0;}else{
let v364;switch(a0.c){
case 0:{
const v366=__nullaryNode(0);
v364=v366;break;}
case 1:{
const v368=(a1)===(a0.a[0]);
let v367;if(v368){
const v371=__nullaryNode(0);
v367=v371;}else{
const v372=__node(1,[a0.a[0],a0.a[1]]);
v367=v372;}
v364=v367;break;}
case 2:{
const v376=yield d_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[0],a1);
const v379=yield d_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[1],a1);
const v375=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v376,v379);
v364=v375;break;}
default:throw Error('literal constructor projection');}
v353=v364;}
return v353;}
function* d_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1){let v382;switch(a0.c){
case 0:{
const v385=yield d_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0.a[0]);
const v387=false;
const v389=__node(0,[a0.a[0]]);
const v391=__nullaryNode(0);
const v384=__node(0,[v385,v387,a1,v389,v391]);
v382=v384;break;}
default:throw Error('literal constructor projection');}
return v382;}
function* d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0,a1){const v396=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v394=(a1)<(v396);
const v400=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v398=(a1)>(v400);
const v393=(v394)||(v398);
let v392;if(v393){
const v402=__nullaryNode(0);
v392=v402;}else{
let v403;switch(a0.c){
case 0:{
const v405=__nullaryNode(0);
v403=v405;break;}
case 1:{
const v407=(a1)===(a0.a[0]);
let v406;if(v407){
const v410=__node(1,[a0.a[1]]);
v406=v410;}else{
const v412=__nullaryNode(0);
v406=v412;}
v403=v406;break;}
case 2:{
const v414=yield d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a1);
const v417=yield d_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[1],a1);
const v413=d_b786cd3d542360e36d11a412339399f2084fa0e5a8bec5ab1461e548f657f81d(v414,v417);
v403=v413;break;}
default:throw Error('literal constructor projection');}
v392=v403;}
return v392;}
function* d_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0){let v420;switch(a0.c){
case 0:{
const v422=__nullaryNode(0);
v420=v422;break;}
case 1:{
let v424;switch(a0.a[0].c){
case 0:{
v424=a0.a[0].a[1];break;}
default:throw Error('literal constructor projection');}
let v423;if(v424){
const v429=yield d_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0.a[1]);
const v427=__node(1,[a0.a[0],v429]);
v423=v427;}else{
const v431=yield d_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0.a[1]);
v423=v431;}
v420=v423;break;}
default:throw Error('literal constructor projection');}
return v420;}
function* d_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(a0){let v433;switch(a0.c){
case 0:{
const v435=__nullaryNode(0);
v433=v435;break;}
case 1:{
const v438=yield d_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(a0.a[2]);
const v436=__node(1,[a0.a[1],v438]);
v433=v436;break;}
default:throw Error('literal constructor projection');}
return v433;}
function* d_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(a0,a1){let v440;switch(a0.c){
case 0:{
v440=a1;break;}
case 1:{
const v446=yield d_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(a0.a[2],a1);
const v443=__node(1,[a0.a[0],a0.a[1],v446]);
v440=v443;break;}
default:throw Error('literal constructor projection');}
return v440;}
function* d_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(a0,a1,a2,a3){let v449;switch(a0.c){
case 0:{
let v451;if(a3){
const v455=__nullaryNode(0);
const v454=__node(1,[v455]);
const v456=false;
const v458=__node(0,[a0.a[0]]);
const v460=__nullaryNode(0);
const v453=__node(0,[v454,v456,a1,v458,v460]);
v451=v453;}else{
const v464=18446744073709551615n;
const v462=(a1)===(v464);
let v461;if(v462){
const v466=1n;
const v468=__node(0,[a0.a[0]]);
const v465=__node(1,[v466,a1,v468]);
v461=v465;}else{
const v472=__nullaryNode(0);
const v471=__node(0,[v472]);
const v473=true;
const v476=1n;
const v474=BigInt.asUintN(64,(a1)+(v476));
const v478=yield d_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[0],a2);
const v477=__node(0,[v478]);
const v482=__node(0,[a2]);
const v484=__nullaryNode(0);
const v481=__node(1,[v482,v484]);
const v470=__node(0,[v471,v473,v474,v477,v481]);
v461=v470;}
v451=v461;}
v449=v451;break;}
default:throw Error('literal constructor projection');}
return v449;}
function* d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0){let v485;switch(a0.c){
case 0:{
const v488=yield d_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[0]);
const v487=__node(0,[v488]);
v485=v487;break;}
default:throw Error('literal constructor projection');}
return v485;}
function d_b786cd3d542360e36d11a412339399f2084fa0e5a8bec5ab1461e548f657f81d(a0,a1){let v490;switch(a0.c){
case 0:{
v490=a1;break;}
case 1:{
const v493=__node(1,[a0.a[0]]);
v490=v493;break;}
default:throw Error('literal constructor projection');}
return v490;}
function* d_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0){let v495;switch(a0.c){
case 0:{
const v497=0n;
v495=v497;break;}
case 1:{
const v498=yield d_2a975b3a5fe826968db8619175ac9f0dfbf3be2c770a2eab7b9bb32e684cf01b(a0.a[1]);
v495=v498;break;}
case 2:{
v495=a0.a[5];break;}
default:throw Error('literal constructor projection');}
return v495;}
function* d_c7ad7bdf333846cfdaf9c1cef5bcc98d8b1f5a0ca3c654237e21162cd70e16f6(a0,a1,a2){const v503=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v505=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v502=(v503)<(v505);
let v501;if(v502){
let v507;switch(a1.c){
case 0:{
const v511=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v509=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v511);
v507=v509;break;}
case 1:{
const v516=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v514=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v516);
v507=v514;break;}
case 2:{
const v520=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1.a[0]);
const v523=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1.a[1],a2);
const v519=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v520,v523);
v507=v519;break;}
default:throw Error('literal constructor projection');}
v501=v507;}else{
const v528=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v526=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v528);
v501=v526;}
return v501;}
function d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0){let v531;switch(a0.c){
case 0:{
const v533=18446744073709551615n;
v531=v533;break;}
case 1:{
v531=a0.a[0];break;}
case 2:{
v531=a0.a[2];break;}
default:throw Error('literal constructor projection');}
return v531;}
function* d_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0,a1,a2){const v540=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v538=(a1)<(v540);
const v544=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v542=(a1)>(v544);
const v537=(v538)||(v542);
let v536;if(v537){
v536=a0;}else{
let v547;switch(a0.c){
case 0:{
const v549=__nullaryNode(0);
v547=v549;break;}
case 1:{
const v551=(a1)===(a0.a[0]);
let v550;if(v551){
const v554=__node(1,[a0.a[0],a2]);
v550=v554;}else{
const v557=__node(1,[a0.a[0],a0.a[1]]);
v550=v557;}
v547=v550;break;}
case 2:{
const v561=yield d_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[0],a1,a2);
const v565=yield d_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[1],a1,a2);
const v560=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v561,v565);
v547=v560;break;}
default:throw Error('literal constructor projection');}
v536=v547;}
return v536;}
function d_d0c069f5e4d74cddcd676b884d3c209df73106f994fb0b83d77481fc2dd559a0(a0){let v569;switch(a0.c){
case 0:{
const v576=__nullaryNode(0);
const v575=__node(0,[v576]);
const v571=__node(0,[a0.a[0],a0.a[1],a0.a[2],v575,a0.a[4]]);
v569=v571;break;}
case 1:{
const v582=__nullaryNode(0);
const v581=__node(0,[v582]);
const v578=__node(1,[a0.a[0],a0.a[1],v581]);
v569=v578;break;}
default:throw Error('literal constructor projection');}
return v569;}
function* d_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(a0,a1,a2){let v583;switch(a0.c){
case 0:{
const v585=__node(1,[a1,a2]);
v583=v585;break;}
case 1:{
const v589=__node(1,[a1,a2]);
const v592=__node(1,[a0.a[0],a0.a[1]]);
const v588=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v589,v592);
v583=v588;break;}
case 2:{
const v596=yield d_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(a0.a[0],a1,a2);
const v595=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v596,a0.a[1]);
v583=v595;break;}
default:throw Error('literal constructor projection');}
return v583;}
function* d_dd9122cd0ef5414b8f184fc5a412c2e0c7b9002cb5d701ef49dc7b9f5465679c(a0,a1){const v603=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v606=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v608=1n;
const v605=BigInt.asUintN(64,(v606)+(v608));
const v602=(v603)>(v605);
let v601;if(v602){
let v609;switch(a0.c){
case 0:{
const v611=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v609=v611;break;}
case 1:{
const v614=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v609=v614;break;}
case 2:{
const v617=yield d_c7ad7bdf333846cfdaf9c1cef5bcc98d8b1f5a0ca3c654237e21162cd70e16f6(a0.a[0],a0.a[1],a1);
v609=v617;break;}
default:throw Error('literal constructor projection');}
v601=v609;}else{
const v621=yield d_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v601=v621;}
return v601;}
function* d_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0){let v624;switch(a0.c){
case 0:{
const v626=__nullaryNode(0);
v624=v626;break;}
case 1:{
const v628=yield d_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0.a[2]);
const v627=yield d_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(v628,a0.a[0],a0.a[1]);
v624=v627;break;}
default:throw Error('literal constructor projection');}
return v624;}
function* d_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1){let v632;switch(a0.c){
case 0:{
const v635=yield d_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0.a[0]);
const v637=false;
const v639=__node(0,[a0.a[0]]);
const v641=__nullaryNode(0);
const v634=__node(0,[v635,v637,a1,v639,v641]);
v632=v634;break;}
default:throw Error('literal constructor projection');}
return v632;}
function* d_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(a0){let v642;switch(a0.c){
case 0:{
const v644=0n;
v642=v644;break;}
case 1:{
const v647=yield d_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(a0.a[1]);
const v645=BigInt.asUintN(64,(a0.a[0])+(v647));
v642=v645;break;}
default:throw Error('literal constructor projection');}
return v642;}
function* d_e76afcdc421fd94b92ff9f51242ab3db38cff4e5f27b705ee3645613843bcfc2(a0){let v649;switch(a0.c){
case 0:{
const v655=yield d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[3]);
const v651=__node(0,[a0.a[0],a0.a[1],a0.a[2],v655,a0.a[4]]);
v649=v651;break;}
case 1:{
const v661=yield d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[2]);
const v658=__node(1,[a0.a[0],a0.a[1],v661]);
v649=v658;break;}
default:throw Error('literal constructor projection');}
return v649;}
function* d_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0,a1,a2){let v663;switch(a0.c){
case 0:{
const v665=__node(1,[a1,a2]);
v663=v665;break;}
case 1:{
const v669=(a1)<(a0.a[0]);
let v668;if(v669){
const v673=__node(1,[a1,a2]);
const v676=__node(1,[a0.a[0],a0.a[1]]);
const v672=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v673,v676);
v668=v672;}else{
const v680=__node(1,[a0.a[0],a0.a[1]]);
const v683=__node(1,[a1,a2]);
const v679=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v680,v683);
v668=v679;}
v663=v668;break;}
case 2:{
const v689=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0.a[0]);
const v687=(a1)<(v689);
let v686;if(v687){
const v692=yield d_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[0],a1,a2);
const v691=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v692,a0.a[1]);
v686=v691;}else{
const v699=yield d_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[1],a1,a2);
const v697=yield d_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(a0.a[0],v699);
v686=v697;}
v663=v686;break;}
default:throw Error('literal constructor projection');}
return v663;}
function* d_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(a0){let v703;switch(a0.c){
case 0:{
const v705=0n;
v703=v705;break;}
case 1:{
const v708=yield d_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(a0.a[1]);
const v706=BigInt.asUintN(64,(a0.a[0])+(v708));
v703=v706;break;}
default:throw Error('literal constructor projection');}
return v703;}
function d_f8b201f9576cf5f758072d19d59fc2103838413eaff9a64f4a5aa01b90455187(a0){let v710;switch(a0.c){
case 0:{
const v717=__nullaryNode(0);
const v716=__node(0,[v717]);
const v712=__node(0,[a0.a[0],a0.a[1],a0.a[2],v716,a0.a[4]]);
v710=v712;break;}
case 1:{
const v723=__nullaryNode(0);
const v722=__node(0,[v723]);
const v719=__node(1,[a0.a[0],a0.a[1],v722]);
v710=v719;break;}
default:throw Error('literal constructor projection');}
return v710;}
function* d_q_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1){let v724;switch(a0.c){
case 0:{
let v726;switch(a0.a[0].c){
case 0:{
const v728=0n;
v726=v728;break;}
case 1:{
const v729=yield d_2937ee59437d4727fd243a664a281a6018453ca819aede4e91f0a7d9bda2ca12(a0.a[0].a[1]);
v726=v729;break;}
case 2:{
v726=a0.a[0].a[4];break;}
default:throw Error('literal constructor projection');}
v724=v726;break;}
default:throw Error('literal constructor projection');}
return v724;}
function* d_q_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1){let v732;switch(a0.c){
case 0:{
let v734;switch(a0.a[0].c){
case 0:{
const v736=0n;
v734=v736;break;}
case 1:{
const v737=yield d_2a975b3a5fe826968db8619175ac9f0dfbf3be2c770a2eab7b9bb32e684cf01b(a0.a[0].a[1]);
v734=v737;break;}
case 2:{
v734=a0.a[0].a[5];break;}
default:throw Error('literal constructor projection');}
v732=v734;break;}
default:throw Error('literal constructor projection');}
return v732;}
function dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v5=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v7=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a1);
const v4=(v5)<(v7);
let v3;if(v4){
const v9=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
v3=v9;}else{
const v11=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a1);
v3=v11;}
const v15=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v17=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a1);
const v14=(v15)<(v17);
let v13;if(v14){
const v19=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a1);
v13=v19;}else{
const v21=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
v13=v21;}
const v24=dFast_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0);
const v26=dFast_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a1);
const v23=BigInt.asUintN(64,(v24)+(v26));
const v29=dFast_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0);
const v31=dFast_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a1);
const v28=BigInt.asUintN(64,(v29)+(v31));
const v36=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v38=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v35=(v36)<(v38);
let v34;if(v35){
const v40=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
v34=v40;}else{
const v42=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
v34=v42;}
const v44=1n;
const v33=BigInt.asUintN(64,(v34)+(v44));
const v0=__node(2,[a0,a1,v3,v13,v23,v28,v33]);
return v0;}finally{__directDepth--;}}
function dFast_14b1c60245cb25b6473dae8947e9201876796fa199c6cdd20ee3a2661b7317b0(a0,a1,a2){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v47=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a2);
const v49=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v46=(v47)<(v49);
let v45;if(v46){
let v51;switch(a1.c){
case 0:{
const v54=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v53=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v54,a2);
v51=v53;break;}
case 1:{
const v59=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v58=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v59,a2);
v51=v58;break;}
case 2:{
const v64=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1.a[0]);
const v67=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1.a[1],a2);
const v63=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v64,v67);
v51=v63;break;}
default:throw Error('literal constructor projection');}
v45=v51;}else{
const v71=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
const v70=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v71,a2);
v45=v70;}
return v45;}finally{__directDepth--;}}
function dFast_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v75;switch(a0.c){
case 0:{
const v77=__nullaryNode(0);
v75=v77;break;}
case 1:{
let v79;switch(a0.a[0].c){
case 0:{
v79=a0.a[0].a[1];break;}
default:throw Error('literal constructor projection');}
let v78;if(v79){
const v84=dFast_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0.a[1]);
const v82=__node(1,[a0.a[0],v84]);
v78=v82;}else{
const v86=dFast_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(a0.a[1]);
v78=v86;}
v75=v78;break;}
default:throw Error('literal constructor projection');}
return v75;}finally{__directDepth--;}}
function dFast_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v88;switch(a0.c){
case 0:{
const v90=__nullaryNode(0);
v88=v90;break;}
case 1:{
let v94;switch(a0.a[0].c){
case 0:{
v94=a0.a[0].a[0];break;}
default:throw Error('literal constructor projection');}
const v97=0n;
const v93=BigInt.asUintN(64,(v94)*(v97));
const v98=1n;
const v92=BigInt.asUintN(64,(v93)+(v98));
const v99=dFast_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(a0.a[1]);
const v91=__node(1,[v92,v99]);
v88=v91;break;}
default:throw Error('literal constructor projection');}
return v88;}finally{__directDepth--;}}
function dFast_2227a6ba7041bd43fcef1b26000ccf84bfe9666af2f812e03de515c517d771d0(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v101;switch(a0.c){
case 0:{
const v107=dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[3]);
const v103=__node(0,[a0.a[0],a0.a[1],a0.a[2],v107,a0.a[4]]);
v101=v103;break;}
case 1:{
const v113=dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[2]);
const v110=__node(1,[a0.a[0],a0.a[1],v113]);
v101=v110;break;}
default:throw Error('literal constructor projection');}
return v101;}finally{__directDepth--;}}
function dFast_2937ee59437d4727fd243a664a281a6018453ca819aede4e91f0a7d9bda2ca12(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v120=0n;
const v122=__nullaryNode(0);
const v119=__node(1,[v120,a0,v122]);
const v118=dFast_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(v119);
const v117=dFast_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(v118);
const v116=dFast_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(v117);
const v115=dFast_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(v116);
return v115;}finally{__directDepth--;}}
function dFast_2a975b3a5fe826968db8619175ac9f0dfbf3be2c770a2eab7b9bb32e684cf01b(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v128=0n;
const v130=__nullaryNode(0);
const v127=__node(1,[v128,a0,v130]);
const v126=dFast_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(v127);
const v125=dFast_1c4ef7b3f512ff85bfb65b181a32c0bfc88e4cddfeb6b1bd12fbb24fe24d9805(v126);
const v124=dFast_1e34544693ce3a76972d38f5de098aca0975198471a6c30935fe54cb724504c8(v125);
const v123=dFast_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(v124);
return v123;}finally{__directDepth--;}}
function dFast_2d15d039af07da09e966dbb56adcd73b313da516d054674d5f55c495085b08bd(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v131;switch(a0.c){
case 0:{
const v137=dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[3]);
const v133=__node(0,[a0.a[0],a0.a[1],a0.a[2],v137,a0.a[4]]);
v131=v133;break;}
case 1:{
const v143=dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[2]);
const v140=__node(1,[a0.a[0],a0.a[1],v143]);
v131=v140;break;}
default:throw Error('literal constructor projection');}
return v131;}finally{__directDepth--;}}
function dFast_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v145;switch(a0.c){
case 0:{
const v148=dFast_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0.a[0]);
const v147=__node(0,[v148]);
v145=v147;break;}
default:throw Error('literal constructor projection');}
return v145;}finally{__directDepth--;}}
function dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v152=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v155=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v157=1n;
const v154=BigInt.asUintN(64,(v155)+(v157));
const v151=(v152)>(v154);
let v150;if(v151){
const v158=dFast_dd9122cd0ef5414b8f184fc5a412c2e0c7b9002cb5d701ef49dc7b9f5465679c(a0,a1);
v150=v158;}else{
const v161=dFast_5772432f10e31d0ddf159e9ab757ef7042f15ed47699a0c380e996b8cda2529c(a0,a1);
v150=v161;}
return v150;}finally{__directDepth--;}}
function dFast_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v164;switch(a0.c){
case 0:{
const v166=__nullaryNode(0);
v164=v166;break;}
case 1:{
let v168;switch(a0.a[0].c){
case 0:{
v168=a0.a[0].a[0];break;}
default:throw Error('literal constructor projection');}
const v171=dFast_3ac8d3f13efde674396bc57a7438ad8d845b3229ec0af8cf2f27c539f1e6f4f3(a0.a[1]);
const v167=__node(1,[v168,v171]);
v164=v167;break;}
default:throw Error('literal constructor projection');}
return v164;}finally{__directDepth--;}}
function dFast_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(a0,a1,a2,a3,a4,a5){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v173;switch(a0.c){
case 0:{
const v177=dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v176;switch(v177.c){
case 0:{
const v180=false;
v176=v180;break;}
case 1:{
const v181=true;
v176=v181;break;}
default:throw Error('literal constructor projection');}
let v175;if(v176){
const v184=dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v183;switch(v184.c){
case 0:{
const v187=false;
v183=v187;break;}
case 1:{
const v188=true;
v183=v188;break;}
default:throw Error('literal constructor projection');}
let v182;if(v183){
let v189;if(a5){
const v193=__nullaryNode(0);
const v192=__node(1,[v193]);
const v194=false;
const v196=__node(0,[a0.a[0]]);
const v198=__nullaryNode(0);
const v191=__node(0,[v192,v194,a1,v196,v198]);
v189=v191;}else{
const v202=18446744073709551615n;
const v200=(a1)===(v202);
let v199;if(v200){
const v204=1n;
const v206=__node(0,[a0.a[0]]);
const v203=__node(1,[v204,a1,v206]);
v199=v203;}else{
const v210=__nullaryNode(0);
const v209=__node(0,[v210]);
const v211=true;
const v214=1n;
const v212=BigInt.asUintN(64,(a1)+(v214));
const v219=__node(0,[a3,a4]);
const v216=dFast_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[0],a2,v219);
const v215=__node(0,[v216]);
const v223=__node(0,[a3]);
const v225=__nullaryNode(0);
const v222=__node(1,[v223,v225]);
const v208=__node(0,[v209,v211,v212,v215,v222]);
v199=v208;}
v189=v199;}
v182=v189;}else{
const v227=2n;
const v229=__node(0,[a0.a[0]]);
const v226=__node(1,[v227,a1,v229]);
v182=v226;}
v175=v182;}else{
const v233=dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a2);
let v232;switch(v233.c){
case 0:{
const v236=false;
v232=v236;break;}
case 1:{
const v237=true;
v232=v237;break;}
default:throw Error('literal constructor projection');}
let v231;if(v232){
const v239=2n;
const v241=__node(0,[a0.a[0]]);
const v238=__node(1,[v239,a1,v241]);
v231=v238;}else{
let v243;if(a5){
const v247=__nullaryNode(0);
const v246=__node(1,[v247]);
const v248=false;
const v250=__node(0,[a0.a[0]]);
const v252=__nullaryNode(0);
const v245=__node(0,[v246,v248,a1,v250,v252]);
v243=v245;}else{
const v256=18446744073709551615n;
const v254=(a1)===(v256);
let v253;if(v254){
const v258=1n;
const v260=__node(0,[a0.a[0]]);
const v257=__node(1,[v258,a1,v260]);
v253=v257;}else{
const v264=__nullaryNode(0);
const v263=__node(0,[v264]);
const v265=true;
const v268=1n;
const v266=BigInt.asUintN(64,(a1)+(v268));
const v273=__node(0,[a3,a4]);
const v270=dFast_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[0],a2,v273);
const v269=__node(0,[v270]);
const v277=__node(0,[a3]);
const v279=__nullaryNode(0);
const v276=__node(1,[v277,v279]);
const v262=__node(0,[v263,v265,v266,v269,v276]);
v253=v262;}
v243=v253;}
v231=v243;}
v175=v231;}
v173=v175;break;}
default:throw Error('literal constructor projection');}
return v173;}finally{__directDepth--;}}
function dFast_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v280;switch(a0.c){
case 0:{
const v282=__nullaryNode(0);
v280=v282;break;}
case 1:{
const v286=__nullaryNode(0);
const v283=__node(1,[a0.a[0],a0.a[1],v286]);
v280=v283;break;}
case 2:{
const v288=dFast_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[0]);
const v290=dFast_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[1]);
const v287=dFast_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(v288,v290);
v280=v287;break;}
default:throw Error('literal constructor projection');}
return v280;}finally{__directDepth--;}}
function dFast_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v292;switch(a0.c){
case 0:{
const v294=0n;
v292=v294;break;}
case 1:{
const v295=dFast_2937ee59437d4727fd243a664a281a6018453ca819aede4e91f0a7d9bda2ca12(a0.a[1]);
v292=v295;break;}
case 2:{
v292=a0.a[4];break;}
default:throw Error('literal constructor projection');}
return v292;}finally{__directDepth--;}}
function dFast_5772432f10e31d0ddf159e9ab757ef7042f15ed47699a0c380e996b8cda2529c(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v300=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v303=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v305=1n;
const v302=BigInt.asUintN(64,(v303)+(v305));
const v299=(v300)>(v302);
let v298;if(v299){
let v306;switch(a1.c){
case 0:{
const v308=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v306=v308;break;}
case 1:{
const v311=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v306=v311;break;}
case 2:{
const v314=dFast_14b1c60245cb25b6473dae8947e9201876796fa199c6cdd20ee3a2661b7317b0(a0,a1.a[0],a1.a[1]);
v306=v314;break;}
default:throw Error('literal constructor projection');}
v298=v306;}else{
const v318=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v298=v318;}
return v298;}finally{__directDepth--;}}
function dFast_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v325=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v323=(a1)<(v325);
const v329=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v327=(a1)>(v329);
const v322=(v323)||(v327);
let v321;if(v322){
v321=a0;}else{
let v332;switch(a0.c){
case 0:{
const v334=__nullaryNode(0);
v332=v334;break;}
case 1:{
const v336=(a1)===(a0.a[0]);
let v335;if(v336){
const v339=__nullaryNode(0);
v335=v339;}else{
const v340=__node(1,[a0.a[0],a0.a[1]]);
v335=v340;}
v332=v335;break;}
case 2:{
const v344=dFast_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[0],a1);
const v347=dFast_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[1],a1);
const v343=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v344,v347);
v332=v343;break;}
default:throw Error('literal constructor projection');}
v321=v332;}
return v321;}finally{__directDepth--;}}
function dFast_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v350;switch(a0.c){
case 0:{
const v353=dFast_475ab96fe2e02a28266b359a578407f229ddfb6abe1e42bd05f78d958d80aee1(a0.a[0]);
const v355=false;
const v357=__node(0,[a0.a[0]]);
const v359=__nullaryNode(0);
const v352=__node(0,[v353,v355,a1,v357,v359]);
v350=v352;break;}
default:throw Error('literal constructor projection');}
return v350;}finally{__directDepth--;}}
function dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v364=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v362=(a1)<(v364);
const v368=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v366=(a1)>(v368);
const v361=(v362)||(v366);
let v360;if(v361){
const v370=__nullaryNode(0);
v360=v370;}else{
let v371;switch(a0.c){
case 0:{
const v373=__nullaryNode(0);
v371=v373;break;}
case 1:{
const v375=(a1)===(a0.a[0]);
let v374;if(v375){
const v378=__node(1,[a0.a[1]]);
v374=v378;}else{
const v380=__nullaryNode(0);
v374=v380;}
v371=v374;break;}
case 2:{
const v382=dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[0],a1);
const v385=dFast_6f9dd3a9a14f715f8376d62c865b2b45ae52dc57dd7fa8e525d1c86cbae25862(a0.a[1],a1);
const v381=d_b786cd3d542360e36d11a412339399f2084fa0e5a8bec5ab1461e548f657f81d(v382,v385);
v371=v381;break;}
default:throw Error('literal constructor projection');}
v360=v371;}
return v360;}finally{__directDepth--;}}
function dFast_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v388;switch(a0.c){
case 0:{
const v390=__nullaryNode(0);
v388=v390;break;}
case 1:{
let v392;switch(a0.a[0].c){
case 0:{
v392=a0.a[0].a[1];break;}
default:throw Error('literal constructor projection');}
let v391;if(v392){
const v397=dFast_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0.a[1]);
const v395=__node(1,[a0.a[0],v397]);
v391=v395;}else{
const v399=dFast_85a7d3b8a8546e52909abfe0c30d30a4b6da6981bb0b2fa37b1a363c96f862b7(a0.a[1]);
v391=v399;}
v388=v391;break;}
default:throw Error('literal constructor projection');}
return v388;}finally{__directDepth--;}}
function dFast_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v401;switch(a0.c){
case 0:{
const v403=__nullaryNode(0);
v401=v403;break;}
case 1:{
const v406=dFast_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(a0.a[2]);
const v404=__node(1,[a0.a[1],v406]);
v401=v404;break;}
default:throw Error('literal constructor projection');}
return v401;}finally{__directDepth--;}}
function dFast_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v408;switch(a0.c){
case 0:{
v408=a1;break;}
case 1:{
const v414=dFast_a02900963d57d97aa1fe55df523348d493b722a2443aac9e13c6f54caadaf9fc(a0.a[2],a1);
const v411=__node(1,[a0.a[0],a0.a[1],v414]);
v408=v411;break;}
default:throw Error('literal constructor projection');}
return v408;}finally{__directDepth--;}}
function dFast_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(a0,a1,a2,a3){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v417;switch(a0.c){
case 0:{
let v419;if(a3){
const v423=__nullaryNode(0);
const v422=__node(1,[v423]);
const v424=false;
const v426=__node(0,[a0.a[0]]);
const v428=__nullaryNode(0);
const v421=__node(0,[v422,v424,a1,v426,v428]);
v419=v421;}else{
const v432=18446744073709551615n;
const v430=(a1)===(v432);
let v429;if(v430){
const v434=1n;
const v436=__node(0,[a0.a[0]]);
const v433=__node(1,[v434,a1,v436]);
v429=v433;}else{
const v440=__nullaryNode(0);
const v439=__node(0,[v440]);
const v441=true;
const v444=1n;
const v442=BigInt.asUintN(64,(a1)+(v444));
const v446=dFast_69e8f0462123beaac5b725c965920b8c2340af30429b47d726fe1fc20b333fba(a0.a[0],a2);
const v445=__node(0,[v446]);
const v450=__node(0,[a2]);
const v452=__nullaryNode(0);
const v449=__node(1,[v450,v452]);
const v438=__node(0,[v439,v441,v442,v445,v449]);
v429=v438;}
v419=v429;}
v417=v419;break;}
default:throw Error('literal constructor projection');}
return v417;}finally{__directDepth--;}}
function dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v453;switch(a0.c){
case 0:{
const v456=dFast_474aca4c64ac507e51414e3ae5a86dd90b62e855a278e97c55f54a514b35a23f(a0.a[0]);
const v455=__node(0,[v456]);
v453=v455;break;}
default:throw Error('literal constructor projection');}
return v453;}finally{__directDepth--;}}
function dFast_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v458;switch(a0.c){
case 0:{
const v460=0n;
v458=v460;break;}
case 1:{
const v461=dFast_2a975b3a5fe826968db8619175ac9f0dfbf3be2c770a2eab7b9bb32e684cf01b(a0.a[1]);
v458=v461;break;}
case 2:{
v458=a0.a[5];break;}
default:throw Error('literal constructor projection');}
return v458;}finally{__directDepth--;}}
function dFast_c7ad7bdf333846cfdaf9c1cef5bcc98d8b1f5a0ca3c654237e21162cd70e16f6(a0,a1,a2){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v466=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v468=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v465=(v466)<(v468);
let v464;if(v465){
let v470;switch(a1.c){
case 0:{
const v474=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v472=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v474);
v470=v472;break;}
case 1:{
const v479=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v477=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v479);
v470=v477;break;}
case 2:{
const v483=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1.a[0]);
const v486=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1.a[1],a2);
const v482=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v483,v486);
v470=v482;break;}
default:throw Error('literal constructor projection');}
v464=v470;}else{
const v491=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a1,a2);
const v489=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,v491);
v464=v489;}
return v464;}finally{__directDepth--;}}
function dFast_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0,a1,a2){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v498=d_cbcba9e3f787a3b23562b0ef4be74ae4029b63401f57fe7d6d0c2b591d40de0d(a0);
const v496=(a1)<(v498);
const v502=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0);
const v500=(a1)>(v502);
const v495=(v496)||(v500);
let v494;if(v495){
v494=a0;}else{
let v505;switch(a0.c){
case 0:{
const v507=__nullaryNode(0);
v505=v507;break;}
case 1:{
const v509=(a1)===(a0.a[0]);
let v508;if(v509){
const v512=__node(1,[a0.a[0],a2]);
v508=v512;}else{
const v515=__node(1,[a0.a[0],a0.a[1]]);
v508=v515;}
v505=v508;break;}
case 2:{
const v519=dFast_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[0],a1,a2);
const v523=dFast_cdac157f6e4978e9b319d23081095a8ba5b3a6ac6201346dc2b27a84b324bf4a(a0.a[1],a1,a2);
const v518=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(v519,v523);
v505=v518;break;}
default:throw Error('literal constructor projection');}
v494=v505;}
return v494;}finally{__directDepth--;}}
function dFast_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(a0,a1,a2){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v527;switch(a0.c){
case 0:{
const v529=__node(1,[a1,a2]);
v527=v529;break;}
case 1:{
const v533=__node(1,[a1,a2]);
const v536=__node(1,[a0.a[0],a0.a[1]]);
const v532=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v533,v536);
v527=v532;break;}
case 2:{
const v540=dFast_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(a0.a[0],a1,a2);
const v539=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v540,a0.a[1]);
v527=v539;break;}
default:throw Error('literal constructor projection');}
return v527;}finally{__directDepth--;}}
function dFast_dd9122cd0ef5414b8f184fc5a412c2e0c7b9002cb5d701ef49dc7b9f5465679c(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{const v547=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a0);
const v550=d_066da9768e60dc3a4deef2f7ffa439f31ea6760f6843c76a54d8d01b3d158502(a1);
const v552=1n;
const v549=BigInt.asUintN(64,(v550)+(v552));
const v546=(v547)>(v549);
let v545;if(v546){
let v553;switch(a0.c){
case 0:{
const v555=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v553=v555;break;}
case 1:{
const v558=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v553=v558;break;}
case 2:{
const v561=dFast_c7ad7bdf333846cfdaf9c1cef5bcc98d8b1f5a0ca3c654237e21162cd70e16f6(a0.a[0],a0.a[1],a1);
v553=v561;break;}
default:throw Error('literal constructor projection');}
v545=v553;}else{
const v565=dFast_0b82c59bf15e551e176949b916544f67dde263a9f75f1ec465ac2b2dbfa26f9d(a0,a1);
v545=v565;}
return v545;}finally{__directDepth--;}}
function dFast_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v568;switch(a0.c){
case 0:{
const v570=__nullaryNode(0);
v568=v570;break;}
case 1:{
const v572=dFast_dffe3cbe17995837057b32aa776d32f23b98ea8678aef1774171ba497b8e970e(a0.a[2]);
const v571=dFast_d3554f5e38086e7c5371632665836436d78fdb52414f083de240f23c44048dd2(v572,a0.a[0],a0.a[1]);
v568=v571;break;}
default:throw Error('literal constructor projection');}
return v568;}finally{__directDepth--;}}
function dFast_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v576;switch(a0.c){
case 0:{
const v579=dFast_bec00838bc86fe94b60646b673443ee2c95dab64d792591aa787130a07f48fa4(a0.a[0]);
const v581=false;
const v583=__node(0,[a0.a[0]]);
const v585=__nullaryNode(0);
const v578=__node(0,[v579,v581,a1,v583,v585]);
v576=v578;break;}
default:throw Error('literal constructor projection');}
return v576;}finally{__directDepth--;}}
function dFast_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v586;switch(a0.c){
case 0:{
const v588=0n;
v586=v588;break;}
case 1:{
const v591=dFast_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(a0.a[1]);
const v589=BigInt.asUintN(64,(a0.a[0])+(v591));
v586=v589;break;}
default:throw Error('literal constructor projection');}
return v586;}finally{__directDepth--;}}
function dFast_e76afcdc421fd94b92ff9f51242ab3db38cff4e5f27b705ee3645613843bcfc2(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v593;switch(a0.c){
case 0:{
const v599=dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[3]);
const v595=__node(0,[a0.a[0],a0.a[1],a0.a[2],v599,a0.a[4]]);
v593=v595;break;}
case 1:{
const v605=dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0.a[2]);
const v602=__node(1,[a0.a[0],a0.a[1],v605]);
v593=v602;break;}
default:throw Error('literal constructor projection');}
return v593;}finally{__directDepth--;}}
function dFast_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0,a1,a2){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v607;switch(a0.c){
case 0:{
const v609=__node(1,[a1,a2]);
v607=v609;break;}
case 1:{
const v613=(a1)<(a0.a[0]);
let v612;if(v613){
const v617=__node(1,[a1,a2]);
const v620=__node(1,[a0.a[0],a0.a[1]]);
const v616=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v617,v620);
v612=v616;}else{
const v624=__node(1,[a0.a[0],a0.a[1]]);
const v627=__node(1,[a1,a2]);
const v623=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v624,v627);
v612=v623;}
v607=v612;break;}
case 2:{
const v633=d_33cb437b4635cf97d1432adf5fa704f96098a5dcdf2145356c6b147fc5db53b3(a0.a[0]);
const v631=(a1)<(v633);
let v630;if(v631){
const v636=dFast_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[0],a1,a2);
const v635=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(v636,a0.a[1]);
v630=v635;}else{
const v643=dFast_f164be79137c4feecda8b0c95f9c4e6051393512cfb8310647e1e12726f07cc9(a0.a[1],a1,a2);
const v641=dFast_39fdb49f21e47ef59bea4dece9690ec239474e73f3b69a62d9eb8cce5ac9392e(a0.a[0],v643);
v630=v641;}
v607=v630;break;}
default:throw Error('literal constructor projection');}
return v607;}finally{__directDepth--;}}
function dFast_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v647;switch(a0.c){
case 0:{
const v649=0n;
v647=v649;break;}
case 1:{
const v652=dFast_f4382357257997dc9baee0b6ecf9b6cc766701993418e72196ead925a3c78422(a0.a[1]);
const v650=BigInt.asUintN(64,(a0.a[0])+(v652));
v647=v650;break;}
default:throw Error('literal constructor projection');}
return v647;}finally{__directDepth--;}}
function dFast_q_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v654;switch(a0.c){
case 0:{
let v656;switch(a0.a[0].c){
case 0:{
const v658=0n;
v656=v658;break;}
case 1:{
const v659=dFast_2937ee59437d4727fd243a664a281a6018453ca819aede4e91f0a7d9bda2ca12(a0.a[0].a[1]);
v656=v659;break;}
case 2:{
v656=a0.a[0].a[4];break;}
default:throw Error('literal constructor projection');}
v654=v656;break;}
default:throw Error('literal constructor projection');}
return v654;}finally{__directDepth--;}}
function dFast_q_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v662;switch(a0.c){
case 0:{
let v664;switch(a0.a[0].c){
case 0:{
const v666=0n;
v664=v666;break;}
case 1:{
const v667=dFast_2a975b3a5fe826968db8619175ac9f0dfbf3be2c770a2eab7b9bb32e684cf01b(a0.a[0].a[1]);
v664=v667;break;}
case 2:{
v664=a0.a[0].a[5];break;}
default:throw Error('literal constructor projection');}
v662=v664;break;}
default:throw Error('literal constructor projection');}
return v662;}finally{__directDepth--;}}
function f_186b6350f974a9daf5c57b97446437bb2cabe2a9241d8e38d84e02980089fef8(a0){return d_186b6350f974a9daf5c57b97446437bb2cabe2a9241d8e38d84e02980089fef8(a0);}
function f_2227a6ba7041bd43fcef1b26000ccf84bfe9666af2f812e03de515c517d771d0(a0){try{return dFast_2227a6ba7041bd43fcef1b26000ccf84bfe9666af2f812e03de515c517d771d0(a0);}catch(error){if(error!==__deepCall)throw error;return __run(d_2227a6ba7041bd43fcef1b26000ccf84bfe9666af2f812e03de515c517d771d0(a0));}}
function f_2d15d039af07da09e966dbb56adcd73b313da516d054674d5f55c495085b08bd(a0){try{return dFast_2d15d039af07da09e966dbb56adcd73b313da516d054674d5f55c495085b08bd(a0);}catch(error){if(error!==__deepCall)throw error;return __run(d_2d15d039af07da09e966dbb56adcd73b313da516d054674d5f55c495085b08bd(a0));}}
function f_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(a0){try{return dFast_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(a0);}catch(error){if(error!==__deepCall)throw error;return __run(d_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(a0));}}
function f_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(a0,a1,a2,a3,a4,a5){try{return dFast_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(a0,a1,a2,a3,a4,a5);}catch(error){if(error!==__deepCall)throw error;return __run(d_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(a0,a1,a2,a3,a4,a5));}}
function f_4d9946ad9a037d55daebbf6b4f332ecf1e985eca512336e0f0bb06e1d923e74d(a0){return d_4d9946ad9a037d55daebbf6b4f332ecf1e985eca512336e0f0bb06e1d923e74d(a0);}
function f_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1){try{return dFast_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1);}catch(error){if(error!==__deepCall)throw error;return __run(d_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1));}}
function f_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(a0,a1,a2,a3){try{return dFast_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(a0,a1,a2,a3);}catch(error){if(error!==__deepCall)throw error;return __run(d_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(a0,a1,a2,a3));}}
function f_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0){try{return dFast_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0);}catch(error){if(error!==__deepCall)throw error;return __run(d_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(a0));}}
function f_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1){try{return dFast_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1);}catch(error){if(error!==__deepCall)throw error;return __run(d_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1));}}
function f_e76afcdc421fd94b92ff9f51242ab3db38cff4e5f27b705ee3645613843bcfc2(a0){try{return dFast_e76afcdc421fd94b92ff9f51242ab3db38cff4e5f27b705ee3645613843bcfc2(a0);}catch(error){if(error!==__deepCall)throw error;return __run(d_e76afcdc421fd94b92ff9f51242ab3db38cff4e5f27b705ee3645613843bcfc2(a0));}}
function f_08d94601ac1aa2ed93b41bdd0a8554f32110869bd547d78880f4da001de33883(a0){return d_08d94601ac1aa2ed93b41bdd0a8554f32110869bd547d78880f4da001de33883(a0);}
function f_d0c069f5e4d74cddcd676b884d3c209df73106f994fb0b83d77481fc2dd559a0(a0){return d_d0c069f5e4d74cddcd676b884d3c209df73106f994fb0b83d77481fc2dd559a0(a0);}
function f_f8b201f9576cf5f758072d19d59fc2103838413eaff9a64f4a5aa01b90455187(a0){return d_f8b201f9576cf5f758072d19d59fc2103838413eaff9a64f4a5aa01b90455187(a0);}
function f_q_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1){try{return dFast_q_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1);}catch(error){if(error!==__deepCall)throw error;return __run(d_q_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(a0,a1));}}
function f_q_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1){try{return dFast_q_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1);}catch(error){if(error!==__deepCall)throw error;return __run(d_q_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(a0,a1));}}
const __encoder=new TextEncoder();
function __keyCompare(a,b){if(typeof a==='string'&&typeof b==='string'){const x=__encoder.encode(a),y=__encoder.encode(b);for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]<y[i]?-1:1;return x.length-y.length;}return a<b?-1:a>b?1:0;}

// Portable snapshot ABI shared with native/Wasm. Hashing uses Web Crypto.
function __snapshotLimits(limits={}){
 const result={bytes:64*1024*1024,values:1000000,depth:128,...limits};
 for(const k of ['bytes','values','depth'])if(!Number.isSafeInteger(result[k])||result[k]<0||result[k]>(k==='depth'?128:k==='values'?1000000:64*1024*1024))throw Error('invalid snapshot limits');
 return result;
}
const __hash=async bytes=>new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256',bytes));
function __snapshotWriter(limits){
 const out=[];let left=limits.values;
 function bytes(xs){if(xs.length>limits.bytes-out.length)throw Error('snapshot byte limit exceeded');for(const x of xs)out.push(x);}
 function integer(n,size){n=BigInt(n);for(let i=0;i<size;i++){bytes([Number(n&255n)]);n>>=8n;}}
 function raw(xs){integer(xs.length,8);bytes(xs);}
 function value(v,t,depth=0,bindings=[]){if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{value(v,t.body,depth+1,bindings);}finally{bindings.pop();}break;
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');value(v,bound[1],depth+1,bindings);break;}
  case 'unit':break;case 'bool':bytes([v?1:0]);break;
  case 'u32':case 'i32':case 'f32':integer(v,4);break;case 'u64':integer(v,8);break;
  case 'vector':if(v.length!==t.size)throw Error('vector dimension mismatch');for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'int':{let n=v<0n?-v:v;const xs=[];while(n){if(xs.length>=4096)throw Error('snapshot Int exceeds size limit');xs.push(Number(n&255n));n>>=8n;}bytes([v===0n?0:v>0n?1:2]);raw(xs);break;}
  case 'string':raw(__encoder.encode(v));break;
  case 'id':integer(BigInt('0x'+v),16);break;
  case 'enum':integer(t.variants.indexOf(v),4);break;
  case 'record':for(const f of t.fields)value(v[f.name],f.type,depth+1,bindings);break;
  case 'list':if(v.length>left)throw Error('snapshot value limit exceeded');integer(v.length,8);for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'option':if(Object.hasOwn(v,'Some')){bytes([1]);value(v.Some,t.element,depth+1,bindings);}else bytes([0]);break;
  case 'result':if(Object.hasOwn(v,'Ok')){bytes([0]);value(v.Ok,t.ok,depth+1,bindings);}else{bytes([1]);value(v.Err,t.error,depth+1,bindings);}break;
  default:throw Error('unsupported snapshot type');
 }}
 return {bytes,integer,raw,value,get left(){return left;},finish:()=>new Uint8Array(out)};
}
async function __snapshotEncode(meta,state,options){
 const limits=__snapshotLimits(options),w=__snapshotWriter(limits);
 w.integer(state.version,8);
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const rows=[...state.tables[r.index].entries()].sort((a,b)=>__keyCompare(a[0],b[0],r.key));if(rows.length>Math.floor(w.left/2))throw Error('snapshot row limit exceeded');w.integer(rows.length,8);for(const [k,v]of rows){w.value(k,r.snapshotKey??r.key);w.value(v,r.snapshotValue??r.value);}}
 w.integer(state.outbox.length,8);
 for(const e of state.outbox){const channel=meta.events.findIndex(t=>t.name===e.channel);w.integer(e.commit,8);w.integer(e.position,8);w.integer(channel,4);w.value(e.value,meta.events[channel].snapshotType??meta.events[channel].type);}
 const payload=w.finish(),header=__snapshotWriter(limits);header.bytes([86,76,83,84,65,84,69,0,1,0,1,0]);header.bytes(meta.snapshot.program);header.bytes(meta.snapshot.schema);header.integer(payload.length,8);header.bytes(payload);
 const bytes=header.finish();if(bytes.length+32>limits.bytes)throw Error('snapshot byte limit exceeded');const digest=await __hash(bytes);const result=new Uint8Array(bytes.length+32);result.set(bytes);result.set(digest,bytes.length);return result;
}
async function __snapshotDecode(meta,input,options){
 const limits=__snapshotLimits(options);
 if(!(input instanceof Uint8Array)&&!Array.isArray(input))throw Error('expected snapshot bytes');
 if(input.length>limits.bytes||input.length<116)throw Error('snapshot byte length invalid');
 if(Array.isArray(input)&&input.some(b=>!Number.isInteger(b)||b<0||b>255))throw Error('invalid snapshot bytes');
 const bytes=new Uint8Array(input); // capture before asynchronous integrity work
 function same(a,b){return a.length===b.length&&a.every((v,i)=>v===b[i]);}
 if(!same(bytes.subarray(0,12),[86,76,83,84,65,84,69,0,1,0,1,0]))throw Error('snapshot format or semantics version mismatch');
 if(!same(bytes.subarray(12,44),meta.snapshot.program)||!same(bytes.subarray(44,76),meta.snapshot.schema))throw Error('snapshot program or schema identity mismatch');
 const end=bytes.length-32,digest=await __hash(bytes.subarray(0,end));if(!same(digest,bytes.subarray(end)))throw Error('snapshot integrity check failed');
 let at=76,left=limits.values;
 function take(n){if(!Number.isSafeInteger(n)||n<0||n>end-at)throw Error('truncated snapshot');const x=bytes.subarray(at,at+n);at+=n;return x;}
 function integer(size){const xs=take(size);let n=0n;for(let i=size-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return n;}
 function length(){const n=integer(8);if(n>BigInt(Number.MAX_SAFE_INTEGER))throw Error('snapshot length not addressable');return Number(n);}
 function sequence(){const n=length();if(n>left)throw Error('snapshot value limit exceeded');return n;}
 function raw(){return take(length());}
 const n=length();if(n!==end-84)throw Error('snapshot payload length mismatch');
 function value(t,depth=0,bindings=[]){if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{return value(t.body,depth+1,bindings);}finally{bindings.pop();}
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');return value(bound[1],depth+1,bindings);}
  case 'unit':return null;case 'bool':{const b=take(1)[0];if(b>1)throw Error('invalid Bool tag');return b===1;}
  case 'u32':case 'f32':return Number(integer(4));case 'i32':return Number(BigInt.asIntN(32,integer(4)));case 'u64':return integer(8);
  case 'vector':{const xs=[];for(let i=0;i<t.size;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'int':{const sign=take(1)[0],xs=raw();if(xs.length>4096)throw Error('snapshot Int exceeds size limit');if(!((sign===0&&xs.length===0)||((sign===1||sign===2)&&xs.length>0&&xs[xs.length-1]!==0)))throw Error('noncanonical signed integer');let n=0n;for(let i=xs.length-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return sign===2?-n:n;}
  case 'string':return new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(raw());
  case 'id':return integer(16).toString(16).padStart(32,'0');
  case 'enum':{const i=Number(integer(4));if(i>=t.variants.length)throw Error('invalid enum tag');return t.variants[i];}
  case 'record':return Object.fromEntries(t.fields.map(f=>[f.name,value(f.type,depth+1,bindings)]));
  case 'list':{const n=sequence(),xs=[];for(let i=0;i<n;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'option':{const tag=take(1)[0];if(tag===0)return {None:null};if(tag===1)return {Some:value(t.element,depth+1,bindings)};throw Error('invalid Option tag');}
  case 'result':{const tag=take(1)[0];if(tag===0)return {Ok:value(t.ok,depth+1,bindings)};if(tag===1)return {Err:value(t.error,depth+1,bindings)};throw Error('invalid Result tag');}
  default:throw Error('unsupported snapshot type');
 }}
 const version=integer(8),tables=meta.roots.map(()=>new Map());
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const n=sequence();if(n>Math.floor(left/2))throw Error('snapshot row limit exceeded');let prior;for(let i=0;i<n;i++){const k=value(r.snapshotKey??r.key),v=value(r.snapshotValue??r.value);if(i&&__keyCompare(prior,k,r.key)>=0)throw Error('duplicate or unordered snapshot key');tables[r.index].set(k,v);prior=k;}}
 const count=sequence(),outbox=[];let prior;
 for(let i=0;i<count;i++){const commit=integer(8),position=integer(8),channel=Number(integer(4));if(!meta.events[channel])throw Error('unknown snapshot event channel');const v=value(meta.events[channel].snapshotType??meta.events[channel].type);if(commit===0n||commit>version||(prior&&(commit<prior.commit||(commit===prior.commit&&position<=prior.position))))throw Error('invalid snapshot event sequence');const e={commit,position,channel:meta.events[channel].name,value:v};outbox.push(e);prior=e;}
 if(at!==end)throw Error('trailing snapshot payload');return {version,tables,outbox};
}
function read_0(v,d=0,internal=false){return v;}
function write_0(v,d=0,snapshot=false){return v;}
function read_1(v,d=0,internal=false){return v;}
function write_1(v,d=0,snapshot=false){return v;}
function read_2(v,d=0,internal=false){return __node(0,[]);}
function write_2(v,d=0,snapshot=false){return null;}
function read_3(v,d=0,internal=false){let tail=__node(0,[]);for(let i=v.length-1;i>=0;i--)tail=__node(1,[read_1(v[i],d+1,internal),tail]);return tail;}
function write_3(v,d=0,snapshot=false){let cursor=v;const xs=[];while(cursor.c!==0){xs.push(write_1(cursor.a[0],d+1,snapshot));cursor=cursor.a[1];}return xs;}
function read_4(v,d=0,internal=false){let tail=__node(0,[]);for(let i=v.length-1;i>=0;i--)tail=__node(1,[read_6(v[i],d+1,internal),tail]);return tail;}
function write_4(v,d=0,snapshot=false){let cursor=v;const xs=[];while(cursor.c!==0){xs.push(write_6(cursor.a[0],d+1,snapshot));cursor=cursor.a[1];}return xs;}
function read_5(v,d=0,internal=false){switch(v){case "Error.Failed":return __node(0,[]);default:return undefined;}}
function write_5(v,d=0,snapshot=false){return ["Error.Failed"][v.c];}
function read_6(v,d=0,internal=false){return __node(0,[read_1(v["value"],d+1,internal),read_0(v["active"],d+1,internal)]);}
function write_6(v,d=0,snapshot=false){return Object.fromEntries([["value",write_1(v.a[0],d+1,snapshot)],["active",write_0(v.a[1],d+1,snapshot)]]);}
function read_7(v,d=0,internal=false){if(Object.hasOwn(v,'Some'))return __node(1,[read_6(v.Some,d+1,internal)]);return __node(0,[]);}
function write_7(v,d=0,snapshot=false){return v.c===0?{None:null}:{Some:write_6(v.a[0],d+1,snapshot)};}
function read_8(v,d=0,internal=false){if(Object.hasOwn(v,'Ok'))return __node(0,[read_2(v.Ok,d+1,internal)]);return __node(1,[read_5(v.Err,d+1,internal)]);}
function write_8(v,d=0,snapshot=false){return v.c===0?{Ok:write_2(v.a[0],d+1,snapshot)}:{Err:write_5(v.a[0],d+1,snapshot)};}
const __meta={"events":[{"name":"seen","snapshotType":{"kind":"u64"},"type":{"kind":"u64"}}],"roots":[{"key":{"kind":"u64"},"name":"Rows","snapshotKey":{"kind":"u64"},"snapshotValue":{"fields":[{"name":"value","type":{"kind":"u64"}},{"name":"active","type":{"kind":"bool"}}],"kind":"record"},"value":{"fields":[{"name":"value","type":{"kind":"u64"}},{"name":"active","type":{"kind":"bool"}}],"kind":"record","name":"Row"}}],"snapshot":{"program":[52,20,97,227,197,216,139,58,45,98,73,196,205,50,83,26,202,227,210,13,109,164,33,109,207,238,49,79,213,123,165,218],"schema":[217,47,159,252,204,85,237,70,76,82,248,36,231,99,128,206,40,43,134,247,81,235,124,169,208,7,125,5,136,138,247,164]}};
function __fromTables(tables){const roots=[];
{const rows=[...tables[0].entries()];let prior,tail=__node(0,[]);for(let j=rows.length-1;j>=0;j--){const [key,value]=rows[j];tail=__node(1,[read_1(key,0,true),read_6(value,0,true),tail]);}roots.push(tail);}
return __node(0,roots);}
function __tables(logical){const tables=[];
{let cursor=logical.a[0],prior;const rows=new Map();while(cursor.c!==0){const [key,value,tail]=cursor.a;rows.set(write_1(key,0,true),write_6(value,0,true));cursor=tail;}tables.push(rows);}
return tables;}
function __events(list){const events=[];let cursor=list;while(cursor.c!==0){const [event,tail]=cursor.a;switch(event.c){
case 0:events.push(["seen", write_1(event.a[0],0,true), write_1(event.a[0],0,false)]);break;
default:throw Error('unknown source event');}cursor=tail;}return events;}
// CALLER CONTRACT: arguments must have declared types and canonical values.
// Malformed data may throw, produce wrong results or corrupt state.
export function createState(){let version=0n,outbox=[],busy=false,transaction=null;
const initial=__node(0,[__node(0,[])]);let physical=f_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(initial);
function boundary(){if(busy)throw Error('state operation already in progress');}
function invoke_native(name,args,resultOnly=false){boundary();switch(name){
case "put":{
const a0=read_1(args[0],0);
const a1=read_1(args[1],0);
const a2=read_0(args[2],0);
const a3=read_0(args[3],0);
const executed=f_3b0c0ccd4b91f303b3f560132298b6e179e2746933a6772c9665fa8cca34d037(physical,version,a0,a1,a2,a3);const observed=f_d0c069f5e4d74cddcd676b884d3c209df73106f994fb0b83d77481fc2dd559a0(executed),next=f_4d9946ad9a037d55daebbf6b4f332ecf1e985eca512336e0f0bb06e1d923e74d(executed);if(observed.c===1)throw Error('commit sequence exhausted');const [reply,committed,newVersion,,events]=observed.a;const result=write_8(reply,0,false),staged=__events(events),published=[];
if(committed){for(let i=0;i<staged.length;i++){const [channel,value,publicValue]=staged[i];outbox.push({commit:newVersion,position:BigInt(i),channel,value});if(!resultOnly)published.push({commit:newVersion,position:BigInt(i),channel,value:publicValue});}}physical=next;version=newVersion;return resultOnly?result:{result,committed,version,events:published};}
case "erase":{
const a0=read_1(args[0],0);
const a1=read_0(args[1],0);
const executed=f_a30c0ace3df642a1b8bb987b0b4d92e42f1f5989252275039eac2b19b8e2f8cf(physical,version,a0,a1);const observed=f_d0c069f5e4d74cddcd676b884d3c209df73106f994fb0b83d77481fc2dd559a0(executed),next=f_4d9946ad9a037d55daebbf6b4f332ecf1e985eca512336e0f0bb06e1d923e74d(executed);if(observed.c===1)throw Error('commit sequence exhausted');const [reply,committed,newVersion,,events]=observed.a;const result=write_8(reply,0,false),staged=__events(events),published=[];
if(committed){for(let i=0;i<staged.length;i++){const [channel,value,publicValue]=staged[i];outbox.push({commit:newVersion,position:BigInt(i),channel,value});if(!resultOnly)published.push({commit:newVersion,position:BigInt(i),channel,value:publicValue});}}physical=next;version=newVersion;return resultOnly?result:{result,committed,version,events:published};}
case "total_query":{
const reply=f_q_6f015cf95d2de57418f6ec4a135049e4c4efe16e1bd8e8e2d897be79d1b5cda2(physical,version);const result=write_1(reply,0,false);return resultOnly?result:{result,committed:false,version,events:[]};}
case "count_query":{
const reply=f_q_e20846c003a8b502d7ad895156c1789be9b8dd4e753f999358335a76133df97f(physical,version);const result=write_1(reply,0,false);return resultOnly?result:{result,committed:false,version,events:[]};}
default:throw Error(`unknown action ${name}`);}}
async function invoke_json(name,args){return invoke_native(name,args);}
const actionNames=new Set(["put","erase","total_query","count_query"]);
return Object.freeze({invoke:invoke_json,invoke_json,bind(name,{resultOnly=false}={}){if(!actionNames.has(name))throw Error(`unknown action ${name}`);return (...args)=>invoke_native(name,args,resultOnly);},beginTransaction(){boundary();if(transaction)throw Error('state transaction already in progress');transaction={physical,version,outbox,length:outbox.length};return true;},commitTransaction(){boundary();if(!transaction)throw Error('no state transaction');transaction=null;},rollbackTransaction(){boundary();if(!transaction)throw Error('no state transaction');physical=transaction.physical;version=transaction.version;outbox=transaction.outbox;outbox.length=transaction.length;transaction=null;},get version(){return version;},get outbox(){return outbox.map(e=>({...e,value:__publicEvent(e.channel,e.value)}));},acknowledge_through(commit,position){boundary();commit=BigInt(commit);position=BigInt(position);outbox=outbox.filter(e=>e.commit>commit||(e.commit===commit&&e.position>position));},async checkpoint(limits){boundary();
const logical=f_b7826aae147e8886f18fda462f945afd80c7cde8cda9e79cef27e33f8a6fcf2e(physical);return __snapshotEncode(__meta,{version,tables:__tables(logical),outbox},limits);},async restore(bytes,limits){boundary();if(transaction)throw Error('restore during state transaction');busy=true;try{const saved=await __snapshotDecode(__meta,bytes,limits);const logical=__fromTables(saved.tables);const next=f_378fe8760941738df4a2ee37fb2ec528d1a07b3b9e12ffcf79558a65c32829f4(logical);physical=next;version=saved.version;outbox=saved.outbox;}finally{busy=false;}}});}
function __publicEvent(channel,value){switch(channel){
case "seen":return write_1(read_1(value,0,true),0,false);
default:throw Error('unknown source event');}}
