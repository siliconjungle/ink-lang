#![allow(non_camel_case_types,non_snake_case,unused_variables,unused_parens,dead_code)]
pub const INK_TABLE_STORAGE:&str="ordered";
pub const INK_ABI_CONTRACT:&str="{\"abi\":\"ink-values-v1\",\"actions\":[{\"name\":\"initialize\",\"params\":[],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"kind\":\"unit\"}}},{\"name\":\"retarget\",\"params\":[{\"name\":\"samples\",\"type\":{\"element\":{\"fields\":[{\"name\":\"input\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"target\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"Example\"},\"kind\":\"list\"}},{\"name\":\"instruction_cost\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"expected\",\"type\":{\"kind\":\"u32\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"kind\":\"u32\"}}},{\"name\":\"retune\",\"params\":[{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"Coefficients\"}},{\"name\":\"fail\",\"type\":{\"kind\":\"bool\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"kind\":\"unit\"}}},{\"name\":\"episode\",\"params\":[{\"name\":\"units\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"rate\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"goal_version\",\"type\":{\"kind\":\"u32\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"fields\":[{\"name\":\"step\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"loss\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"best\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"accepted\",\"type\":{\"kind\":\"bool\"}},{\"name\":\"goal_version\",\"type\":{\"kind\":\"u32\"}}],\"kind\":\"record\",\"name\":\"Report\"}}},{\"name\":\"aborted\",\"params\":[{\"name\":\"units\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"rate\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"goal_version\",\"type\":{\"kind\":\"u32\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"kind\":\"unit\"}}},{\"name\":\"serve\",\"params\":[{\"name\":\"input\",\"type\":{\"kind\":\"f32\"}}],\"result\":{\"kind\":\"f32\"}},{\"name\":\"structure\",\"params\":[],\"result\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}},{\"name\":\"policy\",\"params\":[],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"fields\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"first\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"second\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"steps\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"first_power\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_power\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab\"}}},{\"name\":\"loss\",\"params\":[],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"kind\":\"f32\"}}},{\"name\":\"set_live\",\"params\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}}],\"result\":{\"kind\":\"unit\"}}],\"functions\":[{\"name\":\"evaluate\",\"params\":[{\"name\":\"code\",\"type\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}},{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"Coefficients\"}},{\"name\":\"input\",\"type\":{\"kind\":\"f32\"}}],\"result\":{\"kind\":\"f32\"}},{\"name\":\"coefficients_valid\",\"params\":[{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"Coefficients\"}}],\"result\":{\"kind\":\"bool\"}},{\"name\":\"goal_valid\",\"params\":[{\"name\":\"g\",\"type\":{\"fields\":[{\"name\":\"samples\",\"type\":{\"element\":{\"fields\":[{\"name\":\"input\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"target\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"Example\"},\"kind\":\"list\"}},{\"name\":\"instruction_cost\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"version\",\"type\":{\"kind\":\"u32\"}}],\"kind\":\"record\",\"name\":\"Goal\"}}],\"result\":{\"kind\":\"bool\"}},{\"name\":\"squared_error\",\"params\":[{\"name\":\"code\",\"type\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}},{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"Coefficients\"}},{\"name\":\"s\",\"type\":{\"fields\":[{\"name\":\"input\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"target\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"Example\"}}],\"result\":{\"kind\":\"f32\"}},{\"name\":\"objective\",\"params\":[{\"name\":\"code\",\"type\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}},{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"Coefficients\"}},{\"name\":\"g\",\"type\":{\"fields\":[{\"name\":\"samples\",\"type\":{\"element\":{\"fields\":[{\"name\":\"input\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"target\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"Example\"},\"kind\":\"list\"}},{\"name\":\"instruction_cost\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"version\",\"type\":{\"kind\":\"u32\"}}],\"kind\":\"record\",\"name\":\"Goal\"}}],\"result\":{\"kind\":\"f32\"}},{\"name\":\"unpack\",\"params\":[{\"name\":\"xs\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"result\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}}],\"kind\":\"record\",\"name\":\"Parameters\"}},{\"name\":\"pack\",\"params\":[{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}}],\"kind\":\"record\",\"name\":\"Parameters\"}}],\"result\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"mass\",\"params\":[{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}}],\"kind\":\"record\",\"name\":\"Parameters\"}},{\"name\":\"p\",\"type\":{\"fields\":[{\"name\":\"slot\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"operation\",\"type\":{\"kind\":\"u32\"}}],\"kind\":\"record\",\"name\":\"Pick\"}}],\"result\":{\"kind\":\"f32\"}},{\"name\":\"operation\",\"params\":[{\"name\":\"index\",\"type\":{\"kind\":\"u32\"}}],\"result\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]}},{\"name\":\"distribution\",\"params\":[{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}}],\"kind\":\"record\",\"name\":\"Parameters\"}},{\"name\":\"slot\",\"type\":{\"kind\":\"u32\"}}],\"result\":{\"fields\":[{\"name\":\"masses\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"derivatives\",\"type\":{\"element\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"Distribution\"}},{\"name\":\"sample_slot\",\"params\":[{\"name\":\"accumulator\",\"type\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"fields\":[{\"name\":\"choices\",\"type\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}},{\"name\":\"decisions\",\"type\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"Building\"}}},{\"name\":\"slot\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}}],\"kind\":\"record\",\"name\":\"Parameters\"}},{\"name\":\"units\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"fields\":[{\"name\":\"choices\",\"type\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}},{\"name\":\"decisions\",\"type\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"Building\"}}},{\"name\":\"sample\",\"params\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"units\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"fields\":[{\"name\":\"code\",\"type\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}},{\"name\":\"decisions\",\"type\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"Sampled\"}}},{\"name\":\"reward\",\"params\":[{\"name\":\"loss\",\"type\":{\"kind\":\"f32\"}}],\"result\":{\"kind\":\"f32\"}},{\"name\":\"operation_index\",\"params\":[{\"name\":\"op\",\"type\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]}}],\"result\":{\"kind\":\"u32\"}},{\"name\":\"elite_slot\",\"params\":[{\"name\":\"accumulator\",\"type\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}}},{\"name\":\"slot\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}}],\"kind\":\"record\",\"name\":\"Parameters\"}},{\"name\":\"code\",\"type\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}}},{\"name\":\"proposal_gradient\",\"params\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"selected\",\"type\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}},{\"name\":\"sampled\",\"type\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}},{\"name\":\"loss\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"before\",\"type\":{\"kind\":\"f32\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}},{\"name\":\"valid_policy\",\"params\":[{\"name\":\"p\",\"type\":{\"fields\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"first\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"second\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"steps\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"first_power\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_power\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab\"}}],\"result\":{\"kind\":\"bool\"}},{\"name\":\"numeric\",\"params\":[{\"name\":\"xs\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"result\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54\",\"params\":[{\"name\":\"xs\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"result\":{\"kind\":\"bool\"}},{\"name\":\"ink_m28a5428efa573345218636e9cec104f24b6e8c67d7c4c0f979b255813b2abee3\",\"params\":[{\"name\":\"masses\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"allowed\",\"type\":{\"element\":{\"kind\":\"bool\"},\"kind\":\"list\"}}],\"result\":{\"kind\":\"f32\"}},{\"name\":\"ink_mfd18151b0af45b45f5b48ef5e7a09ac1294681f654e2174ae3b33183f445ef14\",\"params\":[{\"name\":\"masses\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"allowed\",\"type\":{\"element\":{\"kind\":\"bool\"},\"kind\":\"list\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}},{\"name\":\"ink_mc05a2256079ef1f1818d13e69727dc7902cdb7f70856a671af2ba08ef190d23a\",\"params\":[{\"name\":\"masses\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"allowed\",\"type\":{\"element\":{\"kind\":\"bool\"},\"kind\":\"list\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}},{\"name\":\"ink_m6ec6e8f9e757c220bfe2ed28cbb8dab4ec520de5ee8de5ca702cbdb805a5f910\",\"params\":[{\"name\":\"scaled\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"unit\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"total\",\"type\":{\"kind\":\"f32\"}}],\"result\":{\"kind\":\"u32\"}},{\"name\":\"ink_maa2c8802d351b443dda0bc206d70fa9fe87756b57a84d0357e9dfb4c1e7a0667\",\"params\":[{\"name\":\"derivatives\",\"type\":{\"element\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"},\"kind\":\"list\"}},{\"name\":\"allowed\",\"type\":{\"element\":{\"kind\":\"bool\"},\"kind\":\"list\"}},{\"name\":\"maximum\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"total\",\"type\":{\"kind\":\"f32\"}}],\"result\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"ink_m1774c4db693eebe71b1f79bce053b93633d1e1ec37196dd480b59c0248b4fbc2\",\"params\":[{\"name\":\"masses\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"derivatives\",\"type\":{\"element\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"},\"kind\":\"list\"}},{\"name\":\"allowed\",\"type\":{\"element\":{\"kind\":\"bool\"},\"kind\":\"list\"}},{\"name\":\"total\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"selected\",\"type\":{\"kind\":\"u32\"}}],\"result\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"ink_m1fbf7ee6cef3bcca5d7d258c8606275806894b60d839126202d17f016ea87c80\",\"params\":[{\"name\":\"masses\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"derivatives\",\"type\":{\"element\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"},\"kind\":\"list\"}},{\"name\":\"allowed\",\"type\":{\"element\":{\"kind\":\"bool\"},\"kind\":\"list\"}},{\"name\":\"unit\",\"type\":{\"kind\":\"f32\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"}}},{\"name\":\"ink_m99468fca85aa8fb996f0c891430c813d82505250d39d8e415bf27679ddc39e07\",\"params\":[{\"name\":\"masses\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"derivatives\",\"type\":{\"element\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"},\"kind\":\"list\"}},{\"name\":\"allowed\",\"type\":{\"element\":{\"kind\":\"bool\"},\"kind\":\"list\"}},{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"}}},{\"name\":\"ink_maadd6c30a027af52d851f0828eec45339d218ad3bbe73e4d8d7cdd3892e754f4\",\"params\":[{\"name\":\"decision\",\"type\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"}},{\"name\":\"return_value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"baseline\",\"type\":{\"kind\":\"f32\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}},{\"name\":\"ink_m696809152e57d8dfa3f01f9a3e12c048434b9f2af91ff53321ea6ceeeeca5431\",\"params\":[{\"name\":\"accumulator\",\"type\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}},{\"name\":\"decision\",\"type\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"}},{\"name\":\"return_value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"baseline\",\"type\":{\"kind\":\"f32\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}},{\"name\":\"ink_m372cbaf2ee2bc8705fad4b5b65a9e744ea468afbe4c153f17c7da282a459d1cd\",\"params\":[{\"name\":\"decisions\",\"type\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}},{\"name\":\"return_values\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"baselines\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}},{\"name\":\"ink_m43c1e2ac4d6d9a37358654ff5c1abcd42d4b01146c41a7ca617bccb074a8813b\",\"params\":[{\"name\":\"decisions\",\"type\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}},{\"name\":\"return_values\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"baselines\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}},{\"name\":\"ink_m4b5ada8f7d6b3beaee6fc06bf68e61ca158cbc7664899364dff18d21555697ae\",\"params\":[{\"name\":\"decisions\",\"type\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}},{\"name\":\"return_value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"baseline\",\"type\":{\"kind\":\"f32\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}},{\"name\":\"ink_mda500f665e6078213ee2391fedf06240c651d1725327b086aa70cda14bef9a07\",\"params\":[{\"name\":\"rewards\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"discount\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bootstrap\",\"type\":{\"kind\":\"f32\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}},{\"name\":\"ink_meefc22a28d97f5bdc4100b36eeab9549241c3ef201b83c2f75111644d317833d\",\"params\":[{\"name\":\"rate\",\"type\":{\"kind\":\"f32\"}}],\"result\":{\"fields\":[{\"name\":\"rate\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"first_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"epsilon\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"weight_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"norm_limit\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249\"}},{\"name\":\"ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96\",\"params\":[{\"name\":\"xs\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"result\":{\"kind\":\"bool\"}},{\"name\":\"ink_m786bdc6011aece08dbf36c5ca89c437e06ff758c9d3d242f723dde2af6ea31db\",\"params\":[{\"name\":\"state\",\"type\":{\"fields\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"first\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"second\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"steps\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"first_power\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_power\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab\"}}],\"result\":{\"kind\":\"bool\"}},{\"name\":\"ink_mdfbd57a9f460147afedb262e2bfe0f6197f9b813c85277c59f5e101900063ad7\",\"params\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"fields\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"first\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"second\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"steps\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"first_power\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_power\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab\"}}},{\"name\":\"ink_m5226ad25deae5e47d7fb65b6b5961d46740dd4e97b54d76a24d3d0445845fe35\",\"params\":[{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"rate\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"first_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"epsilon\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"weight_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"norm_limit\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249\"}}],\"result\":{\"kind\":\"bool\"}},{\"name\":\"ink_m8abb6b2bcbe55251e0b82a28f26d7ce761729346e35019c2b60ca9b5ee22590d\",\"params\":[{\"name\":\"x\",\"type\":{\"kind\":\"f32\"}}],\"result\":{\"kind\":\"f32\"}},{\"name\":\"ink_m7d03a2ed6071238ff1b69a8e56a8cb96b9dc3b095b2d939c0ccfed84ee9580b5\",\"params\":[{\"name\":\"xs\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"limit\",\"type\":{\"kind\":\"f32\"}}],\"result\":{\"kind\":\"f32\"}},{\"name\":\"ink_m00ba8185ca362d257d138fe1886cbc5f3acc38c4a238bef60c3d3d7fa0276eab\",\"params\":[{\"name\":\"weight\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"first\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"first_power\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_power\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"rate\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"first_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"epsilon\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"weight_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"norm_limit\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249\"}}],\"result\":{\"kind\":\"f32\"}},{\"name\":\"ink_m2a55f95a80595bc61d1fcab41ff00f438ff6f2057b597df20aaae3c18507d2be\",\"params\":[{\"name\":\"state\",\"type\":{\"fields\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"first\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"second\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"steps\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"first_power\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_power\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab\"}},{\"name\":\"gradient\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"rate\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"first_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"epsilon\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"weight_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"norm_limit\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249\"}}],\"result\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"fields\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"first\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"second\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"steps\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"first_power\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_power\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab\"}}},{\"name\":\"__ink_differential_3\",\"params\":[{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"scale\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"bias\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"relu\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_5\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"scale\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"bias\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"relu\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_5\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"scale\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"bias\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"relu\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_5\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"scale\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"bias\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"relu\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_5\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_4\"}},{\"name\":\"p\",\"type\":{\"fields\":[{\"name\":\"slot\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"operation\",\"type\":{\"kind\":\"u32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_6\"}}],\"result\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"__ink_differential_1\",\"params\":[{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}}],\"kind\":\"record\",\"name\":\"Parameters\"}},{\"name\":\"p\",\"type\":{\"fields\":[{\"name\":\"slot\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"operation\",\"type\":{\"kind\":\"u32\"}}],\"kind\":\"record\",\"name\":\"Pick\"}}],\"result\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}}],\"kind\":\"record\",\"name\":\"Parameters\"}}]}";
pub const INK_VALUE_ABI:&str="ink-values-v1";
pub const INK_WIRE_CONTRACT:&str="{\"format\":\"ink-value-wire-v1\",\"functions\":{\"__ink_differential_1\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"d9a2817b6f5795592e5f12e4e54fd3af0061b7a04d8d3e55dd63c3a2e7b0558e\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}}],\"kind\":\"record\",\"name\":\"Parameters\"}},{\"name\":\"p\",\"type\":{\"fields\":[{\"name\":\"slot\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"operation\",\"type\":{\"kind\":\"u32\"}}],\"kind\":\"record\",\"name\":\"Pick\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"2af269616d48554c4ef5e8a1371afd52412f1ef4f05c2d9506bd43bfde5de326\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}}],\"kind\":\"record\",\"name\":\"Parameters\"}}},\"__ink_differential_3\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"d75895cfaa56f5921632cb59e1d374ad909ca98b00fd2271f993b80ac8cdcc66\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"scale\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"bias\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"relu\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_5\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"scale\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"bias\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"relu\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_5\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"scale\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"bias\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"relu\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_5\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"scale\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"bias\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}},{\"name\":\"relu\",\"type\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_5\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_4\"}},{\"name\":\"p\",\"type\":{\"fields\":[{\"name\":\"slot\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"operation\",\"type\":{\"kind\":\"u32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_6\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"cfdb397c2afc9c623de1f1010b9630cbab4a4f82a83884720c53cd04425275d8\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_0\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_1\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_2\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_3\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_4\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_5\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_6\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_7\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_8\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_9\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_10\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_11\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_12\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_13\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_14\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"tangent_15\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"__ink_differential_2\"}}},\"coefficients_valid\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"2e1de3e6be85620514132feea03f80ad75ab3cacb5ac40c3715611efdc2a8a0a\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"Coefficients\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176\",\"named\":{},\"root\":{\"kind\":\"bool\"}}},\"distribution\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"28045a638724bf195eaa2c13edf966d6b852033c3212b0f890b11d2bed0a4ee0\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}}],\"kind\":\"record\",\"name\":\"Parameters\"}},{\"name\":\"slot\",\"type\":{\"kind\":\"u32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"b58490b582e9db511b7d71c575e602c19fd38a9ce66a06065b482246605c09a9\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"masses\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"derivatives\",\"type\":{\"element\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"Distribution\"}}},\"elite_slot\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"ad037cb953c14f4fb546dd767f1a0d45caa23b80c581c77178aac95484198504\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"accumulator\",\"type\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}}},{\"name\":\"slot\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}}],\"kind\":\"record\",\"name\":\"Parameters\"}},{\"name\":\"code\",\"type\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"e1b825ef360a6557af5947d501dffff13bf6e9d8532025b04e5cd262660ad2e7\",\"named\":{},\"root\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}}}},\"evaluate\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"714e94324647680288585f759fac356df2eb522ea46759364d96efb96203f7af\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"code\",\"type\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}},{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"Coefficients\"}},{\"name\":\"input\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45\",\"named\":{},\"root\":{\"kind\":\"f32\"}}},\"goal_valid\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"6731468a2fe00d1d59bf0460836be4378e76c6a0830598d58adbf633e915b120\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"g\",\"type\":{\"fields\":[{\"name\":\"samples\",\"type\":{\"element\":{\"fields\":[{\"name\":\"input\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"target\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"Example\"},\"kind\":\"list\"}},{\"name\":\"instruction_cost\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"version\",\"type\":{\"kind\":\"u32\"}}],\"kind\":\"record\",\"name\":\"Goal\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176\",\"named\":{},\"root\":{\"kind\":\"bool\"}}},\"ink_m00ba8185ca362d257d138fe1886cbc5f3acc38c4a238bef60c3d3d7fa0276eab\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"a9d67b7a474f78841986a2160f6d9330ec73efe55bb06560a35a27a22ad078b5\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"weight\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"first\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"first_power\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_power\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"rate\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"first_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"epsilon\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"weight_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"norm_limit\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45\",\"named\":{},\"root\":{\"kind\":\"f32\"}}},\"ink_m1774c4db693eebe71b1f79bce053b93633d1e1ec37196dd480b59c0248b4fbc2\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"48baf4f7fc28a2b3b5df8f3367f2d7cd4d4bccc1c64a334e7433f0c6fd503d4b\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"masses\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"derivatives\",\"type\":{\"element\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"},\"kind\":\"list\"}},{\"name\":\"allowed\",\"type\":{\"element\":{\"kind\":\"bool\"},\"kind\":\"list\"}},{\"name\":\"total\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"selected\",\"type\":{\"kind\":\"u32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477\",\"named\":{},\"root\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}},\"ink_m1fbf7ee6cef3bcca5d7d258c8606275806894b60d839126202d17f016ea87c80\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"1c83630f3139ed38673ed470f191df2b950104eaf550096543a7611da7c50d02\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"masses\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"derivatives\",\"type\":{\"element\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"},\"kind\":\"list\"}},{\"name\":\"allowed\",\"type\":{\"element\":{\"kind\":\"bool\"},\"kind\":\"list\"}},{\"name\":\"unit\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"4c26cf6146a67b60bc34cb27a1b07b25ab14048bb6f0044b09b8e87179b513fa\",\"named\":{},\"root\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"}}}},\"ink_m28a5428efa573345218636e9cec104f24b6e8c67d7c4c0f979b255813b2abee3\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"d02715cce4688c556e60843790a4e59e61ebaad2c9c1064929c6b794d816a06a\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"masses\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"allowed\",\"type\":{\"element\":{\"kind\":\"bool\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45\",\"named\":{},\"root\":{\"kind\":\"f32\"}}},\"ink_m2a55f95a80595bc61d1fcab41ff00f438ff6f2057b597df20aaae3c18507d2be\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"e0ef5b019bff93f73efd86b897d6f35ea8eb8b607d972cd47729126beaf5fafa\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"state\",\"type\":{\"fields\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"first\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"second\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"steps\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"first_power\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_power\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab\"}},{\"name\":\"gradient\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"rate\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"first_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"epsilon\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"weight_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"norm_limit\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"93944e72b897c9246b2efb71a34cebe025e2d57af4d472565578d66dcdc24614\",\"named\":{},\"root\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"fields\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"first\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"second\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"steps\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"first_power\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_power\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab\"}}}},\"ink_m372cbaf2ee2bc8705fad4b5b65a9e744ea468afbe4c153f17c7da282a459d1cd\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"a626656c4896f714c5263b675ceb0f0453e3cae783d93d52d880765e7164cd22\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"decisions\",\"type\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}},{\"name\":\"return_values\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"baselines\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31\",\"named\":{},\"root\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}}},\"ink_m43c1e2ac4d6d9a37358654ff5c1abcd42d4b01146c41a7ca617bccb074a8813b\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"a626656c4896f714c5263b675ceb0f0453e3cae783d93d52d880765e7164cd22\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"decisions\",\"type\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}},{\"name\":\"return_values\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"baselines\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31\",\"named\":{},\"root\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}}},\"ink_m4b5ada8f7d6b3beaee6fc06bf68e61ca158cbc7664899364dff18d21555697ae\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"46abc3d35c147b6bc27332854c2c200b359592fc034ea676178ecfaaa6e4f354\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"decisions\",\"type\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}},{\"name\":\"return_value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"baseline\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31\",\"named\":{},\"root\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}}},\"ink_m5226ad25deae5e47d7fb65b6b5961d46740dd4e97b54d76a24d3d0445845fe35\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"d7bb8db3ffe558eca9f4f6716e44807734e18db170e874ada1038fb500fa33ad\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"rate\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"first_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"epsilon\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"weight_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"norm_limit\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176\",\"named\":{},\"root\":{\"kind\":\"bool\"}}},\"ink_m696809152e57d8dfa3f01f9a3e12c048434b9f2af91ff53321ea6ceeeeca5431\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"c3638b7b9e1ad05ebcb8c60f864d4a1bbb22d0effd3343b6de51dc1abb657d20\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"accumulator\",\"type\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}},{\"name\":\"decision\",\"type\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"}},{\"name\":\"return_value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"baseline\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31\",\"named\":{},\"root\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}}},\"ink_m6ec6e8f9e757c220bfe2ed28cbb8dab4ec520de5ee8de5ca702cbdb805a5f910\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"ea3bdda55cda843ccb548330a20f97b77f397a07d72ef90ae77e37672fe45ca4\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"scaled\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"unit\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"total\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff\",\"named\":{},\"root\":{\"kind\":\"u32\"}}},\"ink_m786bdc6011aece08dbf36c5ca89c437e06ff758c9d3d242f723dde2af6ea31db\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"95732fc2e08ae05f4d215e9e358781620c82dea66fab6ca4ada670422dd62463\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"state\",\"type\":{\"fields\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"first\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"second\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"steps\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"first_power\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_power\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176\",\"named\":{},\"root\":{\"kind\":\"bool\"}}},\"ink_m7d03a2ed6071238ff1b69a8e56a8cb96b9dc3b095b2d939c0ccfed84ee9580b5\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"a7c17d063bba03b64d18b54cb89be038b3c836fdbf7ee6cc9644e5db742a8d67\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"xs\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"limit\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45\",\"named\":{},\"root\":{\"kind\":\"f32\"}}},\"ink_m8abb6b2bcbe55251e0b82a28f26d7ce761729346e35019c2b60ca9b5ee22590d\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"3d9fa005996e654b10e4e749ab0e2c4a9988b4ba944f21f1019c2132cbcb62b2\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"x\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45\",\"named\":{},\"root\":{\"kind\":\"f32\"}}},\"ink_m99468fca85aa8fb996f0c891430c813d82505250d39d8e415bf27679ddc39e07\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"d2aec7a161e83197cb0218fdd61843b82bc48bc0376a0e2d27cb5a10062d48ac\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"masses\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"derivatives\",\"type\":{\"element\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"},\"kind\":\"list\"}},{\"name\":\"allowed\",\"type\":{\"element\":{\"kind\":\"bool\"},\"kind\":\"list\"}},{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"4c26cf6146a67b60bc34cb27a1b07b25ab14048bb6f0044b09b8e87179b513fa\",\"named\":{},\"root\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"}}}},\"ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"7d522496fa90814f2f1e12091142cca8648a00e9c787d158636f57940650d4e4\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"xs\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176\",\"named\":{},\"root\":{\"kind\":\"bool\"}}},\"ink_maa2c8802d351b443dda0bc206d70fa9fe87756b57a84d0357e9dfb4c1e7a0667\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"63dc6e7ffb23fa2f492a776dfe3f26537ee473c9be45219097955b470f66c12e\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"derivatives\",\"type\":{\"element\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"},\"kind\":\"list\"}},{\"name\":\"allowed\",\"type\":{\"element\":{\"kind\":\"bool\"},\"kind\":\"list\"}},{\"name\":\"maximum\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"total\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477\",\"named\":{},\"root\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}},\"ink_maadd6c30a027af52d851f0828eec45339d218ad3bbe73e4d8d7cdd3892e754f4\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"2881c9ed2616bb70e9db4b1ec27ea38b7a87b36752047fc96da9ca8379b19bc6\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"decision\",\"type\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"}},{\"name\":\"return_value\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"baseline\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31\",\"named\":{},\"root\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}}},\"ink_mc05a2256079ef1f1818d13e69727dc7902cdb7f70856a671af2ba08ef190d23a\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"d02715cce4688c556e60843790a4e59e61ebaad2c9c1064929c6b794d816a06a\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"masses\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"allowed\",\"type\":{\"element\":{\"kind\":\"bool\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31\",\"named\":{},\"root\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}}},\"ink_mda500f665e6078213ee2391fedf06240c651d1725327b086aa70cda14bef9a07\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"2be6f1cb78767fdb61c1c0484a5a6b843d511c7eee041ed29a5db92ea7552629\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"rewards\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"discount\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bootstrap\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31\",\"named\":{},\"root\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}}},\"ink_mdfbd57a9f460147afedb262e2bfe0f6197f9b813c85277c59f5e101900063ad7\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"fb0d53fcc5118c446d80e19c4ffd8b95f7979f94f7fb23149d3518375b621a75\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"93944e72b897c9246b2efb71a34cebe025e2d57af4d472565578d66dcdc24614\",\"named\":{},\"root\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"fields\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"first\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"second\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"steps\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"first_power\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_power\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab\"}}}},\"ink_meefc22a28d97f5bdc4100b36eeab9549241c3ef201b83c2f75111644d317833d\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"4748bdf2b6e86fd410744d69adce4514614c078ede8a1a3a86a717f27b6f4802\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"rate\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"ebe1deeb6dfcd30c7222004d895fd628b866b66eaba30c8067beddc0fad06e6e\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"rate\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"first_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"epsilon\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"weight_decay\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"norm_limit\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249\"}}},\"ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"7d522496fa90814f2f1e12091142cca8648a00e9c787d158636f57940650d4e4\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"xs\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176\",\"named\":{},\"root\":{\"kind\":\"bool\"}}},\"ink_mfd18151b0af45b45f5b48ef5e7a09ac1294681f654e2174ae3b33183f445ef14\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"d02715cce4688c556e60843790a4e59e61ebaad2c9c1064929c6b794d816a06a\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"masses\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"allowed\",\"type\":{\"element\":{\"kind\":\"bool\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31\",\"named\":{},\"root\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}}},\"mass\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"d9a2817b6f5795592e5f12e4e54fd3af0061b7a04d8d3e55dd63c3a2e7b0558e\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}}],\"kind\":\"record\",\"name\":\"Parameters\"}},{\"name\":\"p\",\"type\":{\"fields\":[{\"name\":\"slot\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"operation\",\"type\":{\"kind\":\"u32\"}}],\"kind\":\"record\",\"name\":\"Pick\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45\",\"named\":{},\"root\":{\"kind\":\"f32\"}}},\"numeric\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"7d522496fa90814f2f1e12091142cca8648a00e9c787d158636f57940650d4e4\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"xs\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477\",\"named\":{},\"root\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}},\"objective\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"73b6c3c00ad53194b4a983fbdfe4a21d2b6d7d09e0360d32bf0c48ae7e548d78\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"code\",\"type\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}},{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"Coefficients\"}},{\"name\":\"g\",\"type\":{\"fields\":[{\"name\":\"samples\",\"type\":{\"element\":{\"fields\":[{\"name\":\"input\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"target\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"Example\"},\"kind\":\"list\"}},{\"name\":\"instruction_cost\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"version\",\"type\":{\"kind\":\"u32\"}}],\"kind\":\"record\",\"name\":\"Goal\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45\",\"named\":{},\"root\":{\"kind\":\"f32\"}}},\"operation\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"b18b8e3a9b0c713996792c0169d67db393284bc0fbbe8923341264f4e701d595\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"index\",\"type\":{\"kind\":\"u32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"b3b157bb16bd893ea71380744900064a9de9eb7c3acb99e1b5f09d5ea004acdc\",\"named\":{},\"root\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]}}},\"operation_index\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"67c7b08ea9bc79f73b03679d7de04a95cbe0804e8e6378cf44de5a5141901762\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"op\",\"type\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff\",\"named\":{},\"root\":{\"kind\":\"u32\"}}},\"pack\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"6da39b4bdc61a0dfc05cd13f33b9dff603918ce7e5f350c1a2667fd66780df45\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}}],\"kind\":\"record\",\"name\":\"Parameters\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477\",\"named\":{},\"root\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}},\"proposal_gradient\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"354e9d2a1be8a2863cda9de86d7ffca9c62c80a6f98b48128fae5eea579790b8\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"selected\",\"type\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}},{\"name\":\"sampled\",\"type\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}},{\"name\":\"loss\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"before\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31\",\"named\":{},\"root\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}}},\"reward\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"2450f19e0e579b7c693172b8f9d966f4cb2a66f0c54c8aeddd2fc3a24094c456\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"loss\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45\",\"named\":{},\"root\":{\"kind\":\"f32\"}}},\"sample\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"557496ff636fb6b286c9734903484337d7c625c8342438da588ba6bc566acc30\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"units\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"f5fccdf188a8fa8e7f79687e82888811bdcfc6c5067f21e08583a3d045794cc3\",\"named\":{},\"root\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"fields\":[{\"name\":\"code\",\"type\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}},{\"name\":\"decisions\",\"type\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"Sampled\"}}}},\"sample_slot\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"4e2e4f167d2a7ffd909bf20fcea9b4f15c0bda928c5ecc2ea7a66ff053c3a51f\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"accumulator\",\"type\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"fields\":[{\"name\":\"choices\",\"type\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}},{\"name\":\"decisions\",\"type\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"Building\"}}},{\"name\":\"slot\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}}],\"kind\":\"record\",\"name\":\"Parameters\"}},{\"name\":\"units\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"2031034504710782006d73b2256047567d88bffe38d126e61266c10961c7253a\",\"named\":{},\"root\":{\"error\":{\"kind\":\"string\"},\"kind\":\"result\",\"ok\":{\"fields\":[{\"name\":\"choices\",\"type\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}},{\"name\":\"decisions\",\"type\":{\"element\":{\"fields\":[{\"name\":\"action\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"probability\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"score\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"Building\"}}}},\"squared_error\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"ce23998d984ebd7a5a923c4549ceab6d1453e81c138e942ab750cb78daf8862a\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"code\",\"type\":{\"element\":{\"kind\":\"enum\",\"name\":\"Op\",\"variants\":[\"Op.Identity\",\"Op.Scale\",\"Op.Bias\",\"Op.Relu\"]},\"kind\":\"list\"}},{\"name\":\"w\",\"type\":{\"fields\":[{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"Coefficients\"}},{\"name\":\"s\",\"type\":{\"fields\":[{\"name\":\"input\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"target\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"Example\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45\",\"named\":{},\"root\":{\"kind\":\"f32\"}}},\"unpack\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"7d522496fa90814f2f1e12091142cca8648a00e9c787d158636f57940650d4e4\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"xs\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"2af269616d48554c4ef5e8a1371afd52412f1ef4f05c2d9506bd43bfde5de326\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"a\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"b\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"c\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}},{\"name\":\"d\",\"type\":{\"fields\":[{\"name\":\"identity\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"scale\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"bias\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"relu\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"MassRow\"}}],\"kind\":\"record\",\"name\":\"Parameters\"}}},\"valid_policy\":{\"arguments\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"da93f3054ae6844e61714614bad93fb28519ae0c770b7d7cba7e52b5f01783b8\",\"named\":{},\"root\":{\"fields\":[{\"name\":\"p\",\"type\":{\"fields\":[{\"name\":\"weights\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"first\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"second\",\"type\":{\"element\":{\"kind\":\"f32\"},\"kind\":\"list\"}},{\"name\":\"steps\",\"type\":{\"kind\":\"u32\"}},{\"name\":\"first_power\",\"type\":{\"kind\":\"f32\"}},{\"name\":\"second_power\",\"type\":{\"kind\":\"f32\"}}],\"kind\":\"record\",\"name\":\"ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab\"}}],\"kind\":\"record\",\"name\":\"arguments\"}},\"result\":{\"format\":\"ink-value-wire-v1\",\"identity\":\"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176\",\"named\":{},\"root\":{\"kind\":\"bool\"}}}}}";
// Shared support for generated native applications. No parser or evaluator.
use num_bigint::BigInt;
use serde_json::{Value as Json, json};
use std::collections::BTreeMap;
pub trait Wire: Sized {
    fn to_json(&self) -> Json;
    fn from_json(v: &Json) -> Result<Self, String>;
}
macro_rules! unsigned_wire {
    ($t:ty) => { impl Wire for $t {
        fn to_json(&self) -> Json { json!(self) }
        fn from_json(v:&Json)->Result<Self,String> { v.as_u64().and_then(|n| n.try_into().ok()).ok_or("invalid unsigned integer".into()) }
    } };
}
unsigned_wire!(u32); unsigned_wire!(u64);
impl Wire for () {
    fn to_json(&self)->Json { Json::Null }
    fn from_json(v:&Json)->Result<Self,String>{ if v.is_null(){Ok(())}else{Err("expected Unit".into())} }
}
impl Wire for bool {
    fn to_json(&self)->Json{json!(self)}
    fn from_json(v:&Json)->Result<Self,String>{v.as_bool().ok_or("expected Bool".into())}
}
impl Wire for String {
    fn to_json(&self)->Json{json!(self)}
    fn from_json(v:&Json)->Result<Self,String>{v.as_str().map(str::to_owned).ok_or("expected String".into())}
}
impl Wire for BigInt {
    fn to_json(&self)->Json{json!({"Int":self.to_string()})}
    fn from_json(v:&Json)->Result<Self,String>{v.get("Int").and_then(Json::as_str).map(str::to_owned).unwrap_or_else(||v.to_string()).parse().map_err(|_|"expected Int".into())}
}
impl<T:Wire> Wire for Vec<T> {
    fn to_json(&self)->Json{self.iter().map(Wire::to_json).collect()}
    fn from_json(v:&Json)->Result<Self,String>{v.as_array().ok_or("expected List")?.iter().map(T::from_json).collect()}
}
impl<T:Wire> Wire for Option<T> {
    fn to_json(&self)->Json{match self{Some(v)=>json!({"Some":v.to_json()}),None=>json!({"None":null})}}
    fn from_json(v:&Json)->Result<Self,String>{
        let obj=v.as_object().ok_or("expected Option")?;
        if obj.len()!=1 {return Err("expected one tag".into())}
        if let Some(x)=obj.get("Some"){Ok(Some(T::from_json(x)?))}
        else if obj.get("None")==Some(&Json::Null){Ok(None)}else{Err("invalid Option".into())}
    }
}
impl<T:Wire,E:Wire> Wire for Result<T,E> {
    fn to_json(&self)->Json{match self{Ok(v)=>json!({"Ok":v.to_json()}),Err(e)=>json!({"Err":e.to_json()})}}
    fn from_json(v:&Json)->Result<Self,String>{
        let obj=v.as_object().ok_or("expected Result")?;
        if obj.len()!=1 {return Err("expected one tag".into())}
        if let Some(x)=obj.get("Ok"){Ok(Ok(T::from_json(x)?))}
        else if let Some(x)=obj.get("Err"){Ok(Err(E::from_json(x)?))}else{Err("invalid Result".into())}
    }
}
#[derive(Clone, Debug)]
pub struct Event {pub commit:u64,pub position:u64,pub data:EventData}
impl Event {
    pub fn to_json(&self)->Json {let (channel,value)=self.data.wire();json!({"commit":self.commit,"position":self.position,"channel":channel,"value":value})}
}
#[derive(Clone, Debug)]
pub struct Outcome<T> {pub result:T,pub committed:bool,pub version:u64,pub events:Vec<Event>}
impl<T:Wire> Outcome<T> {
    pub fn to_json(&self)->Json {json!({"result":self.result.to_json(),"committed":self.committed,"version":self.version,"events":self.events.iter().map(Event::to_json).collect::<Vec<_>>()})}
}
// The borrow prevents further mutation of State while these event references
// exist. Keeping an outcome independently still uses the existing owned API.
#[derive(Debug)]
pub struct OutcomeView<'a,T> {pub result:T,pub committed:bool,pub version:u64,pub events:&'a [Event]}
impl<T> OutcomeView<'_,T> {
    pub fn into_owned(self)->Outcome<T>{Outcome{result:self.result,committed:self.committed,version:self.version,events:self.events.to_vec()}}
}
impl<T:Wire> OutcomeView<'_,T> {
    pub fn to_json(&self)->Json {json!({"result":self.result.to_json(),"committed":self.committed,"version":self.version,"events":self.events.iter().map(Event::to_json).collect::<Vec<_>>()})}
}

impl Wire for i32 {
 fn to_json(&self)->Json{json!(self)}
 fn from_json(v:&Json)->Result<Self,String>{v.as_i64().and_then(|n|n.try_into().ok()).ok_or("invalid i32".into())}
}
impl Wire for f32 {
 fn to_json(&self)->Json{if self.is_finite(){json!(self)}else{json!({"F32Bits":self.to_bits()})}}
 fn from_json(v:&Json)->Result<Self,String>{
  if let Some(n)=v.as_f64(){let f=n as f32;if f.is_finite(){return Ok(f)}return Err("f32 overflow".into())}
  if let Some(o)=v.as_object(){if o.len()==1{if let Some(b)=o.get("F32Bits").and_then(Json::as_u64).and_then(|n|u32::try_from(n).ok()){return Ok(Self::from_bits(b))}}}
  Err("expected finite f32 or F32Bits".into())
 }
}
impl Wire for f64 {
 fn to_json(&self)->Json{if self.is_finite(){json!(self)}else{json!({"F64Bits":self.to_bits().to_string()})}}
 fn from_json(v:&Json)->Result<Self,String>{
  if let Some(n)=v.as_f64(){if n.is_finite(){return Ok(n)}return Err("f64 overflow".into())}
  if let Some(o)=v.as_object(){if o.len()==1{if let Some(s)=o.get("F64Bits").and_then(Json::as_str){
   if !s.is_empty()&&s.len()<=20&&!(s.len()>1&&s.starts_with('0'))&&s.bytes().all(|c|c.is_ascii_digit()){
    if let Ok(bits)=s.parse::<u64>(){return Ok(Self::from_bits(bits));}
   }
  }}}
  Err("expected finite f64 or F64Bits decimal string".into())
 }
}
impl<T:Wire,const N:usize> Wire for [T;N] {
 fn to_json(&self)->Json{self.iter().map(Wire::to_json).collect()}
 fn from_json(v:&Json)->Result<Self,String>{let a=v.as_array().ok_or("expected vector")?;if a.len()!=N{return Err("vector dimension mismatch".into())}a.iter().map(T::from_json).collect::<Result<Vec<_>,_>>()?.try_into().map_err(|_|"vector dimension mismatch".into())}
}

#[derive(Clone,Copy,Debug,PartialEq,Eq)] pub enum InkArithmeticError {Overflow}
impl Wire for InkArithmeticError {
 fn to_json(&self)->Json{json!("ArithmeticError.Overflow")}
 fn from_json(v:&Json)->Result<Self,String>{if v.as_str()==Some("ArithmeticError.Overflow"){Ok(Self::Overflow)}else{Err("invalid arithmetic error".into())}}
}

impl<T:Wire> Wire for Box<T> { fn to_json(&self)->Json { (**self).to_json() } fn from_json(v:&Json)->Result<Self,String> { Ok(Box::new(T::from_json(v)?)) } }

// Structural stored-data identity is separate from scalar IEEE equality.
trait InkDataEq { fn ink_data_eq(&self,other:&Self)->bool; }
macro_rules! data_eq {($($t:ty),*)=>{$(impl InkDataEq for $t{fn ink_data_eq(&self,other:&Self)->bool{self==other}})*};}
data_eq!((),bool,u32,u64,i32,BigInt,String,InkArithmeticError);
impl InkDataEq for f32{fn ink_data_eq(&self,other:&Self)->bool{self.to_bits()==other.to_bits()}}
impl InkDataEq for f64{fn ink_data_eq(&self,other:&Self)->bool{self.to_bits()==other.to_bits()}}
impl<T:InkDataEq> InkDataEq for Box<T>{fn ink_data_eq(&self,other:&Self)->bool{(**self).ink_data_eq(&**other)}}
impl<T:InkDataEq> InkDataEq for Vec<T>{fn ink_data_eq(&self,other:&Self)->bool{self.len()==other.len()&&self.iter().zip(other).all(|(a,b)|a.ink_data_eq(b))}}
impl<T:InkDataEq,const N:usize> InkDataEq for [T;N]{fn ink_data_eq(&self,other:&Self)->bool{self.iter().zip(other).all(|(a,b)|a.ink_data_eq(b))}}
impl<T:InkDataEq> InkDataEq for Option<T>{fn ink_data_eq(&self,other:&Self)->bool{match(self,other){(Some(a),Some(b))=>a.ink_data_eq(b),(None,None)=>true,_=>false}}}
impl<T:InkDataEq,E:InkDataEq> InkDataEq for Result<T,E>{fn ink_data_eq(&self,other:&Self)->bool{match(self,other){(Ok(a),Ok(b))=>a.ink_data_eq(b),(Err(a),Err(b))=>a.ink_data_eq(b),_=>false}}}

pub fn ink_int_from_f64(x:f64)->Option<num_bigint::BigInt>{
 if !x.is_finite(){return None;}let b=x.to_bits();let e=((b>>52)&2047) as i32-1023;
 if e<0{return Some(0.into());}let m=(b&0xfffffffffffff)|0x10000000000000;let n=num_bigint::BigInt::from(m);
 let v=if e>=52{n<<((e-52) as usize)}else{n>>((52-e) as usize)};
 Some(if b&0x8000000000000000!=0{-v}else{v})
}
pub fn ink_f64_from_int(x:&num_bigint::BigInt)->f64{
 use num_bigint::{BigUint,Sign};let a=x.magnitude();let bits=a.bits();let sign=if x.sign()==Sign::Minus{0x8000000000000000}else{0};
 if bits==0{return 0.0;}if bits<=53{let n=a.to_u64_digits()[0] as f64;return if sign==0{n}else{-n};}
 if bits>1024{return f64::from_bits(sign|0x7ff0000000000000);}
 let shift=(bits-53) as usize;let q=a>>shift;let mut m=q.to_u64_digits()[0];let rem=a-(&q<<shift);let half=BigUint::from(1u32)<<(shift-1);
 if rem>half||(rem==half&&m&1!=0){m+=1;}let mut e=bits-1+1023;
 if m==0x20000000000000{m>>=1;e+=1;}if e>=2047{return f64::from_bits(sign|0x7ff0000000000000);}
 f64::from_bits(sign|(e<<52)|(m&0xfffffffffffff))
}
pub fn ink_int_from_f32(x:f32)->Option<num_bigint::BigInt>{
 if !x.is_finite(){return None;}let b=x.to_bits();let e=((b>>23)&255) as i32-127;
 if e<0{return Some(0.into());}let m=(b&0x7fffff)|0x800000;let n=num_bigint::BigInt::from(m);
 let v=if e>=23{n<<((e-23) as usize)}else{n>>((23-e) as usize)};
 Some(if b&0x80000000!=0{-v}else{v})
}
pub fn ink_f32_from_int(x:&num_bigint::BigInt)->f32{
 use num_bigint::{BigUint,Sign};let a=x.magnitude();let bits=a.bits();let sign=if x.sign()==Sign::Minus{0x80000000}else{0};
 if bits==0{return 0.0;}if bits<=24{let n=a.to_u32_digits()[0] as f32;return if sign==0{n}else{-n};}
 if bits>128{return f32::from_bits(sign|0x7f800000);}
 let shift=(bits-24) as usize;let q=a>>shift;let mut m=q.to_u32_digits()[0];let rem=a-(&q<<shift);let half=BigUint::from(1u32)<<(shift-1);
 if rem>half||(rem==half&&m&1!=0){m+=1;}let mut e=bits as u32-1+127;
 if m==0x1000000{m>>=1;e+=1;}if e>=255{return f32::from_bits(sign|0x7f800000);}
 f32::from_bits(sign|(e<<23)|(m&0x7fffff))
}

mod temporary {
// Affine owners use a Vec directly until partitioned. Partitions share one
// allocation with disjoint logical ranges. Checked source cannot retain the old
// owner or escape a partition; growth detaches a range before it can overlap.
#[derive(Clone, Debug)]
enum InkBufferStorage<T> {
    Owned(Vec<T>),
    Shared { data:std::rc::Rc<std::cell::RefCell<Vec<T>>>, start:usize, end:usize },
}
#[derive(Clone, Debug)]
pub struct OwnedBuffer<T>(InkBufferStorage<T>);
pub struct BorrowedBuffer<'a,T>(&'a[T]);
impl<T:Clone> BorrowedBuffer<'_,T> {
    pub fn len(&self)->u32 {self.0.len().try_into().expect("buffer exceeds u32")}
    pub fn get(&self,i:u32)->Option<T> {self.0.get(i as usize).cloned()}
    pub fn with_item<R>(&self,i:u32,f:impl FnOnce(Option<&T>)->R)->R {f(self.0.get(i as usize))}
    pub unsafe fn get_unchecked(&self,i:u32)->T {unsafe{self.0.get_unchecked(i as usize).clone()}}
    pub fn with_range<R>(&self,start:u32,count:u32,f:impl FnOnce(BorrowedBuffer<'_,T>)->R)->R {
        let start=(start as usize).min(self.0.len());let count=(count as usize).min(self.0.len()-start);
        f(BorrowedBuffer(&self.0[start..start+count]))
    }
}
impl<T:Clone> OwnedBuffer<T> {
    pub fn new(xs:Vec<T>)->Self { Self(InkBufferStorage::Owned(xs)) }
    // Opaque native handles are invocation-local aliases, not source owners.
    pub fn shared(xs:Vec<T>)->Self { let end=xs.len();Self(InkBufferStorage::Shared{data:std::rc::Rc::new(std::cell::RefCell::new(xs)),start:0,end}) }
    fn read<R>(&self,f:impl FnOnce(&[T])->R)->R {match &self.0 {
        InkBufferStorage::Owned(xs)=>f(xs),
        InkBufferStorage::Shared{start,end,..} if start==end=>f(&[]),
        InkBufferStorage::Shared{data,start,end}=>f(&data.borrow()[*start..*end]),
    }}
    fn edit<R>(&mut self,f:impl FnOnce(&mut [T])->R)->R {match &mut self.0 {
        InkBufferStorage::Owned(xs)=>f(xs),
        InkBufferStorage::Shared{start,end,..} if start==end=>f(&mut []),
        InkBufferStorage::Shared{data,start,end}=>f(&mut data.borrow_mut()[*start..*end]),
    }}
    pub fn len(&self)->u32 {let n=match &self.0 {InkBufferStorage::Owned(xs)=>xs.len(),InkBufferStorage::Shared{start,end,..}=>end-start};n.try_into().expect("buffer exceeds u32")}
    pub fn get(&self,i:u32)->Option<T>{self.read(|xs|xs.get(i as usize).cloned())}
    pub fn with_item<R>(&self,i:u32,f:impl FnOnce(Option<&T>)->R)->R {self.read(|xs|f(xs.get(i as usize)))}
    pub fn with_range<R>(&self,start:u32,count:u32,f:impl FnOnce(BorrowedBuffer<'_,T>)->R)->R {
        self.read(|xs|{let start=(start as usize).min(xs.len());let count=(count as usize).min(xs.len()-start);f(BorrowedBuffer(&xs[start..start+count]))})
    }
    // Opaque handles already use shared storage. These invocation-local views
    // are readonly in checked source and retain the original logical bounds.
    pub fn range_handle(&self,start:u32,count:u32)->Self {
        match &self.0 {
            InkBufferStorage::Shared{data,start:base,end}=> {
                let start=*base+(start as usize).min(*end-*base);
                let end=start+(count as usize).min(*end-start);
                Self(InkBufferStorage::Shared{data:data.clone(),start,end})
            },
            InkBufferStorage::Owned(_)=>self.read(|xs|{let start=(start as usize).min(xs.len());let count=(count as usize).min(xs.len()-start);Self::shared(xs[start..start+count].to_vec())}),
        }
    }
    pub unsafe fn get_unchecked(&self,i:u32)->T {self.read(|xs|unsafe{xs.get_unchecked(i as usize).clone()})}
    pub fn set(mut self,i:u32,value:T)->Self {self.edit(|xs|if let Some(x)=xs.get_mut(i as usize){*x=value});self}
    pub fn swap(mut self,a:u32,b:u32)->Self {self.edit(|xs|if (a as usize)<xs.len()&&(b as usize)<xs.len(){xs.swap(a as usize,b as usize)});self}
    pub fn fill_range(mut self,start:u32,count:u32,value:T)->Self {
        self.edit(|xs|{let start=(start as usize).min(xs.len());let count=(count as usize).min(xs.len()-start);xs[start..start+count].fill(value)});self
    }
    pub fn copy_within(mut self,source:u32,destination:u32,count:u32)->Self {
        self.edit(|xs|{
            let source=(source as usize).min(xs.len());let destination=(destination as usize).min(xs.len());
            let count=(count as usize).min(xs.len()-source).min(xs.len()-destination);
            if source==destination{return}
            if destination>source {for i in (0..count).rev(){xs[destination+i]=xs[source+i].clone();}}
            else {for i in 0..count{xs[destination+i]=xs[source+i].clone();}}
        });self
    }
    pub fn copy_within_copy(mut self,source:u32,destination:u32,count:u32)->Self where T:Copy {
        self.edit(|xs|{
            let a=(source as usize).min(xs.len());let b=(destination as usize).min(xs.len());
            let n=(count as usize).min(xs.len()-a).min(xs.len()-b);
            xs.copy_within(a..a+n,b);
        });self
    }
    pub fn map_inplace(mut self,mut f:impl FnMut(T)->T)->Self {self.edit(|xs|for x in xs{*x=f(x.clone())});self}
    pub fn map_indexed_inplace(mut self,mut f:impl FnMut(u32,T)->T)->Self {self.edit(|xs|for(i,x)in xs.iter_mut().enumerate(){*x=f(i as u32,x.clone())});self}
    pub fn scan_inplace(mut self,acc:T,mut f:impl FnMut(T,T)->T)->Self {let mut state=Some(acc);self.edit(|xs|for x in xs{let next=f(state.take().expect("scan state"),x.clone());*x=next.clone();state=Some(next)});self}
    pub fn filter_inplace(mut self,mut f:impl FnMut(T)->bool)->Self {
        let kept=self.edit(|xs|{let mut n=0;for i in 0..xs.len(){if f(xs[i].clone()){xs.swap(n,i);n+=1}}n});
        self.truncate(kept as u32)
    }
    pub fn pop(self)->Self {let n=self.len().saturating_sub(1);self.truncate(n)}
    pub fn truncate(mut self,n:u32)->Self {match &mut self.0 {
        InkBufferStorage::Owned(xs)=>xs.truncate(n as usize),
        InkBufferStorage::Shared{start,end,..}=>*end=*start+((*end-*start).min(n as usize)),
    };self}
    pub fn push(mut self,value:T)->Self {
        assert!(self.len()<u32::MAX,"buffer length exhausted");
        match &mut self.0 {
            InkBufferStorage::Owned(xs)=>{xs.push(value);return self},
            InkBufferStorage::Shared{data,start,end} if *start==0&&*end==data.borrow().len()=>{data.borrow_mut().push(value);*end+=1;return self},
            _=>{},
        }
        let mut xs=self.freeze();xs.push(value);Self::new(xs)
    }
    pub fn split(self,at:u32)->(Self,Self){
        if at==0 || at>=self.len(){
            let empty=if matches!(&self.0,InkBufferStorage::Shared{..}){Self::shared(Vec::new())}else{Self::new(Vec::new())};
            return if at==0 {(empty,self)}else{(self,empty)}
        }
        let (data,start,end)=match self.0 {
            InkBufferStorage::Owned(xs)=>{let end=xs.len();(std::rc::Rc::new(std::cell::RefCell::new(xs)),0,end)},
            InkBufferStorage::Shared{data,start,end}=>(data,start,end),
        };
        let cut=start+(at as usize).min(end-start);
        (Self(InkBufferStorage::Shared{data:data.clone(),start,end:cut}),Self(InkBufferStorage::Shared{data,start:cut,end}))
    }
    pub fn append(self,other:Self)->Self {
        if let (InkBufferStorage::Shared{data,start,end},InkBufferStorage::Shared{data:rhs,start:rstart,end:rend})=(&self.0,&other.0) {
            if std::rc::Rc::ptr_eq(data,rhs)&&end==rstart {return Self(InkBufferStorage::Shared{data:data.clone(),start:*start,end:*rend})}
        }
        let mut rhs=other.freeze();
        let mut left=self;
        if let InkBufferStorage::Shared{data,start,end}=&mut left.0 {
            if *start==0&&*end==data.borrow().len(){data.borrow_mut().append(&mut rhs);*end=data.borrow().len();return left}
        }
        let mut xs=left.freeze();xs.append(&mut rhs);Self::new(xs)
    }
    // Opaque handles obey checked source moves. Other nonempty aliases are
    // dead after this transfer; empty scoped partitions remain usable.
    pub fn freeze_handle(self)->Vec<T>{
        if let InkBufferStorage::Shared{data,start,end}=&self.0 {
            if start==end{return Vec::new()}
            if *start==0&&*end==data.borrow().len(){return std::mem::take(&mut *data.borrow_mut())}
        }
        self.freeze()
    }
    pub fn freeze(self)->Vec<T>{match self.0 {
        InkBufferStorage::Owned(xs)=>xs,
        InkBufferStorage::Shared{start,end,..} if start==end=>Vec::new(),
        InkBufferStorage::Shared{data,start,end}=>match std::rc::Rc::try_unwrap(data) {
            Ok(cell)=>{let mut xs=cell.into_inner();xs.truncate(end);if start==0{xs}else{xs.drain(..start);xs}},
            Err(data)=>data.borrow()[start..end].to_vec(),
        }
    }}
}
impl<T:Clone+PartialEq> PartialEq for OwnedBuffer<T>{fn eq(&self,r:&Self)->bool{self.read(|a|r.read(|b|a==b))}}
impl<T:Clone+Eq> Eq for OwnedBuffer<T>{}
impl<T:Clone+PartialOrd> PartialOrd for OwnedBuffer<T>{fn partial_cmp(&self,r:&Self)->Option<std::cmp::Ordering>{self.read(|a|r.read(|b|a.partial_cmp(b)))}}
impl<T:Clone+Ord> Ord for OwnedBuffer<T>{fn cmp(&self,r:&Self)->std::cmp::Ordering{self.read(|a|r.read(|b|a.cmp(b)))}}
// Exact dense scalar scratch with bounded per-thread allocation reuse. Keys
// outside the dense domain migrate all live entries into the ordered fallback.
const INK_DENSE_LIMIT: usize = 4096;
const INK_SCRATCH_RETAIN: usize = 2048;
const INK_SCRATCH_POOL_LIMIT: usize = 8;
std::thread_local! {static INK_MAP_POOL:std::cell::RefCell<Vec<Box<dyn std::any::Any>>>=const{std::cell::RefCell::new(Vec::new())};}
#[derive(Clone, Debug)]
struct InkSlot<K,V> { epoch:u64, value:Option<(K,V)> }
#[derive(Clone, Debug)]
struct InkDense<K,V> { epoch:u64, length:usize, slots:Vec<InkSlot<K,V>> }
impl<K:'static,V:'static> InkDense<K,V> {
    fn fresh()->Self {
        let old=INK_MAP_POOL.with(|pool| {let mut pool=pool.borrow_mut();let at=pool.iter().position(|p|p.as_ref().is::<Self>());at.map(|i|*pool.swap_remove(i).downcast::<Self>().unwrap())});
        let mut scratch=old.unwrap_or(Self{epoch:0,length:0,slots:vec![]});
        if scratch.epoch==u64::MAX {for slot in &mut scratch.slots {slot.epoch=0;slot.value=None;}scratch.epoch=1;}
        else {scratch.epoch+=1;}
        scratch.length=0;scratch
    }
}
fn ink_dense_index<K:'static>(key:&K)->Option<usize> {
    let any=key as &dyn std::any::Any;
    let index=if let Some(&x)=any.downcast_ref::<u32>() {x as u64}
        else if let Some(&x)=any.downcast_ref::<u64>() {x}
        else if let Some(&x)=any.downcast_ref::<i32>() {u64::try_from(x).ok()?}
        else if let Some(&x)=any.downcast_ref::<bool>() {u64::from(x)} else {return None};
    if index<INK_DENSE_LIMIT as u64 {Some(index as usize)}else{None}
}
fn ink_scalar<T:'static>()->bool {
    let id=std::any::TypeId::of::<T>();[std::any::TypeId::of::<u32>(),std::any::TypeId::of::<u64>(),std::any::TypeId::of::<i32>(),std::any::TypeId::of::<bool>()].contains(&id)
}
#[derive(Clone, Debug)]
enum InkMapStorage<K:Ord+'static,V:'static> { Sparse(std::collections::BTreeMap<K,V>), Dense(InkDense<K,V>), Shared(std::rc::Rc<std::cell::RefCell<OwnedMap<K,V>>>) }
#[derive(Clone, Debug)]
pub struct OwnedMap<K:Ord+'static,V:'static>(InkMapStorage<K,V>);
impl<K:Ord+Clone+'static,V:Clone+'static> OwnedMap<K,V> {
    pub fn new()->Self {
        if ink_scalar::<K>()&&ink_scalar::<V>() {Self(InkMapStorage::Dense(InkDense::fresh()))}
        else {Self::new_sparse()}
    }
    pub fn shared()->Self {Self(InkMapStorage::Shared(std::rc::Rc::new(std::cell::RefCell::new(Self::new()))))}
    pub fn new_sparse()->Self {Self(InkMapStorage::Sparse(std::collections::BTreeMap::new()))}
    fn entries(&self)->Box<dyn Iterator<Item=(K,V)>+'_> {
        match &self.0 {
            InkMapStorage::Shared(map)=>Box::new(map.borrow().entries().collect::<Vec<_>>().into_iter()),
            InkMapStorage::Sparse(map)=>Box::new(map.iter().map(|(k,v)|(k.clone(),v.clone()))),
            InkMapStorage::Dense(s)=>Box::new(s.slots.iter().filter(move|x|x.epoch==s.epoch).filter_map(|x|x.value.as_ref().map(|(k,v)|(k.clone(),v.clone())))),
        }
    }
    pub fn len(&self)->u32 {match &self.0 {InkMapStorage::Sparse(map)=>map.len(),InkMapStorage::Dense(s)=>s.length,InkMapStorage::Shared(map)=>return map.borrow().len()}.try_into().expect("map exceeds u32")}
    pub fn get(&self,key:&K)->Option<V> {
        match &self.0 {
            InkMapStorage::Shared(map)=>map.borrow().get(key),
            InkMapStorage::Sparse(map)=>map.get(key).cloned(),
            InkMapStorage::Dense(s)=>ink_dense_index(key).and_then(|i|s.slots.get(i)).filter(|x|x.epoch==s.epoch).and_then(|x|x.value.as_ref().map(|(_,v)|v.clone())),
        }
    }
    pub fn contains(&self,key:&K)->bool {self.get(key).is_some()}
    pub fn set(mut self,key:K,value:V)->Self {
        if let InkMapStorage::Shared(data)=&self.0 {let mut map=data.borrow_mut();let old=std::mem::replace(&mut *map,Self::new_sparse());*map=old.set(key,value);drop(map);return self;}
        if let InkMapStorage::Dense(s)=&mut self.0 {
            if let Some(index)=ink_dense_index(&key).filter(|&i|i<=s.slots.len().saturating_mul(8)+64) {
                s.slots.resize_with(s.slots.len().max(index+1),||InkSlot{epoch:0,value:None});
                let slot=&mut s.slots[index];if slot.epoch!=s.epoch||slot.value.is_none(){s.length+=1;}
                slot.value=Some((key,value));slot.epoch=s.epoch;return self;
            }
            let mut ordered=std::collections::BTreeMap::new();
            for slot in &mut s.slots {if slot.epoch==s.epoch {if let Some((k,v))=slot.value.take(){ordered.insert(k,v);}}}
            ordered.insert(key,value);
            let old=std::mem::replace(&mut self.0,InkMapStorage::Sparse(ordered));
            if let InkMapStorage::Dense(s)=old {ink_recycle(s);}
        } else if let InkMapStorage::Sparse(map)=&mut self.0 {map.insert(key,value);}
        self
    }
    pub fn remove(mut self,key:&K)->Self {
        if let InkMapStorage::Shared(data)=&self.0 {let mut map=data.borrow_mut();let old=std::mem::replace(&mut *map,Self::new_sparse());*map=old.remove(key);drop(map);return self;}
        match &mut self.0 {
            InkMapStorage::Shared(_)=>unreachable!("shared handled above"),
            InkMapStorage::Sparse(map)=>{map.remove(key);},
            InkMapStorage::Dense(s)=>{if let Some(slot)=ink_dense_index(key).and_then(|i|s.slots.get_mut(i)){if slot.epoch==s.epoch&&slot.value.take().is_some(){s.length-=1;slot.epoch=0;}}},
        }self
    }
    pub fn keys(&self)->Vec<K>{self.entries().map(|(k,_)|k.clone()).collect()}
    pub fn values(&self)->Vec<V>{self.entries().map(|(_,v)|v.clone()).collect()}
}
fn ink_recycle<K:'static,V:'static>(scratch:InkDense<K,V>) {
    if scratch.slots.capacity()<=INK_SCRATCH_RETAIN {INK_MAP_POOL.with(|pool|{let mut pool=pool.borrow_mut();if pool.len()<INK_SCRATCH_POOL_LIMIT {pool.push(Box::new(scratch));}});}
}
impl<K:Ord+'static,V:'static> Drop for OwnedMap<K,V> {
    fn drop(&mut self) {if matches!(self.0,InkMapStorage::Dense(_)){if let InkMapStorage::Dense(s)=std::mem::replace(&mut self.0,InkMapStorage::Sparse(std::collections::BTreeMap::new())){ink_recycle(s);}}}
}
impl<K:Ord+Clone+'static,V:Clone+PartialEq+'static> PartialEq for OwnedMap<K,V>{fn eq(&self,other:&Self)->bool{self.entries().eq(other.entries())}}
impl<K:Ord+Clone+'static,V:Clone+Eq+'static> Eq for OwnedMap<K,V>{}
impl<K:Ord+Clone+'static,V:Clone+Ord+'static> Ord for OwnedMap<K,V>{fn cmp(&self,other:&Self)->std::cmp::Ordering{self.entries().cmp(other.entries())}}
impl<K:Ord+Clone+'static,V:Clone+PartialOrd+'static> PartialOrd for OwnedMap<K,V>{fn partial_cmp(&self,other:&Self)->Option<std::cmp::Ordering>{self.entries().partial_cmp(other.entries())}}

// Bounded fork/join execution. Each worker owns a disjoint mutable slice;
// joining retains source order. Nested parallel requests execute sequentially.
std::thread_local! {static INK_PARALLEL_DEPTH:std::cell::Cell<u32>=const{std::cell::Cell::new(0)};}
struct InkParallelGuard(u32);
impl InkParallelGuard {
    fn enter() -> Self {
        Self(INK_PARALLEL_DEPTH.with(|d| {
            let old = d.get();
            d.set(old + 1);
            old
        }))
    }
}
impl Drop for InkParallelGuard {
    fn drop(&mut self) {
        INK_PARALLEL_DEPTH.with(|d| d.set(self.0));
    }
}
fn ink_parallel_workers(len: usize, grain: u32) -> usize {
    if cfg!(target_arch = "wasm32") {
        return 1;
    }
    if INK_PARALLEL_DEPTH.with(|d| d.get() > 0) {
        return 1;
    }
    let available = std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1);
    let requested = std::env::var("INK_THREADS")
        .ok()
        .and_then(|s| s.parse::<usize>().ok())
        .unwrap_or(available)
        .clamp(1, 32);
    requested.min(len / (grain.max(1) as usize)).max(1)
}
pub fn ink_parallel_map<T: Clone + Sync, U: Send, F: Fn(u32, T) -> U + Sync>(
    xs: Vec<T>,
    grain: u32,
    f: F,
) -> Vec<U> {
    let workers = ink_parallel_workers(xs.len(), grain);
    let _guard = InkParallelGuard::enter();
    if workers == 1 {
        return xs
            .into_iter()
            .enumerate()
            .map(|(i, x)| f(i as u32, x))
            .collect();
    }
    let chunk = (xs.len() + workers - 1) / workers;
    ink_parallel_start_receipt();
    std::thread::scope(|scope| {
        let handles = xs
            .chunks(chunk)
            .enumerate()
            .map(|(part, slice)| {
                let f = &f;
                scope.spawn(move || {
                    let _guard = InkParallelGuard::enter();
                    ink_parallel_record_thread();
                    slice
                        .iter()
                        .cloned()
                        .enumerate()
                        .map(|(i, x)| f((part * chunk + i) as u32, x))
                        .collect::<Vec<U>>()
                })
            })
            .collect::<Vec<_>>();
        let mut output = Vec::with_capacity(xs.len());
        for handle in handles {
            output.extend(handle.join().expect("parallel worker failed"));
        }
        output
    })
}
pub fn ink_parallel_update<T: Clone + Send, F: Fn(u32, T) -> T + Sync>(
    mut xs: Vec<T>,
    grain: u32,
    f: F,
) -> Vec<T> {
    let workers = ink_parallel_workers(xs.len(), grain);
    let _guard = InkParallelGuard::enter();
    if workers == 1 {
        for (i, x) in xs.iter_mut().enumerate() {
            *x = f(i as u32, x.clone());
        }
        return xs;
    }
    let chunk = (xs.len() + workers - 1) / workers;
    ink_parallel_start_receipt();
    std::thread::scope(|scope| {
        for (part, slice) in xs.chunks_mut(chunk).enumerate() {
            let f = &f;
            scope.spawn(move || {
                let _guard = InkParallelGuard::enter();
                ink_parallel_record_thread();
                for (i, x) in slice.iter_mut().enumerate() {
                    *x = f((part * chunk + i) as u32, x.clone());
                }
            });
        }
    });
    xs
}

pub fn ink_parallel_nested()->bool{INK_PARALLEL_DEPTH.with(|d|d.get()>0)}
pub fn with_parallel_worker<T>(f:impl FnOnce()->T)->T{let _guard=InkParallelGuard::enter();f()}

// Diagnostic receipt counts actual entered OS threads, never planned jobs.
static INK_PARALLEL_RECEIPT: std::sync::LazyLock<std::sync::Mutex<(u64,std::collections::BTreeSet<String>,std::collections::BTreeSet<String>)>> = std::sync::LazyLock::new(||std::sync::Mutex::new((0,std::collections::BTreeSet::new(),std::collections::BTreeSet::new())));
fn ink_parallel_start_receipt(){INK_PARALLEL_RECEIPT.lock().expect("parallel receipt lock").2.clear();}
fn ink_parallel_record_thread(){let mut r=INK_PARALLEL_RECEIPT.lock().expect("parallel receipt lock");r.0+=1;let id=format!("{:?}",std::thread::current().id());r.1.insert(id.clone());r.2.insert(id);}
pub fn ink_parallel_statistics()->(u64,Vec<String>,Vec<String>){let r=INK_PARALLEL_RECEIPT.lock().expect("parallel receipt lock");(r.0,r.1.iter().cloned().collect(),r.2.iter().cloned().collect())}

// Rust's ordinary (non-fast-math) f32 operations retain their separate rounding
// points after inlining. Keep NaN canonicalisation visible to vectorisation.
#[inline]
pub fn ink_f32(value:f32)->f32{if value.is_nan(){f32::from_bits(0x7fc00000)}else{value}}
pub fn ink_f64(value:f64)->f64{if value.is_nan(){f64::from_bits(0x7ff8000000000000)}else{value}}
pub fn ink_f64_div(x:f64,y:f64)->f64{ink_f64(x/y)}
pub fn ink_sqrt_f64(x:f64)->f64{ink_f64(x.sqrt())}
pub fn ink_floor_f64(x:f64)->f64{ink_f64(x.floor())}
pub fn ink_ceil_f64(x:f64)->f64{ink_f64(x.ceil())}
pub fn ink_trunc_f64(x:f64)->f64{ink_f64(x.trunc())}
pub fn ink_round_ties_even_f64(x:f64)->f64{ink_f64(x.round_ties_even())}
pub fn ink_u32_from_f64(x:f64)->Option<u32>{let x=x.trunc();(x.is_finite()&&x>=0.0&&x<4294967296.0).then(||x as u32)}
pub fn ink_u64_from_f64(x:f64)->Option<u64>{let x=x.trunc();(x.is_finite()&&x>=0.0&&x<18446744073709551616.0).then(||x as u64)}
pub fn ink_i32_from_f64(x:f64)->Option<i32>{let x=x.trunc();(x.is_finite()&&x>=-2147483648.0&&x<2147483648.0).then(||x as i32)}

// An explicit private-vector representation of the same affine Buffer value.
// Splitting copies into independent owners; allocation identity is unobservable.
// Selected by a checked physical plan, never by a workload matcher.
#[derive(Clone,Debug,PartialEq,Eq,PartialOrd,Ord)]
pub struct DirectBuffer<T>(Vec<T>);
impl<T:Clone> DirectBuffer<T> {
    pub fn new(xs:Vec<T>)->Self {Self(xs)}
    pub fn shared(xs:Vec<T>)->Self {Self(xs)}
    pub fn len(&self)->u32 {self.0.len().try_into().expect("buffer exceeds u32")}
    pub fn get(&self,i:u32)->Option<T>{self.0.get(i as usize).cloned()}
    pub fn with_item<R>(&self,i:u32,f:impl FnOnce(Option<&T>)->R)->R{f(self.0.get(i as usize))}
    pub fn with_range<R>(&self,start:u32,count:u32,f:impl FnOnce(BorrowedBuffer<'_,T>)->R)->R {
        let start=(start as usize).min(self.0.len());let count=(count as usize).min(self.0.len()-start);
        f(BorrowedBuffer(&self.0[start..start+count]))
    }
    pub fn range_handle(&self,start:u32,count:u32)->Self {
        let start=(start as usize).min(self.0.len());let count=(count as usize).min(self.0.len()-start);
        Self::new(self.0[start..start+count].to_vec())
    }
    pub unsafe fn get_unchecked(&self,i:u32)->T{self.0.get_unchecked(i as usize).clone()}
    pub fn set(mut self,i:u32,v:T)->Self{if let Some(x)=self.0.get_mut(i as usize){*x=v;}self}
    pub fn swap(mut self,a:u32,b:u32)->Self{if(a as usize)<self.0.len()&&(b as usize)<self.0.len(){self.0.swap(a as usize,b as usize);}self}
    pub fn fill_range(mut self,start:u32,count:u32,v:T)->Self{let a=(start as usize).min(self.0.len());let n=(count as usize).min(self.0.len()-a);self.0[a..a+n].fill(v);self}
    pub fn copy_within(mut self,source:u32,destination:u32,count:u32)->Self{
        let a=(source as usize).min(self.0.len());let b=(destination as usize).min(self.0.len());let n=(count as usize).min(self.0.len()-a).min(self.0.len()-b);
        if b>a {for i in (0..n).rev(){self.0[b+i]=self.0[a+i].clone();}}else if a!=b {for i in 0..n{self.0[b+i]=self.0[a+i].clone();}}self
    }
    pub fn copy_within_copy(mut self,source:u32,destination:u32,count:u32)->Self where T:Copy {
        let a=(source as usize).min(self.0.len());let b=(destination as usize).min(self.0.len());
        let n=(count as usize).min(self.0.len()-a).min(self.0.len()-b);
        self.0.copy_within(a..a+n,b);self
    }
    pub fn map_inplace(mut self,mut f:impl FnMut(T)->T)->Self{for v in &mut self.0{*v=f(v.clone());}self}
    pub fn map_indexed_inplace(mut self,mut f:impl FnMut(u32,T)->T)->Self{for(i,v)in self.0.iter_mut().enumerate(){*v=f(i as u32,v.clone());}self}
    pub fn scan_inplace(mut self,initial:T,mut f:impl FnMut(T,T)->T)->Self{let mut acc=initial;for v in &mut self.0{acc=f(acc,v.clone());*v=acc.clone();}self}
    pub fn filter_inplace(mut self,mut f:impl FnMut(T)->bool)->Self{self.0.retain(|v|f(v.clone()));self}
    pub fn truncate(mut self,n:u32)->Self{self.0.truncate(n as usize);self}
    pub fn pop(mut self)->Self{self.0.pop();self}
    pub fn push(mut self,v:T)->Self{
        if self.0.len()>=u32::MAX as usize{return self.length_exhausted(v);}
        // Keep the consuming owner's allocation path out of the hot loop. A
        // separate call lets the host compiler retain the vector in registers
        // between pushes without changing its capacity or element semantics.
        if self.0.len()==self.0.capacity(){return self.grow_and_push(v);}
        self.0.push(v);self
    }
    #[cold]
    #[inline(never)]
    fn length_exhausted(self,_v:T)->Self{panic!("buffer length exhausted")}
    #[cold]
    #[inline(never)]
    fn grow_and_push(mut self,v:T)->Self{self.0.push(v);self}
    pub fn split(mut self,at:u32)->(Self,Self){let right=self.0.split_off((at as usize).min(self.0.len()));(self,Self(right))}
    pub fn append(mut self,mut other:Self)->Self{self.0.append(&mut other.0);self}
    pub fn freeze(self)->Vec<T>{self.0}
    pub fn freeze_handle(self)->Vec<T>{self.0}
}

// Lossless scalar columns. Values outside the preferred lane promote storage;
// promotion checks value validity, never runtime profitability.
#[derive(Clone,Debug)]
enum InkWordLanes { U8(Vec<u8>), U16(Vec<u16>), U32(Vec<u32>), U64(Vec<u64>) }
#[derive(Clone,Debug)]
pub struct PackedWords<const BITS:u8,const BASE:u8=64>{data:InkWordLanes}
impl<const BITS:u8,const BASE:u8> Default for PackedWords<BITS,BASE>{fn default()->Self{Self{data:match BITS{8=>InkWordLanes::U8(vec![]),16=>InkWordLanes::U16(vec![]),32=>InkWordLanes::U32(vec![]),64=>InkWordLanes::U64(vec![]),_=>panic!("invalid packed word width")}}}}
impl<const BITS:u8,const BASE:u8> PackedWords<BITS,BASE>{
 pub fn with_capacity(n:usize)->Self{Self{data:match BITS{8=>InkWordLanes::U8(Vec::with_capacity(n)),16=>InkWordLanes::U16(Vec::with_capacity(n)),32=>InkWordLanes::U32(Vec::with_capacity(n)),64=>InkWordLanes::U64(Vec::with_capacity(n)),_=>panic!("invalid packed word width")}}}
 pub fn prepare_push(&mut self,x:u64){if !self.fits(x){self.promote(x);}self.reserve(1);}
 pub fn reserve(&mut self,n:usize){match &mut self.data{InkWordLanes::U8(v)=>v.reserve(n),InkWordLanes::U16(v)=>v.reserve(n),InkWordLanes::U32(v)=>v.reserve(n),InkWordLanes::U64(v)=>v.reserve(n)}}
 pub fn prepare_append(&mut self,other:&Self){if other.len()==0{return;}let bound=match other.data{InkWordLanes::U8(_)=>u8::MAX as u64,InkWordLanes::U16(_)=>u16::MAX as u64,InkWordLanes::U32(_)=>u32::MAX as u64,InkWordLanes::U64(_)=>u64::MAX};if !self.fits(bound){self.promote(bound);}self.reserve(other.len());}
 pub fn len(&self)->usize{match &self.data{InkWordLanes::U8(v)=>v.len(),InkWordLanes::U16(v)=>v.len(),InkWordLanes::U32(v)=>v.len(),InkWordLanes::U64(v)=>v.len()}}
 pub fn storage_identity(&self)->usize{match &self.data{InkWordLanes::U8(v)=>v.as_ptr()as usize,InkWordLanes::U16(v)=>v.as_ptr()as usize,InkWordLanes::U32(v)=>v.as_ptr()as usize,InkWordLanes::U64(v)=>v.as_ptr()as usize}}
 pub fn payload_bytes(&self)->usize{self.len()*match self.data{InkWordLanes::U8(_)=>1,InkWordLanes::U16(_)=>2,InkWordLanes::U32(_)=>4,InkWordLanes::U64(_)=>8}}
 pub fn get(&self,i:usize)->u64{assert!(i<self.len());unsafe{self.get_unchecked(i)}}
 pub unsafe fn get_unchecked(&self,i:usize)->u64{match &self.data{InkWordLanes::U8(v)=>*v.get_unchecked(i)as u64,InkWordLanes::U16(v)=>*v.get_unchecked(i)as u64,InkWordLanes::U32(v)=>*v.get_unchecked(i)as u64,InkWordLanes::U64(v)=>*v.get_unchecked(i)}}
 fn fits(&self,x:u64)->bool{match self.data{InkWordLanes::U8(_)=>x<=u8::MAX as u64,InkWordLanes::U16(_)=>x<=u16::MAX as u64,InkWordLanes::U32(_)=>x<=u32::MAX as u64,InkWordLanes::U64(_)=>true}}
 fn promote(&mut self,value:u64){let xs=(0..self.len()).map(|i|self.get(i)).collect::<Vec<_>>();self.data=if BASE<=32&&value<=u32::MAX as u64{InkWordLanes::U32(xs.into_iter().map(|v|v as u32).collect())}else{InkWordLanes::U64(xs)};}
 pub fn push(&mut self,x:u64){if !self.fits(x){self.promote(x);}match &mut self.data{InkWordLanes::U8(v)=>v.push(x as u8),InkWordLanes::U16(v)=>v.push(x as u16),InkWordLanes::U32(v)=>v.push(x as u32),InkWordLanes::U64(v)=>v.push(x)}}
 pub fn set(&mut self,i:usize,x:u64){assert!(i<self.len());if !self.fits(x){self.promote(x);}match &mut self.data{InkWordLanes::U8(v)=>v[i]=x as u8,InkWordLanes::U16(v)=>v[i]=x as u16,InkWordLanes::U32(v)=>v[i]=x as u32,InkWordLanes::U64(v)=>v[i]=x}}
 pub fn truncate(&mut self,n:usize){match &mut self.data{InkWordLanes::U8(v)=>v.truncate(n),InkWordLanes::U16(v)=>v.truncate(n),InkWordLanes::U32(v)=>v.truncate(n),InkWordLanes::U64(v)=>v.truncate(n)}}
}
#[derive(Clone,Debug,Default)]
pub struct PackedBits{len:usize,words:Vec<u64>}
impl PackedBits{
 pub fn with_capacity(n:usize)->Self{Self{len:0,words:Vec::with_capacity(n.div_ceil(64))}}
 pub fn reserve(&mut self,n:usize){let total=self.len.checked_add(n).expect("bit length overflow").div_ceil(64);self.words.reserve(total-self.words.len());}
 pub fn prepare_push(&mut self,_:bool){self.reserve(1);}
 pub fn prepare_append(&mut self,other:&Self){self.reserve(other.len());}
 pub fn len(&self)->usize{self.len}
 pub fn payload_bytes(&self)->usize{self.words.len()*8}
 pub fn storage_identity(&self)->usize{self.words.as_ptr()as usize}
 pub fn get(&self,i:usize)->bool{assert!(i<self.len);unsafe{self.get_unchecked(i)}}
 pub unsafe fn get_unchecked(&self,i:usize)->bool{(*self.words.get_unchecked(i/64)&(1u64<<(i%64)))!=0}
 pub fn push(&mut self,x:bool){if self.len%64==0{self.words.push(0);}let i=self.len;self.len+=1;self.set(i,x);}
 pub fn set(&mut self,i:usize,x:bool){assert!(i<self.len);let mask=1u64<<(i%64);let w=&mut self.words[i/64];*w=(*w&!mask)|if x{mask}else{0};}
 pub fn truncate(&mut self,n:usize){self.len=self.len.min(n);self.words.truncate(self.len.div_ceil(64));if self.len%64!=0{if let Some(last)=self.words.last_mut(){*last&=(1u64<<(self.len%64))-1;}}}
}

// Fixed scalar/text execution support. Float arithmetic canonicalises NaNs.
pub fn ink_sqrt(x:f32)->f32{ink_f32(x.sqrt())}
pub fn ink_f32_div(x:f32,y:f32)->f32{ink_f32(x/y)}
pub fn ink_floor(x:f32)->f32{ink_f32(x.floor())}
pub fn ink_ceil(x:f32)->f32{ink_f32(x.ceil())}
pub fn ink_trunc(x:f32)->f32{ink_f32(x.trunc())}
pub fn ink_round_ties_even(x:f32)->f32{ink_f32(x.round_ties_even())}
pub fn ink_u32_from_f32(x:f32)->Option<u32>{let x=x.trunc();(x.is_finite()&&x>=0.0&&x<4294967296.0).then(||x as u32)}
pub fn ink_u64_from_f32(x:f32)->Option<u64>{let x=x.trunc();(x.is_finite()&&x>=0.0&&x<18446744073709551616.0).then(||x as u64)}
pub fn ink_i32_from_f32(x:f32)->Option<i32>{let x=x.trunc();(x.is_finite()&&x>=-2147483648.0&&x<2147483648.0).then(||x as i32)}
pub fn ink_string_byte_len(x:&str)->u32{x.len().try_into().expect("String exceeds U32 byte length")}
pub fn ink_string_byte_at(x:&str,i:u32)->Option<u32>{x.as_bytes().get(i as usize).map(|b|*b as u32)}
pub fn ink_string_slice(x:&str,a:u32,b:u32)->Option<String>{x.get(a as usize..b as usize).map(str::to_owned)}
pub fn ink_string_concat(a:&str,b:&str)->String{assert!(a.len().checked_add(b.len()).is_some_and(|n|n<=u32::MAX as usize),"String exceeds U32 byte length");format!("{a}{b}")}
pub fn ink_string_find(x:&str,needle:&str,from:u32)->Option<u32>{x.get(from as usize..).and_then(|s|s.find(needle)).map(|i|from+i as u32)}

// Immutable snapshots share pages. An edit detaches the page directory and
// the touched page only; previous transaction/host before-images stay intact.
#[derive(Clone,Debug)]
pub struct PagedColumn<T,const PAGE:usize>{
    length:usize,
    pages:std::sync::Arc<Vec<std::sync::Arc<Vec<T>>>>,
}
impl<T,const PAGE:usize> Default for PagedColumn<T,PAGE>{
    fn default()->Self{Self{length:0,pages:std::sync::Arc::new(Vec::new())}}
}
impl<T:Clone,const PAGE:usize> PagedColumn<T,PAGE>{
    pub fn with_capacity(n:usize)->Self{
        assert!(PAGE>0);
        Self{length:0,pages:std::sync::Arc::new(Vec::with_capacity(n/PAGE+usize::from(n%PAGE!=0)))}
    }
    pub fn len(&self)->usize{self.length}
    pub fn reserve(&mut self,_additional:usize){}
    pub fn as_ptr(&self)->*const (){std::sync::Arc::as_ptr(&self.pages).cast()}
    pub unsafe fn get_unchecked(&self,i:usize)->&T{
        debug_assert!(i<self.length);
        unsafe{self.pages.get_unchecked(i/PAGE).get_unchecked(i%PAGE)}
    }
    pub unsafe fn get_unchecked_mut(&mut self,i:usize)->&mut T{
        debug_assert!(i<self.length);
        let pages=std::sync::Arc::make_mut(&mut self.pages);
        let page=unsafe{pages.get_unchecked_mut(i/PAGE)};
        unsafe{std::sync::Arc::make_mut(page).get_unchecked_mut(i%PAGE)}
    }
    pub fn set_if_changed_by(&mut self,i:usize,value:T,equal:impl FnOnce(&T,&T)->bool)->bool{
        assert!(i<self.length);
        if equal(unsafe{self.get_unchecked(i)},&value){return false}
        unsafe{*self.get_unchecked_mut(i)=value;}
        true
    }
    pub fn push(&mut self,value:T){
        let length=self.length.checked_add(1).expect("column length overflow");
        let pages=std::sync::Arc::make_mut(&mut self.pages);
        if self.length%PAGE==0{pages.push(std::sync::Arc::new(Vec::with_capacity(PAGE)));}
        std::sync::Arc::make_mut(pages.last_mut().expect("column page")).push(value);
        self.length=length;
    }
    pub fn truncate(&mut self,n:usize){
        if n>=self.length{return}
        if n==0{*self=Self::default();return}
        let pages=std::sync::Arc::make_mut(&mut self.pages);
        pages.truncate(n/PAGE+usize::from(n%PAGE!=0));
        if n%PAGE!=0{std::sync::Arc::make_mut(pages.last_mut().unwrap()).truncate(n%PAGE);}
        self.length=n;
    }
    pub fn append(&mut self,other:&mut Self){
        let length=self.length.checked_add(other.length).expect("column length overflow");
        if self.length%PAGE==0{
            let rhs=std::mem::take(other);
            std::sync::Arc::make_mut(&mut self.pages).extend(rhs.pages.iter().cloned());
            self.length=length;
        }else{
            for i in 0..other.length{self.push(unsafe{other.get_unchecked(i)}.clone());}
            *other=Self::default();
        }
    }
}
pub type InkTable<K,V> = std::collections::BTreeMap<K,V>; pub trait TableCapacity {fn reserve(&mut self,additional:usize);} impl<K,V> TableCapacity for InkTable<K,V>{fn reserve(&mut self,_:usize){}}
}
use temporary::{OwnedMap,InkTable,ink_parallel_map,ink_parallel_update};
use temporary::OwnedBuffer;
use temporary::TableCapacity;

impl<T:Clone> Wire for OwnedBuffer<T>{fn from_json(_: &Json)->Result<Self,String>{Err("temporary storage is internal to a pure invocation".into())}fn to_json(&self)->Json{Json::Null}}
impl<K:Ord+Clone+'static,V:Clone+'static> Wire for OwnedMap<K,V>{fn from_json(_: &Json)->Result<Self,String>{Err("temporary storage is internal to a pure invocation".into())}fn to_json(&self)->Json{Json::Null}}
impl<T:Clone> InkDataEq for OwnedBuffer<T>{fn ink_data_eq(&self,_:&Self)->bool{panic!("temporary storage has no value equality")}}
impl<K:Ord+Clone+'static,V:Clone+'static> InkDataEq for OwnedMap<K,V>{fn ink_data_eq(&self,_:&Self)->bool{panic!("temporary storage has no value equality")}}

mod transaction {
//! Fixed transaction primitives, shared verbatim with generated execution.
//! These describe the base protocol; they select no optimisation or layout.

pub const SEMANTICS: &str = "ink-change-boundary-v1";

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Decision {
    Rollback,
    Commit { version: u64 },
    Exhausted,
}

/// A domain error wins over commit exhaustion. The body has already run;
/// both Rollback and Exhausted require restoration of its tentative effects.
#[inline]
pub fn decide(version: u64, succeeded: bool) -> Decision {
    if !succeeded {
        Decision::Rollback
    } else if let Some(version) = version.checked_add(1) {
        Decision::Commit { version }
    } else {
        Decision::Exhausted
    }
}

/// A nested change's error cannot be captured or ignored by its caller.
/// The outer Err exits the caller; the inner Result is its ordinary value.
#[inline]
pub fn nested_change<T, E>(result: Result<T, E>) -> Result<Result<T, E>, E> {
    match result {
        value @ Ok(_) => Ok(value),
        Err(error) => Err(error),
    }
}

#[derive(Debug, PartialEq, Eq)]
pub struct Publication<T> {
    pub commit: u64,
    pub position: u64,
    pub value: T,
}

/// Preserve staged order and number the committed suffix from zero, regardless
/// of earlier outbox contents. Publication neither clones nor reorders payloads.
pub fn publish<T>(
    version: u64,
    staged: impl Iterator<Item = T>,
) -> impl Iterator<Item = Publication<T>> {
    staged
        .enumerate()
        .map(move |(position, value)| Publication {
            commit: version,
            position: position as u64,
            value,
        })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn domain_errors_precede_exhaustion_and_success_never_wraps() {
        for version in [0, 1, 1 << 63, u64::MAX - 1, u64::MAX] {
            assert_eq!(decide(version, false), Decision::Rollback);
            assert_eq!(
                decide(version, true),
                match version.checked_add(1) {
                    Some(version) => Decision::Commit { version },
                    None => Decision::Exhausted,
                }
            );
        }
    }

    #[test]
    fn nested_result_and_ordered_publication_move_payloads() {
        struct Owned(&'static str);
        assert!(nested_change::<Owned, _>(Err(Owned("error"))).is_err());
        let value = nested_change::<_, Owned>(Ok(Owned("value")))
            .ok()
            .unwrap()
            .ok()
            .unwrap();
        let events: Vec<_> = publish(u64::MAX, [value, Owned("second")].into_iter()).collect();
        assert_eq!(events[0].commit, u64::MAX);
        assert_eq!(events[0].position, 0);
        assert_eq!(events[0].value.0, "value");
        assert_eq!(events[1].position, 1);
        assert_eq!(events[1].value.0, "second");
        assert_eq!(publish::<Owned>(2, std::iter::empty()).count(), 0);
    }
}

}

mod portable {
//! Shared, representation-independent snapshot codec. This module also ships
//! verbatim in generated applications; it has no AST/evaluator dependency.
use num_bigint::{BigInt, Sign};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::cmp::Ordering;

/// Raw binary64 payloads use canonical decimal u64 strings at JSON boundaries.
/// This codec is also embedded verbatim in generated applications.
pub fn f64_bits_from_json(value:&Value)->Result<u64,String> {
    if let Some(bits)=value.get("F64Bits") {
        if value.as_object().is_none_or(|o|o.len()!=1){return Err("expected only F64Bits field".into());}
        let text=bits.as_str().ok_or("F64Bits requires a decimal u64 string")?;
        if text.len()>20{return Err("invalid F64Bits word".into());}
        let parsed=text.parse::<u64>().map_err(|_|"invalid F64Bits word")?;
        if parsed.to_string()!=text{return Err("noncanonical F64Bits word".into());}
        Ok(parsed)
    }else{
        let x=value.as_f64().ok_or("expected binary64 number or F64Bits")?;
        if !x.is_finite(){return Err("finite f64 or explicit F64Bits required".into());}
        Ok(x.to_bits())
    }
}
pub fn f64_bits_to_json(bits:u64)->Value {
    let x=f64::from_bits(bits);
    if x.is_finite(){json!(x)}else{json!({"F64Bits":bits.to_string()})}
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Schema {
    Unit,
    Bool,
    U32,
    U64,
    I32,
    F32,
    F64,
    Vector(Box<Schema>, u8),
    Int,
    String,
    Id,
    Record(Vec<(String, Schema)>),
    Bind(String,Box<Schema>),
    Ref(String),
    Enum(Vec<String>),
    List(Box<Schema>),
    Option(Box<Schema>),
    Result(Box<Schema>, Box<Schema>),
}
/// Literal snapshot descriptors, distinct from public value ABI descriptors.
pub fn descriptor(s:&Schema)->Value {
    match s {
        Schema::Bind(n,t)=>json!({"kind":"bind","name":n,"body":descriptor(t)}),
        Schema::Ref(n)=>json!({"kind":"ref","name":n}),
        Schema::Record(fs)=>json!({"kind":"record","fields":fs.iter().map(|(n,t)|json!({"name":n,"type":descriptor(t)})).collect::<Vec<_>>()}),
        Schema::Enum(xs)=>json!({"kind":"enum","variants":xs}),
        Schema::List(t)=>json!({"kind":"list","element":descriptor(t)}),
        Schema::Option(t)=>json!({"kind":"option","element":descriptor(t)}),
        Schema::Result(a,b)=>json!({"kind":"result","ok":descriptor(a),"error":descriptor(b)}),
        Schema::Vector(t,n)=>json!({"kind":"vector","element":descriptor(t),"size":n}),
        _=>json!({"kind":match s {Schema::Unit=>"unit",Schema::Bool=>"bool",Schema::U32=>"u32",Schema::U64=>"u64",Schema::I32=>"i32",Schema::F32=>"f32",Schema::F64=>"f64",Schema::Int=>"int",Schema::String=>"string",Schema::Id=>"id",_=>unreachable!()}}),
    }
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Layout {
    pub program: [u8; 32],
    pub schema: [u8; 32],
    pub roots: Vec<(String, Schema, Schema)>,
    pub events: Vec<(String, Schema)>,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Event {
    pub commit: u64,
    pub position: u64,
    pub channel: usize,
    pub value: Value,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Logical {
    pub version: u64,
    pub tables: Vec<Vec<(Value, Value)>>,
    pub outbox: Vec<Event>,
}
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub bytes: usize,
    pub values: usize,
    pub depth: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            bytes: 64 * 1024 * 1024,
            values: 1_000_000,
            depth: 128,
        }
    }
}
/// Magnitude bound for one exact integer. Decimal conversion is superlinear,
/// so without it a single large Int in a snapshot takes minutes to hours.
pub const MAX_INT_BYTES: usize = 4096;
const MAGIC: &[u8; 8] = b"VLSTATE\0";
const HEADER: usize = 8 + 2 + 2 + 32 + 32 + 8;
type R<T> = Result<T, String>;
fn u64_bytes(out: &mut Vec<u8>, v: u64) {
    out.extend_from_slice(&v.to_le_bytes());
}
fn count(out: &mut Vec<u8>, n: usize) {
    u64_bytes(out, n as u64);
}
fn raw(out: &mut Vec<u8>, b: &[u8]) {
    count(out, b.len());
    out.extend_from_slice(b);
}
fn tag<'a>(v: &'a Value, name: &str) -> R<&'a Value> {
    let o = v.as_object().ok_or("expected tagged object")?;
    if o.len() != 1 {
        return Err("expected exactly one tag".into());
    }
    o.get(name).ok_or("unexpected value tag".into())
}
fn integer(v: &Value) -> R<BigInt> {
    let s = tag(v, "Int")?.as_str().ok_or("expected Int string")?;
    // Every Int within the bound has fewer than 2.41 decimal digits per byte.
    if s.len() > MAX_INT_BYTES * 5 / 2 + 1 {
        return Err("snapshot Int exceeds size limit".into());
    }
    let n = s.parse::<BigInt>().map_err(|_| "invalid Int")?;
    if n.bits() > 8 * MAX_INT_BYTES as u64 {
        return Err("snapshot Int exceeds size limit".into());
    }
    if n.to_string() != s {
        return Err("noncanonical Int".into());
    }
    Ok(n)
}
fn identifier(v: &Value) -> R<u128> {
    let s = v.as_str().ok_or("expected ID")?;
    if s.len() != 32
        || !s
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err("noncanonical ID".into());
    }
    u128::from_str_radix(s, 16).map_err(|e| e.to_string())
}
fn compare(t: &Schema, a: &Value, b: &Value) -> R<Ordering> {
    Ok(match t {
        Schema::Bool=>a.as_bool().ok_or("invalid Bool key")?.cmp(&b.as_bool().ok_or("invalid Bool key")?),
        Schema::I32 => a
            .as_i64()
            .and_then(|n| i32::try_from(n).ok())
            .ok_or("invalid i32 key")?
            .cmp(
                &b.as_i64()
                    .and_then(|n| i32::try_from(n).ok())
                    .ok_or("invalid i32 key")?,
            ),
        Schema::U32 | Schema::U64 => a
            .as_u64()
            .ok_or("invalid key")?
            .cmp(&b.as_u64().ok_or("invalid key")?),
        Schema::String => a
            .as_str()
            .ok_or("invalid key")?
            .as_bytes()
            .cmp(b.as_str().ok_or("invalid key")?.as_bytes()),
        Schema::Id => identifier(a)?.cmp(&identifier(b)?),
        _ => return Err("unsupported snapshot key schema".into()),
    })
}
fn tick(left: &mut usize, depth: usize, limits: Limits) -> R<()> {
    if *left == 0 || depth > limits.depth {
        return Err("snapshot value/depth limit exceeded".into());
    }
    *left -= 1;
    Ok(())
}
fn encode_value<'s>(
    t: &'s Schema,
    v: &Value,
    out: &mut Vec<u8>,
    left: &mut usize,
    depth: usize,
    limits: Limits,
    bindings: &mut Vec<(&'s str,&'s Schema)>,
) -> R<()> {
    tick(left, depth, limits)?;
    match t {
        Schema::Bind(name,body) => {
            bindings.push((name,body));
            let result=encode_value(body,v,out,left,depth+1,limits,bindings);
            bindings.pop();result?;
        }
        Schema::Ref(name) => {
            let body=bindings.iter().rev().find(|(n,_)|*n==name).map(|(_,s)|*s).ok_or("unbound recursive snapshot schema")?;
            encode_value(body,v,out,left,depth+1,limits,bindings)?;
        }
        Schema::Unit => {
            if !v.is_null() {
                return Err("expected Unit".into());
            }
        }
        Schema::Bool => out.push(v.as_bool().ok_or("expected Bool")? as u8),
        Schema::U32 => out.extend_from_slice(
            &u32::try_from(v.as_u64().ok_or("expected u32")?)
                .map_err(|_| "u32 overflow")?
                .to_le_bytes(),
        ),
        Schema::U64 => u64_bytes(out, v.as_u64().ok_or("expected u64")?),
        Schema::I32 => out.extend_from_slice(
            &i32::try_from(v.as_i64().ok_or("expected i32")?)
                .map_err(|_| "i32 overflow")?
                .to_le_bytes(),
        ),
        Schema::F64 => out.extend_from_slice(&f64_bits_from_json(v)?.to_le_bytes()),
        Schema::F32 => {
            let bits = if let Some(b) = v.get("F32Bits") {
                if v.as_object().is_none_or(|o| o.len() != 1) {
                    return Err("expected only F32Bits field".into());
                }
                u32::try_from(b.as_u64().ok_or("expected f32 bits")?)
                    .map_err(|_| "f32 bits overflow")?
            } else {
                let f = v.as_f64().ok_or("expected f32")? as f32;
                if !f.is_finite() {
                    return Err("finite f32 or F32Bits required".into());
                }
                f.to_bits()
            };
            out.extend_from_slice(&bits.to_le_bytes());
        }
        Schema::Vector(inner, n) => {
            if !(2..=4).contains(n)
                || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
            {
                return Err("invalid vector schema".into());
            }
            let xs = v.as_array().ok_or("expected vector")?;
            if xs.len() != *n as usize {
                return Err("vector dimension mismatch".into());
            }
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits,bindings)?;
            }
        }
        Schema::Int => {
            let n = integer(v)?;
            let (sign, b) = n.to_bytes_le();
            out.push(match sign {
                Sign::NoSign => 0,
                Sign::Plus => 1,
                Sign::Minus => 2,
            });
            if sign == Sign::NoSign {
                raw(out, &[])
            } else {
                raw(out, &b)
            }
        }
        Schema::String => raw(out, v.as_str().ok_or("expected String")?.as_bytes()),
        Schema::Id => out.extend_from_slice(&identifier(v)?.to_le_bytes()),
        Schema::Enum(names) => {
            let s = v.as_str().ok_or("expected enum string")?;
            let index = names
                .iter()
                .position(|n| n == s)
                .ok_or("unknown enum variant")?;
            out.extend_from_slice(&(index as u32).to_le_bytes());
        }
        Schema::Record(fields) => {
            let obj = v.as_object().ok_or("expected record")?;
            if obj.len() != fields.len() {
                return Err("record field mismatch".into());
            }
            for (n, t) in fields {
                encode_value(
                    t,
                    obj.get(n).ok_or("missing record field")?,
                    out,
                    left,
                    depth + 1,
                    limits,
                    bindings,
                )?;
            }
        }
        Schema::List(inner) => {
            let xs = v.as_array().ok_or("expected List")?;
            if xs.len() > *left {
                return Err("snapshot value limit exceeded".into());
            }
            count(out, xs.len());
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits,bindings)?;
            }
        }
        Schema::Option(inner) => {
            if let Ok(x) = tag(v, "Some") {
                out.push(1);
                encode_value(inner, x, out, left, depth + 1, limits,bindings)?;
            } else {
                if !tag(v, "None")?.is_null() {
                    return Err("invalid None".into());
                }
                out.push(0);
            }
        }
        Schema::Result(a, b) => {
            if let Ok(x) = tag(v, "Ok") {
                out.push(0);
                encode_value(a, x, out, left, depth + 1, limits,bindings)?;
            } else {
                out.push(1);
                encode_value(b, tag(v, "Err")?, out, left, depth + 1, limits,bindings)?;
            }
        }
    }
    if out.len() > limits.bytes {
        return Err("snapshot byte limit exceeded".into());
    }
    Ok(())
}
struct Reader<'a> {
    bytes: &'a [u8],
    at: usize,
    left: usize,
    limits: Limits,
}
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> R<&'a [u8]> {
        let end = self.at.checked_add(n).ok_or("snapshot length overflow")?;
        let b = self.bytes.get(self.at..end).ok_or("truncated snapshot")?;
        self.at = end;
        Ok(b)
    }
    fn byte(&mut self) -> R<u8> {
        Ok(self.take(1)?[0])
    }
    fn u32(&mut self) -> R<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn u64(&mut self) -> R<u64> {
        Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
    fn len(&mut self) -> R<usize> {
        usize::try_from(self.u64()?).map_err(|_| "snapshot length not addressable".into())
    }
    fn sequence(&mut self) -> R<usize> {
        let n = self.len()?;
        if n > self.left {
            return Err("snapshot value limit exceeded".into());
        }
        Ok(n)
    }
    fn raw(&mut self) -> R<&'a [u8]> {
        let n = self.len()?;
        self.take(n)
    }
    fn value(&mut self, t: &Schema, depth: usize) -> R<Value> {
        self.value_scoped(t,depth,&mut vec![])
    }
    fn value_scoped<'s>(&mut self,t:&'s Schema,depth:usize,bindings:&mut Vec<(&'s str,&'s Schema)>)->R<Value>{
        tick(&mut self.left, depth, self.limits)?;
        Ok(match t {
            Schema::Bind(name,body) => {
                bindings.push((name,body));let result=self.value_scoped(body,depth+1,bindings);bindings.pop();result?
            }
            Schema::Ref(name) => {
                let body=bindings.iter().rev().find(|(n,_)|*n==name).map(|(_,s)|*s).ok_or("unbound recursive snapshot schema")?;
                self.value_scoped(body,depth+1,bindings)?
            }
            Schema::Unit => Value::Null,
            Schema::Bool => match self.byte()? {
                0 => json!(false),
                1 => json!(true),
                _ => return Err("invalid Bool tag".into()),
            },
            Schema::U32 => json!(self.u32()?),
            Schema::U64 => json!(self.u64()?),
            Schema::I32 => json!(self.u32()? as i32),
            Schema::F64 => f64_bits_to_json(self.u64()?),
            Schema::F32 => {
                let bits = self.u32()?;
                let f = f32::from_bits(bits);
                if f.is_finite() {
                    json!(f)
                } else {
                    json!({"F32Bits":bits})
                }
            }
            Schema::Vector(inner, n) => {
                if !(2..=4).contains(n)
                    || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
                {
                    return Err("invalid vector schema".into());
                }
                (0..*n)
                    .map(|_| self.value_scoped(inner, depth + 1,bindings))
                    .collect::<R<Vec<_>>>()?
                    .into()
            }
            Schema::Int => {
                let sign = self.byte()?;
                let bytes = self.raw()?;
                if bytes.len() > MAX_INT_BYTES {
                    return Err("snapshot Int exceeds size limit".into());
                }
                let sign = match sign {
                    0 if bytes.is_empty() => Sign::NoSign,
                    1 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Plus,
                    2 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Minus,
                    _ => return Err("noncanonical signed integer".into()),
                };
                json!({"Int":BigInt::from_bytes_le(sign,bytes).to_string()})
            }
            Schema::String => json!(std::str::from_utf8(self.raw()?).map_err(|_| "invalid UTF-8")?),
            Schema::Id => json!(format!(
                "{:032x}",
                u128::from_le_bytes(self.take(16)?.try_into().unwrap())
            )),
            Schema::Enum(names) => {
                json!(names.get(self.u32()? as usize).ok_or("invalid enum tag")?)
            }
            Schema::Record(fields) => {
                let mut obj = serde_json::Map::new();
                for (n, t) in fields {
                    obj.insert(n.clone(), self.value_scoped(t, depth + 1,bindings)?);
                }
                Value::Object(obj)
            }
            Schema::List(t) => {
                let n = self.sequence()?;
                let mut xs = Vec::new();
                for _ in 0..n {
                    xs.push(self.value_scoped(t, depth + 1,bindings)?);
                }
                Value::Array(xs)
            }
            Schema::Option(t) => match self.byte()? {
                0 => json!({"None":null}),
                1 => json!({"Some":self.value_scoped(t,depth+1,bindings)?}),
                _ => return Err("invalid Option tag".into()),
            },
            Schema::Result(a, b) => match self.byte()? {
                0 => json!({"Ok":self.value_scoped(a,depth+1,bindings)?}),
                1 => json!({"Err":self.value_scoped(b,depth+1,bindings)?}),
                _ => return Err("invalid Result tag".into()),
            },
        })
    }
}
fn event_order(e: &Event, version: u64, prior: Option<(u64, u64)>) -> R<()> {
    if e.commit == 0 || e.commit > version || prior.is_some_and(|p| p >= (e.commit, e.position)) {
        return Err("invalid snapshot event sequence".into());
    }
    Ok(())
}
fn table_rows(kt:&Schema,vt:&Schema,rows:&[(Value,Value)],out:&mut Vec<u8>,left:&mut usize,limits:Limits)->R<()> {
    if rows.len()>*left/2{return Err("snapshot row limit exceeded".into());}
    count(out,rows.len());
    let mut prior=None;
    for (k,v) in rows {
        if let Some(before)=prior {
            if compare(kt,before,k)?!=Ordering::Less {return Err("snapshot keys must be strictly ordered".into());}
        }
        encode_value(kt,k,out,left,0,limits,&mut vec![])?;
        encode_value(vt,v,out,left,0,limits,&mut vec![])?;
        prior=Some(k);
    }
    Ok(())
}
/// Canonical raw table identity, including float payloads and signed zero.
pub fn table_bytes(kt:&Schema,vt:&Schema,rows:&[(Value,Value)],limits:Limits)->R<Vec<u8>> {
    let mut out=vec![];let mut left=limits.values;
    table_rows(kt,vt,rows,&mut out,&mut left,limits)?;
    if out.len()>limits.bytes{return Err("snapshot byte limit exceeded".into());}
    Ok(out)
}
pub fn encode(layout: &Layout, s: &Logical, limits: Limits) -> R<Vec<u8>> {
    if s.tables.len() != layout.roots.len() {
        return Err("snapshot root count mismatch".into());
    }
    let mut out = Vec::new();
    let mut left = limits.values;
    u64_bytes(&mut out, s.version);
    for (rows, (_, kt, vt)) in s.tables.iter().zip(&layout.roots) {
        table_rows(kt,vt,rows,&mut out,&mut left,limits)?;
    }
    count(&mut out, s.outbox.len());
    let mut prior = None;
    for e in &s.outbox {
        event_order(e, s.version, prior)?;
        let (_, t) = layout
            .events
            .get(e.channel)
            .ok_or("unknown event channel")?;
        u64_bytes(&mut out, e.commit);
        u64_bytes(&mut out, e.position);
        out.extend_from_slice(&(e.channel as u32).to_le_bytes());
        encode_value(t, &e.value, &mut out, &mut left, 0, limits,&mut vec![])?;
        prior = Some((e.commit, e.position));
    }
    if HEADER
        .checked_add(out.len())
        .and_then(|n| n.checked_add(32))
        .is_none_or(|n| n > limits.bytes)
    {
        return Err("snapshot byte limit exceeded".into());
    }
    let mut bytes = Vec::new();
    bytes.extend_from_slice(MAGIC);
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&layout.program);
    bytes.extend_from_slice(&layout.schema);
    count(&mut bytes, out.len());
    bytes.extend_from_slice(&out);
    let digest = Sha256::digest(&bytes);
    bytes.extend_from_slice(&digest);
    Ok(bytes)
}
pub fn decode(layout: &Layout, bytes: &[u8], limits: Limits) -> R<Logical> {
    if bytes.len() > limits.bytes || bytes.len() < HEADER + 32 {
        return Err("snapshot byte length invalid".into());
    }
    if &bytes[..8] != MAGIC || bytes[8..12] != [1, 0, 1, 0] {
        return Err("snapshot format or semantics version mismatch".into());
    }
    if bytes[12..44] != layout.program || bytes[44..76] != layout.schema {
        return Err("snapshot program or schema identity mismatch".into());
    }
    let n = usize::try_from(u64::from_le_bytes(bytes[76..84].try_into().unwrap()))
        .map_err(|_| "snapshot length not addressable")?;
    if HEADER.checked_add(n).and_then(|v| v.checked_add(32)) != Some(bytes.len()) {
        return Err("snapshot payload length mismatch".into());
    }
    let end = bytes.len() - 32;
    if Sha256::digest(&bytes[..end]).as_slice() != &bytes[end..] {
        return Err("snapshot integrity check failed".into());
    }
    let mut r = Reader {
        bytes: &bytes[HEADER..end],
        at: 0,
        left: limits.values,
        limits,
    };
    let version = r.u64()?;
    let mut tables = vec![];
    for (_, kt, vt) in &layout.roots {
        let n = r.sequence()?;
        if n > r.left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        let mut rows: Vec<(Value, Value)> = vec![];
        for _ in 0..n {
            let k = r.value(kt, 0)?;
            let v = r.value(vt, 0)?;
            if let Some((prior, _)) = rows.last() {
                if compare(kt, prior, &k)? != Ordering::Less {
                    return Err("duplicate or unordered snapshot key".into());
                }
            }
            rows.push((k, v));
        }
        tables.push(rows);
    }
    let n = r.sequence()?;
    let mut outbox = vec![];
    let mut prior = None;
    for _ in 0..n {
        let commit = r.u64()?;
        let position = r.u64()?;
        let channel = r.u32()? as usize;
        let (_, t) = layout
            .events
            .get(channel)
            .ok_or("unknown snapshot event channel")?;
        let value = r.value(t, 0)?;
        let e = Event {
            commit,
            position,
            channel,
            value,
        };
        event_order(&e, version, prior)?;
        prior = Some((commit, position));
        outbox.push(e);
    }
    if r.at != r.bytes.len() {
        return Err("trailing snapshot payload".into());
    }
    Ok(Logical {
        version,
        tables,
        outbox,
    })
}

#[cfg(test)]
mod recursive_schema_tests {
    use super::*;
    fn node(next:Schema)->Schema {Schema::Record(vec![("value".into(),Schema::U64),("next".into(),Schema::Option(Box::new(next)))])}
    fn layout(value:Schema)->Layout {Layout{program:[1;32],schema:[2;32],roots:vec![("Rows".into(),Schema::U64,value)],events:vec![]}}
    #[test]
    fn recursive_schema_preserves_wire_bytes_and_rejects_truncation() {
        let bound=layout(Schema::Bind("Node".into(),Box::new(node(Schema::Ref("Node".into())))));
        let unrolled=layout(node(node(Schema::Unit)));
        let logical=Logical{version:4,tables:vec![vec![(json!(3),json!({"value":7,"next":{"Some":{"value":9,"next":{"None":null}}}}))]],outbox:vec![]};
        let bytes=encode(&bound,&logical,Limits::default()).unwrap();
        assert_eq!(bytes,encode(&unrolled,&logical,Limits::default()).unwrap());
        assert_eq!(logical,decode(&bound,&bytes,Limits::default()).unwrap());
        assert!(decode(&bound,&bytes[..bytes.len()-1],Limits::default()).is_err());
        assert!(decode(&bound,&bytes,Limits{depth:3,..Limits::default()}).unwrap_err().contains("depth"));
    }
    #[test]
    fn schema_references_cannot_escape_or_loop_without_consuming_budget() {
        let logical=Logical{version:0,tables:vec![vec![(json!(0),Value::Null)]],outbox:vec![]};
        assert!(encode(&layout(Schema::Ref("Missing".into())),&logical,Limits::default()).unwrap_err().contains("unbound"));
        let cyclic=layout(Schema::Bind("X".into(),Box::new(Schema::Ref("X".into()))));
        assert!(encode(&cyclic,&logical,Limits{depth:8,..Limits::default()}).unwrap_err().contains("depth"));
    }
}

}
pub use portable::Limits as SnapshotLimits;

struct TypedSnapshotWriter{out:Vec<u8>,left:usize,limits:SnapshotLimits}
impl TypedSnapshotWriter{
 fn new(limits:SnapshotLimits)->Self{Self{out:vec![],left:limits.values,limits}}
 fn tick(&mut self,depth:usize)->Result<(),String>{if self.left==0||depth>self.limits.depth{return Err("snapshot value/depth limit exceeded".into())}self.left-=1;Ok(())}
 fn bytes(&mut self,bytes:&[u8])->Result<(),String>{self.out.extend_from_slice(bytes);Ok(())}
 fn value_end(&self)->Result<(),String>{if self.out.len()>self.limits.bytes{return Err("snapshot byte limit exceeded".into())}Ok(())}
 fn count(&mut self,n:usize)->Result<(),String>{self.bytes(&(n as u64).to_le_bytes())}
 fn rows(&mut self,n:usize)->Result<(),String>{if n>self.left/2{return Err("snapshot row limit exceeded".into())}self.count(n)}
 fn list_length(&mut self,n:usize)->Result<(),String>{if n>self.left{return Err("snapshot value limit exceeded".into())}self.count(n)}
 fn raw(&mut self,bytes:&[u8])->Result<(),String>{self.count(bytes.len())?;self.bytes(bytes)}
 fn integer(&mut self,n:&BigInt)->Result<(),String>{if n.bits()>8*portable::MAX_INT_BYTES as u64{return Err("snapshot Int exceeds size limit".into())}let(sign,bytes)=n.to_bytes_le();self.bytes(&[match sign{num_bigint::Sign::NoSign=>0,num_bigint::Sign::Plus=>1,num_bigint::Sign::Minus=>2}])?;self.raw(if sign==num_bigint::Sign::NoSign{&[]}else{&bytes})}
 fn finish(self,layout:&portable::Layout)->Result<Vec<u8>,String>{use sha2::{Digest,Sha256};if 84usize.checked_add(self.out.len()).and_then(|n|n.checked_add(32)).is_none_or(|n|n>self.limits.bytes){return Err("snapshot byte limit exceeded".into())}let mut bytes=Vec::new();bytes.extend_from_slice(b"VLSTATE\0");bytes.extend_from_slice(&[1,0,1,0]);bytes.extend_from_slice(&layout.program);bytes.extend_from_slice(&layout.schema);bytes.extend_from_slice(&(self.out.len()as u64).to_le_bytes());bytes.extend_from_slice(&self.out);let digest=Sha256::digest(&bytes);bytes.extend_from_slice(&digest);Ok(bytes)}
}
struct TypedSnapshotReader<'a>{bytes:&'a [u8],at:usize,left:usize,limits:SnapshotLimits}
impl<'a> TypedSnapshotReader<'a>{
 fn new(layout:&portable::Layout,bytes:&'a [u8],limits:SnapshotLimits)->Result<Self,String>{use sha2::{Digest,Sha256};if bytes.len()>limits.bytes||bytes.len()<116{return Err("snapshot byte length invalid".into())}if &bytes[..8]!=b"VLSTATE\0"||bytes[8..12]!=[1,0,1,0]{return Err("snapshot format or semantics version mismatch".into())}if bytes[12..44]!=layout.program||bytes[44..76]!=layout.schema{return Err("snapshot program or schema identity mismatch".into())}let n=usize::try_from(u64::from_le_bytes(bytes[76..84].try_into().unwrap())).map_err(|_|"snapshot length not addressable")?;if 84usize.checked_add(n).and_then(|v|v.checked_add(32))!=Some(bytes.len()){return Err("snapshot payload length mismatch".into())}let end=bytes.len()-32;if Sha256::digest(&bytes[..end]).as_slice()!=&bytes[end..]{return Err("snapshot integrity check failed".into())}Ok(Self{bytes:&bytes[84..end],at:0,left:limits.values,limits})}
 fn tick(&mut self,depth:usize)->Result<(),String>{if self.left==0||depth>self.limits.depth{return Err("snapshot value/depth limit exceeded".into())}self.left-=1;Ok(())}
 fn take(&mut self,n:usize)->Result<&'a [u8],String>{let end=self.at.checked_add(n).ok_or("snapshot length overflow")?;let b=self.bytes.get(self.at..end).ok_or("truncated snapshot")?;self.at=end;Ok(b)}
 fn byte(&mut self)->Result<u8,String>{Ok(self.take(1)?[0])}
 fn u32(&mut self)->Result<u32,String>{Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))}
 fn u64(&mut self)->Result<u64,String>{Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))}
 fn len(&mut self)->Result<usize,String>{usize::try_from(self.u64()?).map_err(|_|"snapshot length not addressable".into())}
 fn sequence(&mut self)->Result<usize,String>{let n=self.len()?;if n>self.left{return Err("snapshot value limit exceeded".into())}Ok(n)}
 fn raw(&mut self)->Result<&'a [u8],String>{let n=self.len()?;self.take(n)}
 fn boolean(&mut self)->Result<bool,String>{match self.byte()?{0=>Ok(false),1=>Ok(true),_=>Err("invalid Bool tag".into())}}
 fn integer(&mut self)->Result<BigInt,String>{let sign=self.byte()?;let bytes=self.raw()?;if bytes.len()>portable::MAX_INT_BYTES{return Err("snapshot Int exceeds size limit".into())}let sign=match sign{0 if bytes.is_empty()=>num_bigint::Sign::NoSign,1 if !bytes.is_empty()&&bytes.last()!=Some(&0)=>num_bigint::Sign::Plus,2 if !bytes.is_empty()&&bytes.last()!=Some(&0)=>num_bigint::Sign::Minus,_=>return Err("noncanonical signed integer".into())};Ok(BigInt::from_bytes_le(sign,bytes))}
 fn finish(self)->Result<(),String>{if self.at!=self.bytes.len(){return Err("trailing snapshot payload".into())}Ok(())}
}
fn snapshot_layout()->portable::Layout{portable::Layout{program:[140, 144, 231, 17, 2, 37, 147, 223, 132, 250, 248, 2, 69, 78, 182, 82, 69, 0, 94, 193, 200, 17, 71, 12, 194, 201, 5, 116, 74, 59, 19, 150],schema:[149, 165, 81, 3, 148, 102, 162, 137, 208, 7, 109, 190, 54, 120, 1, 205, 251, 216, 108, 170, 252, 52, 34, 249, 135, 101, 48, 190, 172, 82, 37, 69],roots:vec![
("Live".into(),portable::Schema::U64,portable::Schema::F32),
("Policy".into(),portable::Schema::U64,portable::Schema::Record(vec![("weights".into(),portable::Schema::List(Box::new(portable::Schema::F32))),("first".into(),portable::Schema::List(Box::new(portable::Schema::F32))),("second".into(),portable::Schema::List(Box::new(portable::Schema::F32))),("steps".into(),portable::Schema::U32),("first_power".into(),portable::Schema::F32),("second_power".into(),portable::Schema::F32)])),
("Structure".into(),portable::Schema::U64,portable::Schema::List(Box::new(portable::Schema::Enum(vec!["Op.Identity".into(),"Op.Scale".into(),"Op.Bias".into(),"Op.Relu".into()])))),
("Target".into(),portable::Schema::U64,portable::Schema::Record(vec![("samples".into(),portable::Schema::List(Box::new(portable::Schema::Record(vec![("input".into(),portable::Schema::F32),("target".into(),portable::Schema::F32)])))),("instruction_cost".into(),portable::Schema::F32),("version".into(),portable::Schema::U32)])),
("Weights".into(),portable::Schema::U64,portable::Schema::Record(vec![("scale".into(),portable::Schema::F32),("bias".into(),portable::Schema::F32)])),
],events:vec![("searched".into(),portable::Schema::Record(vec![("step".into(),portable::Schema::U32),("loss".into(),portable::Schema::F32),("best".into(),portable::Schema::F32),("accepted".into(),portable::Schema::Bool),("goal_version".into(),portable::Schema::U32)])),
("updated".into(),portable::Schema::Record(vec![("scale".into(),portable::Schema::F32),("bias".into(),portable::Schema::F32)])),
]}}
#[derive(Clone,Debug,PartialEq)] pub struct l_Building{pub l_choices:Vec<l_Op>,pub l_decisions:Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0>}
impl Wire for l_Building {fn to_json(&self)->Json{json!({
"choices":self.l_choices.to_json(),
"decisions":self.l_decisions.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_choices:<Vec<l_Op> as Wire>::from_json(obj.get("choices").unwrap())?,
l_decisions:<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0> as Wire>::from_json(obj.get("decisions").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l_Coefficients{pub l_scale:f32,pub l_bias:f32}
impl Wire for l_Coefficients {fn to_json(&self)->Json{json!({
"scale":self.l_scale.to_json(),
"bias":self.l_bias.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_scale:<f32 as Wire>::from_json(obj.get("scale").unwrap())?,
l_bias:<f32 as Wire>::from_json(obj.get("bias").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l_Distribution{pub l_masses:Vec<f32>,pub l_derivatives:Vec<Vec<f32>>}
impl Wire for l_Distribution {fn to_json(&self)->Json{json!({
"masses":self.l_masses.to_json(),
"derivatives":self.l_derivatives.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_masses:<Vec<f32> as Wire>::from_json(obj.get("masses").unwrap())?,
l_derivatives:<Vec<Vec<f32>> as Wire>::from_json(obj.get("derivatives").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l_Example{pub l_input:f32,pub l_target:f32}
impl Wire for l_Example {fn to_json(&self)->Json{json!({
"input":self.l_input.to_json(),
"target":self.l_target.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_input:<f32 as Wire>::from_json(obj.get("input").unwrap())?,
l_target:<f32 as Wire>::from_json(obj.get("target").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l_Goal{pub l_samples:Vec<l_Example>,pub l_instruction_cost:f32,pub l_version:u32}
impl Wire for l_Goal {fn to_json(&self)->Json{json!({
"samples":self.l_samples.to_json(),
"instruction_cost":self.l_instruction_cost.to_json(),
"version":self.l_version.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_samples:<Vec<l_Example> as Wire>::from_json(obj.get("samples").unwrap())?,
l_instruction_cost:<f32 as Wire>::from_json(obj.get("instruction_cost").unwrap())?,
l_version:<u32 as Wire>::from_json(obj.get("version").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l_MassRow{pub l_identity:f32,pub l_scale:f32,pub l_bias:f32,pub l_relu:f32}
impl Wire for l_MassRow {fn to_json(&self)->Json{json!({
"identity":self.l_identity.to_json(),
"scale":self.l_scale.to_json(),
"bias":self.l_bias.to_json(),
"relu":self.l_relu.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_identity:<f32 as Wire>::from_json(obj.get("identity").unwrap())?,
l_scale:<f32 as Wire>::from_json(obj.get("scale").unwrap())?,
l_bias:<f32 as Wire>::from_json(obj.get("bias").unwrap())?,
l_relu:<f32 as Wire>::from_json(obj.get("relu").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l_Parameters{pub l_a:l_MassRow,pub l_b:l_MassRow,pub l_c:l_MassRow,pub l_d:l_MassRow}
impl Wire for l_Parameters {fn to_json(&self)->Json{json!({
"a":self.l_a.to_json(),
"b":self.l_b.to_json(),
"c":self.l_c.to_json(),
"d":self.l_d.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_a:<l_MassRow as Wire>::from_json(obj.get("a").unwrap())?,
l_b:<l_MassRow as Wire>::from_json(obj.get("b").unwrap())?,
l_c:<l_MassRow as Wire>::from_json(obj.get("c").unwrap())?,
l_d:<l_MassRow as Wire>::from_json(obj.get("d").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq,Eq)] pub struct l_Pick{pub l_slot:u32,pub l_operation:u32}
impl Wire for l_Pick {fn to_json(&self)->Json{json!({
"slot":self.l_slot.to_json(),
"operation":self.l_operation.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_slot:<u32 as Wire>::from_json(obj.get("slot").unwrap())?,
l_operation:<u32 as Wire>::from_json(obj.get("operation").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l_Report{pub l_step:u32,pub l_loss:f32,pub l_best:f32,pub l_accepted:bool,pub l_goal_version:u32}
impl Wire for l_Report {fn to_json(&self)->Json{json!({
"step":self.l_step.to_json(),
"loss":self.l_loss.to_json(),
"best":self.l_best.to_json(),
"accepted":self.l_accepted.to_json(),
"goal_version":self.l_goal_version.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_step:<u32 as Wire>::from_json(obj.get("step").unwrap())?,
l_loss:<f32 as Wire>::from_json(obj.get("loss").unwrap())?,
l_best:<f32 as Wire>::from_json(obj.get("best").unwrap())?,
l_accepted:<bool as Wire>::from_json(obj.get("accepted").unwrap())?,
l_goal_version:<u32 as Wire>::from_json(obj.get("goal_version").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l_Sampled{pub l_code:Vec<l_Op>,pub l_decisions:Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0>}
impl Wire for l_Sampled {fn to_json(&self)->Json{json!({
"code":self.l_code.to_json(),
"decisions":self.l_decisions.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_code:<Vec<l_Op> as Wire>::from_json(obj.get("code").unwrap())?,
l_decisions:<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0> as Wire>::from_json(obj.get("decisions").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l___ink_differential_0{pub l_value:f32,pub l_tangent:f32}
impl Wire for l___ink_differential_0 {fn to_json(&self)->Json{json!({
"value":self.l_value.to_json(),
"tangent":self.l_tangent.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_value:<f32 as Wire>::from_json(obj.get("value").unwrap())?,
l_tangent:<f32 as Wire>::from_json(obj.get("tangent").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l___ink_differential_2{pub l_value:f32,pub l_tangent_0:f32,pub l_tangent_1:f32,pub l_tangent_2:f32,pub l_tangent_3:f32,pub l_tangent_4:f32,pub l_tangent_5:f32,pub l_tangent_6:f32,pub l_tangent_7:f32,pub l_tangent_8:f32,pub l_tangent_9:f32,pub l_tangent_10:f32,pub l_tangent_11:f32,pub l_tangent_12:f32,pub l_tangent_13:f32,pub l_tangent_14:f32,pub l_tangent_15:f32}
impl Wire for l___ink_differential_2 {fn to_json(&self)->Json{json!({
"value":self.l_value.to_json(),
"tangent_0":self.l_tangent_0.to_json(),
"tangent_1":self.l_tangent_1.to_json(),
"tangent_2":self.l_tangent_2.to_json(),
"tangent_3":self.l_tangent_3.to_json(),
"tangent_4":self.l_tangent_4.to_json(),
"tangent_5":self.l_tangent_5.to_json(),
"tangent_6":self.l_tangent_6.to_json(),
"tangent_7":self.l_tangent_7.to_json(),
"tangent_8":self.l_tangent_8.to_json(),
"tangent_9":self.l_tangent_9.to_json(),
"tangent_10":self.l_tangent_10.to_json(),
"tangent_11":self.l_tangent_11.to_json(),
"tangent_12":self.l_tangent_12.to_json(),
"tangent_13":self.l_tangent_13.to_json(),
"tangent_14":self.l_tangent_14.to_json(),
"tangent_15":self.l_tangent_15.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_value:<f32 as Wire>::from_json(obj.get("value").unwrap())?,
l_tangent_0:<f32 as Wire>::from_json(obj.get("tangent_0").unwrap())?,
l_tangent_1:<f32 as Wire>::from_json(obj.get("tangent_1").unwrap())?,
l_tangent_2:<f32 as Wire>::from_json(obj.get("tangent_2").unwrap())?,
l_tangent_3:<f32 as Wire>::from_json(obj.get("tangent_3").unwrap())?,
l_tangent_4:<f32 as Wire>::from_json(obj.get("tangent_4").unwrap())?,
l_tangent_5:<f32 as Wire>::from_json(obj.get("tangent_5").unwrap())?,
l_tangent_6:<f32 as Wire>::from_json(obj.get("tangent_6").unwrap())?,
l_tangent_7:<f32 as Wire>::from_json(obj.get("tangent_7").unwrap())?,
l_tangent_8:<f32 as Wire>::from_json(obj.get("tangent_8").unwrap())?,
l_tangent_9:<f32 as Wire>::from_json(obj.get("tangent_9").unwrap())?,
l_tangent_10:<f32 as Wire>::from_json(obj.get("tangent_10").unwrap())?,
l_tangent_11:<f32 as Wire>::from_json(obj.get("tangent_11").unwrap())?,
l_tangent_12:<f32 as Wire>::from_json(obj.get("tangent_12").unwrap())?,
l_tangent_13:<f32 as Wire>::from_json(obj.get("tangent_13").unwrap())?,
l_tangent_14:<f32 as Wire>::from_json(obj.get("tangent_14").unwrap())?,
l_tangent_15:<f32 as Wire>::from_json(obj.get("tangent_15").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l___ink_differential_4{pub l_a:l___ink_differential_5,pub l_b:l___ink_differential_5,pub l_c:l___ink_differential_5,pub l_d:l___ink_differential_5}
impl Wire for l___ink_differential_4 {fn to_json(&self)->Json{json!({
"a":self.l_a.to_json(),
"b":self.l_b.to_json(),
"c":self.l_c.to_json(),
"d":self.l_d.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_a:<l___ink_differential_5 as Wire>::from_json(obj.get("a").unwrap())?,
l_b:<l___ink_differential_5 as Wire>::from_json(obj.get("b").unwrap())?,
l_c:<l___ink_differential_5 as Wire>::from_json(obj.get("c").unwrap())?,
l_d:<l___ink_differential_5 as Wire>::from_json(obj.get("d").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l___ink_differential_5{pub l_identity:l___ink_differential_2,pub l_scale:l___ink_differential_2,pub l_bias:l___ink_differential_2,pub l_relu:l___ink_differential_2}
impl Wire for l___ink_differential_5 {fn to_json(&self)->Json{json!({
"identity":self.l_identity.to_json(),
"scale":self.l_scale.to_json(),
"bias":self.l_bias.to_json(),
"relu":self.l_relu.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_identity:<l___ink_differential_2 as Wire>::from_json(obj.get("identity").unwrap())?,
l_scale:<l___ink_differential_2 as Wire>::from_json(obj.get("scale").unwrap())?,
l_bias:<l___ink_differential_2 as Wire>::from_json(obj.get("bias").unwrap())?,
l_relu:<l___ink_differential_2 as Wire>::from_json(obj.get("relu").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq,Eq)] pub struct l___ink_differential_6{pub l_slot:u32,pub l_operation:u32}
impl Wire for l___ink_differential_6 {fn to_json(&self)->Json{json!({
"slot":self.l_slot.to_json(),
"operation":self.l_operation.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_slot:<u32 as Wire>::from_json(obj.get("slot").unwrap())?,
l_operation:<u32 as Wire>::from_json(obj.get("operation").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_17{pub l_i:u32,pub l_out:OwnedBuffer<f32>}
impl Wire for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_17 {fn to_json(&self)->Json{json!({
"i":self.l_i.to_json(),
"out":self.l_out.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_i:<u32 as Wire>::from_json(obj.get("i").unwrap())?,
l_out:<OwnedBuffer<f32> as Wire>::from_json(obj.get("out").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_36{pub l_accumulated:f32,pub l_found:bool,pub l_i:u32,pub l_selected:u32}
impl Wire for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_36 {fn to_json(&self)->Json{json!({
"accumulated":self.l_accumulated.to_json(),
"found":self.l_found.to_json(),
"i":self.l_i.to_json(),
"selected":self.l_selected.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_accumulated:<f32 as Wire>::from_json(obj.get("accumulated").unwrap())?,
l_found:<bool as Wire>::from_json(obj.get("found").unwrap())?,
l_i:<u32 as Wire>::from_json(obj.get("i").unwrap())?,
l_selected:<u32 as Wire>::from_json(obj.get("selected").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_5{pub l_i:u32,pub l_maximum:f32}
impl Wire for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_5 {fn to_json(&self)->Json{json!({
"i":self.l_i.to_json(),
"maximum":self.l_maximum.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_i:<u32 as Wire>::from_json(obj.get("i").unwrap())?,
l_maximum:<f32 as Wire>::from_json(obj.get("maximum").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_52{pub l_correction:Vec<f32>,pub l_i:u32}
impl Wire for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_52 {fn to_json(&self)->Json{json!({
"correction":self.l_correction.to_json(),
"i":self.l_i.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_correction:<Vec<f32> as Wire>::from_json(obj.get("correction").unwrap())?,
l_i:<u32 as Wire>::from_json(obj.get("i").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_72{pub l_accumulator:Result<Vec<f32>,String>,pub l_i:u32}
impl Wire for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_72 {fn to_json(&self)->Json{json!({
"accumulator":self.l_accumulator.to_json(),
"i":self.l_i.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_accumulator:<Result<Vec<f32>,String> as Wire>::from_json(obj.get("accumulator").unwrap())?,
l_i:<u32 as Wire>::from_json(obj.get("i").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_87{pub l_i:u32,pub l_next:f32,pub l_reversed:OwnedBuffer<f32>}
impl Wire for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_87 {fn to_json(&self)->Json{json!({
"i":self.l_i.to_json(),
"next":self.l_next.to_json(),
"reversed":self.l_reversed.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_i:<u32 as Wire>::from_json(obj.get("i").unwrap())?,
l_next:<f32 as Wire>::from_json(obj.get("next").unwrap())?,
l_reversed:<OwnedBuffer<f32> as Wire>::from_json(obj.get("reversed").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_99{pub l_i:u32,pub l_out:OwnedBuffer<f32>}
impl Wire for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_99 {fn to_json(&self)->Json{json!({
"i":self.l_i.to_json(),
"out":self.l_out.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_i:<u32 as Wire>::from_json(obj.get("i").unwrap())?,
l_out:<OwnedBuffer<f32> as Wire>::from_json(obj.get("out").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l___ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_24{pub l_first:OwnedBuffer<f32>,pub l_i:u32,pub l_second:OwnedBuffer<f32>,pub l_weights:OwnedBuffer<f32>}
impl Wire for l___ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_24 {fn to_json(&self)->Json{json!({
"first":self.l_first.to_json(),
"i":self.l_i.to_json(),
"second":self.l_second.to_json(),
"weights":self.l_weights.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_first:<OwnedBuffer<f32> as Wire>::from_json(obj.get("first").unwrap())?,
l_i:<u32 as Wire>::from_json(obj.get("i").unwrap())?,
l_second:<OwnedBuffer<f32> as Wire>::from_json(obj.get("second").unwrap())?,
l_weights:<OwnedBuffer<f32> as Wire>::from_json(obj.get("weights").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l___ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_5{pub l_adjusted:OwnedBuffer<f32>,pub l_i:u32}
impl Wire for l___ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_5 {fn to_json(&self)->Json{json!({
"adjusted":self.l_adjusted.to_json(),
"i":self.l_i.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_adjusted:<OwnedBuffer<f32> as Wire>::from_json(obj.get("adjusted").unwrap())?,
l_i:<u32 as Wire>::from_json(obj.get("i").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0{pub l_action:u32,pub l_probability:f32,pub l_score:Vec<f32>}
impl Wire for l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0 {fn to_json(&self)->Json{json!({
"action":self.l_action.to_json(),
"probability":self.l_probability.to_json(),
"score":self.l_score.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_action:<u32 as Wire>::from_json(obj.get("action").unwrap())?,
l_probability:<f32 as Wire>::from_json(obj.get("probability").unwrap())?,
l_score:<Vec<f32> as Wire>::from_json(obj.get("score").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249{pub l_rate:f32,pub l_first_decay:f32,pub l_second_decay:f32,pub l_epsilon:f32,pub l_weight_decay:f32,pub l_norm_limit:f32}
impl Wire for l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249 {fn to_json(&self)->Json{json!({
"rate":self.l_rate.to_json(),
"first_decay":self.l_first_decay.to_json(),
"second_decay":self.l_second_decay.to_json(),
"epsilon":self.l_epsilon.to_json(),
"weight_decay":self.l_weight_decay.to_json(),
"norm_limit":self.l_norm_limit.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_rate:<f32 as Wire>::from_json(obj.get("rate").unwrap())?,
l_first_decay:<f32 as Wire>::from_json(obj.get("first_decay").unwrap())?,
l_second_decay:<f32 as Wire>::from_json(obj.get("second_decay").unwrap())?,
l_epsilon:<f32 as Wire>::from_json(obj.get("epsilon").unwrap())?,
l_weight_decay:<f32 as Wire>::from_json(obj.get("weight_decay").unwrap())?,
l_norm_limit:<f32 as Wire>::from_json(obj.get("norm_limit").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq)] pub struct l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab{pub l_weights:Vec<f32>,pub l_first:Vec<f32>,pub l_second:Vec<f32>,pub l_steps:u32,pub l_first_power:f32,pub l_second_power:f32}
impl Wire for l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab {fn to_json(&self)->Json{json!({
"weights":self.l_weights.to_json(),
"first":self.l_first.to_json(),
"second":self.l_second.to_json(),
"steps":self.l_steps.to_json(),
"first_power":self.l_first_power.to_json(),
"second_power":self.l_second_power.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_weights:<Vec<f32> as Wire>::from_json(obj.get("weights").unwrap())?,
l_first:<Vec<f32> as Wire>::from_json(obj.get("first").unwrap())?,
l_second:<Vec<f32> as Wire>::from_json(obj.get("second").unwrap())?,
l_steps:<u32 as Wire>::from_json(obj.get("steps").unwrap())?,
l_first_power:<f32 as Wire>::from_json(obj.get("first_power").unwrap())?,
l_second_power:<f32 as Wire>::from_json(obj.get("second_power").unwrap())?,
})}}
#[derive(Clone,Copy,Debug,PartialEq,Eq)] pub enum l_Op{l_Identity,l_Scale,l_Bias,l_Relu}
impl Wire for l_Op{fn to_json(&self)->Json{match self{
Self::l_Identity=>json!("Op.Identity"),
Self::l_Scale=>json!("Op.Scale"),
Self::l_Bias=>json!("Op.Bias"),
Self::l_Relu=>json!("Op.Relu"),
}}fn from_json(v:&Json)->Result<Self,String>{match v.as_str(){Some("Op.Identity")=>Ok(Self::l_Identity),
Some("Op.Scale")=>Ok(Self::l_Scale),
Some("Op.Bias")=>Ok(Self::l_Bias),
Some("Op.Relu")=>Ok(Self::l_Relu),
_=>unreachable!("caller enum precondition")}}}
impl InkDataEq for l_Op {fn ink_data_eq(&self,other:&Self)->bool{self==other}}
impl InkDataEq for l_Building {fn ink_data_eq(&self,other:&Self)->bool{self.l_choices.ink_data_eq(&other.l_choices)&&self.l_decisions.ink_data_eq(&other.l_decisions)}}
impl InkDataEq for l_Coefficients {fn ink_data_eq(&self,other:&Self)->bool{self.l_scale.ink_data_eq(&other.l_scale)&&self.l_bias.ink_data_eq(&other.l_bias)}}
impl InkDataEq for l_Distribution {fn ink_data_eq(&self,other:&Self)->bool{self.l_masses.ink_data_eq(&other.l_masses)&&self.l_derivatives.ink_data_eq(&other.l_derivatives)}}
impl InkDataEq for l_Example {fn ink_data_eq(&self,other:&Self)->bool{self.l_input.ink_data_eq(&other.l_input)&&self.l_target.ink_data_eq(&other.l_target)}}
impl InkDataEq for l_Goal {fn ink_data_eq(&self,other:&Self)->bool{self.l_samples.ink_data_eq(&other.l_samples)&&self.l_instruction_cost.ink_data_eq(&other.l_instruction_cost)&&self.l_version.ink_data_eq(&other.l_version)}}
impl InkDataEq for l_MassRow {fn ink_data_eq(&self,other:&Self)->bool{self.l_identity.ink_data_eq(&other.l_identity)&&self.l_scale.ink_data_eq(&other.l_scale)&&self.l_bias.ink_data_eq(&other.l_bias)&&self.l_relu.ink_data_eq(&other.l_relu)}}
impl InkDataEq for l_Parameters {fn ink_data_eq(&self,other:&Self)->bool{self.l_a.ink_data_eq(&other.l_a)&&self.l_b.ink_data_eq(&other.l_b)&&self.l_c.ink_data_eq(&other.l_c)&&self.l_d.ink_data_eq(&other.l_d)}}
impl InkDataEq for l_Pick {fn ink_data_eq(&self,other:&Self)->bool{self.l_slot.ink_data_eq(&other.l_slot)&&self.l_operation.ink_data_eq(&other.l_operation)}}
impl InkDataEq for l_Report {fn ink_data_eq(&self,other:&Self)->bool{self.l_step.ink_data_eq(&other.l_step)&&self.l_loss.ink_data_eq(&other.l_loss)&&self.l_best.ink_data_eq(&other.l_best)&&self.l_accepted.ink_data_eq(&other.l_accepted)&&self.l_goal_version.ink_data_eq(&other.l_goal_version)}}
impl InkDataEq for l_Sampled {fn ink_data_eq(&self,other:&Self)->bool{self.l_code.ink_data_eq(&other.l_code)&&self.l_decisions.ink_data_eq(&other.l_decisions)}}
impl InkDataEq for l___ink_differential_0 {fn ink_data_eq(&self,other:&Self)->bool{self.l_value.ink_data_eq(&other.l_value)&&self.l_tangent.ink_data_eq(&other.l_tangent)}}
impl InkDataEq for l___ink_differential_2 {fn ink_data_eq(&self,other:&Self)->bool{self.l_value.ink_data_eq(&other.l_value)&&self.l_tangent_0.ink_data_eq(&other.l_tangent_0)&&self.l_tangent_1.ink_data_eq(&other.l_tangent_1)&&self.l_tangent_2.ink_data_eq(&other.l_tangent_2)&&self.l_tangent_3.ink_data_eq(&other.l_tangent_3)&&self.l_tangent_4.ink_data_eq(&other.l_tangent_4)&&self.l_tangent_5.ink_data_eq(&other.l_tangent_5)&&self.l_tangent_6.ink_data_eq(&other.l_tangent_6)&&self.l_tangent_7.ink_data_eq(&other.l_tangent_7)&&self.l_tangent_8.ink_data_eq(&other.l_tangent_8)&&self.l_tangent_9.ink_data_eq(&other.l_tangent_9)&&self.l_tangent_10.ink_data_eq(&other.l_tangent_10)&&self.l_tangent_11.ink_data_eq(&other.l_tangent_11)&&self.l_tangent_12.ink_data_eq(&other.l_tangent_12)&&self.l_tangent_13.ink_data_eq(&other.l_tangent_13)&&self.l_tangent_14.ink_data_eq(&other.l_tangent_14)&&self.l_tangent_15.ink_data_eq(&other.l_tangent_15)}}
impl InkDataEq for l___ink_differential_4 {fn ink_data_eq(&self,other:&Self)->bool{self.l_a.ink_data_eq(&other.l_a)&&self.l_b.ink_data_eq(&other.l_b)&&self.l_c.ink_data_eq(&other.l_c)&&self.l_d.ink_data_eq(&other.l_d)}}
impl InkDataEq for l___ink_differential_5 {fn ink_data_eq(&self,other:&Self)->bool{self.l_identity.ink_data_eq(&other.l_identity)&&self.l_scale.ink_data_eq(&other.l_scale)&&self.l_bias.ink_data_eq(&other.l_bias)&&self.l_relu.ink_data_eq(&other.l_relu)}}
impl InkDataEq for l___ink_differential_6 {fn ink_data_eq(&self,other:&Self)->bool{self.l_slot.ink_data_eq(&other.l_slot)&&self.l_operation.ink_data_eq(&other.l_operation)}}
impl InkDataEq for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_17 {fn ink_data_eq(&self,other:&Self)->bool{self.l_i.ink_data_eq(&other.l_i)&&self.l_out.ink_data_eq(&other.l_out)}}
impl InkDataEq for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_36 {fn ink_data_eq(&self,other:&Self)->bool{self.l_accumulated.ink_data_eq(&other.l_accumulated)&&self.l_found.ink_data_eq(&other.l_found)&&self.l_i.ink_data_eq(&other.l_i)&&self.l_selected.ink_data_eq(&other.l_selected)}}
impl InkDataEq for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_5 {fn ink_data_eq(&self,other:&Self)->bool{self.l_i.ink_data_eq(&other.l_i)&&self.l_maximum.ink_data_eq(&other.l_maximum)}}
impl InkDataEq for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_52 {fn ink_data_eq(&self,other:&Self)->bool{self.l_correction.ink_data_eq(&other.l_correction)&&self.l_i.ink_data_eq(&other.l_i)}}
impl InkDataEq for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_72 {fn ink_data_eq(&self,other:&Self)->bool{self.l_accumulator.ink_data_eq(&other.l_accumulator)&&self.l_i.ink_data_eq(&other.l_i)}}
impl InkDataEq for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_87 {fn ink_data_eq(&self,other:&Self)->bool{self.l_i.ink_data_eq(&other.l_i)&&self.l_next.ink_data_eq(&other.l_next)&&self.l_reversed.ink_data_eq(&other.l_reversed)}}
impl InkDataEq for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_99 {fn ink_data_eq(&self,other:&Self)->bool{self.l_i.ink_data_eq(&other.l_i)&&self.l_out.ink_data_eq(&other.l_out)}}
impl InkDataEq for l___ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_24 {fn ink_data_eq(&self,other:&Self)->bool{self.l_first.ink_data_eq(&other.l_first)&&self.l_i.ink_data_eq(&other.l_i)&&self.l_second.ink_data_eq(&other.l_second)&&self.l_weights.ink_data_eq(&other.l_weights)}}
impl InkDataEq for l___ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_5 {fn ink_data_eq(&self,other:&Self)->bool{self.l_adjusted.ink_data_eq(&other.l_adjusted)&&self.l_i.ink_data_eq(&other.l_i)}}
impl InkDataEq for l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0 {fn ink_data_eq(&self,other:&Self)->bool{self.l_action.ink_data_eq(&other.l_action)&&self.l_probability.ink_data_eq(&other.l_probability)&&self.l_score.ink_data_eq(&other.l_score)}}
impl InkDataEq for l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249 {fn ink_data_eq(&self,other:&Self)->bool{self.l_rate.ink_data_eq(&other.l_rate)&&self.l_first_decay.ink_data_eq(&other.l_first_decay)&&self.l_second_decay.ink_data_eq(&other.l_second_decay)&&self.l_epsilon.ink_data_eq(&other.l_epsilon)&&self.l_weight_decay.ink_data_eq(&other.l_weight_decay)&&self.l_norm_limit.ink_data_eq(&other.l_norm_limit)}}
impl InkDataEq for l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab {fn ink_data_eq(&self,other:&Self)->bool{self.l_weights.ink_data_eq(&other.l_weights)&&self.l_first.ink_data_eq(&other.l_first)&&self.l_second.ink_data_eq(&other.l_second)&&self.l_steps.ink_data_eq(&other.l_steps)&&self.l_first_power.ink_data_eq(&other.l_first_power)&&self.l_second_power.ink_data_eq(&other.l_second_power)}}
#[derive(Clone,Debug)] pub enum EventData {
l_searched(l_Report),
l_updated(l_Coefficients),
}
impl EventData {fn wire(&self)->(&'static str,Json){match *self {
Self::l_searched(ref v)=>("searched",v.to_json()),
Self::l_updated(ref v)=>("updated",v.to_json()),
}}}
enum Undo {
l_Structure {key:u64,old:Option<Vec<l_Op>>},
l_Weights {key:u64,old:Option<l_Coefficients>},
l_Policy {key:u64,old:Option<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab>},
l_Target {key:u64,old:Option<l_Goal>},
l_Live {key:u64,old:Option<f32>},
}
struct HostTransaction {version:u64,removed:Vec<Event>}
pub struct State {version:u64,staged:Vec<EventData>,outbox:Vec<Event>,undo:Vec<Undo>,host:Option<HostTransaction>,
l_Structure:InkTable<u64,Vec<l_Op>>,
journal_keys_l_Structure:std::collections::BTreeSet<u64>,
l_Weights:InkTable<u64,l_Coefficients>,
journal_keys_l_Weights:std::collections::BTreeSet<u64>,
l_Policy:InkTable<u64,l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab>,
journal_keys_l_Policy:std::collections::BTreeSet<u64>,
l_Target:InkTable<u64,l_Goal>,
journal_keys_l_Target:std::collections::BTreeSet<u64>,
l_Live:InkTable<u64,f32>,
journal_keys_l_Live:std::collections::BTreeSet<u64>,
}
impl Default for State {fn default()->Self{Self::new()}}
impl State {pub fn parallel_statistics()->Json{let(n,ids,last)=temporary::ink_parallel_statistics();json!({"workers":n,"workerIds":ids,"lastWorkerIds":last})} pub fn new()->Self{Self{version:0,staged:vec![],outbox:vec![],undo:vec![],host:None,
l_Structure:InkTable::new(),
journal_keys_l_Structure:std::collections::BTreeSet::new(),
l_Weights:InkTable::new(),
journal_keys_l_Weights:std::collections::BTreeSet::new(),
l_Policy:InkTable::new(),
journal_keys_l_Policy:std::collections::BTreeSet::new(),
l_Target:InkTable::new(),
journal_keys_l_Target:std::collections::BTreeSet::new(),
l_Live:InkTable::new(),
journal_keys_l_Live:std::collections::BTreeSet::new(),
}}
pub fn begin_transaction(&mut self)->Result<bool,String>{if self.host.is_some()||!self.undo.is_empty()||!self.staged.is_empty(){return Err("transaction already in progress".into())}self.host=Some(HostTransaction{version:self.version,removed:vec![]});Ok(true)}
 pub fn commit_transaction(&mut self){self.host=None;self.undo.clear();self.clear_journal_keys();}
 pub fn rollback_transaction(&mut self){if let Some(host)=self.host.take(){self.rollback();self.version=host.version;self.outbox.retain(|e|e.commit<=host.version);let mut restored=host.removed;restored.append(&mut self.outbox);self.outbox=restored;}}
pub fn version(&self)->u64{self.version}
pub fn outbox(&self)->&[Event]{&self.outbox}
pub fn acknowledge_through(&mut self,commit:u64,position:u64){let old=std::mem::take(&mut self.outbox);for e in old{if(e.commit,e.position)>(commit,position){self.outbox.push(e)}else if let Some(host)=&mut self.host{host.removed.push(e)}}}
pub fn checkpoint(&self)->Result<Vec<u8>,String>{self.checkpoint_with_limits(SnapshotLimits::default())}
pub fn checkpoint_with_limits(&self,limits:SnapshotLimits)->Result<Vec<u8>,String>{if (self.host.is_none()&&!self.undo.is_empty())||!self.staged.is_empty(){return Err("checkpoint requires transaction boundary".into())}let layout=snapshot_layout();let mut writer=TypedSnapshotWriter::new(limits);writer.bytes(&self.version.to_le_bytes())?;writer.rows(self.l_Live.len())?;let mut previous=None;for(key,value)in self.l_Live.iter(){if previous.is_some_and(|p|p>=key){return Err("snapshot keys must be strictly ordered".into())}previous=Some(key);writer.tick(0)?;writer.bytes(&(key).to_le_bytes())?;writer.value_end()?;writer.tick(0)?;writer.bytes(&(value).to_bits().to_le_bytes())?;writer.value_end()?;}writer.rows(self.l_Policy.len())?;let mut previous=None;for(key,value)in self.l_Policy.iter(){if previous.is_some_and(|p|p>=key){return Err("snapshot keys must be strictly ordered".into())}previous=Some(key);writer.tick(0)?;writer.bytes(&(key).to_le_bytes())?;writer.value_end()?;writer.tick(0)?;writer.tick(1)?;writer.list_length((&(value).l_weights).len())?;for snapshot_item_1 in (&(value).l_weights).iter(){writer.tick(2)?;writer.bytes(&(snapshot_item_1).to_bits().to_le_bytes())?;writer.value_end()?;
}writer.value_end()?;writer.tick(1)?;writer.list_length((&(value).l_first).len())?;for snapshot_item_2 in (&(value).l_first).iter(){writer.tick(2)?;writer.bytes(&(snapshot_item_2).to_bits().to_le_bytes())?;writer.value_end()?;
}writer.value_end()?;writer.tick(1)?;writer.list_length((&(value).l_second).len())?;for snapshot_item_3 in (&(value).l_second).iter(){writer.tick(2)?;writer.bytes(&(snapshot_item_3).to_bits().to_le_bytes())?;writer.value_end()?;
}writer.value_end()?;writer.tick(1)?;writer.bytes(&(&(value).l_steps).to_le_bytes())?;writer.value_end()?;writer.tick(1)?;writer.bytes(&(&(value).l_first_power).to_bits().to_le_bytes())?;writer.value_end()?;writer.tick(1)?;writer.bytes(&(&(value).l_second_power).to_bits().to_le_bytes())?;writer.value_end()?;writer.value_end()?;}writer.rows(self.l_Structure.len())?;let mut previous=None;for(key,value)in self.l_Structure.iter(){if previous.is_some_and(|p|p>=key){return Err("snapshot keys must be strictly ordered".into())}previous=Some(key);writer.tick(0)?;writer.bytes(&(key).to_le_bytes())?;writer.value_end()?;writer.tick(0)?;writer.list_length((value).len())?;for snapshot_item_4 in (value).iter(){writer.tick(1)?;writer.bytes(&(match snapshot_item_4{l_Op::l_Identity=>0u32,l_Op::l_Scale=>1u32,l_Op::l_Bias=>2u32,l_Op::l_Relu=>3u32,}).to_le_bytes())?;writer.value_end()?;
}writer.value_end()?;}writer.rows(self.l_Target.len())?;let mut previous=None;for(key,value)in self.l_Target.iter(){if previous.is_some_and(|p|p>=key){return Err("snapshot keys must be strictly ordered".into())}previous=Some(key);writer.tick(0)?;writer.bytes(&(key).to_le_bytes())?;writer.value_end()?;writer.tick(0)?;writer.tick(1)?;writer.list_length((&(value).l_samples).len())?;for snapshot_item_5 in (&(value).l_samples).iter(){writer.tick(2)?;writer.tick(3)?;writer.bytes(&(&(snapshot_item_5).l_input).to_bits().to_le_bytes())?;writer.value_end()?;writer.tick(3)?;writer.bytes(&(&(snapshot_item_5).l_target).to_bits().to_le_bytes())?;writer.value_end()?;writer.value_end()?;
}writer.value_end()?;writer.tick(1)?;writer.bytes(&(&(value).l_instruction_cost).to_bits().to_le_bytes())?;writer.value_end()?;writer.tick(1)?;writer.bytes(&(&(value).l_version).to_le_bytes())?;writer.value_end()?;writer.value_end()?;}writer.rows(self.l_Weights.len())?;let mut previous=None;for(key,value)in self.l_Weights.iter(){if previous.is_some_and(|p|p>=key){return Err("snapshot keys must be strictly ordered".into())}previous=Some(key);writer.tick(0)?;writer.bytes(&(key).to_le_bytes())?;writer.value_end()?;writer.tick(0)?;writer.tick(1)?;writer.bytes(&(&(value).l_scale).to_bits().to_le_bytes())?;writer.value_end()?;writer.tick(1)?;writer.bytes(&(&(value).l_bias).to_bits().to_le_bytes())?;writer.value_end()?;writer.value_end()?;}writer.count(self.outbox.len())?;let mut prior=None;for event in &self.outbox{if event.commit==0||event.commit>self.version||prior.is_some_and(|p|p>=(event.commit,event.position)){return Err("invalid snapshot event sequence".into())}writer.bytes(&event.commit.to_le_bytes())?;writer.bytes(&event.position.to_le_bytes())?;match &event.data{EventData::l_searched(value)=>{writer.bytes(&(0u32).to_le_bytes())?;writer.tick(0)?;writer.tick(1)?;writer.bytes(&(&(value).l_step).to_le_bytes())?;writer.value_end()?;writer.tick(1)?;writer.bytes(&(&(value).l_loss).to_bits().to_le_bytes())?;writer.value_end()?;writer.tick(1)?;writer.bytes(&(&(value).l_best).to_bits().to_le_bytes())?;writer.value_end()?;writer.tick(1)?;writer.bytes(&[(*(&(value).l_accepted)) as u8])?;writer.value_end()?;writer.tick(1)?;writer.bytes(&(&(value).l_goal_version).to_le_bytes())?;writer.value_end()?;writer.value_end()?;},EventData::l_updated(value)=>{writer.bytes(&(1u32).to_le_bytes())?;writer.tick(0)?;writer.tick(1)?;writer.bytes(&(&(value).l_scale).to_bits().to_le_bytes())?;writer.value_end()?;writer.tick(1)?;writer.bytes(&(&(value).l_bias).to_bits().to_le_bytes())?;writer.value_end()?;writer.value_end()?;},}prior=Some((event.commit,event.position));}writer.finish(&layout)}
pub fn restore(bytes:&[u8])->Result<Self,String>{Self::restore_with_limits(bytes,SnapshotLimits::default())}
pub fn restore_with_limits(bytes:&[u8],limits:SnapshotLimits)->Result<Self,String>{let layout=snapshot_layout();let mut reader=TypedSnapshotReader::new(&layout,bytes,limits)?;let mut state=Self::new();state.version=reader.u64()?;let count=reader.sequence()?;if count>reader.left/2{return Err("snapshot row limit exceeded".into())}let mut previous=None;for _ in 0..count{let key={reader.tick(0)?;reader.u64()?};let value={reader.tick(0)?;f32::from_bits(reader.u32()?)};if previous.as_ref().is_some_and(|p|p>=&key){return Err("duplicate or unordered snapshot key".into())}previous=Some(key.clone());state.l_Live.insert(key,value);}let count=reader.sequence()?;if count>reader.left/2{return Err("snapshot row limit exceeded".into())}let mut previous=None;for _ in 0..count{let key={reader.tick(0)?;reader.u64()?};let value={reader.tick(0)?;l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab{l_weights:{reader.tick(1)?;{let count=reader.sequence()?;let mut snapshot_values_1:Vec<f32>=Default::default();for _ in 0..count{snapshot_values_1.push({reader.tick(2)?;f32::from_bits(reader.u32()?)});}snapshot_values_1}},l_first:{reader.tick(1)?;{let count=reader.sequence()?;let mut snapshot_values_2:Vec<f32>=Default::default();for _ in 0..count{snapshot_values_2.push({reader.tick(2)?;f32::from_bits(reader.u32()?)});}snapshot_values_2}},l_second:{reader.tick(1)?;{let count=reader.sequence()?;let mut snapshot_values_3:Vec<f32>=Default::default();for _ in 0..count{snapshot_values_3.push({reader.tick(2)?;f32::from_bits(reader.u32()?)});}snapshot_values_3}},l_steps:{reader.tick(1)?;reader.u32()?},l_first_power:{reader.tick(1)?;f32::from_bits(reader.u32()?)},l_second_power:{reader.tick(1)?;f32::from_bits(reader.u32()?)},}};if previous.as_ref().is_some_and(|p|p>=&key){return Err("duplicate or unordered snapshot key".into())}previous=Some(key.clone());state.l_Policy.insert(key,value);}let count=reader.sequence()?;if count>reader.left/2{return Err("snapshot row limit exceeded".into())}let mut previous=None;for _ in 0..count{let key={reader.tick(0)?;reader.u64()?};let value={reader.tick(0)?;{let count=reader.sequence()?;let mut snapshot_values_4:Vec<l_Op>=Default::default();for _ in 0..count{snapshot_values_4.push({reader.tick(1)?;match reader.u32()?{0=>l_Op::l_Identity,1=>l_Op::l_Scale,2=>l_Op::l_Bias,3=>l_Op::l_Relu,_=>return Err("invalid enum tag".into())}});}snapshot_values_4}};if previous.as_ref().is_some_and(|p|p>=&key){return Err("duplicate or unordered snapshot key".into())}previous=Some(key.clone());state.l_Structure.insert(key,value);}let count=reader.sequence()?;if count>reader.left/2{return Err("snapshot row limit exceeded".into())}let mut previous=None;for _ in 0..count{let key={reader.tick(0)?;reader.u64()?};let value={reader.tick(0)?;l_Goal{l_samples:{reader.tick(1)?;{let count=reader.sequence()?;let mut snapshot_values_5:Vec<l_Example>=Default::default();for _ in 0..count{snapshot_values_5.push({reader.tick(2)?;l_Example{l_input:{reader.tick(3)?;f32::from_bits(reader.u32()?)},l_target:{reader.tick(3)?;f32::from_bits(reader.u32()?)},}});}snapshot_values_5}},l_instruction_cost:{reader.tick(1)?;f32::from_bits(reader.u32()?)},l_version:{reader.tick(1)?;reader.u32()?},}};if previous.as_ref().is_some_and(|p|p>=&key){return Err("duplicate or unordered snapshot key".into())}previous=Some(key.clone());state.l_Target.insert(key,value);}let count=reader.sequence()?;if count>reader.left/2{return Err("snapshot row limit exceeded".into())}let mut previous=None;for _ in 0..count{let key={reader.tick(0)?;reader.u64()?};let value={reader.tick(0)?;l_Coefficients{l_scale:{reader.tick(1)?;f32::from_bits(reader.u32()?)},l_bias:{reader.tick(1)?;f32::from_bits(reader.u32()?)},}};if previous.as_ref().is_some_and(|p|p>=&key){return Err("duplicate or unordered snapshot key".into())}previous=Some(key.clone());state.l_Weights.insert(key,value);}let count=reader.sequence()?;let mut prior=None;for _ in 0..count{let commit=reader.u64()?;let position=reader.u64()?;let channel=reader.u32()?;let data=match channel{0=>EventData::l_searched({reader.tick(0)?;l_Report{l_step:{reader.tick(1)?;reader.u32()?},l_loss:{reader.tick(1)?;f32::from_bits(reader.u32()?)},l_best:{reader.tick(1)?;f32::from_bits(reader.u32()?)},l_accepted:{reader.tick(1)?;reader.boolean()?},l_goal_version:{reader.tick(1)?;reader.u32()?},}}),1=>EventData::l_updated({reader.tick(0)?;l_Coefficients{l_scale:{reader.tick(1)?;f32::from_bits(reader.u32()?)},l_bias:{reader.tick(1)?;f32::from_bits(reader.u32()?)},}}),_=>return Err("unknown snapshot event channel".into())};if commit==0||commit>state.version||prior.is_some_and(|p|p>=(commit,position)){return Err("invalid snapshot event sequence".into())}prior=Some((commit,position));state.outbox.push(Event{commit,position,data});}reader.finish()?;Ok(state)}
fn set_l_Structure(&mut self,key:u64,value:Option<Vec<l_Op>>,return_old:bool)->Option<Vec<l_Op>>{
let old=match value{Some(v)=>self.l_Structure.insert(key.clone(),v),None=>self.l_Structure.remove(&key)};
let result=if return_old{old.clone()}else{None};if self.journal_keys_l_Structure.insert(key.clone()){self.undo.push(Undo::l_Structure{key,old});}
result}
fn set_l_Weights(&mut self,key:u64,value:Option<l_Coefficients>,return_old:bool)->Option<l_Coefficients>{
let old=match value{Some(v)=>self.l_Weights.insert(key.clone(),v),None=>self.l_Weights.remove(&key)};
let result=if return_old{old.clone()}else{None};if self.journal_keys_l_Weights.insert(key.clone()){self.undo.push(Undo::l_Weights{key,old});}
result}
fn set_l_Policy(&mut self,key:u64,value:Option<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab>,return_old:bool)->Option<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab>{
let old=match value{Some(v)=>self.l_Policy.insert(key.clone(),v),None=>self.l_Policy.remove(&key)};
let result=if return_old{old.clone()}else{None};if self.journal_keys_l_Policy.insert(key.clone()){self.undo.push(Undo::l_Policy{key,old});}
result}
fn set_l_Target(&mut self,key:u64,value:Option<l_Goal>,return_old:bool)->Option<l_Goal>{
let old=match value{Some(v)=>self.l_Target.insert(key.clone(),v),None=>self.l_Target.remove(&key)};
let result=if return_old{old.clone()}else{None};if self.journal_keys_l_Target.insert(key.clone()){self.undo.push(Undo::l_Target{key,old});}
result}
fn set_l_Live(&mut self,key:u64,value:Option<f32>,return_old:bool)->Option<f32>{
let old=match value{Some(v)=>self.l_Live.insert(key.clone(),v),None=>self.l_Live.remove(&key)};
let result=if return_old{old.clone()}else{None};if self.journal_keys_l_Live.insert(key.clone()){self.undo.push(Undo::l_Live{key,old});}
result}
fn rollback(&mut self){self.rollback_to(0);}
fn rollback_to(&mut self,mark:usize){for undo in self.undo.drain(mark..).rev(){match undo{
Undo::l_Structure{key,old}=>{match old{Some(v)=>{self.l_Structure.insert(key,v);},None=>{self.l_Structure.remove(&key);}}},
Undo::l_Weights{key,old}=>{match old{Some(v)=>{self.l_Weights.insert(key,v);},None=>{self.l_Weights.remove(&key);}}},
Undo::l_Policy{key,old}=>{match old{Some(v)=>{self.l_Policy.insert(key,v);},None=>{self.l_Policy.remove(&key);}}},
Undo::l_Target{key,old}=>{match old{Some(v)=>{self.l_Target.insert(key,v);},None=>{self.l_Target.remove(&key);}}},
Undo::l_Live{key,old}=>{match old{Some(v)=>{self.l_Live.insert(key,v);},None=>{self.l_Live.remove(&key);}}},
}}self.clear_journal_keys();self.staged.clear();}
fn clear_journal_keys(&mut self){self.journal_keys_l_Structure.clear();
self.journal_keys_l_Weights.clear();
self.journal_keys_l_Policy.clear();
self.journal_keys_l_Target.clear();
self.journal_keys_l_Live.clear();
}
pub fn function_l_evaluate(&self,l_code:Vec<l_Op>,l_w:l_Coefficients,l_input:f32)->f32{{let ink_local_3=(l_code).into_iter();let mut ink_local_2=l_input;for ink_local_0 in ink_local_3 {let ink_local_1=ink_local_2;ink_local_2=if InkDataEq::ink_data_eq(&(ink_local_0.clone()),&(l_Op::l_Scale)) {temporary::ink_f32((ink_local_1) * (((l_w).l_scale).clone()))} else {if InkDataEq::ink_data_eq(&(ink_local_0.clone()),&(l_Op::l_Bias)) {temporary::ink_f32((ink_local_1) + (((l_w).l_bias).clone()))} else {if InkDataEq::ink_data_eq(&(ink_local_0),&(l_Op::l_Relu)) {if ((ink_local_1.clone()) > (f32::from_bits(0u32))) {ink_local_1} else {f32::from_bits(0u32)}} else {ink_local_1}}};}ink_local_2}}
pub fn function_l_coefficients_valid(&self,l_w:l_Coefficients)->bool{(((((((((((((l_w).l_scale).clone()).is_finite()) && (((((l_w).l_scale).clone()) >= (f32::from_bits(1048576000u32)))))) && ((((l_w).l_scale) <= (f32::from_bits(1065353216u32)))))) && ((((l_w).l_bias).clone()).is_finite()))) && (((((l_w).l_bias).clone()) >= (f32::from_bits(0u32)))))) && ((((l_w).l_bias) <= (f32::from_bits(1056964608u32)))))}
pub fn function_l_goal_valid(&self,l_g:l_Goal)->bool{((((((((((((((l_g).l_samples).len() as u32) > (0u32))) && (((((l_g).l_samples).len() as u32) <= (32u32))))) && ((((l_g).l_instruction_cost).clone()).is_finite()))) && (((((l_g).l_instruction_cost).clone()) >= (f32::from_bits(0u32)))))) && ((((l_g).l_instruction_cost) <= (f32::from_bits(1008981770u32)))))) && ({let ink_local_3=((l_g).l_samples).into_iter();let mut ink_local_2=true;for ink_local_0 in ink_local_3 {let ink_local_1=ink_local_2;ink_local_2=((((((((((((ink_local_1) && ((((ink_local_0).l_input).clone()).is_finite()))) && (((((ink_local_0).l_input).clone()) >= (f32::from_bits((f32::from_bits(1082130432u32)).to_bits() ^ 0x80000000)))))) && ((((ink_local_0).l_input) <= (f32::from_bits(1082130432u32)))))) && ((((ink_local_0).l_target).clone()).is_finite()))) && (((((ink_local_0).l_target).clone()) >= (f32::from_bits((f32::from_bits(1107296256u32)).to_bits() ^ 0x80000000)))))) && ((((ink_local_0).l_target) <= (f32::from_bits(1107296256u32)))));}ink_local_2}))}
pub fn function_l_squared_error(&self,l_code:Vec<l_Op>,l_w:l_Coefficients,l_s:l_Example)->f32{{let ink_local_3:f32=temporary::ink_f32(({let ink_local_0=l_code;let ink_local_1=l_w;let ink_local_2=(l_s).l_input;self.function_l_evaluate(ink_local_0,ink_local_1,ink_local_2)}) - ((l_s).l_target));temporary::ink_f32((ink_local_3.clone()) * (ink_local_3))}}
pub fn function_l_objective(&self,l_code:Vec<l_Op>,l_w:l_Coefficients,l_g:l_Goal)->f32{{let ink_local_7:f32={let ink_local_6=((l_g).l_samples).iter();let mut ink_local_5=f32::from_bits(0u32);for ink_local_0 in ink_local_6 {let ink_local_1=ink_local_5;ink_local_5=temporary::ink_f32((ink_local_1) + ({let ink_local_2=l_code.clone();let ink_local_3=l_w.clone();let ink_local_4=(*ink_local_0).clone();self.function_l_squared_error(ink_local_2,ink_local_3,ink_local_4)}));}ink_local_5};{let ink_local_12:f32={let ink_local_11=(l_code).into_iter();let mut ink_local_10=f32::from_bits(0u32);for ink_local_8 in ink_local_11 {let ink_local_9=ink_local_10;ink_local_10=temporary::ink_f32((ink_local_9) + (if InkDataEq::ink_data_eq(&(ink_local_8),&(l_Op::l_Identity)) {f32::from_bits(0u32)} else {f32::from_bits(1065353216u32)}));}ink_local_10};temporary::ink_f32((temporary::ink_f32_div(ink_local_7,(((l_g).l_samples).len() as u32) as f32)) + (temporary::ink_f32(((l_g).l_instruction_cost) * (ink_local_12))))}}}
pub fn function_l_unpack(&self,l_xs:Vec<f32>)->l_Parameters{{let ink_local_12={let ink_local_2={let ink_local_0=&(l_xs);let ink_local_1=0u32;match ink_local_0.get(ink_local_1 as usize){Some(v)=>v.clone(),None=>f32::from_bits(1065353216u32)}};let ink_local_5={let ink_local_3=&(l_xs);let ink_local_4=1u32;match ink_local_3.get(ink_local_4 as usize){Some(v)=>v.clone(),None=>f32::from_bits(1065353216u32)}};let ink_local_8={let ink_local_6=&(l_xs);let ink_local_7=2u32;match ink_local_6.get(ink_local_7 as usize){Some(v)=>v.clone(),None=>f32::from_bits(1065353216u32)}};let ink_local_11={let ink_local_9=&(l_xs);let ink_local_10=3u32;match ink_local_9.get(ink_local_10 as usize){Some(v)=>v.clone(),None=>f32::from_bits(1065353216u32)}};l_MassRow{l_identity:ink_local_2,l_scale:ink_local_5,l_bias:ink_local_8,l_relu:ink_local_11}};let ink_local_25={let ink_local_15={let ink_local_13=&(l_xs);let ink_local_14=4u32;match ink_local_13.get(ink_local_14 as usize){Some(v)=>v.clone(),None=>f32::from_bits(1065353216u32)}};let ink_local_18={let ink_local_16=&(l_xs);let ink_local_17=5u32;match ink_local_16.get(ink_local_17 as usize){Some(v)=>v.clone(),None=>f32::from_bits(1065353216u32)}};let ink_local_21={let ink_local_19=&(l_xs);let ink_local_20=6u32;match ink_local_19.get(ink_local_20 as usize){Some(v)=>v.clone(),None=>f32::from_bits(1065353216u32)}};let ink_local_24={let ink_local_22=&(l_xs);let ink_local_23=7u32;match ink_local_22.get(ink_local_23 as usize){Some(v)=>v.clone(),None=>f32::from_bits(1065353216u32)}};l_MassRow{l_identity:ink_local_15,l_scale:ink_local_18,l_bias:ink_local_21,l_relu:ink_local_24}};let ink_local_38={let ink_local_28={let ink_local_26=&(l_xs);let ink_local_27=8u32;match ink_local_26.get(ink_local_27 as usize){Some(v)=>v.clone(),None=>f32::from_bits(1065353216u32)}};let ink_local_31={let ink_local_29=&(l_xs);let ink_local_30=9u32;match ink_local_29.get(ink_local_30 as usize){Some(v)=>v.clone(),None=>f32::from_bits(1065353216u32)}};let ink_local_34={let ink_local_32=&(l_xs);let ink_local_33=10u32;match ink_local_32.get(ink_local_33 as usize){Some(v)=>v.clone(),None=>f32::from_bits(1065353216u32)}};let ink_local_37={let ink_local_35=&(l_xs);let ink_local_36=11u32;match ink_local_35.get(ink_local_36 as usize){Some(v)=>v.clone(),None=>f32::from_bits(1065353216u32)}};l_MassRow{l_identity:ink_local_28,l_scale:ink_local_31,l_bias:ink_local_34,l_relu:ink_local_37}};let ink_local_51={let ink_local_41={let ink_local_39=&(l_xs);let ink_local_40=12u32;match ink_local_39.get(ink_local_40 as usize){Some(v)=>v.clone(),None=>f32::from_bits(1065353216u32)}};let ink_local_44={let ink_local_42=&(l_xs);let ink_local_43=13u32;match ink_local_42.get(ink_local_43 as usize){Some(v)=>v.clone(),None=>f32::from_bits(1065353216u32)}};let ink_local_47={let ink_local_45=&(l_xs);let ink_local_46=14u32;match ink_local_45.get(ink_local_46 as usize){Some(v)=>v.clone(),None=>f32::from_bits(1065353216u32)}};let ink_local_50={let ink_local_48=&(l_xs);let ink_local_49=15u32;match ink_local_48.get(ink_local_49 as usize){Some(v)=>v.clone(),None=>f32::from_bits(1065353216u32)}};l_MassRow{l_identity:ink_local_41,l_scale:ink_local_44,l_bias:ink_local_47,l_relu:ink_local_50}};l_Parameters{l_a:ink_local_12,l_b:ink_local_25,l_c:ink_local_38,l_d:ink_local_51}}}
pub fn function_l_pack(&self,l_w:l_Parameters)->Vec<f32>{vec![((l_w).l_a).l_identity,((l_w).l_a).l_scale,((l_w).l_a).l_bias,((l_w).l_a).l_relu,((l_w).l_b).l_identity,((l_w).l_b).l_scale,((l_w).l_b).l_bias,((l_w).l_b).l_relu,((l_w).l_c).l_identity,((l_w).l_c).l_scale,((l_w).l_c).l_bias,((l_w).l_c).l_relu,((l_w).l_d).l_identity,((l_w).l_d).l_scale,((l_w).l_d).l_bias,((l_w).l_d).l_relu]}
pub fn function_l_mass(&self,l_w:l_Parameters,l_p:l_Pick)->f32{{let ink_local_0:l_MassRow=if InkDataEq::ink_data_eq(&(((l_p).l_slot).clone()),&(0u32)) {(l_w).l_a} else {if InkDataEq::ink_data_eq(&(((l_p).l_slot).clone()),&(1u32)) {(l_w).l_b} else {if InkDataEq::ink_data_eq(&((l_p).l_slot),&(2u32)) {(l_w).l_c} else {(l_w).l_d}}};{let ink_local_1:f32=if InkDataEq::ink_data_eq(&(((l_p).l_operation).clone()),&(0u32)) {(ink_local_0).l_identity} else {if InkDataEq::ink_data_eq(&(((l_p).l_operation).clone()),&(1u32)) {(ink_local_0).l_scale} else {if InkDataEq::ink_data_eq(&((l_p).l_operation),&(2u32)) {(ink_local_0).l_bias} else {(ink_local_0).l_relu}}};temporary::ink_f32((temporary::ink_f32((ink_local_1.clone()) * (ink_local_1))) + (f32::from_bits(1036831949u32)))}}}
pub fn function_l_operation(&self,l_index:u32)->l_Op{if InkDataEq::ink_data_eq(&(l_index.clone()),&(0u32)) {l_Op::l_Identity} else {if InkDataEq::ink_data_eq(&(l_index.clone()),&(1u32)) {l_Op::l_Scale} else {if InkDataEq::ink_data_eq(&(l_index),&(2u32)) {l_Op::l_Bias} else {l_Op::l_Relu}}}}
pub fn function_l_distribution(&self,l_w:l_Parameters,l_slot:u32)->l_Distribution{{let ink_local_2:l_Pick={let ink_local_0=l_slot.clone();let ink_local_1=0u32;l_Pick{l_slot:ink_local_0,l_operation:ink_local_1}};{let ink_local_5:l_Pick={let ink_local_3=l_slot.clone();let ink_local_4=1u32;l_Pick{l_slot:ink_local_3,l_operation:ink_local_4}};{let ink_local_8:l_Pick={let ink_local_6=l_slot.clone();let ink_local_7=2u32;l_Pick{l_slot:ink_local_6,l_operation:ink_local_7}};{let ink_local_11:l_Pick={let ink_local_9=l_slot;let ink_local_10=3u32;l_Pick{l_slot:ink_local_9,l_operation:ink_local_10}};{let ink_local_20=vec![{let ink_local_12=l_w.clone();let ink_local_13=ink_local_2.clone();self.function_l_mass(ink_local_12,ink_local_13)},{let ink_local_14=l_w.clone();let ink_local_15=ink_local_5.clone();self.function_l_mass(ink_local_14,ink_local_15)},{let ink_local_16=l_w.clone();let ink_local_17=ink_local_8.clone();self.function_l_mass(ink_local_16,ink_local_17)},{let ink_local_18=l_w.clone();let ink_local_19=ink_local_11.clone();self.function_l_mass(ink_local_18,ink_local_19)}];let ink_local_33=vec![{let ink_local_23={let ink_local_21=l_w.clone();let ink_local_22=ink_local_2;self.function_l___ink_differential_1(ink_local_21,ink_local_22)};self.function_l_pack(ink_local_23)},{let ink_local_26={let ink_local_24=l_w.clone();let ink_local_25=ink_local_5;self.function_l___ink_differential_1(ink_local_24,ink_local_25)};self.function_l_pack(ink_local_26)},{let ink_local_29={let ink_local_27=l_w.clone();let ink_local_28=ink_local_8;self.function_l___ink_differential_1(ink_local_27,ink_local_28)};self.function_l_pack(ink_local_29)},{let ink_local_32={let ink_local_30=l_w;let ink_local_31=ink_local_11;self.function_l___ink_differential_1(ink_local_30,ink_local_31)};self.function_l_pack(ink_local_32)}];l_Distribution{l_masses:ink_local_20,l_derivatives:ink_local_33}}}}}}}
pub fn function_l_sample_slot(&self,l_accumulator:Result<l_Building,String>,l_slot:u32,l_w:l_Parameters,l_units:Vec<f32>)->Result<l_Building,String>{match l_accumulator {Ok(ink_local_0)=>{{let ink_local_1:l_Building=ink_local_0;{let ink_local_4:l_Distribution={let ink_local_2=l_w;let ink_local_3=l_slot.clone();self.function_l_distribution(ink_local_2,ink_local_3)};match {let ink_local_5=(ink_local_4).l_masses;let ink_local_6=(ink_local_4).l_derivatives;let ink_local_7=vec![true,true,true,true];let ink_local_10={let ink_local_8=&(l_units);let ink_local_9=l_slot;match ink_local_8.get(ink_local_9 as usize){Some(v)=>v.clone(),None=>f32::from_bits((f32::from_bits(1065353216u32)).to_bits() ^ 0x80000000)}};self.function_l_ink_m1fbf7ee6cef3bcca5d7d258c8606275806894b60d839126202d17f016ea87c80(ink_local_5,ink_local_6,ink_local_7,ink_local_10)} {Ok(ink_local_11)=>{{let ink_local_12:l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0=ink_local_11;Ok({let ink_local_16={let ink_local_14=&((ink_local_1).l_choices);let ink_local_15=&(vec![{let ink_local_13=((ink_local_12).l_action).clone();self.function_l_operation(ink_local_13)}]);(ink_local_14.iter().chain(ink_local_15.iter()).cloned()).collect::<Vec<l_Op>>()};let ink_local_19={let ink_local_17=&((ink_local_1).l_decisions);let ink_local_18=&(vec![ink_local_12]);(ink_local_17.iter().chain(ink_local_18.iter()).cloned()).collect::<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0>>()};l_Building{l_choices:ink_local_16,l_decisions:ink_local_19}})}},Err(ink_local_20)=>{Err(ink_local_20)}}}}},Err(ink_local_21)=>{Err(ink_local_21)}}}
pub fn function_l_sample(&self,l_weights:Vec<f32>,l_units:Vec<f32>)->Result<l_Sampled,String>{if ((!InkDataEq::ink_data_eq(&((l_weights).len() as u32),&(16u32))) || (!InkDataEq::ink_data_eq(&((l_units).len() as u32),&(4u32)))) {Err("policy shape".to_owned())} else {{let ink_local_1:l_Parameters={let ink_local_0=l_weights;self.function_l_unpack(ink_local_0)};{let ink_local_2:Vec<u32>=vec![0u32,1u32,2u32,3u32];{let ink_local_5:Result<l_Building,String>=Ok({let ink_local_3=vec![];let ink_local_4=vec![];l_Building{l_choices:ink_local_3,l_decisions:ink_local_4}});match {let ink_local_13=(ink_local_2).into_iter();let mut ink_local_12=ink_local_5;for ink_local_6 in ink_local_13 {let ink_local_7=ink_local_12;ink_local_12={let ink_local_8=ink_local_7;let ink_local_9=ink_local_6;let ink_local_10=ink_local_1.clone();let ink_local_11=l_units.clone();self.function_l_sample_slot(ink_local_8,ink_local_9,ink_local_10,ink_local_11)};}ink_local_12} {Ok(ink_local_14)=>{{let ink_local_15:l_Building=ink_local_14;{let ink_local_16:Vec<l_Op>=vec![];{let ink_local_22:Vec<l_Op>={let mut ink_local_21=ink_local_16;for ink_local_17 in 0..8u32 {let ink_local_18=ink_local_21;ink_local_21={let ink_local_19=&(ink_local_18);let ink_local_20=&((ink_local_15).l_choices);(ink_local_19.iter().chain(ink_local_20.iter()).cloned()).collect::<Vec<l_Op>>()};}ink_local_21};Ok({let ink_local_23=ink_local_22;let ink_local_24=(ink_local_15).l_decisions;l_Sampled{l_code:ink_local_23,l_decisions:ink_local_24}})}}}},Err(ink_local_25)=>{Err(ink_local_25)}}}}}}}
pub fn function_l_reward(&self,l_loss:f32)->f32{temporary::ink_f32_div(f32::from_bits((l_loss.clone()).to_bits() ^ 0x80000000),temporary::ink_f32((f32::from_bits(1065353216u32)) + (l_loss)))}
pub fn function_l_operation_index(&self,l_op:l_Op)->u32{if InkDataEq::ink_data_eq(&(l_op.clone()),&(l_Op::l_Identity)) {0u32} else {if InkDataEq::ink_data_eq(&(l_op.clone()),&(l_Op::l_Scale)) {1u32} else {if InkDataEq::ink_data_eq(&(l_op),&(l_Op::l_Bias)) {2u32} else {3u32}}}}
pub fn function_l_elite_slot(&self,l_accumulator:Result<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0>,String>,l_slot:u32,l_w:l_Parameters,l_code:Vec<l_Op>)->Result<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0>,String>{match l_accumulator {Ok(ink_local_0)=>{{let ink_local_1:Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0>=ink_local_0;{let ink_local_4:l_Distribution={let ink_local_2=l_w;let ink_local_3=l_slot.clone();self.function_l_distribution(ink_local_2,ink_local_3)};match {let ink_local_5=(ink_local_4).l_masses;let ink_local_6=(ink_local_4).l_derivatives;let ink_local_7=vec![true,true,true,true];let ink_local_11={let ink_local_10={let ink_local_8=&(l_code);let ink_local_9=l_slot;match ink_local_8.get(ink_local_9 as usize){Some(v)=>v.clone(),None=>l_Op::l_Identity}};self.function_l_operation_index(ink_local_10)};self.function_l_ink_m99468fca85aa8fb996f0c891430c813d82505250d39d8e415bf27679ddc39e07(ink_local_5,ink_local_6,ink_local_7,ink_local_11)} {Ok(ink_local_12)=>{{let ink_local_13:l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0=ink_local_12;Ok({let ink_local_14=&(ink_local_1);let ink_local_15=&(vec![ink_local_13]);(ink_local_14.iter().chain(ink_local_15.iter()).cloned()).collect::<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0>>()})}},Err(ink_local_16)=>{Err(ink_local_16)}}}}},Err(ink_local_17)=>{Err(ink_local_17)}}}
pub fn function_l_proposal_gradient(&self,l_weights:Vec<f32>,l_selected:Vec<l_Op>,l_sampled:Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0>,l_loss:f32,l_before:f32)->Result<Vec<f32>,String>{if InkDataEq::ink_data_eq(&((l_selected).len() as u32),&(32u32)) {{let ink_local_0:Vec<u32>=vec![0u32,1u32,2u32,3u32];{let ink_local_1:Result<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0>,String>=Ok(vec![]);{let ink_local_3:l_Parameters={let ink_local_2=l_weights;self.function_l_unpack(ink_local_2)};match {let ink_local_11=(ink_local_0).into_iter();let mut ink_local_10=ink_local_1;for ink_local_4 in ink_local_11 {let ink_local_5=ink_local_10;ink_local_10={let ink_local_6=ink_local_5;let ink_local_7=ink_local_4;let ink_local_8=ink_local_3.clone();let ink_local_9=l_selected.clone();self.function_l_elite_slot(ink_local_6,ink_local_7,ink_local_8,ink_local_9)};}ink_local_10} {Ok(ink_local_12)=>{{let ink_local_13:Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0>=ink_local_12;{let ink_local_14=ink_local_13;let ink_local_15=f32::from_bits(1065353216u32);let ink_local_16=f32::from_bits(0u32);self.function_l_ink_m4b5ada8f7d6b3beaee6fc06bf68e61ca158cbc7664899364dff18d21555697ae(ink_local_14,ink_local_15,ink_local_16)}}},Err(ink_local_17)=>{Err(ink_local_17)}}}}}} else {{let ink_local_18=l_sampled;let ink_local_20={let ink_local_19=l_loss;self.function_l_reward(ink_local_19)};let ink_local_22={let ink_local_21=l_before;self.function_l_reward(ink_local_21)};self.function_l_ink_m4b5ada8f7d6b3beaee6fc06bf68e61ca158cbc7664899364dff18d21555697ae(ink_local_18,ink_local_20,ink_local_22)}}}
pub fn function_l_valid_policy(&self,l_p:l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab)->bool{(((({let ink_local_0=l_p.clone();self.function_l_ink_m786bdc6011aece08dbf36c5ca89c437e06ff758c9d3d242f723dde2af6ea31db(ink_local_0)}) && (InkDataEq::ink_data_eq(&(((l_p).l_weights).len() as u32),&(16u32))))) && ({let ink_local_4=((l_p).l_weights).into_iter();let mut ink_local_3=true;for ink_local_1 in ink_local_4 {let ink_local_2=ink_local_3;ink_local_3=((((ink_local_2) && (((ink_local_1.clone()) >= (f32::from_bits((f32::from_bits(1090519040u32)).to_bits() ^ 0x80000000)))))) && (((ink_local_1) <= (f32::from_bits(1090519040u32)))));}ink_local_3}))}
pub fn function_l_numeric(&self,l_xs:Vec<f32>)->Vec<f32>{(((l_xs).into_iter()).map(|ink_local_0|temporary::ink_f32((temporary::ink_f32((ink_local_0.clone()) * (ink_local_0))) + (f32::from_bits(1056964608u32))))).collect::<Vec<f32>>()}
pub fn function_l_ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54(&self,l_xs:Vec<f32>)->bool{{let ink_local_3=(l_xs).into_iter();let mut ink_local_2=true;for ink_local_0 in ink_local_3 {let ink_local_1=ink_local_2;ink_local_2=((ink_local_1) && ((ink_local_0).is_finite()));}ink_local_2}}
pub fn function_l_ink_m28a5428efa573345218636e9cec104f24b6e8c67d7c4c0f979b255813b2abee3(&self,l_masses:Vec<f32>,l_allowed:Vec<bool>)->f32{{let ink_local_0:f32=f32::from_bits(0u32);{let ink_local_1:u32=0u32;{let ink_local_19:l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_5={let ink_local_18=(l_masses).into_iter();let mut ink_local_17={let ink_local_2=ink_local_1;let ink_local_3=ink_local_0;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_5{l_i:ink_local_2,l_maximum:ink_local_3}};for ink_local_4 in ink_local_18 {let ink_local_5=ink_local_17;ink_local_17={let ink_local_6:u32=(ink_local_5).l_i;{let ink_local_7:f32=(ink_local_5).l_maximum;if (({let ink_local_8=&(l_allowed);let ink_local_9=ink_local_6.clone();match ink_local_8.get(ink_local_9 as usize){Some(v)=>v.clone(),None=>false}}) && (((ink_local_4.clone()) > (ink_local_7.clone())))) {{let ink_local_10:f32=ink_local_4;{let ink_local_11:u32=(ink_local_6).wrapping_add(1u32);{let ink_local_12=ink_local_11;let ink_local_13=ink_local_10;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_5{l_i:ink_local_12,l_maximum:ink_local_13}}}}} else {{let ink_local_14:u32=(ink_local_6).wrapping_add(1u32);{let ink_local_15=ink_local_14;let ink_local_16=ink_local_7;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_5{l_i:ink_local_15,l_maximum:ink_local_16}}}}}};}ink_local_17};{let ink_local_20:u32=(ink_local_19).l_i;{let ink_local_21:f32=(ink_local_19).l_maximum;ink_local_21}}}}}}
pub fn function_l_ink_mfd18151b0af45b45f5b48ef5e7a09ac1294681f654e2174ae3b33183f445ef14(&self,l_masses:Vec<f32>,l_allowed:Vec<bool>)->Result<Vec<f32>,String>{if ((((((((InkDataEq::ink_data_eq(&((l_masses).len() as u32),&(0u32))) || ((((l_masses).len() as u32) > (256u32))))) || (!InkDataEq::ink_data_eq(&((l_allowed).len() as u32),&((l_masses).len() as u32))))) || (InkDataEq::ink_data_eq(&({let ink_local_0=l_masses.clone();self.function_l_ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54(ink_local_0)}),&(false))))) || (InkDataEq::ink_data_eq(&({let ink_local_4=(l_masses).iter();let mut ink_local_3=true;for ink_local_1 in ink_local_4 {let ink_local_2=ink_local_3;ink_local_3=((ink_local_2) && ((((*ink_local_1).clone()) >= (f32::from_bits(0u32)))));}ink_local_3}),&(false)))) {Err("policy shape or mass domain".to_owned())} else {{let ink_local_7:f32={let ink_local_5=l_masses.clone();let ink_local_6=l_allowed.clone();self.function_l_ink_m28a5428efa573345218636e9cec104f24b6e8c67d7c4c0f979b255813b2abee3(ink_local_5,ink_local_6)};if ((ink_local_7.clone()) == (f32::from_bits(0u32))) {Err("no positive allowed policy mass".to_owned())} else {{let ink_local_8:OwnedBuffer<f32>=<OwnedBuffer<f32>>::new(Default::default());{let ink_local_9:u32=0u32;{let ink_local_24:l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_17={let ink_local_23=(l_masses).into_iter();let mut ink_local_22={let ink_local_10=ink_local_9;let ink_local_11=ink_local_8;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_17{l_i:ink_local_10,l_out:ink_local_11}};for ink_local_12 in ink_local_23 {let ink_local_13=ink_local_22;ink_local_22={let ink_local_14:u32=(ink_local_13).l_i;{let ink_local_15:OwnedBuffer<f32>=(ink_local_13).l_out;{let ink_local_18:OwnedBuffer<f32>=(ink_local_15).push(if {let ink_local_16=&(l_allowed);let ink_local_17=ink_local_14.clone();match ink_local_16.get(ink_local_17 as usize){Some(v)=>v.clone(),None=>false}} {temporary::ink_f32_div(ink_local_12,ink_local_7.clone())} else {f32::from_bits(0u32)});{let ink_local_19:u32=(ink_local_14).wrapping_add(1u32);{let ink_local_20=ink_local_19;let ink_local_21=ink_local_18;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_17{l_i:ink_local_20,l_out:ink_local_21}}}}}};}ink_local_22};{let ink_local_25:u32=(ink_local_24).l_i;{let ink_local_26:OwnedBuffer<f32>=(ink_local_24).l_out;Ok((ink_local_26).freeze())}}}}}}}}}
pub fn function_l_ink_mc05a2256079ef1f1818d13e69727dc7902cdb7f70856a671af2ba08ef190d23a(&self,l_masses:Vec<f32>,l_allowed:Vec<bool>)->Result<Vec<f32>,String>{match {let ink_local_0=l_masses;let ink_local_1=l_allowed;self.function_l_ink_mfd18151b0af45b45f5b48ef5e7a09ac1294681f654e2174ae3b33183f445ef14(ink_local_0,ink_local_1)} {Ok(ink_local_2)=>{{let ink_local_3:Vec<f32>=ink_local_2;{let ink_local_8:f32={let ink_local_7=(ink_local_3).iter();let mut ink_local_6=f32::from_bits(0u32);for ink_local_4 in ink_local_7 {let ink_local_5=ink_local_6;ink_local_6=temporary::ink_f32((ink_local_5) + ((*ink_local_4).clone()));}ink_local_6};Ok((((ink_local_3).into_iter()).map(|ink_local_9|temporary::ink_f32_div(ink_local_9,ink_local_8.clone()))).collect::<Vec<f32>>())}}},Err(ink_local_10)=>{Err(ink_local_10)}}}
pub fn function_l_ink_m6ec6e8f9e757c220bfe2ed28cbb8dab4ec520de5ee8de5ca702cbdb805a5f910(&self,l_scaled:Vec<f32>,l_unit:f32,l_total:f32)->u32{{let ink_local_0:f32=temporary::ink_f32((l_unit) * (l_total));{let ink_local_1:f32=f32::from_bits(0u32);{let ink_local_2:u32=0u32;{let ink_local_3:bool=false;{let ink_local_4:u32=0u32;{let ink_local_44:l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_36={let ink_local_43=(l_scaled).into_iter();let mut ink_local_42={let ink_local_5=ink_local_1;let ink_local_6=ink_local_3;let ink_local_7=ink_local_4;let ink_local_8=ink_local_2;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_36{l_accumulated:ink_local_5,l_found:ink_local_6,l_i:ink_local_7,l_selected:ink_local_8}};for ink_local_9 in ink_local_43 {let ink_local_10=ink_local_42;ink_local_42={let ink_local_11:f32=(ink_local_10).l_accumulated;{let ink_local_12:bool=(ink_local_10).l_found;{let ink_local_13:u32=(ink_local_10).l_i;{let ink_local_14:u32=(ink_local_10).l_selected;if ((((ink_local_9.clone()) > (f32::from_bits(0u32)))) && (InkDataEq::ink_data_eq(&(ink_local_12.clone()),&(false)))) {{let ink_local_15:u32=ink_local_13.clone();{let ink_local_16:f32=temporary::ink_f32((ink_local_11) + (ink_local_9.clone()));if ((((((ink_local_9) > (f32::from_bits(0u32)))) && (InkDataEq::ink_data_eq(&(ink_local_12.clone()),&(false))))) && (((ink_local_0.clone()) < (ink_local_16.clone())))) {{let ink_local_17:u32=ink_local_13.clone();{let ink_local_18:bool=true;{let ink_local_19:u32=(ink_local_13).wrapping_add(1u32);{let ink_local_20=ink_local_16;let ink_local_21=ink_local_18;let ink_local_22=ink_local_19;let ink_local_23=ink_local_17;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_36{l_accumulated:ink_local_20,l_found:ink_local_21,l_i:ink_local_22,l_selected:ink_local_23}}}}}} else {{let ink_local_24:u32=(ink_local_13).wrapping_add(1u32);{let ink_local_25=ink_local_16;let ink_local_26=ink_local_12;let ink_local_27=ink_local_24;let ink_local_28=ink_local_15;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_36{l_accumulated:ink_local_25,l_found:ink_local_26,l_i:ink_local_27,l_selected:ink_local_28}}}}}}} else {{let ink_local_29:f32=temporary::ink_f32((ink_local_11) + (ink_local_9.clone()));if ((((((ink_local_9) > (f32::from_bits(0u32)))) && (InkDataEq::ink_data_eq(&(ink_local_12.clone()),&(false))))) && (((ink_local_0.clone()) < (ink_local_29.clone())))) {{let ink_local_30:u32=ink_local_13.clone();{let ink_local_31:bool=true;{let ink_local_32:u32=(ink_local_13).wrapping_add(1u32);{let ink_local_33=ink_local_29;let ink_local_34=ink_local_31;let ink_local_35=ink_local_32;let ink_local_36=ink_local_30;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_36{l_accumulated:ink_local_33,l_found:ink_local_34,l_i:ink_local_35,l_selected:ink_local_36}}}}}} else {{let ink_local_37:u32=(ink_local_13).wrapping_add(1u32);{let ink_local_38=ink_local_29;let ink_local_39=ink_local_12;let ink_local_40=ink_local_37;let ink_local_41=ink_local_14;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_36{l_accumulated:ink_local_38,l_found:ink_local_39,l_i:ink_local_40,l_selected:ink_local_41}}}}}}}}}};}ink_local_42};{let ink_local_45:f32=(ink_local_44).l_accumulated;{let ink_local_46:bool=(ink_local_44).l_found;{let ink_local_47:u32=(ink_local_44).l_i;{let ink_local_48:u32=(ink_local_44).l_selected;ink_local_48}}}}}}}}}}}
pub fn function_l_ink_maa2c8802d351b443dda0bc206d70fa9fe87756b57a84d0357e9dfb4c1e7a0667(&self,l_derivatives:Vec<Vec<f32>>,l_allowed:Vec<bool>,l_maximum:f32,l_total:f32)->Vec<f32>{{let ink_local_3:Vec<f32>=((({let ink_local_0=&(l_derivatives);let ink_local_1=0u32;match ink_local_0.get(ink_local_1 as usize){Some(v)=>v.clone(),None=>vec![]}}).into_iter()).map(|ink_local_2|f32::from_bits(0u32))).collect::<Vec<f32>>();{let ink_local_4:u32=0u32;{let ink_local_26:l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_52={let ink_local_25=(l_derivatives).into_iter();let mut ink_local_24={let ink_local_5=ink_local_3;let ink_local_6=ink_local_4;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_52{l_correction:ink_local_5,l_i:ink_local_6}};for ink_local_7 in ink_local_25 {let ink_local_8=ink_local_24;ink_local_24={let ink_local_9:Vec<f32>=(ink_local_8).l_correction;{let ink_local_10:u32=(ink_local_8).l_i;if {let ink_local_11=&(l_allowed);let ink_local_12=ink_local_10.clone();match ink_local_11.get(ink_local_12 as usize){Some(v)=>v.clone(),None=>false}} {{let ink_local_17:Vec<f32>={let ink_local_15=(ink_local_9).into_iter();let ink_local_16=(ink_local_7).into_iter();(ink_local_15.zip(ink_local_16).map(|(ink_local_13,ink_local_14)|temporary::ink_f32((ink_local_13) + (temporary::ink_f32_div(temporary::ink_f32_div(ink_local_14,l_maximum.clone()),l_total.clone()))))).collect::<Vec<f32>>()};{let ink_local_18:u32=(ink_local_10).wrapping_add(1u32);{let ink_local_19=ink_local_17;let ink_local_20=ink_local_18;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_52{l_correction:ink_local_19,l_i:ink_local_20}}}}} else {{let ink_local_21:u32=(ink_local_10).wrapping_add(1u32);{let ink_local_22=ink_local_9;let ink_local_23=ink_local_21;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_52{l_correction:ink_local_22,l_i:ink_local_23}}}}}};}ink_local_24};{let ink_local_27:Vec<f32>=(ink_local_26).l_correction;{let ink_local_28:u32=(ink_local_26).l_i;ink_local_27}}}}}}
pub fn function_l_ink_m1774c4db693eebe71b1f79bce053b93633d1e1ec37196dd480b59c0248b4fbc2(&self,l_masses:Vec<f32>,l_derivatives:Vec<Vec<f32>>,l_allowed:Vec<bool>,l_total:f32,l_selected:u32)->Vec<f32>{{let ink_local_2:f32={let ink_local_0=&(l_masses);let ink_local_1=l_selected.clone();match ink_local_0.get(ink_local_1 as usize){Some(v)=>v.clone(),None=>f32::from_bits(0u32)}};{let ink_local_5:f32={let ink_local_3=l_masses;let ink_local_4=l_allowed.clone();self.function_l_ink_m28a5428efa573345218636e9cec104f24b6e8c67d7c4c0f979b255813b2abee3(ink_local_3,ink_local_4)};{let ink_local_10:Vec<f32>={let ink_local_6=l_derivatives.clone();let ink_local_7=l_allowed;let ink_local_8=ink_local_5;let ink_local_9=l_total;self.function_l_ink_maa2c8802d351b443dda0bc206d70fa9fe87756b57a84d0357e9dfb4c1e7a0667(ink_local_6,ink_local_7,ink_local_8,ink_local_9)};{let ink_local_15=({let ink_local_11=&(l_derivatives);let ink_local_12=l_selected;match ink_local_11.get(ink_local_12 as usize){Some(v)=>v.clone(),None=>vec![]}}).into_iter();let ink_local_16=(ink_local_10).into_iter();(ink_local_15.zip(ink_local_16).map(|(ink_local_13,ink_local_14)|temporary::ink_f32((temporary::ink_f32_div(ink_local_13,ink_local_2.clone())) - (ink_local_14)))).collect::<Vec<f32>>()}}}}}
pub fn function_l_ink_m1fbf7ee6cef3bcca5d7d258c8606275806894b60d839126202d17f016ea87c80(&self,l_masses:Vec<f32>,l_derivatives:Vec<Vec<f32>>,l_allowed:Vec<bool>,l_unit:f32)->Result<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0,String>{match {let ink_local_0=l_masses.clone();let ink_local_1=l_allowed.clone();self.function_l_ink_mfd18151b0af45b45f5b48ef5e7a09ac1294681f654e2174ae3b33183f445ef14(ink_local_0,ink_local_1)} {Ok(ink_local_2)=>{{let ink_local_3:Vec<f32>=ink_local_2;{let ink_local_6:u32=({let ink_local_4=&(l_derivatives);let ink_local_5=0u32;match ink_local_4.get(ink_local_5 as usize){Some(v)=>v.clone(),None=>vec![]}}).len() as u32;if ((((((((((((InkDataEq::ink_data_eq(&((l_unit.clone()).is_finite()),&(false))) || (((l_unit.clone()) < (f32::from_bits(0u32)))))) || (((l_unit.clone()) >= (f32::from_bits(1065353216u32)))))) || (!InkDataEq::ink_data_eq(&((l_derivatives).len() as u32),&((l_masses).len() as u32))))) || (InkDataEq::ink_data_eq(&(ink_local_6.clone()),&(0u32))))) || (((ink_local_6.clone()) > (4096u32))))) || ((((l_masses).len() as u32) > ({let ink_local_7=65536u32;let ink_local_8=ink_local_6.clone();if ink_local_8==0  {0u32} else {ink_local_7 / ink_local_8}})))) {Err("policy sampling or derivative shape".to_owned())} else {if InkDataEq::ink_data_eq(&({let ink_local_13=(l_derivatives).iter();let mut ink_local_12=true;for ink_local_9 in ink_local_13 {let ink_local_10=ink_local_12;ink_local_12=((((ink_local_10) && (InkDataEq::ink_data_eq(&((ink_local_9).len() as u32),&(ink_local_6.clone()))))) && ({let ink_local_11=(*ink_local_9).clone();self.function_l_ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54(ink_local_11)}));}ink_local_12}),&(false)) {Err("policy derivative domain".to_owned())} else {{let ink_local_18:f32={let ink_local_17=(ink_local_3).iter();let mut ink_local_16=f32::from_bits(0u32);for ink_local_14 in ink_local_17 {let ink_local_15=ink_local_16;ink_local_16=temporary::ink_f32((ink_local_15) + ((*ink_local_14).clone()));}ink_local_16};{let ink_local_22:u32={let ink_local_19=ink_local_3.clone();let ink_local_20=l_unit;let ink_local_21=ink_local_18.clone();self.function_l_ink_m6ec6e8f9e757c220bfe2ed28cbb8dab4ec520de5ee8de5ca702cbdb805a5f910(ink_local_19,ink_local_20,ink_local_21)};{let ink_local_28:Vec<f32>={let ink_local_23=l_masses;let ink_local_24=l_derivatives;let ink_local_25=l_allowed;let ink_local_26=ink_local_18.clone();let ink_local_27=ink_local_22.clone();self.function_l_ink_m1774c4db693eebe71b1f79bce053b93633d1e1ec37196dd480b59c0248b4fbc2(ink_local_23,ink_local_24,ink_local_25,ink_local_26,ink_local_27)};{let ink_local_31:f32=temporary::ink_f32_div({let ink_local_29=&(ink_local_3);let ink_local_30=ink_local_22.clone();match ink_local_29.get(ink_local_30 as usize){Some(v)=>v.clone(),None=>f32::from_bits(0u32)}},ink_local_18);if ((InkDataEq::ink_data_eq(&({let ink_local_32=ink_local_28.clone();self.function_l_ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54(ink_local_32)}),&(false))) || (((ink_local_31.clone()) <= (f32::from_bits(0u32))))) {Err("nonfinite policy score or probability underflow".to_owned())} else {Ok({let ink_local_33=ink_local_22;let ink_local_34=ink_local_31;let ink_local_35=ink_local_28;l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0{l_action:ink_local_33,l_probability:ink_local_34,l_score:ink_local_35}})}}}}}}}}}},Err(ink_local_36)=>{Err(ink_local_36)}}}
pub fn function_l_ink_m99468fca85aa8fb996f0c891430c813d82505250d39d8e415bf27679ddc39e07(&self,l_masses:Vec<f32>,l_derivatives:Vec<Vec<f32>>,l_allowed:Vec<bool>,l_action:u32)->Result<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0,String>{match {let ink_local_0=l_masses.clone();let ink_local_1=l_allowed.clone();self.function_l_ink_mfd18151b0af45b45f5b48ef5e7a09ac1294681f654e2174ae3b33183f445ef14(ink_local_0,ink_local_1)} {Ok(ink_local_2)=>{{let ink_local_3:Vec<f32>=ink_local_2;{let ink_local_6:u32=({let ink_local_4=&(l_derivatives);let ink_local_5=0u32;match ink_local_4.get(ink_local_5 as usize){Some(v)=>v.clone(),None=>vec![]}}).len() as u32;if ((((((((((((!InkDataEq::ink_data_eq(&((l_derivatives).len() as u32),&((l_masses).len() as u32))) || (InkDataEq::ink_data_eq(&(ink_local_6.clone()),&(0u32))))) || (((ink_local_6.clone()) > (4096u32))))) || ((((l_masses).len() as u32) > ({let ink_local_7=65536u32;let ink_local_8=ink_local_6.clone();if ink_local_8==0  {0u32} else {ink_local_7 / ink_local_8}}))))) || (((l_action.clone()) >= ((l_masses).len() as u32))))) || (InkDataEq::ink_data_eq(&({let ink_local_9=&(l_allowed);let ink_local_10=l_action.clone();match ink_local_9.get(ink_local_10 as usize){Some(v)=>v.clone(),None=>false}}),&(false))))) || ((({let ink_local_11=&(ink_local_3);let ink_local_12=l_action.clone();match ink_local_11.get(ink_local_12 as usize){Some(v)=>v.clone(),None=>f32::from_bits(0u32)}}) <= (f32::from_bits(0u32))))) {Err("policy selected action or derivative shape".to_owned())} else {if InkDataEq::ink_data_eq(&({let ink_local_17=(l_derivatives).iter();let mut ink_local_16=true;for ink_local_13 in ink_local_17 {let ink_local_14=ink_local_16;ink_local_16=((((ink_local_14) && (InkDataEq::ink_data_eq(&((ink_local_13).len() as u32),&(ink_local_6.clone()))))) && ({let ink_local_15=(*ink_local_13).clone();self.function_l_ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54(ink_local_15)}));}ink_local_16}),&(false)) {Err("policy derivative domain".to_owned())} else {{let ink_local_22:f32={let ink_local_21=(ink_local_3).iter();let mut ink_local_20=f32::from_bits(0u32);for ink_local_18 in ink_local_21 {let ink_local_19=ink_local_20;ink_local_20=temporary::ink_f32((ink_local_19) + ((*ink_local_18).clone()));}ink_local_20};{let ink_local_28:Vec<f32>={let ink_local_23=l_masses;let ink_local_24=l_derivatives;let ink_local_25=l_allowed;let ink_local_26=ink_local_22.clone();let ink_local_27=l_action.clone();self.function_l_ink_m1774c4db693eebe71b1f79bce053b93633d1e1ec37196dd480b59c0248b4fbc2(ink_local_23,ink_local_24,ink_local_25,ink_local_26,ink_local_27)};{let ink_local_31:f32=temporary::ink_f32_div({let ink_local_29=&(ink_local_3);let ink_local_30=l_action.clone();match ink_local_29.get(ink_local_30 as usize){Some(v)=>v.clone(),None=>f32::from_bits(0u32)}},ink_local_22);if ((InkDataEq::ink_data_eq(&({let ink_local_32=ink_local_28.clone();self.function_l_ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54(ink_local_32)}),&(false))) || (((ink_local_31.clone()) <= (f32::from_bits(0u32))))) {Err("nonfinite policy score or probability underflow".to_owned())} else {Ok({let ink_local_33=l_action;let ink_local_34=ink_local_31;let ink_local_35=ink_local_28;l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0{l_action:ink_local_33,l_probability:ink_local_34,l_score:ink_local_35}})}}}}}}}}},Err(ink_local_36)=>{Err(ink_local_36)}}}
pub fn function_l_ink_maadd6c30a027af52d851f0828eec45339d218ad3bbe73e4d8d7cdd3892e754f4(&self,l_decision:l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0,l_return_value:f32,l_baseline:f32)->Result<Vec<f32>,String>{if ((((((((((((((InkDataEq::ink_data_eq(&((l_return_value.clone()).is_finite()),&(false))) || (InkDataEq::ink_data_eq(&((l_baseline.clone()).is_finite()),&(false))))) || (InkDataEq::ink_data_eq(&((((l_decision).l_probability).clone()).is_finite()),&(false))))) || (((((l_decision).l_probability).clone()) <= (f32::from_bits(0u32)))))) || ((((l_decision).l_probability) > (f32::from_bits(1065353216u32)))))) || (InkDataEq::ink_data_eq(&(((l_decision).l_score).len() as u32),&(0u32))))) || (((((l_decision).l_score).len() as u32) > (4096u32))))) || (InkDataEq::ink_data_eq(&({let ink_local_0=((l_decision).l_score).clone();self.function_l_ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54(ink_local_0)}),&(false)))) {Err("policy feedback domain".to_owned())} else {{let ink_local_1:f32=temporary::ink_f32((l_return_value) - (l_baseline));{let ink_local_3:Vec<f32>=((((l_decision).l_score).into_iter()).map(|ink_local_2|temporary::ink_f32((f32::from_bits((ink_local_1.clone()).to_bits() ^ 0x80000000)) * (ink_local_2)))).collect::<Vec<f32>>();if ((InkDataEq::ink_data_eq(&((ink_local_1.clone()).is_finite()),&(false))) || (InkDataEq::ink_data_eq(&({let ink_local_4=ink_local_3.clone();self.function_l_ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54(ink_local_4)}),&(false)))) {Err("nonfinite policy gradient".to_owned())} else {Ok(ink_local_3)}}}}}
pub fn function_l_ink_m696809152e57d8dfa3f01f9a3e12c048434b9f2af91ff53321ea6ceeeeca5431(&self,l_accumulator:Result<Vec<f32>,String>,l_decision:l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0,l_return_value:f32,l_baseline:f32)->Result<Vec<f32>,String>{match l_accumulator {Ok(ink_local_0)=>{{let ink_local_1:Vec<f32>=ink_local_0;match {let ink_local_2=l_decision;let ink_local_3=l_return_value;let ink_local_4=l_baseline;self.function_l_ink_maadd6c30a027af52d851f0828eec45339d218ad3bbe73e4d8d7cdd3892e754f4(ink_local_2,ink_local_3,ink_local_4)} {Ok(ink_local_5)=>{{let ink_local_6:Vec<f32>=ink_local_5;if !InkDataEq::ink_data_eq(&((ink_local_1).len() as u32),&((ink_local_6).len() as u32)) {Err("trajectory parameter shape".to_owned())} else {{let ink_local_11:Vec<f32>={let ink_local_9=(ink_local_1).into_iter();let ink_local_10=(ink_local_6).into_iter();(ink_local_9.zip(ink_local_10).map(|(ink_local_7,ink_local_8)|temporary::ink_f32((ink_local_7) + (ink_local_8)))).collect::<Vec<f32>>()};if InkDataEq::ink_data_eq(&({let ink_local_12=ink_local_11.clone();self.function_l_ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54(ink_local_12)}),&(false)) {Err("nonfinite trajectory gradient".to_owned())} else {Ok(ink_local_11)}}}}},Err(ink_local_13)=>{Err(ink_local_13)}}}},Err(ink_local_14)=>{Err(ink_local_14)}}}
pub fn function_l_ink_m372cbaf2ee2bc8705fad4b5b65a9e744ea468afbe4c153f17c7da282a459d1cd(&self,l_decisions:Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0>,l_return_values:Vec<f32>,l_baselines:Vec<f32>)->Result<Vec<f32>,String>{{let ink_local_5:l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0={let ink_local_3=&(l_decisions);let ink_local_4=0u32;match ink_local_3.get(ink_local_4 as usize){Some(v)=>v.clone(),None=>{let ink_local_0=0u32;let ink_local_1=f32::from_bits(0u32);let ink_local_2=vec![];l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0{l_action:ink_local_0,l_probability:ink_local_1,l_score:ink_local_2}}}};{let ink_local_6:u32=((ink_local_5).l_score).len() as u32;if ((((((((((((InkDataEq::ink_data_eq(&((l_decisions).len() as u32),&(0u32))) || ((((l_decisions).len() as u32) > (4096u32))))) || (!InkDataEq::ink_data_eq(&((l_return_values).len() as u32),&((l_decisions).len() as u32))))) || (!InkDataEq::ink_data_eq(&((l_baselines).len() as u32),&((l_decisions).len() as u32))))) || (InkDataEq::ink_data_eq(&(ink_local_6.clone()),&(0u32))))) || (((ink_local_6.clone()) > (4096u32))))) || ((((l_decisions).len() as u32) > ({let ink_local_7=65536u32;let ink_local_8=ink_local_6;if ink_local_8==0  {0u32} else {ink_local_7 / ink_local_8}})))) {Err("trajectory shape".to_owned())} else {{let ink_local_10:Result<Vec<f32>,String>=Ok(((((ink_local_5).l_score).into_iter()).map(|ink_local_9|f32::from_bits(0u32))).collect::<Vec<f32>>());{let ink_local_11:u32=0u32;{let ink_local_32:l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_72={let ink_local_31=(l_decisions).into_iter();let mut ink_local_30={let ink_local_12=ink_local_10;let ink_local_13=ink_local_11;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_72{l_accumulator:ink_local_12,l_i:ink_local_13}};for ink_local_14 in ink_local_31 {let ink_local_15=ink_local_30;ink_local_30={let ink_local_16:Result<Vec<f32>,String>=(ink_local_15).l_accumulator;{let ink_local_17:u32=(ink_local_15).l_i;{let ink_local_26:Result<Vec<f32>,String>={let ink_local_18=ink_local_16;let ink_local_19=ink_local_14;let ink_local_22={let ink_local_20=&(l_return_values);let ink_local_21=ink_local_17.clone();match ink_local_20.get(ink_local_21 as usize){Some(v)=>v.clone(),None=>f32::from_bits(0u32)}};let ink_local_25={let ink_local_23=&(l_baselines);let ink_local_24=ink_local_17.clone();match ink_local_23.get(ink_local_24 as usize){Some(v)=>v.clone(),None=>f32::from_bits(0u32)}};self.function_l_ink_m696809152e57d8dfa3f01f9a3e12c048434b9f2af91ff53321ea6ceeeeca5431(ink_local_18,ink_local_19,ink_local_22,ink_local_25)};{let ink_local_27:u32=(ink_local_17).wrapping_add(1u32);{let ink_local_28=ink_local_26;let ink_local_29=ink_local_27;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_72{l_accumulator:ink_local_28,l_i:ink_local_29}}}}}};}ink_local_30};{let ink_local_33:Result<Vec<f32>,String>=(ink_local_32).l_accumulator;{let ink_local_34:u32=(ink_local_32).l_i;ink_local_33}}}}}}}}}
pub fn function_l_ink_m43c1e2ac4d6d9a37358654ff5c1abcd42d4b01146c41a7ca617bccb074a8813b(&self,l_decisions:Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0>,l_return_values:Vec<f32>,l_baselines:Vec<f32>)->Result<Vec<f32>,String>{match {let ink_local_0=l_decisions.clone();let ink_local_1=l_return_values;let ink_local_2=l_baselines;self.function_l_ink_m372cbaf2ee2bc8705fad4b5b65a9e744ea468afbe4c153f17c7da282a459d1cd(ink_local_0,ink_local_1,ink_local_2)} {Ok(ink_local_3)=>{{let ink_local_4:Vec<f32>=ink_local_3;Ok((((ink_local_4).into_iter()).map(|ink_local_5|temporary::ink_f32_div(ink_local_5,((l_decisions).len() as u32) as f32))).collect::<Vec<f32>>())}},Err(ink_local_6)=>{Err(ink_local_6)}}}
pub fn function_l_ink_m4b5ada8f7d6b3beaee6fc06bf68e61ca158cbc7664899364dff18d21555697ae(&self,l_decisions:Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0>,l_return_value:f32,l_baseline:f32)->Result<Vec<f32>,String>{{let ink_local_0=l_decisions.clone();let ink_local_2=(((l_decisions).iter()).map(|ink_local_1|l_return_value.clone())).collect::<Vec<f32>>();let ink_local_4=(((l_decisions).into_iter()).map(|ink_local_3|l_baseline.clone())).collect::<Vec<f32>>();self.function_l_ink_m372cbaf2ee2bc8705fad4b5b65a9e744ea468afbe4c153f17c7da282a459d1cd(ink_local_0,ink_local_2,ink_local_4)}}
pub fn function_l_ink_mda500f665e6078213ee2391fedf06240c651d1725327b086aa70cda14bef9a07(&self,l_rewards:Vec<f32>,l_discount:f32,l_bootstrap:f32)->Result<Vec<f32>,String>{if (((((((((((((l_rewards).len() as u32) > (4096u32))) || (InkDataEq::ink_data_eq(&({let ink_local_0=l_rewards.clone();self.function_l_ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54(ink_local_0)}),&(false))))) || (InkDataEq::ink_data_eq(&((l_discount.clone()).is_finite()),&(false))))) || (((l_discount.clone()) < (f32::from_bits(0u32)))))) || (((l_discount.clone()) > (f32::from_bits(1065353216u32)))))) || (InkDataEq::ink_data_eq(&((l_bootstrap.clone()).is_finite()),&(false)))) {Err("return domain".to_owned())} else {{let ink_local_1:OwnedBuffer<f32>=<OwnedBuffer<f32>>::new(Default::default());{let ink_local_2:f32=l_bootstrap;{let ink_local_3:u32=0u32;{let ink_local_22:l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_87={let ink_local_21=(l_rewards).iter();let mut ink_local_20={let ink_local_4=ink_local_3;let ink_local_5=ink_local_2;let ink_local_6=ink_local_1;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_87{l_i:ink_local_4,l_next:ink_local_5,l_reversed:ink_local_6}};for ink_local_7 in ink_local_21 {let ink_local_8=ink_local_20;ink_local_20={let ink_local_9:u32=(ink_local_8).l_i;{let ink_local_10:f32=(ink_local_8).l_next;{let ink_local_11:OwnedBuffer<f32>=(ink_local_8).l_reversed;{let ink_local_14:f32=temporary::ink_f32(({let ink_local_12=l_rewards.clone();let ink_local_13=(((l_rewards).len() as u32).wrapping_sub(1u32)).wrapping_sub(ink_local_9.clone());match ink_local_12.get(ink_local_13 as usize){Some(v)=>v.clone(),None=>f32::from_bits(0u32)}}) + (temporary::ink_f32((l_discount.clone()) * (ink_local_10))));{let ink_local_15:OwnedBuffer<f32>=(ink_local_11).push(ink_local_14.clone());{let ink_local_16:u32=(ink_local_9).wrapping_add(1u32);{let ink_local_17=ink_local_16;let ink_local_18=ink_local_14;let ink_local_19=ink_local_15;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_87{l_i:ink_local_17,l_next:ink_local_18,l_reversed:ink_local_19}}}}}}}};}ink_local_20};{let ink_local_23:u32=(ink_local_22).l_i;{let ink_local_24:f32=(ink_local_22).l_next;{let ink_local_25:OwnedBuffer<f32>=(ink_local_22).l_reversed;{let ink_local_26:Vec<f32>=(ink_local_25).freeze();if InkDataEq::ink_data_eq(&({let ink_local_27=ink_local_26.clone();self.function_l_ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54(ink_local_27)}),&(false)) {Err("nonfinite return".to_owned())} else {{let ink_local_28:OwnedBuffer<f32>=<OwnedBuffer<f32>>::new(Default::default());{let ink_local_29:u32=0u32;{let ink_local_44:l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_99={let ink_local_43=(ink_local_26).iter();let mut ink_local_42={let ink_local_30=ink_local_29;let ink_local_31=ink_local_28;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_99{l_i:ink_local_30,l_out:ink_local_31}};for ink_local_32 in ink_local_43 {let ink_local_33=ink_local_42;ink_local_42={let ink_local_34:u32=(ink_local_33).l_i;{let ink_local_35:OwnedBuffer<f32>=(ink_local_33).l_out;{let ink_local_38:OwnedBuffer<f32>=(ink_local_35).push({let ink_local_36=ink_local_26.clone();let ink_local_37=(((ink_local_26).len() as u32).wrapping_sub(1u32)).wrapping_sub(ink_local_34.clone());match ink_local_36.get(ink_local_37 as usize){Some(v)=>v.clone(),None=>f32::from_bits(0u32)}});{let ink_local_39:u32=(ink_local_34).wrapping_add(1u32);{let ink_local_40=ink_local_39;let ink_local_41=ink_local_38;l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_99{l_i:ink_local_40,l_out:ink_local_41}}}}}};}ink_local_42};{let ink_local_45:u32=(ink_local_44).l_i;{let ink_local_46:OwnedBuffer<f32>=(ink_local_44).l_out;Ok((ink_local_46).freeze())}}}}}}}}}}}}}}}}
pub fn function_l_ink_meefc22a28d97f5bdc4100b36eeab9549241c3ef201b83c2f75111644d317833d(&self,l_rate:f32)->l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249{{let ink_local_0=l_rate;let ink_local_1=f32::from_bits(1063675494u32);let ink_local_2=f32::from_bits(1065336439u32);let ink_local_3=f32::from_bits(841731191u32);let ink_local_4=f32::from_bits(0u32);let ink_local_5=f32::from_bits(1065353216u32);l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249{l_rate:ink_local_0,l_first_decay:ink_local_1,l_second_decay:ink_local_2,l_epsilon:ink_local_3,l_weight_decay:ink_local_4,l_norm_limit:ink_local_5}}}
pub fn function_l_ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96(&self,l_xs:Vec<f32>)->bool{{let ink_local_3=(l_xs).into_iter();let mut ink_local_2=true;for ink_local_0 in ink_local_3 {let ink_local_1=ink_local_2;ink_local_2=((ink_local_1) && ((ink_local_0).is_finite()));}ink_local_2}}
pub fn function_l_ink_m786bdc6011aece08dbf36c5ca89c437e06ff758c9d3d242f723dde2af6ea31db(&self,l_state:l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab)->bool{((((((((((((((((((InkDataEq::ink_data_eq(&(((l_state).l_weights).len() as u32),&(((l_state).l_first).len() as u32))) && (InkDataEq::ink_data_eq(&(((l_state).l_weights).len() as u32),&(((l_state).l_second).len() as u32))))) && ({let ink_local_0=(l_state).l_weights;self.function_l_ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96(ink_local_0)}))) && ({let ink_local_1=(l_state).l_first;self.function_l_ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96(ink_local_1)}))) && ({let ink_local_2=((l_state).l_second).clone();self.function_l_ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96(ink_local_2)}))) && ({let ink_local_6=((l_state).l_second).into_iter();let mut ink_local_5=true;for ink_local_3 in ink_local_6 {let ink_local_4=ink_local_5;ink_local_5=((ink_local_4) && (((ink_local_3) >= (f32::from_bits(0u32)))));}ink_local_5}))) && (((((l_state).l_first_power).clone()) >= (f32::from_bits(0u32)))))) && ((((l_state).l_first_power) <= (f32::from_bits(1065353216u32)))))) && (((((l_state).l_second_power).clone()) >= (f32::from_bits(0u32)))))) && ((((l_state).l_second_power) <= (f32::from_bits(1065353216u32)))))}
pub fn function_l_ink_mdfbd57a9f460147afedb262e2bfe0f6197f9b813c85277c59f5e101900063ad7(&self,l_weights:Vec<f32>)->Result<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab,String>{if InkDataEq::ink_data_eq(&({let ink_local_0=l_weights.clone();self.function_l_ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96(ink_local_0)}),&(false)) {Err("nonfinite weights".to_owned())} else {{let ink_local_2:Vec<f32>=(((l_weights).iter()).map(|ink_local_1|f32::from_bits(0u32))).collect::<Vec<f32>>();Ok({let ink_local_3=l_weights;let ink_local_4=ink_local_2.clone();let ink_local_5=ink_local_2;let ink_local_6=0u32;let ink_local_7=f32::from_bits(1065353216u32);let ink_local_8=f32::from_bits(1065353216u32);l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab{l_weights:ink_local_3,l_first:ink_local_4,l_second:ink_local_5,l_steps:ink_local_6,l_first_power:ink_local_7,l_second_power:ink_local_8}})}}}
pub fn function_l_ink_m5226ad25deae5e47d7fb65b6b5961d46740dd4e97b54d76a24d3d0445845fe35(&self,l_c:l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249)->bool{(((((((((((((((((((((((((l_c).l_rate).clone()).is_finite()) && ((((l_c).l_rate) > (f32::from_bits(0u32)))))) && (((((l_c).l_first_decay).clone()) >= (f32::from_bits(0u32)))))) && ((((l_c).l_first_decay) < (f32::from_bits(1065353216u32)))))) && (((((l_c).l_second_decay).clone()) >= (f32::from_bits(0u32)))))) && ((((l_c).l_second_decay) < (f32::from_bits(1065353216u32)))))) && ((((l_c).l_epsilon).clone()).is_finite()))) && ((((l_c).l_epsilon) > (f32::from_bits(0u32)))))) && ((((l_c).l_weight_decay).clone()).is_finite()))) && ((((l_c).l_weight_decay) >= (f32::from_bits(0u32)))))) && ((((l_c).l_norm_limit).clone()).is_finite()))) && ((((l_c).l_norm_limit) >= (f32::from_bits(0u32)))))}
pub fn function_l_ink_m8abb6b2bcbe55251e0b82a28f26d7ce761729346e35019c2b60ca9b5ee22590d(&self,l_x:f32)->f32{if ((l_x.clone()) < (f32::from_bits(0u32))) {f32::from_bits((l_x).to_bits() ^ 0x80000000)} else {l_x}}
pub fn function_l_ink_m7d03a2ed6071238ff1b69a8e56a8cb96b9dc3b095b2d939c0ccfed84ee9580b5(&self,l_xs:Vec<f32>,l_limit:f32)->f32{if ((l_limit.clone()) == (f32::from_bits(0u32))) {f32::from_bits(1065353216u32)} else {{let ink_local_6:f32={let ink_local_5=(l_xs).iter();let mut ink_local_4=f32::from_bits(0u32);for ink_local_0 in ink_local_5 {let ink_local_1=ink_local_4;ink_local_4=if (({let ink_local_2=(*ink_local_0).clone();self.function_l_ink_m8abb6b2bcbe55251e0b82a28f26d7ce761729346e35019c2b60ca9b5ee22590d(ink_local_2)}) > (ink_local_1.clone())) {{let ink_local_3=(*ink_local_0).clone();self.function_l_ink_m8abb6b2bcbe55251e0b82a28f26d7ce761729346e35019c2b60ca9b5ee22590d(ink_local_3)}} else {ink_local_1};}ink_local_4};if ((ink_local_6.clone()) == (f32::from_bits(0u32))) {f32::from_bits(1065353216u32)} else {{let ink_local_11:f32={let ink_local_10=(l_xs).into_iter();let mut ink_local_9=f32::from_bits(0u32);for ink_local_7 in ink_local_10 {let ink_local_8=ink_local_9;ink_local_9=temporary::ink_f32((ink_local_8) + (temporary::ink_f32((temporary::ink_f32_div(ink_local_7.clone(),ink_local_6.clone())) * (temporary::ink_f32_div(ink_local_7,ink_local_6.clone())))));}ink_local_9};{let ink_local_12:f32=temporary::ink_f32_div(temporary::ink_f32_div(l_limit,ink_local_6),temporary::ink_sqrt(ink_local_11));if ((ink_local_12.clone()) < (f32::from_bits(1065353216u32))) {ink_local_12} else {f32::from_bits(1065353216u32)}}}}}}}
pub fn function_l_ink_m00ba8185ca362d257d138fe1886cbc5f3acc38c4a238bef60c3d3d7fa0276eab(&self,l_weight:f32,l_first:f32,l_second:f32,l_first_power:f32,l_second_power:f32,l_c:l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249)->f32{temporary::ink_f32((l_weight) - (temporary::ink_f32_div(temporary::ink_f32(((l_c).l_rate) * (temporary::ink_f32_div(l_first,temporary::ink_f32((f32::from_bits(1065353216u32)) - (l_first_power))))),temporary::ink_f32((temporary::ink_sqrt(temporary::ink_f32_div(l_second,temporary::ink_f32((f32::from_bits(1065353216u32)) - (l_second_power))))) + ((l_c).l_epsilon)))))}
pub fn function_l_ink_m2a55f95a80595bc61d1fcab41ff00f438ff6f2057b597df20aaae3c18507d2be(&self,l_state:l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab,l_gradient:Vec<f32>,l_c:l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249)->Result<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab,String>{if ((((((((InkDataEq::ink_data_eq(&({let ink_local_0=l_state.clone();self.function_l_ink_m786bdc6011aece08dbf36c5ca89c437e06ff758c9d3d242f723dde2af6ea31db(ink_local_0)}),&(false))) || (InkDataEq::ink_data_eq(&({let ink_local_1=l_c.clone();self.function_l_ink_m5226ad25deae5e47d7fb65b6b5961d46740dd4e97b54d76a24d3d0445845fe35(ink_local_1)}),&(false))))) || (!InkDataEq::ink_data_eq(&((l_gradient).len() as u32),&(((l_state).l_weights).len() as u32))))) || (InkDataEq::ink_data_eq(&({let ink_local_2=l_gradient.clone();self.function_l_ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96(ink_local_2)}),&(false))))) || (InkDataEq::ink_data_eq(&(((l_state).l_steps).clone()),&(4294967295u32)))) {Err("optimizer domain".to_owned())} else {{let ink_local_3:OwnedBuffer<f32>=<OwnedBuffer<f32>>::new(Default::default());{let ink_local_4:u32=0u32;{let ink_local_19:l___ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_5={let ink_local_18=(l_gradient).into_iter();let mut ink_local_17={let ink_local_5=ink_local_3;let ink_local_6=ink_local_4;l___ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_5{l_adjusted:ink_local_5,l_i:ink_local_6}};for ink_local_7 in ink_local_18 {let ink_local_8=ink_local_17;ink_local_17={let ink_local_9:OwnedBuffer<f32>=(ink_local_8).l_adjusted;{let ink_local_10:u32=(ink_local_8).l_i;{let ink_local_13:OwnedBuffer<f32>=(ink_local_9).push(temporary::ink_f32((ink_local_7) + (temporary::ink_f32((((l_c).l_weight_decay).clone()) * ({let ink_local_11=&((l_state).l_weights);let ink_local_12=ink_local_10.clone();match ink_local_11.get(ink_local_12 as usize){Some(v)=>v.clone(),None=>f32::from_bits(0u32)}})))));{let ink_local_14:u32=(ink_local_10).wrapping_add(1u32);{let ink_local_15=ink_local_13;let ink_local_16=ink_local_14;l___ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_5{l_adjusted:ink_local_15,l_i:ink_local_16}}}}}};}ink_local_17};{let ink_local_20:OwnedBuffer<f32>=(ink_local_19).l_adjusted;{let ink_local_21:u32=(ink_local_19).l_i;{let ink_local_22:Vec<f32>=(ink_local_20).freeze();if InkDataEq::ink_data_eq(&({let ink_local_23=ink_local_22.clone();self.function_l_ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96(ink_local_23)}),&(false)) {Err("nonfinite gradient".to_owned())} else {{let ink_local_26:f32={let ink_local_24=ink_local_22.clone();let ink_local_25=((l_c).l_norm_limit).clone();self.function_l_ink_m7d03a2ed6071238ff1b69a8e56a8cb96b9dc3b095b2d939c0ccfed84ee9580b5(ink_local_24,ink_local_25)};{let ink_local_27:f32=temporary::ink_f32((((l_state).l_first_power).clone()) * (((l_c).l_first_decay).clone()));{let ink_local_28:f32=temporary::ink_f32((((l_state).l_second_power).clone()) * (((l_c).l_second_decay).clone()));{let ink_local_29:OwnedBuffer<f32>=<OwnedBuffer<f32>>::new(Default::default());{let ink_local_30:OwnedBuffer<f32>=<OwnedBuffer<f32>>::new(Default::default());{let ink_local_31:OwnedBuffer<f32>=<OwnedBuffer<f32>>::new(Default::default());{let ink_local_32:u32=0u32;{let ink_local_69:l___ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_24={let ink_local_68=(ink_local_22).into_iter();let mut ink_local_67={let ink_local_33=ink_local_30;let ink_local_34=ink_local_32;let ink_local_35=ink_local_31;let ink_local_36=ink_local_29;l___ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_24{l_first:ink_local_33,l_i:ink_local_34,l_second:ink_local_35,l_weights:ink_local_36}};for ink_local_37 in ink_local_68 {let ink_local_38=ink_local_67;ink_local_67={let ink_local_39:OwnedBuffer<f32>=(ink_local_38).l_first;{let ink_local_40:u32=(ink_local_38).l_i;{let ink_local_41:OwnedBuffer<f32>=(ink_local_38).l_second;{let ink_local_42:OwnedBuffer<f32>=(ink_local_38).l_weights;{let ink_local_43:f32=temporary::ink_f32((ink_local_37) * (ink_local_26.clone()));{let ink_local_46:f32=temporary::ink_f32((temporary::ink_f32((((l_c).l_first_decay).clone()) * ({let ink_local_44=&((l_state).l_first);let ink_local_45=ink_local_40.clone();match ink_local_44.get(ink_local_45 as usize){Some(v)=>v.clone(),None=>f32::from_bits(0u32)}}))) + (temporary::ink_f32((temporary::ink_f32((f32::from_bits(1065353216u32)) - (((l_c).l_first_decay).clone()))) * (ink_local_43.clone()))));{let ink_local_49:f32=temporary::ink_f32((temporary::ink_f32((((l_c).l_second_decay).clone()) * ({let ink_local_47=&((l_state).l_second);let ink_local_48=ink_local_40.clone();match ink_local_47.get(ink_local_48 as usize){Some(v)=>v.clone(),None=>f32::from_bits(0u32)}}))) + (temporary::ink_f32((temporary::ink_f32((temporary::ink_f32((f32::from_bits(1065353216u32)) - (((l_c).l_second_decay).clone()))) * (ink_local_43.clone()))) * (ink_local_43))));{let ink_local_58:f32={let ink_local_52={let ink_local_50=&((l_state).l_weights);let ink_local_51=ink_local_40.clone();match ink_local_50.get(ink_local_51 as usize){Some(v)=>v.clone(),None=>f32::from_bits(0u32)}};let ink_local_53=ink_local_46.clone();let ink_local_54=ink_local_49.clone();let ink_local_55=ink_local_27.clone();let ink_local_56=ink_local_28.clone();let ink_local_57=l_c.clone();self.function_l_ink_m00ba8185ca362d257d138fe1886cbc5f3acc38c4a238bef60c3d3d7fa0276eab(ink_local_52,ink_local_53,ink_local_54,ink_local_55,ink_local_56,ink_local_57)};{let ink_local_59:OwnedBuffer<f32>=(ink_local_42).push(ink_local_58);{let ink_local_60:OwnedBuffer<f32>=(ink_local_39).push(ink_local_46);{let ink_local_61:OwnedBuffer<f32>=(ink_local_41).push(ink_local_49);{let ink_local_62:u32=(ink_local_40).wrapping_add(1u32);{let ink_local_63=ink_local_60;let ink_local_64=ink_local_62;let ink_local_65=ink_local_61;let ink_local_66=ink_local_59;l___ink_loop_bf770e63bfb4b31e3ac83a621b6975c750f03984a70534dbb402bc1286d27412_24{l_first:ink_local_63,l_i:ink_local_64,l_second:ink_local_65,l_weights:ink_local_66}}}}}}}}}}}}}};}ink_local_67};{let ink_local_70:OwnedBuffer<f32>=(ink_local_69).l_first;{let ink_local_71:u32=(ink_local_69).l_i;{let ink_local_72:OwnedBuffer<f32>=(ink_local_69).l_second;{let ink_local_73:OwnedBuffer<f32>=(ink_local_69).l_weights;{let ink_local_80:l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab={let ink_local_74=(ink_local_73).freeze();let ink_local_75=(ink_local_70).freeze();let ink_local_76=(ink_local_72).freeze();let ink_local_77=((l_state).l_steps).wrapping_add(1u32);let ink_local_78=ink_local_27;let ink_local_79=ink_local_28;l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab{l_weights:ink_local_74,l_first:ink_local_75,l_second:ink_local_76,l_steps:ink_local_77,l_first_power:ink_local_78,l_second_power:ink_local_79}};if InkDataEq::ink_data_eq(&({let ink_local_81=ink_local_80.clone();self.function_l_ink_m786bdc6011aece08dbf36c5ca89c437e06ff758c9d3d242f723dde2af6ea31db(ink_local_81)}),&(false)) {Err("nonfinite optimizer update".to_owned())} else {Ok(ink_local_80)}}}}}}}}}}}}}}}}}}}}}}}
pub fn function_l___ink_differential_3(&self,l_w:l___ink_differential_4,l_p:l___ink_differential_6)->l___ink_differential_2{{let ink_local_0:l___ink_differential_5=if InkDataEq::ink_data_eq(&(((l_p).l_slot).clone()),&(0u32)) {(l_w).l_a} else {if InkDataEq::ink_data_eq(&(((l_p).l_slot).clone()),&(1u32)) {(l_w).l_b} else {if InkDataEq::ink_data_eq(&((l_p).l_slot),&(2u32)) {(l_w).l_c} else {(l_w).l_d}}};{let ink_local_1:l___ink_differential_2=if InkDataEq::ink_data_eq(&(((l_p).l_operation).clone()),&(0u32)) {(ink_local_0).l_identity} else {if InkDataEq::ink_data_eq(&(((l_p).l_operation).clone()),&(1u32)) {(ink_local_0).l_scale} else {if InkDataEq::ink_data_eq(&((l_p).l_operation),&(2u32)) {(ink_local_0).l_bias} else {(ink_local_0).l_relu}}};{let ink_local_22:l___ink_differential_2={let ink_local_2:l___ink_differential_2=ink_local_1.clone();{let ink_local_3:l___ink_differential_2=ink_local_1;{let ink_local_4:f32=temporary::ink_f32((((ink_local_2).l_value).clone()) * (((ink_local_3).l_value).clone()));{let ink_local_5=ink_local_4;let ink_local_6=temporary::ink_f32((temporary::ink_f32(((ink_local_2).l_tangent_0) * (((ink_local_3).l_value).clone()))) + (temporary::ink_f32((((ink_local_2).l_value).clone()) * ((ink_local_3).l_tangent_0))));let ink_local_7=temporary::ink_f32((temporary::ink_f32(((ink_local_2).l_tangent_1) * (((ink_local_3).l_value).clone()))) + (temporary::ink_f32((((ink_local_2).l_value).clone()) * ((ink_local_3).l_tangent_1))));let ink_local_8=temporary::ink_f32((temporary::ink_f32(((ink_local_2).l_tangent_2) * (((ink_local_3).l_value).clone()))) + (temporary::ink_f32((((ink_local_2).l_value).clone()) * ((ink_local_3).l_tangent_2))));let ink_local_9=temporary::ink_f32((temporary::ink_f32(((ink_local_2).l_tangent_3) * (((ink_local_3).l_value).clone()))) + (temporary::ink_f32((((ink_local_2).l_value).clone()) * ((ink_local_3).l_tangent_3))));let ink_local_10=temporary::ink_f32((temporary::ink_f32(((ink_local_2).l_tangent_4) * (((ink_local_3).l_value).clone()))) + (temporary::ink_f32((((ink_local_2).l_value).clone()) * ((ink_local_3).l_tangent_4))));let ink_local_11=temporary::ink_f32((temporary::ink_f32(((ink_local_2).l_tangent_5) * (((ink_local_3).l_value).clone()))) + (temporary::ink_f32((((ink_local_2).l_value).clone()) * ((ink_local_3).l_tangent_5))));let ink_local_12=temporary::ink_f32((temporary::ink_f32(((ink_local_2).l_tangent_6) * (((ink_local_3).l_value).clone()))) + (temporary::ink_f32((((ink_local_2).l_value).clone()) * ((ink_local_3).l_tangent_6))));let ink_local_13=temporary::ink_f32((temporary::ink_f32(((ink_local_2).l_tangent_7) * (((ink_local_3).l_value).clone()))) + (temporary::ink_f32((((ink_local_2).l_value).clone()) * ((ink_local_3).l_tangent_7))));let ink_local_14=temporary::ink_f32((temporary::ink_f32(((ink_local_2).l_tangent_8) * (((ink_local_3).l_value).clone()))) + (temporary::ink_f32((((ink_local_2).l_value).clone()) * ((ink_local_3).l_tangent_8))));let ink_local_15=temporary::ink_f32((temporary::ink_f32(((ink_local_2).l_tangent_9) * (((ink_local_3).l_value).clone()))) + (temporary::ink_f32((((ink_local_2).l_value).clone()) * ((ink_local_3).l_tangent_9))));let ink_local_16=temporary::ink_f32((temporary::ink_f32(((ink_local_2).l_tangent_10) * (((ink_local_3).l_value).clone()))) + (temporary::ink_f32((((ink_local_2).l_value).clone()) * ((ink_local_3).l_tangent_10))));let ink_local_17=temporary::ink_f32((temporary::ink_f32(((ink_local_2).l_tangent_11) * (((ink_local_3).l_value).clone()))) + (temporary::ink_f32((((ink_local_2).l_value).clone()) * ((ink_local_3).l_tangent_11))));let ink_local_18=temporary::ink_f32((temporary::ink_f32(((ink_local_2).l_tangent_12) * (((ink_local_3).l_value).clone()))) + (temporary::ink_f32((((ink_local_2).l_value).clone()) * ((ink_local_3).l_tangent_12))));let ink_local_19=temporary::ink_f32((temporary::ink_f32(((ink_local_2).l_tangent_13) * (((ink_local_3).l_value).clone()))) + (temporary::ink_f32((((ink_local_2).l_value).clone()) * ((ink_local_3).l_tangent_13))));let ink_local_20=temporary::ink_f32((temporary::ink_f32(((ink_local_2).l_tangent_14) * (((ink_local_3).l_value).clone()))) + (temporary::ink_f32((((ink_local_2).l_value).clone()) * ((ink_local_3).l_tangent_14))));let ink_local_21=temporary::ink_f32((temporary::ink_f32(((ink_local_2).l_tangent_15) * ((ink_local_3).l_value))) + (temporary::ink_f32(((ink_local_2).l_value) * ((ink_local_3).l_tangent_15))));l___ink_differential_2{l_value:ink_local_5,l_tangent_0:ink_local_6,l_tangent_1:ink_local_7,l_tangent_2:ink_local_8,l_tangent_3:ink_local_9,l_tangent_4:ink_local_10,l_tangent_5:ink_local_11,l_tangent_6:ink_local_12,l_tangent_7:ink_local_13,l_tangent_8:ink_local_14,l_tangent_9:ink_local_15,l_tangent_10:ink_local_16,l_tangent_11:ink_local_17,l_tangent_12:ink_local_18,l_tangent_13:ink_local_19,l_tangent_14:ink_local_20,l_tangent_15:ink_local_21}}}}};{let ink_local_40:l___ink_differential_2={let ink_local_23=f32::from_bits(1036831949u32);let ink_local_24=f32::from_bits(0u32);let ink_local_25=f32::from_bits(0u32);let ink_local_26=f32::from_bits(0u32);let ink_local_27=f32::from_bits(0u32);let ink_local_28=f32::from_bits(0u32);let ink_local_29=f32::from_bits(0u32);let ink_local_30=f32::from_bits(0u32);let ink_local_31=f32::from_bits(0u32);let ink_local_32=f32::from_bits(0u32);let ink_local_33=f32::from_bits(0u32);let ink_local_34=f32::from_bits(0u32);let ink_local_35=f32::from_bits(0u32);let ink_local_36=f32::from_bits(0u32);let ink_local_37=f32::from_bits(0u32);let ink_local_38=f32::from_bits(0u32);let ink_local_39=f32::from_bits(0u32);l___ink_differential_2{l_value:ink_local_23,l_tangent_0:ink_local_24,l_tangent_1:ink_local_25,l_tangent_2:ink_local_26,l_tangent_3:ink_local_27,l_tangent_4:ink_local_28,l_tangent_5:ink_local_29,l_tangent_6:ink_local_30,l_tangent_7:ink_local_31,l_tangent_8:ink_local_32,l_tangent_9:ink_local_33,l_tangent_10:ink_local_34,l_tangent_11:ink_local_35,l_tangent_12:ink_local_36,l_tangent_13:ink_local_37,l_tangent_14:ink_local_38,l_tangent_15:ink_local_39}};{let ink_local_41:f32=temporary::ink_f32(((ink_local_22).l_value) + ((ink_local_40).l_value));{let ink_local_42=ink_local_41;let ink_local_43=temporary::ink_f32(((ink_local_22).l_tangent_0) + ((ink_local_40).l_tangent_0));let ink_local_44=temporary::ink_f32(((ink_local_22).l_tangent_1) + ((ink_local_40).l_tangent_1));let ink_local_45=temporary::ink_f32(((ink_local_22).l_tangent_2) + ((ink_local_40).l_tangent_2));let ink_local_46=temporary::ink_f32(((ink_local_22).l_tangent_3) + ((ink_local_40).l_tangent_3));let ink_local_47=temporary::ink_f32(((ink_local_22).l_tangent_4) + ((ink_local_40).l_tangent_4));let ink_local_48=temporary::ink_f32(((ink_local_22).l_tangent_5) + ((ink_local_40).l_tangent_5));let ink_local_49=temporary::ink_f32(((ink_local_22).l_tangent_6) + ((ink_local_40).l_tangent_6));let ink_local_50=temporary::ink_f32(((ink_local_22).l_tangent_7) + ((ink_local_40).l_tangent_7));let ink_local_51=temporary::ink_f32(((ink_local_22).l_tangent_8) + ((ink_local_40).l_tangent_8));let ink_local_52=temporary::ink_f32(((ink_local_22).l_tangent_9) + ((ink_local_40).l_tangent_9));let ink_local_53=temporary::ink_f32(((ink_local_22).l_tangent_10) + ((ink_local_40).l_tangent_10));let ink_local_54=temporary::ink_f32(((ink_local_22).l_tangent_11) + ((ink_local_40).l_tangent_11));let ink_local_55=temporary::ink_f32(((ink_local_22).l_tangent_12) + ((ink_local_40).l_tangent_12));let ink_local_56=temporary::ink_f32(((ink_local_22).l_tangent_13) + ((ink_local_40).l_tangent_13));let ink_local_57=temporary::ink_f32(((ink_local_22).l_tangent_14) + ((ink_local_40).l_tangent_14));let ink_local_58=temporary::ink_f32(((ink_local_22).l_tangent_15) + ((ink_local_40).l_tangent_15));l___ink_differential_2{l_value:ink_local_42,l_tangent_0:ink_local_43,l_tangent_1:ink_local_44,l_tangent_2:ink_local_45,l_tangent_3:ink_local_46,l_tangent_4:ink_local_47,l_tangent_5:ink_local_48,l_tangent_6:ink_local_49,l_tangent_7:ink_local_50,l_tangent_8:ink_local_51,l_tangent_9:ink_local_52,l_tangent_10:ink_local_53,l_tangent_11:ink_local_54,l_tangent_12:ink_local_55,l_tangent_13:ink_local_56,l_tangent_14:ink_local_57,l_tangent_15:ink_local_58}}}}}}}}
pub fn function_l___ink_differential_1(&self,l_w:l_Parameters,l_p:l_Pick)->l_Parameters{{let ink_local_296:l___ink_differential_2={let ink_local_292={let ink_local_72={let ink_local_17={let ink_local_0=((l_w).l_a).l_identity;let ink_local_1=f32::from_bits(1065353216u32);let ink_local_2=f32::from_bits(0u32);let ink_local_3=f32::from_bits(0u32);let ink_local_4=f32::from_bits(0u32);let ink_local_5=f32::from_bits(0u32);let ink_local_6=f32::from_bits(0u32);let ink_local_7=f32::from_bits(0u32);let ink_local_8=f32::from_bits(0u32);let ink_local_9=f32::from_bits(0u32);let ink_local_10=f32::from_bits(0u32);let ink_local_11=f32::from_bits(0u32);let ink_local_12=f32::from_bits(0u32);let ink_local_13=f32::from_bits(0u32);let ink_local_14=f32::from_bits(0u32);let ink_local_15=f32::from_bits(0u32);let ink_local_16=f32::from_bits(0u32);l___ink_differential_2{l_value:ink_local_0,l_tangent_0:ink_local_1,l_tangent_1:ink_local_2,l_tangent_2:ink_local_3,l_tangent_3:ink_local_4,l_tangent_4:ink_local_5,l_tangent_5:ink_local_6,l_tangent_6:ink_local_7,l_tangent_7:ink_local_8,l_tangent_8:ink_local_9,l_tangent_9:ink_local_10,l_tangent_10:ink_local_11,l_tangent_11:ink_local_12,l_tangent_12:ink_local_13,l_tangent_13:ink_local_14,l_tangent_14:ink_local_15,l_tangent_15:ink_local_16}};let ink_local_35={let ink_local_18=((l_w).l_a).l_scale;let ink_local_19=f32::from_bits(0u32);let ink_local_20=f32::from_bits(1065353216u32);let ink_local_21=f32::from_bits(0u32);let ink_local_22=f32::from_bits(0u32);let ink_local_23=f32::from_bits(0u32);let ink_local_24=f32::from_bits(0u32);let ink_local_25=f32::from_bits(0u32);let ink_local_26=f32::from_bits(0u32);let ink_local_27=f32::from_bits(0u32);let ink_local_28=f32::from_bits(0u32);let ink_local_29=f32::from_bits(0u32);let ink_local_30=f32::from_bits(0u32);let ink_local_31=f32::from_bits(0u32);let ink_local_32=f32::from_bits(0u32);let ink_local_33=f32::from_bits(0u32);let ink_local_34=f32::from_bits(0u32);l___ink_differential_2{l_value:ink_local_18,l_tangent_0:ink_local_19,l_tangent_1:ink_local_20,l_tangent_2:ink_local_21,l_tangent_3:ink_local_22,l_tangent_4:ink_local_23,l_tangent_5:ink_local_24,l_tangent_6:ink_local_25,l_tangent_7:ink_local_26,l_tangent_8:ink_local_27,l_tangent_9:ink_local_28,l_tangent_10:ink_local_29,l_tangent_11:ink_local_30,l_tangent_12:ink_local_31,l_tangent_13:ink_local_32,l_tangent_14:ink_local_33,l_tangent_15:ink_local_34}};let ink_local_53={let ink_local_36=((l_w).l_a).l_bias;let ink_local_37=f32::from_bits(0u32);let ink_local_38=f32::from_bits(0u32);let ink_local_39=f32::from_bits(1065353216u32);let ink_local_40=f32::from_bits(0u32);let ink_local_41=f32::from_bits(0u32);let ink_local_42=f32::from_bits(0u32);let ink_local_43=f32::from_bits(0u32);let ink_local_44=f32::from_bits(0u32);let ink_local_45=f32::from_bits(0u32);let ink_local_46=f32::from_bits(0u32);let ink_local_47=f32::from_bits(0u32);let ink_local_48=f32::from_bits(0u32);let ink_local_49=f32::from_bits(0u32);let ink_local_50=f32::from_bits(0u32);let ink_local_51=f32::from_bits(0u32);let ink_local_52=f32::from_bits(0u32);l___ink_differential_2{l_value:ink_local_36,l_tangent_0:ink_local_37,l_tangent_1:ink_local_38,l_tangent_2:ink_local_39,l_tangent_3:ink_local_40,l_tangent_4:ink_local_41,l_tangent_5:ink_local_42,l_tangent_6:ink_local_43,l_tangent_7:ink_local_44,l_tangent_8:ink_local_45,l_tangent_9:ink_local_46,l_tangent_10:ink_local_47,l_tangent_11:ink_local_48,l_tangent_12:ink_local_49,l_tangent_13:ink_local_50,l_tangent_14:ink_local_51,l_tangent_15:ink_local_52}};let ink_local_71={let ink_local_54=((l_w).l_a).l_relu;let ink_local_55=f32::from_bits(0u32);let ink_local_56=f32::from_bits(0u32);let ink_local_57=f32::from_bits(0u32);let ink_local_58=f32::from_bits(1065353216u32);let ink_local_59=f32::from_bits(0u32);let ink_local_60=f32::from_bits(0u32);let ink_local_61=f32::from_bits(0u32);let ink_local_62=f32::from_bits(0u32);let ink_local_63=f32::from_bits(0u32);let ink_local_64=f32::from_bits(0u32);let ink_local_65=f32::from_bits(0u32);let ink_local_66=f32::from_bits(0u32);let ink_local_67=f32::from_bits(0u32);let ink_local_68=f32::from_bits(0u32);let ink_local_69=f32::from_bits(0u32);let ink_local_70=f32::from_bits(0u32);l___ink_differential_2{l_value:ink_local_54,l_tangent_0:ink_local_55,l_tangent_1:ink_local_56,l_tangent_2:ink_local_57,l_tangent_3:ink_local_58,l_tangent_4:ink_local_59,l_tangent_5:ink_local_60,l_tangent_6:ink_local_61,l_tangent_7:ink_local_62,l_tangent_8:ink_local_63,l_tangent_9:ink_local_64,l_tangent_10:ink_local_65,l_tangent_11:ink_local_66,l_tangent_12:ink_local_67,l_tangent_13:ink_local_68,l_tangent_14:ink_local_69,l_tangent_15:ink_local_70}};l___ink_differential_5{l_identity:ink_local_17,l_scale:ink_local_35,l_bias:ink_local_53,l_relu:ink_local_71}};let ink_local_145={let ink_local_90={let ink_local_73=((l_w).l_b).l_identity;let ink_local_74=f32::from_bits(0u32);let ink_local_75=f32::from_bits(0u32);let ink_local_76=f32::from_bits(0u32);let ink_local_77=f32::from_bits(0u32);let ink_local_78=f32::from_bits(1065353216u32);let ink_local_79=f32::from_bits(0u32);let ink_local_80=f32::from_bits(0u32);let ink_local_81=f32::from_bits(0u32);let ink_local_82=f32::from_bits(0u32);let ink_local_83=f32::from_bits(0u32);let ink_local_84=f32::from_bits(0u32);let ink_local_85=f32::from_bits(0u32);let ink_local_86=f32::from_bits(0u32);let ink_local_87=f32::from_bits(0u32);let ink_local_88=f32::from_bits(0u32);let ink_local_89=f32::from_bits(0u32);l___ink_differential_2{l_value:ink_local_73,l_tangent_0:ink_local_74,l_tangent_1:ink_local_75,l_tangent_2:ink_local_76,l_tangent_3:ink_local_77,l_tangent_4:ink_local_78,l_tangent_5:ink_local_79,l_tangent_6:ink_local_80,l_tangent_7:ink_local_81,l_tangent_8:ink_local_82,l_tangent_9:ink_local_83,l_tangent_10:ink_local_84,l_tangent_11:ink_local_85,l_tangent_12:ink_local_86,l_tangent_13:ink_local_87,l_tangent_14:ink_local_88,l_tangent_15:ink_local_89}};let ink_local_108={let ink_local_91=((l_w).l_b).l_scale;let ink_local_92=f32::from_bits(0u32);let ink_local_93=f32::from_bits(0u32);let ink_local_94=f32::from_bits(0u32);let ink_local_95=f32::from_bits(0u32);let ink_local_96=f32::from_bits(0u32);let ink_local_97=f32::from_bits(1065353216u32);let ink_local_98=f32::from_bits(0u32);let ink_local_99=f32::from_bits(0u32);let ink_local_100=f32::from_bits(0u32);let ink_local_101=f32::from_bits(0u32);let ink_local_102=f32::from_bits(0u32);let ink_local_103=f32::from_bits(0u32);let ink_local_104=f32::from_bits(0u32);let ink_local_105=f32::from_bits(0u32);let ink_local_106=f32::from_bits(0u32);let ink_local_107=f32::from_bits(0u32);l___ink_differential_2{l_value:ink_local_91,l_tangent_0:ink_local_92,l_tangent_1:ink_local_93,l_tangent_2:ink_local_94,l_tangent_3:ink_local_95,l_tangent_4:ink_local_96,l_tangent_5:ink_local_97,l_tangent_6:ink_local_98,l_tangent_7:ink_local_99,l_tangent_8:ink_local_100,l_tangent_9:ink_local_101,l_tangent_10:ink_local_102,l_tangent_11:ink_local_103,l_tangent_12:ink_local_104,l_tangent_13:ink_local_105,l_tangent_14:ink_local_106,l_tangent_15:ink_local_107}};let ink_local_126={let ink_local_109=((l_w).l_b).l_bias;let ink_local_110=f32::from_bits(0u32);let ink_local_111=f32::from_bits(0u32);let ink_local_112=f32::from_bits(0u32);let ink_local_113=f32::from_bits(0u32);let ink_local_114=f32::from_bits(0u32);let ink_local_115=f32::from_bits(0u32);let ink_local_116=f32::from_bits(1065353216u32);let ink_local_117=f32::from_bits(0u32);let ink_local_118=f32::from_bits(0u32);let ink_local_119=f32::from_bits(0u32);let ink_local_120=f32::from_bits(0u32);let ink_local_121=f32::from_bits(0u32);let ink_local_122=f32::from_bits(0u32);let ink_local_123=f32::from_bits(0u32);let ink_local_124=f32::from_bits(0u32);let ink_local_125=f32::from_bits(0u32);l___ink_differential_2{l_value:ink_local_109,l_tangent_0:ink_local_110,l_tangent_1:ink_local_111,l_tangent_2:ink_local_112,l_tangent_3:ink_local_113,l_tangent_4:ink_local_114,l_tangent_5:ink_local_115,l_tangent_6:ink_local_116,l_tangent_7:ink_local_117,l_tangent_8:ink_local_118,l_tangent_9:ink_local_119,l_tangent_10:ink_local_120,l_tangent_11:ink_local_121,l_tangent_12:ink_local_122,l_tangent_13:ink_local_123,l_tangent_14:ink_local_124,l_tangent_15:ink_local_125}};let ink_local_144={let ink_local_127=((l_w).l_b).l_relu;let ink_local_128=f32::from_bits(0u32);let ink_local_129=f32::from_bits(0u32);let ink_local_130=f32::from_bits(0u32);let ink_local_131=f32::from_bits(0u32);let ink_local_132=f32::from_bits(0u32);let ink_local_133=f32::from_bits(0u32);let ink_local_134=f32::from_bits(0u32);let ink_local_135=f32::from_bits(1065353216u32);let ink_local_136=f32::from_bits(0u32);let ink_local_137=f32::from_bits(0u32);let ink_local_138=f32::from_bits(0u32);let ink_local_139=f32::from_bits(0u32);let ink_local_140=f32::from_bits(0u32);let ink_local_141=f32::from_bits(0u32);let ink_local_142=f32::from_bits(0u32);let ink_local_143=f32::from_bits(0u32);l___ink_differential_2{l_value:ink_local_127,l_tangent_0:ink_local_128,l_tangent_1:ink_local_129,l_tangent_2:ink_local_130,l_tangent_3:ink_local_131,l_tangent_4:ink_local_132,l_tangent_5:ink_local_133,l_tangent_6:ink_local_134,l_tangent_7:ink_local_135,l_tangent_8:ink_local_136,l_tangent_9:ink_local_137,l_tangent_10:ink_local_138,l_tangent_11:ink_local_139,l_tangent_12:ink_local_140,l_tangent_13:ink_local_141,l_tangent_14:ink_local_142,l_tangent_15:ink_local_143}};l___ink_differential_5{l_identity:ink_local_90,l_scale:ink_local_108,l_bias:ink_local_126,l_relu:ink_local_144}};let ink_local_218={let ink_local_163={let ink_local_146=((l_w).l_c).l_identity;let ink_local_147=f32::from_bits(0u32);let ink_local_148=f32::from_bits(0u32);let ink_local_149=f32::from_bits(0u32);let ink_local_150=f32::from_bits(0u32);let ink_local_151=f32::from_bits(0u32);let ink_local_152=f32::from_bits(0u32);let ink_local_153=f32::from_bits(0u32);let ink_local_154=f32::from_bits(0u32);let ink_local_155=f32::from_bits(1065353216u32);let ink_local_156=f32::from_bits(0u32);let ink_local_157=f32::from_bits(0u32);let ink_local_158=f32::from_bits(0u32);let ink_local_159=f32::from_bits(0u32);let ink_local_160=f32::from_bits(0u32);let ink_local_161=f32::from_bits(0u32);let ink_local_162=f32::from_bits(0u32);l___ink_differential_2{l_value:ink_local_146,l_tangent_0:ink_local_147,l_tangent_1:ink_local_148,l_tangent_2:ink_local_149,l_tangent_3:ink_local_150,l_tangent_4:ink_local_151,l_tangent_5:ink_local_152,l_tangent_6:ink_local_153,l_tangent_7:ink_local_154,l_tangent_8:ink_local_155,l_tangent_9:ink_local_156,l_tangent_10:ink_local_157,l_tangent_11:ink_local_158,l_tangent_12:ink_local_159,l_tangent_13:ink_local_160,l_tangent_14:ink_local_161,l_tangent_15:ink_local_162}};let ink_local_181={let ink_local_164=((l_w).l_c).l_scale;let ink_local_165=f32::from_bits(0u32);let ink_local_166=f32::from_bits(0u32);let ink_local_167=f32::from_bits(0u32);let ink_local_168=f32::from_bits(0u32);let ink_local_169=f32::from_bits(0u32);let ink_local_170=f32::from_bits(0u32);let ink_local_171=f32::from_bits(0u32);let ink_local_172=f32::from_bits(0u32);let ink_local_173=f32::from_bits(0u32);let ink_local_174=f32::from_bits(1065353216u32);let ink_local_175=f32::from_bits(0u32);let ink_local_176=f32::from_bits(0u32);let ink_local_177=f32::from_bits(0u32);let ink_local_178=f32::from_bits(0u32);let ink_local_179=f32::from_bits(0u32);let ink_local_180=f32::from_bits(0u32);l___ink_differential_2{l_value:ink_local_164,l_tangent_0:ink_local_165,l_tangent_1:ink_local_166,l_tangent_2:ink_local_167,l_tangent_3:ink_local_168,l_tangent_4:ink_local_169,l_tangent_5:ink_local_170,l_tangent_6:ink_local_171,l_tangent_7:ink_local_172,l_tangent_8:ink_local_173,l_tangent_9:ink_local_174,l_tangent_10:ink_local_175,l_tangent_11:ink_local_176,l_tangent_12:ink_local_177,l_tangent_13:ink_local_178,l_tangent_14:ink_local_179,l_tangent_15:ink_local_180}};let ink_local_199={let ink_local_182=((l_w).l_c).l_bias;let ink_local_183=f32::from_bits(0u32);let ink_local_184=f32::from_bits(0u32);let ink_local_185=f32::from_bits(0u32);let ink_local_186=f32::from_bits(0u32);let ink_local_187=f32::from_bits(0u32);let ink_local_188=f32::from_bits(0u32);let ink_local_189=f32::from_bits(0u32);let ink_local_190=f32::from_bits(0u32);let ink_local_191=f32::from_bits(0u32);let ink_local_192=f32::from_bits(0u32);let ink_local_193=f32::from_bits(1065353216u32);let ink_local_194=f32::from_bits(0u32);let ink_local_195=f32::from_bits(0u32);let ink_local_196=f32::from_bits(0u32);let ink_local_197=f32::from_bits(0u32);let ink_local_198=f32::from_bits(0u32);l___ink_differential_2{l_value:ink_local_182,l_tangent_0:ink_local_183,l_tangent_1:ink_local_184,l_tangent_2:ink_local_185,l_tangent_3:ink_local_186,l_tangent_4:ink_local_187,l_tangent_5:ink_local_188,l_tangent_6:ink_local_189,l_tangent_7:ink_local_190,l_tangent_8:ink_local_191,l_tangent_9:ink_local_192,l_tangent_10:ink_local_193,l_tangent_11:ink_local_194,l_tangent_12:ink_local_195,l_tangent_13:ink_local_196,l_tangent_14:ink_local_197,l_tangent_15:ink_local_198}};let ink_local_217={let ink_local_200=((l_w).l_c).l_relu;let ink_local_201=f32::from_bits(0u32);let ink_local_202=f32::from_bits(0u32);let ink_local_203=f32::from_bits(0u32);let ink_local_204=f32::from_bits(0u32);let ink_local_205=f32::from_bits(0u32);let ink_local_206=f32::from_bits(0u32);let ink_local_207=f32::from_bits(0u32);let ink_local_208=f32::from_bits(0u32);let ink_local_209=f32::from_bits(0u32);let ink_local_210=f32::from_bits(0u32);let ink_local_211=f32::from_bits(0u32);let ink_local_212=f32::from_bits(1065353216u32);let ink_local_213=f32::from_bits(0u32);let ink_local_214=f32::from_bits(0u32);let ink_local_215=f32::from_bits(0u32);let ink_local_216=f32::from_bits(0u32);l___ink_differential_2{l_value:ink_local_200,l_tangent_0:ink_local_201,l_tangent_1:ink_local_202,l_tangent_2:ink_local_203,l_tangent_3:ink_local_204,l_tangent_4:ink_local_205,l_tangent_5:ink_local_206,l_tangent_6:ink_local_207,l_tangent_7:ink_local_208,l_tangent_8:ink_local_209,l_tangent_9:ink_local_210,l_tangent_10:ink_local_211,l_tangent_11:ink_local_212,l_tangent_12:ink_local_213,l_tangent_13:ink_local_214,l_tangent_14:ink_local_215,l_tangent_15:ink_local_216}};l___ink_differential_5{l_identity:ink_local_163,l_scale:ink_local_181,l_bias:ink_local_199,l_relu:ink_local_217}};let ink_local_291={let ink_local_236={let ink_local_219=((l_w).l_d).l_identity;let ink_local_220=f32::from_bits(0u32);let ink_local_221=f32::from_bits(0u32);let ink_local_222=f32::from_bits(0u32);let ink_local_223=f32::from_bits(0u32);let ink_local_224=f32::from_bits(0u32);let ink_local_225=f32::from_bits(0u32);let ink_local_226=f32::from_bits(0u32);let ink_local_227=f32::from_bits(0u32);let ink_local_228=f32::from_bits(0u32);let ink_local_229=f32::from_bits(0u32);let ink_local_230=f32::from_bits(0u32);let ink_local_231=f32::from_bits(0u32);let ink_local_232=f32::from_bits(1065353216u32);let ink_local_233=f32::from_bits(0u32);let ink_local_234=f32::from_bits(0u32);let ink_local_235=f32::from_bits(0u32);l___ink_differential_2{l_value:ink_local_219,l_tangent_0:ink_local_220,l_tangent_1:ink_local_221,l_tangent_2:ink_local_222,l_tangent_3:ink_local_223,l_tangent_4:ink_local_224,l_tangent_5:ink_local_225,l_tangent_6:ink_local_226,l_tangent_7:ink_local_227,l_tangent_8:ink_local_228,l_tangent_9:ink_local_229,l_tangent_10:ink_local_230,l_tangent_11:ink_local_231,l_tangent_12:ink_local_232,l_tangent_13:ink_local_233,l_tangent_14:ink_local_234,l_tangent_15:ink_local_235}};let ink_local_254={let ink_local_237=((l_w).l_d).l_scale;let ink_local_238=f32::from_bits(0u32);let ink_local_239=f32::from_bits(0u32);let ink_local_240=f32::from_bits(0u32);let ink_local_241=f32::from_bits(0u32);let ink_local_242=f32::from_bits(0u32);let ink_local_243=f32::from_bits(0u32);let ink_local_244=f32::from_bits(0u32);let ink_local_245=f32::from_bits(0u32);let ink_local_246=f32::from_bits(0u32);let ink_local_247=f32::from_bits(0u32);let ink_local_248=f32::from_bits(0u32);let ink_local_249=f32::from_bits(0u32);let ink_local_250=f32::from_bits(0u32);let ink_local_251=f32::from_bits(1065353216u32);let ink_local_252=f32::from_bits(0u32);let ink_local_253=f32::from_bits(0u32);l___ink_differential_2{l_value:ink_local_237,l_tangent_0:ink_local_238,l_tangent_1:ink_local_239,l_tangent_2:ink_local_240,l_tangent_3:ink_local_241,l_tangent_4:ink_local_242,l_tangent_5:ink_local_243,l_tangent_6:ink_local_244,l_tangent_7:ink_local_245,l_tangent_8:ink_local_246,l_tangent_9:ink_local_247,l_tangent_10:ink_local_248,l_tangent_11:ink_local_249,l_tangent_12:ink_local_250,l_tangent_13:ink_local_251,l_tangent_14:ink_local_252,l_tangent_15:ink_local_253}};let ink_local_272={let ink_local_255=((l_w).l_d).l_bias;let ink_local_256=f32::from_bits(0u32);let ink_local_257=f32::from_bits(0u32);let ink_local_258=f32::from_bits(0u32);let ink_local_259=f32::from_bits(0u32);let ink_local_260=f32::from_bits(0u32);let ink_local_261=f32::from_bits(0u32);let ink_local_262=f32::from_bits(0u32);let ink_local_263=f32::from_bits(0u32);let ink_local_264=f32::from_bits(0u32);let ink_local_265=f32::from_bits(0u32);let ink_local_266=f32::from_bits(0u32);let ink_local_267=f32::from_bits(0u32);let ink_local_268=f32::from_bits(0u32);let ink_local_269=f32::from_bits(0u32);let ink_local_270=f32::from_bits(1065353216u32);let ink_local_271=f32::from_bits(0u32);l___ink_differential_2{l_value:ink_local_255,l_tangent_0:ink_local_256,l_tangent_1:ink_local_257,l_tangent_2:ink_local_258,l_tangent_3:ink_local_259,l_tangent_4:ink_local_260,l_tangent_5:ink_local_261,l_tangent_6:ink_local_262,l_tangent_7:ink_local_263,l_tangent_8:ink_local_264,l_tangent_9:ink_local_265,l_tangent_10:ink_local_266,l_tangent_11:ink_local_267,l_tangent_12:ink_local_268,l_tangent_13:ink_local_269,l_tangent_14:ink_local_270,l_tangent_15:ink_local_271}};let ink_local_290={let ink_local_273=((l_w).l_d).l_relu;let ink_local_274=f32::from_bits(0u32);let ink_local_275=f32::from_bits(0u32);let ink_local_276=f32::from_bits(0u32);let ink_local_277=f32::from_bits(0u32);let ink_local_278=f32::from_bits(0u32);let ink_local_279=f32::from_bits(0u32);let ink_local_280=f32::from_bits(0u32);let ink_local_281=f32::from_bits(0u32);let ink_local_282=f32::from_bits(0u32);let ink_local_283=f32::from_bits(0u32);let ink_local_284=f32::from_bits(0u32);let ink_local_285=f32::from_bits(0u32);let ink_local_286=f32::from_bits(0u32);let ink_local_287=f32::from_bits(0u32);let ink_local_288=f32::from_bits(0u32);let ink_local_289=f32::from_bits(1065353216u32);l___ink_differential_2{l_value:ink_local_273,l_tangent_0:ink_local_274,l_tangent_1:ink_local_275,l_tangent_2:ink_local_276,l_tangent_3:ink_local_277,l_tangent_4:ink_local_278,l_tangent_5:ink_local_279,l_tangent_6:ink_local_280,l_tangent_7:ink_local_281,l_tangent_8:ink_local_282,l_tangent_9:ink_local_283,l_tangent_10:ink_local_284,l_tangent_11:ink_local_285,l_tangent_12:ink_local_286,l_tangent_13:ink_local_287,l_tangent_14:ink_local_288,l_tangent_15:ink_local_289}};l___ink_differential_5{l_identity:ink_local_236,l_scale:ink_local_254,l_bias:ink_local_272,l_relu:ink_local_290}};l___ink_differential_4{l_a:ink_local_72,l_b:ink_local_145,l_c:ink_local_218,l_d:ink_local_291}};let ink_local_295={let ink_local_293=(l_p).l_slot;let ink_local_294=(l_p).l_operation;l___ink_differential_6{l_slot:ink_local_293,l_operation:ink_local_294}};self.function_l___ink_differential_3(ink_local_292,ink_local_295)};{let ink_local_301={let ink_local_297=(ink_local_296).l_tangent_0;let ink_local_298=(ink_local_296).l_tangent_1;let ink_local_299=(ink_local_296).l_tangent_2;let ink_local_300=(ink_local_296).l_tangent_3;l_MassRow{l_identity:ink_local_297,l_scale:ink_local_298,l_bias:ink_local_299,l_relu:ink_local_300}};let ink_local_306={let ink_local_302=(ink_local_296).l_tangent_4;let ink_local_303=(ink_local_296).l_tangent_5;let ink_local_304=(ink_local_296).l_tangent_6;let ink_local_305=(ink_local_296).l_tangent_7;l_MassRow{l_identity:ink_local_302,l_scale:ink_local_303,l_bias:ink_local_304,l_relu:ink_local_305}};let ink_local_311={let ink_local_307=(ink_local_296).l_tangent_8;let ink_local_308=(ink_local_296).l_tangent_9;let ink_local_309=(ink_local_296).l_tangent_10;let ink_local_310=(ink_local_296).l_tangent_11;l_MassRow{l_identity:ink_local_307,l_scale:ink_local_308,l_bias:ink_local_309,l_relu:ink_local_310}};let ink_local_316={let ink_local_312=(ink_local_296).l_tangent_12;let ink_local_313=(ink_local_296).l_tangent_13;let ink_local_314=(ink_local_296).l_tangent_14;let ink_local_315=(ink_local_296).l_tangent_15;l_MassRow{l_identity:ink_local_312,l_scale:ink_local_313,l_bias:ink_local_314,l_relu:ink_local_315}};l_Parameters{l_a:ink_local_301,l_b:ink_local_306,l_c:ink_local_311,l_d:ink_local_316}}}}
#[cfg(target_arch="wasm32")] pub fn parallel_worker(&self,task:&Json)->Result<Json,String>{let start=task["start"].as_u64().and_then(|x|u32::try_from(x).ok()).ok_or("parallel start")?;let items=task["items"].as_array().ok_or("parallel items")?;let captures=task["captures"].as_array().ok_or("parallel captures")?;temporary::with_parallel_worker(||match task["callback"].as_str().ok_or("parallel callback")?{
_=>Err("unknown compiled parallel callback".into()),})}
fn action_l_initialize(&mut self,)->Result<(),String>{let l_p:l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab=({let tmp_1:Vec<f32>=vec![f32::from_bits(1065353216u32),f32::from_bits(1065353216u32),f32::from_bits(1065353216u32),f32::from_bits(1065353216u32),f32::from_bits(1065353216u32),f32::from_bits(1065353216u32),f32::from_bits(1065353216u32),f32::from_bits(1065353216u32),f32::from_bits(1065353216u32),f32::from_bits(1065353216u32),f32::from_bits(1065353216u32),f32::from_bits(1065353216u32),f32::from_bits(1065353216u32),f32::from_bits(1065353216u32),f32::from_bits(1065353216u32),f32::from_bits(1065353216u32)];self.function_l_ink_mdfbd57a9f460147afedb262e2bfe0f6197f9b813c85277c59f5e101900063ad7(tmp_1)})?;
let _:()={let key=0u64;let value=l_p;self.set_l_Policy(key,Some(value),false);};
return Ok(());
}
pub fn invoke_view_l_initialize(&mut self,)->Result<OutcomeView<'_,Result<(),String>>,String>{
self.clear_journal_keys();let mark=self.undo.len();let result=self.action_l_initialize();
let version=match transaction::decide(self.version,result.is_ok()){transaction::Decision::Rollback=>{self.rollback_to(mark);return Ok(OutcomeView{result,committed:false,version:self.version,events:&[]})},transaction::Decision::Exhausted=>{self.rollback_to(mark);return Err("commit sequence exhausted".into())},transaction::Decision::Commit{version}=>version};self.version=version;if self.host.is_none(){self.undo.clear();}self.clear_journal_keys();let start=self.outbox.len();self.outbox.extend(transaction::publish(version,self.staged.drain(..)).map(|published|Event{commit:published.commit,position:published.position,data:published.value}));Ok(OutcomeView{result,committed:true,version,events:&self.outbox[start..]})}
pub fn invoke_l_initialize(&mut self,)->Result<Outcome<Result<(),String>>,String>{self.invoke_view_l_initialize().map(OutcomeView::into_owned)}
fn action_l_retarget(&mut self,l_samples:Vec<l_Example>,l_instruction_cost:f32,l_expected:u32)->Result<u32,String>{let l_old:u32=match self.l_Target.get(&(0u64)).cloned() {Some(l_g)=>{l_g.l_version.clone()},None=>{let l_u=();0u32}};
if ((!InkDataEq::ink_data_eq(&(l_expected),&(<u32 as Clone>::clone(&l_old)))) || (InkDataEq::ink_data_eq(&(<u32 as Clone>::clone(&l_old)),&(4294967295u32)))) {return Err("stale goal".to_owned());
} else {}
let l_next:l_Goal=l_Goal{l_samples:l_samples,l_instruction_cost:l_instruction_cost,l_version:(l_old).wrapping_add(1u32)};
if InkDataEq::ink_data_eq(&({let tmp_2:l_Goal=<l_Goal as Clone>::clone(&l_next);self.function_l_goal_valid(tmp_2)}),&(false)) {return Err("goal domain".to_owned());
} else {}
let _:()={let key=0u64;let value=<l_Goal as Clone>::clone(&l_next);self.set_l_Target(key,Some(value),false);};
let l_reset:()=({transaction::nested_change(self.action_l_initialize())?})?;
return Ok(l_next.l_version);
}
pub fn invoke_view_l_retarget(&mut self,l_samples:Vec<l_Example>,l_instruction_cost:f32,l_expected:u32)->Result<OutcomeView<'_,Result<u32,String>>,String>{
self.clear_journal_keys();let mark=self.undo.len();let result=self.action_l_retarget(l_samples,l_instruction_cost,l_expected);
let version=match transaction::decide(self.version,result.is_ok()){transaction::Decision::Rollback=>{self.rollback_to(mark);return Ok(OutcomeView{result,committed:false,version:self.version,events:&[]})},transaction::Decision::Exhausted=>{self.rollback_to(mark);return Err("commit sequence exhausted".into())},transaction::Decision::Commit{version}=>version};self.version=version;if self.host.is_none(){self.undo.clear();}self.clear_journal_keys();let start=self.outbox.len();self.outbox.extend(transaction::publish(version,self.staged.drain(..)).map(|published|Event{commit:published.commit,position:published.position,data:published.value}));Ok(OutcomeView{result,committed:true,version,events:&self.outbox[start..]})}
pub fn invoke_l_retarget(&mut self,l_samples:Vec<l_Example>,l_instruction_cost:f32,l_expected:u32)->Result<Outcome<Result<u32,String>>,String>{self.invoke_view_l_retarget(l_samples,l_instruction_cost,l_expected).map(OutcomeView::into_owned)}
fn action_l_retune(&mut self,l_w:l_Coefficients,l_fail:bool)->Result<(),String>{if {let l___ink_local_18:Option<()>=Some(());match l___ink_local_18 {Some(l___ink_local_16)=>{{let tmp_3:l_Coefficients=<l_Coefficients as Clone>::clone(&l_w);self.function_l_coefficients_valid(tmp_3)}},None=>{let l___ink_local_17=();{let tmp_4:l_Coefficients=<l_Coefficients as Clone>::clone(&l_w);self.function_l_coefficients_valid(tmp_4)}}}} {let _:()={let key=0u64;let value=<l_Coefficients as Clone>::clone(&l_w);self.set_l_Weights(key,Some(value),false);};
{let value=<l_Coefficients as Clone>::clone(&l_w);self.staged.push(EventData::l_updated(value));}
if l_fail {return Err("cancel coefficient update".to_owned());
} else {}
return Ok(());
} else {return Err({let l___ink_local_21:Option<()>=Some(());match l___ink_local_21 {Some(l___ink_local_19)=>{"coefficient domain".to_owned()},None=>{let l___ink_local_20=();"coefficient domain".to_owned()}}});
}
}
pub fn invoke_view_l_retune(&mut self,l_w:l_Coefficients,l_fail:bool)->Result<OutcomeView<'_,Result<(),String>>,String>{
self.clear_journal_keys();let mark=self.undo.len();let result=self.action_l_retune(l_w,l_fail);
let version=match transaction::decide(self.version,result.is_ok()){transaction::Decision::Rollback=>{self.rollback_to(mark);return Ok(OutcomeView{result,committed:false,version:self.version,events:&[]})},transaction::Decision::Exhausted=>{self.rollback_to(mark);return Err("commit sequence exhausted".into())},transaction::Decision::Commit{version}=>version};self.version=version;if self.host.is_none(){self.undo.clear();}self.clear_journal_keys();let start=self.outbox.len();self.outbox.extend(transaction::publish(version,self.staged.drain(..)).map(|published|Event{commit:published.commit,position:published.position,data:published.value}));Ok(OutcomeView{result,committed:true,version,events:&self.outbox[start..]})}
pub fn invoke_l_retune(&mut self,l_w:l_Coefficients,l_fail:bool)->Result<Outcome<Result<(),String>>,String>{self.invoke_view_l_retune(l_w,l_fail).map(OutcomeView::into_owned)}
fn action_l_episode(&mut self,l_units:Vec<f32>,l_rate:f32,l_goal_version:u32)->Result<l_Report,String>{let l_policy:l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab=((self.l_Policy.get(&(0u64)).cloned()).ok_or("initialize policy".to_owned()))?;
let l_goal:l_Goal=((self.l_Target.get(&(0u64)).cloned()).ok_or("initialize target".to_owned()))?;
let l_w:l_Coefficients=(self.l_Weights.get(&(0u64)).cloned()).unwrap_or(l_Coefficients{l_scale:f32::from_bits(1061158912u32),l_bias:f32::from_bits(1048576000u32)});
if ((((((((((((InkDataEq::ink_data_eq(&({let tmp_5:l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab=<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab as Clone>::clone(&l_policy);self.function_l_valid_policy(tmp_5)}),&(false))) || (InkDataEq::ink_data_eq(&({let tmp_6:l_Goal=<l_Goal as Clone>::clone(&l_goal);self.function_l_goal_valid(tmp_6)}),&(false))))) || (InkDataEq::ink_data_eq(&({let tmp_7:l_Coefficients=<l_Coefficients as Clone>::clone(&l_w);self.function_l_coefficients_valid(tmp_7)}),&(false))))) || (!InkDataEq::ink_data_eq(&(l_goal.l_version.clone()),&(l_goal_version))))) || (InkDataEq::ink_data_eq(&((<f32 as Clone>::clone(&l_rate)).is_finite()),&(false))))) || (((<f32 as Clone>::clone(&l_rate)) <= (f32::from_bits(0u32)))))) || (((<f32 as Clone>::clone(&l_rate)) > (f32::from_bits(1036831949u32))))) {return Err("training domain or stale goal".to_owned());
} else {}
let l_previous:Vec<l_Op>=(self.l_Structure.get(&(0u64)).cloned()).unwrap_or(vec![]);
let l_before:f32={let tmp_8:Vec<l_Op>=<Vec<l_Op> as Clone>::clone(&l_previous);let tmp_9:l_Coefficients=<l_Coefficients as Clone>::clone(&l_w);let tmp_10:l_Goal=<l_Goal as Clone>::clone(&l_goal);self.function_l_objective(tmp_8,tmp_9,tmp_10)};
let l_candidate:l_Sampled=({let tmp_11:Vec<f32>=l_policy.l_weights.clone();let tmp_12:Vec<f32>=l_units;self.function_l_sample(tmp_11,tmp_12)})?;
let l_loss:f32={let tmp_13:Vec<l_Op>=l_candidate.l_code.clone();let tmp_14:l_Coefficients=l_w;let tmp_15:l_Goal=<l_Goal as Clone>::clone(&l_goal);self.function_l_objective(tmp_13,tmp_14,tmp_15)};
let l_accepted:bool=((<f32 as Clone>::clone(&l_loss)) < (<f32 as Clone>::clone(&l_before)));
let l_selected:Vec<l_Op>=if <bool as Clone>::clone(&l_accepted) {l_candidate.l_code} else {l_previous};
let l_gradient:Vec<f32>=({let tmp_16:Vec<f32>=l_policy.l_weights.clone();let tmp_17:Vec<l_Op>=<Vec<l_Op> as Clone>::clone(&l_selected);let tmp_18:Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0>=l_candidate.l_decisions;let tmp_19:f32=<f32 as Clone>::clone(&l_loss);let tmp_20:f32=<f32 as Clone>::clone(&l_before);self.function_l_proposal_gradient(tmp_16,tmp_17,tmp_18,tmp_19,tmp_20)})?;
let l_next:l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab=({let tmp_21:l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab=l_policy;let tmp_22:Vec<f32>=l_gradient;let tmp_24:l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249={let l___ink_surface_2193_base:l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249={let tmp_23:f32=l_rate;self.function_l_ink_meefc22a28d97f5bdc4100b36eeab9549241c3ef201b83c2f75111644d317833d(tmp_23)};{let l___ink_surface_2193_field0:f32=f32::from_bits(0u32);l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249{l_rate:l___ink_surface_2193_base.l_rate,l_first_decay:l___ink_surface_2193_base.l_first_decay,l_second_decay:l___ink_surface_2193_base.l_second_decay,l_epsilon:l___ink_surface_2193_base.l_epsilon,l_weight_decay:l___ink_surface_2193_base.l_weight_decay,l_norm_limit:l___ink_surface_2193_field0}}};self.function_l_ink_m2a55f95a80595bc61d1fcab41ff00f438ff6f2057b597df20aaae3c18507d2be(tmp_21,tmp_22,tmp_24)})?;
if ((InkDataEq::ink_data_eq(&({let tmp_25:l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab=<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab as Clone>::clone(&l_next);self.function_l_valid_policy(tmp_25)}),&(false))) || (InkDataEq::ink_data_eq(&((<f32 as Clone>::clone(&l_loss)).is_finite()),&(false)))) {return Err("candidate domain".to_owned());
} else {}
if <bool as Clone>::clone(&l_accepted) {let _:()={let key=0u64;let value=l_selected;self.set_l_Structure(key,Some(value),false);};
} else {}
let _:()={let key=0u64;let value=<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab as Clone>::clone(&l_next);self.set_l_Policy(key,Some(value),false);};
let l_report:l_Report=l_Report{l_step:l_next.l_steps,l_loss:<f32 as Clone>::clone(&l_loss),l_best:if <bool as Clone>::clone(&l_accepted) {l_loss} else {l_before},l_accepted:l_accepted,l_goal_version:l_goal.l_version};
{let value=<l_Report as Clone>::clone(&l_report);self.staged.push(EventData::l_searched(value));}
return Ok(l_report);
}
pub fn invoke_view_l_episode(&mut self,l_units:Vec<f32>,l_rate:f32,l_goal_version:u32)->Result<OutcomeView<'_,Result<l_Report,String>>,String>{
self.clear_journal_keys();let mark=self.undo.len();let result=self.action_l_episode(l_units,l_rate,l_goal_version);
let version=match transaction::decide(self.version,result.is_ok()){transaction::Decision::Rollback=>{self.rollback_to(mark);return Ok(OutcomeView{result,committed:false,version:self.version,events:&[]})},transaction::Decision::Exhausted=>{self.rollback_to(mark);return Err("commit sequence exhausted".into())},transaction::Decision::Commit{version}=>version};self.version=version;if self.host.is_none(){self.undo.clear();}self.clear_journal_keys();let start=self.outbox.len();self.outbox.extend(transaction::publish(version,self.staged.drain(..)).map(|published|Event{commit:published.commit,position:published.position,data:published.value}));Ok(OutcomeView{result,committed:true,version,events:&self.outbox[start..]})}
pub fn invoke_l_episode(&mut self,l_units:Vec<f32>,l_rate:f32,l_goal_version:u32)->Result<Outcome<Result<l_Report,String>>,String>{self.invoke_view_l_episode(l_units,l_rate,l_goal_version).map(OutcomeView::into_owned)}
fn action_l_aborted(&mut self,l_units:Vec<f32>,l_rate:f32,l_goal_version:u32)->Result<(),String>{let l_report:l_Report=({let tmp_26:Vec<f32>=l_units;let tmp_27:f32=l_rate;let tmp_28:u32=l_goal_version;transaction::nested_change(self.action_l_episode(tmp_26,tmp_27,tmp_28))?})?;
return Err("cancel whole search step".to_owned());
}
pub fn invoke_view_l_aborted(&mut self,l_units:Vec<f32>,l_rate:f32,l_goal_version:u32)->Result<OutcomeView<'_,Result<(),String>>,String>{
self.clear_journal_keys();let mark=self.undo.len();let result=self.action_l_aborted(l_units,l_rate,l_goal_version);
let version=match transaction::decide(self.version,result.is_ok()){transaction::Decision::Rollback=>{self.rollback_to(mark);return Ok(OutcomeView{result,committed:false,version:self.version,events:&[]})},transaction::Decision::Exhausted=>{self.rollback_to(mark);return Err("commit sequence exhausted".into())},transaction::Decision::Commit{version}=>version};self.version=version;if self.host.is_none(){self.undo.clear();}self.clear_journal_keys();let start=self.outbox.len();self.outbox.extend(transaction::publish(version,self.staged.drain(..)).map(|published|Event{commit:published.commit,position:published.position,data:published.value}));Ok(OutcomeView{result,committed:true,version,events:&self.outbox[start..]})}
pub fn invoke_l_aborted(&mut self,l_units:Vec<f32>,l_rate:f32,l_goal_version:u32)->Result<Outcome<Result<(),String>>,String>{self.invoke_view_l_aborted(l_units,l_rate,l_goal_version).map(OutcomeView::into_owned)}
fn action_l_serve(&mut self,l_input:f32)->f32{return temporary::ink_f32(({let tmp_29:Vec<l_Op>=(self.l_Structure.get(&(0u64)).cloned()).unwrap_or(vec![]);let tmp_30:l_Coefficients=(self.l_Weights.get(&(0u64)).cloned()).unwrap_or(l_Coefficients{l_scale:f32::from_bits(1061158912u32),l_bias:f32::from_bits(1048576000u32)});let tmp_31:f32=l_input;self.function_l_evaluate(tmp_29,tmp_30,tmp_31)}) + ((self.l_Live.get(&(0u64)).cloned()).unwrap_or(f32::from_bits(0u32))));
}
pub fn invoke_view_l_serve(&mut self,l_input:f32)->Result<OutcomeView<'_,f32>,String>{
self.clear_journal_keys();let mark=self.undo.len();let result=self.action_l_serve(l_input);
Ok(OutcomeView{result,committed:false,version:self.version,events:&[]})}
pub fn invoke_l_serve(&mut self,l_input:f32)->Result<Outcome<f32>,String>{self.invoke_view_l_serve(l_input).map(OutcomeView::into_owned)}
fn action_l_structure(&mut self,)->Vec<l_Op>{return (self.l_Structure.get(&(0u64)).cloned()).unwrap_or(vec![]);
}
pub fn invoke_view_l_structure(&mut self,)->Result<OutcomeView<'_,Vec<l_Op>>,String>{
self.clear_journal_keys();let mark=self.undo.len();let result=self.action_l_structure();
Ok(OutcomeView{result,committed:false,version:self.version,events:&[]})}
pub fn invoke_l_structure(&mut self,)->Result<Outcome<Vec<l_Op>>,String>{self.invoke_view_l_structure().map(OutcomeView::into_owned)}
fn action_l_policy(&mut self,)->Result<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab,String>{return (self.l_Policy.get(&(0u64)).cloned()).ok_or("initialize policy".to_owned());
}
pub fn invoke_view_l_policy(&mut self,)->Result<OutcomeView<'_,Result<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab,String>>,String>{
self.clear_journal_keys();let mark=self.undo.len();let result=self.action_l_policy();
Ok(OutcomeView{result,committed:false,version:self.version,events:&[]})}
pub fn invoke_l_policy(&mut self,)->Result<Outcome<Result<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab,String>>,String>{self.invoke_view_l_policy().map(OutcomeView::into_owned)}
fn action_l_loss(&mut self,)->Result<f32,String>{let l_goal:l_Goal=((self.l_Target.get(&(0u64)).cloned()).ok_or("initialize target".to_owned()))?;
if InkDataEq::ink_data_eq(&({let tmp_32:l_Goal=<l_Goal as Clone>::clone(&l_goal);self.function_l_goal_valid(tmp_32)}),&(false)) {return Err("goal domain".to_owned());
} else {}
return Ok({let tmp_33:Vec<l_Op>=(self.l_Structure.get(&(0u64)).cloned()).unwrap_or(vec![]);let tmp_34:l_Coefficients=(self.l_Weights.get(&(0u64)).cloned()).unwrap_or(l_Coefficients{l_scale:f32::from_bits(1061158912u32),l_bias:f32::from_bits(1048576000u32)});let tmp_35:l_Goal=l_goal;self.function_l_objective(tmp_33,tmp_34,tmp_35)});
}
pub fn invoke_view_l_loss(&mut self,)->Result<OutcomeView<'_,Result<f32,String>>,String>{
self.clear_journal_keys();let mark=self.undo.len();let result=self.action_l_loss();
Ok(OutcomeView{result,committed:false,version:self.version,events:&[]})}
pub fn invoke_l_loss(&mut self,)->Result<Outcome<Result<f32,String>>,String>{self.invoke_view_l_loss().map(OutcomeView::into_owned)}
fn action_l_set_live(&mut self,l_value:f32)->(){let _:()={let key=0u64;let value=l_value;self.set_l_Live(key,Some(value),false);};
return ();
}
pub fn invoke_view_l_set_live(&mut self,l_value:f32)->Result<OutcomeView<'_,()>,String>{
self.clear_journal_keys();let mark=self.undo.len();let result=self.action_l_set_live(l_value);
let version=match transaction::decide(self.version,true){transaction::Decision::Rollback=>{self.rollback_to(mark);return Ok(OutcomeView{result,committed:false,version:self.version,events:&[]})},transaction::Decision::Exhausted=>{self.rollback_to(mark);return Err("commit sequence exhausted".into())},transaction::Decision::Commit{version}=>version};self.version=version;if self.host.is_none(){self.undo.clear();}self.clear_journal_keys();let start=self.outbox.len();self.outbox.extend(transaction::publish(version,self.staged.drain(..)).map(|published|Event{commit:published.commit,position:published.position,data:published.value}));Ok(OutcomeView{result,committed:true,version,events:&self.outbox[start..]})}
pub fn invoke_l_set_live(&mut self,l_value:f32)->Result<Outcome<()>,String>{self.invoke_view_l_set_live(l_value).map(OutcomeView::into_owned)}
pub fn call_json(&mut self,name:&str,args:&Json)->Result<Json,String>{let args=args.as_array().unwrap();match name{
"evaluate"=>{let a0=<Vec<l_Op> as Wire>::from_json(&args[0])?;let a1=<l_Coefficients as Wire>::from_json(&args[1])?;let a2=<f32 as Wire>::from_json(&args[2])?;Ok(self.function_l_evaluate(a0,a1,a2).to_json())},
"coefficients_valid"=>{let a0=<l_Coefficients as Wire>::from_json(&args[0])?;Ok(self.function_l_coefficients_valid(a0).to_json())},
"goal_valid"=>{let a0=<l_Goal as Wire>::from_json(&args[0])?;Ok(self.function_l_goal_valid(a0).to_json())},
"squared_error"=>{let a0=<Vec<l_Op> as Wire>::from_json(&args[0])?;let a1=<l_Coefficients as Wire>::from_json(&args[1])?;let a2=<l_Example as Wire>::from_json(&args[2])?;Ok(self.function_l_squared_error(a0,a1,a2).to_json())},
"objective"=>{let a0=<Vec<l_Op> as Wire>::from_json(&args[0])?;let a1=<l_Coefficients as Wire>::from_json(&args[1])?;let a2=<l_Goal as Wire>::from_json(&args[2])?;Ok(self.function_l_objective(a0,a1,a2).to_json())},
"unpack"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;Ok(self.function_l_unpack(a0).to_json())},
"pack"=>{let a0=<l_Parameters as Wire>::from_json(&args[0])?;Ok(self.function_l_pack(a0).to_json())},
"mass"=>{let a0=<l_Parameters as Wire>::from_json(&args[0])?;let a1=<l_Pick as Wire>::from_json(&args[1])?;Ok(self.function_l_mass(a0,a1).to_json())},
"operation"=>{let a0=<u32 as Wire>::from_json(&args[0])?;Ok(self.function_l_operation(a0).to_json())},
"distribution"=>{let a0=<l_Parameters as Wire>::from_json(&args[0])?;let a1=<u32 as Wire>::from_json(&args[1])?;Ok(self.function_l_distribution(a0,a1).to_json())},
"sample_slot"=>{let a0=<Result<l_Building,String> as Wire>::from_json(&args[0])?;let a1=<u32 as Wire>::from_json(&args[1])?;let a2=<l_Parameters as Wire>::from_json(&args[2])?;let a3=<Vec<f32> as Wire>::from_json(&args[3])?;Ok(self.function_l_sample_slot(a0,a1,a2,a3).to_json())},
"sample"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;let a1=<Vec<f32> as Wire>::from_json(&args[1])?;Ok(self.function_l_sample(a0,a1).to_json())},
"reward"=>{let a0=<f32 as Wire>::from_json(&args[0])?;Ok(self.function_l_reward(a0).to_json())},
"operation_index"=>{let a0=<l_Op as Wire>::from_json(&args[0])?;Ok(self.function_l_operation_index(a0).to_json())},
"elite_slot"=>{let a0=<Result<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0>,String> as Wire>::from_json(&args[0])?;let a1=<u32 as Wire>::from_json(&args[1])?;let a2=<l_Parameters as Wire>::from_json(&args[2])?;let a3=<Vec<l_Op> as Wire>::from_json(&args[3])?;Ok(self.function_l_elite_slot(a0,a1,a2,a3).to_json())},
"proposal_gradient"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;let a1=<Vec<l_Op> as Wire>::from_json(&args[1])?;let a2=<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0> as Wire>::from_json(&args[2])?;let a3=<f32 as Wire>::from_json(&args[3])?;let a4=<f32 as Wire>::from_json(&args[4])?;Ok(self.function_l_proposal_gradient(a0,a1,a2,a3,a4).to_json())},
"valid_policy"=>{let a0=<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab as Wire>::from_json(&args[0])?;Ok(self.function_l_valid_policy(a0).to_json())},
"numeric"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;Ok(self.function_l_numeric(a0).to_json())},
"ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;Ok(self.function_l_ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54(a0).to_json())},
"ink_m28a5428efa573345218636e9cec104f24b6e8c67d7c4c0f979b255813b2abee3"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;let a1=<Vec<bool> as Wire>::from_json(&args[1])?;Ok(self.function_l_ink_m28a5428efa573345218636e9cec104f24b6e8c67d7c4c0f979b255813b2abee3(a0,a1).to_json())},
"ink_mfd18151b0af45b45f5b48ef5e7a09ac1294681f654e2174ae3b33183f445ef14"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;let a1=<Vec<bool> as Wire>::from_json(&args[1])?;Ok(self.function_l_ink_mfd18151b0af45b45f5b48ef5e7a09ac1294681f654e2174ae3b33183f445ef14(a0,a1).to_json())},
"ink_mc05a2256079ef1f1818d13e69727dc7902cdb7f70856a671af2ba08ef190d23a"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;let a1=<Vec<bool> as Wire>::from_json(&args[1])?;Ok(self.function_l_ink_mc05a2256079ef1f1818d13e69727dc7902cdb7f70856a671af2ba08ef190d23a(a0,a1).to_json())},
"ink_m6ec6e8f9e757c220bfe2ed28cbb8dab4ec520de5ee8de5ca702cbdb805a5f910"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;let a1=<f32 as Wire>::from_json(&args[1])?;let a2=<f32 as Wire>::from_json(&args[2])?;Ok(self.function_l_ink_m6ec6e8f9e757c220bfe2ed28cbb8dab4ec520de5ee8de5ca702cbdb805a5f910(a0,a1,a2).to_json())},
"ink_maa2c8802d351b443dda0bc206d70fa9fe87756b57a84d0357e9dfb4c1e7a0667"=>{let a0=<Vec<Vec<f32>> as Wire>::from_json(&args[0])?;let a1=<Vec<bool> as Wire>::from_json(&args[1])?;let a2=<f32 as Wire>::from_json(&args[2])?;let a3=<f32 as Wire>::from_json(&args[3])?;Ok(self.function_l_ink_maa2c8802d351b443dda0bc206d70fa9fe87756b57a84d0357e9dfb4c1e7a0667(a0,a1,a2,a3).to_json())},
"ink_m1774c4db693eebe71b1f79bce053b93633d1e1ec37196dd480b59c0248b4fbc2"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;let a1=<Vec<Vec<f32>> as Wire>::from_json(&args[1])?;let a2=<Vec<bool> as Wire>::from_json(&args[2])?;let a3=<f32 as Wire>::from_json(&args[3])?;let a4=<u32 as Wire>::from_json(&args[4])?;Ok(self.function_l_ink_m1774c4db693eebe71b1f79bce053b93633d1e1ec37196dd480b59c0248b4fbc2(a0,a1,a2,a3,a4).to_json())},
"ink_m1fbf7ee6cef3bcca5d7d258c8606275806894b60d839126202d17f016ea87c80"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;let a1=<Vec<Vec<f32>> as Wire>::from_json(&args[1])?;let a2=<Vec<bool> as Wire>::from_json(&args[2])?;let a3=<f32 as Wire>::from_json(&args[3])?;Ok(self.function_l_ink_m1fbf7ee6cef3bcca5d7d258c8606275806894b60d839126202d17f016ea87c80(a0,a1,a2,a3).to_json())},
"ink_m99468fca85aa8fb996f0c891430c813d82505250d39d8e415bf27679ddc39e07"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;let a1=<Vec<Vec<f32>> as Wire>::from_json(&args[1])?;let a2=<Vec<bool> as Wire>::from_json(&args[2])?;let a3=<u32 as Wire>::from_json(&args[3])?;Ok(self.function_l_ink_m99468fca85aa8fb996f0c891430c813d82505250d39d8e415bf27679ddc39e07(a0,a1,a2,a3).to_json())},
"ink_maadd6c30a027af52d851f0828eec45339d218ad3bbe73e4d8d7cdd3892e754f4"=>{let a0=<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0 as Wire>::from_json(&args[0])?;let a1=<f32 as Wire>::from_json(&args[1])?;let a2=<f32 as Wire>::from_json(&args[2])?;Ok(self.function_l_ink_maadd6c30a027af52d851f0828eec45339d218ad3bbe73e4d8d7cdd3892e754f4(a0,a1,a2).to_json())},
"ink_m696809152e57d8dfa3f01f9a3e12c048434b9f2af91ff53321ea6ceeeeca5431"=>{let a0=<Result<Vec<f32>,String> as Wire>::from_json(&args[0])?;let a1=<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0 as Wire>::from_json(&args[1])?;let a2=<f32 as Wire>::from_json(&args[2])?;let a3=<f32 as Wire>::from_json(&args[3])?;Ok(self.function_l_ink_m696809152e57d8dfa3f01f9a3e12c048434b9f2af91ff53321ea6ceeeeca5431(a0,a1,a2,a3).to_json())},
"ink_m372cbaf2ee2bc8705fad4b5b65a9e744ea468afbe4c153f17c7da282a459d1cd"=>{let a0=<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0> as Wire>::from_json(&args[0])?;let a1=<Vec<f32> as Wire>::from_json(&args[1])?;let a2=<Vec<f32> as Wire>::from_json(&args[2])?;Ok(self.function_l_ink_m372cbaf2ee2bc8705fad4b5b65a9e744ea468afbe4c153f17c7da282a459d1cd(a0,a1,a2).to_json())},
"ink_m43c1e2ac4d6d9a37358654ff5c1abcd42d4b01146c41a7ca617bccb074a8813b"=>{let a0=<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0> as Wire>::from_json(&args[0])?;let a1=<Vec<f32> as Wire>::from_json(&args[1])?;let a2=<Vec<f32> as Wire>::from_json(&args[2])?;Ok(self.function_l_ink_m43c1e2ac4d6d9a37358654ff5c1abcd42d4b01146c41a7ca617bccb074a8813b(a0,a1,a2).to_json())},
"ink_m4b5ada8f7d6b3beaee6fc06bf68e61ca158cbc7664899364dff18d21555697ae"=>{let a0=<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0> as Wire>::from_json(&args[0])?;let a1=<f32 as Wire>::from_json(&args[1])?;let a2=<f32 as Wire>::from_json(&args[2])?;Ok(self.function_l_ink_m4b5ada8f7d6b3beaee6fc06bf68e61ca158cbc7664899364dff18d21555697ae(a0,a1,a2).to_json())},
"ink_mda500f665e6078213ee2391fedf06240c651d1725327b086aa70cda14bef9a07"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;let a1=<f32 as Wire>::from_json(&args[1])?;let a2=<f32 as Wire>::from_json(&args[2])?;Ok(self.function_l_ink_mda500f665e6078213ee2391fedf06240c651d1725327b086aa70cda14bef9a07(a0,a1,a2).to_json())},
"ink_meefc22a28d97f5bdc4100b36eeab9549241c3ef201b83c2f75111644d317833d"=>{let a0=<f32 as Wire>::from_json(&args[0])?;Ok(self.function_l_ink_meefc22a28d97f5bdc4100b36eeab9549241c3ef201b83c2f75111644d317833d(a0).to_json())},
"ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;Ok(self.function_l_ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96(a0).to_json())},
"ink_m786bdc6011aece08dbf36c5ca89c437e06ff758c9d3d242f723dde2af6ea31db"=>{let a0=<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab as Wire>::from_json(&args[0])?;Ok(self.function_l_ink_m786bdc6011aece08dbf36c5ca89c437e06ff758c9d3d242f723dde2af6ea31db(a0).to_json())},
"ink_mdfbd57a9f460147afedb262e2bfe0f6197f9b813c85277c59f5e101900063ad7"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;Ok(self.function_l_ink_mdfbd57a9f460147afedb262e2bfe0f6197f9b813c85277c59f5e101900063ad7(a0).to_json())},
"ink_m5226ad25deae5e47d7fb65b6b5961d46740dd4e97b54d76a24d3d0445845fe35"=>{let a0=<l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249 as Wire>::from_json(&args[0])?;Ok(self.function_l_ink_m5226ad25deae5e47d7fb65b6b5961d46740dd4e97b54d76a24d3d0445845fe35(a0).to_json())},
"ink_m8abb6b2bcbe55251e0b82a28f26d7ce761729346e35019c2b60ca9b5ee22590d"=>{let a0=<f32 as Wire>::from_json(&args[0])?;Ok(self.function_l_ink_m8abb6b2bcbe55251e0b82a28f26d7ce761729346e35019c2b60ca9b5ee22590d(a0).to_json())},
"ink_m7d03a2ed6071238ff1b69a8e56a8cb96b9dc3b095b2d939c0ccfed84ee9580b5"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;let a1=<f32 as Wire>::from_json(&args[1])?;Ok(self.function_l_ink_m7d03a2ed6071238ff1b69a8e56a8cb96b9dc3b095b2d939c0ccfed84ee9580b5(a0,a1).to_json())},
"ink_m00ba8185ca362d257d138fe1886cbc5f3acc38c4a238bef60c3d3d7fa0276eab"=>{let a0=<f32 as Wire>::from_json(&args[0])?;let a1=<f32 as Wire>::from_json(&args[1])?;let a2=<f32 as Wire>::from_json(&args[2])?;let a3=<f32 as Wire>::from_json(&args[3])?;let a4=<f32 as Wire>::from_json(&args[4])?;let a5=<l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249 as Wire>::from_json(&args[5])?;Ok(self.function_l_ink_m00ba8185ca362d257d138fe1886cbc5f3acc38c4a238bef60c3d3d7fa0276eab(a0,a1,a2,a3,a4,a5).to_json())},
"ink_m2a55f95a80595bc61d1fcab41ff00f438ff6f2057b597df20aaae3c18507d2be"=>{let a0=<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab as Wire>::from_json(&args[0])?;let a1=<Vec<f32> as Wire>::from_json(&args[1])?;let a2=<l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249 as Wire>::from_json(&args[2])?;Ok(self.function_l_ink_m2a55f95a80595bc61d1fcab41ff00f438ff6f2057b597df20aaae3c18507d2be(a0,a1,a2).to_json())},
"__ink_differential_3"=>{let a0=<l___ink_differential_4 as Wire>::from_json(&args[0])?;let a1=<l___ink_differential_6 as Wire>::from_json(&args[1])?;Ok(self.function_l___ink_differential_3(a0,a1).to_json())},
"__ink_differential_1"=>{let a0=<l_Parameters as Wire>::from_json(&args[0])?;let a1=<l_Pick as Wire>::from_json(&args[1])?;Ok(self.function_l___ink_differential_1(a0,a1).to_json())},
_=>Err("unknown function".into())}}
pub fn invoke_json(&mut self,name:&str,args:&Json)->Result<Json,String>{let args=args.as_array().unwrap();match name{
"initialize"=>{Ok(self.invoke_view_l_initialize()?.to_json())},
"retarget"=>{let a0=<Vec<l_Example> as Wire>::from_json(&args[0])?;let a1=<f32 as Wire>::from_json(&args[1])?;let a2=<u32 as Wire>::from_json(&args[2])?;Ok(self.invoke_view_l_retarget(a0,a1,a2)?.to_json())},
"retune"=>{let a0=<l_Coefficients as Wire>::from_json(&args[0])?;let a1=<bool as Wire>::from_json(&args[1])?;Ok(self.invoke_view_l_retune(a0,a1)?.to_json())},
"episode"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;let a1=<f32 as Wire>::from_json(&args[1])?;let a2=<u32 as Wire>::from_json(&args[2])?;Ok(self.invoke_view_l_episode(a0,a1,a2)?.to_json())},
"aborted"=>{let a0=<Vec<f32> as Wire>::from_json(&args[0])?;let a1=<f32 as Wire>::from_json(&args[1])?;let a2=<u32 as Wire>::from_json(&args[2])?;Ok(self.invoke_view_l_aborted(a0,a1,a2)?.to_json())},
"serve"=>{let a0=<f32 as Wire>::from_json(&args[0])?;Ok(self.invoke_view_l_serve(a0)?.to_json())},
"structure"=>{Ok(self.invoke_view_l_structure()?.to_json())},
"policy"=>{Ok(self.invoke_view_l_policy()?.to_json())},
"loss"=>{Ok(self.invoke_view_l_loss()?.to_json())},
"set_live"=>{let a0=<f32 as Wire>::from_json(&args[0])?;Ok(self.invoke_view_l_set_live(a0)?.to_json())},
_=>Err("unknown action".into())}}}

mod value_wire {
//! Bounded, schema-bound portable values. Networking is deliberately external.
//! The descriptor and codecs are operationally trusted, not proof certificates.
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet};
pub const FORMAT: &str = "ink-value-wire-v1";
pub const MAGIC: &[u8; 8] = b"INKVAL\0\x01";
// Keep these helpers self-contained: this file is also embedded verbatim in
// generated native applications without a dependency on the compiler or ABI.
pub(crate) fn f64_bits(value:&Value)->Result<u64,String>{
    if let Some(n)=value.as_f64(){
        return if n.is_finite(){Ok(n.to_bits())}else{Err("non-finite f64 needs F64Bits".into())};
    }
    let o=value.as_object().ok_or("expected finite f64 or F64Bits")?;
    if o.len()!=1{return Err("invalid F64Bits fields".into());}
    let text=o.get("F64Bits").and_then(Value::as_str).ok_or("F64Bits needs an unsigned decimal string")?;
    if text.is_empty()||text.len()>20||text.len()>1&&text.starts_with('0')||!text.bytes().all(|c|c.is_ascii_digit()){
        return Err("invalid F64Bits decimal string".into());
    }
    text.parse().map_err(|_|"F64Bits outside u64 range".into())
}
pub(crate) fn f64_raw(bits:u64)->Value{json!({"F64Bits":bits.to_string()})}
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub bytes: usize,
    pub nodes: usize,
    pub depth: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            bytes: 16 * 1024 * 1024,
            nodes: 1_000_000,
            depth: 128,
        }
    }
}
impl Limits {
    pub fn checked(self) -> Result<Self, String> {
        let max = Self::default();
        if self.bytes > max.bytes || self.nodes > max.nodes || self.depth > max.depth {
            return Err("wire hard resource limit".into());
        }
        Ok(self)
    }
}
#[derive(Clone, Debug)]
pub struct Schema {
    root: Value,
    named: BTreeMap<String, Value>,
    identity: [u8; 32],
}
impl Schema {
    pub fn new(root: Value, named: BTreeMap<String, Value>) -> Result<Self, String> {
        fn check(
            t: &Value,
            named: &BTreeMap<String, Value>,
            used: &mut BTreeSet<String>,
            depth: usize,
            budget: &mut usize,
        ) -> Result<(), String> {
            if depth > 64 || *budget == 0 {
                return Err("wire descriptor limit".into());
            }
            *budget -= 1;
            let obj = t.as_object().ok_or("invalid wire descriptor")?;
            let kind = t["kind"].as_str().ok_or("missing wire kind")?;
            let keys: &[&str] = match kind {
                "u32" | "u64" | "i32" | "f32" | "f64" | "bool" | "unit" | "string" | "int" => &["kind"],
                "id" | "ref" => &["kind", "name"],
                "enum" => &["kind", "name", "variants"],
                "record" => &["kind", "name", "fields"],
                "list" | "option" => &["kind", "element"],
                "vector" => &["kind", "element", "size"],
                "result" => &["kind", "ok", "error"],
                _ => return Err("unsupported wire descriptor".into()),
            };
            if obj.len() != keys.len() || keys.iter().any(|k| !obj.contains_key(*k)) {
                return Err("invalid wire descriptor fields".into());
            }
            match kind {
                "id" | "ref" | "enum" | "record" => {
                    t["name"].as_str().ok_or("missing descriptor name")?;
                }
                _ => {}
            }
            match kind {
                "ref" => {
                    let n = t["name"].as_str().unwrap();
                    if used.insert(n.into()) {
                        let d = named.get(n).ok_or("unresolved wire reference")?;
                        if d["kind"] != "record" || d["name"] != n {
                            return Err("invalid named wire reference".into());
                        }
                        check(d, named, used, depth + 1, budget)?;
                    }
                }
                "record" => {
                    let mut seen = BTreeSet::new();
                    for f in t["fields"].as_array().ok_or("missing descriptor fields")? {
                        if f.as_object().is_none_or(|o| o.len() != 2)
                            || !seen.insert(f["name"].as_str().ok_or("invalid field name")?)
                        {
                            return Err("invalid or duplicate wire field".into());
                        }
                        check(&f["type"], named, used, depth + 1, budget)?;
                    }
                }
                "enum" => {
                    let variants = t["variants"].as_array().ok_or("missing variants")?;
                    let mut seen = BTreeSet::new();
                    if variants.is_empty() || variants.len() > 64 {
                        return Err("wire enum limit".into());
                    }
                    for v in variants {
                        if !seen.insert(v.as_str().ok_or("invalid variant")?) {
                            return Err("duplicate variant".into());
                        }
                    }
                }
                "vector" => {
                    if t["size"].as_u64().is_none_or(|n| n == 0 || n > 64) {
                        return Err("invalid vector size".into());
                    }
                    check(&t["element"], named, used, depth + 1, budget)?;
                }
                "list" | "option" => check(&t["element"], named, used, depth + 1, budget)?,
                "result" => {
                    check(&t["ok"], named, used, depth + 1, budget)?;
                    check(&t["error"], named, used, depth + 1, budget)?;
                }
                _ => {}
            }
            Ok(())
        }
        let mut used = BTreeSet::new();
        check(&root, &named, &mut used, 0, &mut 100_000)?;
        let named = named
            .into_iter()
            .filter(|(k, _)| used.contains(k))
            .collect::<BTreeMap<_, _>>();
        let identity = Sha256::digest(
            serde_json::to_vec(&json!({"format":FORMAT,"root":root,"named":named}))
                .map_err(|e| e.to_string())?,
        )
        .into();
        Ok(Self {
            root,
            named,
            identity,
        })
    }
    pub fn root(&self) -> &Value {
        &self.root
    }
    pub fn named(&self) -> &BTreeMap<String, Value> {
        &self.named
    }
    pub fn identity(&self) -> String {
        self.identity.iter().map(|b| format!("{b:02x}")).collect()
    }
    pub fn descriptor(&self) -> Value {
        json!({"format":FORMAT,"root":self.root,"named":self.named,"identity":self.identity()})
    }
    pub fn from_descriptor(v: &Value) -> Result<Self, String> {
        if v["format"] != FORMAT || v.as_object().is_none_or(|o| o.len() != 4) {
            return Err("invalid wire schema envelope".into());
        }
        let s = Self::new(
            v["root"].clone(),
            serde_json::from_value(v["named"].clone()).map_err(|e| e.to_string())?,
        )?;
        if v["identity"] != s.identity() {
            return Err("wire schema identity mismatch".into());
        }
        Ok(s)
    }
    pub(crate) fn resolve<'a>(&'a self, mut t: &'a Value) -> Result<&'a Value, String> {
        for _ in 0..64 {
            if t["kind"] != "ref" {
                return Ok(t);
            }
            t = self
                .named
                .get(t["name"].as_str().ok_or("wire reference name")?)
                .ok_or("wire reference")?;
        }
        Err("wire reference cycle".into())
    }
    pub fn encode(&self, value: &Value, limits: Limits) -> Result<Vec<u8>, String> {
        let limits = limits.checked()?;
        if limits.bytes < 44 {
            return Err("wire byte limit".into());
        }
        let mut out = Vec::new();
        out.extend(MAGIC);
        out.extend(self.identity);
        encode(
            self,
            &self.root,
            value,
            &mut out,
            &mut limits.nodes.clone(),
            0,
            limits,
        )?;
        // Encoding validation is also a check on public numeric/string carriers.
        self.validate(&out, limits)?;
        Ok(out)
    }
    pub fn validate<'a>(
        &'a self,
        bytes: &'a [u8],
        limits: Limits,
    ) -> Result<Validated<'a>, String> {
        let limits = limits.checked()?;
        if bytes.len() > limits.bytes || bytes.len() < 44 {
            return Err("wire byte limit or truncated header".into());
        }
        if &bytes[..8] != MAGIC || bytes[8..40] != self.identity {
            return Err("wire format or schema mismatch".into());
        }
        let mut pos = 40;
        walk(
            self,
            &self.root,
            bytes,
            &mut pos,
            &mut limits.nodes.clone(),
            0,
            limits,
            false,
        )?;
        if pos != bytes.len() {
            return Err("trailing wire bytes".into());
        }
        Ok(Validated {
            schema: self,
            ty: &self.root,
            bytes: &bytes[40..],
            limits,
        })
    }
    pub fn decode(&self, bytes: &[u8], limits: Limits) -> Result<Value, String> {
        self.validate(bytes, limits)?.materialize()
    }
    /// Emit frames directly from a native value or a streaming input adapter.
    /// Final validation binds the emitted shape to this exact schema.
    pub fn encode_with(
        &self,
        limits: Limits,
        emit: impl FnOnce(&mut Encoder) -> Result<(), String>,
    ) -> Result<Vec<u8>, String> {
        let mut writer = Encoder::new(limits)?;
        writer.bytes(MAGIC)?;
        writer.bytes(&self.identity)?;
        emit(&mut writer)?;
        self.validate(&writer.out, limits)?;
        Ok(writer.out)
    }
}

/// Bounded forward frame writer, shared by native and streaming codecs.
/// It carries resource accounting; only Schema::encode_with authenticates types.
pub struct Encoder {
    out: Vec<u8>,
    limits: Limits,
    remaining: usize,
    depth: usize,
}
impl Encoder {
    fn new(limits: Limits) -> Result<Self, String> {
        let limits = limits.checked()?;
        Ok(Self {
            out: Vec::new(),
            remaining: limits.nodes,
            depth: 0,
            limits,
        })
    }
    pub fn position(&self) -> usize {
        self.out.len()
    }
    pub fn bytes(&mut self, bytes: &[u8]) -> Result<(), String> {
        if bytes.len() > self.limits.bytes.saturating_sub(self.out.len()) {
            return Err("wire byte limit".into());
        }
        self.out.extend_from_slice(bytes);
        Ok(())
    }
    pub fn word(&mut self, value: u32) -> Result<(), String> {
        self.bytes(&value.to_le_bytes())
    }
    pub fn patch_word(&mut self, at: usize, value: u32) -> Result<(), String> {
        let end = at.checked_add(4).ok_or("wire offset overflow")?;
        self.out
            .get_mut(at..end)
            .ok_or("wire patch offset")?
            .copy_from_slice(&value.to_le_bytes());
        Ok(())
    }
    pub fn frame(
        &mut self,
        emit: impl FnOnce(&mut Self) -> Result<(), String>,
    ) -> Result<(), String> {
        count(&mut self.remaining, self.depth, self.limits)?;
        let at = self.position();
        self.word(0)?;
        self.depth += 1;
        let result = emit(self);
        self.depth -= 1;
        result?;
        let length = u32::try_from(self.position() - at - 4).map_err(|_| "wire frame overflow")?;
        self.patch_word(at, length)
    }
    /// Reorder a contiguous suffix using a checked permutation of its spans.
    /// Already ordered fields incur no copy. This supports unordered text records.
    pub fn reorder(&mut self, start: usize, spans: &[(usize, usize)]) -> Result<(), String> {
        let mut sorted = spans.to_vec();
        sorted.sort_unstable();
        let mut at = start;
        for &(a, b) in &sorted {
            if a != at || b < a {
                return Err("wire span permutation".into());
            }
            at = b;
        }
        if start > self.out.len() || at != self.out.len() {
            return Err("wire span permutation".into());
        }
        if sorted == spans {
            return Ok(());
        }
        let mut ordered = Vec::with_capacity(self.out.len() - start);
        for &(a, b) in spans {
            ordered.extend_from_slice(self.out.get(a..b).ok_or("wire span offset")?);
        }
        self.out[start..].copy_from_slice(&ordered);
        Ok(())
    }
}
fn count(budget: &mut usize, depth: usize, limits: Limits) -> Result<(), String> {
    if *budget == 0 || depth > limits.depth {
        return Err("wire node or depth limit".into());
    }
    *budget -= 1;
    Ok(())
}
fn decimal(s: &str) -> bool {
    let b = s.strip_prefix('-').unwrap_or(s);
    !b.is_empty()
        && b.bytes().all(|b| b.is_ascii_digit())
        && (b == "0" || !b.starts_with('0'))
        && s != "-0"
}
fn tag<'a>(v: &'a Value, n: &str) -> Result<&'a Value, String> {
    if v.as_object().is_some_and(|o| o.len() == 1) {
        v.get(n).ok_or("invalid wire value tag".into())
    } else {
        Err("invalid wire value tag".into())
    }
}
fn encode(
    s: &Schema,
    t: &Value,
    v: &Value,
    out: &mut Vec<u8>,
    budget: &mut usize,
    d: usize,
    limits: Limits,
) -> Result<(), String> {
    count(budget, d, limits)?;
    let t = s.resolve(t)?;
    let at = out.len();
    out.extend([0; 4]);
    let error = || "invalid value for wire schema".to_string();
    match t["kind"].as_str().ok_or_else(error)? {
        "unit" => {
            if !v.is_null() {
                return Err(error());
            }
        }
        "bool" => out.push(u8::from(v.as_bool().ok_or_else(error)?)),
        "u32" => out.extend(
            u32::try_from(v.as_u64().ok_or_else(error)?)
                .map_err(|_| error())?
                .to_le_bytes(),
        ),
        "i32" => out.extend(
            i32::try_from(v.as_i64().ok_or_else(error)?)
                .map_err(|_| error())?
                .to_le_bytes(),
        ),
        "u64" => {
            let n = if let Some(n) = v.as_u64() {
                n
            } else {
                let text = v.as_str().ok_or_else(error)?;
                if !decimal(text) || text.starts_with('-') {
                    return Err(error());
                }
                text.parse::<u64>().map_err(|_| error())?
            };
            out.extend(n.to_le_bytes());
        }
        "f64" => out.extend(f64_bits(v)?.to_le_bytes()),
        "f32" => {
            let bits = if let Some(n) = v.as_f64() {
                let f = n as f32;
                if !f.is_finite() {
                    return Err(error());
                }
                f.to_bits()
            } else {
                u32::try_from(tag(v, "F32Bits")?.as_u64().ok_or_else(error)?)
                    .map_err(|_| error())?
            };
            out.extend(bits.to_le_bytes());
        }
        "string" | "int" | "id" | "enum" => {
            let text = if t["kind"] == "int" {
                tag(v, "Int")?.as_str().ok_or_else(error)?
            } else {
                v.as_str().ok_or_else(error)?
            };
            if text.len() > limits.bytes.saturating_sub(out.len()) {
                return Err("wire byte limit".into());
            }
            if t["kind"] == "int" && !decimal(text) {
                return Err(error());
            }
            if t["kind"] == "enum" && !t["variants"].as_array().unwrap().contains(v) {
                return Err(error());
            }
            if t["kind"] == "id"
                && (text.len() != 32
                    || !text
                        .bytes()
                        .all(|b| b.is_ascii_hexdigit() && !b.is_ascii_uppercase()))
            {
                return Err(error());
            }
            out.extend(text.as_bytes());
        }
        "list" | "vector" => {
            let xs = v.as_array().ok_or_else(error)?;
            if xs.len() > *budget
                || t["kind"] == "vector" && Some(xs.len() as u64) != t["size"].as_u64()
            {
                return Err(error());
            }
            out.extend(u32::try_from(xs.len()).map_err(|_| error())?.to_le_bytes());
            for x in xs {
                encode(s, &t["element"], x, out, budget, d + 1, limits)?;
            }
        }
        "record" => {
            let o = v.as_object().ok_or_else(error)?;
            let fs = t["fields"].as_array().unwrap();
            if o.len() != fs.len() {
                return Err(error());
            }
            for f in fs {
                encode(
                    s,
                    &f["type"],
                    o.get(f["name"].as_str().unwrap()).ok_or_else(error)?,
                    out,
                    budget,
                    d + 1,
                    limits,
                )?;
            }
        }
        "option" => {
            if let Ok(x) = tag(v, "Some") {
                out.push(1);
                encode(s, &t["element"], x, out, budget, d + 1, limits)?;
            } else {
                if !tag(v, "None")?.is_null() {
                    return Err(error());
                }
                out.push(0);
            }
        }
        "result" => {
            if let Ok(x) = tag(v, "Ok") {
                out.push(0);
                encode(s, &t["ok"], x, out, budget, d + 1, limits)?;
            } else {
                out.push(1);
                encode(s, &t["error"], tag(v, "Err")?, out, budget, d + 1, limits)?;
            }
        }
        _ => return Err(error()),
    }
    if out.len() > limits.bytes {
        return Err("wire byte limit".into());
    }
    let len = u32::try_from(out.len() - at - 4).map_err(|_| "wire frame overflow")?;
    out[at..at + 4].copy_from_slice(&len.to_le_bytes());
    Ok(())
}
fn u32_at(bytes: &[u8], pos: usize) -> Result<u32, String> {
    Ok(u32::from_le_bytes(
        bytes
            .get(pos..pos.checked_add(4).ok_or("wire offset overflow")?)
            .ok_or("truncated wire length")?
            .try_into()
            .unwrap(),
    ))
}
fn frame(bytes: &[u8], pos: usize) -> Result<(usize, usize), String> {
    let start = pos.checked_add(4).ok_or("wire offset overflow")?;
    let end = start
        .checked_add(u32_at(bytes, pos)? as usize)
        .ok_or("wire length overflow")?;
    if end > bytes.len() {
        return Err("truncated wire frame".into());
    }
    Ok((start, end))
}
fn walk(
    s: &Schema,
    t: &Value,
    bytes: &[u8],
    pos: &mut usize,
    budget: &mut usize,
    d: usize,
    limits: Limits,
    materialize: bool,
) -> Result<Option<Value>, String> {
    count(budget, d, limits)?;
    let t = s.resolve(t)?;
    let (start, end) = frame(bytes, *pos)?;
    *pos = end;
    let body = &bytes[start..end];
    let mut p = 0;
    let error = || "malformed wire value".to_string();
    let value = match t["kind"].as_str().ok_or_else(error)? {
        "unit" => {
            if !body.is_empty() {
                return Err(error());
            }
            Value::Null
        }
        "bool" => {
            if body.len() != 1 || body[0] > 1 {
                return Err(error());
            }
            Value::Bool(body[0] == 1)
        }
        "u32" | "i32" | "f32" => {
            if body.len() != 4 {
                return Err(error());
            }
            let bits = u32_at(body, 0)?;
            match t["kind"].as_str().unwrap() {
                "u32" => json!(bits),
                "i32" => json!(bits as i32),
                _ => {
                    if materialize {
                        json!({"F32Bits":bits})
                    } else {
                        Value::Null
                    }
                }
            }
        }
        "f64" => {
            if body.len()!=8{return Err(error());}
            if materialize{f64_raw(u64::from_le_bytes(body.try_into().unwrap()))}else{Value::Null}
        }
        "u64" => {
            if body.len() != 8 {
                return Err(error());
            }
            json!(u64::from_le_bytes(body.try_into().unwrap()))
        }
        "string" | "int" | "id" | "enum" => {
            let text = std::str::from_utf8(body).map_err(|_| error())?;
            if t["kind"] == "int" && !decimal(text)
                || t["kind"] == "enum"
                    && !t["variants"]
                        .as_array()
                        .unwrap()
                        .iter()
                        .any(|v| v.as_str() == Some(text))
                || t["kind"] == "id"
                    && (text.len() != 32
                        || !text
                            .bytes()
                            .all(|b| b.is_ascii_hexdigit() && !b.is_ascii_uppercase()))
            {
                return Err(error());
            }
            if materialize {
                if t["kind"] == "int" {
                    json!({"Int":text})
                } else {
                    json!(text)
                }
            } else {
                Value::Null
            }
        }
        "list" | "vector" => {
            let n = u32_at(body, 0)? as usize;
            p = 4;
            if n > *budget
                || n > body.len().saturating_sub(4) / 4
                || t["kind"] == "vector" && Some(n as u64) != t["size"].as_u64()
            {
                return Err(error());
            }
            let mut xs = vec![];
            for _ in 0..n {
                if let Some(x) = walk(
                    s,
                    &t["element"],
                    body,
                    &mut p,
                    budget,
                    d + 1,
                    limits,
                    materialize,
                )? {
                    xs.push(x);
                }
            }
            if p != body.len() {
                return Err(error());
            }
            Value::Array(xs)
        }
        "record" => {
            let mut fields = serde_json::Map::new();
            for f in t["fields"].as_array().unwrap() {
                if let Some(x) = walk(
                    s,
                    &f["type"],
                    body,
                    &mut p,
                    budget,
                    d + 1,
                    limits,
                    materialize,
                )? {
                    fields.insert(f["name"].as_str().unwrap().into(), x);
                }
            }
            if p != body.len() {
                return Err(error());
            }
            Value::Object(fields)
        }
        "option" | "result" => {
            let b = *body.first().ok_or_else(error)?;
            if b > 1 {
                return Err(error());
            }
            p = 1;
            if t["kind"] == "option" && b == 0 {
                if body.len() != 1 {
                    return Err(error());
                }
                if materialize {
                    json!({"None":null})
                } else {
                    Value::Null
                }
            } else {
                let (tag, child) = if t["kind"] == "option" {
                    ("Some", &t["element"])
                } else if b == 0 {
                    ("Ok", &t["ok"])
                } else {
                    ("Err", &t["error"])
                };
                let x = walk(s, child, body, &mut p, budget, d + 1, limits, materialize)?;
                if p != body.len() {
                    return Err(error());
                }
                if let Some(x) = x {
                    json!({tag:x})
                } else {
                    Value::Null
                }
            }
        }
        _ => return Err(error()),
    };
    Ok(materialize.then_some(value))
}
/// Borrowed access to already structurally validated bytes. Rust borrowing
/// prevents mutation while this validation witness exists. No JSON tree is built.
#[derive(Clone, Copy)]
pub struct Validated<'a> {
    schema: &'a Schema,
    ty: &'a Value,
    bytes: &'a [u8],
    limits: Limits,
}
impl<'a> Validated<'a> {
    pub fn descriptor(&self) -> Result<&'a Value, String> {
        self.schema.resolve(self.ty)
    }
    pub fn limits(&self) -> Limits {
        self.limits
    }
    pub fn kind(&self) -> Result<&'a str, String> {
        self.schema.resolve(self.ty)?["kind"]
            .as_str()
            .ok_or("wire kind".into())
    }
    pub fn require_kind(&self, kind: &str) -> Result<(), String> {
        if self.kind()? == kind {
            Ok(())
        } else {
            Err("wire native type mismatch".into())
        }
    }
    pub fn require_name(&self, name: &str) -> Result<(), String> {
        if self.schema.resolve(self.ty)?["name"] == name {
            Ok(())
        } else {
            Err("wire nominal type mismatch".into())
        }
    }
    /// Scalar bytes or a container body; safe to borrow for the witness lifetime.
    pub fn body(&self) -> Result<&'a [u8], String> {
        let (a, b) = frame(self.bytes, 0)?;
        Ok(&self.bytes[a..b])
    }
    pub fn fields(&self) -> Result<Fields<'a>, String> {
        self.require_kind("record")?;
        let t = self.schema.resolve(self.ty)?;
        Ok(Fields {
            parent: *self,
            fields: t["fields"].as_array().unwrap().iter(),
            body: self.body()?,
            position: 0,
        })
    }
    pub fn payload(&self) -> &'a [u8] {
        self.bytes
    }
    pub fn materialize(&self) -> Result<Value, String> {
        let mut p = 0;
        walk(
            self.schema,
            self.ty,
            self.bytes,
            &mut p,
            &mut self.limits.nodes.clone(),
            0,
            self.limits,
            true,
        )?
        .ok_or("wire decode".into())
    }
    pub fn field(&self, name: &str) -> Result<Option<Self>, String> {
        let t = self.schema.resolve(self.ty)?;
        if t["kind"] != "record" {
            return Err("wire view is not a record".into());
        }
        let (start, end) = frame(self.bytes, 0)?;
        let body = &self.bytes[start..end];
        let mut p = 0;
        for f in t["fields"].as_array().unwrap() {
            let (_, next) = frame(body, p)?;
            if f["name"] == name {
                return Ok(Some(Self {
                    schema: self.schema,
                    ty: &f["type"],
                    bytes: &body[p..next],
                    limits: self.limits,
                }));
            }
            p = next;
        }
        Ok(None)
    }
    pub fn at(&self, index: usize) -> Result<Option<Self>, String> {
        let t = self.schema.resolve(self.ty)?;
        if t["kind"] != "list" && t["kind"] != "vector" {
            return Err("wire view is not a sequence".into());
        }
        let (start, end) = frame(self.bytes, 0)?;
        let body = &self.bytes[start..end];
        let n = u32_at(body, 0)? as usize;
        if index >= n {
            return Ok(None);
        }
        let mut p = 4;
        for i in 0..n {
            let (_, next) = frame(body, p)?;
            if i == index {
                return Ok(Some(Self {
                    schema: self.schema,
                    ty: &t["element"],
                    bytes: &body[p..next],
                    limits: self.limits,
                }));
            }
            p = next;
        }
        Ok(None)
    }
}

impl<'a> Validated<'a> {
    pub fn text(&self) -> Result<&'a str, String> {
        let t = self.schema.resolve(self.ty)?;
        if !["string", "int", "id", "enum"].contains(&t["kind"].as_str().unwrap_or("")) {
            return Err("wire view is not text".into());
        }
        let (a, b) = frame(self.bytes, 0)?;
        std::str::from_utf8(&self.bytes[a..b]).map_err(|e| e.to_string())
    }
    pub fn len(&self) -> Result<usize, String> {
        let t = self.schema.resolve(self.ty)?;
        if t["kind"] != "list" && t["kind"] != "vector" {
            return Err("wire view is not a sequence".into());
        }
        let (a, _) = frame(self.bytes, 0)?;
        Ok(u32_at(self.bytes, a)? as usize)
    }
    pub fn is_empty(&self) -> Result<bool, String> {
        Ok(self.len()? == 0)
    }
    pub fn variant(&self) -> Result<(bool, Option<Self>), String> {
        let t = self.schema.resolve(self.ty)?;
        if t["kind"] != "option" && t["kind"] != "result" {
            return Err("wire view is not a sum".into());
        }
        let (a, b) = frame(self.bytes, 0)?;
        let tag = self.bytes[a] == 1;
        if t["kind"] == "option" && !tag {
            return Ok((false, None));
        }
        let ty = if t["kind"] == "option" {
            &t["element"]
        } else if tag {
            &t["error"]
        } else {
            &t["ok"]
        };
        Ok((
            tag,
            Some(Self {
                schema: self.schema,
                ty,
                bytes: &self.bytes[a + 1..b],
                limits: self.limits,
            }),
        ))
    }
}

/// A single forward traversal over a validated sequence, without repeated scans.
pub struct Items<'a> {
    schema: &'a Schema,
    ty: &'a Value,
    body: &'a [u8],
    position: usize,
    left: usize,
    limits: Limits,
}
impl<'a> Iterator for Items<'a> {
    type Item = Result<Validated<'a>, String>;
    fn next(&mut self) -> Option<Self::Item> {
        if self.left == 0 {
            return None;
        }
        self.left -= 1;
        let at = self.position;
        Some(frame(self.body, at).map(|(_, end)| {
            self.position = end;
            Validated {
                schema: self.schema,
                ty: self.ty,
                bytes: &self.body[at..end],
                limits: self.limits,
            }
        }))
    }
}
impl<'a> Validated<'a> {
    pub fn items(&self) -> Result<Items<'a>, String> {
        let t = self.schema.resolve(self.ty)?;
        if t["kind"] != "list" && t["kind"] != "vector" {
            return Err("wire view is not a sequence".into());
        }
        let (a, b) = frame(self.bytes, 0)?;
        let body = &self.bytes[a..b];
        Ok(Items {
            schema: self.schema,
            ty: &t["element"],
            body,
            position: 4,
            left: u32_at(body, 0)? as usize,
            limits: self.limits,
        })
    }
}

/// Declaration-order record traversal without repeated name scans.
pub struct Fields<'a> {
    parent: Validated<'a>,
    fields: std::slice::Iter<'a, Value>,
    body: &'a [u8],
    position: usize,
}
impl<'a> Iterator for Fields<'a> {
    type Item = Result<Validated<'a>, String>;
    fn next(&mut self) -> Option<Self::Item> {
        let f = self.fields.next()?;
        let at = self.position;
        Some(frame(self.body, at).map(|(_, end)| {
            self.position = end;
            Validated {
                schema: self.parent.schema,
                ty: &f["type"],
                bytes: &self.body[at..end],
                limits: self.parent.limits,
            }
        }))
    }
}

/// Optional O(1) sequence access. Construction is a single scan; offsets are u32
/// because the authenticated wire is bounded to 16 MiB. The witness borrows it.
pub struct SequenceIndex<'a> {
    parent: Validated<'a>,
    offsets: Vec<u32>,
}
impl<'a> SequenceIndex<'a> {
    pub fn len(&self) -> usize {
        self.offsets.len()
    }
    pub fn is_empty(&self) -> bool {
        self.offsets.is_empty()
    }
    pub fn retained_bytes(&self) -> usize {
        self.offsets.capacity() * std::mem::size_of::<u32>()
    }
    pub fn at(&self, index: usize) -> Result<Option<Validated<'a>>, String> {
        let Some(&at) = self.offsets.get(index) else {
            return Ok(None);
        };
        let t = self.parent.schema.resolve(self.parent.ty)?;
        let body = self.parent.body()?;
        let (_, end) = frame(body, at as usize)?;
        Ok(Some(Validated {
            schema: self.parent.schema,
            ty: &t["element"],
            bytes: &body[at as usize..end],
            limits: self.parent.limits,
        }))
    }
}
impl<'a> Validated<'a> {
    pub fn index(&self) -> Result<SequenceIndex<'a>, String> {
        let items = self.items()?;
        let mut offsets = Vec::with_capacity(items.left);
        let mut at = 4usize;
        for item in items {
            let item = item?;
            offsets.push(u32::try_from(at).map_err(|_| "wire index offset")?);
            at += item.bytes.len();
        }
        Ok(SequenceIndex {
            parent: *self,
            offsets,
        })
    }
}

}
pub use value_wire::Limits as ValueWireLimits;
// Generic pure-call binary boundary. Types and schema identities are emitted
// from the complete checked source. This adapter does no networking.
impl State {
 fn binary_schema_map()->&'static std::collections::BTreeMap<String,(value_wire::Schema,value_wire::Schema)>{
  static SCHEMAS:std::sync::OnceLock<std::collections::BTreeMap<String,(value_wire::Schema,value_wire::Schema)>>=std::sync::OnceLock::new();
  SCHEMAS.get_or_init(||{
   let manifest:Json=serde_json::from_str(INK_WIRE_CONTRACT).expect("compiled wire metadata");
   manifest["functions"].as_object().expect("compiled functions").iter().filter(|(_,v)|v.get("unsupported").is_none()).map(|(name,v)|{
    (name.clone(),(value_wire::Schema::from_descriptor(&v["arguments"]).expect("compiled argument schema"),value_wire::Schema::from_descriptor(&v["result"]).expect("compiled result schema")))
   }).collect()
  })
 }
 pub fn binary_schemas(name:&str)->Result<&'static (value_wire::Schema,value_wire::Schema),String>{Self::binary_schema_map().get(name).ok_or("unsupported binary function".into())}
 pub fn binary_function(index:u32)->Result<&'static str,String>{Self::binary_schema_map().keys().nth(index as usize).map(String::as_str).ok_or("unknown binary function index".into())}

 pub fn validate_binary_arguments<'a>(name:&str,bytes:&'a[u8],limits:ValueWireLimits)->Result<value_wire::Validated<'a>,String>{Self::binary_schemas(name)?.0.validate(bytes,limits)}
 pub fn call_binary(&mut self,name:&str,bytes:&[u8],limits:ValueWireLimits)->Result<Vec<u8>,String>{
  let (input,output)=Self::binary_schemas(name)?;
  let record=input.validate(bytes,limits)?;
  self.binary_call_frame(name,record,output,limits)
 }
}
// Generic direct native values: no serde_json document/carrier on this path.
pub trait BinaryValue: Sized {
 fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>;
 fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>;
}
macro_rules! binary_word {
 ($t:ty,$kind:literal) => {impl BinaryValue for $t{
  fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind($kind)?;Ok(Self::from_le_bytes(v.body()?.try_into().map_err(|_|"wire scalar width")?))}
  fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|w.bytes(&self.to_le_bytes()))}
 }};
}
binary_word!(u32,"u32");binary_word!(u64,"u64");binary_word!(i32,"i32");binary_word!(f32,"f32");binary_word!(f64,"f64");
impl BinaryValue for (){
 fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("unit")?;Ok(())}
 fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|_|Ok(()))}
}
impl BinaryValue for bool{
 fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("bool")?;Ok(v.body()?[0]!=0)}
 fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|w.bytes(&[u8::from(*self)]))}
}
impl BinaryValue for String{
 fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("string")?;Ok(v.text()?.to_owned())}
 fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|w.bytes(self.as_bytes()))}
}
impl BinaryValue for BigInt{
 fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("int")?;v.text()?.parse().map_err(|_|"invalid binary Int".into())}
 fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|w.bytes(self.to_string().as_bytes()))}
}
impl<T:BinaryValue> BinaryValue for Vec<T>{
 fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("list")?;v.items()?.map(|x|T::from_binary(x?)).collect()}
 fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{w.word(self.len().try_into().map_err(|_|"wire sequence size")?)?;for x in self{x.write_binary(w)?;}Ok(())})}
}
impl<T:BinaryValue,const N:usize> BinaryValue for [T;N]{
 fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("vector")?;v.items()?.map(|x|T::from_binary(x?)).collect::<Result<Vec<_>,_>>()?.try_into().map_err(|_|"wire vector size".into())}
 fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{w.word(N.try_into().map_err(|_|"wire vector size")?)?;for x in self{x.write_binary(w)?;}Ok(())})}
}
impl<T:BinaryValue> BinaryValue for Box<T>{
 fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{T::from_binary(v).map(Box::new)}
 fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{(**self).write_binary(w)}
}
impl<T:BinaryValue> BinaryValue for Option<T>{
 fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("option")?;let (_,child)=v.variant()?;child.map(T::from_binary).transpose()}
 fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|match self{None=>w.bytes(&[0]),Some(x)=>{w.bytes(&[1])?;x.write_binary(w)}})}
}
impl<T:BinaryValue,E:BinaryValue> BinaryValue for Result<T,E>{
 fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("result")?;let (err,child)=v.variant()?;let child=child.ok_or("wire Result payload")?;if err{E::from_binary(child).map(Err)}else{T::from_binary(child).map(Ok)}}
 fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|match self{Ok(x)=>{w.bytes(&[0])?;x.write_binary(w)},Err(x)=>{w.bytes(&[1])?;x.write_binary(w)}})}
}
impl BinaryValue for InkArithmeticError{
 fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("enum")?;v.require_name("ArithmeticError")?;if v.text()?=="ArithmeticError.Overflow"{Ok(Self::Overflow)}else{Err("wire arithmetic error".into())}}
 fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|w.bytes(b"ArithmeticError.Overflow"))}
}
impl BinaryValue for l_Building{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("Building")?;let mut fields=v.fields()?;Ok(Self{
l_choices:<Vec<l_Op> as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_decisions:<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0> as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_choices.write_binary(w)?;
self.l_decisions.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l_Coefficients{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("Coefficients")?;let mut fields=v.fields()?;Ok(Self{
l_scale:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_bias:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_scale.write_binary(w)?;
self.l_bias.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l_Distribution{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("Distribution")?;let mut fields=v.fields()?;Ok(Self{
l_masses:<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_derivatives:<Vec<Vec<f32>> as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_masses.write_binary(w)?;
self.l_derivatives.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l_Example{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("Example")?;let mut fields=v.fields()?;Ok(Self{
l_input:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_target:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_input.write_binary(w)?;
self.l_target.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l_Goal{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("Goal")?;let mut fields=v.fields()?;Ok(Self{
l_samples:<Vec<l_Example> as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_instruction_cost:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_version:<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_samples.write_binary(w)?;
self.l_instruction_cost.write_binary(w)?;
self.l_version.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l_MassRow{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("MassRow")?;let mut fields=v.fields()?;Ok(Self{
l_identity:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_scale:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_bias:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_relu:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_identity.write_binary(w)?;
self.l_scale.write_binary(w)?;
self.l_bias.write_binary(w)?;
self.l_relu.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l_Parameters{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("Parameters")?;let mut fields=v.fields()?;Ok(Self{
l_a:<l_MassRow as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_b:<l_MassRow as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_c:<l_MassRow as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_d:<l_MassRow as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_a.write_binary(w)?;
self.l_b.write_binary(w)?;
self.l_c.write_binary(w)?;
self.l_d.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l_Pick{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("Pick")?;let mut fields=v.fields()?;Ok(Self{
l_slot:<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_operation:<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_slot.write_binary(w)?;
self.l_operation.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l_Report{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("Report")?;let mut fields=v.fields()?;Ok(Self{
l_step:<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_loss:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_best:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_accepted:<bool as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_goal_version:<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_step.write_binary(w)?;
self.l_loss.write_binary(w)?;
self.l_best.write_binary(w)?;
self.l_accepted.write_binary(w)?;
self.l_goal_version.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l_Sampled{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("Sampled")?;let mut fields=v.fields()?;Ok(Self{
l_code:<Vec<l_Op> as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_decisions:<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0> as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_code.write_binary(w)?;
self.l_decisions.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l___ink_differential_0{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("__ink_differential_0")?;let mut fields=v.fields()?;Ok(Self{
l_value:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_value.write_binary(w)?;
self.l_tangent.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l___ink_differential_2{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("__ink_differential_2")?;let mut fields=v.fields()?;Ok(Self{
l_value:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent_0:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent_1:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent_2:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent_3:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent_4:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent_5:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent_6:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent_7:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent_8:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent_9:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent_10:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent_11:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent_12:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent_13:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent_14:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_tangent_15:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_value.write_binary(w)?;
self.l_tangent_0.write_binary(w)?;
self.l_tangent_1.write_binary(w)?;
self.l_tangent_2.write_binary(w)?;
self.l_tangent_3.write_binary(w)?;
self.l_tangent_4.write_binary(w)?;
self.l_tangent_5.write_binary(w)?;
self.l_tangent_6.write_binary(w)?;
self.l_tangent_7.write_binary(w)?;
self.l_tangent_8.write_binary(w)?;
self.l_tangent_9.write_binary(w)?;
self.l_tangent_10.write_binary(w)?;
self.l_tangent_11.write_binary(w)?;
self.l_tangent_12.write_binary(w)?;
self.l_tangent_13.write_binary(w)?;
self.l_tangent_14.write_binary(w)?;
self.l_tangent_15.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l___ink_differential_4{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("__ink_differential_4")?;let mut fields=v.fields()?;Ok(Self{
l_a:<l___ink_differential_5 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_b:<l___ink_differential_5 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_c:<l___ink_differential_5 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_d:<l___ink_differential_5 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_a.write_binary(w)?;
self.l_b.write_binary(w)?;
self.l_c.write_binary(w)?;
self.l_d.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l___ink_differential_5{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("__ink_differential_5")?;let mut fields=v.fields()?;Ok(Self{
l_identity:<l___ink_differential_2 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_scale:<l___ink_differential_2 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_bias:<l___ink_differential_2 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_relu:<l___ink_differential_2 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_identity.write_binary(w)?;
self.l_scale.write_binary(w)?;
self.l_bias.write_binary(w)?;
self.l_relu.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l___ink_differential_6{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("__ink_differential_6")?;let mut fields=v.fields()?;Ok(Self{
l_slot:<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_operation:<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_slot.write_binary(w)?;
self.l_operation.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_36{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_36")?;let mut fields=v.fields()?;Ok(Self{
l_accumulated:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_found:<bool as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_i:<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_selected:<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_accumulated.write_binary(w)?;
self.l_found.write_binary(w)?;
self.l_i.write_binary(w)?;
self.l_selected.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_5{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_5")?;let mut fields=v.fields()?;Ok(Self{
l_i:<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_maximum:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_i.write_binary(w)?;
self.l_maximum.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_52{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_52")?;let mut fields=v.fields()?;Ok(Self{
l_correction:<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_i:<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_correction.write_binary(w)?;
self.l_i.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l___ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_72{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("__ink_loop_6e655ce4c0b036a41a6c1a6647711c4e78b94c3bb3facd9461cf0b97384b0f9a_72")?;let mut fields=v.fields()?;Ok(Self{
l_accumulator:<Result<Vec<f32>,String> as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_i:<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_accumulator.write_binary(w)?;
self.l_i.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0")?;let mut fields=v.fields()?;Ok(Self{
l_action:<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_probability:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_score:<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_action.write_binary(w)?;
self.l_probability.write_binary(w)?;
self.l_score.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249")?;let mut fields=v.fields()?;Ok(Self{
l_rate:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_first_decay:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_second_decay:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_epsilon:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_weight_decay:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_norm_limit:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_rate.write_binary(w)?;
self.l_first_decay.write_binary(w)?;
self.l_second_decay.write_binary(w)?;
self.l_epsilon.write_binary(w)?;
self.l_weight_decay.write_binary(w)?;
self.l_norm_limit.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("record")?;v.require_name("ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab")?;let mut fields=v.fields()?;Ok(Self{
l_weights:<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_first:<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_second:<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_steps:<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_first_power:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
l_second_power:<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire record field")??)?,
})}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|{self.l_weights.write_binary(w)?;
self.l_first.write_binary(w)?;
self.l_second.write_binary(w)?;
self.l_steps.write_binary(w)?;
self.l_first_power.write_binary(w)?;
self.l_second_power.write_binary(w)?;
Ok(())})}}
impl BinaryValue for l_Op{fn from_binary(v:value_wire::Validated<'_>)->Result<Self,String>{v.require_kind("enum")?;v.require_name("Op")?;match v.text()?{
"Op.Identity"=>Ok(Self::l_Identity),
"Op.Scale"=>Ok(Self::l_Scale),
"Op.Bias"=>Ok(Self::l_Bias),
"Op.Relu"=>Ok(Self::l_Relu),
_=>Err("wire enum variant".into())}}fn write_binary(&self,w:&mut value_wire::Encoder)->Result<(),String>{w.frame(|w|w.bytes(match self{Self::l_Identity=>"Op.Identity".as_bytes(),
Self::l_Scale=>"Op.Scale".as_bytes(),
Self::l_Bias=>"Op.Bias".as_bytes(),
Self::l_Relu=>"Op.Relu".as_bytes(),
}))}}
impl State{fn binary_call_frame(&mut self,name:&str,record:value_wire::Validated<'_>,output:&value_wire::Schema,limits:ValueWireLimits)->Result<Vec<u8>,String>{match name{
"evaluate"=>{let mut fields=record.fields()?;
let a0=<Vec<l_Op> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<l_Coefficients as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_evaluate(a0,a1,a2);output.encode_with(limits,|w|result.write_binary(w))},
"coefficients_valid"=>{let mut fields=record.fields()?;
let a0=<l_Coefficients as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_coefficients_valid(a0);output.encode_with(limits,|w|result.write_binary(w))},
"goal_valid"=>{let mut fields=record.fields()?;
let a0=<l_Goal as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_goal_valid(a0);output.encode_with(limits,|w|result.write_binary(w))},
"squared_error"=>{let mut fields=record.fields()?;
let a0=<Vec<l_Op> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<l_Coefficients as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<l_Example as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_squared_error(a0,a1,a2);output.encode_with(limits,|w|result.write_binary(w))},
"objective"=>{let mut fields=record.fields()?;
let a0=<Vec<l_Op> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<l_Coefficients as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<l_Goal as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_objective(a0,a1,a2);output.encode_with(limits,|w|result.write_binary(w))},
"unpack"=>{let mut fields=record.fields()?;
let a0=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_unpack(a0);output.encode_with(limits,|w|result.write_binary(w))},
"pack"=>{let mut fields=record.fields()?;
let a0=<l_Parameters as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_pack(a0);output.encode_with(limits,|w|result.write_binary(w))},
"mass"=>{let mut fields=record.fields()?;
let a0=<l_Parameters as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<l_Pick as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_mass(a0,a1);output.encode_with(limits,|w|result.write_binary(w))},
"operation"=>{let mut fields=record.fields()?;
let a0=<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_operation(a0);output.encode_with(limits,|w|result.write_binary(w))},
"distribution"=>{let mut fields=record.fields()?;
let a0=<l_Parameters as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_distribution(a0,a1);output.encode_with(limits,|w|result.write_binary(w))},
"sample_slot"=>{let mut fields=record.fields()?;
let a0=<Result<l_Building,String> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<l_Parameters as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a3=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_sample_slot(a0,a1,a2,a3);output.encode_with(limits,|w|result.write_binary(w))},
"sample"=>{let mut fields=record.fields()?;
let a0=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_sample(a0,a1);output.encode_with(limits,|w|result.write_binary(w))},
"reward"=>{let mut fields=record.fields()?;
let a0=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_reward(a0);output.encode_with(limits,|w|result.write_binary(w))},
"operation_index"=>{let mut fields=record.fields()?;
let a0=<l_Op as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_operation_index(a0);output.encode_with(limits,|w|result.write_binary(w))},
"elite_slot"=>{let mut fields=record.fields()?;
let a0=<Result<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0>,String> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<l_Parameters as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a3=<Vec<l_Op> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_elite_slot(a0,a1,a2,a3);output.encode_with(limits,|w|result.write_binary(w))},
"proposal_gradient"=>{let mut fields=record.fields()?;
let a0=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<Vec<l_Op> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a3=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a4=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_proposal_gradient(a0,a1,a2,a3,a4);output.encode_with(limits,|w|result.write_binary(w))},
"valid_policy"=>{let mut fields=record.fields()?;
let a0=<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_valid_policy(a0);output.encode_with(limits,|w|result.write_binary(w))},
"numeric"=>{let mut fields=record.fields()?;
let a0=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_numeric(a0);output.encode_with(limits,|w|result.write_binary(w))},
"ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54"=>{let mut fields=record.fields()?;
let a0=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54(a0);output.encode_with(limits,|w|result.write_binary(w))},
"ink_m28a5428efa573345218636e9cec104f24b6e8c67d7c4c0f979b255813b2abee3"=>{let mut fields=record.fields()?;
let a0=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<Vec<bool> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_m28a5428efa573345218636e9cec104f24b6e8c67d7c4c0f979b255813b2abee3(a0,a1);output.encode_with(limits,|w|result.write_binary(w))},
"ink_mfd18151b0af45b45f5b48ef5e7a09ac1294681f654e2174ae3b33183f445ef14"=>{let mut fields=record.fields()?;
let a0=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<Vec<bool> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_mfd18151b0af45b45f5b48ef5e7a09ac1294681f654e2174ae3b33183f445ef14(a0,a1);output.encode_with(limits,|w|result.write_binary(w))},
"ink_mc05a2256079ef1f1818d13e69727dc7902cdb7f70856a671af2ba08ef190d23a"=>{let mut fields=record.fields()?;
let a0=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<Vec<bool> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_mc05a2256079ef1f1818d13e69727dc7902cdb7f70856a671af2ba08ef190d23a(a0,a1);output.encode_with(limits,|w|result.write_binary(w))},
"ink_m6ec6e8f9e757c220bfe2ed28cbb8dab4ec520de5ee8de5ca702cbdb805a5f910"=>{let mut fields=record.fields()?;
let a0=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_m6ec6e8f9e757c220bfe2ed28cbb8dab4ec520de5ee8de5ca702cbdb805a5f910(a0,a1,a2);output.encode_with(limits,|w|result.write_binary(w))},
"ink_maa2c8802d351b443dda0bc206d70fa9fe87756b57a84d0357e9dfb4c1e7a0667"=>{let mut fields=record.fields()?;
let a0=<Vec<Vec<f32>> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<Vec<bool> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a3=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_maa2c8802d351b443dda0bc206d70fa9fe87756b57a84d0357e9dfb4c1e7a0667(a0,a1,a2,a3);output.encode_with(limits,|w|result.write_binary(w))},
"ink_m1774c4db693eebe71b1f79bce053b93633d1e1ec37196dd480b59c0248b4fbc2"=>{let mut fields=record.fields()?;
let a0=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<Vec<Vec<f32>> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<Vec<bool> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a3=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a4=<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_m1774c4db693eebe71b1f79bce053b93633d1e1ec37196dd480b59c0248b4fbc2(a0,a1,a2,a3,a4);output.encode_with(limits,|w|result.write_binary(w))},
"ink_m1fbf7ee6cef3bcca5d7d258c8606275806894b60d839126202d17f016ea87c80"=>{let mut fields=record.fields()?;
let a0=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<Vec<Vec<f32>> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<Vec<bool> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a3=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_m1fbf7ee6cef3bcca5d7d258c8606275806894b60d839126202d17f016ea87c80(a0,a1,a2,a3);output.encode_with(limits,|w|result.write_binary(w))},
"ink_m99468fca85aa8fb996f0c891430c813d82505250d39d8e415bf27679ddc39e07"=>{let mut fields=record.fields()?;
let a0=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<Vec<Vec<f32>> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<Vec<bool> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a3=<u32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_m99468fca85aa8fb996f0c891430c813d82505250d39d8e415bf27679ddc39e07(a0,a1,a2,a3);output.encode_with(limits,|w|result.write_binary(w))},
"ink_maadd6c30a027af52d851f0828eec45339d218ad3bbe73e4d8d7cdd3892e754f4"=>{let mut fields=record.fields()?;
let a0=<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_maadd6c30a027af52d851f0828eec45339d218ad3bbe73e4d8d7cdd3892e754f4(a0,a1,a2);output.encode_with(limits,|w|result.write_binary(w))},
"ink_m696809152e57d8dfa3f01f9a3e12c048434b9f2af91ff53321ea6ceeeeca5431"=>{let mut fields=record.fields()?;
let a0=<Result<Vec<f32>,String> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a3=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_m696809152e57d8dfa3f01f9a3e12c048434b9f2af91ff53321ea6ceeeeca5431(a0,a1,a2,a3);output.encode_with(limits,|w|result.write_binary(w))},
"ink_m372cbaf2ee2bc8705fad4b5b65a9e744ea468afbe4c153f17c7da282a459d1cd"=>{let mut fields=record.fields()?;
let a0=<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_m372cbaf2ee2bc8705fad4b5b65a9e744ea468afbe4c153f17c7da282a459d1cd(a0,a1,a2);output.encode_with(limits,|w|result.write_binary(w))},
"ink_m43c1e2ac4d6d9a37358654ff5c1abcd42d4b01146c41a7ca617bccb074a8813b"=>{let mut fields=record.fields()?;
let a0=<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_m43c1e2ac4d6d9a37358654ff5c1abcd42d4b01146c41a7ca617bccb074a8813b(a0,a1,a2);output.encode_with(limits,|w|result.write_binary(w))},
"ink_m4b5ada8f7d6b3beaee6fc06bf68e61ca158cbc7664899364dff18d21555697ae"=>{let mut fields=record.fields()?;
let a0=<Vec<l_ink_m661637c3adbaa0f0830635fd9a160d462e80b490866b2aafcfaa41cf717ac7c0> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_m4b5ada8f7d6b3beaee6fc06bf68e61ca158cbc7664899364dff18d21555697ae(a0,a1,a2);output.encode_with(limits,|w|result.write_binary(w))},
"ink_mda500f665e6078213ee2391fedf06240c651d1725327b086aa70cda14bef9a07"=>{let mut fields=record.fields()?;
let a0=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_mda500f665e6078213ee2391fedf06240c651d1725327b086aa70cda14bef9a07(a0,a1,a2);output.encode_with(limits,|w|result.write_binary(w))},
"ink_meefc22a28d97f5bdc4100b36eeab9549241c3ef201b83c2f75111644d317833d"=>{let mut fields=record.fields()?;
let a0=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_meefc22a28d97f5bdc4100b36eeab9549241c3ef201b83c2f75111644d317833d(a0);output.encode_with(limits,|w|result.write_binary(w))},
"ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96"=>{let mut fields=record.fields()?;
let a0=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96(a0);output.encode_with(limits,|w|result.write_binary(w))},
"ink_m786bdc6011aece08dbf36c5ca89c437e06ff758c9d3d242f723dde2af6ea31db"=>{let mut fields=record.fields()?;
let a0=<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_m786bdc6011aece08dbf36c5ca89c437e06ff758c9d3d242f723dde2af6ea31db(a0);output.encode_with(limits,|w|result.write_binary(w))},
"ink_mdfbd57a9f460147afedb262e2bfe0f6197f9b813c85277c59f5e101900063ad7"=>{let mut fields=record.fields()?;
let a0=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_mdfbd57a9f460147afedb262e2bfe0f6197f9b813c85277c59f5e101900063ad7(a0);output.encode_with(limits,|w|result.write_binary(w))},
"ink_m5226ad25deae5e47d7fb65b6b5961d46740dd4e97b54d76a24d3d0445845fe35"=>{let mut fields=record.fields()?;
let a0=<l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_m5226ad25deae5e47d7fb65b6b5961d46740dd4e97b54d76a24d3d0445845fe35(a0);output.encode_with(limits,|w|result.write_binary(w))},
"ink_m8abb6b2bcbe55251e0b82a28f26d7ce761729346e35019c2b60ca9b5ee22590d"=>{let mut fields=record.fields()?;
let a0=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_m8abb6b2bcbe55251e0b82a28f26d7ce761729346e35019c2b60ca9b5ee22590d(a0);output.encode_with(limits,|w|result.write_binary(w))},
"ink_m7d03a2ed6071238ff1b69a8e56a8cb96b9dc3b095b2d939c0ccfed84ee9580b5"=>{let mut fields=record.fields()?;
let a0=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_m7d03a2ed6071238ff1b69a8e56a8cb96b9dc3b095b2d939c0ccfed84ee9580b5(a0,a1);output.encode_with(limits,|w|result.write_binary(w))},
"ink_m00ba8185ca362d257d138fe1886cbc5f3acc38c4a238bef60c3d3d7fa0276eab"=>{let mut fields=record.fields()?;
let a0=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a3=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a4=<f32 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a5=<l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_m00ba8185ca362d257d138fe1886cbc5f3acc38c4a238bef60c3d3d7fa0276eab(a0,a1,a2,a3,a4,a5);output.encode_with(limits,|w|result.write_binary(w))},
"ink_m2a55f95a80595bc61d1fcab41ff00f438ff6f2057b597df20aaae3c18507d2be"=>{let mut fields=record.fields()?;
let a0=<l_ink_md0e21302c2c2a82a6b87784e492f7b2e65c3a0ef3b191fb5e2428cbb90610fab as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<Vec<f32> as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a2=<l_ink_m9855292354160c3a107c125b8c215caf588dc8c3b3949a93e9ef8e771b334249 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l_ink_m2a55f95a80595bc61d1fcab41ff00f438ff6f2057b597df20aaae3c18507d2be(a0,a1,a2);output.encode_with(limits,|w|result.write_binary(w))},
"__ink_differential_3"=>{let mut fields=record.fields()?;
let a0=<l___ink_differential_4 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<l___ink_differential_6 as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l___ink_differential_3(a0,a1);output.encode_with(limits,|w|result.write_binary(w))},
"__ink_differential_1"=>{let mut fields=record.fields()?;
let a0=<l_Parameters as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let a1=<l_Pick as BinaryValue>::from_binary(fields.next().ok_or("wire argument")??)?;
let result=self.function_l___ink_differential_1(a0,a1);output.encode_with(limits,|w|result.write_binary(w))},
_=>Err("unsupported binary function".into())}}}
// Appended verbatim to generated applications. This is a host ABI, not an optimiser.
mod state_wasm {
    use super::*;
    use std::cell::RefCell;
    const MAX_BUFFER: usize = 64 * 1024 * 1024;
    const MAX_TOTAL: usize = 128 * 1024 * 1024;
    const MAX_JSON: usize = 4 * 1024 * 1024;
    const MAX_BUFFERS: usize = 256;
    const MAX_STATES: usize = 128;
    struct Registry {
        next: u32,
        states: BTreeMap<u32, State>,
        buffers: BTreeMap<u32, Vec<u8>>,
        bytes: usize,
        error: String,
    }
    impl Registry {
        fn new() -> Self {
            Self {
                next: 0,
                states: BTreeMap::new(),
                buffers: BTreeMap::new(),
                bytes: 0,
                error: String::new(),
            }
        }
        fn id(&mut self) -> Result<u32, String> {
            self.next = self
                .next
                .checked_add(1)
                .ok_or("ABI handle sequence exhausted")?;
            Ok(self.next)
        }
        fn fail(&mut self, error: impl Into<String>) -> u32 {
            self.error = error.into();
            0
        }
        fn insert_buffer(&mut self, bytes: Vec<u8>) -> Result<u32, String> {
            if bytes.len() > MAX_BUFFER
                || self.buffers.len() >= MAX_BUFFERS
                || self
                    .bytes
                    .checked_add(bytes.len())
                    .is_none_or(|n| n > MAX_TOTAL)
            {
                return Err("ABI buffer limit".into());
            }
            let id = self.id()?;
            self.bytes += bytes.len();
            self.buffers.insert(id, bytes);
            Ok(id)
        }
        fn reserve_output(&mut self) -> Result<u32, String> {
            // Reserve an output slot and enough accounting space before a change.
            if self
                .bytes
                .checked_add(MAX_BUFFER)
                .is_none_or(|n| n > MAX_TOTAL)
            {
                return Err("ABI output capacity unavailable".into());
            }
            self.insert_buffer(Vec::new())
        }
        fn finish(&mut self, id: u32, bytes: Vec<u8>) -> u32 {
            self.bytes += bytes.len();
            *self.buffers.get_mut(&id).expect("reserved output slot") = bytes;
            id
        }
        fn envelope(&mut self, id: u32, result: Result<Json, String>, committed: bool) -> u32 {
            let payload = match result {
                Ok(value) => serde_json::json!({"ok":value}),
                Err(message) => {
                    serde_json::json!({"error":{"message":message,"committed":committed}})
                }
            };
            let mut bytes = serde_json::to_vec(&payload).expect("JSON value serialization");
            if bytes.len() > MAX_BUFFER {
                bytes=serde_json::to_vec(&serde_json::json!({"error":{"message":"ABI response exceeds 64 MiB","committed":committed}})).expect("JSON error serialization");
            }
            self.finish(id, bytes)
        }
    }
    thread_local! {static REGISTRY:RefCell<Registry>=RefCell::new(Registry::new());}
    #[no_mangle]
    pub extern "C" fn lang_abi_version() -> u32 {
        1
    }
    #[no_mangle]
    pub extern "C" fn lang_buffer_alloc(length: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            let length = length as usize;
            if length > MAX_BUFFER
                || r.buffers.len() >= MAX_BUFFERS
                || r.bytes.checked_add(length).is_none_or(|n| n > MAX_TOTAL)
            {
                return r.fail("ABI buffer limit");
            }
            match r.insert_buffer(vec![0; length]) {
                Ok(id) => id,
                Err(e) => r.fail(e),
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_buffer_ptr(handle: u32) -> usize {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            match r.buffers.get(&handle) {
                Some(bytes) => bytes.as_ptr() as usize,
                None => r.fail("unknown buffer handle") as usize,
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_buffer_len(handle: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            match r.buffers.get(&handle) {
                Some(bytes) => bytes.len() as u32,
                None => r.fail("unknown buffer handle"),
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_buffer_free(handle: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            match r.buffers.remove(&handle) {
                Some(bytes) => {
                    r.bytes -= bytes.len();
                    1
                }
                None => r.fail("unknown buffer handle"),
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_error() -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            let bytes = r.error.as_bytes().to_vec();
            match r.insert_buffer(bytes) {
                Ok(id) => id,
                Err(_) => 0,
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_init() -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            if r.states.len() >= MAX_STATES {
                return r.fail("ABI state handle limit");
            }
            match r.id() {
                Ok(id) => {
                    r.states.insert(id, State::new());
                    id
                }
                Err(e) => r.fail(e),
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_state_drop(handle: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            if r.states.remove(&handle).is_some() {
                1
            } else {
                r.fail("unknown state handle")
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_restore(buffer: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            if r.states.len() >= MAX_STATES {
                return r.fail("ABI state handle limit");
            }
            let id = match r.id() {
                Ok(id) => id,
                Err(e) => return r.fail(e),
            };
            let Some(bytes) = r.buffers.get(&buffer) else {
                return r.fail("unknown buffer handle");
            };
            match State::restore(bytes) {
                Ok(state) => {
                    r.states.insert(id, state);
                    id
                }
                Err(e) => r.fail(e),
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_checkpoint(state: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            let id = match r.reserve_output() {
                Ok(id) => id,
                Err(e) => return r.fail(e),
            };
            let result = r
                .states
                .get(&state)
                .ok_or_else(|| "unknown state handle".to_string())
                .and_then(|s| s.checkpoint());
            match result {
                Ok(bytes) => r.finish(id, bytes),
                Err(e) => {
                    r.buffers.remove(&id);
                    r.fail(e)
                }
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_invoke(state: u32, request: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            let id = match r.reserve_output() {
                Ok(id) => id,
                Err(e) => return r.fail(e),
            };
            let result = (|| -> Result<Json, String> {
                let bytes = r.buffers.get(&request).ok_or("unknown buffer handle")?;
                if bytes.len() > MAX_JSON {
                    return Err("ABI request exceeds 4 MiB".into());
                }
                let message: Json = serde_json::from_slice(bytes).map_err(|e| e.to_string())?;
                let pure = message.get("pure").and_then(Json::as_str);
                let name = pure
                    .or_else(|| message.get("call").and_then(Json::as_str))
                    .ok_or("request needs call or pure")?;
                let args = message.get("args").ok_or("request needs args")?;
                let state = r.states.get_mut(&state).ok_or("unknown state handle")?;
                if pure.is_some() {
                    state.call_json(name, args)
                } else {
                    state.invoke_json(name, args)
                }
            })();
            let committed = result
                .as_ref()
                .ok()
                .and_then(|v| v.get("committed"))
                .and_then(Json::as_bool)
                .unwrap_or(false);
            r.envelope(id, result, committed)
        })
    }
    // A generic raw-byte operation boundary. The optional value-wire export
    // supplies the operation; representation runtimes need no value-wire code.
    pub(crate) fn invoke_bytes(state:u32,request:u32,operation:impl FnOnce(&mut State,&[u8])->Result<Vec<u8>,String>)->u32{
        REGISTRY.with(|registry|{
            let mut r=registry.borrow_mut();
            let id=match r.reserve_output(){Ok(id)=>id,Err(e)=>return r.fail(e)};
            let result=(||{
                let Registry{states,buffers,..}=&mut *r;
                let bytes=buffers.get(&request).ok_or("unknown buffer handle")?;
                operation(states.get_mut(&state).ok_or("unknown state handle")?,bytes)
            })();
            match result{Ok(bytes) if bytes.len()<=MAX_BUFFER=>r.finish(id,bytes),Ok(_)=>{r.buffers.remove(&id);r.fail("ABI binary output limit")},Err(e)=>{r.buffers.remove(&id);r.fail(e)}}
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_events(state: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            let id = match r.reserve_output() {
                Ok(id) => id,
                Err(e) => return r.fail(e),
            };
            let result = r
                .states
                .get(&state)
                .ok_or_else(|| "unknown state handle".into())
                .map(|s| Json::Array(s.outbox().iter().map(Event::to_json).collect()));
            r.envelope(id, result, false)
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_acknowledge(state: u32, commit: u64, position: u64) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            match r.states.get_mut(&state) {
                Some(s) => {
                    s.acknowledge_through(commit, position);
                    1
                }
                None => r.fail("unknown state handle"),
            }
        })
    }
    // Optional ABI-v1 retained-operation extension. Older hosts may ignore it.
    #[no_mangle]
    pub extern "C" fn lang_transaction_begin(state:u32)->u32 {
        REGISTRY.with(|r| {let mut r=r.borrow_mut();
            let result=r.states.get_mut(&state).ok_or_else(||"unknown state handle".to_owned()).and_then(|s|s.begin_transaction());
            match result {Ok(true)=>1,Ok(false)=>2,Err(e)=>r.fail(e)}
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_transaction_commit(state:u32)->u32 {
        REGISTRY.with(|r| {let mut r=r.borrow_mut();match r.states.get_mut(&state){Some(s)=>{s.commit_transaction();1},None=>r.fail("unknown state handle")}})
    }
    #[no_mangle]
    pub extern "C" fn lang_transaction_rollback(state:u32)->u32 {
        REGISTRY.with(|r| {let mut r=r.borrow_mut();match r.states.get_mut(&state){Some(s)=>{s.rollback_transaction();1},None=>r.fail("unknown state handle")}})
    }
    #[no_mangle]
    pub extern "C" fn lang_version(state: u32) -> u64 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            match r.states.get(&state) {
                Some(s) => s.version(),
                None => {
                    r.fail("unknown state handle");
                    0
                }
            }
        })
    }
}

// Per-instance task transport is separate from the state-handle registry. Host
// scheduling can re-enter this ABI without borrowing or publishing transaction state.
#[cfg(target_arch="wasm32")]
thread_local! {static PARALLEL_IO:std::cell::RefCell<Vec<u8>>=const{std::cell::RefCell::new(Vec::new())};}
#[cfg(target_arch="wasm32")]
#[link(wasm_import_module="ink_parallel")]
unsafe extern "C" {#[link_name="run"] fn __ink_parallel_import(ptr:u32,len:u32)->u32;}
#[cfg(target_arch="wasm32")]
fn __ink_parallel_host(task:Json)->Result<Json,String>{
    let bytes=serde_json::to_vec(&task).map_err(|e|e.to_string())?;
    if bytes.len()>64*1024*1024{return Err("parallel request limit".into());}
    let length=unsafe{__ink_parallel_import(bytes.as_ptr() as u32,bytes.len() as u32)};
    PARALLEL_IO.with(|io|{let io=io.borrow();if length as usize!=io.len(){return Err("parallel response length".into());}let reply:Json=serde_json::from_slice(&io).map_err(|e|e.to_string())?;if let Some(error)=reply["error"].as_str(){return Err(error.into());}reply.get("ok").cloned().ok_or("parallel response envelope".into())})
}
#[cfg(target_arch="wasm32")]
#[no_mangle]
pub extern "C" fn lang_parallel_alloc(len:u32)->u32{if len>64*1024*1024{return 0;}PARALLEL_IO.with(|io|{let mut io=io.borrow_mut();io.resize(len as usize,0);io.as_mut_ptr() as u32})}
#[cfg(target_arch="wasm32")]
#[no_mangle]
pub extern "C" fn lang_parallel_ptr()->u32{PARALLEL_IO.with(|io|io.borrow().as_ptr() as u32)}
#[cfg(target_arch="wasm32")]
#[no_mangle]
pub unsafe extern "C" fn lang_parallel_worker(ptr:u32,len:u32)->u32{
    let result=(||->Result<Json,String>{if len>64*1024*1024{return Err("parallel request limit".into());}let task:Json=serde_json::from_slice(std::slice::from_raw_parts(ptr as *const u8,len as usize)).map_err(|e|e.to_string())?;State::new().parallel_worker(&task)})();
    let reply=match result{Ok(v)=>json!({"ok":v}),Err(e)=>json!({"error":e})};
    let bytes=serde_json::to_vec(&reply).expect("parallel response");if bytes.len()>64*1024*1024{return 0;}
    let len=bytes.len() as u32;PARALLEL_IO.with(|io|*io.borrow_mut()=bytes);len
}
// Optional raw binary extension. Arguments and results bind compiled schemas;
// the existing registry owns handles and reports UTF-8 errors through lang_error.
#[no_mangle]
pub extern "C" fn lang_call_binary(state:u32,function:u32,arguments:u32)->u32{
 state_wasm::invoke_bytes(state,arguments,|s,bytes|s.call_binary(State::binary_function(function)?,bytes,ValueWireLimits::default()))
}
#[cfg(not(target_arch = "wasm32"))]
pub mod durable;
#[cfg(not(target_arch = "wasm32"))]
impl durable::CompiledState for State {
    fn create() -> Self {
        Self::new()
    }
    fn restore(bytes: &[u8]) -> Result<Self, String> {
        Self::restore(bytes)
    }
    fn checkpoint(&self) -> Result<Vec<u8>, String> {
        self.checkpoint()
    }
    fn invoke(
        &mut self,
        call: &str,
        args: &serde_json::Value,
    ) -> Result<serde_json::Value, String> {
        self.invoke_json(call, args)
    }
    fn pure(&mut self, call: &str, args: &serde_json::Value) -> Result<serde_json::Value, String> {
        self.call_json(call, args)
    }
    fn events(&self) -> Vec<serde_json::Value> {
        self.outbox().iter().map(Event::to_json).collect()
    }
    fn acknowledge(&mut self, commit: u64, position: u64) {
        self.acknowledge_through(commit, position)
    }
    fn begin_transaction(&mut self) -> Result<bool, String> {
        self.begin_transaction()
    }
    fn commit_transaction(&mut self) {
        self.commit_transaction()
    }
    fn rollback_transaction(&mut self) {
        self.rollback_transaction()
    }
    fn version(&self) -> u64 {
        self.version()
    }
}
#[cfg(not(target_arch = "wasm32"))]
pub type DurableState = durable::Host<State, durable::FileStore>;

include!("initial-state.rs");
