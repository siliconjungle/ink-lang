#[path="../../gpu/f1/native/src/lib.rs"] mod part1;
#[path="../../gpu/f5/native/src/lib.rs"] mod part5;
#[path="../../gpu/f6/native/src/lib.rs"] mod part6;
#[path="../../gpu/f7/native/src/lib.rs"] mod part7;
#[path="../../gpu/f12/native/src/lib.rs"] mod part12;
#[path="../../gpu/f17/native/src/lib.rs"] mod part17;
#[path="../../gpu/f18/native/src/lib.rs"] mod part18;
#[path="../../gpu/f19/native/src/lib.rs"] mod part19;
#[path="../../gpu/f22/native/src/lib.rs"] mod part22;
#[path="../../gpu/f33/native/src/lib.rs"] mod part33;
#[path="../../gpu/f34/native/src/lib.rs"] mod part34;
#[path="../../gpu/f37/native/src/lib.rs"] mod part37;
#[path="../../gpu/f38/native/src/lib.rs"] mod part38;
#[path="../../gpu/f40/native/src/lib.rs"] mod part40;
#[path="../../gpu/f42/native/src/lib.rs"] mod part42;
#[path="../../gpu/f43/native/src/lib.rs"] mod part43;

struct GpuEngines{part1:part1::Engine,part5:part5::Engine,part6:part6::Engine,part7:part7::Engine,part12:part12::Engine,part17:part17::Engine,part18:part18::Engine,part19:part19::Engine,part22:part22::Engine,part33:part33::Engine,part34:part34::Engine,part37:part37::Engine,part38:part38::Engine,part40:part40::Engine,part42:part42::Engine,part43:part43::Engine,}impl GpuEngines{fn new()->Self{Self{part1:part1::Engine::new(),part5:part5::Engine::new(),part6:part6::Engine::new(),part7:part7::Engine::new(),part12:part12::Engine::new(),part17:part17::Engine::new(),part18:part18::Engine::new(),part19:part19::Engine::new(),part22:part22::Engine::new(),part33:part33::Engine::new(),part34:part34::Engine::new(),part37:part37::Engine::new(),part38:part38::Engine::new(),part40:part40::Engine::new(),part42:part42::Engine::new(),part43:part43::Engine::new(),}} fn call(&mut self,name:&str,args:&serde_json::Value,backend:&str,options:Option<&serde_json::Value>)->Result<serde_json::Value,String>{match name{"coefficients_valid"=>{if let Some(options)=options{self.part1.configure_selection(options.clone())?;}self.part1.call(name,args,part1::Backend::parse(backend)?) },
"unpack"=>{if let Some(options)=options{self.part5.configure_selection(options.clone())?;}self.part5.call(name,args,part5::Backend::parse(backend)?) },
"pack"=>{if let Some(options)=options{self.part6.configure_selection(options.clone())?;}self.part6.call(name,args,part6::Backend::parse(backend)?) },
"mass"=>{if let Some(options)=options{self.part7.configure_selection(options.clone())?;}self.part7.call(name,args,part7::Backend::parse(backend)?) },
"reward"=>{if let Some(options)=options{self.part12.configure_selection(options.clone())?;}self.part12.call(name,args,part12::Backend::parse(backend)?) },
"numeric"=>{if let Some(options)=options{self.part17.configure_selection(options.clone())?;}self.part17.call(name,args,part17::Backend::parse(backend)?) },
"ink_mf8c8b7bece8d14389eab1038adb3b7830097079aed0acc6403a569b9c382cc54"=>{if let Some(options)=options{self.part18.configure_selection(options.clone())?;}self.part18.call(name,args,part18::Backend::parse(backend)?) },
"ink_m28a5428efa573345218636e9cec104f24b6e8c67d7c4c0f979b255813b2abee3"=>{if let Some(options)=options{self.part19.configure_selection(options.clone())?;}self.part19.call(name,args,part19::Backend::parse(backend)?) },
"ink_m6ec6e8f9e757c220bfe2ed28cbb8dab4ec520de5ee8de5ca702cbdb805a5f910"=>{if let Some(options)=options{self.part22.configure_selection(options.clone())?;}self.part22.call(name,args,part22::Backend::parse(backend)?) },
"ink_meefc22a28d97f5bdc4100b36eeab9549241c3ef201b83c2f75111644d317833d"=>{if let Some(options)=options{self.part33.configure_selection(options.clone())?;}self.part33.call(name,args,part33::Backend::parse(backend)?) },
"ink_ma7989fd41503b856aac5b390003c2c4aff5f8c7c67e22867c2e88acff5a22d96"=>{if let Some(options)=options{self.part34.configure_selection(options.clone())?;}self.part34.call(name,args,part34::Backend::parse(backend)?) },
"ink_m5226ad25deae5e47d7fb65b6b5961d46740dd4e97b54d76a24d3d0445845fe35"=>{if let Some(options)=options{self.part37.configure_selection(options.clone())?;}self.part37.call(name,args,part37::Backend::parse(backend)?) },
"ink_m8abb6b2bcbe55251e0b82a28f26d7ce761729346e35019c2b60ca9b5ee22590d"=>{if let Some(options)=options{self.part38.configure_selection(options.clone())?;}self.part38.call(name,args,part38::Backend::parse(backend)?) },
"ink_m00ba8185ca362d257d138fe1886cbc5f3acc38c4a238bef60c3d3d7fa0276eab"=>{if let Some(options)=options{self.part40.configure_selection(options.clone())?;}self.part40.call(name,args,part40::Backend::parse(backend)?) },
"__ink_differential_3"=>{if let Some(options)=options{self.part42.configure_selection(options.clone())?;}self.part42.call(name,args,part42::Backend::parse(backend)?) },
"__ink_differential_1"=>{if let Some(options)=options{self.part43.configure_selection(options.clone())?;}self.part43.call(name,args,part43::Backend::parse(backend)?) },
_=>Err("CPU-only function".into())}}}
include!("state-cli.rs");
fn run() -> Result<(), String> {
    let mut engines = GpuEngines::new();
    run_with_pure_initialized(compiled_state::initial_state,|state, step| {
        let name = step["pure"].as_str().ok_or("missing pure")?;
        let backend = step["backend"].as_str().unwrap_or("auto");
        if !["auto", "cpu", "gpu", "gpu-required"].contains(&backend) {
            return Err("invalid native backend".into());
        }
        if let Some(options)=step.get("selection") {
            ink_abi::selection::decide(options,&serde_json::json!({}),&["cpu".into()])?;
        }
        if backend == "cpu" {
            state
                .pure(name, &step["args"])
                .map(|v| serde_json::json!({"value":v,"backend":"cpu"}))
        } else {
            engines.call(name, &step["args"], backend, step.get("selection")).or_else(|e| {
                if backend=="gpu-required"{return Err(e);}
                state
                    .pure(name, &step["args"])
                    .map(|v| serde_json::json!({"value":v,"backend":"cpu","reason":e}))
            })
        }
    })
}
fn main() -> std::process::ExitCode {
    match run() {
        Ok(()) => std::process::ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("error: {e}");
            std::process::ExitCode::FAILURE
        }
    }
}
