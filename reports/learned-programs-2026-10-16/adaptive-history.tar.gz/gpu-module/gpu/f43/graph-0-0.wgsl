// Exact wrapping u64 over two storage lanes. No floating point intermediates.
struct InkU64 {lo:u32,hi:u32,}
struct InkDiv64 {quotient:InkU64,remainder:InkU64,}
fn ink_u64_shl(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64(a.lo<<k,(a.hi<<k)|(a.lo>>(32u-k)));}return InkU64(0u,a.lo<<(k-32u));}
fn ink_u64_shr(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64((a.lo>>k)|(a.hi<<(32u-k)),a.hi>>k);}return InkU64(a.hi>>(k-32u),0u);}
fn ink_u64_rol(a:InkU64,count:u32)->InkU64{let k=count&63u;let l=ink_u64_shl(a,k);let r=ink_u64_shr(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_ror(a:InkU64,count:u32)->InkU64{let k=count&63u;let r=ink_u64_shr(a,k);let l=ink_u64_shl(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_eq(a:InkU64,b:InkU64)->bool{return a.lo==b.lo&&a.hi==b.hi;}
fn ink_u64_lt(a:InkU64,b:InkU64)->bool{return a.hi<b.hi||(a.hi==b.hi&&a.lo<b.lo);}
fn ink_u64_add(a:InkU64,b:InkU64)->InkU64{let lo=a.lo+b.lo;return InkU64(lo,a.hi+b.hi+select(0u,1u,lo<a.lo));}
fn ink_u64_sub(a:InkU64,b:InkU64)->InkU64{return InkU64(a.lo-b.lo,a.hi-b.hi-select(0u,1u,a.lo<b.lo));}
fn ink_u64_mul(a:InkU64,b:InkU64)->InkU64{let al=a.lo&65535u;let ah=a.lo>>16u;let bl=b.lo&65535u;let bh=b.lo>>16u;let p=al*bl;let x=ah*bl;let y=al*bh;let mid=(p>>16u)+(x&65535u)+(y&65535u);let high=ah*bh+(x>>16u)+(y>>16u)+(mid>>16u);return InkU64((mid<<16u)|(p&65535u),high+a.lo*b.hi+a.hi*b.lo);}
fn ink_u64_div(a:InkU64,b:InkU64)->InkDiv64{var q=InkU64(0u,0u);var r=InkU64(0u,0u);var cursor=64u;loop{if(cursor==0u){break;}cursor--;var bit=0u;if(cursor>=32u){bit=(a.hi>>(cursor-32u))&1u;}else{bit=(a.lo>>cursor)&1u;}let overflow=r.hi>>31u;r=InkU64((r.lo<<1u)|bit,(r.hi<<1u)|(r.lo>>31u));if(overflow!=0u||!ink_u64_lt(r,b)){r=ink_u64_sub(r,b);if(cursor>=32u){q.hi|=1u<<(cursor-32u);}else{q.lo|=1u<<cursor;}}}return InkDiv64(q,r);}
// Binary32 evaluated with integer lanes: round-to-nearest, ties-to-even,
// gradual underflow, signed zero and canonical arithmetic NaN.
fn ink_f32_nan(x:u32)->bool{return (x&0x7fffffffu)>0x7f800000u;}
fn ink_f32_eq(a:u32,b:u32)->bool{return !ink_f32_nan(a)&&!ink_f32_nan(b)&&(a==b||((a|b)&0x7fffffffu)==0u);}
fn ink_f32_lt(a:u32,b:u32)->bool{
 if(ink_f32_nan(a)||ink_f32_nan(b)||ink_f32_eq(a,b)){return false;}
 if((a^b)&0x80000000u)!=0u{return (a&0x80000000u)!=0u;}
 if((a&0x80000000u)!=0u){return a>b;}return a<b;
}
fn ink_f32_jam(x:u32,n:u32)->u32{if(n==0u){return x;}if(n>=32u){return select(0u,1u,x!=0u);}return (x>>n)|select(0u,1u,(x&((1u<<n)-1u))!=0u);}
fn ink_f32_round(sign:u32,exponent:i32,extended:u32)->u32{
 var e=exponent;var s=extended;
 if(e<1i){s=ink_f32_jam(s,u32(1i-e));e=1i;}
 let tail=s&7u;var sig=s>>3u;
 if(tail>4u||(tail==4u&&(sig&1u)!=0u)){sig++;}
 if(sig>=0x1000000u){sig>>=1u;e++;}
 if(e>=255i){return sign|0x7f800000u;}
 if(sig==0u){return sign;}
 let raw=select(u32(e),0u,e==1i&&sig<0x800000u);
 return sign|(raw<<23u)|(sig&0x7fffffu);
}
fn ink_f32_add(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 var x=a;var y=b;if((x&0x7fffffffu)<(y&0x7fffffffu)){x=b;y=a;}
 let ax=x&0x7fffffffu;let ay=y&0x7fffffffu;let sign=x&0x80000000u;
 if(ax==0x7f800000u){if(ay==ax&&((x^y)&0x80000000u)!=0u){return 0x7fc00000u;}return x;}
 let rx=(x>>23u)&255u;let ry=(y>>23u)&255u;var e=i32(max(rx,1u));
 var sx=((x&0x7fffffu)|select(0u,0x800000u,rx!=0u))<<3u;
 let sy=ink_f32_jam(((y&0x7fffffu)|select(0u,0x800000u,ry!=0u))<<3u,u32(e)-max(ry,1u));
 if(((x^y)&0x80000000u)==0u){sx+=sy;if(sx>=0x8000000u){sx=ink_f32_jam(sx,1u);e++;}}
 else{sx-=sy;if(sx==0u){return 0u;}loop{if(sx>=0x4000000u||e<=1i){break;}sx<<=1u;e--;}}
 return ink_f32_round(sign,e,sx);
}
fn ink_f32_sub(a:u32,b:u32)->u32{return ink_f32_add(a,b^0x80000000u);}
fn ink_f32_mul(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(aa==0x7f800000u||bb==0x7f800000u){if(aa==0u||bb==0u){return 0x7fc00000u;}return sign|0x7f800000u;}
 if(aa==0u||bb==0u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u));var eb=i32(max(rb,1u));
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 let product=ink_u64_mul(InkU64(sa,0u),InkU64(sb,0u));let high=(product.hi&0x8000u)!=0u;
 let shift=select(20u,21u,high);let extended=(product.lo>>shift)|(product.hi<<(32u-shift))|select(0u,1u,(product.lo&((1u<<shift)-1u))!=0u);
 return ink_f32_round(sign,ea+eb-127i+select(0i,1i,high),extended);
}
// Exact sqrt and division use integer significands, independent of WGSL float
// approximation allowances and device flush-to-zero behavior.
fn ink_f32_sqrt(x:u32)->u32{
 let a=x&0x7fffffffu;if(a==0u){return x;}
 if(a>0x7f800000u||(x&0x80000000u)!=0u){return 0x7fc00000u;}
 if(a==0x7f800000u){return x;}
 let raw=(x>>23u)&255u;var m=(x&0x7fffffu)|select(0u,0x800000u,raw!=0u);var e=i32(max(raw,1u))-127i;
 loop{if(m>=0x800000u){break;}m<<=1u;e--;}
 let odd=e&1i;var half=(e-odd)/2i;let shift=23u+u32(odd);
 let n=InkU64(m<<shift,m>>(32u-shift));var lo=0u;var hi=0x1000000u;
 loop{if(lo+1u>=hi){break;}let mid=(lo+hi)>>1u;let sq=ink_u64_mul(InkU64(mid,0u),InkU64(mid,0u));if(!ink_u64_lt(n,sq)){lo=mid;}else{hi=mid;}}
 let sq=ink_u64_mul(InkU64(lo,0u),InkU64(lo,0u));let rem=ink_u64_sub(n,sq);
 if(ink_u64_lt(InkU64(lo,0u),rem)){lo++;}
 if(lo==0x1000000u){lo>>=1u;half++;}
 return (u32(half+127i)<<23u)|(lo&0x7fffffu);
}
fn ink_f32_div(a:u32,b:u32)->u32{
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(ink_f32_nan(a)||ink_f32_nan(b)||(aa==0u&&bb==0u)||(aa==0x7f800000u&&bb==aa)){return 0x7fc00000u;}
 if(aa==0x7f800000u||bb==0u){return sign|0x7f800000u;}
 if(aa==0u||bb==0x7f800000u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u))-127i;var eb=i32(max(rb,1u))-127i;
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 var e=ea-eb;if(sa<sb){sa<<=1u;e--;}
 let division=ink_u64_div(InkU64(sa<<26u,sa>>6u),InkU64(sb,0u));
 let extended=division.quotient.lo|select(0u,1u,!ink_u64_eq(division.remainder,InkU64(0u,0u)));
 return ink_f32_round(sign,e+127i,extended);
}
// mode: 0 trunc, 1 floor, 2 ceil, 3 ties-to-even.
fn ink_f32_integral(x:u32,mode:u32)->u32{
 let a=x&0x7fffffffu;let sign=x&0x80000000u;
 if(a>0x7f800000u){return 0x7fc00000u;}if(a>=0x4b000000u||a==0u){return x;}
 let e=i32((x>>23u)&255u)-127i;
 if(e<0i){var up=false;if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){up=a>0x3f000000u;}return sign|select(0u,0x3f800000u,up);}
 let shift=u32(23i-e);let mask=(1u<<shift)-1u;let fraction=a&mask;var rounded=a&~mask;var up=false;
 if(fraction!=0u){if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){let half=1u<<(shift-1u);up=fraction>half||(fraction==half&&((rounded>>shift)&1u)!=0u);}}
 if(up){rounded+=1u<<shift;}return sign|rounded;
}
fn ink_f32_from_u64(x:InkU64)->u32{
 if(ink_u64_eq(x,InkU64(0u,0u))){return 0u;}
 let leading=select(countLeadingZeros(x.lo)+32u,countLeadingZeros(x.hi),x.hi!=0u);let e=63u-leading;
 if(e<=23u){return ((e+127u)<<23u)|((x.lo<<(23u-e))&0x7fffffu);}
 let shift=e-23u;var sig=0u;var rem=InkU64(0u,0u);var half=InkU64(0u,0u);
 if(shift<32u){sig=(x.lo>>shift)|(x.hi<<(32u-shift));rem=InkU64(x.lo&((1u<<shift)-1u),0u);half=InkU64(1u<<(shift-1u),0u);}
 else if(shift==32u){sig=x.hi;rem=InkU64(x.lo,0u);half=InkU64(0x80000000u,0u);}
 else{sig=x.hi>>(shift-32u);rem=InkU64(x.lo,x.hi&((1u<<(shift-32u))-1u));half=InkU64(0u,1u<<(shift-33u));}
 if(ink_u64_lt(half,rem)||(ink_u64_eq(rem,half)&&(sig&1u)!=0u)){sig++;}
 var exponent=e+127u;if(sig==0x1000000u){sig>>=1u;exponent++;}
 return (exponent<<23u)|(sig&0x7fffffu);
}
fn ink_f32_from_i32(x:i32)->u32{let neg=x<0i;let magnitude=select(u32(x),0u-u32(x),neg);return ink_f32_from_u64(InkU64(magnitude,0u))|select(0u,0x80000000u,neg);}
struct InkBuffer_u32{data:array<u32,64>,length:u32,}
struct InkBuffer_InkU64{data:array<InkU64,64>,length:u32,}
struct InkBuffer_i32{data:array<i32,64>,length:u32,}
struct InkBuffer_bool{data:array<bool,64>,length:u32,}
struct R_MassRow{ink_f_identity:u32,ink_f_scale:u32,ink_f_bias:u32,ink_f_relu:u32,}
struct R_Parameters{ink_f_a:R_MassRow,ink_f_b:R_MassRow,ink_f_c:R_MassRow,ink_f_d:R_MassRow,}
struct R_Pick{ink_f_slot:u32,ink_f_operation:u32,}
struct R___ink_differential_2{ink_f_value:u32,ink_f_tangent_0:u32,ink_f_tangent_1:u32,ink_f_tangent_2:u32,ink_f_tangent_3:u32,ink_f_tangent_4:u32,ink_f_tangent_5:u32,ink_f_tangent_6:u32,ink_f_tangent_7:u32,ink_f_tangent_8:u32,ink_f_tangent_9:u32,ink_f_tangent_10:u32,ink_f_tangent_11:u32,ink_f_tangent_12:u32,ink_f_tangent_13:u32,ink_f_tangent_14:u32,ink_f_tangent_15:u32,}
struct R___ink_differential_4{ink_f_a:R___ink_differential_5,ink_f_b:R___ink_differential_5,ink_f_c:R___ink_differential_5,ink_f_d:R___ink_differential_5,}
struct R___ink_differential_5{ink_f_identity:R___ink_differential_2,ink_f_scale:R___ink_differential_2,ink_f_bias:R___ink_differential_2,ink_f_relu:R___ink_differential_2,}
struct R___ink_differential_6{ink_f_slot:u32,ink_f_operation:u32,}
@group(0) @binding(0) var<storage,read> a0:array<u32>;
@group(0) @binding(1) var<storage,read> a1:array<u32>;
@group(0) @binding(2) var<storage,read_write> output:array<u32>;
@compute @workgroup_size(1) fn main(@builtin(global_invocation_id) gid:vec3<u32>){
if(gid.x!=0u){return;}var t0:u32=(R___ink_differential_6(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u])).ink_f_slot;
var t1:R___ink_differential_5;
if ((t0 == 0u)) {
t1=(R___ink_differential_4(R___ink_differential_5(R___ink_differential_2(a1[0u+(0u)*272u+0u],a1[0u+(0u)*272u+1u],a1[0u+(0u)*272u+2u],a1[0u+(0u)*272u+3u],a1[0u+(0u)*272u+4u],a1[0u+(0u)*272u+5u],a1[0u+(0u)*272u+6u],a1[0u+(0u)*272u+7u],a1[0u+(0u)*272u+8u],a1[0u+(0u)*272u+9u],a1[0u+(0u)*272u+10u],a1[0u+(0u)*272u+11u],a1[0u+(0u)*272u+12u],a1[0u+(0u)*272u+13u],a1[0u+(0u)*272u+14u],a1[0u+(0u)*272u+15u],a1[0u+(0u)*272u+16u]),R___ink_differential_2(a1[0u+(0u)*272u+17u],a1[0u+(0u)*272u+18u],a1[0u+(0u)*272u+19u],a1[0u+(0u)*272u+20u],a1[0u+(0u)*272u+21u],a1[0u+(0u)*272u+22u],a1[0u+(0u)*272u+23u],a1[0u+(0u)*272u+24u],a1[0u+(0u)*272u+25u],a1[0u+(0u)*272u+26u],a1[0u+(0u)*272u+27u],a1[0u+(0u)*272u+28u],a1[0u+(0u)*272u+29u],a1[0u+(0u)*272u+30u],a1[0u+(0u)*272u+31u],a1[0u+(0u)*272u+32u],a1[0u+(0u)*272u+33u]),R___ink_differential_2(a1[0u+(0u)*272u+34u],a1[0u+(0u)*272u+35u],a1[0u+(0u)*272u+36u],a1[0u+(0u)*272u+37u],a1[0u+(0u)*272u+38u],a1[0u+(0u)*272u+39u],a1[0u+(0u)*272u+40u],a1[0u+(0u)*272u+41u],a1[0u+(0u)*272u+42u],a1[0u+(0u)*272u+43u],a1[0u+(0u)*272u+44u],a1[0u+(0u)*272u+45u],a1[0u+(0u)*272u+46u],a1[0u+(0u)*272u+47u],a1[0u+(0u)*272u+48u],a1[0u+(0u)*272u+49u],a1[0u+(0u)*272u+50u]),R___ink_differential_2(a1[0u+(0u)*272u+51u],a1[0u+(0u)*272u+52u],a1[0u+(0u)*272u+53u],a1[0u+(0u)*272u+54u],a1[0u+(0u)*272u+55u],a1[0u+(0u)*272u+56u],a1[0u+(0u)*272u+57u],a1[0u+(0u)*272u+58u],a1[0u+(0u)*272u+59u],a1[0u+(0u)*272u+60u],a1[0u+(0u)*272u+61u],a1[0u+(0u)*272u+62u],a1[0u+(0u)*272u+63u],a1[0u+(0u)*272u+64u],a1[0u+(0u)*272u+65u],a1[0u+(0u)*272u+66u],a1[0u+(0u)*272u+67u])),R___ink_differential_5(R___ink_differential_2(a1[0u+(0u)*272u+68u],a1[0u+(0u)*272u+69u],a1[0u+(0u)*272u+70u],a1[0u+(0u)*272u+71u],a1[0u+(0u)*272u+72u],a1[0u+(0u)*272u+73u],a1[0u+(0u)*272u+74u],a1[0u+(0u)*272u+75u],a1[0u+(0u)*272u+76u],a1[0u+(0u)*272u+77u],a1[0u+(0u)*272u+78u],a1[0u+(0u)*272u+79u],a1[0u+(0u)*272u+80u],a1[0u+(0u)*272u+81u],a1[0u+(0u)*272u+82u],a1[0u+(0u)*272u+83u],a1[0u+(0u)*272u+84u]),R___ink_differential_2(a1[0u+(0u)*272u+85u],a1[0u+(0u)*272u+86u],a1[0u+(0u)*272u+87u],a1[0u+(0u)*272u+88u],a1[0u+(0u)*272u+89u],a1[0u+(0u)*272u+90u],a1[0u+(0u)*272u+91u],a1[0u+(0u)*272u+92u],a1[0u+(0u)*272u+93u],a1[0u+(0u)*272u+94u],a1[0u+(0u)*272u+95u],a1[0u+(0u)*272u+96u],a1[0u+(0u)*272u+97u],a1[0u+(0u)*272u+98u],a1[0u+(0u)*272u+99u],a1[0u+(0u)*272u+100u],a1[0u+(0u)*272u+101u]),R___ink_differential_2(a1[0u+(0u)*272u+102u],a1[0u+(0u)*272u+103u],a1[0u+(0u)*272u+104u],a1[0u+(0u)*272u+105u],a1[0u+(0u)*272u+106u],a1[0u+(0u)*272u+107u],a1[0u+(0u)*272u+108u],a1[0u+(0u)*272u+109u],a1[0u+(0u)*272u+110u],a1[0u+(0u)*272u+111u],a1[0u+(0u)*272u+112u],a1[0u+(0u)*272u+113u],a1[0u+(0u)*272u+114u],a1[0u+(0u)*272u+115u],a1[0u+(0u)*272u+116u],a1[0u+(0u)*272u+117u],a1[0u+(0u)*272u+118u]),R___ink_differential_2(a1[0u+(0u)*272u+119u],a1[0u+(0u)*272u+120u],a1[0u+(0u)*272u+121u],a1[0u+(0u)*272u+122u],a1[0u+(0u)*272u+123u],a1[0u+(0u)*272u+124u],a1[0u+(0u)*272u+125u],a1[0u+(0u)*272u+126u],a1[0u+(0u)*272u+127u],a1[0u+(0u)*272u+128u],a1[0u+(0u)*272u+129u],a1[0u+(0u)*272u+130u],a1[0u+(0u)*272u+131u],a1[0u+(0u)*272u+132u],a1[0u+(0u)*272u+133u],a1[0u+(0u)*272u+134u],a1[0u+(0u)*272u+135u])),R___ink_differential_5(R___ink_differential_2(a1[0u+(0u)*272u+136u],a1[0u+(0u)*272u+137u],a1[0u+(0u)*272u+138u],a1[0u+(0u)*272u+139u],a1[0u+(0u)*272u+140u],a1[0u+(0u)*272u+141u],a1[0u+(0u)*272u+142u],a1[0u+(0u)*272u+143u],a1[0u+(0u)*272u+144u],a1[0u+(0u)*272u+145u],a1[0u+(0u)*272u+146u],a1[0u+(0u)*272u+147u],a1[0u+(0u)*272u+148u],a1[0u+(0u)*272u+149u],a1[0u+(0u)*272u+150u],a1[0u+(0u)*272u+151u],a1[0u+(0u)*272u+152u]),R___ink_differential_2(a1[0u+(0u)*272u+153u],a1[0u+(0u)*272u+154u],a1[0u+(0u)*272u+155u],a1[0u+(0u)*272u+156u],a1[0u+(0u)*272u+157u],a1[0u+(0u)*272u+158u],a1[0u+(0u)*272u+159u],a1[0u+(0u)*272u+160u],a1[0u+(0u)*272u+161u],a1[0u+(0u)*272u+162u],a1[0u+(0u)*272u+163u],a1[0u+(0u)*272u+164u],a1[0u+(0u)*272u+165u],a1[0u+(0u)*272u+166u],a1[0u+(0u)*272u+167u],a1[0u+(0u)*272u+168u],a1[0u+(0u)*272u+169u]),R___ink_differential_2(a1[0u+(0u)*272u+170u],a1[0u+(0u)*272u+171u],a1[0u+(0u)*272u+172u],a1[0u+(0u)*272u+173u],a1[0u+(0u)*272u+174u],a1[0u+(0u)*272u+175u],a1[0u+(0u)*272u+176u],a1[0u+(0u)*272u+177u],a1[0u+(0u)*272u+178u],a1[0u+(0u)*272u+179u],a1[0u+(0u)*272u+180u],a1[0u+(0u)*272u+181u],a1[0u+(0u)*272u+182u],a1[0u+(0u)*272u+183u],a1[0u+(0u)*272u+184u],a1[0u+(0u)*272u+185u],a1[0u+(0u)*272u+186u]),R___ink_differential_2(a1[0u+(0u)*272u+187u],a1[0u+(0u)*272u+188u],a1[0u+(0u)*272u+189u],a1[0u+(0u)*272u+190u],a1[0u+(0u)*272u+191u],a1[0u+(0u)*272u+192u],a1[0u+(0u)*272u+193u],a1[0u+(0u)*272u+194u],a1[0u+(0u)*272u+195u],a1[0u+(0u)*272u+196u],a1[0u+(0u)*272u+197u],a1[0u+(0u)*272u+198u],a1[0u+(0u)*272u+199u],a1[0u+(0u)*272u+200u],a1[0u+(0u)*272u+201u],a1[0u+(0u)*272u+202u],a1[0u+(0u)*272u+203u])),R___ink_differential_5(R___ink_differential_2(a1[0u+(0u)*272u+204u],a1[0u+(0u)*272u+205u],a1[0u+(0u)*272u+206u],a1[0u+(0u)*272u+207u],a1[0u+(0u)*272u+208u],a1[0u+(0u)*272u+209u],a1[0u+(0u)*272u+210u],a1[0u+(0u)*272u+211u],a1[0u+(0u)*272u+212u],a1[0u+(0u)*272u+213u],a1[0u+(0u)*272u+214u],a1[0u+(0u)*272u+215u],a1[0u+(0u)*272u+216u],a1[0u+(0u)*272u+217u],a1[0u+(0u)*272u+218u],a1[0u+(0u)*272u+219u],a1[0u+(0u)*272u+220u]),R___ink_differential_2(a1[0u+(0u)*272u+221u],a1[0u+(0u)*272u+222u],a1[0u+(0u)*272u+223u],a1[0u+(0u)*272u+224u],a1[0u+(0u)*272u+225u],a1[0u+(0u)*272u+226u],a1[0u+(0u)*272u+227u],a1[0u+(0u)*272u+228u],a1[0u+(0u)*272u+229u],a1[0u+(0u)*272u+230u],a1[0u+(0u)*272u+231u],a1[0u+(0u)*272u+232u],a1[0u+(0u)*272u+233u],a1[0u+(0u)*272u+234u],a1[0u+(0u)*272u+235u],a1[0u+(0u)*272u+236u],a1[0u+(0u)*272u+237u]),R___ink_differential_2(a1[0u+(0u)*272u+238u],a1[0u+(0u)*272u+239u],a1[0u+(0u)*272u+240u],a1[0u+(0u)*272u+241u],a1[0u+(0u)*272u+242u],a1[0u+(0u)*272u+243u],a1[0u+(0u)*272u+244u],a1[0u+(0u)*272u+245u],a1[0u+(0u)*272u+246u],a1[0u+(0u)*272u+247u],a1[0u+(0u)*272u+248u],a1[0u+(0u)*272u+249u],a1[0u+(0u)*272u+250u],a1[0u+(0u)*272u+251u],a1[0u+(0u)*272u+252u],a1[0u+(0u)*272u+253u],a1[0u+(0u)*272u+254u]),R___ink_differential_2(a1[0u+(0u)*272u+255u],a1[0u+(0u)*272u+256u],a1[0u+(0u)*272u+257u],a1[0u+(0u)*272u+258u],a1[0u+(0u)*272u+259u],a1[0u+(0u)*272u+260u],a1[0u+(0u)*272u+261u],a1[0u+(0u)*272u+262u],a1[0u+(0u)*272u+263u],a1[0u+(0u)*272u+264u],a1[0u+(0u)*272u+265u],a1[0u+(0u)*272u+266u],a1[0u+(0u)*272u+267u],a1[0u+(0u)*272u+268u],a1[0u+(0u)*272u+269u],a1[0u+(0u)*272u+270u],a1[0u+(0u)*272u+271u])))).ink_f_a;
} else {
var t2:u32=(R___ink_differential_6(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u])).ink_f_slot;
var t3:R___ink_differential_5;
if ((t2 == 1u)) {
t3=(R___ink_differential_4(R___ink_differential_5(R___ink_differential_2(a1[0u+(0u)*272u+0u],a1[0u+(0u)*272u+1u],a1[0u+(0u)*272u+2u],a1[0u+(0u)*272u+3u],a1[0u+(0u)*272u+4u],a1[0u+(0u)*272u+5u],a1[0u+(0u)*272u+6u],a1[0u+(0u)*272u+7u],a1[0u+(0u)*272u+8u],a1[0u+(0u)*272u+9u],a1[0u+(0u)*272u+10u],a1[0u+(0u)*272u+11u],a1[0u+(0u)*272u+12u],a1[0u+(0u)*272u+13u],a1[0u+(0u)*272u+14u],a1[0u+(0u)*272u+15u],a1[0u+(0u)*272u+16u]),R___ink_differential_2(a1[0u+(0u)*272u+17u],a1[0u+(0u)*272u+18u],a1[0u+(0u)*272u+19u],a1[0u+(0u)*272u+20u],a1[0u+(0u)*272u+21u],a1[0u+(0u)*272u+22u],a1[0u+(0u)*272u+23u],a1[0u+(0u)*272u+24u],a1[0u+(0u)*272u+25u],a1[0u+(0u)*272u+26u],a1[0u+(0u)*272u+27u],a1[0u+(0u)*272u+28u],a1[0u+(0u)*272u+29u],a1[0u+(0u)*272u+30u],a1[0u+(0u)*272u+31u],a1[0u+(0u)*272u+32u],a1[0u+(0u)*272u+33u]),R___ink_differential_2(a1[0u+(0u)*272u+34u],a1[0u+(0u)*272u+35u],a1[0u+(0u)*272u+36u],a1[0u+(0u)*272u+37u],a1[0u+(0u)*272u+38u],a1[0u+(0u)*272u+39u],a1[0u+(0u)*272u+40u],a1[0u+(0u)*272u+41u],a1[0u+(0u)*272u+42u],a1[0u+(0u)*272u+43u],a1[0u+(0u)*272u+44u],a1[0u+(0u)*272u+45u],a1[0u+(0u)*272u+46u],a1[0u+(0u)*272u+47u],a1[0u+(0u)*272u+48u],a1[0u+(0u)*272u+49u],a1[0u+(0u)*272u+50u]),R___ink_differential_2(a1[0u+(0u)*272u+51u],a1[0u+(0u)*272u+52u],a1[0u+(0u)*272u+53u],a1[0u+(0u)*272u+54u],a1[0u+(0u)*272u+55u],a1[0u+(0u)*272u+56u],a1[0u+(0u)*272u+57u],a1[0u+(0u)*272u+58u],a1[0u+(0u)*272u+59u],a1[0u+(0u)*272u+60u],a1[0u+(0u)*272u+61u],a1[0u+(0u)*272u+62u],a1[0u+(0u)*272u+63u],a1[0u+(0u)*272u+64u],a1[0u+(0u)*272u+65u],a1[0u+(0u)*272u+66u],a1[0u+(0u)*272u+67u])),R___ink_differential_5(R___ink_differential_2(a1[0u+(0u)*272u+68u],a1[0u+(0u)*272u+69u],a1[0u+(0u)*272u+70u],a1[0u+(0u)*272u+71u],a1[0u+(0u)*272u+72u],a1[0u+(0u)*272u+73u],a1[0u+(0u)*272u+74u],a1[0u+(0u)*272u+75u],a1[0u+(0u)*272u+76u],a1[0u+(0u)*272u+77u],a1[0u+(0u)*272u+78u],a1[0u+(0u)*272u+79u],a1[0u+(0u)*272u+80u],a1[0u+(0u)*272u+81u],a1[0u+(0u)*272u+82u],a1[0u+(0u)*272u+83u],a1[0u+(0u)*272u+84u]),R___ink_differential_2(a1[0u+(0u)*272u+85u],a1[0u+(0u)*272u+86u],a1[0u+(0u)*272u+87u],a1[0u+(0u)*272u+88u],a1[0u+(0u)*272u+89u],a1[0u+(0u)*272u+90u],a1[0u+(0u)*272u+91u],a1[0u+(0u)*272u+92u],a1[0u+(0u)*272u+93u],a1[0u+(0u)*272u+94u],a1[0u+(0u)*272u+95u],a1[0u+(0u)*272u+96u],a1[0u+(0u)*272u+97u],a1[0u+(0u)*272u+98u],a1[0u+(0u)*272u+99u],a1[0u+(0u)*272u+100u],a1[0u+(0u)*272u+101u]),R___ink_differential_2(a1[0u+(0u)*272u+102u],a1[0u+(0u)*272u+103u],a1[0u+(0u)*272u+104u],a1[0u+(0u)*272u+105u],a1[0u+(0u)*272u+106u],a1[0u+(0u)*272u+107u],a1[0u+(0u)*272u+108u],a1[0u+(0u)*272u+109u],a1[0u+(0u)*272u+110u],a1[0u+(0u)*272u+111u],a1[0u+(0u)*272u+112u],a1[0u+(0u)*272u+113u],a1[0u+(0u)*272u+114u],a1[0u+(0u)*272u+115u],a1[0u+(0u)*272u+116u],a1[0u+(0u)*272u+117u],a1[0u+(0u)*272u+118u]),R___ink_differential_2(a1[0u+(0u)*272u+119u],a1[0u+(0u)*272u+120u],a1[0u+(0u)*272u+121u],a1[0u+(0u)*272u+122u],a1[0u+(0u)*272u+123u],a1[0u+(0u)*272u+124u],a1[0u+(0u)*272u+125u],a1[0u+(0u)*272u+126u],a1[0u+(0u)*272u+127u],a1[0u+(0u)*272u+128u],a1[0u+(0u)*272u+129u],a1[0u+(0u)*272u+130u],a1[0u+(0u)*272u+131u],a1[0u+(0u)*272u+132u],a1[0u+(0u)*272u+133u],a1[0u+(0u)*272u+134u],a1[0u+(0u)*272u+135u])),R___ink_differential_5(R___ink_differential_2(a1[0u+(0u)*272u+136u],a1[0u+(0u)*272u+137u],a1[0u+(0u)*272u+138u],a1[0u+(0u)*272u+139u],a1[0u+(0u)*272u+140u],a1[0u+(0u)*272u+141u],a1[0u+(0u)*272u+142u],a1[0u+(0u)*272u+143u],a1[0u+(0u)*272u+144u],a1[0u+(0u)*272u+145u],a1[0u+(0u)*272u+146u],a1[0u+(0u)*272u+147u],a1[0u+(0u)*272u+148u],a1[0u+(0u)*272u+149u],a1[0u+(0u)*272u+150u],a1[0u+(0u)*272u+151u],a1[0u+(0u)*272u+152u]),R___ink_differential_2(a1[0u+(0u)*272u+153u],a1[0u+(0u)*272u+154u],a1[0u+(0u)*272u+155u],a1[0u+(0u)*272u+156u],a1[0u+(0u)*272u+157u],a1[0u+(0u)*272u+158u],a1[0u+(0u)*272u+159u],a1[0u+(0u)*272u+160u],a1[0u+(0u)*272u+161u],a1[0u+(0u)*272u+162u],a1[0u+(0u)*272u+163u],a1[0u+(0u)*272u+164u],a1[0u+(0u)*272u+165u],a1[0u+(0u)*272u+166u],a1[0u+(0u)*272u+167u],a1[0u+(0u)*272u+168u],a1[0u+(0u)*272u+169u]),R___ink_differential_2(a1[0u+(0u)*272u+170u],a1[0u+(0u)*272u+171u],a1[0u+(0u)*272u+172u],a1[0u+(0u)*272u+173u],a1[0u+(0u)*272u+174u],a1[0u+(0u)*272u+175u],a1[0u+(0u)*272u+176u],a1[0u+(0u)*272u+177u],a1[0u+(0u)*272u+178u],a1[0u+(0u)*272u+179u],a1[0u+(0u)*272u+180u],a1[0u+(0u)*272u+181u],a1[0u+(0u)*272u+182u],a1[0u+(0u)*272u+183u],a1[0u+(0u)*272u+184u],a1[0u+(0u)*272u+185u],a1[0u+(0u)*272u+186u]),R___ink_differential_2(a1[0u+(0u)*272u+187u],a1[0u+(0u)*272u+188u],a1[0u+(0u)*272u+189u],a1[0u+(0u)*272u+190u],a1[0u+(0u)*272u+191u],a1[0u+(0u)*272u+192u],a1[0u+(0u)*272u+193u],a1[0u+(0u)*272u+194u],a1[0u+(0u)*272u+195u],a1[0u+(0u)*272u+196u],a1[0u+(0u)*272u+197u],a1[0u+(0u)*272u+198u],a1[0u+(0u)*272u+199u],a1[0u+(0u)*272u+200u],a1[0u+(0u)*272u+201u],a1[0u+(0u)*272u+202u],a1[0u+(0u)*272u+203u])),R___ink_differential_5(R___ink_differential_2(a1[0u+(0u)*272u+204u],a1[0u+(0u)*272u+205u],a1[0u+(0u)*272u+206u],a1[0u+(0u)*272u+207u],a1[0u+(0u)*272u+208u],a1[0u+(0u)*272u+209u],a1[0u+(0u)*272u+210u],a1[0u+(0u)*272u+211u],a1[0u+(0u)*272u+212u],a1[0u+(0u)*272u+213u],a1[0u+(0u)*272u+214u],a1[0u+(0u)*272u+215u],a1[0u+(0u)*272u+216u],a1[0u+(0u)*272u+217u],a1[0u+(0u)*272u+218u],a1[0u+(0u)*272u+219u],a1[0u+(0u)*272u+220u]),R___ink_differential_2(a1[0u+(0u)*272u+221u],a1[0u+(0u)*272u+222u],a1[0u+(0u)*272u+223u],a1[0u+(0u)*272u+224u],a1[0u+(0u)*272u+225u],a1[0u+(0u)*272u+226u],a1[0u+(0u)*272u+227u],a1[0u+(0u)*272u+228u],a1[0u+(0u)*272u+229u],a1[0u+(0u)*272u+230u],a1[0u+(0u)*272u+231u],a1[0u+(0u)*272u+232u],a1[0u+(0u)*272u+233u],a1[0u+(0u)*272u+234u],a1[0u+(0u)*272u+235u],a1[0u+(0u)*272u+236u],a1[0u+(0u)*272u+237u]),R___ink_differential_2(a1[0u+(0u)*272u+238u],a1[0u+(0u)*272u+239u],a1[0u+(0u)*272u+240u],a1[0u+(0u)*272u+241u],a1[0u+(0u)*272u+242u],a1[0u+(0u)*272u+243u],a1[0u+(0u)*272u+244u],a1[0u+(0u)*272u+245u],a1[0u+(0u)*272u+246u],a1[0u+(0u)*272u+247u],a1[0u+(0u)*272u+248u],a1[0u+(0u)*272u+249u],a1[0u+(0u)*272u+250u],a1[0u+(0u)*272u+251u],a1[0u+(0u)*272u+252u],a1[0u+(0u)*272u+253u],a1[0u+(0u)*272u+254u]),R___ink_differential_2(a1[0u+(0u)*272u+255u],a1[0u+(0u)*272u+256u],a1[0u+(0u)*272u+257u],a1[0u+(0u)*272u+258u],a1[0u+(0u)*272u+259u],a1[0u+(0u)*272u+260u],a1[0u+(0u)*272u+261u],a1[0u+(0u)*272u+262u],a1[0u+(0u)*272u+263u],a1[0u+(0u)*272u+264u],a1[0u+(0u)*272u+265u],a1[0u+(0u)*272u+266u],a1[0u+(0u)*272u+267u],a1[0u+(0u)*272u+268u],a1[0u+(0u)*272u+269u],a1[0u+(0u)*272u+270u],a1[0u+(0u)*272u+271u])))).ink_f_b;
} else {
var t4:u32=(R___ink_differential_6(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u])).ink_f_slot;
var t5:R___ink_differential_5;
if ((t4 == 2u)) {
t5=(R___ink_differential_4(R___ink_differential_5(R___ink_differential_2(a1[0u+(0u)*272u+0u],a1[0u+(0u)*272u+1u],a1[0u+(0u)*272u+2u],a1[0u+(0u)*272u+3u],a1[0u+(0u)*272u+4u],a1[0u+(0u)*272u+5u],a1[0u+(0u)*272u+6u],a1[0u+(0u)*272u+7u],a1[0u+(0u)*272u+8u],a1[0u+(0u)*272u+9u],a1[0u+(0u)*272u+10u],a1[0u+(0u)*272u+11u],a1[0u+(0u)*272u+12u],a1[0u+(0u)*272u+13u],a1[0u+(0u)*272u+14u],a1[0u+(0u)*272u+15u],a1[0u+(0u)*272u+16u]),R___ink_differential_2(a1[0u+(0u)*272u+17u],a1[0u+(0u)*272u+18u],a1[0u+(0u)*272u+19u],a1[0u+(0u)*272u+20u],a1[0u+(0u)*272u+21u],a1[0u+(0u)*272u+22u],a1[0u+(0u)*272u+23u],a1[0u+(0u)*272u+24u],a1[0u+(0u)*272u+25u],a1[0u+(0u)*272u+26u],a1[0u+(0u)*272u+27u],a1[0u+(0u)*272u+28u],a1[0u+(0u)*272u+29u],a1[0u+(0u)*272u+30u],a1[0u+(0u)*272u+31u],a1[0u+(0u)*272u+32u],a1[0u+(0u)*272u+33u]),R___ink_differential_2(a1[0u+(0u)*272u+34u],a1[0u+(0u)*272u+35u],a1[0u+(0u)*272u+36u],a1[0u+(0u)*272u+37u],a1[0u+(0u)*272u+38u],a1[0u+(0u)*272u+39u],a1[0u+(0u)*272u+40u],a1[0u+(0u)*272u+41u],a1[0u+(0u)*272u+42u],a1[0u+(0u)*272u+43u],a1[0u+(0u)*272u+44u],a1[0u+(0u)*272u+45u],a1[0u+(0u)*272u+46u],a1[0u+(0u)*272u+47u],a1[0u+(0u)*272u+48u],a1[0u+(0u)*272u+49u],a1[0u+(0u)*272u+50u]),R___ink_differential_2(a1[0u+(0u)*272u+51u],a1[0u+(0u)*272u+52u],a1[0u+(0u)*272u+53u],a1[0u+(0u)*272u+54u],a1[0u+(0u)*272u+55u],a1[0u+(0u)*272u+56u],a1[0u+(0u)*272u+57u],a1[0u+(0u)*272u+58u],a1[0u+(0u)*272u+59u],a1[0u+(0u)*272u+60u],a1[0u+(0u)*272u+61u],a1[0u+(0u)*272u+62u],a1[0u+(0u)*272u+63u],a1[0u+(0u)*272u+64u],a1[0u+(0u)*272u+65u],a1[0u+(0u)*272u+66u],a1[0u+(0u)*272u+67u])),R___ink_differential_5(R___ink_differential_2(a1[0u+(0u)*272u+68u],a1[0u+(0u)*272u+69u],a1[0u+(0u)*272u+70u],a1[0u+(0u)*272u+71u],a1[0u+(0u)*272u+72u],a1[0u+(0u)*272u+73u],a1[0u+(0u)*272u+74u],a1[0u+(0u)*272u+75u],a1[0u+(0u)*272u+76u],a1[0u+(0u)*272u+77u],a1[0u+(0u)*272u+78u],a1[0u+(0u)*272u+79u],a1[0u+(0u)*272u+80u],a1[0u+(0u)*272u+81u],a1[0u+(0u)*272u+82u],a1[0u+(0u)*272u+83u],a1[0u+(0u)*272u+84u]),R___ink_differential_2(a1[0u+(0u)*272u+85u],a1[0u+(0u)*272u+86u],a1[0u+(0u)*272u+87u],a1[0u+(0u)*272u+88u],a1[0u+(0u)*272u+89u],a1[0u+(0u)*272u+90u],a1[0u+(0u)*272u+91u],a1[0u+(0u)*272u+92u],a1[0u+(0u)*272u+93u],a1[0u+(0u)*272u+94u],a1[0u+(0u)*272u+95u],a1[0u+(0u)*272u+96u],a1[0u+(0u)*272u+97u],a1[0u+(0u)*272u+98u],a1[0u+(0u)*272u+99u],a1[0u+(0u)*272u+100u],a1[0u+(0u)*272u+101u]),R___ink_differential_2(a1[0u+(0u)*272u+102u],a1[0u+(0u)*272u+103u],a1[0u+(0u)*272u+104u],a1[0u+(0u)*272u+105u],a1[0u+(0u)*272u+106u],a1[0u+(0u)*272u+107u],a1[0u+(0u)*272u+108u],a1[0u+(0u)*272u+109u],a1[0u+(0u)*272u+110u],a1[0u+(0u)*272u+111u],a1[0u+(0u)*272u+112u],a1[0u+(0u)*272u+113u],a1[0u+(0u)*272u+114u],a1[0u+(0u)*272u+115u],a1[0u+(0u)*272u+116u],a1[0u+(0u)*272u+117u],a1[0u+(0u)*272u+118u]),R___ink_differential_2(a1[0u+(0u)*272u+119u],a1[0u+(0u)*272u+120u],a1[0u+(0u)*272u+121u],a1[0u+(0u)*272u+122u],a1[0u+(0u)*272u+123u],a1[0u+(0u)*272u+124u],a1[0u+(0u)*272u+125u],a1[0u+(0u)*272u+126u],a1[0u+(0u)*272u+127u],a1[0u+(0u)*272u+128u],a1[0u+(0u)*272u+129u],a1[0u+(0u)*272u+130u],a1[0u+(0u)*272u+131u],a1[0u+(0u)*272u+132u],a1[0u+(0u)*272u+133u],a1[0u+(0u)*272u+134u],a1[0u+(0u)*272u+135u])),R___ink_differential_5(R___ink_differential_2(a1[0u+(0u)*272u+136u],a1[0u+(0u)*272u+137u],a1[0u+(0u)*272u+138u],a1[0u+(0u)*272u+139u],a1[0u+(0u)*272u+140u],a1[0u+(0u)*272u+141u],a1[0u+(0u)*272u+142u],a1[0u+(0u)*272u+143u],a1[0u+(0u)*272u+144u],a1[0u+(0u)*272u+145u],a1[0u+(0u)*272u+146u],a1[0u+(0u)*272u+147u],a1[0u+(0u)*272u+148u],a1[0u+(0u)*272u+149u],a1[0u+(0u)*272u+150u],a1[0u+(0u)*272u+151u],a1[0u+(0u)*272u+152u]),R___ink_differential_2(a1[0u+(0u)*272u+153u],a1[0u+(0u)*272u+154u],a1[0u+(0u)*272u+155u],a1[0u+(0u)*272u+156u],a1[0u+(0u)*272u+157u],a1[0u+(0u)*272u+158u],a1[0u+(0u)*272u+159u],a1[0u+(0u)*272u+160u],a1[0u+(0u)*272u+161u],a1[0u+(0u)*272u+162u],a1[0u+(0u)*272u+163u],a1[0u+(0u)*272u+164u],a1[0u+(0u)*272u+165u],a1[0u+(0u)*272u+166u],a1[0u+(0u)*272u+167u],a1[0u+(0u)*272u+168u],a1[0u+(0u)*272u+169u]),R___ink_differential_2(a1[0u+(0u)*272u+170u],a1[0u+(0u)*272u+171u],a1[0u+(0u)*272u+172u],a1[0u+(0u)*272u+173u],a1[0u+(0u)*272u+174u],a1[0u+(0u)*272u+175u],a1[0u+(0u)*272u+176u],a1[0u+(0u)*272u+177u],a1[0u+(0u)*272u+178u],a1[0u+(0u)*272u+179u],a1[0u+(0u)*272u+180u],a1[0u+(0u)*272u+181u],a1[0u+(0u)*272u+182u],a1[0u+(0u)*272u+183u],a1[0u+(0u)*272u+184u],a1[0u+(0u)*272u+185u],a1[0u+(0u)*272u+186u]),R___ink_differential_2(a1[0u+(0u)*272u+187u],a1[0u+(0u)*272u+188u],a1[0u+(0u)*272u+189u],a1[0u+(0u)*272u+190u],a1[0u+(0u)*272u+191u],a1[0u+(0u)*272u+192u],a1[0u+(0u)*272u+193u],a1[0u+(0u)*272u+194u],a1[0u+(0u)*272u+195u],a1[0u+(0u)*272u+196u],a1[0u+(0u)*272u+197u],a1[0u+(0u)*272u+198u],a1[0u+(0u)*272u+199u],a1[0u+(0u)*272u+200u],a1[0u+(0u)*272u+201u],a1[0u+(0u)*272u+202u],a1[0u+(0u)*272u+203u])),R___ink_differential_5(R___ink_differential_2(a1[0u+(0u)*272u+204u],a1[0u+(0u)*272u+205u],a1[0u+(0u)*272u+206u],a1[0u+(0u)*272u+207u],a1[0u+(0u)*272u+208u],a1[0u+(0u)*272u+209u],a1[0u+(0u)*272u+210u],a1[0u+(0u)*272u+211u],a1[0u+(0u)*272u+212u],a1[0u+(0u)*272u+213u],a1[0u+(0u)*272u+214u],a1[0u+(0u)*272u+215u],a1[0u+(0u)*272u+216u],a1[0u+(0u)*272u+217u],a1[0u+(0u)*272u+218u],a1[0u+(0u)*272u+219u],a1[0u+(0u)*272u+220u]),R___ink_differential_2(a1[0u+(0u)*272u+221u],a1[0u+(0u)*272u+222u],a1[0u+(0u)*272u+223u],a1[0u+(0u)*272u+224u],a1[0u+(0u)*272u+225u],a1[0u+(0u)*272u+226u],a1[0u+(0u)*272u+227u],a1[0u+(0u)*272u+228u],a1[0u+(0u)*272u+229u],a1[0u+(0u)*272u+230u],a1[0u+(0u)*272u+231u],a1[0u+(0u)*272u+232u],a1[0u+(0u)*272u+233u],a1[0u+(0u)*272u+234u],a1[0u+(0u)*272u+235u],a1[0u+(0u)*272u+236u],a1[0u+(0u)*272u+237u]),R___ink_differential_2(a1[0u+(0u)*272u+238u],a1[0u+(0u)*272u+239u],a1[0u+(0u)*272u+240u],a1[0u+(0u)*272u+241u],a1[0u+(0u)*272u+242u],a1[0u+(0u)*272u+243u],a1[0u+(0u)*272u+244u],a1[0u+(0u)*272u+245u],a1[0u+(0u)*272u+246u],a1[0u+(0u)*272u+247u],a1[0u+(0u)*272u+248u],a1[0u+(0u)*272u+249u],a1[0u+(0u)*272u+250u],a1[0u+(0u)*272u+251u],a1[0u+(0u)*272u+252u],a1[0u+(0u)*272u+253u],a1[0u+(0u)*272u+254u]),R___ink_differential_2(a1[0u+(0u)*272u+255u],a1[0u+(0u)*272u+256u],a1[0u+(0u)*272u+257u],a1[0u+(0u)*272u+258u],a1[0u+(0u)*272u+259u],a1[0u+(0u)*272u+260u],a1[0u+(0u)*272u+261u],a1[0u+(0u)*272u+262u],a1[0u+(0u)*272u+263u],a1[0u+(0u)*272u+264u],a1[0u+(0u)*272u+265u],a1[0u+(0u)*272u+266u],a1[0u+(0u)*272u+267u],a1[0u+(0u)*272u+268u],a1[0u+(0u)*272u+269u],a1[0u+(0u)*272u+270u],a1[0u+(0u)*272u+271u])))).ink_f_c;
} else {
t5=(R___ink_differential_4(R___ink_differential_5(R___ink_differential_2(a1[0u+(0u)*272u+0u],a1[0u+(0u)*272u+1u],a1[0u+(0u)*272u+2u],a1[0u+(0u)*272u+3u],a1[0u+(0u)*272u+4u],a1[0u+(0u)*272u+5u],a1[0u+(0u)*272u+6u],a1[0u+(0u)*272u+7u],a1[0u+(0u)*272u+8u],a1[0u+(0u)*272u+9u],a1[0u+(0u)*272u+10u],a1[0u+(0u)*272u+11u],a1[0u+(0u)*272u+12u],a1[0u+(0u)*272u+13u],a1[0u+(0u)*272u+14u],a1[0u+(0u)*272u+15u],a1[0u+(0u)*272u+16u]),R___ink_differential_2(a1[0u+(0u)*272u+17u],a1[0u+(0u)*272u+18u],a1[0u+(0u)*272u+19u],a1[0u+(0u)*272u+20u],a1[0u+(0u)*272u+21u],a1[0u+(0u)*272u+22u],a1[0u+(0u)*272u+23u],a1[0u+(0u)*272u+24u],a1[0u+(0u)*272u+25u],a1[0u+(0u)*272u+26u],a1[0u+(0u)*272u+27u],a1[0u+(0u)*272u+28u],a1[0u+(0u)*272u+29u],a1[0u+(0u)*272u+30u],a1[0u+(0u)*272u+31u],a1[0u+(0u)*272u+32u],a1[0u+(0u)*272u+33u]),R___ink_differential_2(a1[0u+(0u)*272u+34u],a1[0u+(0u)*272u+35u],a1[0u+(0u)*272u+36u],a1[0u+(0u)*272u+37u],a1[0u+(0u)*272u+38u],a1[0u+(0u)*272u+39u],a1[0u+(0u)*272u+40u],a1[0u+(0u)*272u+41u],a1[0u+(0u)*272u+42u],a1[0u+(0u)*272u+43u],a1[0u+(0u)*272u+44u],a1[0u+(0u)*272u+45u],a1[0u+(0u)*272u+46u],a1[0u+(0u)*272u+47u],a1[0u+(0u)*272u+48u],a1[0u+(0u)*272u+49u],a1[0u+(0u)*272u+50u]),R___ink_differential_2(a1[0u+(0u)*272u+51u],a1[0u+(0u)*272u+52u],a1[0u+(0u)*272u+53u],a1[0u+(0u)*272u+54u],a1[0u+(0u)*272u+55u],a1[0u+(0u)*272u+56u],a1[0u+(0u)*272u+57u],a1[0u+(0u)*272u+58u],a1[0u+(0u)*272u+59u],a1[0u+(0u)*272u+60u],a1[0u+(0u)*272u+61u],a1[0u+(0u)*272u+62u],a1[0u+(0u)*272u+63u],a1[0u+(0u)*272u+64u],a1[0u+(0u)*272u+65u],a1[0u+(0u)*272u+66u],a1[0u+(0u)*272u+67u])),R___ink_differential_5(R___ink_differential_2(a1[0u+(0u)*272u+68u],a1[0u+(0u)*272u+69u],a1[0u+(0u)*272u+70u],a1[0u+(0u)*272u+71u],a1[0u+(0u)*272u+72u],a1[0u+(0u)*272u+73u],a1[0u+(0u)*272u+74u],a1[0u+(0u)*272u+75u],a1[0u+(0u)*272u+76u],a1[0u+(0u)*272u+77u],a1[0u+(0u)*272u+78u],a1[0u+(0u)*272u+79u],a1[0u+(0u)*272u+80u],a1[0u+(0u)*272u+81u],a1[0u+(0u)*272u+82u],a1[0u+(0u)*272u+83u],a1[0u+(0u)*272u+84u]),R___ink_differential_2(a1[0u+(0u)*272u+85u],a1[0u+(0u)*272u+86u],a1[0u+(0u)*272u+87u],a1[0u+(0u)*272u+88u],a1[0u+(0u)*272u+89u],a1[0u+(0u)*272u+90u],a1[0u+(0u)*272u+91u],a1[0u+(0u)*272u+92u],a1[0u+(0u)*272u+93u],a1[0u+(0u)*272u+94u],a1[0u+(0u)*272u+95u],a1[0u+(0u)*272u+96u],a1[0u+(0u)*272u+97u],a1[0u+(0u)*272u+98u],a1[0u+(0u)*272u+99u],a1[0u+(0u)*272u+100u],a1[0u+(0u)*272u+101u]),R___ink_differential_2(a1[0u+(0u)*272u+102u],a1[0u+(0u)*272u+103u],a1[0u+(0u)*272u+104u],a1[0u+(0u)*272u+105u],a1[0u+(0u)*272u+106u],a1[0u+(0u)*272u+107u],a1[0u+(0u)*272u+108u],a1[0u+(0u)*272u+109u],a1[0u+(0u)*272u+110u],a1[0u+(0u)*272u+111u],a1[0u+(0u)*272u+112u],a1[0u+(0u)*272u+113u],a1[0u+(0u)*272u+114u],a1[0u+(0u)*272u+115u],a1[0u+(0u)*272u+116u],a1[0u+(0u)*272u+117u],a1[0u+(0u)*272u+118u]),R___ink_differential_2(a1[0u+(0u)*272u+119u],a1[0u+(0u)*272u+120u],a1[0u+(0u)*272u+121u],a1[0u+(0u)*272u+122u],a1[0u+(0u)*272u+123u],a1[0u+(0u)*272u+124u],a1[0u+(0u)*272u+125u],a1[0u+(0u)*272u+126u],a1[0u+(0u)*272u+127u],a1[0u+(0u)*272u+128u],a1[0u+(0u)*272u+129u],a1[0u+(0u)*272u+130u],a1[0u+(0u)*272u+131u],a1[0u+(0u)*272u+132u],a1[0u+(0u)*272u+133u],a1[0u+(0u)*272u+134u],a1[0u+(0u)*272u+135u])),R___ink_differential_5(R___ink_differential_2(a1[0u+(0u)*272u+136u],a1[0u+(0u)*272u+137u],a1[0u+(0u)*272u+138u],a1[0u+(0u)*272u+139u],a1[0u+(0u)*272u+140u],a1[0u+(0u)*272u+141u],a1[0u+(0u)*272u+142u],a1[0u+(0u)*272u+143u],a1[0u+(0u)*272u+144u],a1[0u+(0u)*272u+145u],a1[0u+(0u)*272u+146u],a1[0u+(0u)*272u+147u],a1[0u+(0u)*272u+148u],a1[0u+(0u)*272u+149u],a1[0u+(0u)*272u+150u],a1[0u+(0u)*272u+151u],a1[0u+(0u)*272u+152u]),R___ink_differential_2(a1[0u+(0u)*272u+153u],a1[0u+(0u)*272u+154u],a1[0u+(0u)*272u+155u],a1[0u+(0u)*272u+156u],a1[0u+(0u)*272u+157u],a1[0u+(0u)*272u+158u],a1[0u+(0u)*272u+159u],a1[0u+(0u)*272u+160u],a1[0u+(0u)*272u+161u],a1[0u+(0u)*272u+162u],a1[0u+(0u)*272u+163u],a1[0u+(0u)*272u+164u],a1[0u+(0u)*272u+165u],a1[0u+(0u)*272u+166u],a1[0u+(0u)*272u+167u],a1[0u+(0u)*272u+168u],a1[0u+(0u)*272u+169u]),R___ink_differential_2(a1[0u+(0u)*272u+170u],a1[0u+(0u)*272u+171u],a1[0u+(0u)*272u+172u],a1[0u+(0u)*272u+173u],a1[0u+(0u)*272u+174u],a1[0u+(0u)*272u+175u],a1[0u+(0u)*272u+176u],a1[0u+(0u)*272u+177u],a1[0u+(0u)*272u+178u],a1[0u+(0u)*272u+179u],a1[0u+(0u)*272u+180u],a1[0u+(0u)*272u+181u],a1[0u+(0u)*272u+182u],a1[0u+(0u)*272u+183u],a1[0u+(0u)*272u+184u],a1[0u+(0u)*272u+185u],a1[0u+(0u)*272u+186u]),R___ink_differential_2(a1[0u+(0u)*272u+187u],a1[0u+(0u)*272u+188u],a1[0u+(0u)*272u+189u],a1[0u+(0u)*272u+190u],a1[0u+(0u)*272u+191u],a1[0u+(0u)*272u+192u],a1[0u+(0u)*272u+193u],a1[0u+(0u)*272u+194u],a1[0u+(0u)*272u+195u],a1[0u+(0u)*272u+196u],a1[0u+(0u)*272u+197u],a1[0u+(0u)*272u+198u],a1[0u+(0u)*272u+199u],a1[0u+(0u)*272u+200u],a1[0u+(0u)*272u+201u],a1[0u+(0u)*272u+202u],a1[0u+(0u)*272u+203u])),R___ink_differential_5(R___ink_differential_2(a1[0u+(0u)*272u+204u],a1[0u+(0u)*272u+205u],a1[0u+(0u)*272u+206u],a1[0u+(0u)*272u+207u],a1[0u+(0u)*272u+208u],a1[0u+(0u)*272u+209u],a1[0u+(0u)*272u+210u],a1[0u+(0u)*272u+211u],a1[0u+(0u)*272u+212u],a1[0u+(0u)*272u+213u],a1[0u+(0u)*272u+214u],a1[0u+(0u)*272u+215u],a1[0u+(0u)*272u+216u],a1[0u+(0u)*272u+217u],a1[0u+(0u)*272u+218u],a1[0u+(0u)*272u+219u],a1[0u+(0u)*272u+220u]),R___ink_differential_2(a1[0u+(0u)*272u+221u],a1[0u+(0u)*272u+222u],a1[0u+(0u)*272u+223u],a1[0u+(0u)*272u+224u],a1[0u+(0u)*272u+225u],a1[0u+(0u)*272u+226u],a1[0u+(0u)*272u+227u],a1[0u+(0u)*272u+228u],a1[0u+(0u)*272u+229u],a1[0u+(0u)*272u+230u],a1[0u+(0u)*272u+231u],a1[0u+(0u)*272u+232u],a1[0u+(0u)*272u+233u],a1[0u+(0u)*272u+234u],a1[0u+(0u)*272u+235u],a1[0u+(0u)*272u+236u],a1[0u+(0u)*272u+237u]),R___ink_differential_2(a1[0u+(0u)*272u+238u],a1[0u+(0u)*272u+239u],a1[0u+(0u)*272u+240u],a1[0u+(0u)*272u+241u],a1[0u+(0u)*272u+242u],a1[0u+(0u)*272u+243u],a1[0u+(0u)*272u+244u],a1[0u+(0u)*272u+245u],a1[0u+(0u)*272u+246u],a1[0u+(0u)*272u+247u],a1[0u+(0u)*272u+248u],a1[0u+(0u)*272u+249u],a1[0u+(0u)*272u+250u],a1[0u+(0u)*272u+251u],a1[0u+(0u)*272u+252u],a1[0u+(0u)*272u+253u],a1[0u+(0u)*272u+254u]),R___ink_differential_2(a1[0u+(0u)*272u+255u],a1[0u+(0u)*272u+256u],a1[0u+(0u)*272u+257u],a1[0u+(0u)*272u+258u],a1[0u+(0u)*272u+259u],a1[0u+(0u)*272u+260u],a1[0u+(0u)*272u+261u],a1[0u+(0u)*272u+262u],a1[0u+(0u)*272u+263u],a1[0u+(0u)*272u+264u],a1[0u+(0u)*272u+265u],a1[0u+(0u)*272u+266u],a1[0u+(0u)*272u+267u],a1[0u+(0u)*272u+268u],a1[0u+(0u)*272u+269u],a1[0u+(0u)*272u+270u],a1[0u+(0u)*272u+271u])))).ink_f_d;
}
t3=t5;
}
t1=t3;
}
var t6:R___ink_differential_5=t1;
var t7:u32=(R___ink_differential_6(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u])).ink_f_operation;
var t8:R___ink_differential_2;
if ((t7 == 0u)) {
t8=(t6).ink_f_identity;
} else {
var t9:u32=(R___ink_differential_6(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u])).ink_f_operation;
var t10:R___ink_differential_2;
if ((t9 == 1u)) {
t10=(t6).ink_f_scale;
} else {
var t11:u32=(R___ink_differential_6(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u])).ink_f_operation;
var t12:R___ink_differential_2;
if ((t11 == 2u)) {
t12=(t6).ink_f_bias;
} else {
t12=(t6).ink_f_relu;
}
t10=t12;
}
t8=t10;
}
var t13:R___ink_differential_2=t8;
var t14:R___ink_differential_2=t13;
var t15:R___ink_differential_2=t13;
var t16:u32=(t14).ink_f_value;
var t17:u32=ink_f32_mul(t16,(t15).ink_f_value);
var t18:u32=t17;
var t19:u32=(t14).ink_f_tangent_0;
var t20:u32=ink_f32_mul(t19,(t15).ink_f_value);
var t21:u32=(t14).ink_f_value;
var t22:u32=ink_f32_add(t20,ink_f32_mul(t21,(t15).ink_f_tangent_0));
var t23:u32=(t14).ink_f_tangent_1;
var t24:u32=ink_f32_mul(t23,(t15).ink_f_value);
var t25:u32=(t14).ink_f_value;
var t26:u32=ink_f32_add(t24,ink_f32_mul(t25,(t15).ink_f_tangent_1));
var t27:u32=(t14).ink_f_tangent_2;
var t28:u32=ink_f32_mul(t27,(t15).ink_f_value);
var t29:u32=(t14).ink_f_value;
var t30:u32=ink_f32_add(t28,ink_f32_mul(t29,(t15).ink_f_tangent_2));
var t31:u32=(t14).ink_f_tangent_3;
var t32:u32=ink_f32_mul(t31,(t15).ink_f_value);
var t33:u32=(t14).ink_f_value;
var t34:u32=ink_f32_add(t32,ink_f32_mul(t33,(t15).ink_f_tangent_3));
var t35:u32=(t14).ink_f_tangent_4;
var t36:u32=ink_f32_mul(t35,(t15).ink_f_value);
var t37:u32=(t14).ink_f_value;
var t38:u32=ink_f32_add(t36,ink_f32_mul(t37,(t15).ink_f_tangent_4));
var t39:u32=(t14).ink_f_tangent_5;
var t40:u32=ink_f32_mul(t39,(t15).ink_f_value);
var t41:u32=(t14).ink_f_value;
var t42:u32=ink_f32_add(t40,ink_f32_mul(t41,(t15).ink_f_tangent_5));
var t43:u32=(t14).ink_f_tangent_6;
var t44:u32=ink_f32_mul(t43,(t15).ink_f_value);
var t45:u32=(t14).ink_f_value;
var t46:u32=ink_f32_add(t44,ink_f32_mul(t45,(t15).ink_f_tangent_6));
var t47:u32=(t14).ink_f_tangent_7;
var t48:u32=ink_f32_mul(t47,(t15).ink_f_value);
var t49:u32=(t14).ink_f_value;
var t50:u32=ink_f32_add(t48,ink_f32_mul(t49,(t15).ink_f_tangent_7));
var t51:u32=(t14).ink_f_tangent_8;
var t52:u32=ink_f32_mul(t51,(t15).ink_f_value);
var t53:u32=(t14).ink_f_value;
var t54:u32=ink_f32_add(t52,ink_f32_mul(t53,(t15).ink_f_tangent_8));
var t55:u32=(t14).ink_f_tangent_9;
var t56:u32=ink_f32_mul(t55,(t15).ink_f_value);
var t57:u32=(t14).ink_f_value;
var t58:u32=ink_f32_add(t56,ink_f32_mul(t57,(t15).ink_f_tangent_9));
var t59:u32=(t14).ink_f_tangent_10;
var t60:u32=ink_f32_mul(t59,(t15).ink_f_value);
var t61:u32=(t14).ink_f_value;
var t62:u32=ink_f32_add(t60,ink_f32_mul(t61,(t15).ink_f_tangent_10));
var t63:u32=(t14).ink_f_tangent_11;
var t64:u32=ink_f32_mul(t63,(t15).ink_f_value);
var t65:u32=(t14).ink_f_value;
var t66:u32=ink_f32_add(t64,ink_f32_mul(t65,(t15).ink_f_tangent_11));
var t67:u32=(t14).ink_f_tangent_12;
var t68:u32=ink_f32_mul(t67,(t15).ink_f_value);
var t69:u32=(t14).ink_f_value;
var t70:u32=ink_f32_add(t68,ink_f32_mul(t69,(t15).ink_f_tangent_12));
var t71:u32=(t14).ink_f_tangent_13;
var t72:u32=ink_f32_mul(t71,(t15).ink_f_value);
var t73:u32=(t14).ink_f_value;
var t74:u32=ink_f32_add(t72,ink_f32_mul(t73,(t15).ink_f_tangent_13));
var t75:u32=(t14).ink_f_tangent_14;
var t76:u32=ink_f32_mul(t75,(t15).ink_f_value);
var t77:u32=(t14).ink_f_value;
var t78:u32=ink_f32_add(t76,ink_f32_mul(t77,(t15).ink_f_tangent_14));
var t79:u32=(t14).ink_f_tangent_15;
var t80:u32=ink_f32_mul(t79,(t15).ink_f_value);
var t81:u32=(t14).ink_f_value;
var t82:u32=ink_f32_add(t80,ink_f32_mul(t81,(t15).ink_f_tangent_15));
var t83:R___ink_differential_2=R___ink_differential_2(t18,t22,t26,t30,t34,t38,t42,t46,t50,t54,t58,t62,t66,t70,t74,t78,t82);
var t84:u32=1036831949u;
var t85:u32=0u;
var t86:u32=0u;
var t87:u32=0u;
var t88:u32=0u;
var t89:u32=0u;
var t90:u32=0u;
var t91:u32=0u;
var t92:u32=0u;
var t93:u32=0u;
var t94:u32=0u;
var t95:u32=0u;
var t96:u32=0u;
var t97:u32=0u;
var t98:u32=0u;
var t99:u32=0u;
var t100:u32=0u;
var t101:R___ink_differential_2=R___ink_differential_2(t84,t85,t86,t87,t88,t89,t90,t91,t92,t93,t94,t95,t96,t97,t98,t99,t100);
var t102:u32=(t83).ink_f_value;
var t103:u32=ink_f32_add(t102,(t101).ink_f_value);
var t104:u32=t103;
var t105:u32=(t83).ink_f_tangent_0;
var t106:u32=ink_f32_add(t105,(t101).ink_f_tangent_0);
var t107:u32=(t83).ink_f_tangent_1;
var t108:u32=ink_f32_add(t107,(t101).ink_f_tangent_1);
var t109:u32=(t83).ink_f_tangent_2;
var t110:u32=ink_f32_add(t109,(t101).ink_f_tangent_2);
var t111:u32=(t83).ink_f_tangent_3;
var t112:u32=ink_f32_add(t111,(t101).ink_f_tangent_3);
var t113:u32=(t83).ink_f_tangent_4;
var t114:u32=ink_f32_add(t113,(t101).ink_f_tangent_4);
var t115:u32=(t83).ink_f_tangent_5;
var t116:u32=ink_f32_add(t115,(t101).ink_f_tangent_5);
var t117:u32=(t83).ink_f_tangent_6;
var t118:u32=ink_f32_add(t117,(t101).ink_f_tangent_6);
var t119:u32=(t83).ink_f_tangent_7;
var t120:u32=ink_f32_add(t119,(t101).ink_f_tangent_7);
var t121:u32=(t83).ink_f_tangent_8;
var t122:u32=ink_f32_add(t121,(t101).ink_f_tangent_8);
var t123:u32=(t83).ink_f_tangent_9;
var t124:u32=ink_f32_add(t123,(t101).ink_f_tangent_9);
var t125:u32=(t83).ink_f_tangent_10;
var t126:u32=ink_f32_add(t125,(t101).ink_f_tangent_10);
var t127:u32=(t83).ink_f_tangent_11;
var t128:u32=ink_f32_add(t127,(t101).ink_f_tangent_11);
var t129:u32=(t83).ink_f_tangent_12;
var t130:u32=ink_f32_add(t129,(t101).ink_f_tangent_12);
var t131:u32=(t83).ink_f_tangent_13;
var t132:u32=ink_f32_add(t131,(t101).ink_f_tangent_13);
var t133:u32=(t83).ink_f_tangent_14;
var t134:u32=ink_f32_add(t133,(t101).ink_f_tangent_14);
var t135:u32=(t83).ink_f_tangent_15;
var t136:u32=ink_f32_add(t135,(t101).ink_f_tangent_15);
var t137:R___ink_differential_2=R___ink_differential_2(t104,t106,t108,t110,t112,t114,t116,t118,t120,t122,t124,t126,t128,t130,t132,t134,t136);
output[0u+0u]=bitcast<u32>((t137).ink_f_value);
output[0u+1u]=bitcast<u32>((t137).ink_f_tangent_0);
output[0u+2u]=bitcast<u32>((t137).ink_f_tangent_1);
output[0u+3u]=bitcast<u32>((t137).ink_f_tangent_2);
output[0u+4u]=bitcast<u32>((t137).ink_f_tangent_3);
output[0u+5u]=bitcast<u32>((t137).ink_f_tangent_4);
output[0u+6u]=bitcast<u32>((t137).ink_f_tangent_5);
output[0u+7u]=bitcast<u32>((t137).ink_f_tangent_6);
output[0u+8u]=bitcast<u32>((t137).ink_f_tangent_7);
output[0u+9u]=bitcast<u32>((t137).ink_f_tangent_8);
output[0u+10u]=bitcast<u32>((t137).ink_f_tangent_9);
output[0u+11u]=bitcast<u32>((t137).ink_f_tangent_10);
output[0u+12u]=bitcast<u32>((t137).ink_f_tangent_11);
output[0u+13u]=bitcast<u32>((t137).ink_f_tangent_12);
output[0u+14u]=bitcast<u32>((t137).ink_f_tangent_13);
output[0u+15u]=bitcast<u32>((t137).ink_f_tangent_14);
output[0u+16u]=bitcast<u32>((t137).ink_f_tangent_15);


}