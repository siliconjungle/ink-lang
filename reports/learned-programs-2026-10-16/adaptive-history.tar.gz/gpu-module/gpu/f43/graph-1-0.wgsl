// Exact wrapping u64 over two storage lanes. No floating point intermediates.
struct InkU64 {lo:u32,hi:u32,}
struct InkDiv64 {quotient:InkU64,remainder:InkU64,}
fn ink_u64_shl(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64(a.lo<<k,(a.hi<<k)|(a.lo>>(32u-k)));}return InkU64(0u,a.lo<<(k-32u));}
fn ink_u64_shr(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64((a.lo>>k)|(a.hi<<(32u-k)),a.hi>>k);}return InkU64(a.hi>>(k-32u),0u);}
fn ink_u64_rol(a:InkU64,count:u32)->InkU64{let k=count&63u;let l=ink_u64_shl(a,k);let r=ink_u64_shr(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_ror(a:InkU64,count:u32)->InkU64{let k=count&63u;let r=ink_u64_shr(a,k);let l=ink_u64_shl(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_eq(a:InkU64,b:InkU64)->bool{return a.lo==b.lo&&a.hi==b.hi;}
fn ink_u64_lt(a:InkU64,b:InkU64)->bool{return a.hi<b.hi||(a.hi==b.hi&&a.lo<b.lo);}
fn ink_u64_add(a:InkU64,b:InkU64)->InkU64{let lo=a.lo+b.lo;return InkU64(lo,a.hi+b.hi+select(0u,1u,lo<a.lo));}
fn ink_u64_sub(a:InkU64,b:InkU64)->InkU64{return InkU64(a.lo-b.lo,a.hi-b.hi-select(0u,1u,a.lo<b.lo));}
fn ink_u64_mul(a:InkU64,b:InkU64)->InkU64{let al=a.lo&65535u;let ah=a.lo>>16u;let bl=b.lo&65535u;let bh=b.lo>>16u;let p=al*bl;let x=ah*bl;let y=al*bh;let mid=(p>>16u)+(x&65535u)+(y&65535u);let high=ah*bh+(x>>16u)+(y>>16u)+(mid>>16u);return InkU64((mid<<16u)|(p&65535u),high+a.lo*b.hi+a.hi*b.lo);}
fn ink_u64_div(a:InkU64,b:InkU64)->InkDiv64{var q=InkU64(0u,0u);var r=InkU64(0u,0u);var cursor=64u;loop{if(cursor==0u){break;}cursor--;var bit=0u;if(cursor>=32u){bit=(a.hi>>(cursor-32u))&1u;}else{bit=(a.lo>>cursor)&1u;}let overflow=r.hi>>31u;r=InkU64((r.lo<<1u)|bit,(r.hi<<1u)|(r.lo>>31u));if(overflow!=0u||!ink_u64_lt(r,b)){r=ink_u64_sub(r,b);if(cursor>=32u){q.hi|=1u<<(cursor-32u);}else{q.lo|=1u<<cursor;}}}return InkDiv64(q,r);}
// Binary32 evaluated with integer lanes: round-to-nearest, ties-to-even,
// gradual underflow, signed zero and canonical arithmetic NaN.
fn ink_f32_nan(x:u32)->bool{return (x&0x7fffffffu)>0x7f800000u;}
fn ink_f32_eq(a:u32,b:u32)->bool{return !ink_f32_nan(a)&&!ink_f32_nan(b)&&(a==b||((a|b)&0x7fffffffu)==0u);}
fn ink_f32_lt(a:u32,b:u32)->bool{
 if(ink_f32_nan(a)||ink_f32_nan(b)||ink_f32_eq(a,b)){return false;}
 if((a^b)&0x80000000u)!=0u{return (a&0x80000000u)!=0u;}
 if((a&0x80000000u)!=0u){return a>b;}return a<b;
}
fn ink_f32_jam(x:u32,n:u32)->u32{if(n==0u){return x;}if(n>=32u){return select(0u,1u,x!=0u);}return (x>>n)|select(0u,1u,(x&((1u<<n)-1u))!=0u);}
fn ink_f32_round(sign:u32,exponent:i32,extended:u32)->u32{
 var e=exponent;var s=extended;
 if(e<1i){s=ink_f32_jam(s,u32(1i-e));e=1i;}
 let tail=s&7u;var sig=s>>3u;
 if(tail>4u||(tail==4u&&(sig&1u)!=0u)){sig++;}
 if(sig>=0x1000000u){sig>>=1u;e++;}
 if(e>=255i){return sign|0x7f800000u;}
 if(sig==0u){return sign;}
 let raw=select(u32(e),0u,e==1i&&sig<0x800000u);
 return sign|(raw<<23u)|(sig&0x7fffffu);
}
fn ink_f32_add(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 var x=a;var y=b;if((x&0x7fffffffu)<(y&0x7fffffffu)){x=b;y=a;}
 let ax=x&0x7fffffffu;let ay=y&0x7fffffffu;let sign=x&0x80000000u;
 if(ax==0x7f800000u){if(ay==ax&&((x^y)&0x80000000u)!=0u){return 0x7fc00000u;}return x;}
 let rx=(x>>23u)&255u;let ry=(y>>23u)&255u;var e=i32(max(rx,1u));
 var sx=((x&0x7fffffu)|select(0u,0x800000u,rx!=0u))<<3u;
 let sy=ink_f32_jam(((y&0x7fffffu)|select(0u,0x800000u,ry!=0u))<<3u,u32(e)-max(ry,1u));
 if(((x^y)&0x80000000u)==0u){sx+=sy;if(sx>=0x8000000u){sx=ink_f32_jam(sx,1u);e++;}}
 else{sx-=sy;if(sx==0u){return 0u;}loop{if(sx>=0x4000000u||e<=1i){break;}sx<<=1u;e--;}}
 return ink_f32_round(sign,e,sx);
}
fn ink_f32_sub(a:u32,b:u32)->u32{return ink_f32_add(a,b^0x80000000u);}
fn ink_f32_mul(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(aa==0x7f800000u||bb==0x7f800000u){if(aa==0u||bb==0u){return 0x7fc00000u;}return sign|0x7f800000u;}
 if(aa==0u||bb==0u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u));var eb=i32(max(rb,1u));
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 let product=ink_u64_mul(InkU64(sa,0u),InkU64(sb,0u));let high=(product.hi&0x8000u)!=0u;
 let shift=select(20u,21u,high);let extended=(product.lo>>shift)|(product.hi<<(32u-shift))|select(0u,1u,(product.lo&((1u<<shift)-1u))!=0u);
 return ink_f32_round(sign,ea+eb-127i+select(0i,1i,high),extended);
}
// Exact sqrt and division use integer significands, independent of WGSL float
// approximation allowances and device flush-to-zero behavior.
fn ink_f32_sqrt(x:u32)->u32{
 let a=x&0x7fffffffu;if(a==0u){return x;}
 if(a>0x7f800000u||(x&0x80000000u)!=0u){return 0x7fc00000u;}
 if(a==0x7f800000u){return x;}
 let raw=(x>>23u)&255u;var m=(x&0x7fffffu)|select(0u,0x800000u,raw!=0u);var e=i32(max(raw,1u))-127i;
 loop{if(m>=0x800000u){break;}m<<=1u;e--;}
 let odd=e&1i;var half=(e-odd)/2i;let shift=23u+u32(odd);
 let n=InkU64(m<<shift,m>>(32u-shift));var lo=0u;var hi=0x1000000u;
 loop{if(lo+1u>=hi){break;}let mid=(lo+hi)>>1u;let sq=ink_u64_mul(InkU64(mid,0u),InkU64(mid,0u));if(!ink_u64_lt(n,sq)){lo=mid;}else{hi=mid;}}
 let sq=ink_u64_mul(InkU64(lo,0u),InkU64(lo,0u));let rem=ink_u64_sub(n,sq);
 if(ink_u64_lt(InkU64(lo,0u),rem)){lo++;}
 if(lo==0x1000000u){lo>>=1u;half++;}
 return (u32(half+127i)<<23u)|(lo&0x7fffffu);
}
fn ink_f32_div(a:u32,b:u32)->u32{
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(ink_f32_nan(a)||ink_f32_nan(b)||(aa==0u&&bb==0u)||(aa==0x7f800000u&&bb==aa)){return 0x7fc00000u;}
 if(aa==0x7f800000u||bb==0u){return sign|0x7f800000u;}
 if(aa==0u||bb==0x7f800000u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u))-127i;var eb=i32(max(rb,1u))-127i;
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 var e=ea-eb;if(sa<sb){sa<<=1u;e--;}
 let division=ink_u64_div(InkU64(sa<<26u,sa>>6u),InkU64(sb,0u));
 let extended=division.quotient.lo|select(0u,1u,!ink_u64_eq(division.remainder,InkU64(0u,0u)));
 return ink_f32_round(sign,e+127i,extended);
}
// mode: 0 trunc, 1 floor, 2 ceil, 3 ties-to-even.
fn ink_f32_integral(x:u32,mode:u32)->u32{
 let a=x&0x7fffffffu;let sign=x&0x80000000u;
 if(a>0x7f800000u){return 0x7fc00000u;}if(a>=0x4b000000u||a==0u){return x;}
 let e=i32((x>>23u)&255u)-127i;
 if(e<0i){var up=false;if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){up=a>0x3f000000u;}return sign|select(0u,0x3f800000u,up);}
 let shift=u32(23i-e);let mask=(1u<<shift)-1u;let fraction=a&mask;var rounded=a&~mask;var up=false;
 if(fraction!=0u){if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){let half=1u<<(shift-1u);up=fraction>half||(fraction==half&&((rounded>>shift)&1u)!=0u);}}
 if(up){rounded+=1u<<shift;}return sign|rounded;
}
fn ink_f32_from_u64(x:InkU64)->u32{
 if(ink_u64_eq(x,InkU64(0u,0u))){return 0u;}
 let leading=select(countLeadingZeros(x.lo)+32u,countLeadingZeros(x.hi),x.hi!=0u);let e=63u-leading;
 if(e<=23u){return ((e+127u)<<23u)|((x.lo<<(23u-e))&0x7fffffu);}
 let shift=e-23u;var sig=0u;var rem=InkU64(0u,0u);var half=InkU64(0u,0u);
 if(shift<32u){sig=(x.lo>>shift)|(x.hi<<(32u-shift));rem=InkU64(x.lo&((1u<<shift)-1u),0u);half=InkU64(1u<<(shift-1u),0u);}
 else if(shift==32u){sig=x.hi;rem=InkU64(x.lo,0u);half=InkU64(0x80000000u,0u);}
 else{sig=x.hi>>(shift-32u);rem=InkU64(x.lo,x.hi&((1u<<(shift-32u))-1u));half=InkU64(0u,1u<<(shift-33u));}
 if(ink_u64_lt(half,rem)||(ink_u64_eq(rem,half)&&(sig&1u)!=0u)){sig++;}
 var exponent=e+127u;if(sig==0x1000000u){sig>>=1u;exponent++;}
 return (exponent<<23u)|(sig&0x7fffffu);
}
fn ink_f32_from_i32(x:i32)->u32{let neg=x<0i;let magnitude=select(u32(x),0u-u32(x),neg);return ink_f32_from_u64(InkU64(magnitude,0u))|select(0u,0x80000000u,neg);}
struct InkBuffer_u32{data:array<u32,64>,length:u32,}
struct InkBuffer_InkU64{data:array<InkU64,64>,length:u32,}
struct InkBuffer_i32{data:array<i32,64>,length:u32,}
struct InkBuffer_bool{data:array<bool,64>,length:u32,}
struct R_MassRow{ink_f_identity:u32,ink_f_scale:u32,ink_f_bias:u32,ink_f_relu:u32,}
struct R_Parameters{ink_f_a:R_MassRow,ink_f_b:R_MassRow,ink_f_c:R_MassRow,ink_f_d:R_MassRow,}
struct R_Pick{ink_f_slot:u32,ink_f_operation:u32,}
struct R___ink_differential_2{ink_f_value:u32,ink_f_tangent_0:u32,ink_f_tangent_1:u32,ink_f_tangent_2:u32,ink_f_tangent_3:u32,ink_f_tangent_4:u32,ink_f_tangent_5:u32,ink_f_tangent_6:u32,ink_f_tangent_7:u32,ink_f_tangent_8:u32,ink_f_tangent_9:u32,ink_f_tangent_10:u32,ink_f_tangent_11:u32,ink_f_tangent_12:u32,ink_f_tangent_13:u32,ink_f_tangent_14:u32,ink_f_tangent_15:u32,}
struct R___ink_differential_4{ink_f_a:R___ink_differential_5,ink_f_b:R___ink_differential_5,ink_f_c:R___ink_differential_5,ink_f_d:R___ink_differential_5,}
struct R___ink_differential_5{ink_f_identity:R___ink_differential_2,ink_f_scale:R___ink_differential_2,ink_f_bias:R___ink_differential_2,ink_f_relu:R___ink_differential_2,}
struct R___ink_differential_6{ink_f_slot:u32,ink_f_operation:u32,}
@group(0) @binding(0) var<storage,read> a0:array<u32>;
@group(0) @binding(1) var<storage,read> a1:array<u32>;
@group(0) @binding(2) var<storage,read_write> output:array<u32>;
@compute @workgroup_size(1) fn main(@builtin(global_invocation_id) gid:vec3<u32>){
if(gid.x!=0u){return;}var t0:u32=((R_Parameters(R_MassRow(a1[0u+(0u)*16u+0u],a1[0u+(0u)*16u+1u],a1[0u+(0u)*16u+2u],a1[0u+(0u)*16u+3u]),R_MassRow(a1[0u+(0u)*16u+4u],a1[0u+(0u)*16u+5u],a1[0u+(0u)*16u+6u],a1[0u+(0u)*16u+7u]),R_MassRow(a1[0u+(0u)*16u+8u],a1[0u+(0u)*16u+9u],a1[0u+(0u)*16u+10u],a1[0u+(0u)*16u+11u]),R_MassRow(a1[0u+(0u)*16u+12u],a1[0u+(0u)*16u+13u],a1[0u+(0u)*16u+14u],a1[0u+(0u)*16u+15u]))).ink_f_a).ink_f_identity;
var t1:u32=1065353216u;
var t2:u32=0u;
var t3:u32=0u;
var t4:u32=0u;
var t5:u32=0u;
var t6:u32=0u;
var t7:u32=0u;
var t8:u32=0u;
var t9:u32=0u;
var t10:u32=0u;
var t11:u32=0u;
var t12:u32=0u;
var t13:u32=0u;
var t14:u32=0u;
var t15:u32=0u;
var t16:u32=0u;
var t17:R___ink_differential_2=R___ink_differential_2(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13,t14,t15,t16);
var t18:u32=((R_Parameters(R_MassRow(a1[0u+(0u)*16u+0u],a1[0u+(0u)*16u+1u],a1[0u+(0u)*16u+2u],a1[0u+(0u)*16u+3u]),R_MassRow(a1[0u+(0u)*16u+4u],a1[0u+(0u)*16u+5u],a1[0u+(0u)*16u+6u],a1[0u+(0u)*16u+7u]),R_MassRow(a1[0u+(0u)*16u+8u],a1[0u+(0u)*16u+9u],a1[0u+(0u)*16u+10u],a1[0u+(0u)*16u+11u]),R_MassRow(a1[0u+(0u)*16u+12u],a1[0u+(0u)*16u+13u],a1[0u+(0u)*16u+14u],a1[0u+(0u)*16u+15u]))).ink_f_a).ink_f_scale;
var t19:u32=0u;
var t20:u32=1065353216u;
var t21:u32=0u;
var t22:u32=0u;
var t23:u32=0u;
var t24:u32=0u;
var t25:u32=0u;
var t26:u32=0u;
var t27:u32=0u;
var t28:u32=0u;
var t29:u32=0u;
var t30:u32=0u;
var t31:u32=0u;
var t32:u32=0u;
var t33:u32=0u;
var t34:u32=0u;
var t35:R___ink_differential_2=R___ink_differential_2(t18,t19,t20,t21,t22,t23,t24,t25,t26,t27,t28,t29,t30,t31,t32,t33,t34);
var t36:u32=((R_Parameters(R_MassRow(a1[0u+(0u)*16u+0u],a1[0u+(0u)*16u+1u],a1[0u+(0u)*16u+2u],a1[0u+(0u)*16u+3u]),R_MassRow(a1[0u+(0u)*16u+4u],a1[0u+(0u)*16u+5u],a1[0u+(0u)*16u+6u],a1[0u+(0u)*16u+7u]),R_MassRow(a1[0u+(0u)*16u+8u],a1[0u+(0u)*16u+9u],a1[0u+(0u)*16u+10u],a1[0u+(0u)*16u+11u]),R_MassRow(a1[0u+(0u)*16u+12u],a1[0u+(0u)*16u+13u],a1[0u+(0u)*16u+14u],a1[0u+(0u)*16u+15u]))).ink_f_a).ink_f_bias;
var t37:u32=0u;
var t38:u32=0u;
var t39:u32=1065353216u;
var t40:u32=0u;
var t41:u32=0u;
var t42:u32=0u;
var t43:u32=0u;
var t44:u32=0u;
var t45:u32=0u;
var t46:u32=0u;
var t47:u32=0u;
var t48:u32=0u;
var t49:u32=0u;
var t50:u32=0u;
var t51:u32=0u;
var t52:u32=0u;
var t53:R___ink_differential_2=R___ink_differential_2(t36,t37,t38,t39,t40,t41,t42,t43,t44,t45,t46,t47,t48,t49,t50,t51,t52);
var t54:u32=((R_Parameters(R_MassRow(a1[0u+(0u)*16u+0u],a1[0u+(0u)*16u+1u],a1[0u+(0u)*16u+2u],a1[0u+(0u)*16u+3u]),R_MassRow(a1[0u+(0u)*16u+4u],a1[0u+(0u)*16u+5u],a1[0u+(0u)*16u+6u],a1[0u+(0u)*16u+7u]),R_MassRow(a1[0u+(0u)*16u+8u],a1[0u+(0u)*16u+9u],a1[0u+(0u)*16u+10u],a1[0u+(0u)*16u+11u]),R_MassRow(a1[0u+(0u)*16u+12u],a1[0u+(0u)*16u+13u],a1[0u+(0u)*16u+14u],a1[0u+(0u)*16u+15u]))).ink_f_a).ink_f_relu;
var t55:u32=0u;
var t56:u32=0u;
var t57:u32=0u;
var t58:u32=1065353216u;
var t59:u32=0u;
var t60:u32=0u;
var t61:u32=0u;
var t62:u32=0u;
var t63:u32=0u;
var t64:u32=0u;
var t65:u32=0u;
var t66:u32=0u;
var t67:u32=0u;
var t68:u32=0u;
var t69:u32=0u;
var t70:u32=0u;
var t71:R___ink_differential_2=R___ink_differential_2(t54,t55,t56,t57,t58,t59,t60,t61,t62,t63,t64,t65,t66,t67,t68,t69,t70);
var t72:R___ink_differential_5=R___ink_differential_5(t17,t35,t53,t71);
var t73:u32=((R_Parameters(R_MassRow(a1[0u+(0u)*16u+0u],a1[0u+(0u)*16u+1u],a1[0u+(0u)*16u+2u],a1[0u+(0u)*16u+3u]),R_MassRow(a1[0u+(0u)*16u+4u],a1[0u+(0u)*16u+5u],a1[0u+(0u)*16u+6u],a1[0u+(0u)*16u+7u]),R_MassRow(a1[0u+(0u)*16u+8u],a1[0u+(0u)*16u+9u],a1[0u+(0u)*16u+10u],a1[0u+(0u)*16u+11u]),R_MassRow(a1[0u+(0u)*16u+12u],a1[0u+(0u)*16u+13u],a1[0u+(0u)*16u+14u],a1[0u+(0u)*16u+15u]))).ink_f_b).ink_f_identity;
var t74:u32=0u;
var t75:u32=0u;
var t76:u32=0u;
var t77:u32=0u;
var t78:u32=1065353216u;
var t79:u32=0u;
var t80:u32=0u;
var t81:u32=0u;
var t82:u32=0u;
var t83:u32=0u;
var t84:u32=0u;
var t85:u32=0u;
var t86:u32=0u;
var t87:u32=0u;
var t88:u32=0u;
var t89:u32=0u;
var t90:R___ink_differential_2=R___ink_differential_2(t73,t74,t75,t76,t77,t78,t79,t80,t81,t82,t83,t84,t85,t86,t87,t88,t89);
var t91:u32=((R_Parameters(R_MassRow(a1[0u+(0u)*16u+0u],a1[0u+(0u)*16u+1u],a1[0u+(0u)*16u+2u],a1[0u+(0u)*16u+3u]),R_MassRow(a1[0u+(0u)*16u+4u],a1[0u+(0u)*16u+5u],a1[0u+(0u)*16u+6u],a1[0u+(0u)*16u+7u]),R_MassRow(a1[0u+(0u)*16u+8u],a1[0u+(0u)*16u+9u],a1[0u+(0u)*16u+10u],a1[0u+(0u)*16u+11u]),R_MassRow(a1[0u+(0u)*16u+12u],a1[0u+(0u)*16u+13u],a1[0u+(0u)*16u+14u],a1[0u+(0u)*16u+15u]))).ink_f_b).ink_f_scale;
var t92:u32=0u;
var t93:u32=0u;
var t94:u32=0u;
var t95:u32=0u;
var t96:u32=0u;
var t97:u32=1065353216u;
var t98:u32=0u;
var t99:u32=0u;
var t100:u32=0u;
var t101:u32=0u;
var t102:u32=0u;
var t103:u32=0u;
var t104:u32=0u;
var t105:u32=0u;
var t106:u32=0u;
var t107:u32=0u;
var t108:R___ink_differential_2=R___ink_differential_2(t91,t92,t93,t94,t95,t96,t97,t98,t99,t100,t101,t102,t103,t104,t105,t106,t107);
var t109:u32=((R_Parameters(R_MassRow(a1[0u+(0u)*16u+0u],a1[0u+(0u)*16u+1u],a1[0u+(0u)*16u+2u],a1[0u+(0u)*16u+3u]),R_MassRow(a1[0u+(0u)*16u+4u],a1[0u+(0u)*16u+5u],a1[0u+(0u)*16u+6u],a1[0u+(0u)*16u+7u]),R_MassRow(a1[0u+(0u)*16u+8u],a1[0u+(0u)*16u+9u],a1[0u+(0u)*16u+10u],a1[0u+(0u)*16u+11u]),R_MassRow(a1[0u+(0u)*16u+12u],a1[0u+(0u)*16u+13u],a1[0u+(0u)*16u+14u],a1[0u+(0u)*16u+15u]))).ink_f_b).ink_f_bias;
var t110:u32=0u;
var t111:u32=0u;
var t112:u32=0u;
var t113:u32=0u;
var t114:u32=0u;
var t115:u32=0u;
var t116:u32=1065353216u;
var t117:u32=0u;
var t118:u32=0u;
var t119:u32=0u;
var t120:u32=0u;
var t121:u32=0u;
var t122:u32=0u;
var t123:u32=0u;
var t124:u32=0u;
var t125:u32=0u;
var t126:R___ink_differential_2=R___ink_differential_2(t109,t110,t111,t112,t113,t114,t115,t116,t117,t118,t119,t120,t121,t122,t123,t124,t125);
var t127:u32=((R_Parameters(R_MassRow(a1[0u+(0u)*16u+0u],a1[0u+(0u)*16u+1u],a1[0u+(0u)*16u+2u],a1[0u+(0u)*16u+3u]),R_MassRow(a1[0u+(0u)*16u+4u],a1[0u+(0u)*16u+5u],a1[0u+(0u)*16u+6u],a1[0u+(0u)*16u+7u]),R_MassRow(a1[0u+(0u)*16u+8u],a1[0u+(0u)*16u+9u],a1[0u+(0u)*16u+10u],a1[0u+(0u)*16u+11u]),R_MassRow(a1[0u+(0u)*16u+12u],a1[0u+(0u)*16u+13u],a1[0u+(0u)*16u+14u],a1[0u+(0u)*16u+15u]))).ink_f_b).ink_f_relu;
var t128:u32=0u;
var t129:u32=0u;
var t130:u32=0u;
var t131:u32=0u;
var t132:u32=0u;
var t133:u32=0u;
var t134:u32=0u;
var t135:u32=1065353216u;
var t136:u32=0u;
var t137:u32=0u;
var t138:u32=0u;
var t139:u32=0u;
var t140:u32=0u;
var t141:u32=0u;
var t142:u32=0u;
var t143:u32=0u;
var t144:R___ink_differential_2=R___ink_differential_2(t127,t128,t129,t130,t131,t132,t133,t134,t135,t136,t137,t138,t139,t140,t141,t142,t143);
var t145:R___ink_differential_5=R___ink_differential_5(t90,t108,t126,t144);
var t146:u32=((R_Parameters(R_MassRow(a1[0u+(0u)*16u+0u],a1[0u+(0u)*16u+1u],a1[0u+(0u)*16u+2u],a1[0u+(0u)*16u+3u]),R_MassRow(a1[0u+(0u)*16u+4u],a1[0u+(0u)*16u+5u],a1[0u+(0u)*16u+6u],a1[0u+(0u)*16u+7u]),R_MassRow(a1[0u+(0u)*16u+8u],a1[0u+(0u)*16u+9u],a1[0u+(0u)*16u+10u],a1[0u+(0u)*16u+11u]),R_MassRow(a1[0u+(0u)*16u+12u],a1[0u+(0u)*16u+13u],a1[0u+(0u)*16u+14u],a1[0u+(0u)*16u+15u]))).ink_f_c).ink_f_identity;
var t147:u32=0u;
var t148:u32=0u;
var t149:u32=0u;
var t150:u32=0u;
var t151:u32=0u;
var t152:u32=0u;
var t153:u32=0u;
var t154:u32=0u;
var t155:u32=1065353216u;
var t156:u32=0u;
var t157:u32=0u;
var t158:u32=0u;
var t159:u32=0u;
var t160:u32=0u;
var t161:u32=0u;
var t162:u32=0u;
var t163:R___ink_differential_2=R___ink_differential_2(t146,t147,t148,t149,t150,t151,t152,t153,t154,t155,t156,t157,t158,t159,t160,t161,t162);
var t164:u32=((R_Parameters(R_MassRow(a1[0u+(0u)*16u+0u],a1[0u+(0u)*16u+1u],a1[0u+(0u)*16u+2u],a1[0u+(0u)*16u+3u]),R_MassRow(a1[0u+(0u)*16u+4u],a1[0u+(0u)*16u+5u],a1[0u+(0u)*16u+6u],a1[0u+(0u)*16u+7u]),R_MassRow(a1[0u+(0u)*16u+8u],a1[0u+(0u)*16u+9u],a1[0u+(0u)*16u+10u],a1[0u+(0u)*16u+11u]),R_MassRow(a1[0u+(0u)*16u+12u],a1[0u+(0u)*16u+13u],a1[0u+(0u)*16u+14u],a1[0u+(0u)*16u+15u]))).ink_f_c).ink_f_scale;
var t165:u32=0u;
var t166:u32=0u;
var t167:u32=0u;
var t168:u32=0u;
var t169:u32=0u;
var t170:u32=0u;
var t171:u32=0u;
var t172:u32=0u;
var t173:u32=0u;
var t174:u32=1065353216u;
var t175:u32=0u;
var t176:u32=0u;
var t177:u32=0u;
var t178:u32=0u;
var t179:u32=0u;
var t180:u32=0u;
var t181:R___ink_differential_2=R___ink_differential_2(t164,t165,t166,t167,t168,t169,t170,t171,t172,t173,t174,t175,t176,t177,t178,t179,t180);
var t182:u32=((R_Parameters(R_MassRow(a1[0u+(0u)*16u+0u],a1[0u+(0u)*16u+1u],a1[0u+(0u)*16u+2u],a1[0u+(0u)*16u+3u]),R_MassRow(a1[0u+(0u)*16u+4u],a1[0u+(0u)*16u+5u],a1[0u+(0u)*16u+6u],a1[0u+(0u)*16u+7u]),R_MassRow(a1[0u+(0u)*16u+8u],a1[0u+(0u)*16u+9u],a1[0u+(0u)*16u+10u],a1[0u+(0u)*16u+11u]),R_MassRow(a1[0u+(0u)*16u+12u],a1[0u+(0u)*16u+13u],a1[0u+(0u)*16u+14u],a1[0u+(0u)*16u+15u]))).ink_f_c).ink_f_bias;
var t183:u32=0u;
var t184:u32=0u;
var t185:u32=0u;
var t186:u32=0u;
var t187:u32=0u;
var t188:u32=0u;
var t189:u32=0u;
var t190:u32=0u;
var t191:u32=0u;
var t192:u32=0u;
var t193:u32=1065353216u;
var t194:u32=0u;
var t195:u32=0u;
var t196:u32=0u;
var t197:u32=0u;
var t198:u32=0u;
var t199:R___ink_differential_2=R___ink_differential_2(t182,t183,t184,t185,t186,t187,t188,t189,t190,t191,t192,t193,t194,t195,t196,t197,t198);
var t200:u32=((R_Parameters(R_MassRow(a1[0u+(0u)*16u+0u],a1[0u+(0u)*16u+1u],a1[0u+(0u)*16u+2u],a1[0u+(0u)*16u+3u]),R_MassRow(a1[0u+(0u)*16u+4u],a1[0u+(0u)*16u+5u],a1[0u+(0u)*16u+6u],a1[0u+(0u)*16u+7u]),R_MassRow(a1[0u+(0u)*16u+8u],a1[0u+(0u)*16u+9u],a1[0u+(0u)*16u+10u],a1[0u+(0u)*16u+11u]),R_MassRow(a1[0u+(0u)*16u+12u],a1[0u+(0u)*16u+13u],a1[0u+(0u)*16u+14u],a1[0u+(0u)*16u+15u]))).ink_f_c).ink_f_relu;
var t201:u32=0u;
var t202:u32=0u;
var t203:u32=0u;
var t204:u32=0u;
var t205:u32=0u;
var t206:u32=0u;
var t207:u32=0u;
var t208:u32=0u;
var t209:u32=0u;
var t210:u32=0u;
var t211:u32=0u;
var t212:u32=1065353216u;
var t213:u32=0u;
var t214:u32=0u;
var t215:u32=0u;
var t216:u32=0u;
var t217:R___ink_differential_2=R___ink_differential_2(t200,t201,t202,t203,t204,t205,t206,t207,t208,t209,t210,t211,t212,t213,t214,t215,t216);
var t218:R___ink_differential_5=R___ink_differential_5(t163,t181,t199,t217);
var t219:u32=((R_Parameters(R_MassRow(a1[0u+(0u)*16u+0u],a1[0u+(0u)*16u+1u],a1[0u+(0u)*16u+2u],a1[0u+(0u)*16u+3u]),R_MassRow(a1[0u+(0u)*16u+4u],a1[0u+(0u)*16u+5u],a1[0u+(0u)*16u+6u],a1[0u+(0u)*16u+7u]),R_MassRow(a1[0u+(0u)*16u+8u],a1[0u+(0u)*16u+9u],a1[0u+(0u)*16u+10u],a1[0u+(0u)*16u+11u]),R_MassRow(a1[0u+(0u)*16u+12u],a1[0u+(0u)*16u+13u],a1[0u+(0u)*16u+14u],a1[0u+(0u)*16u+15u]))).ink_f_d).ink_f_identity;
var t220:u32=0u;
var t221:u32=0u;
var t222:u32=0u;
var t223:u32=0u;
var t224:u32=0u;
var t225:u32=0u;
var t226:u32=0u;
var t227:u32=0u;
var t228:u32=0u;
var t229:u32=0u;
var t230:u32=0u;
var t231:u32=0u;
var t232:u32=1065353216u;
var t233:u32=0u;
var t234:u32=0u;
var t235:u32=0u;
var t236:R___ink_differential_2=R___ink_differential_2(t219,t220,t221,t222,t223,t224,t225,t226,t227,t228,t229,t230,t231,t232,t233,t234,t235);
var t237:u32=((R_Parameters(R_MassRow(a1[0u+(0u)*16u+0u],a1[0u+(0u)*16u+1u],a1[0u+(0u)*16u+2u],a1[0u+(0u)*16u+3u]),R_MassRow(a1[0u+(0u)*16u+4u],a1[0u+(0u)*16u+5u],a1[0u+(0u)*16u+6u],a1[0u+(0u)*16u+7u]),R_MassRow(a1[0u+(0u)*16u+8u],a1[0u+(0u)*16u+9u],a1[0u+(0u)*16u+10u],a1[0u+(0u)*16u+11u]),R_MassRow(a1[0u+(0u)*16u+12u],a1[0u+(0u)*16u+13u],a1[0u+(0u)*16u+14u],a1[0u+(0u)*16u+15u]))).ink_f_d).ink_f_scale;
var t238:u32=0u;
var t239:u32=0u;
var t240:u32=0u;
var t241:u32=0u;
var t242:u32=0u;
var t243:u32=0u;
var t244:u32=0u;
var t245:u32=0u;
var t246:u32=0u;
var t247:u32=0u;
var t248:u32=0u;
var t249:u32=0u;
var t250:u32=0u;
var t251:u32=1065353216u;
var t252:u32=0u;
var t253:u32=0u;
var t254:R___ink_differential_2=R___ink_differential_2(t237,t238,t239,t240,t241,t242,t243,t244,t245,t246,t247,t248,t249,t250,t251,t252,t253);
var t255:u32=((R_Parameters(R_MassRow(a1[0u+(0u)*16u+0u],a1[0u+(0u)*16u+1u],a1[0u+(0u)*16u+2u],a1[0u+(0u)*16u+3u]),R_MassRow(a1[0u+(0u)*16u+4u],a1[0u+(0u)*16u+5u],a1[0u+(0u)*16u+6u],a1[0u+(0u)*16u+7u]),R_MassRow(a1[0u+(0u)*16u+8u],a1[0u+(0u)*16u+9u],a1[0u+(0u)*16u+10u],a1[0u+(0u)*16u+11u]),R_MassRow(a1[0u+(0u)*16u+12u],a1[0u+(0u)*16u+13u],a1[0u+(0u)*16u+14u],a1[0u+(0u)*16u+15u]))).ink_f_d).ink_f_bias;
var t256:u32=0u;
var t257:u32=0u;
var t258:u32=0u;
var t259:u32=0u;
var t260:u32=0u;
var t261:u32=0u;
var t262:u32=0u;
var t263:u32=0u;
var t264:u32=0u;
var t265:u32=0u;
var t266:u32=0u;
var t267:u32=0u;
var t268:u32=0u;
var t269:u32=0u;
var t270:u32=1065353216u;
var t271:u32=0u;
var t272:R___ink_differential_2=R___ink_differential_2(t255,t256,t257,t258,t259,t260,t261,t262,t263,t264,t265,t266,t267,t268,t269,t270,t271);
var t273:u32=((R_Parameters(R_MassRow(a1[0u+(0u)*16u+0u],a1[0u+(0u)*16u+1u],a1[0u+(0u)*16u+2u],a1[0u+(0u)*16u+3u]),R_MassRow(a1[0u+(0u)*16u+4u],a1[0u+(0u)*16u+5u],a1[0u+(0u)*16u+6u],a1[0u+(0u)*16u+7u]),R_MassRow(a1[0u+(0u)*16u+8u],a1[0u+(0u)*16u+9u],a1[0u+(0u)*16u+10u],a1[0u+(0u)*16u+11u]),R_MassRow(a1[0u+(0u)*16u+12u],a1[0u+(0u)*16u+13u],a1[0u+(0u)*16u+14u],a1[0u+(0u)*16u+15u]))).ink_f_d).ink_f_relu;
var t274:u32=0u;
var t275:u32=0u;
var t276:u32=0u;
var t277:u32=0u;
var t278:u32=0u;
var t279:u32=0u;
var t280:u32=0u;
var t281:u32=0u;
var t282:u32=0u;
var t283:u32=0u;
var t284:u32=0u;
var t285:u32=0u;
var t286:u32=0u;
var t287:u32=0u;
var t288:u32=0u;
var t289:u32=1065353216u;
var t290:R___ink_differential_2=R___ink_differential_2(t273,t274,t275,t276,t277,t278,t279,t280,t281,t282,t283,t284,t285,t286,t287,t288,t289);
var t291:R___ink_differential_5=R___ink_differential_5(t236,t254,t272,t290);
var t292:R___ink_differential_4=R___ink_differential_4(t72,t145,t218,t291);
var t293:u32=(R_Pick(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u])).ink_f_slot;
var t294:u32=(R_Pick(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u])).ink_f_operation;
var t295:R___ink_differential_6=R___ink_differential_6(t293,t294);
var t296:u32=(t295).ink_f_slot;
var t297:R___ink_differential_5;
if ((t296 == 0u)) {
t297=(t292).ink_f_a;
} else {
var t298:u32=(t295).ink_f_slot;
var t299:R___ink_differential_5;
if ((t298 == 1u)) {
t299=(t292).ink_f_b;
} else {
var t300:u32=(t295).ink_f_slot;
var t301:R___ink_differential_5;
if ((t300 == 2u)) {
t301=(t292).ink_f_c;
} else {
t301=(t292).ink_f_d;
}
t299=t301;
}
t297=t299;
}
var t302:R___ink_differential_5=t297;
var t303:u32=(t295).ink_f_operation;
var t304:R___ink_differential_2;
if ((t303 == 0u)) {
t304=(t302).ink_f_identity;
} else {
var t305:u32=(t295).ink_f_operation;
var t306:R___ink_differential_2;
if ((t305 == 1u)) {
t306=(t302).ink_f_scale;
} else {
var t307:u32=(t295).ink_f_operation;
var t308:R___ink_differential_2;
if ((t307 == 2u)) {
t308=(t302).ink_f_bias;
} else {
t308=(t302).ink_f_relu;
}
t306=t308;
}
t304=t306;
}
var t309:R___ink_differential_2=t304;
var t310:R___ink_differential_2=t309;
var t311:R___ink_differential_2=t309;
var t312:u32=(t310).ink_f_value;
var t313:u32=ink_f32_mul(t312,(t311).ink_f_value);
var t314:u32=t313;
var t315:u32=(t310).ink_f_tangent_0;
var t316:u32=ink_f32_mul(t315,(t311).ink_f_value);
var t317:u32=(t310).ink_f_value;
var t318:u32=ink_f32_add(t316,ink_f32_mul(t317,(t311).ink_f_tangent_0));
var t319:u32=(t310).ink_f_tangent_1;
var t320:u32=ink_f32_mul(t319,(t311).ink_f_value);
var t321:u32=(t310).ink_f_value;
var t322:u32=ink_f32_add(t320,ink_f32_mul(t321,(t311).ink_f_tangent_1));
var t323:u32=(t310).ink_f_tangent_2;
var t324:u32=ink_f32_mul(t323,(t311).ink_f_value);
var t325:u32=(t310).ink_f_value;
var t326:u32=ink_f32_add(t324,ink_f32_mul(t325,(t311).ink_f_tangent_2));
var t327:u32=(t310).ink_f_tangent_3;
var t328:u32=ink_f32_mul(t327,(t311).ink_f_value);
var t329:u32=(t310).ink_f_value;
var t330:u32=ink_f32_add(t328,ink_f32_mul(t329,(t311).ink_f_tangent_3));
var t331:u32=(t310).ink_f_tangent_4;
var t332:u32=ink_f32_mul(t331,(t311).ink_f_value);
var t333:u32=(t310).ink_f_value;
var t334:u32=ink_f32_add(t332,ink_f32_mul(t333,(t311).ink_f_tangent_4));
var t335:u32=(t310).ink_f_tangent_5;
var t336:u32=ink_f32_mul(t335,(t311).ink_f_value);
var t337:u32=(t310).ink_f_value;
var t338:u32=ink_f32_add(t336,ink_f32_mul(t337,(t311).ink_f_tangent_5));
var t339:u32=(t310).ink_f_tangent_6;
var t340:u32=ink_f32_mul(t339,(t311).ink_f_value);
var t341:u32=(t310).ink_f_value;
var t342:u32=ink_f32_add(t340,ink_f32_mul(t341,(t311).ink_f_tangent_6));
var t343:u32=(t310).ink_f_tangent_7;
var t344:u32=ink_f32_mul(t343,(t311).ink_f_value);
var t345:u32=(t310).ink_f_value;
var t346:u32=ink_f32_add(t344,ink_f32_mul(t345,(t311).ink_f_tangent_7));
var t347:u32=(t310).ink_f_tangent_8;
var t348:u32=ink_f32_mul(t347,(t311).ink_f_value);
var t349:u32=(t310).ink_f_value;
var t350:u32=ink_f32_add(t348,ink_f32_mul(t349,(t311).ink_f_tangent_8));
var t351:u32=(t310).ink_f_tangent_9;
var t352:u32=ink_f32_mul(t351,(t311).ink_f_value);
var t353:u32=(t310).ink_f_value;
var t354:u32=ink_f32_add(t352,ink_f32_mul(t353,(t311).ink_f_tangent_9));
var t355:u32=(t310).ink_f_tangent_10;
var t356:u32=ink_f32_mul(t355,(t311).ink_f_value);
var t357:u32=(t310).ink_f_value;
var t358:u32=ink_f32_add(t356,ink_f32_mul(t357,(t311).ink_f_tangent_10));
var t359:u32=(t310).ink_f_tangent_11;
var t360:u32=ink_f32_mul(t359,(t311).ink_f_value);
var t361:u32=(t310).ink_f_value;
var t362:u32=ink_f32_add(t360,ink_f32_mul(t361,(t311).ink_f_tangent_11));
var t363:u32=(t310).ink_f_tangent_12;
var t364:u32=ink_f32_mul(t363,(t311).ink_f_value);
var t365:u32=(t310).ink_f_value;
var t366:u32=ink_f32_add(t364,ink_f32_mul(t365,(t311).ink_f_tangent_12));
var t367:u32=(t310).ink_f_tangent_13;
var t368:u32=ink_f32_mul(t367,(t311).ink_f_value);
var t369:u32=(t310).ink_f_value;
var t370:u32=ink_f32_add(t368,ink_f32_mul(t369,(t311).ink_f_tangent_13));
var t371:u32=(t310).ink_f_tangent_14;
var t372:u32=ink_f32_mul(t371,(t311).ink_f_value);
var t373:u32=(t310).ink_f_value;
var t374:u32=ink_f32_add(t372,ink_f32_mul(t373,(t311).ink_f_tangent_14));
var t375:u32=(t310).ink_f_tangent_15;
var t376:u32=ink_f32_mul(t375,(t311).ink_f_value);
var t377:u32=(t310).ink_f_value;
var t378:u32=ink_f32_add(t376,ink_f32_mul(t377,(t311).ink_f_tangent_15));
var t379:R___ink_differential_2=R___ink_differential_2(t314,t318,t322,t326,t330,t334,t338,t342,t346,t350,t354,t358,t362,t366,t370,t374,t378);
var t380:u32=1036831949u;
var t381:u32=0u;
var t382:u32=0u;
var t383:u32=0u;
var t384:u32=0u;
var t385:u32=0u;
var t386:u32=0u;
var t387:u32=0u;
var t388:u32=0u;
var t389:u32=0u;
var t390:u32=0u;
var t391:u32=0u;
var t392:u32=0u;
var t393:u32=0u;
var t394:u32=0u;
var t395:u32=0u;
var t396:u32=0u;
var t397:R___ink_differential_2=R___ink_differential_2(t380,t381,t382,t383,t384,t385,t386,t387,t388,t389,t390,t391,t392,t393,t394,t395,t396);
var t398:u32=(t379).ink_f_value;
var t399:u32=ink_f32_add(t398,(t397).ink_f_value);
var t400:u32=t399;
var t401:u32=(t379).ink_f_tangent_0;
var t402:u32=ink_f32_add(t401,(t397).ink_f_tangent_0);
var t403:u32=(t379).ink_f_tangent_1;
var t404:u32=ink_f32_add(t403,(t397).ink_f_tangent_1);
var t405:u32=(t379).ink_f_tangent_2;
var t406:u32=ink_f32_add(t405,(t397).ink_f_tangent_2);
var t407:u32=(t379).ink_f_tangent_3;
var t408:u32=ink_f32_add(t407,(t397).ink_f_tangent_3);
var t409:u32=(t379).ink_f_tangent_4;
var t410:u32=ink_f32_add(t409,(t397).ink_f_tangent_4);
var t411:u32=(t379).ink_f_tangent_5;
var t412:u32=ink_f32_add(t411,(t397).ink_f_tangent_5);
var t413:u32=(t379).ink_f_tangent_6;
var t414:u32=ink_f32_add(t413,(t397).ink_f_tangent_6);
var t415:u32=(t379).ink_f_tangent_7;
var t416:u32=ink_f32_add(t415,(t397).ink_f_tangent_7);
var t417:u32=(t379).ink_f_tangent_8;
var t418:u32=ink_f32_add(t417,(t397).ink_f_tangent_8);
var t419:u32=(t379).ink_f_tangent_9;
var t420:u32=ink_f32_add(t419,(t397).ink_f_tangent_9);
var t421:u32=(t379).ink_f_tangent_10;
var t422:u32=ink_f32_add(t421,(t397).ink_f_tangent_10);
var t423:u32=(t379).ink_f_tangent_11;
var t424:u32=ink_f32_add(t423,(t397).ink_f_tangent_11);
var t425:u32=(t379).ink_f_tangent_12;
var t426:u32=ink_f32_add(t425,(t397).ink_f_tangent_12);
var t427:u32=(t379).ink_f_tangent_13;
var t428:u32=ink_f32_add(t427,(t397).ink_f_tangent_13);
var t429:u32=(t379).ink_f_tangent_14;
var t430:u32=ink_f32_add(t429,(t397).ink_f_tangent_14);
var t431:u32=(t379).ink_f_tangent_15;
var t432:u32=ink_f32_add(t431,(t397).ink_f_tangent_15);
var t433:R___ink_differential_2=R___ink_differential_2(t400,t402,t404,t406,t408,t410,t412,t414,t416,t418,t420,t422,t424,t426,t428,t430,t432);
var t434:u32=(t433).ink_f_tangent_0;
var t435:u32=(t433).ink_f_tangent_1;
var t436:u32=(t433).ink_f_tangent_2;
var t437:u32=(t433).ink_f_tangent_3;
var t438:R_MassRow=R_MassRow(t434,t435,t436,t437);
var t439:u32=(t433).ink_f_tangent_4;
var t440:u32=(t433).ink_f_tangent_5;
var t441:u32=(t433).ink_f_tangent_6;
var t442:u32=(t433).ink_f_tangent_7;
var t443:R_MassRow=R_MassRow(t439,t440,t441,t442);
var t444:u32=(t433).ink_f_tangent_8;
var t445:u32=(t433).ink_f_tangent_9;
var t446:u32=(t433).ink_f_tangent_10;
var t447:u32=(t433).ink_f_tangent_11;
var t448:R_MassRow=R_MassRow(t444,t445,t446,t447);
var t449:u32=(t433).ink_f_tangent_12;
var t450:u32=(t433).ink_f_tangent_13;
var t451:u32=(t433).ink_f_tangent_14;
var t452:u32=(t433).ink_f_tangent_15;
var t453:R_MassRow=R_MassRow(t449,t450,t451,t452);
var t454:R_Parameters=R_Parameters(t438,t443,t448,t453);
output[0u+0u]=bitcast<u32>(((t454).ink_f_a).ink_f_identity);
output[0u+1u]=bitcast<u32>(((t454).ink_f_a).ink_f_scale);
output[0u+2u]=bitcast<u32>(((t454).ink_f_a).ink_f_bias);
output[0u+3u]=bitcast<u32>(((t454).ink_f_a).ink_f_relu);
output[0u+4u]=bitcast<u32>(((t454).ink_f_b).ink_f_identity);
output[0u+5u]=bitcast<u32>(((t454).ink_f_b).ink_f_scale);
output[0u+6u]=bitcast<u32>(((t454).ink_f_b).ink_f_bias);
output[0u+7u]=bitcast<u32>(((t454).ink_f_b).ink_f_relu);
output[0u+8u]=bitcast<u32>(((t454).ink_f_c).ink_f_identity);
output[0u+9u]=bitcast<u32>(((t454).ink_f_c).ink_f_scale);
output[0u+10u]=bitcast<u32>(((t454).ink_f_c).ink_f_bias);
output[0u+11u]=bitcast<u32>(((t454).ink_f_c).ink_f_relu);
output[0u+12u]=bitcast<u32>(((t454).ink_f_d).ink_f_identity);
output[0u+13u]=bitcast<u32>(((t454).ink_f_d).ink_f_scale);
output[0u+14u]=bitcast<u32>(((t454).ink_f_d).ink_f_bias);
output[0u+15u]=bitcast<u32>(((t454).ink_f_d).ink_f_relu);


}