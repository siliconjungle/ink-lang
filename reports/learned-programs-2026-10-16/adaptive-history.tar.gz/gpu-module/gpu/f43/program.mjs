const __recordElisions=new Set([]);
const __nativeF32=true;
// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
// Binary64 uses native Numbers for finite arithmetic and immutable private
// tags only where a NaN's exact payload must survive non-arithmetic operations.
const __doubleView=new DataView(new ArrayBuffer(8));
const __double=bits=>{__doubleView.setBigUint64(0,bits,true);return __doubleView.getFloat64(0,true);};
const __doubleBits=number=>{if(Number.isNaN(number))return 0x7ff8000000000000n;__doubleView.setFloat64(0,number,true);return __doubleView.getBigUint64(0,true);};
const __dfNumber=value=>typeof value==='number'?value:__double(BigInt(value.F64Bits));
const __dfBits=value=>typeof value==='number'?__doubleBits(value):BigInt(value.F64Bits);
const __dfFromBits=bits=>(bits&0x7fffffffffffffffn)>0x7ff0000000000000n?Object.freeze({F64Bits:bits.toString()}):__double(bits);
const __dfInput=value=>typeof value==='number'?value:__dfFromBits(BigInt(value.F64Bits));
const __dfNeg=value=>typeof value==='number'&&!Number.isNaN(value)?-value:__dfFromBits(__dfBits(value)^0x8000000000000000n);
const __dfOutput=value=>{const n=__dfNumber(value);return Number.isFinite(n)?n:{F64Bits:__dfBits(value).toString()};};
const __dfCapture=value=>{
 if(typeof value==='number'&&Number.isFinite(value))return value;
 if(!value||typeof value!=='object'||Object.keys(value).length!==1||!Object.hasOwn(value,'F64Bits'))throw Error('invalid f64');const text=value.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid f64');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');return __dfFromBits(bits);
};
// Native binary32 lane for pure modules. Explicit NaN payloads remain tagged;
// arithmetic canonicalizes NaNs just as __bits does in the exact-bit lane.
const __nfValue = value => typeof value === 'number' ? Math.fround(value) : value;
// Number operands have already been normalised at their typed read or producer.
const __nfNumber = value => typeof value === 'number' ? value : __float(value.F32Bits);
const __nfBits = value => typeof value === 'number' ? __bits(value) : value.F32Bits;
const __nfFromBits = bits => (bits & 0x7fffffff)>0x7f800000 ? {F32Bits:bits} : __float(bits);
const __nfNeg = value => typeof value === 'number' && !Number.isNaN(value) ? -value : {F32Bits:(__nfBits(value) ^ 0x80000000) >>> 0};
const __nfOutput = value => {const n=typeof value==='number'?Math.fround(value):__float(value.F32Bits);return Number.isFinite(n)?n:{F32Bits:__nfBits(value)};};
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output, capture=false) {
  const convert=__representationRaw(type,output,capture);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':capture?'capture:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output, capture) {
  switch (type.kind) {
    case 'ref': {
      let resolved;
      return (value,context)=>(resolved??=__representation(__namedTypes[type.name],output,capture))(value,context);
    }
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output,capture);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output,capture),err=__representation(type.error,output,capture);
      const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);
      if(flat)return output?(value,context)=>{const v=__sumView(key,value);return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};}:(v,context)=>Object.hasOwn(v,'Ok')?__sumMake(key,true,ok(v.Ok,context)):__sumMake(key,false,err(v.Err,context));
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f64':return output?__dfOutput:__dfInput;
    case 'f32': if(typeof __nativeF32!=='undefined'&&__nativeF32)return output?__nfOutput:capture?__nfValue:__identity;
      return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output,capture);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){
        if(!type.fields.length)return ()=>undefined; // lexically unconsumed projected input
        const field=type.fields[0],child=__representation(field.type,output,capture);
        return output?(value,context)=>({[field.name]:child(value,context)}):(value,context)=>child(value[field.name],context);
      }
      const fields = type.fields.map(field => [field.name, __representation(field.type, output,capture)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
function __fn0(v0,v1){
const v2=v1["slot"];
const v3=0;
let v4;if((v2===v3)){
v4=v0["a"];}else{
const v5=v1["slot"];
const v6=1;
let v7;if((v5===v6)){
v7=v0["b"];}else{
const v8=v1["slot"];
const v9=2;
let v10;if((v8===v9)){
v10=v0["c"];}else{
v10=v0["d"];}
v7=v10;}
v4=v7;}
const v11=v4;
const v12=v1["operation"];
const v13=0;
let v14;if((v12===v13)){
v14=v11["identity"];}else{
const v15=v1["operation"];
const v16=1;
let v17;if((v15===v16)){
v17=v11["scale"];}else{
const v18=v1["operation"];
const v19=2;
let v20;if((v18===v19)){
v20=v11["bias"];}else{
v20=v11["relu"];}
v17=v20;}
v14=v17;}
const v21=v14;
const v22=__nfValue(v21["value"]);
const v23=__nfValue(v21["value"]);
const v24=Math.fround(__nfNumber(v22) * __nfNumber(v23));
const v25=__nfValue(v21["tangent_0"]);
const v26=__nfValue(v21["value"]);
const v27=Math.fround(__nfNumber(v25) * __nfNumber(v26));
const v28=__nfValue(v21["value"]);
const v29=__nfValue(v21["tangent_0"]);
const v30=Math.fround(__nfNumber(v28) * __nfNumber(v29));
const v31=Math.fround(v27 + v30);
const v32=__nfValue(v21["tangent_1"]);
const v33=__nfValue(v21["value"]);
const v34=Math.fround(__nfNumber(v32) * __nfNumber(v33));
const v35=__nfValue(v21["value"]);
const v36=__nfValue(v21["tangent_1"]);
const v37=Math.fround(__nfNumber(v35) * __nfNumber(v36));
const v38=Math.fround(v34 + v37);
const v39=__nfValue(v21["tangent_2"]);
const v40=__nfValue(v21["value"]);
const v41=Math.fround(__nfNumber(v39) * __nfNumber(v40));
const v42=__nfValue(v21["value"]);
const v43=__nfValue(v21["tangent_2"]);
const v44=Math.fround(__nfNumber(v42) * __nfNumber(v43));
const v45=Math.fround(v41 + v44);
const v46=__nfValue(v21["tangent_3"]);
const v47=__nfValue(v21["value"]);
const v48=Math.fround(__nfNumber(v46) * __nfNumber(v47));
const v49=__nfValue(v21["value"]);
const v50=__nfValue(v21["tangent_3"]);
const v51=Math.fround(__nfNumber(v49) * __nfNumber(v50));
const v52=Math.fround(v48 + v51);
const v53=__nfValue(v21["tangent_4"]);
const v54=__nfValue(v21["value"]);
const v55=Math.fround(__nfNumber(v53) * __nfNumber(v54));
const v56=__nfValue(v21["value"]);
const v57=__nfValue(v21["tangent_4"]);
const v58=Math.fround(__nfNumber(v56) * __nfNumber(v57));
const v59=Math.fround(v55 + v58);
const v60=__nfValue(v21["tangent_5"]);
const v61=__nfValue(v21["value"]);
const v62=Math.fround(__nfNumber(v60) * __nfNumber(v61));
const v63=__nfValue(v21["value"]);
const v64=__nfValue(v21["tangent_5"]);
const v65=Math.fround(__nfNumber(v63) * __nfNumber(v64));
const v66=Math.fround(v62 + v65);
const v67=__nfValue(v21["tangent_6"]);
const v68=__nfValue(v21["value"]);
const v69=Math.fround(__nfNumber(v67) * __nfNumber(v68));
const v70=__nfValue(v21["value"]);
const v71=__nfValue(v21["tangent_6"]);
const v72=Math.fround(__nfNumber(v70) * __nfNumber(v71));
const v73=Math.fround(v69 + v72);
const v74=__nfValue(v21["tangent_7"]);
const v75=__nfValue(v21["value"]);
const v76=Math.fround(__nfNumber(v74) * __nfNumber(v75));
const v77=__nfValue(v21["value"]);
const v78=__nfValue(v21["tangent_7"]);
const v79=Math.fround(__nfNumber(v77) * __nfNumber(v78));
const v80=Math.fround(v76 + v79);
const v81=__nfValue(v21["tangent_8"]);
const v82=__nfValue(v21["value"]);
const v83=Math.fround(__nfNumber(v81) * __nfNumber(v82));
const v84=__nfValue(v21["value"]);
const v85=__nfValue(v21["tangent_8"]);
const v86=Math.fround(__nfNumber(v84) * __nfNumber(v85));
const v87=Math.fround(v83 + v86);
const v88=__nfValue(v21["tangent_9"]);
const v89=__nfValue(v21["value"]);
const v90=Math.fround(__nfNumber(v88) * __nfNumber(v89));
const v91=__nfValue(v21["value"]);
const v92=__nfValue(v21["tangent_9"]);
const v93=Math.fround(__nfNumber(v91) * __nfNumber(v92));
const v94=Math.fround(v90 + v93);
const v95=__nfValue(v21["tangent_10"]);
const v96=__nfValue(v21["value"]);
const v97=Math.fround(__nfNumber(v95) * __nfNumber(v96));
const v98=__nfValue(v21["value"]);
const v99=__nfValue(v21["tangent_10"]);
const v100=Math.fround(__nfNumber(v98) * __nfNumber(v99));
const v101=Math.fround(v97 + v100);
const v102=__nfValue(v21["tangent_11"]);
const v103=__nfValue(v21["value"]);
const v104=Math.fround(__nfNumber(v102) * __nfNumber(v103));
const v105=__nfValue(v21["value"]);
const v106=__nfValue(v21["tangent_11"]);
const v107=Math.fround(__nfNumber(v105) * __nfNumber(v106));
const v108=Math.fround(v104 + v107);
const v109=__nfValue(v21["tangent_12"]);
const v110=__nfValue(v21["value"]);
const v111=Math.fround(__nfNumber(v109) * __nfNumber(v110));
const v112=__nfValue(v21["value"]);
const v113=__nfValue(v21["tangent_12"]);
const v114=Math.fround(__nfNumber(v112) * __nfNumber(v113));
const v115=Math.fround(v111 + v114);
const v116=__nfValue(v21["tangent_13"]);
const v117=__nfValue(v21["value"]);
const v118=Math.fround(__nfNumber(v116) * __nfNumber(v117));
const v119=__nfValue(v21["value"]);
const v120=__nfValue(v21["tangent_13"]);
const v121=Math.fround(__nfNumber(v119) * __nfNumber(v120));
const v122=Math.fround(v118 + v121);
const v123=__nfValue(v21["tangent_14"]);
const v124=__nfValue(v21["value"]);
const v125=Math.fround(__nfNumber(v123) * __nfNumber(v124));
const v126=__nfValue(v21["value"]);
const v127=__nfValue(v21["tangent_14"]);
const v128=Math.fround(__nfNumber(v126) * __nfNumber(v127));
const v129=Math.fround(v125 + v128);
const v130=__nfValue(v21["tangent_15"]);
const v131=__nfValue(v21["value"]);
const v132=Math.fround(__nfNumber(v130) * __nfNumber(v131));
const v133=__nfValue(v21["value"]);
const v134=__nfValue(v21["tangent_15"]);
const v135=Math.fround(__nfNumber(v133) * __nfNumber(v134));
const v136=Math.fround(v132 + v135);
const v138=__nfFromBits(1036831949);
const v139=__nfFromBits(0);
const v140=__nfFromBits(0);
const v141=__nfFromBits(0);
const v142=__nfFromBits(0);
const v143=__nfFromBits(0);
const v144=__nfFromBits(0);
const v145=__nfFromBits(0);
const v146=__nfFromBits(0);
const v147=__nfFromBits(0);
const v148=__nfFromBits(0);
const v149=__nfFromBits(0);
const v150=__nfFromBits(0);
const v151=__nfFromBits(0);
const v152=__nfFromBits(0);
const v153=__nfFromBits(0);
const v154=__nfFromBits(0);
const v156=Math.fround(v24 + v138);
const v157=Math.fround(v31 + v139);
const v158=Math.fround(v38 + v140);
const v159=Math.fround(v45 + v141);
const v160=Math.fround(v52 + v142);
const v161=Math.fround(v59 + v143);
const v162=Math.fround(v66 + v144);
const v163=Math.fround(v73 + v145);
const v164=Math.fround(v80 + v146);
const v165=Math.fround(v87 + v147);
const v166=Math.fround(v94 + v148);
const v167=Math.fround(v101 + v149);
const v168=Math.fround(v108 + v150);
const v169=Math.fround(v115 + v151);
const v170=Math.fround(v122 + v152);
const v171=Math.fround(v129 + v153);
const v172=Math.fround(v136 + v154);
return ({["value"]:v156,["tangent_0"]:v157,["tangent_1"]:v158,["tangent_2"]:v159,["tangent_3"]:v160,["tangent_4"]:v161,["tangent_5"]:v162,["tangent_6"]:v163,["tangent_7"]:v164,["tangent_8"]:v165,["tangent_9"]:v166,["tangent_10"]:v167,["tangent_11"]:v168,["tangent_12"]:v169,["tangent_13"]:v170,["tangent_14"]:v171,["tangent_15"]:v172});}
function __fn1(v173,v174){
const v175=v173["a"];
const v176=__nfValue(v175["identity"]);
const v177=__nfFromBits(1065353216);
const v178=__nfFromBits(0);
const v179=__nfFromBits(0);
const v180=__nfFromBits(0);
const v181=__nfFromBits(0);
const v182=__nfFromBits(0);
const v183=__nfFromBits(0);
const v184=__nfFromBits(0);
const v185=__nfFromBits(0);
const v186=__nfFromBits(0);
const v187=__nfFromBits(0);
const v188=__nfFromBits(0);
const v189=__nfFromBits(0);
const v190=__nfFromBits(0);
const v191=__nfFromBits(0);
const v192=__nfFromBits(0);
const v193=({["value"]:v176,["tangent_0"]:v177,["tangent_1"]:v178,["tangent_2"]:v179,["tangent_3"]:v180,["tangent_4"]:v181,["tangent_5"]:v182,["tangent_6"]:v183,["tangent_7"]:v184,["tangent_8"]:v185,["tangent_9"]:v186,["tangent_10"]:v187,["tangent_11"]:v188,["tangent_12"]:v189,["tangent_13"]:v190,["tangent_14"]:v191,["tangent_15"]:v192});
const v194=v173["a"];
const v195=__nfValue(v194["scale"]);
const v196=__nfFromBits(0);
const v197=__nfFromBits(1065353216);
const v198=__nfFromBits(0);
const v199=__nfFromBits(0);
const v200=__nfFromBits(0);
const v201=__nfFromBits(0);
const v202=__nfFromBits(0);
const v203=__nfFromBits(0);
const v204=__nfFromBits(0);
const v205=__nfFromBits(0);
const v206=__nfFromBits(0);
const v207=__nfFromBits(0);
const v208=__nfFromBits(0);
const v209=__nfFromBits(0);
const v210=__nfFromBits(0);
const v211=__nfFromBits(0);
const v212=({["value"]:v195,["tangent_0"]:v196,["tangent_1"]:v197,["tangent_2"]:v198,["tangent_3"]:v199,["tangent_4"]:v200,["tangent_5"]:v201,["tangent_6"]:v202,["tangent_7"]:v203,["tangent_8"]:v204,["tangent_9"]:v205,["tangent_10"]:v206,["tangent_11"]:v207,["tangent_12"]:v208,["tangent_13"]:v209,["tangent_14"]:v210,["tangent_15"]:v211});
const v213=v173["a"];
const v214=__nfValue(v213["bias"]);
const v215=__nfFromBits(0);
const v216=__nfFromBits(0);
const v217=__nfFromBits(1065353216);
const v218=__nfFromBits(0);
const v219=__nfFromBits(0);
const v220=__nfFromBits(0);
const v221=__nfFromBits(0);
const v222=__nfFromBits(0);
const v223=__nfFromBits(0);
const v224=__nfFromBits(0);
const v225=__nfFromBits(0);
const v226=__nfFromBits(0);
const v227=__nfFromBits(0);
const v228=__nfFromBits(0);
const v229=__nfFromBits(0);
const v230=__nfFromBits(0);
const v231=({["value"]:v214,["tangent_0"]:v215,["tangent_1"]:v216,["tangent_2"]:v217,["tangent_3"]:v218,["tangent_4"]:v219,["tangent_5"]:v220,["tangent_6"]:v221,["tangent_7"]:v222,["tangent_8"]:v223,["tangent_9"]:v224,["tangent_10"]:v225,["tangent_11"]:v226,["tangent_12"]:v227,["tangent_13"]:v228,["tangent_14"]:v229,["tangent_15"]:v230});
const v232=v173["a"];
const v233=__nfValue(v232["relu"]);
const v234=__nfFromBits(0);
const v235=__nfFromBits(0);
const v236=__nfFromBits(0);
const v237=__nfFromBits(1065353216);
const v238=__nfFromBits(0);
const v239=__nfFromBits(0);
const v240=__nfFromBits(0);
const v241=__nfFromBits(0);
const v242=__nfFromBits(0);
const v243=__nfFromBits(0);
const v244=__nfFromBits(0);
const v245=__nfFromBits(0);
const v246=__nfFromBits(0);
const v247=__nfFromBits(0);
const v248=__nfFromBits(0);
const v249=__nfFromBits(0);
const v250=({["value"]:v233,["tangent_0"]:v234,["tangent_1"]:v235,["tangent_2"]:v236,["tangent_3"]:v237,["tangent_4"]:v238,["tangent_5"]:v239,["tangent_6"]:v240,["tangent_7"]:v241,["tangent_8"]:v242,["tangent_9"]:v243,["tangent_10"]:v244,["tangent_11"]:v245,["tangent_12"]:v246,["tangent_13"]:v247,["tangent_14"]:v248,["tangent_15"]:v249});
const v251=({["identity"]:v193,["scale"]:v212,["bias"]:v231,["relu"]:v250});
const v252=v173["b"];
const v253=__nfValue(v252["identity"]);
const v254=__nfFromBits(0);
const v255=__nfFromBits(0);
const v256=__nfFromBits(0);
const v257=__nfFromBits(0);
const v258=__nfFromBits(1065353216);
const v259=__nfFromBits(0);
const v260=__nfFromBits(0);
const v261=__nfFromBits(0);
const v262=__nfFromBits(0);
const v263=__nfFromBits(0);
const v264=__nfFromBits(0);
const v265=__nfFromBits(0);
const v266=__nfFromBits(0);
const v267=__nfFromBits(0);
const v268=__nfFromBits(0);
const v269=__nfFromBits(0);
const v270=({["value"]:v253,["tangent_0"]:v254,["tangent_1"]:v255,["tangent_2"]:v256,["tangent_3"]:v257,["tangent_4"]:v258,["tangent_5"]:v259,["tangent_6"]:v260,["tangent_7"]:v261,["tangent_8"]:v262,["tangent_9"]:v263,["tangent_10"]:v264,["tangent_11"]:v265,["tangent_12"]:v266,["tangent_13"]:v267,["tangent_14"]:v268,["tangent_15"]:v269});
const v271=v173["b"];
const v272=__nfValue(v271["scale"]);
const v273=__nfFromBits(0);
const v274=__nfFromBits(0);
const v275=__nfFromBits(0);
const v276=__nfFromBits(0);
const v277=__nfFromBits(0);
const v278=__nfFromBits(1065353216);
const v279=__nfFromBits(0);
const v280=__nfFromBits(0);
const v281=__nfFromBits(0);
const v282=__nfFromBits(0);
const v283=__nfFromBits(0);
const v284=__nfFromBits(0);
const v285=__nfFromBits(0);
const v286=__nfFromBits(0);
const v287=__nfFromBits(0);
const v288=__nfFromBits(0);
const v289=({["value"]:v272,["tangent_0"]:v273,["tangent_1"]:v274,["tangent_2"]:v275,["tangent_3"]:v276,["tangent_4"]:v277,["tangent_5"]:v278,["tangent_6"]:v279,["tangent_7"]:v280,["tangent_8"]:v281,["tangent_9"]:v282,["tangent_10"]:v283,["tangent_11"]:v284,["tangent_12"]:v285,["tangent_13"]:v286,["tangent_14"]:v287,["tangent_15"]:v288});
const v290=v173["b"];
const v291=__nfValue(v290["bias"]);
const v292=__nfFromBits(0);
const v293=__nfFromBits(0);
const v294=__nfFromBits(0);
const v295=__nfFromBits(0);
const v296=__nfFromBits(0);
const v297=__nfFromBits(0);
const v298=__nfFromBits(1065353216);
const v299=__nfFromBits(0);
const v300=__nfFromBits(0);
const v301=__nfFromBits(0);
const v302=__nfFromBits(0);
const v303=__nfFromBits(0);
const v304=__nfFromBits(0);
const v305=__nfFromBits(0);
const v306=__nfFromBits(0);
const v307=__nfFromBits(0);
const v308=({["value"]:v291,["tangent_0"]:v292,["tangent_1"]:v293,["tangent_2"]:v294,["tangent_3"]:v295,["tangent_4"]:v296,["tangent_5"]:v297,["tangent_6"]:v298,["tangent_7"]:v299,["tangent_8"]:v300,["tangent_9"]:v301,["tangent_10"]:v302,["tangent_11"]:v303,["tangent_12"]:v304,["tangent_13"]:v305,["tangent_14"]:v306,["tangent_15"]:v307});
const v309=v173["b"];
const v310=__nfValue(v309["relu"]);
const v311=__nfFromBits(0);
const v312=__nfFromBits(0);
const v313=__nfFromBits(0);
const v314=__nfFromBits(0);
const v315=__nfFromBits(0);
const v316=__nfFromBits(0);
const v317=__nfFromBits(0);
const v318=__nfFromBits(1065353216);
const v319=__nfFromBits(0);
const v320=__nfFromBits(0);
const v321=__nfFromBits(0);
const v322=__nfFromBits(0);
const v323=__nfFromBits(0);
const v324=__nfFromBits(0);
const v325=__nfFromBits(0);
const v326=__nfFromBits(0);
const v327=({["value"]:v310,["tangent_0"]:v311,["tangent_1"]:v312,["tangent_2"]:v313,["tangent_3"]:v314,["tangent_4"]:v315,["tangent_5"]:v316,["tangent_6"]:v317,["tangent_7"]:v318,["tangent_8"]:v319,["tangent_9"]:v320,["tangent_10"]:v321,["tangent_11"]:v322,["tangent_12"]:v323,["tangent_13"]:v324,["tangent_14"]:v325,["tangent_15"]:v326});
const v328=({["identity"]:v270,["scale"]:v289,["bias"]:v308,["relu"]:v327});
const v329=v173["c"];
const v330=__nfValue(v329["identity"]);
const v331=__nfFromBits(0);
const v332=__nfFromBits(0);
const v333=__nfFromBits(0);
const v334=__nfFromBits(0);
const v335=__nfFromBits(0);
const v336=__nfFromBits(0);
const v337=__nfFromBits(0);
const v338=__nfFromBits(0);
const v339=__nfFromBits(1065353216);
const v340=__nfFromBits(0);
const v341=__nfFromBits(0);
const v342=__nfFromBits(0);
const v343=__nfFromBits(0);
const v344=__nfFromBits(0);
const v345=__nfFromBits(0);
const v346=__nfFromBits(0);
const v347=({["value"]:v330,["tangent_0"]:v331,["tangent_1"]:v332,["tangent_2"]:v333,["tangent_3"]:v334,["tangent_4"]:v335,["tangent_5"]:v336,["tangent_6"]:v337,["tangent_7"]:v338,["tangent_8"]:v339,["tangent_9"]:v340,["tangent_10"]:v341,["tangent_11"]:v342,["tangent_12"]:v343,["tangent_13"]:v344,["tangent_14"]:v345,["tangent_15"]:v346});
const v348=v173["c"];
const v349=__nfValue(v348["scale"]);
const v350=__nfFromBits(0);
const v351=__nfFromBits(0);
const v352=__nfFromBits(0);
const v353=__nfFromBits(0);
const v354=__nfFromBits(0);
const v355=__nfFromBits(0);
const v356=__nfFromBits(0);
const v357=__nfFromBits(0);
const v358=__nfFromBits(0);
const v359=__nfFromBits(1065353216);
const v360=__nfFromBits(0);
const v361=__nfFromBits(0);
const v362=__nfFromBits(0);
const v363=__nfFromBits(0);
const v364=__nfFromBits(0);
const v365=__nfFromBits(0);
const v366=({["value"]:v349,["tangent_0"]:v350,["tangent_1"]:v351,["tangent_2"]:v352,["tangent_3"]:v353,["tangent_4"]:v354,["tangent_5"]:v355,["tangent_6"]:v356,["tangent_7"]:v357,["tangent_8"]:v358,["tangent_9"]:v359,["tangent_10"]:v360,["tangent_11"]:v361,["tangent_12"]:v362,["tangent_13"]:v363,["tangent_14"]:v364,["tangent_15"]:v365});
const v367=v173["c"];
const v368=__nfValue(v367["bias"]);
const v369=__nfFromBits(0);
const v370=__nfFromBits(0);
const v371=__nfFromBits(0);
const v372=__nfFromBits(0);
const v373=__nfFromBits(0);
const v374=__nfFromBits(0);
const v375=__nfFromBits(0);
const v376=__nfFromBits(0);
const v377=__nfFromBits(0);
const v378=__nfFromBits(0);
const v379=__nfFromBits(1065353216);
const v380=__nfFromBits(0);
const v381=__nfFromBits(0);
const v382=__nfFromBits(0);
const v383=__nfFromBits(0);
const v384=__nfFromBits(0);
const v385=({["value"]:v368,["tangent_0"]:v369,["tangent_1"]:v370,["tangent_2"]:v371,["tangent_3"]:v372,["tangent_4"]:v373,["tangent_5"]:v374,["tangent_6"]:v375,["tangent_7"]:v376,["tangent_8"]:v377,["tangent_9"]:v378,["tangent_10"]:v379,["tangent_11"]:v380,["tangent_12"]:v381,["tangent_13"]:v382,["tangent_14"]:v383,["tangent_15"]:v384});
const v386=v173["c"];
const v387=__nfValue(v386["relu"]);
const v388=__nfFromBits(0);
const v389=__nfFromBits(0);
const v390=__nfFromBits(0);
const v391=__nfFromBits(0);
const v392=__nfFromBits(0);
const v393=__nfFromBits(0);
const v394=__nfFromBits(0);
const v395=__nfFromBits(0);
const v396=__nfFromBits(0);
const v397=__nfFromBits(0);
const v398=__nfFromBits(0);
const v399=__nfFromBits(1065353216);
const v400=__nfFromBits(0);
const v401=__nfFromBits(0);
const v402=__nfFromBits(0);
const v403=__nfFromBits(0);
const v404=({["value"]:v387,["tangent_0"]:v388,["tangent_1"]:v389,["tangent_2"]:v390,["tangent_3"]:v391,["tangent_4"]:v392,["tangent_5"]:v393,["tangent_6"]:v394,["tangent_7"]:v395,["tangent_8"]:v396,["tangent_9"]:v397,["tangent_10"]:v398,["tangent_11"]:v399,["tangent_12"]:v400,["tangent_13"]:v401,["tangent_14"]:v402,["tangent_15"]:v403});
const v405=({["identity"]:v347,["scale"]:v366,["bias"]:v385,["relu"]:v404});
const v406=v173["d"];
const v407=__nfValue(v406["identity"]);
const v408=__nfFromBits(0);
const v409=__nfFromBits(0);
const v410=__nfFromBits(0);
const v411=__nfFromBits(0);
const v412=__nfFromBits(0);
const v413=__nfFromBits(0);
const v414=__nfFromBits(0);
const v415=__nfFromBits(0);
const v416=__nfFromBits(0);
const v417=__nfFromBits(0);
const v418=__nfFromBits(0);
const v419=__nfFromBits(0);
const v420=__nfFromBits(1065353216);
const v421=__nfFromBits(0);
const v422=__nfFromBits(0);
const v423=__nfFromBits(0);
const v424=({["value"]:v407,["tangent_0"]:v408,["tangent_1"]:v409,["tangent_2"]:v410,["tangent_3"]:v411,["tangent_4"]:v412,["tangent_5"]:v413,["tangent_6"]:v414,["tangent_7"]:v415,["tangent_8"]:v416,["tangent_9"]:v417,["tangent_10"]:v418,["tangent_11"]:v419,["tangent_12"]:v420,["tangent_13"]:v421,["tangent_14"]:v422,["tangent_15"]:v423});
const v425=v173["d"];
const v426=__nfValue(v425["scale"]);
const v427=__nfFromBits(0);
const v428=__nfFromBits(0);
const v429=__nfFromBits(0);
const v430=__nfFromBits(0);
const v431=__nfFromBits(0);
const v432=__nfFromBits(0);
const v433=__nfFromBits(0);
const v434=__nfFromBits(0);
const v435=__nfFromBits(0);
const v436=__nfFromBits(0);
const v437=__nfFromBits(0);
const v438=__nfFromBits(0);
const v439=__nfFromBits(0);
const v440=__nfFromBits(1065353216);
const v441=__nfFromBits(0);
const v442=__nfFromBits(0);
const v443=({["value"]:v426,["tangent_0"]:v427,["tangent_1"]:v428,["tangent_2"]:v429,["tangent_3"]:v430,["tangent_4"]:v431,["tangent_5"]:v432,["tangent_6"]:v433,["tangent_7"]:v434,["tangent_8"]:v435,["tangent_9"]:v436,["tangent_10"]:v437,["tangent_11"]:v438,["tangent_12"]:v439,["tangent_13"]:v440,["tangent_14"]:v441,["tangent_15"]:v442});
const v444=v173["d"];
const v445=__nfValue(v444["bias"]);
const v446=__nfFromBits(0);
const v447=__nfFromBits(0);
const v448=__nfFromBits(0);
const v449=__nfFromBits(0);
const v450=__nfFromBits(0);
const v451=__nfFromBits(0);
const v452=__nfFromBits(0);
const v453=__nfFromBits(0);
const v454=__nfFromBits(0);
const v455=__nfFromBits(0);
const v456=__nfFromBits(0);
const v457=__nfFromBits(0);
const v458=__nfFromBits(0);
const v459=__nfFromBits(0);
const v460=__nfFromBits(1065353216);
const v461=__nfFromBits(0);
const v462=({["value"]:v445,["tangent_0"]:v446,["tangent_1"]:v447,["tangent_2"]:v448,["tangent_3"]:v449,["tangent_4"]:v450,["tangent_5"]:v451,["tangent_6"]:v452,["tangent_7"]:v453,["tangent_8"]:v454,["tangent_9"]:v455,["tangent_10"]:v456,["tangent_11"]:v457,["tangent_12"]:v458,["tangent_13"]:v459,["tangent_14"]:v460,["tangent_15"]:v461});
const v463=v173["d"];
const v464=__nfValue(v463["relu"]);
const v465=__nfFromBits(0);
const v466=__nfFromBits(0);
const v467=__nfFromBits(0);
const v468=__nfFromBits(0);
const v469=__nfFromBits(0);
const v470=__nfFromBits(0);
const v471=__nfFromBits(0);
const v472=__nfFromBits(0);
const v473=__nfFromBits(0);
const v474=__nfFromBits(0);
const v475=__nfFromBits(0);
const v476=__nfFromBits(0);
const v477=__nfFromBits(0);
const v478=__nfFromBits(0);
const v479=__nfFromBits(0);
const v480=__nfFromBits(1065353216);
const v481=({["value"]:v464,["tangent_0"]:v465,["tangent_1"]:v466,["tangent_2"]:v467,["tangent_3"]:v468,["tangent_4"]:v469,["tangent_5"]:v470,["tangent_6"]:v471,["tangent_7"]:v472,["tangent_8"]:v473,["tangent_9"]:v474,["tangent_10"]:v475,["tangent_11"]:v476,["tangent_12"]:v477,["tangent_13"]:v478,["tangent_14"]:v479,["tangent_15"]:v480});
const v482=({["identity"]:v424,["scale"]:v443,["bias"]:v462,["relu"]:v481});
const v484=v174["slot"];
const v485=v174["operation"];
const v487=0;
let v488;
let v489;
let v490;
let v491;
if((v484===v487)){
v488=v251["identity"];
v489=v251["scale"];
v490=v251["bias"];
v491=v251["relu"];
}else{
const v492=1;
let v493;
let v494;
let v495;
let v496;
if((v484===v492)){
v493=v328["identity"];
v494=v328["scale"];
v495=v328["bias"];
v496=v328["relu"];
}else{
const v497=2;
let v498;
let v499;
let v500;
let v501;
if((v484===v497)){
v498=v405["identity"];
v499=v405["scale"];
v500=v405["bias"];
v501=v405["relu"];
}else{
v498=v482["identity"];
v499=v482["scale"];
v500=v482["bias"];
v501=v482["relu"];
}
v493=v498;
v494=v499;
v495=v500;
v496=v501;
}
v488=v493;
v489=v494;
v490=v495;
v491=v496;
}
const v503=0;
let v504;
let v505;
let v506;
let v507;
let v508;
let v509;
let v510;
let v511;
let v512;
let v513;
let v514;
let v515;
let v516;
let v517;
let v518;
let v519;
let v520;
if((v485===v503)){
const v521=v488;
v504=v521["value"];
v505=v521["tangent_0"];
v506=v521["tangent_1"];
v507=v521["tangent_2"];
v508=v521["tangent_3"];
v509=v521["tangent_4"];
v510=v521["tangent_5"];
v511=v521["tangent_6"];
v512=v521["tangent_7"];
v513=v521["tangent_8"];
v514=v521["tangent_9"];
v515=v521["tangent_10"];
v516=v521["tangent_11"];
v517=v521["tangent_12"];
v518=v521["tangent_13"];
v519=v521["tangent_14"];
v520=v521["tangent_15"];
}else{
const v522=1;
let v523;
let v524;
let v525;
let v526;
let v527;
let v528;
let v529;
let v530;
let v531;
let v532;
let v533;
let v534;
let v535;
let v536;
let v537;
let v538;
let v539;
if((v485===v522)){
const v540=v489;
v523=v540["value"];
v524=v540["tangent_0"];
v525=v540["tangent_1"];
v526=v540["tangent_2"];
v527=v540["tangent_3"];
v528=v540["tangent_4"];
v529=v540["tangent_5"];
v530=v540["tangent_6"];
v531=v540["tangent_7"];
v532=v540["tangent_8"];
v533=v540["tangent_9"];
v534=v540["tangent_10"];
v535=v540["tangent_11"];
v536=v540["tangent_12"];
v537=v540["tangent_13"];
v538=v540["tangent_14"];
v539=v540["tangent_15"];
}else{
const v541=2;
let v542;
let v543;
let v544;
let v545;
let v546;
let v547;
let v548;
let v549;
let v550;
let v551;
let v552;
let v553;
let v554;
let v555;
let v556;
let v557;
let v558;
if((v485===v541)){
const v559=v490;
v542=v559["value"];
v543=v559["tangent_0"];
v544=v559["tangent_1"];
v545=v559["tangent_2"];
v546=v559["tangent_3"];
v547=v559["tangent_4"];
v548=v559["tangent_5"];
v549=v559["tangent_6"];
v550=v559["tangent_7"];
v551=v559["tangent_8"];
v552=v559["tangent_9"];
v553=v559["tangent_10"];
v554=v559["tangent_11"];
v555=v559["tangent_12"];
v556=v559["tangent_13"];
v557=v559["tangent_14"];
v558=v559["tangent_15"];
}else{
const v560=v491;
v542=v560["value"];
v543=v560["tangent_0"];
v544=v560["tangent_1"];
v545=v560["tangent_2"];
v546=v560["tangent_3"];
v547=v560["tangent_4"];
v548=v560["tangent_5"];
v549=v560["tangent_6"];
v550=v560["tangent_7"];
v551=v560["tangent_8"];
v552=v560["tangent_9"];
v553=v560["tangent_10"];
v554=v560["tangent_11"];
v555=v560["tangent_12"];
v556=v560["tangent_13"];
v557=v560["tangent_14"];
v558=v560["tangent_15"];
}
v523=v542;
v524=v543;
v525=v544;
v526=v545;
v527=v546;
v528=v547;
v529=v548;
v530=v549;
v531=v550;
v532=v551;
v533=v552;
v534=v553;
v535=v554;
v536=v555;
v537=v556;
v538=v557;
v539=v558;
}
v504=v523;
v505=v524;
v506=v525;
v507=v526;
v508=v527;
v509=v528;
v510=v529;
v511=v530;
v512=v531;
v513=v532;
v514=v533;
v515=v534;
v516=v535;
v517=v536;
v518=v537;
v519=v538;
v520=v539;
}
const v562=__nfValue(v504);
const v563=__nfValue(v504);
const v564=Math.fround(__nfNumber(v562) * __nfNumber(v563));
const v565=__nfValue(v505);
const v566=__nfValue(v504);
const v567=Math.fround(__nfNumber(v565) * __nfNumber(v566));
const v568=__nfValue(v504);
const v569=__nfValue(v505);
const v570=Math.fround(__nfNumber(v568) * __nfNumber(v569));
const v571=Math.fround(v567 + v570);
const v572=__nfValue(v506);
const v573=__nfValue(v504);
const v574=Math.fround(__nfNumber(v572) * __nfNumber(v573));
const v575=__nfValue(v504);
const v576=__nfValue(v506);
const v577=Math.fround(__nfNumber(v575) * __nfNumber(v576));
const v578=Math.fround(v574 + v577);
const v579=__nfValue(v507);
const v580=__nfValue(v504);
const v581=Math.fround(__nfNumber(v579) * __nfNumber(v580));
const v582=__nfValue(v504);
const v583=__nfValue(v507);
const v584=Math.fround(__nfNumber(v582) * __nfNumber(v583));
const v585=Math.fround(v581 + v584);
const v586=__nfValue(v508);
const v587=__nfValue(v504);
const v588=Math.fround(__nfNumber(v586) * __nfNumber(v587));
const v589=__nfValue(v504);
const v590=__nfValue(v508);
const v591=Math.fround(__nfNumber(v589) * __nfNumber(v590));
const v592=Math.fround(v588 + v591);
const v593=__nfValue(v509);
const v594=__nfValue(v504);
const v595=Math.fround(__nfNumber(v593) * __nfNumber(v594));
const v596=__nfValue(v504);
const v597=__nfValue(v509);
const v598=Math.fround(__nfNumber(v596) * __nfNumber(v597));
const v599=Math.fround(v595 + v598);
const v600=__nfValue(v510);
const v601=__nfValue(v504);
const v602=Math.fround(__nfNumber(v600) * __nfNumber(v601));
const v603=__nfValue(v504);
const v604=__nfValue(v510);
const v605=Math.fround(__nfNumber(v603) * __nfNumber(v604));
const v606=Math.fround(v602 + v605);
const v607=__nfValue(v511);
const v608=__nfValue(v504);
const v609=Math.fround(__nfNumber(v607) * __nfNumber(v608));
const v610=__nfValue(v504);
const v611=__nfValue(v511);
const v612=Math.fround(__nfNumber(v610) * __nfNumber(v611));
const v613=Math.fround(v609 + v612);
const v614=__nfValue(v512);
const v615=__nfValue(v504);
const v616=Math.fround(__nfNumber(v614) * __nfNumber(v615));
const v617=__nfValue(v504);
const v618=__nfValue(v512);
const v619=Math.fround(__nfNumber(v617) * __nfNumber(v618));
const v620=Math.fround(v616 + v619);
const v621=__nfValue(v513);
const v622=__nfValue(v504);
const v623=Math.fround(__nfNumber(v621) * __nfNumber(v622));
const v624=__nfValue(v504);
const v625=__nfValue(v513);
const v626=Math.fround(__nfNumber(v624) * __nfNumber(v625));
const v627=Math.fround(v623 + v626);
const v628=__nfValue(v514);
const v629=__nfValue(v504);
const v630=Math.fround(__nfNumber(v628) * __nfNumber(v629));
const v631=__nfValue(v504);
const v632=__nfValue(v514);
const v633=Math.fround(__nfNumber(v631) * __nfNumber(v632));
const v634=Math.fround(v630 + v633);
const v635=__nfValue(v515);
const v636=__nfValue(v504);
const v637=Math.fround(__nfNumber(v635) * __nfNumber(v636));
const v638=__nfValue(v504);
const v639=__nfValue(v515);
const v640=Math.fround(__nfNumber(v638) * __nfNumber(v639));
const v641=Math.fround(v637 + v640);
const v642=__nfValue(v516);
const v643=__nfValue(v504);
const v644=Math.fround(__nfNumber(v642) * __nfNumber(v643));
const v645=__nfValue(v504);
const v646=__nfValue(v516);
const v647=Math.fround(__nfNumber(v645) * __nfNumber(v646));
const v648=Math.fround(v644 + v647);
const v649=__nfValue(v517);
const v650=__nfValue(v504);
const v651=Math.fround(__nfNumber(v649) * __nfNumber(v650));
const v652=__nfValue(v504);
const v653=__nfValue(v517);
const v654=Math.fround(__nfNumber(v652) * __nfNumber(v653));
const v655=Math.fround(v651 + v654);
const v656=__nfValue(v518);
const v657=__nfValue(v504);
const v658=Math.fround(__nfNumber(v656) * __nfNumber(v657));
const v659=__nfValue(v504);
const v660=__nfValue(v518);
const v661=Math.fround(__nfNumber(v659) * __nfNumber(v660));
const v662=Math.fround(v658 + v661);
const v663=__nfValue(v519);
const v664=__nfValue(v504);
const v665=Math.fround(__nfNumber(v663) * __nfNumber(v664));
const v666=__nfValue(v504);
const v667=__nfValue(v519);
const v668=Math.fround(__nfNumber(v666) * __nfNumber(v667));
const v669=Math.fround(v665 + v668);
const v670=__nfValue(v520);
const v671=__nfValue(v504);
const v672=Math.fround(__nfNumber(v670) * __nfNumber(v671));
const v673=__nfValue(v504);
const v674=__nfValue(v520);
const v675=Math.fround(__nfNumber(v673) * __nfNumber(v674));
const v676=Math.fround(v672 + v675);
const v678=__nfFromBits(1036831949);
const v679=__nfFromBits(0);
const v680=__nfFromBits(0);
const v681=__nfFromBits(0);
const v682=__nfFromBits(0);
const v683=__nfFromBits(0);
const v684=__nfFromBits(0);
const v685=__nfFromBits(0);
const v686=__nfFromBits(0);
const v687=__nfFromBits(0);
const v688=__nfFromBits(0);
const v689=__nfFromBits(0);
const v690=__nfFromBits(0);
const v691=__nfFromBits(0);
const v692=__nfFromBits(0);
const v693=__nfFromBits(0);
const v694=__nfFromBits(0);
const v696=Math.fround(v564 + v678);
const v697=Math.fround(v571 + v679);
const v698=Math.fround(v578 + v680);
const v699=Math.fround(v585 + v681);
const v700=Math.fround(v592 + v682);
const v701=Math.fround(v599 + v683);
const v702=Math.fround(v606 + v684);
const v703=Math.fround(v613 + v685);
const v704=Math.fround(v620 + v686);
const v705=Math.fround(v627 + v687);
const v706=Math.fround(v634 + v688);
const v707=Math.fround(v641 + v689);
const v708=Math.fround(v648 + v690);
const v709=Math.fround(v655 + v691);
const v710=Math.fround(v662 + v692);
const v711=Math.fround(v669 + v693);
const v712=Math.fround(v676 + v694);
const v714=({["identity"]:v697,["scale"]:v698,["bias"]:v699,["relu"]:v700});
const v715=({["identity"]:v701,["scale"]:v702,["bias"]:v703,["relu"]:v704});
const v716=({["identity"]:v705,["scale"]:v706,["bias"]:v707,["relu"]:v708});
const v717=({["identity"]:v709,["scale"]:v710,["bias"]:v711,["relu"]:v712});
return ({["a"]:v714,["b"]:v715,["c"]:v716,["d"]:v717});}
const __namedTypes={"MassRow":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"},"Parameters":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"},"Pick":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"Pick"},"__ink_differential_2":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"},"__ink_differential_4":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"},"__ink_differential_5":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"},"__ink_differential_6":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_6"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v7","core_sha256":"0d3e179a776bbea361e45f0d2881b885b4097970959b37651880badc568eb204","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"f32_storage":"native-number-with-exact-nonfinite-tags","functions":[{"destination":null,"index":0,"internal":false,"name":"__ink_differential_3","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"}},{"name":"p","type":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_6"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"destination":null,"index":1,"internal":false,"name":"__ink_differential_1","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}},{"name":"p","type":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"Pick"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}}],"named_types":{"MassRow":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"},"Parameters":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"},"Pick":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"Pick"},"__ink_differential_2":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"},"__ink_differential_4":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"},"__ink_differential_5":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"},"__ink_differential_6":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_6"}},"prepared_compiled":{"evaluation":"lazy source-order; successful bindings only","functions":[{"delegated_calls":0,"factory":true,"function":"__ink_differential_3","retained_bindings":2},{"delegated_calls":1,"factory":true,"function":"__ink_differential_1","retained_bindings":1}],"lifetime":"prepared token","semantics":"sealed-value-residual-v1"},"private_record_elisions":[],"private_sum_spines":[],"schema":1,"state":null,"wire":{"format":"ink-value-wire-v1","functions":{"__ink_differential_1":{"arguments":{"format":"ink-value-wire-v1","identity":"d9a2817b6f5795592e5f12e4e54fd3af0061b7a04d8d3e55dd63c3a2e7b0558e","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}},{"name":"p","type":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"Pick"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"2af269616d48554c4ef5e8a1371afd52412f1ef4f05c2d9506bd43bfde5de326","named":{},"root":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}}},"__ink_differential_3":{"arguments":{"format":"ink-value-wire-v1","identity":"d75895cfaa56f5921632cb59e1d374ad909ca98b00fd2271f993b80ac8cdcc66","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"}},{"name":"p","type":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_6"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"cfdb397c2afc9c623de1f1010b9630cbab4a4f82a83884720c53cd04425275d8","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}}}}};
const __implementations=[__fn0,__fn1];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
const __inputTypes=[{"capture":[false,false],"types":[{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"},{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_6"}]},{"capture":[false,false],"types":[{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"},{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"Pick"}]}];

// Descriptor work occurs once at module initialisation, never per word-list call.
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=> {
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const output=__representation(f.result,true);
  const body=__implementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
  const needsInput=input.some(c=>c!==__identity);
  const entry=!needsInput && output===__identity ? implementation :
    (...args)=>{const context=new WeakMap();return output(implementation(...(needsInput ? args.map((v,i)=>input[i](v,context)) : args)),context);};
  return [f.name,entry];
})));
export function call(name,args) { return functions[name](...args); }
// Shared bounded binary codec; generated code supplies exact descriptors.
export const valueWireFormat='ink-value-wire-v1';
// A connection agrees on the complete value schema before using this format.
// Version byte + schema-directed fields; schema identity is out of band.
export const compactValueWireFormat='ink-value-session-v1';
const wireMagic=Uint8Array.of(73,78,75,86,65,76,0,1);
const wireEncoder=new TextEncoder(),wireDecoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const wireDefaults=Object.freeze({bytes:16777216,nodes:1000000,depth:128}),wireDefaultOptions=Object.freeze({});
const wireDecimal=s=>typeof s==='string'&&/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(s);
function wireLimits(options){if(options===wireDefaultOptions||options===wireDefaults)return wireDefaults;const l={...wireDefaults,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>wireDefaults[k])throw Error('wire hard resource limit');return l;}
const wireFloat=new DataView(new ArrayBuffer(4));
function wireDecodeText(bytes,start,end){
 if(end-start<=16){let text='';for(let i=start;i<end;i++){const byte=bytes[i];if(byte>=128)return wireDecoder.decode(bytes.subarray(start,end));text+=String.fromCharCode(byte);}return text;}
 return wireDecoder.decode(bytes.subarray(start,end));
}
function wireUtf8Length(text){let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const wireOwn=(v,k)=>v!==null&&typeof v==='object'&&Object.hasOwn(v,k);
const wireTagged=(v,k)=>wireOwn(v,k)&&Object.keys(v).length===1;
const wireDouble=new DataView(new ArrayBuffer(8));
function wireF64Bits(v){
 if(typeof v==='number'&&Number.isFinite(v)){wireDouble.setFloat64(0,v,true);return wireDouble.getBigUint64(0,true);}
 if(!wireTagged(v,'F64Bits'))wireInvalidValue();const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))wireInvalidValue();
 const bits=BigInt(text);if(bits>18446744073709551615n)wireInvalidValue();return bits;
}
const wireCanonical=v=>Array.isArray(v)?'['+v.map(wireCanonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort((a,b)=>{const x=Array.from(a,c=>c.codePointAt(0)),y=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]-y[i];return x.length-y.length;}).map(k=>JSON.stringify(k)+':'+wireCanonical(v[k])).join(',')+'}':JSON.stringify(v);
export async function createValueCodec(root,named={}){
 const used=new Set(),budget={nodes:100000};
 function check(t,d=0){
  if(d>64||--budget.nodes<0)throw Error('wire descriptor limit');
  const keys={u32:['kind'],u64:['kind'],i32:['kind'],f32:['kind'],f64:['kind'],bool:['kind'],unit:['kind'],string:['kind'],int:['kind'],id:['kind','name'],ref:['kind','name'],enum:['kind','name','variants'],record:['kind','name','fields'],list:['kind','element'],option:['kind','element'],vector:['kind','element','size'],result:['kind','ok','error']}[t?.kind];
  if(!keys||Object.keys(t).length!==keys.length||keys.some(k=>!Object.hasOwn(t,k)))throw Error('invalid wire descriptor');
  if(keys.includes('name')&&(typeof t.name!=='string'||!t.name.isWellFormed()))throw Error('invalid descriptor name');
  if(t.kind==='ref'){if(!used.has(t.name)){used.add(t.name);if(named[t.name]?.kind!=='record'||named[t.name].name!==t.name)throw Error('unresolved wire reference');check(named[t.name],d+1);}}
  if(t.kind==='record'){if(!Array.isArray(t.fields))throw Error('wire fields');const names=new Set();for(const f of t.fields){if(Object.keys(f).length!==2||typeof f.name!=='string'||!f.name.isWellFormed()||names.has(f.name))throw Error('duplicate wire field');names.add(f.name);check(f.type,d+1);}}
  if(t.kind==='enum'&&(!Array.isArray(t.variants)||!t.variants.length||t.variants.length>64||t.variants.some(v=>typeof v!=='string'||!v.isWellFormed())||new Set(t.variants).size!==t.variants.length))throw Error('wire enum');
  if(['list','vector','option'].includes(t.kind)){if(t.kind==='vector'&&(!Number.isInteger(t.size)||t.size<1||t.size>64))throw Error('wire vector');check(t.element,d+1);}
  if(t.kind==='result'){check(t.ok,d+1);check(t.error,d+1);}
 }
 check(root);const names=Object.fromEntries([...used].sort().map(k=>[k,named[k]]));
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',wireEncoder.encode(wireCanonical({format:valueWireFormat,root,named:names}))));
 return new ValueCodec({format:valueWireFormat,root,named:names,identity:Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('')});
}
// Resolve immutable descriptor edges once. Logical validation traverses the
// literal schema; single-child nodes use a loop rather than recursive closures.
function wireValuePlan(codec){
 const seen=new WeakMap();let remaining=100000;
 const build=type=>{
  const t=codec.resolve(type);if(seen.has(t))return seen.get(t);
  if(--remaining<0)throw Error('wire descriptor limit');const p={kind:t.kind,type:t,decode:null,decodeCompact:null};seen.set(t,p);
  if(t.kind==='record')p.fields=t.fields.map(f=>({name:f.name,plan:build(f.type)}));
  if(t.kind==='list'||t.kind==='vector'||t.kind==='option')p.element=build(t.element);
  if(t.kind==='result'){p.ok=build(t.ok);p.error=build(t.error);}
  return p;
 };return build(codec.descriptor.root);
}
function wireBindDecodePlan(root,compact=false){
 const seen=new Set(),pending=[root];let flags=0;
 while(pending.length){
  const p=pending.pop();if(seen.has(p))continue;seen.add(p);if(compact)p.decodeCompact=compactDecodeOperation(p);else p.decode=wireDecodeOperation(p);
  if(p.fields?.length>4)flags|=1;
  if(p.kind==='u32'||p.kind==='i32'||p.kind==='u64'||p.kind==='f32'||p.kind==='f64')flags|=2;
  if(p.fields)for(const f of p.fields)pending.push(f.plan);
  if(p.element)pending.push(p.element);
  if(p.ok){pending.push(p.ok);pending.push(p.error);}
 }
 return flags|4;
}
// Select literal descriptor operations once, without runtime source generation
// or eval. Recursive edges call the completed plan. The generic scanner remains
// the visitor/validation path and an independent materialisation implementation.
function wireReadOperation(p){
 const t=p.type;
 let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':read=(r,end)=>{r.size(end,4);const value={F32Bits:r.view.getUint32(r.cursor,true)};r.cursor=end;return value;};break;
  case 'f64':read=(r,end)=>{r.size(end,8);const value={F64Bits:r.view.getBigUint64(r.cursor,true).toString()};r.cursor=end;return value;};break;
  case 'u64':read=(r,end)=>{r.size(end,8);const value=r.view.getBigUint64(r.cursor,true);r.cursor=end;return value;};break;
  case 'string':read=(r,end)=>r.text(end);break;
  case 'int':read=(r,end)=>{const text=r.text(end);if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=(r,end)=>{const text=r.text(end);if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=(r,end)=>{const text=r.text(end);if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{
    if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;
    if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');
    const values=new Array(n);for(let i=0;i<n;i++)values[i]=element.decode(r,end,d+1);return values;
   };break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1)});break;
    case 2:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1)});break;
    case 3:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1)});break;
    case 4:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1),[fs[3].name]:fs[3].plan.decode(r,end,d+1)});break;
    default:read=(r,end,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decode(r,end,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,end,d)=>{const tag=r.tag(end);return tag?{Some:p.element.decode(r,end,d+1)}:{None:null};};break;
  case 'result':read=(r,end,d)=>r.tag(end)?{Err:p.error.decode(r,end,d+1)}:{Ok:p.ok.decode(r,end,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function wireDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=wireReadOperation(field.plan),name=field.name;
  return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),childEnd=r.enter(end,d+1),item=read(r,childEnd,d+1);if(r.cursor!==childEnd)throw Error('trailing wire frame bytes');const value={[name]:item};if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
 }
 const read=wireReadOperation(p);
 return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
}
class WireDecodeCursor{
 constructor(bytes,view,limits){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
// Bind literal validation and postorder visitation once for every descriptor.
// No logical carriers are allocated; projection still validates every child.
function wireScanPlan(root){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,scan:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.scan=wireScanOperation(p);return p;
 };
 return build(root);
}
function wireScanOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':case 'f64':case 'u64':{const size=p.kind==='f32'?4:8;read=(r,end)=>{r.size(end,size);r.cursor=end;};break;}
  case 'string':read=(r,end)=>{let i=r.cursor;while(i<end&&r.bytes[i]<128)i++;if(i<end)wireDecoder.decode(r.bytes.subarray(r.cursor,end));r.cursor=end;};break;
  case 'int':case 'id':case 'enum':read=(r,end)=>{const text=r.text(end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');for(let i=0;i<n;i++)element.scan(r,end,d+1);};break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>{};break;
    case 1:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);};break;
    case 2:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);};break;
    case 3:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);};break;
    case 4:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);fs[3].plan.scan(r,end,d+1);};break;
    default:read=(r,end,d)=>{for(const f of fs)f.plan.scan(r,end,d+1);};
   }break;
  }
  case 'option':read=(r,end,d)=>{if(r.tag(end))p.element.scan(r,end,d+1);};break;
  case 'result':read=(r,end,d)=>{(r.tag(end)?p.error:p.ok).scan(r,end,d+1);};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return (r,parentEnd,d)=>{
  const end=r.enter(parentEnd,d),start=r.cursor,value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');
  const visitor=r.visitor;if(visitor&&(!r.selected||r.selected.has(t.name))){if(r.spans)visitor(t,r.bytes,start,end,d);else visitor(t,r.bytes.subarray(start,end),d);}
  return value;
 };
}
// Separate methods keep decoding's cursor callsites monomorphic. Both cursors
// are checked against the independent generic scanner and malformed fixtures.
class WireScanCursor{
 constructor(bytes,view,limits,visitor,selected,spans){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.visitor=visitor;this.selected=selected;this.spans=spans;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
function compactReadOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=()=>null;break;
  case 'bool':read=r=>{r.require(1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':case 'i32':read=r=>{r.require(4);const n=p.kind==='u32'?r.view.getUint32(r.cursor,true):r.view.getInt32(r.cursor,true);r.cursor+=4;return n;};break;
  case 'f32':read=r=>{r.require(4);const n=r.view.getUint32(r.cursor,true);r.cursor+=4;return {F32Bits:n};};break;
  case 'f64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return {F64Bits:n.toString()};};break;
  case 'u64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return n;};break;
  case 'string':read=r=>r.text();break;
  case 'int':read=r=>{const text=r.text();if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=r=>{const text=r.text();if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=r=>{const text=r.text();if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':read=(r,d)=>{const n=r.count();if(n>r.remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');const values=new Array(n);for(let i=0;i<n;i++)values[i]=p.element.decodeCompact(r,d+1);return values;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1)});break;
    case 2:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1)});break;
    case 3:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1)});break;
    case 4:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1),[fs[3].name]:fs[3].plan.decodeCompact(r,d+1)});break;
    default:read=(r,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decodeCompact(r,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,d)=>r.tag()?{Some:p.element.decodeCompact(r,d+1)}:{None:null};break;
  case 'result':read=(r,d)=>r.tag()?{Err:p.error.decodeCompact(r,d+1)}:{Ok:p.ok.decodeCompact(r,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function compactDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=compactReadOperation(field.plan),name=field.name;
  return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');if(d+1>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return {[name]:read(r,d+1)};};
 }
 const read=compactReadOperation(p);
 return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return read(r,d);};
}
class CompactDecodeCursor{
 constructor(bytes,limits,flags){this.bytes=bytes;this.view=flags&2?new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength):null;this.cursor=1;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 require(n){if(n>this.bytes.length-this.cursor)throw Error('truncated compact value');}
 count(){
  if(this.cursor>=this.bytes.length)throw Error('truncated compact value');
  const first=this.bytes[this.cursor++];if(first<128)return first;
  let value=first&127,scale=128;
  for(let i=1;i<5;i++){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const byte=this.bytes[this.cursor++];if(i===4&&byte>15)throw Error('compact count overflow');value+=(byte&127)*scale;if(byte<128){if(byte===0)throw Error('noncanonical compact count');return value;}scale*=128;}throw Error('compact count overflow');
 }
 tag(){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const tag=this.bytes[this.cursor++];if(tag>1)throw Error('wire sum tag');return tag;}
 text(){const n=this.count();this.require(n);const start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
function wireInvalidValue(){throw Error('invalid value for wire schema');}
// Capture has the canonical logical meaning of decode(encode(value)), without
// allocating wire bytes. A separate plan leaves validation/decoder hot shapes
// unchanged and never retains host input containers between calls.
function wireCapturePlan(root,checked=true){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,capture:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({name:f.name,plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.capture=checked?wireCaptureOperation(p):wireCopyOperation(p);return p;
 };return build(root);
}
function wireCaptureOperation(p){
 const t=p.type;let copy;
 switch(p.kind){
  case 'unit':copy=v=>{if(v!==null)wireInvalidValue();return null;};break;
  case 'bool':copy=(v,r)=>{if(typeof v!=='boolean')wireInvalidValue();r.add(1);return v;};break;
  case 'u32':case 'i32':{
   const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
   copy=(v,r)=>{if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();r.add(4);return v===0?0:v;};break;
  }
  case 'u64':copy=(v,r)=>{const kind=typeof v;if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();r.add(8);return n;};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'int':case 'id':case 'enum':copy=(v,r)=>{const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;if(typeof text!=='string'||!text.isWellFormed()||text.length>r.limit)wireInvalidValue();if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();r.add(wireUtf8Length(text));return p.kind==='int'?{Int:text}:text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   copy=(v,r,d)=>{if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();const n=v.length;if(n>r.remaining||size!==null&&n!==size)wireInvalidValue();r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=element.capture(v[i],r,d+1);return out;};break;
  }
  case 'record':{
   const fs=p.fields;let fields;
   switch(fs.length){
    case 0:fields=()=>({});break;
    case 1:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:fields=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }
   copy=(v,r,d)=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();for(const f of fs)if(!wireOwn(v,f.name))wireInvalidValue();return fields(v,r,d);};break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'None')&&v.None===null)return {None:null};if(wireTagged(v,'Some'))return {Some:p.element.capture(v.Some,r,d+1)};wireInvalidValue();};break;
  case 'result':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'Ok'))return {Ok:p.ok.capture(v.Ok,r,d+1)};if(wireTagged(v,'Err'))return {Err:p.error.capture(v.Err,r,d+1)};wireInvalidValue();};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
class WireCaptureCursor{
 constructor(limits){this.remaining=limits.nodes;this.depth=limits.depth;this.limit=limits.bytes;this.bytes=40;this.add(0);}
 add(n){this.bytes+=n;if(this.bytes>this.limit)throw Error('wire byte limit');}
 enter(depth,bytes){if(depth>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.add(bytes);}
 text(value){if(value.length>this.limit)throw Error('wire byte limit');this.add(wireUtf8Length(value));}
}
// Literal lowerers share this fixed resource policy with logical capture.
export function createValueCaptureBudget(options=wireDefaultOptions){return new WireCaptureCursor(wireLimits(options));}
// The trusted-value API has the same canonical copy and ownership semantics.
// Its caller supplies a stable value accepted by validateValue. Shape/range
// checks remain at external capture boundaries; resource limits still apply.
function wireCopyOperation(p){
 let copy;
 switch(p.kind){
  case 'unit':copy=()=>null;break;
  case 'bool':copy=(v,r)=>{r.add(1);return v;};break;
  case 'u32':copy=(v,r)=>{r.add(4);return v>>>0;};break;
  case 'i32':copy=(v,r)=>{r.add(4);return v|0;};break;
  case 'u64':copy=(v,r)=>{r.add(8);return BigInt(v);};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'){wireFloat.setFloat32(0,v,true);bits=wireFloat.getUint32(0,true);}else bits=v.F32Bits;r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'id':case 'enum':copy=(v,r)=>{r.add(wireUtf8Length(v));return v;};break;
  case 'int':copy=(v,r)=>{const text=typeof v==='bigint'?v.toString():v.Int;r.add(wireUtf8Length(text));return {Int:text};};break;
  case 'list':case 'vector':copy=(v,r,d)=>{const n=v.length;if(n>r.remaining)throw Error('wire sequence size');r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=p.element.capture(v[i],r,d+1);return out;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:copy=()=>({});break;
    case 1:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:copy=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'None')&&v.None===null?{None:null}:{Some:p.element.capture(v.Some,r,d+1)};};break;
  case 'result':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'Ok')?{Ok:p.ok.capture(v.Ok,r,d+1)}:{Err:p.error.capture(v.Err,r,d+1)};};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
// Emit the cached literal schema with one forward writer. Each value is checked
// where it is consumed; byte bounds belong to the writer, not a second size walk.
function wireEncodeValue(root,value,l,w){
 let remaining=l.nodes;const depthLimit=l.depth;
 const node=(p,v,d)=>{
  if(d>depthLimit||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type,start=w.beginNode();
  switch(p.kind){
   case 'unit':if(v!==null)wireInvalidValue();break;
   case 'bool':if(typeof v!=='boolean')wireInvalidValue();w.byte(+v);break;
   case 'u32':case 'i32':{
    const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
    if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();w.word(v>>>0);break;
   }
   case 'u64':{
    const kind=typeof v;
    if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
    const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();w.wide(n);break;
   }
   case 'f64':w.wide(wireF64Bits(v));break;
   case 'f32':{
    let bits;
    if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}
    else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
    w.word(bits);break;
   }
   case 'string':case 'int':case 'id':case 'enum':{
    const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
    if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&(typeof text!=='string'||!/^[0-9a-f]{32}$/.test(text))||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
    w.text(text);break;
   }
   case 'list':case 'vector':{
    if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
    if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
    w.count(v.length);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);break;
   }
   case 'record':{
    const fs=p.fields;
    if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
    for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
    for(let i=0;i<fs.length;i++){const f=fs[i];node(f.plan,v[f.name],d+1);}break;
   }
   case 'option':{
    if(wireTagged(v,'None')&&v.None===null)w.byte(0);
    else if(wireTagged(v,'Some')){w.byte(1);node(p.element,v.Some,d+1);}else wireInvalidValue();break;
   }
   case 'result':{
    if(wireTagged(v,'Ok')){w.byte(0);node(p.ok,v.Ok,d+1);}
    else if(wireTagged(v,'Err')){w.byte(1);node(p.error,v.Err,d+1);}else wireInvalidValue();break;
   }
   default:throw Error('unsupported wire kind');
  }
  w.endNode(start);
 };
 node(root,value,0);
}
function wireCheckValue(root,value,l){
 let remaining=l.nodes,total=40;
 const add=n=>{total+=n;if(total>l.bytes)throw Error('wire byte limit');};
 const node=(p,v,d)=>{
  while(true){
   if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
   const t=p.type;
   switch(p.kind){
    case 'unit':if(v!==null)wireInvalidValue();add(4);return;
    case 'bool':if(typeof v!=='boolean')wireInvalidValue();add(5);return;
    case 'u32':case 'i32':{
     const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
     if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();add(8);return;
    }
    case 'u64':{
     const kind=typeof v;
     if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
     const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();add(12);return;
    }
    case 'f64':wireF64Bits(v);add(12);return;
    case 'f32':{
     if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();}
     else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();const bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
     add(8);return;
    }
    case 'string':case 'int':case 'id':case 'enum':{
     const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
     if(typeof text!=='string'||!text.isWellFormed()||text.length>l.bytes)wireInvalidValue();
     if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
     add(4+wireUtf8Length(text));return;
    }
    case 'list':case 'vector':{
     if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
     if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
     add(8);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);return;
    }
    case 'record':{
     const fs=p.fields;
     if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
     for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
     add(4);if(!fs.length)return;
     for(let i=0;i<fs.length-1;i++)node(fs[i].plan,v[fs[i].name],d+1);
     const f=fs[fs.length-1];p=f.plan;v=v[f.name];d++;continue;
    }
    case 'option':{
     if(wireTagged(v,'None')&&v.None===null){add(5);return;}
     if(!wireTagged(v,'Some'))wireInvalidValue();add(5);p=p.element;v=v.Some;d++;continue;
    }
    case 'result':{
     if(wireTagged(v,'Ok')){add(5);p=p.ok;v=v.Ok;}
     else if(wireTagged(v,'Err')){add(5);p=p.error;v=v.Err;}else wireInvalidValue();
     d++;continue;
    }
    default:throw Error('unsupported wire kind');
   }
  }
 };
 node(root,value,0);if(total>l.bytes)throw Error('wire byte limit');
}
// A single cursor replaces per-node child closures and {end,value} temporaries.
// Projection filters limit callback materialisation, never schema validation.
function wireScanValue(root,bytes,view,l,materialize,visitor,selected,spans){
 let cursor=40,remaining=l.nodes;
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,parentEnd,d)=>{
  if(d>l.depth||--remaining<0||cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const t=p.type,start=cursor+4,end=start+view.getUint32(cursor,true);if(end>parentEnd)throw Error('truncated wire frame');cursor=start;let value;
  switch(p.kind){
   case 'unit':if(end-start!==0)throw Error('malformed wire scalar');value=null;break;
   case 'bool':if(end-start!==1)throw Error('malformed wire scalar');if(bytes[start]>1)throw Error('invalid wire Bool');value=!!bytes[start];cursor=end;break;
   case 'u32':case 'i32':if(end-start!==4)throw Error('malformed wire scalar');value=p.kind==='u32'?view.getUint32(start,true):view.getInt32(start,true);cursor=end;break;
   case 'f32':if(end-start!==4)throw Error('malformed wire scalar');if(materialize)value={F32Bits:view.getUint32(start,true)};cursor=end;break;
   case 'f64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value={F64Bits:view.getBigUint64(start,true).toString()};cursor=end;break;
   case 'u64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value=view.getBigUint64(start,true);cursor=end;break;
   case 'string':case 'int':case 'id':case 'enum':{
    if(p.kind==='string'&&!materialize){let i=start;while(i<end&&bytes[i]<128)i++;if(i<end)wireDecoder.decode(bytes.subarray(start,end));}
    else{const text=wireDecodeText(bytes,start,end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    cursor=end;break;
   }
   case 'list':case 'vector':{
    if(start+4>end)throw Error('wire list count');const n=view.getUint32(start,true);cursor+=4;
    if(n>remaining||n>Math.floor((end-cursor)/4)||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,end,d+1);if(materialize)value.push(child);}break;
   }
   case 'record':{
    const fs=p.fields;
    // Computed literal keys create own data properties even for __proto__ or
    // prototype setters. Common small records need no descriptor allocations.
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:value={};break;case 1:value={[fs[0].name]:node(fs[0].plan,end,d+1)};break;case 2:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1)};break;case 3:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1)};break;case 4:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1),[fs[3].name]:node(fs[3].plan,end,d+1)};break;}
    }else{if(materialize)value={};for(const f of fs){const child=node(f.plan,end,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}}break;
   }
   case 'option':case 'result':{
    if(start===end||bytes[cursor]>1)throw Error('wire sum tag');const tag=bytes[cursor++];
    if(p.kind==='option'&&tag===0){if(materialize)value={None:null};}
    else{const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,end,d+1);if(materialize)value={[label]:child};}break;
   }
   default:throw Error('unsupported wire kind');
  }
  if(cursor!==end)throw Error('trailing wire frame bytes');
  if(visitor&&(!selected||selected.has(t.name))){if(spans)visitor(t,bytes,start,end,d);else visitor(t,bytes.subarray(start,end),d);}
  return value;
 };
 const result=node(root,bytes.length,0);if(cursor!==bytes.length)throw Error('trailing wire bytes');return result;
}
export class ValueCodec{
 #hash;
 #header;
 #headerWords;
 #descriptor;
 #valuePlan;
 #compactCodec;
 #encoder;
 #decodeBound=0;
 #scanPlan=null;
 #capturePlan=null;
 #copyPlan=null;
 get descriptor(){return this.#descriptor;}
 constructor(descriptor){
  // This synchronous path is for compiler-generated immutable metadata. For
  // untrusted descriptors use createValueCodec and compare the computed identity.
  if(descriptor?.format!==valueWireFormat||!/^[0-9a-f]{64}$/.test(descriptor.identity))throw Error('invalid wire schema');
  this.#descriptor=structuredClone(descriptor);this.#hash=Uint8Array.from(descriptor.identity.match(/../g),s=>parseInt(s,16));
  this.#header=new Uint8Array(40);this.#header.set(wireMagic);this.#header.set(this.#hash,8);
  const headerView=new DataView(this.#header.buffer);this.#headerWords=Array.from({length:10},(_,i)=>headerView.getUint32(i*4,true));
  const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}};freeze(this.descriptor);this.#valuePlan=wireValuePlan(this);
 }
 resolve(t){for(let i=0;i<64;i++){if(t.kind!=='ref')return t;t=this.descriptor.named[t.name];if(!t)throw Error('wire reference');}throw Error('wire reference cycle');}
 validateValue(value,options=wireDefaultOptions){wireCheckValue(this.#valuePlan,value,wireLimits(options));return true;}
 capture(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#capturePlan??=wireCapturePlan(this.#valuePlan);return this.#capturePlan.capture(value,new WireCaptureCursor(limits),0);}
 copy(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#copyPlan??=wireCapturePlan(this.#valuePlan,false);return this.#copyPlan.capture(value,new WireCaptureCursor(limits),0);}
 compact(){return this.#compactCodec??=new CompactValueCodec(this);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new WireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.bytes(this.#header);wireEncodeValue(this.#valuePlan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new WireEncoder(options);w.bytes(wireMagic);w.bytes(this.#hash);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 scan(bytes,options=wireDefaultOptions,materialize=false,visitor=null,names=null,spans=false){
  const l=wireLimits(options);if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<44||bytes.length>l.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==this.#headerWords[i])throw Error('wire format or schema mismatch');
  if(names!==null&&(!Array.isArray(names)||names.length>100000||names.some(n=>typeof n!=='string')))throw Error('wire visitor names');
  if(materialize&&!visitor){this.#decodeBound||=wireBindDecodePlan(this.#valuePlan);const cursor=new WireDecodeCursor(bytes,view,l);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#valuePlan.decode(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  if(!materialize){this.#scanPlan??=wireScanPlan(this.#valuePlan);const cursor=new WireScanCursor(bytes,view,l,visitor,names===null?null:new Set(names),spans),value=this.#scanPlan.scan(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  return wireScanValue(this.#valuePlan,bytes,view,l,materialize,visitor,names===null?null:new Set(names),spans);
 }
 visit(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names);}
 visitSpans(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names,true);}
 validate(bytes,options=wireDefaultOptions){this.scan(bytes,options,false);return true;}
 decode(bytes,options=wireDefaultOptions){return this.scan(bytes,options,true);}
}

// Bounded forward emission avoids building and repeatedly joining child buffers.
class WireEncoder{
 #data=new Uint8Array(256);#view=new DataView(this.#data.buffer);#at=0;#remaining;#depth=0;#byteLimit;#depthLimit;
 active=false;
 constructor(options){this.reset(options);}
 reset(options){const limits=wireLimits(options);this.#byteLimit=limits.bytes;this.#depthLimit=limits.depth;this.#remaining=limits.nodes;this.#depth=0;this.#at=0;this.active=true;}
 get capacity(){return this.#data.length;}
 get position(){return this.#at;}
 beginNode(){const at=this.#at;this.word(0);return at;}
 endNode(at){this.patchWord(at,this.#at-at-4);}
 count(n){this.word(n);}
 beginCount(){const at=this.position;this.count(0);return at;}
 endCount(at,n){this.patchWord(at,n);}
 #reserve(size){
  const end=this.#at+size;if(end>this.#byteLimit)throw Error('wire byte limit');
  if(end>this.#data.length){const next=new Uint8Array(Math.min(this.#byteLimit,Math.max(end,this.#data.length*2)));next.set(this.#data.subarray(0,this.#at));this.#data=next;this.#view=new DataView(next.buffer);}
  return end;
 }
 bytes(bytes){const end=this.#reserve(bytes.length);this.#data.set(bytes,this.#at);this.#at=end;}
 byte(n){if(!Number.isInteger(n)||n<0||n>255)throw Error('wire byte range');this.#reserve(1);this.#data[this.#at++]=n;}
 word(n){if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire word range');const end=this.#reserve(4);this.#view.setUint32(this.#at,n,true);this.#at=end;}
 wide(n){if(typeof n!=='bigint'||n<0n||n>18446744073709551615n)throw Error('wire wide range');const end=this.#reserve(8);this.#view.setBigUint64(this.#at,n,true);this.#at=end;}
 text(text,count=false){
  if(typeof text!=='string')throw Error('wire Unicode');
  if(text.length<=16){
   let ascii=true;for(let i=0;i<text.length;i++)if(text.charCodeAt(i)>=128){ascii=false;break;}
   if(ascii){if(count)this.count(text.length);const end=this.#reserve(text.length);for(let i=0;i<text.length;i++)this.#data[this.#at+i]=text.charCodeAt(i);this.#at=end;return;}
  }
  if(!text.isWellFormed())throw Error('wire Unicode');const size=wireUtf8Length(text);if(count)this.count(size);
  const end=this.#reserve(size),r=wireEncoder.encodeInto(text,this.#data.subarray(this.#at,end));if(r.read!==text.length||r.written!==size)throw Error('wire UTF-8 size');this.#at=end;
 }
 patchWord(at,n){if(!Number.isInteger(at)||at<0||at+4>this.#at||!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire patch offset');this.#view.setUint32(at,n,true);}
 patchByte(at,n){if(!Number.isInteger(at)||at<0||at>=this.#at||!Number.isInteger(n)||n<0||n>255)throw Error('wire patch offset');this.#data[at]=n;}
 replace(at,removed,bytes){
  if(!Number.isInteger(at)||!Number.isInteger(removed)||at<0||removed<0||at+removed>this.#at||!(bytes instanceof Uint8Array))throw Error('wire replacement range');
  const extra=bytes.length-removed,end=extra>0?this.#reserve(extra):this.#at+extra;
  this.#data.copyWithin(at+bytes.length,at+removed,this.#at);this.#data.set(bytes,at);this.#at=end;
 }
 // Literal generated writers use balanced frames without per-node callbacks.
 // An exception abandons this invocation; encodeWith never reuses its writer.
 openFrame(){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;return at;}
 closeFrame(at){if(this.#depth===0)throw Error('wire frame boundary');this.#depth--;this.endNode(at);}
 frame(emit){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;try{emit(this);}finally{this.#depth--;}this.endNode(at);}
 reorder(start,spans){
  const sorted=spans.slice().sort((a,b)=>a[0]-b[0]);let at=start;
  for(const [a,b] of sorted){if(!Number.isInteger(a)||!Number.isInteger(b)||a!==at||b<a)throw Error('wire span permutation');at=b;}
  if(start<0||start>this.#at||at!==this.#at)throw Error('wire span permutation');
  if(spans.every((s,i)=>s===sorted[i]))return;
  const copy=this.#data.slice(start,this.#at);at=start;for(const [a,b] of spans){this.#data.set(copy.subarray(a-start,b-start),at);at+=b-a;}
 }
 finish(){if(this.#depth!==0)throw Error('wire frame boundary');return this.#data.slice(0,this.#at);}
}

class CompactWireEncoder extends WireEncoder{
 beginNode(){return 0;}
 endNode(){}
 endCount(at,n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  if(n<128){this.patchByte(at,n);return;}
  const bytes=[];while(n>=128){bytes.push(n%128+128);n=Math.floor(n/128);}bytes.push(n);this.replace(at,1,Uint8Array.from(bytes));
 }
 count(n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  while(n>=128){this.byte(n%128+128);n=Math.floor(n/128);}this.byte(n);
 }
 text(text){super.text(text,true);}
}

function compactScanValue(root,bytes,l,materialize){
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let cursor=1,remaining=l.nodes;
 const require=n=>{if(n>bytes.length-cursor)throw Error('truncated compact value');};
 const count=()=>{
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   require(1);const byte=bytes[cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }throw Error('compact count overflow');
 };
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,d)=>{
  if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type;let value;
  switch(p.kind){
   case 'unit':return null;
   case 'bool':require(1);if(bytes[cursor]>1)throw Error('invalid wire Bool');return !!bytes[cursor++];
   case 'u32':case 'i32':require(4);value=p.kind==='u32'?view.getUint32(cursor,true):view.getInt32(cursor,true);cursor+=4;return value;
   case 'f32':require(4);if(materialize)value={F32Bits:view.getUint32(cursor,true)};cursor+=4;return value;
   case 'f64':require(8);if(materialize)value={F64Bits:view.getBigUint64(cursor,true).toString()};cursor+=8;return value;
   case 'u64':require(8);if(materialize)value=view.getBigUint64(cursor,true);cursor+=8;return value;
   case 'string':case 'int':case 'id':case 'enum':{
    const n=count();require(n);const start=cursor;cursor+=n;
    if(p.kind==='string'&&!materialize){let i=start;while(i<cursor&&bytes[i]<128)i++;if(i<cursor)wireDecoder.decode(bytes.subarray(start,cursor));}
    else{const text=wireDecodeText(bytes,start,cursor);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    return value;
   }
   case 'list':case 'vector':{
    const n=count();if(n>remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,d+1);if(materialize)value.push(child);}return value;
   }
   case 'record':{
    const fs=p.fields;
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:return {};case 1:return {[fs[0].name]:node(fs[0].plan,d+1)};case 2:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1)};case 3:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1)};case 4:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1),[fs[3].name]:node(fs[3].plan,d+1)};}
    }
    if(materialize)value={};for(const f of fs){const child=node(f.plan,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}return value;
   }
   case 'option':case 'result':{
    require(1);const tag=bytes[cursor++];if(tag>1)throw Error('wire sum tag');
    if(p.kind==='option'&&tag===0)return materialize?{None:null}:undefined;
    const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,d+1);
    return materialize?{[label]:child}:undefined;
   }
   default:throw Error('unsupported wire kind');
  }
 };
 const value=node(root,0);if(cursor!==bytes.length)throw Error('trailing compact bytes');return value;
}

// General transport codec, independent of source rewrites and checkpoints.
// The sender/receiver must negotiate this exact identity and format. There is
// deliberately no claim that the bytes themselves identify their schema.
export class CompactValueCodec{
 #source;#plan;#encoder;#decodeBound=0;
 get format(){return compactValueWireFormat;}
 get identity(){return this.#source.descriptor.identity;}
 constructor(valueCodec){if(!(valueCodec instanceof ValueCodec))throw Error('compact codec requires a checked value codec');this.#source=valueCodec;this.#plan=wireValuePlan(valueCodec);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new CompactWireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.byte(1);wireEncodeValue(this.#plan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new CompactWireEncoder(options);w.byte(1);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 #scan(bytes,options,materialize){
  const l=wireLimits(options);
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<1||bytes.length>l.bytes)throw Error('wire byte limit or header');
  if(bytes[0]!==1)throw Error('compact format mismatch');
  if(materialize){this.#decodeBound||=wireBindDecodePlan(this.#plan,true);const cursor=new CompactDecodeCursor(bytes,l,this.#decodeBound);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#plan.decodeCompact(cursor,0);if(cursor.cursor!==bytes.length)throw Error('trailing compact bytes');return value;}
  return compactScanValue(this.#plan,bytes,l,materialize);
 }
 decode(bytes,options=wireDefaultOptions){return this.#scan(bytes,options,true);}
 validate(bytes,options=wireDefaultOptions){this.#scan(bytes,options,false);return true;}
}

// Compiler materialisers consume already validated bytes synchronously. This
// factory is for trusted emitted code, not untrusted descriptor/callback data.
// The complete generic validator runs before any compiler reader is invoked.
class ValidatedValueReader{
 constructor(bytes,compact){this.bytes=bytes;this.view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);this.cursor=compact?1:40;this.compact=compact;}
 frame(){if(this.compact)return 0;const end=this.cursor+4+this.view.getUint32(this.cursor,true);this.cursor+=4;return end;}
 finish(end){if(!this.compact&&this.cursor!==end)throw Error('compiled reader frame mismatch');}
 byte(){return this.bytes[this.cursor++];}
 word(){const n=this.view.getUint32(this.cursor,true);this.cursor+=4;return n;}
 signed(){const n=this.view.getInt32(this.cursor,true);this.cursor+=4;return n;}
 wide(){const n=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return n;}
 count(){if(!this.compact)return this.word();let n=0,scale=1,byte;do{byte=this.byte();n+=(byte&127)*scale;scale*=128;}while(byte>=128);return n;}
 text(end){const n=this.compact?this.count():end-this.cursor,start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
class CompiledCompactValueCodec extends CompactValueCodec{
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,true),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
}
class CompiledValueCodec extends ValueCodec{
 #read;#compiledCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,false),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
 compact(){return this.#compiledCompact??=new CompiledCompactValueCodec(this,this.#read);}
}
export function createCompiledValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new CompiledValueCodec(descriptor,read);}

// Trusted literal materialisers may use this checked reader to validate and
// construct in one traversal. The emitter must use frame/finish at every source
// node, typed text reads and counted sequence reads; arbitrary callbacks do not
// establish a schema correspondence proof. The independent scanner remains the
// validation oracle and the original factory retains its pre-validation path.
function literalValueHeader(identity){
 const bytes=new Uint8Array(40);bytes.set(wireMagic);
 for(let i=0;i<32;i++)bytes[i+8]=parseInt(identity.slice(i*2,i*2+2),16);
 const view=new DataView(bytes.buffer),words=new Uint32Array(10);
 for(let i=0;i<10;i++)words[i]=view.getUint32(i*4,true);
 return words;
}
class CheckedLiteralValueReader {
 constructor(bytes,header,compact,limits){
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<(compact?1:44)||bytes.length>limits.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  if(compact){if(bytes[0]!==1)throw Error('compact format mismatch');}
  else for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==header[i])throw Error('wire format or schema mismatch');
  this.bytes=bytes;this.view=view;
  this.cursor=compact?1:40;this.compact=compact;this.remaining=limits.nodes;this.depth=limits.depth;this.ends=[];
 }
 require(n){if(this.cursor+n>(this.ends.at(-1)??this.bytes.length))throw Error('truncated wire frame');}
 frame(){
  if(this.ends.length>this.depth||--this.remaining<0)throw Error('wire node or depth limit');
  let end=this.bytes.length;
  if(!this.compact){this.require(4);end=this.cursor+4+this.view.getUint32(this.cursor,true);this.require(end-this.cursor);this.cursor+=4;}
  this.ends.push(end);return this.compact?0:end;
 }
 finish(end){
  if(!this.ends.length||!this.compact&&(this.ends.at(-1)!==end||this.cursor!==end))throw Error('compiled reader frame mismatch');
  this.ends.pop();
 }
 byte(){this.require(1);const value=this.bytes[this.cursor++];if(value>1)throw Error('wire sum tag or Bool');return value;}
 word(){this.require(4);const value=this.view.getUint32(this.cursor,true);this.cursor+=4;return value;}
 signed(){this.require(4);const value=this.view.getInt32(this.cursor,true);this.cursor+=4;return value;}
 wide(){this.require(8);const value=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return value;}
 rawCount(){
  if(!this.compact)return this.word();
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   this.require(1);const byte=this.bytes[this.cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }
  throw Error('compact count overflow');
 }
 count(size){
  const value=this.rawCount();
  if(value>this.remaining||size!==undefined&&value!==size)throw Error('wire sequence size');
  return value;
 }
 text(end,kind='string',variants){
  const size=this.compact?this.rawCount():end-this.cursor;
  this.require(size);const start=this.cursor;this.cursor+=size;
  const value=wireDecodeText(this.bytes,start,this.cursor);
  if(kind==='int'&&!wireDecimal(value)||kind==='id'&&!/^[0-9a-f]{32}$/.test(value)||kind==='enum'&&!variants.includes(value))throw Error('malformed wire text');
  return value;
 }
 complete(){if(this.ends.length||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
// Compact source nodes have no individual frame ends: retain the same checked
// depth/node order using a counter, with bounds against the complete buffer.
class CheckedCompactLiteralValueReader extends CheckedLiteralValueReader {
 constructor(bytes,limits){super(bytes,null,true,limits);this.level=0;}
 require(n){if(this.cursor+n>this.bytes.length)throw Error('truncated wire frame');}
 frame(){if(this.level>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.level++;return 0;}
 finish(_end){if(!this.level)throw Error('compiled reader frame mismatch');this.level--;}
 complete(){if(this.level||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
class FusedCompactValueCodec extends CompactValueCodec {
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedCompactLiteralValueReader(bytes,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
}
class FusedValueCodec extends ValueCodec {
 #read;#header;#fusedCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;this.#header=literalValueHeader(this.descriptor.identity);}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedLiteralValueReader(bytes,this.#header,false,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
 compact(){return this.#fusedCompact??=new FusedCompactValueCodec(this,this.#read);}
}
export function createFusedValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new FusedValueCodec(descriptor,read);}
// JSON text is a boundary adapter to an ordinary recursive Ink datatype.
// No JavaScript Number conversion occurs for JSON numeric tokens.
export function jsonNumberToken(s){return typeof s==='string'&&/^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/.test(s);}
// JSON numeric tokens have an ASCII grammar. Check validated UTF-8 spans
// directly, preserving exact lexemes without allocating a decoded String.
function jsonNumberSpan(bytes,lo,hi){
 let at=lo;if(bytes[at]===45)at++;
 if(at>=hi)return false;
 if(bytes[at]===48)at++;
 else{if(bytes[at]<49||bytes[at]>57)return false;do{at++;}while(at<hi&&bytes[at]>=48&&bytes[at]<=57);}
 if(at<hi&&bytes[at]===46){const start=++at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 if(at<hi&&(bytes[at]===69||bytes[at]===101)){at++;if(at<hi&&(bytes[at]===43||bytes[at]===45))at++;const start=at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 return at===hi;
}
const jsonWireEncoder=new TextEncoder();
// Scalar conversion completes before writer callbacks; no per-value byte array.
const jsonFloatScratch=new DataView(new ArrayBuffer(4));
function jsonUtf8Length(text){if(text.length>16&&!/[^\x00-\x7f]/.test(text))return text.length;let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const jsonLimits={bytes:16777216,nodes:1000000,depth:128};
const jsonQuoters=new WeakSet();
/** Explicit, bounded reuse of immutable JSON string quotes. Cache payload bytes
 * are UTF-16 storage estimates; entry caps bound separate Map/object overhead.
 * Logical output budgets are charged again on every use, including cache hits.
 */
export function createJsonQuoter({maxEntries=1024,maxBytes=131072}={}){
 if(!Number.isSafeInteger(maxEntries)||maxEntries<0||maxEntries>65536||!Number.isSafeInteger(maxBytes)||maxBytes<0||maxBytes>16777216)throw Error('JSON quote cache budget');
 const entries=new Map();let bytes=0,hits=0,misses=0;
 const token=value=>{
  const prior=entries.get(value);if(prior!==undefined){hits++;return prior;}
  if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid JSON String');
  misses++;const text=JSON.stringify(value),size=2*(value.length+text.length),quoted=Object.freeze({text,utf8Bytes:jsonUtf8Length(text)});
  if(maxEntries&&size<=maxBytes){
   while(entries.size&&(entries.size>=maxEntries||bytes+size>maxBytes)){const key=entries.keys().next().value;bytes-=2*(key.length+entries.get(key).text.length);entries.delete(key);}
   entries.set(value,quoted);bytes+=size;
  }
  return quoted;
 };
 const quoter=Object.freeze({
  token,
  quote(value){return token(value).text;},
  clear(){entries.clear();bytes=0;},
  stats(){return {entries:entries.size,payload_bytes:bytes,hits,misses};},
 });jsonQuoters.add(quoter);return quoter;
}
function checkedJsonLimits(options){const l={...jsonLimits,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>jsonLimits[k])throw Error('JSON hard resource limit');return l;}
function jsonVariant(index,item){let payload=index===0?{}:{item0:item};if(index<5)payload={Ok:payload};for(let i=0;i<index;i++)payload={Err:payload};return {payload};}
export function parseJson(text,options={}){return parseJsonValue(text,options,null);}
function parseJsonValue(text,options,boundary){
 const p=new JsonWireReader(text,options);
 const value=(d,wireDepth=0)=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){boundary?.node(0,wireDepth);p.at+=4;return jsonVariant(0,null);}if(c==='t'&&text.startsWith('true',p.at)){boundary?.node(1,wireDepth);p.at+=4;return jsonVariant(1,true);}if(c==='f'&&text.startsWith('false',p.at)){boundary?.node(1,wireDepth);p.at+=5;return jsonVariant(1,false);}
  if(c==='"'){boundary?.node(3,wireDepth);const item=p.string();boundary?.text(item);return jsonVariant(3,item);}
  if(c==='['){boundary?.node(4,wireDepth);p.at++;const xs=[];if(!p.eat(']'))while(true){xs.push(value(d+1,wireDepth+8));if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}return jsonVariant(4,xs);}
  if(c==='{'){boundary?.node(5,wireDepth);p.at++;const xs=[],seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary?.member(key,wireDepth);if(!p.eat(':'))throw Error('JSON object colon');xs.push({key,value:value(d+1,wireDepth+9)});if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}return jsonVariant(5,xs);}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();boundary?.node(2,wireDepth);boundary?.text(token);return jsonVariant(2,token);}
  throw Error('invalid JSON value');
 };
 const out=value(0);p.finish();return out;
}
export function stringifyJson(value,options={}){return stringifyJsonValue(value,options,null);}
function stringifyJsonValue(value,options,boundary){
 const l=checkedJsonLimits(options);let remaining=l.nodes,bytes=0,output='';
 const emit=s=>{bytes+=jsonUtf8Length(s);if(bytes>l.bytes)throw Error('JSON byte limit');output+=s;};
 const write=(v,d,wireDepth=0)=>{
  if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');if(!v||Object.keys(v).length!==1||!Object.hasOwn(v,'payload'))throw Error('invalid JSON record');let p=v.payload,index=0;
  while(index<5&&p&&Object.hasOwn(p,'Err')){if(Object.keys(p).length!==1||boundary&&Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Err;index++;}
  if(index<5){if(!p||Object.keys(p).length!==1||!Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Ok;}
  if(!p||Object.keys(p).length!==(index===0?0:1)||index>0&&!Object.hasOwn(p,'item0'))throw Error('invalid JSON payload');const item=p.item0;boundary?.node(index,wireDepth);
  switch(index){
   case 0:emit('null');break;
   case 1:if(typeof item!=='boolean')throw Error('invalid JSON Boolean');emit(item?'true':'false');break;
   case 2:if(!jsonNumberToken(item))throw Error('invalid JSON number');boundary?.text(item);emit(item);break;
   case 3:if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary?.text(item);emit(JSON.stringify(item));break;
   case 4:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Array');const count=item.length;let visited=0;emit('[');item.forEach((x,i)=>{visited++;if(i)emit(',');write(x,d+1,wireDepth+8);});if(visited!==count)throw Error('invalid JSON Array');emit(']');break;}
   case 5:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Object');const count=item.length,seen=new Set();let visited=0;emit('{');item.forEach((m,i)=>{visited++;if(!m||Object.keys(m).length!==2||typeof m.key!=='string'||!m.key.isWellFormed()||!Object.hasOwn(m,'value')||boundary&&!Object.hasOwn(m,'key'))throw Error('invalid JSON member');if(seen.has(m.key))throw Error('duplicate JSON object key');seen.add(m.key);boundary?.member(m.key,wireDepth);if(i)emit(',');emit(JSON.stringify(m.key));emit(':');write(m.value,d+1,wireDepth+9);});if(visited!==count)throw Error('invalid JSON Object');emit('}');break;}
  }
 };write(value,0);return output;
}
// The adapter's schema is the fixed recursive JSON library shape checked by
// JsonCodec. Charge its ordinary record/sum/list wire nodes while parsing or
// rendering, rather than interpreting and walking the completed tree again.
function jsonBoundaryBudget(options){
 const l=checkedJsonLimits(options);let remaining=l.nodes,total=40;
 const charge=(nodes,bytes,depth)=>{remaining-=nodes;total+=bytes;if(remaining<0||depth>l.depth)throw Error('wire node or depth limit');if(total>l.bytes)throw Error('wire byte limit');};
 return {
  node(index,depth){charge(index===0?3:index<4?index+4:8,index===0?13:index===1?23:index===2?27:index===3?32:41,depth+(index===0?2:index<4?index+3:7));},
  text(text){charge(0,jsonUtf8Length(text),0);},
  member(key,depth){charge(2,8+jsonUtf8Length(key),depth+9);},
 };
}
function jsonSameSchema(a,b){
 if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;
 const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>Object.hasOwn(b,k)&&jsonSameSchema(a[k],b[k]));
}
// Host-object conversion is opt-in and JavaScript-only. Inspect data properties
// rather than invoking getters/toJSON; reflection is not a sandbox for proxies.
function jsonJSKeys(value){
 if(!value||typeof value!=='object')throw Error('expected a plain JavaScript object');
 const prototype=Object.getPrototypeOf(value);
 if(prototype!==Object.prototype&&prototype!==null)throw Error('expected a plain JavaScript object');
 const keys=Reflect.ownKeys(value);
 if(keys.some(k=>typeof k!=='string'))throw Error('JavaScript symbol keys are unsupported');
 return keys;
}
function jsonJSData(value,key){
 const property=Object.getOwnPropertyDescriptor(value,key);
 if(!property||!property.enumerable||!Object.hasOwn(property,'value'))throw Error('expected an enumerable own data property');
 return property.value;
}
function jsonJSRecord(value,names){
 const keys=jsonJSKeys(value);
 if(keys.length!==names.length||keys.some(k=>!names.includes(k)))throw Error('invalid JSON record or variant');
}
function jsonJSArray(value,remaining){
 if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype)throw Error('expected a plain JavaScript array');
 const length=value.length;
 if(length>remaining)throw Error('JSON node limit');
 const keys=Reflect.ownKeys(value);
 if(keys.length!==length+1||keys.some(k=>typeof k!=='string'||k!=='length'&&(!/^(0|[1-9][0-9]*)$/.test(k)||Number(k)>=length)))throw Error('sparse or decorated JavaScript arrays are unsupported');
 return length;
}
function jsonFromJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),active=new WeakSet();let remaining=limits.nodes;
 const text=value=>{if(!value.isWellFormed())throw Error('invalid JSON Unicode');boundary.text(value);return value;};
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  if(value===null){boundary.node(0,wireDepth);return jsonVariant(0);}
  switch(typeof value){
   case 'boolean':boundary.node(1,wireDepth);return jsonVariant(1,value);
   case 'string':boundary.node(3,wireDepth);return jsonVariant(3,text(value));
   case 'number':
    if(!Number.isFinite(value))throw Error('non-finite JavaScript numbers are unsupported');
    boundary.node(2,wireDepth);return jsonVariant(2,text(Object.is(value,-0)?'-0':String(value)));
   case 'bigint':boundary.node(2,wireDepth);return jsonVariant(2,text(String(value)));
   case 'object':break;
   default:throw Error('unsupported JavaScript value');
  }
  if(active.has(value))throw Error('cyclic JavaScript value');
  active.add(value);
  try{
   if(Array.isArray(value)){
    boundary.node(4,wireDepth);const count=jsonJSArray(value,remaining),items=[];
    for(let i=0;i<count;i++)items.push(visit(jsonJSData(value,String(i)),depth+1,wireDepth+8));
    return jsonVariant(4,items);
   }
   boundary.node(5,wireDepth);const keys=jsonJSKeys(value),members=[];
   if(keys.length>remaining)throw Error('JSON node limit');
   for(const key of keys){
    if(!key.isWellFormed())throw Error('invalid JSON Unicode');
    boundary.member(key,wireDepth);
    members.push({key,value:visit(jsonJSData(value,key),depth+1,wireDepth+9)});
   }
   return jsonVariant(5,members);
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
function jsonDecimalKey(token){
 const [,sign,whole,fraction='',exponent='0']=/^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(token);
 const digits=(whole+fraction).replace(/^0+/,'');
 if(!digits)return '0';
 const trimmed=digits.replace(/0+$/,'');
 return sign+trimmed+'e'+(Number(exponent)-fraction.length+digits.length-trimmed.length);
}
function jsonToJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),mode=options?.numbers??'number',active=new WeakSet();let remaining=limits.nodes;
 if(!['number','bigint','string'].includes(mode))throw Error('unknown JavaScript number policy');
 const number=token=>{
  if(!jsonNumberToken(token))throw Error('invalid JSON number');
  boundary.text(token);
  if(mode==='string')return token;
  if(mode==='bigint')return BigInt(jsonInteger(token,4096));
  const result=Number(token);
  if(!Number.isFinite(result)||jsonDecimalKey(token)!==jsonDecimalKey(String(result)))throw Error('JSON number loses precision as JavaScript Number; choose numbers: bigint or string');
  return result;
 };
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  jsonJSRecord(value,['payload']);
  if(active.has(value))throw Error('cyclic JSON value');
  active.add(value);
  try{
   let payload=jsonJSData(value,'payload'),index=0;
   while(index<5&&Object.hasOwn(payload,'Err')){jsonJSRecord(payload,['Err']);payload=jsonJSData(payload,'Err');index++;}
   if(index<5){jsonJSRecord(payload,['Ok']);payload=jsonJSData(payload,'Ok');}
   jsonJSRecord(payload,index===0?[]:['item0']);boundary.node(index,wireDepth);
   const item=index===0?null:jsonJSData(payload,'item0');
   if(index===0)return null;
   if(index===1){if(typeof item!=='boolean')throw Error('invalid JSON Boolean');return item;}
   if(index===2)return number(item);
   if(index===3){if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary.text(item);return item;}
   const count=jsonJSArray(item,remaining);
   if(index===4){const out=[];for(let i=0;i<count;i++)out.push(visit(jsonJSData(item,String(i)),depth+1,wireDepth+8));return out;}
   const out={},seen=new Set();
   for(let i=0;i<count;i++){
    const member=jsonJSData(item,String(i));jsonJSRecord(member,['key','value']);const key=jsonJSData(member,'key');
    if(typeof key!=='string'||!key.isWellFormed())throw Error('invalid JSON member key');
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary.member(key,wireDepth);
    Object.defineProperty(out,key,{value:visit(jsonJSData(member,'value'),depth+1,wireDepth+9),enumerable:true,writable:true,configurable:true});
   }
   return out;
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
const jsonConstructionPaths=Object.freeze(Array.from({length:6},(_,index)=>Object.freeze([0,...Array(index).fill(1),...(index<5?[0]:[]),0])));
function parseJsonConstructed(text,options,builder){
 const p=new JsonWireReader(text,options);
 const paths=jsonConstructionPaths;
 const fused=typeof builder.openPath==='function';
 const begin=index=>{if(fused){builder.openPath(paths[index]);return;}for(const choice of paths[index])builder.open(choice);};
 const end=index=>{for(let i=0;i<(fused?1:index<5?index+3:7);i++)builder.close();};
 const leaf=(index,item)=>{if(typeof builder.scalarPath==='function'){builder.scalarPath(paths[index],item);return;}begin(index);builder.scalar(item);end(index);};
 const value=d=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){p.at+=4;if(typeof builder.emptyPath==='function')builder.emptyPath(paths[0]);else{begin(0);end(0);}return;}
  if(c==='t'&&text.startsWith('true',p.at)){p.at+=4;leaf(1,true);return;}
  if(c==='f'&&text.startsWith('false',p.at)){p.at+=5;leaf(1,false);return;}
  if(c==='"'){leaf(3,p.string());return;}
  if(c==='['){begin(4);builder.open(0);p.at++;if(!p.eat(']'))while(true){value(d+1);if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}builder.close();end(4);return;}
  if(c==='{'){begin(5);builder.open(0);p.at++;const seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');builder.open(0);builder.scalar(key);value(d+1);builder.close();if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}builder.close();end(5);return;}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();leaf(2,token);return;}
  throw Error('invalid JSON value');
 };
 value(0);p.finish();return builder.finish();
}
const jsonCompiledRenderers=new WeakMap();
function compiledJsonRenderer(json,codec,unwrap){
 if(typeof codec?.reducer!=='function')throw Error('compiled JSON reduction unavailable');
 const source=codec.resolve(codec.descriptor.root),root=json.values.descriptor.root;
 const selected=unwrap&&source.kind==='result'?codec.resolve(source.ok):source;
 if(!jsonSameSchema(root,selected)||unwrap&&source.kind!=='result')throw Error('compiled JSON schema mismatch');
 let variants=root.fields[0].type;const roles=new Map([[root.name,'root']]);
 let member;
 for(let index=0;index<6;index++){
  const branch=index<5?variants.ok:variants;roles.set(branch.name,index);
  if(index===5){member=branch.fields[0].type.element.name;roles.set(member,'member');}
  if(index<5)variants=variants.error;
 }
 const nodeRoles=new Map();
 return codec.reducer((node,index)=>{
  const role=roles.get(node.name);nodeRoles.set(index,role);
  if(node.kind==='record'){
   if(role==='root')return value=>value;
   if(role==='member')return (key,value,context)=>{
    const text=(context.quoter?context.quote(key,true):context.add(JSON.stringify(key)+':'))+value,seen=context.members;
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);return text;
   };
   if(role===0)return context=>context.add('null');
   if(role===1)return (value,context)=>context.add(value?'true':'false');
   if(role===2)return (token,context)=>{if(!jsonNumberToken(token))throw Error('invalid JSON number');return context.add(token);};
   if(role===3)return (value,context)=>context.quoter?context.quote(value,false):context.add(JSON.stringify(value));
   if(role===4)return (value,context)=>{context.add('[]');return '['+value+']';};
   if(role===5)return (value,context)=>{context.add('{}');return '{'+value+'}';};
   return ()=>null;
  }
  if(node.kind==='list'||node.kind==='vector'){
   const members=nodeRoles.get(node.children[0])==='member';
   return {
    start:(_length,context)=>{
     const out={text:'',parent:members?context.members:null};
     if(members)context.members=new Set();return out;
    },
    step:(out,value,index,context)=>{out.text+=(index?context.add(','):'')+value;return out;},
    finish:(out,context)=>{if(members)context.members=out.parent;return out.text;},
   };
  }
  if(node.kind==='result'){
   // A Result<Json,E> boundary is explicitly requested by the caller. Ordinary
   // JSON's own sums only propagate an already rendered branch.
   if(unwrap&&nodeRoles.get(node.children[0])==='root')return (tag,value)=>{if(tag)throw Error('JSON result is Err');return value;};
   return (_tag,value)=>value;
  }
  if(node.kind==='string')return value=>{if(!value.isWellFormed())throw Error('invalid JSON String');return value;};
  return value=>value;
 });
}
export class JsonCodec{
 constructor(valueCodec){
  const root=valueCodec.descriptor.root,fields=root.fields;if(root.kind!=='record'||!Array.isArray(fields)||fields.length!==1||fields[0].name!=='payload')throw Error('JSON schema payload');let sum=fields[0].type;
  for(let i=0;i<6;i++){
   if(i<5&&sum.kind!=='result')throw Error('JSON schema sum');const branch=i<5?sum.ok:sum,fs=branch.fields;
   if(branch.kind!=='record'||!Array.isArray(fs)||fs.length!==(i?1:0)||i&&fs[0].name!=='item0')throw Error('JSON schema branch');
   if(i){const t=fs[0].type;if(i===1&&t.kind!=='bool'||(i===2||i===3)&&t.kind!=='string'||i===4&&(t.kind!=='list'||t.element.kind!=='ref'||t.element.name!==root.name))throw Error('JSON schema variant');if(i===5){const mf=t.element?.fields;if(t.kind!=='list'||t.element?.kind!=='record'||!Array.isArray(mf)||mf.length!==2||mf[0].name!=='key'||mf[0].type.kind!=='string'||mf[1].name!=='value'||mf[1].type.kind!=='ref'||mf[1].type.name!==root.name)throw Error('JSON schema member');}}
   if(i===2)this.numberBranch=branch.name;if(i===5)this.objectBranch=branch.name;
   if(i<5)sum=sum.error;
  }if(!jsonSameSchema(root,valueCodec.resolve({kind:'ref',name:root.name})))throw Error('JSON recursive schema mismatch');this.values=valueCodec;
 }
 parse(text,options={}){return parseJsonValue(text,options,jsonBoundaryBudget(options));}
 parseCompiled(codec,text,options={}){
  if(codec?.identity!==this.values.descriptor.identity||typeof codec.builder!=='function')throw Error('compiled JSON schema mismatch');
  const builder=codec.builder(options);try{return parseJsonConstructed(text,options,builder);}catch(error){builder.abort();throw error;}
 }
 stringify(value,options={}){return stringifyJsonValue(value,options,jsonBoundaryBudget(options));}
 stringifyCompiled(codec,handle,options={}){
  const limits=checkedJsonLimits(options),unwrap=options.unwrapResult===true;
  const quoter=options.quoter;if(quoter!==undefined&&!jsonQuoters.has(quoter))throw Error('JSON quote cache owner mismatch');
  let codecs=jsonCompiledRenderers.get(this);if(!codecs)jsonCompiledRenderers.set(this,codecs=new WeakMap());
  let renderers=codecs.get(codec);if(!renderers)codecs.set(codec,renderers=new Map());
  let render=renderers.get(unwrap);if(!render)renderers.set(unwrap,render=compiledJsonRenderer(this,codec,unwrap));
  let bytes=0;const context={
   quoter,
   add(text){bytes+=jsonUtf8Length(text);if(bytes>limits.bytes)throw Error('JSON byte limit');return text;},
   quote(value,colon){
    if(!quoter)return this.add(JSON.stringify(value)+(colon?':':''));
    const token=quoter.token(value);bytes+=token.utf8Bytes+(colon?1:0);if(bytes>limits.bytes)throw Error('JSON byte limit');return token.text+(colon?':':'');
   },
  };
  const text=render(handle,context,limits);
  return text;
 }
 fromJS(value,options={}){return jsonFromJS(value,options);}
 toJS(value,options={}){return jsonToJS(value,options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,false);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,false,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,true);}
 validateBinary(bytes,options={}){
  const decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});let view;
  this.values.visitSpans(bytes,(type,data,start,end)=>{
   view??=new DataView(data.buffer,data.byteOffset,data.byteLength);
   if(type.name===this.numberBranch){const length=view.getUint32(start,true);if(!jsonNumberSpan(data,start+4,start+4+length))throw Error('invalid JSON number token');}
   if(type.name===this.objectBranch){const listEnd=start+4+view.getUint32(start,true),count=view.getUint32(start+4,true),seen=new Set();let at=start+8;for(let i=0;i<count;i++){const memberEnd=at+4+view.getUint32(at,true),keyStart=at+8,keyEnd=keyStart+view.getUint32(at+4,true),key=decoder.decode(data.subarray(keyStart,keyEnd));if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);at=memberEnd;}if(at!==listEnd)throw Error('invalid JSON object frame');}
  },options,[this.numberBranch,this.objectBranch]);return true;

 }
}
function jsonUnpack(value){let p=value.payload,i=0;while(i<5&&Object.hasOwn(p,'Err')){p=p.Err;i++;}return [i,(i<5?p.Ok:p).item0];}
function jsonInteger(token,limit){
 if(!jsonNumberToken(token))throw Error('invalid JSON number');const negative=token[0]==='-',raw=negative?token.slice(1):token,[mantissa,exp='0']=raw.split(/[eE]/);let digits=mantissa.replace('.','');if(/^0+$/.test(digits))return '0';const exponent=Number(exp),fraction=mantissa.includes('.')?mantissa.length-mantissa.indexOf('.')-1:0,shift=exponent-fraction;
 if(!Number.isSafeInteger(exponent)||!Number.isSafeInteger(shift))throw Error('JSON integer exponent limit');
 if(shift<0){const cut=-shift;if(cut>=digits.length||!/^[0]+$/.test(digits.slice(-cut)))throw Error('JSON number is not an integer');digits=digits.slice(0,-cut);}else{if(digits.length+shift>limit)throw Error('JSON integer magnitude limit');digits+='0'.repeat(shift);}
 digits=digits.replace(/^0+/,'');if(digits.length>limit)throw Error('JSON integer magnitude limit');return (negative?'-':'')+digits;
}
function jsonBinary64Value(v){
 if(typeof v==='number')return v;
 const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid F64Bits');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');
 const b=new DataView(new ArrayBuffer(8));b.setBigUint64(0,bits,true);return b.getFloat64(0,true);
}
export class TypedJsonCodec{
 constructor(valueCodec){this.values=valueCodec;}
 decode(document,options={}){
  // Validate JSON-specific invariants before interpreting any tagged/record
  // shape, including duplicated names and malformed numeric tokens.
  stringifyJson(document,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const read=(type,value,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type),[kind,item]=jsonUnpack(value);const fail=()=>{throw Error('JSON does not match '+t.kind);};
   switch(t.kind){
    case 'unit':if(kind!==0)fail();return null;
    case 'bool':if(kind!==1)fail();return item;
    case 'u32':case 'u64':case 'i32':case 'int':{if(kind!==2)fail();const text=jsonInteger(item,t.kind==='int'?4096:t.kind==='u64'?20:10);return t.kind==='int'?{Int:text}:t.kind==='u64'?BigInt(text):Number(text);}
    case 'f64':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(8));if(!Number.isFinite(n))throw Error('JSON f64 overflow');b.setFloat64(0,n,true);return {F64Bits:b.getBigUint64(0,true).toString()};}
    case 'f32':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(4));b.setFloat32(0,n,true);if(!Number.isFinite(b.getFloat32(0,true)))throw Error('JSON f32 overflow');return {F32Bits:b.getUint32(0,true)};}
    case 'string':case 'enum':case 'id':if(kind!==3)fail();return item;
    case 'list':case 'vector':if(kind!==4)fail();return item.map(x=>read(t.element,x,d+1));
    case 'record':{if(kind!==5||item.length!==t.fields.length)throw Error('unknown or missing JSON record field');const fields=new Map(item.map(m=>[m.key,m.value])),out={};for(const f of t.fields){if(!fields.has(f.name))throw Error('missing JSON record field');Object.defineProperty(out,f.name,{value:read(f.type,fields.get(f.name),d+1),writable:true,enumerable:true,configurable:true});}return out;}
    case 'option':case 'result':{if(kind!==5||item.length!==1)fail();const m=item[0];if(t.kind==='option'&&m.key==='None'&&jsonUnpack(m.value)[0]===0)return {None:null};const child=t.kind==='option'&&m.key==='Some'?t.element:t.kind==='result'&&m.key==='Ok'?t.ok:t.kind==='result'&&m.key==='Err'?t.error:null;if(!child)fail();return {[m.key]:read(child,m.value,d+1)};}
    default:fail();
   }
  };
  const out=read(this.values.descriptor.root,document,0);this.values.validateValue(out,options);return out;
 }
 encode(value,options={}){
  this.values.validateValue(value,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const write=(type,v,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type);
   switch(t.kind){
    case 'unit':return jsonVariant(0);
    case 'bool':return jsonVariant(1,v);
    case 'u32':case 'u64':case 'i32':return jsonVariant(2,String(v));
    case 'int':return jsonVariant(2,typeof v==='bigint'?String(v):v.Int);
    case 'f64':{const n=jsonBinary64Value(v);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'f32':{let n;if(typeof v==='number')n=Math.fround(v);else{const b=new DataView(new ArrayBuffer(4));b.setUint32(0,v.F32Bits,true);n=b.getFloat32(0,true);}if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'string':case 'id':case 'enum':return jsonVariant(3,v);
    case 'list':case 'vector':return jsonVariant(4,Array.from(v,x=>write(t.element,x,d+1)));
    case 'record':return jsonVariant(5,t.fields.map(f=>({key:f.name,value:write(f.type,v[f.name],d+1)})));
    case 'option':return jsonVariant(5,[Object.hasOwn(v,'Some')?{key:'Some',value:write(t.element,v.Some,d+1)}:{key:'None',value:jsonVariant(0)}]);
    case 'result':return jsonVariant(5,[Object.hasOwn(v,'Ok')?{key:'Ok',value:write(t.ok,v.Ok,d+1)}:{key:'Err',value:write(t.error,v.Err,d+1)}]);
    default:throw Error('unsupported typed JSON descriptor');
   }
  };return write(this.values.descriptor.root,value,0);
 }
 parse(text,options={}){return this.decode(parseJson(text,options),options);}
 stringify(value,options={}){return stringifyJson(this.encode(value,options),options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,true);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,true,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,false);}
}

// Token reader shared by schema-directed and arbitrary-JSON wire emission.
class JsonWireReader{
 constructor(text,options){this.l=checkedJsonLimits(options);if(typeof text!=='string'||!text.isWellFormed()||text.length>this.l.bytes||jsonUtf8Length(text)>this.l.bytes)throw Error('JSON byte or Unicode limit');this.text=text;this.at=0;this.remaining=this.l.nodes;}
 ws(){while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(c!==32&&c!==9&&c!==10&&c!==13)break;this.at++;}}
 peek(){this.ws();return this.text[this.at];}
 eat(c){this.ws();if(this.text[this.at]===c){this.at++;return true;}return false;}
 node(d){if(d>this.l.depth||--this.remaining<0)throw Error('JSON node or depth limit');}
 string(){
  this.ws();const start=this.at;if(this.text[start]!=='"')throw Error('expected JSON string');
  const end=this.text.indexOf('"',start+1);if(end<0)throw Error('unterminated JSON string');
  const raw=this.text.slice(start+1,end);
  if(!raw.includes('\\')&&!/[\x00-\x1f]/.test(raw)){this.at=end+1;return raw;}
  this.at=start+1;while(this.at<this.text.length){if(this.text[this.at]==='"'){this.at++;const v=JSON.parse(this.text.slice(start,this.at));if(!v.isWellFormed())throw Error('invalid JSON Unicode');return v;}if(this.text[this.at]==='\\')this.at+=2;else this.at++;}throw Error('unterminated JSON string');
 }
 number(){const start=this.at;while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(!(c>=48&&c<=57||c===45||c===43||c===46||c===101||c===69))break;this.at++;}const token=this.text.slice(start,this.at);if(!jsonNumberToken(token))throw Error('invalid JSON number');return token;}
 leaf(d){this.node(d);const c=this.peek();if(c==='n'&&this.text.startsWith('null',this.at)){this.at+=4;return null;}if(c==='t'&&this.text.startsWith('true',this.at)){this.at+=4;return true;}if(c==='f'&&this.text.startsWith('false',this.at)){this.at+=5;return false;}if(c==='"')return this.string();if(c==='-'||c>='0'&&c<='9')return this.number();throw Error('invalid JSON scalar');}
 finish(){this.ws();if(this.at!==this.text.length)throw Error('trailing JSON text');}
}
function streamJsonBinary(values,text,options,typed,compact=false){
 const p=new JsonWireReader(text,options),utf8=jsonWireEncoder;
 const list=(w,open,close,item)=>{if(!p.eat(open))throw Error('JSON container shape');const at=w.beginCount();let count=0;if(!p.eat(close))while(true){item(w);count++;if(p.eat(close))break;if(!p.eat(','))throw Error('JSON container separator');}w.endCount(at,count);};
 const variant=(w,index,level,emit)=>{if(level<index)w.frame(w=>{w.byte(1);variant(w,index,level+1,emit);});else if(index<5)w.frame(w=>{w.byte(0);w.frame(emit);});else w.frame(emit);};
 const json=(w,d)=>{
  const ch=p.peek(),index=ch==='n'?0:ch==='t'||ch==='f'?1:ch==='-'||ch>='0'&&ch<='9'?2:ch==='"'?3:ch==='['?4:ch==='{'?5:-1;if(index<0)throw Error('invalid JSON value');
  const leaf=index<4?p.leaf(d):null;if(index>=4)p.node(d);
  w.frame(w=>variant(w,index,0,w=>{
   if(index===0)return;if(index===1){w.frame(w=>w.byte(+leaf));return;}
   if(index===2||index===3){w.frame(w=>w.text(leaf));return;}
   w.frame(w=>{if(index===4)list(w,'[',']',w=>json(w,d+1));else{const seen=new Set();list(w,'{','}',w=>{const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');w.frame(w=>{w.frame(w=>w.text(key));json(w,d+1);});});}});
  }));
 };
 const read=(type,w,d)=>{
  const t=values.resolve(type);w.frame(w=>{
   if(t.kind==='list'||t.kind==='vector'){p.node(d);list(w,'[',']',w=>read(t.element,w,d+1));return;}
   if(t.kind==='record'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON record');const start=w.position,spans=new Array(t.fields.length).fill(null);
    if(!p.eat('}'))while(true){const key=p.string(),i=t.fields.findIndex(f=>f.name===key);if(i<0)throw Error('unknown JSON record field');if(spans[i])throw Error('duplicate JSON record field');if(!p.eat(':'))throw Error('JSON record colon');const at=w.position;read(t.fields[i].type,w,d+1);spans[i]=[at,w.position];if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON record separator');}
    if(spans.some(s=>s===null))throw Error('missing JSON record field');w.reorder(start,spans);return;
   }
   if(t.kind==='option'||t.kind==='result'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON tagged value');const key=p.string();if(!p.eat(':'))throw Error('JSON tag colon');
    if(t.kind==='option'&&key==='None'){if(p.leaf(d+1)!==null)throw Error('JSON None payload');w.byte(0);}
    else{const child=t.kind==='option'&&key==='Some'?t.element:t.kind==='result'&&key==='Ok'?t.ok:t.kind==='result'&&key==='Err'?t.error:null;if(!child)throw Error('invalid JSON tag');w.byte(key==='Ok'?0:1);read(child,w,d+1);}
    if(!p.eat('}'))throw Error('expected exactly one JSON tag');return;
   }
   const ch=p.peek(),v=p.leaf(d),bad=()=>{throw Error('JSON does not match '+t.kind);};
   if(t.kind==='unit'){if(v!==null)bad();return;}
   if(t.kind==='bool'){if(typeof v!=='boolean')bad();w.byte(+v);return;}
   if(['string','id','enum'].includes(t.kind)){if(ch!=='"')bad();w.text(v);return;}
   if(ch!=='-'&&!(ch>='0'&&ch<='9'))bad();
   if(t.kind==='int'){w.text(jsonInteger(v,4096));return;}
   if(t.kind==='f64'){const n=Number(v);if(!Number.isFinite(n))throw Error('JSON f64 overflow');const b=new DataView(new ArrayBuffer(8));b.setFloat64(0,n,true);w.wide(b.getBigUint64(0,true));}
   else if(t.kind==='f32'){jsonFloatScratch.setFloat32(0,Number(v),true);if(!Number.isFinite(jsonFloatScratch.getFloat32(0,true)))throw Error('JSON f32 overflow');w.word(jsonFloatScratch.getUint32(0,true));}
   else{const n=BigInt(jsonInteger(v,t.kind==='u64'?20:10));if(t.kind==='u64'){if(n<0n||n>18446744073709551615n)bad();w.wide(n);}else if(t.kind==='u32'){if(n<0n||n>4294967295n)bad();w.word(Number(n));}else if(t.kind==='i32'){if(n< -2147483648n||n>2147483647n)bad();w.word(Number(n)>>>0);}else bad();}
  });
 };
 return (compact?values.compact():values).encodeWith(w=>{if(typed)read(values.descriptor.root,w,0);else json(w,0);p.finish();},options);
}

// Render validated bytes in a single traversal; only the final text is owned.
function streamWireJsonText(values,bytes,options,library){
 values.validate(bytes,options);const l=checkedJsonLimits(options),parts=[];let size=0,remaining=l.nodes;const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 const emit=s=>{size+=jsonUtf8Length(s);if(size>l.bytes)throw Error('JSON byte limit');parts.push(s);};
 const string=s=>emit(JSON.stringify(s));const node=d=>{if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');};
 const frame=(type,at)=>{const t=values.resolve(type),start=at+4,end=start+dv.getUint32(at,true);return{t,start,end};};
 const json=(type,at,d)=>{
  node(d);let root=frame(type,at),sum=frame(root.t.fields[0].type,root.start),index=0;
  while(index<5){const err=bytes[sum.start];sum=frame(err?sum.t.error:sum.t.ok,sum.start+1);if(!err)break;index++;}
  if(index===0){emit('null');return root.end;}
  const item=frame(sum.t.fields[0].type,sum.start);
  if(index===1)emit(bytes[item.start]?'true':'false');
  else if(index===2){const token=decoder.decode(bytes.subarray(item.start,item.end));if(!jsonNumberToken(token))throw Error('invalid JSON number token');emit(token);}
  else if(index===3)string(decoder.decode(bytes.subarray(item.start,item.end)));
  else{const count=dv.getUint32(item.start,true);let p=item.start+4;emit(index===4?'[':'{');const seen=new Set();for(let i=0;i<count;i++){if(i)emit(',');if(index===4)p=json(item.t.element,p,d+1);else{const member=frame(item.t.element,p),key=frame(member.t.fields[0].type,member.start),name=decoder.decode(bytes.subarray(key.start,key.end));if(seen.has(name))throw Error('duplicate JSON object key');seen.add(name);string(name);emit(':');json(member.t.fields[1].type,key.end,d+1);p=member.end;}}emit(index===4?']':'}');}
  return root.end;
 };
 const typed=(type,at,d)=>{
  node(d);const f=frame(type,at),t=f.t;let p=f.start;
  switch(t.kind){
   case 'unit':emit('null');break;
   case 'bool':emit(bytes[p]?'true':'false');break;
   case 'u32':emit(String(dv.getUint32(p,true)));break;
   case 'u64':emit(String(dv.getBigUint64(p,true)));break;
   case 'i32':emit(String(dv.getInt32(p,true)));break;
   case 'f64':{const n=dv.getFloat64(p,true);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'f32':{const n=dv.getFloat32(p,true);if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'int':emit(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'string':case 'id':case 'enum':string(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'list':case 'vector':{const n=dv.getUint32(p,true);p+=4;emit('[');for(let i=0;i<n;i++){if(i)emit(',');p=typed(t.element,p,d+1);}emit(']');break;}
   case 'record':emit('{');for(let i=0;i<t.fields.length;i++){if(i)emit(',');const field=t.fields[i];string(field.name);emit(':');p=typed(field.type,p,d+1);}emit('}');break;
   case 'option':case 'result':{const tag=bytes[p++],key=t.kind==='option'?(tag?'Some':'None'):tag?'Err':'Ok';emit('{');string(key);emit(':');if(t.kind==='option'&&!tag){node(d+1);emit('null');}else typed(t.kind==='option'?t.element:tag?t.error:t.ok,p,d+1);emit('}');break;}
   default:throw Error('unsupported typed JSON descriptor');
  }return f.end;
 };
 if(library)json(values.descriptor.root,40,0);else typed(values.descriptor.root,40,0);return parts.join('');
}

/** Owned, optional read view of arbitrary JSON. Auxiliary indexes contain member
 * offsets only. Logical order, exact number tokens and missing/null remain intact.
 * This does not transparently replace any compiled Ink action or its state.
 */
export function createJsonLookup(text,{stepEntries=16,minReads=4,maxEntries=4096,maxObjects=64,maxIndexBytes=262144,...limits}={}){
 for(const [v,max]of [[stepEntries,4096],[minReads,1000000],[maxEntries,1000000],[maxObjects,256],[maxIndexBytes,16777216]])if(!Number.isSafeInteger(v)||v<0||v>max)throw Error('JSON index budget');
 let root=parseJson(text,limits),indexes=new Map(),entries=0,indexBytes=0;
 const stats={reads:0,writes:0,scanned_members:0,index_hits:0,built_entries:0,invalidations:0};
 function parts(path){
  if(!Array.isArray(path))throw Error('JSON lookup path');const n=path.length;if(n>128)throw Error('JSON lookup path');
  const owned=[];for(let i=0;i<n;i++){const d=Object.getOwnPropertyDescriptor(path,String(i));if(!d||!Object.hasOwn(d,'value'))throw Error('JSON lookup path');const p=d.value;if(!(typeof p==='string'&&p.isWellFormed()&&p.length<=4096)&&!(Number.isSafeInteger(p)&&p>=0))throw Error('JSON lookup path');owned.push(p);}return owned;
 }
 function variant(value){let p=value.payload,index=0;while(index<5&&Object.hasOwn(p,'Err')){p=p.Err;index++;}return {index,item:(index<5?p.Ok:p).item0};}
 function resolve(document,path,indexed){
  let value=document,budget=stepEntries;
  for(let depth=0;depth<path.length;depth++){
   const part=path[depth],v=variant(value);
   if(typeof part==='number'){
    if(v.index!==4)throw Error('expected JSON array');if(part>=v.item.length)return {found:false};value=v.item[part];continue;
   }
   if(v.index!==5)throw Error('expected JSON object');
   const prefix=path.slice(0,depth),key=JSON.stringify(prefix),overhead=128+prefix.reduce((n,p)=>n+(typeof p==='string'?16+p.length*2:8),0);let idx=indexed?indexes.get(key):null;
   if(indexed&&!idx&&indexes.size<maxObjects&&indexBytes+overhead<=maxIndexBytes){idx={path:prefix,reads:0,cursor:0,keys:new Map(),bytes:overhead};indexes.set(key,idx);indexBytes+=overhead;}
   if(idx){
    idx.reads++;
    if(idx.reads>=minReads)while(budget>0&&idx.cursor<v.item.length&&entries<maxEntries){
     const member=v.item[idx.cursor],bytes=64+member.key.length*2;
     if(indexBytes+bytes>maxIndexBytes)break;
     idx.keys.set(member.key,idx.cursor++);idx.bytes+=bytes;indexBytes+=bytes;entries++;stats.built_entries++;budget--;
    }
    if(idx.keys.has(part)){stats.index_hits++;value=v.item[idx.keys.get(part)].value;continue;}
   }
   let found=false;
   for(let i=idx?.cursor??0;i<v.item.length;i++){if(indexed)stats.scanned_members++;if(v.item[i].key===part){value=v.item[i].value;found=true;break;}}
   if(!found)return {found:false};
  }
  return {found:true,value};
 }
 return {
  lookup(path){stats.reads++;const r=resolve(root,parts(path),true);return r.found?{found:true,value:structuredClone(r.value)}:r;},
  set(path,key,text){
   path=parts(path);if(typeof key!=='string'||!key.isWellFormed())throw Error('JSON object key');
   const replacement=parseJson(text,limits),next=structuredClone(root),r=resolve(next,path,false);
   if(!r.found)throw Error('JSON update path missing');const object=variant(r.value);if(object.index!==5)throw Error('expected JSON object');
   const members=[{key,value:replacement},...object.item.filter(m=>m.key!==key)];
   // Validate the complete resulting document before publishing a write.
   let payload=r.value.payload;for(let i=0;i<5;i++)payload=payload.Err;payload.item0=members;
   stringifyJson(next,limits);root=next;stats.writes++;
   for(const [id,idx]of indexes)if(idx.path.length>=path.length&&path.every((p,i)=>p===idx.path[i])){entries-=idx.keys.size;indexBytes-=idx.bytes;indexes.delete(id);stats.invalidations++;}
  },
  replace(text){const next=parseJson(text,limits);root=next;stats.writes++;stats.invalidations+=indexes.size;indexes.clear();entries=0;indexBytes=0;},
  stringify(){return stringifyJson(root,limits);},
  stats(){return {...stats,index_entries:entries,index_objects:indexes.size,index_bytes:indexBytes};}
 };
}
function __ownedValue2(value,budget,depth){budget.enter(depth,4);return {["a"]:__ownedValue3(value["a"],budget,depth+1),["b"]:__ownedValue3(value["b"],budget,depth+1),["c"]:__ownedValue3(value["c"],budget,depth+1),["d"]:__ownedValue3(value["d"],budget,depth+1)};}
function __ownedValue3(value,budget,depth){budget.enter(depth,4);return {["identity"]:__ownedValue1(value["identity"],budget,depth+1),["scale"]:__ownedValue1(value["scale"],budget,depth+1),["bias"]:__ownedValue1(value["bias"],budget,depth+1),["relu"]:__ownedValue1(value["relu"],budget,depth+1)};}
function __ownedValue0(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue1(value["value"],budget,depth+1),["tangent_0"]:__ownedValue1(value["tangent_0"],budget,depth+1),["tangent_1"]:__ownedValue1(value["tangent_1"],budget,depth+1),["tangent_2"]:__ownedValue1(value["tangent_2"],budget,depth+1),["tangent_3"]:__ownedValue1(value["tangent_3"],budget,depth+1),["tangent_4"]:__ownedValue1(value["tangent_4"],budget,depth+1),["tangent_5"]:__ownedValue1(value["tangent_5"],budget,depth+1),["tangent_6"]:__ownedValue1(value["tangent_6"],budget,depth+1),["tangent_7"]:__ownedValue1(value["tangent_7"],budget,depth+1),["tangent_8"]:__ownedValue1(value["tangent_8"],budget,depth+1),["tangent_9"]:__ownedValue1(value["tangent_9"],budget,depth+1),["tangent_10"]:__ownedValue1(value["tangent_10"],budget,depth+1),["tangent_11"]:__ownedValue1(value["tangent_11"],budget,depth+1),["tangent_12"]:__ownedValue1(value["tangent_12"],budget,depth+1),["tangent_13"]:__ownedValue1(value["tangent_13"],budget,depth+1),["tangent_14"]:__ownedValue1(value["tangent_14"],budget,depth+1),["tangent_15"]:__ownedValue1(value["tangent_15"],budget,depth+1)};}
function __ownedValue1(value,budget,depth){budget.enter(depth,8);const bits=typeof value==='number'?__bits(value):value.F32Bits;return {F32Bits:bits===0?0:bits};}
const __ownedFunctions=Object.freeze(Object.fromEntries([["__ink_differential_3",__ownedValue0],["__ink_differential_1",__ownedValue2]]));
function __wireValue7(reader){const end=reader.frame();const value={["a"]:__wireValue8(reader),["b"]:__wireValue8(reader),["c"]:__wireValue8(reader),["d"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue1(reader){const end=reader.frame();const value={["a"]:__wireValue2(reader),["b"]:__wireValue2(reader),["c"]:__wireValue2(reader),["d"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue8(reader){const end=reader.frame();const value={["identity"]:__wireValue9(reader),["scale"]:__wireValue9(reader),["bias"]:__wireValue9(reader),["relu"]:__wireValue9(reader)};reader.finish(end);return value;}
function __wireValue2(reader){const end=reader.frame();const value={["identity"]:__wireValue3(reader),["scale"]:__wireValue3(reader),["bias"]:__wireValue3(reader),["relu"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue4(reader){const end=reader.frame();const value={["slot"]:__wireValue5(reader),["operation"]:__wireValue5(reader)};reader.finish(end);return value;}
function __wireValue10(reader){const end=reader.frame();const value={["slot"]:__wireValue5(reader),["operation"]:__wireValue5(reader)};reader.finish(end);return value;}
function __wireValue9(reader){const end=reader.frame();const value={["value"]:__wireValue3(reader),["tangent_0"]:__wireValue3(reader),["tangent_1"]:__wireValue3(reader),["tangent_2"]:__wireValue3(reader),["tangent_3"]:__wireValue3(reader),["tangent_4"]:__wireValue3(reader),["tangent_5"]:__wireValue3(reader),["tangent_6"]:__wireValue3(reader),["tangent_7"]:__wireValue3(reader),["tangent_8"]:__wireValue3(reader),["tangent_9"]:__wireValue3(reader),["tangent_10"]:__wireValue3(reader),["tangent_11"]:__wireValue3(reader),["tangent_12"]:__wireValue3(reader),["tangent_13"]:__wireValue3(reader),["tangent_14"]:__wireValue3(reader),["tangent_15"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue6(reader){const end=reader.frame();const value={["w"]:__wireValue7(reader),["p"]:__wireValue10(reader)};reader.finish(end);return value;}
function __wireValue0(reader){const end=reader.frame();const value={["w"]:__wireValue1(reader),["p"]:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue3(reader){const end=reader.frame();const value={F32Bits:reader.word()};reader.finish(end);return value;}
function __wireValue5(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
const __wireReaders=Object.freeze(Object.fromEntries([["__ink_differential_1",[__wireValue0,__wireValue1]],["__ink_differential_3",[__wireValue6,__wireValue9]]]));

const __ownedImplementations=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>{
 const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
 const body=__implementations[f.index];
 const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
 return [f.name,input.every(c=>c===__identity)?implementation:(...args)=>{const context=new WeakMap();return implementation(...args.map((v,i)=>input[i](v,context)));}];
})));

export const valueCodecs=(()=>{const codecs={};for(const [name,s] of Object.entries(metadata.wire.functions)){if(s.unsupported)continue;let value;Object.defineProperty(codecs,name,{enumerable:true,get:()=>value??=(Object.freeze(Object.hasOwn(__wireReaders,name)?{arguments:createCompiledValueCodec(s.arguments,__wireReaders[name][0]),result:createCompiledValueCodec(s.result,__wireReaders[name][1])}:{arguments:new ValueCodec(s.arguments),result:new ValueCodec(s.result)}))});}return Object.freeze(codecs);})();
function __callEncoded(name,bytes,limits,compact){
 const f=metadata.functions.find(f=>f.name===name&&!f.internal),codecs=valueCodecs[name];
 if(!f||!codecs)throw Error('unsupported binary function');
 const input=compact?codecs.arguments.compact():codecs.arguments,output=compact?codecs.result.compact():codecs.result;
 const entry=__compiledEntries.get(name);
 if(entry){
  const slot=compact?1:0;
  entry.argumentCodecs[slot]??=(entry.boundaryReaders[slot]?createFusedValueCodec:createCompiledValueCodec)(metadata.wire.functions[name].arguments,entry.arguments);
  const decoder=entry.argumentCodecs[slot];
  const values=(compact?decoder.compact():decoder).decode(bytes,limits),args=f.params.map(p=>values[p.name]);
  if(entry.precondition!==null&&__implementations[entry.precondition](...args)!==true)throw Error('contract precondition failed');
  return __compiledEncodeResult(entry,__implementations[entry.index](...args),limits,compact);
 }
 const values=input.decode(bytes,limits);
 const result=call(name,f.params.map(p=>values[p.name]));
 return output.encode(result,limits);
}
export function callBinary(name,bytes,limits={}){return __callEncoded(name,bytes,limits,false);}
export function callCompact(name,bytes,limits={}){return __callEncoded(name,bytes,limits,true);}
// Same stable, well-typed caller inputs as call; the result owns every container.
// The checked source return type justifies trusted copying, not arbitrary input.
export function callOwned(name,args,limits={}){
 if(!Object.hasOwn(__ownedFunctions,name)||!Object.hasOwn(functions,name))throw Error('unsupported owned function');
 const result=__ownedImplementations[name](...args);return __ownedFunctions[name](result,createValueCaptureBudget(limits),0);
}
function __privateCapture0(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==4){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"c")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"d")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture1(value["a"],budget,depth+1),["b"]:__privateCapture1(value["b"],budget,depth+1),["c"]:__privateCapture1(value["c"],budget,depth+1),["d"]:__privateCapture1(value["d"],budget,depth+1)};}
function __privateCapture6(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==4){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"c")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"d")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture7(value["a"],budget,depth+1),["b"]:__privateCapture7(value["b"],budget,depth+1),["c"]:__privateCapture7(value["c"],budget,depth+1),["d"]:__privateCapture7(value["d"],budget,depth+1)};}
function __privateCapture1(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==4){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"identity")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"scale")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"bias")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"relu")){throw Error('invalid value for wire schema');}return {["identity"]:__privateCapture2(value["identity"],budget,depth+1),["scale"]:__privateCapture2(value["scale"],budget,depth+1),["bias"]:__privateCapture2(value["bias"],budget,depth+1),["relu"]:__privateCapture2(value["relu"],budget,depth+1)};}
function __privateCapture7(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==4){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"identity")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"scale")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"bias")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"relu")){throw Error('invalid value for wire schema');}return {["identity"]:__privateCapture3(value["identity"],budget,depth+1),["scale"]:__privateCapture3(value["scale"],budget,depth+1),["bias"]:__privateCapture3(value["bias"],budget,depth+1),["relu"]:__privateCapture3(value["relu"],budget,depth+1)};}
function __privateCapture8(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"slot")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"operation")){throw Error('invalid value for wire schema');}return {["slot"]:__privateCapture5(value["slot"],budget,depth+1),["operation"]:__privateCapture5(value["operation"],budget,depth+1)};}
function __privateCapture4(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"slot")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"operation")){throw Error('invalid value for wire schema');}return {["slot"]:__privateCapture5(value["slot"],budget,depth+1),["operation"]:__privateCapture5(value["operation"],budget,depth+1)};}
function __privateCapture2(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==17){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_0")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_1")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_2")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_3")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_4")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_5")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_6")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_7")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_8")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_9")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_10")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_11")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_12")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_13")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_14")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_15")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture3(value["value"],budget,depth+1),["tangent_0"]:__privateCapture3(value["tangent_0"],budget,depth+1),["tangent_1"]:__privateCapture3(value["tangent_1"],budget,depth+1),["tangent_2"]:__privateCapture3(value["tangent_2"],budget,depth+1),["tangent_3"]:__privateCapture3(value["tangent_3"],budget,depth+1),["tangent_4"]:__privateCapture3(value["tangent_4"],budget,depth+1),["tangent_5"]:__privateCapture3(value["tangent_5"],budget,depth+1),["tangent_6"]:__privateCapture3(value["tangent_6"],budget,depth+1),["tangent_7"]:__privateCapture3(value["tangent_7"],budget,depth+1),["tangent_8"]:__privateCapture3(value["tangent_8"],budget,depth+1),["tangent_9"]:__privateCapture3(value["tangent_9"],budget,depth+1),["tangent_10"]:__privateCapture3(value["tangent_10"],budget,depth+1),["tangent_11"]:__privateCapture3(value["tangent_11"],budget,depth+1),["tangent_12"]:__privateCapture3(value["tangent_12"],budget,depth+1),["tangent_13"]:__privateCapture3(value["tangent_13"],budget,depth+1),["tangent_14"]:__privateCapture3(value["tangent_14"],budget,depth+1),["tangent_15"]:__privateCapture3(value["tangent_15"],budget,depth+1)};}
function __privateCapture3(value,budget,depth=0){budget.enter(depth,4);let bits;if(typeof value==='number'&&Number.isFinite(value)){bits=__bits(value);if(!Number.isFinite(__float(bits))){throw Error('invalid value for wire schema');}}else{if(!(value!==null&&typeof value==='object'&&Object.hasOwn(value,'F32Bits')&&Object.keys(value).length===1)){throw Error('invalid value for wire schema');}bits=value.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295){throw Error('invalid value for wire schema');}}budget.add(4);return __nfFromBits(bits);}
function __privateCapture5(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='number'||!Number.isInteger(value)||value<0||value>4294967295){throw Error('invalid value for wire schema');}budget.add(4);return value===0?0:value;}
function __privateWireValue0(reader){const end=reader.frame();const value={["a"]:__privateWireValue1(reader),["b"]:__privateWireValue1(reader),["c"]:__privateWireValue1(reader),["d"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue7(reader){const end=reader.frame();const value={["a"]:__privateWireValue8(reader),["b"]:__privateWireValue8(reader),["c"]:__privateWireValue8(reader),["d"]:__privateWireValue8(reader)};reader.finish(end);return value;}
function __privateWireValue1(reader){const end=reader.frame();const value={["identity"]:__privateWireValue2(reader),["scale"]:__privateWireValue2(reader),["bias"]:__privateWireValue2(reader),["relu"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue8(reader){const end=reader.frame();const value={["identity"]:__privateWireValue3(reader),["scale"]:__privateWireValue3(reader),["bias"]:__privateWireValue3(reader),["relu"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue9(reader){const end=reader.frame();const value={["slot"]:__privateWireValue5(reader),["operation"]:__privateWireValue5(reader)};reader.finish(end);return value;}
function __privateWireValue4(reader){const end=reader.frame();const value={["slot"]:__privateWireValue5(reader),["operation"]:__privateWireValue5(reader)};reader.finish(end);return value;}
function __privateWireValue2(reader){const end=reader.frame();const value={["value"]:__privateWireValue3(reader),["tangent_0"]:__privateWireValue3(reader),["tangent_1"]:__privateWireValue3(reader),["tangent_2"]:__privateWireValue3(reader),["tangent_3"]:__privateWireValue3(reader),["tangent_4"]:__privateWireValue3(reader),["tangent_5"]:__privateWireValue3(reader),["tangent_6"]:__privateWireValue3(reader),["tangent_7"]:__privateWireValue3(reader),["tangent_8"]:__privateWireValue3(reader),["tangent_9"]:__privateWireValue3(reader),["tangent_10"]:__privateWireValue3(reader),["tangent_11"]:__privateWireValue3(reader),["tangent_12"]:__privateWireValue3(reader),["tangent_13"]:__privateWireValue3(reader),["tangent_14"]:__privateWireValue3(reader),["tangent_15"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue6(reader){const end=reader.frame();const value={["w"]:__privateWireValue0(reader),["p"]:__privateWireValue4(reader)};reader.finish(end);return value;}
function __privateWireValue10(reader){const end=reader.frame();const value={["w"]:__privateWireValue7(reader),["p"]:__privateWireValue9(reader)};reader.finish(end);return value;}
function __privateWireValue3(reader){const end=reader.frame();const value=__nfFromBits(reader.word());reader.finish(end);return value;}
function __privateWireValue5(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __compiledOwnedValue0(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue1(value["a"],budget,depth+1),["b"]:__compiledOwnedValue1(value["b"],budget,depth+1),["c"]:__compiledOwnedValue1(value["c"],budget,depth+1),["d"]:__compiledOwnedValue1(value["d"],budget,depth+1)};}
function __compiledOwnedValue6(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue7(value["a"],budget,depth+1),["b"]:__compiledOwnedValue7(value["b"],budget,depth+1),["c"]:__compiledOwnedValue7(value["c"],budget,depth+1),["d"]:__compiledOwnedValue7(value["d"],budget,depth+1)};}
function __compiledOwnedValue1(value,budget,depth){budget.enter(depth,4);return {["identity"]:__compiledOwnedValue2(value["identity"],budget,depth+1),["scale"]:__compiledOwnedValue2(value["scale"],budget,depth+1),["bias"]:__compiledOwnedValue2(value["bias"],budget,depth+1),["relu"]:__compiledOwnedValue2(value["relu"],budget,depth+1)};}
function __compiledOwnedValue7(value,budget,depth){budget.enter(depth,4);return {["identity"]:__compiledOwnedValue3(value["identity"],budget,depth+1),["scale"]:__compiledOwnedValue3(value["scale"],budget,depth+1),["bias"]:__compiledOwnedValue3(value["bias"],budget,depth+1),["relu"]:__compiledOwnedValue3(value["relu"],budget,depth+1)};}
function __compiledOwnedValue8(value,budget,depth){budget.enter(depth,4);return {["slot"]:__compiledOwnedValue5(value["slot"],budget,depth+1),["operation"]:__compiledOwnedValue5(value["operation"],budget,depth+1)};}
function __compiledOwnedValue4(value,budget,depth){budget.enter(depth,4);return {["slot"]:__compiledOwnedValue5(value["slot"],budget,depth+1),["operation"]:__compiledOwnedValue5(value["operation"],budget,depth+1)};}
function __compiledOwnedValue2(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue3(value["value"],budget,depth+1),["tangent_0"]:__compiledOwnedValue3(value["tangent_0"],budget,depth+1),["tangent_1"]:__compiledOwnedValue3(value["tangent_1"],budget,depth+1),["tangent_2"]:__compiledOwnedValue3(value["tangent_2"],budget,depth+1),["tangent_3"]:__compiledOwnedValue3(value["tangent_3"],budget,depth+1),["tangent_4"]:__compiledOwnedValue3(value["tangent_4"],budget,depth+1),["tangent_5"]:__compiledOwnedValue3(value["tangent_5"],budget,depth+1),["tangent_6"]:__compiledOwnedValue3(value["tangent_6"],budget,depth+1),["tangent_7"]:__compiledOwnedValue3(value["tangent_7"],budget,depth+1),["tangent_8"]:__compiledOwnedValue3(value["tangent_8"],budget,depth+1),["tangent_9"]:__compiledOwnedValue3(value["tangent_9"],budget,depth+1),["tangent_10"]:__compiledOwnedValue3(value["tangent_10"],budget,depth+1),["tangent_11"]:__compiledOwnedValue3(value["tangent_11"],budget,depth+1),["tangent_12"]:__compiledOwnedValue3(value["tangent_12"],budget,depth+1),["tangent_13"]:__compiledOwnedValue3(value["tangent_13"],budget,depth+1),["tangent_14"]:__compiledOwnedValue3(value["tangent_14"],budget,depth+1),["tangent_15"]:__compiledOwnedValue3(value["tangent_15"],budget,depth+1)};}
function __compiledOwnedValue3(value,budget,depth){budget.enter(depth,8);const bits=typeof value==='number'?__bits(value):value.F32Bits;return {F32Bits:bits===0?0:bits};}
function __compiledOwnedValue5(value,budget,depth){budget.enter(depth,8);return value>>>0;}
function __privateWireWrite0(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["a"],compact);__privateWireWrite1(writer,value["b"],compact);__privateWireWrite1(writer,value["c"],compact);__privateWireWrite1(writer,value["d"],compact);writer.closeFrame(frame);}
function __privateWireWrite6(writer,value,compact){const frame=writer.openFrame();__privateWireWrite7(writer,value["a"],compact);__privateWireWrite7(writer,value["b"],compact);__privateWireWrite7(writer,value["c"],compact);__privateWireWrite7(writer,value["d"],compact);writer.closeFrame(frame);}
function __privateWireWrite1(writer,value,compact){const frame=writer.openFrame();__privateWireWrite2(writer,value["identity"],compact);__privateWireWrite2(writer,value["scale"],compact);__privateWireWrite2(writer,value["bias"],compact);__privateWireWrite2(writer,value["relu"],compact);writer.closeFrame(frame);}
function __privateWireWrite7(writer,value,compact){const frame=writer.openFrame();__privateWireWrite3(writer,value["identity"],compact);__privateWireWrite3(writer,value["scale"],compact);__privateWireWrite3(writer,value["bias"],compact);__privateWireWrite3(writer,value["relu"],compact);writer.closeFrame(frame);}
function __privateWireWrite8(writer,value,compact){const frame=writer.openFrame();__privateWireWrite5(writer,value["slot"],compact);__privateWireWrite5(writer,value["operation"],compact);writer.closeFrame(frame);}
function __privateWireWrite4(writer,value,compact){const frame=writer.openFrame();__privateWireWrite5(writer,value["slot"],compact);__privateWireWrite5(writer,value["operation"],compact);writer.closeFrame(frame);}
function __privateWireWrite2(writer,value,compact){const frame=writer.openFrame();__privateWireWrite3(writer,value["value"],compact);__privateWireWrite3(writer,value["tangent_0"],compact);__privateWireWrite3(writer,value["tangent_1"],compact);__privateWireWrite3(writer,value["tangent_2"],compact);__privateWireWrite3(writer,value["tangent_3"],compact);__privateWireWrite3(writer,value["tangent_4"],compact);__privateWireWrite3(writer,value["tangent_5"],compact);__privateWireWrite3(writer,value["tangent_6"],compact);__privateWireWrite3(writer,value["tangent_7"],compact);__privateWireWrite3(writer,value["tangent_8"],compact);__privateWireWrite3(writer,value["tangent_9"],compact);__privateWireWrite3(writer,value["tangent_10"],compact);__privateWireWrite3(writer,value["tangent_11"],compact);__privateWireWrite3(writer,value["tangent_12"],compact);__privateWireWrite3(writer,value["tangent_13"],compact);__privateWireWrite3(writer,value["tangent_14"],compact);__privateWireWrite3(writer,value["tangent_15"],compact);writer.closeFrame(frame);}
function __privateWireWrite3(writer,value,compact){const frame=writer.openFrame();writer.word(__nfBits(value));writer.closeFrame(frame);}
function __privateWireWrite5(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
// Handles have no mutable private payload surface. Membership and type identity
// are checked by this module's closure; copied/foreign objects cannot forge them.
const __compiledHandles=new WeakMap();
const __compiledBindings=new WeakMap();
function __compiledHandle(identity,value,guaranteed=false){
 const handle=Object.freeze(Object.create(null));
 __compiledHandles.set(handle,{identity,value,guaranteed});return handle;
}
function __compiledEntry(handle,identity){
 const entry=__compiledHandles.get(handle);
 if(!entry||entry.identity!==identity)throw Error('compiled value type or owner mismatch');
 return entry;
}
function __compiledUnwrap(handle,identity){return __compiledEntry(handle,identity).value;}
// Emit the portable schema's framing/scalar events without creating a buffer
// or exposing private composite nodes. Only this wrapper receives callbacks
// from the literal writer; host visitors never receive those closures.
function __compiledValueEvents(sink,limits){
 const methods=['begin','end','byte','word','wide','text','count'];
 for(const name of methods)if(typeof sink?.[name]!=='function')throw Error('compiled value visitor method: '+name);
 const budget=createValueCaptureBudget(limits);let depth=0,closed=false;
 const active=()=>{if(closed)throw Error('compiled value visitor is closed');};
 const writer=Object.freeze({
  openFrame(){active();budget.enter(depth,4);depth++;sink.begin();return 0;}
  ,closeFrame(){active();if(depth===0)throw Error('wire frame boundary');try{sink.end();}finally{depth--;}}
  ,frame(emit){active();budget.enter(depth,4);depth++;sink.begin();try{emit();sink.end();}finally{depth--;}}
  ,byte(value){active();budget.add(1);sink.byte(value);}
  ,word(value){active();budget.add(4);sink.word(value);}
  ,wide(value){active();budget.add(8);sink.wide(value);}
  ,text(value){active();budget.text(value);sink.text(value);}
  ,count(value){active();budget.add(4);if(value>budget.remaining)throw Error('wire sequence size');sink.count(value);}
 });
 return {writer,close(){closed=true;}};
}
function __compiledReduction(factory,root,reduce,identity){
 if(typeof factory!=='function')throw Error('compiled reduction factory');
 const reducers=[],seen=new Set(),nodes=__reductionNodes();
 const prepare=index=>{
  if(seen.has(index))return;seen.add(index);
  const node=nodes[index];
  for(const child of node.children)prepare(child);
  const reducer=factory(node,index);
  if(node.kind==='list'||node.kind==='vector'){
   const start=reducer?.start,step=reducer?.step,finish=reducer?.finish;
   if(typeof start!=='function'||typeof step!=='function'||typeof finish!=='function')throw Error('compiled collection reduction');
   reducers[index]=Object.freeze({start,step,finish});
  }else{
   if(typeof reducer!=='function')throw Error('compiled value reduction');
   reducers[index]=reducer;
  }
 };
 prepare(root);Object.freeze(reducers);
 return Object.freeze(function(handle,context,limits={}){
  const value=__compiledUnwrap(handle,identity),budget=createValueCaptureBudget(limits);
  return reduce(value,reducers,budget,0,context);
 });
}
function __compiledCodec(schema,capture,read,write,copy,constructorRoot,reductionRoot,reduce,portableFused=false,compactFused=false){
 const privateCodec=createCompiledValueCodec(schema,read),publicCodec=privateCodec;
 let fusedCodec;const fused=()=>fusedCodec??=createFusedValueCodec(schema,read);
 const identity=schema.identity;
 const codec=Object.freeze({
  identity,
  descriptor:publicCodec.descriptor,
  resolve(type){return publicCodec.resolve(type);},
  capture(value,limits={}){
   return __compiledHandle(identity,capture(value,createValueCaptureBudget(limits),0));
  },
  decode(bytes,limits={}){return __compiledHandle(identity,(portableFused?fused():privateCodec).decode(bytes,limits));},
  decodeCompact(bytes,limits={}){return __compiledHandle(identity,(compactFused?fused():privateCodec).compact().decode(bytes,limits));},
  decodeFused(bytes,limits={}){return __compiledHandle(identity,fused().decode(bytes,limits));},
  decodeCompactFused(bytes,limits={}){return __compiledHandle(identity,fused().compact().decode(bytes,limits));},
  encode(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.encodeWith(writer=>write(writer,value,false),limits);},
  encodeCompact(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.compact().encodeWith(writer=>write(writer,value,true),limits);},
  materialize(handle,limits={}){return copy(__compiledUnwrap(handle,identity),createValueCaptureBudget(limits),0);},
  builder(limits={}){return __valueBuilder(__constructorNodes(),constructorRoot,identity,limits);},
  reducer(factory){return __compiledReduction(factory,reductionRoot,reduce,identity);},
  visit(handle,sink,limits={}){
   const value=__compiledUnwrap(handle,identity),events=__compiledValueEvents(sink,limits);
   try{write(events.writer,value,false);}finally{events.close();}
  },
 });
 __compiledBindings.set(codec,{publicCodec,write,capture});return codec;
}

function __compiledEncodeResult(entry,value,limits,compact){
 const {publicCodec,write}=__compiledBindings.get(entry.result());
 return (compact?publicCodec.compact():publicCodec).encodeWith(writer=>write(writer,value,compact),limits);
}
let __constructorNodesValue;function __constructorNodes(){return __constructorNodesValue??=[{kind:'record',fields:["a","b","c","d"],patterns:[{bytes:4,label:"record",children:[1,1,1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1],["c"]:values[2],["d"]:values[3]})}]},{kind:'record',fields:["identity","scale","bias","relu"],patterns:[{bytes:4,label:"record",children:[2,2,2,2],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["identity"]:values[0],["scale"]:values[1],["bias"]:values[2],["relu"]:values[3]})}]},{kind:'record',fields:["value","tangent_0","tangent_1","tangent_2","tangent_3","tangent_4","tangent_5","tangent_6","tangent_7","tangent_8","tangent_9","tangent_10","tangent_11","tangent_12","tangent_13","tangent_14","tangent_15"],patterns:[{bytes:4,label:"record",children:[3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["tangent_0"]:values[1],["tangent_1"]:values[2],["tangent_2"]:values[3],["tangent_3"]:values[4],["tangent_4"]:values[5],["tangent_5"]:values[6],["tangent_6"]:values[7],["tangent_7"]:values[8],["tangent_8"]:values[9],["tangent_9"]:values[10],["tangent_10"]:values[11],["tangent_11"]:values[12],["tangent_12"]:values[13],["tangent_13"]:values[14],["tangent_14"]:values[15],["tangent_15"]:values[16]})}]},{kind:"f32",scalar:__privateCapture3},{kind:'record',fields:["slot","operation"],patterns:[{bytes:4,label:"record",children:[5,5],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["slot"]:values[0],["operation"]:values[1]})}]},{kind:"u32",scalar:__privateCapture5},{kind:'record',fields:["a","b","c","d"],patterns:[{bytes:4,label:"record",children:[7,7,7,7],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1],["c"]:values[2],["d"]:values[3]})}]},{kind:'record',fields:["identity","scale","bias","relu"],patterns:[{bytes:4,label:"record",children:[3,3,3,3],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["identity"]:values[0],["scale"]:values[1],["bias"]:values[2],["relu"]:values[3]})}]},{kind:'record',fields:["slot","operation"],patterns:[{bytes:4,label:"record",children:[5,5],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["slot"]:values[0],["operation"]:values[1]})}]}];}
// Typed input construction only: plans contain literal constructor/capture
// functions emitted from source schemas. No source expression evaluator.
// All frames and private values remain in this closure; callers receive only
// an owned opaque handle after one complete, well-typed root is constructed.
const __constructorPaths=new WeakMap();
function __valueBuilder(nodes,root,identity,limits){
 const budget=createValueCaptureBudget(limits),frames=[];
 let result,targetNode,targetDepth,complete=false,closed=false,failed=false,busy=false;
 const fail=message=>{failed=true;frames.length=0;result=undefined;throw Error(message);};
 const active=()=>{if(failed||closed)throw Error('value builder is closed');};
 const expected=()=>{
  if(!frames.length){if(complete)fail('value builder root already complete');targetNode=root;targetDepth=0;return;}
  const frame=frames.at(-1),position=frame.values.length;
  if(!frame.pattern.sequence&&position>=frame.pattern.children.length)fail('value builder constructor is full');
  targetNode=frame.pattern.sequence?frame.pattern.children[0]:frame.pattern.children[position];targetDepth=frame.depth+frame.pattern.childDepth;
 };
 const accept=value=>{
  if(frames.length)frames.at(-1).values.push(value);
  else{result=value;complete=true;}
 };
 const execute=(operation,first,second)=>{
  active();if(busy)throw Error('value builder operation already active');busy=true;
  try{return operation(first,second);}catch(error){failed=true;frames.length=0;result=undefined;throw error;}finally{busy=false;}
 };
 // Compile and cache constructor paths independently of the session's values.
 const pathPlan=(choices,startNode,startDepth)=>{
   if(!Array.isArray(choices)||choices.length===0||choices.length>128)fail('invalid value builder path');
   let cache=__constructorPaths.get(nodes);if(!cache){cache=new WeakMap();__constructorPaths.set(nodes,cache);}
   let entries=cache.get(choices),saved=entries?.get(startNode);
   if(saved)return saved;
   const path=[],charges=[];let node=startNode,depth=startDepth;
   for(let i=0;i<choices.length;i++){
    const choice=choices[i],patterns=nodes[node].patterns;
    if(!Number.isSafeInteger(choice)||choice<0||!patterns||choice>=patterns.length)fail('invalid value builder constructor');
    const pattern=patterns[choice];charges.push([pattern,depth-startDepth]);path.push({pattern,node:nodes[node]});
    if(i+1<choices.length){if(pattern.sequence||pattern.children.length!==1)fail('value builder path is not unary');node=pattern.children[0];depth+=pattern.childDepth;}
   }
   const terminal=path.at(-1).pattern;
   // Compose literal constructor functions once per path, instead of
   // allocating and interpreting another recursive closure for every value.
   const compose=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=args=>args[0];
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=args=>p.make([inner(args)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?compose(last+1):args=>args[0]):compose(last);
     return args=>node.flat(index,payload(args));
    }
    const inner=at+1<path.length?compose(at+1):null;
    if(pattern.transparent)return inner??(args=>args[0]);
    return inner?args=>pattern.make([inner(args)]):pattern.make;
   };
   const make=compose(0);
   // Scalar paths use the same literal constructors, but pass the leaf
   // directly through erased records and flat sums. No temporary argument
   // array is needed at those edges. Ordinary constructors keep their array
   // calling convention; no private value reaches the public builder API.
   const composeScalar=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=value=>value;
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=value=>p.make([inner(value)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?composeScalar(last+1):value=>value):composeScalar(last);
     return value=>node.flat(index,payload(value));
    }
    const inner=at+1<path.length?composeScalar(at+1):null;
    if(pattern.transparent)return inner??(value=>value);
    return inner?value=>pattern.make([inner(value)]):value=>pattern.make([value]);
   };
   const scalar=composeScalar(0);
   const pattern={...terminal,make};
   // Only frozen arrays of ordinary data properties can key reusable plans.
   // Mutable arrays and frozen accessor arrays retain checked per-call paths.
   const fixed=charges.every(([p])=>Number.isSafeInteger(p.bytes)&&p.bytes>=4);
   const plan={pattern,scalar,charges,offset:depth-startDepth,bytes:fixed?charges.reduce((n,[p])=>n+p.bytes,0):null};
   let reusable=Object.isFrozen(choices);
   for(let i=0;reusable&&i<choices.length;i++){const field=Object.getOwnPropertyDescriptor(choices,String(i));reusable=!!field&&Object.hasOwn(field,'value');}
   if(reusable){
    if(!entries){entries=new Map();cache.set(choices,entries);}entries.set(startNode,plan);
   }
   return plan;
 };
 const chargePath=(plan,depth)=>{
  // Each emitted constructor consumes one node and a fixed frame/tag cost.
  // Only take the combined charge when every original check would succeed.
  // Replaying the original order retains the exact first failure otherwise.
  if(plan.bytes!==null&&depth+plan.offset<=budget.depth&&plan.charges.length<=budget.remaining&&budget.bytes+plan.bytes<=budget.limit){
   budget.remaining-=plan.charges.length;budget.bytes+=plan.bytes;return;
  }
  for(const [pattern,offset]of plan.charges)pattern.charge(budget,depth+offset);
 };
 // Operations are allocated once per session, and share expected-node
 // scratch only while the existing reentrancy guard is held.
 const openOperation=(choice)=>{
   expected();const node=nodes[targetNode];
   if(!Number.isSafeInteger(choice)||choice<0||!node.patterns||choice>=node.patterns.length)fail('invalid value builder constructor');
   const pattern=node.patterns[choice];pattern.charge(budget,targetDepth);
   frames.push({pattern,depth:targetDepth,values:[]});
 };
 const openPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth);
   chargePath(plan,targetDepth);
   frames.push({pattern:plan.pattern,depth:targetDepth+plan.offset,values:[]});
 };
 const scalarPathOperation=(choices,value)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==1)fail('value builder path has no scalar leaf');
   const capture=nodes[pattern.children[0]].scalar;
   if(typeof capture!=='function')fail('value builder path has no scalar leaf');
   chargePath(plan,targetDepth);
   const leaf=capture(value,budget,targetDepth+plan.offset+pattern.childDepth);
   accept(plan.scalar(leaf));
 };
 const emptyPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==0)fail('value builder path is not empty');
   chargePath(plan,targetDepth);accept(pattern.make([]));
 };
 const scalarOperation=(value)=>{
   expected();const capture=nodes[targetNode].scalar;
   if(typeof capture!=='function')fail('value builder expects a constructor');
   accept(capture(value,budget,targetDepth));
 };
 const closeOperation=()=>{
   if(!frames.length)fail('value builder has no open constructor');
   const frame=frames.at(-1),pattern=frame.pattern,count=frame.values.length;
   if(!pattern.sequence&&count!==pattern.children.length||pattern.size!==undefined&&count!==pattern.size)fail('value builder constructor arity');
   if(pattern.sequence&&count>budget.limit)fail('wire sequence size');
   const value=pattern.make(frame.values);
   frames.pop();accept(value);
 };
 const finishOperation=()=>{
   if(frames.length||!complete)fail('value builder root is incomplete');
   closed=true;const handle=__compiledHandle(identity,result);result=undefined;return handle;
 };
 const api=Object.freeze({
  open(choice){return execute(openOperation,choice);},
  // Charge every source constructor even when unary paths share one frame.
  openPath(choices){return execute(openPathOperation,choices);},
  // Complete the path and leaf without intermediate session frames.
  scalarPath(choices,value){return execute(scalarPathOperation,choices,value);},
  emptyPath(choices){return execute(emptyPathOperation,choices);},
  scalar(value){return execute(scalarOperation,value);},
  close(){return execute(closeOperation);},
  finish(){return execute(finishOperation);},
  abort(){if(busy)throw Error('value builder operation already active');failed=true;frames.length=0;result=undefined;},
 });
 return api;
}
function __reduceValue0(value,r,b,d,c){b.enter(d,4);return r[0](__reduceValue1(value["a"],r,b,d+1,c),__reduceValue1(value["b"],r,b,d+1,c),__reduceValue1(value["c"],r,b,d+1,c),__reduceValue1(value["d"],r,b,d+1,c),c);}
function __reduceValue1(value,r,b,d,c){b.enter(d,4);return r[1](__reduceValue2(value["identity"],r,b,d+1,c),__reduceValue2(value["scale"],r,b,d+1,c),__reduceValue2(value["bias"],r,b,d+1,c),__reduceValue2(value["relu"],r,b,d+1,c),c);}
function __reduceValue2(value,r,b,d,c){b.enter(d,4);return r[2](__reduceValue3(value["value"],r,b,d+1,c),__reduceValue3(value["tangent_0"],r,b,d+1,c),__reduceValue3(value["tangent_1"],r,b,d+1,c),__reduceValue3(value["tangent_2"],r,b,d+1,c),__reduceValue3(value["tangent_3"],r,b,d+1,c),__reduceValue3(value["tangent_4"],r,b,d+1,c),__reduceValue3(value["tangent_5"],r,b,d+1,c),__reduceValue3(value["tangent_6"],r,b,d+1,c),__reduceValue3(value["tangent_7"],r,b,d+1,c),__reduceValue3(value["tangent_8"],r,b,d+1,c),__reduceValue3(value["tangent_9"],r,b,d+1,c),__reduceValue3(value["tangent_10"],r,b,d+1,c),__reduceValue3(value["tangent_11"],r,b,d+1,c),__reduceValue3(value["tangent_12"],r,b,d+1,c),__reduceValue3(value["tangent_13"],r,b,d+1,c),__reduceValue3(value["tangent_14"],r,b,d+1,c),__reduceValue3(value["tangent_15"],r,b,d+1,c),c);}
function __reduceValue3(value,r,b,d,c){b.enter(d,8);return r[3]({F32Bits:__nfBits(value)},c);}
function __reduceValue4(value,r,b,d,c){b.enter(d,4);return r[4](__reduceValue5(value["slot"],r,b,d+1,c),__reduceValue5(value["operation"],r,b,d+1,c),c);}
function __reduceValue5(value,r,b,d,c){b.enter(d,8);return r[5](value,c);}
function __reduceValue6(value,r,b,d,c){b.enter(d,4);return r[6](__reduceValue7(value["a"],r,b,d+1,c),__reduceValue7(value["b"],r,b,d+1,c),__reduceValue7(value["c"],r,b,d+1,c),__reduceValue7(value["d"],r,b,d+1,c),c);}
function __reduceValue7(value,r,b,d,c){b.enter(d,4);return r[7](__reduceValue3(value["identity"],r,b,d+1,c),__reduceValue3(value["scale"],r,b,d+1,c),__reduceValue3(value["bias"],r,b,d+1,c),__reduceValue3(value["relu"],r,b,d+1,c),c);}
function __reduceValue8(value,r,b,d,c){b.enter(d,4);return r[8](__reduceValue5(value["slot"],r,b,d+1,c),__reduceValue5(value["operation"],r,b,d+1,c),c);}
let __reductionNodeCache;function __reductionNodes(){return __reductionNodeCache??=Object.freeze([Object.freeze({"children":Object.freeze([1,1,1,1]),"fields":Object.freeze(["a","b","c","d"]),"kind":"record","name":"__ink_differential_4"}),Object.freeze({"children":Object.freeze([2,2,2,2]),"fields":Object.freeze(["identity","scale","bias","relu"]),"kind":"record","name":"__ink_differential_5"}),Object.freeze({"children":Object.freeze([3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3]),"fields":Object.freeze(["value","tangent_0","tangent_1","tangent_2","tangent_3","tangent_4","tangent_5","tangent_6","tangent_7","tangent_8","tangent_9","tangent_10","tangent_11","tangent_12","tangent_13","tangent_14","tangent_15"]),"kind":"record","name":"__ink_differential_2"}),Object.freeze({"children":Object.freeze([]),"kind":"f32"}),Object.freeze({"children":Object.freeze([5,5]),"fields":Object.freeze(["slot","operation"]),"kind":"record","name":"__ink_differential_6"}),Object.freeze({"children":Object.freeze([]),"kind":"u32"}),Object.freeze({"children":Object.freeze([7,7,7,7]),"fields":Object.freeze(["a","b","c","d"]),"kind":"record","name":"Parameters"}),Object.freeze({"children":Object.freeze([3,3,3,3]),"fields":Object.freeze(["identity","scale","bias","relu"]),"kind":"record","name":"MassRow"}),Object.freeze({"children":Object.freeze([5,5]),"fields":Object.freeze(["slot","operation"]),"kind":"record","name":"Pick"})]);}
function __compiledNamed0(){return {};}
let __compiledCodec0Value;function __compiledCodec0(){return __compiledCodec0Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"69fa1f86c0802e9ea4a81f07b4a316b84c2eea52b26d6c85b03561911588f8fd","named":__compiledNamed0(),"root":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"scale","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"bias","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"relu","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"}},__privateCapture0,__privateWireValue0,__privateWireWrite0,__compiledOwnedValue0,0,0,__reduceValue0,false,false);}
let __compiledCodec1Value;function __compiledCodec1(){return __compiledCodec1Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"7a219422b28ff5a00294fafcdfd098ec59cb4c4d6641d22bfe7b7cecf550dfab","named":__compiledNamed0(),"root":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_6"}},__privateCapture4,__privateWireValue4,__privateWireWrite4,__compiledOwnedValue4,4,4,__reduceValue4,false,false);}
let __compiledCodec2Value;function __compiledCodec2(){return __compiledCodec2Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"cfdb397c2afc9c623de1f1010b9630cbab4a4f82a83884720c53cd04425275d8","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}},{"name":"tangent_12","type":{"kind":"f32"}},{"name":"tangent_13","type":{"kind":"f32"}},{"name":"tangent_14","type":{"kind":"f32"}},{"name":"tangent_15","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},__privateCapture2,__privateWireValue2,__privateWireWrite2,__compiledOwnedValue2,2,2,__reduceValue2,false,false);}
let __compiledCodec3Value;function __compiledCodec3(){return __compiledCodec3Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"2af269616d48554c4ef5e8a1371afd52412f1ef4f05c2d9506bd43bfde5de326","named":__compiledNamed0(),"root":{"fields":[{"name":"a","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"b","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"c","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}},{"name":"d","type":{"fields":[{"name":"identity","type":{"kind":"f32"}},{"name":"scale","type":{"kind":"f32"}},{"name":"bias","type":{"kind":"f32"}},{"name":"relu","type":{"kind":"f32"}}],"kind":"record","name":"MassRow"}}],"kind":"record","name":"Parameters"}},__privateCapture6,__privateWireValue7,__privateWireWrite6,__compiledOwnedValue6,6,6,__reduceValue6,false,false);}
let __compiledCodec4Value;function __compiledCodec4(){return __compiledCodec4Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"90d27c3bfbfcbfb1eb38f6a728d7bba55f35673fcf68b40398473bd2df865ec5","named":__compiledNamed0(),"root":{"fields":[{"name":"slot","type":{"kind":"u32"}},{"name":"operation","type":{"kind":"u32"}}],"kind":"record","name":"Pick"}},__privateCapture8,__privateWireValue9,__privateWireWrite8,__compiledOwnedValue8,8,8,__reduceValue8,false,false);}
const __compiledEntries=new Map([["__ink_differential_3",{index:0,params:[__compiledCodec0,__compiledCodec1],result:__compiledCodec2,arguments:__privateWireValue6,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_1",{index:1,params:[__compiledCodec3,__compiledCodec4],result:__compiledCodec3,arguments:__privateWireValue10,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}]]);

export const compiledValues=Object.freeze(Object.fromEntries([...__compiledEntries].map(([name,entry])=>[name,Object.freeze({get params(){return Object.freeze(entry.params.map(codec=>codec()));},get result(){return entry.result();}})])));
function __compiledValidate(entry,owned){
 const values=owned.map(v=>v.value);
 const established=entry.onlyTypeGuards&&entry.needsInvariants.every((needed,i)=>!needed||owned[i].guaranteed);
 if(entry.precondition!==null&&!established){
  if(__implementations[entry.precondition](...values)!==true)throw Error('contract precondition failed');
  for(let i=0;i<owned.length;i++)if(entry.needsInvariants[i])owned[i].guaranteed=true;
 }
 return values;
}
export function callCompiled(name,args){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(args)||args.length!==entry.params.length)throw Error('unsupported compiled call');
 const owned=entry.params.map((codec,i)=>__compiledEntry(args[i],codec().identity)),values=__compiledValidate(entry,owned);
 // Checked source outputs satisfy their declared value interfaces. Private
 // handles expose only detached copies and never retain mutable host inputs.
 return __compiledHandle(entry.result().identity,__implementations[entry.index](...values),true);
}

// Explicit sealed-value partial application. Each token owns a bounded set of
// lexical caches; no mutable host object, global memo table or error is retained.
const __preparedCompiled=new WeakMap();
export function prepareCompiled(name,bindings){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(bindings)||bindings.length>entry.params.length)throw Error('unsupported prepared compiled call');
 const captured=new Array(entry.params.length),fixed=new Array(entry.params.length).fill(false);
 for(const binding of bindings){
  if(!Array.isArray(binding)||binding.length!==2)throw Error('prepared compiled binding');
  const [index,handle]=binding;
  if(!Number.isInteger(index)||index<0||index>=fixed.length||fixed[index])throw Error('prepared compiled parameter');
  captured[index]=__compiledEntry(handle,entry.params[index]().identity);fixed[index]=true;
 }
 const remaining=fixed.flatMap((yes,i)=>yes?[]:[i]);
 const factory=__preparedFactories.get(entry.index);
 const run=factory?factory(fixed):__implementations[entry.index];
 const token=Object.freeze(Object.create(null));
 __preparedCompiled.set(token,{entry,captured,remaining,run});return token;
}
export function callPreparedCompiled(token,args){
 const prepared=__preparedCompiled.get(token);
 if(!prepared||!Array.isArray(args)||args.length!==prepared.remaining.length)throw Error('invalid prepared compiled call');
 const {entry,captured,remaining,run}=prepared,owned=captured.slice();
 for(let i=0;i<remaining.length;i++){const at=remaining[i];owned[at]=__compiledEntry(args[i],entry.params[at]().identity);}
 const values=__compiledValidate(entry,owned);
 return __compiledHandle(entry.result().identity,run(...values),true);
}
const __intoImplementations=[null,null];

export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>{
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const body=__intoImplementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args.slice(0,f.params.length))!==true)throw Error('contract precondition failed');return body(...args);};
  const entry=input.every(c=>c===__identity)?implementation:(...values)=>{const context=new WeakMap();return implementation(...input.map((convert,i)=>convert(values[i],context)),values[f.params.length]);};
  return [f.name,entry];
})));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}

function __preparedPart(mask,path){
 for(const field of path){
  if(mask===true)return true;
  if(!mask || typeof mask!=="object")return false;
  mask=Object.hasOwn(mask.fields,field)?mask.fields[field]:false;
 }
 return mask;
}
function __preparedStable(mask,path){const part=__preparedPart(mask,path);return part===true || (!!part && part.all===true);}
function __prepareFn0(fixed,depth=0){if(depth>=16||!((true)))return __fn0;const v753=__preparedStable(fixed[0],["a"])&&__preparedStable(fixed[0],["b"])&&__preparedStable(fixed[0],["c"])&&__preparedStable(fixed[0],["d"])&&__preparedStable(fixed[1],["operation"])&&__preparedStable(fixed[1],["slot"]);
let v752=false,v751;
let v940=false,v939;
return function(v718,v719){const v721=v719["slot"];
const v722=0;
const v723=(v721===v722);
let v724;if(v723){
v724=v718["a"];}else{
const v725=v719["slot"];
const v726=1;
const v727=(v725===v726);
let v728;if(v727){
v728=v718["b"];}else{
const v729=v719["slot"];
const v730=2;
const v731=(v729===v730);
let v732;if(v731){
v732=v718["c"];}else{
v732=v718["d"];}
v728=v732;}
v724=v728;}
const v720=v724;
const v734=v719["operation"];
const v735=0;
const v736=(v734===v735);
let v737;if(v736){
const v738=v720;
v737=v738["identity"];}else{
const v739=v719["operation"];
const v740=1;
const v741=(v739===v740);
let v742;if(v741){
const v743=v720;
v742=v743["scale"];}else{
const v744=v719["operation"];
const v745=2;
const v746=(v744===v745);
let v747;if(v746){
const v748=v720;
v747=v748["bias"];}else{
const v749=v720;
v747=v749["relu"];}
v742=v747;}
v737=v742;}
const v733=v737;
let v750;if(v753&&v752){v750=v751;}else{
const v754=v733;
const v755=v733;
const v757=v754;
const v758=__nfValue(v757["value"]);
const v759=v755;
const v760=__nfValue(v759["value"]);
const v756=Math.fround(__nfNumber(v758) * __nfNumber(v760));
const v761=__nfValue(v756);
const v762=v754;
const v763=__nfValue(v762["tangent_0"]);
const v764=v755;
const v765=__nfValue(v764["value"]);
const v766=Math.fround(__nfNumber(v763) * __nfNumber(v765));
const v767=v754;
const v768=__nfValue(v767["value"]);
const v769=v755;
const v770=__nfValue(v769["tangent_0"]);
const v771=Math.fround(__nfNumber(v768) * __nfNumber(v770));
const v772=Math.fround(v766 + v771);
const v773=v754;
const v774=__nfValue(v773["tangent_1"]);
const v775=v755;
const v776=__nfValue(v775["value"]);
const v777=Math.fround(__nfNumber(v774) * __nfNumber(v776));
const v778=v754;
const v779=__nfValue(v778["value"]);
const v780=v755;
const v781=__nfValue(v780["tangent_1"]);
const v782=Math.fround(__nfNumber(v779) * __nfNumber(v781));
const v783=Math.fround(v777 + v782);
const v784=v754;
const v785=__nfValue(v784["tangent_2"]);
const v786=v755;
const v787=__nfValue(v786["value"]);
const v788=Math.fround(__nfNumber(v785) * __nfNumber(v787));
const v789=v754;
const v790=__nfValue(v789["value"]);
const v791=v755;
const v792=__nfValue(v791["tangent_2"]);
const v793=Math.fround(__nfNumber(v790) * __nfNumber(v792));
const v794=Math.fround(v788 + v793);
const v795=v754;
const v796=__nfValue(v795["tangent_3"]);
const v797=v755;
const v798=__nfValue(v797["value"]);
const v799=Math.fround(__nfNumber(v796) * __nfNumber(v798));
const v800=v754;
const v801=__nfValue(v800["value"]);
const v802=v755;
const v803=__nfValue(v802["tangent_3"]);
const v804=Math.fround(__nfNumber(v801) * __nfNumber(v803));
const v805=Math.fround(v799 + v804);
const v806=v754;
const v807=__nfValue(v806["tangent_4"]);
const v808=v755;
const v809=__nfValue(v808["value"]);
const v810=Math.fround(__nfNumber(v807) * __nfNumber(v809));
const v811=v754;
const v812=__nfValue(v811["value"]);
const v813=v755;
const v814=__nfValue(v813["tangent_4"]);
const v815=Math.fround(__nfNumber(v812) * __nfNumber(v814));
const v816=Math.fround(v810 + v815);
const v817=v754;
const v818=__nfValue(v817["tangent_5"]);
const v819=v755;
const v820=__nfValue(v819["value"]);
const v821=Math.fround(__nfNumber(v818) * __nfNumber(v820));
const v822=v754;
const v823=__nfValue(v822["value"]);
const v824=v755;
const v825=__nfValue(v824["tangent_5"]);
const v826=Math.fround(__nfNumber(v823) * __nfNumber(v825));
const v827=Math.fround(v821 + v826);
const v828=v754;
const v829=__nfValue(v828["tangent_6"]);
const v830=v755;
const v831=__nfValue(v830["value"]);
const v832=Math.fround(__nfNumber(v829) * __nfNumber(v831));
const v833=v754;
const v834=__nfValue(v833["value"]);
const v835=v755;
const v836=__nfValue(v835["tangent_6"]);
const v837=Math.fround(__nfNumber(v834) * __nfNumber(v836));
const v838=Math.fround(v832 + v837);
const v839=v754;
const v840=__nfValue(v839["tangent_7"]);
const v841=v755;
const v842=__nfValue(v841["value"]);
const v843=Math.fround(__nfNumber(v840) * __nfNumber(v842));
const v844=v754;
const v845=__nfValue(v844["value"]);
const v846=v755;
const v847=__nfValue(v846["tangent_7"]);
const v848=Math.fround(__nfNumber(v845) * __nfNumber(v847));
const v849=Math.fround(v843 + v848);
const v850=v754;
const v851=__nfValue(v850["tangent_8"]);
const v852=v755;
const v853=__nfValue(v852["value"]);
const v854=Math.fround(__nfNumber(v851) * __nfNumber(v853));
const v855=v754;
const v856=__nfValue(v855["value"]);
const v857=v755;
const v858=__nfValue(v857["tangent_8"]);
const v859=Math.fround(__nfNumber(v856) * __nfNumber(v858));
const v860=Math.fround(v854 + v859);
const v861=v754;
const v862=__nfValue(v861["tangent_9"]);
const v863=v755;
const v864=__nfValue(v863["value"]);
const v865=Math.fround(__nfNumber(v862) * __nfNumber(v864));
const v866=v754;
const v867=__nfValue(v866["value"]);
const v868=v755;
const v869=__nfValue(v868["tangent_9"]);
const v870=Math.fround(__nfNumber(v867) * __nfNumber(v869));
const v871=Math.fround(v865 + v870);
const v872=v754;
const v873=__nfValue(v872["tangent_10"]);
const v874=v755;
const v875=__nfValue(v874["value"]);
const v876=Math.fround(__nfNumber(v873) * __nfNumber(v875));
const v877=v754;
const v878=__nfValue(v877["value"]);
const v879=v755;
const v880=__nfValue(v879["tangent_10"]);
const v881=Math.fround(__nfNumber(v878) * __nfNumber(v880));
const v882=Math.fround(v876 + v881);
const v883=v754;
const v884=__nfValue(v883["tangent_11"]);
const v885=v755;
const v886=__nfValue(v885["value"]);
const v887=Math.fround(__nfNumber(v884) * __nfNumber(v886));
const v888=v754;
const v889=__nfValue(v888["value"]);
const v890=v755;
const v891=__nfValue(v890["tangent_11"]);
const v892=Math.fround(__nfNumber(v889) * __nfNumber(v891));
const v893=Math.fround(v887 + v892);
const v894=v754;
const v895=__nfValue(v894["tangent_12"]);
const v896=v755;
const v897=__nfValue(v896["value"]);
const v898=Math.fround(__nfNumber(v895) * __nfNumber(v897));
const v899=v754;
const v900=__nfValue(v899["value"]);
const v901=v755;
const v902=__nfValue(v901["tangent_12"]);
const v903=Math.fround(__nfNumber(v900) * __nfNumber(v902));
const v904=Math.fround(v898 + v903);
const v905=v754;
const v906=__nfValue(v905["tangent_13"]);
const v907=v755;
const v908=__nfValue(v907["value"]);
const v909=Math.fround(__nfNumber(v906) * __nfNumber(v908));
const v910=v754;
const v911=__nfValue(v910["value"]);
const v912=v755;
const v913=__nfValue(v912["tangent_13"]);
const v914=Math.fround(__nfNumber(v911) * __nfNumber(v913));
const v915=Math.fround(v909 + v914);
const v916=v754;
const v917=__nfValue(v916["tangent_14"]);
const v918=v755;
const v919=__nfValue(v918["value"]);
const v920=Math.fround(__nfNumber(v917) * __nfNumber(v919));
const v921=v754;
const v922=__nfValue(v921["value"]);
const v923=v755;
const v924=__nfValue(v923["tangent_14"]);
const v925=Math.fround(__nfNumber(v922) * __nfNumber(v924));
const v926=Math.fround(v920 + v925);
const v927=v754;
const v928=__nfValue(v927["tangent_15"]);
const v929=v755;
const v930=__nfValue(v929["value"]);
const v931=Math.fround(__nfNumber(v928) * __nfNumber(v930));
const v932=v754;
const v933=__nfValue(v932["value"]);
const v934=v755;
const v935=__nfValue(v934["tangent_15"]);
const v936=Math.fround(__nfNumber(v933) * __nfNumber(v935));
const v937=Math.fround(v931 + v936);
v750=({["value"]:v761,["tangent_0"]:v772,["tangent_1"]:v783,["tangent_2"]:v794,["tangent_3"]:v805,["tangent_4"]:v816,["tangent_5"]:v827,["tangent_6"]:v838,["tangent_7"]:v849,["tangent_8"]:v860,["tangent_9"]:v871,["tangent_10"]:v882,["tangent_11"]:v893,["tangent_12"]:v904,["tangent_13"]:v915,["tangent_14"]:v926,["tangent_15"]:v937});if(v753){v751=v750;v752=true;}}
let v938;if(true&&v940){v938=v939;}else{
const v941=__nfFromBits(1036831949);
const v942=__nfFromBits(0);
const v943=__nfFromBits(0);
const v944=__nfFromBits(0);
const v945=__nfFromBits(0);
const v946=__nfFromBits(0);
const v947=__nfFromBits(0);
const v948=__nfFromBits(0);
const v949=__nfFromBits(0);
const v950=__nfFromBits(0);
const v951=__nfFromBits(0);
const v952=__nfFromBits(0);
const v953=__nfFromBits(0);
const v954=__nfFromBits(0);
const v955=__nfFromBits(0);
const v956=__nfFromBits(0);
const v957=__nfFromBits(0);
v938=({["value"]:v941,["tangent_0"]:v942,["tangent_1"]:v943,["tangent_2"]:v944,["tangent_3"]:v945,["tangent_4"]:v946,["tangent_5"]:v947,["tangent_6"]:v948,["tangent_7"]:v949,["tangent_8"]:v950,["tangent_9"]:v951,["tangent_10"]:v952,["tangent_11"]:v953,["tangent_12"]:v954,["tangent_13"]:v955,["tangent_14"]:v956,["tangent_15"]:v957});if(true){v939=v938;v940=true;}}
const v959=v750;
const v960=__nfValue(v959["value"]);
const v961=v938;
const v962=__nfValue(v961["value"]);
const v958=Math.fround(__nfNumber(v960) + __nfNumber(v962));
const v963=__nfValue(v958);
const v964=v750;
const v965=__nfValue(v964["tangent_0"]);
const v966=v938;
const v967=__nfValue(v966["tangent_0"]);
const v968=Math.fround(__nfNumber(v965) + __nfNumber(v967));
const v969=v750;
const v970=__nfValue(v969["tangent_1"]);
const v971=v938;
const v972=__nfValue(v971["tangent_1"]);
const v973=Math.fround(__nfNumber(v970) + __nfNumber(v972));
const v974=v750;
const v975=__nfValue(v974["tangent_2"]);
const v976=v938;
const v977=__nfValue(v976["tangent_2"]);
const v978=Math.fround(__nfNumber(v975) + __nfNumber(v977));
const v979=v750;
const v980=__nfValue(v979["tangent_3"]);
const v981=v938;
const v982=__nfValue(v981["tangent_3"]);
const v983=Math.fround(__nfNumber(v980) + __nfNumber(v982));
const v984=v750;
const v985=__nfValue(v984["tangent_4"]);
const v986=v938;
const v987=__nfValue(v986["tangent_4"]);
const v988=Math.fround(__nfNumber(v985) + __nfNumber(v987));
const v989=v750;
const v990=__nfValue(v989["tangent_5"]);
const v991=v938;
const v992=__nfValue(v991["tangent_5"]);
const v993=Math.fround(__nfNumber(v990) + __nfNumber(v992));
const v994=v750;
const v995=__nfValue(v994["tangent_6"]);
const v996=v938;
const v997=__nfValue(v996["tangent_6"]);
const v998=Math.fround(__nfNumber(v995) + __nfNumber(v997));
const v999=v750;
const v1000=__nfValue(v999["tangent_7"]);
const v1001=v938;
const v1002=__nfValue(v1001["tangent_7"]);
const v1003=Math.fround(__nfNumber(v1000) + __nfNumber(v1002));
const v1004=v750;
const v1005=__nfValue(v1004["tangent_8"]);
const v1006=v938;
const v1007=__nfValue(v1006["tangent_8"]);
const v1008=Math.fround(__nfNumber(v1005) + __nfNumber(v1007));
const v1009=v750;
const v1010=__nfValue(v1009["tangent_9"]);
const v1011=v938;
const v1012=__nfValue(v1011["tangent_9"]);
const v1013=Math.fround(__nfNumber(v1010) + __nfNumber(v1012));
const v1014=v750;
const v1015=__nfValue(v1014["tangent_10"]);
const v1016=v938;
const v1017=__nfValue(v1016["tangent_10"]);
const v1018=Math.fround(__nfNumber(v1015) + __nfNumber(v1017));
const v1019=v750;
const v1020=__nfValue(v1019["tangent_11"]);
const v1021=v938;
const v1022=__nfValue(v1021["tangent_11"]);
const v1023=Math.fround(__nfNumber(v1020) + __nfNumber(v1022));
const v1024=v750;
const v1025=__nfValue(v1024["tangent_12"]);
const v1026=v938;
const v1027=__nfValue(v1026["tangent_12"]);
const v1028=Math.fround(__nfNumber(v1025) + __nfNumber(v1027));
const v1029=v750;
const v1030=__nfValue(v1029["tangent_13"]);
const v1031=v938;
const v1032=__nfValue(v1031["tangent_13"]);
const v1033=Math.fround(__nfNumber(v1030) + __nfNumber(v1032));
const v1034=v750;
const v1035=__nfValue(v1034["tangent_14"]);
const v1036=v938;
const v1037=__nfValue(v1036["tangent_14"]);
const v1038=Math.fround(__nfNumber(v1035) + __nfNumber(v1037));
const v1039=v750;
const v1040=__nfValue(v1039["tangent_15"]);
const v1041=v938;
const v1042=__nfValue(v1041["tangent_15"]);
const v1043=Math.fround(__nfNumber(v1040) + __nfNumber(v1042));
return ({["value"]:v963,["tangent_0"]:v968,["tangent_1"]:v973,["tangent_2"]:v978,["tangent_3"]:v983,["tangent_4"]:v988,["tangent_5"]:v993,["tangent_6"]:v998,["tangent_7"]:v1003,["tangent_8"]:v1008,["tangent_9"]:v1013,["tangent_10"]:v1018,["tangent_11"]:v1023,["tangent_12"]:v1028,["tangent_13"]:v1033,["tangent_14"]:v1038,["tangent_15"]:v1043});};}
function __prepareFn1(fixed,depth=0){if(depth>=16||!((true)))return __fn1;const v1049=__preparedStable(fixed[0],["a","bias"])&&__preparedStable(fixed[0],["a","identity"])&&__preparedStable(fixed[0],["a","relu"])&&__preparedStable(fixed[0],["a","scale"])&&__preparedStable(fixed[0],["b","bias"])&&__preparedStable(fixed[0],["b","identity"])&&__preparedStable(fixed[0],["b","relu"])&&__preparedStable(fixed[0],["b","scale"])&&__preparedStable(fixed[0],["c","bias"])&&__preparedStable(fixed[0],["c","identity"])&&__preparedStable(fixed[0],["c","relu"])&&__preparedStable(fixed[0],["c","scale"])&&__preparedStable(fixed[0],["d","bias"])&&__preparedStable(fixed[0],["d","identity"])&&__preparedStable(fixed[0],["d","relu"])&&__preparedStable(fixed[0],["d","scale"])&&__preparedStable(fixed[1],["operation"])&&__preparedStable(fixed[1],["slot"]);
let v1048=false,v1047;
const v1359=__preparedPart(fixed[0],["a","bias"]);
const v1360={all:__preparedStable(fixed[0],["a","bias"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v1359}};
const v1361=__preparedPart(fixed[0],["a","identity"]);
const v1362={all:__preparedStable(fixed[0],["a","identity"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v1361}};
const v1363=__preparedPart(fixed[0],["a","relu"]);
const v1364={all:__preparedStable(fixed[0],["a","relu"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v1363}};
const v1365=__preparedPart(fixed[0],["a","scale"]);
const v1366={all:__preparedStable(fixed[0],["a","scale"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v1365}};
const v1367={all:__preparedStable(fixed[0],["a","bias"])&&__preparedStable(fixed[0],["a","identity"])&&__preparedStable(fixed[0],["a","relu"])&&__preparedStable(fixed[0],["a","scale"]),fields:{["bias"]:v1360,["identity"]:v1362,["relu"]:v1364,["scale"]:v1366}};
const v1368=__preparedPart(fixed[0],["b","bias"]);
const v1369={all:__preparedStable(fixed[0],["b","bias"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v1368}};
const v1370=__preparedPart(fixed[0],["b","identity"]);
const v1371={all:__preparedStable(fixed[0],["b","identity"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v1370}};
const v1372=__preparedPart(fixed[0],["b","relu"]);
const v1373={all:__preparedStable(fixed[0],["b","relu"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v1372}};
const v1374=__preparedPart(fixed[0],["b","scale"]);
const v1375={all:__preparedStable(fixed[0],["b","scale"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v1374}};
const v1376={all:__preparedStable(fixed[0],["b","bias"])&&__preparedStable(fixed[0],["b","identity"])&&__preparedStable(fixed[0],["b","relu"])&&__preparedStable(fixed[0],["b","scale"]),fields:{["bias"]:v1369,["identity"]:v1371,["relu"]:v1373,["scale"]:v1375}};
const v1377=__preparedPart(fixed[0],["c","bias"]);
const v1378={all:__preparedStable(fixed[0],["c","bias"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v1377}};
const v1379=__preparedPart(fixed[0],["c","identity"]);
const v1380={all:__preparedStable(fixed[0],["c","identity"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v1379}};
const v1381=__preparedPart(fixed[0],["c","relu"]);
const v1382={all:__preparedStable(fixed[0],["c","relu"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v1381}};
const v1383=__preparedPart(fixed[0],["c","scale"]);
const v1384={all:__preparedStable(fixed[0],["c","scale"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v1383}};
const v1385={all:__preparedStable(fixed[0],["c","bias"])&&__preparedStable(fixed[0],["c","identity"])&&__preparedStable(fixed[0],["c","relu"])&&__preparedStable(fixed[0],["c","scale"]),fields:{["bias"]:v1378,["identity"]:v1380,["relu"]:v1382,["scale"]:v1384}};
const v1386=__preparedPart(fixed[0],["d","bias"]);
const v1387={all:__preparedStable(fixed[0],["d","bias"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v1386}};
const v1388=__preparedPart(fixed[0],["d","identity"]);
const v1389={all:__preparedStable(fixed[0],["d","identity"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v1388}};
const v1390=__preparedPart(fixed[0],["d","relu"]);
const v1391={all:__preparedStable(fixed[0],["d","relu"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v1390}};
const v1392=__preparedPart(fixed[0],["d","scale"]);
const v1393={all:__preparedStable(fixed[0],["d","scale"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_12"]:true,["tangent_13"]:true,["tangent_14"]:true,["tangent_15"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v1392}};
const v1394={all:__preparedStable(fixed[0],["d","bias"])&&__preparedStable(fixed[0],["d","identity"])&&__preparedStable(fixed[0],["d","relu"])&&__preparedStable(fixed[0],["d","scale"]),fields:{["bias"]:v1387,["identity"]:v1389,["relu"]:v1391,["scale"]:v1393}};
const v1395={all:__preparedStable(fixed[0],["a","bias"])&&__preparedStable(fixed[0],["a","identity"])&&__preparedStable(fixed[0],["a","relu"])&&__preparedStable(fixed[0],["a","scale"])&&__preparedStable(fixed[0],["b","bias"])&&__preparedStable(fixed[0],["b","identity"])&&__preparedStable(fixed[0],["b","relu"])&&__preparedStable(fixed[0],["b","scale"])&&__preparedStable(fixed[0],["c","bias"])&&__preparedStable(fixed[0],["c","identity"])&&__preparedStable(fixed[0],["c","relu"])&&__preparedStable(fixed[0],["c","scale"])&&__preparedStable(fixed[0],["d","bias"])&&__preparedStable(fixed[0],["d","identity"])&&__preparedStable(fixed[0],["d","relu"])&&__preparedStable(fixed[0],["d","scale"]),fields:{["a"]:v1367,["b"]:v1376,["c"]:v1385,["d"]:v1394}};
const v1399=__preparedPart(fixed[1],["operation"]);
const v1400=__preparedPart(fixed[1],["slot"]);
const v1401={all:__preparedStable(fixed[1],["operation"])&&__preparedStable(fixed[1],["slot"]),fields:{["operation"]:v1399,["slot"]:v1400}};
const v1404=depth<15&&__preparedFactories.has(0)&&((true));
let v1402;
return function(v1044,v1045){let v1046;if(v1049&&v1048){v1046=v1047;}else{
const v1050=v1044["a"];
const v1051=__nfValue(v1050["identity"]);
const v1052=__nfFromBits(1065353216);
const v1053=__nfFromBits(0);
const v1054=__nfFromBits(0);
const v1055=__nfFromBits(0);
const v1056=__nfFromBits(0);
const v1057=__nfFromBits(0);
const v1058=__nfFromBits(0);
const v1059=__nfFromBits(0);
const v1060=__nfFromBits(0);
const v1061=__nfFromBits(0);
const v1062=__nfFromBits(0);
const v1063=__nfFromBits(0);
const v1064=__nfFromBits(0);
const v1065=__nfFromBits(0);
const v1066=__nfFromBits(0);
const v1067=__nfFromBits(0);
const v1068=({["value"]:v1051,["tangent_0"]:v1052,["tangent_1"]:v1053,["tangent_2"]:v1054,["tangent_3"]:v1055,["tangent_4"]:v1056,["tangent_5"]:v1057,["tangent_6"]:v1058,["tangent_7"]:v1059,["tangent_8"]:v1060,["tangent_9"]:v1061,["tangent_10"]:v1062,["tangent_11"]:v1063,["tangent_12"]:v1064,["tangent_13"]:v1065,["tangent_14"]:v1066,["tangent_15"]:v1067});
const v1069=v1044["a"];
const v1070=__nfValue(v1069["scale"]);
const v1071=__nfFromBits(0);
const v1072=__nfFromBits(1065353216);
const v1073=__nfFromBits(0);
const v1074=__nfFromBits(0);
const v1075=__nfFromBits(0);
const v1076=__nfFromBits(0);
const v1077=__nfFromBits(0);
const v1078=__nfFromBits(0);
const v1079=__nfFromBits(0);
const v1080=__nfFromBits(0);
const v1081=__nfFromBits(0);
const v1082=__nfFromBits(0);
const v1083=__nfFromBits(0);
const v1084=__nfFromBits(0);
const v1085=__nfFromBits(0);
const v1086=__nfFromBits(0);
const v1087=({["value"]:v1070,["tangent_0"]:v1071,["tangent_1"]:v1072,["tangent_2"]:v1073,["tangent_3"]:v1074,["tangent_4"]:v1075,["tangent_5"]:v1076,["tangent_6"]:v1077,["tangent_7"]:v1078,["tangent_8"]:v1079,["tangent_9"]:v1080,["tangent_10"]:v1081,["tangent_11"]:v1082,["tangent_12"]:v1083,["tangent_13"]:v1084,["tangent_14"]:v1085,["tangent_15"]:v1086});
const v1088=v1044["a"];
const v1089=__nfValue(v1088["bias"]);
const v1090=__nfFromBits(0);
const v1091=__nfFromBits(0);
const v1092=__nfFromBits(1065353216);
const v1093=__nfFromBits(0);
const v1094=__nfFromBits(0);
const v1095=__nfFromBits(0);
const v1096=__nfFromBits(0);
const v1097=__nfFromBits(0);
const v1098=__nfFromBits(0);
const v1099=__nfFromBits(0);
const v1100=__nfFromBits(0);
const v1101=__nfFromBits(0);
const v1102=__nfFromBits(0);
const v1103=__nfFromBits(0);
const v1104=__nfFromBits(0);
const v1105=__nfFromBits(0);
const v1106=({["value"]:v1089,["tangent_0"]:v1090,["tangent_1"]:v1091,["tangent_2"]:v1092,["tangent_3"]:v1093,["tangent_4"]:v1094,["tangent_5"]:v1095,["tangent_6"]:v1096,["tangent_7"]:v1097,["tangent_8"]:v1098,["tangent_9"]:v1099,["tangent_10"]:v1100,["tangent_11"]:v1101,["tangent_12"]:v1102,["tangent_13"]:v1103,["tangent_14"]:v1104,["tangent_15"]:v1105});
const v1107=v1044["a"];
const v1108=__nfValue(v1107["relu"]);
const v1109=__nfFromBits(0);
const v1110=__nfFromBits(0);
const v1111=__nfFromBits(0);
const v1112=__nfFromBits(1065353216);
const v1113=__nfFromBits(0);
const v1114=__nfFromBits(0);
const v1115=__nfFromBits(0);
const v1116=__nfFromBits(0);
const v1117=__nfFromBits(0);
const v1118=__nfFromBits(0);
const v1119=__nfFromBits(0);
const v1120=__nfFromBits(0);
const v1121=__nfFromBits(0);
const v1122=__nfFromBits(0);
const v1123=__nfFromBits(0);
const v1124=__nfFromBits(0);
const v1125=({["value"]:v1108,["tangent_0"]:v1109,["tangent_1"]:v1110,["tangent_2"]:v1111,["tangent_3"]:v1112,["tangent_4"]:v1113,["tangent_5"]:v1114,["tangent_6"]:v1115,["tangent_7"]:v1116,["tangent_8"]:v1117,["tangent_9"]:v1118,["tangent_10"]:v1119,["tangent_11"]:v1120,["tangent_12"]:v1121,["tangent_13"]:v1122,["tangent_14"]:v1123,["tangent_15"]:v1124});
const v1126=({["identity"]:v1068,["scale"]:v1087,["bias"]:v1106,["relu"]:v1125});
const v1127=v1044["b"];
const v1128=__nfValue(v1127["identity"]);
const v1129=__nfFromBits(0);
const v1130=__nfFromBits(0);
const v1131=__nfFromBits(0);
const v1132=__nfFromBits(0);
const v1133=__nfFromBits(1065353216);
const v1134=__nfFromBits(0);
const v1135=__nfFromBits(0);
const v1136=__nfFromBits(0);
const v1137=__nfFromBits(0);
const v1138=__nfFromBits(0);
const v1139=__nfFromBits(0);
const v1140=__nfFromBits(0);
const v1141=__nfFromBits(0);
const v1142=__nfFromBits(0);
const v1143=__nfFromBits(0);
const v1144=__nfFromBits(0);
const v1145=({["value"]:v1128,["tangent_0"]:v1129,["tangent_1"]:v1130,["tangent_2"]:v1131,["tangent_3"]:v1132,["tangent_4"]:v1133,["tangent_5"]:v1134,["tangent_6"]:v1135,["tangent_7"]:v1136,["tangent_8"]:v1137,["tangent_9"]:v1138,["tangent_10"]:v1139,["tangent_11"]:v1140,["tangent_12"]:v1141,["tangent_13"]:v1142,["tangent_14"]:v1143,["tangent_15"]:v1144});
const v1146=v1044["b"];
const v1147=__nfValue(v1146["scale"]);
const v1148=__nfFromBits(0);
const v1149=__nfFromBits(0);
const v1150=__nfFromBits(0);
const v1151=__nfFromBits(0);
const v1152=__nfFromBits(0);
const v1153=__nfFromBits(1065353216);
const v1154=__nfFromBits(0);
const v1155=__nfFromBits(0);
const v1156=__nfFromBits(0);
const v1157=__nfFromBits(0);
const v1158=__nfFromBits(0);
const v1159=__nfFromBits(0);
const v1160=__nfFromBits(0);
const v1161=__nfFromBits(0);
const v1162=__nfFromBits(0);
const v1163=__nfFromBits(0);
const v1164=({["value"]:v1147,["tangent_0"]:v1148,["tangent_1"]:v1149,["tangent_2"]:v1150,["tangent_3"]:v1151,["tangent_4"]:v1152,["tangent_5"]:v1153,["tangent_6"]:v1154,["tangent_7"]:v1155,["tangent_8"]:v1156,["tangent_9"]:v1157,["tangent_10"]:v1158,["tangent_11"]:v1159,["tangent_12"]:v1160,["tangent_13"]:v1161,["tangent_14"]:v1162,["tangent_15"]:v1163});
const v1165=v1044["b"];
const v1166=__nfValue(v1165["bias"]);
const v1167=__nfFromBits(0);
const v1168=__nfFromBits(0);
const v1169=__nfFromBits(0);
const v1170=__nfFromBits(0);
const v1171=__nfFromBits(0);
const v1172=__nfFromBits(0);
const v1173=__nfFromBits(1065353216);
const v1174=__nfFromBits(0);
const v1175=__nfFromBits(0);
const v1176=__nfFromBits(0);
const v1177=__nfFromBits(0);
const v1178=__nfFromBits(0);
const v1179=__nfFromBits(0);
const v1180=__nfFromBits(0);
const v1181=__nfFromBits(0);
const v1182=__nfFromBits(0);
const v1183=({["value"]:v1166,["tangent_0"]:v1167,["tangent_1"]:v1168,["tangent_2"]:v1169,["tangent_3"]:v1170,["tangent_4"]:v1171,["tangent_5"]:v1172,["tangent_6"]:v1173,["tangent_7"]:v1174,["tangent_8"]:v1175,["tangent_9"]:v1176,["tangent_10"]:v1177,["tangent_11"]:v1178,["tangent_12"]:v1179,["tangent_13"]:v1180,["tangent_14"]:v1181,["tangent_15"]:v1182});
const v1184=v1044["b"];
const v1185=__nfValue(v1184["relu"]);
const v1186=__nfFromBits(0);
const v1187=__nfFromBits(0);
const v1188=__nfFromBits(0);
const v1189=__nfFromBits(0);
const v1190=__nfFromBits(0);
const v1191=__nfFromBits(0);
const v1192=__nfFromBits(0);
const v1193=__nfFromBits(1065353216);
const v1194=__nfFromBits(0);
const v1195=__nfFromBits(0);
const v1196=__nfFromBits(0);
const v1197=__nfFromBits(0);
const v1198=__nfFromBits(0);
const v1199=__nfFromBits(0);
const v1200=__nfFromBits(0);
const v1201=__nfFromBits(0);
const v1202=({["value"]:v1185,["tangent_0"]:v1186,["tangent_1"]:v1187,["tangent_2"]:v1188,["tangent_3"]:v1189,["tangent_4"]:v1190,["tangent_5"]:v1191,["tangent_6"]:v1192,["tangent_7"]:v1193,["tangent_8"]:v1194,["tangent_9"]:v1195,["tangent_10"]:v1196,["tangent_11"]:v1197,["tangent_12"]:v1198,["tangent_13"]:v1199,["tangent_14"]:v1200,["tangent_15"]:v1201});
const v1203=({["identity"]:v1145,["scale"]:v1164,["bias"]:v1183,["relu"]:v1202});
const v1204=v1044["c"];
const v1205=__nfValue(v1204["identity"]);
const v1206=__nfFromBits(0);
const v1207=__nfFromBits(0);
const v1208=__nfFromBits(0);
const v1209=__nfFromBits(0);
const v1210=__nfFromBits(0);
const v1211=__nfFromBits(0);
const v1212=__nfFromBits(0);
const v1213=__nfFromBits(0);
const v1214=__nfFromBits(1065353216);
const v1215=__nfFromBits(0);
const v1216=__nfFromBits(0);
const v1217=__nfFromBits(0);
const v1218=__nfFromBits(0);
const v1219=__nfFromBits(0);
const v1220=__nfFromBits(0);
const v1221=__nfFromBits(0);
const v1222=({["value"]:v1205,["tangent_0"]:v1206,["tangent_1"]:v1207,["tangent_2"]:v1208,["tangent_3"]:v1209,["tangent_4"]:v1210,["tangent_5"]:v1211,["tangent_6"]:v1212,["tangent_7"]:v1213,["tangent_8"]:v1214,["tangent_9"]:v1215,["tangent_10"]:v1216,["tangent_11"]:v1217,["tangent_12"]:v1218,["tangent_13"]:v1219,["tangent_14"]:v1220,["tangent_15"]:v1221});
const v1223=v1044["c"];
const v1224=__nfValue(v1223["scale"]);
const v1225=__nfFromBits(0);
const v1226=__nfFromBits(0);
const v1227=__nfFromBits(0);
const v1228=__nfFromBits(0);
const v1229=__nfFromBits(0);
const v1230=__nfFromBits(0);
const v1231=__nfFromBits(0);
const v1232=__nfFromBits(0);
const v1233=__nfFromBits(0);
const v1234=__nfFromBits(1065353216);
const v1235=__nfFromBits(0);
const v1236=__nfFromBits(0);
const v1237=__nfFromBits(0);
const v1238=__nfFromBits(0);
const v1239=__nfFromBits(0);
const v1240=__nfFromBits(0);
const v1241=({["value"]:v1224,["tangent_0"]:v1225,["tangent_1"]:v1226,["tangent_2"]:v1227,["tangent_3"]:v1228,["tangent_4"]:v1229,["tangent_5"]:v1230,["tangent_6"]:v1231,["tangent_7"]:v1232,["tangent_8"]:v1233,["tangent_9"]:v1234,["tangent_10"]:v1235,["tangent_11"]:v1236,["tangent_12"]:v1237,["tangent_13"]:v1238,["tangent_14"]:v1239,["tangent_15"]:v1240});
const v1242=v1044["c"];
const v1243=__nfValue(v1242["bias"]);
const v1244=__nfFromBits(0);
const v1245=__nfFromBits(0);
const v1246=__nfFromBits(0);
const v1247=__nfFromBits(0);
const v1248=__nfFromBits(0);
const v1249=__nfFromBits(0);
const v1250=__nfFromBits(0);
const v1251=__nfFromBits(0);
const v1252=__nfFromBits(0);
const v1253=__nfFromBits(0);
const v1254=__nfFromBits(1065353216);
const v1255=__nfFromBits(0);
const v1256=__nfFromBits(0);
const v1257=__nfFromBits(0);
const v1258=__nfFromBits(0);
const v1259=__nfFromBits(0);
const v1260=({["value"]:v1243,["tangent_0"]:v1244,["tangent_1"]:v1245,["tangent_2"]:v1246,["tangent_3"]:v1247,["tangent_4"]:v1248,["tangent_5"]:v1249,["tangent_6"]:v1250,["tangent_7"]:v1251,["tangent_8"]:v1252,["tangent_9"]:v1253,["tangent_10"]:v1254,["tangent_11"]:v1255,["tangent_12"]:v1256,["tangent_13"]:v1257,["tangent_14"]:v1258,["tangent_15"]:v1259});
const v1261=v1044["c"];
const v1262=__nfValue(v1261["relu"]);
const v1263=__nfFromBits(0);
const v1264=__nfFromBits(0);
const v1265=__nfFromBits(0);
const v1266=__nfFromBits(0);
const v1267=__nfFromBits(0);
const v1268=__nfFromBits(0);
const v1269=__nfFromBits(0);
const v1270=__nfFromBits(0);
const v1271=__nfFromBits(0);
const v1272=__nfFromBits(0);
const v1273=__nfFromBits(0);
const v1274=__nfFromBits(1065353216);
const v1275=__nfFromBits(0);
const v1276=__nfFromBits(0);
const v1277=__nfFromBits(0);
const v1278=__nfFromBits(0);
const v1279=({["value"]:v1262,["tangent_0"]:v1263,["tangent_1"]:v1264,["tangent_2"]:v1265,["tangent_3"]:v1266,["tangent_4"]:v1267,["tangent_5"]:v1268,["tangent_6"]:v1269,["tangent_7"]:v1270,["tangent_8"]:v1271,["tangent_9"]:v1272,["tangent_10"]:v1273,["tangent_11"]:v1274,["tangent_12"]:v1275,["tangent_13"]:v1276,["tangent_14"]:v1277,["tangent_15"]:v1278});
const v1280=({["identity"]:v1222,["scale"]:v1241,["bias"]:v1260,["relu"]:v1279});
const v1281=v1044["d"];
const v1282=__nfValue(v1281["identity"]);
const v1283=__nfFromBits(0);
const v1284=__nfFromBits(0);
const v1285=__nfFromBits(0);
const v1286=__nfFromBits(0);
const v1287=__nfFromBits(0);
const v1288=__nfFromBits(0);
const v1289=__nfFromBits(0);
const v1290=__nfFromBits(0);
const v1291=__nfFromBits(0);
const v1292=__nfFromBits(0);
const v1293=__nfFromBits(0);
const v1294=__nfFromBits(0);
const v1295=__nfFromBits(1065353216);
const v1296=__nfFromBits(0);
const v1297=__nfFromBits(0);
const v1298=__nfFromBits(0);
const v1299=({["value"]:v1282,["tangent_0"]:v1283,["tangent_1"]:v1284,["tangent_2"]:v1285,["tangent_3"]:v1286,["tangent_4"]:v1287,["tangent_5"]:v1288,["tangent_6"]:v1289,["tangent_7"]:v1290,["tangent_8"]:v1291,["tangent_9"]:v1292,["tangent_10"]:v1293,["tangent_11"]:v1294,["tangent_12"]:v1295,["tangent_13"]:v1296,["tangent_14"]:v1297,["tangent_15"]:v1298});
const v1300=v1044["d"];
const v1301=__nfValue(v1300["scale"]);
const v1302=__nfFromBits(0);
const v1303=__nfFromBits(0);
const v1304=__nfFromBits(0);
const v1305=__nfFromBits(0);
const v1306=__nfFromBits(0);
const v1307=__nfFromBits(0);
const v1308=__nfFromBits(0);
const v1309=__nfFromBits(0);
const v1310=__nfFromBits(0);
const v1311=__nfFromBits(0);
const v1312=__nfFromBits(0);
const v1313=__nfFromBits(0);
const v1314=__nfFromBits(0);
const v1315=__nfFromBits(1065353216);
const v1316=__nfFromBits(0);
const v1317=__nfFromBits(0);
const v1318=({["value"]:v1301,["tangent_0"]:v1302,["tangent_1"]:v1303,["tangent_2"]:v1304,["tangent_3"]:v1305,["tangent_4"]:v1306,["tangent_5"]:v1307,["tangent_6"]:v1308,["tangent_7"]:v1309,["tangent_8"]:v1310,["tangent_9"]:v1311,["tangent_10"]:v1312,["tangent_11"]:v1313,["tangent_12"]:v1314,["tangent_13"]:v1315,["tangent_14"]:v1316,["tangent_15"]:v1317});
const v1319=v1044["d"];
const v1320=__nfValue(v1319["bias"]);
const v1321=__nfFromBits(0);
const v1322=__nfFromBits(0);
const v1323=__nfFromBits(0);
const v1324=__nfFromBits(0);
const v1325=__nfFromBits(0);
const v1326=__nfFromBits(0);
const v1327=__nfFromBits(0);
const v1328=__nfFromBits(0);
const v1329=__nfFromBits(0);
const v1330=__nfFromBits(0);
const v1331=__nfFromBits(0);
const v1332=__nfFromBits(0);
const v1333=__nfFromBits(0);
const v1334=__nfFromBits(0);
const v1335=__nfFromBits(1065353216);
const v1336=__nfFromBits(0);
const v1337=({["value"]:v1320,["tangent_0"]:v1321,["tangent_1"]:v1322,["tangent_2"]:v1323,["tangent_3"]:v1324,["tangent_4"]:v1325,["tangent_5"]:v1326,["tangent_6"]:v1327,["tangent_7"]:v1328,["tangent_8"]:v1329,["tangent_9"]:v1330,["tangent_10"]:v1331,["tangent_11"]:v1332,["tangent_12"]:v1333,["tangent_13"]:v1334,["tangent_14"]:v1335,["tangent_15"]:v1336});
const v1338=v1044["d"];
const v1339=__nfValue(v1338["relu"]);
const v1340=__nfFromBits(0);
const v1341=__nfFromBits(0);
const v1342=__nfFromBits(0);
const v1343=__nfFromBits(0);
const v1344=__nfFromBits(0);
const v1345=__nfFromBits(0);
const v1346=__nfFromBits(0);
const v1347=__nfFromBits(0);
const v1348=__nfFromBits(0);
const v1349=__nfFromBits(0);
const v1350=__nfFromBits(0);
const v1351=__nfFromBits(0);
const v1352=__nfFromBits(0);
const v1353=__nfFromBits(0);
const v1354=__nfFromBits(0);
const v1355=__nfFromBits(1065353216);
const v1356=({["value"]:v1339,["tangent_0"]:v1340,["tangent_1"]:v1341,["tangent_2"]:v1342,["tangent_3"]:v1343,["tangent_4"]:v1344,["tangent_5"]:v1345,["tangent_6"]:v1346,["tangent_7"]:v1347,["tangent_8"]:v1348,["tangent_9"]:v1349,["tangent_10"]:v1350,["tangent_11"]:v1351,["tangent_12"]:v1352,["tangent_13"]:v1353,["tangent_14"]:v1354,["tangent_15"]:v1355});
const v1357=({["identity"]:v1299,["scale"]:v1318,["bias"]:v1337,["relu"]:v1356});
const v1358=({["a"]:v1126,["b"]:v1203,["c"]:v1280,["d"]:v1357});
const v1396=v1045["slot"];
const v1397=v1045["operation"];
const v1398=({["slot"]:v1396,["operation"]:v1397});
let v1405;if(v1404){if(!v1402){const v1403=__preparedFactories.get(0);v1402=v1403([v1395,v1401],depth+1);}v1405=v1402(v1358,v1398);}else{v1405=__fn0(v1358,v1398);}
v1046=v1405;if(v1049){v1047=v1046;v1048=true;}}
const v1406=v1046;
const v1407=__nfValue(v1406["tangent_0"]);
const v1408=v1046;
const v1409=__nfValue(v1408["tangent_1"]);
const v1410=v1046;
const v1411=__nfValue(v1410["tangent_2"]);
const v1412=v1046;
const v1413=__nfValue(v1412["tangent_3"]);
const v1414=({["identity"]:v1407,["scale"]:v1409,["bias"]:v1411,["relu"]:v1413});
const v1415=v1046;
const v1416=__nfValue(v1415["tangent_4"]);
const v1417=v1046;
const v1418=__nfValue(v1417["tangent_5"]);
const v1419=v1046;
const v1420=__nfValue(v1419["tangent_6"]);
const v1421=v1046;
const v1422=__nfValue(v1421["tangent_7"]);
const v1423=({["identity"]:v1416,["scale"]:v1418,["bias"]:v1420,["relu"]:v1422});
const v1424=v1046;
const v1425=__nfValue(v1424["tangent_8"]);
const v1426=v1046;
const v1427=__nfValue(v1426["tangent_9"]);
const v1428=v1046;
const v1429=__nfValue(v1428["tangent_10"]);
const v1430=v1046;
const v1431=__nfValue(v1430["tangent_11"]);
const v1432=({["identity"]:v1425,["scale"]:v1427,["bias"]:v1429,["relu"]:v1431});
const v1433=v1046;
const v1434=__nfValue(v1433["tangent_12"]);
const v1435=v1046;
const v1436=__nfValue(v1435["tangent_13"]);
const v1437=v1046;
const v1438=__nfValue(v1437["tangent_14"]);
const v1439=v1046;
const v1440=__nfValue(v1439["tangent_15"]);
const v1441=({["identity"]:v1434,["scale"]:v1436,["bias"]:v1438,["relu"]:v1440});
return ({["a"]:v1414,["b"]:v1423,["c"]:v1432,["d"]:v1441});};}
const __preparedFactories=new Map([[0,__prepareFn0],[1,__prepareFn1]]);
