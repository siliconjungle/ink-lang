import hashlib,json,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parents[2];p=r/'build/conversion-guard/source';rows={}
def git(repo,*args):return subprocess.check_output(['git','-C',str(repo),*args])
def check(repo,revision,folder,paths):
 n=0
 for entry in git(repo,'ls-tree','-r','-z',revision,*paths).split(b'\0'):
  if not entry:continue
  meta,name=entry.split(b'\t',1);mode,kind,expected=meta.decode().split();name=name.decode()
  if kind!='blob':continue
  data=(folder/name).read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  assert actual==expected,(folder,name,actual,expected)
  rows[str((folder/name).relative_to(p))]=hashlib.sha256(data).hexdigest();n+=1
 return n
source=git(r,'rev-parse','77398ac8f93b944b1aa6b5ce7becd877629a336f').decode().strip()
counts={'root':check(r,source,p,['Cargo.toml','src','core','stdlib'])};pins={}
for name in ['abi','native-support','lowerings/rust','lowerings/js','lowerings/wasm','lowerings/gpu','runtime']:
 pin=git(r,'ls-tree',source,name).decode().split()[2];pins[name]=pin;counts[name]=check(r/name,pin,p/name,['Cargo.toml','Cargo.lock','src','devices','shaders','hosts','include','assets'])
rec=dict(schema=1,status='matched',distribution=source,packages=pins,files=rows,counts=counts,compiler_sha256=hashlib.sha256(Path(sys.argv[1] if len(sys.argv)>1 else r/'build/composed-graph/compiler/ink').read_bytes()).hexdigest(),lock_sha256=hashlib.sha256((p/'Cargo.lock').read_bytes()).hexdigest(),scope='Every compiled root/core/stdlib source and every pinned Ink dependency source, embedded device/shader/host assets, manifest and committed lock matches the published Git blobs. Private test overlay is outside the CLI build. Normal Cargo builds the compiler; finite source correspondence, not compiler correctness.')
(r/(sys.argv[2] if len(sys.argv)>2 else 'build/composed-graph/compiler-sources.json')).write_text(json.dumps(rec,indent=2)+'\n');print(counts,rec['compiler_sha256'])
