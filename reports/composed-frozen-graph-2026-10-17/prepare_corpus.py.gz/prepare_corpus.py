"""Copy the exact active publication; omit only the disposable SQLite index."""
import json,os,shutil,sys
from pathlib import Path
r=Path(__file__).resolve().parents[2];sys.path[:0]=[str(r/'planner'),str(r/'knowledge')]
from ink_planner.corpus import private_file_copy
from ink_knowledge import Store,identity
from ink_knowledge.publication import commit
from ink_knowledge.store import _publication_lock
source=r/'knowledge';destination=r/'build/composed-graph/knowledge-fixed'
assert not destination.exists()
omit={'.git','build','compiled-cache','__pycache__','store','index.sqlite','index.sqlite-wal','index.sqlite-shm'}
shutil.copytree(source,destination,copy_function=private_file_copy,symlinks=True,ignore=lambda path,names:set(names)&(omit if Path(path)==source else {'__pycache__'}))
publication=Store(source);members=publication.members();trees={publication.snapshot['root']};seen=set()
for w in members.values():
 key=(tuple(w['entries']),tuple((e['sibling'],e['left'])for e in w['path']))
 if key in seen:continue
 seen.add(key);node=identity(dict(schema=1,entries=w['entries']));trees.add(node)
 for edge in w['path']:
  sibling=edge['sibling'];trees.add(sibling);node=identity(dict(schema=1,left=sibling if edge['left']else node,right=node if edge['left']else sibling));trees.add(node)
data=destination/'store';metadata={'names.json','snapshot.json','publication.json','names','objects','trees','snapshots'}
shutil.copytree(publication.data,data,copy_function=private_file_copy,symlinks=True,ignore=lambda path,names:{n for n in names if n.startswith(('.publication.sqlite','.ink-pointer-','.ink-object-'))}|(set(names)&metadata if Path(path)==publication.data else set()))
for directory,ids in [('objects',members),('trees',trees),('snapshots',[publication.snapshot_id])]:
 (data/directory).mkdir()
 for ident in ids:os.link(publication.data/directory/(ident+'.json'),data/directory/(ident+'.json'))
with _publication_lock(destination):commit(data,publication.snapshot,publication.names)
fixed=Store(destination);assert fixed.publication_id==publication.publication_id;assert Store(source).publication_id==publication.publication_id
assert not(destination/'index.sqlite').exists()
record=dict(schema=1,snapshot=fixed.snapshot_id,publication=fixed.publication_id,members=len(members),scope='Exact active canonical publication and complete source/fixture inputs. Immutable files shared; private metadata and lock. Disposable index omitted and normal planner rebuilds it; no cached verdict grants authority.')
(r/'build/composed-graph/corpus-isolation.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
