import hashlib,json,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parents[2];d=r/'build/composed-graph';ink=r/'build/conversion-guard/target/debug/ink';out=d/'publication-replay';out.mkdir(exist_ok=True);images={};log=d/'publication-replay.log'
log.write_bytes(b'')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(command):
 with log.open('ab')as f:subprocess.run(list(map(str,command)),stdout=f,stderr=subprocess.STDOUT,check=True)
for target in ['javascript','rust']:
 for name,packet in [('baseline',d/'identity-plan.json'),('projected',r/'build/owned-graph-probe/projection-plan.json'),('selected',d/'plan.json')]:
  path=out/(name+('.mjs'if target=='javascript'else'.rs'));expected=d/(name+'.mjs')if target=='javascript'else d/'native/src'/(name+'.rs')
  run([ink,'compile',d/'source.core.json','--core','--plan',packet,'--target',target,'-o',path]);assert path.read_bytes()==expected.read_bytes(),(target,name)
  images[target+'/'+name]=dict(actual=sha(path),expected=sha(expected),equal=True)
regenerated=out/'plan.json';run([sys.executable,r/'reports/composed-frozen-graph-2026-10-17/compose.py',d/'source.core.json','--compiler',ink,'-o',regenerated]);assert json.loads(regenerated.read_bytes())==json.loads((d/'plan.json').read_bytes())
record=dict(schema=1,status='passed',compiler_sha256=sha(ink),compiler_source_receipt='publication-compiler-sources.json',images=images,authoring=dict(equal_json=True,sha256=sha(regenerated)),log_sha256=sha(log),scope='Normal dev-profile Cargo build from checked published source blobs reproduces every measured JavaScript/Rust image and the entire four-step authored plan. Finite reproducibility, not whole-compiler verification.')
(d/'publication-replay.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
