"""Retain checked-source helper expansion and all measured/adverse cohorts."""
from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
root=Path(__file__).resolve().parents[3];base=Path(__file__).parent;report=root/'reports/direct-owned-helpers-2026-10-17';report.mkdir(exist_ok=False)
summary={'schema':1,'status':'validated-literal-emission','distribution':'802dac62e9bc58698d5a6363e42ac6e62c4125d8','javascript':'dc5e2908efb0b509b1a4949ae87115fbe69fc6ff','baseline_javascript':'a6c14fb6f232370fac8cafc973b4803083e1e0a8','artifacts':{},'source_archives':{},'cohorts':{}}
def sha(data):return hashlib.sha256(data).hexdigest()
def save(path,data):
 p=report/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
def retain(name,path):
 data=path.read_bytes();encoding='gzip'if len(data)>4096 else'identity';stored='data/'+name+('.gz'if encoding=='gzip'else'');encoded=gzip.compress(data,mtime=0)if encoding=='gzip'else data;save(stored,encoded)
 summary['artifacts'][name]={'stored':stored,'encoding':encoding,'bytes':len(data),'sha256':sha(data),'stored_sha256':sha(encoded)}
def archive(name,files):
 stream=io.BytesIO()
 with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0)as gz:
  with tarfile.open(fileobj=gz,mode='w')as tar:
   for n,data in sorted(files.items()):
    info=tarfile.TarInfo(n);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
 data=stream.getvalue();save(name,data);summary['source_archives'][name]={'bytes':len(data),'sha256':sha(data),'files':{n:sha(data)for n,data in sorted(files.items())}}
def git_source(repo,revision):
 files={}
 for entry in subprocess.check_output(['git','ls-tree','-r','-z',revision],cwd=repo).split(b'\0'):
  if not entry:continue
  meta,name=entry.split(b'\t');mode,kind,oid=meta.decode().split();assert kind=='blob';files[name.decode()]=subprocess.check_output(['git','cat-file','blob',oid],cwd=repo)
 return files
for label,revision in [('baseline',summary['baseline_javascript']),('final',summary['javascript'])]:archive(f'sources/{label}-javascript.tar.gz',git_source(root/'lowerings/js',revision))
files={str(p.relative_to(base/'package')):p.read_bytes()for p in(base/'package').rglob('*')if p.is_file()};archive('sources/private-prototype.tar.gz',files)
for path in ['initial-sources.json','sources.json','receipts.json','build.log','controls.log','owned-parameters-receipt.json','owned-parameters.log','full-validation-receipt.json','full-fetch.log','full-tests.log','full-examples.log','move-fixture-failure-owned-parameters-receipt.json','move-fixture-failure-owned-parameters.log','move-fixture-failure-sources.json','root-fixture-fix.json','js-publication.json','dependent-publication.json','gpu-dependency-receipt.json','runtime-dependency-receipt.json','root-dependency-receipt.json','feature-audit.json','final-emission.json','distribution-image-reproduction.json','retained-controls-receipt.json']:
 retain('validation/diagnostics/'+path,base/path)
for path in ['receipt.json','fetch.log','tests.log','examples.log']:retain('validation/package/'+path,base/'final-validation'/path)
for path in ['receipt.json','sources.json','compile.log','owned-parameters.log','owned-records.log','numerical-state.log','function-specialization.log']:retain('validation/integration/'+path,base/'integration-2'/path)
for path in ['receipt.json','sources.json','compile.log','owned-parameters.log']:retain('validation/failed-integration/'+path,base/'integration'/path)
retain('validation/failed-integration/test.rs',base/'integration/source/tests/owned_parameter_helpers.rs')
for p in(base/'gpu-validation').iterdir():
 if p.is_file():retain('validation/gpu/'+p.name,p)
for mode in ['native','bits']:
 for p in(base/'retained-controls'/mode).iterdir():
  if p.is_file():retain('controls/'+mode+'/'+p.name,p)
data=root/'build/owned-carriers/neural-final'
for p in ['source.core.json','model.snapshot','contexts.json','reference-history.json','measure.mjs']:retain('neural/'+p,data/p)
retain('neural/baseline.mjs',data/'new.mjs');retain('neural/new.mjs',base/'neural-final.mjs')
for cohort in ['cohort-1','cohort-2']:
 for p in(base/cohort).iterdir():
  if p.is_file():retain('neural/'+cohort+'/'+p.name,p)
 retain('neural/'+cohort+'/acquisition.log',base/(cohort+'.log'));summary['cohorts']['neural/'+cohort]={'pairs':6}
for p in(base/'other-images').iterdir():
 if p.is_file():retain('other-images/'+p.name,p)
for name,source in [('graph',root/'build/owned-carriers/graph-final/source.core.json'),('complex-text',root/'build/complex-text-draft/source.core.json')]:retain('other-images/'+name+'.core.json',source)
parity=base/'integration-2/source/build/owned-parameter-helper-parity'
for name in ['source.ink','script.json','expected.json','program.mjs','check.mjs','check-wasm.mjs','state-wasm.mjs']:retain('parity/'+name,parity/name)
retain('parity/compiled_state.wasm',parity/'rust/target/wasm32-unknown-unknown/debug/compiled_state.wasm')
for name in ['src/lib.rs','src/main.rs','Cargo.toml','Cargo.lock']:retain('parity/native/'+name,parity/'rust'/name)
for name in ['integrate.py','integrate-2.py','validate_gpu.py','gather.py']:retain('acquisition/'+name,base/name)
retain('acquisition/measure.py',root/'build/number-buffer-probe/measure.py')
(report/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(report)
