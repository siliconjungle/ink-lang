function __fn0(v0,v1){
const v2=v0;
const v3=v2.length;
const v4=[];
for(let v5=0;v5<v3;v5++){
const v6=v2[v5];
const v7=v6;
if(v7["visible"]){v4.push(v6);}
}
const v8=v4;
const v9=v8.length;
const v10=new Array(v9);
for(let v11=0;v11<v9;v11++){
const v12=v8[v11];
const v13=v12;
const v14=v13["selected"];
let v15=v14;if(v15){
const v16=v12;
const v17=v16["id"];
const v18=v1;
v15=(v17===v18);}
v10[v11]=v15;
}
const v19=v10;
let v20=false;
for(let v21=0;v21<v19.length;v21++){
const v22=v19[v21];
const v23=v20;
let v24=v23;if(!v24){
v24=v22;}
v20=v24;
}
return v20;}
const __namedTypes={"Layer":{"fields":[{"name":"visible","type":{"kind":"bool"}},{"name":"selected","type":{"kind":"bool"}},{"name":"id","type":{"kind":"i32"}}],"kind":"record","name":"Layer"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"86c1d141ba4f9caf71ea8da2509e8ba278686407d2a7689c2a2cdae63405402d","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":null,"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"fields":[{"name":"visible","type":{"kind":"bool"}},{"name":"selected","type":{"kind":"bool"}},{"name":"id","type":{"kind":"i32"}}],"kind":"record","name":"Layer"},"kind":"list"}},{"name":"key","type":{"kind":"i32"}}],"precondition":null,"result":{"kind":"bool"}}],"named_types":{"Layer":{"fields":[{"name":"visible","type":{"kind":"bool"}},{"name":"selected","type":{"kind":"bool"}},{"name":"id","type":{"kind":"i32"}}],"kind":"record","name":"Layer"}},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[null];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
