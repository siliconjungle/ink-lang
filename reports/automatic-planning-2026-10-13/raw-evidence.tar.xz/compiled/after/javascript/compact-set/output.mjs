function __fn0(v0,v1){
const v2=v0;
let v3=false;
for(let v4=0;v4<v2.length;v4++){
const v5=v2[v4];
const v6=v3;
const v7=v3;
let v8=v7;if(!v8){
const v9=v5;
const v10=v9;
const v11=v1;
v8=(v10===v11);}
v3=v8;
if(v6)break;
}
return v3;}
function __fn1(v12,v13){
const v14=[];
const v15=v12;
const v16=v14;
let v17=({["out"]:v16});
for(let v18=0;v18<v15.length;v18++){
const v19=v15[v18];
const v20=v17;
const v21=v20["out"];
const v22=v21;
let v23=false;
for(let v24=0;v24<v22.length;v24++){
const v25=v22[v24];
const v26=v23;
let v27=v26;if(!v27){
const v28=v25;
const v29=v19;
v27=(v28===v29);}
v23=v27;
}
const v30=v23;
const v31=false;
let v32;if((v30===v31)){
const v33=v21;
const v34=v19;
const v35=[v34];
const v36=v33.length;
const v37=v35.length;
const v38=new Array(v36+v37);
for(let v39=0;v39<v36;v39++){v38[v39]=v33[v39];}
for(let v40=0;v40<v37;v40++){v38[v36+v40]=v35[v40];}
const v41=v38;
const v42=v41;
v32=({["out"]:v42});}else{
const v43=v21;
v32=({["out"]:v43});}
v17=v32;
}
const v44=v17;
const v45=v44;
const v46=v45["out"];
return v46;}
function __into1(v47,v48,v49){
const v50=[];
const v51=v47;
const v52=v50;
let v53=({["out"]:v52});
for(let v54=0;v54<v51.length;v54++){
const v55=v51[v54];
const v56=v53;
const v57=v56["out"];
const v58=v57;
let v59=false;
for(let v60=0;v60<v58.length;v60++){
const v61=v58[v60];
const v62=v59;
let v63=v62;if(!v63){
const v64=v61;
const v65=v55;
v63=(v64===v65);}
v59=v63;
}
const v66=v59;
const v67=false;
let v68;if((v66===v67)){
const v69=v57;
const v70=v55;
const v71=[v70];
const v72=v69.length;
const v73=v71.length;
const v74=new Array(v72+v73);
for(let v75=0;v75<v72;v75++){v74[v75]=v69[v75];}
for(let v76=0;v76<v73;v76++){v74[v72+v76]=v71[v76];}
const v77=v74;
const v78=v77;
v68=({["out"]:v78});}else{
const v79=v57;
v68=({["out"]:v79});}
v53=v68;
}
const v80=v53;
const v81=v80;
const v82=v81["out"];
const v83=v82.length;
for(let v84=0;v84<v83;v84++){
v49[v84]=v82[v84];
}
return v83;}
const __namedTypes={"__ink_loop_7ffbebe14e03c87ce472d07a0730652e389294fd2d35582c49f6f96b53fd8155_1":{"fields":[{"name":"out","type":{"element":{"kind":"u32"},"kind":"list"}}],"kind":"record","name":"__ink_loop_7ffbebe14e03c87ce472d07a0730652e389294fd2d35582c49f6f96b53fd8155_1"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"595e14dc15eec776073fc52bafc3716b44777b3dc3e2e8253ced09f53fea5095","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":null,"index":0,"internal":false,"name":"contains","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"x","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":1,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"unused","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"kind":"u32"},"kind":"list"}}],"named_types":{"__ink_loop_7ffbebe14e03c87ce472d07a0730652e389294fd2d35582c49f6f96b53fd8155_1":{"fields":[{"name":"out","type":{"element":{"kind":"u32"},"kind":"list"}}],"kind":"record","name":"__ink_loop_7ffbebe14e03c87ce472d07a0730652e389294fd2d35582c49f6f96b53fd8155_1"}},"schema":1,"state":null};
const __implementations=[__fn0,__fn1];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[null,__into1];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
