function __fn0(v0,v1){
const v2=v0;
let v3="missing";
for(let v4=0;v4<v2.length;v4++){
const v5=v2[v4];
const v6=v5;
const v7=v6["key"];
const v8=v1;
const v9=(v7===v8);
const v10=v5;
const v11=v10["key"];
const v12=v1;
let v13;if((v11===v12)){
const v14=v5;
v13=v14["label"];}else{
v13=v3;}
v3=v13;
if(v9)break;
}
return v3;}
const __namedTypes={"Node":{"fields":[{"name":"key","type":{"kind":"u32"}},{"name":"label","type":{"kind":"string"}},{"name":"active","type":{"kind":"bool"}}],"kind":"record","name":"Node"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v6","core_sha256":"f473e515172817d2bc8dadb5cdeb6a98b4bd1e68b0c30e7479d751f43f409be8","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":null,"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"fields":[{"name":"key","type":{"kind":"u32"}},{"name":"label","type":{"kind":"string"}},{"name":"active","type":{"kind":"bool"}}],"kind":"record","name":"Node"},"kind":"list"}},{"name":"cut","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"string"}}],"named_types":{"Node":{"fields":[{"name":"key","type":{"kind":"u32"}},{"name":"label","type":{"kind":"string"}},{"name":"active","type":{"kind":"bool"}}],"kind":"record","name":"Node"}},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[null];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
