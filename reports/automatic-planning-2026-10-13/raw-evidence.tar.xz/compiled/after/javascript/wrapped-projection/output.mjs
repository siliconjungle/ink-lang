function __fn0(v0,v1){
const v2=v0;
const v3=v2.length;
const v4=new Array(v3);
for(let v5=0;v5<v3;v5++){
const v6=v2[v5];
const v7=v6;
const v8=v7["id"];
const v9=v6;
const v10=v9["value"];
const v11=v1;
const v12=(((v10) + (v11)) >>> 0);
v4[v5]=({["id"]:v8,["value"]:v12});
}
const v13=v4;
const v14=v13.length;
const v15=[];
for(let v16=0;v16<v14;v16++){
const v17=v13[v16];
const v18=v17;
const v19=v18["value"];
const v20=0;
if(!(v19===v20)){v15.push(v17);}
}
return v15;}
function __into0(v21,v22,v23){
const v24=v21;
const v25=v24.length;
const v26=new Array(v25);
for(let v27=0;v27<v25;v27++){
const v28=v24[v27];
const v29=v28;
const v30=v29["id"];
const v31=v28;
const v32=v31["value"];
const v33=v22;
const v34=(((v32) + (v33)) >>> 0);
v26[v27]=({["id"]:v30,["value"]:v34});
}
const v35=v26;
const v36=v35.length;
let v37=0;
for(let v38=0;v38<v36;v38++){
const v39=v35[v38];
const v40=v39;
const v41=v40["value"];
const v42=0;
if(!(v41===v42)){
v23[v37++]=v39;
}
}
return v37;}
const __namedTypes={"Row":{"fields":[{"name":"id","type":{"kind":"u32"}},{"name":"value","type":{"kind":"u32"}}],"kind":"record","name":"Row"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v2","core_sha256":"234142eb41a2c8440061df66551719af09cd569ed7c6a3ff60252673954191e5","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"fields":[{"name":"id","type":{"kind":"u32"}},{"name":"value","type":{"kind":"u32"}}],"kind":"record","name":"Row"},"kind":"list"}},{"name":"add","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"fields":[{"name":"id","type":{"kind":"u32"}},{"name":"value","type":{"kind":"u32"}}],"kind":"record","name":"Row"},"kind":"list"}}],"named_types":{"Row":{"fields":[{"name":"id","type":{"kind":"u32"}},{"name":"value","type":{"kind":"u32"}}],"kind":"record","name":"Row"}},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[__into0];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
