function __fn0(v0,v1){
const v2=v0;
let v3=false;
for(let v4=0;v4<v2.length;v4++){
const v5=v2[v4];
const v6=v5;
let v7;if(v6["visible"]){
const v8=v3;
let v9=v8;if(!v9){
const v10=v5;
const v11=v10["selected"];
let v12=v11;if(v12){
const v13=v5;
const v14=v13["id"];
const v15=v1;
v12=(v14===v15);}
v9=v12;}
v7=v9;}else{
v7=v3;}
v3=v7;
}
return v3;}
const __namedTypes={"Layer":{"fields":[{"name":"visible","type":{"kind":"bool"}},{"name":"selected","type":{"kind":"bool"}},{"name":"id","type":{"kind":"i32"}}],"kind":"record","name":"Layer"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"25f7a684ec5221eabe6e204b900d35c8ceab70ac62167b3f06cdc1d63dcc8343","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":null,"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"fields":[{"name":"visible","type":{"kind":"bool"}},{"name":"selected","type":{"kind":"bool"}},{"name":"id","type":{"kind":"i32"}}],"kind":"record","name":"Layer"},"kind":"list"}},{"name":"key","type":{"kind":"i32"}}],"precondition":null,"result":{"kind":"bool"}}],"named_types":{"Layer":{"fields":[{"name":"visible","type":{"kind":"bool"}},{"name":"selected","type":{"kind":"bool"}},{"name":"id","type":{"kind":"i32"}}],"kind":"record","name":"Layer"}},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[null];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
