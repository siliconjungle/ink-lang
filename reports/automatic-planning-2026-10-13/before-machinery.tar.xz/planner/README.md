# Ink planner

Untrusted search, cost selection and routing for [Ink](https://github.com/siliconjungle/ink-lang). This repository can propose programs and execution plans; only the semantic core can admit their proof evidence. It neither defines language semantics nor emits target code.

Install `ink-knowledge` first, then `python3 -m pip install -e .`. The distribution pins both repositories; its source entry points `plan.py` and `route.py` use the installed package or explicitly configured/pinned knowledge checkout. `INK_KNOWLEDGE_ROOT` selects a separate installation.

```sh
ink-plan --compiler /path/to/ink --core program.core.json \
  --knowledge-root /path/to/ink-knowledge \
  --snapshot /path/to/ink-knowledge/store/snapshots/SNAPSHOT_SHA256.json \
  --budget 128 -o selection.json
/path/to/ink check-selection program.core.json selection.json
```

The knowledge API discovers laws by typed result sorts present in the program. Search matches below binders, composes rewrites, discharges conditions with supporting proofs, and checks every candidate in a bounded checker session. Rules and combinations come from data. Candidate cost is a structural estimate, explicitly separate from measured physical performance. Unsupported candidates or exhausted search retain the unchanged program.

A selection uses `ink-evidence-v1`: the exact input core ID, an authenticated pinned knowledge view and ordered applications carrying their substitutions and premise proofs. Replay rechecks all evidence against that input; it requires no live database, filenames or latest snapshot. The old catalogue selection wire is not accepted. `schemas/selection.json` describes this envelope; individual semantic proof terms are versioned by the core.

`ink-route` creates literal pure source graphs, with explicit placements or an unchanged CPU baseline. `ink-select-route` checks every candidate, then consults `Store.observations` only when `--knowledge-root`, `--target TARGET.json` and `--workload WORKLOAD.json` supply matching provenance. No comparable baseline evidence means baseline selection. A cheap invalid candidate still rejects. Proved graph alternatives use the same pinned knowledge view and semantic proof calculus.

`ink_planner.search` is the bounded search API; `ink_planner.source_routing.produce` is the graph API. Target packages and execution domains are opaque names to the proof checker. Physical scheduling, profiling, GPU/device operations and fallback belong to `ink-runtime` and device adapters.

`research/` contains the historical scalar/collection search experiment. It is outside production discovery and is retained to reproduce regression evidence.


Semantic search marks a resulting term state as seen only after the compiler
accepts its proof package. A rejected conditional law cannot suppress another
valid proof reaching the same result. `tests/test_semantic_search.py` covers this
case and preservation of the baseline on rejection/budget exhaustion. Matching,
costs and deduplication remain untrusted; every selected step is replayed.

The CLI exposes `--rounds 0..64` (default 12) independently of the unchanged
`--budget 0..4096` proof-check bound. Larger modules may need more than twelve
independent rewrites; `--rounds 32` permits those while retaining checked
admission and the baseline fallback. The receipt records `round_limit`.

## Measured physical representation selection

`ink-select-representation` (or `select_representation.py`) checks a baseline and
a bounded candidate index with the actual Ink compiler, then ranks comparable
measurements of a supplied lifecycle profile. Candidate indices contain request
paths and optional bridge paths, resolved relative to the index file. Maximum
candidates is 32; per-check timeout is bounded to 60 seconds. Checker inputs are
staged from the exact bytes later written to the selection output.

```sh
python3 planner/select_representation.py --compiler target/debug/ink \
  --source examples/point-query-delta.ink \
  --baseline knowledge/research/point-delta/refresh.json \
  --candidates reports/incremental-maintenance-selection/candidates.json \
  --knowledge-root knowledge \
  --target reports/incremental-maintenance-selection/target.json \
  --workload reports/incremental-maintenance-selection/workload.json \
  --profile reports/incremental-maintenance-selection/profile.json \
  --migration-count 1 -o build/selected-representation.json
```

Profile keys are initialise, teardown, check, compile and action:NAME, with
nonnegative integer counts. Missing required phases exclude alternatives; missing
comparable baseline phases retain the checked baseline. Exact rational pooled
medians determine weighted costs, with ties retaining the baseline. Migration
requires a checked bridge and charges its measured cost. Phase observations retain
the supplied workload shape/distribution/concurrency/residency and exact target
provenance. Distribution becomes `{workload: ORIGINAL, phase: PHASE}`.

The measurement plan ID is SHA256 of the exact request file, binding witness
and closure costs. Migration phases use `migrate:BASELINE_REQUEST_SHA:BRIDGE_SHA`.
`--memory-limit BYTES` constrains the maximum measured peak across required
regions; unknown memory is not zero. An infeasible baseline memory constraint
fails explicitly. Measurements do not guarantee a future process memory limit.

The output is the exact frozen checked request, plus a checked bridge when switching
and a `.selection.json` receipt containing hashes, evidence IDs and weighted costs.
Emit/execute commands replay through the checker. This is explicit external
selection; there is no live adaptation or performance authority in the core.

Discovery objects are untrusted search inputs. The planner validates each proposal
and final result with the exact selected rewrite/premise dependency closure,
using at most eight cached checker sessions. Unused discovery laws do not consume
a shared admission budget and are omitted from final proof authority. Every
chosen law is still checked; an invalid or over-budget closure rejects the
proposal. Discovery counts and checked roots are recorded separately.
`--compact-output` controls JSON formatting; both output forms contain only the
selected closure.

Proposal costs are ranked before bounded checker work. Search checks only enough admitted alternatives to fill the next beam; rejected proofs do not suppress other proofs of the same body. Generated proposals and checked attempts are reported separately.

Type-indexed discovery pages through snapshot candidates independently of the rewrite-check budget. The budget bounds proof attempts, not the subset of law IDs that can be discovered.

Optional target component models and their source/physical boundaries are documented
in [docs-target-components.md](docs-target-components.md). Schema1 pricing and default
structural ranking remain unchanged.

Offline cost profiles use `python -m ink_planner.cost_profiles --knowledge-root
KNOWLEDGE --rows ROWS.json --target-key TARGET -o PROFILE.json`. Each row names an
immutable observation and its exact compiled scope. The fitter uses explicit
workload features, nonnegative prices and intersected observed domains; hosts
never extrapolate or run training probes. Fitted models retain their observation
IDs in knowledge's `store/cost-models`, outside mathematical admission. Structural
search defaults come from knowledge's `structural-costs.json` and are unmeasured
hypotheses, never evidence of speed or correctness.

Optional offline emitted-work ranking over already checked alternatives is described in [docs-physical-features.md](docs-physical-features.md). It leaves the default semantic search unchanged and retains the baseline for missing/incomparable target evidence.

## Database implementation candidates

`ink-select-implementation` (`select_implementation.py`) compares supplied
canonical implementation entry IDs through the existing selection and physical
representation proof protocols. An ordinary program can be published as an empty
selection package and has the same checks as other candidates. The compiler
contains no source-versus-cache selector. All seven lanes bind separate measurement
identities to the candidate and exact compiler; lifecycle frequencies, setup,
portable migration and measured memory enter external ranking. Missing comparable
evidence retains the supplied baseline, which can itself be any admitted candidate.

`--replay selected.json` authenticates the recorded database snapshot/package,
rechecks proofs and invokes existing lowering commands. Catalogue entries cannot
provide scripts or executable commands. See the distribution's
`docs/state-choice.md` and knowledge's `research/implementation-candidates`
publication for usage and trust limits. Representation-only selection retains
its explicit checked direct-bridge interface.

See the distribution’s `docs/storage-bulk-incremental.md` for the checked chunk/index
and Boolean maintenance producers, bulk collection laws, overlapping proof admission,
optional search-hint cache and incremental discovery index. Optimisation evidence
remains untrusted; source-bound proof replay and measured selection are separate.

Without an explicit `--candidates` file, implementation selection now discovers
source-bound database packages and automatically proposes checked indexed and
grouped alternatives through knowledge's generic producer. `--no-proposals`
limits selection to published candidates. Explicit pools retain their previous
behavior. Producer subprocesses are bounded; failed proposals are reported and
leave the baseline available. Recipe caching binds source, exact compiler,
producer code/data and budgets; checker admission is repeated on every selection.
The existing lifecycle ranker and backend/workload observations decide whether
batching is profitable. Missing evidence retains the baseline. Reproduce cold
proposal, grouped/indexed/baseline selection and exact replay with the distribution
integration test `tests/automatic_candidates_integration.py` and its fixture.
Scalable table profiles use separate `action:batch`, `action:scan`,
`action:intersection`, `action:erase` and `action:abort` phases alongside setup,
proof checking, compilation, checkpoint and restore. The caller supplies bounded
counts and exact workload cohorts. A batch sample is not a scalar-update sample
multiplied by input length: duplicates, overlap and rollback can change its cost.
These existing generic lifecycle phases need no compiler-specific pricing rule.

## Optional probabilistic search and compiled kernels

`ink-plan` retains ordinary deterministic search by default. Opt-in
`--search-strategy stochastic|learned --search-seed N --search-restarts 4`
shares one bounded candidate-check budget across restarts and retains an ordinary
first lane. `--search-trace TRACE.json` records actual checker outcomes and effort;
`ink-fit-search --rows TRACE.json -o MODEL.json` fits acceptance and checker-effort
hints. Learned search requires `--search-model MODEL.json`. A model predicts utility,
never mathematical truth. All proposals and cached recipes still replay through
the independent source-bound checker; failed proposals retain the baseline.

`ink-synthesize --compiler INK --core CORE --function NAME --output-store STORE
-o SELECTION.json` proposes bounded pure u32 arithmetic expressions. Affine probes,
random candidates, exact sample vectors and counterexamples reject bad proposals;
ordinary universal word-ring proofs admit replacements. This is not general
program synthesis, float equivalence or a transactional state proof.

`ink-plan-parallel` runs independent planner/checker processes with a shared total
proof budget and separately rechecks the selected package before publication.
Worker startup and proof costs count in complete planning timings. More workers
are not automatically faster.

`ink-autotune` provides bounded offline Gaussian-process configuration exploration
over supplied complete-call observations. Correctness, device fallback, explicit
setup cost, expected call count and independent heldout evidence gate alternatives.
The CLI without heldout evidence retains the baseline. The Python API accepts a
heldout callback. Receipts do not install runtime profiles or grant eligibility;
existing proof and target-context admission still apply.

`--discovery-accelerator` enables knowledge's authenticated in-memory exact index.
`--ann-hints` optionally uses HNSW structural neighbourhoods to order proposals.
Install the optional `ann` extra for hnswlib 0.8.0; neither NumPy nor HNSW is a
default dependency. The 64-dimensional deterministic structural sketch is not a
learned semantic embedding. Full typed discovery and exact matching remain;
missing libraries or index failures retain ordinary ordering. Approximate recall
can affect search quality at a fixed budget, so multi-restart search keeps an
ordinary lane. These disposable indexes confer no proof authority.

Packaged `kernels/planner.ink` and `hosts/planner-kernels.mjs` execute bounded word
feature scoring and candidate evaluation through ordinary compiled Ink backends.
`--selfhost-endpoint http://127.0.0.1:PORT` connects stochastic/learned search to an
optional loopback host; scores are independently compared and failures use local
ranking. Synthesis supports the same host for one-register word evaluation. Python
still coordinates graph search and the independent checker remains separate.
No runtime profitability trials are added. See the distribution's
`docs/probabilistic-planning.md` and `bench/probabilistic-planner` for commands,
actual hardware GPU receipts, retained losses and setup costs.

`ink-plan-adaptive --compiler INK --core CORE --snapshot SNAPSHOT --knowledge-root
STORE --target-context TARGET.json --profile PROFILE.json -o SELECTION.json`
chooses a search approach from saved offline evidence. Observed cohorts bind
catalogue size, source node count, budgets, exact source/snapshot, planner and
producer code/data, compiler, Python and caller-supplied target context. There is
no extrapolation to an unseen size or catalogue pin. Alternatives need more than
10% gain in complete-call training and each independent holdout, with no loss
in checked selected structural cost. Setup already enters child timings. Missing
or stale profiles retain ordinary search. Wrapper overhead is measured separately;
these receipts guide compilation and never change mathematical admission.

Source contract refinement uses the ordinary knowledge recipe registry and
`ink-evidence-v1` package checker. `contract-witnesses` proposes postcondition
witnesses and the core rechecks every postcondition, invariant and caller.
Both compiled planning and implementation selection accept `--contract-proofs`
for source input; checked core input already carries its evidence. Candidate
publication includes the dependency closure of embedded pure and state proofs,
including inside composed plans. Missing comparable performance observations
retains the baseline; a proof of correctness is not a speed estimate.

## Streaming planning and effort

Compiled planning now admits proposals while producers continue running. Two
bounded recipe processes share the budget, and semantic matching reuses exact
unchanged subtrees. Quick, balanced and thorough settings make the exploration
budget explicit; individual flags override the preset. See
[search scheduling](docs/search-scheduling.md) for limits, cache behaviour and
research references. Wider discovery still requires independent proof replay and
comparable performance evidence before selection.

## License

Project code and documentation are [MIT licensed](LICENSE). Third-party dependencies,
vendored projects and research data retain their own licenses and notices.
