# Ink C lowering

Literal C emission for Ink's executable pure and stateful language.
The compiler checks types/effects and database replacements; this backend consumes
`ink_core::core::CheckedModule`. It adds no optimisation catalogue.

The packed pure CLI `cargo run --release -- CORE.json -o program.c` rechecks the versioned core input
before writing output. Clang/LLVM can compile that C to native code or Wasm.
The C emitter, allocation runtime and target toolchain remain trusted. This is
not a direct assembly or GPU backend.

Part of the personal siliconjungle Ink repositories. The distribution pins this
repository as a submodule. Core schema/toolchain compatibility must be explicit;
repository identities do not establish correctness.

Pure compute v2 adds i32/f32, numeric vectors and records, sequential bindings,
array results, indexed reads, bounded loops and the packed owned-call ABI.
The smaller word-only and packed compute ABIs remain explicit pure interfaces.
See ink-lang/docs/gpu-compute.md for semantics, supported layouts and validation.

`native::lower_selected` accepts the shared, locally checked semantic selection witness and lowers its exact selected module. Optimisation laws and search remain in the independently pinned knowledge database.

The packed ABI borrows `List<u32>` input storage directly. Callers provide
well-typed, aligned words and keep input storage alive until the result has been
consumed. Identity results may alias input storage; map and sort leave inputs
unchanged. The web host copies packed results before resetting the call arena.

Current complete execution coverage, GPU exclusions and integration evidence are documented in the [lowering parity contract](https://github.com/siliconjungle/ink-lang/blob/main/docs/lowering-parity.md).
`complete::lower` emits literal C functions/actions through a typed primitive ABI. The runtime assembles the shared Rust value/transaction/snapshot implementation; this path is not freestanding C-only. Existing packed pure emission remains available.

Complete selected emission uses `complete::lower_selected(&CheckedSelection)` and the core-authenticated original checkpoint layout. Bare checked-module emission keeps its own snapshot namespace; callers cannot supply an identity override.

All targets consume [ink-abi](https://github.com/siliconjungle/ink-abi) for shared
type/layout contracts. Early termination, owned-buffer transforms and helper
unfolding are checked database choices. The backend emits the resulting general
operations literally; it does not infer those transformations from source patterns.

Literal state lowering supports fixed batch upserts/removals, shared-key intersections and forward numerical/predicate scans. The dynamic support journals affected payloads rather than cloning all tables. Shared-key iteration probes the smaller table; C scans retain an ordered key carrier and use value frames to reclaim row/callback scratch while preserving the accumulator. No source-pipeline matcher grants algorithmic rewrite authority.

## License

Project code and documentation are [MIT licensed](LICENSE). Third-party dependencies,
vendored projects and research data retain their own licenses and notices.
