//! Literal checked constructor/function emission. No rewrite or layout rules.
use ink_core::{definition::CheckedDefinition, logic::{Declaration,Sort,Term}, LangResult};
use std::collections::BTreeMap;
pub struct Emission { pub source:String, pub functions:Vec<String>, pub datatypes:Vec<String> }
struct Lower { types:BTreeMap<String,usize>, next:usize }
impl Lower {
 fn sort(&self,s:&Sort,current:&str)->i32 {match s {Sort::Bool=>-1,Sort::U64=>-2,Sort::Data(id)=>self.types[id] as i32,Sort::SelfType=>self.types[current] as i32}}
 fn fresh(&mut self)->String {let n=format!("v{}",self.next);self.next+=1;n}
 fn expr(&mut self,t:&Term,env:&BTreeMap<String,String>,current:&str,out:&mut String)->LangResult<String>{
  if self.next>100000{return Err("C definition emission limit".into());}
  if let Term::Var(n)=t {return env.get(n).cloned().ok_or("C definition variable".into());}
  let name=self.fresh();
  let value=match t {
   Term::Bool(x)=>format!("scalar(0,{})",usize::from(*x)),Term::U64(x)=>format!("scalar(1,UINT64_C({x}))"),
   Term::Construct{datatype,constructor,arguments}=>{let xs=arguments.iter().map(|x|self.expr(x,env,current,out)).collect::<LangResult<Vec<_>>>()?;format!("construct({}, {}, {}, (V*[]){{{}}})",self.types[datatype],constructor,xs.len(),if xs.is_empty(){"0".into()}else{xs.join(",")})},
   Term::Call{arguments,..}|Term::SelfCall(arguments)=>{let id=if let Term::Call{function,..}=t{function}else{current};let xs=arguments.iter().map(|x|self.expr(x,env,current,out)).collect::<LangResult<Vec<_>>>()?;format!("f_{id}({})",xs.join(","))},
   Term::Binary{op,left,right}=>{let a=self.expr(left,env,current,out)?;let b=self.expr(right,env,current,out)?;if let Some(operator)=op.strip_prefix("f32:"){let index=["+","-","*","neg","==","!=","<","<=",">",">="].iter().position(|x|*x==operator).ok_or("binary32 operator")?;format!("scalar({},f32_word({index},{a}->word,{b}->word))",usize::from(index<4))}else if op=="quot"||op=="rem"{format!("scalar(1,({b}->word?({a}->word {} {b}->word):0))",if op=="quot"{"/"}else{"%"})}else{let numeric=["+","-","*","&"].contains(&op.as_str());let oper=match op.as_str(){"&&"=>"&","||"=>"|",x=>x};format!("scalar({},({a}->word {oper} {b}->word))",usize::from(numeric))}},
   Term::If{condition,on_true,on_false}=>{let c=self.expr(condition,env,current,out)?;out.push_str(&format!("V* {name};if({c}->word){{\n"));let a=self.expr(on_true,env,current,out)?;out.push_str(&format!("{name}={a};}}else{{\n"));let b=self.expr(on_false,env,current,out)?;out.push_str(&format!("{name}={b};}}\n"));return Ok(name)},
   Term::Match{scrutinee,branches}=>{let c=self.expr(scrutinee,env,current,out)?;out.push_str(&format!("V* {name}=&zero;switch({c}->tag){{\n"));for(i,b)in branches.iter().enumerate(){let mut local=env.clone();out.push_str(&format!("case {i}:{{\n"));for(j,n)in b.bindings.iter().enumerate(){local.insert(n.clone(),format!("{c}->fields[{j}]"));}let value=self.expr(&b.body,&local,current,out)?;out.push_str(&format!("{name}={value};break;}}\n"));}out.push_str("default:error=1;break;}\n");return Ok(name)},
   Term::Var(_)=>unreachable!(),
  };
  out.push_str(&format!("V* {name}={value};if(error){{depth--;return &zero;}}\n"));Ok(name)
 }
}
pub fn lower(checked:&CheckedDefinition)->LangResult<Emission>{
 let declarations=checked.executable_declarations()?;
 let datatypes=declarations.iter().filter_map(|(id,d)|matches!(d,Declaration::Datatype{..}).then_some(id.clone())).collect::<Vec<_>>();
 let mut lower=Lower{types:datatypes.iter().enumerate().map(|(i,id)|(id.clone(),i)).collect(),next:0};
 let mut source=include_str!("definition.c.txt").to_owned()+include_str!("definition-f32.c.txt");
 for(id,d)in &declarations{if let Declaration::Function{params,..}=d{source.push_str(&format!("static V* f_{id}({});\n",if params.is_empty(){"void".into()}else{(0..params.len()).map(|i|format!("V* a{i}")).collect::<Vec<_>>().join(",")}));}}
 source.push_str("static int fields(int type,int tag,int* sorts){switch(type){\n");
 for id in &datatypes {let Declaration::Datatype{constructors}= &declarations[id]else{unreachable!()};source.push_str(&format!("case {}:switch(tag){{\n",lower.types[id]));for(i,c)in constructors.iter().enumerate(){source.push_str(&format!("case {i}:"));for(j,s)in c.fields.iter().enumerate(){source.push_str(&format!("sorts[{j}]={};",lower.sort(s,id)));}source.push_str(&format!("return {};\n",c.fields.len()));}source.push_str("default:return -1;}\n");}source.push_str("default:return -1;}}\n");
 for(id,d)in &declarations{if let Declaration::Function{params,body,..}=d{
  let env=params.iter().enumerate().map(|(i,(n,_))|(n.clone(),format!("a{i}"))).collect();
  source.push_str(&format!("static V* f_{id}({}){{if(!enter())return &zero;\n",if params.is_empty(){"void".into()}else{(0..params.len()).map(|i|format!("V* a{i}")).collect::<Vec<_>>().join(",")}));
  let value=lower.expr(body,&env,id,&mut source)?;source.push_str(&format!("depth--;return {value};}}\n"));
 }}
 source.push_str("V* ink_def_call(int function,V**args,int count){work=0;depth=0;error=0;switch(function){\n");
 for(i,id)in checked.exports().iter().enumerate(){let Declaration::Function{params,..}=&declarations[id]else{unreachable!()};let target=checked.choices().get(id).unwrap_or(id);source.push_str(&format!("case {i}:if(count!={}){{error=1;return &zero;}}",params.len()));for(j,(_,sort))in params.iter().enumerate(){source.push_str(&format!("if(!validate(args[{j}],{})){{error=1;return &zero;}}",lower.sort(sort,"")));}source.push_str(&format!("return f_{target}({});\n",(0..params.len()).map(|j|format!("args[{j}]")).collect::<Vec<_>>().join(",")));}source.push_str("default:error=1;return &zero;}}\n");
 if source.len()>16000000{return Err("C definition source limit".into());}
 Ok(Emission{source,functions:checked.exports().to_vec(),datatypes})
}
