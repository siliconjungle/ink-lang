//! Complete literal C lowering through a value/transaction primitive ABI.
//! Action control flow and collection loops are emitted as C. The companion
//! runtime provides exact values, codecs and storage; it receives no program AST.
use ink_abi::ValueKind as LiteralKind;
const U32_KIND: u32 = LiteralKind::U32 as u32;
use ink_core::{check, core::CheckedModule, syntax::*, LangResult};
use serde_json::{json, Value};
use std::collections::BTreeMap;
pub struct Emission {
    pub c: String,
    pub metadata: Value,
}
fn cquote(s: &str) -> String {
    format!(
        "\"{}\"",
        s.as_bytes()
            .iter()
            .map(|b| format!("\\{b:03o}"))
            .collect::<String>()
    )
}
type Env = BTreeMap<String, (String, Type)>;
fn references(e: &Expr, name: &str) -> bool {
    ink_core::analysis::references_free(e, name)
}

struct Emitter<'a> {
    module: &'a CheckedModule,
    next: usize,
    lines: String,
    state: bool,
    callbacks: Vec<(String, String)>,
    execution: &'a ink_core::action_ir::Execution,
}
impl Emitter<'_> {
    fn p(&self) -> &Program {
        self.module.program()
    }
    fn fresh(&mut self) -> String {
        let v = format!("v{}", self.next);
        self.next += 1;
        v
    }
    fn line(&mut self, s: impl AsRef<str>) {
        self.lines.push_str(s.as_ref());
        self.lines.push('\n');
    }
    fn infer(&self, e: &Expr, env: &Env, want: Option<&Type>) -> LangResult<Type> {
        let types = env
            .iter()
            .map(|(n, (_, t))| (n.clone(), t.clone()))
            .collect();
        if self.state {
            self.execution
                .type_of(e)
                .cloned()
                .or_else(|| {
                    if let Expr::Var(n) = e {
                        self.p()
                            .states
                            .iter()
                            .chain(&self.p().keeps)
                            .find(|d| &d.name == n)
                            .map(|d| d.ty.clone())
                    } else {
                        None
                    }
                })
                .ok_or_else(|| format!("missing checked action type: {e:?}"))
        } else {
            check::infer_context(e, &types, self.p(), want)
        }
    }
    fn op(&mut self, op: &str, args: &[String]) -> String {
        let v = self.fresh();
        let op = serde_json::to_string(op).unwrap();
        let array = if args.is_empty() {
            "NULL".into()
        } else {
            format!("(uint64_t[]){{{}}}", args.join(","))
        };
        self.line(format!(
            "uint64_t {v}=ink_op(ctx,{op},{array},{});if(ink_failed(ctx))return 0;",
            args.len()
        ));
        v
    }
    fn literal(&mut self, kind: u32, n: u64, text: &str) -> String {
        let v = self.fresh();
        self.line(format!(
            "uint64_t {v}=ink_literal(ctx,{kind},UINT64_C({n}),{},{});if(ink_failed(ctx))return 0;",
            cquote(text),
            text.len()
        ));
        v
    }
    fn kind(t: &Type) -> u32 {
        match t {
            Type::Unit => LiteralKind::Unit as u32,
            Type::Bool => LiteralKind::Bool as u32,
            Type::U32 => LiteralKind::U32 as u32,
            Type::U64 => LiteralKind::U64 as u32,
            Type::I32 => LiteralKind::I32 as u32,
            Type::F32 => LiteralKind::F32 as u32,
            Type::Int => LiteralKind::Int as u32,
            _ => LiteralKind::U64 as u32,
        }
    }
    fn lambda(
        &mut self,
        e: &Expr,
        env: &Env,
        params: Vec<(String, Type)>,
        result: &Type,
    ) -> LangResult<String> {
        let mut local = env.clone();
        let mut body = e;
        for (v, t) in params {
            let Expr::Lambda(n, b) = body else {
                return Err("typed lambda".into());
            };
            local.insert(n.clone(), (v, t));
            body = b;
        }
        self.expr(body, &local, Some(result))
    }
    fn parallel(
        &mut self,
        input: String,
        grain: String,
        callback: &Expr,
        env: &Env,
        input_ty: &Type,
        result: &Type,
        buffer: bool,
    ) -> LangResult<String> {
        // The checker excludes captured owners. Export only immutable bindings;
        // each invocation receives independent handles in its own value arena.
        let captures: Vec<_> = env
            .iter()
            .filter(|(n, (_, t))| {
                references(callback, n) && !ink_core::local_collections::owned(t, self.p())
            })
            .collect();
        let name = format!("parallel_{}", self.fresh());
        let saved = std::mem::take(&mut self.lines);
        let mut local = Env::new();
        for (i, (key, (_, ty))) in captures.iter().enumerate() {
            local.insert((*key).clone(), (format!("captures[{i}]"), ty.clone()));
        }
        self.line(format!("static uint64_t {name}(InkContext*ctx,uint32_t index,uint64_t item,const uint64_t*captures){{"));
        let index = self.fresh();
        self.line(format!("uint64_t {index}=ink_literal(ctx,2,index,\"\",0);"));
        let value = self.lambda(
            callback,
            &local,
            vec![(index, Type::U32), ("item".into(), input_ty.clone())],
            result,
        )?;
        self.line(format!("return {value};}}"));
        let body = std::mem::replace(&mut self.lines, saved);
        self.callbacks.push((name.clone(), body));
        let args = if captures.is_empty() {
            "NULL".into()
        } else {
            format!(
                "(uint64_t[]){{{}}}",
                captures
                    .iter()
                    .map(|(_, (v, _))| v.as_str())
                    .collect::<Vec<_>>()
                    .join(",")
            )
        };
        let out = self.fresh();
        self.line(format!("uint64_t {out}=ink_parallel(ctx,{input},ink_u32(ctx,{grain}),{},{args},{},{});if(ink_failed(ctx))return 0;", name.trim_start_matches("parallel_v"), captures.len(), u32::from(buffer)));
        Ok(out)
    }
    fn tail(&mut self, e: &Expr, env: &Env, f: &Function) -> LangResult<()> {
        match e {
            Expr::Let(n, annotation, a, b) => {
                let t = self.infer(a, env, annotation.as_deref())?;
                let value = self.expr(a, env, Some(&t))?;
                let mut local = env.clone();
                local.insert(n.clone(), (value, t));
                self.tail(b, &local, f)?;
            }
            Expr::Call(n, a) if n == "choose" => {
                let value = self.expr(&a[0], env, Some(&Type::Bool))?;
                self.line(format!("if(ink_bool(ctx,{value})){{"));
                self.tail(&a[1], env, f)?;
                self.line("}else{");
                self.tail(&a[2], env, f)?;
                self.line("}");
            }
            Expr::Call(n, a) if n == &f.name => {
                let mut values = vec![];
                for (a, (_, t)) in a.iter().zip(&f.params) {
                    let v = self.expr(a, env, Some(t))?;
                    let tmp = self.fresh();
                    self.line(format!("uint64_t {tmp}={v};"));
                    let v = tmp;
                    values.push(v);
                }
                for (index, v) in values.into_iter().enumerate() {
                    self.line(format!("a{index}={v};"));
                }
                self.line("continue;");
            }
            _ => {
                let v = self.expr(e, env, Some(&f.result))?;
                self.line(format!("return {v};"));
            }
        }
        Ok(())
    }
    fn expr(&mut self, e: &Expr, env: &Env, want: Option<&Type>) -> LangResult<String> {
        let t = self.infer(e, env, want)?;
        Ok(match e {
            Expr::Num(n) => self.literal(
                Self::kind(&t),
                if t == Type::F32 {
                    (*n as f32).to_bits() as u64
                } else {
                    *n
                },
                "",
            ),
            Expr::Float(b) => self.literal(LiteralKind::F32 as u32, *b as u64, ""),
            Expr::Bool(b) => self.literal(LiteralKind::Bool as u32, *b as u64, ""),
            Expr::Unit => self.literal(LiteralKind::Unit as u32, 0, ""),
            Expr::String(s) => self.literal(LiteralKind::String as u32, 0, s),
            Expr::Var(n) => {
                if let Some((v, _)) = env.get(n) {
                    v.clone()
                } else if n == "None" {
                    self.op("None", &[])
                } else {
                    let i = self
                        .p()
                        .keeps
                        .iter()
                        .position(|k| &k.name == n)
                        .ok_or("state value")?;
                    self.call(2, i, &[], false)
                }
            }
            Expr::Neg(x) => {
                if matches!((&t, x.as_ref()), (Type::I32, Expr::Num(2147483648))) {
                    self.literal(LiteralKind::I32 as u32, 2147483648, "")
                } else {
                    let a = self.expr(x, env, Some(&t))?;
                    self.op("neg", &[a])
                }
            }
            Expr::Let(n, annotation, a, b) => {
                let at = self.infer(a, env, annotation.as_deref())?;
                let a = self.expr(a, env, Some(&at))?;
                let mut local = env.clone();
                local.insert(n.clone(), (a, at));
                self.expr(b, &local, Some(&t))?
            }
            Expr::Record(n, fields) => {
                let schema = self.p().records[n].clone();
                let mut vals = BTreeMap::new();
                for (k, e) in fields {
                    let ft = &schema.iter().find(|(f, _)| f == k).ok_or("field")?.1;
                    vals.insert(k.clone(), self.expr(e, env, Some(ft))?);
                }
                self.op(
                    &format!("record:{n}"),
                    &schema
                        .iter()
                        .map(|(k, _)| vals[k].clone())
                        .collect::<Vec<_>>(),
                )
            }
            Expr::Field(x, n) => {
                if let Expr::Var(en) = x.as_ref() {
                    if self.p().enums.contains_key(en) {
                        return Ok(self.literal(LiteralKind::Enum as u32, 0, &format!("{en}.{n}")));
                    }
                }
                let a = self.expr(x, env, None)?;
                self.op(&format!("field:{n}"), &[a])
            }
            Expr::Try(x) => {
                let a = self.expr(x, env, None)?;
                self.op("try", &[a])
            }
            Expr::Binary(op, a, b) => {
                let types = env
                    .iter()
                    .map(|(n, (_, t))| (n.clone(), t.clone()))
                    .collect();
                let mut at = if check::is_number(&t) || t == Type::Int {
                    t.clone()
                } else if self.state {
                    self.infer(a, env, None)?
                } else {
                    self.infer(
                        a,
                        env,
                        check::hint(a, &types, self.p())
                            .or_else(|| check::hint(b, &types, self.p()))
                            .as_ref(),
                    )?
                };
                if self.state && matches!(a.as_ref(), Expr::Num(_)) {
                    let bt = self.infer(b, env, None)?;
                    if matches!(bt, Type::U32 | Type::Int) {
                        at = bt
                    }
                }
                let a = self.expr(a, env, Some(&at))?;
                if op == "&&" || op == "||" {
                    let out = self.fresh();
                    self.line(format!(
                        "uint64_t {out}={a};if({}ink_bool(ctx,{a})){{",
                        if op == "||" { "!" } else { "" }
                    ));
                    let b = self.expr(b, env, Some(&at))?;
                    self.line(format!("{out}={b};}}"));
                    out
                } else {
                    let b = self.expr(b, env, Some(&at))?;
                    self.op(op, &[a, b])
                }
            }
            Expr::Call(n, args) if n == "choose" => {
                let c = self.expr(&args[0], env, Some(&Type::Bool))?;
                let out = self.fresh();
                self.line(format!("uint64_t {out};if(ink_bool(ctx,{c})){{"));
                let a = self.expr(&args[1], env, Some(&t))?;
                self.line(format!("{out}={a};}}else{{"));
                let b = self.expr(&args[2], env, Some(&t))?;
                self.line(format!("{out}={b};}}"));
                out
            }
            Expr::Call(n, args) if n == "list" => {
                let Type::List(inner) = &t else {
                    return Err("list type".into());
                };
                let values = args
                    .iter()
                    .map(|e| self.expr(e, env, Some(inner)))
                    .collect::<LangResult<Vec<_>>>()?;
                self.op("list", &values)
            }
            Expr::Call(n, args) if n == "quot_or" || n == "rem_or" => {
                let a = self.expr(&args[0], env, Some(&t))?;
                let b = self.expr(&args[1], env, Some(&t))?;
                let valid = self.op("div_ok", &[a.clone(), b.clone()]);
                let out = self.fresh();
                self.line(format!("uint64_t {out};if(ink_bool(ctx,{valid})){{"));
                let v = self.op(if n == "quot_or" { "quot" } else { "rem" }, &[a, b]);
                self.line(format!("{out}={v};}}else{{"));
                let f = self.expr(&args[2], env, Some(&t))?;
                self.line(format!("{out}={f};}}"));
                out
            }
            Expr::Call(n, args) if n == "length" => {
                let xs = self.expr(&args[0], env, None)?;
                self.op("list_length", &[xs])
            }
            Expr::Call(n, args) if n == "parallel_map" => {
                let input = self.expr(&args[0], env, None)?;
                let grain = self.expr(&args[1], env, Some(&Type::U32))?;
                let Type::List(inner) = self.infer(&args[0], env, None)? else {
                    unreachable!()
                };
                let Type::List(result) = &t else {
                    unreachable!()
                };
                self.parallel(input, grain, &args[2], env, &inner, result, false)?
            }
            Expr::Call(n, args) if n == "repeat_until" => {
                let limit = self.expr(&args[0], env, Some(&Type::U32))?;
                let initial = self.expr(&args[1], env, Some(&t))?;
                let out = self.fresh();
                let i = self.fresh();
                let bound = self.fresh();
                self.line(format!("uint32_t {bound}=ink_u32(ctx,{limit});uint64_t {out}={initial};for(uint32_t {i}=0;{i}<{bound};{i}++){{if(!ink_tick(ctx))return 0;"));
                let stop =
                    self.lambda(&args[2], env, vec![(out.clone(), t.clone())], &Type::Bool)?;
                self.line(format!("if(ink_bool(ctx,{stop}))break;"));
                let index = self.fresh();
                self.line(format!(
                    "uint64_t {index}=ink_literal(ctx,{U32_KIND},{i},\"\",0);"
                ));
                let body = self.lambda(
                    &args[3],
                    env,
                    vec![(index, Type::U32), (out.clone(), t.clone())],
                    &t,
                )?;
                self.line(format!("{out}={body};}}"));
                out
            }
            Expr::Call(n, args) if n == "buffer" || n == "buffer_fill" => {
                let Type::Buffer(inner) = &t else {
                    unreachable!()
                };
                if n == "buffer" {
                    let xs = self.expr(&args[0], env, Some(&Type::List(inner.clone())))?;
                    self.op("buffer_new", &[xs])
                } else {
                    let len = self.expr(&args[0], env, Some(&Type::U32))?;
                    let value = self.expr(&args[1], env, Some(inner))?;
                    self.op("buffer_fill", &[len, value])
                }
            }
            Expr::Method(x, _, _) if matches!(x.as_ref(),Expr::Var(v) if v=="Buffer" || v=="Map") => {
                self.op(
                    if matches!(t, Type::Buffer(_)) {
                        "buffer_empty"
                    } else {
                        "map_empty"
                    },
                    &[],
                )
            }
            Expr::Method(x, n, args)
                if matches!(self.infer(x, env, None)?, Type::Buffer(_) | Type::Map(..)) =>
            {
                let xt = self.infer(x, env, None)?;
                let xv = self.expr(x, env, None)?;
                if n == "filter" {
                    let Type::Buffer(inner) = &xt else {
                        unreachable!()
                    };
                    let len = self.op("buffer_len", &[xv.clone()]);
                    let i = self.fresh();
                    let kept = self.literal(LiteralKind::U32 as u32, 0, "");
                    self.line(format!("for(uint32_t {i}=0;{i}<ink_u32(ctx,{len});{i}++){{if(!ink_tick(ctx))return 0;"));
                    let index = self.fresh();
                    self.line(format!(
                        "uint64_t {index}=ink_literal(ctx,{},{i},\"\",0);",
                        LiteralKind::U32 as u32
                    ));
                    let item = self.op("buffer_get", &[xv.clone(), index]);
                    let pred = self.lambda(
                        &args[0],
                        env,
                        vec![(item.clone(), *inner.clone())],
                        &Type::Bool,
                    )?;
                    self.line(format!("if(ink_bool(ctx,{pred})){{"));
                    self.op("buffer_set", &[xv.clone(), kept.clone(), item]);
                    let one = self.literal(LiteralKind::U32 as u32, 1, "");
                    let next = self.op("+", &[kept.clone(), one]);
                    self.line(format!("{kept}={next};}}}}"));
                    return Ok(self.op("buffer_truncate", &[xv, kept]));
                }
                if ["map", "map_indexed", "scan"].contains(&n.as_str()) {
                    let Type::Buffer(inner) = &xt else {
                        unreachable!()
                    };
                    let len = self.op("buffer_len", &[xv.clone()]);
                    let i = self.fresh();
                    let acc = if n == "scan" {
                        Some(self.literal(Self::kind(inner), 0, ""))
                    } else {
                        None
                    };
                    self.line(format!("for(uint32_t {i}=0;{i}<ink_u32(ctx,{len});{i}++){{if(!ink_tick(ctx))return 0;"));
                    let index = self.fresh();
                    self.line(format!(
                        "uint64_t {index}=ink_literal(ctx,{},{i},\"\",0);",
                        LiteralKind::U32 as u32
                    ));
                    let item = self.op("buffer_get", &[xv.clone(), index.clone()]);
                    let value = if let Some(acc) = acc {
                        let add = self.op("+", &[acc.clone(), item]);
                        self.line(format!("{acc}={add};"));
                        acc
                    } else {
                        let params = if n == "map" {
                            vec![(item, *inner.clone())]
                        } else {
                            vec![(index.clone(), Type::U32), (item, *inner.clone())]
                        };
                        self.lambda(&args[0], env, params, inner)?
                    };
                    self.op("buffer_set", &[xv.clone(), index, value]);
                    self.line("}");
                    return Ok(xv);
                }
                if n == "map_parallel" {
                    let Type::Buffer(inner) = &xt else {
                        unreachable!()
                    };
                    let grain = self.expr(&args[0], env, Some(&Type::U32))?;
                    return self.parallel(xv, grain, &args[1], env, inner, inner, true);
                }
                if n == "split_at" {
                    let at = self.expr(&args[0], env, Some(&Type::U32))?;
                    let pair = self.op("buffer_split", &[xv, at]);
                    let left = self.item(&pair, "0");
                    let right = self.item(&pair, "1");
                    return self.lambda(
                        &args[1],
                        env,
                        vec![(left, xt.clone()), (right, xt.clone())],
                        &xt,
                    );
                }
                if n == "append" {
                    let other = self.expr(&args[0], env, Some(&xt))?;
                    return Ok(self.op("buffer_append", &[xv, other]));
                }
                if n == "fill_range" || n == "copy_within" {
                    let Type::Buffer(inner) = &xt else {
                        unreachable!()
                    };
                    let a = self.expr(&args[0], env, Some(&Type::U32))?;
                    let b = self.expr(&args[1], env, Some(&Type::U32))?;
                    let c = self.expr(
                        &args[2],
                        env,
                        Some(if n == "fill_range" { inner } else { &Type::U32 }),
                    )?;
                    return Ok(self.op(&format!("buffer_{n}"), &[xv, a, b, c]));
                }
                let (prefix, key, value) = match &xt {
                    Type::Buffer(inner) => ("buffer", Type::U32, inner.as_ref()),
                    Type::Map(k, v) => ("map", *k.clone(), v.as_ref()),
                    _ => unreachable!(),
                };
                let mut values = vec![xv];
                if !args.is_empty() {
                    values.push(self.expr(
                        &args[0],
                        env,
                        Some(if n == "push" { value } else { &key }),
                    )?);
                }
                if n == "at_or" || n == "get_or" {
                    let valid = self.op(&format!("{prefix}_contains"), &values);
                    let out = self.fresh();
                    self.line(format!("uint64_t {out};if(ink_bool(ctx,{valid})){{"));
                    let v = self.op(&format!("{prefix}_get"), &values);
                    self.line(format!("{out}={v};}}else{{"));
                    let v = self.expr(&args[1], env, Some(value))?;
                    self.line(format!("{out}={v};}}"));
                    out
                } else {
                    if args.len() == 2 {
                        values.push(self.expr(
                            &args[1],
                            env,
                            Some(if n == "swap" { &Type::U32 } else { value }),
                        )?);
                    }
                    self.op(&format!("{prefix}_{n}"), &values)
                }
            }
            Expr::Call(n, args) if n == "repeat" => {
                let Expr::Num(bound) = args[0] else {
                    return Err("loop bound".into());
                };
                let initial = self.expr(&args[1], env, Some(&t))?;
                let out = self.fresh();
                let i = self.fresh();
                self.line(format!("uint64_t {out}={initial};for(uint32_t {i}=0;{i}<{bound};{i}++){{if(!ink_tick(ctx))return 0;"));
                let index = self.fresh();
                self.line(format!(
                    "uint64_t {index}=ink_literal(ctx,{U32_KIND},{i},\"\",0);"
                ));
                let body = self.lambda(
                    &args[2],
                    env,
                    vec![(index, Type::U32), (out.clone(), t.clone())],
                    &t,
                )?;
                self.line(format!("{out}={body};}}"));
                out
            }
            Expr::Call(n, args) if n == "fold_until" => {
                let Type::List(inner) = self.infer(&args[0], env, None)? else {
                    return Err("fold input".into());
                };
                let xs = self.expr(&args[0], env, None)?;
                let initial = self.expr(&args[1], env, Some(&t))?;
                let out = self.fresh();
                let i = self.fresh();
                self.line(format!("uint64_t {out}={initial};for(size_t {i}=0;{i}<ink_length(ctx,{xs});{i}++){{if(!ink_tick(ctx))return 0;"));
                let item = self.item(&xs, &i);
                let values = vec![(item, *inner), (out.clone(), t.clone())];
                let condition = self.lambda(&args[2], env, values.clone(), &Type::Bool)?;
                let stop = self.fresh();
                self.line(format!("bool {stop}=ink_bool(ctx,{condition});"));
                let value = self.lambda(&args[3], env, values, &t)?;
                self.line(format!("{out}={value};if({stop})break;}}"));
                out
            }
            Expr::Call(n, args) if n == "foldr" || n == "foldl" => {
                let Type::List(inner) = self.infer(&args[0], env, None)? else {
                    return Err("fold type".into());
                };
                let xs = self.expr(&args[0], env, None)?;
                let initial = self.expr(&args[1], env, Some(&t))?;
                let out = self.fresh();
                let i = self.fresh();
                self.line(format!("uint64_t {out}={initial};"));
                self.line(if n=="foldr" {format!("for(size_t {i}=ink_length(ctx,{xs});{i}>0;){{--{i};if(!ink_tick(ctx))return 0;")}
                    else {format!("for(size_t {i}=0;{i}<ink_length(ctx,{xs});{i}++){{if(!ink_tick(ctx))return 0;")});
                let item = self.item(&xs, &i);
                let body = self.lambda(
                    &args[2],
                    env,
                    vec![(item, *inner), (out.clone(), t.clone())],
                    &t,
                )?;
                self.line(format!("{out}={body};}}"));
                out
            }
            Expr::Call(n, args) if n == "sum" || n == "count" => {
                let context = if n == "sum" {
                    Some(Type::List(Box::new(t.clone())))
                } else {
                    None
                };
                let xs = self.expr(&args[0], env, context.as_ref())?;
                if n == "count" {
                    let out = self.fresh();
                    self.line(format!(
                        "uint64_t {out}=ink_literal(ctx,{},ink_length(ctx,{xs}),\"\",0);",
                        Self::kind(&t)
                    ));
                    out
                } else {
                    let out = self.literal(Self::kind(&t), 0, "");
                    let i = self.fresh();
                    self.line(format!("for(size_t {i}=0;{i}<ink_length(ctx,{xs});{i}++){{if(!ink_tick(ctx))return 0;"));
                    let item = self.item(&xs, &i);
                    let add = self.op("+", &[out.clone(), item]);
                    self.line(format!("{out}={add};}}"));
                    out
                }
            }
            Expr::Call(n, args) if ink_core::word::primitive(n) => {
                let ts = ink_core::word::arguments(n, &t);
                let args = args
                    .iter()
                    .zip(ts)
                    .map(|(a, t)| self.expr(a, env, Some(&t)))
                    .collect::<LangResult<Vec<_>>>()?;
                self.op(n, &args)
            }
            Expr::Call(n, args) if ["vec2", "vec3", "vec4"].contains(&n.as_str()) => {
                let Type::Vector(inner, _) = &t else {
                    return Err("vector type".into());
                };
                let vals = args
                    .iter()
                    .map(|e| self.expr(e, env, Some(inner)))
                    .collect::<LangResult<Vec<_>>>()?;
                self.op("vector", &vals)
            }
            Expr::Call(n, args)
                if [
                    "Ok",
                    "Err",
                    "Some",
                    "Int",
                    "checked_add",
                    "checked_sub",
                    "checked_mul",
                ]
                .contains(&n.as_str()) =>
            {
                let context = match (&t, n.as_str()) {
                    (Type::Result(a, _), "Ok") | (Type::Option(a), "Some") => Some(&**a),
                    (Type::Result(_, b), "Err") => Some(&**b),
                    (Type::Result(a, _), "checked_add" | "checked_sub" | "checked_mul") => {
                        Some(&**a)
                    }
                    _ => None,
                };
                let first = self.expr(&args[0], env, context)?;
                let ft = self.infer(&args[0], env, context)?;
                let mut vals = vec![first];
                for e in &args[1..] {
                    vals.push(self.expr(e, env, Some(&ft))?)
                }
                self.op(n, &vals)
            }
            Expr::Call(n, args) => {
                let (kind, i, params, change) = if let Some((i, a)) = self
                    .p()
                    .actions
                    .iter()
                    .enumerate()
                    .find(|(_, a)| &a.name == n)
                {
                    (1, i, a.params.clone(), a.kind == ActionKind::Change && matches!(a.result,Type::Result(..)))
                } else {
                    let (i, f) = self
                        .p()
                        .functions
                        .iter()
                        .enumerate()
                        .find(|(_, f)| &f.name == n)
                        .ok_or("call target")?;
                    (0, i, f.params.clone(), false)
                };
                let vals = args
                    .iter()
                    .zip(&params)
                    .map(|(e, (_, t))| self.expr(e, env, Some(t)))
                    .collect::<LangResult<Vec<_>>>()?;
                self.call(kind, i, &vals, change)
            }
            Expr::Method(xs, n, args) if n == "drop" || n == "take" => {
                let xs = self.expr(xs, env, Some(&t))?;
                let count = self.expr(&args[0], env, Some(&Type::U32))?;
                self.op(&format!("list_{n}"), &[xs, count])
            }
            Expr::Method(xs, n, args) => self.method(xs, n, args, env, &t)?,
            _ => return Err("expression outside checked executable language".into()),
        })
    }
    fn call(&mut self, kind: u32, index: usize, args: &[String], change: bool) -> String {
        let v = self.fresh();
        let array = if args.is_empty() {
            "NULL".into()
        } else {
            format!("(uint64_t[]){{{}}}", args.join(","))
        };
        self.line(format!("uint64_t {v}=ink_program_call(ctx,{kind},{index},{array},{});if(ink_failed(ctx))return 0;",args.len()));
        if change {
            self.op("nested_change", &[v])
        } else {
            v
        }
    }
    fn item(&mut self, xs: &str, index: &str) -> String {
        let v = self.fresh();
        self.line(format!(
            "uint64_t {v}=ink_item(ctx,{xs},{index});if(ink_failed(ctx))return 0;"
        ));
        v
    }
    fn method(
        &mut self,
        xs: &Expr,
        n: &str,
        args: &[Expr],
        env: &Env,
        t: &Type,
    ) -> LangResult<String> {
        let xt = self.infer(xs, env, None)?;
        if let Type::Table(kt, vt) = &xt {
            let Expr::Var(root) = xs else {
                return Err("table root".into());
            };
            let i = self
                .p()
                .states
                .iter()
                .position(|d| &d.name == root)
                .ok_or("state root")?;
            if n=="sum_by" || n=="count_where" {
                let keys=self.op(&format!("table:{i}:keys"),&[]);
                let frame=self.fresh();self.line(format!("uint64_t {frame}=ink_value_frame(ctx);"));
                let out=self.literal(Self::kind(t),0,"");let index=self.fresh();
                self.line(format!("for(size_t {index}=0;{index}<ink_length(ctx,{keys});{index}++){{if(!ink_tick(ctx))return 0;"));
                let key=self.item(&keys,&index);
                let item=self.op(&format!("table:{i}:scan_get"),&[key]);
                let body=self.lambda(&args[0],env,vec![(item,vt.as_ref().clone())],if n=="count_where" {&Type::Bool}else{t})?;
                if n=="count_where" {self.line(format!("if(ink_bool(ctx,{body})){{"));let one=self.literal(Self::kind(t),1,"");let add=self.op("+",&[out.clone(),one]);self.line(format!("{out}={add};}}"));}
                else {let add=self.op("+",&[out.clone(),body]);self.line(format!("{out}={add};"));}
                self.line(format!("{out}=ink_value_finish_frame(ctx,{frame},{out});if(ink_failed(ctx))return 0;"));
                self.line("}");return Ok(out);
            }
            if n=="shared_keys" {
                let Expr::Var(other)=&args[0] else{return Err("shared_keys root".into());};
                let j=self.p().states.iter().position(|s| &s.name==other).ok_or("shared_keys table")?;
                return Ok(self.op(&format!("table:{i}:intersect_table:{j}"),&[]));
            }
            let vals = args
                .iter()
                .enumerate()
                .map(|(i, e)| self.expr(e, env, Some(&ink_core::table_argument(n, i, &kt, &vt))))
                .collect::<LangResult<Vec<_>>>()?;
            return Ok(self.op(&format!("table:{i}:{n}"), &vals));
        }
        let value = self.expr(xs, env, None)?;
        if n == "fold" && matches!(xt, Type::Option(_) | Type::Result(..)) {
            let (a, b, tag) = match &xt {
                Type::Option(a) => (a.as_ref().clone(), Type::Unit, "Some"),
                Type::Result(a, b) => (a.as_ref().clone(), b.as_ref().clone(), "Ok"),
                _ => unreachable!(),
            };
            let wanted = self.op(&format!("tag:{tag}"), &[value.clone()]);
            let out = self.fresh();
            self.line(format!("uint64_t {out}=0;if(ink_bool(ctx,{wanted})){{"));
            let item = self.op("unwrap", &[value.clone()]);
            let body = self.lambda(&args[0], env, vec![(item, a)], t)?;
            self.line(format!("{out}={body};}}else{{"));
            let item = if matches!(xt, Type::Option(_)) {
                self.literal(0, 0, "")
            } else {
                self.op("unwrap", &[value])
            };
            let body = self.lambda(&args[1], env, vec![(item, b)], t)?;
            self.line(format!("{out}={body};}}"));
            return Ok(out);
        } else if n == "unwrap_or" {
            let fallback = self.expr(&args[0], env, Some(t))?;
            let present = self.op("tag:Some", &[value.clone()]);
            let out = self.fresh();
            self.line(format!("uint64_t {out}={fallback};if(ink_bool(ctx,{present})){{"));
            let inner = self.op("unwrap", &[value]);
            self.line(format!("{out}={inner};}}"));
            return Ok(out);
        }
        if n == "ok_or" {
            let error = self.expr(&args[0], env, None)?;
            return Ok(self.op("ok_or", &[value, error]));
        }
        let Type::List(inner) = &xt else {
            let (inner, tag) = match (&xt, n) {
                (Type::Option(t), "map") => (*t.clone(), "Some"),
                (Type::Result(a, _), "map") => (*a.clone(), "Ok"),
                (Type::Result(_, b), "map_err") => (*b.clone(), "Err"),
                _ => return Err("method receiver".into()),
            };
            let wanted = self.op(&format!("tag:{tag}"), &[value.clone()]);
            let out = self.fresh();
            self.line(format!(
                "uint64_t {out}={value};if(ink_bool(ctx,{wanted})){{"
            ));
            let item = self.op("unwrap", &[value]);
            let result = match t {
                Type::Option(t) => &**t,
                Type::Result(a, b) => {
                    if n == "map_err" {
                        &**b
                    } else {
                        &**a
                    }
                }
                _ => return Err("map output".into()),
            };
            let body = self.lambda(&args[0], env, vec![(item, inner)], result)?;
            let wrapped = self.op(tag, &[body]);
            self.line(format!("{out}={wrapped};}}"));
            return Ok(out);
        };
        if n == "concat" {
            // Both complete operands precede construction. The value ABI
            // handles every admitted element carrier, including nested values.
            let right = self.expr(&args[0], env, Some(&xt))?;
            let out = self.op("list", &[]);
            for input in [&value, &right] {
                let len = self.fresh();
                let i = self.fresh();
                self.line(format!("size_t {len}=ink_length(ctx,{input});"));
                self.line(format!(
                    "for(size_t {i}=0;{i}<{len};{i}++){{if(!ink_tick(ctx))return 0;"
                ));
                let item = self.item(input, &i);
                self.line(format!(
                    "ink_append(ctx,{out},{item});if(ink_failed(ctx))return 0;}}"
                ));
            }
            return Ok(out);
        }
        if n == "sort" {
            return Ok(self.op("sort", &[value]));
        }
        if n == "at_or" {
            let index = self.expr(&args[0], env, Some(&Type::U32))?;
            let out = self.fresh();
            self.line(format!(
                "uint64_t {out};if(ink_u32(ctx,{index})<ink_length(ctx,{value})){{"
            ));
            let item = self.item(&value, &format!("ink_u32(ctx,{index})"));
            self.line(format!("{out}={item};}}else{{"));
            let fallback = self.expr(&args[1], env, Some(t))?;
            self.line(format!("{out}={fallback};}}"));
            return Ok(out);
        }
        let other = if n == "zip" {
            Some(self.expr(&args[0], env, None)?)
        } else {
            None
        };
        let out = self.op("list", &[]);
        let i = self.fresh();
        let len = self.fresh();
        self.line(format!("size_t {len}=ink_length(ctx,{value});"));
        if let Some(o) = &other {
            self.line(format!(
                "if(ink_length(ctx,{o})<{len}){len}=ink_length(ctx,{o});"
            ))
        }
        let scan = if n == "scan" {
            Some(self.literal(Self::kind(inner), 0, ""))
        } else {
            None
        };
        self.line(format!(
            "for(size_t {i}=0;{i}<{len};{i}++){{if(!ink_tick(ctx))return 0;"
        ));
        let item = self.item(&value, &i);
        let body = match n {
            "scan" => {
                let acc = scan.as_ref().unwrap();
                let add = self.op("+", &[acc.clone(), item]);
                self.line(format!("{acc}={add};"));
                acc.clone()
            }
            "map" | "filter" => {
                let result = if n == "filter" {
                    &Type::Bool
                } else {
                    let Type::List(out) = t else {
                        return Err("map output".into());
                    };
                    &**out
                };
                let body =
                    self.lambda(&args[0], env, vec![(item.clone(), *inner.clone())], result)?;
                if n == "filter" {
                    self.line(format!("if(ink_bool(ctx,{body})){{"));
                    item
                } else {
                    body
                }
            }
            "map_indexed" => {
                let index = self.fresh();
                self.line(format!(
                    "uint64_t {index}=ink_literal(ctx,{U32_KIND},{i},\"\",0);"
                ));
                let Type::List(result) = t else {
                    return Err("indexed output".into());
                };
                self.lambda(
                    &args[0],
                    env,
                    vec![(index, Type::U32), (item, *inner.clone())],
                    result,
                )?
            }
            "zip" => {
                let Type::List(ot) = self.infer(&args[0], env, None)? else {
                    return Err("zip type".into());
                };
                let other = self.item(other.as_ref().unwrap(), &i);
                let Type::List(result) = t else {
                    return Err("zip output".into());
                };
                self.lambda(
                    &args[1],
                    env,
                    vec![(item, *inner.clone()), (other, *ot)],
                    result,
                )?
            }
            _ => return Err(format!("unsupported collection operation {n}")),
        };
        self.line(format!(
            "ink_append(ctx,{out},{body});if(ink_failed(ctx))return 0;"
        ));
        if n == "filter" {
            self.line("}")
        };
        self.line("}");
        Ok(out)
    }
    fn block(&mut self, body: &[Statement], env: &mut Env, result: &Type) -> LangResult<()> {
        for s in body {
            self.line("if(!ink_tick(ctx))return 0;");
            match s {
                Statement::Let(n, annotation, e) => {
                    let t = self.infer(e, env, annotation.as_ref())?;
                    let v = self.expr(e, env, Some(&t))?;
                    env.insert(n.clone(), (v, t));
                }
                Statement::Return(e) => {
                    let v = self.expr(e, env, Some(result))?;
                    self.line(format!("return {v};"));
                }
                Statement::Expr(e) => {
                    self.expr(e, env, None)?;
                }
                Statement::Emit(n, e) => {
                    let et = self.p().events[n].clone();
                    let v = self.expr(e, env, Some(&et))?;
                    self.op(&format!("emit:{n}"), &[v]);
                }
                Statement::If(e, a, b) => {
                    let v = self.expr(e, env, Some(&Type::Bool))?;
                    self.line(format!("if(ink_bool(ctx,{v})){{"));
                    self.block(a, &mut env.clone(), result)?;
                    self.line("}else{");
                    self.block(b, &mut env.clone(), result)?;
                    self.line("}");
                }
            }
        }
        Ok(())
    }
}
pub fn lower(module: &CheckedModule) -> LangResult<Emission> {
    let layout = ink_core::snapshot::layout(module.program())?;
    lower_with_layout(module, &layout)
}
pub fn lower_planned(plan: &ink_core::planning::CheckedPlan) -> LangResult<Emission> {
    let layout=ink_core::snapshot::layout(plan.original().program())?;
    let mut emission=lower_with_layout(plan.module(),&layout)?;
    emission.metadata["compiled_plan"]=serde_json::json!({"source":plan.original().identity()?,"plan":ink_core::registry::identity(plan.package())?});
    Ok(emission)
}
/// Preserve the checked original snapshot namespace while emitting selected code.
pub fn lower_selected(selected: &ink_core::optimisation::CheckedSelection) -> LangResult<Emission> {
    let layout = ink_core::snapshot::selected_layout(selected)?;
    let mut emission = lower_with_layout(selected.module(), &layout)?;
    emission.metadata["selection"] =
        serde_json::to_value(selected.evidence()).map_err(|e| e.to_string())?;
    Ok(emission)
}
fn lower_with_layout(
    module: &CheckedModule,
    layout: &ink_core::snapshot_wire::Layout,
) -> LangResult<Emission> {
    let p = module.program();
    let execution = ink_core::action_ir::CheckedActions::elaborate(module)?.execution()?;
    let mut e = Emitter {
        module,
        next: 0,
        lines: ink_abi::VALUES_C_HEADER.into(),
        state: false,
        callbacks: Vec::new(),
        execution: &execution,
    };
    let decls = p
        .functions
        .iter()
        .enumerate()
        .map(|(i, f)| (format!("pure{i}"), f.params.len()))
        .chain(
            p.actions
                .iter()
                .enumerate()
                .map(|(i, a)| (format!("action{i}"), a.params.len())),
        )
        .chain(
            p.keeps
                .iter()
                .enumerate()
                .map(|(i, _)| (format!("keep{i}"), 0)),
        )
        .collect::<Vec<_>>();
    for (n, count) in decls {
        e.line(format!(
            "static uint64_t {n}(InkContext*ctx{});",
            (0..count)
                .map(|i| format!(",uint64_t a{i}"))
                .collect::<String>()
        ));
    }
    for (i, f) in p.functions.iter().enumerate() {
        e.state = false;
        let env = f
            .params
            .iter()
            .enumerate()
            .map(|(i, (n, t))| (n.clone(), (format!("a{i}"), t.clone())))
            .collect();
        e.line(format!(
            "static uint64_t pure{i}(InkContext*ctx{}){{if(!ink_tick(ctx))return 0;",
            (0..f.params.len())
                .map(|i| format!(",uint64_t a{i}"))
                .collect::<String>()
        ));
        if ink_core::recursion::recursive(f) {
            e.line("for(;;){if(!ink_tick(ctx))return 0;");
            e.tail(&f.body, &env, f)?;
            e.line("}}");
        } else {
            let body = e.expr(&f.body, &env, Some(&f.result))?;
            e.line(format!("return {body};}}"));
        }
    }
    e.state = true;
    for (i, k) in execution.keeps().iter().enumerate() {
        e.line(format!(
            "static uint64_t keep{i}(InkContext*ctx){{if(!ink_tick(ctx))return 0;"
        ));
        let body = e.expr(&k.value, &Env::new(), Some(&k.ty))?;
        e.line(format!("return {body};}}"));
    }
    for (i, a) in execution.actions().iter().enumerate() {
        let mut env = a
            .params
            .iter()
            .enumerate()
            .map(|(i, (n, t))| (n.clone(), (format!("a{i}"), t.clone())))
            .collect();
        e.line(format!(
            "static uint64_t action{i}(InkContext*ctx{}){{if(!ink_tick(ctx))return 0;",
            (0..a.params.len())
                .map(|i| format!(",uint64_t a{i}"))
                .collect::<String>()
        ));
        e.block(&a.body, &mut env, &a.result)?;
        e.line("return 0;}");
    }
    let mut declarations = String::new();
    for (name, body) in e.callbacks.clone() {
        declarations.push_str(&format!(
            "static uint64_t {name}(InkContext*,uint32_t,uint64_t,const uint64_t*);\n"
        ));
        e.line(body);
    }
    e.line("uint64_t ink_parallel_callback(InkContext*ctx,uint32_t callback,uint32_t index,uint64_t item,const uint64_t*captures){switch(callback){");
    for (name, _) in e.callbacks.clone() {
        e.line(format!(
            "case {}:return {name}(ctx,index,item,captures);",
            name.trim_start_matches("parallel_v")
        ));
    }
    e.line("default:return ink_error(ctx,\"unknown compiled parallel callback\");}}");
    let at = ink_abi::VALUES_C_HEADER.len();
    e.lines.insert_str(at, &declarations);
    e.line("uint64_t ink_program_call(InkContext*ctx,uint32_t kind,uint32_t index,const uint64_t*args,size_t length){switch(kind){");
    for (kind, decls) in [
        (
            0,
            p.functions
                .iter()
                .map(|f| f.params.len())
                .collect::<Vec<_>>(),
        ),
        (1, p.actions.iter().map(|a| a.params.len()).collect()),
        (2, p.keeps.iter().map(|_| 0).collect()),
    ] {
        e.line(format!("case {kind}:switch(index){{"));
        for (i, count) in decls.iter().enumerate() {
            let name = match kind {
                0 => "pure",
                1 => "action",
                _ => "keep",
            };
            e.line(format!("case {i}:if(length!={count})return ink_error(ctx,\"argument count mismatch\");{} {name}{i}(ctx{});",if kind==1||(kind==2&&matches!(p.keeps[i].ty,Type::Result(..))){"return ink_finish_action(ctx,"}else{"return"},(0..*count).map(|i|format!(",args[{i}]")).collect::<String>()).replace(");;", ");"));
            if kind == 1 || (kind == 2 && matches!(p.keeps[i].ty, Type::Result(..))) {
                // Close the finish-action call while keeping emitted action control flow literal.
                let last = e.lines.rfind(';').unwrap();
                e.lines.insert(last, ')');
            }
        }
        e.line("default:return ink_error(ctx,\"unknown function index\");}");
    }
    e.line("default:return ink_error(ctx,\"unknown call kind\");}}");
    let metadata = json!({"abi":ink_abi::VALUE_ABI,"core_sha256":module.identity()?,"records":p.records,"ids":p.ids,"enums":p.enums,"functions":p.functions.iter().map(|f|json!({"name":f.name,"precondition":p.contracts.precondition_checks.get(&f.name),"internal":ink_core::local_collections::owned(&f.result,p)||f.params.iter().any(|(_,t)|ink_core::local_collections::owned(t,p)),"params":f.params.iter().map(|(_,t)|t).collect::<Vec<_>>(),"result":f.result})).collect::<Vec<_>>(),"actions":p.actions.iter().map(|a|json!({"name":a.name,"precondition":p.contracts.precondition_checks.get(&a.name),"change":a.kind==ActionKind::Change,"params":a.params.iter().map(|(_,t)|t).collect::<Vec<_>>(),"result":a.result})).collect::<Vec<_>>(),"roots":p.states.iter().map(|d|json!({"name":d.name,"type":d.ty})).collect::<Vec<_>>(),"events":p.events,"snapshot_program":layout.program,"snapshot_schema":layout.schema,"invariant_checks":p.contracts.invariant_checks});
    Ok(Emission {
        c: e.lines,
        metadata,
    })
}
