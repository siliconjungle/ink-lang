import {StatefulModule} from "./program.wasm.state-wasm.mjs";
import {readArtifact} from "./program.wasm.initial-state.mjs";
let ready,initial;
const module=()=>ready??=readArtifact(new URL("./program.wasm",import.meta.url),{"bytes":613937,"file":"program.wasm","sha256":"4e1ee3b615b097cf31e0de8da0f620e67ad7d447652a0bfe969155948227e99d"}).then(bytes=>StatefulModule.instantiate(bytes));
const seed=()=>initial??=readArtifact(new URL("./program.wasm.initial.snapshot",import.meta.url),{"bytes":728,"file":"program.wasm.initial.snapshot","sha256":"17056d4d7d4b584f555a6695529f1b2a377a4b93e754c54fc6b9b2b4471e406e"});
export async function createState(){const [host,bytes]=await Promise.all([module(),seed()]);return host.restore(bytes);}
export async function restoreState(bytes){return (await module()).restore(bytes);}
