#[path="../../gpu/f1/native/src/lib.rs"] mod part1;
#[path="../../gpu/f2/native/src/lib.rs"] mod part2;
#[path="../../gpu/f3/native/src/lib.rs"] mod part3;
#[path="../../gpu/f4/native/src/lib.rs"] mod part4;
#[path="../../gpu/f5/native/src/lib.rs"] mod part5;

struct GpuEngines{part1:part1::Engine,part2:part2::Engine,part3:part3::Engine,part4:part4::Engine,part5:part5::Engine,}impl GpuEngines{fn new()->Self{Self{part1:part1::Engine::new(),part2:part2::Engine::new(),part3:part3::Engine::new(),part4:part4::Engine::new(),part5:part5::Engine::new(),}} fn call(&mut self,name:&str,args:&serde_json::Value,backend:&str,options:Option<&serde_json::Value>)->Result<serde_json::Value,String>{match name{"numeric"=>{if let Some(options)=options{self.part1.configure_selection(options.clone())?;}self.part1.call(name,args,part1::Backend::parse(backend)?) },
"__frozen_proposal_3"=>{if let Some(options)=options{self.part2.configure_selection(options.clone())?;}self.part2.call(name,args,part2::Backend::parse(backend)?) },
"__frozen_proposal_163"=>{if let Some(options)=options{self.part3.configure_selection(options.clone())?;}self.part3.call(name,args,part3::Backend::parse(backend)?) },
"__frozen_proposal_187"=>{if let Some(options)=options{self.part4.configure_selection(options.clone())?;}self.part4.call(name,args,part4::Backend::parse(backend)?) },
"__frozen_proposal_199"=>{if let Some(options)=options{self.part5.configure_selection(options.clone())?;}self.part5.call(name,args,part5::Backend::parse(backend)?) },
_=>Err("CPU-only function".into())}}}
include!("state-cli.rs");
fn run() -> Result<(), String> {
    let mut engines = GpuEngines::new();
    run_with_pure_initialized(compiled_state::initial_state,|state, step| {
        let name = step["pure"].as_str().ok_or("missing pure")?;
        let backend = step["backend"].as_str().unwrap_or("auto");
        if !["auto", "cpu", "gpu", "gpu-required"].contains(&backend) {
            return Err("invalid native backend".into());
        }
        if let Some(options)=step.get("selection") {
            ink_abi::selection::decide(options,&serde_json::json!({}),&["cpu".into()])?;
        }
        if backend == "cpu" {
            state
                .pure(name, &step["args"])
                .map(|v| serde_json::json!({"value":v,"backend":"cpu"}))
        } else {
            engines.call(name, &step["args"], backend, step.get("selection")).or_else(|e| {
                if backend=="gpu-required"{return Err(e);}
                state
                    .pure(name, &step["args"])
                    .map(|v| serde_json::json!({"value":v,"backend":"cpu","reason":e}))
            })
        }
    })
}
fn main() -> std::process::ExitCode {
    match run() {
        Ok(()) => std::process::ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("error: {e}");
            std::process::ExitCode::FAILURE
        }
    }
}
