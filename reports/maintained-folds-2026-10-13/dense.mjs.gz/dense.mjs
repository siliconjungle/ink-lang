const __compiledMaintained=(()=>{const __nullaryNodes=[];
function __nullaryNode(c){return __nullaryNodes[c]??=({c,a:[]});}
function __node(c,a){return a.length===0?__nullaryNode(c):{c,a};}
const __deepCall=Symbol('private direct-call depth');let __directDepth=0;
function __run(call){const stack=[call];let result;while(stack.length){const frame=stack[stack.length-1],step=frame.next(result);if(step.done){result=step.value;stack.pop();}else{result=undefined;stack.push(step.value);}}return result;}
const __fpView=new DataView(new ArrayBuffer(4));
function __fpNumber(bits){__fpView.setUint32(0,Number(BigInt.asUintN(32,bits)),true);return __fpView.getFloat32(0,true);}
function __fpWord(op,a,b){
 if(op==='neg')return BigInt.asUintN(32,a)^2147483648n;
 const x=__fpNumber(a),y=__fpNumber(b);
 switch(op){case '==':return x===y;case '!=':return x!==y;case '<':return x<y;case '<=':return x<=y;case '>':return x>y;case '>=':return x>=y;}
 const value=op==='+'?x+y:op==='-'?x-y:op==='*'?x*y:undefined;
 if(value===undefined)throw Error('binary32 operator');if(Number.isNaN(value))return 2143289344n;__fpView.setFloat32(0,value,true);return BigInt(__fpView.getUint32(0,true));
}
function* d_050aa7b6d2b7a2157d6b76abdc418cfb76edc6dce0fb93cfcfdb29388447a6b5(a0){let v0;switch(a0.c){
case 0:{
const v2=__nullaryNode(0);
v0=v2;break;}
case 1:{
let v4;switch(a0.a[0].c){
case 0:{
v4=a0.a[0].a[1];break;}
default:throw Error('literal constructor projection');}
let v3;if(v4){
const v9=yield d_050aa7b6d2b7a2157d6b76abdc418cfb76edc6dce0fb93cfcfdb29388447a6b5(a0.a[1]);
const v7=__node(1,[a0.a[0],v9]);
v3=v7;}else{
const v11=yield d_050aa7b6d2b7a2157d6b76abdc418cfb76edc6dce0fb93cfcfdb29388447a6b5(a0.a[1]);
v3=v11;}
v0=v3;break;}
default:throw Error('literal constructor projection');}
return v0;}
function* d_22b2265e43aaccee69c6998e928b876d221b7a6a2debfb1348d9944245bb271e(a0){let v13;switch(a0.c){
case 0:{
const v15=0n;
v13=v15;break;}
case 1:{
const v17=d_e521309e69210a8141a1771a77e9f64f67ad809275b3e4a4d53c17159475beda(a0.a[0],a0.a[1]);
const v20=yield d_22b2265e43aaccee69c6998e928b876d221b7a6a2debfb1348d9944245bb271e(a0.a[2]);
const v16=d_ff57d07d62477da2d6d3d2901fac59d5b35ced2b41bac696ab5e3ce2968e740f(v17,v20);
v13=v16;break;}
default:throw Error('literal constructor projection');}
return v13;}
function* d_2600d17cfde73d687e613d4c613bf379c009e8d886cae97ef5977e6b7964502d(a0){let v22;switch(a0.c){
case 0:{
const v24=0n;
v22=v24;break;}
case 1:{
const v26=d_747d01aea9858ff7fa878ca16219022287a9cfc3a0c84b910fb48754273baea3(a0.a[0],a0.a[1]);
const v29=yield d_2600d17cfde73d687e613d4c613bf379c009e8d886cae97ef5977e6b7964502d(a0.a[2]);
const v25=d_ff57d07d62477da2d6d3d2901fac59d5b35ced2b41bac696ab5e3ce2968e740f(v26,v29);
v22=v25;break;}
default:throw Error('literal constructor projection');}
return v22;}
function* d_28d30c99ac2346c788a97797035c9ea3256c999874bdb05a92bd22598d18f74e(a0,a1){let v36;switch(a0.c){
case 0:{
v36=a0.a[0];break;}
default:throw Error('literal constructor projection');}
const v35=yield d_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(v36);
const v34=yield d_42bcfc81973185a91de9b43cba4f132128c78eff440511b3c07e6a76e69f33e9(v35);
const v33=yield d_53c45dc029b1f468d468eb13abd3466ab99cfc87c65bca9f7ec70a03703b9b08(v34);
const v32=yield d_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(v33);
const v39=false;
const v42=__nullaryNode(0);
const v31=__node(0,[v32,v39,a1,a0,v42]);
return v31;}
function d_367f026719979baf5ec00654a45e182ee094a0e6e758dbdf32c3b07c482e27b0(a0){let v44;switch(a0.c){
case 0:{
v44=a0.a[1];break;}
default:throw Error('literal constructor projection');}
let v43;if(v44){
let v48;switch(a0.c){
case 0:{
v48=a0.a[0];break;}
default:throw Error('literal constructor projection');}
const v51=0n;
const v47=BigInt.asUintN(64,(v48)+(v51));
v43=v47;}else{
const v52=0n;
v43=v52;}
return v43;}
function* d_42bcfc81973185a91de9b43cba4f132128c78eff440511b3c07e6a76e69f33e9(a0){let v53;switch(a0.c){
case 0:{
const v55=__nullaryNode(0);
v53=v55;break;}
case 1:{
let v57;switch(a0.a[0].c){
case 0:{
v57=a0.a[0].a[1];break;}
default:throw Error('literal constructor projection');}
let v56;if(v57){
const v62=yield d_42bcfc81973185a91de9b43cba4f132128c78eff440511b3c07e6a76e69f33e9(a0.a[1]);
const v60=__node(1,[a0.a[0],v62]);
v56=v60;}else{
const v64=yield d_42bcfc81973185a91de9b43cba4f132128c78eff440511b3c07e6a76e69f33e9(a0.a[1]);
v56=v64;}
v53=v56;break;}
default:throw Error('literal constructor projection');}
return v53;}
function* d_53c45dc029b1f468d468eb13abd3466ab99cfc87c65bca9f7ec70a03703b9b08(a0){let v66;switch(a0.c){
case 0:{
const v68=__nullaryNode(0);
v66=v68;break;}
case 1:{
let v70;switch(a0.a[0].c){
case 0:{
v70=a0.a[0].a[0];break;}
default:throw Error('literal constructor projection');}
const v73=yield d_53c45dc029b1f468d468eb13abd3466ab99cfc87c65bca9f7ec70a03703b9b08(a0.a[1]);
const v69=__node(1,[v70,v73]);
v66=v69;break;}
default:throw Error('literal constructor projection');}
return v66;}
function d_747d01aea9858ff7fa878ca16219022287a9cfc3a0c84b910fb48754273baea3(a0,a1){const v75=d_b10beed7bdc0232ef2a9af6acc349665d8c8fe9ac5f9b127a9669029ce15c43f(a1);
return v75;}
function* d_80666f547b1443998122afc2b4c819f61effe761cddde60edc8bd7be8f57ab37(a0,a1){let v82;switch(a0.c){
case 0:{
v82=a0.a[0];break;}
default:throw Error('literal constructor projection');}
const v81=yield d_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(v82);
const v80=yield d_050aa7b6d2b7a2157d6b76abdc418cfb76edc6dce0fb93cfcfdb29388447a6b5(v81);
const v79=yield d_bd21e152bf3bbf21e059537b1e26cade022d9e6c7b057fe42c53b5685f1f5b5d(v80);
const v78=yield d_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(v79);
const v85=false;
const v88=__nullaryNode(0);
const v77=__node(0,[v78,v85,a1,a0,v88]);
return v77;}
function* d_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(a0){let v89;switch(a0.c){
case 0:{
const v91=__nullaryNode(0);
v89=v91;break;}
case 1:{
const v94=yield d_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(a0.a[2]);
const v92=__node(1,[a0.a[1],v94]);
v89=v92;break;}
default:throw Error('literal constructor projection');}
return v89;}
function d_b10beed7bdc0232ef2a9af6acc349665d8c8fe9ac5f9b127a9669029ce15c43f(a0){let v97;switch(a0.c){
case 0:{
v97=a0.a[1];break;}
default:throw Error('literal constructor projection');}
let v96;if(v97){
let v103;switch(a0.c){
case 0:{
v103=a0.a[0];break;}
default:throw Error('literal constructor projection');}
const v106=0n;
const v102=BigInt.asUintN(64,(v103)*(v106));
const v107=1n;
const v101=BigInt.asUintN(64,(v102)+(v107));
const v108=0n;
const v100=BigInt.asUintN(64,(v101)+(v108));
v96=v100;}else{
const v109=0n;
v96=v109;}
return v96;}
function* d_bd21e152bf3bbf21e059537b1e26cade022d9e6c7b057fe42c53b5685f1f5b5d(a0){let v110;switch(a0.c){
case 0:{
const v112=__nullaryNode(0);
v110=v112;break;}
case 1:{
let v116;switch(a0.a[0].c){
case 0:{
v116=a0.a[0].a[0];break;}
default:throw Error('literal constructor projection');}
const v119=0n;
const v115=BigInt.asUintN(64,(v116)*(v119));
const v120=1n;
const v114=BigInt.asUintN(64,(v115)+(v120));
const v121=yield d_bd21e152bf3bbf21e059537b1e26cade022d9e6c7b057fe42c53b5685f1f5b5d(a0.a[1]);
const v113=__node(1,[v114,v121]);
v110=v113;break;}
default:throw Error('literal constructor projection');}
return v110;}
function* d_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(a0){let v123;switch(a0.c){
case 0:{
const v125=0n;
v123=v125;break;}
case 1:{
const v128=yield d_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(a0.a[1]);
const v126=BigInt.asUintN(64,(a0.a[0])+(v128));
v123=v126;break;}
default:throw Error('literal constructor projection');}
return v123;}
function d_e3411065db075d990745a607b7daccebec79314f4b047b97dc7b4bb384db15a4(a0){const v131=0n;
const v130=BigInt.asUintN(64,(v131)-(a0));
return v130;}
function d_e521309e69210a8141a1771a77e9f64f67ad809275b3e4a4d53c17159475beda(a0,a1){const v133=d_367f026719979baf5ec00654a45e182ee094a0e6e758dbdf32c3b07c482e27b0(a1);
return v133;}
function d_ff57d07d62477da2d6d3d2901fac59d5b35ced2b41bac696ab5e3ce2968e740f(a0,a1){const v135=BigInt.asUintN(64,(a0)+(a1));
return v135;}
function dFast_050aa7b6d2b7a2157d6b76abdc418cfb76edc6dce0fb93cfcfdb29388447a6b5(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v0;switch(a0.c){
case 0:{
const v2=__nullaryNode(0);
v0=v2;break;}
case 1:{
let v4;switch(a0.a[0].c){
case 0:{
v4=a0.a[0].a[1];break;}
default:throw Error('literal constructor projection');}
let v3;if(v4){
const v9=dFast_050aa7b6d2b7a2157d6b76abdc418cfb76edc6dce0fb93cfcfdb29388447a6b5(a0.a[1]);
const v7=__node(1,[a0.a[0],v9]);
v3=v7;}else{
const v11=dFast_050aa7b6d2b7a2157d6b76abdc418cfb76edc6dce0fb93cfcfdb29388447a6b5(a0.a[1]);
v3=v11;}
v0=v3;break;}
default:throw Error('literal constructor projection');}
return v0;}finally{__directDepth--;}}
function dFast_22b2265e43aaccee69c6998e928b876d221b7a6a2debfb1348d9944245bb271e(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v13;switch(a0.c){
case 0:{
const v15=0n;
v13=v15;break;}
case 1:{
const v17=d_e521309e69210a8141a1771a77e9f64f67ad809275b3e4a4d53c17159475beda(a0.a[0],a0.a[1]);
const v20=dFast_22b2265e43aaccee69c6998e928b876d221b7a6a2debfb1348d9944245bb271e(a0.a[2]);
const v16=d_ff57d07d62477da2d6d3d2901fac59d5b35ced2b41bac696ab5e3ce2968e740f(v17,v20);
v13=v16;break;}
default:throw Error('literal constructor projection');}
return v13;}finally{__directDepth--;}}
function dFast_2600d17cfde73d687e613d4c613bf379c009e8d886cae97ef5977e6b7964502d(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v22;switch(a0.c){
case 0:{
const v24=0n;
v22=v24;break;}
case 1:{
const v26=d_747d01aea9858ff7fa878ca16219022287a9cfc3a0c84b910fb48754273baea3(a0.a[0],a0.a[1]);
const v29=dFast_2600d17cfde73d687e613d4c613bf379c009e8d886cae97ef5977e6b7964502d(a0.a[2]);
const v25=d_ff57d07d62477da2d6d3d2901fac59d5b35ced2b41bac696ab5e3ce2968e740f(v26,v29);
v22=v25;break;}
default:throw Error('literal constructor projection');}
return v22;}finally{__directDepth--;}}
function dFast_28d30c99ac2346c788a97797035c9ea3256c999874bdb05a92bd22598d18f74e(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v36;switch(a0.c){
case 0:{
v36=a0.a[0];break;}
default:throw Error('literal constructor projection');}
const v35=dFast_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(v36);
const v34=dFast_42bcfc81973185a91de9b43cba4f132128c78eff440511b3c07e6a76e69f33e9(v35);
const v33=dFast_53c45dc029b1f468d468eb13abd3466ab99cfc87c65bca9f7ec70a03703b9b08(v34);
const v32=dFast_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(v33);
const v39=false;
const v42=__nullaryNode(0);
const v31=__node(0,[v32,v39,a1,a0,v42]);
return v31;}finally{__directDepth--;}}
function dFast_42bcfc81973185a91de9b43cba4f132128c78eff440511b3c07e6a76e69f33e9(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v43;switch(a0.c){
case 0:{
const v45=__nullaryNode(0);
v43=v45;break;}
case 1:{
let v47;switch(a0.a[0].c){
case 0:{
v47=a0.a[0].a[1];break;}
default:throw Error('literal constructor projection');}
let v46;if(v47){
const v52=dFast_42bcfc81973185a91de9b43cba4f132128c78eff440511b3c07e6a76e69f33e9(a0.a[1]);
const v50=__node(1,[a0.a[0],v52]);
v46=v50;}else{
const v54=dFast_42bcfc81973185a91de9b43cba4f132128c78eff440511b3c07e6a76e69f33e9(a0.a[1]);
v46=v54;}
v43=v46;break;}
default:throw Error('literal constructor projection');}
return v43;}finally{__directDepth--;}}
function dFast_53c45dc029b1f468d468eb13abd3466ab99cfc87c65bca9f7ec70a03703b9b08(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v56;switch(a0.c){
case 0:{
const v58=__nullaryNode(0);
v56=v58;break;}
case 1:{
let v60;switch(a0.a[0].c){
case 0:{
v60=a0.a[0].a[0];break;}
default:throw Error('literal constructor projection');}
const v63=dFast_53c45dc029b1f468d468eb13abd3466ab99cfc87c65bca9f7ec70a03703b9b08(a0.a[1]);
const v59=__node(1,[v60,v63]);
v56=v59;break;}
default:throw Error('literal constructor projection');}
return v56;}finally{__directDepth--;}}
function dFast_80666f547b1443998122afc2b4c819f61effe761cddde60edc8bd7be8f57ab37(a0,a1){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v70;switch(a0.c){
case 0:{
v70=a0.a[0];break;}
default:throw Error('literal constructor projection');}
const v69=dFast_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(v70);
const v68=dFast_050aa7b6d2b7a2157d6b76abdc418cfb76edc6dce0fb93cfcfdb29388447a6b5(v69);
const v67=dFast_bd21e152bf3bbf21e059537b1e26cade022d9e6c7b057fe42c53b5685f1f5b5d(v68);
const v66=dFast_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(v67);
const v73=false;
const v76=__nullaryNode(0);
const v65=__node(0,[v66,v73,a1,a0,v76]);
return v65;}finally{__directDepth--;}}
function dFast_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v77;switch(a0.c){
case 0:{
const v79=__nullaryNode(0);
v77=v79;break;}
case 1:{
const v82=dFast_860856c66fc035defeb18a36b37c55c658790c951fb1e274c3501374069fd590(a0.a[2]);
const v80=__node(1,[a0.a[1],v82]);
v77=v80;break;}
default:throw Error('literal constructor projection');}
return v77;}finally{__directDepth--;}}
function dFast_bd21e152bf3bbf21e059537b1e26cade022d9e6c7b057fe42c53b5685f1f5b5d(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v84;switch(a0.c){
case 0:{
const v86=__nullaryNode(0);
v84=v86;break;}
case 1:{
let v90;switch(a0.a[0].c){
case 0:{
v90=a0.a[0].a[0];break;}
default:throw Error('literal constructor projection');}
const v93=0n;
const v89=BigInt.asUintN(64,(v90)*(v93));
const v94=1n;
const v88=BigInt.asUintN(64,(v89)+(v94));
const v95=dFast_bd21e152bf3bbf21e059537b1e26cade022d9e6c7b057fe42c53b5685f1f5b5d(a0.a[1]);
const v87=__node(1,[v88,v95]);
v84=v87;break;}
default:throw Error('literal constructor projection');}
return v84;}finally{__directDepth--;}}
function dFast_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(a0){if(__directDepth>=128)throw __deepCall;__directDepth++;try{let v97;switch(a0.c){
case 0:{
const v99=0n;
v97=v99;break;}
case 1:{
const v102=dFast_e2ca0264984b8a85a7ce10e263b78fe652a2ad6d9b73eec70267b0b27cedf63b(a0.a[1]);
const v100=BigInt.asUintN(64,(a0.a[0])+(v102));
v97=v100;break;}
default:throw Error('literal constructor projection');}
return v97;}finally{__directDepth--;}}
function f_22b2265e43aaccee69c6998e928b876d221b7a6a2debfb1348d9944245bb271e(a0){try{return dFast_22b2265e43aaccee69c6998e928b876d221b7a6a2debfb1348d9944245bb271e(a0);}catch(error){if(error!==__deepCall)throw error;return __run(d_22b2265e43aaccee69c6998e928b876d221b7a6a2debfb1348d9944245bb271e(a0));}}
function f_2600d17cfde73d687e613d4c613bf379c009e8d886cae97ef5977e6b7964502d(a0){try{return dFast_2600d17cfde73d687e613d4c613bf379c009e8d886cae97ef5977e6b7964502d(a0);}catch(error){if(error!==__deepCall)throw error;return __run(d_2600d17cfde73d687e613d4c613bf379c009e8d886cae97ef5977e6b7964502d(a0));}}
function f_28d30c99ac2346c788a97797035c9ea3256c999874bdb05a92bd22598d18f74e(a0,a1){try{return dFast_28d30c99ac2346c788a97797035c9ea3256c999874bdb05a92bd22598d18f74e(a0,a1);}catch(error){if(error!==__deepCall)throw error;return __run(d_28d30c99ac2346c788a97797035c9ea3256c999874bdb05a92bd22598d18f74e(a0,a1));}}
function f_747d01aea9858ff7fa878ca16219022287a9cfc3a0c84b910fb48754273baea3(a0,a1){return d_747d01aea9858ff7fa878ca16219022287a9cfc3a0c84b910fb48754273baea3(a0,a1);}
function f_80666f547b1443998122afc2b4c819f61effe761cddde60edc8bd7be8f57ab37(a0,a1){try{return dFast_80666f547b1443998122afc2b4c819f61effe761cddde60edc8bd7be8f57ab37(a0,a1);}catch(error){if(error!==__deepCall)throw error;return __run(d_80666f547b1443998122afc2b4c819f61effe761cddde60edc8bd7be8f57ab37(a0,a1));}}
function f_e3411065db075d990745a607b7daccebec79314f4b047b97dc7b4bb384db15a4(a0){return d_e3411065db075d990745a607b7daccebec79314f4b047b97dc7b4bb384db15a4(a0);}
function f_e521309e69210a8141a1771a77e9f64f67ad809275b3e4a4d53c17159475beda(a0,a1){return d_e521309e69210a8141a1771a77e9f64f67ad809275b3e4a4d53c17159475beda(a0,a1);}
function f_ff57d07d62477da2d6d3d2901fac59d5b35ced2b41bac696ab5e3ce2968e740f(a0,a1){return d_ff57d07d62477da2d6d3d2901fac59d5b35ced2b41bac696ab5e3ce2968e740f(a0,a1);}
const __encoder=new TextEncoder();
function read_0(v,d=0,internal=false){return v;}
function write_0(v,d=0,snapshot=false){return v;}
function read_1(v,d=0,internal=false){return v;}
function write_1(v,d=0,snapshot=false){return v;}
function read_2(v,d=0,internal=false){return __node(0,[]);}
function write_2(v,d=0,snapshot=false){return null;}
function read_3(v,d=0,internal=false){let tail=__node(0,[]);for(let i=v.length-1;i>=0;i--)tail=__node(1,[read_1(v[i],d+1,internal),tail]);return tail;}
function write_3(v,d=0,snapshot=false){let cursor=v;const xs=[];while(cursor.c!==0){xs.push(write_1(cursor.a[0],d+1,snapshot));cursor=cursor.a[1];}return xs;}
function read_4(v,d=0,internal=false){let tail=__node(0,[]);for(let i=v.length-1;i>=0;i--)tail=__node(1,[read_6(v[i],d+1,internal),tail]);return tail;}
function write_4(v,d=0,snapshot=false){let cursor=v;const xs=[];while(cursor.c!==0){xs.push(write_6(cursor.a[0],d+1,snapshot));cursor=cursor.a[1];}return xs;}
function read_5(v,d=0,internal=false){switch(v){case "Error.Failed":return __node(0,[]);default:return undefined;}}
function write_5(v,d=0,snapshot=false){return ["Error.Failed"][v.c];}
function read_6(v,d=0,internal=false){return __node(0,[read_1(v["value"],d+1,internal),read_0(v["active"],d+1,internal)]);}
function write_6(v,d=0,snapshot=false){return Object.fromEntries([["value",write_1(v.a[0],d+1,snapshot)],["active",write_0(v.a[1],d+1,snapshot)]]);}
function read_7(v,d=0,internal=false){if(Object.hasOwn(v,'Some'))return __node(1,[read_6(v.Some,d+1,internal)]);return __node(0,[]);}
function write_7(v,d=0,snapshot=false){return v.c===0?{None:null}:{Some:write_6(v.a[0],d+1,snapshot)};}
function read_8(v,d=0,internal=false){if(Object.hasOwn(v,'Ok'))return __node(0,[read_2(v.Ok,d+1,internal)]);return __node(1,[read_5(v.Err,d+1,internal)]);}
function write_8(v,d=0,snapshot=false){return v.c===0?{Ok:write_2(v.a[0],d+1,snapshot)}:{Err:write_5(v.a[0],d+1,snapshot)};}
const __maintainedViews=[
{root:0,keep:0,zero:0n,contribution:(key,row)=>f_e521309e69210a8141a1771a77e9f64f67ad809275b3e4a4d53c17159475beda(read_1(key,0,true),read_6(row,0,true)),combine:f_ff57d07d62477da2d6d3d2901fac59d5b35ced2b41bac696ab5e3ce2968e740f,inverse:f_e3411065db075d990745a607b7daccebec79314f4b047b97dc7b4bb384db15a4},
{root:0,keep:1,zero:0n,contribution:(key,row)=>f_747d01aea9858ff7fa878ca16219022287a9cfc3a0c84b910fb48754273baea3(read_1(key,0,true),read_6(row,0,true)),combine:f_ff57d07d62477da2d6d3d2901fac59d5b35ced2b41bac696ab5e3ce2968e740f,inverse:f_e3411065db075d990745a607b7daccebec79314f4b047b97dc7b4bb384db15a4},
];
return __maintainedViews;})();
// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output) {
  const convert=__representationRaw(type,output);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output) {
  switch (type.kind) {
    case 'ref': {
      let resolved;
      return (value,context)=>(resolved??=__representation(__namedTypes[type.name],output))(value,context);
    }
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output),err=__representation(type.error,output);
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f32': return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      const fields = type.fields.map(field => [field.name, __representation(field.type, output)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
function __stateWord(value){
 if(typeof value==='number'&&!Number.isSafeInteger(value))throw Error('u64 requires an exact integer');
 if(!['bigint','number','string'].includes(typeof value)||typeof value==='string'&&!/^(0|[1-9][0-9]*)$/.test(value))throw Error('invalid u64');
 const n=BigInt(value);if(n<0n||n>18446744073709551615n)throw Error('invalid u64');return n;
}
// Compile the capture traversal once. Each invocation still validates and owns
// every public container; no host value is retained between calls.
const __stateCaptures=new WeakMap();
function __stateCapture(type){
 const prior=__stateCaptures.get(type);if(prior)return prior;
 const capture=__compileStateCapture(type);__stateCaptures.set(type,capture);return capture;
}
function __compileStateCapture(type){
 const limited=copy=>(value,budget={cells:1000000},depth=0)=>{
  if(depth>64||--budget.cells<0)throw Error('state input resource limit');
  return copy(value,budget,depth);
 };
 const tagged=(value,tag)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
 switch(type.kind){
  case 'ref':{
   // Resolve lazily so recursive schemas compile to recursive validators rather
   // than reverting to descriptor interpretation at every referenced node.
   let resolved;
   return limited((value,budget,depth)=>(resolved??=__stateCapture(__namedTypes[type.name]))(value,budget,depth+1));
  }
  case 'u32':case 'i32':{
   const min=type.kind==='u32'?0:-2147483648,max=type.kind==='u32'?4294967295:2147483647;
   return limited(value=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;});
  }
  case 'u64':return limited(__stateWord);
  case 'bool':return limited(value=>{if(typeof value!=='boolean')throw Error('invalid Bool');return value;});
  case 'unit':return limited(value=>{if(value!==null)throw Error('invalid Unit');return null;});
  case 'string':return limited(value=>{if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;});
  case 'enum':return limited(value=>{if(!type.variants.includes(value))throw Error('invalid enum');return value;});
  case 'id':return limited(value=>{if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();});
  case 'list':case 'vector':{
   const item=__stateCapture(type.element),size=type.kind==='vector'?type.size:null;
   return limited((value,budget,depth)=>{
    if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
    if(size!==null&&value.length!==size)throw Error('invalid vector length');
    const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=item(value[i],budget,depth+1);return out;
   });
  }
  case 'record':{
   const fields=type.fields.map(f=>[f.name,__stateCapture(f.type)]);
   return limited((value,budget,depth)=>{
    if(!value||typeof value!=='object'||Array.isArray(value)||!fields.every(([name])=>Object.hasOwn(value,name)))throw Error('invalid record');
    const out={};for(const [name,copy]of fields){const field=copy(value[name],budget,depth+1);if(name==='__proto__')Object.defineProperty(out,name,{value:field,writable:true,enumerable:true,configurable:true});else out[name]=field;}return out;
   });
  }
  case 'option':{
   const item=__stateCapture(type.element);
   return limited((value,budget,depth)=>{if(tagged(value,'Some'))return {Some:item(value.Some,budget,depth+1)};if(tagged(value,'None')&&value.None===null)return {None:null};throw Error('invalid Option');});
  }
  case 'result':{
   const ok=__stateCapture(type.ok),err=__stateCapture(type.error);
   return limited((value,budget,depth)=>{if(tagged(value,'Ok'))return {Ok:ok(value.Ok,budget,depth+1)};if(tagged(value,'Err'))return {Err:err(value.Err,budget,depth+1)};throw Error('invalid Result');});
  }
  default:return (value,budget,depth)=>__stateInput(value,type,budget,depth);
 }
}
function __stateInput(value,type,budget={cells:1000000},depth=0){
  if(depth>64||--budget.cells<0)throw Error('state input resource limit');
  const input=(v,t)=>__stateInput(v,t,budget,depth+1);
  const integer=(min,max)=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;};
  const tagged=tag=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
  switch(type.kind){
    case 'ref':return input(value,__namedTypes[type.name]);
    case 'u32':return integer(0,4294967295);
    case 'i32':return integer(-2147483648,2147483647);
    case 'u64':return __stateWord(value);
    case 'int':{
      if(typeof value==='bigint')return value;
      if(!tagged('Int')||typeof value.Int!=='string'||!/^(-?[0-9]+)$/.test(value.Int))throw Error('invalid Int');return BigInt(value.Int);
    }
    case 'f32':{
      if(typeof value==='number'&&Number.isFinite(value)){const bits=__bits(value);if((bits&0x7fffffff)===0x7f800000)throw Error('f32 overflow requires F32Bits');return bits;}
      if(!tagged('F32Bits')||!Number.isInteger(value.F32Bits)||value.F32Bits<0||value.F32Bits>4294967295)throw Error('invalid f32');return value.F32Bits;
    }
    case 'bool':if(typeof value!=='boolean')throw Error('invalid Bool');return value;
    case 'unit':if(value!==null)throw Error('invalid Unit');return null;
    case 'string':if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;
    case 'id':if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();
    case 'enum':if(!type.variants.includes(value))throw Error('invalid enum');return value;
    case 'list':case 'vector':{
      if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
      if(type.kind==='vector'&&value.length!==type.size)throw Error('invalid vector length');
      return Array.from(value,v=>input(v,type.element));
    }
    case 'record':if(!value||typeof value!=='object'||Array.isArray(value)||!type.fields.every(f=>Object.hasOwn(value,f.name)))throw Error('invalid record');return Object.fromEntries(type.fields.map(f=>[f.name,input(value[f.name],f.type)]));
    case 'option':if(tagged('Some'))return {Some:input(value.Some,type.element)};if(tagged('None')&&value.None===null)return {None:null};throw Error('invalid Option');
    case 'result':if(tagged('Ok'))return {Ok:input(value.Ok,type.ok)};if(tagged('Err'))return {Err:input(value.Err,type.error)};throw Error('invalid Result');
    default:throw Error('unsupported public value type');
  }
}
// Mutable host replies must not retain references into compiled state or its outbox.
// State results must own mutable containers. Compile the declared schema once:
// scalars need no structured clone, while nested records/lists remain detached.
function __ownedResult(copy,nested){
 const owned=(value,context)=>{
  if(!context&&!nested)return copy(value,null);
  const memo=context||new WeakMap();
  if(memo.has(value))return memo.get(value);
  const result=copy(value,memo);memo.set(value,result);return result;
 };
 owned.container=true;return owned;
}
function __stateResult(type){
 switch(type.kind){
  case 'ref':{let resolved;const copy=(value,context)=>(resolved??=__stateResult(__namedTypes[type.name]))(value,context);copy.container=true;return copy;}
  case 'record':{const fields=type.fields.map(f=>[f.name,__stateResult(f.type)]);return __ownedResult((value,context)=>Object.fromEntries(fields.map(([name,copy])=>[name,copy(value[name],context)])),fields.some(([,copy])=>copy.container));}
  case 'list':case 'vector':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Array.from(value,item=>copy(item,context)),copy.container);}
  case 'option':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Object.hasOwn(value,'Some')?{Some:copy(value.Some,context)}:{None:null},copy.container);}
  case 'result':{const ok=__stateResult(type.ok),err=__stateResult(type.error);return __ownedResult((value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)},ok.container||err.container);}
  default:return __representation(type,true);
 }
}
function __stateOutput(value,type){return __stateResult(type)(value);}
const __u64 = n => BigInt.asUintN(64, n);
function __div(a, b, fallback, signed, remainder) {
  if (b === 0 || b === 0n || (signed && a === -2147483648 && b === -1)) return fallback();
  return typeof a === 'bigint' ? (remainder ? a % b : a / b) :
    ((remainder ? a % b : Math.trunc(a / b)) + 0); // integer zero has no sign
}
function __at(xs, index, fallback) { return index < xs.length ? xs[index] : fallback(); }
// Ordinary arrays retain the declared result element type when input is typed.
function __map(xs, fn) {
  const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = fn(xs[i], i);
  return out;
}
function __filter(xs, fn) {
  const out = [];
  for (let i = 0; i < xs.length; i++) if (fn(xs[i])) out.push(xs[i]);
  return out;
}
function __concat(xs, ys) {
  const left = xs.length, right = ys.length, out = new Array(left + right);
  for (let i = 0; i < left; i++) out[i] = xs[i];
  for (let i = 0; i < right; i++) out[left + i] = ys[i];
  return out;
}
function __zip(xs, ys, fn) {
  const n = Math.min(xs.length, ys.length), out = new Array(n);
  for (let i = 0; i < n; i++) out[i] = fn(xs[i], ys[i]);
  return out;
}
function __repeat(n, initial, fn) { let value = initial; for (let i = 0; i < n; i++) value = fn(i, value); return value; }
function __foldr(xs, initial, fn) { let value = initial; for (let i = xs.length - 1; i >= 0; i--) value = fn(xs[i], value); return value; }
function __scan(xs, zero, add) {
  let value = zero; const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = value = add(value, xs[i]);
  return out;
}
const __sort = xs => Array.from(xs).sort((a,b) => a < b ? -1 : a > b ? 1 : 0);
// Fixed word semantics, including arithmetic signed right shift. Shift and
// rotation counts wrap modulo width; no source-pattern optimisation lives here.
function __word(op,a,b,bits) {
  const width=BigInt(Math.abs(bits)), k=BigInt(b??0)%width;
  const x=BigInt(a), y=BigInt(b??0), unsigned=BigInt.asUintN(Number(width),x);
  let r;
  switch(op) {
    case 'word_not':r=~x;break;
    case 'word_and':r=x&y;break;
    case 'word_or':r=x|y;break;
    case 'word_xor':r=x^y;break;
    case 'wrapping_shl':r=x<<k;break;
    case 'wrapping_shr':r=x>>k;break;
    case 'rotate_left':r=(unsigned<<k)|(unsigned>>(width-k));break;
    case 'rotate_right':r=(unsigned>>k)|(unsigned<<(width-k));break;
    default:throw new Error('unknown word operation');
  }
  r=bits<0?BigInt.asIntN(Number(width),r):BigInt.asUintN(Number(width),r);
  return bits===64?r:Number(r);
}
const __namedTypes={"Row":{"fields":[{"name":"value","type":{"kind":"u64"}},{"name":"active","type":{"kind":"bool"}}],"kind":"record","name":"Row"}};
// Portable snapshot ABI shared with native/Wasm. Hashing uses Web Crypto.
function __snapshotLimits(limits={}){
 const result={bytes:64*1024*1024,values:1000000,depth:128,...limits};
 for(const k of ['bytes','values','depth'])if(!Number.isSafeInteger(result[k])||result[k]<0||result[k]>(k==='depth'?128:k==='values'?1000000:64*1024*1024))throw Error('invalid snapshot limits');
 return result;
}
const __hash=async bytes=>new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256',bytes));
function __snapshotWriter(limits){
 const out=[];let left=limits.values;
 function bytes(xs){if(xs.length>limits.bytes-out.length)throw Error('snapshot byte limit exceeded');for(const x of xs)out.push(x);}
 function integer(n,size){n=BigInt(n);for(let i=0;i<size;i++){bytes([Number(n&255n)]);n>>=8n;}}
 function raw(xs){integer(xs.length,8);bytes(xs);}
 function value(v,t,depth=0,bindings=[]){if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{value(v,t.body,depth+1,bindings);}finally{bindings.pop();}break;
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');value(v,bound[1],depth+1,bindings);break;}
  case 'unit':break;case 'bool':bytes([v?1:0]);break;
  case 'u32':case 'i32':case 'f32':integer(v,4);break;case 'u64':integer(v,8);break;
  case 'vector':if(v.length!==t.size)throw Error('vector dimension mismatch');for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'int':{let n=v<0n?-v:v;const xs=[];while(n){if(xs.length>=4096)throw Error('snapshot Int exceeds size limit');xs.push(Number(n&255n));n>>=8n;}bytes([v===0n?0:v>0n?1:2]);raw(xs);break;}
  case 'string':raw(__encoder.encode(v));break;
  case 'id':integer(BigInt('0x'+v),16);break;
  case 'enum':integer(t.variants.indexOf(v),4);break;
  case 'record':for(const f of t.fields)value(v[f.name],f.type,depth+1,bindings);break;
  case 'list':if(v.length>left)throw Error('snapshot value limit exceeded');integer(v.length,8);for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'option':if(Object.hasOwn(v,'Some')){bytes([1]);value(v.Some,t.element,depth+1,bindings);}else bytes([0]);break;
  case 'result':if(Object.hasOwn(v,'Ok')){bytes([0]);value(v.Ok,t.ok,depth+1,bindings);}else{bytes([1]);value(v.Err,t.error,depth+1,bindings);}break;
  default:throw Error('unsupported snapshot type');
 }}
 return {bytes,integer,raw,value,get left(){return left;},finish:()=>new Uint8Array(out)};
}
async function __snapshotEncode(meta,state,options){
 const limits=__snapshotLimits(options),w=__snapshotWriter(limits);
 w.integer(state.version,8);
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const rows=[...state.tables[r.index].entries()].sort((a,b)=>__keyCompare(a[0],b[0],r.key));if(rows.length>Math.floor(w.left/2))throw Error('snapshot row limit exceeded');w.integer(rows.length,8);for(const [k,v]of rows){w.value(k,r.snapshotKey??r.key);w.value(v,r.snapshotValue??r.value);}}
 w.integer(state.outbox.length,8);
 for(const e of state.outbox){const channel=meta.events.findIndex(t=>t.name===e.channel);w.integer(e.commit,8);w.integer(e.position,8);w.integer(channel,4);w.value(e.value,meta.events[channel].snapshotType??meta.events[channel].type);}
 const payload=w.finish(),header=__snapshotWriter(limits);header.bytes([86,76,83,84,65,84,69,0,1,0,1,0]);header.bytes(meta.snapshot.program);header.bytes(meta.snapshot.schema);header.integer(payload.length,8);header.bytes(payload);
 const bytes=header.finish();if(bytes.length+32>limits.bytes)throw Error('snapshot byte limit exceeded');const digest=await __hash(bytes);const result=new Uint8Array(bytes.length+32);result.set(bytes);result.set(digest,bytes.length);return result;
}
async function __snapshotDecode(meta,input,options){
 const limits=__snapshotLimits(options);
 if(!(input instanceof Uint8Array)&&!Array.isArray(input))throw Error('expected snapshot bytes');
 if(input.length>limits.bytes||input.length<116)throw Error('snapshot byte length invalid');
 if(Array.isArray(input)&&input.some(b=>!Number.isInteger(b)||b<0||b>255))throw Error('invalid snapshot bytes');
 const bytes=new Uint8Array(input); // capture before asynchronous integrity work
 function same(a,b){return a.length===b.length&&a.every((v,i)=>v===b[i]);}
 if(!same(bytes.subarray(0,12),[86,76,83,84,65,84,69,0,1,0,1,0]))throw Error('snapshot format or semantics version mismatch');
 if(!same(bytes.subarray(12,44),meta.snapshot.program)||!same(bytes.subarray(44,76),meta.snapshot.schema))throw Error('snapshot program or schema identity mismatch');
 const end=bytes.length-32,digest=await __hash(bytes.subarray(0,end));if(!same(digest,bytes.subarray(end)))throw Error('snapshot integrity check failed');
 let at=76,left=limits.values;
 function take(n){if(!Number.isSafeInteger(n)||n<0||n>end-at)throw Error('truncated snapshot');const x=bytes.subarray(at,at+n);at+=n;return x;}
 function integer(size){const xs=take(size);let n=0n;for(let i=size-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return n;}
 function length(){const n=integer(8);if(n>BigInt(Number.MAX_SAFE_INTEGER))throw Error('snapshot length not addressable');return Number(n);}
 function sequence(){const n=length();if(n>left)throw Error('snapshot value limit exceeded');return n;}
 function raw(){return take(length());}
 const n=length();if(n!==end-84)throw Error('snapshot payload length mismatch');
 function value(t,depth=0,bindings=[]){if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{return value(t.body,depth+1,bindings);}finally{bindings.pop();}
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');return value(bound[1],depth+1,bindings);}
  case 'unit':return null;case 'bool':{const b=take(1)[0];if(b>1)throw Error('invalid Bool tag');return b===1;}
  case 'u32':case 'f32':return Number(integer(4));case 'i32':return Number(BigInt.asIntN(32,integer(4)));case 'u64':return integer(8);
  case 'vector':{const xs=[];for(let i=0;i<t.size;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'int':{const sign=take(1)[0],xs=raw();if(xs.length>4096)throw Error('snapshot Int exceeds size limit');if(!((sign===0&&xs.length===0)||((sign===1||sign===2)&&xs.length>0&&xs[xs.length-1]!==0)))throw Error('noncanonical signed integer');let n=0n;for(let i=xs.length-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return sign===2?-n:n;}
  case 'string':return new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(raw());
  case 'id':return integer(16).toString(16).padStart(32,'0');
  case 'enum':{const i=Number(integer(4));if(i>=t.variants.length)throw Error('invalid enum tag');return t.variants[i];}
  case 'record':return Object.fromEntries(t.fields.map(f=>[f.name,value(f.type,depth+1,bindings)]));
  case 'list':{const n=sequence(),xs=[];for(let i=0;i<n;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'option':{const tag=take(1)[0];if(tag===0)return {None:null};if(tag===1)return {Some:value(t.element,depth+1,bindings)};throw Error('invalid Option tag');}
  case 'result':{const tag=take(1)[0];if(tag===0)return {Ok:value(t.ok,depth+1,bindings)};if(tag===1)return {Err:value(t.error,depth+1,bindings)};throw Error('invalid Result tag');}
  default:throw Error('unsupported snapshot type');
 }}
 const version=integer(8),tables=meta.roots.map(()=>new Map());
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const n=sequence();if(n>Math.floor(left/2))throw Error('snapshot row limit exceeded');let prior;for(let i=0;i<n;i++){const k=value(r.snapshotKey??r.key),v=value(r.snapshotValue??r.value);if(i&&__keyCompare(prior,k,r.key)>=0)throw Error('duplicate or unordered snapshot key');tables[r.index].set(k,v);prior=k;}}
 const count=sequence(),outbox=[];let prior;
 for(let i=0;i<count;i++){const commit=integer(8),position=integer(8),channel=Number(integer(4));if(!meta.events[channel])throw Error('unknown snapshot event channel');const v=value(meta.events[channel].snapshotType??meta.events[channel].type);if(commit===0n||commit>version||(prior&&(commit<prior.commit||(commit===prior.commit&&position<=prior.position))))throw Error('invalid snapshot event sequence');const e={commit,position,channel:meta.events[channel].name,value:v};outbox.push(e);prior=e;}
 if(at!==end)throw Error('trailing snapshot payload');return {version,tables,outbox};
}
// Fixed host subscription lifecycle. Dependencies come from checked effects;
// equality and ownership codecs are compiled from each query's result type.
function __createObservers(prepare){
 const subscriptions=new Map(),byRoot=new Map(),pending=new Set(),errors=[];
 let next=0,held=0,flushing=false;
 function report(s,error,phase){
  errors.push({query:s?.query??null,error,phase});
  if(s?.onError)try{s.onError(error);}catch(e){errors.push({query:s.query,error:e,phase:'error-handler'});}
 }
 function flush(){
  if(held||flushing||!pending.size)return;
  flushing=true;let passes=0;
  try{
   while(pending.size&&!held){
    if(++passes>1024){report(null,Error('subscription publication budget exhausted'),'publication');break;}
    const affected=new Set();
    for(const root of pending)for(const id of byRoot.get(root)||[])affected.add(id);
    pending.clear();const deliveries=[];
    // Evaluate all affected queries before calling any consumers.
    for(const id of affected){
     const s=subscriptions.get(id);if(!s)continue;
     try{const value=s.capture(s.read());if(!s.equal(s.value,value)){s.value=value;deliveries.push([s,value]);}}
     catch(e){report(s,e,'query');}
    }
    for(const [s,value]of deliveries)if(subscriptions.get(s.id)===s){
     try{s.callback(s.output(value));}catch(e){report(s,e,'listener');}
    }
   }
  }finally{flushing=false;}
 }
 return {
  get active(){return subscriptions.size!==0;},
  subscribe(query,args,callback,{immediate=true,onError}={}){
   if(typeof callback!=='function'||onError!==undefined&&typeof onError!=='function')throw TypeError('subscription callback');
   const q=prepare(query,args),s={...q,id:next++,query,callback,onError};
   s.value=s.capture(s.read());subscriptions.set(s.id,s);
   for(const root of s.roots){let ids=byRoot.get(root);if(!ids)byRoot.set(root,ids=new Set());ids.add(s.id);}
   const dispose=()=>{if(!subscriptions.delete(s.id))return;for(const root of s.roots){const ids=byRoot.get(root);ids.delete(s.id);if(!ids.size)byRoot.delete(root);}};
   if(immediate)try{callback(s.output(s.value));}catch(e){dispose();throw e;}
   return dispose;
  },
  commit(roots){if(!subscriptions.size)return;for(const root of roots)pending.add(root);flush();},
  hold(){held++;return new Set(pending);},
  release(){if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  rollback(mark){pending.clear();for(const root of mark)pending.add(root);if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  batch(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('batch callback must be synchronous');held++;
   try{const value=callback();if(value&&typeof value.then==='function')throw TypeError('state batch callback must be synchronous');return value;}
   finally{held--;flush();}
  },
  flush,
  takeErrors(){return errors.splice(0);}
 };
}
// CALLER CONTRACT: arguments must match declared types; malformed data may throw or corrupt state.
// Fixed state primitives used by emitted action bodies, without an AST evaluator.
class __Abort {constructor(value){this.value=value;}}
function __try(value){if(Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value.Ok;}
function __nested(value,change){if(change && Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value;}
function __equal(a,b){if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object')return false;const ak=Object.keys(a),bk=Object.keys(b);return ak.length===bk.length&&ak.every(k=>Object.hasOwn(b,k)&&__equal(a[k],b[k]));}
function __checked(op,a,b,bits){const x=BigInt(a),y=BigInt(b),n=op==='checked_add'?x+y:op==='checked_sub'?x-y:x*y;const min=bits===-32?-2147483648n:0n,max=bits===-32?2147483648n:1n<<BigInt(bits);return n<min||n>=max?{Err:'ArithmeticError.Overflow'}:{Ok:Math.abs(bits)===32?Number(n):n};}
function __okOr(value,error){return Object.hasOwn(value,'Some')?{Ok:value.Some}:{Err:error};}
function __mapValue(value,kind,method,fn){
 if(kind==='list')return value[method](fn);
 if(kind==='option')return Object.hasOwn(value,'Some')?{Some:fn(value.Some)}:{None:null};
 const tag=method==='map_err'?'Err':'Ok';return Object.hasOwn(value,tag)?{[tag]:fn(value[tag])}:value;
}
const __encoder=new TextEncoder();
function __tick(ctx){if(--ctx.fuel<0)throw Error('Ink state execution budget exhausted');}
function __keyCompare(a,b,type){
 if(type.kind==='string'){let i=0,j=0;while(i<a.length&&j<b.length){const x=a.codePointAt(i),y=b.codePointAt(j);if(x!==y)return x-y;i+=x>65535?2:1;j+=y>65535?2:1;}return (i<a.length?1:0)-(j<b.length?1:0);}
 return a<b?-1:a>b?1:0;
}
// A table's ordered key view is reused until membership changes. Values are
// fetched at traversal time, so replacement never leaves stale row payloads.
const __tableOrder=new WeakMap();
function __keyPosition(keys,key,type){let low=0,high=keys.length;while(low<high){const middle=(low+high)>>>1;if(__keyCompare(keys[middle],key,type)<0)low=middle+1;else high=middle;}return low;}
function __tableMembership(rt,index,key,present){
 const view=__tableOrder.get(rt.tables[index]);if(!view)return;
 const at=__keyPosition(view.keys,key,rt.meta.roots[index].key);
 if((at<view.keys.length&&view.keys[at]===key)===present)view.pending.delete(key);
 else view.pending.set(key,present);
}
function __orderedKeys(rt,index){
 const table=rt.tables[index],type=rt.meta.roots[index].key;let view=__tableOrder.get(table);
 if(!view){view={keys:[...table.keys()].sort((a,b)=>__keyCompare(a,b,type)),pending:new Map()};__tableOrder.set(table,view);}
 if(view.pending.size){
  const changes=[...view.pending.keys()].sort((a,b)=>__keyCompare(a,b,type)),merged=[];let i=0,j=0;
  while(i<view.keys.length||j<changes.length){
   if(j===changes.length||(i<view.keys.length&&__keyCompare(view.keys[i],changes[j],type)<0))merged.push(view.keys[i++]);
   else{const key=changes[j++];if(i<view.keys.length&&view.keys[i]===key)i++;if(view.pending.get(key))merged.push(key);}
  }
  view.keys=merged;view.pending.clear();
 }
 const keys=view.keys;
 const cell=rt.cell;
 if(cell&&cell.index===index&&table.has(cell.key)!==(cell.next!==undefined)){
  if(cell.next===undefined)return keys.filter(k=>k!==cell.key);
  return [...keys,cell.key].sort((a,b)=>__keyCompare(a,b,rt.meta.roots[index].key));
 }
 return keys;
}
function __cellGet(rt,index,key){const cell=rt.cell;return cell&&cell.index===index&&cell.key===key?cell.next:rt.tables[index].get(key);}
function __readTable(rt,index){const cell=rt.cell;if(!cell||cell.index!==index)return rt.tables[index];const table=new Map(rt.tables[index]);if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);return table;}
// The first before-image of each cell suffices for whole-transaction rollback.
function __remember(rt,index,key,present,value){if(rt.cellMode)return;if(!rt.seen[index].has(key)){rt.seen[index].add(key);rt.undo.push([index,key,present,value]);}}
// Only scalar keeps are retained. Reverse edges come from checked source effects.
// Before-images preserve cached values across failed actions; host rollback and
// restore discard caches rather than serializing them into logical snapshots.
function __invalidateKeeps(rt,index){
 if(rt.observers?.active)rt.changedRoots.add(index);
 if(!rt.keeps)return;
 for(const keep of rt.meta.keepInvalidations[index]){
  if(!rt.keepSeen.has(keep)){rt.keepSeen.add(keep);rt.keepBefore[keep]=rt.keeps[keep];rt.keepUndo.push(keep);}
  rt.keeps[keep]=undefined;
 }
}
function __restoreKeeps(rt){for(let i=rt.keepUndo.length-1;i>=0;i--){const keep=rt.keepUndo[i];rt.keeps[keep]=rt.keepBefore[keep];}}
function __rebuildViews(rt){
 for(const view of rt.views){let value=view.zero;for(const [key,row]of rt.tables[view.root])value=view.combine(value,view.contribution(key,row));rt.keeps[view.keep]=value;}
}
function __updateViews(rt,index,key,oldValue,newValue){
 if(rt.viewsByRoot[index].length===0)return null;
 const updates=rt.viewNext;
 for(const view of rt.viewsByRoot[index]){
  let value=rt.keeps[view.keep];
  if(oldValue!==undefined)value=view.combine(value,view.inverse(view.contribution(key,oldValue)));
  if(newValue!==undefined)value=view.combine(value,view.contribution(key,newValue));
  updates[view.keep]=value;
 }
 return updates;
}
function __installViews(rt,updates,index){if(updates)for(const view of rt.viewsByRoot[index])rt.keeps[view.keep]=updates[view.keep];}
function __writeCell(rt,index,key,next){if(rt.cellMode){if(rt.cell)throw Error('checked single-cell bound exceeded');rt.cell={index,key,next};}else{const table=rt.tables[index];if(table.has(key)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);if(next===undefined)table.delete(key);else table.set(key,next);}}
function __commitCell(rt){const cell=rt.cell;if(!cell)return;const table=rt.tables[cell.index];if(table.has(cell.key)!==(cell.next!==undefined))__tableMembership(rt,cell.index,cell.key,cell.next!==undefined);if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);rt.cell=null;}
class __DenseTable{
 constructor(capacity){this.limit=capacity;this.bigLimit=BigInt(capacity);this.dense=[];this.sparse=new Map();this.members=new Set();}
 slot(key){return (typeof key==='bigint'?key>=0n&&key<this.bigLimit:Number.isInteger(key)&&key>=0&&key<this.limit)?Number(key):-1;}
 get size(){return this.members.size;}
 get(key){const i=this.slot(key);return i<0?this.sparse.get(key):this.dense[i];}
 has(key){return this.get(key)!==undefined;}
 set(key,value){const i=this.slot(key);if(i<0)this.sparse.set(key,value);else this.dense[i]=value;this.members.add(key);return this;}
 delete(key){const i=this.slot(key);if(i<0)this.sparse.delete(key);else this.dense[i]=undefined;return this.members.delete(key);}
 keys(){return this.members.keys();}
 *values(){for(const key of this.members)yield this.get(key);}
 *entries(){for(const key of this.members)yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
function __newTables(meta,prefixes,old){return meta.roots.map((_,i)=>{const t=prefixes[i]?new __DenseTable(prefixes[i]):new Map();if(old)for(const [k,v]of old[i])t.set(k,v);return t;});}
function __cachedKeep(ctx,rt,index,compute){const prior=rt.keeps[index];if(prior!==undefined)return prior;const value=compute(ctx,rt);rt.keeps[index]=value;return value;}
function __table(rt,index,method,args){
 const key=args[0];
 if(method==='get'){const value=__cellGet(rt,index,key);return value===undefined?{None:null}:{Some:value};}
 if(method==='contains')return __cellGet(rt,index,key)!==undefined;
 const table=rt.tables[index];
 if(method==='values'||method==='keys'){const keys=__orderedKeys(rt,index);return method==='keys'?keys.slice():keys.map(k=>__cellGet(rt,index,k));}
 if(method==='intersect_table'){const current=__readTable(rt,index),other=__readTable(rt,args[0]),small=current.size<=other.size?current:other,large=small===current?other:current;const result=[];for(const k of small.keys())if(large.has(k))result.push(k);return result.sort((a,b)=>__keyCompare(a,b,rt.meta.roots[index].key));}
 if(method==='intersect_keys'){const selected=new Set(args[0]);return __orderedKeys(rt,index).filter(k=>selected.has(k));}
 if(method==='put_many'){const keys=args[0],values=args[1];if(keys.length!==values.length)return {Err:'table bulk length mismatch'};for(let i=0;i<keys.length;i++)__table(rt,index,'put',[keys[i],values[i]]);return {Ok:null};}
 if(method==='remove_many'){for(const k of args[0])__table(rt,index,'remove',[k]);return null;}
 // Checked table values never use undefined (Unit uses null), so one lookup
 // distinguishes absence without a second hash probe.
 if(method==='remove'){const value=table.get(key),present=value!==undefined;if(present){const updates=__updateViews(rt,index,key,value,undefined);__invalidateKeeps(rt,index);__remember(rt,index,key,true,value);__writeCell(rt,index,key,undefined);__installViews(rt,updates,index);}return present?{Some:value}:{None:null};}
 const prior=table.get(key),present=prior!==undefined;
 if(method==='insert'&&present)throw Error('insert key already present');
 if(method==='replace'&&!present)throw Error('replace key absent');
 if(present&&__stateRootEquals[index](prior,args[1]))return null;
 const updates=__updateViews(rt,index,key,prior,args[1]);
 __invalidateKeeps(rt,index);
 __remember(rt,index,key,present,prior);__writeCell(rt,index,key,args[1]);__installViews(rt,updates,index);return null;
}
function __rollback(rt,mark){for(let i=rt.undo.length-1;i>=mark;i--){const [index,key,present,value]=rt.undo[i];const table=rt.tables[index];if(table.has(key)!==present)__tableMembership(rt,index,key,present);if(present)table.set(key,value);else table.delete(key);}rt.undo.length=mark;}
function __createState(meta,implementations,captures=null,views=[],prefixes=[]){
 const rt={meta,tables:__newTables(meta,prefixes),version:0n,outbox:[],staged:[],busy:false,undo:[],seen:meta.roots.map(()=>new Set()),host:null,keeps:new Array(meta.keeps.length),keepUndo:[],keepSeen:new Set()};
 rt.views=views;rt.viewsByRoot=meta.roots.map((_,root)=>views.filter(v=>v.root===root));__rebuildViews(rt);
 rt.viewNext=new Array(meta.keeps.length);rt.cell=null;rt.cellMode=false;rt.ctx={fuel:100000000};
 rt.keepBefore=new Array(meta.keeps.length);
 rt.changedRoots=new Set();
 const actionMap=new Map(meta.actions.map(a=>[a.name,{...a,inputs:captures?captures[a.index]:a.params.map(p=>__stateCapture(p.type)),output:__stateResult(a.result)}]));
 const eventOutput=new Map(meta.events.map(e=>[e.name,__stateResult(e.type)]));
 const prepared=new WeakMap();
 const observers=rt.observers=__createObservers((name,args)=>{
  const a=actionMap.get(name);if(!a||a.change)throw Error('subscription requires a readonly query');
  const captured=a.inputs.map((convert,i)=>convert(args[i]));
  const publicArgs=captured.map((v,i)=>__stateResult(a.params[i].type)(v));
  return {roots:a.roots,read:()=>run(a,publicArgs,null,null,true),capture:__stateCapture(a.result),output:a.output,equal:__stateQueryEquals[a.index]};
 });
 function invoke(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);return run(a,args);}
 function read(a,args,inputs,output,resultOnly,owned=false){
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  rt.busy=true;
  try{const value=implementations[a.index](ctx,rt,...captured),result=a.freshResult?value:(output||a.output)(value);return resultOnly?result:{result,committed:false,version:rt.version,events:[]};}
  finally{rt.busy=false;}
 }
 function run(a,args,inputs=null,output=null,resultOnly=false,owned=false){
  if(!a.change)return read(a,args,inputs,output,resultOnly,owned);
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  const mark=rt.undo.length,version=rt.version,outbox=rt.outbox,outboxLength=rt.outbox.length;
  rt.busy=true;rt.cellMode=a.singleCell&&!rt.host;rt.staged.length=0;rt.changedRoots.clear();let successful=false;
  try{
   const value=implementations[a.index](ctx,rt,...captured);
   const result=a.freshResult?value:(output||a.output)(value);
   if(a.fallible && Object.hasOwn(value,'Err')){__rollback(rt,mark);__restoreKeeps(rt);if(rt.host?.strict)rt.host.failure=Object.assign(Error('transaction action failed'),{action:a.name,result});return resultOnly?result:{result,committed:false,version,events:[]};}
   if(version===18446744073709551615n)throw Error('commit sequence exhausted');
   const next=version+1n;
   const events=resultOnly?null:new Array(rt.staged.length);
   for(let i=0;i<rt.staged.length;i++){
    const [channel,value]=rt.staged[i],position=BigInt(i);
    rt.outbox.push({commit:next,position,channel,value});
    if(events)events[i]={commit:next,position,channel,value:eventOutput.get(channel)(value)};
   }
   __commitCell(rt);rt.version=next;
   successful=true;
   return resultOnly?result:{result,committed:true,version:next,events};
  }catch(e){__rollback(rt,mark);__restoreKeeps(rt);rt.version=version;rt.outbox=outbox;rt.outbox.length=outboxLength;if(rt.host?.strict)rt.host.failure=e;throw e;}
  finally{rt.cell=null;rt.cellMode=false;rt.staged.length=0;rt.busy=false;for(const keep of rt.keepUndo)rt.keepBefore[keep]=undefined;rt.keepUndo.length=0;rt.keepSeen.clear();for(const seen of rt.seen)seen.clear();if(!rt.host)rt.undo.length=0;if(successful)observers.commit(rt.changedRoots);}
 }
 return Object.freeze({
  subscribe(...args){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribe(...args);},
  batch:observers.batch,flushSubscriptions:observers.flush,takeSubscriptionErrors:observers.takeErrors,
  transaction(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('transaction callback must be synchronous');this.beginTransaction();rt.host.strict=true;
   try{const value=callback(this);if(value&&typeof value.then==='function')throw TypeError('state transaction callback must be synchronous');this.commitTransaction();return value;}catch(e){this.rollbackTransaction();throw e;}
  },
  invoke,invoke_json:invoke,
  prepare(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);const captured=a.inputs.map((convert,i)=>convert(args[i])),token=Object.freeze({});prepared.set(token,{action:a,args:captured});return token;},
  invokePrepared(token){const packet=prepared.get(token);if(!packet)throw Error('invalid prepared state call');return run(packet.action,packet.args,null,null,false,true);},
  // A prebound typed entrypoint: scalar arguments obey the native caller contract.
  // Composite arguments still capture owned input; events remain in the outbox.
  bind(name,{resultOnly=false}={}){
   const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);
   const inputs=a.params.map((p,i)=>['u32','i32','u64','bool','unit','string','f32','id','enum','int'].includes(p.type.kind)?__representation(p.type,false):a.inputs[i]);
   if(!a.change&&!a.precondition&&inputs.length===0)return ()=>{
    if(rt.busy)throw Error('state operation already in progress');rt.busy=true;const ctx=rt.ctx;ctx.fuel=100000000;
    try{const value=implementations[a.index](ctx,rt),result=a.freshResult?value:a.output(value);return resultOnly?result:{result,committed:false,version:rt.version,events:[]};}finally{rt.busy=false;}
   };
   return __stateBoundFactories[a.index](run,a,inputs,a.output,resultOnly);
  },
  beginTransaction(){if(rt.busy||rt.host||rt.undo.length)throw Error('transaction already in progress');rt.host={version:rt.version,outbox:rt.outbox,length:rt.outbox.length,keeps:rt.keeps.slice(),notificationMark:observers.hold()};return true;},
  commitTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');if(rt.host.failure)throw rt.host.failure;rt.host=null;rt.undo.length=0;observers.release();},
  rollbackTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');__rollback(rt,0);rt.version=rt.host.version;rt.outbox=rt.host.outbox;rt.outbox.length=rt.host.length;rt.keeps=rt.host.keeps;const mark=rt.host.notificationMark;rt.host=null;observers.rollback(mark);},
  get version(){return rt.version;},
  get outbox(){return rt.outbox.map(e=>({...e,value:eventOutput.get(e.channel)(e.value)}));},
  acknowledgeThrough(commit,position){if(rt.busy)throw Error('state operation already in progress');commit=__stateWord(commit);position=__stateWord(position);const last=rt.outbox.at(-1);if(!last)return;if(last.commit<commit||(last.commit===commit&&last.position<=position)){if(rt.host)rt.outbox=[];else rt.outbox.length=0;return;}rt.outbox=rt.outbox.filter(e=>e.commit>commit||(e.commit===commit&&e.position>position));},
  async invokeAsync(name,args){
   if(typeof __parallelInvokeAsync!=='function')return invoke(name,args);
   if(rt.busy||rt.host)throw Error('parallel state call requires transaction boundary');const captured=structuredClone(args);rt.busy=true;observers.hold();let completed=false;
   try{const snapshot=await __snapshotEncode(meta,rt);const reply=await __parallelInvokeAsync(name,captured,snapshot);const s=await __snapshotDecode(meta,reply.snapshot);const candidate={...rt,tables:__newTables(meta,prefixes,s.tables),keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);rt.tables=candidate.tables;rt.version=s.version;rt.outbox=s.outbox;rt.keeps=candidate.keeps;completed=true;return reply.value;}finally{rt.busy=false;if(completed)observers.commit(meta.roots.map((_,i)=>i));observers.release();}
  },
  checkpoint(limits){if(rt.busy)throw Error('checkpoint requires transaction boundary');return __snapshotEncode(meta,rt,limits);},
  async restore(bytes,limits){if(rt.host)throw Error('restore during transaction');if(rt.busy)throw Error('restore requires transaction boundary');rt.busy=true;rt.ctx.fuel=100000000;observers.hold();let restored=false;try{const s=await __snapshotDecode(meta,bytes,limits);const candidate={...rt,tables:__newTables(meta,prefixes,s.tables),version:s.version,outbox:s.outbox,keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);for(const name of meta.invariantChecks||[]){const a=actionMap.get(name);if(implementations[a.index](rt.ctx,candidate)!==true)throw Error('snapshot violates state invariant');}rt.tables=candidate.tables;rt.version=s.version;rt.outbox=s.outbox;rt.keeps=candidate.keeps;restored=true;}finally{rt.busy=false;if(restored)observers.commit(meta.roots.map((_,i)=>i));observers.release();}},
 });
}
function __computeKeep0(ctx,rt){__tick(ctx);return (__mapValue(__mapValue(__table(rt,0,"values",[]),"list","filter",(s0)=>{__tick(ctx);return (s0)["active"];}),"list","map",(s1)=>{__tick(ctx);return (s1)["value"];})).reduce((a,b)=>{__tick(ctx);return __u64((a) + (b));},0n);}
function __keep0(ctx,rt){return __cachedKeep(ctx,rt,0,__computeKeep0);}
function __computeKeep1(ctx,rt){__tick(ctx);return (__mapValue(__mapValue(__table(rt,0,"values",[]),"list","filter",(s2)=>{__tick(ctx);return (s2)["active"];}),"list","map",(s3)=>{__tick(ctx);return __u64((__u64(((s3)["value"]) * (0n))) + (1n));})).reduce((a,b)=>{__tick(ctx);return __u64((a) + (b));},0n);}
function __keep1(ctx,rt){return __cachedKeep(ctx,rt,1,__computeKeep1);}
function __action0(ctx,rt,s4,s5,s6,s7){__tick(ctx);try{__tick(ctx);if(__table(rt,0,"contains",[s4])){__tick(ctx);__table(rt,0,"replace",[s4,({["value"]:s5,["active"]:s6})]);}else{__tick(ctx);__table(rt,0,"insert",[s4,({["value"]:s5,["active"]:s6})]);}__tick(ctx);rt.staged.push(["seen",s5]);__tick(ctx);if(s7){__tick(ctx);return ({Err:"Error.Failed"});}else{}__tick(ctx);return ({Ok:null});}catch(e){if(e instanceof __Abort)return {Err:e.value};throw e;}}
function __action1(ctx,rt,s8,s9){__tick(ctx);try{__tick(ctx);__table(rt,0,"remove",[s8]);__tick(ctx);rt.staged.push(["seen",s8]);__tick(ctx);if(s9){__tick(ctx);return ({Err:"Error.Failed"});}else{}__tick(ctx);return ({Ok:null});}catch(e){if(e instanceof __Abort)return {Err:e.value};throw e;}}
function __action2(ctx,rt){__tick(ctx);__tick(ctx);return __keep0(ctx,rt);}
function __action3(ctx,rt){__tick(ctx);__tick(ctx);return __keep1(ctx,rt);}
function __stateValueEqual0(a,b){if(a===b)return true;return (a["value"]===b["value"])&&(a["active"]===b["active"]);}
function __stateValueEqual1(a,b){if(a===b)return true;const x=Object.hasOwn(a,'Ok');return x===Object.hasOwn(b,'Ok')&&(x?(a.Ok===b.Ok):(a.Err===b.Err));}
function __ownedInput1(value,budget={cells:1000000},depth=0){if(depth>64||--budget.cells<0)throw Error('state input resource limit');if(typeof value!=='boolean')throw Error('invalid Bool');return value;}
function __ownedInput0(value,budget={cells:1000000},depth=0){if(depth>64||--budget.cells<0)throw Error('state input resource limit');return __stateWord(value);}
const __stateQueryEquals=[(a,b)=>__stateValueEqual1(a,b),(a,b)=>__stateValueEqual1(a,b),(a,b)=>(a===b),(a,b)=>(a===b)];
const __stateRootEquals=[(a,b)=>__stateValueEqual0(a,b)];
const __stateBoundFactories=[(run,a,inputs,output,only)=>{const args=new Array(4);return (p0,p1,p2,p3)=>{args[0]=inputs[0](p0);args[1]=inputs[1](p1);args[2]=inputs[2](p2);args[3]=inputs[3](p3);return run(a,args,null,output,only,true);};},(run,a,inputs,output,only)=>{const args=new Array(2);return (p0,p1)=>{args[0]=inputs[0](p0);args[1]=inputs[1](p1);return run(a,args,null,output,only,true);};},(run,a,inputs,output,only)=>{const args=new Array(0);return ()=>{return run(a,args,null,output,only,true);};},(run,a,inputs,output,only)=>{const args=new Array(0);return ()=>{return run(a,args,null,output,only,true);};}];
const __densePrefixes=[4096];
const __stateMetadata={"actions":[{"change":true,"fallible":true,"freshResult":true,"index":0,"name":"put","params":[{"name":"key","type":{"kind":"u64"}},{"name":"value","type":{"kind":"u64"}},{"name":"active","type":{"kind":"bool"}},{"name":"fail","type":{"kind":"bool"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"Error","variants":["Error.Failed"]},"kind":"result","ok":{"kind":"unit"}},"roots":[0],"singleCell":true},{"change":true,"fallible":true,"freshResult":true,"index":1,"name":"erase","params":[{"name":"key","type":{"kind":"u64"}},{"name":"fail","type":{"kind":"bool"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"Error","variants":["Error.Failed"]},"kind":"result","ok":{"kind":"unit"}},"roots":[0],"singleCell":true},{"change":false,"fallible":false,"freshResult":true,"index":2,"name":"total_query","params":[],"precondition":null,"result":{"kind":"u64"},"roots":[0],"singleCell":true},{"change":false,"fallible":false,"freshResult":true,"index":3,"name":"count_query","params":[],"precondition":null,"result":{"kind":"u64"},"roots":[0],"singleCell":true}],"events":[{"name":"seen","snapshotType":{"kind":"u64"},"type":{"kind":"u64"}}],"invariantChecks":[],"keepInvalidations":[[0,1]],"keeps":[{"cached":true,"name":"total"},{"cached":true,"name":"size"}],"roots":[{"key":{"kind":"u64"},"name":"Rows","snapshotKey":{"kind":"u64"},"snapshotValue":{"fields":[{"name":"value","type":{"kind":"u64"}},{"name":"active","type":{"kind":"bool"}}],"kind":"record"},"value":{"fields":[{"name":"value","type":{"kind":"u64"}},{"name":"active","type":{"kind":"bool"}}],"kind":"record","name":"Row"}}],"snapshot":{"program":[52,20,97,227,197,216,139,58,45,98,73,196,205,50,83,26,202,227,210,13,109,164,33,109,207,238,49,79,213,123,165,218],"schema":[217,47,159,252,204,85,237,70,76,82,248,36,231,99,128,206,40,43,134,247,81,235,124,169,208,7,125,5,136,138,247,164]}};const __actions=[__action0,__action1,__action2,__action3];const __stateInputCaptures=[[__ownedInput0,__ownedInput0,__ownedInput1,__ownedInput1],[__ownedInput0,__ownedInput1],[],[]];
export function createState(){return __createState(__stateMetadata,__actions,__stateInputCaptures,__compiledMaintained,__densePrefixes);}
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v1","core_sha256":"b79d2303fd0e80416ef884f1ebdfb57d7a27c1a1167786e7f6e0ce15e65f665e","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[],"named_types":{"Row":{"fields":[{"name":"value","type":{"kind":"u64"}},{"name":"active","type":{"kind":"bool"}}],"kind":"record","name":"Row"}},"schema":1,"state":{"actions":[{"change":true,"fallible":true,"freshResult":true,"index":0,"name":"put","params":[{"name":"key","type":{"kind":"u64"}},{"name":"value","type":{"kind":"u64"}},{"name":"active","type":{"kind":"bool"}},{"name":"fail","type":{"kind":"bool"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"Error","variants":["Error.Failed"]},"kind":"result","ok":{"kind":"unit"}},"roots":[0],"singleCell":true},{"change":true,"fallible":true,"freshResult":true,"index":1,"name":"erase","params":[{"name":"key","type":{"kind":"u64"}},{"name":"fail","type":{"kind":"bool"}}],"precondition":null,"result":{"error":{"kind":"enum","name":"Error","variants":["Error.Failed"]},"kind":"result","ok":{"kind":"unit"}},"roots":[0],"singleCell":true},{"change":false,"fallible":false,"freshResult":true,"index":2,"name":"total_query","params":[],"precondition":null,"result":{"kind":"u64"},"roots":[0],"singleCell":true},{"change":false,"fallible":false,"freshResult":true,"index":3,"name":"count_query","params":[],"precondition":null,"result":{"kind":"u64"},"roots":[0],"singleCell":true}],"events":[{"name":"seen","snapshotType":{"kind":"u64"},"type":{"kind":"u64"}}],"invariantChecks":[],"keepInvalidations":[[0,1]],"keeps":[{"cached":true,"name":"total"},{"cached":true,"name":"size"}],"roots":[{"key":{"kind":"u64"},"name":"Rows","snapshotKey":{"kind":"u64"},"snapshotValue":{"fields":[{"name":"value","type":{"kind":"u64"}},{"name":"active","type":{"kind":"bool"}}],"kind":"record"},"value":{"fields":[{"name":"value","type":{"kind":"u64"}},{"name":"active","type":{"kind":"bool"}}],"kind":"record","name":"Row"}}],"snapshot":{"program":[52,20,97,227,197,216,139,58,45,98,73,196,205,50,83,26,202,227,210,13,109,164,33,109,207,238,49,79,213,123,165,218],"schema":[217,47,159,252,204,85,237,70,76,82,248,36,231,99,128,206,40,43,134,247,81,235,124,169,208,7,125,5,136,138,247,164]}},"wire":{"format":"ink-value-wire-v1","functions":{}}};
const __implementations=[];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
// Shared bounded binary codec; generated code supplies exact descriptors.
export const valueWireFormat='ink-value-wire-v1';
const wireMagic=Uint8Array.of(73,78,75,86,65,76,0,1);
const wireEncoder=new TextEncoder(),wireDecoder=new TextDecoder('utf-8',{fatal:true});
const wireDefaults={bytes:16777216,nodes:1000000,depth:128};
const wireDecimal=s=>typeof s==='string'&&/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(s);
function wireLimits(options){const l={...wireDefaults,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>wireDefaults[k])throw Error('wire hard resource limit');return l;}
const wireOwn=(v,k)=>v!==null&&typeof v==='object'&&Object.hasOwn(v,k);
const wireTagged=(v,k)=>wireOwn(v,k)&&Object.keys(v).length===1;
const wireCanonical=v=>Array.isArray(v)?'['+v.map(wireCanonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort((a,b)=>{const x=Array.from(a,c=>c.codePointAt(0)),y=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]-y[i];return x.length-y.length;}).map(k=>JSON.stringify(k)+':'+wireCanonical(v[k])).join(',')+'}':JSON.stringify(v);
export async function createValueCodec(root,named={}){
 const used=new Set(),budget={nodes:100000};
 function check(t,d=0){
  if(d>64||--budget.nodes<0)throw Error('wire descriptor limit');
  const keys={u32:['kind'],u64:['kind'],i32:['kind'],f32:['kind'],bool:['kind'],unit:['kind'],string:['kind'],int:['kind'],id:['kind','name'],ref:['kind','name'],enum:['kind','name','variants'],record:['kind','name','fields'],list:['kind','element'],option:['kind','element'],vector:['kind','element','size'],result:['kind','ok','error']}[t?.kind];
  if(!keys||Object.keys(t).length!==keys.length||keys.some(k=>!Object.hasOwn(t,k)))throw Error('invalid wire descriptor');
  if(keys.includes('name')&&(typeof t.name!=='string'||!t.name.isWellFormed()))throw Error('invalid descriptor name');
  if(t.kind==='ref'){if(!used.has(t.name)){used.add(t.name);if(named[t.name]?.kind!=='record'||named[t.name].name!==t.name)throw Error('unresolved wire reference');check(named[t.name],d+1);}}
  if(t.kind==='record'){if(!Array.isArray(t.fields))throw Error('wire fields');const names=new Set();for(const f of t.fields){if(Object.keys(f).length!==2||typeof f.name!=='string'||!f.name.isWellFormed()||names.has(f.name))throw Error('duplicate wire field');names.add(f.name);check(f.type,d+1);}}
  if(t.kind==='enum'&&(!Array.isArray(t.variants)||!t.variants.length||t.variants.length>64||t.variants.some(v=>typeof v!=='string'||!v.isWellFormed())||new Set(t.variants).size!==t.variants.length))throw Error('wire enum');
  if(['list','vector','option'].includes(t.kind)){if(t.kind==='vector'&&(!Number.isInteger(t.size)||t.size<1||t.size>64))throw Error('wire vector');check(t.element,d+1);}
  if(t.kind==='result'){check(t.ok,d+1);check(t.error,d+1);}
 }
 check(root);const names=Object.fromEntries([...used].sort().map(k=>[k,named[k]]));
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',wireEncoder.encode(wireCanonical({format:valueWireFormat,root,named:names}))));
 return new ValueCodec({format:valueWireFormat,root,named:names,identity:Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('')});
}
export class ValueCodec{
 #hash;
 #descriptor;
 get descriptor(){return this.#descriptor;}
 constructor(descriptor){
  // This synchronous path is for compiler-generated immutable metadata. For
  // untrusted descriptors use createValueCodec and compare the computed identity.
  if(descriptor?.format!==valueWireFormat||!/^[0-9a-f]{64}$/.test(descriptor.identity))throw Error('invalid wire schema');
  this.#descriptor=structuredClone(descriptor);this.#hash=Uint8Array.from(descriptor.identity.match(/../g),s=>parseInt(s,16));
  const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}};freeze(this.descriptor);
 }
 resolve(t){for(let i=0;i<64;i++){if(t.kind!=='ref')return t;t=this.descriptor.named[t.name];if(!t)throw Error('wire reference');}throw Error('wire reference cycle');}
 encode(value,options={}){
  const l=wireLimits(options);let remaining=l.nodes,total=40;
  const node=(t,v,d)=>{
   if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');t=this.resolve(t);let body;
   const bad=()=>{throw Error('invalid value for wire schema');};
   const integer=(min,max)=>{if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)bad();};
   const words=(size,write)=>{const b=new Uint8Array(size);write(new DataView(b.buffer));return b;};
   switch(t.kind){
    case 'unit':if(v!==null)bad();body=new Uint8Array();break;
    case 'bool':if(typeof v!=='boolean')bad();body=Uint8Array.of(+v);break;
    case 'u32':integer(0,4294967295);body=words(4,b=>b.setUint32(0,v,true));break;
    case 'i32':integer(-2147483648,2147483647);body=words(4,b=>b.setInt32(0,v,true));break;
    case 'u64':{if(typeof v==='number'&&!Number.isSafeInteger(v)||!['bigint','number','string'].includes(typeof v)||typeof v==='string'&&(!wireDecimal(v)||v.startsWith('-')))bad();const n=BigInt(v);if(n<0n||n>18446744073709551615n)bad();body=words(8,b=>b.setBigUint64(0,n,true));break;}
    case 'f32':{let bits;if(typeof v==='number'&&Number.isFinite(v)){const b=words(4,b=>b.setFloat32(0,v,true));if(!Number.isFinite(new DataView(b.buffer).getFloat32(0,true)))bad();body=b;break;}if(!wireTagged(v,'F32Bits'))bad();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)bad();body=words(4,b=>b.setUint32(0,bits,true));break;}
    case 'string':case 'int':case 'id':case 'enum':{const text=t.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;if(typeof text!=='string'||!text.isWellFormed()||text.length>l.bytes)bad();if(t.kind==='int'&&!wireDecimal(text)||t.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||t.kind==='enum'&&!t.variants.includes(text))bad();body=wireEncoder.encode(text);break;}
    case 'list':case 'vector':{if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))bad();if(v.length>remaining||t.kind==='vector'&&v.length!==t.size)bad();const children=Array.from(v,x=>node(t.element,x,d+1));body=join([words(4,b=>b.setUint32(0,v.length,true)),...children]);break;}
    case 'record':{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==t.fields.length||t.fields.some(f=>!Object.hasOwn(v,f.name)))bad();body=join(t.fields.map(f=>node(f.type,v[f.name],d+1)));break;}
    case 'option':if(wireTagged(v,'Some'))body=join([Uint8Array.of(1),node(t.element,v.Some,d+1)]);else{if(!wireTagged(v,'None')||v.None!==null)bad();body=Uint8Array.of(0);}break;
    case 'result':if(wireTagged(v,'Ok'))body=join([Uint8Array.of(0),node(t.ok,v.Ok,d+1)]);else{if(!wireTagged(v,'Err'))bad();body=join([Uint8Array.of(1),node(t.error,v.Err,d+1)]);}break;
    default:bad();
   }
   // Children have already been counted; only local frame/scalar bytes are new.
   const container=['list','vector','record','option','result'].includes(t.kind);
   total+=4+(container?(t.kind==='record'?0:['list','vector'].includes(t.kind)?4:1):body.length);
   if(total>l.bytes)throw Error('wire byte limit');return join([words(4,b=>b.setUint32(0,body.length,true)),body]);
  };
  const payload=node(this.descriptor.root,value,0);const bytes=join([wireMagic,this.#hash,payload]);if(bytes.length>l.bytes)throw Error('wire byte limit');return bytes;
 }
 encodeWith(emit,options={}){
  const w=new WireEncoder(options);w.bytes(wireMagic);w.bytes(this.#hash);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 scan(bytes,options={},materialize=false,visitor=null){
  const l=wireLimits(options);if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<44||bytes.length>l.bytes)throw Error('wire byte limit or header');
  if(wireMagic.some((b,i)=>bytes[i]!==b)||this.#hash.some((b,i)=>bytes[i+8]!==b))throw Error('wire format or schema mismatch');
  let remaining=l.nodes;const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  const node=(t,at,parentEnd,d)=>{
   if(d>l.depth||--remaining<0||at+4>parentEnd)throw Error('wire node, depth or length limit');t=this.resolve(t);const start=at+4,end=start+view.getUint32(at,true);if(end>parentEnd)throw Error('truncated wire frame');let p=start,value;
   const size=n=>{if(end-start!==n)throw Error('malformed wire scalar');};
   const child=type=>{const r=node(type,p,end,d+1);p=r.end;return r.value;};
   switch(t.kind){
    case 'unit':size(0);value=null;break;
    case 'bool':size(1);if(bytes[start]>1)throw Error('invalid wire Bool');value=!!bytes[start];break;
    case 'u32':size(4);value=view.getUint32(start,true);break;
    case 'i32':size(4);value=view.getInt32(start,true);break;
    case 'f32':size(4);if(materialize)value={F32Bits:view.getUint32(start,true)};break;
    case 'u64':size(8);if(materialize)value=view.getBigUint64(start,true);break;
    case 'string':case 'int':case 'id':case 'enum':{const text=wireDecoder.decode(bytes.subarray(start,end));if(t.kind==='int'&&!wireDecimal(text)||t.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||t.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=t.kind==='int'?{Int:text}:text;break;}
    case 'list':case 'vector':{if(start+4>end)throw Error('wire list count');const n=view.getUint32(start,true);p+=4;if(n>remaining||n>Math.floor((end-p)/4)||t.kind==='vector'&&n!==t.size)throw Error('wire sequence size');if(materialize)value=[];for(let i=0;i<n;i++){const v=child(t.element);if(materialize)value.push(v);}if(p!==end)throw Error('trailing sequence bytes');break;}
    case 'record':{if(materialize)value={};for(const f of t.fields){const v=child(f.type);if(materialize)Object.defineProperty(value,f.name,{value:v,enumerable:true,writable:true,configurable:true});}if(p!==end)throw Error('trailing record bytes');break;}
    case 'option':case 'result':{if(start===end||bytes[p]>1)throw Error('wire sum tag');const b=bytes[p++];if(t.kind==='option'&&b===0){if(p!==end)throw Error('wire None bytes');if(materialize)value={None:null};}else{const tag=t.kind==='option'?'Some':b===0?'Ok':'Err';const v=child(t.kind==='option'?t.element:b===0?t.ok:t.error);if(p!==end)throw Error('trailing sum bytes');if(materialize)value={[tag]:v};}break;}
    default:throw Error('unsupported wire kind');
   }if(visitor)visitor(t,bytes.subarray(start,end),d);return {end,value};
  };
  const r=node(this.descriptor.root,40,bytes.length,0);if(r.end!==bytes.length)throw Error('trailing wire bytes');return r.value;
 }
 visit(bytes,visitor,options={}){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor);}
 validate(bytes,options={}){this.scan(bytes,options,false);return true;}
 decode(bytes,options={}){return this.scan(bytes,options,true);}
}
function join(parts){const size=parts.reduce((n,p)=>n+p.length,0);if(size>16777216)throw Error('wire allocation limit');const out=new Uint8Array(size);let at=0;for(const p of parts){out.set(p,at);at+=p.length;}return out;}

// Bounded forward emission avoids building and repeatedly joining child buffers.
class WireEncoder{
 #data=new Uint8Array(256);#at=0;#remaining;#depth=0;#limits;
 constructor(options){this.#limits=wireLimits(options);this.#remaining=this.#limits.nodes;}
 get position(){return this.#at;}
 bytes(bytes){
  const end=this.#at+bytes.length;if(end>this.#limits.bytes)throw Error('wire byte limit');
  if(end>this.#data.length){const next=new Uint8Array(Math.min(this.#limits.bytes,Math.max(end,this.#data.length*2)));next.set(this.#data.subarray(0,this.#at));this.#data=next;}
  this.#data.set(bytes,this.#at);this.#at=end;
 }
 word(n){if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire word range');const b=new Uint8Array(4);new DataView(b.buffer).setUint32(0,n,true);this.bytes(b);}
 patchWord(at,n){if(!Number.isInteger(at)||at<0||at+4>this.#at||!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire patch offset');new DataView(this.#data.buffer).setUint32(at,n,true);}
 frame(emit){if(this.#depth>this.#limits.depth||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.position;this.word(0);this.#depth++;try{emit(this);}finally{this.#depth--;}this.patchWord(at,this.position-at-4);}
 reorder(start,spans){
  const sorted=spans.slice().sort((a,b)=>a[0]-b[0]);let at=start;
  for(const [a,b] of sorted){if(!Number.isInteger(a)||!Number.isInteger(b)||a!==at||b<a)throw Error('wire span permutation');at=b;}
  if(start<0||start>this.#at||at!==this.#at)throw Error('wire span permutation');
  if(spans.every((s,i)=>s===sorted[i]))return;
  const copy=this.#data.slice(start,this.#at);at=start;for(const [a,b] of spans){this.#data.set(copy.subarray(a-start,b-start),at);at+=b-a;}
 }
 finish(){return this.#data.slice(0,this.#at);}
}
// JSON text is a boundary adapter to an ordinary recursive Ink datatype.
// No JavaScript Number conversion occurs for JSON numeric tokens.
export function jsonNumberToken(s){return typeof s==='string'&&/^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/.test(s);}
const jsonWireEncoder=new TextEncoder();
const jsonLimits={bytes:16777216,nodes:1000000,depth:128};
function checkedJsonLimits(options){const l={...jsonLimits,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>jsonLimits[k])throw Error('JSON hard resource limit');return l;}
function jsonVariant(index,item){let payload=index===0?{}:{item0:item};if(index<5)payload={Ok:payload};for(let i=0;i<index;i++)payload={Err:payload};return {payload};}
export function parseJson(text,options={}){
 const l=checkedJsonLimits(options);if(typeof text!=='string'||!text.isWellFormed()||text.length>l.bytes||new TextEncoder().encode(text).length>l.bytes)throw Error('JSON byte or Unicode limit');let at=0,remaining=l.nodes;
 const ws=()=>{while(at<text.length&&' \t\r\n'.includes(text[at]))at++;};
 const eat=c=>{ws();if(text[at]===c){at++;return true;}return false;};
 const string=()=>{ws();const start=at;if(!eat('"'))throw Error('expected JSON string');while(at<text.length){if(text[at]==='"'){at++;const v=JSON.parse(text.slice(start,at));if(!v.isWellFormed())throw Error('invalid JSON Unicode');return v;}if(text[at]==='\\')at+=2;else at++;}throw Error('unterminated JSON string');};
 const value=d=>{
  if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');ws();const c=text[at];
  for(const [word,index,item] of [['null',0,null],['true',1,true],['false',1,false]])if(text.startsWith(word,at)){at+=word.length;return jsonVariant(index,item);}
  if(c==='"')return jsonVariant(3,string());
  if(c==='['){at++;const xs=[];if(!eat(']'))while(true){xs.push(value(d+1));if(eat(']'))break;if(!eat(','))throw Error('JSON array separator');}return jsonVariant(4,xs);}
  if(c==='{'){at++;const xs=[],seen=new Set();if(!eat('}'))while(true){const key=string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!eat(':'))throw Error('JSON object colon');xs.push({key,value:value(d+1)});if(eat('}'))break;if(!eat(','))throw Error('JSON object separator');}return jsonVariant(5,xs);}
  if(c==='-'||c>='0'&&c<='9'){const start=at;while(at<text.length&&'-+0123456789.eE'.includes(text[at]))at++;const token=text.slice(start,at);if(!jsonNumberToken(token))throw Error('invalid JSON number');return jsonVariant(2,token);}
  throw Error('invalid JSON value');
 };
 const out=value(0);ws();if(at!==text.length)throw Error('trailing JSON text');return out;
}
export function stringifyJson(value,options={}){
 const l=checkedJsonLimits(options);let remaining=l.nodes,bytes=0;const parts=[];const encoder=new TextEncoder();
 const emit=s=>{bytes+=encoder.encode(s).length;if(bytes>l.bytes)throw Error('JSON byte limit');parts.push(s);};
 const write=(v,d)=>{
  if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');if(!v||Object.keys(v).length!==1||!Object.hasOwn(v,'payload'))throw Error('invalid JSON record');let p=v.payload,index=0;
  while(index<5&&p&&Object.hasOwn(p,'Err')){if(Object.keys(p).length!==1)throw Error('invalid JSON sum');p=p.Err;index++;}
  if(index<5){if(!p||Object.keys(p).length!==1||!Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Ok;}
  if(!p||Object.keys(p).length!==(index===0?0:1)||index>0&&!Object.hasOwn(p,'item0'))throw Error('invalid JSON payload');const item=p.item0;
  switch(index){
   case 0:emit('null');break;
   case 1:if(typeof item!=='boolean')throw Error('invalid JSON Boolean');emit(item?'true':'false');break;
   case 2:if(!jsonNumberToken(item))throw Error('invalid JSON number');emit(item);break;
   case 3:if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');emit(JSON.stringify(item));break;
   case 4:if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Array');emit('[');item.forEach((x,i)=>{if(i)emit(',');write(x,d+1);});emit(']');break;
   case 5:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Object');const seen=new Set();emit('{');item.forEach((m,i)=>{if(!m||Object.keys(m).length!==2||typeof m.key!=='string'||!m.key.isWellFormed()||!Object.hasOwn(m,'value'))throw Error('invalid JSON member');if(seen.has(m.key))throw Error('duplicate JSON object key');seen.add(m.key);if(i)emit(',');emit(JSON.stringify(m.key));emit(':');write(m.value,d+1);});emit('}');break;}
  }
 };write(value,0);return parts.join('');
}
export class JsonCodec{
 constructor(valueCodec){
  const root=valueCodec.descriptor.root,fields=root.fields;if(root.kind!=='record'||!Array.isArray(fields)||fields.length!==1||fields[0].name!=='payload')throw Error('JSON schema payload');let sum=fields[0].type;
  for(let i=0;i<6;i++){
   if(i<5&&sum.kind!=='result')throw Error('JSON schema sum');const branch=i<5?sum.ok:sum,fs=branch.fields;
   if(branch.kind!=='record'||!Array.isArray(fs)||fs.length!==(i?1:0)||i&&fs[0].name!=='item0')throw Error('JSON schema branch');
   if(i){const t=fs[0].type;if(i===1&&t.kind!=='bool'||(i===2||i===3)&&t.kind!=='string'||i===4&&(t.kind!=='list'||t.element.kind!=='ref'||t.element.name!==root.name))throw Error('JSON schema variant');if(i===5){const mf=t.element?.fields;if(t.kind!=='list'||t.element?.kind!=='record'||!Array.isArray(mf)||mf.length!==2||mf[0].name!=='key'||mf[0].type.kind!=='string'||mf[1].name!=='value'||mf[1].type.kind!=='ref'||mf[1].type.name!==root.name)throw Error('JSON schema member');}}
   if(i===2)this.numberBranch=branch.name;if(i===5)this.objectBranch=branch.name;
   if(i<5)sum=sum.error;
  }this.values=valueCodec;
 }
 parse(text,options={}){const v=parseJson(text,options);this.values.encode(v,options);return v;}
 stringify(value,options={}){this.values.encode(value,options);return stringifyJson(value,options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,false);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,true);}
 validateBinary(bytes,options={}){
  const decoder=new TextDecoder('utf-8',{fatal:true});
  this.values.visit(bytes,(type,body)=>{
   if(type.kind!=='record')return;
   const view=new DataView(body.buffer,body.byteOffset,body.byteLength);
   if(type.name===this.numberBranch){const length=view.getUint32(0,true);if(!jsonNumberToken(decoder.decode(body.subarray(4,4+length))))throw Error('invalid JSON number token');}
   if(type.name===this.objectBranch){const listEnd=4+view.getUint32(0,true),count=view.getUint32(4,true),seen=new Set();let at=8;for(let i=0;i<count;i++){const memberEnd=at+4+view.getUint32(at,true),keyStart=at+8,keyEnd=keyStart+view.getUint32(at+4,true),key=decoder.decode(body.subarray(keyStart,keyEnd));if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);at=memberEnd;}if(at!==listEnd)throw Error('invalid JSON object frame');}
  },options);return true;
 }
}
function jsonUnpack(value){let p=value.payload,i=0;while(i<5&&Object.hasOwn(p,'Err')){p=p.Err;i++;}return [i,(i<5?p.Ok:p).item0];}
function jsonInteger(token,limit){
 if(!jsonNumberToken(token))throw Error('invalid JSON number');const negative=token[0]==='-',raw=negative?token.slice(1):token,[mantissa,exp='0']=raw.split(/[eE]/);let digits=mantissa.replace('.','');if(/^0+$/.test(digits))return '0';const exponent=Number(exp),fraction=mantissa.includes('.')?mantissa.length-mantissa.indexOf('.')-1:0,shift=exponent-fraction;
 if(!Number.isSafeInteger(exponent)||!Number.isSafeInteger(shift))throw Error('JSON integer exponent limit');
 if(shift<0){const cut=-shift;if(cut>=digits.length||!/^[0]+$/.test(digits.slice(-cut)))throw Error('JSON number is not an integer');digits=digits.slice(0,-cut);}else{if(digits.length+shift>limit)throw Error('JSON integer magnitude limit');digits+='0'.repeat(shift);}
 digits=digits.replace(/^0+/,'');if(digits.length>limit)throw Error('JSON integer magnitude limit');return (negative?'-':'')+digits;
}
export class TypedJsonCodec{
 constructor(valueCodec){this.values=valueCodec;}
 decode(document,options={}){
  // Validate JSON-specific invariants before interpreting any tagged/record
  // shape, including duplicated names and malformed numeric tokens.
  stringifyJson(document,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const read=(type,value,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type),[kind,item]=jsonUnpack(value);const fail=()=>{throw Error('JSON does not match '+t.kind);};
   switch(t.kind){
    case 'unit':if(kind!==0)fail();return null;
    case 'bool':if(kind!==1)fail();return item;
    case 'u32':case 'u64':case 'i32':case 'int':{if(kind!==2)fail();const text=jsonInteger(item,t.kind==='int'?4096:t.kind==='u64'?20:10);return t.kind==='int'?{Int:text}:t.kind==='u64'?BigInt(text):Number(text);}
    case 'f32':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(4));b.setFloat32(0,n,true);if(!Number.isFinite(b.getFloat32(0,true)))throw Error('JSON f32 overflow');return {F32Bits:b.getUint32(0,true)};}
    case 'string':case 'enum':case 'id':if(kind!==3)fail();return item;
    case 'list':case 'vector':if(kind!==4)fail();return item.map(x=>read(t.element,x,d+1));
    case 'record':{if(kind!==5||item.length!==t.fields.length)throw Error('unknown or missing JSON record field');const fields=new Map(item.map(m=>[m.key,m.value])),out={};for(const f of t.fields){if(!fields.has(f.name))throw Error('missing JSON record field');Object.defineProperty(out,f.name,{value:read(f.type,fields.get(f.name),d+1),writable:true,enumerable:true,configurable:true});}return out;}
    case 'option':case 'result':{if(kind!==5||item.length!==1)fail();const m=item[0];if(t.kind==='option'&&m.key==='None'&&jsonUnpack(m.value)[0]===0)return {None:null};const child=t.kind==='option'&&m.key==='Some'?t.element:t.kind==='result'&&m.key==='Ok'?t.ok:t.kind==='result'&&m.key==='Err'?t.error:null;if(!child)fail();return {[m.key]:read(child,m.value,d+1)};}
    default:fail();
   }
  };
  const out=read(this.values.descriptor.root,document,0);this.values.encode(out,options);return out;
 }
 encode(value,options={}){
  this.values.encode(value,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const write=(type,v,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type);
   switch(t.kind){
    case 'unit':return jsonVariant(0);
    case 'bool':return jsonVariant(1,v);
    case 'u32':case 'u64':case 'i32':return jsonVariant(2,String(v));
    case 'int':return jsonVariant(2,typeof v==='bigint'?String(v):v.Int);
    case 'f32':{let n;if(typeof v==='number')n=Math.fround(v);else{const b=new DataView(new ArrayBuffer(4));b.setUint32(0,v.F32Bits,true);n=b.getFloat32(0,true);}if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'string':case 'id':case 'enum':return jsonVariant(3,v);
    case 'list':case 'vector':return jsonVariant(4,Array.from(v,x=>write(t.element,x,d+1)));
    case 'record':return jsonVariant(5,t.fields.map(f=>({key:f.name,value:write(f.type,v[f.name],d+1)})));
    case 'option':return jsonVariant(5,[Object.hasOwn(v,'Some')?{key:'Some',value:write(t.element,v.Some,d+1)}:{key:'None',value:jsonVariant(0)}]);
    case 'result':return jsonVariant(5,[Object.hasOwn(v,'Ok')?{key:'Ok',value:write(t.ok,v.Ok,d+1)}:{key:'Err',value:write(t.error,v.Err,d+1)}]);
    default:throw Error('unsupported typed JSON descriptor');
   }
  };return write(this.values.descriptor.root,value,0);
 }
 parse(text,options={}){return this.decode(parseJson(text,options),options);}
 stringify(value,options={}){return stringifyJson(this.encode(value,options),options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,false);}
}

// Token reader shared by schema-directed and arbitrary-JSON wire emission.
class JsonWireReader{
 constructor(text,options){this.l=checkedJsonLimits(options);if(typeof text!=='string'||!text.isWellFormed()||text.length>this.l.bytes||jsonWireEncoder.encode(text).length>this.l.bytes)throw Error('JSON byte or Unicode limit');this.text=text;this.at=0;this.remaining=this.l.nodes;}
 ws(){while(this.at<this.text.length&&' \t\r\n'.includes(this.text[this.at]))this.at++;}
 peek(){this.ws();return this.text[this.at];}
 eat(c){this.ws();if(this.text[this.at]===c){this.at++;return true;}return false;}
 node(d){if(d>this.l.depth||--this.remaining<0)throw Error('JSON node or depth limit');}
 string(){this.ws();const start=this.at;if(!this.eat('"'))throw Error('expected JSON string');while(this.at<this.text.length){if(this.text[this.at]==='"'){this.at++;const v=JSON.parse(this.text.slice(start,this.at));if(!v.isWellFormed())throw Error('invalid JSON Unicode');return v;}if(this.text[this.at]==='\\')this.at+=2;else this.at++;}throw Error('unterminated JSON string');}
 leaf(d){this.node(d);const c=this.peek();for(const [word,v] of [['null',null],['true',true],['false',false]])if(this.text.startsWith(word,this.at)){this.at+=word.length;return v;}if(c==='"')return this.string();if(c==='-'||c>='0'&&c<='9'){const start=this.at;while(this.at<this.text.length&&'-+0123456789.eE'.includes(this.text[this.at]))this.at++;const token=this.text.slice(start,this.at);if(!jsonNumberToken(token))throw Error('invalid JSON number');return token;}throw Error('invalid JSON scalar');}
 finish(){this.ws();if(this.at!==this.text.length)throw Error('trailing JSON text');}
}
function streamJsonBinary(values,text,options,typed){
 const p=new JsonWireReader(text,options),utf8=jsonWireEncoder;
 const list=(w,open,close,item)=>{if(!p.eat(open))throw Error('JSON container shape');const at=w.position;w.word(0);let count=0;if(!p.eat(close))while(true){item(w);count++;if(p.eat(close))break;if(!p.eat(','))throw Error('JSON container separator');}w.patchWord(at,count);};
 const variant=(w,index,level,emit)=>{if(level<index)w.frame(w=>{w.bytes(Uint8Array.of(1));variant(w,index,level+1,emit);});else if(index<5)w.frame(w=>{w.bytes(Uint8Array.of(0));w.frame(emit);});else w.frame(emit);};
 const json=(w,d)=>{
  const ch=p.peek(),index=ch==='n'?0:ch==='t'||ch==='f'?1:ch==='-'||ch>='0'&&ch<='9'?2:ch==='"'?3:ch==='['?4:ch==='{'?5:-1;if(index<0)throw Error('invalid JSON value');
  const leaf=index<4?p.leaf(d):null;if(index>=4)p.node(d);
  w.frame(w=>variant(w,index,0,w=>{
   if(index===0)return;if(index===1){w.frame(w=>w.bytes(Uint8Array.of(+leaf)));return;}
   if(index===2||index===3){w.frame(w=>w.bytes(utf8.encode(leaf)));return;}
   w.frame(w=>{if(index===4)list(w,'[',']',w=>json(w,d+1));else{const seen=new Set();list(w,'{','}',w=>{const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');w.frame(w=>{w.frame(w=>w.bytes(utf8.encode(key)));json(w,d+1);});});}});
  }));
 };
 const read=(type,w,d)=>{
  const t=values.resolve(type);w.frame(w=>{
   if(t.kind==='list'||t.kind==='vector'){p.node(d);list(w,'[',']',w=>read(t.element,w,d+1));return;}
   if(t.kind==='record'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON record');const start=w.position,spans=new Array(t.fields.length).fill(null);
    if(!p.eat('}'))while(true){const key=p.string(),i=t.fields.findIndex(f=>f.name===key);if(i<0)throw Error('unknown JSON record field');if(spans[i])throw Error('duplicate JSON record field');if(!p.eat(':'))throw Error('JSON record colon');const at=w.position;read(t.fields[i].type,w,d+1);spans[i]=[at,w.position];if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON record separator');}
    if(spans.some(s=>s===null))throw Error('missing JSON record field');w.reorder(start,spans);return;
   }
   if(t.kind==='option'||t.kind==='result'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON tagged value');const key=p.string();if(!p.eat(':'))throw Error('JSON tag colon');
    if(t.kind==='option'&&key==='None'){if(p.leaf(d+1)!==null)throw Error('JSON None payload');w.bytes(Uint8Array.of(0));}
    else{const child=t.kind==='option'&&key==='Some'?t.element:t.kind==='result'&&key==='Ok'?t.ok:t.kind==='result'&&key==='Err'?t.error:null;if(!child)throw Error('invalid JSON tag');w.bytes(Uint8Array.of(key==='Ok'?0:1));read(child,w,d+1);}
    if(!p.eat('}'))throw Error('expected exactly one JSON tag');return;
   }
   const ch=p.peek(),v=p.leaf(d),bad=()=>{throw Error('JSON does not match '+t.kind);};
   if(t.kind==='unit'){if(v!==null)bad();return;}
   if(t.kind==='bool'){if(typeof v!=='boolean')bad();w.bytes(Uint8Array.of(+v));return;}
   if(['string','id','enum'].includes(t.kind)){if(ch!=='"')bad();w.bytes(utf8.encode(v));return;}
   if(ch!=='-'&&!(ch>='0'&&ch<='9'))bad();
   if(t.kind==='int'){w.bytes(utf8.encode(jsonInteger(v,4096)));return;}
   const size=t.kind==='u64'?8:4,b=new Uint8Array(size),dv=new DataView(b.buffer);
   if(t.kind==='f32'){dv.setFloat32(0,Number(v),true);if(!Number.isFinite(dv.getFloat32(0,true)))throw Error('JSON f32 overflow');}
   else{const n=BigInt(jsonInteger(v,t.kind==='u64'?20:10));if(t.kind==='u64'){if(n<0n||n>18446744073709551615n)bad();dv.setBigUint64(0,n,true);}else if(t.kind==='u32'){if(n<0n||n>4294967295n)bad();dv.setUint32(0,Number(n),true);}else if(t.kind==='i32'){if(n< -2147483648n||n>2147483647n)bad();dv.setInt32(0,Number(n),true);}else bad();}
   w.bytes(b);
  });
 };
 return values.encodeWith(w=>{if(typed)read(values.descriptor.root,w,0);else json(w,0);p.finish();},options);
}

// Render validated bytes in a single traversal; only the final text is owned.
function streamWireJsonText(values,bytes,options,library){
 values.validate(bytes,options);const l=checkedJsonLimits(options),parts=[];let size=0,remaining=l.nodes;const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),decoder=new TextDecoder('utf-8',{fatal:true});
 const emit=s=>{size+=jsonWireEncoder.encode(s).length;if(size>l.bytes)throw Error('JSON byte limit');parts.push(s);};
 const string=s=>emit(JSON.stringify(s));const node=d=>{if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');};
 const frame=(type,at)=>{const t=values.resolve(type),start=at+4,end=start+dv.getUint32(at,true);return{t,start,end};};
 const json=(type,at,d)=>{
  node(d);let root=frame(type,at),sum=frame(root.t.fields[0].type,root.start),index=0;
  while(index<5){const err=bytes[sum.start];sum=frame(err?sum.t.error:sum.t.ok,sum.start+1);if(!err)break;index++;}
  if(index===0){emit('null');return root.end;}
  const item=frame(sum.t.fields[0].type,sum.start);
  if(index===1)emit(bytes[item.start]?'true':'false');
  else if(index===2){const token=decoder.decode(bytes.subarray(item.start,item.end));if(!jsonNumberToken(token))throw Error('invalid JSON number token');emit(token);}
  else if(index===3)string(decoder.decode(bytes.subarray(item.start,item.end)));
  else{const count=dv.getUint32(item.start,true);let p=item.start+4;emit(index===4?'[':'{');const seen=new Set();for(let i=0;i<count;i++){if(i)emit(',');if(index===4)p=json(item.t.element,p,d+1);else{const member=frame(item.t.element,p),key=frame(member.t.fields[0].type,member.start),name=decoder.decode(bytes.subarray(key.start,key.end));if(seen.has(name))throw Error('duplicate JSON object key');seen.add(name);string(name);emit(':');json(member.t.fields[1].type,key.end,d+1);p=member.end;}}emit(index===4?']':'}');}
  return root.end;
 };
 const typed=(type,at,d)=>{
  node(d);const f=frame(type,at),t=f.t;let p=f.start;
  switch(t.kind){
   case 'unit':emit('null');break;
   case 'bool':emit(bytes[p]?'true':'false');break;
   case 'u32':emit(String(dv.getUint32(p,true)));break;
   case 'u64':emit(String(dv.getBigUint64(p,true)));break;
   case 'i32':emit(String(dv.getInt32(p,true)));break;
   case 'f32':{const n=dv.getFloat32(p,true);if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'int':emit(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'string':case 'id':case 'enum':string(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'list':case 'vector':{const n=dv.getUint32(p,true);p+=4;emit('[');for(let i=0;i<n;i++){if(i)emit(',');p=typed(t.element,p,d+1);}emit(']');break;}
   case 'record':emit('{');for(let i=0;i<t.fields.length;i++){if(i)emit(',');const field=t.fields[i];string(field.name);emit(':');p=typed(field.type,p,d+1);}emit('}');break;
   case 'option':case 'result':{const tag=bytes[p++],key=t.kind==='option'?(tag?'Some':'None'):tag?'Err':'Ok';emit('{');string(key);emit(':');if(t.kind==='option'&&!tag){node(d+1);emit('null');}else typed(t.kind==='option'?t.element:tag?t.error:t.ok,p,d+1);emit('}');break;}
   default:throw Error('unsupported typed JSON descriptor');
  }return f.end;
 };
 if(library)json(values.descriptor.root,40,0);else typed(values.descriptor.root,40,0);return parts.join('');
}

export const valueCodecs=(()=>{const codecs={};for(const [name,s] of Object.entries(metadata.wire.functions)){if(s.unsupported)continue;let value;Object.defineProperty(codecs,name,{enumerable:true,get:()=>value??=(Object.freeze({arguments:new ValueCodec(s.arguments),result:new ValueCodec(s.result)}))});}return Object.freeze(codecs);})();
export function callBinary(name,bytes,limits={}){
 const f=metadata.functions.find(f=>f.name===name&&!f.internal),codecs=valueCodecs[name];
 if(!f||!codecs)throw Error('unsupported binary function');
 const values=codecs.arguments.decode(bytes,limits);
 const result=call(name,f.params.map(p=>values[p.name]));
 return codecs.result.encode(result,limits);
}
const __intoImplementations=[];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
