use serde_json::{json, Value};
use std::{fs, path::Path, process::Command};
use verified_language::{eval, stateful::Runtime, syntax::parse};
const EXTRA: &str = r#"
record Chain{next:Option<Chain>,value:u32,}
fn chain(x:Chain)->Chain{return x;}
fn chain_next(x:Chain)->Option<Chain>{return x.next;}
fn chain_copy(x:Chain)->Chain{return Chain{next:x.next,value:x.value};}
record Tree{children:List<Tree>,value:u32,}
fn tree(x:Tree)->Tree{return x;}
fn tagged(x:Result<Option<Unit>,Error>)->Result<Option<Unit>,Error>{return x;}
fn float_identity(x:f32)->f32{return x;}
fn unit(x:Unit)->Unit{return x;}
state Words:Table<String,u64> =Table.empty();
event marker:u32;
query checked(x:u64,y:u64)->Result<u64,Error>{return checked_add(x,y).map_err(fn(_)=>Error.Overflow);}
query exact(x:Int,y:Int)->Int{return x*x-y;}
query options(x:Option<Int>)->Option<Int>{return x.map(fn(v)=>v*Int(3));}
query mapped(x:Result<Int,Error>)->Result<Int,Error>{return x.map(fn(v)=>v+Int(2)).map_err(fn(e)=>e);}
query equality(x:List<Item>,y:List<Item>)->Bool{return x==y;}
query word_values()->List<u64> reads(Words){return Words.values();}
change word(k:String,v:u64)->Result<Unit,Error> writes(Words){if Words.contains(k){Words.replace(k,v);}else{Words.insert(k,v);}return Ok(());}
change delete_word(k:String)->Result<Option<u64>,Error> writes(Words){return Ok(Words.remove(k));}
change fail(id:ItemId)->Result<Unit,Error> writes(Items) emits(stock_changed,marker){restock(id,7)?;emit marker(3);return Err(Error.Overflow);}
change ignored(id:ItemId)->Result<Unit,Error> writes(Items) emits(stock_changed,marker){let captured=fail(id);emit marker(4);return Ok(());}
query ordinary_error()->Result<Unit,Error>{return Err(Error.Missing);}
change ignore_query()->Result<Unit,Error>{ordinary_error();return Ok(());}
change try_query(id:ItemId)->Result<Unit,Error> writes(Items) emits(stock_changed){restock(id,2)?;ordinary_error()?;return Ok(());}
change events(id:ItemId)->Result<Int,Error> writes(Items) reads(total_units) emits(stock_changed,marker){emit marker(0);restock(id,1)?;emit marker(1);return Ok(total_units);}
fn repeated_arrays(xs:List<i32>)->List<i32>{return repeat(3,xs,fn(i)=>fn(acc)=>acc.map(fn(x)=>x+1));}
fn choose_arrays(xs:List<i32>,ys:List<i32>,b:Bool)->List<i32>{return choose(b,xs,ys).map(fn(x)=>x*2);}
fn composition(xs:List<i32>)->List<i32>{return xs.map(fn(x)=>x+1).filter(fn(x)=>x<4).scan().sort();}
fn wide_scan(xs:List<u64>)->List<u64>{return xs.scan();}
fn wide_sort(xs:List<u64>)->List<u64>{return xs.sort();}
fn nested(xs:List<List<u32>>)->List<u32>{return xs.map(fn(xs)=>sum(xs));}
fn flags(xs:List<Bool>)->List<Bool>{return xs.filter(fn(x)=>x);}
fn fold(xs:List<u32>)->u32{return foldr(xs,0,fn(x)=>fn(rest)=>x-rest);}
fn signed_div(x:i32,y:i32)->i32{return quot_or(x,y,-99);}
fn rem(x:u64,y:u64)->u64{return rem_or(x,y,99);}
fn float_neg(x:f32)->f32{return -x;}
fn binding(x:u32)->u32{let x:u32=x+1;return x*3;}
fn passthrough(x:Result<List<Int>,Error>)->Result<List<Int>,Error>{return x;}
"#;
fn source() -> String {
    format!(
        "{}\n{}\n{}",
        include_str!("../examples/inventory.lang"),
        include_str!("../examples/particles.ink")
            .split_once(';')
            .unwrap()
            .1,
        EXTRA
    )
}
fn fixtures(p: &verified_language::syntax::Program) -> (Vec<Value>, Vec<Value>) {
    let key = format!("{:032x}", 1);
    let mut reference = Runtime::new(p.clone()).unwrap();
    let mut steps = vec![];
    let mut expected = vec![];
    let calls = vec![
        ("total", json!([])),
        ("create", json!([key, "a\u{0000}雪", 12])),
        ("create", json!([key, "duplicate", 0])),
        ("events", json!([key])),
        ("ignored", json!([key])),
        ("try_query", json!([key])),
        ("ignore_query", json!([])),
        ("stock_of", json!([key])),
        ("checked", json!([u64::MAX, 1])),
        (
            "exact",
            json!([{"Int":"123456789012345678901234567890"},{"Int":"-7"}]),
        ),
        ("options", json!([{"Some":{"Int":"-5"}}])),
        ("options", json!([{"None":null}])),
        ("mapped", json!([{"Ok":{"Int":"7"}}])),
        ("mapped", json!([{"Err":"Error.Missing"}])),
        (
            "equality",
            json!([[{"name":"x","stock":1}],[{"name":"x","stock":1}]]),
        ),
        ("word", json!(["😀", u64::MAX])),
        ("word", json!(["\u{e000}", 2])),
        ("word_values", json!([])),
        ("delete_word", json!(["😀"])),
        ("word_values", json!([])),
    ];
    for (name, args) in calls {
        let outcome = reference.invoke_json(name, &args).unwrap();
        steps.push(json!({"call":name,"args":args}));
        expected.push(json!({"reply":{"outcome":outcome.json()},"snapshot":reference.checkpoint_portable().unwrap()}));
    }
    let pure = vec![
        ("prefix", json!([[]])),
        ("ordered", json!([[]])),
        ("composition", json!([[]])),
        ("flags", json!([[false, false]])),
        ("choose_arrays", json!([[], [2, 3], true])),
        ("choose_arrays", json!([[1], [], false])),
        ("drift", json!([[[1, 2, 3]], [], 0.5])),
        (
            "chain",
            json!([{"next":{"Some":{"next":{"None":null},"value":4}},"value":3}]),
        ),
        (
            "chain_next",
            json!([{"next":{"Some":{"next":{"None":null},"value":4}},"value":3}]),
        ),
        (
            "chain_copy",
            json!([{"next":{"Some":{"next":{"None":null},"value":4}},"value":3}]),
        ),
        ("repeated_arrays", json!([[i32::MAX, 1, -5]])),
        ("choose_arrays", json!([[1], [2, 3, 4], true])),
        ("choose_arrays", json!([[1], [2, 3, 4], false])),
        ("float_identity", json!([1e20])),
        ("float_identity", json!([-0.0])),
        ("float_identity", json!([{"F32Bits":2139095040u32}])),
        (
            "tree",
            json!([{"children":[{"children":[],"value":3}],"value":u32::MAX}]),
        ),
        ("tagged", json!([{"Ok":{"Some":null}}])),
        ("tagged", json!([{"Err":"Error.Missing"}])),
        ("unit", json!([null])),
        (
            "matrix4",
            json!([
                [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16],
                [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]
            ]),
        ),
        ("composition", json!([[3, -2, 3, i32::MAX, 0]])),
        ("kick", json!([[[1, 2, 3]], 0.5, [0, -2, 0]])),
        (
            "particles",
            json!([[{"position":[1,2,3],"velocity":[2,-2,1],"mass":5}],0.5]),
        ),
        ("drift", json!([[[1, 2, 3]], [[2, -2, 1]], 0.5])),
        ("gather", json!([[5, -7], [1, 0, 2, u32::MAX]])),
        ("indexed", json!([[i32::MIN, i32::MAX, 3, -9]])),
        ("iterate", json!([[1, -1]])),
        ("prefix", json!([[i32::MAX, 1, -2]])),
        ("ordered", json!([[3, -1, 3, i32::MIN]])),
        ("ordered_sum", json!([[16777216.0, 1.0, -16777216.0]])),
        ("wide_scan", json!([[u64::MAX, 1, 3]])),
        ("wide_sort", json!([[u64::MAX, 1, 0]])),
        ("nested", json!([[[1, 2], [], [u32::MAX, 1]]])),
        ("flags", json!([[true, false, true]])),
        ("fold", json!([[1, 2, 3]])),
        ("signed_div", json!([i32::MIN, -1])),
        ("signed_div", json!([-7, 2])),
        ("rem", json!([u64::MAX, 3])),
        ("float_neg", json!([{"F32Bits":2143289345u32}])),
        ("binding", json!([u32::MAX])),
        (
            "passthrough",
            json!([{"Ok":[{"Int":"123456789012345678901234567890"}]}]),
        ),
    ];
    for (name, args) in pure {
        let f = p.functions.iter().find(|f| f.name == name).unwrap();
        let inputs = args
            .as_array()
            .unwrap()
            .iter()
            .zip(&f.params)
            .map(|(v, (_, t))| eval::Value::from_program_json(v, t, p).unwrap())
            .collect();
        let value = eval::call(p, name, inputs, &mut 100000000).unwrap().json();
        steps.push(json!({"pure":name,"args":args}));
        expected.push(
            json!({"reply":{"value":value},"snapshot":reference.checkpoint_portable().unwrap()}),
        );
    }
    // Restore the exact reference snapshot and continue near counter exhaustion.
    let layout = verified_language::snapshot::layout(p).unwrap();
    let mut logical = verified_language::snapshot_wire::decode(
        &layout,
        &reference.checkpoint_portable().unwrap(),
        Default::default(),
    )
    .unwrap();
    for version in [u64::MAX - 1, u64::MAX] {
        logical.version = version;
        let bytes = verified_language::snapshot_wire::encode(&layout, &logical, Default::default())
            .unwrap();
        steps.push(json!({"restore":bytes}));
        let mut r = Runtime::restore_portable(p.clone(), &bytes).unwrap();
        for (name, args) in [
            ("ignored", json!([key])),
            ("events", json!([key])),
            ("total", json!([])),
        ] {
            let reply = match r.invoke_json(name, &args) {
                Ok(v) => json!({"outcome":v.json()}),
                Err(e) => json!({"host_error":e}),
            };
            steps.push(json!({"call":name,"args":args}));
            expected.push(json!({"reply":reply,"snapshot":r.checkpoint_portable().unwrap()}));
        }
    }
    (steps, expected)
}
#[path = "support/parity.rs"]
mod parity;
use parity::conformance;

#[test]
fn all_cpu_lowerings_preserve_values_transactions_and_portable_snapshots() {
    let p = parse(&source()).unwrap();
    let (steps, expected) = fixtures(&p);
    conformance("lowering-parity", p, &source(), steps, expected);
}
#[test]
fn query_and_result_keep_boundaries_agree_across_lowerings() {
    let p = parse(include_str!("../examples/query-errors.ink")).unwrap();
    let steps: Vec<Value> = serde_json::from_str(include_str!(
        "../reports/action-effects-phase1/query-errors/script.json"
    ))
    .unwrap();
    let mut r = Runtime::new(p.clone()).unwrap();
    let expected = steps
        .iter()
        .map(|s| {
            let o = r
                .invoke_json(s["call"].as_str().unwrap(), &s["args"])
                .unwrap();
            json!({"reply":{"outcome":o.json()},"snapshot":r.checkpoint_portable().unwrap()})
        })
        .collect();
    conformance(
        "lowering-query-errors",
        p,
        include_str!("../examples/query-errors.ink"),
        steps,
        expected,
    );
}

#[test]
fn resident_collection_lengths_survive_feedback() {
    if std::env::var_os("INK_TEST_WGPU").is_none() {
        return;
    }
    let p=parse("module Resident; fn shrink(xs:List<i32>)->List<i32>{return xs.filter(fn(x)=>x>0);} fn prefix(xs:List<i32>)->List<i32>{return xs.scan();} fn ordered(xs:List<i32>)->List<i32>{return xs.sort();} fn identity(xs:List<i32>)->List<i32>{return xs;} fn duplicate(xs:List<i32>)->List<i32>{return xs.concat(xs);}").unwrap();
    let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("build/lowering-residency");
    verified_language::runtime::emit_gpu(&p, &root).unwrap();
    let target = Path::new(env!("CARGO_MANIFEST_DIR")).join("build/parity-residency-target");
    let out = Command::new(env!("CARGO"))
        .args(["build", "--offline", "--quiet", "--manifest-path"])
        .arg(root.join("native/Cargo.toml"))
        .arg("--target-dir")
        .arg(&target)
        .output()
        .unwrap();
    assert!(
        out.status.success(),
        "{}",
        String::from_utf8_lossy(&out.stderr)
    );
    for (xs, want) in [
        (json!([3, -1, 2]), json!([3, 11])),
        (json!([-2, 0]), json!([])),
        (json!([]), json!([])),
    ] {
        let plan = json!({"inputs":{"xs":xs},"steps":[{"id":"filtered","call":"shrink","args":[{"input":"xs"}]},{"id":"prefix","call":"prefix","args":[{"step":"filtered"}]},{"id":"ordered","call":"ordered","args":[{"step":"prefix"}]}],"iterations":3,"feedback":{"xs":"ordered"},"outputs":["ordered"]});
        fs::write(
            root.join("pipeline.json"),
            serde_json::to_vec(&plan).unwrap(),
        )
        .unwrap();
        let out = Command::new(target.join("debug/ink-gpu-program"))
            .arg("--pipeline")
            .arg(root.join("pipeline.json"))
            .args(["--backend", "gpu"])
            .output()
            .unwrap();
        assert!(
            out.status.success(),
            "{}",
            String::from_utf8_lossy(&out.stderr)
        );
        let v: Value = serde_json::from_slice(&out.stdout).unwrap();
        fs::write(root.join("response.json"), &out.stdout).unwrap();
        assert_eq!(v["backend"], "gpu", "resident pipeline response: {v}");
        assert_eq!(v["values"]["ordered"], want);
        assert_eq!(
            v["counters"]["upload_bytes"],
            4 * (xs.as_array().unwrap().len() + 1)
        );
        assert_eq!(
            v["counters"]["readback_bytes"],
            4 * (want.as_array().unwrap().len() + 1)
        );
        // Three iterations of seven filter, five scan and 29 radix-sort passes.
        assert_eq!(v["counters"]["dispatches"], 123);
        assert_eq!(
            v["counters"]["resident_copy_bytes"],
            16 * (xs.as_array().unwrap().len() + 1)
        );
    }
    let run = |name: &str, plan: Value| {
        let path = root.join(format!("{name}.json"));
        fs::write(&path, serde_json::to_vec(&plan).unwrap()).unwrap();
        let out = Command::new(target.join("debug/ink-gpu-program"))
            .arg("--pipeline")
            .arg(path)
            .args(["--backend", "gpu"])
            .output()
            .unwrap();
        assert!(
            out.status.success(),
            "{}",
            String::from_utf8_lossy(&out.stderr)
        );
        fs::write(root.join(format!("{name}-response.json")), &out.stdout).unwrap();
        serde_json::from_slice::<Value>(&out.stdout).unwrap()
    };
    // Identity outputs alias input buffers. Feedback assignments must be simultaneous,
    // and the final iteration's outputs must not be overwritten by a final swap.
    for iterations in [1, 2, 3] {
        let a = json!([3, -1, 3]);
        let b = json!([8, 0, 8]);
        let plan = json!({"inputs":{"a":a,"b":b},"steps":[
            {"id":"left","call":"identity","args":[{"input":"a"}]},
            {"id":"right","call":"identity","args":[{"input":"b"}]},
            {"id":"unused","call":"shrink","args":[{"input":"a"}]}],
            "iterations":iterations,"feedback":{"a":"right","b":"left"},"outputs":["left","right"]});
        let v = run(&format!("swap-{iterations}"), plan);
        assert_eq!(v["backend"], "gpu", "{v}");
        assert_eq!(
            v["values"]["left"],
            if iterations % 2 == 1 {
                a.clone()
            } else {
                b.clone()
            }
        );
        assert_eq!(
            v["values"]["right"],
            if iterations % 2 == 1 { b } else { a }
        );
        assert_eq!(v["counters"]["upload_bytes"], 32);
        assert_eq!(v["counters"]["readback_bytes"], 32);
        assert_eq!(v["counters"]["resident_copy_bytes"], 64 * (iterations - 1));
    }
    // A growing upper bound is not admitted into the fixed resident allocation.
    let v = run(
        "growing",
        json!({"inputs":{"xs":[1]},"steps":[
        {"id":"grown","call":"duplicate","args":[{"input":"xs"}]}],
        "iterations":2,"feedback":{"xs":"grown"},"outputs":["grown"]}),
    );
    assert_eq!(v["backend"], "cpu");
    assert_eq!(
        v["reason"],
        "feedback changes array shape; compiled CPU pipeline"
    );
    assert_eq!(v["values"]["grown"], json!([1, 1, 1, 1]));
}

#[test]
fn indexed_journals_restore_repeated_keys_nested_changes_and_multiple_roots() {
    let source=r#"module Journal;
enum Error{Failed,}
record Row{value:u32,items:List<u32>,}
state Rows:Table<u32,Row> = Table.empty();
state Other:Table<String,u32> = Table.empty();
event seen:u32;
fn wave(xs:List<u32>)->List<u32>{return xs.map(fn(x)=>x+1);}
change seed(key:u32,items:List<u32>)->Result<Unit,Error> writes(Rows){if Rows.contains(key){return Err(Error.Failed);}else{Rows.insert(key,Row{value:key,items:items});}return Ok(());}
change child(key:u32,items:List<u32>)->Result<Unit,Error> writes(Rows) emits(seen){if Rows.contains(key){Rows.replace(key,Row{value:40,items:items});}else{return Err(Error.Failed);}emit seen(40);return Ok(());}
change churn(key:u32,items:List<u32>,fail:Bool)->Result<Option<Row>,Error> writes(Rows,Other) emits(seen){
 let saved=Rows.get(key);Rows.remove(key);if Rows.contains(key){Rows.replace(key,Row{value:20,items:items});}else{Rows.insert(key,Row{value:20,items:items});}child(key,items)?;
 if Rows.contains(key){Rows.replace(key,Row{value:60,items:items});}Rows.remove(999);
 if Other.contains("temporary"){Other.replace("temporary",1);}else{Other.insert("temporary",1);}if Other.contains("temporary"){Other.replace("temporary",2);}Other.remove("temporary");
 emit seen(60);if fail{return Err(Error.Failed);}return Ok(saved);
}
query rows()->List<Row> reads(Rows){return Rows.values();}
query others()->List<u32> reads(Other){return Other.values();}
"#;
    let p=parse(source).unwrap();
    let steps=vec![json!({"call":"seed","args":[1,[1,7,9]]}),json!({"call":"seed","args":[5,[5,7,9]]}),
        json!({"call":"churn","args":[1,[20,40,60],true]}),json!({"call":"rows","args":[]}),
        json!({"call":"churn","args":[1,[20,40,60],false]}),json!({"call":"churn","args":[37,[20,40,60],true]}),
        json!({"call":"rows","args":[]}),json!({"call":"others","args":[]}),
        json!({"call":"churn","args":[37,[20,40,60],false]}),json!({"call":"rows","args":[]}),
        json!({"pure":"wave","args":[[0,1,u32::MAX]],"expect_gpu":true})];
    let mut reference=Runtime::new(p.clone()).unwrap();
    let expected=steps.iter().map(|step|{
        if let Some(name)=step["pure"].as_str(){
            let f=p.functions.iter().find(|f|f.name==name).unwrap();
            let inputs=step["args"].as_array().unwrap().iter().zip(&f.params).map(|(v,(_,t))|eval::Value::from_program_json(v,t,&p).unwrap()).collect();
            json!({"reply":{"value":eval::call(&p,name,inputs,&mut 100000000).unwrap().json()},"snapshot":reference.checkpoint_portable().unwrap()})
        } else {json!({"reply":{"outcome":reference.invoke_json(step["call"].as_str().unwrap(),&step["args"]).unwrap().json()},"snapshot":reference.checkpoint_portable().unwrap()})}
    }).collect();
    conformance("generated-parity-journal",p,source,steps,expected);
}

#[test]
fn grouped_scalar_helpers_preserve_wide_words_lazy_defaults_and_records() {
    let source = r#"module GroupedScalar;
record Pair{word:u64,signed:i32,flag:Bool,}
state Marker:Table<u32,u32>=Table.empty();
query marker()->u32 reads(Marker){return Marker.get(0).unwrap_or(0);}
fn pick(unused:u64,value:u64)->u64{return value;}
fn wide(x:u64)->u64{let a=pick(x*2,x+1);let x=x+7;return (a*x)^x;}
fn signed(x:i32)->i32{let y=x*2147483647;return y+1;}
fn lazy(x:u32,c:Bool)->u32{let y=quot_or(x,0,9);return choose(c,y,rem_or(x,3,7))+x;}
fn packed(x:Pair)->Pair{return Pair{word:wide(x.word),signed:signed(x.signed),flag:choose(x.flag,false,true)};}
"#;
    let p = parse(source).unwrap();
    let reference = Runtime::new(p.clone()).unwrap();
    let snapshot = reference.checkpoint_portable().unwrap();
    let mut steps = vec![];
    for word in [0u64,1,u64::MAX,u64::MAX-1,0x8000000000000001] {
        steps.push(json!({"pure":"wide","args":[word],"expect_gpu":true}));
        for signed in [i32::MIN,-1,0,1,i32::MAX] {
            steps.push(json!({"pure":"packed","args":[{"word":word,"signed":signed,"flag":word%2==0}],"expect_gpu":true}));
        }
    }
    for word in [0u32,1,u32::MAX,0x80000001] {
        for condition in [false,true] {
            steps.push(json!({"pure":"lazy","args":[word,condition],"expect_gpu":true}));
        }
    }
    let expected = steps.iter().map(|step| {
        let name = step["pure"].as_str().unwrap();
        let f = p.functions.iter().find(|f| f.name==name).unwrap();
        let args = step["args"].as_array().unwrap().iter().zip(&f.params).map(|(v,(_,t))|
            eval::Value::from_program_json(v,t,&p).unwrap()).collect();
        json!({"reply":{"value":eval::call(&p,name,args,&mut 100000).unwrap().json()},"snapshot":snapshot})
    }).collect();
    conformance("scalar-statements-parity",p,source,steps,expected);
}
