// Exact wrapping u64 over two storage lanes. No floating point intermediates.
struct InkU64 {lo:u32,hi:u32,}
struct InkDiv64 {quotient:InkU64,remainder:InkU64,}
fn ink_u64_shl(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64(a.lo<<k,(a.hi<<k)|(a.lo>>(32u-k)));}return InkU64(0u,a.lo<<(k-32u));}
fn ink_u64_shr(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64((a.lo>>k)|(a.hi<<(32u-k)),a.hi>>k);}return InkU64(a.hi>>(k-32u),0u);}
fn ink_u64_rol(a:InkU64,count:u32)->InkU64{let k=count&63u;let l=ink_u64_shl(a,k);let r=ink_u64_shr(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_ror(a:InkU64,count:u32)->InkU64{let k=count&63u;let r=ink_u64_shr(a,k);let l=ink_u64_shl(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_eq(a:InkU64,b:InkU64)->bool{return a.lo==b.lo&&a.hi==b.hi;}
fn ink_u64_lt(a:InkU64,b:InkU64)->bool{return a.hi<b.hi||(a.hi==b.hi&&a.lo<b.lo);}
fn ink_u64_add(a:InkU64,b:InkU64)->InkU64{let lo=a.lo+b.lo;return InkU64(lo,a.hi+b.hi+select(0u,1u,lo<a.lo));}
fn ink_u64_sub(a:InkU64,b:InkU64)->InkU64{return InkU64(a.lo-b.lo,a.hi-b.hi-select(0u,1u,a.lo<b.lo));}
fn ink_u64_mul(a:InkU64,b:InkU64)->InkU64{let al=a.lo&65535u;let ah=a.lo>>16u;let bl=b.lo&65535u;let bh=b.lo>>16u;let p=al*bl;let x=ah*bl;let y=al*bh;let mid=(p>>16u)+(x&65535u)+(y&65535u);let high=ah*bh+(x>>16u)+(y>>16u)+(mid>>16u);return InkU64((mid<<16u)|(p&65535u),high+a.lo*b.hi+a.hi*b.lo);}
fn ink_u64_div(a:InkU64,b:InkU64)->InkDiv64{var q=InkU64(0u,0u);var r=InkU64(0u,0u);var cursor=64u;loop{if(cursor==0u){break;}cursor--;var bit=0u;if(cursor>=32u){bit=(a.hi>>(cursor-32u))&1u;}else{bit=(a.lo>>cursor)&1u;}let overflow=r.hi>>31u;r=InkU64((r.lo<<1u)|bit,(r.hi<<1u)|(r.lo>>31u));if(overflow!=0u||!ink_u64_lt(r,b)){r=ink_u64_sub(r,b);if(cursor>=32u){q.hi|=1u<<(cursor-32u);}else{q.lo|=1u<<cursor;}}}return InkDiv64(q,r);}
// Binary32 evaluated with integer lanes: round-to-nearest, ties-to-even,
// gradual underflow, signed zero and canonical arithmetic NaN.
fn ink_f32_nan(x:u32)->bool{return (x&0x7fffffffu)>0x7f800000u;}
fn ink_f32_eq(a:u32,b:u32)->bool{return !ink_f32_nan(a)&&!ink_f32_nan(b)&&(a==b||((a|b)&0x7fffffffu)==0u);}
fn ink_f32_lt(a:u32,b:u32)->bool{
 if(ink_f32_nan(a)||ink_f32_nan(b)||ink_f32_eq(a,b)){return false;}
 if((a^b)&0x80000000u)!=0u{return (a&0x80000000u)!=0u;}
 if((a&0x80000000u)!=0u){return a>b;}return a<b;
}
fn ink_f32_jam(x:u32,n:u32)->u32{if(n==0u){return x;}if(n>=32u){return select(0u,1u,x!=0u);}return (x>>n)|select(0u,1u,(x&((1u<<n)-1u))!=0u);}
fn ink_f32_round(sign:u32,exponent:i32,extended:u32)->u32{
 var e=exponent;var s=extended;
 if(e<1i){s=ink_f32_jam(s,u32(1i-e));e=1i;}
 let tail=s&7u;var sig=s>>3u;
 if(tail>4u||(tail==4u&&(sig&1u)!=0u)){sig++;}
 if(sig>=0x1000000u){sig>>=1u;e++;}
 if(e>=255i){return sign|0x7f800000u;}
 if(sig==0u){return sign;}
 let raw=select(u32(e),0u,e==1i&&sig<0x800000u);
 return sign|(raw<<23u)|(sig&0x7fffffu);
}
fn ink_f32_add(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 var x=a;var y=b;if((x&0x7fffffffu)<(y&0x7fffffffu)){x=b;y=a;}
 let ax=x&0x7fffffffu;let ay=y&0x7fffffffu;let sign=x&0x80000000u;
 if(ax==0x7f800000u){if(ay==ax&&((x^y)&0x80000000u)!=0u){return 0x7fc00000u;}return x;}
 let rx=(x>>23u)&255u;let ry=(y>>23u)&255u;var e=i32(max(rx,1u));
 var sx=((x&0x7fffffu)|select(0u,0x800000u,rx!=0u))<<3u;
 let sy=ink_f32_jam(((y&0x7fffffu)|select(0u,0x800000u,ry!=0u))<<3u,u32(e)-max(ry,1u));
 if(((x^y)&0x80000000u)==0u){sx+=sy;if(sx>=0x8000000u){sx=ink_f32_jam(sx,1u);e++;}}
 else{sx-=sy;if(sx==0u){return 0u;}loop{if(sx>=0x4000000u||e<=1i){break;}sx<<=1u;e--;}}
 return ink_f32_round(sign,e,sx);
}
fn ink_f32_sub(a:u32,b:u32)->u32{return ink_f32_add(a,b^0x80000000u);}
fn ink_f32_mul(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(aa==0x7f800000u||bb==0x7f800000u){if(aa==0u||bb==0u){return 0x7fc00000u;}return sign|0x7f800000u;}
 if(aa==0u||bb==0u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u));var eb=i32(max(rb,1u));
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 let product=ink_u64_mul(InkU64(sa,0u),InkU64(sb,0u));let high=(product.hi&0x8000u)!=0u;
 let shift=select(20u,21u,high);let extended=(product.lo>>shift)|(product.hi<<(32u-shift))|select(0u,1u,(product.lo&((1u<<shift)-1u))!=0u);
 return ink_f32_round(sign,ea+eb-127i+select(0i,1i,high),extended);
}
// Exact sqrt and division use integer significands, independent of WGSL float
// approximation allowances and device flush-to-zero behavior.
fn ink_f32_sqrt(x:u32)->u32{
 let a=x&0x7fffffffu;if(a==0u){return x;}
 if(a>0x7f800000u||(x&0x80000000u)!=0u){return 0x7fc00000u;}
 if(a==0x7f800000u){return x;}
 let raw=(x>>23u)&255u;var m=(x&0x7fffffu)|select(0u,0x800000u,raw!=0u);var e=i32(max(raw,1u))-127i;
 loop{if(m>=0x800000u){break;}m<<=1u;e--;}
 let odd=e&1i;var half=(e-odd)/2i;let shift=23u+u32(odd);
 let n=InkU64(m<<shift,m>>(32u-shift));var lo=0u;var hi=0x1000000u;
 loop{if(lo+1u>=hi){break;}let mid=(lo+hi)>>1u;let sq=ink_u64_mul(InkU64(mid,0u),InkU64(mid,0u));if(!ink_u64_lt(n,sq)){lo=mid;}else{hi=mid;}}
 let sq=ink_u64_mul(InkU64(lo,0u),InkU64(lo,0u));let rem=ink_u64_sub(n,sq);
 if(ink_u64_lt(InkU64(lo,0u),rem)){lo++;}
 if(lo==0x1000000u){lo>>=1u;half++;}
 return (u32(half+127i)<<23u)|(lo&0x7fffffu);
}
fn ink_f32_div(a:u32,b:u32)->u32{
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(ink_f32_nan(a)||ink_f32_nan(b)||(aa==0u&&bb==0u)||(aa==0x7f800000u&&bb==aa)){return 0x7fc00000u;}
 if(aa==0x7f800000u||bb==0u){return sign|0x7f800000u;}
 if(aa==0u||bb==0x7f800000u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u))-127i;var eb=i32(max(rb,1u))-127i;
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 var e=ea-eb;if(sa<sb){sa<<=1u;e--;}
 let division=ink_u64_div(InkU64(sa<<26u,sa>>6u),InkU64(sb,0u));
 let extended=division.quotient.lo|select(0u,1u,!ink_u64_eq(division.remainder,InkU64(0u,0u)));
 return ink_f32_round(sign,e+127i,extended);
}
// mode: 0 trunc, 1 floor, 2 ceil, 3 ties-to-even.
fn ink_f32_integral(x:u32,mode:u32)->u32{
 let a=x&0x7fffffffu;let sign=x&0x80000000u;
 if(a>0x7f800000u){return 0x7fc00000u;}if(a>=0x4b000000u||a==0u){return x;}
 let e=i32((x>>23u)&255u)-127i;
 if(e<0i){var up=false;if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){up=a>0x3f000000u;}return sign|select(0u,0x3f800000u,up);}
 let shift=u32(23i-e);let mask=(1u<<shift)-1u;let fraction=a&mask;var rounded=a&~mask;var up=false;
 if(fraction!=0u){if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){let half=1u<<(shift-1u);up=fraction>half||(fraction==half&&((rounded>>shift)&1u)!=0u);}}
 if(up){rounded+=1u<<shift;}return sign|rounded;
}
fn ink_f32_from_u64(x:InkU64)->u32{
 if(ink_u64_eq(x,InkU64(0u,0u))){return 0u;}
 let leading=select(countLeadingZeros(x.lo)+32u,countLeadingZeros(x.hi),x.hi!=0u);let e=63u-leading;
 if(e<=23u){return ((e+127u)<<23u)|((x.lo<<(23u-e))&0x7fffffu);}
 let shift=e-23u;var sig=0u;var rem=InkU64(0u,0u);var half=InkU64(0u,0u);
 if(shift<32u){sig=(x.lo>>shift)|(x.hi<<(32u-shift));rem=InkU64(x.lo&((1u<<shift)-1u),0u);half=InkU64(1u<<(shift-1u),0u);}
 else if(shift==32u){sig=x.hi;rem=InkU64(x.lo,0u);half=InkU64(0x80000000u,0u);}
 else{sig=x.hi>>(shift-32u);rem=InkU64(x.lo,x.hi&((1u<<(shift-32u))-1u));half=InkU64(0u,1u<<(shift-33u));}
 if(ink_u64_lt(half,rem)||(ink_u64_eq(rem,half)&&(sig&1u)!=0u)){sig++;}
 var exponent=e+127u;if(sig==0x1000000u){sig>>=1u;exponent++;}
 return (exponent<<23u)|(sig&0x7fffffu);
}
fn ink_f32_from_i32(x:i32)->u32{let neg=x<0i;let magnitude=select(u32(x),0u-u32(x),neg);return ink_f32_from_u64(InkU64(magnitude,0u))|select(0u,0x80000000u,neg);}
struct InkBuffer_u32{data:array<u32,64>,length:u32,}
struct InkBuffer_InkU64{data:array<InkU64,64>,length:u32,}
struct InkBuffer_i32{data:array<i32,64>,length:u32,}
struct InkBuffer_bool{data:array<bool,64>,length:u32,}
struct R_Coefficients{ink_f_scale:u32,ink_f_bias:u32,}
@group(0) @binding(0) var<storage,read> a0:array<u32>;
@group(0) @binding(1) var<storage,read> a1:array<u32>;
@group(0) @binding(2) var<storage,read_write> output:array<u32>;
@compute @workgroup_size(1) fn main(@builtin(global_invocation_id) gid:vec3<u32>){
if(gid.x!=0u){return;}var t0:R_Coefficients=R_Coefficients(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t1:u32=a1[0u+(0u)*1u+0u];
var t2:R_Coefficients=t0;
var t3:u32=t1;
var t4:R_Coefficients=t2;
var t5:u32=t3;
var t6:R_Coefficients=t4;
var t7:u32=t5;
var t8:R_Coefficients=t6;
var t9:u32=t7;
var t10:R_Coefficients=t8;
var t11:u32=t9;
var t12:u32=t11;
var t13:u32=ink_f32_mul(t12,(t10).ink_f_scale);
var t14:u32=t13;
var t15:u32=ink_f32_add(t14,(t10).ink_f_bias);
var t16:u32=t15;
var t17:u32;
if (ink_f32_lt(0u,t16)) {
t17=t15;
} else {
t17=0u;
}
var t18:u32=t17;
var t19:u32=t18;
var t20:u32=ink_f32_mul(t19,(t10).ink_f_scale);
var t21:u32=t20;
var t22:u32=ink_f32_add(t21,(t10).ink_f_bias);
var t23:u32=t22;
var t24:u32=ink_f32_mul(t23,(t10).ink_f_scale);
var t25:u32=t24;
var t26:u32;
if (ink_f32_lt(0u,t25)) {
t26=t24;
} else {
t26=0u;
}
var t27:u32=t26;
var t28:u32=t27;
var t29:u32=ink_f32_add(t28,(t10).ink_f_bias);
var t30:u32=t29;
var t31:R_Coefficients=t8;
var t32:u32=t30;
var t33:u32=t32;
var t34:u32=ink_f32_mul(t33,(t31).ink_f_scale);
var t35:u32=t34;
var t36:u32=ink_f32_add(t35,(t31).ink_f_bias);
var t37:u32=t36;
var t38:u32;
if (ink_f32_lt(0u,t37)) {
t38=t36;
} else {
t38=0u;
}
var t39:u32=t38;
var t40:u32=t39;
var t41:u32=ink_f32_mul(t40,(t31).ink_f_scale);
var t42:u32=t41;
var t43:u32=ink_f32_add(t42,(t31).ink_f_bias);
var t44:u32=t43;
var t45:u32=ink_f32_mul(t44,(t31).ink_f_scale);
var t46:u32=t45;
var t47:u32;
if (ink_f32_lt(0u,t46)) {
t47=t45;
} else {
t47=0u;
}
var t48:u32=t47;
var t49:u32=t48;
var t50:u32=ink_f32_add(t49,(t31).ink_f_bias);
var t51:u32=t50;
var t52:R_Coefficients=t6;
var t53:u32=t51;
var t54:R_Coefficients=t52;
var t55:u32=t53;
var t56:u32=t55;
var t57:u32=ink_f32_mul(t56,(t54).ink_f_scale);
var t58:u32=t57;
var t59:u32=ink_f32_add(t58,(t54).ink_f_bias);
var t60:u32=t59;
var t61:u32;
if (ink_f32_lt(0u,t60)) {
t61=t59;
} else {
t61=0u;
}
var t62:u32=t61;
var t63:u32=t62;
var t64:u32=ink_f32_mul(t63,(t54).ink_f_scale);
var t65:u32=t64;
var t66:u32=ink_f32_add(t65,(t54).ink_f_bias);
var t67:u32=t66;
var t68:u32=ink_f32_mul(t67,(t54).ink_f_scale);
var t69:u32=t68;
var t70:u32;
if (ink_f32_lt(0u,t69)) {
t70=t68;
} else {
t70=0u;
}
var t71:u32=t70;
var t72:u32=t71;
var t73:u32=ink_f32_add(t72,(t54).ink_f_bias);
var t74:u32=t73;
var t75:R_Coefficients=t52;
var t76:u32=t74;
var t77:u32=t76;
var t78:u32=ink_f32_mul(t77,(t75).ink_f_scale);
var t79:u32=t78;
var t80:u32=ink_f32_add(t79,(t75).ink_f_bias);
var t81:u32=t80;
var t82:u32;
if (ink_f32_lt(0u,t81)) {
t82=t80;
} else {
t82=0u;
}
var t83:u32=t82;
var t84:u32=t83;
var t85:u32=ink_f32_mul(t84,(t75).ink_f_scale);
var t86:u32=t85;
var t87:u32=ink_f32_add(t86,(t75).ink_f_bias);
var t88:u32=t87;
var t89:u32=ink_f32_mul(t88,(t75).ink_f_scale);
var t90:u32=t89;
var t91:u32;
if (ink_f32_lt(0u,t90)) {
t91=t89;
} else {
t91=0u;
}
var t92:u32=t91;
var t93:u32=t92;
var t94:u32=ink_f32_add(t93,(t75).ink_f_bias);
var t95:u32=t94;
var t96:R_Coefficients=t4;
var t97:u32=t95;
var t98:R_Coefficients=t96;
var t99:u32=t97;
var t100:R_Coefficients=t98;
var t101:u32=t99;
var t102:u32=t101;
var t103:u32=ink_f32_mul(t102,(t100).ink_f_scale);
var t104:u32=t103;
var t105:u32=ink_f32_add(t104,(t100).ink_f_bias);
var t106:u32=t105;
var t107:u32;
if (ink_f32_lt(0u,t106)) {
t107=t105;
} else {
t107=0u;
}
var t108:u32=t107;
var t109:u32=t108;
var t110:u32=ink_f32_mul(t109,(t100).ink_f_scale);
var t111:u32=t110;
var t112:u32=ink_f32_add(t111,(t100).ink_f_bias);
var t113:u32=t112;
var t114:u32=ink_f32_mul(t113,(t100).ink_f_scale);
var t115:u32=t114;
var t116:u32;
if (ink_f32_lt(0u,t115)) {
t116=t114;
} else {
t116=0u;
}
var t117:u32=t116;
var t118:u32=t117;
var t119:u32=ink_f32_add(t118,(t100).ink_f_bias);
var t120:u32=t119;
var t121:R_Coefficients=t98;
var t122:u32=t120;
var t123:u32=t122;
var t124:u32=ink_f32_mul(t123,(t121).ink_f_scale);
var t125:u32=t124;
var t126:u32=ink_f32_add(t125,(t121).ink_f_bias);
var t127:u32=t126;
var t128:u32;
if (ink_f32_lt(0u,t127)) {
t128=t126;
} else {
t128=0u;
}
var t129:u32=t128;
var t130:u32=t129;
var t131:u32=ink_f32_mul(t130,(t121).ink_f_scale);
var t132:u32=t131;
var t133:u32=ink_f32_add(t132,(t121).ink_f_bias);
var t134:u32=t133;
var t135:u32=ink_f32_mul(t134,(t121).ink_f_scale);
var t136:u32=t135;
var t137:u32;
if (ink_f32_lt(0u,t136)) {
t137=t135;
} else {
t137=0u;
}
var t138:u32=t137;
var t139:u32=t138;
var t140:u32=ink_f32_add(t139,(t121).ink_f_bias);
var t141:u32=t140;
var t142:R_Coefficients=t96;
var t143:u32=t141;
var t144:R_Coefficients=t142;
var t145:u32=t143;
var t146:u32=t145;
var t147:u32=ink_f32_mul(t146,(t144).ink_f_scale);
var t148:u32=t147;
var t149:u32=ink_f32_add(t148,(t144).ink_f_bias);
var t150:u32=t149;
var t151:u32;
if (ink_f32_lt(0u,t150)) {
t151=t149;
} else {
t151=0u;
}
var t152:u32=t151;
var t153:u32=t152;
var t154:u32=ink_f32_mul(t153,(t144).ink_f_scale);
var t155:u32=t154;
var t156:u32=ink_f32_add(t155,(t144).ink_f_bias);
var t157:u32=t156;
var t158:u32=ink_f32_mul(t157,(t144).ink_f_scale);
var t159:u32=t158;
var t160:u32;
if (ink_f32_lt(0u,t159)) {
t160=t158;
} else {
t160=0u;
}
var t161:u32=t160;
var t162:u32=t161;
var t163:u32=ink_f32_add(t162,(t144).ink_f_bias);
var t164:u32=t163;
var t165:R_Coefficients=t142;
var t166:u32=t164;
var t167:u32=t166;
var t168:u32=ink_f32_mul(t167,(t165).ink_f_scale);
var t169:u32=t168;
var t170:u32=ink_f32_add(t169,(t165).ink_f_bias);
var t171:u32=t170;
var t172:u32;
if (ink_f32_lt(0u,t171)) {
t172=t170;
} else {
t172=0u;
}
var t173:u32=t172;
var t174:u32=t173;
var t175:u32=ink_f32_mul(t174,(t165).ink_f_scale);
var t176:u32=t175;
var t177:u32=ink_f32_add(t176,(t165).ink_f_bias);
var t178:u32=t177;
var t179:u32=ink_f32_mul(t178,(t165).ink_f_scale);
var t180:u32=t179;
var t181:u32;
if (ink_f32_lt(0u,t180)) {
t181=t179;
} else {
t181=0u;
}
var t182:u32=t181;
var t183:u32=t182;
var t184:u32=ink_f32_add(t183,(t165).ink_f_bias);
var t185:u32=t184;
var t186:R_Coefficients=t2;
var t187:u32=t185;
var t188:R_Coefficients=t186;
var t189:u32=t187;
var t190:R_Coefficients=t188;
var t191:u32=t189;
var t192:R_Coefficients=t190;
var t193:u32=t191;
var t194:u32=t193;
var t195:u32=ink_f32_mul(t194,(t192).ink_f_scale);
var t196:u32=t195;
var t197:u32=ink_f32_add(t196,(t192).ink_f_bias);
var t198:u32=t197;
var t199:u32;
if (ink_f32_lt(0u,t198)) {
t199=t197;
} else {
t199=0u;
}
var t200:u32=t199;
var t201:u32=t200;
var t202:u32=ink_f32_mul(t201,(t192).ink_f_scale);
var t203:u32=t202;
var t204:u32=ink_f32_add(t203,(t192).ink_f_bias);
var t205:u32=t204;
var t206:u32=ink_f32_mul(t205,(t192).ink_f_scale);
var t207:u32=t206;
var t208:u32;
if (ink_f32_lt(0u,t207)) {
t208=t206;
} else {
t208=0u;
}
var t209:u32=t208;
var t210:u32=t209;
var t211:u32=ink_f32_add(t210,(t192).ink_f_bias);
var t212:u32=t211;
var t213:R_Coefficients=t190;
var t214:u32=t212;
var t215:u32=t214;
var t216:u32=ink_f32_mul(t215,(t213).ink_f_scale);
var t217:u32=t216;
var t218:u32=ink_f32_add(t217,(t213).ink_f_bias);
var t219:u32=t218;
var t220:u32;
if (ink_f32_lt(0u,t219)) {
t220=t218;
} else {
t220=0u;
}
var t221:u32=t220;
var t222:u32=t221;
var t223:u32=ink_f32_mul(t222,(t213).ink_f_scale);
var t224:u32=t223;
var t225:u32=ink_f32_add(t224,(t213).ink_f_bias);
var t226:u32=t225;
var t227:u32=ink_f32_mul(t226,(t213).ink_f_scale);
var t228:u32=t227;
var t229:u32;
if (ink_f32_lt(0u,t228)) {
t229=t227;
} else {
t229=0u;
}
var t230:u32=t229;
var t231:u32=t230;
var t232:u32=ink_f32_add(t231,(t213).ink_f_bias);
var t233:u32=t232;
var t234:R_Coefficients=t188;
var t235:u32=t233;
var t236:R_Coefficients=t234;
var t237:u32=t235;
var t238:u32=t237;
var t239:u32=ink_f32_mul(t238,(t236).ink_f_scale);
var t240:u32=t239;
var t241:u32=ink_f32_add(t240,(t236).ink_f_bias);
var t242:u32=t241;
var t243:u32;
if (ink_f32_lt(0u,t242)) {
t243=t241;
} else {
t243=0u;
}
var t244:u32=t243;
var t245:u32=t244;
var t246:u32=ink_f32_mul(t245,(t236).ink_f_scale);
var t247:u32=t246;
var t248:u32=ink_f32_add(t247,(t236).ink_f_bias);
var t249:u32=t248;
var t250:u32=ink_f32_mul(t249,(t236).ink_f_scale);
var t251:u32=t250;
var t252:u32;
if (ink_f32_lt(0u,t251)) {
t252=t250;
} else {
t252=0u;
}
var t253:u32=t252;
var t254:u32=t253;
var t255:u32=ink_f32_add(t254,(t236).ink_f_bias);
var t256:u32=t255;
var t257:R_Coefficients=t234;
var t258:u32=t256;
var t259:u32=t258;
var t260:u32=ink_f32_mul(t259,(t257).ink_f_scale);
var t261:u32=t260;
var t262:u32=ink_f32_add(t261,(t257).ink_f_bias);
var t263:u32=t262;
var t264:u32;
if (ink_f32_lt(0u,t263)) {
t264=t262;
} else {
t264=0u;
}
var t265:u32=t264;
var t266:u32=t265;
var t267:u32=ink_f32_mul(t266,(t257).ink_f_scale);
var t268:u32=t267;
var t269:u32=ink_f32_add(t268,(t257).ink_f_bias);
var t270:u32=t269;
var t271:u32=ink_f32_mul(t270,(t257).ink_f_scale);
var t272:u32=t271;
var t273:u32;
if (ink_f32_lt(0u,t272)) {
t273=t271;
} else {
t273=0u;
}
var t274:u32=t273;
var t275:u32=t274;
var t276:u32=ink_f32_add(t275,(t257).ink_f_bias);
var t277:u32=t276;
var t278:R_Coefficients=t186;
var t279:u32=t277;
var t280:R_Coefficients=t278;
var t281:u32=t279;
var t282:R_Coefficients=t280;
var t283:u32=t281;
var t284:u32=t283;
var t285:u32=ink_f32_mul(t284,(t282).ink_f_scale);
var t286:u32=t285;
var t287:u32=ink_f32_add(t286,(t282).ink_f_bias);
var t288:u32=t287;
var t289:u32;
if (ink_f32_lt(0u,t288)) {
t289=t287;
} else {
t289=0u;
}
var t290:u32=t289;
var t291:u32=t290;
var t292:u32=ink_f32_mul(t291,(t282).ink_f_scale);
var t293:u32=t292;
var t294:u32=ink_f32_add(t293,(t282).ink_f_bias);
var t295:u32=t294;
var t296:u32=ink_f32_mul(t295,(t282).ink_f_scale);
var t297:u32=t296;
var t298:u32;
if (ink_f32_lt(0u,t297)) {
t298=t296;
} else {
t298=0u;
}
var t299:u32=t298;
var t300:u32=t299;
var t301:u32=ink_f32_add(t300,(t282).ink_f_bias);
var t302:u32=t301;
var t303:R_Coefficients=t280;
var t304:u32=t302;
var t305:u32=t304;
var t306:u32=ink_f32_mul(t305,(t303).ink_f_scale);
var t307:u32=t306;
var t308:u32=ink_f32_add(t307,(t303).ink_f_bias);
var t309:u32=t308;
var t310:u32;
if (ink_f32_lt(0u,t309)) {
t310=t308;
} else {
t310=0u;
}
var t311:u32=t310;
var t312:u32=t311;
var t313:u32=ink_f32_mul(t312,(t303).ink_f_scale);
var t314:u32=t313;
var t315:u32=ink_f32_add(t314,(t303).ink_f_bias);
var t316:u32=t315;
var t317:u32=ink_f32_mul(t316,(t303).ink_f_scale);
var t318:u32=t317;
var t319:u32;
if (ink_f32_lt(0u,t318)) {
t319=t317;
} else {
t319=0u;
}
var t320:u32=t319;
var t321:u32=t320;
var t322:u32=ink_f32_add(t321,(t303).ink_f_bias);
var t323:u32=t322;
var t324:R_Coefficients=t278;
var t325:u32=t323;
var t326:R_Coefficients=t324;
var t327:u32=t325;
var t328:u32=t327;
var t329:u32=ink_f32_mul(t328,(t326).ink_f_scale);
var t330:u32=t329;
var t331:u32=ink_f32_add(t330,(t326).ink_f_bias);
var t332:u32=t331;
var t333:u32;
if (ink_f32_lt(0u,t332)) {
t333=t331;
} else {
t333=0u;
}
var t334:u32=t333;
var t335:u32=t334;
var t336:u32=ink_f32_mul(t335,(t326).ink_f_scale);
var t337:u32=t336;
var t338:u32=ink_f32_add(t337,(t326).ink_f_bias);
var t339:u32=t338;
var t340:u32=ink_f32_mul(t339,(t326).ink_f_scale);
var t341:u32=t340;
var t342:u32;
if (ink_f32_lt(0u,t341)) {
t342=t340;
} else {
t342=0u;
}
var t343:u32=t342;
var t344:u32=t343;
var t345:u32=ink_f32_add(t344,(t326).ink_f_bias);
var t346:u32=t345;
var t347:R_Coefficients=t324;
var t348:u32=t346;
var t349:u32=t348;
var t350:u32=ink_f32_mul(t349,(t347).ink_f_scale);
var t351:u32=t350;
var t352:u32=ink_f32_add(t351,(t347).ink_f_bias);
var t353:u32=t352;
var t354:u32;
if (ink_f32_lt(0u,t353)) {
t354=t352;
} else {
t354=0u;
}
var t355:u32=t354;
var t356:u32=t355;
var t357:u32=ink_f32_mul(t356,(t347).ink_f_scale);
var t358:u32=t357;
var t359:u32=ink_f32_add(t358,(t347).ink_f_bias);
var t360:u32=t359;
var t361:u32=ink_f32_mul(t360,(t347).ink_f_scale);
var t362:u32=t361;
var t363:u32;
if (ink_f32_lt(0u,t362)) {
t363=t361;
} else {
t363=0u;
}
var t364:u32=t363;
var t365:u32=t364;
var t366:u32=ink_f32_add(t365,(t347).ink_f_bias);
var t367:u32=t366;
var t368:R_Coefficients=t0;
var t369:u32=t367;
var t370:R_Coefficients=t368;
var t371:u32=t369;
var t372:R_Coefficients=t370;
var t373:u32=t371;
var t374:R_Coefficients=t372;
var t375:u32=t373;
var t376:R_Coefficients=t374;
var t377:u32=t375;
var t378:u32=t377;
var t379:u32=ink_f32_mul(t378,(t376).ink_f_scale);
var t380:u32=t379;
var t381:u32=ink_f32_add(t380,(t376).ink_f_bias);
var t382:u32=t381;
var t383:u32;
if (ink_f32_lt(0u,t382)) {
t383=t381;
} else {
t383=0u;
}
var t384:u32=t383;
var t385:u32=t384;
var t386:u32=ink_f32_mul(t385,(t376).ink_f_scale);
var t387:u32=t386;
var t388:u32=ink_f32_add(t387,(t376).ink_f_bias);
var t389:u32=t388;
var t390:u32=ink_f32_mul(t389,(t376).ink_f_scale);
var t391:u32=t390;
var t392:u32;
if (ink_f32_lt(0u,t391)) {
t392=t390;
} else {
t392=0u;
}
var t393:u32=t392;
var t394:u32=t393;
var t395:u32=ink_f32_add(t394,(t376).ink_f_bias);
var t396:u32=t395;
var t397:R_Coefficients=t374;
var t398:u32=t396;
var t399:u32=t398;
var t400:u32=ink_f32_mul(t399,(t397).ink_f_scale);
var t401:u32=t400;
var t402:u32=ink_f32_add(t401,(t397).ink_f_bias);
var t403:u32=t402;
var t404:u32;
if (ink_f32_lt(0u,t403)) {
t404=t402;
} else {
t404=0u;
}
var t405:u32=t404;
var t406:u32=t405;
var t407:u32=ink_f32_mul(t406,(t397).ink_f_scale);
var t408:u32=t407;
var t409:u32=ink_f32_add(t408,(t397).ink_f_bias);
var t410:u32=t409;
var t411:u32=ink_f32_mul(t410,(t397).ink_f_scale);
var t412:u32=t411;
var t413:u32;
if (ink_f32_lt(0u,t412)) {
t413=t411;
} else {
t413=0u;
}
var t414:u32=t413;
var t415:u32=t414;
var t416:u32=ink_f32_add(t415,(t397).ink_f_bias);
var t417:u32=t416;
var t418:R_Coefficients=t372;
var t419:u32=t417;
var t420:R_Coefficients=t418;
var t421:u32=t419;
var t422:u32=t421;
var t423:u32=ink_f32_mul(t422,(t420).ink_f_scale);
var t424:u32=t423;
var t425:u32=ink_f32_add(t424,(t420).ink_f_bias);
var t426:u32=t425;
var t427:u32;
if (ink_f32_lt(0u,t426)) {
t427=t425;
} else {
t427=0u;
}
var t428:u32=t427;
var t429:u32=t428;
var t430:u32=ink_f32_mul(t429,(t420).ink_f_scale);
var t431:u32=t430;
var t432:u32=ink_f32_add(t431,(t420).ink_f_bias);
var t433:u32=t432;
var t434:u32=ink_f32_mul(t433,(t420).ink_f_scale);
var t435:u32=t434;
var t436:u32;
if (ink_f32_lt(0u,t435)) {
t436=t434;
} else {
t436=0u;
}
var t437:u32=t436;
var t438:u32=t437;
var t439:u32=ink_f32_add(t438,(t420).ink_f_bias);
var t440:u32=t439;
var t441:R_Coefficients=t418;
var t442:u32=t440;
var t443:u32=t442;
var t444:u32=ink_f32_mul(t443,(t441).ink_f_scale);
var t445:u32=t444;
var t446:u32=ink_f32_add(t445,(t441).ink_f_bias);
var t447:u32=t446;
var t448:u32;
if (ink_f32_lt(0u,t447)) {
t448=t446;
} else {
t448=0u;
}
var t449:u32=t448;
var t450:u32=t449;
var t451:u32=ink_f32_mul(t450,(t441).ink_f_scale);
var t452:u32=t451;
var t453:u32=ink_f32_add(t452,(t441).ink_f_bias);
var t454:u32=t453;
var t455:u32=ink_f32_mul(t454,(t441).ink_f_scale);
var t456:u32=t455;
var t457:u32;
if (ink_f32_lt(0u,t456)) {
t457=t455;
} else {
t457=0u;
}
var t458:u32=t457;
var t459:u32=t458;
var t460:u32=ink_f32_add(t459,(t441).ink_f_bias);
var t461:u32=t460;
var t462:R_Coefficients=t370;
var t463:u32=t461;
var t464:R_Coefficients=t462;
var t465:u32=t463;
var t466:R_Coefficients=t464;
var t467:u32=t465;
var t468:u32=t467;
var t469:u32=ink_f32_mul(t468,(t466).ink_f_scale);
var t470:u32=t469;
var t471:u32=ink_f32_add(t470,(t466).ink_f_bias);
var t472:u32=t471;
var t473:u32;
if (ink_f32_lt(0u,t472)) {
t473=t471;
} else {
t473=0u;
}
var t474:u32=t473;
var t475:u32=t474;
var t476:u32=ink_f32_mul(t475,(t466).ink_f_scale);
var t477:u32=t476;
var t478:u32=ink_f32_add(t477,(t466).ink_f_bias);
var t479:u32=t478;
var t480:u32=ink_f32_mul(t479,(t466).ink_f_scale);
var t481:u32=t480;
var t482:u32;
if (ink_f32_lt(0u,t481)) {
t482=t480;
} else {
t482=0u;
}
var t483:u32=t482;
var t484:u32=t483;
var t485:u32=ink_f32_add(t484,(t466).ink_f_bias);
var t486:u32=t485;
var t487:R_Coefficients=t464;
var t488:u32=t486;
var t489:u32=t488;
var t490:u32=ink_f32_mul(t489,(t487).ink_f_scale);
var t491:u32=t490;
var t492:u32=ink_f32_add(t491,(t487).ink_f_bias);
var t493:u32=t492;
var t494:u32;
if (ink_f32_lt(0u,t493)) {
t494=t492;
} else {
t494=0u;
}
var t495:u32=t494;
var t496:u32=t495;
var t497:u32=ink_f32_mul(t496,(t487).ink_f_scale);
var t498:u32=t497;
var t499:u32=ink_f32_add(t498,(t487).ink_f_bias);
var t500:u32=t499;
var t501:u32=ink_f32_mul(t500,(t487).ink_f_scale);
var t502:u32=t501;
var t503:u32;
if (ink_f32_lt(0u,t502)) {
t503=t501;
} else {
t503=0u;
}
var t504:u32=t503;
var t505:u32=t504;
var t506:u32=ink_f32_add(t505,(t487).ink_f_bias);
var t507:u32=t506;
var t508:R_Coefficients=t462;
var t509:u32=t507;
var t510:R_Coefficients=t508;
var t511:u32=t509;
var t512:u32=t511;
var t513:u32=ink_f32_mul(t512,(t510).ink_f_scale);
var t514:u32=t513;
var t515:u32=ink_f32_add(t514,(t510).ink_f_bias);
var t516:u32=t515;
var t517:u32;
if (ink_f32_lt(0u,t516)) {
t517=t515;
} else {
t517=0u;
}
var t518:u32=t517;
var t519:u32=t518;
var t520:u32=ink_f32_mul(t519,(t510).ink_f_scale);
var t521:u32=t520;
var t522:u32=ink_f32_add(t521,(t510).ink_f_bias);
var t523:u32=t522;
var t524:u32=ink_f32_mul(t523,(t510).ink_f_scale);
var t525:u32=t524;
var t526:u32;
if (ink_f32_lt(0u,t525)) {
t526=t524;
} else {
t526=0u;
}
var t527:u32=t526;
var t528:u32=t527;
var t529:u32=ink_f32_add(t528,(t510).ink_f_bias);
var t530:u32=t529;
var t531:R_Coefficients=t508;
var t532:u32=t530;
var t533:u32=t532;
var t534:u32=ink_f32_mul(t533,(t531).ink_f_scale);
var t535:u32=t534;
var t536:u32=ink_f32_add(t535,(t531).ink_f_bias);
var t537:u32=t536;
var t538:u32;
if (ink_f32_lt(0u,t537)) {
t538=t536;
} else {
t538=0u;
}
var t539:u32=t538;
var t540:u32=t539;
var t541:u32=ink_f32_mul(t540,(t531).ink_f_scale);
var t542:u32=t541;
var t543:u32=ink_f32_add(t542,(t531).ink_f_bias);
var t544:u32=t543;
var t545:u32=ink_f32_mul(t544,(t531).ink_f_scale);
var t546:u32=t545;
var t547:u32;
if (ink_f32_lt(0u,t546)) {
t547=t545;
} else {
t547=0u;
}
var t548:u32=t547;
var t549:u32=t548;
var t550:u32=ink_f32_add(t549,(t531).ink_f_bias);
var t551:u32=t550;
var t552:R_Coefficients=t368;
var t553:u32=t551;
var t554:R_Coefficients=t552;
var t555:u32=t553;
var t556:R_Coefficients=t554;
var t557:u32=t555;
var t558:R_Coefficients=t556;
var t559:u32=t557;
var t560:u32=t559;
var t561:u32=ink_f32_mul(t560,(t558).ink_f_scale);
var t562:u32=t561;
var t563:u32=ink_f32_add(t562,(t558).ink_f_bias);
var t564:u32=t563;
var t565:u32;
if (ink_f32_lt(0u,t564)) {
t565=t563;
} else {
t565=0u;
}
var t566:u32=t565;
var t567:u32=t566;
var t568:u32=ink_f32_mul(t567,(t558).ink_f_scale);
var t569:u32=t568;
var t570:u32=ink_f32_add(t569,(t558).ink_f_bias);
var t571:u32=t570;
var t572:u32=ink_f32_mul(t571,(t558).ink_f_scale);
var t573:u32=t572;
var t574:u32;
if (ink_f32_lt(0u,t573)) {
t574=t572;
} else {
t574=0u;
}
var t575:u32=t574;
var t576:u32=t575;
var t577:u32=ink_f32_add(t576,(t558).ink_f_bias);
var t578:u32=t577;
var t579:R_Coefficients=t556;
var t580:u32=t578;
var t581:u32=t580;
var t582:u32=ink_f32_mul(t581,(t579).ink_f_scale);
var t583:u32=t582;
var t584:u32=ink_f32_add(t583,(t579).ink_f_bias);
var t585:u32=t584;
var t586:u32;
if (ink_f32_lt(0u,t585)) {
t586=t584;
} else {
t586=0u;
}
var t587:u32=t586;
var t588:u32=t587;
var t589:u32=ink_f32_mul(t588,(t579).ink_f_scale);
var t590:u32=t589;
var t591:u32=ink_f32_add(t590,(t579).ink_f_bias);
var t592:u32=t591;
var t593:u32=ink_f32_mul(t592,(t579).ink_f_scale);
var t594:u32=t593;
var t595:u32;
if (ink_f32_lt(0u,t594)) {
t595=t593;
} else {
t595=0u;
}
var t596:u32=t595;
var t597:u32=t596;
var t598:u32=ink_f32_add(t597,(t579).ink_f_bias);
var t599:u32=t598;
var t600:R_Coefficients=t554;
var t601:u32=t599;
var t602:R_Coefficients=t600;
var t603:u32=t601;
var t604:u32=t603;
var t605:u32=ink_f32_mul(t604,(t602).ink_f_scale);
var t606:u32=t605;
var t607:u32=ink_f32_add(t606,(t602).ink_f_bias);
var t608:u32=t607;
var t609:u32;
if (ink_f32_lt(0u,t608)) {
t609=t607;
} else {
t609=0u;
}
var t610:u32=t609;
var t611:u32=t610;
var t612:u32=ink_f32_mul(t611,(t602).ink_f_scale);
var t613:u32=t612;
var t614:u32=ink_f32_add(t613,(t602).ink_f_bias);
var t615:u32=t614;
var t616:u32=ink_f32_mul(t615,(t602).ink_f_scale);
var t617:u32=t616;
var t618:u32;
if (ink_f32_lt(0u,t617)) {
t618=t616;
} else {
t618=0u;
}
var t619:u32=t618;
var t620:u32=t619;
var t621:u32=ink_f32_add(t620,(t602).ink_f_bias);
var t622:u32=t621;
var t623:R_Coefficients=t600;
var t624:u32=t622;
var t625:u32=t624;
var t626:u32=ink_f32_mul(t625,(t623).ink_f_scale);
var t627:u32=t626;
var t628:u32=ink_f32_add(t627,(t623).ink_f_bias);
var t629:u32=t628;
var t630:u32;
if (ink_f32_lt(0u,t629)) {
t630=t628;
} else {
t630=0u;
}
var t631:u32=t630;
var t632:u32=t631;
var t633:u32=ink_f32_mul(t632,(t623).ink_f_scale);
var t634:u32=t633;
var t635:u32=ink_f32_add(t634,(t623).ink_f_bias);
var t636:u32=t635;
var t637:u32=ink_f32_mul(t636,(t623).ink_f_scale);
var t638:u32=t637;
var t639:u32;
if (ink_f32_lt(0u,t638)) {
t639=t637;
} else {
t639=0u;
}
var t640:u32=t639;
var t641:u32=t640;
var t642:u32=ink_f32_add(t641,(t623).ink_f_bias);
var t643:u32=t642;
var t644:R_Coefficients=t552;
var t645:u32=t643;
var t646:R_Coefficients=t644;
var t647:u32=t645;
var t648:R_Coefficients=t646;
var t649:u32=t647;
var t650:u32=t649;
var t651:u32=ink_f32_mul(t650,(t648).ink_f_scale);
var t652:u32=t651;
var t653:u32=ink_f32_add(t652,(t648).ink_f_bias);
var t654:u32=t653;
var t655:u32;
if (ink_f32_lt(0u,t654)) {
t655=t653;
} else {
t655=0u;
}
var t656:u32=t655;
var t657:u32=t656;
var t658:u32=ink_f32_mul(t657,(t648).ink_f_scale);
var t659:u32=t658;
var t660:u32=ink_f32_add(t659,(t648).ink_f_bias);
var t661:u32=t660;
var t662:u32=ink_f32_mul(t661,(t648).ink_f_scale);
var t663:u32=t662;
var t664:u32;
if (ink_f32_lt(0u,t663)) {
t664=t662;
} else {
t664=0u;
}
var t665:u32=t664;
var t666:u32=t665;
var t667:u32=ink_f32_add(t666,(t648).ink_f_bias);
var t668:u32=t667;
var t669:R_Coefficients=t646;
var t670:u32=t668;
var t671:u32=t670;
var t672:u32=ink_f32_mul(t671,(t669).ink_f_scale);
var t673:u32=t672;
var t674:u32=ink_f32_add(t673,(t669).ink_f_bias);
var t675:u32=t674;
var t676:u32;
if (ink_f32_lt(0u,t675)) {
t676=t674;
} else {
t676=0u;
}
var t677:u32=t676;
var t678:u32=t677;
var t679:u32=ink_f32_mul(t678,(t669).ink_f_scale);
var t680:u32=t679;
var t681:u32=ink_f32_add(t680,(t669).ink_f_bias);
var t682:u32=t681;
var t683:u32=ink_f32_mul(t682,(t669).ink_f_scale);
var t684:u32=t683;
var t685:u32;
if (ink_f32_lt(0u,t684)) {
t685=t683;
} else {
t685=0u;
}
var t686:u32=t685;
var t687:u32=t686;
var t688:u32=ink_f32_add(t687,(t669).ink_f_bias);
var t689:u32=t688;
var t690:R_Coefficients=t644;
var t691:u32=t689;
var t692:R_Coefficients=t690;
var t693:u32=t691;
var t694:u32=t693;
var t695:u32=ink_f32_mul(t694,(t692).ink_f_scale);
var t696:u32=t695;
var t697:u32=ink_f32_add(t696,(t692).ink_f_bias);
var t698:u32=t697;
var t699:u32;
if (ink_f32_lt(0u,t698)) {
t699=t697;
} else {
t699=0u;
}
var t700:u32=t699;
var t701:u32=t700;
var t702:u32=ink_f32_mul(t701,(t692).ink_f_scale);
var t703:u32=t702;
var t704:u32=ink_f32_add(t703,(t692).ink_f_bias);
var t705:u32=t704;
var t706:u32=ink_f32_mul(t705,(t692).ink_f_scale);
var t707:u32=t706;
var t708:u32;
if (ink_f32_lt(0u,t707)) {
t708=t706;
} else {
t708=0u;
}
var t709:u32=t708;
var t710:u32=t709;
var t711:u32=ink_f32_add(t710,(t692).ink_f_bias);
var t712:u32=t711;
var t713:R_Coefficients=t690;
var t714:u32=t712;
var t715:u32=t714;
var t716:u32=ink_f32_mul(t715,(t713).ink_f_scale);
var t717:u32=t716;
var t718:u32=ink_f32_add(t717,(t713).ink_f_bias);
var t719:u32=t718;
var t720:u32;
if (ink_f32_lt(0u,t719)) {
t720=t718;
} else {
t720=0u;
}
var t721:u32=t720;
var t722:u32=t721;
var t723:u32=ink_f32_mul(t722,(t713).ink_f_scale);
var t724:u32=t723;
var t725:u32=ink_f32_add(t724,(t713).ink_f_bias);
var t726:u32=t725;
var t727:u32=ink_f32_mul(t726,(t713).ink_f_scale);
var t728:u32=t727;
var t729:u32;
if (ink_f32_lt(0u,t728)) {
t729=t727;
} else {
t729=0u;
}
var t730:u32=t729;
var t731:u32=t730;
var t732:u32=ink_f32_add(t731,(t713).ink_f_bias);
var t733:u32=t732;
var t734:R_Coefficients=R_Coefficients(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t735:u32=t733;
var t736:R_Coefficients=t734;
var t737:u32=t735;
var t738:R_Coefficients=t736;
var t739:u32=t737;
var t740:R_Coefficients=t738;
var t741:u32=t739;
var t742:R_Coefficients=t740;
var t743:u32=t741;
var t744:R_Coefficients=t742;
var t745:u32=t743;
var t746:u32=t745;
var t747:u32=ink_f32_mul(t746,(t744).ink_f_scale);
var t748:u32=t747;
var t749:u32=ink_f32_add(t748,(t744).ink_f_bias);
var t750:u32=t749;
var t751:u32;
if (ink_f32_lt(0u,t750)) {
t751=t749;
} else {
t751=0u;
}
var t752:u32=t751;
var t753:u32=t752;
var t754:u32=ink_f32_mul(t753,(t744).ink_f_scale);
var t755:u32=t754;
var t756:u32=ink_f32_add(t755,(t744).ink_f_bias);
var t757:u32=t756;
var t758:u32=ink_f32_mul(t757,(t744).ink_f_scale);
var t759:u32=t758;
var t760:u32;
if (ink_f32_lt(0u,t759)) {
t760=t758;
} else {
t760=0u;
}
var t761:u32=t760;
var t762:u32=t761;
var t763:u32=ink_f32_add(t762,(t744).ink_f_bias);
var t764:u32=t763;
var t765:R_Coefficients=t742;
var t766:u32=t764;
var t767:u32=t766;
var t768:u32=ink_f32_mul(t767,(t765).ink_f_scale);
var t769:u32=t768;
var t770:u32=ink_f32_add(t769,(t765).ink_f_bias);
var t771:u32=t770;
var t772:u32;
if (ink_f32_lt(0u,t771)) {
t772=t770;
} else {
t772=0u;
}
var t773:u32=t772;
var t774:u32=t773;
var t775:u32=ink_f32_mul(t774,(t765).ink_f_scale);
var t776:u32=t775;
var t777:u32=ink_f32_add(t776,(t765).ink_f_bias);
var t778:u32=t777;
var t779:u32=ink_f32_mul(t778,(t765).ink_f_scale);
var t780:u32=t779;
var t781:u32;
if (ink_f32_lt(0u,t780)) {
t781=t779;
} else {
t781=0u;
}
var t782:u32=t781;
var t783:u32=t782;
var t784:u32=ink_f32_add(t783,(t765).ink_f_bias);
var t785:u32=t784;
var t786:R_Coefficients=t740;
var t787:u32=t785;
var t788:R_Coefficients=t786;
var t789:u32=t787;
var t790:u32=t789;
var t791:u32=ink_f32_mul(t790,(t788).ink_f_scale);
var t792:u32=t791;
var t793:u32=ink_f32_add(t792,(t788).ink_f_bias);
var t794:u32=t793;
var t795:u32;
if (ink_f32_lt(0u,t794)) {
t795=t793;
} else {
t795=0u;
}
var t796:u32=t795;
var t797:u32=t796;
var t798:u32=ink_f32_mul(t797,(t788).ink_f_scale);
var t799:u32=t798;
var t800:u32=ink_f32_add(t799,(t788).ink_f_bias);
var t801:u32=t800;
var t802:u32=ink_f32_mul(t801,(t788).ink_f_scale);
var t803:u32=t802;
var t804:u32;
if (ink_f32_lt(0u,t803)) {
t804=t802;
} else {
t804=0u;
}
var t805:u32=t804;
var t806:u32=t805;
var t807:u32=ink_f32_add(t806,(t788).ink_f_bias);
var t808:u32=t807;
var t809:R_Coefficients=t786;
var t810:u32=t808;
var t811:u32=t810;
var t812:u32=ink_f32_mul(t811,(t809).ink_f_scale);
var t813:u32=t812;
var t814:u32=ink_f32_add(t813,(t809).ink_f_bias);
var t815:u32=t814;
var t816:u32;
if (ink_f32_lt(0u,t815)) {
t816=t814;
} else {
t816=0u;
}
var t817:u32=t816;
var t818:u32=t817;
var t819:u32=ink_f32_mul(t818,(t809).ink_f_scale);
var t820:u32=t819;
var t821:u32=ink_f32_add(t820,(t809).ink_f_bias);
var t822:u32=t821;
var t823:u32=ink_f32_mul(t822,(t809).ink_f_scale);
var t824:u32=t823;
var t825:u32;
if (ink_f32_lt(0u,t824)) {
t825=t823;
} else {
t825=0u;
}
var t826:u32=t825;
var t827:u32=t826;
var t828:u32=ink_f32_add(t827,(t809).ink_f_bias);
var t829:u32=t828;
var t830:R_Coefficients=t738;
var t831:u32=t829;
var t832:R_Coefficients=t830;
var t833:u32=t831;
var t834:R_Coefficients=t832;
var t835:u32=t833;
var t836:u32=t835;
var t837:u32=ink_f32_mul(t836,(t834).ink_f_scale);
var t838:u32=t837;
var t839:u32=ink_f32_add(t838,(t834).ink_f_bias);
var t840:u32=t839;
var t841:u32;
if (ink_f32_lt(0u,t840)) {
t841=t839;
} else {
t841=0u;
}
var t842:u32=t841;
var t843:u32=t842;
var t844:u32=ink_f32_mul(t843,(t834).ink_f_scale);
var t845:u32=t844;
var t846:u32=ink_f32_add(t845,(t834).ink_f_bias);
var t847:u32=t846;
var t848:u32=ink_f32_mul(t847,(t834).ink_f_scale);
var t849:u32=t848;
var t850:u32;
if (ink_f32_lt(0u,t849)) {
t850=t848;
} else {
t850=0u;
}
var t851:u32=t850;
var t852:u32=t851;
var t853:u32=ink_f32_add(t852,(t834).ink_f_bias);
var t854:u32=t853;
var t855:R_Coefficients=t832;
var t856:u32=t854;
var t857:u32=t856;
var t858:u32=ink_f32_mul(t857,(t855).ink_f_scale);
var t859:u32=t858;
var t860:u32=ink_f32_add(t859,(t855).ink_f_bias);
var t861:u32=t860;
var t862:u32;
if (ink_f32_lt(0u,t861)) {
t862=t860;
} else {
t862=0u;
}
var t863:u32=t862;
var t864:u32=t863;
var t865:u32=ink_f32_mul(t864,(t855).ink_f_scale);
var t866:u32=t865;
var t867:u32=ink_f32_add(t866,(t855).ink_f_bias);
var t868:u32=t867;
var t869:u32=ink_f32_mul(t868,(t855).ink_f_scale);
var t870:u32=t869;
var t871:u32;
if (ink_f32_lt(0u,t870)) {
t871=t869;
} else {
t871=0u;
}
var t872:u32=t871;
var t873:u32=t872;
var t874:u32=ink_f32_add(t873,(t855).ink_f_bias);
var t875:u32=t874;
var t876:R_Coefficients=t830;
var t877:u32=t875;
var t878:R_Coefficients=t876;
var t879:u32=t877;
var t880:u32=t879;
var t881:u32=ink_f32_mul(t880,(t878).ink_f_scale);
var t882:u32=t881;
var t883:u32=ink_f32_add(t882,(t878).ink_f_bias);
var t884:u32=t883;
var t885:u32;
if (ink_f32_lt(0u,t884)) {
t885=t883;
} else {
t885=0u;
}
var t886:u32=t885;
var t887:u32=t886;
var t888:u32=ink_f32_mul(t887,(t878).ink_f_scale);
var t889:u32=t888;
var t890:u32=ink_f32_add(t889,(t878).ink_f_bias);
var t891:u32=t890;
var t892:u32=ink_f32_mul(t891,(t878).ink_f_scale);
var t893:u32=t892;
var t894:u32;
if (ink_f32_lt(0u,t893)) {
t894=t892;
} else {
t894=0u;
}
var t895:u32=t894;
var t896:u32=t895;
var t897:u32=ink_f32_add(t896,(t878).ink_f_bias);
var t898:u32=t897;
var t899:R_Coefficients=t876;
var t900:u32=t898;
var t901:u32=t900;
var t902:u32=ink_f32_mul(t901,(t899).ink_f_scale);
var t903:u32=t902;
var t904:u32=ink_f32_add(t903,(t899).ink_f_bias);
var t905:u32=t904;
var t906:u32;
if (ink_f32_lt(0u,t905)) {
t906=t904;
} else {
t906=0u;
}
var t907:u32=t906;
var t908:u32=t907;
var t909:u32=ink_f32_mul(t908,(t899).ink_f_scale);
var t910:u32=t909;
var t911:u32=ink_f32_add(t910,(t899).ink_f_bias);
var t912:u32=t911;
var t913:u32=ink_f32_mul(t912,(t899).ink_f_scale);
var t914:u32=t913;
var t915:u32;
if (ink_f32_lt(0u,t914)) {
t915=t913;
} else {
t915=0u;
}
var t916:u32=t915;
var t917:u32=t916;
var t918:u32=ink_f32_add(t917,(t899).ink_f_bias);
var t919:u32=t918;
var t920:R_Coefficients=t736;
var t921:u32=t919;
var t922:R_Coefficients=t920;
var t923:u32=t921;
var t924:R_Coefficients=t922;
var t925:u32=t923;
var t926:R_Coefficients=t924;
var t927:u32=t925;
var t928:u32=t927;
var t929:u32=ink_f32_mul(t928,(t926).ink_f_scale);
var t930:u32=t929;
var t931:u32=ink_f32_add(t930,(t926).ink_f_bias);
var t932:u32=t931;
var t933:u32;
if (ink_f32_lt(0u,t932)) {
t933=t931;
} else {
t933=0u;
}
var t934:u32=t933;
var t935:u32=t934;
var t936:u32=ink_f32_mul(t935,(t926).ink_f_scale);
var t937:u32=t936;
var t938:u32=ink_f32_add(t937,(t926).ink_f_bias);
var t939:u32=t938;
var t940:u32=ink_f32_mul(t939,(t926).ink_f_scale);
var t941:u32=t940;
var t942:u32;
if (ink_f32_lt(0u,t941)) {
t942=t940;
} else {
t942=0u;
}
var t943:u32=t942;
var t944:u32=t943;
var t945:u32=ink_f32_add(t944,(t926).ink_f_bias);
var t946:u32=t945;
var t947:R_Coefficients=t924;
var t948:u32=t946;
var t949:u32=t948;
var t950:u32=ink_f32_mul(t949,(t947).ink_f_scale);
var t951:u32=t950;
var t952:u32=ink_f32_add(t951,(t947).ink_f_bias);
var t953:u32=t952;
var t954:u32;
if (ink_f32_lt(0u,t953)) {
t954=t952;
} else {
t954=0u;
}
var t955:u32=t954;
var t956:u32=t955;
var t957:u32=ink_f32_mul(t956,(t947).ink_f_scale);
var t958:u32=t957;
var t959:u32=ink_f32_add(t958,(t947).ink_f_bias);
var t960:u32=t959;
var t961:u32=ink_f32_mul(t960,(t947).ink_f_scale);
var t962:u32=t961;
var t963:u32;
if (ink_f32_lt(0u,t962)) {
t963=t961;
} else {
t963=0u;
}
var t964:u32=t963;
var t965:u32=t964;
var t966:u32=ink_f32_add(t965,(t947).ink_f_bias);
var t967:u32=t966;
var t968:R_Coefficients=t922;
var t969:u32=t967;
var t970:R_Coefficients=t968;
var t971:u32=t969;
var t972:u32=t971;
var t973:u32=ink_f32_mul(t972,(t970).ink_f_scale);
var t974:u32=t973;
var t975:u32=ink_f32_add(t974,(t970).ink_f_bias);
var t976:u32=t975;
var t977:u32;
if (ink_f32_lt(0u,t976)) {
t977=t975;
} else {
t977=0u;
}
var t978:u32=t977;
var t979:u32=t978;
var t980:u32=ink_f32_mul(t979,(t970).ink_f_scale);
var t981:u32=t980;
var t982:u32=ink_f32_add(t981,(t970).ink_f_bias);
var t983:u32=t982;
var t984:u32=ink_f32_mul(t983,(t970).ink_f_scale);
var t985:u32=t984;
var t986:u32;
if (ink_f32_lt(0u,t985)) {
t986=t984;
} else {
t986=0u;
}
var t987:u32=t986;
var t988:u32=t987;
var t989:u32=ink_f32_add(t988,(t970).ink_f_bias);
var t990:u32=t989;
var t991:R_Coefficients=t968;
var t992:u32=t990;
var t993:u32=t992;
var t994:u32=ink_f32_mul(t993,(t991).ink_f_scale);
var t995:u32=t994;
var t996:u32=ink_f32_add(t995,(t991).ink_f_bias);
var t997:u32=t996;
var t998:u32;
if (ink_f32_lt(0u,t997)) {
t998=t996;
} else {
t998=0u;
}
var t999:u32=t998;
var t1000:u32=t999;
var t1001:u32=ink_f32_mul(t1000,(t991).ink_f_scale);
var t1002:u32=t1001;
var t1003:u32=ink_f32_add(t1002,(t991).ink_f_bias);
var t1004:u32=t1003;
var t1005:u32=ink_f32_mul(t1004,(t991).ink_f_scale);
var t1006:u32=t1005;
var t1007:u32;
if (ink_f32_lt(0u,t1006)) {
t1007=t1005;
} else {
t1007=0u;
}
var t1008:u32=t1007;
var t1009:u32=t1008;
var t1010:u32=ink_f32_add(t1009,(t991).ink_f_bias);
var t1011:u32=t1010;
var t1012:R_Coefficients=t920;
var t1013:u32=t1011;
var t1014:R_Coefficients=t1012;
var t1015:u32=t1013;
var t1016:R_Coefficients=t1014;
var t1017:u32=t1015;
var t1018:u32=t1017;
var t1019:u32=ink_f32_mul(t1018,(t1016).ink_f_scale);
var t1020:u32=t1019;
var t1021:u32=ink_f32_add(t1020,(t1016).ink_f_bias);
var t1022:u32=t1021;
var t1023:u32;
if (ink_f32_lt(0u,t1022)) {
t1023=t1021;
} else {
t1023=0u;
}
var t1024:u32=t1023;
var t1025:u32=t1024;
var t1026:u32=ink_f32_mul(t1025,(t1016).ink_f_scale);
var t1027:u32=t1026;
var t1028:u32=ink_f32_add(t1027,(t1016).ink_f_bias);
var t1029:u32=t1028;
var t1030:u32=ink_f32_mul(t1029,(t1016).ink_f_scale);
var t1031:u32=t1030;
var t1032:u32;
if (ink_f32_lt(0u,t1031)) {
t1032=t1030;
} else {
t1032=0u;
}
var t1033:u32=t1032;
var t1034:u32=t1033;
var t1035:u32=ink_f32_add(t1034,(t1016).ink_f_bias);
var t1036:u32=t1035;
var t1037:R_Coefficients=t1014;
var t1038:u32=t1036;
var t1039:u32=t1038;
var t1040:u32=ink_f32_mul(t1039,(t1037).ink_f_scale);
var t1041:u32=t1040;
var t1042:u32=ink_f32_add(t1041,(t1037).ink_f_bias);
var t1043:u32=t1042;
var t1044:u32;
if (ink_f32_lt(0u,t1043)) {
t1044=t1042;
} else {
t1044=0u;
}
var t1045:u32=t1044;
var t1046:u32=t1045;
var t1047:u32=ink_f32_mul(t1046,(t1037).ink_f_scale);
var t1048:u32=t1047;
var t1049:u32=ink_f32_add(t1048,(t1037).ink_f_bias);
var t1050:u32=t1049;
var t1051:u32=ink_f32_mul(t1050,(t1037).ink_f_scale);
var t1052:u32=t1051;
var t1053:u32;
if (ink_f32_lt(0u,t1052)) {
t1053=t1051;
} else {
t1053=0u;
}
var t1054:u32=t1053;
var t1055:u32=t1054;
var t1056:u32=ink_f32_add(t1055,(t1037).ink_f_bias);
var t1057:u32=t1056;
var t1058:R_Coefficients=t1012;
var t1059:u32=t1057;
var t1060:R_Coefficients=t1058;
var t1061:u32=t1059;
var t1062:u32=t1061;
var t1063:u32=ink_f32_mul(t1062,(t1060).ink_f_scale);
var t1064:u32=t1063;
var t1065:u32=ink_f32_add(t1064,(t1060).ink_f_bias);
var t1066:u32=t1065;
var t1067:u32;
if (ink_f32_lt(0u,t1066)) {
t1067=t1065;
} else {
t1067=0u;
}
var t1068:u32=t1067;
var t1069:u32=t1068;
var t1070:u32=ink_f32_mul(t1069,(t1060).ink_f_scale);
var t1071:u32=t1070;
var t1072:u32=ink_f32_add(t1071,(t1060).ink_f_bias);
var t1073:u32=t1072;
var t1074:u32=ink_f32_mul(t1073,(t1060).ink_f_scale);
var t1075:u32=t1074;
var t1076:u32;
if (ink_f32_lt(0u,t1075)) {
t1076=t1074;
} else {
t1076=0u;
}
var t1077:u32=t1076;
var t1078:u32=t1077;
var t1079:u32=ink_f32_add(t1078,(t1060).ink_f_bias);
var t1080:u32=t1079;
var t1081:R_Coefficients=t1058;
var t1082:u32=t1080;
var t1083:u32=t1082;
var t1084:u32=ink_f32_mul(t1083,(t1081).ink_f_scale);
var t1085:u32=t1084;
var t1086:u32=ink_f32_add(t1085,(t1081).ink_f_bias);
var t1087:u32=t1086;
var t1088:u32;
if (ink_f32_lt(0u,t1087)) {
t1088=t1086;
} else {
t1088=0u;
}
var t1089:u32=t1088;
var t1090:u32=t1089;
var t1091:u32=ink_f32_mul(t1090,(t1081).ink_f_scale);
var t1092:u32=t1091;
var t1093:u32=ink_f32_add(t1092,(t1081).ink_f_bias);
var t1094:u32=t1093;
var t1095:u32=ink_f32_mul(t1094,(t1081).ink_f_scale);
var t1096:u32=t1095;
var t1097:u32;
if (ink_f32_lt(0u,t1096)) {
t1097=t1095;
} else {
t1097=0u;
}
var t1098:u32=t1097;
var t1099:u32=t1098;
var t1100:u32=ink_f32_add(t1099,(t1081).ink_f_bias);
var t1101:u32=t1100;
var t1102:R_Coefficients=t734;
var t1103:u32=t1101;
var t1104:R_Coefficients=t1102;
var t1105:u32=t1103;
var t1106:R_Coefficients=t1104;
var t1107:u32=t1105;
var t1108:R_Coefficients=t1106;
var t1109:u32=t1107;
var t1110:R_Coefficients=t1108;
var t1111:u32=t1109;
var t1112:u32=t1111;
var t1113:u32=ink_f32_mul(t1112,(t1110).ink_f_scale);
var t1114:u32=t1113;
var t1115:u32=ink_f32_add(t1114,(t1110).ink_f_bias);
var t1116:u32=t1115;
var t1117:u32;
if (ink_f32_lt(0u,t1116)) {
t1117=t1115;
} else {
t1117=0u;
}
var t1118:u32=t1117;
var t1119:u32=t1118;
var t1120:u32=ink_f32_mul(t1119,(t1110).ink_f_scale);
var t1121:u32=t1120;
var t1122:u32=ink_f32_add(t1121,(t1110).ink_f_bias);
var t1123:u32=t1122;
var t1124:u32=ink_f32_mul(t1123,(t1110).ink_f_scale);
var t1125:u32=t1124;
var t1126:u32;
if (ink_f32_lt(0u,t1125)) {
t1126=t1124;
} else {
t1126=0u;
}
var t1127:u32=t1126;
var t1128:u32=t1127;
var t1129:u32=ink_f32_add(t1128,(t1110).ink_f_bias);
var t1130:u32=t1129;
var t1131:R_Coefficients=t1108;
var t1132:u32=t1130;
var t1133:u32=t1132;
var t1134:u32=ink_f32_mul(t1133,(t1131).ink_f_scale);
var t1135:u32=t1134;
var t1136:u32=ink_f32_add(t1135,(t1131).ink_f_bias);
var t1137:u32=t1136;
var t1138:u32;
if (ink_f32_lt(0u,t1137)) {
t1138=t1136;
} else {
t1138=0u;
}
var t1139:u32=t1138;
var t1140:u32=t1139;
var t1141:u32=ink_f32_mul(t1140,(t1131).ink_f_scale);
var t1142:u32=t1141;
var t1143:u32=ink_f32_add(t1142,(t1131).ink_f_bias);
var t1144:u32=t1143;
var t1145:u32=ink_f32_mul(t1144,(t1131).ink_f_scale);
var t1146:u32=t1145;
var t1147:u32;
if (ink_f32_lt(0u,t1146)) {
t1147=t1145;
} else {
t1147=0u;
}
var t1148:u32=t1147;
var t1149:u32=t1148;
var t1150:u32=ink_f32_add(t1149,(t1131).ink_f_bias);
var t1151:u32=t1150;
var t1152:R_Coefficients=t1106;
var t1153:u32=t1151;
var t1154:R_Coefficients=t1152;
var t1155:u32=t1153;
var t1156:u32=t1155;
var t1157:u32=ink_f32_mul(t1156,(t1154).ink_f_scale);
var t1158:u32=t1157;
var t1159:u32=ink_f32_add(t1158,(t1154).ink_f_bias);
var t1160:u32=t1159;
var t1161:u32;
if (ink_f32_lt(0u,t1160)) {
t1161=t1159;
} else {
t1161=0u;
}
var t1162:u32=t1161;
var t1163:u32=t1162;
var t1164:u32=ink_f32_mul(t1163,(t1154).ink_f_scale);
var t1165:u32=t1164;
var t1166:u32=ink_f32_add(t1165,(t1154).ink_f_bias);
var t1167:u32=t1166;
var t1168:u32=ink_f32_mul(t1167,(t1154).ink_f_scale);
var t1169:u32=t1168;
var t1170:u32;
if (ink_f32_lt(0u,t1169)) {
t1170=t1168;
} else {
t1170=0u;
}
var t1171:u32=t1170;
var t1172:u32=t1171;
var t1173:u32=ink_f32_add(t1172,(t1154).ink_f_bias);
var t1174:u32=t1173;
var t1175:R_Coefficients=t1152;
var t1176:u32=t1174;
var t1177:u32=t1176;
var t1178:u32=ink_f32_mul(t1177,(t1175).ink_f_scale);
var t1179:u32=t1178;
var t1180:u32=ink_f32_add(t1179,(t1175).ink_f_bias);
var t1181:u32=t1180;
var t1182:u32;
if (ink_f32_lt(0u,t1181)) {
t1182=t1180;
} else {
t1182=0u;
}
var t1183:u32=t1182;
var t1184:u32=t1183;
var t1185:u32=ink_f32_mul(t1184,(t1175).ink_f_scale);
var t1186:u32=t1185;
var t1187:u32=ink_f32_add(t1186,(t1175).ink_f_bias);
var t1188:u32=t1187;
var t1189:u32=ink_f32_mul(t1188,(t1175).ink_f_scale);
var t1190:u32=t1189;
var t1191:u32;
if (ink_f32_lt(0u,t1190)) {
t1191=t1189;
} else {
t1191=0u;
}
var t1192:u32=t1191;
var t1193:u32=t1192;
var t1194:u32=ink_f32_add(t1193,(t1175).ink_f_bias);
var t1195:u32=t1194;
var t1196:R_Coefficients=t1104;
var t1197:u32=t1195;
var t1198:R_Coefficients=t1196;
var t1199:u32=t1197;
var t1200:R_Coefficients=t1198;
var t1201:u32=t1199;
var t1202:u32=t1201;
var t1203:u32=ink_f32_mul(t1202,(t1200).ink_f_scale);
var t1204:u32=t1203;
var t1205:u32=ink_f32_add(t1204,(t1200).ink_f_bias);
var t1206:u32=t1205;
var t1207:u32;
if (ink_f32_lt(0u,t1206)) {
t1207=t1205;
} else {
t1207=0u;
}
var t1208:u32=t1207;
var t1209:u32=t1208;
var t1210:u32=ink_f32_mul(t1209,(t1200).ink_f_scale);
var t1211:u32=t1210;
var t1212:u32=ink_f32_add(t1211,(t1200).ink_f_bias);
var t1213:u32=t1212;
var t1214:u32=ink_f32_mul(t1213,(t1200).ink_f_scale);
var t1215:u32=t1214;
var t1216:u32;
if (ink_f32_lt(0u,t1215)) {
t1216=t1214;
} else {
t1216=0u;
}
var t1217:u32=t1216;
var t1218:u32=t1217;
var t1219:u32=ink_f32_add(t1218,(t1200).ink_f_bias);
var t1220:u32=t1219;
var t1221:R_Coefficients=t1198;
var t1222:u32=t1220;
var t1223:u32=t1222;
var t1224:u32=ink_f32_mul(t1223,(t1221).ink_f_scale);
var t1225:u32=t1224;
var t1226:u32=ink_f32_add(t1225,(t1221).ink_f_bias);
var t1227:u32=t1226;
var t1228:u32;
if (ink_f32_lt(0u,t1227)) {
t1228=t1226;
} else {
t1228=0u;
}
var t1229:u32=t1228;
var t1230:u32=t1229;
var t1231:u32=ink_f32_mul(t1230,(t1221).ink_f_scale);
var t1232:u32=t1231;
var t1233:u32=ink_f32_add(t1232,(t1221).ink_f_bias);
var t1234:u32=t1233;
var t1235:u32=ink_f32_mul(t1234,(t1221).ink_f_scale);
var t1236:u32=t1235;
var t1237:u32;
if (ink_f32_lt(0u,t1236)) {
t1237=t1235;
} else {
t1237=0u;
}
var t1238:u32=t1237;
var t1239:u32=t1238;
var t1240:u32=ink_f32_add(t1239,(t1221).ink_f_bias);
var t1241:u32=t1240;
var t1242:R_Coefficients=t1196;
var t1243:u32=t1241;
var t1244:R_Coefficients=t1242;
var t1245:u32=t1243;
var t1246:u32=t1245;
var t1247:u32=ink_f32_mul(t1246,(t1244).ink_f_scale);
var t1248:u32=t1247;
var t1249:u32=ink_f32_add(t1248,(t1244).ink_f_bias);
var t1250:u32=t1249;
var t1251:u32;
if (ink_f32_lt(0u,t1250)) {
t1251=t1249;
} else {
t1251=0u;
}
var t1252:u32=t1251;
var t1253:u32=t1252;
var t1254:u32=ink_f32_mul(t1253,(t1244).ink_f_scale);
var t1255:u32=t1254;
var t1256:u32=ink_f32_add(t1255,(t1244).ink_f_bias);
var t1257:u32=t1256;
var t1258:u32=ink_f32_mul(t1257,(t1244).ink_f_scale);
var t1259:u32=t1258;
var t1260:u32;
if (ink_f32_lt(0u,t1259)) {
t1260=t1258;
} else {
t1260=0u;
}
var t1261:u32=t1260;
var t1262:u32=t1261;
var t1263:u32=ink_f32_add(t1262,(t1244).ink_f_bias);
var t1264:u32=t1263;
var t1265:R_Coefficients=t1242;
var t1266:u32=t1264;
var t1267:u32=t1266;
var t1268:u32=ink_f32_mul(t1267,(t1265).ink_f_scale);
var t1269:u32=t1268;
var t1270:u32=ink_f32_add(t1269,(t1265).ink_f_bias);
var t1271:u32=t1270;
var t1272:u32;
if (ink_f32_lt(0u,t1271)) {
t1272=t1270;
} else {
t1272=0u;
}
var t1273:u32=t1272;
var t1274:u32=t1273;
var t1275:u32=ink_f32_mul(t1274,(t1265).ink_f_scale);
var t1276:u32=t1275;
var t1277:u32=ink_f32_add(t1276,(t1265).ink_f_bias);
var t1278:u32=t1277;
var t1279:u32=ink_f32_mul(t1278,(t1265).ink_f_scale);
var t1280:u32=t1279;
var t1281:u32;
if (ink_f32_lt(0u,t1280)) {
t1281=t1279;
} else {
t1281=0u;
}
var t1282:u32=t1281;
var t1283:u32=t1282;
var t1284:u32=ink_f32_add(t1283,(t1265).ink_f_bias);
var t1285:u32=t1284;
var t1286:R_Coefficients=t1102;
var t1287:u32=t1285;
var t1288:R_Coefficients=t1286;
var t1289:u32=t1287;
var t1290:R_Coefficients=t1288;
var t1291:u32=t1289;
var t1292:R_Coefficients=t1290;
var t1293:u32=t1291;
var t1294:u32=t1293;
var t1295:u32=ink_f32_mul(t1294,(t1292).ink_f_scale);
var t1296:u32=t1295;
var t1297:u32=ink_f32_add(t1296,(t1292).ink_f_bias);
var t1298:u32=t1297;
var t1299:u32;
if (ink_f32_lt(0u,t1298)) {
t1299=t1297;
} else {
t1299=0u;
}
var t1300:u32=t1299;
var t1301:u32=t1300;
var t1302:u32=ink_f32_mul(t1301,(t1292).ink_f_scale);
var t1303:u32=t1302;
var t1304:u32=ink_f32_add(t1303,(t1292).ink_f_bias);
var t1305:u32=t1304;
var t1306:u32=ink_f32_mul(t1305,(t1292).ink_f_scale);
var t1307:u32=t1306;
var t1308:u32;
if (ink_f32_lt(0u,t1307)) {
t1308=t1306;
} else {
t1308=0u;
}
var t1309:u32=t1308;
var t1310:u32=t1309;
var t1311:u32=ink_f32_add(t1310,(t1292).ink_f_bias);
var t1312:u32=t1311;
var t1313:R_Coefficients=t1290;
var t1314:u32=t1312;
var t1315:u32=t1314;
var t1316:u32=ink_f32_mul(t1315,(t1313).ink_f_scale);
var t1317:u32=t1316;
var t1318:u32=ink_f32_add(t1317,(t1313).ink_f_bias);
var t1319:u32=t1318;
var t1320:u32;
if (ink_f32_lt(0u,t1319)) {
t1320=t1318;
} else {
t1320=0u;
}
var t1321:u32=t1320;
var t1322:u32=t1321;
var t1323:u32=ink_f32_mul(t1322,(t1313).ink_f_scale);
var t1324:u32=t1323;
var t1325:u32=ink_f32_add(t1324,(t1313).ink_f_bias);
var t1326:u32=t1325;
var t1327:u32=ink_f32_mul(t1326,(t1313).ink_f_scale);
var t1328:u32=t1327;
var t1329:u32;
if (ink_f32_lt(0u,t1328)) {
t1329=t1327;
} else {
t1329=0u;
}
var t1330:u32=t1329;
var t1331:u32=t1330;
var t1332:u32=ink_f32_add(t1331,(t1313).ink_f_bias);
var t1333:u32=t1332;
var t1334:R_Coefficients=t1288;
var t1335:u32=t1333;
var t1336:R_Coefficients=t1334;
var t1337:u32=t1335;
var t1338:u32=t1337;
var t1339:u32=ink_f32_mul(t1338,(t1336).ink_f_scale);
var t1340:u32=t1339;
var t1341:u32=ink_f32_add(t1340,(t1336).ink_f_bias);
var t1342:u32=t1341;
var t1343:u32;
if (ink_f32_lt(0u,t1342)) {
t1343=t1341;
} else {
t1343=0u;
}
var t1344:u32=t1343;
var t1345:u32=t1344;
var t1346:u32=ink_f32_mul(t1345,(t1336).ink_f_scale);
var t1347:u32=t1346;
var t1348:u32=ink_f32_add(t1347,(t1336).ink_f_bias);
var t1349:u32=t1348;
var t1350:u32=ink_f32_mul(t1349,(t1336).ink_f_scale);
var t1351:u32=t1350;
var t1352:u32;
if (ink_f32_lt(0u,t1351)) {
t1352=t1350;
} else {
t1352=0u;
}
var t1353:u32=t1352;
var t1354:u32=t1353;
var t1355:u32=ink_f32_add(t1354,(t1336).ink_f_bias);
var t1356:u32=t1355;
var t1357:R_Coefficients=t1334;
var t1358:u32=t1356;
var t1359:u32=t1358;
var t1360:u32=ink_f32_mul(t1359,(t1357).ink_f_scale);
var t1361:u32=t1360;
var t1362:u32=ink_f32_add(t1361,(t1357).ink_f_bias);
var t1363:u32=t1362;
var t1364:u32;
if (ink_f32_lt(0u,t1363)) {
t1364=t1362;
} else {
t1364=0u;
}
var t1365:u32=t1364;
var t1366:u32=t1365;
var t1367:u32=ink_f32_mul(t1366,(t1357).ink_f_scale);
var t1368:u32=t1367;
var t1369:u32=ink_f32_add(t1368,(t1357).ink_f_bias);
var t1370:u32=t1369;
var t1371:u32=ink_f32_mul(t1370,(t1357).ink_f_scale);
var t1372:u32=t1371;
var t1373:u32;
if (ink_f32_lt(0u,t1372)) {
t1373=t1371;
} else {
t1373=0u;
}
var t1374:u32=t1373;
var t1375:u32=t1374;
var t1376:u32=ink_f32_add(t1375,(t1357).ink_f_bias);
var t1377:u32=t1376;
var t1378:R_Coefficients=t1286;
var t1379:u32=t1377;
var t1380:R_Coefficients=t1378;
var t1381:u32=t1379;
var t1382:R_Coefficients=t1380;
var t1383:u32=t1381;
var t1384:u32=t1383;
var t1385:u32=ink_f32_mul(t1384,(t1382).ink_f_scale);
var t1386:u32=t1385;
var t1387:u32=ink_f32_add(t1386,(t1382).ink_f_bias);
var t1388:u32=t1387;
var t1389:u32;
if (ink_f32_lt(0u,t1388)) {
t1389=t1387;
} else {
t1389=0u;
}
var t1390:u32=t1389;
var t1391:u32=t1390;
var t1392:u32=ink_f32_mul(t1391,(t1382).ink_f_scale);
var t1393:u32=t1392;
var t1394:u32=ink_f32_add(t1393,(t1382).ink_f_bias);
var t1395:u32=t1394;
var t1396:u32=ink_f32_mul(t1395,(t1382).ink_f_scale);
var t1397:u32=t1396;
var t1398:u32;
if (ink_f32_lt(0u,t1397)) {
t1398=t1396;
} else {
t1398=0u;
}
var t1399:u32=t1398;
var t1400:u32=t1399;
var t1401:u32=ink_f32_add(t1400,(t1382).ink_f_bias);
var t1402:u32=t1401;
var t1403:R_Coefficients=t1380;
var t1404:u32=t1402;
var t1405:u32=t1404;
var t1406:u32=ink_f32_mul(t1405,(t1403).ink_f_scale);
var t1407:u32=t1406;
var t1408:u32=ink_f32_add(t1407,(t1403).ink_f_bias);
var t1409:u32=t1408;
var t1410:u32;
if (ink_f32_lt(0u,t1409)) {
t1410=t1408;
} else {
t1410=0u;
}
var t1411:u32=t1410;
var t1412:u32=t1411;
var t1413:u32=ink_f32_mul(t1412,(t1403).ink_f_scale);
var t1414:u32=t1413;
var t1415:u32=ink_f32_add(t1414,(t1403).ink_f_bias);
var t1416:u32=t1415;
var t1417:u32=ink_f32_mul(t1416,(t1403).ink_f_scale);
var t1418:u32=t1417;
var t1419:u32;
if (ink_f32_lt(0u,t1418)) {
t1419=t1417;
} else {
t1419=0u;
}
var t1420:u32=t1419;
var t1421:u32=t1420;
var t1422:u32=ink_f32_add(t1421,(t1403).ink_f_bias);
var t1423:u32=t1422;
var t1424:R_Coefficients=t1378;
var t1425:u32=t1423;
var t1426:R_Coefficients=t1424;
var t1427:u32=t1425;
var t1428:u32=t1427;
var t1429:u32=ink_f32_mul(t1428,(t1426).ink_f_scale);
var t1430:u32=t1429;
var t1431:u32=ink_f32_add(t1430,(t1426).ink_f_bias);
var t1432:u32=t1431;
var t1433:u32;
if (ink_f32_lt(0u,t1432)) {
t1433=t1431;
} else {
t1433=0u;
}
var t1434:u32=t1433;
var t1435:u32=t1434;
var t1436:u32=ink_f32_mul(t1435,(t1426).ink_f_scale);
var t1437:u32=t1436;
var t1438:u32=ink_f32_add(t1437,(t1426).ink_f_bias);
var t1439:u32=t1438;
var t1440:u32=ink_f32_mul(t1439,(t1426).ink_f_scale);
var t1441:u32=t1440;
var t1442:u32;
if (ink_f32_lt(0u,t1441)) {
t1442=t1440;
} else {
t1442=0u;
}
var t1443:u32=t1442;
var t1444:u32=t1443;
var t1445:u32=ink_f32_add(t1444,(t1426).ink_f_bias);
var t1446:u32=t1445;
var t1447:R_Coefficients=t1424;
var t1448:u32=t1446;
var t1449:u32=t1448;
var t1450:u32=ink_f32_mul(t1449,(t1447).ink_f_scale);
var t1451:u32=t1450;
var t1452:u32=ink_f32_add(t1451,(t1447).ink_f_bias);
var t1453:u32=t1452;
var t1454:u32;
if (ink_f32_lt(0u,t1453)) {
t1454=t1452;
} else {
t1454=0u;
}
var t1455:u32=t1454;
var t1456:u32=t1455;
var t1457:u32=ink_f32_mul(t1456,(t1447).ink_f_scale);
var t1458:u32=t1457;
var t1459:u32=ink_f32_add(t1458,(t1447).ink_f_bias);
var t1460:u32=t1459;
var t1461:u32=ink_f32_mul(t1460,(t1447).ink_f_scale);
var t1462:u32=t1461;
var t1463:u32;
if (ink_f32_lt(0u,t1462)) {
t1463=t1461;
} else {
t1463=0u;
}
var t1464:u32=t1463;
var t1465:u32=t1464;
var t1466:u32=ink_f32_add(t1465,(t1447).ink_f_bias);
var t1467:u32=t1466;
output[0u+0u]=bitcast<u32>(t1467);


}