// Exact wrapping u64 over two storage lanes. No floating point intermediates.
struct InkU64 {lo:u32,hi:u32,}
struct InkDiv64 {quotient:InkU64,remainder:InkU64,}
fn ink_u64_shl(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64(a.lo<<k,(a.hi<<k)|(a.lo>>(32u-k)));}return InkU64(0u,a.lo<<(k-32u));}
fn ink_u64_shr(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64((a.lo>>k)|(a.hi<<(32u-k)),a.hi>>k);}return InkU64(a.hi>>(k-32u),0u);}
fn ink_u64_rol(a:InkU64,count:u32)->InkU64{let k=count&63u;let l=ink_u64_shl(a,k);let r=ink_u64_shr(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_ror(a:InkU64,count:u32)->InkU64{let k=count&63u;let r=ink_u64_shr(a,k);let l=ink_u64_shl(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_eq(a:InkU64,b:InkU64)->bool{return a.lo==b.lo&&a.hi==b.hi;}
fn ink_u64_lt(a:InkU64,b:InkU64)->bool{return a.hi<b.hi||(a.hi==b.hi&&a.lo<b.lo);}
fn ink_u64_add(a:InkU64,b:InkU64)->InkU64{let lo=a.lo+b.lo;return InkU64(lo,a.hi+b.hi+select(0u,1u,lo<a.lo));}
fn ink_u64_sub(a:InkU64,b:InkU64)->InkU64{return InkU64(a.lo-b.lo,a.hi-b.hi-select(0u,1u,a.lo<b.lo));}
fn ink_u64_mul(a:InkU64,b:InkU64)->InkU64{let al=a.lo&65535u;let ah=a.lo>>16u;let bl=b.lo&65535u;let bh=b.lo>>16u;let p=al*bl;let x=ah*bl;let y=al*bh;let mid=(p>>16u)+(x&65535u)+(y&65535u);let high=ah*bh+(x>>16u)+(y>>16u)+(mid>>16u);return InkU64((mid<<16u)|(p&65535u),high+a.lo*b.hi+a.hi*b.lo);}
fn ink_u64_div(a:InkU64,b:InkU64)->InkDiv64{var q=InkU64(0u,0u);var r=InkU64(0u,0u);var cursor=64u;loop{if(cursor==0u){break;}cursor--;var bit=0u;if(cursor>=32u){bit=(a.hi>>(cursor-32u))&1u;}else{bit=(a.lo>>cursor)&1u;}let overflow=r.hi>>31u;r=InkU64((r.lo<<1u)|bit,(r.hi<<1u)|(r.lo>>31u));if(overflow!=0u||!ink_u64_lt(r,b)){r=ink_u64_sub(r,b);if(cursor>=32u){q.hi|=1u<<(cursor-32u);}else{q.lo|=1u<<cursor;}}}return InkDiv64(q,r);}
// Binary32 evaluated with integer lanes: round-to-nearest, ties-to-even,
// gradual underflow, signed zero and canonical arithmetic NaN.
fn ink_f32_nan(x:u32)->bool{return (x&0x7fffffffu)>0x7f800000u;}
fn ink_f32_eq(a:u32,b:u32)->bool{return !ink_f32_nan(a)&&!ink_f32_nan(b)&&(a==b||((a|b)&0x7fffffffu)==0u);}
fn ink_f32_lt(a:u32,b:u32)->bool{
 if(ink_f32_nan(a)||ink_f32_nan(b)||ink_f32_eq(a,b)){return false;}
 if((a^b)&0x80000000u)!=0u{return (a&0x80000000u)!=0u;}
 if((a&0x80000000u)!=0u){return a>b;}return a<b;
}
fn ink_f32_jam(x:u32,n:u32)->u32{if(n==0u){return x;}if(n>=32u){return select(0u,1u,x!=0u);}return (x>>n)|select(0u,1u,(x&((1u<<n)-1u))!=0u);}
fn ink_f32_round(sign:u32,exponent:i32,extended:u32)->u32{
 var e=exponent;var s=extended;
 if(e<1i){s=ink_f32_jam(s,u32(1i-e));e=1i;}
 let tail=s&7u;var sig=s>>3u;
 if(tail>4u||(tail==4u&&(sig&1u)!=0u)){sig++;}
 if(sig>=0x1000000u){sig>>=1u;e++;}
 if(e>=255i){return sign|0x7f800000u;}
 if(sig==0u){return sign;}
 let raw=select(u32(e),0u,e==1i&&sig<0x800000u);
 return sign|(raw<<23u)|(sig&0x7fffffu);
}
fn ink_f32_add(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 var x=a;var y=b;if((x&0x7fffffffu)<(y&0x7fffffffu)){x=b;y=a;}
 let ax=x&0x7fffffffu;let ay=y&0x7fffffffu;let sign=x&0x80000000u;
 if(ax==0x7f800000u){if(ay==ax&&((x^y)&0x80000000u)!=0u){return 0x7fc00000u;}return x;}
 let rx=(x>>23u)&255u;let ry=(y>>23u)&255u;var e=i32(max(rx,1u));
 var sx=((x&0x7fffffu)|select(0u,0x800000u,rx!=0u))<<3u;
 let sy=ink_f32_jam(((y&0x7fffffu)|select(0u,0x800000u,ry!=0u))<<3u,u32(e)-max(ry,1u));
 if(((x^y)&0x80000000u)==0u){sx+=sy;if(sx>=0x8000000u){sx=ink_f32_jam(sx,1u);e++;}}
 else{sx-=sy;if(sx==0u){return 0u;}loop{if(sx>=0x4000000u||e<=1i){break;}sx<<=1u;e--;}}
 return ink_f32_round(sign,e,sx);
}
fn ink_f32_sub(a:u32,b:u32)->u32{return ink_f32_add(a,b^0x80000000u);}
fn ink_f32_mul(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(aa==0x7f800000u||bb==0x7f800000u){if(aa==0u||bb==0u){return 0x7fc00000u;}return sign|0x7f800000u;}
 if(aa==0u||bb==0u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u));var eb=i32(max(rb,1u));
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 let product=ink_u64_mul(InkU64(sa,0u),InkU64(sb,0u));let high=(product.hi&0x8000u)!=0u;
 let shift=select(20u,21u,high);let extended=(product.lo>>shift)|(product.hi<<(32u-shift))|select(0u,1u,(product.lo&((1u<<shift)-1u))!=0u);
 return ink_f32_round(sign,ea+eb-127i+select(0i,1i,high),extended);
}
// Exact sqrt and division use integer significands, independent of WGSL float
// approximation allowances and device flush-to-zero behavior.
fn ink_f32_sqrt(x:u32)->u32{
 let a=x&0x7fffffffu;if(a==0u){return x;}
 if(a>0x7f800000u||(x&0x80000000u)!=0u){return 0x7fc00000u;}
 if(a==0x7f800000u){return x;}
 let raw=(x>>23u)&255u;var m=(x&0x7fffffu)|select(0u,0x800000u,raw!=0u);var e=i32(max(raw,1u))-127i;
 loop{if(m>=0x800000u){break;}m<<=1u;e--;}
 let odd=e&1i;var half=(e-odd)/2i;let shift=23u+u32(odd);
 let n=InkU64(m<<shift,m>>(32u-shift));var lo=0u;var hi=0x1000000u;
 loop{if(lo+1u>=hi){break;}let mid=(lo+hi)>>1u;let sq=ink_u64_mul(InkU64(mid,0u),InkU64(mid,0u));if(!ink_u64_lt(n,sq)){lo=mid;}else{hi=mid;}}
 let sq=ink_u64_mul(InkU64(lo,0u),InkU64(lo,0u));let rem=ink_u64_sub(n,sq);
 if(ink_u64_lt(InkU64(lo,0u),rem)){lo++;}
 if(lo==0x1000000u){lo>>=1u;half++;}
 return (u32(half+127i)<<23u)|(lo&0x7fffffu);
}
fn ink_f32_div(a:u32,b:u32)->u32{
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(ink_f32_nan(a)||ink_f32_nan(b)||(aa==0u&&bb==0u)||(aa==0x7f800000u&&bb==aa)){return 0x7fc00000u;}
 if(aa==0x7f800000u||bb==0u){return sign|0x7f800000u;}
 if(aa==0u||bb==0x7f800000u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u))-127i;var eb=i32(max(rb,1u))-127i;
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 var e=ea-eb;if(sa<sb){sa<<=1u;e--;}
 let division=ink_u64_div(InkU64(sa<<26u,sa>>6u),InkU64(sb,0u));
 let extended=division.quotient.lo|select(0u,1u,!ink_u64_eq(division.remainder,InkU64(0u,0u)));
 return ink_f32_round(sign,e+127i,extended);
}
// mode: 0 trunc, 1 floor, 2 ceil, 3 ties-to-even.
fn ink_f32_integral(x:u32,mode:u32)->u32{
 let a=x&0x7fffffffu;let sign=x&0x80000000u;
 if(a>0x7f800000u){return 0x7fc00000u;}if(a>=0x4b000000u||a==0u){return x;}
 let e=i32((x>>23u)&255u)-127i;
 if(e<0i){var up=false;if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){up=a>0x3f000000u;}return sign|select(0u,0x3f800000u,up);}
 let shift=u32(23i-e);let mask=(1u<<shift)-1u;let fraction=a&mask;var rounded=a&~mask;var up=false;
 if(fraction!=0u){if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){let half=1u<<(shift-1u);up=fraction>half||(fraction==half&&((rounded>>shift)&1u)!=0u);}}
 if(up){rounded+=1u<<shift;}return sign|rounded;
}
fn ink_f32_from_u64(x:InkU64)->u32{
 if(ink_u64_eq(x,InkU64(0u,0u))){return 0u;}
 let leading=select(countLeadingZeros(x.lo)+32u,countLeadingZeros(x.hi),x.hi!=0u);let e=63u-leading;
 if(e<=23u){return ((e+127u)<<23u)|((x.lo<<(23u-e))&0x7fffffu);}
 let shift=e-23u;var sig=0u;var rem=InkU64(0u,0u);var half=InkU64(0u,0u);
 if(shift<32u){sig=(x.lo>>shift)|(x.hi<<(32u-shift));rem=InkU64(x.lo&((1u<<shift)-1u),0u);half=InkU64(1u<<(shift-1u),0u);}
 else if(shift==32u){sig=x.hi;rem=InkU64(x.lo,0u);half=InkU64(0x80000000u,0u);}
 else{sig=x.hi>>(shift-32u);rem=InkU64(x.lo,x.hi&((1u<<(shift-32u))-1u));half=InkU64(0u,1u<<(shift-33u));}
 if(ink_u64_lt(half,rem)||(ink_u64_eq(rem,half)&&(sig&1u)!=0u)){sig++;}
 var exponent=e+127u;if(sig==0x1000000u){sig>>=1u;exponent++;}
 return (exponent<<23u)|(sig&0x7fffffu);
}
fn ink_f32_from_i32(x:i32)->u32{let neg=x<0i;let magnitude=select(u32(x),0u-u32(x),neg);return ink_f32_from_u64(InkU64(magnitude,0u))|select(0u,0x80000000u,neg);}
struct InkBuffer_u32{data:array<u32,64>,length:u32,}
struct InkBuffer_InkU64{data:array<InkU64,64>,length:u32,}
struct InkBuffer_i32{data:array<i32,64>,length:u32,}
struct InkBuffer_bool{data:array<bool,64>,length:u32,}
struct R_Coefficients{ink_f_scale:u32,ink_f_bias:u32,}
@group(0) @binding(0) var<storage,read> a0:array<u32>;
@group(0) @binding(1) var<storage,read> a1:array<u32>;
@group(0) @binding(2) var<storage,read_write> output:array<u32>;
@compute @workgroup_size(1) fn main(@builtin(global_invocation_id) gid:vec3<u32>){
if(gid.x!=0u){return;}var t0:R_Coefficients=R_Coefficients(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t1:u32=a1[0u+(0u)*1u+0u];
var t2:R_Coefficients=t0;
var t3:u32=t1;
var t4:R_Coefficients=t2;
var t5:u32=t3;
var t6:R_Coefficients=t4;
var t7:u32=t5;
var t8:R_Coefficients=t6;
var t9:u32=t7;
var t10:u32=t9;
var t11:u32=ink_f32_mul(t10,(t8).ink_f_scale);
var t12:u32=t11;
var t13:u32=ink_f32_add(t12,(t8).ink_f_bias);
var t14:u32=t13;
var t15:u32;
if (ink_f32_lt(0u,t14)) {
t15=t13;
} else {
t15=0u;
}
var t16:u32=t15;
var t17:u32=t16;
var t18:u32=ink_f32_mul(t17,(t8).ink_f_scale);
var t19:u32=t18;
var t20:u32=ink_f32_add(t19,(t8).ink_f_bias);
var t21:u32=t20;
var t22:u32=ink_f32_mul(t21,(t8).ink_f_scale);
var t23:u32=t22;
var t24:u32;
if (ink_f32_lt(0u,t23)) {
t24=t22;
} else {
t24=0u;
}
var t25:u32=t24;
var t26:u32=t25;
var t27:u32=ink_f32_add(t26,(t8).ink_f_bias);
var t28:u32=t27;
var t29:R_Coefficients=t6;
var t30:u32=t28;
var t31:u32=t30;
var t32:u32=ink_f32_mul(t31,(t29).ink_f_scale);
var t33:u32=t32;
var t34:u32=ink_f32_add(t33,(t29).ink_f_bias);
var t35:u32=t34;
var t36:u32;
if (ink_f32_lt(0u,t35)) {
t36=t34;
} else {
t36=0u;
}
var t37:u32=t36;
var t38:u32=t37;
var t39:u32=ink_f32_mul(t38,(t29).ink_f_scale);
var t40:u32=t39;
var t41:u32=ink_f32_add(t40,(t29).ink_f_bias);
var t42:u32=t41;
var t43:u32=ink_f32_mul(t42,(t29).ink_f_scale);
var t44:u32=t43;
var t45:u32;
if (ink_f32_lt(0u,t44)) {
t45=t43;
} else {
t45=0u;
}
var t46:u32=t45;
var t47:u32=t46;
var t48:u32=ink_f32_add(t47,(t29).ink_f_bias);
var t49:u32=t48;
var t50:R_Coefficients=t4;
var t51:u32=t49;
var t52:R_Coefficients=t50;
var t53:u32=t51;
var t54:u32=t53;
var t55:u32=ink_f32_mul(t54,(t52).ink_f_scale);
var t56:u32=t55;
var t57:u32=ink_f32_add(t56,(t52).ink_f_bias);
var t58:u32=t57;
var t59:u32;
if (ink_f32_lt(0u,t58)) {
t59=t57;
} else {
t59=0u;
}
var t60:u32=t59;
var t61:u32=t60;
var t62:u32=ink_f32_mul(t61,(t52).ink_f_scale);
var t63:u32=t62;
var t64:u32=ink_f32_add(t63,(t52).ink_f_bias);
var t65:u32=t64;
var t66:u32=ink_f32_mul(t65,(t52).ink_f_scale);
var t67:u32=t66;
var t68:u32;
if (ink_f32_lt(0u,t67)) {
t68=t66;
} else {
t68=0u;
}
var t69:u32=t68;
var t70:u32=t69;
var t71:u32=ink_f32_add(t70,(t52).ink_f_bias);
var t72:u32=t71;
var t73:R_Coefficients=t50;
var t74:u32=t72;
var t75:u32=t74;
var t76:u32=ink_f32_mul(t75,(t73).ink_f_scale);
var t77:u32=t76;
var t78:u32=ink_f32_add(t77,(t73).ink_f_bias);
var t79:u32=t78;
var t80:u32;
if (ink_f32_lt(0u,t79)) {
t80=t78;
} else {
t80=0u;
}
var t81:u32=t80;
var t82:u32=t81;
var t83:u32=ink_f32_mul(t82,(t73).ink_f_scale);
var t84:u32=t83;
var t85:u32=ink_f32_add(t84,(t73).ink_f_bias);
var t86:u32=t85;
var t87:u32=ink_f32_mul(t86,(t73).ink_f_scale);
var t88:u32=t87;
var t89:u32;
if (ink_f32_lt(0u,t88)) {
t89=t87;
} else {
t89=0u;
}
var t90:u32=t89;
var t91:u32=t90;
var t92:u32=ink_f32_add(t91,(t73).ink_f_bias);
var t93:u32=t92;
var t94:R_Coefficients=t2;
var t95:u32=t93;
var t96:R_Coefficients=t94;
var t97:u32=t95;
var t98:R_Coefficients=t96;
var t99:u32=t97;
var t100:u32=t99;
var t101:u32=ink_f32_mul(t100,(t98).ink_f_scale);
var t102:u32=t101;
var t103:u32=ink_f32_add(t102,(t98).ink_f_bias);
var t104:u32=t103;
var t105:u32;
if (ink_f32_lt(0u,t104)) {
t105=t103;
} else {
t105=0u;
}
var t106:u32=t105;
var t107:u32=t106;
var t108:u32=ink_f32_mul(t107,(t98).ink_f_scale);
var t109:u32=t108;
var t110:u32=ink_f32_add(t109,(t98).ink_f_bias);
var t111:u32=t110;
var t112:u32=ink_f32_mul(t111,(t98).ink_f_scale);
var t113:u32=t112;
var t114:u32;
if (ink_f32_lt(0u,t113)) {
t114=t112;
} else {
t114=0u;
}
var t115:u32=t114;
var t116:u32=t115;
var t117:u32=ink_f32_add(t116,(t98).ink_f_bias);
var t118:u32=t117;
var t119:R_Coefficients=t96;
var t120:u32=t118;
var t121:u32=t120;
var t122:u32=ink_f32_mul(t121,(t119).ink_f_scale);
var t123:u32=t122;
var t124:u32=ink_f32_add(t123,(t119).ink_f_bias);
var t125:u32=t124;
var t126:u32;
if (ink_f32_lt(0u,t125)) {
t126=t124;
} else {
t126=0u;
}
var t127:u32=t126;
var t128:u32=t127;
var t129:u32=ink_f32_mul(t128,(t119).ink_f_scale);
var t130:u32=t129;
var t131:u32=ink_f32_add(t130,(t119).ink_f_bias);
var t132:u32=t131;
var t133:u32=ink_f32_mul(t132,(t119).ink_f_scale);
var t134:u32=t133;
var t135:u32;
if (ink_f32_lt(0u,t134)) {
t135=t133;
} else {
t135=0u;
}
var t136:u32=t135;
var t137:u32=t136;
var t138:u32=ink_f32_add(t137,(t119).ink_f_bias);
var t139:u32=t138;
var t140:R_Coefficients=t94;
var t141:u32=t139;
var t142:R_Coefficients=t140;
var t143:u32=t141;
var t144:u32=t143;
var t145:u32=ink_f32_mul(t144,(t142).ink_f_scale);
var t146:u32=t145;
var t147:u32=ink_f32_add(t146,(t142).ink_f_bias);
var t148:u32=t147;
var t149:u32;
if (ink_f32_lt(0u,t148)) {
t149=t147;
} else {
t149=0u;
}
var t150:u32=t149;
var t151:u32=t150;
var t152:u32=ink_f32_mul(t151,(t142).ink_f_scale);
var t153:u32=t152;
var t154:u32=ink_f32_add(t153,(t142).ink_f_bias);
var t155:u32=t154;
var t156:u32=ink_f32_mul(t155,(t142).ink_f_scale);
var t157:u32=t156;
var t158:u32;
if (ink_f32_lt(0u,t157)) {
t158=t156;
} else {
t158=0u;
}
var t159:u32=t158;
var t160:u32=t159;
var t161:u32=ink_f32_add(t160,(t142).ink_f_bias);
var t162:u32=t161;
var t163:R_Coefficients=t140;
var t164:u32=t162;
var t165:u32=t164;
var t166:u32=ink_f32_mul(t165,(t163).ink_f_scale);
var t167:u32=t166;
var t168:u32=ink_f32_add(t167,(t163).ink_f_bias);
var t169:u32=t168;
var t170:u32;
if (ink_f32_lt(0u,t169)) {
t170=t168;
} else {
t170=0u;
}
var t171:u32=t170;
var t172:u32=t171;
var t173:u32=ink_f32_mul(t172,(t163).ink_f_scale);
var t174:u32=t173;
var t175:u32=ink_f32_add(t174,(t163).ink_f_bias);
var t176:u32=t175;
var t177:u32=ink_f32_mul(t176,(t163).ink_f_scale);
var t178:u32=t177;
var t179:u32;
if (ink_f32_lt(0u,t178)) {
t179=t177;
} else {
t179=0u;
}
var t180:u32=t179;
var t181:u32=t180;
var t182:u32=ink_f32_add(t181,(t163).ink_f_bias);
var t183:u32=t182;
var t184:R_Coefficients=t0;
var t185:u32=t183;
var t186:R_Coefficients=t184;
var t187:u32=t185;
var t188:R_Coefficients=t186;
var t189:u32=t187;
var t190:R_Coefficients=t188;
var t191:u32=t189;
var t192:u32=t191;
var t193:u32=ink_f32_mul(t192,(t190).ink_f_scale);
var t194:u32=t193;
var t195:u32=ink_f32_add(t194,(t190).ink_f_bias);
var t196:u32=t195;
var t197:u32;
if (ink_f32_lt(0u,t196)) {
t197=t195;
} else {
t197=0u;
}
var t198:u32=t197;
var t199:u32=t198;
var t200:u32=ink_f32_mul(t199,(t190).ink_f_scale);
var t201:u32=t200;
var t202:u32=ink_f32_add(t201,(t190).ink_f_bias);
var t203:u32=t202;
var t204:u32=ink_f32_mul(t203,(t190).ink_f_scale);
var t205:u32=t204;
var t206:u32;
if (ink_f32_lt(0u,t205)) {
t206=t204;
} else {
t206=0u;
}
var t207:u32=t206;
var t208:u32=t207;
var t209:u32=ink_f32_add(t208,(t190).ink_f_bias);
var t210:u32=t209;
var t211:R_Coefficients=t188;
var t212:u32=t210;
var t213:u32=t212;
var t214:u32=ink_f32_mul(t213,(t211).ink_f_scale);
var t215:u32=t214;
var t216:u32=ink_f32_add(t215,(t211).ink_f_bias);
var t217:u32=t216;
var t218:u32;
if (ink_f32_lt(0u,t217)) {
t218=t216;
} else {
t218=0u;
}
var t219:u32=t218;
var t220:u32=t219;
var t221:u32=ink_f32_mul(t220,(t211).ink_f_scale);
var t222:u32=t221;
var t223:u32=ink_f32_add(t222,(t211).ink_f_bias);
var t224:u32=t223;
var t225:u32=ink_f32_mul(t224,(t211).ink_f_scale);
var t226:u32=t225;
var t227:u32;
if (ink_f32_lt(0u,t226)) {
t227=t225;
} else {
t227=0u;
}
var t228:u32=t227;
var t229:u32=t228;
var t230:u32=ink_f32_add(t229,(t211).ink_f_bias);
var t231:u32=t230;
var t232:R_Coefficients=t186;
var t233:u32=t231;
var t234:R_Coefficients=t232;
var t235:u32=t233;
var t236:u32=t235;
var t237:u32=ink_f32_mul(t236,(t234).ink_f_scale);
var t238:u32=t237;
var t239:u32=ink_f32_add(t238,(t234).ink_f_bias);
var t240:u32=t239;
var t241:u32;
if (ink_f32_lt(0u,t240)) {
t241=t239;
} else {
t241=0u;
}
var t242:u32=t241;
var t243:u32=t242;
var t244:u32=ink_f32_mul(t243,(t234).ink_f_scale);
var t245:u32=t244;
var t246:u32=ink_f32_add(t245,(t234).ink_f_bias);
var t247:u32=t246;
var t248:u32=ink_f32_mul(t247,(t234).ink_f_scale);
var t249:u32=t248;
var t250:u32;
if (ink_f32_lt(0u,t249)) {
t250=t248;
} else {
t250=0u;
}
var t251:u32=t250;
var t252:u32=t251;
var t253:u32=ink_f32_add(t252,(t234).ink_f_bias);
var t254:u32=t253;
var t255:R_Coefficients=t232;
var t256:u32=t254;
var t257:u32=t256;
var t258:u32=ink_f32_mul(t257,(t255).ink_f_scale);
var t259:u32=t258;
var t260:u32=ink_f32_add(t259,(t255).ink_f_bias);
var t261:u32=t260;
var t262:u32;
if (ink_f32_lt(0u,t261)) {
t262=t260;
} else {
t262=0u;
}
var t263:u32=t262;
var t264:u32=t263;
var t265:u32=ink_f32_mul(t264,(t255).ink_f_scale);
var t266:u32=t265;
var t267:u32=ink_f32_add(t266,(t255).ink_f_bias);
var t268:u32=t267;
var t269:u32=ink_f32_mul(t268,(t255).ink_f_scale);
var t270:u32=t269;
var t271:u32;
if (ink_f32_lt(0u,t270)) {
t271=t269;
} else {
t271=0u;
}
var t272:u32=t271;
var t273:u32=t272;
var t274:u32=ink_f32_add(t273,(t255).ink_f_bias);
var t275:u32=t274;
var t276:R_Coefficients=t184;
var t277:u32=t275;
var t278:R_Coefficients=t276;
var t279:u32=t277;
var t280:R_Coefficients=t278;
var t281:u32=t279;
var t282:u32=t281;
var t283:u32=ink_f32_mul(t282,(t280).ink_f_scale);
var t284:u32=t283;
var t285:u32=ink_f32_add(t284,(t280).ink_f_bias);
var t286:u32=t285;
var t287:u32;
if (ink_f32_lt(0u,t286)) {
t287=t285;
} else {
t287=0u;
}
var t288:u32=t287;
var t289:u32=t288;
var t290:u32=ink_f32_mul(t289,(t280).ink_f_scale);
var t291:u32=t290;
var t292:u32=ink_f32_add(t291,(t280).ink_f_bias);
var t293:u32=t292;
var t294:u32=ink_f32_mul(t293,(t280).ink_f_scale);
var t295:u32=t294;
var t296:u32;
if (ink_f32_lt(0u,t295)) {
t296=t294;
} else {
t296=0u;
}
var t297:u32=t296;
var t298:u32=t297;
var t299:u32=ink_f32_add(t298,(t280).ink_f_bias);
var t300:u32=t299;
var t301:R_Coefficients=t278;
var t302:u32=t300;
var t303:u32=t302;
var t304:u32=ink_f32_mul(t303,(t301).ink_f_scale);
var t305:u32=t304;
var t306:u32=ink_f32_add(t305,(t301).ink_f_bias);
var t307:u32=t306;
var t308:u32;
if (ink_f32_lt(0u,t307)) {
t308=t306;
} else {
t308=0u;
}
var t309:u32=t308;
var t310:u32=t309;
var t311:u32=ink_f32_mul(t310,(t301).ink_f_scale);
var t312:u32=t311;
var t313:u32=ink_f32_add(t312,(t301).ink_f_bias);
var t314:u32=t313;
var t315:u32=ink_f32_mul(t314,(t301).ink_f_scale);
var t316:u32=t315;
var t317:u32;
if (ink_f32_lt(0u,t316)) {
t317=t315;
} else {
t317=0u;
}
var t318:u32=t317;
var t319:u32=t318;
var t320:u32=ink_f32_add(t319,(t301).ink_f_bias);
var t321:u32=t320;
var t322:R_Coefficients=t276;
var t323:u32=t321;
var t324:R_Coefficients=t322;
var t325:u32=t323;
var t326:u32=t325;
var t327:u32=ink_f32_mul(t326,(t324).ink_f_scale);
var t328:u32=t327;
var t329:u32=ink_f32_add(t328,(t324).ink_f_bias);
var t330:u32=t329;
var t331:u32;
if (ink_f32_lt(0u,t330)) {
t331=t329;
} else {
t331=0u;
}
var t332:u32=t331;
var t333:u32=t332;
var t334:u32=ink_f32_mul(t333,(t324).ink_f_scale);
var t335:u32=t334;
var t336:u32=ink_f32_add(t335,(t324).ink_f_bias);
var t337:u32=t336;
var t338:u32=ink_f32_mul(t337,(t324).ink_f_scale);
var t339:u32=t338;
var t340:u32;
if (ink_f32_lt(0u,t339)) {
t340=t338;
} else {
t340=0u;
}
var t341:u32=t340;
var t342:u32=t341;
var t343:u32=ink_f32_add(t342,(t324).ink_f_bias);
var t344:u32=t343;
var t345:R_Coefficients=t322;
var t346:u32=t344;
var t347:u32=t346;
var t348:u32=ink_f32_mul(t347,(t345).ink_f_scale);
var t349:u32=t348;
var t350:u32=ink_f32_add(t349,(t345).ink_f_bias);
var t351:u32=t350;
var t352:u32;
if (ink_f32_lt(0u,t351)) {
t352=t350;
} else {
t352=0u;
}
var t353:u32=t352;
var t354:u32=t353;
var t355:u32=ink_f32_mul(t354,(t345).ink_f_scale);
var t356:u32=t355;
var t357:u32=ink_f32_add(t356,(t345).ink_f_bias);
var t358:u32=t357;
var t359:u32=ink_f32_mul(t358,(t345).ink_f_scale);
var t360:u32=t359;
var t361:u32;
if (ink_f32_lt(0u,t360)) {
t361=t359;
} else {
t361=0u;
}
var t362:u32=t361;
var t363:u32=t362;
var t364:u32=ink_f32_add(t363,(t345).ink_f_bias);
var t365:u32=t364;
var t366:R_Coefficients=R_Coefficients(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t367:u32=t365;
var t368:R_Coefficients=t366;
var t369:u32=t367;
var t370:R_Coefficients=t368;
var t371:u32=t369;
var t372:R_Coefficients=t370;
var t373:u32=t371;
var t374:R_Coefficients=t372;
var t375:u32=t373;
var t376:u32=t375;
var t377:u32=ink_f32_mul(t376,(t374).ink_f_scale);
var t378:u32=t377;
var t379:u32=ink_f32_add(t378,(t374).ink_f_bias);
var t380:u32=t379;
var t381:u32;
if (ink_f32_lt(0u,t380)) {
t381=t379;
} else {
t381=0u;
}
var t382:u32=t381;
var t383:u32=t382;
var t384:u32=ink_f32_mul(t383,(t374).ink_f_scale);
var t385:u32=t384;
var t386:u32=ink_f32_add(t385,(t374).ink_f_bias);
var t387:u32=t386;
var t388:u32=ink_f32_mul(t387,(t374).ink_f_scale);
var t389:u32=t388;
var t390:u32;
if (ink_f32_lt(0u,t389)) {
t390=t388;
} else {
t390=0u;
}
var t391:u32=t390;
var t392:u32=t391;
var t393:u32=ink_f32_add(t392,(t374).ink_f_bias);
var t394:u32=t393;
var t395:R_Coefficients=t372;
var t396:u32=t394;
var t397:u32=t396;
var t398:u32=ink_f32_mul(t397,(t395).ink_f_scale);
var t399:u32=t398;
var t400:u32=ink_f32_add(t399,(t395).ink_f_bias);
var t401:u32=t400;
var t402:u32;
if (ink_f32_lt(0u,t401)) {
t402=t400;
} else {
t402=0u;
}
var t403:u32=t402;
var t404:u32=t403;
var t405:u32=ink_f32_mul(t404,(t395).ink_f_scale);
var t406:u32=t405;
var t407:u32=ink_f32_add(t406,(t395).ink_f_bias);
var t408:u32=t407;
var t409:u32=ink_f32_mul(t408,(t395).ink_f_scale);
var t410:u32=t409;
var t411:u32;
if (ink_f32_lt(0u,t410)) {
t411=t409;
} else {
t411=0u;
}
var t412:u32=t411;
var t413:u32=t412;
var t414:u32=ink_f32_add(t413,(t395).ink_f_bias);
var t415:u32=t414;
var t416:R_Coefficients=t370;
var t417:u32=t415;
var t418:R_Coefficients=t416;
var t419:u32=t417;
var t420:u32=t419;
var t421:u32=ink_f32_mul(t420,(t418).ink_f_scale);
var t422:u32=t421;
var t423:u32=ink_f32_add(t422,(t418).ink_f_bias);
var t424:u32=t423;
var t425:u32;
if (ink_f32_lt(0u,t424)) {
t425=t423;
} else {
t425=0u;
}
var t426:u32=t425;
var t427:u32=t426;
var t428:u32=ink_f32_mul(t427,(t418).ink_f_scale);
var t429:u32=t428;
var t430:u32=ink_f32_add(t429,(t418).ink_f_bias);
var t431:u32=t430;
var t432:u32=ink_f32_mul(t431,(t418).ink_f_scale);
var t433:u32=t432;
var t434:u32;
if (ink_f32_lt(0u,t433)) {
t434=t432;
} else {
t434=0u;
}
var t435:u32=t434;
var t436:u32=t435;
var t437:u32=ink_f32_add(t436,(t418).ink_f_bias);
var t438:u32=t437;
var t439:R_Coefficients=t416;
var t440:u32=t438;
var t441:u32=t440;
var t442:u32=ink_f32_mul(t441,(t439).ink_f_scale);
var t443:u32=t442;
var t444:u32=ink_f32_add(t443,(t439).ink_f_bias);
var t445:u32=t444;
var t446:u32;
if (ink_f32_lt(0u,t445)) {
t446=t444;
} else {
t446=0u;
}
var t447:u32=t446;
var t448:u32=t447;
var t449:u32=ink_f32_mul(t448,(t439).ink_f_scale);
var t450:u32=t449;
var t451:u32=ink_f32_add(t450,(t439).ink_f_bias);
var t452:u32=t451;
var t453:u32=ink_f32_mul(t452,(t439).ink_f_scale);
var t454:u32=t453;
var t455:u32;
if (ink_f32_lt(0u,t454)) {
t455=t453;
} else {
t455=0u;
}
var t456:u32=t455;
var t457:u32=t456;
var t458:u32=ink_f32_add(t457,(t439).ink_f_bias);
var t459:u32=t458;
var t460:R_Coefficients=t368;
var t461:u32=t459;
var t462:R_Coefficients=t460;
var t463:u32=t461;
var t464:R_Coefficients=t462;
var t465:u32=t463;
var t466:u32=t465;
var t467:u32=ink_f32_mul(t466,(t464).ink_f_scale);
var t468:u32=t467;
var t469:u32=ink_f32_add(t468,(t464).ink_f_bias);
var t470:u32=t469;
var t471:u32;
if (ink_f32_lt(0u,t470)) {
t471=t469;
} else {
t471=0u;
}
var t472:u32=t471;
var t473:u32=t472;
var t474:u32=ink_f32_mul(t473,(t464).ink_f_scale);
var t475:u32=t474;
var t476:u32=ink_f32_add(t475,(t464).ink_f_bias);
var t477:u32=t476;
var t478:u32=ink_f32_mul(t477,(t464).ink_f_scale);
var t479:u32=t478;
var t480:u32;
if (ink_f32_lt(0u,t479)) {
t480=t478;
} else {
t480=0u;
}
var t481:u32=t480;
var t482:u32=t481;
var t483:u32=ink_f32_add(t482,(t464).ink_f_bias);
var t484:u32=t483;
var t485:R_Coefficients=t462;
var t486:u32=t484;
var t487:u32=t486;
var t488:u32=ink_f32_mul(t487,(t485).ink_f_scale);
var t489:u32=t488;
var t490:u32=ink_f32_add(t489,(t485).ink_f_bias);
var t491:u32=t490;
var t492:u32;
if (ink_f32_lt(0u,t491)) {
t492=t490;
} else {
t492=0u;
}
var t493:u32=t492;
var t494:u32=t493;
var t495:u32=ink_f32_mul(t494,(t485).ink_f_scale);
var t496:u32=t495;
var t497:u32=ink_f32_add(t496,(t485).ink_f_bias);
var t498:u32=t497;
var t499:u32=ink_f32_mul(t498,(t485).ink_f_scale);
var t500:u32=t499;
var t501:u32;
if (ink_f32_lt(0u,t500)) {
t501=t499;
} else {
t501=0u;
}
var t502:u32=t501;
var t503:u32=t502;
var t504:u32=ink_f32_add(t503,(t485).ink_f_bias);
var t505:u32=t504;
var t506:R_Coefficients=t460;
var t507:u32=t505;
var t508:R_Coefficients=t506;
var t509:u32=t507;
var t510:u32=t509;
var t511:u32=ink_f32_mul(t510,(t508).ink_f_scale);
var t512:u32=t511;
var t513:u32=ink_f32_add(t512,(t508).ink_f_bias);
var t514:u32=t513;
var t515:u32;
if (ink_f32_lt(0u,t514)) {
t515=t513;
} else {
t515=0u;
}
var t516:u32=t515;
var t517:u32=t516;
var t518:u32=ink_f32_mul(t517,(t508).ink_f_scale);
var t519:u32=t518;
var t520:u32=ink_f32_add(t519,(t508).ink_f_bias);
var t521:u32=t520;
var t522:u32=ink_f32_mul(t521,(t508).ink_f_scale);
var t523:u32=t522;
var t524:u32;
if (ink_f32_lt(0u,t523)) {
t524=t522;
} else {
t524=0u;
}
var t525:u32=t524;
var t526:u32=t525;
var t527:u32=ink_f32_add(t526,(t508).ink_f_bias);
var t528:u32=t527;
var t529:R_Coefficients=t506;
var t530:u32=t528;
var t531:u32=t530;
var t532:u32=ink_f32_mul(t531,(t529).ink_f_scale);
var t533:u32=t532;
var t534:u32=ink_f32_add(t533,(t529).ink_f_bias);
var t535:u32=t534;
var t536:u32;
if (ink_f32_lt(0u,t535)) {
t536=t534;
} else {
t536=0u;
}
var t537:u32=t536;
var t538:u32=t537;
var t539:u32=ink_f32_mul(t538,(t529).ink_f_scale);
var t540:u32=t539;
var t541:u32=ink_f32_add(t540,(t529).ink_f_bias);
var t542:u32=t541;
var t543:u32=ink_f32_mul(t542,(t529).ink_f_scale);
var t544:u32=t543;
var t545:u32;
if (ink_f32_lt(0u,t544)) {
t545=t543;
} else {
t545=0u;
}
var t546:u32=t545;
var t547:u32=t546;
var t548:u32=ink_f32_add(t547,(t529).ink_f_bias);
var t549:u32=t548;
var t550:R_Coefficients=t366;
var t551:u32=t549;
var t552:R_Coefficients=t550;
var t553:u32=t551;
var t554:R_Coefficients=t552;
var t555:u32=t553;
var t556:R_Coefficients=t554;
var t557:u32=t555;
var t558:u32=t557;
var t559:u32=ink_f32_mul(t558,(t556).ink_f_scale);
var t560:u32=t559;
var t561:u32=ink_f32_add(t560,(t556).ink_f_bias);
var t562:u32=t561;
var t563:u32;
if (ink_f32_lt(0u,t562)) {
t563=t561;
} else {
t563=0u;
}
var t564:u32=t563;
var t565:u32=t564;
var t566:u32=ink_f32_mul(t565,(t556).ink_f_scale);
var t567:u32=t566;
var t568:u32=ink_f32_add(t567,(t556).ink_f_bias);
var t569:u32=t568;
var t570:u32=ink_f32_mul(t569,(t556).ink_f_scale);
var t571:u32=t570;
var t572:u32;
if (ink_f32_lt(0u,t571)) {
t572=t570;
} else {
t572=0u;
}
var t573:u32=t572;
var t574:u32=t573;
var t575:u32=ink_f32_add(t574,(t556).ink_f_bias);
var t576:u32=t575;
var t577:R_Coefficients=t554;
var t578:u32=t576;
var t579:u32=t578;
var t580:u32=ink_f32_mul(t579,(t577).ink_f_scale);
var t581:u32=t580;
var t582:u32=ink_f32_add(t581,(t577).ink_f_bias);
var t583:u32=t582;
var t584:u32;
if (ink_f32_lt(0u,t583)) {
t584=t582;
} else {
t584=0u;
}
var t585:u32=t584;
var t586:u32=t585;
var t587:u32=ink_f32_mul(t586,(t577).ink_f_scale);
var t588:u32=t587;
var t589:u32=ink_f32_add(t588,(t577).ink_f_bias);
var t590:u32=t589;
var t591:u32=ink_f32_mul(t590,(t577).ink_f_scale);
var t592:u32=t591;
var t593:u32;
if (ink_f32_lt(0u,t592)) {
t593=t591;
} else {
t593=0u;
}
var t594:u32=t593;
var t595:u32=t594;
var t596:u32=ink_f32_add(t595,(t577).ink_f_bias);
var t597:u32=t596;
var t598:R_Coefficients=t552;
var t599:u32=t597;
var t600:R_Coefficients=t598;
var t601:u32=t599;
var t602:u32=t601;
var t603:u32=ink_f32_mul(t602,(t600).ink_f_scale);
var t604:u32=t603;
var t605:u32=ink_f32_add(t604,(t600).ink_f_bias);
var t606:u32=t605;
var t607:u32;
if (ink_f32_lt(0u,t606)) {
t607=t605;
} else {
t607=0u;
}
var t608:u32=t607;
var t609:u32=t608;
var t610:u32=ink_f32_mul(t609,(t600).ink_f_scale);
var t611:u32=t610;
var t612:u32=ink_f32_add(t611,(t600).ink_f_bias);
var t613:u32=t612;
var t614:u32=ink_f32_mul(t613,(t600).ink_f_scale);
var t615:u32=t614;
var t616:u32;
if (ink_f32_lt(0u,t615)) {
t616=t614;
} else {
t616=0u;
}
var t617:u32=t616;
var t618:u32=t617;
var t619:u32=ink_f32_add(t618,(t600).ink_f_bias);
var t620:u32=t619;
var t621:R_Coefficients=t598;
var t622:u32=t620;
var t623:u32=t622;
var t624:u32=ink_f32_mul(t623,(t621).ink_f_scale);
var t625:u32=t624;
var t626:u32=ink_f32_add(t625,(t621).ink_f_bias);
var t627:u32=t626;
var t628:u32;
if (ink_f32_lt(0u,t627)) {
t628=t626;
} else {
t628=0u;
}
var t629:u32=t628;
var t630:u32=t629;
var t631:u32=ink_f32_mul(t630,(t621).ink_f_scale);
var t632:u32=t631;
var t633:u32=ink_f32_add(t632,(t621).ink_f_bias);
var t634:u32=t633;
var t635:u32=ink_f32_mul(t634,(t621).ink_f_scale);
var t636:u32=t635;
var t637:u32;
if (ink_f32_lt(0u,t636)) {
t637=t635;
} else {
t637=0u;
}
var t638:u32=t637;
var t639:u32=t638;
var t640:u32=ink_f32_add(t639,(t621).ink_f_bias);
var t641:u32=t640;
var t642:R_Coefficients=t550;
var t643:u32=t641;
var t644:R_Coefficients=t642;
var t645:u32=t643;
var t646:R_Coefficients=t644;
var t647:u32=t645;
var t648:u32=t647;
var t649:u32=ink_f32_mul(t648,(t646).ink_f_scale);
var t650:u32=t649;
var t651:u32=ink_f32_add(t650,(t646).ink_f_bias);
var t652:u32=t651;
var t653:u32;
if (ink_f32_lt(0u,t652)) {
t653=t651;
} else {
t653=0u;
}
var t654:u32=t653;
var t655:u32=t654;
var t656:u32=ink_f32_mul(t655,(t646).ink_f_scale);
var t657:u32=t656;
var t658:u32=ink_f32_add(t657,(t646).ink_f_bias);
var t659:u32=t658;
var t660:u32=ink_f32_mul(t659,(t646).ink_f_scale);
var t661:u32=t660;
var t662:u32;
if (ink_f32_lt(0u,t661)) {
t662=t660;
} else {
t662=0u;
}
var t663:u32=t662;
var t664:u32=t663;
var t665:u32=ink_f32_add(t664,(t646).ink_f_bias);
var t666:u32=t665;
var t667:R_Coefficients=t644;
var t668:u32=t666;
var t669:u32=t668;
var t670:u32=ink_f32_mul(t669,(t667).ink_f_scale);
var t671:u32=t670;
var t672:u32=ink_f32_add(t671,(t667).ink_f_bias);
var t673:u32=t672;
var t674:u32;
if (ink_f32_lt(0u,t673)) {
t674=t672;
} else {
t674=0u;
}
var t675:u32=t674;
var t676:u32=t675;
var t677:u32=ink_f32_mul(t676,(t667).ink_f_scale);
var t678:u32=t677;
var t679:u32=ink_f32_add(t678,(t667).ink_f_bias);
var t680:u32=t679;
var t681:u32=ink_f32_mul(t680,(t667).ink_f_scale);
var t682:u32=t681;
var t683:u32;
if (ink_f32_lt(0u,t682)) {
t683=t681;
} else {
t683=0u;
}
var t684:u32=t683;
var t685:u32=t684;
var t686:u32=ink_f32_add(t685,(t667).ink_f_bias);
var t687:u32=t686;
var t688:R_Coefficients=t642;
var t689:u32=t687;
var t690:R_Coefficients=t688;
var t691:u32=t689;
var t692:u32=t691;
var t693:u32=ink_f32_mul(t692,(t690).ink_f_scale);
var t694:u32=t693;
var t695:u32=ink_f32_add(t694,(t690).ink_f_bias);
var t696:u32=t695;
var t697:u32;
if (ink_f32_lt(0u,t696)) {
t697=t695;
} else {
t697=0u;
}
var t698:u32=t697;
var t699:u32=t698;
var t700:u32=ink_f32_mul(t699,(t690).ink_f_scale);
var t701:u32=t700;
var t702:u32=ink_f32_add(t701,(t690).ink_f_bias);
var t703:u32=t702;
var t704:u32=ink_f32_mul(t703,(t690).ink_f_scale);
var t705:u32=t704;
var t706:u32;
if (ink_f32_lt(0u,t705)) {
t706=t704;
} else {
t706=0u;
}
var t707:u32=t706;
var t708:u32=t707;
var t709:u32=ink_f32_add(t708,(t690).ink_f_bias);
var t710:u32=t709;
var t711:R_Coefficients=t688;
var t712:u32=t710;
var t713:u32=t712;
var t714:u32=ink_f32_mul(t713,(t711).ink_f_scale);
var t715:u32=t714;
var t716:u32=ink_f32_add(t715,(t711).ink_f_bias);
var t717:u32=t716;
var t718:u32;
if (ink_f32_lt(0u,t717)) {
t718=t716;
} else {
t718=0u;
}
var t719:u32=t718;
var t720:u32=t719;
var t721:u32=ink_f32_mul(t720,(t711).ink_f_scale);
var t722:u32=t721;
var t723:u32=ink_f32_add(t722,(t711).ink_f_bias);
var t724:u32=t723;
var t725:u32=ink_f32_mul(t724,(t711).ink_f_scale);
var t726:u32=t725;
var t727:u32;
if (ink_f32_lt(0u,t726)) {
t727=t725;
} else {
t727=0u;
}
var t728:u32=t727;
var t729:u32=t728;
var t730:u32=ink_f32_add(t729,(t711).ink_f_bias);
var t731:u32=t730;
output[0u+0u]=bitcast<u32>(t731);


}