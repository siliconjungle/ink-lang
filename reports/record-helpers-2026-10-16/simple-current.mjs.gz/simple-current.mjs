const __recordElisions=new Set([]);
const __nativeF32=false;
// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
// Binary64 uses native Numbers for finite arithmetic and immutable private
// tags only where a NaN's exact payload must survive non-arithmetic operations.
const __doubleView=new DataView(new ArrayBuffer(8));
const __double=bits=>{__doubleView.setBigUint64(0,bits,true);return __doubleView.getFloat64(0,true);};
const __doubleBits=number=>{if(Number.isNaN(number))return 0x7ff8000000000000n;__doubleView.setFloat64(0,number,true);return __doubleView.getBigUint64(0,true);};
const __dfNumber=value=>typeof value==='number'?value:__double(BigInt(value.F64Bits));
const __dfBits=value=>typeof value==='number'?__doubleBits(value):BigInt(value.F64Bits);
const __dfFromBits=bits=>(bits&0x7fffffffffffffffn)>0x7ff0000000000000n?Object.freeze({F64Bits:bits.toString()}):__double(bits);
const __dfInput=value=>typeof value==='number'?value:__dfFromBits(BigInt(value.F64Bits));
const __dfNeg=value=>typeof value==='number'&&!Number.isNaN(value)?-value:__dfFromBits(__dfBits(value)^0x8000000000000000n);
const __dfOutput=value=>{const n=__dfNumber(value);return Number.isFinite(n)?n:{F64Bits:__dfBits(value).toString()};};
const __dfCapture=value=>{
 if(typeof value==='number'&&Number.isFinite(value))return value;
 if(!value||typeof value!=='object'||Object.keys(value).length!==1||!Object.hasOwn(value,'F64Bits'))throw Error('invalid f64');const text=value.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid f64');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');return __dfFromBits(bits);
};
// Native binary32 lane for pure modules. Explicit NaN payloads remain tagged;
// arithmetic canonicalizes NaNs just as __bits does in the exact-bit lane.
const __nfValue = value => typeof value === 'number' ? Math.fround(value) : value;
// Number operands have already been normalised at their typed read or producer.
const __nfNumber = value => typeof value === 'number' ? value : __float(value.F32Bits);
const __nfBits = value => typeof value === 'number' ? __bits(value) : value.F32Bits;
const __nfFromBits = bits => (bits & 0x7fffffff)>0x7f800000 ? {F32Bits:bits} : __float(bits);
const __nfNeg = value => typeof value === 'number' && !Number.isNaN(value) ? -value : {F32Bits:(__nfBits(value) ^ 0x80000000) >>> 0};
const __nfOutput = value => {const n=typeof value==='number'?Math.fround(value):__float(value.F32Bits);return Number.isFinite(n)?n:{F32Bits:__nfBits(value)};};
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output, capture=false) {
  const convert=__representationRaw(type,output,capture);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':capture?'capture:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output, capture) {
  switch (type.kind) {
    case 'ref': {
      let resolved;
      return (value,context)=>(resolved??=__representation(__namedTypes[type.name],output,capture))(value,context);
    }
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output,capture);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output,capture),err=__representation(type.error,output,capture);
      const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);
      if(flat)return output?(value,context)=>{const v=__sumView(key,value);return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};}:(v,context)=>Object.hasOwn(v,'Ok')?__sumMake(key,true,ok(v.Ok,context)):__sumMake(key,false,err(v.Err,context));
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f64':return output?__dfOutput:__dfInput;
    case 'f32': if(typeof __nativeF32!=='undefined'&&__nativeF32)return output?__nfOutput:capture?__nfValue:__identity;
      return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output,capture);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){
        if(!type.fields.length)return ()=>undefined; // lexically unconsumed projected input
        const field=type.fields[0],child=__representation(field.type,output,capture);
        return output?(value,context)=>({[field.name]:child(value,context)}):(value,context)=>child(value[field.name],context);
      }
      const fields = type.fields.map(field => [field.name, __representation(field.type, output,capture)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
function __stateWord(value){
 if(typeof value==='number'&&!Number.isSafeInteger(value))throw Error('u64 requires an exact integer');
 if(!['bigint','number','string'].includes(typeof value)||typeof value==='string'&&!/^(0|[1-9][0-9]*)$/.test(value))throw Error('invalid u64');
 const n=BigInt(value);if(n<0n||n>18446744073709551615n)throw Error('invalid u64');return n;
}
// Compile the capture traversal once. Each invocation still validates and owns
// every public container; no host value is retained between calls.
const __stateCaptures=new WeakMap();
function __stateCapture(type){
 const prior=__stateCaptures.get(type);if(prior)return prior;
 const capture=__compileStateCapture(type);__stateCaptures.set(type,capture);return capture;
}
function __compileStateCapture(type){
 const limited=copy=>(value,budget={cells:1000000},depth=0)=>{
  if(depth>64||--budget.cells<0)throw Error('state input resource limit');
  return copy(value,budget,depth);
 };
 const tagged=(value,tag)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
 switch(type.kind){
  case 'ref':{
   // Resolve lazily so recursive schemas compile to recursive validators rather
   // than reverting to descriptor interpretation at every referenced node.
   let resolved;
   return limited((value,budget,depth)=>(resolved??=__stateCapture(__namedTypes[type.name]))(value,budget,depth+1));
  }
  case 'u32':case 'i32':{
   const min=type.kind==='u32'?0:-2147483648,max=type.kind==='u32'?4294967295:2147483647;
   return limited(value=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;});
  }
  case 'u64':return limited(__stateWord);
  case 'f64':return limited(__dfCapture);
  case 'bool':return limited(value=>{if(typeof value!=='boolean')throw Error('invalid Bool');return value;});
  case 'unit':return limited(value=>{if(value!==null)throw Error('invalid Unit');return null;});
  case 'string':return limited(value=>{if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;});
  case 'enum':return limited(value=>{if(!type.variants.includes(value))throw Error('invalid enum');return value;});
  case 'id':return limited(value=>{if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();});
  case 'list':case 'vector':{
   const item=__stateCapture(type.element),size=type.kind==='vector'?type.size:null;
   return limited((value,budget,depth)=>{
    if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
    if(size!==null&&value.length!==size)throw Error('invalid vector length');
    const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=item(value[i],budget,depth+1);return out;
   });
  }
  case 'record':{
   const fields=type.fields.map(f=>[f.name,__stateCapture(f.type)]);
   if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name)))return limited((value,budget,depth)=>{const [name,copy]=fields[0];if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,name))throw Error('invalid record');return copy(value[name],budget,depth+1);});
   return limited((value,budget,depth)=>{
    if(!value||typeof value!=='object'||Array.isArray(value)||!fields.every(([name])=>Object.hasOwn(value,name)))throw Error('invalid record');
    const out={};for(const [name,copy]of fields){const field=copy(value[name],budget,depth+1);if(name==='__proto__')Object.defineProperty(out,name,{value:field,writable:true,enumerable:true,configurable:true});else out[name]=field;}return out;
   });
  }
  case 'option':{
   const item=__stateCapture(type.element);
   return limited((value,budget,depth)=>{if(tagged(value,'Some'))return {Some:item(value.Some,budget,depth+1)};if(tagged(value,'None')&&value.None===null)return {None:null};throw Error('invalid Option');});
  }
  case 'result':{
   const ok=__stateCapture(type.ok),err=__stateCapture(type.error);
   return limited((value,budget,depth)=>{if(tagged(value,'Ok'))return {Ok:ok(value.Ok,budget,depth+1)};if(tagged(value,'Err'))return {Err:err(value.Err,budget,depth+1)};throw Error('invalid Result');});
  }
  default:return (value,budget,depth)=>__stateInput(value,type,budget,depth);
 }
}
function __stateInput(value,type,budget={cells:1000000},depth=0,maxDepth=64){
  if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');
  const input=(v,t)=>__stateInput(v,t,budget,depth+1,maxDepth);
  const integer=(min,max)=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;};
  const tagged=tag=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
  switch(type.kind){
    case 'ref':return input(value,__namedTypes[type.name]);
    case 'u32':return integer(0,4294967295);
    case 'i32':return integer(-2147483648,2147483647);
    case 'u64':return __stateWord(value);
    case 'int':{
      if(typeof value==='bigint')return value;
      if(!tagged('Int')||typeof value.Int!=='string'||!/^(-?[0-9]+)$/.test(value.Int))throw Error('invalid Int');return BigInt(value.Int);
    }
    case 'f64':return __dfCapture(value);
    case 'f32':{
      if(typeof value==='number'&&Number.isFinite(value)){const bits=__bits(value);if((bits&0x7fffffff)===0x7f800000)throw Error('f32 overflow requires F32Bits');return bits;}
      if(!tagged('F32Bits')||!Number.isInteger(value.F32Bits)||value.F32Bits<0||value.F32Bits>4294967295)throw Error('invalid f32');return value.F32Bits;
    }
    case 'bool':if(typeof value!=='boolean')throw Error('invalid Bool');return value;
    case 'unit':if(value!==null)throw Error('invalid Unit');return null;
    case 'string':if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;
    case 'id':if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();
    case 'enum':if(!type.variants.includes(value))throw Error('invalid enum');return value;
    case 'list':case 'vector':{
      if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
      if(type.kind==='vector'&&value.length!==type.size)throw Error('invalid vector length');
      return Array.from(value,v=>input(v,type.element));
    }
    case 'record':if(!value||typeof value!=='object'||Array.isArray(value)||!type.fields.every(f=>Object.hasOwn(value,f.name)))throw Error('invalid record');if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){const f=type.fields[0];return input(value[f.name],f.type);}return Object.fromEntries(type.fields.map(f=>[f.name,input(value[f.name],f.type)]));
    case 'option':if(tagged('Some'))return {Some:input(value.Some,type.element)};if(tagged('None')&&value.None===null)return {None:null};throw Error('invalid Option');
    case 'result':{const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);if(tagged('Ok')){const child=input(value.Ok,type.ok);return flat?__sumMake(key,true,child):{Ok:child};}if(tagged('Err')){const child=input(value.Err,type.error);return flat?__sumMake(key,false,child):{Err:child};}throw Error('invalid Result');}
    default:throw Error('unsupported public value type');
  }
}
// Mutable host replies must not retain references into compiled state or its outbox.
// State results must own mutable containers. Compile the declared schema once:
// scalars need no structured clone, while nested records/lists remain detached.
function __ownershipSchema(type){
 // Nominal references and expanded declarations name the same checked sort.
 // Distinct source records retain distinct keys even if a layout erases them.
 if(type.kind==='ref'||type.kind==='record'&&type.name)return ['named',type.name];
 switch(type.kind){
  case 'list':case 'vector':return [type.kind,type.size??null,__ownershipSchema(type.element)];
  case 'option':return ['option',__ownershipSchema(type.element)];
  case 'result':return ['result',__ownershipSchema(type.ok),__ownershipSchema(type.error)];
  case 'record':return ['record',type.fields.map(f=>[f.name,__ownershipSchema(f.type)])];
  default:return type;
 }
}
function __ownedResult(copy,nested,type){
 const key='owned-state:'+JSON.stringify(__ownershipSchema(type));
 let schema=__conversionKeys.get(key);
 if(!schema){schema={};__conversionKeys.set(key,schema);}
 const owned=(value,context)=>{
  if(!context&&!nested)return copy(value,null);
  const memo=context||new WeakMap();
  if(value===null||typeof value!=='object')return copy(value,memo);
  let entries=memo.get(schema);if(!entries){entries=new WeakMap();memo.set(schema,entries);}
  if(entries.has(value))return entries.get(value);
  const result=copy(value,memo);entries.set(value,result);return result;
 };
 owned.container=true;return owned;
}
function __stateResult(type){
 switch(type.kind){
  case 'ref':{let resolved;const copy=(value,context)=>(resolved??=__stateResult(__namedTypes[type.name]))(value,context);copy.container=true;return copy;}
  case 'record':{if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){const f=type.fields[0],copy=__stateResult(f.type);return __ownedResult((value,context)=>({[f.name]:copy(value,context)}),copy.container,type);}const fields=type.fields.map(f=>[f.name,__stateResult(f.type)]);return __ownedResult((value,context)=>Object.fromEntries(fields.map(([name,copy])=>[name,copy(value[name],context)])),fields.some(([,copy])=>copy.container),type);}
  case 'list':case 'vector':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Array.from(value,item=>copy(item,context)),copy.container,type);}
  case 'option':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Object.hasOwn(value,'Some')?{Some:copy(value.Some,context)}:{None:null},copy.container,type);}
  case 'result':{const ok=__stateResult(type.ok),err=__stateResult(type.error),key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);return __ownedResult((value,context)=>{const v=flat?__sumView(key,value):value;return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};},ok.container||err.container,type);}
  default:return __representation(type,true);
 }
}
function __stateOutput(value,type){return __stateResult(type)(value);}
const __u64 = n => BigInt.asUintN(64, n);
function __div(a, b, fallback, signed, remainder) {
  if (b === 0 || b === 0n || (signed && a === -2147483648 && b === -1)) return fallback();
  return typeof a === 'bigint' ? (remainder ? a % b : a / b) :
    ((remainder ? a % b : Math.trunc(a / b)) + 0); // integer zero has no sign
}
function __at(xs, index, fallback) { return index < xs.length ? xs[index] : fallback(); }
// Ordinary arrays retain the declared result element type when input is typed.
function __map(xs, fn) {
  const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = fn(xs[i], i);
  return out;
}
function __filter(xs, fn) {
  const out = [];
  for (let i = 0; i < xs.length; i++) if (fn(xs[i])) out.push(xs[i]);
  return out;
}
function __concat(xs, ys) {
  const left = xs.length, right = ys.length, out = new Array(left + right);
  for (let i = 0; i < left; i++) out[i] = xs[i];
  for (let i = 0; i < right; i++) out[left + i] = ys[i];
  return out;
}
function __zip(xs, ys, fn) {
  const n = Math.min(xs.length, ys.length), out = new Array(n);
  for (let i = 0; i < n; i++) out[i] = fn(xs[i], ys[i]);
  return out;
}
function __repeat(n, initial, fn) { let value = initial; for (let i = 0; i < n; i++) value = fn(i, value); return value; }
function __foldr(xs, initial, fn) { let value = initial; for (let i = xs.length - 1; i >= 0; i--) value = fn(xs[i], value); return value; }
function __scan(xs, zero, add) {
  let value = zero; const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = value = add(value, xs[i]);
  return out;
}
const __sort = xs => Array.from(xs).sort((a,b) => a < b ? -1 : a > b ? 1 : 0);

function __wordSort(xs,Storage){
 const sorted=Storage.from(xs).sort(),out=new Array(sorted.length);
 for(let i=0;i<sorted.length;i++)out[i]=sorted[i];
 return out;
}
// Affine buffers expose bounded disjoint ranges over one allocation. Source
// ownership prevents retaining a parent; growth detaches shared ranges.
// Elements cannot own temporary storage: they are immutable logical values.
// Copy the slot array when acquiring ownership, never the reachable records.
class __InkBuffer {
 constructor(data,start=0,end=data.length,shared=false){this.data=data;this.start=start;this.end=end;this.shared=shared;}
 get length(){return this.end-this.start;}
 set length(n){this.end=this.start+Math.min(this.length,n);if(!this.shared&&this.start===0)this.data.length=this.end;}
 item(i){return this.data[this.start+i];}
 range(start,count){const begin=this.start+Math.min(start,this.length);return new __InkBuffer(this.data,begin,begin+Math.min(count,this.end-begin),true);}
 set(i,v){if(i<this.length)this.data[this.start+i]=v;return this;}
 swap(a,b){if(a<this.length&&b<this.length){const x=this.item(a);this.set(a,this.item(b));this.set(b,x);}return this;}
 fill_range(start,count,value){start=Math.min(start,this.length);count=Math.min(count,this.length-start);this.data.fill(value,this.start+start,this.start+start+count);return this;}
 copy_within(source,destination,count){source=Math.min(source,this.length);destination=Math.min(destination,this.length);count=Math.min(count,this.length-source,this.length-destination);this.data.copyWithin(this.start+destination,this.start+source,this.start+source+count);return this;}
 detach(){if(this.shared||this.start!==0||this.end!==this.data.length){this.data=this.data.slice(this.start,this.end);this.start=0;this.end=this.data.length;this.shared=false;}}
 push(v){if(this.length>=4294967295)throw Error('buffer length exhausted');this.detach();this.data.push(v);this.end++;return this;}
 pop(){this.length=Math.max(0,this.length-1);return this;}
 truncate(n){this.length=Math.min(this.length,n);return this;}
 slice(start=0,end=this.length){return this.data.slice(this.start+start,this.start+Math.min(end,this.length));}
 freeze(){return this.start===0&&this.end===this.data.length?this.data:this.data.slice(this.start,this.end);}
 *[Symbol.iterator](){for(let i=this.start;i<this.end;i++)yield this.data[i];}
}
function __bufferSplit(x,at){const cut=x.start+Math.min(at,x.length);x.shared=true;return [new __InkBuffer(x.data,x.start,cut,true),new __InkBuffer(x.data,cut,x.end,true)];}
function __bufferAppend(a,b){
 if(a.length+b.length>4294967295)throw Error('buffer length exhausted');
 if(a.data===b.data&&a.end===b.start)return new __InkBuffer(a.data,a.start,b.end,a.start!==0||b.end!==a.data.length);
 a.detach();for(const item of b)a.push(item);return a;
}

function __repeat_until(limit,acc,stop,step){for(let i=0;i<limit;i++){if(stop(acc))break;acc=step(i,acc);}return acc;}
function __bufferFill(n,v){return new __InkBuffer(new Array(n).fill(v));}
function __mapGet(m,k,f){return m.has(k)?m.get(k):f();}
function __mapEntries(m,keys){return [...m.entries()].sort(([a],[b])=>a<b?-1:a>b?1:0).map(([k,v])=>keys?k:v);}
function __tempSet(x,k,v,map){x.set(k,v);return x;}
function __bufferSwap(x,a,b){return x.swap(a,b);}
function __tempEdit(x,op,...args){if(op==='push'){x.push(args[0]);}else if(op==='pop')x.pop();else if(op==='truncate')x.truncate(args[0]);else if(op==='remove')x.delete(args[0]);return x;}
// Fixed word semantics, including arithmetic signed right shift. Shift and
// rotation counts wrap modulo width; no source-pattern optimisation lives here.
function __word(op,a,b,bits) {
  const width=BigInt(Math.abs(bits)), k=BigInt(b??0)%width;
  const x=BigInt(a), y=BigInt(b??0), unsigned=BigInt.asUintN(Number(width),x);
  let r;
  switch(op) {
    case 'word_widen_u32_to_u64':case 'word_narrow_u64_to_u32':r=x;break;
    case 'word_not':r=~x;break;
    case 'word_and':r=x&y;break;
    case 'word_or':r=x|y;break;
    case 'word_xor':r=x^y;break;
    case 'wrapping_shl':r=x<<k;break;
    case 'wrapping_shr':r=x>>k;break;
    case 'rotate_left':r=(unsigned<<k)|(unsigned>>(width-k));break;
    case 'rotate_right':r=(unsigned>>k)|(unsigned<<(width-k));break;
    default:throw new Error('unknown word operation');
  }
  r=bits<0?BigInt.asIntN(Number(width),r):BigInt.asUintN(Number(width),r);
  return bits===64?r:Number(r);
}
// Rotations evaluate each operand once. Counts wrap modulo the width.
function __rotl32(a,k){k&=31;return (a<<k)|(a>>>((32-k)&31));}
function __rotr32(a,k){k&=31;return (a>>>k)|(a<<((32-k)&31));}
function __rotl64(a,k){const n=BigInt(k&63);return BigInt.asUintN(64,(a<<n)|(a>>((64n-n)&63n)));}
function __rotr64(a,k){const n=BigInt(k&63);return BigInt.asUintN(64,(a>>n)|(a<<((64n-n)&63n)));}
function __fn0(v0,v1,v2){
return __fn17(v0,v1,v2);}
function __fn1(v3,v4,v5){
const v6=1000000;
const v7=__fn17(v3,v4,v6);
let v8;if(Object.hasOwn(v7,"Ok")){
const v9=v7["Ok"];
v8=__fn34(v9,v5);}else{
const v10=v7["Err"];
v8=({Err:v10});}
return v8;}
function __fn2(v11,v12,v13){
const v14=1000000;
const v15=__fn17(v11,v12,v14);
let v16;if(Object.hasOwn(v15,"Ok")){
const v17=v15["Ok"];
v16=__fn30(v17,v13);}else{
const v18=v15["Err"];
v16=({Err:v18});}
return v16;}
function __fn3(v19,v20,v21){
const v22=1000000;
const v23=__fn17(v19,v20,v22);
let v24;if(Object.hasOwn(v23,"Ok")){
const v25=v23["Ok"];
v24=__fn28(v25,v21);}else{
const v26=v23["Err"];
v24=({Err:v26});}
return v24;}
function __fn4(v27,v28,v29,v30){
const v31=1000000;
const v32=__fn17(v27,v28,v31);
let v33;if(Object.hasOwn(v32,"Ok")){
const v34=v32["Ok"];
v33=__fn35(v34,v29,v30);}else{
const v35=v32["Err"];
v33=({Err:v35});}
return v33;}
function __fn5(v36,v37,v38,v39){
const v40=1000000;
const v41=__fn17(v36,v37,v40);
let v42;if(Object.hasOwn(v41,"Ok")){
const v43=v41["Ok"];
v42=__fn25(v43,v38,v39);}else{
const v44=v41["Err"];
v42=({Err:v44});}
return v42;}
function __fn6(v45,v46){
return __fn34(v45,v46);}
function __fn7(v47){
const v48=v47.length;
const v49=new Array(v48);
for(let v50=0;v50<v48;v50++){
const v51=v47[v50];
const v52=__bits(__float(v51) * __float(v51));
const v53=1056964608;
v49[v50]=__bits(__float(v52) + __float(v53));
}
return v49;}
function __fn8(v54,v55){
let v56;if(Object.hasOwn(v54,"Some")){
const v57=v54["Some"];
let v58;if(v55<v57.length){v58=v57[v55];}else{
v58=0.0;}
v56=v58;}else{
const v59=null;
v56=0.0;}
return v56;}
function __fn9(v60,v61){
const v62=v60["graphemeStartExtras"];
let v63;if(Object.hasOwn(v62,"Some")){
const v64=v62["Some"];
let v65;if(v61<v64.length){v65=v64[v61];}else{
v65=({None:null});}
v63=v65;}else{
const v66=null;
v63=({None:null});}
return v63;}
function __fn10(v67,v68){
const v69=v67["flags"];
let v70;if(v68<v69.length){v70=v69[v68];}else{
v70=0;}
const v71=v70;
const v72=15;
return (((v71)&(v72))>>>0);}
function __fn11(v73,v74,v75){
const v76=__fn10(v73,v74);
const v77=1;
const v78=(v76===v77);
let v79=v78;if(!v79){
const v80=__fn10(v73,v74);
const v81=2;
const v82=(v80===v81);
let v83=v82;if(v83){
const v84=false;
v83=(v75===v84);}
v79=v83;}
return v79;}
function __fn12(v85,v86){
const v87=__fn10(v85,v86);
const v88=1;
const v89=(v87===v88);
let v90=v89;if(!v90){
const v91=__fn10(v85,v86);
const v92=2;
v90=(v91===v92);}
return v90;}
function __fn13(v93){
let v94=true;
for(let v95=0;v95<v93.length;v95++){
const v96=v93[v95];
const v97=v94;
let v98=v97;if(v98){
v98=Number.isFinite(__dfNumber(v96));}
v94=v98;
}
return v94;}
function __fn14(v99,v100){
let v101;if(Object.hasOwn(v99,"Some")){
const v102=v99["Some"];
const v103=v102.length;
const v104=1000000;
const v105=((v103) <= (v104));
let v106=v105;if(v106){
const v107=(v102).length;
v106=(v107===v100);}
const v108=v106;
let v109=v108;if(v109){
v109=__fn13(v102);}
v101=v109;}else{
const v110=null;
v101=true;}
return v101;}
function __fn15(v111,v112,v113,v114){
const v115=v114["index"];
const v116=v111["flags"];
let v117;if(v115<v116.length){v117=v116[v115];}else{
v117=256;}
const v118=v117;
const v119=15;
const v120=(((v118)&(v119))>>>0);
let v121;if(Object.hasOwn(v113,"Some")){
const v122=v113["Some"];
v121=(v122).length;}else{
const v123=null;
v121=0;}
const v124=v121;
const v125=v114["valid"];
let v126=v125;if(v126){
const v127=255;
v126=((v118) <= (v127));}
const v128=v126;
let v129=v128;if(v129){
const v130=2;
v129=((v120) <= (v130));}
const v131=v129;
let v132=v131;if(v132){
const v133=32;
const v134=(((v118)&(v133))>>>0);
const v135=0;
v132=(v134===v135);}
const v136=v132;
let v137=v136;if(v137){
let v138;if(Object.hasOwn(v113,"Some")){
const v139=v113["Some"];
const v140=v139.length;
const v141=0;
const v142=((v140) > (v141));
let v143=v142;if(v143){
const v144=v139.length;
const v145=1000000;
v143=((v144) <= (v145));}
const v146=v143;
let v147=v146;if(v147){
const v148=(v139).length;
v147=((v148) <= (v112));}
const v149=v147;
let v150=v149;if(v150){
v150=__fn13(v139);}
v138=v150;}else{
const v151=null;
v138=true;}
v137=v138;}
const v152=v137;
let v153=v152;if(v153){
const v154=__fn9(v111,v115);
let v155;if(Object.hasOwn(v154,"Some")){
const v156=v154["Some"];
let v157;if(Object.hasOwn(v113,"Some")){
const v158=v113["Some"];
const v159=v156.length;
const v160=v158.length;
const v161=((v159) === (v160));
let v162=v161;if(v162){
v162=__fn13(v156);}
v157=v162;}else{
const v163=null;
v157=false;}
v155=v157;}else{
const v164=null;
v155=true;}
v153=v155;}
const v165=v153;
const v166=v114["budget"];
const v167=(((v112) - (v166)) >>> 0);
const v168=((v124) <= (v167));
let v169=v165;if(v169){
v169=v168;}
const v170=v169;
let v171;if(v168){
const v172=v114["budget"];
v171=(((v172) + (v124)) >>> 0);}else{
v171=v114["budget"];}
const v173=v171;
const v174=1;
const v175=(((v115) + (v174)) >>> 0);
return ({["valid"]:v170,["budget"]:v173,["index"]:v175});}
function __fn16(v176,v177,v178){
const v179=0;
const v180=(v178===v179);
let v181=v180;if(!v181){
const v182=1000000;
v181=((v178) > (v182));}
const v183=v181;
let v184=v183;if(!v184){
const v185=v176["widths"];
const v186=v185.length;
const v187=1000000;
v184=((v186) > (v187));}
const v188=v184;
let v189=v188;if(!v189){
const v190=(v176["widths"]).length;
v189=((v190) > (v178));}
const v191=v189;
let v192=v191;if(!v192){
const v193=v176["widths"];
const v194=__fn13(v193);
const v195=false;
v192=(v194===v195);}
const v196=v192;
let v197=v196;if(!v197){
const v198=Number.isFinite(__dfNumber(v177));
const v199=false;
v197=(v198===v199);}
const v200=v197;
let v201=v200;if(!v201){
const v202=0.0;
v201=((__dfNumber(v177)) < (__dfNumber(v202)));}
let v203;if(v201){
v203=({None:null});}else{
const v204=(v176["widths"]).length;
const v205=v176["flags"];
const v206=v205.length;
const v207=1000000;
const v208=((v206) > (v207));
let v209=v208;if(!v209){
const v210=(v176["flags"]).length;
v209=!(v210===v204);}
const v211=v209;
let v212=v211;if(!v212){
const v213=v176["advances"];
const v214=v213.length;
const v215=1000000;
v212=((v214) > (v215));}
const v216=v212;
let v217=v216;if(!v217){
const v218=(v176["advances"]).length;
v217=!(v218===v204);}
const v219=v217;
let v220=v219;if(!v220){
const v221=v176["startExtras"];
const v222=__fn14(v221,v204);
const v223=false;
v220=(v222===v223);}
const v224=v220;
let v225=v224;if(!v225){
const v226=v176["endTrims"];
const v227=__fn14(v226,v204);
const v228=false;
v225=(v227===v228);}
const v229=v225;
let v230=v229;if(!v230){
const v231=v176["overflowTrims"];
const v232=__fn14(v231,v204);
const v233=false;
v230=(v232===v233);}
const v234=v230;
let v235=v234;if(!v235){
const v236=v176["insideExtras"];
const v237=__fn14(v236,v204);
const v238=false;
v235=(v237===v238);}
const v239=v235;
let v240=v239;if(!v240){
const v241=v176["fillExtras"];
const v242=__fn14(v241,v204);
const v243=false;
v240=(v242===v243);}
const v244=v240;
let v245=v244;if(!v245){
const v246=v176["graphemeStartExtras"];
let v247;if(Object.hasOwn(v246,"Some")){
const v248=v246["Some"];
const v249=v248.length;
const v250=1000000;
const v251=((v249) <= (v250));
let v252=v251;if(v252){
const v253=(v248).length;
v252=(v253===v204);}
v247=v252;}else{
const v254=null;
v247=true;}
const v255=v247;
const v256=false;
v245=(v255===v256);}
let v257;if(v245){
v257=({None:null});}else{
const v258=v176["advances"];
const v259=true;
const v260=0;
let v261=({["valid"]:v259,["budget"]:v204,["index"]:v260});
for(let v262=0;v262<v258.length;v262++){
const v263=v258[v262];
const v264=v261;
v261=__fn15(v176,v178,v263,v264);
}
const v265=v261;
let v266;if(v265["valid"]){
v266=({Some:v265["budget"]});}else{
v266=({None:null});}
v257=v266;}
v203=v257;}
return v203;}
function __fn17(v267,v268,v269){
const v270=__fn16(v267,v268,v269);
let v271;if(Object.hasOwn(v270,"Some")){
const v272=v270["Some"];
v271=({Ok:({["data"]:v267,["epsilon"]:v268,["budget"]:v272})});}else{
const v273=null;
v271=({Err:"invalid simple prepared text"});}
return v271;}
function __fn18(v274){
const v275=v274["data"];
const v276=v274["epsilon"];
const v277=1000000;
const v278=__fn16(v275,v276,v277);
let v279;if(Object.hasOwn(v278,"Some")){
const v280=v278["Some"];
const v281=v274["budget"];
v279=(v280===v281);}else{
const v282=null;
v279=false;}
return v279;}
function __fn19(v283){
let v284;if(Number.isNaN(__dfNumber(v283))){
v284=__dfFromBits(9218868437227405312n);}else{
v284=v283;}
return v284;}
function __fn20(v285,v286){
const v287=0.0;
let v288;if(((__dfNumber(v286)) > (__dfNumber(v287)))){
v288=v286;}else{
v288=0.0;}
const v289=v288;
const v290=v285["epsilon"];
return (__dfNumber(v289) + __dfNumber(v290));}
function __fn21(v291,v292){
const v293=(v291["widths"]).length;
const v294=v292["segment"];
const v295=0;
const v296=(v294===v295);
const v297=v292["grapheme"];
const v298=0;
const v299=((v297) > (v298));
let v300=v299;if(!v300){
const v301=v292["segment"];
v300=((v301) >= (v293));}
const v302=v300;
const v303=({["cursor"]:v292,["done"]:v302});
let v304=v303["cursor"];
let v305=v303["done"];
for(let v307=0;v307<v293;v307++){
if(v305){break;}
const v308=(v307>>>0);
const v309=v304;
const v310=v309["segment"];
let v311;if(__fn11(v291,v310,v296)){
const v312=v304;
const v313=v312["segment"];
const v314=1;
const v315=(((v313) + (v314)) >>> 0);
const v316=0;
const v317=({["segment"]:v315,["grapheme"]:v316});
const v318=v304;
const v319=v318["segment"];
const v320=1;
const v321=(((v319) + (v320)) >>> 0);
const v322=((v321) >= (v293));
v311=({["cursor"]:v317,["done"]:v322});}else{
const v323=v304;
const v324=true;
v311=({["cursor"]:v323,["done"]:v324});}
const v325=v311;
v304=v325["cursor"];
v305=v325["done"];
}
return v304;}
function __fn22(v327,v328,v329,v330){
const v331=(v327).length;
const v332=false;
const v333=({["index"]:v328,["width"]:v329,["done"]:v332});
let v334=v333["index"];
let v335=v333["width"];
let v336=v333["done"];
for(let v338=0;v338<v331;v338++){
const v339=v336;
let v340=v339;if(!v340){
const v341=v334;
const v342=(v327).length;
v340=((v341) >= (v342));}
if(v340){break;}
const v343=(v338>>>0);
const v344=v335;
const v345=v334;
let v346;if(v345<v327.length){v346=v327[v345];}else{
v346=0.0;}
const v347=v346;
const v348=(__dfNumber(v344) + __dfNumber(v347));
let v349;if(((__dfNumber(v348)) > (__dfNumber(v330)))){
const v350=true;
const v351=v334;
const v352=v335;
v349=({["index"]:v351,["width"]:v352,["done"]:v350});}else{
const v353=v334;
const v354=1;
const v355=(((v353) + (v354)) >>> 0);
const v356=v335;
const v357=v334;
let v358;if(v357<v327.length){v358=v327[v357];}else{
v358=0.0;}
const v359=v358;
const v360=(__dfNumber(v356) + __dfNumber(v359));
const v361=false;
v349=({["index"]:v355,["width"]:v360,["done"]:v361});}
const v362=v349;
v334=v362["index"];
v335=v362["width"];
v336=v362["done"];
}
return ({["index"]:v334,["width"]:v335,["done"]:v336});}
function __fn23(v363,v364,v365){
const v366=v365["index"];
const v367=v363["widths"];
let v368;if(v366<v367.length){v368=v367[v366];}else{
v368=0.0;}
const v369=v368;
const v370=v363["endTrims"];
const v371=__fn8(v370,v366);
const v372=v365["width"];
const v373=(__dfNumber(v372) + __dfNumber(v369));
const v374=(__dfNumber(v373) - __dfNumber(v371));
let v375;if(((__dfNumber(v374)) > (__dfNumber(v364)))){
const v376=__fn12(v363,v366);
const v377=false;
const v378=(v376===v377);
let v379=v378;if(v379){
const v380=1;
const v381=(((v366) - (v380)) >>> 0);
v379=__fn12(v363,v381);}
let v382;if(v379){
const v383=v365["width"];
const v384=v363["widths"];
const v385=1;
const v386=(((v366) - (v385)) >>> 0);
let v387;if(v386<v384.length){v387=v384[v386];}else{
v387=0.0;}
const v388=v387;
v382=(__dfNumber(v383) - __dfNumber(v388));}else{
const v389=v365["width"];
const v390=v365["trimmed"];
v382=(__dfNumber(v389) - __dfNumber(v390));}
const v391=v382;
let v392;if(v376){
const v393=1;
v392=(((v366) + (v393)) >>> 0);}else{
v392=v366;}
const v394=v392;
const v395=0;
const v397=true;
const v398=v365["index"];
const v399=v365["width"];
const v400=v365["trimmed"];
const v401=({["segment"]:v394,["grapheme"]:v395});
v375=({["index"]:v398,["width"]:v399,["trimmed"]:v400,["end"]:v401,["result"]:v391,["done"]:v397});}else{
const v402=v365["width"];
const v403=(__dfNumber(v402) + __dfNumber(v369));
const v404=1;
const v405=(((v366) + (v404)) >>> 0);
let v406;if(((__dfNumber(v403)) > (__dfNumber(v364)))){
v406=v371;}else{
v406=0.0;}
const v407=v406;
const v408=v365["end"];
const v409=v365["result"];
const v410=v365["done"];
v375=({["index"]:v405,["width"]:v403,["trimmed"]:v407,["end"]:v408,["result"]:v409,["done"]:v410});}
return v375;}
function __fn24(v411,v412,v413){
const v414=v411["data"];
const v415=__fn20(v411,v413);
const v416=(v414["widths"]).length;
const v417=v412["segment"];
const v418=v414["advances"];
let v419;if(v417<v418.length){v419=v418[v417];}else{
v419=({None:null});}
const v420=v419;
const v421=v414["startExtras"];
let v422;if(Object.hasOwn(v421,"Some")){
const v423=v421["Some"];
const v424=v414["widths"];
let v425;if(v417<v424.length){v425=v424[v417];}else{
v425=0.0;}
const v426=v425;
let v427;if(v417<v423.length){v427=v423[v417];}else{
v427=0.0;}
const v428=v427;
v422=(__dfNumber(v426) + __dfNumber(v428));}else{
const v429=null;
const v430=v414["widths"];
let v431;if(v417<v430.length){v431=v430[v417];}else{
v431=0.0;}
v422=v431;}
const v432=v422;
const v433=v414["endTrims"];
const v434=__fn8(v433,v417);
const v435=v414["overflowTrims"];
let v436;if(Object.hasOwn(v435,"Some")){
const v437=v435["Some"];
let v438;if(v417<v437.length){v438=v437[v417];}else{
v438=0.0;}
const v439=v438;
const v440=(__dfNumber(v432) - __dfNumber(v439));
let v441;if(((__dfNumber(v440)) <= (__dfNumber(v415)))){
let v442;if(v417<v437.length){v442=v437[v417];}else{
v442=0.0;}
v441=v442;}else{
v441=v434;}
v436=v441;}else{
const v443=null;
v436=v434;}
const v444=v436;
const v445=v412["grapheme"];
const v446=0;
const v447=((v445) > (v446));
let v448=v447;if(!v448){
const v449=(__dfNumber(v432) - __dfNumber(v444));
const v450=((__dfNumber(v449)) > (__dfNumber(v415)));
let v451=v450;if(v451){
let v452;if(Object.hasOwn(v420,"Some")){
const v453=v420["Some"];
v452=true;}else{
const v454=null;
v452=false;}
v451=v452;}
v448=v451;}
const v455=v448;
let v456;if(Object.hasOwn(v420,"Some")){
const v457=v420["Some"];
v456=v457;}else{
const v458=null;
v456=[];}
const v459=v456;
const v460=__fn9(v414,v417);
let v461;if(Object.hasOwn(v460,"Some")){
const v462=v460["Some"];
const v463=v412["grapheme"];
let v464;if(v463<v459.length){v464=v459[v463];}else{
v464=0.0;}
const v465=v464;
const v466=v412["grapheme"];
let v467;if(v466<v462.length){v467=v462[v466];}else{
v467=0.0;}
const v468=v467;
v461=(__dfNumber(v465) + __dfNumber(v468));}else{
const v469=null;
const v470=v412["grapheme"];
let v471;if(v470<v459.length){v471=v459[v470];}else{
v471=0.0;}
v461=v471;}
const v472=v461;
const v473=v412["grapheme"];
const v474=0;
let v475;if(((v473) > (v474))){
v475=v414["insideExtras"];}else{
v475=v414["fillExtras"];}
const v476=v475;
let v477;if(Object.hasOwn(v476,"Some")){
const v478=v476["Some"];
let v479;if(v417<v478.length){v479=v478[v417];}else{
v479=0.0;}
const v480=v479;
v477=(__dfNumber(v472) + __dfNumber(v480));}else{
const v481=null;
v477=v472;}
const v482=v477;
let v483;if(v455){
const v484=v412["grapheme"];
const v485=1;
const v486=(((v484) + (v485)) >>> 0);
v483=__fn22(v459,v486,v482,v415);}else{
const v487=(v459).length;
const v488=false;
v483=({["index"]:v487,["width"]:v432,["done"]:v488});}
const v489=v483;
let v490=v455;if(v490){
const v491=v489["index"];
const v492=(v459).length;
v490=((v491) < (v492));}
let v493;if(v490){
const v494=v489["width"];
const v495=v489["index"];
const v496=({["segment"]:v417,["grapheme"]:v495});
v493=({["width"]:v494,["start"]:v412,["end"]:v496});}else{
const v497=false;
const v498=(v455===v497);
let v499=v498;if(v499){
v499=((__dfNumber(v432)) > (__dfNumber(v415)));}
let v500;if(v499){
v500=v444;}else{
v500=0.0;}
const v501=v500;
const v502=1;
const v503=(((v417) + (v502)) >>> 0);
const v504=v489["width"];
const v505=0;
const v506=({["segment"]:v416,["grapheme"]:v505});
const v507=0.0;
const v508=false;
const v509=({["index"]:v503,["width"]:v504,["trimmed"]:v501,["end"]:v506,["result"]:v507,["done"]:v508});
let v510=v509["index"];
let v511=v509["width"];
let v512=v509["trimmed"];
let v513=v509["end"];
let v514=v509["result"];
let v515=v509["done"];
for(let v517=0;v517<v416;v517++){
const v518=v515;
let v519=v518;if(!v519){
const v520=v510;
v519=((v520) >= (v416));}
if(v519){break;}
const v521=(v517>>>0);
const v522=({["index"]:v510,["width"]:v511,["trimmed"]:v512,["end"]:v513,["result"]:v514,["done"]:v515});
const v523=__fn23(v414,v415,v522);
v510=v523["index"];
v511=v523["width"];
v512=v523["trimmed"];
v513=v523["end"];
v514=v523["result"];
v515=v523["done"];
}
let v525;if(v515){
v525=v514;}else{
const v526=v511;
const v527=v512;
v525=(__dfNumber(v526) - __dfNumber(v527));}
const v528=v525;
const v529=v513;
v493=({["width"]:v528,["start"]:v412,["end"]:v529});}
return v493;}
function __fn25(v530,v531,v532){
const v533=({Some:null});
let v534;if(Object.hasOwn(v533,"Some")){
const v535=v533["Some"];
v534=__fn18(v530);}else{
const v536=null;
v534=__fn18(v530);}
let v537;if(v534){
const v538=v530["data"];
const v539=(v538["widths"]).length;
const v540=v531["segment"];
const v541=((v540) > (v539));
let v542=v541;if(!v542){
const v543=v531["segment"];
const v544=(v543===v539);
let v545=v544;if(v545){
const v546=v531["grapheme"];
const v547=0;
v545=((v546) > (v547));}
v542=v545;}
const v548=v542;
let v549=v548;if(!v549){
const v550=v531["grapheme"];
const v551=0;
const v552=((v550) > (v551));
let v553=v552;if(v553){
const v554=v530["data"];
const v555=v554["advances"];
const v556=v531["segment"];
let v557;if(v556<v555.length){v557=v555[v556];}else{
v557=({None:null});}
const v558=v557;
let v559;if(Object.hasOwn(v558,"Some")){
const v560=v558["Some"];
const v561=v531["grapheme"];
const v562=(v560).length;
v559=((v561) < (v562));}else{
const v563=null;
v559=false;}
const v564=v559;
const v565=false;
v553=(v564===v565);}
v549=v553;}
let v566;if(v549){
v566=({Err:"invalid line cursor"});}else{
const v567=v530["data"];
const v568=__fn21(v567,v531);
const v569=v568["segment"];
let v570;if(((v569) >= (v539))){
v570=({Ok:({None:null})});}else{
const v571=__fn19(v532);
v570=({Ok:({Some:__fn24(v530,v568,v571)})});}
v566=v570;}
v537=v566;}else{
const v572=({Some:null});
let v573;if(Object.hasOwn(v572,"Some")){
const v574=v572["Some"];
v573="invalid prepared text";}else{
const v575=null;
v573="invalid prepared text";}
v537=({Err:v573});}
return v537;}
function __fn26(v576,v577,v578){
const v579=v576["data"];
const v580=v578["cursor"];
const v581=__fn21(v579,v580);
const v582=v581["segment"];
const v583=v576["data"];
const v584=(v583["widths"]).length;
let v585;if(((v582) >= (v584))){
const v586=true;
const v587=v578["cursor"];
const v588=v578["stats"];
v585=({["cursor"]:v587,["stats"]:v588,["done"]:v586});}else{
const v589=__fn24(v576,v581,v577);
const v590=v589["end"];
const v591=v578["stats"];
const v592=v591["lineCount"];
const v593=1;
const v594=(((v592) + (v593)) >>> 0);
const v595=v589["width"];
const v596=v578["stats"];
const v597=v596["maxLineWidth"];
let v598;if(((__dfNumber(v595)) > (__dfNumber(v597)))){
v598=v589["width"];}else{
const v599=v578["stats"];
v598=v599["maxLineWidth"];}
const v600=v598;
const v601=({["lineCount"]:v594,["maxLineWidth"]:v600});
const v602=false;
v585=({["cursor"]:v590,["stats"]:v601,["done"]:v602});}
return v585;}
function __fn27(v603,v604){
const v605=v603["budget"];
const v606=1;
const v607=(((v605) + (v606)) >>> 0);
const v608=0;
const v609=0;
const v610=({["segment"]:v608,["grapheme"]:v609});
const v611=0;
const v612=0.0;
const v613=({["lineCount"]:v611,["maxLineWidth"]:v612});
const v614=false;
const v615=({["cursor"]:v610,["stats"]:v613,["done"]:v614});
let v616=v615["cursor"];
let v617=v615["stats"];
let v618=v615["done"];
for(let v620=0;v620<v607;v620++){
if(v618){break;}
const v621=(v620>>>0);
const v623=v603["data"];
const v624=v616;
const v625=__fn21(v623,v624);
const v626=v625["segment"];
const v627=v603["data"];
const v628=(v627["widths"]).length;
let v629;
let v630;
let v631;
if(((v626) >= (v628))){
const v632=true;
const v633=v616;
const v634=v617;
v629=v633;
v630=v634;
v631=v632;
}else{
const v635=__fn24(v603,v625,v604);
const v636=v635["end"];
const v637=v617;
const v638=v637["lineCount"];
const v639=1;
const v640=(((v638) + (v639)) >>> 0);
const v641=v635["width"];
const v642=v617;
const v643=v642["maxLineWidth"];
let v644;if(((__dfNumber(v641)) > (__dfNumber(v643)))){
v644=v635["width"];}else{
const v645=v617;
v644=v645["maxLineWidth"];}
const v646=v644;
const v647=({["lineCount"]:v640,["maxLineWidth"]:v646});
const v648=false;
v629=v636;
v630=v647;
v631=v648;
}
v616=v629;
v617=v630;
v618=v631;
}
return v617;}
function __fn28(v650,v651){
const v652=({Some:null});
let v653;if(Object.hasOwn(v652,"Some")){
const v654=v652["Some"];
v653=__fn18(v650);}else{
const v655=null;
v653=__fn18(v650);}
let v656;if(v653){
const v657=__fn19(v651);
v656=({Ok:__fn27(v650,v657)});}else{
const v658=({Some:null});
let v659;if(Object.hasOwn(v658,"Some")){
const v660=v658["Some"];
v659="invalid prepared text";}else{
const v661=null;
v659="invalid prepared text";}
v656=({Err:v659});}
return v656;}
function __fn29(v662,v663,v664){
const v665=v662["data"];
const v666=v664["cursor"];
const v667=__fn21(v665,v666);
const v668=v667["segment"];
const v669=v662["data"];
const v670=(v669["widths"]).length;
let v671;if(((v668) >= (v670))){
const v672=true;
const v673=v664["cursor"];
const v674=v664["lines"];
v671=({["cursor"]:v673,["lines"]:v674,["done"]:v672});}else{
const v675=__fn24(v662,v667,v663);
const v676=v675["end"];
const v677=v664["lines"];
const v678=__tempEdit(v677,"push",v675);
const v679=false;
v671=({["cursor"]:v676,["lines"]:v678,["done"]:v679});}
return v671;}
function __fn30(v680,v681){
const v682=({Some:null});
let v683;if(Object.hasOwn(v682,"Some")){
const v684=v682["Some"];
v683=__fn18(v680);}else{
const v685=null;
v683=__fn18(v680);}
let v686;if(v683){
const v687=v680["budget"];
const v688=1;
const v689=(((v687) + (v688)) >>> 0);
const v690=0;
const v691=0;
const v692=({["segment"]:v690,["grapheme"]:v691});
const v693=new __InkBuffer([]);
const v694=false;
let v695=({["cursor"]:v692,["lines"]:v693,["done"]:v694});
for(let v696=0;v696<v689;v696++){
const v697=v695;
if(v697["done"]){break;}
const v698=(v696>>>0);
const v699=__fn19(v681);
const v700=v695;
v695=__fn29(v680,v699,v700);}
const v701=v695;
const v702=v701["lines"];
v686=({Ok:v702.freeze()});}else{
const v703=({Some:null});
let v704;if(Object.hasOwn(v703,"Some")){
const v705=v703["Some"];
v704="invalid prepared text";}else{
const v706=null;
v704="invalid prepared text";}
v686=({Err:v704});}
return v686;}
function __fn31(v707,v708,v709,v710){
const v711=(v707).length;
const v712=false;
const v713=({["index"]:v708,["width"]:v709,["done"]:v712});
let v714=v713["index"];
let v715=v713["width"];
let v716=v713["done"];
for(let v718=0;v718<v711;v718++){
const v719=v716;
let v720=v719;if(!v720){
const v721=v714;
const v722=(v707).length;
v720=((v721) >= (v722));}
if(v720){break;}
const v723=(v718>>>0);
const v724=v715;
const v725=v714;
let v726;if(v725<v707.length){v726=v707[v725];}else{
v726=0.0;}
const v727=v726;
const v728=(__dfNumber(v724) + __dfNumber(v727));
let v729;if(((__dfNumber(v728)) <= (__dfNumber(v710)))){
const v730=v714;
const v731=1;
const v732=(((v730) + (v731)) >>> 0);
const v733=v715;
const v734=v714;
let v735;if(v734<v707.length){v735=v707[v734];}else{
v735=0.0;}
const v736=v735;
const v737=(__dfNumber(v733) + __dfNumber(v736));
const v738=false;
v729=({["index"]:v732,["width"]:v737,["done"]:v738});}else{
const v739=true;
const v740=v714;
const v741=v715;
v729=({["index"]:v740,["width"]:v741,["done"]:v739});}
const v742=v729;
v714=v742["index"];
v715=v742["width"];
v716=v742["done"];
}
return ({["index"]:v714,["width"]:v715,["done"]:v716});}
function __fn32(v743,v744,v745,v746){
const v747=v746["count"];
const v748=v747["width"];
let v749;if(Object.hasOwn(v744,"Some")){
const v750=v744["Some"];
const v751=v746["index"];
let v752;if(v751<v750.length){v752=v750[v751];}else{
v752=0.0;}
v749=v752;}else{
const v753=null;
v749=0.0;}
const v754=v749;
const v755=(__dfNumber(v748) + __dfNumber(v754));
const v756=v746["index"];
let v757;if(v756<v743.length){v757=v743[v756];}else{
v757=0.0;}
const v758=v757;
const v759=(__dfNumber(v755) + __dfNumber(v758));
const v760=v746["index"];
const v761=1;
const v762=(((v760) + (v761)) >>> 0);
const v763=__fn31(v743,v762,v759,v745);
const v764=v763["index"];
const v765=(v743).length;
let v766;if(((v764) < (v765))){
const v767=v746["count"];
const v768=v767["lines"];
const v769=1;
const v770=(((v768) + (v769)) >>> 0);
const v771=0.0;
const v772=false;
const v773=({["lines"]:v770,["width"]:v771,["content"]:v772});
const v774=v763["index"];
v766=({["count"]:v773,["index"]:v774});}else{
const v775=v746["count"];
const v776=v775["lines"];
const v777=v763["width"];
const v778=true;
const v779=({["lines"]:v776,["width"]:v777,["content"]:v778});
const v780=v763["index"];
v766=({["count"]:v779,["index"]:v780});}
return v766;}
function __fn33(v781,v782,v783,v784){
const v785=__fn10(v781,v783);
const v786=v781["widths"];
let v787;if(v783<v786.length){v787=v786[v783];}else{
v787=0.0;}
const v788=v787;
const v789=v781["endTrims"];
const v790=__fn8(v789,v783);
const v791=v784["content"];
let v792=v791;if(v792){
const v793=v784["width"];
const v794=(__dfNumber(v793) + __dfNumber(v788));
const v795=(__dfNumber(v794) - __dfNumber(v790));
v792=((__dfNumber(v795)) <= (__dfNumber(v782)));}
let v796;if(v792){
const v797=v784["width"];
const v798=(__dfNumber(v797) + __dfNumber(v788));
const v799=v784["lines"];
const v800=v784["content"];
v796=({["lines"]:v799,["width"]:v798,["content"]:v800});}else{
const v801=v784["content"];
let v802;if(v801){
const v803=v784["lines"];
const v804=1;
const v805=(((v803) + (v804)) >>> 0);
const v806=0.0;
const v807=false;
v802=({["lines"]:v805,["width"]:v806,["content"]:v807});}else{
v802=v784;}
const v808=v802;
let v809=v801;if(v809){
const v810=0;
v809=!(v785===v810);}
const v811=v809;
let v812=v811;if(!v812){
const v813=false;
const v814=(v801===v813);
let v815=v814;if(v815){
const v816=1;
const v817=(v785===v816);
let v818=v817;if(!v818){
const v819=2;
const v820=(v785===v819);
let v821=v820;if(v821){
const v822=0;
v821=((v783) > (v822));}
v818=v821;}
v815=v818;}
v812=v815;}
let v823;if(v812){
v823=v808;}else{
const v824=v781["startExtras"];
let v825;if(Object.hasOwn(v824,"Some")){
const v826=v824["Some"];
let v827;if(v783<v826.length){v827=v826[v783];}else{
v827=0.0;}
const v828=v827;
v825=(__dfNumber(v788) + __dfNumber(v828));}else{
const v829=null;
v825=v788;}
const v830=v825;
const v831=v781["advances"];
let v832;if(v783<v831.length){v832=v831[v783];}else{
v832=({None:null});}
const v833=v832;
const v834=(__dfNumber(v830) - __dfNumber(v790));
const v835=((__dfNumber(v834)) <= (__dfNumber(v782)));
let v836=v835;if(!v836){
let v837;if(Object.hasOwn(v833,"Some")){
const v838=v833["Some"];
v837=false;}else{
const v839=null;
v837=true;}
v836=v837;}
let v840;if(v836){
const v841=v808["width"];
const v842=(__dfNumber(v841) + __dfNumber(v830));
const v843=true;
const v844=v808["lines"];
v840=({["lines"]:v844,["width"]:v842,["content"]:v843});}else{
let v845;if(Object.hasOwn(v833,"Some")){
const v846=v833["Some"];
v845=v846;}else{
const v847=null;
v845=[];}
const v848=v845;
const v849=(v848).length;
const v850=0;
const v851=({["count"]:v808,["index"]:v850});
let v852=v851["count"];
let v853=v851["index"];
for(let v855=0;v855<v849;v855++){
const v856=v853;
const v857=(v848).length;
if(((v856) >= (v857))){break;}
const v858=(v855>>>0);
const v859=__fn9(v781,v783);
const v861=v852;
const v862=v861["width"];
let v863;if(Object.hasOwn(v859,"Some")){
const v864=v859["Some"];
const v865=v853;
let v866;if(v865<v864.length){v866=v864[v865];}else{
v866=0.0;}
v863=v866;}else{
const v867=null;
v863=0.0;}
const v868=v863;
const v869=(__dfNumber(v862) + __dfNumber(v868));
const v870=v853;
let v871;if(v870<v848.length){v871=v848[v870];}else{
v871=0.0;}
const v872=v871;
const v873=(__dfNumber(v869) + __dfNumber(v872));
const v874=v853;
const v875=1;
const v876=(((v874) + (v875)) >>> 0);
const v877=__fn31(v848,v876,v873,v782);
const v878=v877["index"];
const v879=(v848).length;
let v880;
let v881;
if(((v878) < (v879))){
const v882=v852;
const v883=v882["lines"];
const v884=1;
const v885=(((v883) + (v884)) >>> 0);
const v886=0.0;
const v887=false;
const v888=({["lines"]:v885,["width"]:v886,["content"]:v887});
const v889=v877["index"];
v880=v888;
v881=v889;
}else{
const v890=v852;
const v891=v890["lines"];
const v892=v877["width"];
const v893=true;
const v894=({["lines"]:v891,["width"]:v892,["content"]:v893});
const v895=v877["index"];
v880=v894;
v881=v895;
}
v852=v880;
v853=v881;
}
v840=v852;}
v823=v840;}
v796=v823;}
return v796;}
function __fn34(v897,v898){
const v899=({Some:null});
let v900;if(Object.hasOwn(v899,"Some")){
const v901=v899["Some"];
v900=__fn18(v897);}else{
const v902=null;
v900=__fn18(v897);}
let v903;if(v900){
const v904=__fn19(v898);
const v905=v897["data"];
const v906=v905["overflowTrims"];
let v907;if(Object.hasOwn(v906,"Some")){
const v908=v906["Some"];
v907=true;}else{
const v909=null;
v907=false;}
let v910;if(v907){
const v911=__fn27(v897,v904);
v910=({Ok:v911["lineCount"]});}else{
const v912=v897["data"];
const v913=(v912["widths"]).length;
const v914=0;
const v915=0.0;
const v916=false;
const v917=({["lines"]:v914,["width"]:v915,["content"]:v916});
let v918=v917["lines"];
let v919=v917["width"];
let v920=v917["content"];
for(let v922=0;v922<v913;v922++){
if(false){break;}
const v923=(v922>>>0);
const v924=v897["data"];
const v925=__fn20(v897,v904);
const v927=__fn10(v924,v923);
const v928=v924["widths"];
let v929;if(v923<v928.length){v929=v928[v923];}else{
v929=0.0;}
const v930=v929;
const v931=v924["endTrims"];
const v932=__fn8(v931,v923);
const v933=v920;
let v934=v933;if(v934){
const v935=v919;
const v936=(__dfNumber(v935) + __dfNumber(v930));
const v937=(__dfNumber(v936) - __dfNumber(v932));
v934=((__dfNumber(v937)) <= (__dfNumber(v925)));}
let v938;
let v939;
let v940;
if(v934){
const v941=v919;
const v942=(__dfNumber(v941) + __dfNumber(v930));
const v943=v918;
const v944=v920;
v938=v943;
v939=v942;
v940=v944;
}else{
const v945=v920;
let v946;
let v947;
let v948;
if(v945){
const v949=v918;
const v950=1;
const v951=(((v949) + (v950)) >>> 0);
const v952=0.0;
const v953=false;
v946=v951;
v947=v952;
v948=v953;
}else{
v946=v918;
v947=v919;
v948=v920;
}
let v955=v945;if(v955){
const v956=0;
v955=!(v927===v956);}
const v957=v955;
let v958=v957;if(!v958){
const v959=false;
const v960=(v945===v959);
let v961=v960;if(v961){
const v962=1;
const v963=(v927===v962);
let v964=v963;if(!v964){
const v965=2;
const v966=(v927===v965);
let v967=v966;if(v967){
const v968=0;
v967=((v923) > (v968));}
v964=v967;}
v961=v964;}
v958=v961;}
let v969;
let v970;
let v971;
if(v958){
v969=v946;
v970=v947;
v971=v948;
}else{
const v972=v924["startExtras"];
let v973;if(Object.hasOwn(v972,"Some")){
const v974=v972["Some"];
let v975;if(v923<v974.length){v975=v974[v923];}else{
v975=0.0;}
const v976=v975;
v973=(__dfNumber(v930) + __dfNumber(v976));}else{
const v977=null;
v973=v930;}
const v978=v973;
const v979=v924["advances"];
let v980;if(v923<v979.length){v980=v979[v923];}else{
v980=({None:null});}
const v981=v980;
const v982=(__dfNumber(v978) - __dfNumber(v932));
const v983=((__dfNumber(v982)) <= (__dfNumber(v925)));
let v984=v983;if(!v984){
let v985;if(Object.hasOwn(v981,"Some")){
const v986=v981["Some"];
v985=false;}else{
const v987=null;
v985=true;}
v984=v985;}
let v988;
let v989;
let v990;
if(v984){
const v991=v947;
const v992=(__dfNumber(v991) + __dfNumber(v978));
const v993=true;
const v994=v946;
v988=v994;
v989=v992;
v990=v993;
}else{
let v995;if(Object.hasOwn(v981,"Some")){
const v996=v981["Some"];
v995=v996;}else{
const v997=null;
v995=[];}
const v998=v995;
const v999=(v998).length;
const v1000=({["lines"]:v946,["width"]:v947,["content"]:v948});
const v1001=0;
const v1002=({["count"]:v1000,["index"]:v1001});
let v1003=v1002["count"];
let v1004=v1002["index"];
for(let v1006=0;v1006<v999;v1006++){
const v1007=v1004;
const v1008=(v998).length;
if(((v1007) >= (v1008))){break;}
const v1009=(v1006>>>0);
const v1010=__fn9(v924,v923);
const v1011=({["count"]:v1003,["index"]:v1004});
const v1012=__fn32(v998,v1010,v925,v1011);
v1003=v1012["count"];
v1004=v1012["index"];
}
const v1014=v1003;
v988=v1014["lines"];
v989=v1014["width"];
v990=v1014["content"];
}
v969=v988;
v970=v989;
v971=v990;
}
v938=v969;
v939=v970;
v940=v971;
}
v918=v938;
v919=v939;
v920=v940;
}
const v1016=v918;
let v1017;if(v920){
v1017=1;}else{
v1017=0;}
const v1018=v1017;
v910=({Ok:(((v1016) + (v1018)) >>> 0)});}
v903=v910;}else{
const v1019=({Some:null});
let v1020;if(Object.hasOwn(v1019,"Some")){
const v1021=v1019["Some"];
v1020="invalid prepared text";}else{
const v1022=null;
v1020="invalid prepared text";}
v903=({Err:v1020});}
return v903;}
function __fn35(v1023,v1024,v1025){
const v1026=__fn34(v1023,v1024);
let v1027;if(Object.hasOwn(v1026,"Ok")){
const v1028=v1026["Ok"];
const v1029=(__dfNumber(v1028) * __dfNumber(v1025));
v1027=({Ok:({["lineCount"]:v1028,["height"]:v1029})});}else{v1027=({Err:v1026.Err});}
return v1027;}
function __into7(v1030,v1031){
const v1032=v1030.length;
for(let v1034=0;v1034<v1032;v1034++){
const v1035=v1030[v1034];
const v1036=__bits(__float(v1035) * __float(v1035));
const v1037=1056964608;
v1031[v1034]=__intoOutput7(__bits(__float(v1036) + __float(v1037)));
}
return v1032;}
const __namedTypes={"ink_m086abde96a678051961f464f791c4c5c94b31f286fb29436e88cbebcf9b5ad1c":{"fields":[{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"stats","type":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m086abde96a678051961f464f791c4c5c94b31f286fb29436e88cbebcf9b5ad1c"},"ink_m2009348d597e6b76dc210821f6f99bb8afebe7919b4fe0a09c17b3f9ac4793c3":{"fields":[{"name":"index","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"trimmed","type":{"kind":"f64"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"result","type":{"kind":"f64"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m2009348d597e6b76dc210821f6f99bb8afebe7919b4fe0a09c17b3f9ac4793c3"},"ink_m233b63cde5b1951078531833cb439d88de244d40e3a6392d35d12e48ecb2ef5d":{"fields":[{"name":"valid","type":{"kind":"bool"}},{"name":"budget","type":{"kind":"u32"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"ink_m233b63cde5b1951078531833cb439d88de244d40e3a6392d35d12e48ecb2ef5d"},"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"},"ink_m38199727c3368a931db73c0ac28f57f806019aaf5325d854f5e146190d590ba5":{"fields":[{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m38199727c3368a931db73c0ac28f57f806019aaf5325d854f5e146190d590ba5"},"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},"ink_m7b062ce6e1c2efcea6de69b7c533325db5ea045c74268a2b5acae500b6575dfc":{"fields":[{"name":"index","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m7b062ce6e1c2efcea6de69b7c533325db5ea045c74268a2b5acae500b6575dfc"},"ink_mb57c7f78770196118eeb183601122638651b9dc2e5e5132e7d0d790985b01684":{"fields":[{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"lines","type":{"kind":"temporary"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_mb57c7f78770196118eeb183601122638651b9dc2e5e5132e7d0d790985b01684"},"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993":{"fields":[{"name":"width","type":{"kind":"f64"}},{"name":"start","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"kind":"record","name":"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993"},"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"},"ink_me68c2f5e5e86a516faa862d519cff9a3e02bc5e131745a9c88827226a0059c6a":{"fields":[{"name":"count","type":{"fields":[{"name":"lines","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"content","type":{"kind":"bool"}}],"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"ink_me68c2f5e5e86a516faa862d519cff9a3e02bc5e131745a9c88827226a0059c6a"},"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"},"ink_mf31874390da54b3c180b48032618b677f5ca389c9ffcfc54ae469de235e84bcb":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"height","type":{"kind":"f64"}}],"kind":"record","name":"ink_mf31874390da54b3c180b48032618b677f5ca389c9ffcfc54ae469de235e84bcb"},"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844":{"fields":[{"name":"lines","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"content","type":{"kind":"bool"}}],"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"}};
// Portable snapshot ABI shared with native/Wasm. Hashing uses Web Crypto.
function __snapshotLimits(limits={}){
 const result={bytes:64*1024*1024,values:1000000,depth:128,...limits};
 for(const k of ['bytes','values','depth'])if(!Number.isSafeInteger(result[k])||result[k]<0||result[k]>(k==='depth'?128:k==='values'?1000000:64*1024*1024))throw Error('invalid snapshot limits');
 return result;
}
const __hash=async bytes=>new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256',bytes));
function __snapshotWriter(limits){
 const out=[];let left=limits.values,maxDepth=0;
 function bytes(xs){if(xs.length>limits.bytes-out.length)throw Error('snapshot byte limit exceeded');for(const x of xs)out.push(x);}
 function integer(n,size){n=BigInt(n);for(let i=0;i<size;i++){bytes([Number(n&255n)]);n>>=8n;}}
 function raw(xs){integer(xs.length,8);bytes(xs);}
 function value(v,t,depth=0,bindings=[]){maxDepth=Math.max(maxDepth,depth);if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{value(v,t.body,depth+1,bindings);}finally{bindings.pop();}break;
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');value(v,bound[1],depth+1,bindings);break;}
  case 'unit':break;case 'bool':bytes([v?1:0]);break;
  case 'u32':case 'i32':case 'f32':integer(v,4);break;case 'u64':integer(v,8);break;
  case 'f64':integer(__dfBits(v),8);break;
  case 'vector':if(v.length!==t.size)throw Error('vector dimension mismatch');for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'int':{let n=v<0n?-v:v;const xs=[];while(n){if(xs.length>=4096)throw Error('snapshot Int exceeds size limit');xs.push(Number(n&255n));n>>=8n;}bytes([v===0n?0:v>0n?1:2]);raw(xs);break;}
  case 'string':raw(__encoder.encode(v));break;
  case 'id':integer(BigInt('0x'+v),16);break;
  case 'enum':integer(t.variants.indexOf(v),4);break;
  case 'record':for(const f of t.fields)value(t.elided?v:v[f.name],f.type,depth+1,bindings);break;
  case 'list':if(v.length>left)throw Error('snapshot value limit exceeded');integer(v.length,8);for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'option':if(Object.hasOwn(v,'Some')){bytes([1]);value(v.Some,t.element,depth+1,bindings);}else bytes([0]);break;
  case 'result':{const branch=t.sum_key?__sumView(t.sum_key,v):v;if(Object.hasOwn(branch,'Ok')){bytes([0]);value(branch.Ok,t.ok,depth+1,bindings);}else{bytes([1]);value(branch.Err,t.error,depth+1,bindings);}break;}
  default:throw Error('unsupported snapshot type');
 }}
 return {bytes,integer,raw,value,charge(cells,depth){left-=cells;if(left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');},get maxDepth(){return maxDepth;},get left(){return left;},finish:()=>new Uint8Array(out)};
}
async function __snapshotEncode(meta,state,options){
 const limits=__snapshotLimits(options),w=__snapshotWriter(limits);
 w.integer(state.version,8);
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const rows=[...state.tables[r.index].entries()].sort((a,b)=>__keyCompare(a[0],b[0],r.key));if(rows.length>Math.floor(w.left/2))throw Error('snapshot row limit exceeded');w.integer(rows.length,8);for(const [k,v]of rows){
  if(!meta.snapshotRows){w.value(k,r.snapshotKey??r.key);w.value(v,r.snapshotValue??r.value);continue;}
  const cache=state.snapshotRows[r.index];let packed=cache.get(k);
  if(!packed){const row=__snapshotWriter(limits);row.value(k,r.snapshotKey??r.key);row.value(v,r.snapshotValue??r.value);packed={bytes:row.finish(),cells:limits.values-row.left,depth:row.maxDepth};cache.set(k,packed);}
  w.charge(packed.cells,packed.depth);w.bytes(packed.bytes);
 }}
 w.integer(state.outbox.length,8);
 for(const e of state.outbox){const channel=meta.events.findIndex(t=>t.name===e.channel);w.integer(e.commit,8);w.integer(e.position,8);w.integer(channel,4);w.value(e.value,meta.events[channel].snapshotType??meta.events[channel].type);}
 const payload=w.finish(),header=__snapshotWriter(limits);header.bytes([86,76,83,84,65,84,69,0,1,0,1,0]);header.bytes(meta.snapshot.program);header.bytes(meta.snapshot.schema);header.integer(payload.length,8);header.bytes(payload);
 const bytes=header.finish();if(bytes.length+32>limits.bytes)throw Error('snapshot byte limit exceeded');const digest=await __hash(bytes);const result=new Uint8Array(bytes.length+32);result.set(bytes);result.set(digest,bytes.length);return result;
}
async function __snapshotDecode(meta,input,options){
 const limits=__snapshotLimits(options);
 if(!(input instanceof Uint8Array)&&!Array.isArray(input))throw Error('expected snapshot bytes');
 if(input.length>limits.bytes||input.length<116)throw Error('snapshot byte length invalid');
 if(Array.isArray(input)&&input.some(b=>!Number.isInteger(b)||b<0||b>255))throw Error('invalid snapshot bytes');
 const bytes=new Uint8Array(input); // capture before asynchronous integrity work
 function same(a,b){return a.length===b.length&&a.every((v,i)=>v===b[i]);}
 if(!same(bytes.subarray(0,12),[86,76,83,84,65,84,69,0,1,0,1,0]))throw Error('snapshot format or semantics version mismatch');
 if(!same(bytes.subarray(12,44),meta.snapshot.program)||!same(bytes.subarray(44,76),meta.snapshot.schema))throw Error('snapshot program or schema identity mismatch');
 const end=bytes.length-32,digest=await __hash(bytes.subarray(0,end));if(!same(digest,bytes.subarray(end)))throw Error('snapshot integrity check failed');
 let at=76,left=limits.values;
 function take(n){if(!Number.isSafeInteger(n)||n<0||n>end-at)throw Error('truncated snapshot');const x=bytes.subarray(at,at+n);at+=n;return x;}
 function integer(size){const xs=take(size);let n=0n;for(let i=size-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return n;}
 function length(){const n=integer(8);if(n>BigInt(Number.MAX_SAFE_INTEGER))throw Error('snapshot length not addressable');return Number(n);}
 function sequence(){const n=length();if(n>left)throw Error('snapshot value limit exceeded');return n;}
 function raw(){return take(length());}
 const n=length();if(n!==end-84)throw Error('snapshot payload length mismatch');
 function value(t,depth=0,bindings=[]){if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{return value(t.body,depth+1,bindings);}finally{bindings.pop();}
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');return value(bound[1],depth+1,bindings);}
  case 'unit':return null;case 'bool':{const b=take(1)[0];if(b>1)throw Error('invalid Bool tag');return b===1;}
  case 'u32':case 'f32':return Number(integer(4));case 'i32':return Number(BigInt.asIntN(32,integer(4)));case 'u64':return integer(8);
  case 'f64':return __dfFromBits(integer(8));
  case 'vector':{const xs=[];for(let i=0;i<t.size;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'int':{const sign=take(1)[0],xs=raw();if(xs.length>4096)throw Error('snapshot Int exceeds size limit');if(!((sign===0&&xs.length===0)||((sign===1||sign===2)&&xs.length>0&&xs[xs.length-1]!==0)))throw Error('noncanonical signed integer');let n=0n;for(let i=xs.length-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return sign===2?-n:n;}
  case 'string':return new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(raw());
  case 'id':return integer(16).toString(16).padStart(32,'0');
  case 'enum':{const i=Number(integer(4));if(i>=t.variants.length)throw Error('invalid enum tag');return t.variants[i];}
  case 'record':if(t.elided)return value(t.fields[0].type,depth+1,bindings);return Object.fromEntries(t.fields.map(f=>[f.name,value(f.type,depth+1,bindings)]));
  case 'list':{const n=sequence(),xs=[];for(let i=0;i<n;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'option':{const tag=take(1)[0];if(tag===0)return {None:null};if(tag===1)return {Some:value(t.element,depth+1,bindings)};throw Error('invalid Option tag');}
  case 'result':{const tag=take(1)[0];if(tag===0){const child=value(t.ok,depth+1,bindings);return t.sum_key?__sumMake(t.sum_key,true,child):{Ok:child};}if(tag===1){const child=value(t.error,depth+1,bindings);return t.sum_key?__sumMake(t.sum_key,false,child):{Err:child};}throw Error('invalid Result tag');}
  default:throw Error('unsupported snapshot type');
 }}
 const version=integer(8),tables=meta.roots.map(()=>new Map());
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const n=sequence();if(n>Math.floor(left/2))throw Error('snapshot row limit exceeded');let prior;for(let i=0;i<n;i++){const k=value(r.snapshotKey??r.key),v=value(r.snapshotValue??r.value);if(i&&__keyCompare(prior,k,r.key)>=0)throw Error('duplicate or unordered snapshot key');tables[r.index].set(k,v);prior=k;}}
 const count=sequence(),outbox=[];let prior;
 for(let i=0;i<count;i++){const commit=integer(8),position=integer(8),channel=Number(integer(4));if(!meta.events[channel])throw Error('unknown snapshot event channel');const v=value(meta.events[channel].snapshotType??meta.events[channel].type);if(commit===0n||commit>version||(prior&&(commit<prior.commit||(commit===prior.commit&&position<=prior.position))))throw Error('invalid snapshot event sequence');const e={commit,position,channel:meta.events[channel].name,value:v};outbox.push(e);prior=e;}
 if(at!==end)throw Error('trailing snapshot payload');return {version,tables,outbox};
}
// Fixed subscription lifecycle. Root/output edges derive from checked source;
// values and ownership codecs are compiled from each query's declared type.
function __createObservers(prepare){
 const subscriptions=new Map(),byRoot=new Map(),errors=[],directRoots=[],rootSchedules=[];
 let pending=[],spare=[];
 let next=0,held=0,flushing=false;
 function report(s,error,phase){errors.push({query:s?.query??null,error,phase});if(s?.onError)try{s.onError(error);}catch(e){errors.push({query:s.query,error:e,phase:'error-handler'});}}
 function flush(initialPasses=0){
  if(held||flushing||!pending.length)return;
  flushing=true;let passes=initialPasses;
  try{
   while(pending.length&&!held){
    if(++passes>1024){report(null,Error('subscription publication budget exhausted'),'publication');break;}
    const affected=pending;pending=spare;spare=affected;
    for(const s of affected)s.queued=false;
    // Snapshot every affected value before consumers run. Deliveries reside in
    // the stable subscription slots; no per-delivery tuple is allocated.
    for(const s of affected){if(!s.active)continue;s.deliver=false;
     try{if(s.pair){const a=s.pairState?s.pairState.keeps[s.keep0]:s.read0(),b=s.pairState?s.pairState.keeps[s.keep1]:s.read1();if(s.value0!==a||s.value1!==b){s.value0=a;s.value1=b;s.delivery0=a;s.delivery1=b;s.deliver=true;}}else{const value=s.capture(s.read());if(!s.equal(s.value,value)){s.value=value;s.delivery=value;s.deliver=true;}}}
     catch(e){report(s,e,'query');}
    }
    for(const s of affected){if(!s.active||!s.deliver)continue;const value=s.delivery;s.deliver=false;s.delivery=undefined;
     try{if(s.pair)s.callback(s.delivery0,s.delivery1);else s.callback(s.output(value));}catch(e){report(s,e,'listener');}
    }
    affected.length=0;
   }
  }finally{flushing=false;}
 }
 function install(query,q,callback,{immediate=true,onError}={}){
  if(typeof callback!=='function'||onError!==undefined&&typeof onError!=='function')throw TypeError('subscription callback');
  const s={...q,id:next++,query,callback,onError,active:true,queued:false,deliver:false,delivery:undefined};
  if(s.pair){s.value0=s.pairState?s.pairState.keeps[s.keep0]:s.read0();s.value1=s.pairState?s.pairState.keeps[s.keep1]:s.read1();}else{s.value=s.capture(s.read());}subscriptions.set(s.id,s);
  for(const root of s.roots){let ids=byRoot.get(root);if(!ids)byRoot.set(root,ids=[]);ids.push(s);schedule(root,ids);}
  const dispose=()=>{if(!subscriptions.delete(s.id))return;s.active=false;for(const root of s.roots){const ids=byRoot.get(root);ids.splice(ids.indexOf(s),1);schedule(root,ids);if(!ids.length)byRoot.delete(root);}};
  if(immediate)try{if(s.pair)callback(s.value0,s.value1);else callback(s.output(s.value));}catch(e){dispose();throw e;}
  return dispose;
 }
 // Bind the publication implementation when consumers change, instead of
 // rediscovering the one-consumer schedule on each source mutation.
 function schedule(root,ids){
  const s=directRoots[root]=ids.length===1&&ids[0].pairState?ids[0]:null;
  rootSchedules[root]=!ids.length?null:s?()=>publishPair(s):(outputs,epoch)=>{enqueueRoot(root,outputs,epoch);flush();};
 }
 function publishPair(s){
  const a=s.pairState.keeps[s.keep0],b=s.pairState.keeps[s.keep1];
  if(s.value0===a&&s.value1===b)return;
  if(!held&&!flushing&&!pending.length){
   s.value0=a;s.value1=b;flushing=true;
   try{s.callback(a,b);}catch(e){report(s,e,'listener');}finally{flushing=false;}
   flush(1);return;
  }
  if(!s.queued){s.queued=true;pending.push(s);}flush();
 }
 function enqueueRoot(root,outputs,epoch){
  const slots=byRoot.get(root);if(!slots)return;
  for(let i=0;i<slots.length;i++){
   const s=slots[i];if(s.queued)continue;
   if(outputs!==null&&s.outputs?.length){
    let changed=false;for(let j=0;j<s.outputs.length;j++)if(epoch?outputs[s.outputs[j]]===epoch:outputs.has(s.outputs[j])){changed=true;break;}
    if(!changed)continue;
   }
   s.queued=true;pending.push(s);
  }
 }
 return {
  directRoots,rootSchedules,
  get active(){return subscriptions.size!==0;},
  subscribe(query,args,callback,options){return install(query,prepare(query,args),callback,options);},
  subscribeGroup(queries,callback,options){
   if(!Array.isArray(queries)||!queries.length)throw TypeError('subscription group requires queries');
   const qs=queries.map(q=>typeof q==='string'?prepare(q,[]):prepare(q.query,q.args??[]));
   const roots=[...new Set(qs.flatMap(q=>q.roots))];
   // An unknown dependency forces ordinary root invalidation for the group.
   const outputs=qs.every(q=>q.outputs?.length)?[...new Set(qs.flatMap(q=>q.outputs))]:[];
   const scalar=qs.every(q=>q.scalar),direct=qs.every(q=>q.direct);
   return install(queries,{roots,outputs,read:direct?()=>qs.map(q=>q.direct()):()=>qs.map(q=>q.read()),capture:scalar?values=>values:values=>values.map((v,i)=>qs[i].capture(v)),output:scalar?values=>values.slice():values=>values.map((v,i)=>qs[i].output(v)),equal:scalar?(a,b)=>a.every((v,i)=>v===b[i]):(a,b)=>a.every((v,i)=>qs[i].equal(v,b[i]))},callback,options);
  },
  subscribeValues(queries,callback,options){
   if(!Array.isArray(queries)||!queries.length)throw TypeError('subscription group requires queries');
   if(typeof callback!=='function')throw TypeError('subscription callback');
   const qs=queries.map(q=>typeof q==='string'?prepare(q,[]):prepare(q.query,q.args??[]));
   if(qs.length===2&&qs.every(q=>q.scalar)){
    const roots=[...new Set(qs.flatMap(q=>q.roots))],outputs=qs.every(q=>q.outputs?.length)?[...new Set(qs.flatMap(q=>q.outputs))]:[];
    const pairState=qs[0].committed&&qs[1].committed&&qs[0].committed.state===qs[1].committed.state?qs[0].committed.state:null;
    return install(queries,{roots,outputs,pair:true,pairState,keep0:qs[0].committed?.keep,keep1:qs[1].committed?.keep,read0:qs[0].direct||qs[0].read,read1:qs[1].direct||qs[1].read},callback,options);
   }
   return this.subscribeGroup(queries,values=>callback(...values),options);
  },
  commit(roots,outputs=null){
   if(!subscriptions.size)return;
   for(const root of roots)enqueueRoot(root,outputs,false);
   flush();
  },
  // A checked single-root action supplies a reusable array of changed outputs.
  // No root carrier, Set, affected-ID array or Map lookup per delivery is needed.
  commitRoot(root,outputs=null,epoch=0){
   rootSchedules[root]?.(outputs,epoch);
  },
  hold(){held++;return pending.slice();},
  release(){if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  rollback(mark){for(const s of pending)s.queued=false;pending.length=0;for(const s of mark)if(s.active&&!s.queued){s.queued=true;pending.push(s);}if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  batch(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('batch callback must be synchronous');held++;
   try{const value=callback();if(value&&typeof value.then==='function')throw TypeError('state batch callback must be synchronous');return value;}
   finally{held--;flush();}
  },
  flush,takeErrors(){return errors.splice(0);}
 };
}
function __versionWord(v){return typeof v==='number'?BigInt(v):v;}
function __storedCommit(meta,v){return meta.compactCommits&&v<=9007199254740991n?Number(v):v;}
function __nextCommit(v){return typeof v==='number'&&v<9007199254740991?v+1:BigInt(v)+1n;}
// Private column event log. Public records and portable event ordering are unchanged.
// Private event storage. Public events and portable snapshots keep their ordinary
// ordered records. A selected contiguous run omits repeated commit metadata;
// gaps and duplicate commits materialise an exact literal column.
class __EventColumns {
 constructor(channels,compact=false,runs=false){this.channels=channels;this.compact=compact;this.runs=runs;this.commits=runs?null:[];this.base=undefined;this.values=[];this.positions=null;this.channelValues=channels.length===1?null:[];}
 get length(){return this.values.length;}
 set length(n){if(!Number.isSafeInteger(n)||n<0||n>this.length)throw Error('event log truncate');if(this.commits)this.commits.length=n;this.values.length=n;if(this.positions)this.positions.length=n;if(this.channelValues)this.channelValues.length=n;if(n===0){this.base=undefined;if(this.runs)this.commits=null;}}
 append(commit,position,channel,value){
  const i=this.values.length;
  if(this.commits)this.commits.push(commit);
  else if(!i)this.base=commit;
  else{
   const small=typeof this.base==='number'&&typeof commit==='number';
   const expected=small?this.base+i:__versionWord(this.base)+BigInt(i);
   if(expected!==commit){
    this.commits=[];
    for(let j=0;j<i;j++){const word=__versionWord(this.base)+BigInt(j);this.commits.push(this.compact&&word<=9007199254740991n?Number(word):word);}
    this.commits.push(commit);
   }
  }
  this.values.push(value);if(this.channelValues)this.channelValues.push(channel);if(position!==0n&&!this.positions)this.positions=new Array(i).fill(0n);if(this.positions)this.positions.push(position);
 }
 push(e){this.append(this.compact&&e.commit<=9007199254740991n?Number(e.commit):e.commit,e.position,e.channel,e.value);return this.length;}
 at(i){if(i<0)i+=this.length;if(i<0||i>=this.length)return undefined;return {commit:this.commits?__versionWord(this.commits[i]):__versionWord(this.base)+BigInt(i),position:this.positions?this.positions[i]:0n,channel:this.channelValues?this.channelValues[i]:this.channels[0],value:this.values[i]};}
 *[Symbol.iterator](){for(let i=0;i<this.length;i++)yield this.at(i);}
 map(f){const out=new Array(this.length);for(let i=0;i<this.length;i++)out[i]=f(this.at(i),i);return out;}
 filter(f){const out=new __EventColumns(this.channels,this.compact,this.runs);for(let i=0;i<this.length;i++){const e=this.at(i);if(f(e,i))out.push(e);}return out;}
}
function __eventLog(meta,events=[]){
 if(!meta.eventColumns)return meta.compactCommits?events.map(e=>({...e,commit:__storedCommit(meta,e.commit)})):events;
 const log=new __EventColumns(meta.events.map(e=>e.name),meta.compactCommits,meta.eventRuns);for(const e of events)log.append(__storedCommit(meta,e.commit),e.position,e.channel,e.value);return log;
}
// CALLER CONTRACT: arguments must match declared types; malformed data may throw or corrupt state.
// Fixed state primitives used by emitted action bodies, without an AST evaluator.
class __Abort {constructor(value){this.value=value;}}
function __preflightError(message){throw Error(message);}
function __try(value){if(Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value.Ok;}
function __nested(value,change){if(change && Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value;}
function __equal(a,b){if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object')return false;const ak=Object.keys(a),bk=Object.keys(b);return ak.length===bk.length&&ak.every(k=>Object.hasOwn(b,k)&&__equal(a[k],b[k]));}
function __checked(op,a,b,bits){const x=BigInt(a),y=BigInt(b),n=op==='checked_add'?x+y:op==='checked_sub'?x-y:x*y;const min=bits===-32?-2147483648n:0n,max=bits===-32?2147483648n:1n<<BigInt(bits);return n<min||n>=max?{Err:'ArithmeticError.Overflow'}:{Ok:Math.abs(bits)===32?Number(n):n};}
function __okOr(value,error){return Object.hasOwn(value,'Some')?{Ok:value.Some}:{Err:error};}
function __mapValue(value,kind,method,fn){
 if(kind==='list')return value[method](fn);
 if(kind==='option')return Object.hasOwn(value,'Some')?{Some:fn(value.Some)}:{None:null};
 const tag=method==='map_err'?'Err':'Ok';return Object.hasOwn(value,tag)?{[tag]:fn(value[tag])}:value;
}
const __encoder=new TextEncoder();
function __tick(ctx){if(--ctx.fuel<0)throw Error('Ink state execution budget exhausted');}
function __keyCompare(a,b,type){
 if(type.kind==='string'){let i=0,j=0;while(i<a.length&&j<b.length){const x=a.codePointAt(i),y=b.codePointAt(j);if(x!==y)return x-y;i+=x>65535?2:1;j+=y>65535?2:1;}return (i<a.length?1:0)-(j<b.length?1:0);}
 return a<b?-1:a>b?1:0;
}
// A table's ordered key view is reused until membership changes. Values are
// fetched at traversal time, so replacement never leaves stale row payloads.
const __tableOrder=new WeakMap();
function __keyPosition(keys,key,type){let low=0,high=keys.length;while(low<high){const middle=(low+high)>>>1;if(__keyCompare(keys[middle],key,type)<0)low=middle+1;else high=middle;}return low;}
function __tableMembership(rt,index,key,present){
 const view=__tableOrder.get(rt.tables[index]);if(!view)return;
 const at=__keyPosition(view.keys,key,rt.meta.roots[index].key);
 if((at<view.keys.length&&view.keys[at]===key)===present)view.pending.delete(key);
 else view.pending.set(key,present);
}
function __orderedKeys(rt,index){
 const table=rt.tables[index],type=rt.meta.roots[index].key;let view=__tableOrder.get(table);
 if(!view){view={keys:[...table.keys()].sort((a,b)=>__keyCompare(a,b,type)),pending:new Map()};__tableOrder.set(table,view);}
 if(view.pending.size){
  const changes=[...view.pending.keys()].sort((a,b)=>__keyCompare(a,b,type)),merged=[];let i=0,j=0;
  while(i<view.keys.length||j<changes.length){
   if(j===changes.length||(i<view.keys.length&&__keyCompare(view.keys[i],changes[j],type)<0))merged.push(view.keys[i++]);
   else{const key=changes[j++];if(i<view.keys.length&&view.keys[i]===key)i++;if(view.pending.get(key))merged.push(key);}
  }
  view.keys=merged;view.pending.clear();
 }
 const keys=view.keys;
 const cell=rt.cell;
 if(cell&&cell.index===index&&table.has(cell.key)!==(cell.next!==undefined)){
  if(cell.next===undefined)return keys.filter(k=>k!==cell.key);
  const at=__keyPosition(keys,cell.key,type);return [...keys.slice(0,at),cell.key,...keys.slice(at)];
 }
 return keys;
}
function __cellGet(rt,index,key){const cell=rt.cell;return cell&&cell.index===index&&cell.key===key?cell.next:rt.tables[index].get(key);}
function __readTable(rt,index){const cell=rt.cell;if(!cell||cell.index!==index)return rt.tables[index];const table=new Map(rt.tables[index]);if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);return table;}
// The first before-image of each cell suffices for whole-transaction rollback.
function __remember(rt,index,key,present,value){if(rt.cellMode)return;if(!rt.seen[index].has(key)){rt.seen[index].add(key);rt.undo.push([index,key,present,value]);}}
// Immutable keeps retain private values. Public results remain owned copies.
// Reverse edges come from checked source effects.
// Before-images preserve cached values across failed actions; host rollback and
// restore discard caches rather than serializing them into logical snapshots.
function __invalidateKeeps(rt,index){
 if(rt.observers?.active)rt.changedRoots.add(index);
 if(!rt.keeps||rt.cellMode)return;
 for(const keep of rt.meta.keepInvalidations[index]){
  if(!rt.keepDirty[keep]){rt.keepDirty[keep]=1;rt.keepUndoIndices[rt.keepUndoCount++]=keep;rt.keepBefore[keep]=rt.keeps[keep];}
  rt.keeps[keep]=undefined;
 }
}
function __restoreKeeps(rt){for(let i=rt.keepUndoCount-1;i>=0;i--){const keep=rt.keepUndoIndices[i];rt.keeps[keep]=rt.keepBefore[keep];}__refreshActiveViews(rt);}
function __clearKeepJournal(rt){for(let i=0;i<rt.keepUndoCount;i++){const keep=rt.keepUndoIndices[i];rt.keepDirty[keep]=0;rt.keepBefore[keep]=undefined;}rt.keepUndoCount=0;}
function __rebuildViews(rt){
 rt.activeViewRoots=new Uint8Array(rt.meta.roots.length);
 for(const view of rt.views){rt.keeps[view.keep]=undefined;if(!rt.meta.lazyMaintenance)__viewBase(rt,view);}
}
function __refreshActiveViews(rt){rt.activeViewRoots.fill(0);for(const view of rt.views)if(rt.keeps[view.keep]!==undefined)rt.activeViewRoots[view.root]=1;}
function __viewBase(rt,view){
 if(rt.keeps[view.keep]===undefined){let value=view.zero;for(const [key,row]of rt.tables[view.root])value=view.combine(value,view.contribution(key,row));rt.keeps[view.keep]=value;rt.activeViewRoots[view.root]=1;}
 return rt.keeps[view.keep];
}
function __viewValue(view,value,key,oldValue,newValue){
 if(oldValue===undefined)return view.insert?view.insert(value,key,newValue):view.combine(value,view.contribution(key,newValue));
 if(newValue===undefined)return view.remove?view.remove(value,key,oldValue):view.combine(value,view.inverse(view.contribution(key,oldValue)));
 return view.replace?view.replace(value,key,oldValue,newValue):view.combine(view.combine(value,view.inverse(view.contribution(key,oldValue))),view.contribution(key,newValue));
}
function __updateViews(rt,index,key,oldValue,newValue){
 if(!rt.activeViewRoots[index])return null;
 const updates=rt.viewNext;
 for(const view of rt.viewsByRoot[index])updates[view.keep]=rt.keeps[view.keep]===undefined?undefined:__viewValue(view,rt.keeps[view.keep],key,oldValue,newValue);
 return updates;
}
function __installViews(rt,updates,index){if(updates)for(const view of rt.viewsByRoot[index])rt.keeps[view.keep]=updates[view.keep];}
function __pendingView(rt,view){
 const keep=view.keep;
 if(rt.pendingValues[keep]===undefined){
  const cell=rt.cell;
  rt.pendingValues[keep]=__viewValue(view,__viewBase(rt,view),cell.key,cell.prior,cell.next);
  rt.pendingIndices.push(keep);
 }
 return rt.pendingValues[keep];
}
function __prepareCell(rt){if(rt.cell&&rt.activeViewRoots[rt.cell.index]){const prepare=rt.views.prepareRoots?.[rt.cell.index];if(prepare)prepare(rt,rt.cell);else for(const view of rt.viewsByRoot[rt.cell.index])if(rt.keeps[view.keep]!==undefined)__pendingView(rt,view);}}
function __invalidateSnapshotRow(rt,index,key){rt.snapshotRows?.[index].delete(key);}
function __writeCell(rt,index,key,next,prior){
 if(rt.cellMode){if(rt.cell)throw Error('checked single-cell bound exceeded');rt.cell={index,key,next,prior};}
 else{const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);if(rt.changeTracking)__recordChange(rt,index,key,prior,next);if((prior!==undefined)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);if(next===undefined)table.delete(key);else table.set(key,next);}
}
function __commitCell(rt){
 const cell=rt.cell;if(!cell)return;
 const table=rt.tables[cell.index];__invalidateSnapshotRow(rt,cell.index,cell.key);
 if(rt.changeTracking)__recordChange(rt,cell.index,cell.key,cell.prior,cell.next);
 if((cell.prior!==undefined)!==(cell.next!==undefined))__tableMembership(rt,cell.index,cell.key,cell.next!==undefined);
 if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);
 for(const keep of rt.meta.keepInvalidations[cell.index])rt.keeps[keep]=rt.pendingValues[keep];
 rt.cell=null;
}
// Preflight scratch has no logical state or rollback obligations. Definitions
// are the same admitted group operations used by ordinary cell maintenance.
function __prepareDirect(rt,index,key,prior,next){
 const prepare=rt.views.directRoots?.[index];
 if(prepare)prepare(rt,key,prior,next);
 else for(const view of rt.viewsByRoot[index])rt.viewNext[view.keep]=__viewValue(view,rt.keeps[view.keep],key,prior,next);
}
function __storeDirect(rt,index,key,prior,next,slot){
 const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);
 if((prior!==undefined)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);
 if(rt.changeTracking)__recordChange(rt,index,key,prior,next);
 if(slot===undefined){if(next===undefined)table.delete(key);else table.set(key,next);}
 else{
  // The checked preflight lookup retains the dense slot until this commit.
  // No callback or source write can intervene; sparse keys retain exact identity.
  if(slot<0){if(next===undefined)table.sparse.delete(key);else table.sparse.set(key,next);}else table.dense[slot]=next;
  if(prior===undefined&&next!==undefined)table.members.add(key);else if(prior!==undefined&&next===undefined)table.members.delete(key);
 }
}
function __commitDirect(rt,index,key,prior,next,slot){
 __storeDirect(rt,index,key,prior,next,slot);
 const publishOutputs=rt.meta.outputPublication&&!rt.observers.directRoots[index]&&rt.observers.active;
 if(publishOutputs&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}

 for(const keep of rt.meta.keepInvalidations[index]){
  const value=rt.viewByKeep[keep]?rt.viewNext[keep]:undefined;
  if(publishOutputs)rt.changedOutputs[keep]=rt.keeps[keep]!==value?rt.changedOutputEpoch:0;
  rt.keeps[keep]=value;
 }
}
function __emit(rt,channel,value){
 if(rt.eventCount++===0){rt.eventChannel=channel;rt.eventValue=value;}
 else rt.staged.push([channel,value]);
}
// Checked prefix capacities are at most 2^20. Number conversion is exact
// inside that prefix; rounding a wide word cannot move it into the prefix.
// Wide keys retain their original full-width value in the sparse fallback.
class __DenseTable{
 constructor(capacity){this.limit=capacity;this.dense=[];for(let i=0;i<capacity;i++)this.dense.push(undefined);this.sparse=new Map();this.members=new Set();}
 clear(){this.dense.fill(undefined);this.sparse.clear();this.members.clear();__tableOrder.delete(this);return this;}
 slot(key){const i=Number(key);return Number.isInteger(i)&&i>=0&&i<this.limit?i:-1;}
 get size(){return this.members.size;}
 get(key){const i=this.slot(key);return i<0?this.sparse.get(key):this.dense[i];}
 has(key){return this.get(key)!==undefined;}
 set(key,value){const i=this.slot(key),present=i<0?this.sparse.has(key):this.dense[i]!==undefined;if(i<0)this.sparse.set(key,value);else this.dense[i]=value;if(!present)this.members.add(key);return this;}
 delete(key){const i=this.slot(key);if(i<0)this.sparse.delete(key);else this.dense[i]=undefined;return this.members.delete(key);}
 keys(){return this.members.keys();}
 *values(){for(const key of this.members)yield this.get(key);}
 *entries(){for(const key of this.members)yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
class __ColumnTable {
 constructor(root){
  this.limit=root.columnPrefix.capacity;this.keyBig=root.key.kind==='u64';
  this.fields=root.value.fields;this.exactNumbers=root.columnPrefix.exactNumbers;
  this.present=new Uint8Array(this.limit);this.count=0;this.sparse=new Map();
  this.lanes=this.fields.map(f=>f.type.kind==='u64'?(this.exactNumbers?new Float64Array(this.limit):new BigUint64Array(this.limit)):f.type.kind==='i32'?new Int32Array(this.limit):f.type.kind==='bool'?new Uint8Array(this.limit):new Uint32Array(this.limit));
  this.wide=this.fields.map(f=>f.type.kind==='u64'&&this.exactNumbers?new Map():null);
 }
 slot(key){const i=Number(key);return Number.isInteger(i)&&i>=0&&i<this.limit?i:-1;}
 get size(){return this.count+this.sparse.size;}
 has(key){const i=this.slot(key);return i<0?this.sparse.has(key):this.present[i]!==0;}
 get(key){const i=this.slot(key);if(i<0)return this.sparse.get(key);if(!this.present[i])return undefined;const row=Object.create(null);for(let j=0;j<this.fields.length;j++){const f=this.fields[j],v=this.lanes[j][i];row[f.name]=f.type.kind==='bool'?v!==0:f.type.kind==='u64'&&this.exactNumbers?(this.wide[j].get(i)??BigInt(v)):v;}return row;}
 set(key,row){const i=this.slot(key);if(i<0){this.sparse.set(key,row);return this;}for(let j=0;j<this.fields.length;j++){const f=this.fields[j],v=row[f.name];if(f.type.kind==='u64'&&this.exactNumbers){if(v<=9007199254740991n){this.lanes[j][i]=Number(v);this.wide[j].delete(i);}else{this.lanes[j][i]=0;this.wide[j].set(i,v);}}else this.lanes[j][i]=f.type.kind==='bool'?Number(v):v;}if(!this.present[i]){this.present[i]=1;this.count++;}return this;}
 delete(key){const i=this.slot(key);if(i<0)return this.sparse.delete(key);if(!this.present[i])return false;this.present[i]=0;this.count--;for(const wide of this.wide)wide?.delete(i);return true;}
 *keys(){for(let i=0;i<this.limit;i++)if(this.present[i])yield this.keyBig?BigInt(i):i;yield* this.sparse.keys();}
 *values(){for(const key of this.keys())yield this.get(key);}
 *entries(){for(const key of this.keys())yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
function __newTables(meta,prefixes,old,spares){return meta.roots.map((root,i)=>{const prior=spares?.[i];const t=root.columnPrefix?new __ColumnTable(root):prefixes[i]?(prior instanceof __DenseTable&&prior.limit===prefixes[i]?prior.clear():new __DenseTable(prefixes[i])):new Map();if(old)for(const [k,v]of old[i])t.set(k,v);return t;});}
// Only inactive containers are reused. Consume the spare before preparation so
// a failed invariant/rebuild cannot expose its partially reconstructed contents.
// Rows remain immutable; the current logical state changes only at installation.
function __restoreTables(rt,prefixes,old){const spares=rt.restoreSpares;rt.restoreSpares=null;return __newTables(rt.meta,prefixes,old,spares);}
function __cachedKeep(ctx,rt,index,compute){
 if(rt.cell&&rt.meta.keepInvalidations[rt.cell.index].includes(index)){
  const view=rt.viewByKeep[index];
  if(view)return __pendingView(rt,view);
  if(rt.pendingValues[index]===undefined){rt.pendingValues[index]=compute(ctx,rt);rt.pendingIndices.push(index);}
  return rt.pendingValues[index];
 }
 const prior=rt.keeps[index];if(prior!==undefined)return prior;
 const view=rt.viewByKeep[index];if(view)return __viewBase(rt,view);
 const value=compute(ctx,rt);rt.keeps[index]=value;return value;
}
function __tableContains(rt,index,key){return __cellGet(rt,index,key)!==undefined;}
function __tableGet(rt,index,key){const value=__cellGet(rt,index,key);return value===undefined?{None:null}:{Some:value};}
function __tablePut(rt,index,key,next,mode=0){
 const prior=rt.tables[index].get(key),present=prior!==undefined;
 if(mode===1&&present)throw Error('insert key already present');
 if(mode===2&&!present)throw Error('replace key absent');
 if(present&&__stateRootEquals[index](prior,next))return null;
 const updates=rt.cellMode?null:__updateViews(rt,index,key,prior,next);
 __invalidateKeeps(rt,index);__remember(rt,index,key,present,prior);
 __writeCell(rt,index,key,next,prior);__installViews(rt,updates,index);return null;
}
function __tableRemove(rt,index,key){
 const value=rt.tables[index].get(key);
 if(value===undefined)return {None:null};
 const updates=rt.cellMode?null:__updateViews(rt,index,key,value,undefined);
 __invalidateKeeps(rt,index);__remember(rt,index,key,true,value);
 __writeCell(rt,index,key,undefined,value);__installViews(rt,updates,index);return {Some:value};
}
function __table(rt,index,method,args){
 const key=args[0];
 if(method==='get')return __tableGet(rt,index,key);
 if(method==='contains')return __tableContains(rt,index,key);
 const table=rt.tables[index];
 if(method==='values'||method==='keys'){const keys=__orderedKeys(rt,index);return method==='keys'?keys.slice():keys.map(k=>__cellGet(rt,index,k));}
 if(method==='intersect_table'){const current=__readTable(rt,index),other=__readTable(rt,args[0]),small=current.size<=other.size?current:other,large=small===current?other:current;const result=[];for(const k of small.keys())if(large.has(k))result.push(k);return result.sort((a,b)=>__keyCompare(a,b,rt.meta.roots[index].key));}
 if(method==='intersect_keys'){const requested=args[0],size=rt.tables[index].size;
  // Fewer requested keys than rows: look each one up instead of scanning.
  if(requested.length<size){const type=rt.meta.roots[index].key;return [...new Set(requested)].filter(k=>__cellGet(rt,index,k)!==undefined).sort((a,b)=>__keyCompare(a,b,type));}
  const selected=new Set(requested);return __orderedKeys(rt,index).filter(k=>selected.has(k));}
 if(method==='put_many'){const keys=args[0],values=args[1];if(keys.length!==values.length)return {Err:'table bulk length mismatch'};for(let i=0;i<keys.length;i++)__table(rt,index,'put',[keys[i],values[i]]);return {Ok:null};}
 if(method==='remove_many'){for(const k of args[0])__table(rt,index,'remove',[k]);return null;}
 if(method==='remove')return __tableRemove(rt,index,key);
 return __tablePut(rt,index,key,args[1],method==='insert'?1:method==='replace'?2:0);
}

function __rollback(rt,mark){for(let i=rt.undo.length-1;i>=mark;i--){const [index,key,present,value]=rt.undo[i];const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);if(table.has(key)!==present)__tableMembership(rt,index,key,present);if(present)table.set(key,value);else table.delete(key);}rt.undo.length=mark;}
function __recordChange(rt,index,key,prior,next){rt.changeLog.push([index,key,prior,next]);}
function __fixedTableBytes(root,table){
 const writer=__snapshotWriter(__snapshotLimits());
 const rows=[...table.entries()].sort((a,b)=>__keyCompare(a[0],b[0],root.key));
 writer.integer(rows.length,8);
 for(const [key,value]of rows){writer.value(key,root.snapshotKey??root.key);writer.value(value,root.snapshotValue??root.value);}
 return writer.finish();
}
function __createState(meta,implementations,captures=null,views=[],prefixes=[]){
 const rt={meta,tables:__newTables(meta,prefixes),version:meta.compactCommits?0:0n,outbox:__eventLog(meta),staged:[],busy:false,undo:[],seen:meta.roots.map(()=>new Set()),host:null,keeps:new Array(meta.keeps.length),keepDirty:meta.keeps.length?new Uint8Array(meta.keeps.length):null,keepUndoIndices:meta.keeps.length?new Uint32Array(meta.keeps.length):null,keepUndoCount:0};
 const fixed=typeof __stateFrozenFactories==='undefined'?[]:__stateFrozenFactories;
 const fixedBytes=[];
 for(let i=0;i<fixed.length;i++)if(fixed[i]){for(const [key,value]of fixed[i]())rt.tables[i].set(key,value);fixedBytes[i]=__fixedTableBytes(meta.roots[i],rt.tables[i]);}
 function checkFixed(tables){for(let i=0;i<fixedBytes.length;i++)if(fixedBytes[i]){const bytes=__fixedTableBytes(meta.roots[i],tables[i]);if(bytes.length!==fixedBytes[i].length||!bytes.every((v,n)=>v===fixedBytes[i][n]))throw Error('snapshot changes frozen state: '+meta.roots[i].name);}}
 rt.views=views;rt.viewsByRoot=meta.roots.map((_,root)=>views.filter(v=>v.root===root));__rebuildViews(rt);
 rt.viewByKeep=new Array(meta.keeps.length);for(const view of views)rt.viewByKeep[view.keep]=view;
 rt.pendingIndices=[];rt.pendingValues=new Array(meta.keeps.length);
 rt.eventCount=0;rt.eventChannel=null;rt.eventValue=null;
 rt.viewNext=new Array(meta.keeps.length);rt.cell=null;rt.cellMode=false;rt.ctx={fuel:100000000};
 rt.keepBefore=meta.keeps.length?new Array(meta.keeps.length):null;
 rt.changedRoots=new Set();rt.changedOutputs=new Array(meta.keeps.length).fill(0);rt.changedOutputEpoch=0;
 rt.snapshotRows=meta.snapshotRows?meta.roots.map(()=>new Map()):null;
 rt.restoreSpares=null;rt.changeTracking=false;rt.changeLog=[];rt.changeEpoch=0;rt.changeTokens=new Map();
 const actionMap=new Map(meta.actions.map(a=>[a.name,{...a,inputs:captures?captures[a.index]:a.params.map(p=>__stateCapture(p.type)),output:__stateResult(a.result)}]));
 const eventOutput=new Map(meta.events.map(e=>[e.name,__stateResult(e.type)]));
 rt.eventOutput=eventOutput;
 const prepared=new WeakMap();
 const observers=rt.observers=__createObservers((name,args)=>{
  const a=actionMap.get(name);if(!a||a.change)throw Error('subscription requires a readonly query');
  const captured=a.inputs.map((convert,i)=>convert(args[i]));
  const publicArgs=captured.map((v,i)=>__stateResult(a.params[i].type)(v));
  const scalar=['u64','u32','i32','bool','string','unit','enum','id'].includes(a.result.kind);
  return {scalar,committed:scalar&&a.directKeep!==null&&a.directKeep!==undefined?{state:rt,keep:a.directKeep}:null,direct:scalar&&a.directKeep!==null&&a.directKeep!==undefined?()=>rt.keeps[a.directKeep]:null,roots:a.roots,outputs:rt.meta.outputPublication&&a.directKeep!==null&&a.directKeep!==undefined?[a.directKeep]:[],read:!a.precondition&&a.params.length===0?readZero(a,true):()=>run(a,publicArgs,null,null,true),capture:scalar?v=>v:__stateCapture(a.result),output:scalar?v=>v:a.output,equal:__stateQueryEquals[a.index]};
 });
 function invoke(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);return run(a,args);}
 function readZero(a,resultOnly){
  const implementation=implementations[a.index],output=a.output,fresh=a.freshResult;
  if(resultOnly&&fresh&&__stateDirectReadFactories[a.index])return __stateDirectReadFactories[a.index](rt);
  if(a.directKeep!==null&&a.directKeep!==undefined)return ()=>{
   if(rt.busy)throw Error('state operation already in progress');
   const value=rt.keeps[a.directKeep],result=fresh?value:output(value);
   return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};
  };
  return ()=>{
   if(rt.busy)throw Error('state operation already in progress');rt.busy=true;rt.ctx.fuel=100000000;
   try{const value=implementation(rt.ctx,rt),result=fresh?value:output(value);return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};}
   finally{rt.busy=false;}
  };
 }
 function read(a,args,inputs,output,resultOnly,owned=false){
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  rt.busy=true;
  try{const value=implementations[a.index](ctx,rt,...captured),result=a.freshResult?value:(output||a.output)(value);return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};}
  finally{rt.busy=false;}
 }
 function begin(a){
  if(rt.busy)throw Error('state operation already in progress');
  rt.ctx.fuel=100000000;
  rt.actionMark=rt.undo.length;rt.actionVersion=rt.version;rt.actionOutbox=rt.outbox;rt.actionOutboxLength=rt.outbox.length;rt.actionChangeMark=rt.changeLog.length;
  rt.busy=true;rt.cellMode=a.singleCell&&!rt.host;rt.staged.length=0;rt.eventCount=0;rt.changedRoots.clear();rt.actionSuccessful=false;
 }
 function complete(a,value,output,resultOnly){
  const result=a.freshResult?value:(output||a.output)(value);
  const version=rt.actionVersion;
  if(a.fallible && (a.flatFailure?value.tag!==0:Object.hasOwn(value,'Err'))){rt.changeLog.length=rt.actionChangeMark;__rollback(rt,rt.actionMark);__restoreKeeps(rt);if(rt.host?.strict)rt.host.failure=Object.assign(Error('transaction action failed'),{action:a.name,result});return resultOnly?result:{result,committed:false,version:__versionWord(version),events:[]};}
  if(version===18446744073709551615n)throw Error('commit sequence exhausted');
  const next=rt.meta.compactCommits?__nextCommit(version):version+1n;
  const publicNext=resultOnly?null:__versionWord(next);
  __prepareCell(rt);
  const events=resultOnly?null:new Array(rt.eventCount);
  if(rt.eventCount){
   const channel=rt.eventChannel,value=rt.eventValue;
   rt.outbox.push({commit:next,position:0n,channel,value});
   if(events)events[0]={commit:publicNext,position:0n,channel,value:eventOutput.get(channel)(value)};
   for(let i=0;i<rt.staged.length;i++){
    const [channel,value]=rt.staged[i],position=BigInt(i+1);
    rt.outbox.push({commit:next,position,channel,value});
    if(events)events[i+1]={commit:publicNext,position,channel,value:eventOutput.get(channel)(value)};
   }
  }
  __commitCell(rt);rt.version=next;rt.actionSuccessful=true;
  return resultOnly?result:{result,committed:true,version:publicNext,events};
 }
 function abort(e){
  rt.changeLog.length=rt.actionChangeMark;__rollback(rt,rt.actionMark);__restoreKeeps(rt);rt.version=rt.actionVersion;rt.outbox=rt.actionOutbox;rt.outbox.length=rt.actionOutboxLength;if(rt.host?.strict)rt.host.failure=e;throw e;
 }
 function end(){
  const successful=rt.actionSuccessful,single=rt.cellMode;
  rt.cell=null;rt.cellMode=false;rt.staged.length=0;rt.eventCount=0;rt.eventChannel=null;rt.eventValue=null;
  for(const keep of rt.pendingIndices)rt.pendingValues[keep]=undefined;rt.pendingIndices.length=0;
  if(!single){__clearKeepJournal(rt);for(const seen of rt.seen)seen.clear();if(!rt.host)rt.undo.length=0;}
  rt.actionOutbox=null;rt.busy=false;
  if(successful)observers.commit(rt.changedRoots);
 }
 function run(a,args,inputs=null,output=null,resultOnly=false,owned=false){
  if(a.kernels&&!rt.host){
   if(rt.busy)throw Error('state operation already in progress');
   const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
   return a.kernels[resultOnly?1:0](...captured);
  }
  if(!a.change)return read(a,args,inputs,output,resultOnly,owned);
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  begin(a);
  try{return complete(a,implementations[a.index](ctx,rt,...captured),output,resultOnly);}
  catch(e){return abort(e);}
  finally{end();}
 }

 for(const a of actionMap.values())if(__statePreflightFactories[a.index]){
  // run() supplies module-owned captured values; bound native entries still capture composites.
  a.kernels=[false,true].map(only=>__statePreflightFactories[a.index](run,a,a.inputs,a.output,only,rt,begin,complete,abort,end,true));
 }
 return Object.freeze({
  subscribeValues(queries,callback,options){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribeValues(queries,callback,options);},
  subscribeGroup(queries,callback,options){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribeGroup(queries,callback,options);},
  subscribe(...args){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribe(...args);},
  batch:observers.batch,flushSubscriptions:observers.flush,takeSubscriptionErrors:observers.takeErrors,
  transaction(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('transaction callback must be synchronous');this.beginTransaction();rt.host.strict=true;
   try{const value=callback(this);if(value&&typeof value.then==='function')throw TypeError('state transaction callback must be synchronous');this.commitTransaction();return value;}catch(e){this.rollbackTransaction();throw e;}
  },
  invoke,invoke_json:invoke,
  prepare(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);const captured=a.inputs.map((convert,i)=>convert(args[i])),token=Object.freeze({});prepared.set(token,{action:a,args:captured});return token;},
  invokePrepared(token){const packet=prepared.get(token);if(!packet)throw Error('invalid prepared state call');return run(packet.action,packet.args,null,null,false,true);},
  // A prebound typed entrypoint: scalar arguments obey the native caller contract.
  // Composite arguments still capture owned input; events remain in the outbox.
  bind(name,{resultOnly=false}={}){
   const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);
   const inputs=a.params.map((p,i)=>['u32','i32','u64','bool','unit','string','f32','f64','id','enum','int'].includes(p.type.kind)?__representation(p.type,false):a.inputs[i]);
   if(!a.change&&!a.precondition&&inputs.length===0)return readZero(a,resultOnly);
   return (__statePreflightFactories[a.index]||__stateBoundFactories[a.index])(run,a,inputs,a.output,resultOnly,rt,begin,complete,abort,end);
  },
  beginTransaction(){if(rt.busy||rt.host||rt.undo.length)throw Error('transaction already in progress');rt.host={version:rt.version,outbox:rt.outbox,length:rt.outbox.length,keeps:rt.keeps.slice(),changeMark:rt.changeLog.length,notificationMark:observers.hold()};return true;},
  commitTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');if(rt.host.failure)throw rt.host.failure;rt.host=null;rt.undo.length=0;observers.release();},
  rollbackTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');__rollback(rt,0);rt.version=rt.host.version;rt.outbox=rt.host.outbox;rt.outbox.length=rt.host.length;rt.keeps=rt.host.keeps;__refreshActiveViews(rt);rt.changeLog.length=rt.host.changeMark;rt.changeEpoch++;const mark=rt.host.notificationMark;rt.host=null;observers.rollback(mark);},
  changeToken(){
   if(rt.busy||rt.host)throw Error('change token requires transaction boundary');
   const token=Object.freeze({});rt.changeTracking=true;rt.changeTokens.set(token,{epoch:rt.changeEpoch,index:rt.changeLog.length,version:__versionWord(rt.version)});return token;
  },
  releaseChangeToken(token){rt.changeTokens.delete(token);if(!rt.changeTokens.size){rt.changeTracking=false;rt.changeLog.length=0;}},
  changesSince(token){
   if(rt.busy||rt.host)throw Error('changes require transaction boundary');
   const mark=rt.changeTokens.get(token);if(!mark||mark.epoch!==rt.changeEpoch)throw Error('invalid change token lineage');
   const roots=new Map();
   for(let i=mark.index;i<rt.changeLog.length;i++){
    const [root,key,before,after]=rt.changeLog[i];let cells=roots.get(root);if(!cells)roots.set(root,cells=new Map());
    const prior=cells.get(key);if(prior)prior.after=after;else cells.set(key,{before,after});
   }
   const changes=[];
   const codecs=rt.changeOutputs??=meta.roots.map(schema=>({key:__stateResult(schema.key),row:__stateResult(schema.value)}));
   for(const [root,cells]of roots){const schema=meta.roots[root],keyOut=codecs[root].key,rowOut=codecs[root].row;
    for(const [key,{before,after}]of cells){if(before===undefined&&after===undefined||before!==undefined&&after!==undefined&&__stateRootEquals[root](before,after))continue;
     changes.push({table:schema.name,key:keyOut(key),before:before===undefined?{None:null}:{Some:rowOut(before)},after:after===undefined?{None:null}:{Some:rowOut(after)}});
    }
   }
   return {from:mark.version,to:__versionWord(rt.version),changes};
  },
  get version(){return __versionWord(rt.version);},
  get outbox(){return rt.outbox.map(e=>({...e,commit:__versionWord(e.commit),value:eventOutput.get(e.channel)(e.value)}));},
  acknowledgeThrough(commit,position){if(rt.busy)throw Error('state operation already in progress');commit=__stateWord(commit);position=__stateWord(position);const last=rt.outbox.at(-1);if(!last)return;const lastCommit=__versionWord(last.commit);if(lastCommit<commit||(lastCommit===commit&&last.position<=position)){if(rt.host)rt.outbox=__eventLog(meta);else rt.outbox.length=0;return;}rt.outbox=rt.outbox.filter(e=>{const c=__versionWord(e.commit);return c>commit||(c===commit&&e.position>position);});},
  async invokeAsync(name,args){
   if(typeof __parallelInvokeAsync!=='function')return invoke(name,args);
   if(rt.busy||rt.host)throw Error('parallel state call requires transaction boundary');const captured=structuredClone(args);rt.busy=true;observers.hold();let completed=false;
   try{const snapshot=await __snapshotEncode(meta,rt);const reply=await __parallelInvokeAsync(name,captured,snapshot);const s=await __snapshotDecode(meta,reply.snapshot);checkFixed(s.tables);const candidate={...rt,tables:__restoreTables(rt,prefixes,s.tables),keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);const previousTables=rt.tables;rt.tables=candidate.tables;rt.restoreSpares=previousTables.map(table=>table instanceof __DenseTable?table:null);rt.version=__storedCommit(meta,s.version);rt.outbox=__eventLog(meta,s.outbox);rt.keeps=candidate.keeps;rt.activeViewRoots=candidate.activeViewRoots;if(rt.snapshotRows)rt.snapshotRows=meta.roots.map(()=>new Map());rt.changeEpoch++;rt.changeLog.length=0;completed=true;return reply.value;}finally{rt.busy=false;if(completed)observers.commit(meta.roots.map((_,i)=>i));observers.release();}
  },
  checkpoint(limits){if(rt.busy)throw Error('checkpoint requires transaction boundary');return __snapshotEncode(meta,rt,limits);},
  async restore(bytes,limits){if(rt.host)throw Error('restore during transaction');if(rt.busy)throw Error('restore requires transaction boundary');rt.busy=true;rt.ctx.fuel=100000000;observers.hold();let restored=false;try{const s=await __snapshotDecode(meta,bytes,limits);checkFixed(s.tables);const candidate={...rt,tables:__restoreTables(rt,prefixes,s.tables),version:__storedCommit(meta,s.version),outbox:s.outbox,keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);for(const name of meta.invariantChecks||[]){const a=actionMap.get(name);if(implementations[a.index](rt.ctx,candidate)!==true)throw Error('snapshot violates state invariant');}const previousTables=rt.tables;rt.tables=candidate.tables;rt.restoreSpares=previousTables.map(table=>table instanceof __DenseTable?table:null);rt.version=__storedCommit(meta,s.version);rt.outbox=__eventLog(meta,s.outbox);rt.keeps=candidate.keeps;rt.activeViewRoots=candidate.activeViewRoots;if(rt.snapshotRows)rt.snapshotRows=meta.roots.map(()=>new Map());rt.changeEpoch++;rt.changeLog.length=0;restored=true;}finally{rt.busy=false;if(restored)observers.commit(meta.roots.map((_,i)=>i));observers.release();}},
 });
}
function __action0(ctx,rt,s0,s1){__tick(ctx);try{__tick(ctx);__emit(rt,"installed",0);__tick(ctx);const s2=__try(__fn17(s0,s1,1000000));__tick(ctx);__tablePut(rt,0,0,({Some:s2}),0);__tick(ctx);return ({Ok:0});}catch(e){if(e instanceof __Abort)return ({Err:e.value});throw e;}}
function __action1(ctx,rt,s3){__tick(ctx);__tick(ctx);__tablePut(rt,1,0,s3,0);__tick(ctx);return 0;}
function __action2(ctx,rt,s4){__tick(ctx);try{__tick(ctx);return ((s5)=>Object.hasOwn(s5,"Some")?((s6)=>(__fn35(s6,((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,1,0),10.0),s4)))(s5["Some"]):((s7)=>(({Err:"no prepared paragraph"})))(null))(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),({None:null})));}catch(e){if(e instanceof __Abort)return ({Err:e.value});throw e;}}
function __stateCommitRoot0(rt,key,prior,next,slot){__storeDirect(rt,0,key,prior,next,slot);const publish=rt.meta.outputPublication&&!rt.observers.directRoots[0]&&rt.observers.active;if(publish&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}}
function __stateCommitRoot1(rt,key,prior,next,slot){__storeDirect(rt,1,key,prior,next,slot);const publish=rt.meta.outputPublication&&!rt.observers.directRoots[1]&&rt.observers.active;if(publish&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}}
const __stateDirectReadFactories=[null,null,null];
function __stateValueEqual3(a,b){if(a===b)return true;if(a.length!==b.length)return false;for(let i=0;i<a.length;i++)if(!((__dfBits(a[i])===__dfBits(b[i]))))return false;return true;}
function __stateValueEqual4(a,b){if(a===b)return true;if(a.length!==b.length)return false;for(let i=0;i<a.length;i++)if(!((a[i]===b[i])))return false;return true;}
function __stateValueEqual5(a,b){if(a===b)return true;if(a.length!==b.length)return false;for(let i=0;i<a.length;i++)if(!(__stateValueEqual6(a[i],b[i])))return false;return true;}
function __stateValueEqual2(a,b){if(a===b)return true;return __stateValueEqual3(a["widths"],b["widths"])&&__stateValueEqual4(a["flags"],b["flags"])&&__stateValueEqual5(a["advances"],b["advances"])&&__stateValueEqual6(a["startExtras"],b["startExtras"])&&__stateValueEqual7(a["graphemeStartExtras"],b["graphemeStartExtras"])&&__stateValueEqual6(a["endTrims"],b["endTrims"])&&__stateValueEqual6(a["overflowTrims"],b["overflowTrims"])&&__stateValueEqual6(a["insideExtras"],b["insideExtras"])&&__stateValueEqual6(a["fillExtras"],b["fillExtras"]);}
function __stateValueEqual1(a,b){if(a===b)return true;return __stateValueEqual2(a["data"],b["data"])&&(__dfBits(a["epsilon"])===__dfBits(b["epsilon"]))&&(a["budget"]===b["budget"]);}
function __stateValueEqual10(a,b){if(a===b)return true;return (a["lineCount"]===b["lineCount"])&&(__dfBits(a["height"])===__dfBits(b["height"]));}
function __stateValueEqual6(a,b){if(a===b)return true;const x=Object.hasOwn(a,'Some');return x===Object.hasOwn(b,'Some')&&(!x||__stateValueEqual3(a.Some,b.Some));}
function __stateValueEqual7(a,b){if(a===b)return true;const x=Object.hasOwn(a,'Some');return x===Object.hasOwn(b,'Some')&&(!x||__stateValueEqual5(a.Some,b.Some));}
function __stateValueEqual0(a,b){if(a===b)return true;const x=Object.hasOwn(a,'Some');return x===Object.hasOwn(b,'Some')&&(!x||__stateValueEqual1(a.Some,b.Some));}
function __stateValueEqual8(a,b){if(a===b)return true;const xv=a,yv=b,x=Object.hasOwn(xv,'Ok');return x===Object.hasOwn(yv,'Ok')&&(x?(xv.Ok===yv.Ok):(xv.Err===yv.Err));}
function __stateValueEqual9(a,b){if(a===b)return true;const xv=a,yv=b,x=Object.hasOwn(xv,'Ok');return x===Object.hasOwn(yv,'Ok')&&(x?__stateValueEqual10(xv.Ok,yv.Ok):(xv.Err===yv.Err));}
function __ownedInput7(value,budget={cells:1000000},depth=0,maxDepth=64){if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(!value||typeof value!=='object'||Array.isArray(value))throw Error('invalid Option');const keys=Object.keys(value);if(keys.length!==1)throw Error('invalid Option');const tag=keys[0];if(tag==='Some')return ({Some:__ownedInput5(value.Some,budget,depth+1,maxDepth)});if(tag==='None'&&value.None===null)return {None:null};throw Error('invalid Option');}
function __ownedInput5(value,budget={cells:1000000},depth=0,maxDepth=64){if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=__ownedInput6(value[i],budget,depth+1,maxDepth);return out;}
function __ownedInput6(value,budget={cells:1000000},depth=0,maxDepth=64){if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(!value||typeof value!=='object'||Array.isArray(value))throw Error('invalid Option');const keys=Object.keys(value);if(keys.length!==1)throw Error('invalid Option');const tag=keys[0];if(tag==='Some')return ({Some:__ownedInput1(value.Some,budget,depth+1,maxDepth)});if(tag==='None'&&value.None===null)return {None:null};throw Error('invalid Option');}
function __ownedInput1(value,budget={cells:1000000},depth=0,maxDepth=64){if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=__ownedInput2(value[i],budget,depth+1,maxDepth);return out;}
function __ownedInput3(value,budget={cells:1000000},depth=0,maxDepth=64){if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=__ownedInput4(value[i],budget,depth+1,maxDepth);return out;}
function __ownedInput0(value,budget={cells:1000000},depth=0,maxDepth=64){if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,"widths")||!Object.hasOwn(value,"flags")||!Object.hasOwn(value,"advances")||!Object.hasOwn(value,"startExtras")||!Object.hasOwn(value,"graphemeStartExtras")||!Object.hasOwn(value,"endTrims")||!Object.hasOwn(value,"overflowTrims")||!Object.hasOwn(value,"insideExtras")||!Object.hasOwn(value,"fillExtras"))throw Error('invalid record');const field0=__ownedInput1(value["widths"],budget,depth+1,maxDepth);const field1=__ownedInput3(value["flags"],budget,depth+1,maxDepth);const field2=__ownedInput5(value["advances"],budget,depth+1,maxDepth);const field3=__ownedInput6(value["startExtras"],budget,depth+1,maxDepth);const field4=__ownedInput7(value["graphemeStartExtras"],budget,depth+1,maxDepth);const field5=__ownedInput6(value["endTrims"],budget,depth+1,maxDepth);const field6=__ownedInput6(value["overflowTrims"],budget,depth+1,maxDepth);const field7=__ownedInput6(value["insideExtras"],budget,depth+1,maxDepth);const field8=__ownedInput6(value["fillExtras"],budget,depth+1,maxDepth);return {["widths"]:field0,["flags"]:field1,["advances"]:field2,["startExtras"]:field3,["graphemeStartExtras"]:field4,["endTrims"]:field5,["overflowTrims"]:field6,["insideExtras"]:field7,["fillExtras"]:field8};}
const __ownedType2={"kind":"f64"};
function __ownedInput2(value,budget={cells:1000000},depth=0,maxDepth=64){return __stateInput(value,__ownedType2,budget,depth,maxDepth);}
function __ownedInput4(value,budget={cells:1000000},depth=0,maxDepth=64){let scalar=value;if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(typeof scalar!=='number'||!Number.isInteger(scalar)||scalar<0||scalar>4294967295)throw Error('invalid u32');if(scalar===0)scalar=0;return scalar;}
const __stateFrozenFactories=[];
const __stateQueryEquals=[(a,b)=>__stateValueEqual8(a,b),(a,b)=>(a===b),(a,b)=>__stateValueEqual9(a,b)];
const __stateRootEquals=[(a,b)=>__stateValueEqual0(a,b),(a,b)=>(__dfBits(a)===__dfBits(b))];
const __stateBoundFactories=[(run,a,inputs,output,only,rt,begin,complete,abort,end)=>a.precondition?(p0,p1)=>run(a,[inputs[0](p0),inputs[1](p1)],null,output,only,true):(p0,p1)=>{const b0=inputs[0](p0);const b1=inputs[1](p1);begin(a);try{return complete(a,__action0(rt.ctx,rt,b0,b1),output,only);}catch(e){return abort(e);}finally{end();}},(run,a,inputs,output,only,rt,begin,complete,abort,end)=>a.precondition?(p0)=>run(a,[inputs[0](p0)],null,output,only,true):(p0)=>{const b0=inputs[0](p0);begin(a);try{return complete(a,__action1(rt.ctx,rt,b0),output,only);}catch(e){return abort(e);}finally{end();}},(run,a,inputs,output,only)=>(p0)=>run(a,[inputs[0](p0)],null,output,only,true)];const __statePreflightFactories=[null,null,null];
const __stateMetadata={"actions":[{"change":true,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":true,"index":0,"name":"install","params":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"u32"}},"roots":[0],"singleCell":true},{"change":true,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":true,"index":1,"name":"resize","params":[{"name":"width","type":{"kind":"f64"}}],"precondition":null,"result":{"kind":"u32"},"roots":[1],"singleCell":true},{"change":false,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":false,"index":2,"name":"current","params":[{"name":"lineHeight","type":{"kind":"f64"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"height","type":{"kind":"f64"}}],"kind":"record","name":"ink_mf31874390da54b3c180b48032618b677f5ca389c9ffcfc54ae469de235e84bcb"}},"roots":[0,1],"singleCell":true}],"compactCommits":false,"eventColumns":false,"eventRuns":false,"events":[{"name":"installed","snapshotType":{"kind":"u32"},"type":{"kind":"u32"}}],"invariantChecks":[],"keepInvalidations":[[],[]],"keeps":[],"lazyMaintenance":true,"outputPublication":false,"roots":[{"key":{"kind":"u32"},"name":"Paragraph","snapshotKey":{"kind":"u32"},"snapshotValue":{"element":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record"},"kind":"option"},"value":{"element":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"},"kind":"option"}},{"key":{"kind":"u32"},"name":"Width","snapshotKey":{"kind":"u32"},"snapshotValue":{"kind":"f64"},"value":{"kind":"f64"}}],"snapshot":{"program":[117,17,76,231,100,26,241,116,235,41,28,220,59,24,3,156,235,143,34,131,31,83,159,198,161,157,84,148,85,142,116,99],"schema":[174,196,15,59,118,237,34,176,230,248,58,202,96,96,202,43,16,250,136,142,115,137,237,184,160,94,204,51,114,124,32,47]},"snapshotRows":false};const __actions=[__action0,__action1,__action2];const __stateInputCaptures=[[__ownedInput0,__ownedInput2],[__ownedInput2],[__ownedInput2]];
export function createState(){return __createState(__stateMetadata,__actions,__stateInputCaptures);}
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v15","core_sha256":"02416168b8726d91f7597110730e4dc1736b8709a6e1cf44bd7b74000999e30d","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"f32_storage":"exact-u32-bits","functions":[{"destination":null,"index":0,"internal":false,"name":"prepare","parallel":false,"params":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"maximum","type":{"kind":"u32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}}},{"destination":null,"index":1,"internal":false,"name":"count_lines","parallel":false,"params":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"width","type":{"kind":"f64"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"u32"}}},{"destination":null,"index":2,"internal":false,"name":"lines","parallel":false,"params":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"width","type":{"kind":"f64"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"fields":[{"name":"width","type":{"kind":"f64"}},{"name":"start","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"kind":"record","name":"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993"},"kind":"list"}}},{"destination":null,"index":3,"internal":false,"name":"stats","parallel":false,"params":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"width","type":{"kind":"f64"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}}},{"destination":null,"index":4,"internal":false,"name":"layout","parallel":false,"params":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"width","type":{"kind":"f64"}},{"name":"lineHeight","type":{"kind":"f64"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"height","type":{"kind":"f64"}}],"kind":"record","name":"ink_mf31874390da54b3c180b48032618b677f5ca389c9ffcfc54ae469de235e84bcb"}}},{"destination":null,"index":5,"internal":false,"name":"line","parallel":false,"params":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"width","type":{"kind":"f64"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"fields":[{"name":"width","type":{"kind":"f64"}},{"name":"start","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"kind":"record","name":"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993"},"kind":"option"}}},{"destination":null,"index":6,"internal":false,"name":"count_prepared","parallel":false,"params":[{"name":"prepared","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"u32"}}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":7,"internal":false,"name":"numeric","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":8,"internal":false,"name":"ink_maa2ffc47f94a1df1e2b1982bb687b3b95ea1f18c3d31e5270249eb9a5b1b8987","parallel":false,"params":[{"name":"xs","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"i","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"f64"}},{"destination":null,"index":9,"internal":false,"name":"ink_m1cbd9e6f220b01cc6d3614d0b500ae6ae7fb6bc6b3ccb0fd24ba416e435dec02","parallel":false,"params":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"i","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"destination":null,"index":10,"internal":false,"name":"ink_ma9923eba3cdcc3be4bd5eec9937c55f89cb7af34eade1f02c02bde46b444755d","parallel":false,"params":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"i","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"u32"}},{"destination":null,"index":11,"internal":false,"name":"ink_mf2da1ccb63323de619308b515afc2e8427fa422cacc3b9e180896d7c1933a5db","parallel":false,"params":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"i","type":{"kind":"u32"}},{"name":"atStart","type":{"kind":"bool"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":null,"index":12,"internal":false,"name":"ink_mf3fd6a8edcedf12678ee0135d258e53818da29f98901e4823c5b5fa68a8742b5","parallel":false,"params":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"i","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":null,"index":13,"internal":false,"name":"ink_m4871d371876b879fe17454f848676f99047b70dcf533553abf657eccb48917a5","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"f64"},"kind":"list"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":null,"index":14,"internal":false,"name":"ink_m3e5801892156affa301b1de70c5499a6f98c8ab08ce4a11d6064687eaff81e63","parallel":false,"params":[{"name":"xs","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"n","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":null,"index":15,"internal":false,"name":"ink_m1035a47a3beb1fd15b77187a225faf4374da04d4239c2bb5f2fd7f377c9105f8","parallel":false,"params":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"advance","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"s","type":{"fields":[{"name":"valid","type":{"kind":"bool"}},{"name":"budget","type":{"kind":"u32"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"ink_m233b63cde5b1951078531833cb439d88de244d40e3a6392d35d12e48ecb2ef5d"}}],"precondition":null,"result":{"fields":[{"name":"valid","type":{"kind":"bool"}},{"name":"budget","type":{"kind":"u32"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"ink_m233b63cde5b1951078531833cb439d88de244d40e3a6392d35d12e48ecb2ef5d"}},{"destination":null,"index":16,"internal":false,"name":"ink_mb4277fe25fdfb0e134f990b04d6baa626119984e30cca8da242f327fd2871a58","parallel":false,"params":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"maximum","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"kind":"u32"},"kind":"option"}},{"destination":null,"index":17,"internal":false,"name":"ink_mc1df4b06d386435afd93c2deb158f576ca1a0b8da5cc9ddac9804cbbd5aaed55","parallel":false,"params":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"maximum","type":{"kind":"u32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}}},{"destination":null,"index":18,"internal":false,"name":"ink_md45fb160f95b90ffa06f2e883a8e13e6cfb6f48c9e504c758674212aaaafed13","parallel":false,"params":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":null,"index":19,"internal":false,"name":"ink_m79fbd33ce445d81b5495367bea54ed582eb29a97df1560f52a1db7c4538eabd4","parallel":false,"params":[{"name":"width","type":{"kind":"f64"}}],"precondition":null,"result":{"kind":"f64"}},{"destination":null,"index":20,"internal":false,"name":"ink_m403c4c47e84eda8d792b1109de53fbbc655e214636da67f4e0bec47ffe157b0e","parallel":false,"params":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}}],"precondition":null,"result":{"kind":"f64"}},{"destination":null,"index":21,"internal":false,"name":"ink_m693a1ebd0432f205eabdd53caaf1bb1ac592d434476d44639419d5b63ab48e45","parallel":false,"params":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"c","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"precondition":null,"result":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"destination":null,"index":22,"internal":false,"name":"ink_m746b7ebe9bcb715eb063c9a8acdc48ed10dd67c3ac1ab355ca08a8a31f2e076a","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"start","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"fit","type":{"kind":"f64"}}],"precondition":null,"result":{"fields":[{"name":"index","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m7b062ce6e1c2efcea6de69b7c533325db5ea045c74268a2b5acae500b6575dfc"}},{"destination":null,"index":23,"internal":false,"name":"ink_m424a73c98abd59df2df2e9558114156f29b349d1a0fc567d6a7b6991fa96d4e4","parallel":false,"params":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"fit","type":{"kind":"f64"}},{"name":"s","type":{"fields":[{"name":"index","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"trimmed","type":{"kind":"f64"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"result","type":{"kind":"f64"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m2009348d597e6b76dc210821f6f99bb8afebe7919b4fe0a09c17b3f9ac4793c3"}}],"precondition":null,"result":{"fields":[{"name":"index","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"trimmed","type":{"kind":"f64"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"result","type":{"kind":"f64"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m2009348d597e6b76dc210821f6f99bb8afebe7919b4fe0a09c17b3f9ac4793c3"}},{"destination":null,"index":24,"internal":false,"name":"ink_m0fffc1496f6a8b2b8d7044034bab3436a5bf8d98c9b26163ffc110ef18eb690f","parallel":false,"params":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"c","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"width","type":{"kind":"f64"}}],"precondition":null,"result":{"fields":[{"name":"width","type":{"kind":"f64"}},{"name":"start","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"kind":"record","name":"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993"}},{"destination":null,"index":25,"internal":false,"name":"ink_m3ec56d96554edff8dcbc70dd4746c1467d14cccdd680a05225aecdcb1ff10585","parallel":false,"params":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"c","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"width","type":{"kind":"f64"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"fields":[{"name":"width","type":{"kind":"f64"}},{"name":"start","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"kind":"record","name":"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993"},"kind":"option"}}},{"destination":null,"index":26,"internal":false,"name":"ink_m031320cee58f85b79b37202fff6fd536ad71ab758d2d465493cd48cefb302021","parallel":false,"params":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}},{"name":"w","type":{"fields":[{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"stats","type":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m086abde96a678051961f464f791c4c5c94b31f286fb29436e88cbebcf9b5ad1c"}}],"precondition":null,"result":{"fields":[{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"stats","type":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m086abde96a678051961f464f791c4c5c94b31f286fb29436e88cbebcf9b5ad1c"}},{"destination":null,"index":27,"internal":false,"name":"ink_m618e3b1ce3d206a7ce99ecd61dc5909f8327679e73d0e9cd3a60a1c006ce85b8","parallel":false,"params":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}}],"precondition":null,"result":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}},{"destination":null,"index":28,"internal":false,"name":"ink_me3e1d6802e8b8c99257eae2c70e1c73b81194a7b49cd49c1aadcbcf5fb61a373","parallel":false,"params":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}}},{"destination":null,"index":29,"internal":true,"name":"ink_mb3166db2bf18ab05ba193c347c860e3c609f09da430fd77ac9981409ba2efcef","parallel":false,"params":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}},{"name":"w","type":{"fields":[{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"lines","type":{"kind":"temporary"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_mb57c7f78770196118eeb183601122638651b9dc2e5e5132e7d0d790985b01684"}}],"precondition":null,"result":{"fields":[{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"lines","type":{"kind":"temporary"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_mb57c7f78770196118eeb183601122638651b9dc2e5e5132e7d0d790985b01684"}},{"destination":null,"index":30,"internal":false,"name":"ink_m1c643c3729ce33889b175f6534c6f5567e1031f9a2294b31f14214ef5d846f7e","parallel":false,"params":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"fields":[{"name":"width","type":{"kind":"f64"}},{"name":"start","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"kind":"record","name":"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993"},"kind":"list"}}},{"destination":null,"index":31,"internal":false,"name":"ink_m61a3849a7a6ebf0fe028d8fa87a1a3eaa6166a2532387000b50e461faa1b2899","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"start","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"fit","type":{"kind":"f64"}}],"precondition":null,"result":{"fields":[{"name":"index","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m7b062ce6e1c2efcea6de69b7c533325db5ea045c74268a2b5acae500b6575dfc"}},{"destination":null,"index":32,"internal":false,"name":"ink_m09bd2f6d807dddea08a3e05dff926c97158dd5c78fbcec8971733d58e03c9fbf","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"es","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fit","type":{"kind":"f64"}},{"name":"s","type":{"fields":[{"name":"count","type":{"fields":[{"name":"lines","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"content","type":{"kind":"bool"}}],"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"ink_me68c2f5e5e86a516faa862d519cff9a3e02bc5e131745a9c88827226a0059c6a"}}],"precondition":null,"result":{"fields":[{"name":"count","type":{"fields":[{"name":"lines","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"content","type":{"kind":"bool"}}],"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"ink_me68c2f5e5e86a516faa862d519cff9a3e02bc5e131745a9c88827226a0059c6a"}},{"destination":null,"index":33,"internal":false,"name":"ink_mdb420bacbaded3bd4a47c64a08eab41bd49e5a1eb00a06f5fb4216055764e14f","parallel":false,"params":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"fit","type":{"kind":"f64"}},{"name":"i","type":{"kind":"u32"}},{"name":"s","type":{"fields":[{"name":"lines","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"content","type":{"kind":"bool"}}],"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"}}],"precondition":null,"result":{"fields":[{"name":"lines","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"content","type":{"kind":"bool"}}],"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"}},{"destination":null,"index":34,"internal":false,"name":"ink_m5a18484940b2f87721d94e036b20f3f623fd9a7ef0bbb105d497073a418c96f6","parallel":false,"params":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"u32"}}},{"destination":null,"index":35,"internal":false,"name":"ink_mf92f9e487553a051acda291cdf01e6ab1ad3a5254dd3d94587ad2b797d8dea28","parallel":false,"params":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}},{"name":"lineHeight","type":{"kind":"f64"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"height","type":{"kind":"f64"}}],"kind":"record","name":"ink_mf31874390da54b3c180b48032618b677f5ca389c9ffcfc54ae469de235e84bcb"}}}],"named_types":{"ink_m086abde96a678051961f464f791c4c5c94b31f286fb29436e88cbebcf9b5ad1c":{"fields":[{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"stats","type":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m086abde96a678051961f464f791c4c5c94b31f286fb29436e88cbebcf9b5ad1c"},"ink_m2009348d597e6b76dc210821f6f99bb8afebe7919b4fe0a09c17b3f9ac4793c3":{"fields":[{"name":"index","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"trimmed","type":{"kind":"f64"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"result","type":{"kind":"f64"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m2009348d597e6b76dc210821f6f99bb8afebe7919b4fe0a09c17b3f9ac4793c3"},"ink_m233b63cde5b1951078531833cb439d88de244d40e3a6392d35d12e48ecb2ef5d":{"fields":[{"name":"valid","type":{"kind":"bool"}},{"name":"budget","type":{"kind":"u32"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"ink_m233b63cde5b1951078531833cb439d88de244d40e3a6392d35d12e48ecb2ef5d"},"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"},"ink_m38199727c3368a931db73c0ac28f57f806019aaf5325d854f5e146190d590ba5":{"fields":[{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m38199727c3368a931db73c0ac28f57f806019aaf5325d854f5e146190d590ba5"},"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},"ink_m7b062ce6e1c2efcea6de69b7c533325db5ea045c74268a2b5acae500b6575dfc":{"fields":[{"name":"index","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m7b062ce6e1c2efcea6de69b7c533325db5ea045c74268a2b5acae500b6575dfc"},"ink_mb57c7f78770196118eeb183601122638651b9dc2e5e5132e7d0d790985b01684":{"fields":[{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"lines","type":{"kind":"temporary"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_mb57c7f78770196118eeb183601122638651b9dc2e5e5132e7d0d790985b01684"},"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993":{"fields":[{"name":"width","type":{"kind":"f64"}},{"name":"start","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"kind":"record","name":"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993"},"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"},"ink_me68c2f5e5e86a516faa862d519cff9a3e02bc5e131745a9c88827226a0059c6a":{"fields":[{"name":"count","type":{"fields":[{"name":"lines","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"content","type":{"kind":"bool"}}],"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"ink_me68c2f5e5e86a516faa862d519cff9a3e02bc5e131745a9c88827226a0059c6a"},"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"},"ink_mf31874390da54b3c180b48032618b677f5ca389c9ffcfc54ae469de235e84bcb":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"height","type":{"kind":"f64"}}],"kind":"record","name":"ink_mf31874390da54b3c180b48032618b677f5ca389c9ffcfc54ae469de235e84bcb"},"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844":{"fields":[{"name":"lines","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"content","type":{"kind":"bool"}}],"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"}},"prepared_compiled":{"evaluation":"lazy source-order; successful bindings only","functions":[{"delegated_calls":1,"factory":true,"function":"prepare","retained_bindings":0},{"delegated_calls":2,"factory":true,"function":"count_lines","retained_bindings":0},{"delegated_calls":2,"factory":true,"function":"lines","retained_bindings":0},{"delegated_calls":2,"factory":true,"function":"stats","retained_bindings":0},{"delegated_calls":2,"factory":true,"function":"layout","retained_bindings":0},{"delegated_calls":2,"factory":true,"function":"line","retained_bindings":0},{"delegated_calls":1,"factory":true,"function":"count_prepared","retained_bindings":0},{"factory":false,"function":"numeric","reason":"no reusable captured work"},{"factory":false,"function":"ink_maa2ffc47f94a1df1e2b1982bb687b3b95ea1f18c3d31e5270249eb9a5b1b8987","reason":"no reusable captured work"},{"factory":false,"function":"ink_m1cbd9e6f220b01cc6d3614d0b500ae6ae7fb6bc6b3ccb0fd24ba416e435dec02","reason":"no reusable captured work"},{"factory":false,"function":"ink_ma9923eba3cdcc3be4bd5eec9937c55f89cb7af34eade1f02c02bde46b444755d","reason":"no reusable captured work"},{"factory":false,"function":"ink_mf2da1ccb63323de619308b515afc2e8427fa422cacc3b9e180896d7c1933a5db","reason":"no reusable captured work"},{"factory":false,"function":"ink_mf3fd6a8edcedf12678ee0135d258e53818da29f98901e4823c5b5fa68a8742b5","reason":"no reusable captured work"},{"factory":false,"function":"ink_m4871d371876b879fe17454f848676f99047b70dcf533553abf657eccb48917a5","reason":"no reusable captured work"},{"factory":false,"function":"ink_m3e5801892156affa301b1de70c5499a6f98c8ab08ce4a11d6064687eaff81e63","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"ink_m1035a47a3beb1fd15b77187a225faf4374da04d4239c2bb5f2fd7f377c9105f8","retained_bindings":1},{"delegated_calls":0,"factory":true,"function":"ink_mb4277fe25fdfb0e134f990b04d6baa626119984e30cca8da242f327fd2871a58","retained_bindings":3},{"delegated_calls":1,"factory":true,"function":"ink_mc1df4b06d386435afd93c2deb158f576ca1a0b8da5cc9ddac9804cbbd5aaed55","retained_bindings":0},{"delegated_calls":1,"factory":true,"function":"ink_md45fb160f95b90ffa06f2e883a8e13e6cfb6f48c9e504c758674212aaaafed13","retained_bindings":0},{"factory":false,"function":"ink_m79fbd33ce445d81b5495367bea54ed582eb29a97df1560f52a1db7c4538eabd4","reason":"no reusable captured work"},{"factory":false,"function":"ink_m403c4c47e84eda8d792b1109de53fbbc655e214636da67f4e0bec47ffe157b0e","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"ink_m693a1ebd0432f205eabdd53caaf1bb1ac592d434476d44639419d5b63ab48e45","retained_bindings":1},{"factory":false,"function":"ink_m746b7ebe9bcb715eb063c9a8acdc48ed10dd67c3ac1ab355ca08a8a31f2e076a","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"ink_m424a73c98abd59df2df2e9558114156f29b349d1a0fc567d6a7b6991fa96d4e4","retained_bindings":2},{"delegated_calls":0,"factory":true,"function":"ink_m0fffc1496f6a8b2b8d7044034bab3436a5bf8d98c9b26163ffc110ef18eb690f","retained_bindings":3},{"delegated_calls":4,"factory":true,"function":"ink_m3ec56d96554edff8dcbc70dd4746c1467d14cccdd680a05225aecdcb1ff10585","retained_bindings":3},{"delegated_calls":2,"factory":true,"function":"ink_m031320cee58f85b79b37202fff6fd536ad71ab758d2d465493cd48cefb302021","retained_bindings":2},{"delegated_calls":0,"factory":true,"function":"ink_m618e3b1ce3d206a7ce99ecd61dc5909f8327679e73d0e9cd3a60a1c006ce85b8","retained_bindings":1},{"delegated_calls":3,"factory":true,"function":"ink_me3e1d6802e8b8c99257eae2c70e1c73b81194a7b49cd49c1aadcbcf5fb61a373","retained_bindings":1},{"factory":false,"function":"ink_mb3166db2bf18ab05ba193c347c860e3c609f09da430fd77ac9981409ba2efcef","reason":"prepared residual requires a bounded pure value entry"},{"delegated_calls":2,"factory":true,"function":"ink_m1c643c3729ce33889b175f6534c6f5567e1031f9a2294b31f14214ef5d846f7e","retained_bindings":1},{"factory":false,"function":"ink_m61a3849a7a6ebf0fe028d8fa87a1a3eaa6166a2532387000b50e461faa1b2899","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"ink_m09bd2f6d807dddea08a3e05dff926c97158dd5c78fbcec8971733d58e03c9fbf","retained_bindings":1},{"delegated_calls":0,"factory":true,"function":"ink_mdb420bacbaded3bd4a47c64a08eab41bd49e5a1eb00a06f5fb4216055764e14f","retained_bindings":1},{"delegated_calls":3,"factory":true,"function":"ink_m5a18484940b2f87721d94e036b20f3f623fd9a7ef0bbb105d497073a418c96f6","retained_bindings":2},{"delegated_calls":1,"factory":true,"function":"ink_mf92f9e487553a051acda291cdf01e6ab1ad3a5254dd3d94587ad2b797d8dea28","retained_bindings":0}],"lifetime":"prepared token","semantics":"sealed-value-residual-v1"},"private_record_elisions":[],"private_sum_spines":[],"schema":1,"state":{"actions":[{"change":true,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":true,"index":0,"name":"install","params":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"u32"}},"roots":[0],"singleCell":true},{"change":true,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":true,"index":1,"name":"resize","params":[{"name":"width","type":{"kind":"f64"}}],"precondition":null,"result":{"kind":"u32"},"roots":[1],"singleCell":true},{"change":false,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":false,"index":2,"name":"current","params":[{"name":"lineHeight","type":{"kind":"f64"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"height","type":{"kind":"f64"}}],"kind":"record","name":"ink_mf31874390da54b3c180b48032618b677f5ca389c9ffcfc54ae469de235e84bcb"}},"roots":[0,1],"singleCell":true}],"compactCommits":false,"eventColumns":false,"eventRuns":false,"events":[{"name":"installed","snapshotType":{"kind":"u32"},"type":{"kind":"u32"}}],"invariantChecks":[],"keepInvalidations":[[],[]],"keeps":[],"lazyMaintenance":true,"outputPublication":false,"roots":[{"key":{"kind":"u32"},"name":"Paragraph","snapshotKey":{"kind":"u32"},"snapshotValue":{"element":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record"},"kind":"option"},"value":{"element":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"},"kind":"option"}},{"key":{"kind":"u32"},"name":"Width","snapshotKey":{"kind":"u32"},"snapshotValue":{"kind":"f64"},"value":{"kind":"f64"}}],"snapshot":{"program":[117,17,76,231,100,26,241,116,235,41,28,220,59,24,3,156,235,143,34,131,31,83,159,198,161,157,84,148,85,142,116,99],"schema":[174,196,15,59,118,237,34,176,230,248,58,202,96,96,202,43,16,250,136,142,115,137,237,184,160,94,204,51,114,124,32,47]},"snapshotRows":false},"wire":{"format":"ink-value-wire-v1","functions":{"count_lines":{"arguments":{"format":"ink-value-wire-v1","identity":"0d9813fafc11c1ce57d687b8f597a62e1278f03c1d61330d83c27c5625c3aa7f","named":{},"root":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"width","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"521eaeae4d030f71891ee322304be19877dd3df45f375257b9b99b896efe3237","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"u32"}}}},"count_prepared":{"arguments":{"format":"ink-value-wire-v1","identity":"493c6bc7ec48e92144981aed28fb206d98786334ac3f03d4170e2313dd50cc06","named":{},"root":{"fields":[{"name":"prepared","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"521eaeae4d030f71891ee322304be19877dd3df45f375257b9b99b896efe3237","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"u32"}}}},"ink_m031320cee58f85b79b37202fff6fd536ad71ab758d2d465493cd48cefb302021":{"arguments":{"format":"ink-value-wire-v1","identity":"d2e058847ec884bfec22ccda23ace2791ec70492243ce9a2c6884fef1f0ff622","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}},{"name":"w","type":{"fields":[{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"stats","type":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m086abde96a678051961f464f791c4c5c94b31f286fb29436e88cbebcf9b5ad1c"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"95f1d165952114b4814841922105b86c623e8c07746843b06ad383444f2fa3eb","named":{},"root":{"fields":[{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"stats","type":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m086abde96a678051961f464f791c4c5c94b31f286fb29436e88cbebcf9b5ad1c"}}},"ink_m09bd2f6d807dddea08a3e05dff926c97158dd5c78fbcec8971733d58e03c9fbf":{"arguments":{"format":"ink-value-wire-v1","identity":"50e3868e4eed2dffa6000932f23075ff8b30106db7f81c7042a51751d7412a0c","named":{},"root":{"fields":[{"name":"xs","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"es","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fit","type":{"kind":"f64"}},{"name":"s","type":{"fields":[{"name":"count","type":{"fields":[{"name":"lines","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"content","type":{"kind":"bool"}}],"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"ink_me68c2f5e5e86a516faa862d519cff9a3e02bc5e131745a9c88827226a0059c6a"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"542b3f99971053a272b15d88dedbfd32860a89ec2308e87c7bdb1c08c26eae0e","named":{},"root":{"fields":[{"name":"count","type":{"fields":[{"name":"lines","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"content","type":{"kind":"bool"}}],"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"ink_me68c2f5e5e86a516faa862d519cff9a3e02bc5e131745a9c88827226a0059c6a"}}},"ink_m0fffc1496f6a8b2b8d7044034bab3436a5bf8d98c9b26163ffc110ef18eb690f":{"arguments":{"format":"ink-value-wire-v1","identity":"ce0f4f38eae34f7975beae644adf030a570e2ed2a6725820552d739792dda9c6","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"c","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"width","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"c8de454d504db86ea8f8ef8cc6465494fc0e6efc146d375495b17ba9fb23b767","named":{},"root":{"fields":[{"name":"width","type":{"kind":"f64"}},{"name":"start","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"kind":"record","name":"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993"}}},"ink_m1035a47a3beb1fd15b77187a225faf4374da04d4239c2bb5f2fd7f377c9105f8":{"arguments":{"format":"ink-value-wire-v1","identity":"5659766a7c7b7721a933ab4ca42ad202c9eaa5cfb2e6fb31a88e3654eb8f6990","named":{},"root":{"fields":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"advance","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"s","type":{"fields":[{"name":"valid","type":{"kind":"bool"}},{"name":"budget","type":{"kind":"u32"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"ink_m233b63cde5b1951078531833cb439d88de244d40e3a6392d35d12e48ecb2ef5d"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"f437e4e468cf5dba7df20a9114414406da37a3ae54ea711140ac1b5956e95082","named":{},"root":{"fields":[{"name":"valid","type":{"kind":"bool"}},{"name":"budget","type":{"kind":"u32"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"ink_m233b63cde5b1951078531833cb439d88de244d40e3a6392d35d12e48ecb2ef5d"}}},"ink_m1c643c3729ce33889b175f6534c6f5567e1031f9a2294b31f14214ef5d846f7e":{"arguments":{"format":"ink-value-wire-v1","identity":"ea66b8576d707e48b450556d72d53a4493461afe4be9a445be48c4a1aa67ad16","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"56dc0435d74d48781d7002db784cd2f88c15385d3cd6b708425c161c37cc361c","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"fields":[{"name":"width","type":{"kind":"f64"}},{"name":"start","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"kind":"record","name":"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993"},"kind":"list"}}}},"ink_m1cbd9e6f220b01cc6d3614d0b500ae6ae7fb6bc6b3ccb0fd24ba416e435dec02":{"arguments":{"format":"ink-value-wire-v1","identity":"f667ca7c21d73ca0e9242c88fa53326ebdb418812897d559970ed1db9c7aeb3c","named":{},"root":{"fields":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"i","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"61e29a83d1fd64f316d82cf150eb5ad0405d16e0e326ff56bf3bae4248a89a32","named":{},"root":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}},"ink_m3e5801892156affa301b1de70c5499a6f98c8ab08ce4a11d6064687eaff81e63":{"arguments":{"format":"ink-value-wire-v1","identity":"04b5b6b7a1379874fb3dfce45df95449faa3dc7e79b5e259cc1f8b72edd3266e","named":{},"root":{"fields":[{"name":"xs","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"n","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"ink_m3ec56d96554edff8dcbc70dd4746c1467d14cccdd680a05225aecdcb1ff10585":{"arguments":{"format":"ink-value-wire-v1","identity":"ce0f4f38eae34f7975beae644adf030a570e2ed2a6725820552d739792dda9c6","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"c","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"width","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"6dabf0313de1ca25f33127bc080f250697ab4e45b0935d5c06756788a303369f","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"fields":[{"name":"width","type":{"kind":"f64"}},{"name":"start","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"kind":"record","name":"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993"},"kind":"option"}}}},"ink_m403c4c47e84eda8d792b1109de53fbbc655e214636da67f4e0bec47ffe157b0e":{"arguments":{"format":"ink-value-wire-v1","identity":"ea66b8576d707e48b450556d72d53a4493461afe4be9a445be48c4a1aa67ad16","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":{},"root":{"kind":"f64"}}},"ink_m424a73c98abd59df2df2e9558114156f29b349d1a0fc567d6a7b6991fa96d4e4":{"arguments":{"format":"ink-value-wire-v1","identity":"ef8cac5957009d7919ea7afa6481df863418422398f30110fafe8c0d99d5489a","named":{},"root":{"fields":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"fit","type":{"kind":"f64"}},{"name":"s","type":{"fields":[{"name":"index","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"trimmed","type":{"kind":"f64"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"result","type":{"kind":"f64"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m2009348d597e6b76dc210821f6f99bb8afebe7919b4fe0a09c17b3f9ac4793c3"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"50c3299d4fbe93aa5602b822292acc76ab4400b031152a8c6acd698494f4c7f8","named":{},"root":{"fields":[{"name":"index","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"trimmed","type":{"kind":"f64"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"result","type":{"kind":"f64"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m2009348d597e6b76dc210821f6f99bb8afebe7919b4fe0a09c17b3f9ac4793c3"}}},"ink_m4871d371876b879fe17454f848676f99047b70dcf533553abf657eccb48917a5":{"arguments":{"format":"ink-value-wire-v1","identity":"0b69ff4dcdb1d6bbb28477df20642d1e80062f6025ebbd7f1dc071f1f4a655ee","named":{},"root":{"fields":[{"name":"xs","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"ink_m5a18484940b2f87721d94e036b20f3f623fd9a7ef0bbb105d497073a418c96f6":{"arguments":{"format":"ink-value-wire-v1","identity":"ea66b8576d707e48b450556d72d53a4493461afe4be9a445be48c4a1aa67ad16","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"521eaeae4d030f71891ee322304be19877dd3df45f375257b9b99b896efe3237","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"u32"}}}},"ink_m618e3b1ce3d206a7ce99ecd61dc5909f8327679e73d0e9cd3a60a1c006ce85b8":{"arguments":{"format":"ink-value-wire-v1","identity":"ea66b8576d707e48b450556d72d53a4493461afe4be9a445be48c4a1aa67ad16","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"958e0edfe65dde01c97aa1e7b9cb0c065f371a3330a42d473bc79a0491ebfc4f","named":{},"root":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}}},"ink_m61a3849a7a6ebf0fe028d8fa87a1a3eaa6166a2532387000b50e461faa1b2899":{"arguments":{"format":"ink-value-wire-v1","identity":"1dbd92479e4132df4112ee804b4863ed22312c28d4856d85aed77754b2671a10","named":{},"root":{"fields":[{"name":"xs","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"start","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"fit","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"75a4618821d68677bbefcd2dc8914150aecf406a4a3da1ef14cc88b57d83d830","named":{},"root":{"fields":[{"name":"index","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m7b062ce6e1c2efcea6de69b7c533325db5ea045c74268a2b5acae500b6575dfc"}}},"ink_m693a1ebd0432f205eabdd53caaf1bb1ac592d434476d44639419d5b63ab48e45":{"arguments":{"format":"ink-value-wire-v1","identity":"17f3e017634c517452044c80028b56718cfc21dfd3e6cd791ef2319dd220bcc2","named":{},"root":{"fields":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"c","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"8e9fa024666eb3bfe6ab6049f660e547a12b56772f4ecbff9addcea5a92f3d9a","named":{},"root":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}},"ink_m746b7ebe9bcb715eb063c9a8acdc48ed10dd67c3ac1ab355ca08a8a31f2e076a":{"arguments":{"format":"ink-value-wire-v1","identity":"1dbd92479e4132df4112ee804b4863ed22312c28d4856d85aed77754b2671a10","named":{},"root":{"fields":[{"name":"xs","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"start","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"fit","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"75a4618821d68677bbefcd2dc8914150aecf406a4a3da1ef14cc88b57d83d830","named":{},"root":{"fields":[{"name":"index","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m7b062ce6e1c2efcea6de69b7c533325db5ea045c74268a2b5acae500b6575dfc"}}},"ink_m79fbd33ce445d81b5495367bea54ed582eb29a97df1560f52a1db7c4538eabd4":{"arguments":{"format":"ink-value-wire-v1","identity":"c3e1c11e682af8a0dca6bce5731523dfc4cd4063d21e60ee62914c18c5cec200","named":{},"root":{"fields":[{"name":"width","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":{},"root":{"kind":"f64"}}},"ink_ma9923eba3cdcc3be4bd5eec9937c55f89cb7af34eade1f02c02bde46b444755d":{"arguments":{"format":"ink-value-wire-v1","identity":"f667ca7c21d73ca0e9242c88fa53326ebdb418812897d559970ed1db9c7aeb3c","named":{},"root":{"fields":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"i","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff","named":{},"root":{"kind":"u32"}}},"ink_maa2ffc47f94a1df1e2b1982bb687b3b95ea1f18c3d31e5270249eb9a5b1b8987":{"arguments":{"format":"ink-value-wire-v1","identity":"22ccae4e651c3400343cf3a9d397f2740b858e5ad1aeed6d97ee2949ed2b050d","named":{},"root":{"fields":[{"name":"xs","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"i","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":{},"root":{"kind":"f64"}}},"ink_mb3166db2bf18ab05ba193c347c860e3c609f09da430fd77ac9981409ba2efcef":{"unsupported":"unsupported wire descriptor"},"ink_mb4277fe25fdfb0e134f990b04d6baa626119984e30cca8da242f327fd2871a58":{"arguments":{"format":"ink-value-wire-v1","identity":"2a2788fa3b1e05bb17c1278b1fca7eaf8dad34a3e69e8baf16adaaa6487c395b","named":{},"root":{"fields":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"maximum","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"f4055357f369cc8f275f6cc1d5569678031edf449ad32c3c8d392d37fab5b1ed","named":{},"root":{"element":{"kind":"u32"},"kind":"option"}}},"ink_mc1df4b06d386435afd93c2deb158f576ca1a0b8da5cc9ddac9804cbbd5aaed55":{"arguments":{"format":"ink-value-wire-v1","identity":"2a2788fa3b1e05bb17c1278b1fca7eaf8dad34a3e69e8baf16adaaa6487c395b","named":{},"root":{"fields":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"maximum","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"ecfeb978a3522397be254146ef28fe5f3058566b565a7f4962c9131b6b18ae1c","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}}}},"ink_md45fb160f95b90ffa06f2e883a8e13e6cfb6f48c9e504c758674212aaaafed13":{"arguments":{"format":"ink-value-wire-v1","identity":"6f216386ecb924bce5a8e749a1e37cad000c13c87ec367c037a886590a47a6c7","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"ink_mdb420bacbaded3bd4a47c64a08eab41bd49e5a1eb00a06f5fb4216055764e14f":{"arguments":{"format":"ink-value-wire-v1","identity":"d95574a1453f38b447e94bccad1e5dd882553eca4b79f52ca848dd2ede361d93","named":{},"root":{"fields":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"fit","type":{"kind":"f64"}},{"name":"i","type":{"kind":"u32"}},{"name":"s","type":{"fields":[{"name":"lines","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"content","type":{"kind":"bool"}}],"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"3650a28e866fe994c1295f191904faf234c261d3a1a0a1b12bbf12c9e04226a2","named":{},"root":{"fields":[{"name":"lines","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"content","type":{"kind":"bool"}}],"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"}}},"ink_me3e1d6802e8b8c99257eae2c70e1c73b81194a7b49cd49c1aadcbcf5fb61a373":{"arguments":{"format":"ink-value-wire-v1","identity":"ea66b8576d707e48b450556d72d53a4493461afe4be9a445be48c4a1aa67ad16","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"82ec50d2da2c3182aceb5378e08d8b8fe9de60c2be54d6daf5dbdb658955279f","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}}}},"ink_mf2da1ccb63323de619308b515afc2e8427fa422cacc3b9e180896d7c1933a5db":{"arguments":{"format":"ink-value-wire-v1","identity":"ca7d05d687135adb81b9858ad2e18cb8e2bfdd9f310542855171482c6284f07d","named":{},"root":{"fields":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"i","type":{"kind":"u32"}},{"name":"atStart","type":{"kind":"bool"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"ink_mf3fd6a8edcedf12678ee0135d258e53818da29f98901e4823c5b5fa68a8742b5":{"arguments":{"format":"ink-value-wire-v1","identity":"f667ca7c21d73ca0e9242c88fa53326ebdb418812897d559970ed1db9c7aeb3c","named":{},"root":{"fields":[{"name":"d","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"i","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"ink_mf92f9e487553a051acda291cdf01e6ab1ad3a5254dd3d94587ad2b797d8dea28":{"arguments":{"format":"ink-value-wire-v1","identity":"849e86828ba3b664132f5aa51c80dd1f91b4598af1024a1580d92d2e15770ef6","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},{"name":"width","type":{"kind":"f64"}},{"name":"lineHeight","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"847cdb58437325b0783e94e7d572b615580b335968d233fd0e1b9879487ce4b2","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"height","type":{"kind":"f64"}}],"kind":"record","name":"ink_mf31874390da54b3c180b48032618b677f5ca389c9ffcfc54ae469de235e84bcb"}}}},"layout":{"arguments":{"format":"ink-value-wire-v1","identity":"12868a3202c474e3db65dc4ff3bb8dc81cdd78f4fcd3dae557f7b42d54fc8ed2","named":{},"root":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"width","type":{"kind":"f64"}},{"name":"lineHeight","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"847cdb58437325b0783e94e7d572b615580b335968d233fd0e1b9879487ce4b2","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"height","type":{"kind":"f64"}}],"kind":"record","name":"ink_mf31874390da54b3c180b48032618b677f5ca389c9ffcfc54ae469de235e84bcb"}}}},"line":{"arguments":{"format":"ink-value-wire-v1","identity":"ad927f6815e10415fe2ad6b49b3be99770ef082e84bbd38076539814c89e1d9d","named":{},"root":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"width","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"6dabf0313de1ca25f33127bc080f250697ab4e45b0935d5c06756788a303369f","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"fields":[{"name":"width","type":{"kind":"f64"}},{"name":"start","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"kind":"record","name":"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993"},"kind":"option"}}}},"lines":{"arguments":{"format":"ink-value-wire-v1","identity":"0d9813fafc11c1ce57d687b8f597a62e1278f03c1d61330d83c27c5625c3aa7f","named":{},"root":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"width","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"56dc0435d74d48781d7002db784cd2f88c15385d3cd6b708425c161c37cc361c","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"fields":[{"name":"width","type":{"kind":"f64"}},{"name":"start","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"kind":"record","name":"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993"},"kind":"list"}}}},"numeric":{"arguments":{"format":"ink-value-wire-v1","identity":"7d522496fa90814f2f1e12091142cca8648a00e9c787d158636f57940650d4e4","named":{},"root":{"fields":[{"name":"xs","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"prepare":{"arguments":{"format":"ink-value-wire-v1","identity":"420561bdb34944962fafc5dd683910a11ec0ec79e77e10ebde738e30e54acf2c","named":{},"root":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"maximum","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"ecfeb978a3522397be254146ef28fe5f3058566b565a7f4962c9131b6b18ae1c","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}}}},"stats":{"arguments":{"format":"ink-value-wire-v1","identity":"0d9813fafc11c1ce57d687b8f597a62e1278f03c1d61330d83c27c5625c3aa7f","named":{},"root":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"width","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"82ec50d2da2c3182aceb5378e08d8b8fe9de60c2be54d6daf5dbdb658955279f","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}}}}}}};
const __implementations=[__fn0,__fn1,__fn2,__fn3,__fn4,__fn5,__fn6,__fn7,__fn8,__fn9,__fn10,__fn11,__fn12,__fn13,__fn14,__fn15,__fn16,__fn17,__fn18,__fn19,__fn20,__fn21,__fn22,__fn23,__fn24,__fn25,__fn26,__fn27,__fn28,__fn29,__fn30,__fn31,__fn32,__fn33,__fn34,__fn35];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
const __inputTypes=[{"capture":[true,true,true],"types":[{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},{"kind":"f64"},{"kind":"u32"}]},{"capture":[true,true,true],"types":[{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},{"kind":"f64"},{"kind":"f64"}]},{"capture":[true,true,true],"types":[{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},{"kind":"f64"},{"kind":"f64"}]},{"capture":[true,true,true],"types":[{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},{"kind":"f64"},{"kind":"f64"}]},{"capture":[true,true,true,true],"types":[{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},{"kind":"f64"},{"kind":"f64"},{"kind":"f64"}]},{"capture":[true,true,true,true],"types":[{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},{"kind":"f64"},{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"},{"kind":"f64"}]},{"capture":[false,true],"types":[{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"},{"kind":"f64"}]},{"capture":[true],"types":[{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[true,true],"types":[{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},{"kind":"u32"}]},{"capture":[false,true],"types":[{"fields":[{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},{"kind":"u32"}]},{"capture":[false,true],"types":[{"fields":[{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},{"kind":"u32"}]},{"capture":[false,true,true],"types":[{"fields":[{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},{"kind":"u32"},{"kind":"bool"}]},{"capture":[false,true],"types":[{"fields":[{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},{"kind":"u32"}]},{"capture":[true],"types":[{"element":{"kind":"f64"},"kind":"list"}]},{"capture":[true,true],"types":[{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},{"kind":"u32"}]},{"capture":[false,true,true,false],"types":[{"fields":[{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},{"kind":"u32"},{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},{"fields":[{"name":"valid","type":{"kind":"bool"}},{"name":"budget","type":{"kind":"u32"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"ink_m233b63cde5b1951078531833cb439d88de244d40e3a6392d35d12e48ecb2ef5d"}]},{"capture":[false,true,true],"types":[{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},{"kind":"f64"},{"kind":"u32"}]},{"capture":[true,true,true],"types":[{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},{"kind":"f64"},{"kind":"u32"}]},{"capture":[false],"types":[{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}]},{"capture":[true],"types":[{"kind":"f64"}]},{"capture":[false,true],"types":[{"fields":[{"name":"epsilon","type":{"kind":"f64"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"},{"kind":"f64"}]},{"capture":[false,true],"types":[{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}]},{"capture":[true,true,true,true],"types":[{"element":{"kind":"f64"},"kind":"list"},{"kind":"u32"},{"kind":"f64"},{"kind":"f64"}]},{"capture":[false,true,false],"types":[{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},{"kind":"f64"},{"fields":[{"name":"index","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"trimmed","type":{"kind":"f64"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"result","type":{"kind":"f64"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m2009348d597e6b76dc210821f6f99bb8afebe7919b4fe0a09c17b3f9ac4793c3"}]},{"capture":[false,true,true],"types":[{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"},{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"},{"kind":"f64"}]},{"capture":[false,true,true],"types":[{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"},{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"},{"kind":"f64"}]},{"capture":[false,true,false],"types":[{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"},{"kind":"f64"},{"fields":[{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"stats","type":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}}],"kind":"record","name":"ink_m086abde96a678051961f464f791c4c5c94b31f286fb29436e88cbebcf9b5ad1c"}]},{"capture":[false,true],"types":[{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"},{"kind":"f64"}]},{"capture":[false,true],"types":[{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"},{"kind":"f64"}]},{"capture":[false,true,false],"types":[{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"},{"kind":"f64"},{"fields":[{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"lines","type":{"kind":"temporary"}}],"kind":"record","name":"ink_mb57c7f78770196118eeb183601122638651b9dc2e5e5132e7d0d790985b01684"}]},{"capture":[false,true],"types":[{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"},{"kind":"f64"}]},{"capture":[true,true,true,true],"types":[{"element":{"kind":"f64"},"kind":"list"},{"kind":"u32"},{"kind":"f64"},{"kind":"f64"}]},{"capture":[true,true,true,false],"types":[{"element":{"kind":"f64"},"kind":"list"},{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},{"kind":"f64"},{"fields":[{"name":"count","type":{"fields":[{"name":"lines","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"content","type":{"kind":"bool"}}],"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"ink_me68c2f5e5e86a516faa862d519cff9a3e02bc5e131745a9c88827226a0059c6a"}]},{"capture":[false,true,true,true],"types":[{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"},{"kind":"f64"},{"kind":"u32"},{"fields":[{"name":"lines","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"content","type":{"kind":"bool"}}],"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"}]},{"capture":[false,true],"types":[{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"},{"kind":"f64"}]},{"capture":[false,true,true],"types":[{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"},{"kind":"f64"},{"kind":"f64"}]}];

// Descriptor work occurs once at module initialisation, never per word-list call.
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=> {
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const output=__representation(f.result,true);
  const body=__implementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
  const needsInput=input.some(c=>c!==__identity);
  const entry=!needsInput && output===__identity ? implementation :
    (...args)=>{const context=new WeakMap();return output(implementation(...(needsInput ? args.map((v,i)=>input[i](v,context)) : args)),context);};
  return [f.name,entry];
})));
export function call(name,args) {switch(name){case "ink_mb3166db2bf18ab05ba193c347c860e3c609f09da430fd77ac9981409ba2efcef":throw new Error('temporary storage is internal to a pure invocation');}return functions[name](...args);}
// Shared bounded binary codec; generated code supplies exact descriptors.
export const valueWireFormat='ink-value-wire-v1';
// A connection agrees on the complete value schema before using this format.
// Version byte + schema-directed fields; schema identity is out of band.
export const compactValueWireFormat='ink-value-session-v1';
const wireMagic=Uint8Array.of(73,78,75,86,65,76,0,1);
const wireEncoder=new TextEncoder(),wireDecoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const wireDefaults=Object.freeze({bytes:16777216,nodes:1000000,depth:128}),wireDefaultOptions=Object.freeze({});
const wireDecimal=s=>typeof s==='string'&&/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(s);
function wireLimits(options){if(options===wireDefaultOptions||options===wireDefaults)return wireDefaults;const l={...wireDefaults,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>wireDefaults[k])throw Error('wire hard resource limit');return l;}
const wireFloat=new DataView(new ArrayBuffer(4));
function wireDecodeText(bytes,start,end){
 if(end-start<=16){let text='';for(let i=start;i<end;i++){const byte=bytes[i];if(byte>=128)return wireDecoder.decode(bytes.subarray(start,end));text+=String.fromCharCode(byte);}return text;}
 return wireDecoder.decode(bytes.subarray(start,end));
}
function wireUtf8Length(text){let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const wireOwn=(v,k)=>v!==null&&typeof v==='object'&&Object.hasOwn(v,k);
const wireTagged=(v,k)=>wireOwn(v,k)&&Object.keys(v).length===1;
const wireDouble=new DataView(new ArrayBuffer(8));
function wireF64Bits(v){
 if(typeof v==='number'&&Number.isFinite(v)){wireDouble.setFloat64(0,v,true);return wireDouble.getBigUint64(0,true);}
 if(!wireTagged(v,'F64Bits'))wireInvalidValue();const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))wireInvalidValue();
 const bits=BigInt(text);if(bits>18446744073709551615n)wireInvalidValue();return bits;
}
const wireCanonical=v=>Array.isArray(v)?'['+v.map(wireCanonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort((a,b)=>{const x=Array.from(a,c=>c.codePointAt(0)),y=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]-y[i];return x.length-y.length;}).map(k=>JSON.stringify(k)+':'+wireCanonical(v[k])).join(',')+'}':JSON.stringify(v);
export async function createValueCodec(root,named={}){
 const used=new Set(),budget={nodes:100000};
 function check(t,d=0){
  if(d>64||--budget.nodes<0)throw Error('wire descriptor limit');
  const keys={u32:['kind'],u64:['kind'],i32:['kind'],f32:['kind'],f64:['kind'],bool:['kind'],unit:['kind'],string:['kind'],int:['kind'],id:['kind','name'],ref:['kind','name'],enum:['kind','name','variants'],record:['kind','name','fields'],list:['kind','element'],option:['kind','element'],vector:['kind','element','size'],result:['kind','ok','error']}[t?.kind];
  if(!keys||Object.keys(t).length!==keys.length||keys.some(k=>!Object.hasOwn(t,k)))throw Error('invalid wire descriptor');
  if(keys.includes('name')&&(typeof t.name!=='string'||!t.name.isWellFormed()))throw Error('invalid descriptor name');
  if(t.kind==='ref'){if(!used.has(t.name)){used.add(t.name);if(named[t.name]?.kind!=='record'||named[t.name].name!==t.name)throw Error('unresolved wire reference');check(named[t.name],d+1);}}
  if(t.kind==='record'){if(!Array.isArray(t.fields))throw Error('wire fields');const names=new Set();for(const f of t.fields){if(Object.keys(f).length!==2||typeof f.name!=='string'||!f.name.isWellFormed()||names.has(f.name))throw Error('duplicate wire field');names.add(f.name);check(f.type,d+1);}}
  if(t.kind==='enum'&&(!Array.isArray(t.variants)||!t.variants.length||t.variants.length>64||t.variants.some(v=>typeof v!=='string'||!v.isWellFormed())||new Set(t.variants).size!==t.variants.length))throw Error('wire enum');
  if(['list','vector','option'].includes(t.kind)){if(t.kind==='vector'&&(!Number.isInteger(t.size)||t.size<1||t.size>64))throw Error('wire vector');check(t.element,d+1);}
  if(t.kind==='result'){check(t.ok,d+1);check(t.error,d+1);}
 }
 check(root);const names=Object.fromEntries([...used].sort().map(k=>[k,named[k]]));
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',wireEncoder.encode(wireCanonical({format:valueWireFormat,root,named:names}))));
 return new ValueCodec({format:valueWireFormat,root,named:names,identity:Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('')});
}
// Resolve immutable descriptor edges once. Logical validation traverses the
// literal schema; single-child nodes use a loop rather than recursive closures.
function wireValuePlan(codec){
 const seen=new WeakMap();let remaining=100000;
 const build=type=>{
  const t=codec.resolve(type);if(seen.has(t))return seen.get(t);
  if(--remaining<0)throw Error('wire descriptor limit');const p={kind:t.kind,type:t,decode:null,decodeCompact:null};seen.set(t,p);
  if(t.kind==='record')p.fields=t.fields.map(f=>({name:f.name,plan:build(f.type)}));
  if(t.kind==='list'||t.kind==='vector'||t.kind==='option')p.element=build(t.element);
  if(t.kind==='result'){p.ok=build(t.ok);p.error=build(t.error);}
  return p;
 };return build(codec.descriptor.root);
}
function wireBindDecodePlan(root,compact=false){
 const seen=new Set(),pending=[root];let flags=0;
 while(pending.length){
  const p=pending.pop();if(seen.has(p))continue;seen.add(p);if(compact)p.decodeCompact=compactDecodeOperation(p);else p.decode=wireDecodeOperation(p);
  if(p.fields?.length>4)flags|=1;
  if(p.kind==='u32'||p.kind==='i32'||p.kind==='u64'||p.kind==='f32'||p.kind==='f64')flags|=2;
  if(p.fields)for(const f of p.fields)pending.push(f.plan);
  if(p.element)pending.push(p.element);
  if(p.ok){pending.push(p.ok);pending.push(p.error);}
 }
 return flags|4;
}
// Select literal descriptor operations once, without runtime source generation
// or eval. Recursive edges call the completed plan. The generic scanner remains
// the visitor/validation path and an independent materialisation implementation.
function wireReadOperation(p){
 const t=p.type;
 let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':read=(r,end)=>{r.size(end,4);const value={F32Bits:r.view.getUint32(r.cursor,true)};r.cursor=end;return value;};break;
  case 'f64':read=(r,end)=>{r.size(end,8);const value={F64Bits:r.view.getBigUint64(r.cursor,true).toString()};r.cursor=end;return value;};break;
  case 'u64':read=(r,end)=>{r.size(end,8);const value=r.view.getBigUint64(r.cursor,true);r.cursor=end;return value;};break;
  case 'string':read=(r,end)=>r.text(end);break;
  case 'int':read=(r,end)=>{const text=r.text(end);if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=(r,end)=>{const text=r.text(end);if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=(r,end)=>{const text=r.text(end);if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{
    if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;
    if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');
    const values=new Array(n);for(let i=0;i<n;i++)values[i]=element.decode(r,end,d+1);return values;
   };break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1)});break;
    case 2:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1)});break;
    case 3:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1)});break;
    case 4:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1),[fs[3].name]:fs[3].plan.decode(r,end,d+1)});break;
    default:read=(r,end,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decode(r,end,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,end,d)=>{const tag=r.tag(end);return tag?{Some:p.element.decode(r,end,d+1)}:{None:null};};break;
  case 'result':read=(r,end,d)=>r.tag(end)?{Err:p.error.decode(r,end,d+1)}:{Ok:p.ok.decode(r,end,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function wireDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=wireReadOperation(field.plan),name=field.name;
  return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),childEnd=r.enter(end,d+1),item=read(r,childEnd,d+1);if(r.cursor!==childEnd)throw Error('trailing wire frame bytes');const value={[name]:item};if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
 }
 const read=wireReadOperation(p);
 return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
}
class WireDecodeCursor{
 constructor(bytes,view,limits){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
// Bind literal validation and postorder visitation once for every descriptor.
// No logical carriers are allocated; projection still validates every child.
function wireScanPlan(root){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,scan:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.scan=wireScanOperation(p);return p;
 };
 return build(root);
}
function wireScanOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':case 'f64':case 'u64':{const size=p.kind==='f32'?4:8;read=(r,end)=>{r.size(end,size);r.cursor=end;};break;}
  case 'string':read=(r,end)=>{let i=r.cursor;while(i<end&&r.bytes[i]<128)i++;if(i<end)wireDecoder.decode(r.bytes.subarray(r.cursor,end));r.cursor=end;};break;
  case 'int':case 'id':case 'enum':read=(r,end)=>{const text=r.text(end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');for(let i=0;i<n;i++)element.scan(r,end,d+1);};break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>{};break;
    case 1:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);};break;
    case 2:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);};break;
    case 3:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);};break;
    case 4:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);fs[3].plan.scan(r,end,d+1);};break;
    default:read=(r,end,d)=>{for(const f of fs)f.plan.scan(r,end,d+1);};
   }break;
  }
  case 'option':read=(r,end,d)=>{if(r.tag(end))p.element.scan(r,end,d+1);};break;
  case 'result':read=(r,end,d)=>{(r.tag(end)?p.error:p.ok).scan(r,end,d+1);};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return (r,parentEnd,d)=>{
  const end=r.enter(parentEnd,d),start=r.cursor,value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');
  const visitor=r.visitor;if(visitor&&(!r.selected||r.selected.has(t.name))){if(r.spans)visitor(t,r.bytes,start,end,d);else visitor(t,r.bytes.subarray(start,end),d);}
  return value;
 };
}
// Separate methods keep decoding's cursor callsites monomorphic. Both cursors
// are checked against the independent generic scanner and malformed fixtures.
class WireScanCursor{
 constructor(bytes,view,limits,visitor,selected,spans){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.visitor=visitor;this.selected=selected;this.spans=spans;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
function compactReadOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=()=>null;break;
  case 'bool':read=r=>{r.require(1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':case 'i32':read=r=>{r.require(4);const n=p.kind==='u32'?r.view.getUint32(r.cursor,true):r.view.getInt32(r.cursor,true);r.cursor+=4;return n;};break;
  case 'f32':read=r=>{r.require(4);const n=r.view.getUint32(r.cursor,true);r.cursor+=4;return {F32Bits:n};};break;
  case 'f64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return {F64Bits:n.toString()};};break;
  case 'u64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return n;};break;
  case 'string':read=r=>r.text();break;
  case 'int':read=r=>{const text=r.text();if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=r=>{const text=r.text();if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=r=>{const text=r.text();if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':read=(r,d)=>{const n=r.count();if(n>r.remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');const values=new Array(n);for(let i=0;i<n;i++)values[i]=p.element.decodeCompact(r,d+1);return values;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1)});break;
    case 2:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1)});break;
    case 3:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1)});break;
    case 4:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1),[fs[3].name]:fs[3].plan.decodeCompact(r,d+1)});break;
    default:read=(r,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decodeCompact(r,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,d)=>r.tag()?{Some:p.element.decodeCompact(r,d+1)}:{None:null};break;
  case 'result':read=(r,d)=>r.tag()?{Err:p.error.decodeCompact(r,d+1)}:{Ok:p.ok.decodeCompact(r,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function compactDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=compactReadOperation(field.plan),name=field.name;
  return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');if(d+1>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return {[name]:read(r,d+1)};};
 }
 const read=compactReadOperation(p);
 return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return read(r,d);};
}
class CompactDecodeCursor{
 constructor(bytes,limits,flags){this.bytes=bytes;this.view=flags&2?new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength):null;this.cursor=1;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 require(n){if(n>this.bytes.length-this.cursor)throw Error('truncated compact value');}
 count(){
  if(this.cursor>=this.bytes.length)throw Error('truncated compact value');
  const first=this.bytes[this.cursor++];if(first<128)return first;
  let value=first&127,scale=128;
  for(let i=1;i<5;i++){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const byte=this.bytes[this.cursor++];if(i===4&&byte>15)throw Error('compact count overflow');value+=(byte&127)*scale;if(byte<128){if(byte===0)throw Error('noncanonical compact count');return value;}scale*=128;}throw Error('compact count overflow');
 }
 tag(){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const tag=this.bytes[this.cursor++];if(tag>1)throw Error('wire sum tag');return tag;}
 text(){const n=this.count();this.require(n);const start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
function wireInvalidValue(){throw Error('invalid value for wire schema');}
// Capture has the canonical logical meaning of decode(encode(value)), without
// allocating wire bytes. A separate plan leaves validation/decoder hot shapes
// unchanged and never retains host input containers between calls.
function wireCapturePlan(root,checked=true){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,capture:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({name:f.name,plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.capture=checked?wireCaptureOperation(p):wireCopyOperation(p);return p;
 };return build(root);
}
function wireCaptureOperation(p){
 const t=p.type;let copy;
 switch(p.kind){
  case 'unit':copy=v=>{if(v!==null)wireInvalidValue();return null;};break;
  case 'bool':copy=(v,r)=>{if(typeof v!=='boolean')wireInvalidValue();r.add(1);return v;};break;
  case 'u32':case 'i32':{
   const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
   copy=(v,r)=>{if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();r.add(4);return v===0?0:v;};break;
  }
  case 'u64':copy=(v,r)=>{const kind=typeof v;if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();r.add(8);return n;};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'int':case 'id':case 'enum':copy=(v,r)=>{const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;if(typeof text!=='string'||!text.isWellFormed()||text.length>r.limit)wireInvalidValue();if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();r.add(wireUtf8Length(text));return p.kind==='int'?{Int:text}:text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   copy=(v,r,d)=>{if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();const n=v.length;if(n>r.remaining||size!==null&&n!==size)wireInvalidValue();r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=element.capture(v[i],r,d+1);return out;};break;
  }
  case 'record':{
   const fs=p.fields;let fields;
   switch(fs.length){
    case 0:fields=()=>({});break;
    case 1:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:fields=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }
   copy=(v,r,d)=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();for(const f of fs)if(!wireOwn(v,f.name))wireInvalidValue();return fields(v,r,d);};break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'None')&&v.None===null)return {None:null};if(wireTagged(v,'Some'))return {Some:p.element.capture(v.Some,r,d+1)};wireInvalidValue();};break;
  case 'result':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'Ok'))return {Ok:p.ok.capture(v.Ok,r,d+1)};if(wireTagged(v,'Err'))return {Err:p.error.capture(v.Err,r,d+1)};wireInvalidValue();};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
class WireCaptureCursor{
 constructor(limits){this.remaining=limits.nodes;this.depth=limits.depth;this.limit=limits.bytes;this.bytes=40;this.add(0);}
 add(n){this.bytes+=n;if(this.bytes>this.limit)throw Error('wire byte limit');}
 enter(depth,bytes){if(depth>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.add(bytes);}
 text(value){if(value.length>this.limit)throw Error('wire byte limit');this.add(wireUtf8Length(value));}
}
// Literal lowerers share this fixed resource policy with logical capture.
export function createValueCaptureBudget(options=wireDefaultOptions){return new WireCaptureCursor(wireLimits(options));}
// The trusted-value API has the same canonical copy and ownership semantics.
// Its caller supplies a stable value accepted by validateValue. Shape/range
// checks remain at external capture boundaries; resource limits still apply.
function wireCopyOperation(p){
 let copy;
 switch(p.kind){
  case 'unit':copy=()=>null;break;
  case 'bool':copy=(v,r)=>{r.add(1);return v;};break;
  case 'u32':copy=(v,r)=>{r.add(4);return v>>>0;};break;
  case 'i32':copy=(v,r)=>{r.add(4);return v|0;};break;
  case 'u64':copy=(v,r)=>{r.add(8);return BigInt(v);};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'){wireFloat.setFloat32(0,v,true);bits=wireFloat.getUint32(0,true);}else bits=v.F32Bits;r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'id':case 'enum':copy=(v,r)=>{r.add(wireUtf8Length(v));return v;};break;
  case 'int':copy=(v,r)=>{const text=typeof v==='bigint'?v.toString():v.Int;r.add(wireUtf8Length(text));return {Int:text};};break;
  case 'list':case 'vector':copy=(v,r,d)=>{const n=v.length;if(n>r.remaining)throw Error('wire sequence size');r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=p.element.capture(v[i],r,d+1);return out;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:copy=()=>({});break;
    case 1:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:copy=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'None')&&v.None===null?{None:null}:{Some:p.element.capture(v.Some,r,d+1)};};break;
  case 'result':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'Ok')?{Ok:p.ok.capture(v.Ok,r,d+1)}:{Err:p.error.capture(v.Err,r,d+1)};};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
// Emit the cached literal schema with one forward writer. Each value is checked
// where it is consumed; byte bounds belong to the writer, not a second size walk.
function wireEncodeValue(root,value,l,w){
 let remaining=l.nodes;const depthLimit=l.depth;
 const node=(p,v,d)=>{
  if(d>depthLimit||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type,start=w.beginNode();
  switch(p.kind){
   case 'unit':if(v!==null)wireInvalidValue();break;
   case 'bool':if(typeof v!=='boolean')wireInvalidValue();w.byte(+v);break;
   case 'u32':case 'i32':{
    const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
    if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();w.word(v>>>0);break;
   }
   case 'u64':{
    const kind=typeof v;
    if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
    const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();w.wide(n);break;
   }
   case 'f64':w.wide(wireF64Bits(v));break;
   case 'f32':{
    let bits;
    if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}
    else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
    w.word(bits);break;
   }
   case 'string':case 'int':case 'id':case 'enum':{
    const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
    if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&(typeof text!=='string'||!/^[0-9a-f]{32}$/.test(text))||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
    w.text(text);break;
   }
   case 'list':case 'vector':{
    if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
    if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
    w.count(v.length);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);break;
   }
   case 'record':{
    const fs=p.fields;
    if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
    for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
    for(let i=0;i<fs.length;i++){const f=fs[i];node(f.plan,v[f.name],d+1);}break;
   }
   case 'option':{
    if(wireTagged(v,'None')&&v.None===null)w.byte(0);
    else if(wireTagged(v,'Some')){w.byte(1);node(p.element,v.Some,d+1);}else wireInvalidValue();break;
   }
   case 'result':{
    if(wireTagged(v,'Ok')){w.byte(0);node(p.ok,v.Ok,d+1);}
    else if(wireTagged(v,'Err')){w.byte(1);node(p.error,v.Err,d+1);}else wireInvalidValue();break;
   }
   default:throw Error('unsupported wire kind');
  }
  w.endNode(start);
 };
 node(root,value,0);
}
function wireCheckValue(root,value,l){
 let remaining=l.nodes,total=40;
 const add=n=>{total+=n;if(total>l.bytes)throw Error('wire byte limit');};
 const node=(p,v,d)=>{
  while(true){
   if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
   const t=p.type;
   switch(p.kind){
    case 'unit':if(v!==null)wireInvalidValue();add(4);return;
    case 'bool':if(typeof v!=='boolean')wireInvalidValue();add(5);return;
    case 'u32':case 'i32':{
     const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
     if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();add(8);return;
    }
    case 'u64':{
     const kind=typeof v;
     if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
     const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();add(12);return;
    }
    case 'f64':wireF64Bits(v);add(12);return;
    case 'f32':{
     if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();}
     else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();const bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
     add(8);return;
    }
    case 'string':case 'int':case 'id':case 'enum':{
     const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
     if(typeof text!=='string'||!text.isWellFormed()||text.length>l.bytes)wireInvalidValue();
     if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
     add(4+wireUtf8Length(text));return;
    }
    case 'list':case 'vector':{
     if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
     if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
     add(8);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);return;
    }
    case 'record':{
     const fs=p.fields;
     if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
     for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
     add(4);if(!fs.length)return;
     for(let i=0;i<fs.length-1;i++)node(fs[i].plan,v[fs[i].name],d+1);
     const f=fs[fs.length-1];p=f.plan;v=v[f.name];d++;continue;
    }
    case 'option':{
     if(wireTagged(v,'None')&&v.None===null){add(5);return;}
     if(!wireTagged(v,'Some'))wireInvalidValue();add(5);p=p.element;v=v.Some;d++;continue;
    }
    case 'result':{
     if(wireTagged(v,'Ok')){add(5);p=p.ok;v=v.Ok;}
     else if(wireTagged(v,'Err')){add(5);p=p.error;v=v.Err;}else wireInvalidValue();
     d++;continue;
    }
    default:throw Error('unsupported wire kind');
   }
  }
 };
 node(root,value,0);if(total>l.bytes)throw Error('wire byte limit');
}
// A single cursor replaces per-node child closures and {end,value} temporaries.
// Projection filters limit callback materialisation, never schema validation.
function wireScanValue(root,bytes,view,l,materialize,visitor,selected,spans){
 let cursor=40,remaining=l.nodes;
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,parentEnd,d)=>{
  if(d>l.depth||--remaining<0||cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const t=p.type,start=cursor+4,end=start+view.getUint32(cursor,true);if(end>parentEnd)throw Error('truncated wire frame');cursor=start;let value;
  switch(p.kind){
   case 'unit':if(end-start!==0)throw Error('malformed wire scalar');value=null;break;
   case 'bool':if(end-start!==1)throw Error('malformed wire scalar');if(bytes[start]>1)throw Error('invalid wire Bool');value=!!bytes[start];cursor=end;break;
   case 'u32':case 'i32':if(end-start!==4)throw Error('malformed wire scalar');value=p.kind==='u32'?view.getUint32(start,true):view.getInt32(start,true);cursor=end;break;
   case 'f32':if(end-start!==4)throw Error('malformed wire scalar');if(materialize)value={F32Bits:view.getUint32(start,true)};cursor=end;break;
   case 'f64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value={F64Bits:view.getBigUint64(start,true).toString()};cursor=end;break;
   case 'u64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value=view.getBigUint64(start,true);cursor=end;break;
   case 'string':case 'int':case 'id':case 'enum':{
    if(p.kind==='string'&&!materialize){let i=start;while(i<end&&bytes[i]<128)i++;if(i<end)wireDecoder.decode(bytes.subarray(start,end));}
    else{const text=wireDecodeText(bytes,start,end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    cursor=end;break;
   }
   case 'list':case 'vector':{
    if(start+4>end)throw Error('wire list count');const n=view.getUint32(start,true);cursor+=4;
    if(n>remaining||n>Math.floor((end-cursor)/4)||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,end,d+1);if(materialize)value.push(child);}break;
   }
   case 'record':{
    const fs=p.fields;
    // Computed literal keys create own data properties even for __proto__ or
    // prototype setters. Common small records need no descriptor allocations.
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:value={};break;case 1:value={[fs[0].name]:node(fs[0].plan,end,d+1)};break;case 2:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1)};break;case 3:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1)};break;case 4:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1),[fs[3].name]:node(fs[3].plan,end,d+1)};break;}
    }else{if(materialize)value={};for(const f of fs){const child=node(f.plan,end,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}}break;
   }
   case 'option':case 'result':{
    if(start===end||bytes[cursor]>1)throw Error('wire sum tag');const tag=bytes[cursor++];
    if(p.kind==='option'&&tag===0){if(materialize)value={None:null};}
    else{const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,end,d+1);if(materialize)value={[label]:child};}break;
   }
   default:throw Error('unsupported wire kind');
  }
  if(cursor!==end)throw Error('trailing wire frame bytes');
  if(visitor&&(!selected||selected.has(t.name))){if(spans)visitor(t,bytes,start,end,d);else visitor(t,bytes.subarray(start,end),d);}
  return value;
 };
 const result=node(root,bytes.length,0);if(cursor!==bytes.length)throw Error('trailing wire bytes');return result;
}
export class ValueCodec{
 #hash;
 #header;
 #headerWords;
 #descriptor;
 #valuePlan;
 #compactCodec;
 #encoder;
 #decodeBound=0;
 #scanPlan=null;
 #capturePlan=null;
 #copyPlan=null;
 get descriptor(){return this.#descriptor;}
 constructor(descriptor){
  // This synchronous path is for compiler-generated immutable metadata. For
  // untrusted descriptors use createValueCodec and compare the computed identity.
  if(descriptor?.format!==valueWireFormat||!/^[0-9a-f]{64}$/.test(descriptor.identity))throw Error('invalid wire schema');
  this.#descriptor=structuredClone(descriptor);this.#hash=Uint8Array.from(descriptor.identity.match(/../g),s=>parseInt(s,16));
  this.#header=new Uint8Array(40);this.#header.set(wireMagic);this.#header.set(this.#hash,8);
  const headerView=new DataView(this.#header.buffer);this.#headerWords=Array.from({length:10},(_,i)=>headerView.getUint32(i*4,true));
  const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}};freeze(this.descriptor);this.#valuePlan=wireValuePlan(this);
 }
 resolve(t){for(let i=0;i<64;i++){if(t.kind!=='ref')return t;t=this.descriptor.named[t.name];if(!t)throw Error('wire reference');}throw Error('wire reference cycle');}
 validateValue(value,options=wireDefaultOptions){wireCheckValue(this.#valuePlan,value,wireLimits(options));return true;}
 capture(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#capturePlan??=wireCapturePlan(this.#valuePlan);return this.#capturePlan.capture(value,new WireCaptureCursor(limits),0);}
 copy(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#copyPlan??=wireCapturePlan(this.#valuePlan,false);return this.#copyPlan.capture(value,new WireCaptureCursor(limits),0);}
 compact(){return this.#compactCodec??=new CompactValueCodec(this);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new WireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.bytes(this.#header);wireEncodeValue(this.#valuePlan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new WireEncoder(options);w.bytes(wireMagic);w.bytes(this.#hash);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 scan(bytes,options=wireDefaultOptions,materialize=false,visitor=null,names=null,spans=false){
  const l=wireLimits(options);if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<44||bytes.length>l.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==this.#headerWords[i])throw Error('wire format or schema mismatch');
  if(names!==null&&(!Array.isArray(names)||names.length>100000||names.some(n=>typeof n!=='string')))throw Error('wire visitor names');
  if(materialize&&!visitor){this.#decodeBound||=wireBindDecodePlan(this.#valuePlan);const cursor=new WireDecodeCursor(bytes,view,l);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#valuePlan.decode(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  if(!materialize){this.#scanPlan??=wireScanPlan(this.#valuePlan);const cursor=new WireScanCursor(bytes,view,l,visitor,names===null?null:new Set(names),spans),value=this.#scanPlan.scan(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  return wireScanValue(this.#valuePlan,bytes,view,l,materialize,visitor,names===null?null:new Set(names),spans);
 }
 visit(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names);}
 visitSpans(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names,true);}
 validate(bytes,options=wireDefaultOptions){this.scan(bytes,options,false);return true;}
 decode(bytes,options=wireDefaultOptions){return this.scan(bytes,options,true);}
}

// Bounded forward emission avoids building and repeatedly joining child buffers.
class WireEncoder{
 #data=new Uint8Array(256);#view=new DataView(this.#data.buffer);#at=0;#remaining;#depth=0;#byteLimit;#depthLimit;
 active=false;
 constructor(options){this.reset(options);}
 reset(options){const limits=wireLimits(options);this.#byteLimit=limits.bytes;this.#depthLimit=limits.depth;this.#remaining=limits.nodes;this.#depth=0;this.#at=0;this.active=true;}
 get capacity(){return this.#data.length;}
 get position(){return this.#at;}
 beginNode(){const at=this.#at;this.word(0);return at;}
 endNode(at){this.patchWord(at,this.#at-at-4);}
 count(n){this.word(n);}
 beginCount(){const at=this.position;this.count(0);return at;}
 endCount(at,n){this.patchWord(at,n);}
 #reserve(size){
  const end=this.#at+size;if(end>this.#byteLimit)throw Error('wire byte limit');
  if(end>this.#data.length){const next=new Uint8Array(Math.min(this.#byteLimit,Math.max(end,this.#data.length*2)));next.set(this.#data.subarray(0,this.#at));this.#data=next;this.#view=new DataView(next.buffer);}
  return end;
 }
 bytes(bytes){const end=this.#reserve(bytes.length);this.#data.set(bytes,this.#at);this.#at=end;}
 byte(n){if(!Number.isInteger(n)||n<0||n>255)throw Error('wire byte range');this.#reserve(1);this.#data[this.#at++]=n;}
 word(n){if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire word range');const end=this.#reserve(4);this.#view.setUint32(this.#at,n,true);this.#at=end;}
 wide(n){if(typeof n!=='bigint'||n<0n||n>18446744073709551615n)throw Error('wire wide range');const end=this.#reserve(8);this.#view.setBigUint64(this.#at,n,true);this.#at=end;}
 text(text,count=false){
  if(typeof text!=='string')throw Error('wire Unicode');
  if(text.length<=16){
   let ascii=true;for(let i=0;i<text.length;i++)if(text.charCodeAt(i)>=128){ascii=false;break;}
   if(ascii){if(count)this.count(text.length);const end=this.#reserve(text.length);for(let i=0;i<text.length;i++)this.#data[this.#at+i]=text.charCodeAt(i);this.#at=end;return;}
  }
  if(!text.isWellFormed())throw Error('wire Unicode');const size=wireUtf8Length(text);if(count)this.count(size);
  const end=this.#reserve(size),r=wireEncoder.encodeInto(text,this.#data.subarray(this.#at,end));if(r.read!==text.length||r.written!==size)throw Error('wire UTF-8 size');this.#at=end;
 }
 patchWord(at,n){if(!Number.isInteger(at)||at<0||at+4>this.#at||!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire patch offset');this.#view.setUint32(at,n,true);}
 patchByte(at,n){if(!Number.isInteger(at)||at<0||at>=this.#at||!Number.isInteger(n)||n<0||n>255)throw Error('wire patch offset');this.#data[at]=n;}
 replace(at,removed,bytes){
  if(!Number.isInteger(at)||!Number.isInteger(removed)||at<0||removed<0||at+removed>this.#at||!(bytes instanceof Uint8Array))throw Error('wire replacement range');
  const extra=bytes.length-removed,end=extra>0?this.#reserve(extra):this.#at+extra;
  this.#data.copyWithin(at+bytes.length,at+removed,this.#at);this.#data.set(bytes,at);this.#at=end;
 }
 // Literal generated writers use balanced frames without per-node callbacks.
 // An exception abandons this invocation; encodeWith never reuses its writer.
 openFrame(){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;return at;}
 closeFrame(at){if(this.#depth===0)throw Error('wire frame boundary');this.#depth--;this.endNode(at);}
 frame(emit){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;try{emit(this);}finally{this.#depth--;}this.endNode(at);}
 reorder(start,spans){
  const sorted=spans.slice().sort((a,b)=>a[0]-b[0]);let at=start;
  for(const [a,b] of sorted){if(!Number.isInteger(a)||!Number.isInteger(b)||a!==at||b<a)throw Error('wire span permutation');at=b;}
  if(start<0||start>this.#at||at!==this.#at)throw Error('wire span permutation');
  if(spans.every((s,i)=>s===sorted[i]))return;
  const copy=this.#data.slice(start,this.#at);at=start;for(const [a,b] of spans){this.#data.set(copy.subarray(a-start,b-start),at);at+=b-a;}
 }
 finish(){if(this.#depth!==0)throw Error('wire frame boundary');return this.#data.slice(0,this.#at);}
}

class CompactWireEncoder extends WireEncoder{
 beginNode(){return 0;}
 endNode(){}
 endCount(at,n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  if(n<128){this.patchByte(at,n);return;}
  const bytes=[];while(n>=128){bytes.push(n%128+128);n=Math.floor(n/128);}bytes.push(n);this.replace(at,1,Uint8Array.from(bytes));
 }
 count(n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  while(n>=128){this.byte(n%128+128);n=Math.floor(n/128);}this.byte(n);
 }
 text(text){super.text(text,true);}
}

function compactScanValue(root,bytes,l,materialize){
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let cursor=1,remaining=l.nodes;
 const require=n=>{if(n>bytes.length-cursor)throw Error('truncated compact value');};
 const count=()=>{
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   require(1);const byte=bytes[cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }throw Error('compact count overflow');
 };
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,d)=>{
  if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type;let value;
  switch(p.kind){
   case 'unit':return null;
   case 'bool':require(1);if(bytes[cursor]>1)throw Error('invalid wire Bool');return !!bytes[cursor++];
   case 'u32':case 'i32':require(4);value=p.kind==='u32'?view.getUint32(cursor,true):view.getInt32(cursor,true);cursor+=4;return value;
   case 'f32':require(4);if(materialize)value={F32Bits:view.getUint32(cursor,true)};cursor+=4;return value;
   case 'f64':require(8);if(materialize)value={F64Bits:view.getBigUint64(cursor,true).toString()};cursor+=8;return value;
   case 'u64':require(8);if(materialize)value=view.getBigUint64(cursor,true);cursor+=8;return value;
   case 'string':case 'int':case 'id':case 'enum':{
    const n=count();require(n);const start=cursor;cursor+=n;
    if(p.kind==='string'&&!materialize){let i=start;while(i<cursor&&bytes[i]<128)i++;if(i<cursor)wireDecoder.decode(bytes.subarray(start,cursor));}
    else{const text=wireDecodeText(bytes,start,cursor);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    return value;
   }
   case 'list':case 'vector':{
    const n=count();if(n>remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,d+1);if(materialize)value.push(child);}return value;
   }
   case 'record':{
    const fs=p.fields;
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:return {};case 1:return {[fs[0].name]:node(fs[0].plan,d+1)};case 2:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1)};case 3:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1)};case 4:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1),[fs[3].name]:node(fs[3].plan,d+1)};}
    }
    if(materialize)value={};for(const f of fs){const child=node(f.plan,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}return value;
   }
   case 'option':case 'result':{
    require(1);const tag=bytes[cursor++];if(tag>1)throw Error('wire sum tag');
    if(p.kind==='option'&&tag===0)return materialize?{None:null}:undefined;
    const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,d+1);
    return materialize?{[label]:child}:undefined;
   }
   default:throw Error('unsupported wire kind');
  }
 };
 const value=node(root,0);if(cursor!==bytes.length)throw Error('trailing compact bytes');return value;
}

// General transport codec, independent of source rewrites and checkpoints.
// The sender/receiver must negotiate this exact identity and format. There is
// deliberately no claim that the bytes themselves identify their schema.
export class CompactValueCodec{
 #source;#plan;#encoder;#decodeBound=0;
 get format(){return compactValueWireFormat;}
 get identity(){return this.#source.descriptor.identity;}
 constructor(valueCodec){if(!(valueCodec instanceof ValueCodec))throw Error('compact codec requires a checked value codec');this.#source=valueCodec;this.#plan=wireValuePlan(valueCodec);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new CompactWireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.byte(1);wireEncodeValue(this.#plan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new CompactWireEncoder(options);w.byte(1);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 #scan(bytes,options,materialize){
  const l=wireLimits(options);
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<1||bytes.length>l.bytes)throw Error('wire byte limit or header');
  if(bytes[0]!==1)throw Error('compact format mismatch');
  if(materialize){this.#decodeBound||=wireBindDecodePlan(this.#plan,true);const cursor=new CompactDecodeCursor(bytes,l,this.#decodeBound);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#plan.decodeCompact(cursor,0);if(cursor.cursor!==bytes.length)throw Error('trailing compact bytes');return value;}
  return compactScanValue(this.#plan,bytes,l,materialize);
 }
 decode(bytes,options=wireDefaultOptions){return this.#scan(bytes,options,true);}
 validate(bytes,options=wireDefaultOptions){this.#scan(bytes,options,false);return true;}
}

// Compiler materialisers consume already validated bytes synchronously. This
// factory is for trusted emitted code, not untrusted descriptor/callback data.
// The complete generic validator runs before any compiler reader is invoked.
class ValidatedValueReader{
 constructor(bytes,compact){this.bytes=bytes;this.view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);this.cursor=compact?1:40;this.compact=compact;}
 frame(){if(this.compact)return 0;const end=this.cursor+4+this.view.getUint32(this.cursor,true);this.cursor+=4;return end;}
 finish(end){if(!this.compact&&this.cursor!==end)throw Error('compiled reader frame mismatch');}
 byte(){return this.bytes[this.cursor++];}
 word(){const n=this.view.getUint32(this.cursor,true);this.cursor+=4;return n;}
 signed(){const n=this.view.getInt32(this.cursor,true);this.cursor+=4;return n;}
 wide(){const n=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return n;}
 count(){if(!this.compact)return this.word();let n=0,scale=1,byte;do{byte=this.byte();n+=(byte&127)*scale;scale*=128;}while(byte>=128);return n;}
 text(end){const n=this.compact?this.count():end-this.cursor,start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
class CompiledCompactValueCodec extends CompactValueCodec{
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,true),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
}
class CompiledValueCodec extends ValueCodec{
 #read;#compiledCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,false),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
 compact(){return this.#compiledCompact??=new CompiledCompactValueCodec(this,this.#read);}
}
export function createCompiledValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new CompiledValueCodec(descriptor,read);}

// Trusted literal materialisers may use this checked reader to validate and
// construct in one traversal. The emitter must use frame/finish at every source
// node, typed text reads and counted sequence reads; arbitrary callbacks do not
// establish a schema correspondence proof. The independent scanner remains the
// validation oracle and the original factory retains its pre-validation path.
function literalValueHeader(identity){
 const bytes=new Uint8Array(40);bytes.set(wireMagic);
 for(let i=0;i<32;i++)bytes[i+8]=parseInt(identity.slice(i*2,i*2+2),16);
 const view=new DataView(bytes.buffer),words=new Uint32Array(10);
 for(let i=0;i<10;i++)words[i]=view.getUint32(i*4,true);
 return words;
}
class CheckedLiteralValueReader {
 constructor(bytes,header,compact,limits){
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<(compact?1:44)||bytes.length>limits.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  if(compact){if(bytes[0]!==1)throw Error('compact format mismatch');}
  else for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==header[i])throw Error('wire format or schema mismatch');
  this.bytes=bytes;this.view=view;
  this.cursor=compact?1:40;this.compact=compact;this.remaining=limits.nodes;this.depth=limits.depth;this.ends=[];
 }
 require(n){if(this.cursor+n>(this.ends.at(-1)??this.bytes.length))throw Error('truncated wire frame');}
 frame(){
  if(this.ends.length>this.depth||--this.remaining<0)throw Error('wire node or depth limit');
  let end=this.bytes.length;
  if(!this.compact){this.require(4);end=this.cursor+4+this.view.getUint32(this.cursor,true);this.require(end-this.cursor);this.cursor+=4;}
  this.ends.push(end);return this.compact?0:end;
 }
 finish(end){
  if(!this.ends.length||!this.compact&&(this.ends.at(-1)!==end||this.cursor!==end))throw Error('compiled reader frame mismatch');
  this.ends.pop();
 }
 byte(){this.require(1);const value=this.bytes[this.cursor++];if(value>1)throw Error('wire sum tag or Bool');return value;}
 word(){this.require(4);const value=this.view.getUint32(this.cursor,true);this.cursor+=4;return value;}
 signed(){this.require(4);const value=this.view.getInt32(this.cursor,true);this.cursor+=4;return value;}
 wide(){this.require(8);const value=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return value;}
 rawCount(){
  if(!this.compact)return this.word();
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   this.require(1);const byte=this.bytes[this.cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }
  throw Error('compact count overflow');
 }
 count(size){
  const value=this.rawCount();
  if(value>this.remaining||size!==undefined&&value!==size)throw Error('wire sequence size');
  return value;
 }
 text(end,kind='string',variants){
  const size=this.compact?this.rawCount():end-this.cursor;
  this.require(size);const start=this.cursor;this.cursor+=size;
  const value=wireDecodeText(this.bytes,start,this.cursor);
  if(kind==='int'&&!wireDecimal(value)||kind==='id'&&!/^[0-9a-f]{32}$/.test(value)||kind==='enum'&&!variants.includes(value))throw Error('malformed wire text');
  return value;
 }
 complete(){if(this.ends.length||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
// Compact source nodes have no individual frame ends: retain the same checked
// depth/node order using a counter, with bounds against the complete buffer.
class CheckedCompactLiteralValueReader extends CheckedLiteralValueReader {
 constructor(bytes,limits){super(bytes,null,true,limits);this.level=0;}
 require(n){if(this.cursor+n>this.bytes.length)throw Error('truncated wire frame');}
 frame(){if(this.level>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.level++;return 0;}
 finish(_end){if(!this.level)throw Error('compiled reader frame mismatch');this.level--;}
 complete(){if(this.level||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
class FusedCompactValueCodec extends CompactValueCodec {
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedCompactLiteralValueReader(bytes,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
}
class FusedValueCodec extends ValueCodec {
 #read;#header;#fusedCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;this.#header=literalValueHeader(this.descriptor.identity);}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedLiteralValueReader(bytes,this.#header,false,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
 compact(){return this.#fusedCompact??=new FusedCompactValueCodec(this,this.#read);}
}
export function createFusedValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new FusedValueCodec(descriptor,read);}
// JSON text is a boundary adapter to an ordinary recursive Ink datatype.
// No JavaScript Number conversion occurs for JSON numeric tokens.
export function jsonNumberToken(s){return typeof s==='string'&&/^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/.test(s);}
// JSON numeric tokens have an ASCII grammar. Check validated UTF-8 spans
// directly, preserving exact lexemes without allocating a decoded String.
function jsonNumberSpan(bytes,lo,hi){
 let at=lo;if(bytes[at]===45)at++;
 if(at>=hi)return false;
 if(bytes[at]===48)at++;
 else{if(bytes[at]<49||bytes[at]>57)return false;do{at++;}while(at<hi&&bytes[at]>=48&&bytes[at]<=57);}
 if(at<hi&&bytes[at]===46){const start=++at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 if(at<hi&&(bytes[at]===69||bytes[at]===101)){at++;if(at<hi&&(bytes[at]===43||bytes[at]===45))at++;const start=at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 return at===hi;
}
const jsonWireEncoder=new TextEncoder();
// Scalar conversion completes before writer callbacks; no per-value byte array.
const jsonFloatScratch=new DataView(new ArrayBuffer(4));
function jsonUtf8Length(text){if(text.length>16&&!/[^\x00-\x7f]/.test(text))return text.length;let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const jsonLimits={bytes:16777216,nodes:1000000,depth:128};
const jsonQuoters=new WeakSet();
/** Explicit, bounded reuse of immutable JSON string quotes. Cache payload bytes
 * are UTF-16 storage estimates; entry caps bound separate Map/object overhead.
 * Logical output budgets are charged again on every use, including cache hits.
 */
export function createJsonQuoter({maxEntries=1024,maxBytes=131072}={}){
 if(!Number.isSafeInteger(maxEntries)||maxEntries<0||maxEntries>65536||!Number.isSafeInteger(maxBytes)||maxBytes<0||maxBytes>16777216)throw Error('JSON quote cache budget');
 const entries=new Map();let bytes=0,hits=0,misses=0;
 const token=value=>{
  const prior=entries.get(value);if(prior!==undefined){hits++;return prior;}
  if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid JSON String');
  misses++;const text=JSON.stringify(value),size=2*(value.length+text.length),quoted=Object.freeze({text,utf8Bytes:jsonUtf8Length(text)});
  if(maxEntries&&size<=maxBytes){
   while(entries.size&&(entries.size>=maxEntries||bytes+size>maxBytes)){const key=entries.keys().next().value;bytes-=2*(key.length+entries.get(key).text.length);entries.delete(key);}
   entries.set(value,quoted);bytes+=size;
  }
  return quoted;
 };
 const quoter=Object.freeze({
  token,
  quote(value){return token(value).text;},
  clear(){entries.clear();bytes=0;},
  stats(){return {entries:entries.size,payload_bytes:bytes,hits,misses};},
 });jsonQuoters.add(quoter);return quoter;
}
function checkedJsonLimits(options){const l={...jsonLimits,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>jsonLimits[k])throw Error('JSON hard resource limit');return l;}
function jsonVariant(index,item){let payload=index===0?{}:{item0:item};if(index<5)payload={Ok:payload};for(let i=0;i<index;i++)payload={Err:payload};return {payload};}
export function parseJson(text,options={}){return parseJsonValue(text,options,null);}
function parseJsonValue(text,options,boundary){
 const p=new JsonWireReader(text,options);
 const value=(d,wireDepth=0)=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){boundary?.node(0,wireDepth);p.at+=4;return jsonVariant(0,null);}if(c==='t'&&text.startsWith('true',p.at)){boundary?.node(1,wireDepth);p.at+=4;return jsonVariant(1,true);}if(c==='f'&&text.startsWith('false',p.at)){boundary?.node(1,wireDepth);p.at+=5;return jsonVariant(1,false);}
  if(c==='"'){boundary?.node(3,wireDepth);const item=p.string();boundary?.text(item);return jsonVariant(3,item);}
  if(c==='['){boundary?.node(4,wireDepth);p.at++;const xs=[];if(!p.eat(']'))while(true){xs.push(value(d+1,wireDepth+8));if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}return jsonVariant(4,xs);}
  if(c==='{'){boundary?.node(5,wireDepth);p.at++;const xs=[],seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary?.member(key,wireDepth);if(!p.eat(':'))throw Error('JSON object colon');xs.push({key,value:value(d+1,wireDepth+9)});if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}return jsonVariant(5,xs);}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();boundary?.node(2,wireDepth);boundary?.text(token);return jsonVariant(2,token);}
  throw Error('invalid JSON value');
 };
 const out=value(0);p.finish();return out;
}
export function stringifyJson(value,options={}){return stringifyJsonValue(value,options,null);}
function stringifyJsonValue(value,options,boundary){
 const l=checkedJsonLimits(options);let remaining=l.nodes,bytes=0,output='';
 const emit=s=>{bytes+=jsonUtf8Length(s);if(bytes>l.bytes)throw Error('JSON byte limit');output+=s;};
 const write=(v,d,wireDepth=0)=>{
  if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');if(!v||Object.keys(v).length!==1||!Object.hasOwn(v,'payload'))throw Error('invalid JSON record');let p=v.payload,index=0;
  while(index<5&&p&&Object.hasOwn(p,'Err')){if(Object.keys(p).length!==1||boundary&&Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Err;index++;}
  if(index<5){if(!p||Object.keys(p).length!==1||!Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Ok;}
  if(!p||Object.keys(p).length!==(index===0?0:1)||index>0&&!Object.hasOwn(p,'item0'))throw Error('invalid JSON payload');const item=p.item0;boundary?.node(index,wireDepth);
  switch(index){
   case 0:emit('null');break;
   case 1:if(typeof item!=='boolean')throw Error('invalid JSON Boolean');emit(item?'true':'false');break;
   case 2:if(!jsonNumberToken(item))throw Error('invalid JSON number');boundary?.text(item);emit(item);break;
   case 3:if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary?.text(item);emit(JSON.stringify(item));break;
   case 4:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Array');const count=item.length;let visited=0;emit('[');item.forEach((x,i)=>{visited++;if(i)emit(',');write(x,d+1,wireDepth+8);});if(visited!==count)throw Error('invalid JSON Array');emit(']');break;}
   case 5:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Object');const count=item.length,seen=new Set();let visited=0;emit('{');item.forEach((m,i)=>{visited++;if(!m||Object.keys(m).length!==2||typeof m.key!=='string'||!m.key.isWellFormed()||!Object.hasOwn(m,'value')||boundary&&!Object.hasOwn(m,'key'))throw Error('invalid JSON member');if(seen.has(m.key))throw Error('duplicate JSON object key');seen.add(m.key);boundary?.member(m.key,wireDepth);if(i)emit(',');emit(JSON.stringify(m.key));emit(':');write(m.value,d+1,wireDepth+9);});if(visited!==count)throw Error('invalid JSON Object');emit('}');break;}
  }
 };write(value,0);return output;
}
// The adapter's schema is the fixed recursive JSON library shape checked by
// JsonCodec. Charge its ordinary record/sum/list wire nodes while parsing or
// rendering, rather than interpreting and walking the completed tree again.
function jsonBoundaryBudget(options){
 const l=checkedJsonLimits(options);let remaining=l.nodes,total=40;
 const charge=(nodes,bytes,depth)=>{remaining-=nodes;total+=bytes;if(remaining<0||depth>l.depth)throw Error('wire node or depth limit');if(total>l.bytes)throw Error('wire byte limit');};
 return {
  node(index,depth){charge(index===0?3:index<4?index+4:8,index===0?13:index===1?23:index===2?27:index===3?32:41,depth+(index===0?2:index<4?index+3:7));},
  text(text){charge(0,jsonUtf8Length(text),0);},
  member(key,depth){charge(2,8+jsonUtf8Length(key),depth+9);},
 };
}
function jsonSameSchema(a,b){
 if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;
 const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>Object.hasOwn(b,k)&&jsonSameSchema(a[k],b[k]));
}
// Host-object conversion is opt-in and JavaScript-only. Inspect data properties
// rather than invoking getters/toJSON; reflection is not a sandbox for proxies.
function jsonJSKeys(value){
 if(!value||typeof value!=='object')throw Error('expected a plain JavaScript object');
 const prototype=Object.getPrototypeOf(value);
 if(prototype!==Object.prototype&&prototype!==null)throw Error('expected a plain JavaScript object');
 const keys=Reflect.ownKeys(value);
 if(keys.some(k=>typeof k!=='string'))throw Error('JavaScript symbol keys are unsupported');
 return keys;
}
function jsonJSData(value,key){
 const property=Object.getOwnPropertyDescriptor(value,key);
 if(!property||!property.enumerable||!Object.hasOwn(property,'value'))throw Error('expected an enumerable own data property');
 return property.value;
}
function jsonJSRecord(value,names){
 const keys=jsonJSKeys(value);
 if(keys.length!==names.length||keys.some(k=>!names.includes(k)))throw Error('invalid JSON record or variant');
}
function jsonJSArray(value,remaining){
 if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype)throw Error('expected a plain JavaScript array');
 const length=value.length;
 if(length>remaining)throw Error('JSON node limit');
 const keys=Reflect.ownKeys(value);
 if(keys.length!==length+1||keys.some(k=>typeof k!=='string'||k!=='length'&&(!/^(0|[1-9][0-9]*)$/.test(k)||Number(k)>=length)))throw Error('sparse or decorated JavaScript arrays are unsupported');
 return length;
}
function jsonFromJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),active=new WeakSet();let remaining=limits.nodes;
 const text=value=>{if(!value.isWellFormed())throw Error('invalid JSON Unicode');boundary.text(value);return value;};
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  if(value===null){boundary.node(0,wireDepth);return jsonVariant(0);}
  switch(typeof value){
   case 'boolean':boundary.node(1,wireDepth);return jsonVariant(1,value);
   case 'string':boundary.node(3,wireDepth);return jsonVariant(3,text(value));
   case 'number':
    if(!Number.isFinite(value))throw Error('non-finite JavaScript numbers are unsupported');
    boundary.node(2,wireDepth);return jsonVariant(2,text(Object.is(value,-0)?'-0':String(value)));
   case 'bigint':boundary.node(2,wireDepth);return jsonVariant(2,text(String(value)));
   case 'object':break;
   default:throw Error('unsupported JavaScript value');
  }
  if(active.has(value))throw Error('cyclic JavaScript value');
  active.add(value);
  try{
   if(Array.isArray(value)){
    boundary.node(4,wireDepth);const count=jsonJSArray(value,remaining),items=[];
    for(let i=0;i<count;i++)items.push(visit(jsonJSData(value,String(i)),depth+1,wireDepth+8));
    return jsonVariant(4,items);
   }
   boundary.node(5,wireDepth);const keys=jsonJSKeys(value),members=[];
   if(keys.length>remaining)throw Error('JSON node limit');
   for(const key of keys){
    if(!key.isWellFormed())throw Error('invalid JSON Unicode');
    boundary.member(key,wireDepth);
    members.push({key,value:visit(jsonJSData(value,key),depth+1,wireDepth+9)});
   }
   return jsonVariant(5,members);
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
function jsonDecimalKey(token){
 const [,sign,whole,fraction='',exponent='0']=/^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(token);
 const digits=(whole+fraction).replace(/^0+/,'');
 if(!digits)return '0';
 const trimmed=digits.replace(/0+$/,'');
 return sign+trimmed+'e'+(Number(exponent)-fraction.length+digits.length-trimmed.length);
}
function jsonToJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),mode=options?.numbers??'number',active=new WeakSet();let remaining=limits.nodes;
 if(!['number','bigint','string'].includes(mode))throw Error('unknown JavaScript number policy');
 const number=token=>{
  if(!jsonNumberToken(token))throw Error('invalid JSON number');
  boundary.text(token);
  if(mode==='string')return token;
  if(mode==='bigint')return BigInt(jsonInteger(token,4096));
  const result=Number(token);
  if(!Number.isFinite(result)||jsonDecimalKey(token)!==jsonDecimalKey(String(result)))throw Error('JSON number loses precision as JavaScript Number; choose numbers: bigint or string');
  return result;
 };
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  jsonJSRecord(value,['payload']);
  if(active.has(value))throw Error('cyclic JSON value');
  active.add(value);
  try{
   let payload=jsonJSData(value,'payload'),index=0;
   while(index<5&&Object.hasOwn(payload,'Err')){jsonJSRecord(payload,['Err']);payload=jsonJSData(payload,'Err');index++;}
   if(index<5){jsonJSRecord(payload,['Ok']);payload=jsonJSData(payload,'Ok');}
   jsonJSRecord(payload,index===0?[]:['item0']);boundary.node(index,wireDepth);
   const item=index===0?null:jsonJSData(payload,'item0');
   if(index===0)return null;
   if(index===1){if(typeof item!=='boolean')throw Error('invalid JSON Boolean');return item;}
   if(index===2)return number(item);
   if(index===3){if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary.text(item);return item;}
   const count=jsonJSArray(item,remaining);
   if(index===4){const out=[];for(let i=0;i<count;i++)out.push(visit(jsonJSData(item,String(i)),depth+1,wireDepth+8));return out;}
   const out={},seen=new Set();
   for(let i=0;i<count;i++){
    const member=jsonJSData(item,String(i));jsonJSRecord(member,['key','value']);const key=jsonJSData(member,'key');
    if(typeof key!=='string'||!key.isWellFormed())throw Error('invalid JSON member key');
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary.member(key,wireDepth);
    Object.defineProperty(out,key,{value:visit(jsonJSData(member,'value'),depth+1,wireDepth+9),enumerable:true,writable:true,configurable:true});
   }
   return out;
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
const jsonConstructionPaths=Object.freeze(Array.from({length:6},(_,index)=>Object.freeze([0,...Array(index).fill(1),...(index<5?[0]:[]),0])));
function parseJsonConstructed(text,options,builder){
 const p=new JsonWireReader(text,options);
 const paths=jsonConstructionPaths;
 const fused=typeof builder.openPath==='function';
 const begin=index=>{if(fused){builder.openPath(paths[index]);return;}for(const choice of paths[index])builder.open(choice);};
 const end=index=>{for(let i=0;i<(fused?1:index<5?index+3:7);i++)builder.close();};
 const leaf=(index,item)=>{if(typeof builder.scalarPath==='function'){builder.scalarPath(paths[index],item);return;}begin(index);builder.scalar(item);end(index);};
 const value=d=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){p.at+=4;if(typeof builder.emptyPath==='function')builder.emptyPath(paths[0]);else{begin(0);end(0);}return;}
  if(c==='t'&&text.startsWith('true',p.at)){p.at+=4;leaf(1,true);return;}
  if(c==='f'&&text.startsWith('false',p.at)){p.at+=5;leaf(1,false);return;}
  if(c==='"'){leaf(3,p.string());return;}
  if(c==='['){begin(4);builder.open(0);p.at++;if(!p.eat(']'))while(true){value(d+1);if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}builder.close();end(4);return;}
  if(c==='{'){begin(5);builder.open(0);p.at++;const seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');builder.open(0);builder.scalar(key);value(d+1);builder.close();if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}builder.close();end(5);return;}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();leaf(2,token);return;}
  throw Error('invalid JSON value');
 };
 value(0);p.finish();return builder.finish();
}
const jsonCompiledRenderers=new WeakMap();
function compiledJsonRenderer(json,codec,unwrap){
 if(typeof codec?.reducer!=='function')throw Error('compiled JSON reduction unavailable');
 const source=codec.resolve(codec.descriptor.root),root=json.values.descriptor.root;
 const selected=unwrap&&source.kind==='result'?codec.resolve(source.ok):source;
 if(!jsonSameSchema(root,selected)||unwrap&&source.kind!=='result')throw Error('compiled JSON schema mismatch');
 let variants=root.fields[0].type;const roles=new Map([[root.name,'root']]);
 let member;
 for(let index=0;index<6;index++){
  const branch=index<5?variants.ok:variants;roles.set(branch.name,index);
  if(index===5){member=branch.fields[0].type.element.name;roles.set(member,'member');}
  if(index<5)variants=variants.error;
 }
 const nodeRoles=new Map();
 return codec.reducer((node,index)=>{
  const role=roles.get(node.name);nodeRoles.set(index,role);
  if(node.kind==='record'){
   if(role==='root')return value=>value;
   if(role==='member')return (key,value,context)=>{
    const text=(context.quoter?context.quote(key,true):context.add(JSON.stringify(key)+':'))+value,seen=context.members;
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);return text;
   };
   if(role===0)return context=>context.add('null');
   if(role===1)return (value,context)=>context.add(value?'true':'false');
   if(role===2)return (token,context)=>{if(!jsonNumberToken(token))throw Error('invalid JSON number');return context.add(token);};
   if(role===3)return (value,context)=>context.quoter?context.quote(value,false):context.add(JSON.stringify(value));
   if(role===4)return (value,context)=>{context.add('[]');return '['+value+']';};
   if(role===5)return (value,context)=>{context.add('{}');return '{'+value+'}';};
   return ()=>null;
  }
  if(node.kind==='list'||node.kind==='vector'){
   const members=nodeRoles.get(node.children[0])==='member';
   return {
    start:(_length,context)=>{
     const out={text:'',parent:members?context.members:null};
     if(members)context.members=new Set();return out;
    },
    step:(out,value,index,context)=>{out.text+=(index?context.add(','):'')+value;return out;},
    finish:(out,context)=>{if(members)context.members=out.parent;return out.text;},
   };
  }
  if(node.kind==='result'){
   // A Result<Json,E> boundary is explicitly requested by the caller. Ordinary
   // JSON's own sums only propagate an already rendered branch.
   if(unwrap&&nodeRoles.get(node.children[0])==='root')return (tag,value)=>{if(tag)throw Error('JSON result is Err');return value;};
   return (_tag,value)=>value;
  }
  if(node.kind==='string')return value=>{if(!value.isWellFormed())throw Error('invalid JSON String');return value;};
  return value=>value;
 });
}
export class JsonCodec{
 constructor(valueCodec){
  const root=valueCodec.descriptor.root,fields=root.fields;if(root.kind!=='record'||!Array.isArray(fields)||fields.length!==1||fields[0].name!=='payload')throw Error('JSON schema payload');let sum=fields[0].type;
  for(let i=0;i<6;i++){
   if(i<5&&sum.kind!=='result')throw Error('JSON schema sum');const branch=i<5?sum.ok:sum,fs=branch.fields;
   if(branch.kind!=='record'||!Array.isArray(fs)||fs.length!==(i?1:0)||i&&fs[0].name!=='item0')throw Error('JSON schema branch');
   if(i){const t=fs[0].type;if(i===1&&t.kind!=='bool'||(i===2||i===3)&&t.kind!=='string'||i===4&&(t.kind!=='list'||t.element.kind!=='ref'||t.element.name!==root.name))throw Error('JSON schema variant');if(i===5){const mf=t.element?.fields;if(t.kind!=='list'||t.element?.kind!=='record'||!Array.isArray(mf)||mf.length!==2||mf[0].name!=='key'||mf[0].type.kind!=='string'||mf[1].name!=='value'||mf[1].type.kind!=='ref'||mf[1].type.name!==root.name)throw Error('JSON schema member');}}
   if(i===2)this.numberBranch=branch.name;if(i===5)this.objectBranch=branch.name;
   if(i<5)sum=sum.error;
  }if(!jsonSameSchema(root,valueCodec.resolve({kind:'ref',name:root.name})))throw Error('JSON recursive schema mismatch');this.values=valueCodec;
 }
 parse(text,options={}){return parseJsonValue(text,options,jsonBoundaryBudget(options));}
 parseCompiled(codec,text,options={}){
  if(codec?.identity!==this.values.descriptor.identity||typeof codec.builder!=='function')throw Error('compiled JSON schema mismatch');
  const builder=codec.builder(options);try{return parseJsonConstructed(text,options,builder);}catch(error){builder.abort();throw error;}
 }
 stringify(value,options={}){return stringifyJsonValue(value,options,jsonBoundaryBudget(options));}
 stringifyCompiled(codec,handle,options={}){
  const limits=checkedJsonLimits(options),unwrap=options.unwrapResult===true;
  const quoter=options.quoter;if(quoter!==undefined&&!jsonQuoters.has(quoter))throw Error('JSON quote cache owner mismatch');
  let codecs=jsonCompiledRenderers.get(this);if(!codecs)jsonCompiledRenderers.set(this,codecs=new WeakMap());
  let renderers=codecs.get(codec);if(!renderers)codecs.set(codec,renderers=new Map());
  let render=renderers.get(unwrap);if(!render)renderers.set(unwrap,render=compiledJsonRenderer(this,codec,unwrap));
  let bytes=0;const context={
   quoter,
   add(text){bytes+=jsonUtf8Length(text);if(bytes>limits.bytes)throw Error('JSON byte limit');return text;},
   quote(value,colon){
    if(!quoter)return this.add(JSON.stringify(value)+(colon?':':''));
    const token=quoter.token(value);bytes+=token.utf8Bytes+(colon?1:0);if(bytes>limits.bytes)throw Error('JSON byte limit');return token.text+(colon?':':'');
   },
  };
  const text=render(handle,context,limits);
  return text;
 }
 fromJS(value,options={}){return jsonFromJS(value,options);}
 toJS(value,options={}){return jsonToJS(value,options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,false);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,false,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,true);}
 validateBinary(bytes,options={}){
  const decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});let view;
  this.values.visitSpans(bytes,(type,data,start,end)=>{
   view??=new DataView(data.buffer,data.byteOffset,data.byteLength);
   if(type.name===this.numberBranch){const length=view.getUint32(start,true);if(!jsonNumberSpan(data,start+4,start+4+length))throw Error('invalid JSON number token');}
   if(type.name===this.objectBranch){const listEnd=start+4+view.getUint32(start,true),count=view.getUint32(start+4,true),seen=new Set();let at=start+8;for(let i=0;i<count;i++){const memberEnd=at+4+view.getUint32(at,true),keyStart=at+8,keyEnd=keyStart+view.getUint32(at+4,true),key=decoder.decode(data.subarray(keyStart,keyEnd));if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);at=memberEnd;}if(at!==listEnd)throw Error('invalid JSON object frame');}
  },options,[this.numberBranch,this.objectBranch]);return true;

 }
}
function jsonUnpack(value){let p=value.payload,i=0;while(i<5&&Object.hasOwn(p,'Err')){p=p.Err;i++;}return [i,(i<5?p.Ok:p).item0];}
function jsonInteger(token,limit){
 if(!jsonNumberToken(token))throw Error('invalid JSON number');const negative=token[0]==='-',raw=negative?token.slice(1):token,[mantissa,exp='0']=raw.split(/[eE]/);let digits=mantissa.replace('.','');if(/^0+$/.test(digits))return '0';const exponent=Number(exp),fraction=mantissa.includes('.')?mantissa.length-mantissa.indexOf('.')-1:0,shift=exponent-fraction;
 if(!Number.isSafeInteger(exponent)||!Number.isSafeInteger(shift))throw Error('JSON integer exponent limit');
 if(shift<0){const cut=-shift;if(cut>=digits.length||!/^[0]+$/.test(digits.slice(-cut)))throw Error('JSON number is not an integer');digits=digits.slice(0,-cut);}else{if(digits.length+shift>limit)throw Error('JSON integer magnitude limit');digits+='0'.repeat(shift);}
 digits=digits.replace(/^0+/,'');if(digits.length>limit)throw Error('JSON integer magnitude limit');return (negative?'-':'')+digits;
}
function jsonBinary64Value(v){
 if(typeof v==='number')return v;
 const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid F64Bits');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');
 const b=new DataView(new ArrayBuffer(8));b.setBigUint64(0,bits,true);return b.getFloat64(0,true);
}
export class TypedJsonCodec{
 constructor(valueCodec){this.values=valueCodec;}
 decode(document,options={}){
  // Validate JSON-specific invariants before interpreting any tagged/record
  // shape, including duplicated names and malformed numeric tokens.
  stringifyJson(document,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const read=(type,value,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type),[kind,item]=jsonUnpack(value);const fail=()=>{throw Error('JSON does not match '+t.kind);};
   switch(t.kind){
    case 'unit':if(kind!==0)fail();return null;
    case 'bool':if(kind!==1)fail();return item;
    case 'u32':case 'u64':case 'i32':case 'int':{if(kind!==2)fail();const text=jsonInteger(item,t.kind==='int'?4096:t.kind==='u64'?20:10);return t.kind==='int'?{Int:text}:t.kind==='u64'?BigInt(text):Number(text);}
    case 'f64':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(8));if(!Number.isFinite(n))throw Error('JSON f64 overflow');b.setFloat64(0,n,true);return {F64Bits:b.getBigUint64(0,true).toString()};}
    case 'f32':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(4));b.setFloat32(0,n,true);if(!Number.isFinite(b.getFloat32(0,true)))throw Error('JSON f32 overflow');return {F32Bits:b.getUint32(0,true)};}
    case 'string':case 'enum':case 'id':if(kind!==3)fail();return item;
    case 'list':case 'vector':if(kind!==4)fail();return item.map(x=>read(t.element,x,d+1));
    case 'record':{if(kind!==5||item.length!==t.fields.length)throw Error('unknown or missing JSON record field');const fields=new Map(item.map(m=>[m.key,m.value])),out={};for(const f of t.fields){if(!fields.has(f.name))throw Error('missing JSON record field');Object.defineProperty(out,f.name,{value:read(f.type,fields.get(f.name),d+1),writable:true,enumerable:true,configurable:true});}return out;}
    case 'option':case 'result':{if(kind!==5||item.length!==1)fail();const m=item[0];if(t.kind==='option'&&m.key==='None'&&jsonUnpack(m.value)[0]===0)return {None:null};const child=t.kind==='option'&&m.key==='Some'?t.element:t.kind==='result'&&m.key==='Ok'?t.ok:t.kind==='result'&&m.key==='Err'?t.error:null;if(!child)fail();return {[m.key]:read(child,m.value,d+1)};}
    default:fail();
   }
  };
  const out=read(this.values.descriptor.root,document,0);this.values.validateValue(out,options);return out;
 }
 encode(value,options={}){
  this.values.validateValue(value,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const write=(type,v,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type);
   switch(t.kind){
    case 'unit':return jsonVariant(0);
    case 'bool':return jsonVariant(1,v);
    case 'u32':case 'u64':case 'i32':return jsonVariant(2,String(v));
    case 'int':return jsonVariant(2,typeof v==='bigint'?String(v):v.Int);
    case 'f64':{const n=jsonBinary64Value(v);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'f32':{let n;if(typeof v==='number')n=Math.fround(v);else{const b=new DataView(new ArrayBuffer(4));b.setUint32(0,v.F32Bits,true);n=b.getFloat32(0,true);}if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'string':case 'id':case 'enum':return jsonVariant(3,v);
    case 'list':case 'vector':return jsonVariant(4,Array.from(v,x=>write(t.element,x,d+1)));
    case 'record':return jsonVariant(5,t.fields.map(f=>({key:f.name,value:write(f.type,v[f.name],d+1)})));
    case 'option':return jsonVariant(5,[Object.hasOwn(v,'Some')?{key:'Some',value:write(t.element,v.Some,d+1)}:{key:'None',value:jsonVariant(0)}]);
    case 'result':return jsonVariant(5,[Object.hasOwn(v,'Ok')?{key:'Ok',value:write(t.ok,v.Ok,d+1)}:{key:'Err',value:write(t.error,v.Err,d+1)}]);
    default:throw Error('unsupported typed JSON descriptor');
   }
  };return write(this.values.descriptor.root,value,0);
 }
 parse(text,options={}){return this.decode(parseJson(text,options),options);}
 stringify(value,options={}){return stringifyJson(this.encode(value,options),options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,true);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,true,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,false);}
}

// Token reader shared by schema-directed and arbitrary-JSON wire emission.
class JsonWireReader{
 constructor(text,options){this.l=checkedJsonLimits(options);if(typeof text!=='string'||!text.isWellFormed()||text.length>this.l.bytes||jsonUtf8Length(text)>this.l.bytes)throw Error('JSON byte or Unicode limit');this.text=text;this.at=0;this.remaining=this.l.nodes;}
 ws(){while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(c!==32&&c!==9&&c!==10&&c!==13)break;this.at++;}}
 peek(){this.ws();return this.text[this.at];}
 eat(c){this.ws();if(this.text[this.at]===c){this.at++;return true;}return false;}
 node(d){if(d>this.l.depth||--this.remaining<0)throw Error('JSON node or depth limit');}
 string(){
  this.ws();const start=this.at;if(this.text[start]!=='"')throw Error('expected JSON string');
  const end=this.text.indexOf('"',start+1);if(end<0)throw Error('unterminated JSON string');
  const raw=this.text.slice(start+1,end);
  if(!raw.includes('\\')&&!/[\x00-\x1f]/.test(raw)){this.at=end+1;return raw;}
  this.at=start+1;while(this.at<this.text.length){if(this.text[this.at]==='"'){this.at++;const v=JSON.parse(this.text.slice(start,this.at));if(!v.isWellFormed())throw Error('invalid JSON Unicode');return v;}if(this.text[this.at]==='\\')this.at+=2;else this.at++;}throw Error('unterminated JSON string');
 }
 number(){const start=this.at;while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(!(c>=48&&c<=57||c===45||c===43||c===46||c===101||c===69))break;this.at++;}const token=this.text.slice(start,this.at);if(!jsonNumberToken(token))throw Error('invalid JSON number');return token;}
 leaf(d){this.node(d);const c=this.peek();if(c==='n'&&this.text.startsWith('null',this.at)){this.at+=4;return null;}if(c==='t'&&this.text.startsWith('true',this.at)){this.at+=4;return true;}if(c==='f'&&this.text.startsWith('false',this.at)){this.at+=5;return false;}if(c==='"')return this.string();if(c==='-'||c>='0'&&c<='9')return this.number();throw Error('invalid JSON scalar');}
 finish(){this.ws();if(this.at!==this.text.length)throw Error('trailing JSON text');}
}
function streamJsonBinary(values,text,options,typed,compact=false){
 const p=new JsonWireReader(text,options),utf8=jsonWireEncoder;
 const list=(w,open,close,item)=>{if(!p.eat(open))throw Error('JSON container shape');const at=w.beginCount();let count=0;if(!p.eat(close))while(true){item(w);count++;if(p.eat(close))break;if(!p.eat(','))throw Error('JSON container separator');}w.endCount(at,count);};
 const variant=(w,index,level,emit)=>{if(level<index)w.frame(w=>{w.byte(1);variant(w,index,level+1,emit);});else if(index<5)w.frame(w=>{w.byte(0);w.frame(emit);});else w.frame(emit);};
 const json=(w,d)=>{
  const ch=p.peek(),index=ch==='n'?0:ch==='t'||ch==='f'?1:ch==='-'||ch>='0'&&ch<='9'?2:ch==='"'?3:ch==='['?4:ch==='{'?5:-1;if(index<0)throw Error('invalid JSON value');
  const leaf=index<4?p.leaf(d):null;if(index>=4)p.node(d);
  w.frame(w=>variant(w,index,0,w=>{
   if(index===0)return;if(index===1){w.frame(w=>w.byte(+leaf));return;}
   if(index===2||index===3){w.frame(w=>w.text(leaf));return;}
   w.frame(w=>{if(index===4)list(w,'[',']',w=>json(w,d+1));else{const seen=new Set();list(w,'{','}',w=>{const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');w.frame(w=>{w.frame(w=>w.text(key));json(w,d+1);});});}});
  }));
 };
 const read=(type,w,d)=>{
  const t=values.resolve(type);w.frame(w=>{
   if(t.kind==='list'||t.kind==='vector'){p.node(d);list(w,'[',']',w=>read(t.element,w,d+1));return;}
   if(t.kind==='record'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON record');const start=w.position,spans=new Array(t.fields.length).fill(null);
    if(!p.eat('}'))while(true){const key=p.string(),i=t.fields.findIndex(f=>f.name===key);if(i<0)throw Error('unknown JSON record field');if(spans[i])throw Error('duplicate JSON record field');if(!p.eat(':'))throw Error('JSON record colon');const at=w.position;read(t.fields[i].type,w,d+1);spans[i]=[at,w.position];if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON record separator');}
    if(spans.some(s=>s===null))throw Error('missing JSON record field');w.reorder(start,spans);return;
   }
   if(t.kind==='option'||t.kind==='result'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON tagged value');const key=p.string();if(!p.eat(':'))throw Error('JSON tag colon');
    if(t.kind==='option'&&key==='None'){if(p.leaf(d+1)!==null)throw Error('JSON None payload');w.byte(0);}
    else{const child=t.kind==='option'&&key==='Some'?t.element:t.kind==='result'&&key==='Ok'?t.ok:t.kind==='result'&&key==='Err'?t.error:null;if(!child)throw Error('invalid JSON tag');w.byte(key==='Ok'?0:1);read(child,w,d+1);}
    if(!p.eat('}'))throw Error('expected exactly one JSON tag');return;
   }
   const ch=p.peek(),v=p.leaf(d),bad=()=>{throw Error('JSON does not match '+t.kind);};
   if(t.kind==='unit'){if(v!==null)bad();return;}
   if(t.kind==='bool'){if(typeof v!=='boolean')bad();w.byte(+v);return;}
   if(['string','id','enum'].includes(t.kind)){if(ch!=='"')bad();w.text(v);return;}
   if(ch!=='-'&&!(ch>='0'&&ch<='9'))bad();
   if(t.kind==='int'){w.text(jsonInteger(v,4096));return;}
   if(t.kind==='f64'){const n=Number(v);if(!Number.isFinite(n))throw Error('JSON f64 overflow');const b=new DataView(new ArrayBuffer(8));b.setFloat64(0,n,true);w.wide(b.getBigUint64(0,true));}
   else if(t.kind==='f32'){jsonFloatScratch.setFloat32(0,Number(v),true);if(!Number.isFinite(jsonFloatScratch.getFloat32(0,true)))throw Error('JSON f32 overflow');w.word(jsonFloatScratch.getUint32(0,true));}
   else{const n=BigInt(jsonInteger(v,t.kind==='u64'?20:10));if(t.kind==='u64'){if(n<0n||n>18446744073709551615n)bad();w.wide(n);}else if(t.kind==='u32'){if(n<0n||n>4294967295n)bad();w.word(Number(n));}else if(t.kind==='i32'){if(n< -2147483648n||n>2147483647n)bad();w.word(Number(n)>>>0);}else bad();}
  });
 };
 return (compact?values.compact():values).encodeWith(w=>{if(typed)read(values.descriptor.root,w,0);else json(w,0);p.finish();},options);
}

// Render validated bytes in a single traversal; only the final text is owned.
function streamWireJsonText(values,bytes,options,library){
 values.validate(bytes,options);const l=checkedJsonLimits(options),parts=[];let size=0,remaining=l.nodes;const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 const emit=s=>{size+=jsonUtf8Length(s);if(size>l.bytes)throw Error('JSON byte limit');parts.push(s);};
 const string=s=>emit(JSON.stringify(s));const node=d=>{if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');};
 const frame=(type,at)=>{const t=values.resolve(type),start=at+4,end=start+dv.getUint32(at,true);return{t,start,end};};
 const json=(type,at,d)=>{
  node(d);let root=frame(type,at),sum=frame(root.t.fields[0].type,root.start),index=0;
  while(index<5){const err=bytes[sum.start];sum=frame(err?sum.t.error:sum.t.ok,sum.start+1);if(!err)break;index++;}
  if(index===0){emit('null');return root.end;}
  const item=frame(sum.t.fields[0].type,sum.start);
  if(index===1)emit(bytes[item.start]?'true':'false');
  else if(index===2){const token=decoder.decode(bytes.subarray(item.start,item.end));if(!jsonNumberToken(token))throw Error('invalid JSON number token');emit(token);}
  else if(index===3)string(decoder.decode(bytes.subarray(item.start,item.end)));
  else{const count=dv.getUint32(item.start,true);let p=item.start+4;emit(index===4?'[':'{');const seen=new Set();for(let i=0;i<count;i++){if(i)emit(',');if(index===4)p=json(item.t.element,p,d+1);else{const member=frame(item.t.element,p),key=frame(member.t.fields[0].type,member.start),name=decoder.decode(bytes.subarray(key.start,key.end));if(seen.has(name))throw Error('duplicate JSON object key');seen.add(name);string(name);emit(':');json(member.t.fields[1].type,key.end,d+1);p=member.end;}}emit(index===4?']':'}');}
  return root.end;
 };
 const typed=(type,at,d)=>{
  node(d);const f=frame(type,at),t=f.t;let p=f.start;
  switch(t.kind){
   case 'unit':emit('null');break;
   case 'bool':emit(bytes[p]?'true':'false');break;
   case 'u32':emit(String(dv.getUint32(p,true)));break;
   case 'u64':emit(String(dv.getBigUint64(p,true)));break;
   case 'i32':emit(String(dv.getInt32(p,true)));break;
   case 'f64':{const n=dv.getFloat64(p,true);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'f32':{const n=dv.getFloat32(p,true);if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'int':emit(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'string':case 'id':case 'enum':string(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'list':case 'vector':{const n=dv.getUint32(p,true);p+=4;emit('[');for(let i=0;i<n;i++){if(i)emit(',');p=typed(t.element,p,d+1);}emit(']');break;}
   case 'record':emit('{');for(let i=0;i<t.fields.length;i++){if(i)emit(',');const field=t.fields[i];string(field.name);emit(':');p=typed(field.type,p,d+1);}emit('}');break;
   case 'option':case 'result':{const tag=bytes[p++],key=t.kind==='option'?(tag?'Some':'None'):tag?'Err':'Ok';emit('{');string(key);emit(':');if(t.kind==='option'&&!tag){node(d+1);emit('null');}else typed(t.kind==='option'?t.element:tag?t.error:t.ok,p,d+1);emit('}');break;}
   default:throw Error('unsupported typed JSON descriptor');
  }return f.end;
 };
 if(library)json(values.descriptor.root,40,0);else typed(values.descriptor.root,40,0);return parts.join('');
}

/** Owned, optional read view of arbitrary JSON. Auxiliary indexes contain member
 * offsets only. Logical order, exact number tokens and missing/null remain intact.
 * This does not transparently replace any compiled Ink action or its state.
 */
export function createJsonLookup(text,{stepEntries=16,minReads=4,maxEntries=4096,maxObjects=64,maxIndexBytes=262144,...limits}={}){
 for(const [v,max]of [[stepEntries,4096],[minReads,1000000],[maxEntries,1000000],[maxObjects,256],[maxIndexBytes,16777216]])if(!Number.isSafeInteger(v)||v<0||v>max)throw Error('JSON index budget');
 let root=parseJson(text,limits),indexes=new Map(),entries=0,indexBytes=0;
 const stats={reads:0,writes:0,scanned_members:0,index_hits:0,built_entries:0,invalidations:0};
 function parts(path){
  if(!Array.isArray(path))throw Error('JSON lookup path');const n=path.length;if(n>128)throw Error('JSON lookup path');
  const owned=[];for(let i=0;i<n;i++){const d=Object.getOwnPropertyDescriptor(path,String(i));if(!d||!Object.hasOwn(d,'value'))throw Error('JSON lookup path');const p=d.value;if(!(typeof p==='string'&&p.isWellFormed()&&p.length<=4096)&&!(Number.isSafeInteger(p)&&p>=0))throw Error('JSON lookup path');owned.push(p);}return owned;
 }
 function variant(value){let p=value.payload,index=0;while(index<5&&Object.hasOwn(p,'Err')){p=p.Err;index++;}return {index,item:(index<5?p.Ok:p).item0};}
 function resolve(document,path,indexed){
  let value=document,budget=stepEntries;
  for(let depth=0;depth<path.length;depth++){
   const part=path[depth],v=variant(value);
   if(typeof part==='number'){
    if(v.index!==4)throw Error('expected JSON array');if(part>=v.item.length)return {found:false};value=v.item[part];continue;
   }
   if(v.index!==5)throw Error('expected JSON object');
   const prefix=path.slice(0,depth),key=JSON.stringify(prefix),overhead=128+prefix.reduce((n,p)=>n+(typeof p==='string'?16+p.length*2:8),0);let idx=indexed?indexes.get(key):null;
   if(indexed&&!idx&&indexes.size<maxObjects&&indexBytes+overhead<=maxIndexBytes){idx={path:prefix,reads:0,cursor:0,keys:new Map(),bytes:overhead};indexes.set(key,idx);indexBytes+=overhead;}
   if(idx){
    idx.reads++;
    if(idx.reads>=minReads)while(budget>0&&idx.cursor<v.item.length&&entries<maxEntries){
     const member=v.item[idx.cursor],bytes=64+member.key.length*2;
     if(indexBytes+bytes>maxIndexBytes)break;
     idx.keys.set(member.key,idx.cursor++);idx.bytes+=bytes;indexBytes+=bytes;entries++;stats.built_entries++;budget--;
    }
    if(idx.keys.has(part)){stats.index_hits++;value=v.item[idx.keys.get(part)].value;continue;}
   }
   let found=false;
   for(let i=idx?.cursor??0;i<v.item.length;i++){if(indexed)stats.scanned_members++;if(v.item[i].key===part){value=v.item[i].value;found=true;break;}}
   if(!found)return {found:false};
  }
  return {found:true,value};
 }
 return {
  lookup(path){stats.reads++;const r=resolve(root,parts(path),true);return r.found?{found:true,value:structuredClone(r.value)}:r;},
  set(path,key,text){
   path=parts(path);if(typeof key!=='string'||!key.isWellFormed())throw Error('JSON object key');
   const replacement=parseJson(text,limits),next=structuredClone(root),r=resolve(next,path,false);
   if(!r.found)throw Error('JSON update path missing');const object=variant(r.value);if(object.index!==5)throw Error('expected JSON object');
   const members=[{key,value:replacement},...object.item.filter(m=>m.key!==key)];
   // Validate the complete resulting document before publishing a write.
   let payload=r.value.payload;for(let i=0;i<5;i++)payload=payload.Err;payload.item0=members;
   stringifyJson(next,limits);root=next;stats.writes++;
   for(const [id,idx]of indexes)if(idx.path.length>=path.length&&path.every((p,i)=>p===idx.path[i])){entries-=idx.keys.size;indexBytes-=idx.bytes;indexes.delete(id);stats.invalidations++;}
  },
  replace(text){const next=parseJson(text,limits);root=next;stats.writes++;stats.invalidations+=indexes.size;indexes.clear();entries=0;indexBytes=0;},
  stringify(){return stringifyJson(root,limits);},
  stats(){return {...stats,index_entries:entries,index_objects:indexes.size,index_bytes:indexBytes};}
 };
}
function __ownedValue9(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__ownedValue7(value.Some,budget,depth+1)};}
function __ownedValue7(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue8(value[i],budget,depth+1);return out;}
function __ownedValue8(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__ownedValue3(value.Some,budget,depth+1)};}
function __ownedValue13(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue14(value[i],budget,depth+1);return out;}
function __ownedValue21(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__ownedValue14(value.Some,budget,depth+1)};}
function __ownedValue22(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue23(value[i],budget,depth+1);return out;}
function __ownedValue3(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue4(value[i],budget,depth+1);return out;}
function __ownedValue5(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue6(value[i],budget,depth+1);return out;}
function __ownedValue26(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__ownedValue6(value.Some,budget,depth+1)};}
function __ownedValue12(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue13(value.Ok,budget,depth+1)}:{Err:__ownedValue10(value.Err,budget,depth+1)};}
function __ownedValue20(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue21(value.Ok,budget,depth+1)}:{Err:__ownedValue10(value.Err,budget,depth+1)};}
function __ownedValue0(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue1(value.Ok,budget,depth+1)}:{Err:__ownedValue10(value.Err,budget,depth+1)};}
function __ownedValue18(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue19(value.Ok,budget,depth+1)}:{Err:__ownedValue10(value.Err,budget,depth+1)};}
function __ownedValue16(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue17(value.Ok,budget,depth+1)}:{Err:__ownedValue10(value.Err,budget,depth+1)};}
function __ownedValue11(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue6(value.Ok,budget,depth+1)}:{Err:__ownedValue10(value.Err,budget,depth+1)};}
function __ownedValue30(value,budget,depth){budget.enter(depth,4);return {["count"]:__ownedValue31(value["count"],budget,depth+1),["index"]:__ownedValue6(value["index"],budget,depth+1)};}
function __ownedValue29(value,budget,depth){budget.enter(depth,4);return {["cursor"]:__ownedValue15(value["cursor"],budget,depth+1),["stats"]:__ownedValue17(value["stats"],budget,depth+1),["done"]:__ownedValue24(value["done"],budget,depth+1)};}
function __ownedValue1(value,budget,depth){budget.enter(depth,4);return {["data"]:__ownedValue2(value["data"],budget,depth+1),["epsilon"]:__ownedValue4(value["epsilon"],budget,depth+1),["budget"]:__ownedValue6(value["budget"],budget,depth+1)};}
function __ownedValue27(value,budget,depth){budget.enter(depth,4);return {["index"]:__ownedValue6(value["index"],budget,depth+1),["width"]:__ownedValue4(value["width"],budget,depth+1),["done"]:__ownedValue24(value["done"],budget,depth+1)};}
function __ownedValue28(value,budget,depth){budget.enter(depth,4);return {["index"]:__ownedValue6(value["index"],budget,depth+1),["width"]:__ownedValue4(value["width"],budget,depth+1),["trimmed"]:__ownedValue4(value["trimmed"],budget,depth+1),["end"]:__ownedValue15(value["end"],budget,depth+1),["result"]:__ownedValue4(value["result"],budget,depth+1),["done"]:__ownedValue24(value["done"],budget,depth+1)};}
function __ownedValue19(value,budget,depth){budget.enter(depth,4);return {["lineCount"]:__ownedValue6(value["lineCount"],budget,depth+1),["height"]:__ownedValue4(value["height"],budget,depth+1)};}
function __ownedValue17(value,budget,depth){budget.enter(depth,4);return {["lineCount"]:__ownedValue6(value["lineCount"],budget,depth+1),["maxLineWidth"]:__ownedValue4(value["maxLineWidth"],budget,depth+1)};}
function __ownedValue31(value,budget,depth){budget.enter(depth,4);return {["lines"]:__ownedValue6(value["lines"],budget,depth+1),["width"]:__ownedValue4(value["width"],budget,depth+1),["content"]:__ownedValue24(value["content"],budget,depth+1)};}
function __ownedValue15(value,budget,depth){budget.enter(depth,4);return {["segment"]:__ownedValue6(value["segment"],budget,depth+1),["grapheme"]:__ownedValue6(value["grapheme"],budget,depth+1)};}
function __ownedValue25(value,budget,depth){budget.enter(depth,4);return {["valid"]:__ownedValue24(value["valid"],budget,depth+1),["budget"]:__ownedValue6(value["budget"],budget,depth+1),["index"]:__ownedValue6(value["index"],budget,depth+1)};}
function __ownedValue14(value,budget,depth){budget.enter(depth,4);return {["width"]:__ownedValue4(value["width"],budget,depth+1),["start"]:__ownedValue15(value["start"],budget,depth+1),["end"]:__ownedValue15(value["end"],budget,depth+1)};}
function __ownedValue2(value,budget,depth){budget.enter(depth,4);return {["widths"]:__ownedValue3(value["widths"],budget,depth+1),["flags"]:__ownedValue5(value["flags"],budget,depth+1),["advances"]:__ownedValue7(value["advances"],budget,depth+1),["startExtras"]:__ownedValue8(value["startExtras"],budget,depth+1),["graphemeStartExtras"]:__ownedValue9(value["graphemeStartExtras"],budget,depth+1),["endTrims"]:__ownedValue8(value["endTrims"],budget,depth+1),["overflowTrims"]:__ownedValue8(value["overflowTrims"],budget,depth+1),["insideExtras"]:__ownedValue8(value["insideExtras"],budget,depth+1),["fillExtras"]:__ownedValue8(value["fillExtras"],budget,depth+1)};}
function __ownedValue24(value,budget,depth){budget.enter(depth,5);return value;}
function __ownedValue23(value,budget,depth){budget.enter(depth,8);return {F32Bits:value===0?0:value};}
function __ownedValue4(value,budget,depth){budget.enter(depth,12);return {F64Bits:__dfBits(value).toString()};}
function __ownedValue10(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __ownedValue6(value,budget,depth){budget.enter(depth,8);return value>>>0;}
const __ownedFunctions=Object.freeze(Object.fromEntries([["prepare",__ownedValue0],["count_lines",__ownedValue11],["lines",__ownedValue12],["stats",__ownedValue16],["layout",__ownedValue18],["line",__ownedValue20],["count_prepared",__ownedValue11],["numeric",__ownedValue22],["ink_maa2ffc47f94a1df1e2b1982bb687b3b95ea1f18c3d31e5270249eb9a5b1b8987",__ownedValue4],["ink_m1cbd9e6f220b01cc6d3614d0b500ae6ae7fb6bc6b3ccb0fd24ba416e435dec02",__ownedValue8],["ink_ma9923eba3cdcc3be4bd5eec9937c55f89cb7af34eade1f02c02bde46b444755d",__ownedValue6],["ink_mf2da1ccb63323de619308b515afc2e8427fa422cacc3b9e180896d7c1933a5db",__ownedValue24],["ink_mf3fd6a8edcedf12678ee0135d258e53818da29f98901e4823c5b5fa68a8742b5",__ownedValue24],["ink_m4871d371876b879fe17454f848676f99047b70dcf533553abf657eccb48917a5",__ownedValue24],["ink_m3e5801892156affa301b1de70c5499a6f98c8ab08ce4a11d6064687eaff81e63",__ownedValue24],["ink_m1035a47a3beb1fd15b77187a225faf4374da04d4239c2bb5f2fd7f377c9105f8",__ownedValue25],["ink_mb4277fe25fdfb0e134f990b04d6baa626119984e30cca8da242f327fd2871a58",__ownedValue26],["ink_mc1df4b06d386435afd93c2deb158f576ca1a0b8da5cc9ddac9804cbbd5aaed55",__ownedValue0],["ink_md45fb160f95b90ffa06f2e883a8e13e6cfb6f48c9e504c758674212aaaafed13",__ownedValue24],["ink_m79fbd33ce445d81b5495367bea54ed582eb29a97df1560f52a1db7c4538eabd4",__ownedValue4],["ink_m403c4c47e84eda8d792b1109de53fbbc655e214636da67f4e0bec47ffe157b0e",__ownedValue4],["ink_m693a1ebd0432f205eabdd53caaf1bb1ac592d434476d44639419d5b63ab48e45",__ownedValue15],["ink_m746b7ebe9bcb715eb063c9a8acdc48ed10dd67c3ac1ab355ca08a8a31f2e076a",__ownedValue27],["ink_m424a73c98abd59df2df2e9558114156f29b349d1a0fc567d6a7b6991fa96d4e4",__ownedValue28],["ink_m0fffc1496f6a8b2b8d7044034bab3436a5bf8d98c9b26163ffc110ef18eb690f",__ownedValue14],["ink_m3ec56d96554edff8dcbc70dd4746c1467d14cccdd680a05225aecdcb1ff10585",__ownedValue20],["ink_m031320cee58f85b79b37202fff6fd536ad71ab758d2d465493cd48cefb302021",__ownedValue29],["ink_m618e3b1ce3d206a7ce99ecd61dc5909f8327679e73d0e9cd3a60a1c006ce85b8",__ownedValue17],["ink_me3e1d6802e8b8c99257eae2c70e1c73b81194a7b49cd49c1aadcbcf5fb61a373",__ownedValue16],["ink_m1c643c3729ce33889b175f6534c6f5567e1031f9a2294b31f14214ef5d846f7e",__ownedValue12],["ink_m61a3849a7a6ebf0fe028d8fa87a1a3eaa6166a2532387000b50e461faa1b2899",__ownedValue27],["ink_m09bd2f6d807dddea08a3e05dff926c97158dd5c78fbcec8971733d58e03c9fbf",__ownedValue30],["ink_mdb420bacbaded3bd4a47c64a08eab41bd49e5a1eb00a06f5fb4216055764e14f",__ownedValue31],["ink_m5a18484940b2f87721d94e036b20f3f623fd9a7ef0bbb105d497073a418c96f6",__ownedValue11],["ink_mf92f9e487553a051acda291cdf01e6ab1ad3a5254dd3d94587ad2b797d8dea28",__ownedValue18]]));
function __wireValue8(reader){const end=reader.frame();const value=reader.byte()?{Some:__wireValue6(reader)}:{None:null};reader.finish(end);return value;}
function __wireValue6(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue7(reader);reader.finish(end);return value;}
function __wireValue7(reader){const end=reader.frame();const value=reader.byte()?{Some:__wireValue2(reader)}:{None:null};reader.finish(end);return value;}
function __wireValue27(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue22(reader);reader.finish(end);return value;}
function __wireValue31(reader){const end=reader.frame();const value=reader.byte()?{Some:__wireValue22(reader)}:{None:null};reader.finish(end);return value;}
function __wireValue53(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue54(reader);reader.finish(end);return value;}
function __wireValue2(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue3(reader);reader.finish(end);return value;}
function __wireValue4(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue5(reader);reader.finish(end);return value;}
function __wireValue41(reader){const end=reader.frame();const value=reader.byte()?{Some:__wireValue5(reader)}:{None:null};reader.finish(end);return value;}
function __wireValue26(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue10(reader)}:{Ok:__wireValue27(reader)};reader.finish(end);return value;}
function __wireValue30(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue10(reader)}:{Ok:__wireValue31(reader)};reader.finish(end);return value;}
function __wireValue42(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue10(reader)}:{Ok:__wireValue12(reader)};reader.finish(end);return value;}
function __wireValue48(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue10(reader)}:{Ok:__wireValue49(reader)};reader.finish(end);return value;}
function __wireValue45(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue10(reader)}:{Ok:__wireValue16(reader)};reader.finish(end);return value;}
function __wireValue9(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue10(reader)}:{Ok:__wireValue5(reader)};reader.finish(end);return value;}
function __wireValue19(reader){const end=reader.frame();const value={["count"]:__wireValue20(reader),["index"]:__wireValue5(reader)};reader.finish(end);return value;}
function __wireValue14(reader){const end=reader.frame();const value={["cursor"]:__wireValue15(reader),["stats"]:__wireValue16(reader),["done"]:__wireValue17(reader)};reader.finish(end);return value;}
function __wireValue37(reader){const end=reader.frame();const value={["d"]:__wireValue1(reader),["c"]:__wireValue15(reader)};reader.finish(end);return value;}
function __wireValue40(reader){const end=reader.frame();const value={["d"]:__wireValue1(reader),["epsilon"]:__wireValue3(reader),["maximum"]:__wireValue5(reader)};reader.finish(end);return value;}
function __wireValue44(reader){const end=reader.frame();const value={["d"]:__wireValue1(reader),["fit"]:__wireValue3(reader),["i"]:__wireValue5(reader),["s"]:__wireValue20(reader)};reader.finish(end);return value;}
function __wireValue32(reader){const end=reader.frame();const value={["d"]:__wireValue1(reader),["fit"]:__wireValue3(reader),["s"]:__wireValue33(reader)};reader.finish(end);return value;}
function __wireValue46(reader){const end=reader.frame();const value={["d"]:__wireValue1(reader),["i"]:__wireValue5(reader),["atStart"]:__wireValue17(reader)};reader.finish(end);return value;}
function __wireValue28(reader){const end=reader.frame();const value={["d"]:__wireValue1(reader),["i"]:__wireValue5(reader)};reader.finish(end);return value;}
function __wireValue23(reader){const end=reader.frame();const value={["d"]:__wireValue1(reader),["maximum"]:__wireValue5(reader),["advance"]:__wireValue7(reader),["s"]:__wireValue24(reader)};reader.finish(end);return value;}
function __wireValue12(reader){const end=reader.frame();const value={["data"]:__wireValue1(reader),["epsilon"]:__wireValue3(reader),["budget"]:__wireValue5(reader)};reader.finish(end);return value;}
function __wireValue51(reader){const end=reader.frame();const value={["data"]:__wireValue1(reader),["epsilon"]:__wireValue3(reader),["cursor"]:__wireValue15(reader),["width"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue55(reader){const end=reader.frame();const value={["data"]:__wireValue1(reader),["epsilon"]:__wireValue3(reader),["maximum"]:__wireValue5(reader)};reader.finish(end);return value;}
function __wireValue50(reader){const end=reader.frame();const value={["data"]:__wireValue1(reader),["epsilon"]:__wireValue3(reader),["width"]:__wireValue3(reader),["lineHeight"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue0(reader){const end=reader.frame();const value={["data"]:__wireValue1(reader),["epsilon"]:__wireValue3(reader),["width"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue36(reader){const end=reader.frame();const value={["index"]:__wireValue5(reader),["width"]:__wireValue3(reader),["done"]:__wireValue17(reader)};reader.finish(end);return value;}
function __wireValue33(reader){const end=reader.frame();const value={["index"]:__wireValue5(reader),["width"]:__wireValue3(reader),["trimmed"]:__wireValue3(reader),["end"]:__wireValue15(reader),["result"]:__wireValue3(reader),["done"]:__wireValue17(reader)};reader.finish(end);return value;}
function __wireValue49(reader){const end=reader.frame();const value={["lineCount"]:__wireValue5(reader),["height"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue16(reader){const end=reader.frame();const value={["lineCount"]:__wireValue5(reader),["maxLineWidth"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue20(reader){const end=reader.frame();const value={["lines"]:__wireValue5(reader),["width"]:__wireValue3(reader),["content"]:__wireValue17(reader)};reader.finish(end);return value;}
function __wireValue21(reader){const end=reader.frame();const value={["p"]:__wireValue12(reader),["c"]:__wireValue15(reader),["width"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue47(reader){const end=reader.frame();const value={["p"]:__wireValue12(reader),["width"]:__wireValue3(reader),["lineHeight"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue13(reader){const end=reader.frame();const value={["p"]:__wireValue12(reader),["width"]:__wireValue3(reader),["w"]:__wireValue14(reader)};reader.finish(end);return value;}
function __wireValue25(reader){const end=reader.frame();const value={["p"]:__wireValue12(reader),["width"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue43(reader){const end=reader.frame();const value={["p"]:__wireValue12(reader)};reader.finish(end);return value;}
function __wireValue11(reader){const end=reader.frame();const value={["prepared"]:__wireValue12(reader),["width"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue15(reader){const end=reader.frame();const value={["segment"]:__wireValue5(reader),["grapheme"]:__wireValue5(reader)};reader.finish(end);return value;}
function __wireValue24(reader){const end=reader.frame();const value={["valid"]:__wireValue17(reader),["budget"]:__wireValue5(reader),["index"]:__wireValue5(reader)};reader.finish(end);return value;}
function __wireValue22(reader){const end=reader.frame();const value={["width"]:__wireValue3(reader),["start"]:__wireValue15(reader),["end"]:__wireValue15(reader)};reader.finish(end);return value;}
function __wireValue38(reader){const end=reader.frame();const value={["width"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue1(reader){const end=reader.frame();const value={["widths"]:__wireValue2(reader),["flags"]:__wireValue4(reader),["advances"]:__wireValue6(reader),["startExtras"]:__wireValue7(reader),["graphemeStartExtras"]:__wireValue8(reader),["endTrims"]:__wireValue7(reader),["overflowTrims"]:__wireValue7(reader),["insideExtras"]:__wireValue7(reader),["fillExtras"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue39(reader){const end=reader.frame();const value={["xs"]:__wireValue7(reader),["i"]:__wireValue5(reader)};reader.finish(end);return value;}
function __wireValue29(reader){const end=reader.frame();const value={["xs"]:__wireValue7(reader),["n"]:__wireValue5(reader)};reader.finish(end);return value;}
function __wireValue52(reader){const end=reader.frame();const value={["xs"]:__wireValue53(reader)};reader.finish(end);return value;}
function __wireValue18(reader){const end=reader.frame();const value={["xs"]:__wireValue2(reader),["es"]:__wireValue7(reader),["fit"]:__wireValue3(reader),["s"]:__wireValue19(reader)};reader.finish(end);return value;}
function __wireValue35(reader){const end=reader.frame();const value={["xs"]:__wireValue2(reader),["start"]:__wireValue5(reader),["width"]:__wireValue3(reader),["fit"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue34(reader){const end=reader.frame();const value={["xs"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue17(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __wireValue54(reader){const end=reader.frame();const value={F32Bits:reader.word()};reader.finish(end);return value;}
function __wireValue3(reader){const end=reader.frame();const value={F64Bits:reader.wide().toString()};reader.finish(end);return value;}
function __wireValue10(reader){const end=reader.frame();const value=reader.text(end,"string");reader.finish(end);return value;}
function __wireValue5(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
const __wireReaders=Object.freeze(Object.fromEntries([["count_lines",[__wireValue0,__wireValue9]],["count_prepared",[__wireValue11,__wireValue9]],["ink_m031320cee58f85b79b37202fff6fd536ad71ab758d2d465493cd48cefb302021",[__wireValue13,__wireValue14]],["ink_m09bd2f6d807dddea08a3e05dff926c97158dd5c78fbcec8971733d58e03c9fbf",[__wireValue18,__wireValue19]],["ink_m0fffc1496f6a8b2b8d7044034bab3436a5bf8d98c9b26163ffc110ef18eb690f",[__wireValue21,__wireValue22]],["ink_m1035a47a3beb1fd15b77187a225faf4374da04d4239c2bb5f2fd7f377c9105f8",[__wireValue23,__wireValue24]],["ink_m1c643c3729ce33889b175f6534c6f5567e1031f9a2294b31f14214ef5d846f7e",[__wireValue25,__wireValue26]],["ink_m1cbd9e6f220b01cc6d3614d0b500ae6ae7fb6bc6b3ccb0fd24ba416e435dec02",[__wireValue28,__wireValue7]],["ink_m3e5801892156affa301b1de70c5499a6f98c8ab08ce4a11d6064687eaff81e63",[__wireValue29,__wireValue17]],["ink_m3ec56d96554edff8dcbc70dd4746c1467d14cccdd680a05225aecdcb1ff10585",[__wireValue21,__wireValue30]],["ink_m403c4c47e84eda8d792b1109de53fbbc655e214636da67f4e0bec47ffe157b0e",[__wireValue25,__wireValue3]],["ink_m424a73c98abd59df2df2e9558114156f29b349d1a0fc567d6a7b6991fa96d4e4",[__wireValue32,__wireValue33]],["ink_m4871d371876b879fe17454f848676f99047b70dcf533553abf657eccb48917a5",[__wireValue34,__wireValue17]],["ink_m5a18484940b2f87721d94e036b20f3f623fd9a7ef0bbb105d497073a418c96f6",[__wireValue25,__wireValue9]],["ink_m618e3b1ce3d206a7ce99ecd61dc5909f8327679e73d0e9cd3a60a1c006ce85b8",[__wireValue25,__wireValue16]],["ink_m61a3849a7a6ebf0fe028d8fa87a1a3eaa6166a2532387000b50e461faa1b2899",[__wireValue35,__wireValue36]],["ink_m693a1ebd0432f205eabdd53caaf1bb1ac592d434476d44639419d5b63ab48e45",[__wireValue37,__wireValue15]],["ink_m746b7ebe9bcb715eb063c9a8acdc48ed10dd67c3ac1ab355ca08a8a31f2e076a",[__wireValue35,__wireValue36]],["ink_m79fbd33ce445d81b5495367bea54ed582eb29a97df1560f52a1db7c4538eabd4",[__wireValue38,__wireValue3]],["ink_ma9923eba3cdcc3be4bd5eec9937c55f89cb7af34eade1f02c02bde46b444755d",[__wireValue28,__wireValue5]],["ink_maa2ffc47f94a1df1e2b1982bb687b3b95ea1f18c3d31e5270249eb9a5b1b8987",[__wireValue39,__wireValue3]],["ink_mb4277fe25fdfb0e134f990b04d6baa626119984e30cca8da242f327fd2871a58",[__wireValue40,__wireValue41]],["ink_mc1df4b06d386435afd93c2deb158f576ca1a0b8da5cc9ddac9804cbbd5aaed55",[__wireValue40,__wireValue42]],["ink_md45fb160f95b90ffa06f2e883a8e13e6cfb6f48c9e504c758674212aaaafed13",[__wireValue43,__wireValue17]],["ink_mdb420bacbaded3bd4a47c64a08eab41bd49e5a1eb00a06f5fb4216055764e14f",[__wireValue44,__wireValue20]],["ink_me3e1d6802e8b8c99257eae2c70e1c73b81194a7b49cd49c1aadcbcf5fb61a373",[__wireValue25,__wireValue45]],["ink_mf2da1ccb63323de619308b515afc2e8427fa422cacc3b9e180896d7c1933a5db",[__wireValue46,__wireValue17]],["ink_mf3fd6a8edcedf12678ee0135d258e53818da29f98901e4823c5b5fa68a8742b5",[__wireValue28,__wireValue17]],["ink_mf92f9e487553a051acda291cdf01e6ab1ad3a5254dd3d94587ad2b797d8dea28",[__wireValue47,__wireValue48]],["layout",[__wireValue50,__wireValue48]],["line",[__wireValue51,__wireValue30]],["lines",[__wireValue0,__wireValue26]],["numeric",[__wireValue52,__wireValue53]],["prepare",[__wireValue55,__wireValue42]],["stats",[__wireValue0,__wireValue45]]]));

const __ownedImplementations=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>{
 const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
 const body=__implementations[f.index];
 const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
 return [f.name,input.every(c=>c===__identity)?implementation:(...args)=>{const context=new WeakMap();return implementation(...args.map((v,i)=>input[i](v,context)));}];
})));

export const valueCodecs=(()=>{const codecs={};for(const [name,s] of Object.entries(metadata.wire.functions)){if(s.unsupported)continue;let value;Object.defineProperty(codecs,name,{enumerable:true,get:()=>value??=(Object.freeze(Object.hasOwn(__wireReaders,name)?{arguments:createCompiledValueCodec(s.arguments,__wireReaders[name][0]),result:createCompiledValueCodec(s.result,__wireReaders[name][1])}:{arguments:new ValueCodec(s.arguments),result:new ValueCodec(s.result)}))});}return Object.freeze(codecs);})();
function __callEncoded(name,bytes,limits,compact){
 const f=metadata.functions.find(f=>f.name===name&&!f.internal),codecs=valueCodecs[name];
 if(!f||!codecs)throw Error('unsupported binary function');
 const input=compact?codecs.arguments.compact():codecs.arguments,output=compact?codecs.result.compact():codecs.result;
 const entry=__compiledEntries.get(name);
 if(entry){
  const slot=compact?1:0;
  entry.argumentCodecs[slot]??=(entry.boundaryReaders[slot]?createFusedValueCodec:createCompiledValueCodec)(metadata.wire.functions[name].arguments,entry.arguments);
  const decoder=entry.argumentCodecs[slot];
  const values=(compact?decoder.compact():decoder).decode(bytes,limits),args=f.params.map(p=>values[p.name]);
  if(entry.precondition!==null&&__implementations[entry.precondition](...args)!==true)throw Error('contract precondition failed');
  return __compiledEncodeResult(entry,__implementations[entry.index](...args),limits,compact);
 }
 const values=input.decode(bytes,limits);
 const result=call(name,f.params.map(p=>values[p.name]));
 return output.encode(result,limits);
}
export function callBinary(name,bytes,limits={}){return __callEncoded(name,bytes,limits,false);}
export function callCompact(name,bytes,limits={}){return __callEncoded(name,bytes,limits,true);}
// Same stable, well-typed caller inputs as call; the result owns every container.
// The checked source return type justifies trusted copying, not arbitrary input.
export function callOwned(name,args,limits={}){
 if(!Object.hasOwn(__ownedFunctions,name)||!Object.hasOwn(functions,name))throw Error('unsupported owned function');
 const result=__ownedImplementations[name](...args);return __ownedFunctions[name](result,createValueCaptureBudget(limits),0);
}
function __privateCapture7(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if((value!==null&&typeof value==='object'&&Object.hasOwn(value,'None')&&Object.keys(value).length===1)&&value.None===null)return {None:null};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Some')&&Object.keys(value).length===1)return {Some:__privateCapture5(value.Some,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture5(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture6(value[i],budget,depth+1);return out;}
function __privateCapture6(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if((value!==null&&typeof value==='object'&&Object.hasOwn(value,'None')&&Object.keys(value).length===1)&&value.None===null)return {None:null};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Some')&&Object.keys(value).length===1)return {Some:__privateCapture1(value.Some,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture13(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture14(value[i],budget,depth+1);return out;}
function __privateCapture21(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if((value!==null&&typeof value==='object'&&Object.hasOwn(value,'None')&&Object.keys(value).length===1)&&value.None===null)return {None:null};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Some')&&Object.keys(value).length===1)return {Some:__privateCapture14(value.Some,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture22(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture23(value[i],budget,depth+1);return out;}
function __privateCapture1(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture2(value[i],budget,depth+1);return out;}
function __privateCapture3(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture4(value[i],budget,depth+1);return out;}
function __privateCapture26(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if((value!==null&&typeof value==='object'&&Object.hasOwn(value,'None')&&Object.keys(value).length===1)&&value.None===null)return {None:null};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Some')&&Object.keys(value).length===1)return {Some:__privateCapture4(value.Some,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture12(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture13(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture10(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture20(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture21(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture10(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture8(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture9(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture10(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture18(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture19(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture10(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture16(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture17(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture10(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture11(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture4(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture10(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture30(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"count")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"index")){throw Error('invalid value for wire schema');}return {["count"]:__privateCapture31(value["count"],budget,depth+1),["index"]:__privateCapture4(value["index"],budget,depth+1)};}
function __privateCapture29(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==3){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"cursor")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"stats")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"done")){throw Error('invalid value for wire schema');}return {["cursor"]:__privateCapture15(value["cursor"],budget,depth+1),["stats"]:__privateCapture17(value["stats"],budget,depth+1),["done"]:__privateCapture24(value["done"],budget,depth+1)};}
function __privateCapture9(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==3){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"data")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"epsilon")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"budget")){throw Error('invalid value for wire schema');}return {["data"]:__privateCapture0(value["data"],budget,depth+1),["epsilon"]:__privateCapture2(value["epsilon"],budget,depth+1),["budget"]:__privateCapture4(value["budget"],budget,depth+1)};}
function __privateCapture27(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==3){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"index")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"width")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"done")){throw Error('invalid value for wire schema');}return {["index"]:__privateCapture4(value["index"],budget,depth+1),["width"]:__privateCapture2(value["width"],budget,depth+1),["done"]:__privateCapture24(value["done"],budget,depth+1)};}
function __privateCapture28(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"index")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"width")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"trimmed")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"end")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"result")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"done")){throw Error('invalid value for wire schema');}return {["index"]:__privateCapture4(value["index"],budget,depth+1),["width"]:__privateCapture2(value["width"],budget,depth+1),["trimmed"]:__privateCapture2(value["trimmed"],budget,depth+1),["end"]:__privateCapture15(value["end"],budget,depth+1),["result"]:__privateCapture2(value["result"],budget,depth+1),["done"]:__privateCapture24(value["done"],budget,depth+1)};}
function __privateCapture19(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"lineCount")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"height")){throw Error('invalid value for wire schema');}return {["lineCount"]:__privateCapture4(value["lineCount"],budget,depth+1),["height"]:__privateCapture2(value["height"],budget,depth+1)};}
function __privateCapture17(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"lineCount")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"maxLineWidth")){throw Error('invalid value for wire schema');}return {["lineCount"]:__privateCapture4(value["lineCount"],budget,depth+1),["maxLineWidth"]:__privateCapture2(value["maxLineWidth"],budget,depth+1)};}
function __privateCapture31(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==3){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"lines")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"width")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"content")){throw Error('invalid value for wire schema');}return {["lines"]:__privateCapture4(value["lines"],budget,depth+1),["width"]:__privateCapture2(value["width"],budget,depth+1),["content"]:__privateCapture24(value["content"],budget,depth+1)};}
function __privateCapture15(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"segment")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"grapheme")){throw Error('invalid value for wire schema');}return {["segment"]:__privateCapture4(value["segment"],budget,depth+1),["grapheme"]:__privateCapture4(value["grapheme"],budget,depth+1)};}
function __privateCapture25(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==3){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"valid")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"budget")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"index")){throw Error('invalid value for wire schema');}return {["valid"]:__privateCapture24(value["valid"],budget,depth+1),["budget"]:__privateCapture4(value["budget"],budget,depth+1),["index"]:__privateCapture4(value["index"],budget,depth+1)};}
function __privateCapture14(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==3){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"width")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"start")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"end")){throw Error('invalid value for wire schema');}return {["width"]:__privateCapture2(value["width"],budget,depth+1),["start"]:__privateCapture15(value["start"],budget,depth+1),["end"]:__privateCapture15(value["end"],budget,depth+1)};}
function __privateCapture0(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==9){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"widths")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"flags")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"advances")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"startExtras")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"graphemeStartExtras")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"endTrims")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"overflowTrims")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"insideExtras")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"fillExtras")){throw Error('invalid value for wire schema');}return {["widths"]:__privateCapture1(value["widths"],budget,depth+1),["flags"]:__privateCapture3(value["flags"],budget,depth+1),["advances"]:__privateCapture5(value["advances"],budget,depth+1),["startExtras"]:__privateCapture6(value["startExtras"],budget,depth+1),["graphemeStartExtras"]:__privateCapture7(value["graphemeStartExtras"],budget,depth+1),["endTrims"]:__privateCapture6(value["endTrims"],budget,depth+1),["overflowTrims"]:__privateCapture6(value["overflowTrims"],budget,depth+1),["insideExtras"]:__privateCapture6(value["insideExtras"],budget,depth+1),["fillExtras"]:__privateCapture6(value["fillExtras"],budget,depth+1)};}
function __privateCapture24(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='boolean'){throw Error('invalid value for wire schema');}budget.add(1);return value;}
function __privateCapture23(value,budget,depth=0){budget.enter(depth,4);let bits;if(typeof value==='number'&&Number.isFinite(value)){bits=__bits(value);if(!Number.isFinite(__float(bits))){throw Error('invalid value for wire schema');}}else{if(!(value!==null&&typeof value==='object'&&Object.hasOwn(value,'F32Bits')&&Object.keys(value).length===1)){throw Error('invalid value for wire schema');}bits=value.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295){throw Error('invalid value for wire schema');}}budget.add(4);return bits===0?0:bits;}
function __privateCapture2(value,budget,depth=0){budget.enter(depth,4);const result=__dfCapture(value);budget.add(8);return result;}
function __privateCapture10(value,budget,depth=0){budget.enter(depth,4);const text=value;if(typeof text!=='string'||!text.isWellFormed()||text.length>budget.limit){throw Error('invalid value for wire schema');}budget.text(text);return text;}
function __privateCapture4(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='number'||!Number.isInteger(value)||value<0||value>4294967295){throw Error('invalid value for wire schema');}budget.add(4);return value===0?0:value;}
function __privateWireValue7(reader){const end=reader.frame();const value=reader.byte()?{Some:__privateWireValue5(reader)}:{None:null};reader.finish(end);return value;}
function __privateWireValue5(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue6(reader);reader.finish(end);return value;}
function __privateWireValue6(reader){const end=reader.frame();const value=reader.byte()?{Some:__privateWireValue1(reader)}:{None:null};reader.finish(end);return value;}
function __privateWireValue15(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue16(reader);reader.finish(end);return value;}
function __privateWireValue24(reader){const end=reader.frame();const value=reader.byte()?{Some:__privateWireValue16(reader)}:{None:null};reader.finish(end);return value;}
function __privateWireValue27(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue28(reader);reader.finish(end);return value;}
function __privateWireValue1(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue2(reader);reader.finish(end);return value;}
function __privateWireValue3(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue4(reader);reader.finish(end);return value;}
function __privateWireValue38(reader){const end=reader.frame();const value=reader.byte()?{Some:__privateWireValue4(reader)}:{None:null};reader.finish(end);return value;}
function __privateWireValue14(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue10(reader)}:{Ok:__privateWireValue15(reader)};reader.finish(end);return value;}
function __privateWireValue23(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue10(reader)}:{Ok:__privateWireValue24(reader)};reader.finish(end);return value;}
function __privateWireValue8(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue10(reader)}:{Ok:__privateWireValue9(reader)};reader.finish(end);return value;}
function __privateWireValue20(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue10(reader)}:{Ok:__privateWireValue21(reader)};reader.finish(end);return value;}
function __privateWireValue18(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue10(reader)}:{Ok:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue12(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue10(reader)}:{Ok:__privateWireValue4(reader)};reader.finish(end);return value;}
function __privateWireValue51(reader){const end=reader.frame();const value={["count"]:__privateWireValue52(reader),["index"]:__privateWireValue4(reader)};reader.finish(end);return value;}
function __privateWireValue49(reader){const end=reader.frame();const value={["cursor"]:__privateWireValue17(reader),["stats"]:__privateWireValue19(reader),["done"]:__privateWireValue32(reader)};reader.finish(end);return value;}
function __privateWireValue43(reader){const end=reader.frame();const value={["d"]:__privateWireValue0(reader),["c"]:__privateWireValue17(reader)};reader.finish(end);return value;}
function __privateWireValue39(reader){const end=reader.frame();const value={["d"]:__privateWireValue0(reader),["epsilon"]:__privateWireValue2(reader),["maximum"]:__privateWireValue4(reader)};reader.finish(end);return value;}
function __privateWireValue54(reader){const end=reader.frame();const value={["d"]:__privateWireValue0(reader),["fit"]:__privateWireValue2(reader),["i"]:__privateWireValue4(reader),["s"]:__privateWireValue52(reader)};reader.finish(end);return value;}
function __privateWireValue47(reader){const end=reader.frame();const value={["d"]:__privateWireValue0(reader),["fit"]:__privateWireValue2(reader),["s"]:__privateWireValue46(reader)};reader.finish(end);return value;}
function __privateWireValue33(reader){const end=reader.frame();const value={["d"]:__privateWireValue0(reader),["i"]:__privateWireValue4(reader),["atStart"]:__privateWireValue32(reader)};reader.finish(end);return value;}
function __privateWireValue31(reader){const end=reader.frame();const value={["d"]:__privateWireValue0(reader),["i"]:__privateWireValue4(reader)};reader.finish(end);return value;}
function __privateWireValue37(reader){const end=reader.frame();const value={["d"]:__privateWireValue0(reader),["maximum"]:__privateWireValue4(reader),["advance"]:__privateWireValue6(reader),["s"]:__privateWireValue36(reader)};reader.finish(end);return value;}
function __privateWireValue9(reader){const end=reader.frame();const value={["data"]:__privateWireValue0(reader),["epsilon"]:__privateWireValue2(reader),["budget"]:__privateWireValue4(reader)};reader.finish(end);return value;}
function __privateWireValue25(reader){const end=reader.frame();const value={["data"]:__privateWireValue0(reader),["epsilon"]:__privateWireValue2(reader),["cursor"]:__privateWireValue17(reader),["width"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue11(reader){const end=reader.frame();const value={["data"]:__privateWireValue0(reader),["epsilon"]:__privateWireValue2(reader),["maximum"]:__privateWireValue4(reader)};reader.finish(end);return value;}
function __privateWireValue22(reader){const end=reader.frame();const value={["data"]:__privateWireValue0(reader),["epsilon"]:__privateWireValue2(reader),["width"]:__privateWireValue2(reader),["lineHeight"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue13(reader){const end=reader.frame();const value={["data"]:__privateWireValue0(reader),["epsilon"]:__privateWireValue2(reader),["width"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue44(reader){const end=reader.frame();const value={["index"]:__privateWireValue4(reader),["width"]:__privateWireValue2(reader),["done"]:__privateWireValue32(reader)};reader.finish(end);return value;}
function __privateWireValue46(reader){const end=reader.frame();const value={["index"]:__privateWireValue4(reader),["width"]:__privateWireValue2(reader),["trimmed"]:__privateWireValue2(reader),["end"]:__privateWireValue17(reader),["result"]:__privateWireValue2(reader),["done"]:__privateWireValue32(reader)};reader.finish(end);return value;}
function __privateWireValue21(reader){const end=reader.frame();const value={["lineCount"]:__privateWireValue4(reader),["height"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue19(reader){const end=reader.frame();const value={["lineCount"]:__privateWireValue4(reader),["maxLineWidth"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue52(reader){const end=reader.frame();const value={["lines"]:__privateWireValue4(reader),["width"]:__privateWireValue2(reader),["content"]:__privateWireValue32(reader)};reader.finish(end);return value;}
function __privateWireValue48(reader){const end=reader.frame();const value={["p"]:__privateWireValue9(reader),["c"]:__privateWireValue17(reader),["width"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue55(reader){const end=reader.frame();const value={["p"]:__privateWireValue9(reader),["width"]:__privateWireValue2(reader),["lineHeight"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue50(reader){const end=reader.frame();const value={["p"]:__privateWireValue9(reader),["width"]:__privateWireValue2(reader),["w"]:__privateWireValue49(reader)};reader.finish(end);return value;}
function __privateWireValue42(reader){const end=reader.frame();const value={["p"]:__privateWireValue9(reader),["width"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue40(reader){const end=reader.frame();const value={["p"]:__privateWireValue9(reader)};reader.finish(end);return value;}
function __privateWireValue26(reader){const end=reader.frame();const value={["prepared"]:__privateWireValue9(reader),["width"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue17(reader){const end=reader.frame();const value={["segment"]:__privateWireValue4(reader),["grapheme"]:__privateWireValue4(reader)};reader.finish(end);return value;}
function __privateWireValue36(reader){const end=reader.frame();const value={["valid"]:__privateWireValue32(reader),["budget"]:__privateWireValue4(reader),["index"]:__privateWireValue4(reader)};reader.finish(end);return value;}
function __privateWireValue16(reader){const end=reader.frame();const value={["width"]:__privateWireValue2(reader),["start"]:__privateWireValue17(reader),["end"]:__privateWireValue17(reader)};reader.finish(end);return value;}
function __privateWireValue41(reader){const end=reader.frame();const value={["width"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue0(reader){const end=reader.frame();const value={["widths"]:__privateWireValue1(reader),["flags"]:__privateWireValue3(reader),["advances"]:__privateWireValue5(reader),["startExtras"]:__privateWireValue6(reader),["graphemeStartExtras"]:__privateWireValue7(reader),["endTrims"]:__privateWireValue6(reader),["overflowTrims"]:__privateWireValue6(reader),["insideExtras"]:__privateWireValue6(reader),["fillExtras"]:__privateWireValue6(reader)};reader.finish(end);return value;}
function __privateWireValue30(reader){const end=reader.frame();const value={["xs"]:__privateWireValue6(reader),["i"]:__privateWireValue4(reader)};reader.finish(end);return value;}
function __privateWireValue35(reader){const end=reader.frame();const value={["xs"]:__privateWireValue6(reader),["n"]:__privateWireValue4(reader)};reader.finish(end);return value;}
function __privateWireValue29(reader){const end=reader.frame();const value={["xs"]:__privateWireValue27(reader)};reader.finish(end);return value;}
function __privateWireValue53(reader){const end=reader.frame();const value={["xs"]:__privateWireValue1(reader),["es"]:__privateWireValue6(reader),["fit"]:__privateWireValue2(reader),["s"]:__privateWireValue51(reader)};reader.finish(end);return value;}
function __privateWireValue45(reader){const end=reader.frame();const value={["xs"]:__privateWireValue1(reader),["start"]:__privateWireValue4(reader),["width"]:__privateWireValue2(reader),["fit"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue34(reader){const end=reader.frame();const value={["xs"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue32(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __privateWireValue28(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __privateWireValue2(reader){const end=reader.frame();const value=__dfFromBits(reader.wide());reader.finish(end);return value;}
function __privateWireValue10(reader){const end=reader.frame();const value=reader.text(end,"string");reader.finish(end);return value;}
function __privateWireValue4(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __compiledOwnedValue7(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__compiledOwnedValue5(value.Some,budget,depth+1)};}
function __compiledOwnedValue5(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue6(value[i],budget,depth+1);return out;}
function __compiledOwnedValue6(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__compiledOwnedValue1(value.Some,budget,depth+1)};}
function __compiledOwnedValue13(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue14(value[i],budget,depth+1);return out;}
function __compiledOwnedValue21(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__compiledOwnedValue14(value.Some,budget,depth+1)};}
function __compiledOwnedValue22(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue23(value[i],budget,depth+1);return out;}
function __compiledOwnedValue1(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue2(value[i],budget,depth+1);return out;}
function __compiledOwnedValue3(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue4(value[i],budget,depth+1);return out;}
function __compiledOwnedValue26(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__compiledOwnedValue4(value.Some,budget,depth+1)};}
function __compiledOwnedValue12(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue13(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue10(value.Err,budget,depth+1)};}
function __compiledOwnedValue20(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue21(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue10(value.Err,budget,depth+1)};}
function __compiledOwnedValue8(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue9(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue10(value.Err,budget,depth+1)};}
function __compiledOwnedValue18(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue19(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue10(value.Err,budget,depth+1)};}
function __compiledOwnedValue16(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue17(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue10(value.Err,budget,depth+1)};}
function __compiledOwnedValue11(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue4(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue10(value.Err,budget,depth+1)};}
function __compiledOwnedValue30(value,budget,depth){budget.enter(depth,4);return {["count"]:__compiledOwnedValue31(value["count"],budget,depth+1),["index"]:__compiledOwnedValue4(value["index"],budget,depth+1)};}
function __compiledOwnedValue29(value,budget,depth){budget.enter(depth,4);return {["cursor"]:__compiledOwnedValue15(value["cursor"],budget,depth+1),["stats"]:__compiledOwnedValue17(value["stats"],budget,depth+1),["done"]:__compiledOwnedValue24(value["done"],budget,depth+1)};}
function __compiledOwnedValue9(value,budget,depth){budget.enter(depth,4);return {["data"]:__compiledOwnedValue0(value["data"],budget,depth+1),["epsilon"]:__compiledOwnedValue2(value["epsilon"],budget,depth+1),["budget"]:__compiledOwnedValue4(value["budget"],budget,depth+1)};}
function __compiledOwnedValue27(value,budget,depth){budget.enter(depth,4);return {["index"]:__compiledOwnedValue4(value["index"],budget,depth+1),["width"]:__compiledOwnedValue2(value["width"],budget,depth+1),["done"]:__compiledOwnedValue24(value["done"],budget,depth+1)};}
function __compiledOwnedValue28(value,budget,depth){budget.enter(depth,4);return {["index"]:__compiledOwnedValue4(value["index"],budget,depth+1),["width"]:__compiledOwnedValue2(value["width"],budget,depth+1),["trimmed"]:__compiledOwnedValue2(value["trimmed"],budget,depth+1),["end"]:__compiledOwnedValue15(value["end"],budget,depth+1),["result"]:__compiledOwnedValue2(value["result"],budget,depth+1),["done"]:__compiledOwnedValue24(value["done"],budget,depth+1)};}
function __compiledOwnedValue19(value,budget,depth){budget.enter(depth,4);return {["lineCount"]:__compiledOwnedValue4(value["lineCount"],budget,depth+1),["height"]:__compiledOwnedValue2(value["height"],budget,depth+1)};}
function __compiledOwnedValue17(value,budget,depth){budget.enter(depth,4);return {["lineCount"]:__compiledOwnedValue4(value["lineCount"],budget,depth+1),["maxLineWidth"]:__compiledOwnedValue2(value["maxLineWidth"],budget,depth+1)};}
function __compiledOwnedValue31(value,budget,depth){budget.enter(depth,4);return {["lines"]:__compiledOwnedValue4(value["lines"],budget,depth+1),["width"]:__compiledOwnedValue2(value["width"],budget,depth+1),["content"]:__compiledOwnedValue24(value["content"],budget,depth+1)};}
function __compiledOwnedValue15(value,budget,depth){budget.enter(depth,4);return {["segment"]:__compiledOwnedValue4(value["segment"],budget,depth+1),["grapheme"]:__compiledOwnedValue4(value["grapheme"],budget,depth+1)};}
function __compiledOwnedValue25(value,budget,depth){budget.enter(depth,4);return {["valid"]:__compiledOwnedValue24(value["valid"],budget,depth+1),["budget"]:__compiledOwnedValue4(value["budget"],budget,depth+1),["index"]:__compiledOwnedValue4(value["index"],budget,depth+1)};}
function __compiledOwnedValue14(value,budget,depth){budget.enter(depth,4);return {["width"]:__compiledOwnedValue2(value["width"],budget,depth+1),["start"]:__compiledOwnedValue15(value["start"],budget,depth+1),["end"]:__compiledOwnedValue15(value["end"],budget,depth+1)};}
function __compiledOwnedValue0(value,budget,depth){budget.enter(depth,4);return {["widths"]:__compiledOwnedValue1(value["widths"],budget,depth+1),["flags"]:__compiledOwnedValue3(value["flags"],budget,depth+1),["advances"]:__compiledOwnedValue5(value["advances"],budget,depth+1),["startExtras"]:__compiledOwnedValue6(value["startExtras"],budget,depth+1),["graphemeStartExtras"]:__compiledOwnedValue7(value["graphemeStartExtras"],budget,depth+1),["endTrims"]:__compiledOwnedValue6(value["endTrims"],budget,depth+1),["overflowTrims"]:__compiledOwnedValue6(value["overflowTrims"],budget,depth+1),["insideExtras"]:__compiledOwnedValue6(value["insideExtras"],budget,depth+1),["fillExtras"]:__compiledOwnedValue6(value["fillExtras"],budget,depth+1)};}
function __compiledOwnedValue24(value,budget,depth){budget.enter(depth,5);return value;}
function __compiledOwnedValue23(value,budget,depth){budget.enter(depth,8);return {F32Bits:value===0?0:value};}
function __compiledOwnedValue2(value,budget,depth){budget.enter(depth,12);return {F64Bits:__dfBits(value).toString()};}
function __compiledOwnedValue10(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __compiledOwnedValue4(value,budget,depth){budget.enter(depth,8);return value>>>0;}
function __privateWireWrite7(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Some')){writer.byte(1);__privateWireWrite5(writer,value.Some,compact);}else{writer.byte(0);}writer.closeFrame(frame);}
function __privateWireWrite5(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite6(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite6(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Some')){writer.byte(1);__privateWireWrite1(writer,value.Some,compact);}else{writer.byte(0);}writer.closeFrame(frame);}
function __privateWireWrite13(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite14(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite21(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Some')){writer.byte(1);__privateWireWrite14(writer,value.Some,compact);}else{writer.byte(0);}writer.closeFrame(frame);}
function __privateWireWrite22(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite23(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite1(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite2(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite3(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite4(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite26(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Some')){writer.byte(1);__privateWireWrite4(writer,value.Some,compact);}else{writer.byte(0);}writer.closeFrame(frame);}
function __privateWireWrite12(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite13(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite10(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite20(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite21(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite10(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite8(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite9(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite10(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite18(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite19(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite10(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite16(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite17(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite10(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite11(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite4(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite10(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite30(writer,value,compact){const frame=writer.openFrame();__privateWireWrite31(writer,value["count"],compact);__privateWireWrite4(writer,value["index"],compact);writer.closeFrame(frame);}
function __privateWireWrite29(writer,value,compact){const frame=writer.openFrame();__privateWireWrite15(writer,value["cursor"],compact);__privateWireWrite17(writer,value["stats"],compact);__privateWireWrite24(writer,value["done"],compact);writer.closeFrame(frame);}
function __privateWireWrite9(writer,value,compact){const frame=writer.openFrame();__privateWireWrite0(writer,value["data"],compact);__privateWireWrite2(writer,value["epsilon"],compact);__privateWireWrite4(writer,value["budget"],compact);writer.closeFrame(frame);}
function __privateWireWrite27(writer,value,compact){const frame=writer.openFrame();__privateWireWrite4(writer,value["index"],compact);__privateWireWrite2(writer,value["width"],compact);__privateWireWrite24(writer,value["done"],compact);writer.closeFrame(frame);}
function __privateWireWrite28(writer,value,compact){const frame=writer.openFrame();__privateWireWrite4(writer,value["index"],compact);__privateWireWrite2(writer,value["width"],compact);__privateWireWrite2(writer,value["trimmed"],compact);__privateWireWrite15(writer,value["end"],compact);__privateWireWrite2(writer,value["result"],compact);__privateWireWrite24(writer,value["done"],compact);writer.closeFrame(frame);}
function __privateWireWrite19(writer,value,compact){const frame=writer.openFrame();__privateWireWrite4(writer,value["lineCount"],compact);__privateWireWrite2(writer,value["height"],compact);writer.closeFrame(frame);}
function __privateWireWrite17(writer,value,compact){const frame=writer.openFrame();__privateWireWrite4(writer,value["lineCount"],compact);__privateWireWrite2(writer,value["maxLineWidth"],compact);writer.closeFrame(frame);}
function __privateWireWrite31(writer,value,compact){const frame=writer.openFrame();__privateWireWrite4(writer,value["lines"],compact);__privateWireWrite2(writer,value["width"],compact);__privateWireWrite24(writer,value["content"],compact);writer.closeFrame(frame);}
function __privateWireWrite15(writer,value,compact){const frame=writer.openFrame();__privateWireWrite4(writer,value["segment"],compact);__privateWireWrite4(writer,value["grapheme"],compact);writer.closeFrame(frame);}
function __privateWireWrite25(writer,value,compact){const frame=writer.openFrame();__privateWireWrite24(writer,value["valid"],compact);__privateWireWrite4(writer,value["budget"],compact);__privateWireWrite4(writer,value["index"],compact);writer.closeFrame(frame);}
function __privateWireWrite14(writer,value,compact){const frame=writer.openFrame();__privateWireWrite2(writer,value["width"],compact);__privateWireWrite15(writer,value["start"],compact);__privateWireWrite15(writer,value["end"],compact);writer.closeFrame(frame);}
function __privateWireWrite0(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["widths"],compact);__privateWireWrite3(writer,value["flags"],compact);__privateWireWrite5(writer,value["advances"],compact);__privateWireWrite6(writer,value["startExtras"],compact);__privateWireWrite7(writer,value["graphemeStartExtras"],compact);__privateWireWrite6(writer,value["endTrims"],compact);__privateWireWrite6(writer,value["overflowTrims"],compact);__privateWireWrite6(writer,value["insideExtras"],compact);__privateWireWrite6(writer,value["fillExtras"],compact);writer.closeFrame(frame);}
function __privateWireWrite24(writer,value,compact){const frame=writer.openFrame();writer.byte(value?1:0);writer.closeFrame(frame);}
function __privateWireWrite23(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
function __privateWireWrite2(writer,value,compact){const frame=writer.openFrame();writer.wide(__dfBits(value));writer.closeFrame(frame);}
function __privateWireWrite10(writer,value,compact){const frame=writer.openFrame();writer.text(value,compact);writer.closeFrame(frame);}
function __privateWireWrite4(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
// Handles have no mutable private payload surface. Membership and type identity
// are checked by this module's closure; copied/foreign objects cannot forge them.
const __compiledHandles=new WeakMap();
const __compiledBindings=new WeakMap();
function __compiledHandle(identity,value,guaranteed=false){
 const handle=Object.freeze(Object.create(null));
 __compiledHandles.set(handle,{identity,value,guaranteed});return handle;
}
function __compiledEntry(handle,identity){
 const entry=__compiledHandles.get(handle);
 if(!entry||entry.identity!==identity)throw Error('compiled value type or owner mismatch');
 return entry;
}
function __compiledUnwrap(handle,identity){return __compiledEntry(handle,identity).value;}
// Emit the portable schema's framing/scalar events without creating a buffer
// or exposing private composite nodes. Only this wrapper receives callbacks
// from the literal writer; host visitors never receive those closures.
function __compiledValueEvents(sink,limits){
 const methods=['begin','end','byte','word','wide','text','count'];
 for(const name of methods)if(typeof sink?.[name]!=='function')throw Error('compiled value visitor method: '+name);
 const budget=createValueCaptureBudget(limits);let depth=0,closed=false;
 const active=()=>{if(closed)throw Error('compiled value visitor is closed');};
 const writer=Object.freeze({
  openFrame(){active();budget.enter(depth,4);depth++;sink.begin();return 0;}
  ,closeFrame(){active();if(depth===0)throw Error('wire frame boundary');try{sink.end();}finally{depth--;}}
  ,frame(emit){active();budget.enter(depth,4);depth++;sink.begin();try{emit();sink.end();}finally{depth--;}}
  ,byte(value){active();budget.add(1);sink.byte(value);}
  ,word(value){active();budget.add(4);sink.word(value);}
  ,wide(value){active();budget.add(8);sink.wide(value);}
  ,text(value){active();budget.text(value);sink.text(value);}
  ,count(value){active();budget.add(4);if(value>budget.remaining)throw Error('wire sequence size');sink.count(value);}
 });
 return {writer,close(){closed=true;}};
}
function __compiledReduction(factory,root,reduce,identity){
 if(typeof factory!=='function')throw Error('compiled reduction factory');
 const reducers=[],seen=new Set(),nodes=__reductionNodes();
 const prepare=index=>{
  if(seen.has(index))return;seen.add(index);
  const node=nodes[index];
  for(const child of node.children)prepare(child);
  const reducer=factory(node,index);
  if(node.kind==='list'||node.kind==='vector'){
   const start=reducer?.start,step=reducer?.step,finish=reducer?.finish;
   if(typeof start!=='function'||typeof step!=='function'||typeof finish!=='function')throw Error('compiled collection reduction');
   reducers[index]=Object.freeze({start,step,finish});
  }else{
   if(typeof reducer!=='function')throw Error('compiled value reduction');
   reducers[index]=reducer;
  }
 };
 prepare(root);Object.freeze(reducers);
 return Object.freeze(function(handle,context,limits={}){
  const value=__compiledUnwrap(handle,identity),budget=createValueCaptureBudget(limits);
  return reduce(value,reducers,budget,0,context);
 });
}
function __compiledCodec(schema,capture,read,write,copy,constructorRoot,reductionRoot,reduce,portableFused=false,compactFused=false){
 const privateCodec=createCompiledValueCodec(schema,read),publicCodec=privateCodec;
 let fusedCodec;const fused=()=>fusedCodec??=createFusedValueCodec(schema,read);
 const identity=schema.identity;
 const codec=Object.freeze({
  identity,
  descriptor:publicCodec.descriptor,
  resolve(type){return publicCodec.resolve(type);},
  capture(value,limits={}){
   return __compiledHandle(identity,capture(value,createValueCaptureBudget(limits),0));
  },
  decode(bytes,limits={}){return __compiledHandle(identity,(portableFused?fused():privateCodec).decode(bytes,limits));},
  decodeCompact(bytes,limits={}){return __compiledHandle(identity,(compactFused?fused():privateCodec).compact().decode(bytes,limits));},
  decodeFused(bytes,limits={}){return __compiledHandle(identity,fused().decode(bytes,limits));},
  decodeCompactFused(bytes,limits={}){return __compiledHandle(identity,fused().compact().decode(bytes,limits));},
  encode(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.encodeWith(writer=>write(writer,value,false),limits);},
  encodeCompact(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.compact().encodeWith(writer=>write(writer,value,true),limits);},
  materialize(handle,limits={}){return copy(__compiledUnwrap(handle,identity),createValueCaptureBudget(limits),0);},
  builder(limits={}){return __valueBuilder(__constructorNodes(),constructorRoot,identity,limits);},
  reducer(factory){return __compiledReduction(factory,reductionRoot,reduce,identity);},
  visit(handle,sink,limits={}){
   const value=__compiledUnwrap(handle,identity),events=__compiledValueEvents(sink,limits);
   try{write(events.writer,value,false);}finally{events.close();}
  },
 });
 __compiledBindings.set(codec,{publicCodec,write,capture});return codec;
}

function __compiledEncodeResult(entry,value,limits,compact){
 const {publicCodec,write}=__compiledBindings.get(entry.result());
 return (compact?publicCodec.compact():publicCodec).encodeWith(writer=>write(writer,value,compact),limits);
}
let __constructorNodesValue;function __constructorNodes(){return __constructorNodesValue??=[{kind:'record',fields:["widths","flags","advances","startExtras","graphemeStartExtras","endTrims","overflowTrims","insideExtras","fillExtras"],patterns:[{bytes:4,label:"record",children:[1,3,5,6,7,6,6,6,6],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["widths"]:values[0],["flags"]:values[1],["advances"]:values[2],["startExtras"]:values[3],["graphemeStartExtras"]:values[4],["endTrims"]:values[5],["overflowTrims"]:values[6],["insideExtras"]:values[7],["fillExtras"]:values[8]})}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[2],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:"f64",scalar:__privateCapture2},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[4],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:"u32",scalar:__privateCapture4},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[6],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'option',patterns:[{bytes:5,label:"None",children:[],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({None:null})},{bytes:5,label:"Some",children:[1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({Some:values[0]})}]},{kind:'option',patterns:[{bytes:5,label:"None",children:[],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({None:null})},{bytes:5,label:"Some",children:[5],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({Some:values[0]})}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[9],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[10],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'record',fields:["data","epsilon","budget"],patterns:[{bytes:4,label:"record",children:[0,2,4],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["data"]:values[0],["epsilon"]:values[1],["budget"]:values[2]})}]},{kind:"string",scalar:__privateCapture10},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[4],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[10],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[13],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[10],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[14],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["width","start","end"],patterns:[{bytes:4,label:"record",children:[2,15,15],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["width"]:values[0],["start"]:values[1],["end"]:values[2]})}]},{kind:'record',fields:["segment","grapheme"],patterns:[{bytes:4,label:"record",children:[4,4],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["segment"]:values[0],["grapheme"]:values[1]})}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[17],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[10],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'record',fields:["lineCount","maxLineWidth"],patterns:[{bytes:4,label:"record",children:[4,2],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["lineCount"]:values[0],["maxLineWidth"]:values[1]})}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[19],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[10],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'record',fields:["lineCount","height"],patterns:[{bytes:4,label:"record",children:[4,2],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["lineCount"]:values[0],["height"]:values[1]})}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[21],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[10],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'option',patterns:[{bytes:5,label:"None",children:[],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({None:null})},{bytes:5,label:"Some",children:[14],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({Some:values[0]})}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[23],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:"f32",scalar:__privateCapture23},{kind:"bool",scalar:__privateCapture24},{kind:'record',fields:["valid","budget","index"],patterns:[{bytes:4,label:"record",children:[24,4,4],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["valid"]:values[0],["budget"]:values[1],["index"]:values[2]})}]},{kind:'option',patterns:[{bytes:5,label:"None",children:[],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({None:null})},{bytes:5,label:"Some",children:[4],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({Some:values[0]})}]},{kind:'record',fields:["index","width","done"],patterns:[{bytes:4,label:"record",children:[4,2,24],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["index"]:values[0],["width"]:values[1],["done"]:values[2]})}]},{kind:'record',fields:["index","width","trimmed","end","result","done"],patterns:[{bytes:4,label:"record",children:[4,2,2,15,2,24],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["index"]:values[0],["width"]:values[1],["trimmed"]:values[2],["end"]:values[3],["result"]:values[4],["done"]:values[5]})}]},{kind:'record',fields:["cursor","stats","done"],patterns:[{bytes:4,label:"record",children:[15,17,24],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["cursor"]:values[0],["stats"]:values[1],["done"]:values[2]})}]},{kind:'record',fields:["count","index"],patterns:[{bytes:4,label:"record",children:[31,4],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["count"]:values[0],["index"]:values[1]})}]},{kind:'record',fields:["lines","width","content"],patterns:[{bytes:4,label:"record",children:[4,2,24],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["lines"]:values[0],["width"]:values[1],["content"]:values[2]})}]}];}
// Typed input construction only: plans contain literal constructor/capture
// functions emitted from source schemas. No source expression evaluator.
// All frames and private values remain in this closure; callers receive only
// an owned opaque handle after one complete, well-typed root is constructed.
const __constructorPaths=new WeakMap();
function __valueBuilder(nodes,root,identity,limits){
 const budget=createValueCaptureBudget(limits),frames=[];
 let result,targetNode,targetDepth,complete=false,closed=false,failed=false,busy=false;
 const fail=message=>{failed=true;frames.length=0;result=undefined;throw Error(message);};
 const active=()=>{if(failed||closed)throw Error('value builder is closed');};
 const expected=()=>{
  if(!frames.length){if(complete)fail('value builder root already complete');targetNode=root;targetDepth=0;return;}
  const frame=frames.at(-1),position=frame.values.length;
  if(!frame.pattern.sequence&&position>=frame.pattern.children.length)fail('value builder constructor is full');
  targetNode=frame.pattern.sequence?frame.pattern.children[0]:frame.pattern.children[position];targetDepth=frame.depth+frame.pattern.childDepth;
 };
 const accept=value=>{
  if(frames.length)frames.at(-1).values.push(value);
  else{result=value;complete=true;}
 };
 const execute=(operation,first,second)=>{
  active();if(busy)throw Error('value builder operation already active');busy=true;
  try{return operation(first,second);}catch(error){failed=true;frames.length=0;result=undefined;throw error;}finally{busy=false;}
 };
 // Compile and cache constructor paths independently of the session's values.
 const pathPlan=(choices,startNode,startDepth)=>{
   if(!Array.isArray(choices)||choices.length===0||choices.length>128)fail('invalid value builder path');
   let cache=__constructorPaths.get(nodes);if(!cache){cache=new WeakMap();__constructorPaths.set(nodes,cache);}
   let entries=cache.get(choices),saved=entries?.get(startNode);
   if(saved)return saved;
   const path=[],charges=[];let node=startNode,depth=startDepth;
   for(let i=0;i<choices.length;i++){
    const choice=choices[i],patterns=nodes[node].patterns;
    if(!Number.isSafeInteger(choice)||choice<0||!patterns||choice>=patterns.length)fail('invalid value builder constructor');
    const pattern=patterns[choice];charges.push([pattern,depth-startDepth]);path.push({pattern,node:nodes[node]});
    if(i+1<choices.length){if(pattern.sequence||pattern.children.length!==1)fail('value builder path is not unary');node=pattern.children[0];depth+=pattern.childDepth;}
   }
   const terminal=path.at(-1).pattern;
   // Compose literal constructor functions once per path, instead of
   // allocating and interpreting another recursive closure for every value.
   const compose=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=args=>args[0];
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=args=>p.make([inner(args)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?compose(last+1):args=>args[0]):compose(last);
     return args=>node.flat(index,payload(args));
    }
    const inner=at+1<path.length?compose(at+1):null;
    if(pattern.transparent)return inner??(args=>args[0]);
    return inner?args=>pattern.make([inner(args)]):pattern.make;
   };
   const make=compose(0);
   // Scalar paths use the same literal constructors, but pass the leaf
   // directly through erased records and flat sums. No temporary argument
   // array is needed at those edges. Ordinary constructors keep their array
   // calling convention; no private value reaches the public builder API.
   const composeScalar=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=value=>value;
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=value=>p.make([inner(value)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?composeScalar(last+1):value=>value):composeScalar(last);
     return value=>node.flat(index,payload(value));
    }
    const inner=at+1<path.length?composeScalar(at+1):null;
    if(pattern.transparent)return inner??(value=>value);
    return inner?value=>pattern.make([inner(value)]):value=>pattern.make([value]);
   };
   const scalar=composeScalar(0);
   const pattern={...terminal,make};
   // Only frozen arrays of ordinary data properties can key reusable plans.
   // Mutable arrays and frozen accessor arrays retain checked per-call paths.
   const fixed=charges.every(([p])=>Number.isSafeInteger(p.bytes)&&p.bytes>=4);
   const plan={pattern,scalar,charges,offset:depth-startDepth,bytes:fixed?charges.reduce((n,[p])=>n+p.bytes,0):null};
   let reusable=Object.isFrozen(choices);
   for(let i=0;reusable&&i<choices.length;i++){const field=Object.getOwnPropertyDescriptor(choices,String(i));reusable=!!field&&Object.hasOwn(field,'value');}
   if(reusable){
    if(!entries){entries=new Map();cache.set(choices,entries);}entries.set(startNode,plan);
   }
   return plan;
 };
 const chargePath=(plan,depth)=>{
  // Each emitted constructor consumes one node and a fixed frame/tag cost.
  // Only take the combined charge when every original check would succeed.
  // Replaying the original order retains the exact first failure otherwise.
  if(plan.bytes!==null&&depth+plan.offset<=budget.depth&&plan.charges.length<=budget.remaining&&budget.bytes+plan.bytes<=budget.limit){
   budget.remaining-=plan.charges.length;budget.bytes+=plan.bytes;return;
  }
  for(const [pattern,offset]of plan.charges)pattern.charge(budget,depth+offset);
 };
 // Operations are allocated once per session, and share expected-node
 // scratch only while the existing reentrancy guard is held.
 const openOperation=(choice)=>{
   expected();const node=nodes[targetNode];
   if(!Number.isSafeInteger(choice)||choice<0||!node.patterns||choice>=node.patterns.length)fail('invalid value builder constructor');
   const pattern=node.patterns[choice];pattern.charge(budget,targetDepth);
   frames.push({pattern,depth:targetDepth,values:[]});
 };
 const openPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth);
   chargePath(plan,targetDepth);
   frames.push({pattern:plan.pattern,depth:targetDepth+plan.offset,values:[]});
 };
 const scalarPathOperation=(choices,value)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==1)fail('value builder path has no scalar leaf');
   const capture=nodes[pattern.children[0]].scalar;
   if(typeof capture!=='function')fail('value builder path has no scalar leaf');
   chargePath(plan,targetDepth);
   const leaf=capture(value,budget,targetDepth+plan.offset+pattern.childDepth);
   accept(plan.scalar(leaf));
 };
 const emptyPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==0)fail('value builder path is not empty');
   chargePath(plan,targetDepth);accept(pattern.make([]));
 };
 const scalarOperation=(value)=>{
   expected();const capture=nodes[targetNode].scalar;
   if(typeof capture!=='function')fail('value builder expects a constructor');
   accept(capture(value,budget,targetDepth));
 };
 const closeOperation=()=>{
   if(!frames.length)fail('value builder has no open constructor');
   const frame=frames.at(-1),pattern=frame.pattern,count=frame.values.length;
   if(!pattern.sequence&&count!==pattern.children.length||pattern.size!==undefined&&count!==pattern.size)fail('value builder constructor arity');
   if(pattern.sequence&&count>budget.limit)fail('wire sequence size');
   const value=pattern.make(frame.values);
   frames.pop();accept(value);
 };
 const finishOperation=()=>{
   if(frames.length||!complete)fail('value builder root is incomplete');
   closed=true;const handle=__compiledHandle(identity,result);result=undefined;return handle;
 };
 const api=Object.freeze({
  open(choice){return execute(openOperation,choice);},
  // Charge every source constructor even when unary paths share one frame.
  openPath(choices){return execute(openPathOperation,choices);},
  // Complete the path and leaf without intermediate session frames.
  scalarPath(choices,value){return execute(scalarPathOperation,choices,value);},
  emptyPath(choices){return execute(emptyPathOperation,choices);},
  scalar(value){return execute(scalarOperation,value);},
  close(){return execute(closeOperation);},
  finish(){return execute(finishOperation);},
  abort(){if(busy)throw Error('value builder operation already active');failed=true;frames.length=0;result=undefined;},
 });
 return api;
}
function __reduceValue0(value,r,b,d,c){b.enter(d,4);return r[0](__reduceValue1(value["widths"],r,b,d+1,c),__reduceValue3(value["flags"],r,b,d+1,c),__reduceValue5(value["advances"],r,b,d+1,c),__reduceValue6(value["startExtras"],r,b,d+1,c),__reduceValue7(value["graphemeStartExtras"],r,b,d+1,c),__reduceValue6(value["endTrims"],r,b,d+1,c),__reduceValue6(value["overflowTrims"],r,b,d+1,c),__reduceValue6(value["insideExtras"],r,b,d+1,c),__reduceValue6(value["fillExtras"],r,b,d+1,c),c);}
function __reduceValue1(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[1];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue2(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue2(value,r,b,d,c){b.enter(d,12);return r[2]({F64Bits:__dfBits(value).toString()},c);}
function __reduceValue3(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[3];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue4(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue4(value,r,b,d,c){b.enter(d,8);return r[4](value,c);}
function __reduceValue5(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[5];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue6(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue6(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'None')&&value.None===null?r[6](0,null,c):r[6](1,__reduceValue1(value.Some,r,b,d+1,c),c);}
function __reduceValue7(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'None')&&value.None===null?r[7](0,null,c):r[7](1,__reduceValue5(value.Some,r,b,d+1,c),c);}
function __reduceValue8(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[8](0,__reduceValue9(value.Ok,r,b,d+1,c),c):r[8](1,__reduceValue10(value.Err,r,b,d+1,c),c);}
function __reduceValue9(value,r,b,d,c){b.enter(d,4);return r[9](__reduceValue0(value["data"],r,b,d+1,c),__reduceValue2(value["epsilon"],r,b,d+1,c),__reduceValue4(value["budget"],r,b,d+1,c),c);}
function __reduceValue10(value,r,b,d,c){b.enter(d,4);b.text(value);return r[10](value,c);}
function __reduceValue11(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[11](0,__reduceValue4(value.Ok,r,b,d+1,c),c):r[11](1,__reduceValue10(value.Err,r,b,d+1,c),c);}
function __reduceValue12(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[12](0,__reduceValue13(value.Ok,r,b,d+1,c),c):r[12](1,__reduceValue10(value.Err,r,b,d+1,c),c);}
function __reduceValue13(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[13];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue14(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue14(value,r,b,d,c){b.enter(d,4);return r[14](__reduceValue2(value["width"],r,b,d+1,c),__reduceValue15(value["start"],r,b,d+1,c),__reduceValue15(value["end"],r,b,d+1,c),c);}
function __reduceValue15(value,r,b,d,c){b.enter(d,4);return r[15](__reduceValue4(value["segment"],r,b,d+1,c),__reduceValue4(value["grapheme"],r,b,d+1,c),c);}
function __reduceValue16(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[16](0,__reduceValue17(value.Ok,r,b,d+1,c),c):r[16](1,__reduceValue10(value.Err,r,b,d+1,c),c);}
function __reduceValue17(value,r,b,d,c){b.enter(d,4);return r[17](__reduceValue4(value["lineCount"],r,b,d+1,c),__reduceValue2(value["maxLineWidth"],r,b,d+1,c),c);}
function __reduceValue18(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[18](0,__reduceValue19(value.Ok,r,b,d+1,c),c):r[18](1,__reduceValue10(value.Err,r,b,d+1,c),c);}
function __reduceValue19(value,r,b,d,c){b.enter(d,4);return r[19](__reduceValue4(value["lineCount"],r,b,d+1,c),__reduceValue2(value["height"],r,b,d+1,c),c);}
function __reduceValue20(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[20](0,__reduceValue21(value.Ok,r,b,d+1,c),c):r[20](1,__reduceValue10(value.Err,r,b,d+1,c),c);}
function __reduceValue21(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'None')&&value.None===null?r[21](0,null,c):r[21](1,__reduceValue14(value.Some,r,b,d+1,c),c);}
function __reduceValue22(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[22];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue23(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue23(value,r,b,d,c){b.enter(d,8);return r[23]({F32Bits:value},c);}
function __reduceValue24(value,r,b,d,c){b.enter(d,5);return r[24](value,c);}
function __reduceValue25(value,r,b,d,c){b.enter(d,4);return r[25](__reduceValue24(value["valid"],r,b,d+1,c),__reduceValue4(value["budget"],r,b,d+1,c),__reduceValue4(value["index"],r,b,d+1,c),c);}
function __reduceValue26(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'None')&&value.None===null?r[26](0,null,c):r[26](1,__reduceValue4(value.Some,r,b,d+1,c),c);}
function __reduceValue27(value,r,b,d,c){b.enter(d,4);return r[27](__reduceValue4(value["index"],r,b,d+1,c),__reduceValue2(value["width"],r,b,d+1,c),__reduceValue24(value["done"],r,b,d+1,c),c);}
function __reduceValue28(value,r,b,d,c){b.enter(d,4);return r[28](__reduceValue4(value["index"],r,b,d+1,c),__reduceValue2(value["width"],r,b,d+1,c),__reduceValue2(value["trimmed"],r,b,d+1,c),__reduceValue15(value["end"],r,b,d+1,c),__reduceValue2(value["result"],r,b,d+1,c),__reduceValue24(value["done"],r,b,d+1,c),c);}
function __reduceValue29(value,r,b,d,c){b.enter(d,4);return r[29](__reduceValue15(value["cursor"],r,b,d+1,c),__reduceValue17(value["stats"],r,b,d+1,c),__reduceValue24(value["done"],r,b,d+1,c),c);}
function __reduceValue30(value,r,b,d,c){b.enter(d,4);return r[30](__reduceValue31(value["count"],r,b,d+1,c),__reduceValue4(value["index"],r,b,d+1,c),c);}
function __reduceValue31(value,r,b,d,c){b.enter(d,4);return r[31](__reduceValue4(value["lines"],r,b,d+1,c),__reduceValue2(value["width"],r,b,d+1,c),__reduceValue24(value["content"],r,b,d+1,c),c);}
let __reductionNodeCache;function __reductionNodes(){return __reductionNodeCache??=Object.freeze([Object.freeze({"children":Object.freeze([1,3,5,6,7,6,6,6,6]),"fields":Object.freeze(["widths","flags","advances","startExtras","graphemeStartExtras","endTrims","overflowTrims","insideExtras","fillExtras"]),"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}),Object.freeze({"children":Object.freeze([2]),"kind":"list"}),Object.freeze({"children":Object.freeze([]),"kind":"f64"}),Object.freeze({"children":Object.freeze([4]),"kind":"list"}),Object.freeze({"children":Object.freeze([]),"kind":"u32"}),Object.freeze({"children":Object.freeze([6]),"kind":"list"}),Object.freeze({"children":Object.freeze([1]),"kind":"option"}),Object.freeze({"children":Object.freeze([5]),"kind":"option"}),Object.freeze({"children":Object.freeze([9,10]),"kind":"result"}),Object.freeze({"children":Object.freeze([0,2,4]),"fields":Object.freeze(["data","epsilon","budget"]),"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}),Object.freeze({"children":Object.freeze([]),"kind":"string"}),Object.freeze({"children":Object.freeze([4,10]),"kind":"result"}),Object.freeze({"children":Object.freeze([13,10]),"kind":"result"}),Object.freeze({"children":Object.freeze([14]),"kind":"list"}),Object.freeze({"children":Object.freeze([2,15,15]),"fields":Object.freeze(["width","start","end"]),"kind":"record","name":"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993"}),Object.freeze({"children":Object.freeze([4,4]),"fields":Object.freeze(["segment","grapheme"]),"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}),Object.freeze({"children":Object.freeze([17,10]),"kind":"result"}),Object.freeze({"children":Object.freeze([4,2]),"fields":Object.freeze(["lineCount","maxLineWidth"]),"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}),Object.freeze({"children":Object.freeze([19,10]),"kind":"result"}),Object.freeze({"children":Object.freeze([4,2]),"fields":Object.freeze(["lineCount","height"]),"kind":"record","name":"ink_mf31874390da54b3c180b48032618b677f5ca389c9ffcfc54ae469de235e84bcb"}),Object.freeze({"children":Object.freeze([21,10]),"kind":"result"}),Object.freeze({"children":Object.freeze([14]),"kind":"option"}),Object.freeze({"children":Object.freeze([23]),"kind":"list"}),Object.freeze({"children":Object.freeze([]),"kind":"f32"}),Object.freeze({"children":Object.freeze([]),"kind":"bool"}),Object.freeze({"children":Object.freeze([24,4,4]),"fields":Object.freeze(["valid","budget","index"]),"kind":"record","name":"ink_m233b63cde5b1951078531833cb439d88de244d40e3a6392d35d12e48ecb2ef5d"}),Object.freeze({"children":Object.freeze([4]),"kind":"option"}),Object.freeze({"children":Object.freeze([4,2,24]),"fields":Object.freeze(["index","width","done"]),"kind":"record","name":"ink_m7b062ce6e1c2efcea6de69b7c533325db5ea045c74268a2b5acae500b6575dfc"}),Object.freeze({"children":Object.freeze([4,2,2,15,2,24]),"fields":Object.freeze(["index","width","trimmed","end","result","done"]),"kind":"record","name":"ink_m2009348d597e6b76dc210821f6f99bb8afebe7919b4fe0a09c17b3f9ac4793c3"}),Object.freeze({"children":Object.freeze([15,17,24]),"fields":Object.freeze(["cursor","stats","done"]),"kind":"record","name":"ink_m086abde96a678051961f464f791c4c5c94b31f286fb29436e88cbebcf9b5ad1c"}),Object.freeze({"children":Object.freeze([31,4]),"fields":Object.freeze(["count","index"]),"kind":"record","name":"ink_me68c2f5e5e86a516faa862d519cff9a3e02bc5e131745a9c88827226a0059c6a"}),Object.freeze({"children":Object.freeze([4,2,24]),"fields":Object.freeze(["lines","width","content"]),"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"})]);}
function __compiledNamed0(){return {};}
let __compiledCodec0Value;function __compiledCodec0(){return __compiledCodec0Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"6a12295ab1a7d1a82257153e77a592e35552995f61ba0e3bb3c6b0e998d0aaec","named":__compiledNamed0(),"root":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},__privateCapture0,__privateWireValue0,__privateWireWrite0,__compiledOwnedValue0,0,0,__reduceValue0,false,false);}
let __compiledCodec1Value;function __compiledCodec1(){return __compiledCodec1Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":__compiledNamed0(),"root":{"kind":"f64"}},__privateCapture2,__privateWireValue2,__privateWireWrite2,__compiledOwnedValue2,2,2,__reduceValue2,false,false);}
let __compiledCodec2Value;function __compiledCodec2(){return __compiledCodec2Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff","named":__compiledNamed0(),"root":{"kind":"u32"}},__privateCapture4,__privateWireValue4,__privateWireWrite4,__compiledOwnedValue4,4,4,__reduceValue4,false,false);}
let __compiledCodec3Value;function __compiledCodec3(){return __compiledCodec3Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"ecfeb978a3522397be254146ef28fe5f3058566b565a7f4962c9131b6b18ae1c","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}}},__privateCapture8,__privateWireValue8,__privateWireWrite8,__compiledOwnedValue8,8,8,__reduceValue8,false,false);}
let __compiledCodec4Value;function __compiledCodec4(){return __compiledCodec4Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"521eaeae4d030f71891ee322304be19877dd3df45f375257b9b99b896efe3237","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"u32"}}},__privateCapture11,__privateWireValue12,__privateWireWrite11,__compiledOwnedValue11,11,11,__reduceValue11,false,false);}
let __compiledCodec5Value;function __compiledCodec5(){return __compiledCodec5Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"56dc0435d74d48781d7002db784cd2f88c15385d3cd6b708425c161c37cc361c","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"fields":[{"name":"width","type":{"kind":"f64"}},{"name":"start","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"kind":"record","name":"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993"},"kind":"list"}}},__privateCapture12,__privateWireValue14,__privateWireWrite12,__compiledOwnedValue12,12,12,__reduceValue12,false,false);}
let __compiledCodec6Value;function __compiledCodec6(){return __compiledCodec6Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"82ec50d2da2c3182aceb5378e08d8b8fe9de60c2be54d6daf5dbdb658955279f","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}}},__privateCapture16,__privateWireValue18,__privateWireWrite16,__compiledOwnedValue16,16,16,__reduceValue16,false,false);}
let __compiledCodec7Value;function __compiledCodec7(){return __compiledCodec7Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"847cdb58437325b0783e94e7d572b615580b335968d233fd0e1b9879487ce4b2","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"height","type":{"kind":"f64"}}],"kind":"record","name":"ink_mf31874390da54b3c180b48032618b677f5ca389c9ffcfc54ae469de235e84bcb"}}},__privateCapture18,__privateWireValue20,__privateWireWrite18,__compiledOwnedValue18,18,18,__reduceValue18,false,false);}
let __compiledCodec8Value;function __compiledCodec8(){return __compiledCodec8Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"8e9fa024666eb3bfe6ab6049f660e547a12b56772f4ecbff9addcea5a92f3d9a","named":__compiledNamed0(),"root":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},__privateCapture15,__privateWireValue17,__privateWireWrite15,__compiledOwnedValue15,15,15,__reduceValue15,false,false);}
let __compiledCodec9Value;function __compiledCodec9(){return __compiledCodec9Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"6dabf0313de1ca25f33127bc080f250697ab4e45b0935d5c06756788a303369f","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"fields":[{"name":"width","type":{"kind":"f64"}},{"name":"start","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"kind":"record","name":"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993"},"kind":"option"}}},__privateCapture20,__privateWireValue23,__privateWireWrite20,__compiledOwnedValue20,20,20,__reduceValue20,false,false);}
let __compiledCodec10Value;function __compiledCodec10(){return __compiledCodec10Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"acf4b91a06bec753d55d8da6fe10af423067ce8dec33348ec407148ad1926430","named":__compiledNamed0(),"root":{"fields":[{"name":"data","type":{"fields":[{"name":"widths","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"flags","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"advances","type":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"}},{"name":"startExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"graphemeStartExtras","type":{"element":{"element":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"},"kind":"list"},"kind":"option"}},{"name":"endTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"overflowTrims","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"insideExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},{"name":"fillExtras","type":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}}],"kind":"record","name":"ink_m65acfe79ee1b007f44b6f7ecc0131dbee707343e5a53f22c71bba1f6c036ebff"}},{"name":"epsilon","type":{"kind":"f64"}},{"name":"budget","type":{"kind":"u32"}}],"kind":"record","name":"ink_mdb54778f579f908908ad7f3f346cc3ea2d7cc1340eed5217914631e6ebc478e8"}},__privateCapture9,__privateWireValue9,__privateWireWrite9,__compiledOwnedValue9,9,9,__reduceValue9,false,false);}
let __compiledCodec11Value;function __compiledCodec11(){return __compiledCodec11Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":__compiledNamed0(),"root":{"element":{"kind":"f32"},"kind":"list"}},__privateCapture22,__privateWireValue27,__privateWireWrite22,__compiledOwnedValue22,22,22,__reduceValue22,false,false);}
let __compiledCodec12Value;function __compiledCodec12(){return __compiledCodec12Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"61e29a83d1fd64f316d82cf150eb5ad0405d16e0e326ff56bf3bae4248a89a32","named":__compiledNamed0(),"root":{"element":{"element":{"kind":"f64"},"kind":"list"},"kind":"option"}},__privateCapture6,__privateWireValue6,__privateWireWrite6,__compiledOwnedValue6,6,6,__reduceValue6,false,false);}
let __compiledCodec13Value;function __compiledCodec13(){return __compiledCodec13Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":__compiledNamed0(),"root":{"kind":"bool"}},__privateCapture24,__privateWireValue32,__privateWireWrite24,__compiledOwnedValue24,24,24,__reduceValue24,false,false);}
let __compiledCodec14Value;function __compiledCodec14(){return __compiledCodec14Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"152a8177038a47dcbc6416cb2d7d38cc76c42d7e55613dee4787f2dfb646e9e7","named":__compiledNamed0(),"root":{"element":{"kind":"f64"},"kind":"list"}},__privateCapture1,__privateWireValue1,__privateWireWrite1,__compiledOwnedValue1,1,1,__reduceValue1,false,false);}
let __compiledCodec15Value;function __compiledCodec15(){return __compiledCodec15Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"f437e4e468cf5dba7df20a9114414406da37a3ae54ea711140ac1b5956e95082","named":__compiledNamed0(),"root":{"fields":[{"name":"valid","type":{"kind":"bool"}},{"name":"budget","type":{"kind":"u32"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"ink_m233b63cde5b1951078531833cb439d88de244d40e3a6392d35d12e48ecb2ef5d"}},__privateCapture25,__privateWireValue36,__privateWireWrite25,__compiledOwnedValue25,25,25,__reduceValue25,false,false);}
let __compiledCodec16Value;function __compiledCodec16(){return __compiledCodec16Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"f4055357f369cc8f275f6cc1d5569678031edf449ad32c3c8d392d37fab5b1ed","named":__compiledNamed0(),"root":{"element":{"kind":"u32"},"kind":"option"}},__privateCapture26,__privateWireValue38,__privateWireWrite26,__compiledOwnedValue26,26,26,__reduceValue26,false,false);}
let __compiledCodec17Value;function __compiledCodec17(){return __compiledCodec17Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"75a4618821d68677bbefcd2dc8914150aecf406a4a3da1ef14cc88b57d83d830","named":__compiledNamed0(),"root":{"fields":[{"name":"index","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m7b062ce6e1c2efcea6de69b7c533325db5ea045c74268a2b5acae500b6575dfc"}},__privateCapture27,__privateWireValue44,__privateWireWrite27,__compiledOwnedValue27,27,27,__reduceValue27,false,false);}
let __compiledCodec18Value;function __compiledCodec18(){return __compiledCodec18Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"50c3299d4fbe93aa5602b822292acc76ab4400b031152a8c6acd698494f4c7f8","named":__compiledNamed0(),"root":{"fields":[{"name":"index","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"trimmed","type":{"kind":"f64"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"result","type":{"kind":"f64"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m2009348d597e6b76dc210821f6f99bb8afebe7919b4fe0a09c17b3f9ac4793c3"}},__privateCapture28,__privateWireValue46,__privateWireWrite28,__compiledOwnedValue28,28,28,__reduceValue28,false,false);}
let __compiledCodec19Value;function __compiledCodec19(){return __compiledCodec19Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"c8de454d504db86ea8f8ef8cc6465494fc0e6efc146d375495b17ba9fb23b767","named":__compiledNamed0(),"root":{"fields":[{"name":"width","type":{"kind":"f64"}},{"name":"start","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"end","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}}],"kind":"record","name":"ink_mc03a85b468fe7b088aa96db164811d6d6b67a5d8647d5d9237958f70b2ae2993"}},__privateCapture14,__privateWireValue16,__privateWireWrite14,__compiledOwnedValue14,14,14,__reduceValue14,false,false);}
let __compiledCodec20Value;function __compiledCodec20(){return __compiledCodec20Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"95f1d165952114b4814841922105b86c623e8c07746843b06ad383444f2fa3eb","named":__compiledNamed0(),"root":{"fields":[{"name":"cursor","type":{"fields":[{"name":"segment","type":{"kind":"u32"}},{"name":"grapheme","type":{"kind":"u32"}}],"kind":"record","name":"ink_m2790802a593ba1a09d029a1ebf8c3785763b6685703b958ab56b6d0bc06ed8be"}},{"name":"stats","type":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}},{"name":"done","type":{"kind":"bool"}}],"kind":"record","name":"ink_m086abde96a678051961f464f791c4c5c94b31f286fb29436e88cbebcf9b5ad1c"}},__privateCapture29,__privateWireValue49,__privateWireWrite29,__compiledOwnedValue29,29,29,__reduceValue29,false,false);}
let __compiledCodec21Value;function __compiledCodec21(){return __compiledCodec21Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"958e0edfe65dde01c97aa1e7b9cb0c065f371a3330a42d473bc79a0491ebfc4f","named":__compiledNamed0(),"root":{"fields":[{"name":"lineCount","type":{"kind":"u32"}},{"name":"maxLineWidth","type":{"kind":"f64"}}],"kind":"record","name":"ink_mebc69b4f5837f6ba504ffabce3a2e390b39e0df6c574d9d7170f95c92d5d24e8"}},__privateCapture17,__privateWireValue19,__privateWireWrite17,__compiledOwnedValue17,17,17,__reduceValue17,false,false);}
let __compiledCodec22Value;function __compiledCodec22(){return __compiledCodec22Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"542b3f99971053a272b15d88dedbfd32860a89ec2308e87c7bdb1c08c26eae0e","named":__compiledNamed0(),"root":{"fields":[{"name":"count","type":{"fields":[{"name":"lines","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"content","type":{"kind":"bool"}}],"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"ink_me68c2f5e5e86a516faa862d519cff9a3e02bc5e131745a9c88827226a0059c6a"}},__privateCapture30,__privateWireValue51,__privateWireWrite30,__compiledOwnedValue30,30,30,__reduceValue30,false,false);}
let __compiledCodec23Value;function __compiledCodec23(){return __compiledCodec23Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"3650a28e866fe994c1295f191904faf234c261d3a1a0a1b12bbf12c9e04226a2","named":__compiledNamed0(),"root":{"fields":[{"name":"lines","type":{"kind":"u32"}},{"name":"width","type":{"kind":"f64"}},{"name":"content","type":{"kind":"bool"}}],"kind":"record","name":"ink_mf5f38b2c9341e2757358c69c56230c166b0a29429246531c44a142a452637844"}},__privateCapture31,__privateWireValue52,__privateWireWrite31,__compiledOwnedValue31,31,31,__reduceValue31,false,false);}
const __compiledEntries=new Map([["prepare",{index:0,params:[__compiledCodec0,__compiledCodec1,__compiledCodec2],result:__compiledCodec3,arguments:__privateWireValue11,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["count_lines",{index:1,params:[__compiledCodec0,__compiledCodec1,__compiledCodec1],result:__compiledCodec4,arguments:__privateWireValue13,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["lines",{index:2,params:[__compiledCodec0,__compiledCodec1,__compiledCodec1],result:__compiledCodec5,arguments:__privateWireValue13,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["stats",{index:3,params:[__compiledCodec0,__compiledCodec1,__compiledCodec1],result:__compiledCodec6,arguments:__privateWireValue13,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["layout",{index:4,params:[__compiledCodec0,__compiledCodec1,__compiledCodec1,__compiledCodec1],result:__compiledCodec7,arguments:__privateWireValue22,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["line",{index:5,params:[__compiledCodec0,__compiledCodec1,__compiledCodec8,__compiledCodec1],result:__compiledCodec9,arguments:__privateWireValue25,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["count_prepared",{index:6,params:[__compiledCodec10,__compiledCodec1],result:__compiledCodec4,arguments:__privateWireValue26,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["numeric",{index:7,params:[__compiledCodec11],result:__compiledCodec11,arguments:__privateWireValue29,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["ink_maa2ffc47f94a1df1e2b1982bb687b3b95ea1f18c3d31e5270249eb9a5b1b8987",{index:8,params:[__compiledCodec12,__compiledCodec2],result:__compiledCodec1,arguments:__privateWireValue30,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["ink_m1cbd9e6f220b01cc6d3614d0b500ae6ae7fb6bc6b3ccb0fd24ba416e435dec02",{index:9,params:[__compiledCodec0,__compiledCodec2],result:__compiledCodec12,arguments:__privateWireValue31,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["ink_ma9923eba3cdcc3be4bd5eec9937c55f89cb7af34eade1f02c02bde46b444755d",{index:10,params:[__compiledCodec0,__compiledCodec2],result:__compiledCodec2,arguments:__privateWireValue31,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["ink_mf2da1ccb63323de619308b515afc2e8427fa422cacc3b9e180896d7c1933a5db",{index:11,params:[__compiledCodec0,__compiledCodec2,__compiledCodec13],result:__compiledCodec13,arguments:__privateWireValue33,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["ink_mf3fd6a8edcedf12678ee0135d258e53818da29f98901e4823c5b5fa68a8742b5",{index:12,params:[__compiledCodec0,__compiledCodec2],result:__compiledCodec13,arguments:__privateWireValue31,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["ink_m4871d371876b879fe17454f848676f99047b70dcf533553abf657eccb48917a5",{index:13,params:[__compiledCodec14],result:__compiledCodec13,arguments:__privateWireValue34,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["ink_m3e5801892156affa301b1de70c5499a6f98c8ab08ce4a11d6064687eaff81e63",{index:14,params:[__compiledCodec12,__compiledCodec2],result:__compiledCodec13,arguments:__privateWireValue35,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["ink_m1035a47a3beb1fd15b77187a225faf4374da04d4239c2bb5f2fd7f377c9105f8",{index:15,params:[__compiledCodec0,__compiledCodec2,__compiledCodec12,__compiledCodec15],result:__compiledCodec15,arguments:__privateWireValue37,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["ink_mb4277fe25fdfb0e134f990b04d6baa626119984e30cca8da242f327fd2871a58",{index:16,params:[__compiledCodec0,__compiledCodec1,__compiledCodec2],result:__compiledCodec16,arguments:__privateWireValue39,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["ink_mc1df4b06d386435afd93c2deb158f576ca1a0b8da5cc9ddac9804cbbd5aaed55",{index:17,params:[__compiledCodec0,__compiledCodec1,__compiledCodec2],result:__compiledCodec3,arguments:__privateWireValue39,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["ink_md45fb160f95b90ffa06f2e883a8e13e6cfb6f48c9e504c758674212aaaafed13",{index:18,params:[__compiledCodec10],result:__compiledCodec13,arguments:__privateWireValue40,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["ink_m79fbd33ce445d81b5495367bea54ed582eb29a97df1560f52a1db7c4538eabd4",{index:19,params:[__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue41,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["ink_m403c4c47e84eda8d792b1109de53fbbc655e214636da67f4e0bec47ffe157b0e",{index:20,params:[__compiledCodec10,__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue42,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["ink_m693a1ebd0432f205eabdd53caaf1bb1ac592d434476d44639419d5b63ab48e45",{index:21,params:[__compiledCodec0,__compiledCodec8],result:__compiledCodec8,arguments:__privateWireValue43,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["ink_m746b7ebe9bcb715eb063c9a8acdc48ed10dd67c3ac1ab355ca08a8a31f2e076a",{index:22,params:[__compiledCodec14,__compiledCodec2,__compiledCodec1,__compiledCodec1],result:__compiledCodec17,arguments:__privateWireValue45,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["ink_m424a73c98abd59df2df2e9558114156f29b349d1a0fc567d6a7b6991fa96d4e4",{index:23,params:[__compiledCodec0,__compiledCodec1,__compiledCodec18],result:__compiledCodec18,arguments:__privateWireValue47,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["ink_m0fffc1496f6a8b2b8d7044034bab3436a5bf8d98c9b26163ffc110ef18eb690f",{index:24,params:[__compiledCodec10,__compiledCodec8,__compiledCodec1],result:__compiledCodec19,arguments:__privateWireValue48,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["ink_m3ec56d96554edff8dcbc70dd4746c1467d14cccdd680a05225aecdcb1ff10585",{index:25,params:[__compiledCodec10,__compiledCodec8,__compiledCodec1],result:__compiledCodec9,arguments:__privateWireValue48,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["ink_m031320cee58f85b79b37202fff6fd536ad71ab758d2d465493cd48cefb302021",{index:26,params:[__compiledCodec10,__compiledCodec1,__compiledCodec20],result:__compiledCodec20,arguments:__privateWireValue50,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["ink_m618e3b1ce3d206a7ce99ecd61dc5909f8327679e73d0e9cd3a60a1c006ce85b8",{index:27,params:[__compiledCodec10,__compiledCodec1],result:__compiledCodec21,arguments:__privateWireValue42,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["ink_me3e1d6802e8b8c99257eae2c70e1c73b81194a7b49cd49c1aadcbcf5fb61a373",{index:28,params:[__compiledCodec10,__compiledCodec1],result:__compiledCodec6,arguments:__privateWireValue42,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["ink_m1c643c3729ce33889b175f6534c6f5567e1031f9a2294b31f14214ef5d846f7e",{index:30,params:[__compiledCodec10,__compiledCodec1],result:__compiledCodec5,arguments:__privateWireValue42,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["ink_m61a3849a7a6ebf0fe028d8fa87a1a3eaa6166a2532387000b50e461faa1b2899",{index:31,params:[__compiledCodec14,__compiledCodec2,__compiledCodec1,__compiledCodec1],result:__compiledCodec17,arguments:__privateWireValue45,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["ink_m09bd2f6d807dddea08a3e05dff926c97158dd5c78fbcec8971733d58e03c9fbf",{index:32,params:[__compiledCodec14,__compiledCodec12,__compiledCodec1,__compiledCodec22],result:__compiledCodec22,arguments:__privateWireValue53,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["ink_mdb420bacbaded3bd4a47c64a08eab41bd49e5a1eb00a06f5fb4216055764e14f",{index:33,params:[__compiledCodec0,__compiledCodec1,__compiledCodec2,__compiledCodec23],result:__compiledCodec23,arguments:__privateWireValue54,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["ink_m5a18484940b2f87721d94e036b20f3f623fd9a7ef0bbb105d497073a418c96f6",{index:34,params:[__compiledCodec10,__compiledCodec1],result:__compiledCodec4,arguments:__privateWireValue42,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["ink_mf92f9e487553a051acda291cdf01e6ab1ad3a5254dd3d94587ad2b797d8dea28",{index:35,params:[__compiledCodec10,__compiledCodec1,__compiledCodec1],result:__compiledCodec7,arguments:__privateWireValue55,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}]]);

export const compiledValues=Object.freeze(Object.fromEntries([...__compiledEntries].map(([name,entry])=>[name,Object.freeze({get params(){return Object.freeze(entry.params.map(codec=>codec()));},get result(){return entry.result();}})])));
function __compiledValidate(entry,owned){
 const values=owned.map(v=>v.value);
 const established=entry.onlyTypeGuards&&entry.needsInvariants.every((needed,i)=>!needed||owned[i].guaranteed);
 if(entry.precondition!==null&&!established){
  if(__implementations[entry.precondition](...values)!==true)throw Error('contract precondition failed');
  for(let i=0;i<owned.length;i++)if(entry.needsInvariants[i])owned[i].guaranteed=true;
 }
 return values;
}
export function callCompiled(name,args){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(args)||args.length!==entry.params.length)throw Error('unsupported compiled call');
 const owned=entry.params.map((codec,i)=>__compiledEntry(args[i],codec().identity)),values=__compiledValidate(entry,owned);
 // Checked source outputs satisfy their declared value interfaces. Private
 // handles expose only detached copies and never retain mutable host inputs.
 return __compiledHandle(entry.result().identity,__implementations[entry.index](...values),true);
}

// Explicit sealed-value partial application. Each token owns a bounded set of
// lexical caches; no mutable host object, global memo table or error is retained.
const __preparedCompiled=new WeakMap();
export function prepareCompiled(name,bindings){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(bindings)||bindings.length>entry.params.length)throw Error('unsupported prepared compiled call');
 const captured=new Array(entry.params.length),fixed=new Array(entry.params.length).fill(false);
 for(const binding of bindings){
  if(!Array.isArray(binding)||binding.length!==2)throw Error('prepared compiled binding');
  const [index,handle]=binding;
  if(!Number.isInteger(index)||index<0||index>=fixed.length||fixed[index])throw Error('prepared compiled parameter');
  captured[index]=__compiledEntry(handle,entry.params[index]().identity);fixed[index]=true;
 }
 const remaining=fixed.flatMap((yes,i)=>yes?[]:[i]);
 const factory=__preparedFactories.get(entry.index);
 const run=factory?factory(fixed):__implementations[entry.index];
 const token=Object.freeze(Object.create(null));
 __preparedCompiled.set(token,{entry,captured,remaining,run});return token;
}
export function callPreparedCompiled(token,args){
 const prepared=__preparedCompiled.get(token);
 if(!prepared||!Array.isArray(args)||args.length!==prepared.remaining.length)throw Error('invalid prepared compiled call');
 const {entry,captured,remaining,run}=prepared,owned=captured.slice();
 for(let i=0;i<remaining.length;i++){const at=remaining[i];owned[at]=__compiledEntry(args[i],entry.params[at]().identity);}
 const values=__compiledValidate(entry,owned);
 return __compiledHandle(entry.result().identity,run(...values),true);
}
const __intoOutput7=__representation(metadata.functions[7].result.element,true);
const __intoImplementations=[null,null,null,null,null,null,null,__into7,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];

export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>{
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const body=__intoImplementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args.slice(0,f.params.length))!==true)throw Error('contract precondition failed');return body(...args);};
  const entry=input.every(c=>c===__identity)?implementation:(...values)=>{const context=new WeakMap();return implementation(...input.map((convert,i)=>convert(values[i],context)),values[f.params.length]);};
  return [f.name,entry];
})));
export function callInto(name,args,destination){switch(name){case "ink_mb3166db2bf18ab05ba193c347c860e3c609f09da430fd77ac9981409ba2efcef":throw new Error('temporary storage is internal to a pure invocation');}return functionsInto[name](...args,destination);}

function __preparedPart(mask,path){
 for(const field of path){
  if(mask===true)return true;
  if(!mask || typeof mask!=="object")return false;
  mask=Object.hasOwn(mask.fields,field)?mask.fields[field]:false;
 }
 return mask;
}
function __preparedStable(mask,path){const part=__preparedPart(mask,path);return part===true || (!!part && part.all===true);}
function __prepareFn0(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["widths"])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))||(__preparedStable(fixed[0],["advances"])&&__preparedStable(fixed[0],["endTrims"])&&__preparedStable(fixed[0],["fillExtras"])&&__preparedStable(fixed[0],["flags"])&&__preparedStable(fixed[0],["graphemeStartExtras"])&&__preparedStable(fixed[0],["insideExtras"])&&__preparedStable(fixed[0],["overflowTrims"])&&__preparedStable(fixed[0],["startExtras"])&&__preparedStable(fixed[0],["widths"]))))return __fn0;const v1043=depth<15&&__preparedFactories.has(17)&&((__preparedStable(fixed[0],["widths"])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))||(__preparedStable(fixed[0],["advances"])&&__preparedStable(fixed[0],["endTrims"])&&__preparedStable(fixed[0],["fillExtras"])&&__preparedStable(fixed[0],["flags"])&&__preparedStable(fixed[0],["graphemeStartExtras"])&&__preparedStable(fixed[0],["insideExtras"])&&__preparedStable(fixed[0],["overflowTrims"])&&__preparedStable(fixed[0],["startExtras"])&&__preparedStable(fixed[0],["widths"])));
let v1041;
return function(v1038,v1039,v1040){let v1044;if(v1043){if(!v1041){const v1042=__preparedFactories.get(17);v1041=v1042([fixed[0],fixed[1],fixed[2]],depth+1);}v1044=v1041(v1038,v1039,v1040);}else{v1044=__fn17(v1038,v1039,v1040);}
return v1044;};}
function __prepareFn1(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn1;const v1051=depth<15&&__preparedFactories.has(17)&&((__preparedStable(fixed[0],["widths"])&&__preparedStable(fixed[1],[]))||(__preparedStable(fixed[0],["advances"])&&__preparedStable(fixed[0],["endTrims"])&&__preparedStable(fixed[0],["fillExtras"])&&__preparedStable(fixed[0],["flags"])&&__preparedStable(fixed[0],["graphemeStartExtras"])&&__preparedStable(fixed[0],["insideExtras"])&&__preparedStable(fixed[0],["overflowTrims"])&&__preparedStable(fixed[0],["startExtras"])&&__preparedStable(fixed[0],["widths"])));
let v1049;
const v1058=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
const v1061=depth<15&&__preparedFactories.has(34)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])));
let v1059;
return function(v1045,v1046,v1047){const v1048=1000000;
let v1052;if(v1051){if(!v1049){const v1050=__preparedFactories.get(17);v1049=v1050([fixed[0],fixed[1],true],depth+1);}v1052=v1049(v1045,v1046,v1048);}else{v1052=__fn17(v1045,v1046,v1048);}
const v1053=v1052;
let v1054;if(Object.hasOwn(v1053,"Ok")){
const v1055=v1053["Ok"];
const v1056=v1055;
const v1057=v1056;
let v1062;if(v1061){if(!v1059){const v1060=__preparedFactories.get(34);v1059=v1060([v1058,fixed[2]],depth+1);}v1062=v1059(v1057,v1047);}else{v1062=__fn34(v1057,v1047);}
v1054=v1062;}else{
const v1063=v1053["Err"];
v1054=({Err:v1063});}
return v1054;};}
function __prepareFn2(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn2;const v1070=depth<15&&__preparedFactories.has(17)&&((__preparedStable(fixed[0],["widths"])&&__preparedStable(fixed[1],[]))||(__preparedStable(fixed[0],["advances"])&&__preparedStable(fixed[0],["endTrims"])&&__preparedStable(fixed[0],["fillExtras"])&&__preparedStable(fixed[0],["flags"])&&__preparedStable(fixed[0],["graphemeStartExtras"])&&__preparedStable(fixed[0],["insideExtras"])&&__preparedStable(fixed[0],["overflowTrims"])&&__preparedStable(fixed[0],["startExtras"])&&__preparedStable(fixed[0],["widths"])));
let v1068;
const v1077=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
const v1080=depth<15&&__preparedFactories.has(30)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])));
let v1078;
return function(v1064,v1065,v1066){const v1067=1000000;
let v1071;if(v1070){if(!v1068){const v1069=__preparedFactories.get(17);v1068=v1069([fixed[0],fixed[1],true],depth+1);}v1071=v1068(v1064,v1065,v1067);}else{v1071=__fn17(v1064,v1065,v1067);}
const v1072=v1071;
let v1073;if(Object.hasOwn(v1072,"Ok")){
const v1074=v1072["Ok"];
const v1075=v1074;
const v1076=v1075;
let v1081;if(v1080){if(!v1078){const v1079=__preparedFactories.get(30);v1078=v1079([v1077,fixed[2]],depth+1);}v1081=v1078(v1076,v1066);}else{v1081=__fn30(v1076,v1066);}
v1073=v1081;}else{
const v1082=v1072["Err"];
v1073=({Err:v1082});}
return v1073;};}
function __prepareFn3(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn3;const v1089=depth<15&&__preparedFactories.has(17)&&((__preparedStable(fixed[0],["widths"])&&__preparedStable(fixed[1],[]))||(__preparedStable(fixed[0],["advances"])&&__preparedStable(fixed[0],["endTrims"])&&__preparedStable(fixed[0],["fillExtras"])&&__preparedStable(fixed[0],["flags"])&&__preparedStable(fixed[0],["graphemeStartExtras"])&&__preparedStable(fixed[0],["insideExtras"])&&__preparedStable(fixed[0],["overflowTrims"])&&__preparedStable(fixed[0],["startExtras"])&&__preparedStable(fixed[0],["widths"])));
let v1087;
const v1096=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
const v1099=depth<15&&__preparedFactories.has(28)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])));
let v1097;
return function(v1083,v1084,v1085){const v1086=1000000;
let v1090;if(v1089){if(!v1087){const v1088=__preparedFactories.get(17);v1087=v1088([fixed[0],fixed[1],true],depth+1);}v1090=v1087(v1083,v1084,v1086);}else{v1090=__fn17(v1083,v1084,v1086);}
const v1091=v1090;
let v1092;if(Object.hasOwn(v1091,"Ok")){
const v1093=v1091["Ok"];
const v1094=v1093;
const v1095=v1094;
let v1100;if(v1099){if(!v1097){const v1098=__preparedFactories.get(28);v1097=v1098([v1096,fixed[2]],depth+1);}v1100=v1097(v1095,v1085);}else{v1100=__fn28(v1095,v1085);}
v1092=v1100;}else{
const v1101=v1091["Err"];
v1092=({Err:v1101});}
return v1092;};}
function __prepareFn4(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn4;const v1109=depth<15&&__preparedFactories.has(17)&&((__preparedStable(fixed[0],["widths"])&&__preparedStable(fixed[1],[]))||(__preparedStable(fixed[0],["advances"])&&__preparedStable(fixed[0],["endTrims"])&&__preparedStable(fixed[0],["fillExtras"])&&__preparedStable(fixed[0],["flags"])&&__preparedStable(fixed[0],["graphemeStartExtras"])&&__preparedStable(fixed[0],["insideExtras"])&&__preparedStable(fixed[0],["overflowTrims"])&&__preparedStable(fixed[0],["startExtras"])&&__preparedStable(fixed[0],["widths"])));
let v1107;
const v1116=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
const v1119=depth<15&&__preparedFactories.has(35)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])));
let v1117;
return function(v1102,v1103,v1104,v1105){const v1106=1000000;
let v1110;if(v1109){if(!v1107){const v1108=__preparedFactories.get(17);v1107=v1108([fixed[0],fixed[1],true],depth+1);}v1110=v1107(v1102,v1103,v1106);}else{v1110=__fn17(v1102,v1103,v1106);}
const v1111=v1110;
let v1112;if(Object.hasOwn(v1111,"Ok")){
const v1113=v1111["Ok"];
const v1114=v1113;
const v1115=v1114;
let v1120;if(v1119){if(!v1117){const v1118=__preparedFactories.get(35);v1117=v1118([v1116,fixed[2],fixed[3]],depth+1);}v1120=v1117(v1115,v1104,v1105);}else{v1120=__fn35(v1115,v1104,v1105);}
v1112=v1120;}else{
const v1121=v1111["Err"];
v1112=({Err:v1121});}
return v1112;};}
function __prepareFn5(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn5;const v1129=depth<15&&__preparedFactories.has(17)&&((__preparedStable(fixed[0],["widths"])&&__preparedStable(fixed[1],[]))||(__preparedStable(fixed[0],["advances"])&&__preparedStable(fixed[0],["endTrims"])&&__preparedStable(fixed[0],["fillExtras"])&&__preparedStable(fixed[0],["flags"])&&__preparedStable(fixed[0],["graphemeStartExtras"])&&__preparedStable(fixed[0],["insideExtras"])&&__preparedStable(fixed[0],["overflowTrims"])&&__preparedStable(fixed[0],["startExtras"])&&__preparedStable(fixed[0],["widths"])));
let v1127;
const v1136=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
const v1139=depth<15&&__preparedFactories.has(25)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])));
let v1137;
return function(v1122,v1123,v1124,v1125){const v1126=1000000;
let v1130;if(v1129){if(!v1127){const v1128=__preparedFactories.get(17);v1127=v1128([fixed[0],fixed[1],true],depth+1);}v1130=v1127(v1122,v1123,v1126);}else{v1130=__fn17(v1122,v1123,v1126);}
const v1131=v1130;
let v1132;if(Object.hasOwn(v1131,"Ok")){
const v1133=v1131["Ok"];
const v1134=v1133;
const v1135=v1134;
let v1140;if(v1139){if(!v1137){const v1138=__preparedFactories.get(25);v1137=v1138([v1136,fixed[2],fixed[3]],depth+1);}v1140=v1137(v1135,v1124,v1125);}else{v1140=__fn25(v1135,v1124,v1125);}
v1132=v1140;}else{
const v1141=v1131["Err"];
v1132=({Err:v1141});}
return v1132;};}
function __prepareFn6(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["data","widths"])&&__preparedStable(fixed[0],["epsilon"]))||(__preparedStable(fixed[0],["data","advances"])&&__preparedStable(fixed[0],["data","endTrims"])&&__preparedStable(fixed[0],["data","fillExtras"])&&__preparedStable(fixed[0],["data","flags"])&&__preparedStable(fixed[0],["data","graphemeStartExtras"])&&__preparedStable(fixed[0],["data","insideExtras"])&&__preparedStable(fixed[0],["data","overflowTrims"])&&__preparedStable(fixed[0],["data","startExtras"])&&__preparedStable(fixed[0],["data","widths"]))))return __fn6;const v1146=depth<15&&__preparedFactories.has(34)&&((__preparedStable(fixed[0],["data","widths"])&&__preparedStable(fixed[0],["epsilon"]))||(__preparedStable(fixed[0],["data","advances"])&&__preparedStable(fixed[0],["data","endTrims"])&&__preparedStable(fixed[0],["data","fillExtras"])&&__preparedStable(fixed[0],["data","flags"])&&__preparedStable(fixed[0],["data","graphemeStartExtras"])&&__preparedStable(fixed[0],["data","insideExtras"])&&__preparedStable(fixed[0],["data","overflowTrims"])&&__preparedStable(fixed[0],["data","startExtras"])&&__preparedStable(fixed[0],["data","widths"])));
let v1144;
return function(v1142,v1143){let v1147;if(v1146){if(!v1144){const v1145=__preparedFactories.get(34);v1144=v1145([fixed[0],fixed[1]],depth+1);}v1147=v1144(v1142,v1143);}else{v1147=__fn34(v1142,v1143);}
return v1147;};}
function __prepareFn15(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],["index"])&&__preparedStable(fixed[3],["valid"]))))return __fn15;const v1182=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],["index"])&&__preparedStable(fixed[3],["valid"]);
let v1181=false,v1180;
return function(v1163,v1164,v1165,v1166){const v1167=v1166["index"];
const v1169=v1163["flags"];
const v1170=v1167;
let v1171;if(v1170<v1169.length){v1171=v1169[v1170];}else{
v1171=256;}
const v1168=v1171;
const v1173=v1168;
const v1174=15;
const v1172=(((v1173)&(v1174))>>>0);
let v1176;if(Object.hasOwn(v1165,"Some")){
const v1177=v1165["Some"];
v1176=(v1177).length;}else{
const v1178=null;
v1176=0;}
const v1175=v1176;
let v1179;if(v1182&&v1181){v1179=v1180;}else{
const v1183=v1166["valid"];
let v1184=v1183;if(v1184){
const v1185=v1168;
const v1186=255;
v1184=((v1185) <= (v1186));}
const v1187=v1184;
let v1188=v1187;if(v1188){
const v1189=v1172;
const v1190=2;
v1188=((v1189) <= (v1190));}
const v1191=v1188;
let v1192=v1191;if(v1192){
const v1193=v1168;
const v1194=32;
const v1195=(((v1193)&(v1194))>>>0);
const v1196=0;
v1192=(v1195===v1196);}
const v1197=v1192;
let v1198=v1197;if(v1198){
let v1199;if(Object.hasOwn(v1165,"Some")){
const v1200=v1165["Some"];
const v1201=v1200.length;
const v1202=0;
const v1203=((v1201) > (v1202));
let v1204=v1203;if(v1204){
const v1205=v1200.length;
const v1206=1000000;
v1204=((v1205) <= (v1206));}
const v1207=v1204;
let v1208=v1207;if(v1208){
const v1209=(v1200).length;
v1208=((v1209) <= (v1164));}
const v1210=v1208;
let v1211=v1210;if(v1211){
v1211=__fn13(v1200);}
v1199=v1211;}else{
const v1212=null;
v1199=true;}
v1198=v1199;}
const v1213=v1198;
let v1214=v1213;if(v1214){
const v1215=v1167;
const v1216=__fn9(v1163,v1215);
let v1217;if(Object.hasOwn(v1216,"Some")){
const v1218=v1216["Some"];
let v1219;if(Object.hasOwn(v1165,"Some")){
const v1220=v1165["Some"];
const v1221=v1218.length;
const v1222=v1220.length;
const v1223=((v1221) === (v1222));
let v1224=v1223;if(v1224){
v1224=__fn13(v1218);}
v1219=v1224;}else{
const v1225=null;
v1219=false;}
v1217=v1219;}else{
const v1226=null;
v1217=true;}
v1214=v1217;}
v1179=v1214;if(v1182){v1180=v1179;v1181=true;}}
const v1228=v1175;
const v1229=v1166["budget"];
const v1230=(((v1164) - (v1229)) >>> 0);
const v1227=((v1228) <= (v1230));
const v1231=v1179;
let v1232=v1231;if(v1232){
v1232=v1227;}
const v1233=v1232;
let v1234;if(v1227){
const v1235=v1166["budget"];
const v1236=v1175;
v1234=(((v1235) + (v1236)) >>> 0);}else{
v1234=v1166["budget"];}
const v1237=v1234;
const v1238=v1167;
const v1239=1;
const v1240=(((v1238) + (v1239)) >>> 0);
return ({["valid"]:v1233,["budget"]:v1237,["index"]:v1240});};}
function __prepareFn16(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["widths"])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))||(__preparedStable(fixed[0],["advances"])&&__preparedStable(fixed[0],["endTrims"])&&__preparedStable(fixed[0],["fillExtras"])&&__preparedStable(fixed[0],["flags"])&&__preparedStable(fixed[0],["graphemeStartExtras"])&&__preparedStable(fixed[0],["insideExtras"])&&__preparedStable(fixed[0],["overflowTrims"])&&__preparedStable(fixed[0],["startExtras"])&&__preparedStable(fixed[0],["widths"]))))return __fn16;const v1247=__preparedStable(fixed[0],["widths"])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v1246=false,v1245;
const v1277=__preparedStable(fixed[0],["advances"])&&__preparedStable(fixed[0],["endTrims"])&&__preparedStable(fixed[0],["fillExtras"])&&__preparedStable(fixed[0],["flags"])&&__preparedStable(fixed[0],["graphemeStartExtras"])&&__preparedStable(fixed[0],["insideExtras"])&&__preparedStable(fixed[0],["overflowTrims"])&&__preparedStable(fixed[0],["startExtras"])&&__preparedStable(fixed[0],["widths"]);
let v1276=false,v1275;
const v1342=__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[]);
let v1341=false,v1340;
return function(v1241,v1242,v1243){let v1244;if(v1247&&v1246){v1244=v1245;}else{
const v1248=0;
const v1249=(v1243===v1248);
let v1250=v1249;if(!v1250){
const v1251=1000000;
v1250=((v1243) > (v1251));}
const v1252=v1250;
let v1253=v1252;if(!v1253){
const v1254=v1241["widths"];
const v1255=v1254.length;
const v1256=1000000;
v1253=((v1255) > (v1256));}
const v1257=v1253;
let v1258=v1257;if(!v1258){
const v1259=(v1241["widths"]).length;
v1258=((v1259) > (v1243));}
const v1260=v1258;
let v1261=v1260;if(!v1261){
const v1262=v1241["widths"];
const v1263=__fn13(v1262);
const v1264=false;
v1261=(v1263===v1264);}
const v1265=v1261;
let v1266=v1265;if(!v1266){
const v1267=Number.isFinite(__dfNumber(v1242));
const v1268=false;
v1266=(v1267===v1268);}
const v1269=v1266;
let v1270=v1269;if(!v1270){
const v1271=0.0;
v1270=((__dfNumber(v1242)) < (__dfNumber(v1271)));}
v1244=v1270;if(v1247){v1245=v1244;v1246=true;}}
let v1272;if(v1244){
v1272=({None:null});}else{
const v1273=(v1241["widths"]).length;
let v1274;if(v1277&&v1276){v1274=v1275;}else{
const v1278=v1241["flags"];
const v1279=v1278.length;
const v1280=1000000;
const v1281=((v1279) > (v1280));
let v1282=v1281;if(!v1282){
const v1283=(v1241["flags"]).length;
const v1284=v1273;
v1282=!(v1283===v1284);}
const v1285=v1282;
let v1286=v1285;if(!v1286){
const v1287=v1241["advances"];
const v1288=v1287.length;
const v1289=1000000;
v1286=((v1288) > (v1289));}
const v1290=v1286;
let v1291=v1290;if(!v1291){
const v1292=(v1241["advances"]).length;
const v1293=v1273;
v1291=!(v1292===v1293);}
const v1294=v1291;
let v1295=v1294;if(!v1295){
const v1296=v1241["startExtras"];
const v1297=v1273;
const v1298=__fn14(v1296,v1297);
const v1299=false;
v1295=(v1298===v1299);}
const v1300=v1295;
let v1301=v1300;if(!v1301){
const v1302=v1241["endTrims"];
const v1303=v1273;
const v1304=__fn14(v1302,v1303);
const v1305=false;
v1301=(v1304===v1305);}
const v1306=v1301;
let v1307=v1306;if(!v1307){
const v1308=v1241["overflowTrims"];
const v1309=v1273;
const v1310=__fn14(v1308,v1309);
const v1311=false;
v1307=(v1310===v1311);}
const v1312=v1307;
let v1313=v1312;if(!v1313){
const v1314=v1241["insideExtras"];
const v1315=v1273;
const v1316=__fn14(v1314,v1315);
const v1317=false;
v1313=(v1316===v1317);}
const v1318=v1313;
let v1319=v1318;if(!v1319){
const v1320=v1241["fillExtras"];
const v1321=v1273;
const v1322=__fn14(v1320,v1321);
const v1323=false;
v1319=(v1322===v1323);}
const v1324=v1319;
let v1325=v1324;if(!v1325){
const v1326=v1241["graphemeStartExtras"];
let v1327;if(Object.hasOwn(v1326,"Some")){
const v1328=v1326["Some"];
const v1329=v1328.length;
const v1330=1000000;
const v1331=((v1329) <= (v1330));
let v1332=v1331;if(v1332){
const v1333=(v1328).length;
const v1334=v1273;
v1332=(v1333===v1334);}
v1327=v1332;}else{
const v1335=null;
v1327=true;}
const v1336=v1327;
const v1337=false;
v1325=(v1336===v1337);}
v1274=v1325;if(v1277){v1275=v1274;v1276=true;}}
let v1338;if(v1274){
v1338=({None:null});}else{
let v1339;if(v1342&&v1341){v1339=v1340;}else{
const v1343=v1241["advances"];
const v1344=true;
const v1345=v1273;
const v1346=0;
let v1347=({["valid"]:v1344,["budget"]:v1345,["index"]:v1346});
for(let v1348=0;v1348<v1343.length;v1348++){
const v1349=v1343[v1348];
const v1350=v1347;
v1347=__fn15(v1241,v1243,v1349,v1350);
}
v1339=v1347;if(v1342){v1340=v1339;v1341=true;}}
const v1351=v1339;
const v1352=v1351["valid"];
let v1353;if(v1352){
const v1354=v1339;
v1353=({Some:v1354["budget"]});}else{
v1353=({None:null});}
v1338=v1353;}
v1272=v1338;}
return v1272;};}
function __prepareFn17(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["widths"])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))||(__preparedStable(fixed[0],["advances"])&&__preparedStable(fixed[0],["endTrims"])&&__preparedStable(fixed[0],["fillExtras"])&&__preparedStable(fixed[0],["flags"])&&__preparedStable(fixed[0],["graphemeStartExtras"])&&__preparedStable(fixed[0],["insideExtras"])&&__preparedStable(fixed[0],["overflowTrims"])&&__preparedStable(fixed[0],["startExtras"])&&__preparedStable(fixed[0],["widths"]))))return __fn17;const v1360=depth<15&&__preparedFactories.has(16)&&((__preparedStable(fixed[0],["widths"])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))||(__preparedStable(fixed[0],["advances"])&&__preparedStable(fixed[0],["endTrims"])&&__preparedStable(fixed[0],["fillExtras"])&&__preparedStable(fixed[0],["flags"])&&__preparedStable(fixed[0],["graphemeStartExtras"])&&__preparedStable(fixed[0],["insideExtras"])&&__preparedStable(fixed[0],["overflowTrims"])&&__preparedStable(fixed[0],["startExtras"])&&__preparedStable(fixed[0],["widths"])));
let v1358;
return function(v1355,v1356,v1357){let v1361;if(v1360){if(!v1358){const v1359=__preparedFactories.get(16);v1358=v1359([fixed[0],fixed[1],fixed[2]],depth+1);}v1361=v1358(v1355,v1356,v1357);}else{v1361=__fn16(v1355,v1356,v1357);}
const v1362=v1361;
let v1363;if(Object.hasOwn(v1362,"Some")){
const v1364=v1362["Some"];
v1363=({Ok:({["data"]:v1355,["epsilon"]:v1356,["budget"]:v1364})});}else{
const v1365=null;
v1363=({Err:"invalid simple prepared text"});}
return v1363;};}
function __prepareFn18(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["data","widths"])&&__preparedStable(fixed[0],["epsilon"]))||(__preparedStable(fixed[0],["data","advances"])&&__preparedStable(fixed[0],["data","endTrims"])&&__preparedStable(fixed[0],["data","fillExtras"])&&__preparedStable(fixed[0],["data","flags"])&&__preparedStable(fixed[0],["data","graphemeStartExtras"])&&__preparedStable(fixed[0],["data","insideExtras"])&&__preparedStable(fixed[0],["data","overflowTrims"])&&__preparedStable(fixed[0],["data","startExtras"])&&__preparedStable(fixed[0],["data","widths"]))))return __fn18;const v1368=__preparedPart(fixed[0],["data"]);
const v1370=__preparedPart(fixed[0],["epsilon"]);
const v1374=depth<15&&__preparedFactories.has(16)&&((__preparedStable(fixed[0],["data","widths"])&&__preparedStable(fixed[0],["epsilon"]))||(__preparedStable(fixed[0],["data","advances"])&&__preparedStable(fixed[0],["data","endTrims"])&&__preparedStable(fixed[0],["data","fillExtras"])&&__preparedStable(fixed[0],["data","flags"])&&__preparedStable(fixed[0],["data","graphemeStartExtras"])&&__preparedStable(fixed[0],["data","insideExtras"])&&__preparedStable(fixed[0],["data","overflowTrims"])&&__preparedStable(fixed[0],["data","startExtras"])&&__preparedStable(fixed[0],["data","widths"])));
let v1372;
return function(v1366){const v1367=v1366["data"];
const v1369=v1366["epsilon"];
const v1371=1000000;
let v1375;if(v1374){if(!v1372){const v1373=__preparedFactories.get(16);v1372=v1373([v1368,v1370,true],depth+1);}v1375=v1372(v1367,v1369,v1371);}else{v1375=__fn16(v1367,v1369,v1371);}
const v1376=v1375;
let v1377;if(Object.hasOwn(v1376,"Some")){
const v1378=v1376["Some"];
const v1379=v1366["budget"];
v1377=(v1378===v1379);}else{
const v1380=null;
v1377=false;}
return v1377;};}
function __prepareFn21(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn21;const v1393=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
let v1392=false,v1391;
return function(v1384,v1385){const v1386=(v1384["widths"]).length;
const v1388=v1385["segment"];
const v1389=0;
const v1387=(v1388===v1389);
let v1390;if(v1393&&v1392){v1390=v1391;}else{
const v1394=v1386;
const v1395=v1385["grapheme"];
const v1396=0;
const v1397=((v1395) > (v1396));
let v1398=v1397;if(!v1398){
const v1399=v1385["segment"];
const v1400=v1386;
v1398=((v1399) >= (v1400));}
const v1401=v1398;
const v1402=({["cursor"]:v1385,["done"]:v1401});
let v1403=v1402["cursor"];
let v1404=v1402["done"];
for(let v1406=0;v1406<v1394;v1406++){
if(v1404)break;
const v1407=(v1406>>>0);
const v1409=v1403;
const v1410=v1409["segment"];
const v1411=v1387;
const v1408=__fn11(v1384,v1410,v1411);
let v1412;if(v1408){
const v1413=v1403;
const v1414=v1413["segment"];
const v1415=1;
const v1416=(((v1414) + (v1415)) >>> 0);
const v1417=0;
const v1418=({["segment"]:v1416,["grapheme"]:v1417});
const v1419=v1403;
const v1420=v1419["segment"];
const v1421=1;
const v1422=(((v1420) + (v1421)) >>> 0);
const v1423=v1386;
const v1424=((v1422) >= (v1423));
v1412=({["cursor"]:v1418,["done"]:v1424});}else{
const v1425=v1403;
const v1426=true;
v1412=({["cursor"]:v1425,["done"]:v1426});}
const v1427=v1412;
v1403=v1427["cursor"];
v1404=v1427["done"];
}
v1390=({["cursor"]:v1403,["done"]:v1404});if(v1393){v1391=v1390;v1392=true;}}
const v1428=v1390;
return v1428["cursor"];};}
function __prepareFn23(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],["index"]))))return __fn23;const v1456=__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],["index"])&&__preparedStable(fixed[2],["trimmed"])&&__preparedStable(fixed[2],["width"]);
let v1455=false,v1454;
const v1460=__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],["index"]);
let v1459=false,v1458;
return function(v1433,v1434,v1435){const v1436=v1435["index"];
const v1438=v1433["widths"];
const v1439=v1436;
let v1440;if(v1439<v1438.length){v1440=v1438[v1439];}else{
v1440=0.0;}
const v1437=v1440;
const v1442=v1433["endTrims"];
const v1443=v1436;
const v1441=__fn8(v1442,v1443);
const v1444=v1435["width"];
const v1445=v1437;
const v1446=(__dfNumber(v1444) + __dfNumber(v1445));
const v1447=v1441;
const v1448=(__dfNumber(v1446) - __dfNumber(v1447));
const v1449=((__dfNumber(v1448)) > (__dfNumber(v1434)));
let v1450;if(v1449){
const v1452=v1436;
const v1451=__fn12(v1433,v1452);
let v1453;if(v1456&&v1455){v1453=v1454;}else{
let v1457;if(v1460&&v1459){v1457=v1458;}else{
const v1461=v1451;
const v1462=false;
const v1463=(v1461===v1462);
let v1464=v1463;if(v1464){
const v1465=v1436;
const v1466=1;
const v1467=(((v1465) - (v1466)) >>> 0);
v1464=__fn12(v1433,v1467);}
v1457=v1464;if(v1460){v1458=v1457;v1459=true;}}
let v1468;if(v1457){
const v1469=v1435["width"];
const v1470=v1433["widths"];
const v1471=v1436;
const v1472=1;
const v1473=(((v1471) - (v1472)) >>> 0);
let v1474;if(v1473<v1470.length){v1474=v1470[v1473];}else{
v1474=0.0;}
const v1475=v1474;
v1468=(__dfNumber(v1469) - __dfNumber(v1475));}else{
const v1476=v1435["width"];
const v1477=v1435["trimmed"];
v1468=(__dfNumber(v1476) - __dfNumber(v1477));}
v1453=v1468;if(v1456){v1454=v1453;v1455=true;}}
let v1479;if(v1451){
const v1480=v1436;
const v1481=1;
v1479=(((v1480) + (v1481)) >>> 0);}else{
v1479=v1436;}
const v1482=v1479;
const v1483=0;
const v1478=({["segment"]:v1482,["grapheme"]:v1483});
const v1484=v1453;
const v1485=true;
const v1486=v1435["index"];
const v1487=v1435["width"];
const v1488=v1435["trimmed"];
const v1489=v1478;
const v1490=v1484;
const v1491=v1485;
v1450=({["index"]:v1486,["width"]:v1487,["trimmed"]:v1488,["end"]:v1489,["result"]:v1490,["done"]:v1491});}else{
const v1493=v1435["width"];
const v1494=v1437;
const v1492=(__dfNumber(v1493) + __dfNumber(v1494));
const v1496=v1436;
const v1497=1;
const v1495=(((v1496) + (v1497)) >>> 0);
const v1498=v1492;
const v1500=v1492;
const v1501=((__dfNumber(v1500)) > (__dfNumber(v1434)));
let v1502;if(v1501){
v1502=v1441;}else{
v1502=0.0;}
const v1499=v1502;
const v1503=v1495;
const v1504=v1498;
const v1505=v1499;
const v1506=v1435["end"];
const v1507=v1435["result"];
const v1508=v1435["done"];
v1450=({["index"]:v1503,["width"]:v1504,["trimmed"]:v1505,["end"]:v1506,["result"]:v1507,["done"]:v1508});}
return v1450;};}
function __prepareFn24(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["data"])&&__preparedStable(fixed[1],[]))))return __fn24;const v1583=__preparedStable(fixed[0],["data"])&&__preparedStable(fixed[1],[]);
let v1582=false,v1581;
const v1618=__preparedStable(fixed[0],["data"])&&__preparedStable(fixed[0],["epsilon"])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v1617=false,v1616;
let v1654=false,v1653;
return function(v1509,v1510,v1511){const v1512=v1509["data"];
const v1513=__fn20(v1509,v1511);
const v1515=v1512;
const v1514=(v1515["widths"]).length;
const v1516=v1510["segment"];
const v1518=v1512;
const v1519=v1518["advances"];
const v1520=v1516;
let v1521;if(v1520<v1519.length){v1521=v1519[v1520];}else{
v1521=({None:null});}
const v1517=v1521;
const v1523=v1512;
const v1524=v1523["startExtras"];
let v1525;if(Object.hasOwn(v1524,"Some")){
const v1526=v1524["Some"];
const v1527=v1512;
const v1528=v1527["widths"];
const v1529=v1516;
let v1530;if(v1529<v1528.length){v1530=v1528[v1529];}else{
v1530=0.0;}
const v1531=v1530;
const v1532=v1516;
let v1533;if(v1532<v1526.length){v1533=v1526[v1532];}else{
v1533=0.0;}
const v1534=v1533;
v1525=(__dfNumber(v1531) + __dfNumber(v1534));}else{
const v1535=null;
const v1536=v1512;
const v1537=v1536["widths"];
const v1538=v1516;
let v1539;if(v1538<v1537.length){v1539=v1537[v1538];}else{
v1539=0.0;}
v1525=v1539;}
const v1522=v1525;
const v1541=v1512;
const v1542=v1541["endTrims"];
const v1543=v1516;
const v1540=__fn8(v1542,v1543);
const v1545=v1512;
const v1546=v1545["overflowTrims"];
let v1547;if(Object.hasOwn(v1546,"Some")){
const v1548=v1546["Some"];
const v1549=v1522;
const v1550=v1516;
let v1551;if(v1550<v1548.length){v1551=v1548[v1550];}else{
v1551=0.0;}
const v1552=v1551;
const v1553=(__dfNumber(v1549) - __dfNumber(v1552));
const v1554=v1513;
const v1555=((__dfNumber(v1553)) <= (__dfNumber(v1554)));
let v1556;if(v1555){
const v1557=v1516;
let v1558;if(v1557<v1548.length){v1558=v1548[v1557];}else{
v1558=0.0;}
v1556=v1558;}else{
v1556=v1540;}
v1547=v1556;}else{
const v1559=null;
v1547=v1540;}
const v1544=v1547;
const v1561=v1510["grapheme"];
const v1562=0;
const v1563=((v1561) > (v1562));
let v1564=v1563;if(!v1564){
const v1565=v1522;
const v1566=v1544;
const v1567=(__dfNumber(v1565) - __dfNumber(v1566));
const v1568=v1513;
const v1569=((__dfNumber(v1567)) > (__dfNumber(v1568)));
let v1570=v1569;if(v1570){
const v1571=v1517;
let v1572;if(Object.hasOwn(v1571,"Some")){
const v1573=v1571["Some"];
v1572=true;}else{
const v1574=null;
v1572=false;}
v1570=v1572;}
v1564=v1570;}
const v1560=v1564;
const v1576=v1517;
let v1577;if(Object.hasOwn(v1576,"Some")){
const v1578=v1576["Some"];
v1577=v1578;}else{
const v1579=null;
v1577=[];}
const v1575=v1577;
let v1580;if(v1583&&v1582){v1580=v1581;}else{
const v1584=v1512;
const v1585=v1516;
const v1586=__fn9(v1584,v1585);
let v1587;if(Object.hasOwn(v1586,"Some")){
const v1588=v1586["Some"];
const v1589=v1575;
const v1590=v1510["grapheme"];
let v1591;if(v1590<v1589.length){v1591=v1589[v1590];}else{
v1591=0.0;}
const v1592=v1591;
const v1593=v1510["grapheme"];
let v1594;if(v1593<v1588.length){v1594=v1588[v1593];}else{
v1594=0.0;}
const v1595=v1594;
v1587=(__dfNumber(v1592) + __dfNumber(v1595));}else{
const v1596=null;
const v1597=v1575;
const v1598=v1510["grapheme"];
let v1599;if(v1598<v1597.length){v1599=v1597[v1598];}else{
v1599=0.0;}
v1587=v1599;}
v1580=v1587;if(v1583){v1581=v1580;v1582=true;}}
const v1601=v1510["grapheme"];
const v1602=0;
const v1603=((v1601) > (v1602));
let v1604;if(v1603){
const v1605=v1512;
v1604=v1605["insideExtras"];}else{
const v1606=v1512;
v1604=v1606["fillExtras"];}
const v1607=v1604;
let v1608;if(Object.hasOwn(v1607,"Some")){
const v1609=v1607["Some"];
const v1610=v1580;
const v1611=v1516;
let v1612;if(v1611<v1609.length){v1612=v1609[v1611];}else{
v1612=0.0;}
const v1613=v1612;
v1608=(__dfNumber(v1610) + __dfNumber(v1613));}else{
const v1614=null;
v1608=v1580;}
const v1600=v1608;
let v1615;if(v1618&&v1617){v1615=v1616;}else{
const v1619=v1560;
let v1620;if(v1619){
const v1621=v1575;
const v1622=v1510["grapheme"];
const v1623=1;
const v1624=(((v1622) + (v1623)) >>> 0);
const v1625=v1600;
const v1626=v1513;
v1620=__fn22(v1621,v1624,v1625,v1626);}else{
const v1627=(v1575).length;
const v1628=v1522;
const v1629=false;
v1620=({["index"]:v1627,["width"]:v1628,["done"]:v1629});}
v1615=v1620;if(v1618){v1616=v1615;v1617=true;}}
const v1630=v1560;
let v1631=v1630;if(v1631){
const v1632=v1615;
const v1633=v1632["index"];
const v1634=(v1575).length;
v1631=((v1633) < (v1634));}
const v1635=v1631;
let v1636;if(v1635){
const v1637=v1615;
const v1638=v1637["width"];
const v1639=v1516;
const v1640=v1615;
const v1641=v1640["index"];
const v1642=({["segment"]:v1639,["grapheme"]:v1641});
v1636=({["width"]:v1638,["start"]:v1510,["end"]:v1642});}else{
const v1644=v1560;
const v1645=false;
const v1646=(v1644===v1645);
let v1647=v1646;if(v1647){
const v1648=v1522;
const v1649=v1513;
v1647=((__dfNumber(v1648)) > (__dfNumber(v1649)));}
const v1650=v1647;
let v1651;if(v1650){
v1651=v1544;}else{
v1651=0.0;}
const v1643=v1651;
let v1652;if(v1618&&v1654){v1652=v1653;}else{
const v1655=v1514;
const v1656=v1516;
const v1657=1;
const v1658=(((v1656) + (v1657)) >>> 0);
const v1659=v1615;
const v1660=v1659["width"];
const v1661=v1643;
const v1662=v1514;
const v1663=0;
const v1664=({["segment"]:v1662,["grapheme"]:v1663});
const v1665=0.0;
const v1666=false;
const v1667=({["index"]:v1658,["width"]:v1660,["trimmed"]:v1661,["end"]:v1664,["result"]:v1665,["done"]:v1666});
let v1668=v1667["index"];
let v1669=v1667["width"];
let v1670=v1667["trimmed"];
let v1671=v1667["end"];
let v1672=v1667["result"];
let v1673=v1667["done"];
for(let v1675=0;v1675<v1655;v1675++){
const v1676=v1673;
let v1677=v1676;if(!v1677){
const v1678=v1668;
const v1679=v1514;
v1677=((v1678) >= (v1679));}
if(v1677)break;
const v1680=(v1675>>>0);
const v1681=v1512;
const v1682=v1513;
const v1684=v1668;
const v1685=v1681["widths"];
let v1686;if(v1684<v1685.length){v1686=v1685[v1684];}else{
v1686=0.0;}
const v1687=v1686;
const v1688=v1681["endTrims"];
const v1689=__fn8(v1688,v1684);
const v1690=v1669;
const v1691=(__dfNumber(v1690) + __dfNumber(v1687));
const v1692=(__dfNumber(v1691) - __dfNumber(v1689));
let v1693;
let v1694;
let v1695;
let v1696;
let v1697;
let v1698;
if(((__dfNumber(v1692)) > (__dfNumber(v1682)))){
const v1699=__fn12(v1681,v1684);
const v1700=false;
const v1701=(v1699===v1700);
let v1702=v1701;if(v1702){
const v1703=1;
const v1704=(((v1684) - (v1703)) >>> 0);
v1702=__fn12(v1681,v1704);}
let v1705;if(v1702){
const v1706=v1669;
const v1707=v1681["widths"];
const v1708=1;
const v1709=(((v1684) - (v1708)) >>> 0);
let v1710;if(v1709<v1707.length){v1710=v1707[v1709];}else{
v1710=0.0;}
const v1711=v1710;
v1705=(__dfNumber(v1706) - __dfNumber(v1711));}else{
const v1712=v1669;
const v1713=v1670;
v1705=(__dfNumber(v1712) - __dfNumber(v1713));}
const v1714=v1705;
let v1715;if(v1699){
const v1716=1;
v1715=(((v1684) + (v1716)) >>> 0);}else{
v1715=v1684;}
const v1717=v1715;
const v1718=0;
const v1720=true;
const v1721=v1668;
const v1722=v1669;
const v1723=v1670;
const v1724=({["segment"]:v1717,["grapheme"]:v1718});
v1693=v1721;
v1694=v1722;
v1695=v1723;
v1696=v1724;
v1697=v1714;
v1698=v1720;
}else{
const v1725=v1669;
const v1726=(__dfNumber(v1725) + __dfNumber(v1687));
const v1727=1;
const v1728=(((v1684) + (v1727)) >>> 0);
let v1729;if(((__dfNumber(v1726)) > (__dfNumber(v1682)))){
v1729=v1689;}else{
v1729=0.0;}
const v1730=v1729;
const v1731=v1671;
const v1732=v1672;
const v1733=v1673;
v1693=v1728;
v1694=v1726;
v1695=v1730;
v1696=v1731;
v1697=v1732;
v1698=v1733;
}
v1668=v1693;
v1669=v1694;
v1670=v1695;
v1671=v1696;
v1672=v1697;
v1673=v1698;
}
v1652=({["index"]:v1668,["width"]:v1669,["trimmed"]:v1670,["end"]:v1671,["result"]:v1672,["done"]:v1673});if(v1618){v1653=v1652;v1654=true;}}
const v1734=v1652;
let v1735;if(v1734["done"]){
const v1736=v1652;
v1735=v1736["result"];}else{
const v1737=v1652;
const v1738=v1737["width"];
const v1739=v1652;
const v1740=v1739["trimmed"];
v1735=(__dfNumber(v1738) - __dfNumber(v1740));}
const v1741=v1735;
const v1742=v1652;
const v1743=v1742["end"];
v1636=({["width"]:v1741,["start"]:v1510,["end"]:v1743});}
return v1636;};}
function __prepareFn25(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["data","widths"])&&__preparedStable(fixed[0],["epsilon"]))||(__preparedStable(fixed[0],["data","advances"])&&__preparedStable(fixed[0],["data","endTrims"])&&__preparedStable(fixed[0],["data","fillExtras"])&&__preparedStable(fixed[0],["data","flags"])&&__preparedStable(fixed[0],["data","graphemeStartExtras"])&&__preparedStable(fixed[0],["data","insideExtras"])&&__preparedStable(fixed[0],["data","overflowTrims"])&&__preparedStable(fixed[0],["data","startExtras"])&&__preparedStable(fixed[0],["data","widths"]))))return __fn25;const v1750=__preparedStable(fixed[0],[]);
let v1749=false,v1748;
const v1757=depth<15&&__preparedFactories.has(18)&&((__preparedStable(fixed[0],["data","widths"])&&__preparedStable(fixed[0],["epsilon"]))||(__preparedStable(fixed[0],["data","advances"])&&__preparedStable(fixed[0],["data","endTrims"])&&__preparedStable(fixed[0],["data","fillExtras"])&&__preparedStable(fixed[0],["data","flags"])&&__preparedStable(fixed[0],["data","graphemeStartExtras"])&&__preparedStable(fixed[0],["data","insideExtras"])&&__preparedStable(fixed[0],["data","overflowTrims"])&&__preparedStable(fixed[0],["data","startExtras"])&&__preparedStable(fixed[0],["data","widths"])));
let v1755;
let v1760;
const v1769=__preparedStable(fixed[0],["data","advances"])&&__preparedStable(fixed[0],["data","widths"])&&__preparedStable(fixed[1],[]);
let v1768=false,v1767;
const v1802=__preparedStable(fixed[0],["data"])&&__preparedStable(fixed[1],[]);
let v1801=false,v1800;
const v1804=__preparedPart(fixed[0],["data"]);
const v1807=depth<15&&__preparedFactories.has(21)&&((__preparedStable(fixed[0],["data"])&&__preparedStable(fixed[1],[])));
let v1805;
const v1816=__preparedStable(fixed[2],[]);
const v1819=depth<15&&__preparedFactories.has(24)&&((__preparedStable(fixed[0],["data"])&&__preparedStable(fixed[1],[])));
let v1817;
return function(v1744,v1745,v1746){let v1747;if(v1750&&v1749){v1747=v1748;}else{
const v1751=({Some:null});
const v1752=v1751;
let v1753;if(Object.hasOwn(v1752,"Some")){
const v1754=v1752["Some"];
let v1758;if(v1757){if(!v1755){const v1756=__preparedFactories.get(18);v1755=v1756([fixed[0]],depth+1);}v1758=v1755(v1744);}else{v1758=__fn18(v1744);}
v1753=v1758;}else{
const v1759=null;
let v1762;if(v1757){if(!v1760){const v1761=__preparedFactories.get(18);v1760=v1761([fixed[0]],depth+1);}v1762=v1760(v1744);}else{v1762=__fn18(v1744);}
v1753=v1762;}
v1747=v1753;if(v1750){v1748=v1747;v1749=true;}}
let v1763;if(v1747){
const v1765=v1744["data"];
const v1764=(v1765["widths"]).length;
let v1766;if(v1769&&v1768){v1766=v1767;}else{
const v1770=v1745["segment"];
const v1771=v1764;
const v1772=((v1770) > (v1771));
let v1773=v1772;if(!v1773){
const v1774=v1745["segment"];
const v1775=v1764;
const v1776=(v1774===v1775);
let v1777=v1776;if(v1777){
const v1778=v1745["grapheme"];
const v1779=0;
v1777=((v1778) > (v1779));}
v1773=v1777;}
const v1780=v1773;
let v1781=v1780;if(!v1781){
const v1782=v1745["grapheme"];
const v1783=0;
const v1784=((v1782) > (v1783));
let v1785=v1784;if(v1785){
const v1786=v1744["data"];
const v1787=v1786["advances"];
const v1788=v1745["segment"];
let v1789;if(v1788<v1787.length){v1789=v1787[v1788];}else{
v1789=({None:null});}
const v1790=v1789;
let v1791;if(Object.hasOwn(v1790,"Some")){
const v1792=v1790["Some"];
const v1793=v1745["grapheme"];
const v1794=(v1792).length;
v1791=((v1793) < (v1794));}else{
const v1795=null;
v1791=false;}
const v1796=v1791;
const v1797=false;
v1785=(v1796===v1797);}
v1781=v1785;}
v1766=v1781;if(v1769){v1767=v1766;v1768=true;}}
let v1798;if(v1766){
v1798=({Err:"invalid line cursor"});}else{
let v1799;if(v1802&&v1801){v1799=v1800;}else{
const v1803=v1744["data"];
let v1808;if(v1807){if(!v1805){const v1806=__preparedFactories.get(21);v1805=v1806([v1804,fixed[1]],depth+1);}v1808=v1805(v1803,v1745);}else{v1808=__fn21(v1803,v1745);}
v1799=v1808;if(v1802){v1800=v1799;v1801=true;}}
const v1809=v1799;
const v1810=v1809["segment"];
const v1811=v1764;
const v1812=((v1810) >= (v1811));
let v1813;if(v1812){
v1813=({Ok:({None:null})});}else{
const v1814=v1799;
const v1815=__fn19(v1746);
let v1820;if(v1819){if(!v1817){const v1818=__preparedFactories.get(24);v1817=v1818([fixed[0],v1802,v1816],depth+1);}v1820=v1817(v1744,v1814,v1815);}else{v1820=__fn24(v1744,v1814,v1815);}
const v1821=v1820;
const v1823=({Some:v1821});
v1813=({Ok:v1823});}
v1798=v1813;}
v1763=v1798;}else{
const v1825=({Some:null});
let v1826;if(Object.hasOwn(v1825,"Some")){
const v1827=v1825["Some"];
v1826="invalid prepared text";}else{
const v1828=null;
v1826="invalid prepared text";}
v1763=({Err:v1826});}
return v1763;};}
function __prepareFn26(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["data"])&&__preparedStable(fixed[2],["cursor"]))))return __fn26;const v1835=__preparedStable(fixed[0],["data"])&&__preparedStable(fixed[2],["cursor"]);
let v1834=false,v1833;
const v1837=__preparedPart(fixed[0],["data"]);
const v1839=__preparedPart(fixed[2],["cursor"]);
const v1842=depth<15&&__preparedFactories.has(21)&&((__preparedStable(fixed[0],["data"])&&__preparedStable(fixed[2],["cursor"])));
let v1840;
const v1857=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],["cursor"]);
let v1856=false,v1855;
const v1861=depth<15&&__preparedFactories.has(24)&&((__preparedStable(fixed[0],["data"])&&__preparedStable(fixed[2],["cursor"])));
let v1859;
return function(v1829,v1830,v1831){let v1832;if(v1835&&v1834){v1832=v1833;}else{
const v1836=v1829["data"];
const v1838=v1831["cursor"];
let v1843;if(v1842){if(!v1840){const v1841=__preparedFactories.get(21);v1840=v1841([v1837,v1839],depth+1);}v1843=v1840(v1836,v1838);}else{v1843=__fn21(v1836,v1838);}
v1832=v1843;if(v1835){v1833=v1832;v1834=true;}}
const v1844=v1832;
const v1845=v1844["segment"];
const v1846=v1829["data"];
const v1847=(v1846["widths"]).length;
const v1848=((v1845) >= (v1847));
let v1849;if(v1848){
const v1850=true;
const v1851=v1831["cursor"];
const v1852=v1831["stats"];
const v1853=v1850;
v1849=({["cursor"]:v1851,["stats"]:v1852,["done"]:v1853});}else{
let v1854;if(v1857&&v1856){v1854=v1855;}else{
const v1858=v1832;
let v1862;if(v1861){if(!v1859){const v1860=__preparedFactories.get(24);v1859=v1860([fixed[0],v1835,fixed[1]],depth+1);}v1862=v1859(v1829,v1858,v1830);}else{v1862=__fn24(v1829,v1858,v1830);}
v1854=v1862;if(v1857){v1855=v1854;v1856=true;}}
const v1863=v1854;
const v1864=v1863["end"];
const v1865=v1831["stats"];
const v1866=v1865["lineCount"];
const v1867=1;
const v1868=(((v1866) + (v1867)) >>> 0);
const v1869=v1854;
const v1870=v1869["width"];
const v1871=v1831["stats"];
const v1872=v1871["maxLineWidth"];
let v1873;if(((__dfNumber(v1870)) > (__dfNumber(v1872)))){
const v1874=v1854;
v1873=v1874["width"];}else{
const v1875=v1831["stats"];
v1873=v1875["maxLineWidth"];}
const v1876=v1873;
const v1877=({["lineCount"]:v1868,["maxLineWidth"]:v1876});
const v1878=false;
v1849=({["cursor"]:v1864,["stats"]:v1877,["done"]:v1878});}
return v1849;};}
function __prepareFn27(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn27;const v1884=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
let v1883=false,v1882;
return function(v1879,v1880){let v1881;if(v1884&&v1883){v1881=v1882;}else{
const v1885=v1879["budget"];
const v1886=1;
const v1887=(((v1885) + (v1886)) >>> 0);
const v1888=0;
const v1889=0;
const v1890=({["segment"]:v1888,["grapheme"]:v1889});
const v1891=0;
const v1892=0.0;
const v1893=({["lineCount"]:v1891,["maxLineWidth"]:v1892});
const v1894=false;
const v1895=({["cursor"]:v1890,["stats"]:v1893,["done"]:v1894});
let v1896=v1895["cursor"];
let v1897=v1895["stats"];
let v1898=v1895["done"];
for(let v1900=0;v1900<v1887;v1900++){
if(v1898)break;
const v1901=(v1900>>>0);
const v1903=v1879["data"];
const v1904=v1896;
const v1905=__fn21(v1903,v1904);
const v1906=v1905["segment"];
const v1907=v1879["data"];
const v1908=(v1907["widths"]).length;
let v1909;
let v1910;
let v1911;
if(((v1906) >= (v1908))){
const v1912=true;
const v1913=v1896;
const v1914=v1897;
v1909=v1913;
v1910=v1914;
v1911=v1912;
}else{
const v1915=__fn24(v1879,v1905,v1880);
const v1916=v1915["end"];
const v1917=v1897;
const v1918=v1917["lineCount"];
const v1919=1;
const v1920=(((v1918) + (v1919)) >>> 0);
const v1921=v1915["width"];
const v1922=v1897;
const v1923=v1922["maxLineWidth"];
let v1924;if(((__dfNumber(v1921)) > (__dfNumber(v1923)))){
v1924=v1915["width"];}else{
const v1925=v1897;
v1924=v1925["maxLineWidth"];}
const v1926=v1924;
const v1927=({["lineCount"]:v1920,["maxLineWidth"]:v1926});
const v1928=false;
v1909=v1916;
v1910=v1927;
v1911=v1928;
}
v1896=v1909;
v1897=v1910;
v1898=v1911;
}
v1881=({["cursor"]:v1896,["stats"]:v1897,["done"]:v1898});if(v1884){v1882=v1881;v1883=true;}}
const v1929=v1881;
return v1929["stats"];};}
function __prepareFn28(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["data","widths"])&&__preparedStable(fixed[0],["epsilon"]))||(__preparedStable(fixed[0],["data","advances"])&&__preparedStable(fixed[0],["data","endTrims"])&&__preparedStable(fixed[0],["data","fillExtras"])&&__preparedStable(fixed[0],["data","flags"])&&__preparedStable(fixed[0],["data","graphemeStartExtras"])&&__preparedStable(fixed[0],["data","insideExtras"])&&__preparedStable(fixed[0],["data","overflowTrims"])&&__preparedStable(fixed[0],["data","startExtras"])&&__preparedStable(fixed[0],["data","widths"]))))return __fn28;const v1935=__preparedStable(fixed[0],[]);
let v1934=false,v1933;
const v1942=depth<15&&__preparedFactories.has(18)&&((__preparedStable(fixed[0],["data","widths"])&&__preparedStable(fixed[0],["epsilon"]))||(__preparedStable(fixed[0],["data","advances"])&&__preparedStable(fixed[0],["data","endTrims"])&&__preparedStable(fixed[0],["data","fillExtras"])&&__preparedStable(fixed[0],["data","flags"])&&__preparedStable(fixed[0],["data","graphemeStartExtras"])&&__preparedStable(fixed[0],["data","insideExtras"])&&__preparedStable(fixed[0],["data","overflowTrims"])&&__preparedStable(fixed[0],["data","startExtras"])&&__preparedStable(fixed[0],["data","widths"])));
let v1940;
let v1945;
const v1950=__preparedStable(fixed[1],[]);
const v1953=depth<15&&__preparedFactories.has(27)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])));
let v1951;
return function(v1930,v1931){let v1932;if(v1935&&v1934){v1932=v1933;}else{
const v1936=({Some:null});
const v1937=v1936;
let v1938;if(Object.hasOwn(v1937,"Some")){
const v1939=v1937["Some"];
let v1943;if(v1942){if(!v1940){const v1941=__preparedFactories.get(18);v1940=v1941([fixed[0]],depth+1);}v1943=v1940(v1930);}else{v1943=__fn18(v1930);}
v1938=v1943;}else{
const v1944=null;
let v1947;if(v1942){if(!v1945){const v1946=__preparedFactories.get(18);v1945=v1946([fixed[0]],depth+1);}v1947=v1945(v1930);}else{v1947=__fn18(v1930);}
v1938=v1947;}
v1932=v1938;if(v1935){v1933=v1932;v1934=true;}}
let v1948;if(v1932){
const v1949=__fn19(v1931);
let v1954;if(v1953){if(!v1951){const v1952=__preparedFactories.get(27);v1951=v1952([fixed[0],v1950],depth+1);}v1954=v1951(v1930,v1949);}else{v1954=__fn27(v1930,v1949);}
const v1955=v1954;
v1948=({Ok:v1955});}else{
const v1957=({Some:null});
let v1958;if(Object.hasOwn(v1957,"Some")){
const v1959=v1957["Some"];
v1958="invalid prepared text";}else{
const v1960=null;
v1958="invalid prepared text";}
v1948=({Err:v1958});}
return v1948;};}
function __prepareFn30(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["data","widths"])&&__preparedStable(fixed[0],["epsilon"]))||(__preparedStable(fixed[0],["data","advances"])&&__preparedStable(fixed[0],["data","endTrims"])&&__preparedStable(fixed[0],["data","fillExtras"])&&__preparedStable(fixed[0],["data","flags"])&&__preparedStable(fixed[0],["data","graphemeStartExtras"])&&__preparedStable(fixed[0],["data","insideExtras"])&&__preparedStable(fixed[0],["data","overflowTrims"])&&__preparedStable(fixed[0],["data","startExtras"])&&__preparedStable(fixed[0],["data","widths"]))))return __fn30;const v1966=__preparedStable(fixed[0],[]);
let v1965=false,v1964;
const v1973=depth<15&&__preparedFactories.has(18)&&((__preparedStable(fixed[0],["data","widths"])&&__preparedStable(fixed[0],["epsilon"]))||(__preparedStable(fixed[0],["data","advances"])&&__preparedStable(fixed[0],["data","endTrims"])&&__preparedStable(fixed[0],["data","fillExtras"])&&__preparedStable(fixed[0],["data","flags"])&&__preparedStable(fixed[0],["data","graphemeStartExtras"])&&__preparedStable(fixed[0],["data","insideExtras"])&&__preparedStable(fixed[0],["data","overflowTrims"])&&__preparedStable(fixed[0],["data","startExtras"])&&__preparedStable(fixed[0],["data","widths"])));
let v1971;
let v1976;
return function(v1961,v1962){let v1963;if(v1966&&v1965){v1963=v1964;}else{
const v1967=({Some:null});
const v1968=v1967;
let v1969;if(Object.hasOwn(v1968,"Some")){
const v1970=v1968["Some"];
let v1974;if(v1973){if(!v1971){const v1972=__preparedFactories.get(18);v1971=v1972([fixed[0]],depth+1);}v1974=v1971(v1961);}else{v1974=__fn18(v1961);}
v1969=v1974;}else{
const v1975=null;
let v1978;if(v1973){if(!v1976){const v1977=__preparedFactories.get(18);v1976=v1977([fixed[0]],depth+1);}v1978=v1976(v1961);}else{v1978=__fn18(v1961);}
v1969=v1978;}
v1963=v1969;if(v1966){v1964=v1963;v1965=true;}}
let v1979;if(v1963){
const v1981=v1961["budget"];
const v1982=1;
const v1983=(((v1981) + (v1982)) >>> 0);
const v1984=0;
const v1985=0;
const v1986=({["segment"]:v1984,["grapheme"]:v1985});
const v1987=new __InkBuffer([]);
const v1988=false;
let v1989=({["cursor"]:v1986,["lines"]:v1987,["done"]:v1988});
for(let v1990=0;v1990<v1983;v1990++){
const v1991=v1989;
if(v1991["done"]){break;}
const v1992=(v1990>>>0);
const v1993=__fn19(v1962);
const v1994=v1989;
v1989=__fn29(v1961,v1993,v1994);}
const v1980=v1989;
const v1995=v1980;
const v1996=v1995["lines"];
v1979=({Ok:v1996.freeze()});}else{
const v1997=({Some:null});
let v1998;if(Object.hasOwn(v1997,"Some")){
const v1999=v1997["Some"];
v1998="invalid prepared text";}else{
const v2000=null;
v1998="invalid prepared text";}
v1979=({Err:v1998});}
return v1979;};}
function __prepareFn32(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[]))))return __fn32;const v2026=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[]);
let v2025=false,v2024;
return function(v2005,v2006,v2007,v2008){const v2010=v2008["count"];
const v2011=v2010["width"];
let v2012;if(Object.hasOwn(v2006,"Some")){
const v2013=v2006["Some"];
const v2014=v2008["index"];
let v2015;if(v2014<v2013.length){v2015=v2013[v2014];}else{
v2015=0.0;}
v2012=v2015;}else{
const v2016=null;
v2012=0.0;}
const v2017=v2012;
const v2009=(__dfNumber(v2011) + __dfNumber(v2017));
const v2019=v2009;
const v2020=v2008["index"];
let v2021;if(v2020<v2005.length){v2021=v2005[v2020];}else{
v2021=0.0;}
const v2022=v2021;
const v2018=(__dfNumber(v2019) + __dfNumber(v2022));
let v2023;if(v2026&&v2025){v2023=v2024;}else{
const v2027=v2008["index"];
const v2028=1;
const v2029=(((v2027) + (v2028)) >>> 0);
const v2030=v2018;
v2023=__fn31(v2005,v2029,v2030,v2007);if(v2026){v2024=v2023;v2025=true;}}
const v2031=v2023;
const v2032=v2031["index"];
const v2033=(v2005).length;
const v2034=((v2032) < (v2033));
let v2035;if(v2034){
const v2036=v2008["count"];
const v2037=v2036["lines"];
const v2038=1;
const v2039=(((v2037) + (v2038)) >>> 0);
const v2040=0.0;
const v2041=false;
const v2042=({["lines"]:v2039,["width"]:v2040,["content"]:v2041});
const v2043=v2023;
const v2044=v2043["index"];
v2035=({["count"]:v2042,["index"]:v2044});}else{
const v2045=v2008["count"];
const v2046=v2045["lines"];
const v2047=v2023;
const v2048=v2047["width"];
const v2049=true;
const v2050=({["lines"]:v2046,["width"]:v2048,["content"]:v2049});
const v2051=v2023;
const v2052=v2051["index"];
v2035=({["count"]:v2050,["index"]:v2052});}
return v2035;};}
function __prepareFn33(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[]))))return __fn33;const v2147=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[]);
let v2146=false,v2145;
return function(v2053,v2054,v2055,v2056){const v2057=__fn10(v2053,v2055);
const v2059=v2053["widths"];
let v2060;if(v2055<v2059.length){v2060=v2059[v2055];}else{
v2060=0.0;}
const v2058=v2060;
const v2062=v2053["endTrims"];
const v2061=__fn8(v2062,v2055);
const v2063=v2056["content"];
let v2064=v2063;if(v2064){
const v2065=v2056["width"];
const v2066=v2058;
const v2067=(__dfNumber(v2065) + __dfNumber(v2066));
const v2068=v2061;
const v2069=(__dfNumber(v2067) - __dfNumber(v2068));
v2064=((__dfNumber(v2069)) <= (__dfNumber(v2054)));}
const v2070=v2064;
let v2071;if(v2070){
const v2073=v2056["width"];
const v2074=v2058;
const v2072=(__dfNumber(v2073) + __dfNumber(v2074));
const v2075=v2056["lines"];
const v2076=v2072;
const v2077=v2056["content"];
v2071=({["lines"]:v2075,["width"]:v2076,["content"]:v2077});}else{
const v2078=v2056["content"];
const v2080=v2078;
let v2081;if(v2080){
const v2082=v2056["lines"];
const v2083=1;
const v2084=(((v2082) + (v2083)) >>> 0);
const v2085=0.0;
const v2086=false;
v2081=({["lines"]:v2084,["width"]:v2085,["content"]:v2086});}else{
v2081=v2056;}
const v2079=v2081;
const v2087=v2078;
let v2088=v2087;if(v2088){
const v2089=v2057;
const v2090=0;
v2088=!(v2089===v2090);}
const v2091=v2088;
let v2092=v2091;if(!v2092){
const v2093=v2078;
const v2094=false;
const v2095=(v2093===v2094);
let v2096=v2095;if(v2096){
const v2097=v2057;
const v2098=1;
const v2099=(v2097===v2098);
let v2100=v2099;if(!v2100){
const v2101=v2057;
const v2102=2;
const v2103=(v2101===v2102);
let v2104=v2103;if(v2104){
const v2105=0;
v2104=((v2055) > (v2105));}
v2100=v2104;}
v2096=v2100;}
v2092=v2096;}
const v2106=v2092;
let v2107;if(v2106){
v2107=v2079;}else{
const v2109=v2053["startExtras"];
let v2110;if(Object.hasOwn(v2109,"Some")){
const v2111=v2109["Some"];
const v2112=v2058;
let v2113;if(v2055<v2111.length){v2113=v2111[v2055];}else{
v2113=0.0;}
const v2114=v2113;
v2110=(__dfNumber(v2112) + __dfNumber(v2114));}else{
const v2115=null;
v2110=v2058;}
const v2108=v2110;
const v2117=v2053["advances"];
let v2118;if(v2055<v2117.length){v2118=v2117[v2055];}else{
v2118=({None:null});}
const v2116=v2118;
const v2119=v2108;
const v2120=v2061;
const v2121=(__dfNumber(v2119) - __dfNumber(v2120));
const v2122=((__dfNumber(v2121)) <= (__dfNumber(v2054)));
let v2123=v2122;if(!v2123){
const v2124=v2116;
let v2125;if(Object.hasOwn(v2124,"Some")){
const v2126=v2124["Some"];
v2125=false;}else{
const v2127=null;
v2125=true;}
v2123=v2125;}
const v2128=v2123;
let v2129;if(v2128){
const v2131=v2079;
const v2132=v2131["width"];
const v2133=v2108;
const v2130=(__dfNumber(v2132) + __dfNumber(v2133));
const v2134=true;
const v2135=v2079;
const v2136=v2135["lines"];
const v2137=v2130;
const v2138=v2134;
v2129=({["lines"]:v2136,["width"]:v2137,["content"]:v2138});}else{
const v2140=v2116;
let v2141;if(Object.hasOwn(v2140,"Some")){
const v2142=v2140["Some"];
v2141=v2142;}else{
const v2143=null;
v2141=[];}
const v2139=v2141;
let v2144;if(v2147&&v2146){v2144=v2145;}else{
const v2148=(v2139).length;
const v2149=v2079;
const v2150=0;
const v2151=({["count"]:v2149,["index"]:v2150});
let v2152=v2151["count"];
let v2153=v2151["index"];
for(let v2155=0;v2155<v2148;v2155++){
const v2156=v2153;
const v2157=(v2139).length;
if(((v2156) >= (v2157)))break;
const v2158=(v2155>>>0);
const v2159=v2139;
const v2160=__fn9(v2053,v2055);
const v2162=v2152;
const v2163=v2162["width"];
let v2164;if(Object.hasOwn(v2160,"Some")){
const v2165=v2160["Some"];
const v2166=v2153;
let v2167;if(v2166<v2165.length){v2167=v2165[v2166];}else{
v2167=0.0;}
v2164=v2167;}else{
const v2168=null;
v2164=0.0;}
const v2169=v2164;
const v2170=(__dfNumber(v2163) + __dfNumber(v2169));
const v2171=v2153;
let v2172;if(v2171<v2159.length){v2172=v2159[v2171];}else{
v2172=0.0;}
const v2173=v2172;
const v2174=(__dfNumber(v2170) + __dfNumber(v2173));
const v2175=v2153;
const v2176=1;
const v2177=(((v2175) + (v2176)) >>> 0);
const v2178=__fn31(v2159,v2177,v2174,v2054);
const v2179=v2178["index"];
const v2180=(v2159).length;
let v2181;
let v2182;
if(((v2179) < (v2180))){
const v2183=v2152;
const v2184=v2183["lines"];
const v2185=1;
const v2186=(((v2184) + (v2185)) >>> 0);
const v2187=0.0;
const v2188=false;
const v2189=({["lines"]:v2186,["width"]:v2187,["content"]:v2188});
const v2190=v2178["index"];
v2181=v2189;
v2182=v2190;
}else{
const v2191=v2152;
const v2192=v2191["lines"];
const v2193=v2178["width"];
const v2194=true;
const v2195=({["lines"]:v2192,["width"]:v2193,["content"]:v2194});
const v2196=v2178["index"];
v2181=v2195;
v2182=v2196;
}
v2152=v2181;
v2153=v2182;
}
v2144=({["count"]:v2152,["index"]:v2153});if(v2147){v2145=v2144;v2146=true;}}
const v2197=v2144;
v2129=v2197["count"];}
v2107=v2129;}
v2071=v2107;}
return v2071;};}
function __prepareFn34(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["data","widths"])&&__preparedStable(fixed[0],["epsilon"]))||(__preparedStable(fixed[0],["data","advances"])&&__preparedStable(fixed[0],["data","endTrims"])&&__preparedStable(fixed[0],["data","fillExtras"])&&__preparedStable(fixed[0],["data","flags"])&&__preparedStable(fixed[0],["data","graphemeStartExtras"])&&__preparedStable(fixed[0],["data","insideExtras"])&&__preparedStable(fixed[0],["data","overflowTrims"])&&__preparedStable(fixed[0],["data","startExtras"])&&__preparedStable(fixed[0],["data","widths"]))))return __fn34;const v2203=__preparedStable(fixed[0],[]);
let v2202=false,v2201;
const v2210=depth<15&&__preparedFactories.has(18)&&((__preparedStable(fixed[0],["data","widths"])&&__preparedStable(fixed[0],["epsilon"]))||(__preparedStable(fixed[0],["data","advances"])&&__preparedStable(fixed[0],["data","endTrims"])&&__preparedStable(fixed[0],["data","fillExtras"])&&__preparedStable(fixed[0],["data","flags"])&&__preparedStable(fixed[0],["data","graphemeStartExtras"])&&__preparedStable(fixed[0],["data","insideExtras"])&&__preparedStable(fixed[0],["data","overflowTrims"])&&__preparedStable(fixed[0],["data","startExtras"])&&__preparedStable(fixed[0],["data","widths"])));
let v2208;
let v2213;
const v2226=__preparedStable(fixed[1],[]);
const v2229=depth<15&&__preparedFactories.has(27)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])));
let v2227;
const v2238=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
let v2237=false,v2236;
return function(v2198,v2199){let v2200;if(v2203&&v2202){v2200=v2201;}else{
const v2204=({Some:null});
const v2205=v2204;
let v2206;if(Object.hasOwn(v2205,"Some")){
const v2207=v2205["Some"];
let v2211;if(v2210){if(!v2208){const v2209=__preparedFactories.get(18);v2208=v2209([fixed[0]],depth+1);}v2211=v2208(v2198);}else{v2211=__fn18(v2198);}
v2206=v2211;}else{
const v2212=null;
let v2215;if(v2210){if(!v2213){const v2214=__preparedFactories.get(18);v2213=v2214([fixed[0]],depth+1);}v2215=v2213(v2198);}else{v2215=__fn18(v2198);}
v2206=v2215;}
v2200=v2206;if(v2203){v2201=v2200;v2202=true;}}
let v2216;if(v2200){
const v2217=__fn19(v2199);
const v2218=v2198["data"];
const v2219=v2218["overflowTrims"];
let v2220;if(Object.hasOwn(v2219,"Some")){
const v2221=v2219["Some"];
v2220=true;}else{
const v2222=null;
v2220=false;}
const v2223=v2220;
let v2224;if(v2223){
const v2225=v2217;
let v2230;if(v2229){if(!v2227){const v2228=__preparedFactories.get(27);v2227=v2228([fixed[0],v2226],depth+1);}v2230=v2227(v2198,v2225);}else{v2230=__fn27(v2198,v2225);}
const v2231=v2230;
const v2233=v2231["lineCount"];
v2224=({Ok:v2233});}else{
let v2235;if(v2238&&v2237){v2235=v2236;}else{
const v2239=v2198["data"];
const v2240=(v2239["widths"]).length;
const v2241=0;
const v2242=0.0;
const v2243=false;
const v2244=({["lines"]:v2241,["width"]:v2242,["content"]:v2243});
let v2245=v2244["lines"];
let v2246=v2244["width"];
let v2247=v2244["content"];
for(let v2249=0;v2249<v2240;v2249++){
if(false)break;
const v2250=(v2249>>>0);
const v2251=v2198["data"];
const v2252=v2217;
const v2253=__fn20(v2198,v2252);
const v2255=__fn10(v2251,v2250);
const v2256=v2251["widths"];
let v2257;if(v2250<v2256.length){v2257=v2256[v2250];}else{
v2257=0.0;}
const v2258=v2257;
const v2259=v2251["endTrims"];
const v2260=__fn8(v2259,v2250);
const v2261=v2247;
let v2262=v2261;if(v2262){
const v2263=v2246;
const v2264=(__dfNumber(v2263) + __dfNumber(v2258));
const v2265=(__dfNumber(v2264) - __dfNumber(v2260));
v2262=((__dfNumber(v2265)) <= (__dfNumber(v2253)));}
let v2266;
let v2267;
let v2268;
if(v2262){
const v2269=v2246;
const v2270=(__dfNumber(v2269) + __dfNumber(v2258));
const v2271=v2245;
const v2272=v2247;
v2266=v2271;
v2267=v2270;
v2268=v2272;
}else{
const v2273=v2247;
let v2274;
let v2275;
let v2276;
if(v2273){
const v2277=v2245;
const v2278=1;
const v2279=(((v2277) + (v2278)) >>> 0);
const v2280=0.0;
const v2281=false;
v2274=v2279;
v2275=v2280;
v2276=v2281;
}else{
v2274=v2245;
v2275=v2246;
v2276=v2247;
}
let v2283=v2273;if(v2283){
const v2284=0;
v2283=!(v2255===v2284);}
const v2285=v2283;
let v2286=v2285;if(!v2286){
const v2287=false;
const v2288=(v2273===v2287);
let v2289=v2288;if(v2289){
const v2290=1;
const v2291=(v2255===v2290);
let v2292=v2291;if(!v2292){
const v2293=2;
const v2294=(v2255===v2293);
let v2295=v2294;if(v2295){
const v2296=0;
v2295=((v2250) > (v2296));}
v2292=v2295;}
v2289=v2292;}
v2286=v2289;}
let v2297;
let v2298;
let v2299;
if(v2286){
v2297=v2274;
v2298=v2275;
v2299=v2276;
}else{
const v2300=v2251["startExtras"];
let v2301;if(Object.hasOwn(v2300,"Some")){
const v2302=v2300["Some"];
let v2303;if(v2250<v2302.length){v2303=v2302[v2250];}else{
v2303=0.0;}
const v2304=v2303;
v2301=(__dfNumber(v2258) + __dfNumber(v2304));}else{
const v2305=null;
v2301=v2258;}
const v2306=v2301;
const v2307=v2251["advances"];
let v2308;if(v2250<v2307.length){v2308=v2307[v2250];}else{
v2308=({None:null});}
const v2309=v2308;
const v2310=(__dfNumber(v2306) - __dfNumber(v2260));
const v2311=((__dfNumber(v2310)) <= (__dfNumber(v2253)));
let v2312=v2311;if(!v2312){
let v2313;if(Object.hasOwn(v2309,"Some")){
const v2314=v2309["Some"];
v2313=false;}else{
const v2315=null;
v2313=true;}
v2312=v2313;}
let v2316;
let v2317;
let v2318;
if(v2312){
const v2319=v2275;
const v2320=(__dfNumber(v2319) + __dfNumber(v2306));
const v2321=true;
const v2322=v2274;
v2316=v2322;
v2317=v2320;
v2318=v2321;
}else{
let v2323;if(Object.hasOwn(v2309,"Some")){
const v2324=v2309["Some"];
v2323=v2324;}else{
const v2325=null;
v2323=[];}
const v2326=v2323;
const v2327=(v2326).length;
const v2328=({["lines"]:v2274,["width"]:v2275,["content"]:v2276});
const v2329=0;
const v2330=({["count"]:v2328,["index"]:v2329});
let v2331=v2330["count"];
let v2332=v2330["index"];
for(let v2334=0;v2334<v2327;v2334++){
const v2335=v2332;
const v2336=(v2326).length;
if(((v2335) >= (v2336))){break;}
const v2337=(v2334>>>0);
const v2338=__fn9(v2251,v2250);
const v2340=v2331;
const v2341=v2340["width"];
let v2342;if(Object.hasOwn(v2338,"Some")){
const v2343=v2338["Some"];
const v2344=v2332;
let v2345;if(v2344<v2343.length){v2345=v2343[v2344];}else{
v2345=0.0;}
v2342=v2345;}else{
const v2346=null;
v2342=0.0;}
const v2347=v2342;
const v2348=(__dfNumber(v2341) + __dfNumber(v2347));
const v2349=v2332;
let v2350;if(v2349<v2326.length){v2350=v2326[v2349];}else{
v2350=0.0;}
const v2351=v2350;
const v2352=(__dfNumber(v2348) + __dfNumber(v2351));
const v2353=v2332;
const v2354=1;
const v2355=(((v2353) + (v2354)) >>> 0);
const v2356=__fn31(v2326,v2355,v2352,v2253);
const v2357=v2356["index"];
const v2358=(v2326).length;
let v2359;
let v2360;
if(((v2357) < (v2358))){
const v2361=v2331;
const v2362=v2361["lines"];
const v2363=1;
const v2364=(((v2362) + (v2363)) >>> 0);
const v2365=0.0;
const v2366=false;
const v2367=({["lines"]:v2364,["width"]:v2365,["content"]:v2366});
const v2368=v2356["index"];
v2359=v2367;
v2360=v2368;
}else{
const v2369=v2331;
const v2370=v2369["lines"];
const v2371=v2356["width"];
const v2372=true;
const v2373=({["lines"]:v2370,["width"]:v2371,["content"]:v2372});
const v2374=v2356["index"];
v2359=v2373;
v2360=v2374;
}
v2331=v2359;
v2332=v2360;
}
const v2376=v2331;
v2316=v2376["lines"];
v2317=v2376["width"];
v2318=v2376["content"];
}
v2297=v2316;
v2298=v2317;
v2299=v2318;
}
v2266=v2297;
v2267=v2298;
v2268=v2299;
}
v2245=v2266;
v2246=v2267;
v2247=v2268;
}
v2235=({["lines"]:v2245,["width"]:v2246,["content"]:v2247});if(v2238){v2236=v2235;v2237=true;}}
const v2377=v2235;
const v2378=v2377["lines"];
const v2379=v2235;
let v2380;if(v2379["content"]){
v2380=1;}else{
v2380=0;}
const v2381=v2380;
v2224=({Ok:(((v2378) + (v2381)) >>> 0)});}
v2216=v2224;}else{
const v2382=({Some:null});
let v2383;if(Object.hasOwn(v2382,"Some")){
const v2384=v2382["Some"];
v2383="invalid prepared text";}else{
const v2385=null;
v2383="invalid prepared text";}
v2216=({Err:v2383});}
return v2216;};}
function __prepareFn35(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["data","widths"])&&__preparedStable(fixed[0],["epsilon"]))||(__preparedStable(fixed[0],["data","advances"])&&__preparedStable(fixed[0],["data","endTrims"])&&__preparedStable(fixed[0],["data","fillExtras"])&&__preparedStable(fixed[0],["data","flags"])&&__preparedStable(fixed[0],["data","graphemeStartExtras"])&&__preparedStable(fixed[0],["data","insideExtras"])&&__preparedStable(fixed[0],["data","overflowTrims"])&&__preparedStable(fixed[0],["data","startExtras"])&&__preparedStable(fixed[0],["data","widths"]))))return __fn35;const v2391=depth<15&&__preparedFactories.has(34)&&((__preparedStable(fixed[0],["data","widths"])&&__preparedStable(fixed[0],["epsilon"]))||(__preparedStable(fixed[0],["data","advances"])&&__preparedStable(fixed[0],["data","endTrims"])&&__preparedStable(fixed[0],["data","fillExtras"])&&__preparedStable(fixed[0],["data","flags"])&&__preparedStable(fixed[0],["data","graphemeStartExtras"])&&__preparedStable(fixed[0],["data","insideExtras"])&&__preparedStable(fixed[0],["data","overflowTrims"])&&__preparedStable(fixed[0],["data","startExtras"])&&__preparedStable(fixed[0],["data","widths"])));
let v2389;
return function(v2386,v2387,v2388){let v2392;if(v2391){if(!v2389){const v2390=__preparedFactories.get(34);v2389=v2390([fixed[0],fixed[1]],depth+1);}v2392=v2389(v2386,v2387);}else{v2392=__fn34(v2386,v2387);}
const v2393=v2392;
let v2394;if(Object.hasOwn(v2393,"Ok")){
const v2395=v2393["Ok"];
const v2396=(__dfNumber(v2395) * __dfNumber(v2388));
v2394=({Ok:({["lineCount"]:v2395,["height"]:v2396})});}else{
v2394=({Err:v2393["Err"]});}
return v2394;};}
const __preparedFactories=new Map([[0,__prepareFn0],[1,__prepareFn1],[2,__prepareFn2],[3,__prepareFn3],[4,__prepareFn4],[5,__prepareFn5],[6,__prepareFn6],[15,__prepareFn15],[16,__prepareFn16],[17,__prepareFn17],[18,__prepareFn18],[21,__prepareFn21],[23,__prepareFn23],[24,__prepareFn24],[25,__prepareFn25],[26,__prepareFn26],[27,__prepareFn27],[28,__prepareFn28],[30,__prepareFn30],[32,__prepareFn32],[33,__prepareFn33],[34,__prepareFn34],[35,__prepareFn35]]);
