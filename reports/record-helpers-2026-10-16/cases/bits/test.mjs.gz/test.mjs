
import assert from 'node:assert/strict';import fs from 'node:fs';import * as m from './program.mjs';
const cases=JSON.parse(fs.readFileSync(new URL('cases.json',import.meta.url)));let calls=0;
for(const c of cases){
 const entry=m.compiledValues[c.name],args=c.args.map((v,i)=>entry.params[i].capture(v));
 const expected=m.valueCodecs[c.name].result.encode(c.expected);
 assert.deepEqual(entry.result.encode(m.callCompiled(c.name,args)),expected,c.name);calls++;
 for(const fixed of [[],[0],[0,1]]){
  const token=m.prepareCompiled(c.name,fixed.map(i=>[i,args[i]]));
  for(let repeat=0;repeat<2;repeat++){
   const out=m.callPreparedCompiled(token,args.filter((_,i)=>!fixed.includes(i)));
   assert.deepEqual(entry.result.encode(out),expected,c.name);calls++;
   const host=entry.result.materialize(out);if(Array.isArray(host))host.splice(0);
  }
 }
}
console.log(JSON.stringify({cases:cases.length,calls,exactTypedBytes:true}));
