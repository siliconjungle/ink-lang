const __recordElisions=new Set([]);
const __nativeF32=true;
// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
// Binary64 uses native Numbers for finite arithmetic and immutable private
// tags only where a NaN's exact payload must survive non-arithmetic operations.
const __doubleView=new DataView(new ArrayBuffer(8));
const __double=bits=>{__doubleView.setBigUint64(0,bits,true);return __doubleView.getFloat64(0,true);};
const __doubleBits=number=>{if(Number.isNaN(number))return 0x7ff8000000000000n;__doubleView.setFloat64(0,number,true);return __doubleView.getBigUint64(0,true);};
const __dfNumber=value=>typeof value==='number'?value:__double(BigInt(value.F64Bits));
const __dfBits=value=>typeof value==='number'?__doubleBits(value):BigInt(value.F64Bits);
const __dfFromBits=bits=>(bits&0x7fffffffffffffffn)>0x7ff0000000000000n?Object.freeze({F64Bits:bits.toString()}):__double(bits);
const __dfInput=value=>typeof value==='number'?value:__dfFromBits(BigInt(value.F64Bits));
const __dfNeg=value=>typeof value==='number'&&!Number.isNaN(value)?-value:__dfFromBits(__dfBits(value)^0x8000000000000000n);
const __dfOutput=value=>{const n=__dfNumber(value);return Number.isFinite(n)?n:{F64Bits:__dfBits(value).toString()};};
const __dfCapture=value=>{
 if(typeof value==='number'&&Number.isFinite(value))return value;
 if(!value||typeof value!=='object'||Object.keys(value).length!==1||!Object.hasOwn(value,'F64Bits'))throw Error('invalid f64');const text=value.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid f64');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');return __dfFromBits(bits);
};
// Native binary32 lane for pure modules. Explicit NaN payloads remain tagged;
// arithmetic canonicalizes NaNs just as __bits does in the exact-bit lane.
const __nfValue = value => typeof value === 'number' ? Math.fround(value) : value;
// Number operands have already been normalised at their typed read or producer.
const __nfNumber = value => typeof value === 'number' ? value : __float(value.F32Bits);
const __nfBits = value => typeof value === 'number' ? __bits(value) : value.F32Bits;
const __nfFromBits = bits => (bits & 0x7fffffff)>0x7f800000 ? {F32Bits:bits} : __float(bits);
const __nfNeg = value => typeof value === 'number' && !Number.isNaN(value) ? -value : {F32Bits:(__nfBits(value) ^ 0x80000000) >>> 0};
const __nfOutput = value => {const n=typeof value==='number'?Math.fround(value):__float(value.F32Bits);return Number.isFinite(n)?n:{F32Bits:__nfBits(value)};};
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output, capture=false) {
  const convert=__representationRaw(type,output,capture);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':capture?'capture:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output, capture) {
  switch (type.kind) {
    case 'ref': {
      let resolved;
      return (value,context)=>(resolved??=__representation(__namedTypes[type.name],output,capture))(value,context);
    }
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output,capture);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output,capture),err=__representation(type.error,output,capture);
      const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);
      if(flat)return output?(value,context)=>{const v=__sumView(key,value);return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};}:(v,context)=>Object.hasOwn(v,'Ok')?__sumMake(key,true,ok(v.Ok,context)):__sumMake(key,false,err(v.Err,context));
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f64':return output?__dfOutput:__dfInput;
    case 'f32': if(typeof __nativeF32!=='undefined'&&__nativeF32)return output?__nfOutput:capture?__nfValue:__identity;
      return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output,capture);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){
        if(!type.fields.length)return ()=>undefined; // lexically unconsumed projected input
        const field=type.fields[0],child=__representation(field.type,output,capture);
        return output?(value,context)=>({[field.name]:child(value,context)}):(value,context)=>child(value[field.name],context);
      }
      const fields = type.fields.map(field => [field.name, __representation(field.type, output,capture)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
// Affine buffers expose bounded disjoint ranges over one allocation. Source
// ownership prevents retaining a parent; growth detaches shared ranges.
// Elements cannot own temporary storage: they are immutable logical values.
// Copy the slot array when acquiring ownership, never the reachable records.
class __InkBuffer {
 constructor(data,start=0,end=data.length,shared=false){this.data=data;this.start=start;this.end=end;this.shared=shared;}
 get length(){return this.end-this.start;}
 set length(n){this.end=this.start+Math.min(this.length,n);if(!this.shared&&this.start===0)this.data.length=this.end;}
 item(i){return this.data[this.start+i];}
 range(start,count){const begin=this.start+Math.min(start,this.length);return new __InkBuffer(this.data,begin,begin+Math.min(count,this.end-begin),true);}
 set(i,v){if(i<this.length)this.data[this.start+i]=v;return this;}
 swap(a,b){if(a<this.length&&b<this.length){const x=this.item(a);this.set(a,this.item(b));this.set(b,x);}return this;}
 fill_range(start,count,value){start=Math.min(start,this.length);count=Math.min(count,this.length-start);this.data.fill(value,this.start+start,this.start+start+count);return this;}
 copy_within(source,destination,count){source=Math.min(source,this.length);destination=Math.min(destination,this.length);count=Math.min(count,this.length-source,this.length-destination);this.data.copyWithin(this.start+destination,this.start+source,this.start+source+count);return this;}
 detach(){if(this.shared||this.start!==0||this.end!==this.data.length){this.data=this.data.slice(this.start,this.end);this.start=0;this.end=this.data.length;this.shared=false;}}
 push(v){if(this.length>=4294967295)throw Error('buffer length exhausted');this.detach();this.data.push(v);this.end++;return this;}
 pop(){this.length=Math.max(0,this.length-1);return this;}
 truncate(n){this.length=Math.min(this.length,n);return this;}
 slice(start=0,end=this.length){return this.data.slice(this.start+start,this.start+Math.min(end,this.length));}
 freeze(){return this.start===0&&this.end===this.data.length?this.data:this.data.slice(this.start,this.end);}
 *[Symbol.iterator](){for(let i=this.start;i<this.end;i++)yield this.data[i];}
}
function __bufferSplit(x,at){const cut=x.start+Math.min(at,x.length);x.shared=true;return [new __InkBuffer(x.data,x.start,cut,true),new __InkBuffer(x.data,cut,x.end,true)];}
function __bufferAppend(a,b){
 if(a.length+b.length>4294967295)throw Error('buffer length exhausted');
 if(a.data===b.data&&a.end===b.start)return new __InkBuffer(a.data,a.start,b.end,a.start!==0||b.end!==a.data.length);
 a.detach();for(const item of b)a.push(item);return a;
}

function __repeat_until(limit,acc,stop,step){for(let i=0;i<limit;i++){if(stop(acc))break;acc=step(i,acc);}return acc;}
function __bufferFill(n,v){return new __InkBuffer(new Array(n).fill(v));}
function __mapGet(m,k,f){return m.has(k)?m.get(k):f();}
function __mapEntries(m,keys){return [...m.entries()].sort(([a],[b])=>a<b?-1:a>b?1:0).map(([k,v])=>keys?k:v);}
function __tempSet(x,k,v,map){x.set(k,v);return x;}
function __bufferSwap(x,a,b){return x.swap(a,b);}
function __tempEdit(x,op,...args){if(op==='push'){x.push(args[0]);}else if(op==='pop')x.pop();else if(op==='truncate')x.truncate(args[0]);else if(op==='remove')x.delete(args[0]);return x;}
function __fn0(v0){
const v1=v0["b"];
const v2=v0["a"];
const v3=__dfNeg(v2);
const v4=v0["index"];
const v5=v0["stop"];
const v6=v0["label"];
const v7=v0["values"];
return ({["a"]:v1,["b"]:v3,["index"]:v4,["stop"]:v5,["label"]:v6,["values"]:v7});}
function __fn1(v8,v9,v10){
const v11=0;
const v12=false;
const v13="lane";
const v14=[v8,v9];
const v16=({["a"]:v8,["b"]:v9,["index"]:v11,["stop"]:v12,["label"]:v13,["values"]:v14});
let v17=v16["a"];
let v18=v16["b"];
let v19=v16["index"];
let v20=v16["stop"];
let v21=v16["label"];
let v22=v16["values"];
for(let v24=0;v24<v10;v24++){
if(v20){break;}
const v25=(v24>>>0);
const v26=7;
const v27=(v25===v26);
const v28=v17;
const v29=v18;
const v30=v21;
const v31=v22;
const v33=__dfNeg(v28);
v17=v29;
v18=v33;
v19=v25;
v20=v27;
v21=v30;
v22=v31;
}
return ({["a"]:v17,["b"]:v18,["index"]:v19,["stop"]:v20,["label"]:v21,["values"]:v22});}
function __fn2(v34,v35,v36){
const v37=__fn1(v34,v35,v36);
const v38=v37["b"];
const v39=v37["a"];
const v40=v37["index"];
const v41=v37["stop"];
const v42=v37["label"];
const v43=v37["values"];
const v45=v37["a"];
const v46=v37["b"];
let v47;if(v36<v43.length){v47=v43[v36];}else{
v47=v34;}
const v48=v47;
return [v38,v45,v39,v46,v48,v40];}
function __fn3(v49){
const v50=v49["lane"];
const v51=v50["a"];
const v52=v49["lane"];
const v53=v52["b"];
const v54=v49["extra"];
return [v51,v53,v54];}
function __fn4(v55,v56){
const v57=0;
let v58;if((v56===v57)){
const v59=v55["b"];
const v60=__dfNeg(v59);
const v61=v55["b"];
const v62=v55["index"];
const v63=v55["stop"];
const v64=v55["label"];
const v65=v55["values"];
v58=({["a"]:v60,["b"]:v61,["index"]:v62,["stop"]:v63,["label"]:v64,["values"]:v65});}else{
const v66=v55["a"];
const v67=__dfNeg(v66);
const v68=v55["a"];
const v69=v55["index"];
const v70=v55["stop"];
const v71=v55["label"];
const v72=v55["values"];
v58=({["a"]:v68,["b"]:v67,["index"]:v69,["stop"]:v70,["label"]:v71,["values"]:v72});}
const v73=v58;
const v74=1;
let v75;if((v56===v74)){
v75=v73;}else{
const v76=v73["values"];
const v77=v73["a"];
const v78=v73["b"];
const v79=v73["index"];
const v80=v73["stop"];
const v81=v73["label"];
const v83=__dfNeg(v77);
v75=({["a"]:v78,["b"]:v83,["index"]:v79,["stop"]:v80,["label"]:v81,["values"]:v76});}
return v75;}
function __fn5(v84,v85,v86){
const v87=false;
const v88="branch";
const v89=[v84,v85];
const v92=0;
let v93;
let v94;
let v95;
let v96;
let v97;
let v98;
if((v86===v92)){
const v99=__dfNeg(v85);
v93=v99;
v94=v85;
v95=v86;
v96=v87;
v97=v88;
v98=v89;
}else{
const v100=__dfNeg(v84);
v93=v84;
v94=v100;
v95=v86;
v96=v87;
v97=v88;
v98=v89;
}
const v102=1;
let v103;
let v104;
let v105;
let v106;
let v107;
let v108;
if((v86===v102)){
v103=v93;
v104=v94;
v105=v95;
v106=v96;
v107=v97;
v108=v98;
}else{
const v109=v98;
const v110=v93;
const v111=v94;
const v112=v95;
const v113=v96;
const v114=v97;
const v116=__dfNeg(v110);
v103=v111;
v104=v116;
v105=v112;
v106=v113;
v107=v114;
v108=v109;
}
return ({["a"]:v103,["b"]:v104,["index"]:v105,["stop"]:v106,["label"]:v107,["values"]:v108});}
function __fn6(v117,v118,v119){
const v120=false;
const v121="nested";
const v122=[v117,v118];
const v124=({["a"]:v117,["b"]:v118,["index"]:v119,["stop"]:v120,["label"]:v121,["values"]:v122});
const v125=__dfNeg(v118);
const v128=v124["a"];
const v129=v124["b"];
return [v128,v129,v125];}
function __fn7(v130,v131){
const v132=v131["values"];
const v133=v132.length;
const v134=v130.length;
const v135=new Array(v133+v134);
for(let v136=0;v136<v133;v136++){v135[v136]=v132[v136];}
for(let v137=0;v137<v134;v137++){v135[v133+v137]=v130[v137];}
const v138=v131["a"];
const v139=v131["b"];
const v140=v131["index"];
const v141=v131["stop"];
const v142=v131["label"];
return ({["a"]:v138,["b"]:v139,["index"]:v140,["stop"]:v141,["label"]:v142,["values"]:v135});}
function __fn8(v143,v144,v145){
const v146=[v143,v144];
const v147=false;
const v148="alias";
const v150=({["a"]:v143,["b"]:v144,["index"]:v145,["stop"]:v147,["label"]:v148,["values"]:v146});
let v151=v150["a"];
let v152=v150["b"];
let v153=v150["index"];
let v154=v150["stop"];
let v155=v150["label"];
let v156=v150["values"];
for(let v158=0;v158<v145;v158++){
if(false){break;}
const v159=(v158>>>0);
const v160=[v159];
const v162=v156;
const v163=v162.length;
const v164=v160.length;
const v165=new Array(v163+v164);
for(let v166=0;v166<v163;v166++){v165[v166]=v162[v166];}
for(let v167=0;v167<v164;v167++){v165[v163+v167]=v160[v167];}
const v168=v151;
const v169=v152;
const v170=v153;
const v171=v154;
const v172=v155;
v151=v168;
v152=v169;
v153=v170;
v154=v171;
v155=v172;
v156=v165;
}
const v174=v156;
const v175=v146.length;
const v176=v174.length;
const v177=new Array(v175+v176);
for(let v178=0;v178<v175;v178++){v177[v178]=v146[v178];}
for(let v179=0;v179<v176;v179++){v177[v175+v179]=v174[v179];}
return v177;}
function __fn9(v180){
const v181=v180["values"];
const v182=0.0;
const v183=__dfNeg(v182);
const v184=__tempEdit(v181,"push",v183);
return v184.freeze();}
function __fn10(v185,v186,v187){
const v188=new __InkBuffer([]);
const v189=__tempEdit(v188,"push",v185);
const v190=__tempEdit(v189,"push",v186);
const v191=({["values"]:v190});
return __fn9(v191);}
function __fn11(v192,v193,v194){
const v195=({Some:null});
let v196;if(Object.hasOwn(v195,"Some")){
const v197=v195["Some"];
const v198=10;
v196=((v194) < (v198));}else{
const v199=null;
const v200=10;
v196=((v194) < (v200));}
let v201;if(v196){
v201=({Ok:__fn1(v192,v193,v194)});}else{
const v202=({Some:null});
let v203;if(Object.hasOwn(v202,"Some")){
const v204=v202["Some"];
v203="outside range";}else{
const v205=null;
v203="outside range";}
v201=({Err:v203});}
return v201;}
function __fn12(v206){
return __fn13(v206);}
function __fn13(v207){
return __fn14(v207);}
function __fn14(v208){
return __fn15(v208);}
function __fn15(v209){
return __fn16(v209);}
function __fn16(v210){
return __fn17(v210);}
function __fn17(v211){
return __fn18(v211);}
function __fn18(v212){
return __fn19(v212);}
function __fn19(v213){
return __fn20(v213);}
function __fn20(v214){
return __fn0(v214);}
function __fn21(v215,v216,v217){
const v218=0;
const v219=__fn1(v215,v216,v218);
return __fn12(v219);}
function __fn22(v220){
const v221=v220["a"];
const v222=v220["a"];
const v223=v220["a"];
const v224=v220["a"];
const v225=v220["a"];
const v226=v220["a"];
const v227=v220["a"];
const v228=v220["a"];
const v229=v220["a"];
const v230=v220["a"];
const v231=v220["a"];
const v232=v220["a"];
const v233=v220["a"];
const v234=v220["a"];
const v235=v220["a"];
const v236=v220["a"];
const v237=v220["a"];
const v238=v220["a"];
const v239=v220["a"];
const v240=v220["a"];
const v241=v220["a"];
const v242=v220["a"];
const v243=v220["a"];
const v244=v220["a"];
const v245=v220["a"];
const v246=v220["a"];
const v247=v220["a"];
const v248=v220["a"];
const v249=v220["a"];
const v250=v220["a"];
const v251=v220["a"];
const v252=v220["a"];
const v253=v220["a"];
const v254=v220["a"];
const v255=v220["a"];
const v256=v220["a"];
const v257=v220["a"];
const v258=v220["a"];
const v259=v220["a"];
const v260=v220["a"];
const v261=v220["a"];
const v262=v220["a"];
const v263=v220["a"];
const v264=v220["a"];
const v265=v220["a"];
const v266=v220["a"];
const v267=v220["a"];
const v268=v220["a"];
const v269=v220["a"];
const v270=v220["a"];
const v271=v220["a"];
const v272=v220["a"];
const v273=v220["a"];
const v274=v220["a"];
const v275=v220["a"];
const v276=v220["a"];
const v277=v220["a"];
const v278=v220["a"];
const v279=v220["a"];
const v280=v220["a"];
const v281=v220["a"];
const v282=v220["a"];
const v283=v220["a"];
const v284=v220["a"];
const v285=v220["a"];
const v286=v220["a"];
const v287=v220["a"];
const v288=v220["a"];
const v289=v220["a"];
const v290=v220["a"];
const v291=v220["a"];
const v292=v220["a"];
const v293=v220["a"];
const v294=v220["a"];
const v295=v220["a"];
const v296=v220["a"];
const v297=v220["a"];
const v298=v220["a"];
const v299=v220["a"];
const v300=v220["a"];
const v301=v220["a"];
const v302=v220["a"];
const v303=v220["a"];
const v304=v220["a"];
const v305=v220["a"];
const v306=v220["a"];
const v307=v220["a"];
const v308=v220["a"];
const v309=v220["a"];
const v310=v220["a"];
const v311=v220["a"];
const v312=v220["a"];
const v313=v220["a"];
const v314=v220["a"];
const v315=v220["a"];
const v316=v220["a"];
const v317=v220["a"];
const v318=v220["a"];
const v319=v220["a"];
const v320=v220["a"];
const v321=v220["a"];
const v322=v220["a"];
const v323=v220["a"];
const v324=v220["a"];
const v325=v220["a"];
const v326=v220["a"];
const v327=v220["a"];
const v328=v220["a"];
const v329=v220["a"];
const v330=v220["a"];
const v331=v220["a"];
const v332=v220["a"];
const v333=v220["a"];
const v334=v220["a"];
const v335=v220["a"];
const v336=v220["a"];
const v337=v220["a"];
const v338=v220["a"];
const v339=v220["a"];
const v340=v220["a"];
const v341=v220["a"];
const v342=v220["a"];
const v343=v220["a"];
const v344=v220["a"];
const v345=v220["a"];
const v346=v220["a"];
const v347=v220["a"];
const v348=v220["a"];
const v349=v220["a"];
const v350=v220["a"];
const v351=v220["a"];
const v352=v220["a"];
const v353=v220["a"];
const v354=v220["a"];
const v355=v220["a"];
const v356=v220["a"];
const v357=v220["a"];
const v358=v220["a"];
const v359=v220["a"];
const v360=v220["a"];
const v361=v220["a"];
const v362=v220["a"];
const v363=v220["a"];
const v364=v220["a"];
const v365=v220["a"];
const v366=v220["a"];
const v367=v220["a"];
const v368=v220["a"];
const v369=v220["a"];
const v370=v220["a"];
const v371=v220["a"];
const v372=v220["a"];
const v373=v220["a"];
const v374=v220["a"];
const v375=v220["a"];
const v376=v220["a"];
const v377=v220["a"];
const v378=v220["a"];
const v379=v220["a"];
const v380=v220["a"];
const v381=v220["a"];
const v382=v220["a"];
const v383=v220["a"];
const v384=v220["a"];
const v385=v220["a"];
const v386=v220["a"];
const v387=v220["a"];
const v388=v220["a"];
const v389=v220["a"];
const v390=v220["a"];
const v391=v220["a"];
const v392=v220["a"];
const v393=v220["a"];
const v394=v220["a"];
const v395=v220["a"];
const v396=v220["a"];
const v397=v220["a"];
const v398=v220["a"];
const v399=v220["a"];
const v400=v220["a"];
const v401=v220["a"];
const v402=v220["a"];
const v403=v220["a"];
const v404=v220["a"];
const v405=v220["a"];
const v406=v220["a"];
const v407=v220["a"];
const v408=v220["a"];
const v409=v220["a"];
const v410=v220["a"];
const v411=v220["a"];
const v412=v220["a"];
const v413=v220["a"];
const v414=v220["a"];
const v415=v220["a"];
const v416=v220["a"];
const v417=v220["a"];
const v418=v220["a"];
const v419=v220["a"];
const v420=v220["a"];
const v421=v220["a"];
const v422=v220["a"];
const v423=v220["a"];
const v424=v220["a"];
const v425=v220["a"];
const v426=v220["a"];
const v427=v220["a"];
const v428=v220["a"];
const v429=v220["a"];
const v430=v220["a"];
const v431=v220["a"];
const v432=v220["a"];
const v433=v220["a"];
const v434=v220["a"];
const v435=v220["a"];
const v436=v220["a"];
const v437=v220["a"];
const v438=v220["a"];
const v439=v220["a"];
const v440=v220["a"];
const v441=v220["a"];
const v442=v220["a"];
const v443=v220["a"];
const v444=v220["a"];
const v445=v220["a"];
const v446=v220["a"];
const v447=v220["a"];
const v448=v220["a"];
const v449=v220["a"];
const v450=v220["a"];
const v451=v220["a"];
const v452=v220["a"];
const v453=v220["a"];
const v454=v220["a"];
const v455=v220["a"];
const v456=v220["a"];
const v457=v220["a"];
const v458=v220["a"];
const v459=v220["a"];
const v460=v220["a"];
const v461=v220["a"];
const v462=v220["a"];
const v463=v220["a"];
const v464=v220["a"];
const v465=v220["a"];
const v466=v220["a"];
const v467=v220["a"];
const v468=v220["a"];
const v469=v220["a"];
const v470=v220["a"];
const v471=v220["a"];
const v472=v220["a"];
const v473=v220["a"];
const v474=v220["a"];
const v475=v220["a"];
const v476=v220["a"];
const v477=v220["a"];
const v478=v220["a"];
const v479=v220["a"];
const v480=v220["a"];
const v481=v220["a"];
const v482=v220["a"];
const v483=v220["a"];
const v484=v220["a"];
const v485=v220["a"];
const v486=v220["a"];
const v487=v220["a"];
const v488=v220["a"];
const v489=v220["a"];
const v490=v220["a"];
const v491=v220["a"];
const v492=v220["a"];
const v493=v220["a"];
const v494=v220["a"];
const v495=v220["a"];
const v496=v220["a"];
const v497=v220["a"];
const v498=v220["a"];
const v499=v220["a"];
const v500=v220["a"];
const v501=v220["a"];
const v502=v220["a"];
const v503=v220["a"];
const v504=v220["a"];
const v505=v220["a"];
const v506=v220["a"];
const v507=v220["a"];
const v508=v220["a"];
const v509=v220["a"];
const v510=v220["a"];
const v511=v220["a"];
const v512=v220["a"];
const v513=v220["a"];
const v514=v220["a"];
const v515=v220["a"];
const v516=v220["a"];
const v517=v220["a"];
const v518=v220["a"];
const v519=v220["a"];
const v520=v220["a"];
return [v221,v222,v223,v224,v225,v226,v227,v228,v229,v230,v231,v232,v233,v234,v235,v236,v237,v238,v239,v240,v241,v242,v243,v244,v245,v246,v247,v248,v249,v250,v251,v252,v253,v254,v255,v256,v257,v258,v259,v260,v261,v262,v263,v264,v265,v266,v267,v268,v269,v270,v271,v272,v273,v274,v275,v276,v277,v278,v279,v280,v281,v282,v283,v284,v285,v286,v287,v288,v289,v290,v291,v292,v293,v294,v295,v296,v297,v298,v299,v300,v301,v302,v303,v304,v305,v306,v307,v308,v309,v310,v311,v312,v313,v314,v315,v316,v317,v318,v319,v320,v321,v322,v323,v324,v325,v326,v327,v328,v329,v330,v331,v332,v333,v334,v335,v336,v337,v338,v339,v340,v341,v342,v343,v344,v345,v346,v347,v348,v349,v350,v351,v352,v353,v354,v355,v356,v357,v358,v359,v360,v361,v362,v363,v364,v365,v366,v367,v368,v369,v370,v371,v372,v373,v374,v375,v376,v377,v378,v379,v380,v381,v382,v383,v384,v385,v386,v387,v388,v389,v390,v391,v392,v393,v394,v395,v396,v397,v398,v399,v400,v401,v402,v403,v404,v405,v406,v407,v408,v409,v410,v411,v412,v413,v414,v415,v416,v417,v418,v419,v420,v421,v422,v423,v424,v425,v426,v427,v428,v429,v430,v431,v432,v433,v434,v435,v436,v437,v438,v439,v440,v441,v442,v443,v444,v445,v446,v447,v448,v449,v450,v451,v452,v453,v454,v455,v456,v457,v458,v459,v460,v461,v462,v463,v464,v465,v466,v467,v468,v469,v470,v471,v472,v473,v474,v475,v476,v477,v478,v479,v480,v481,v482,v483,v484,v485,v486,v487,v488,v489,v490,v491,v492,v493,v494,v495,v496,v497,v498,v499,v500,v501,v502,v503,v504,v505,v506,v507,v508,v509,v510,v511,v512,v513,v514,v515,v516,v517,v518,v519,v520];}
function __fn23(v521,v522,v523){
const v524=false;
const v525="large";
const v526=[v521,v522];
const v528=({["a"]:v521,["b"]:v522,["index"]:v523,["stop"]:v524,["label"]:v525,["values"]:v526});
return __fn22(v528);}
function __into2(v529,v530,v531,v532){
const v533=__fn1(v529,v530,v531);
const v534=v533["b"];
const v535=v533["a"];
const v536=v533["index"];
const v537=v533["stop"];
const v538=v533["label"];
const v539=v533["values"];
const v540=({["a"]:v534,["b"]:v535,["index"]:v536,["stop"]:v537,["label"]:v538,["values"]:v539});
const v541=v540["a"];
const v542=v533["a"];
const v543=v540["b"];
const v544=v533["b"];
const v545=v540["values"];
let v546;if(v531<v545.length){v546=v545[v531];}else{
v546=v529;}
const v547=v546;
const v548=v540["index"];
const v549=[v541,v542,v543,v544,v547,v548];
const v550=v549.length;
for(let v551=0;v551<v550;v551++){
v532[v551]=__intoOutput2(v549[v551]);
}
return v550;}
function __into3(v552,v553){
const v554=v552["lane"];
const v555=v554["a"];
const v556=v552["lane"];
const v557=v556["b"];
const v558=v552["extra"];
const v559=[v555,v557,v558];
const v560=v559.length;
for(let v561=0;v561<v560;v561++){
v553[v561]=__intoOutput3(v559[v561]);
}
return v560;}
function __into6(v562,v563,v564,v565){
const v566=false;
const v567="nested";
const v568=[v562,v563];
const v569=({["a"]:v562,["b"]:v563,["index"]:v564,["stop"]:v566,["label"]:v567,["values"]:v568});
const v570=__dfNeg(v563);
const v571=({["lane"]:v569,["extra"]:v570});
const v572=__into3(v571,v565);
return v572;}
function __into8(v573,v574,v575,v576){
const v577=[v573,v574];
const v578=false;
const v579="alias";
const v580=({["a"]:v573,["b"]:v574,["index"]:v575,["stop"]:v578,["label"]:v579,["values"]:v577});
let v581=v580["a"];
let v582=v580["b"];
let v583=v580["index"];
let v584=v580["stop"];
let v585=v580["label"];
let v586=v580["values"];
for(let v588=0;v588<v575;v588++){
if(false){break;}
const v589=(v588>>>0);
const v590=[v589];
const v592=v586;
const v593=v592.length;
const v594=v590.length;
const v595=new Array(v593+v594);
for(let v596=0;v596<v593;v596++){v595[v596]=v592[v596];}
for(let v597=0;v597<v594;v597++){v595[v593+v597]=v590[v597];}
const v598=v581;
const v599=v582;
const v600=v583;
const v601=v584;
const v602=v585;
v581=v598;
v582=v599;
v583=v600;
v584=v601;
v585=v602;
v586=v595;
}
const v603=({["a"]:v581,["b"]:v582,["index"]:v583,["stop"]:v584,["label"]:v585,["values"]:v586});
const v604=v603["values"];
const v605=v577.length;
const v606=v604.length;
for(let v607=0;v607<v605;v607++){
v576[0+v607]=__intoOutput8(v577[v607]);
}
for(let v608=0;v608<v606;v608++){
v576[v605+v608]=__intoOutput8(v604[v608]);
}
const v609=v605+v606;
return v609;}
function __into9(v610,v611){
const v612=v610["values"];
const v613=0.0;
const v614=__dfNeg(v613);
const v615=__tempEdit(v612,"push",v614);
const v616=v615.freeze();
const v617=v616.length;
for(let v618=0;v618<v617;v618++){
v611[v618]=__intoOutput9(v616[v618]);
}
return v617;}
function __into10(v619,v620,v621,v622){
const v623=new __InkBuffer([]);
const v624=__tempEdit(v623,"push",v619);
const v625=__tempEdit(v624,"push",v620);
const v626=({["values"]:v625});
const v627=__into9(v626,v622);
return v627;}
function __into22(v628,v629){
const v630=v628["a"];
const v631=v628["a"];
const v632=v628["a"];
const v633=v628["a"];
const v634=v628["a"];
const v635=v628["a"];
const v636=v628["a"];
const v637=v628["a"];
const v638=v628["a"];
const v639=v628["a"];
const v640=v628["a"];
const v641=v628["a"];
const v642=v628["a"];
const v643=v628["a"];
const v644=v628["a"];
const v645=v628["a"];
const v646=v628["a"];
const v647=v628["a"];
const v648=v628["a"];
const v649=v628["a"];
const v650=v628["a"];
const v651=v628["a"];
const v652=v628["a"];
const v653=v628["a"];
const v654=v628["a"];
const v655=v628["a"];
const v656=v628["a"];
const v657=v628["a"];
const v658=v628["a"];
const v659=v628["a"];
const v660=v628["a"];
const v661=v628["a"];
const v662=v628["a"];
const v663=v628["a"];
const v664=v628["a"];
const v665=v628["a"];
const v666=v628["a"];
const v667=v628["a"];
const v668=v628["a"];
const v669=v628["a"];
const v670=v628["a"];
const v671=v628["a"];
const v672=v628["a"];
const v673=v628["a"];
const v674=v628["a"];
const v675=v628["a"];
const v676=v628["a"];
const v677=v628["a"];
const v678=v628["a"];
const v679=v628["a"];
const v680=v628["a"];
const v681=v628["a"];
const v682=v628["a"];
const v683=v628["a"];
const v684=v628["a"];
const v685=v628["a"];
const v686=v628["a"];
const v687=v628["a"];
const v688=v628["a"];
const v689=v628["a"];
const v690=v628["a"];
const v691=v628["a"];
const v692=v628["a"];
const v693=v628["a"];
const v694=v628["a"];
const v695=v628["a"];
const v696=v628["a"];
const v697=v628["a"];
const v698=v628["a"];
const v699=v628["a"];
const v700=v628["a"];
const v701=v628["a"];
const v702=v628["a"];
const v703=v628["a"];
const v704=v628["a"];
const v705=v628["a"];
const v706=v628["a"];
const v707=v628["a"];
const v708=v628["a"];
const v709=v628["a"];
const v710=v628["a"];
const v711=v628["a"];
const v712=v628["a"];
const v713=v628["a"];
const v714=v628["a"];
const v715=v628["a"];
const v716=v628["a"];
const v717=v628["a"];
const v718=v628["a"];
const v719=v628["a"];
const v720=v628["a"];
const v721=v628["a"];
const v722=v628["a"];
const v723=v628["a"];
const v724=v628["a"];
const v725=v628["a"];
const v726=v628["a"];
const v727=v628["a"];
const v728=v628["a"];
const v729=v628["a"];
const v730=v628["a"];
const v731=v628["a"];
const v732=v628["a"];
const v733=v628["a"];
const v734=v628["a"];
const v735=v628["a"];
const v736=v628["a"];
const v737=v628["a"];
const v738=v628["a"];
const v739=v628["a"];
const v740=v628["a"];
const v741=v628["a"];
const v742=v628["a"];
const v743=v628["a"];
const v744=v628["a"];
const v745=v628["a"];
const v746=v628["a"];
const v747=v628["a"];
const v748=v628["a"];
const v749=v628["a"];
const v750=v628["a"];
const v751=v628["a"];
const v752=v628["a"];
const v753=v628["a"];
const v754=v628["a"];
const v755=v628["a"];
const v756=v628["a"];
const v757=v628["a"];
const v758=v628["a"];
const v759=v628["a"];
const v760=v628["a"];
const v761=v628["a"];
const v762=v628["a"];
const v763=v628["a"];
const v764=v628["a"];
const v765=v628["a"];
const v766=v628["a"];
const v767=v628["a"];
const v768=v628["a"];
const v769=v628["a"];
const v770=v628["a"];
const v771=v628["a"];
const v772=v628["a"];
const v773=v628["a"];
const v774=v628["a"];
const v775=v628["a"];
const v776=v628["a"];
const v777=v628["a"];
const v778=v628["a"];
const v779=v628["a"];
const v780=v628["a"];
const v781=v628["a"];
const v782=v628["a"];
const v783=v628["a"];
const v784=v628["a"];
const v785=v628["a"];
const v786=v628["a"];
const v787=v628["a"];
const v788=v628["a"];
const v789=v628["a"];
const v790=v628["a"];
const v791=v628["a"];
const v792=v628["a"];
const v793=v628["a"];
const v794=v628["a"];
const v795=v628["a"];
const v796=v628["a"];
const v797=v628["a"];
const v798=v628["a"];
const v799=v628["a"];
const v800=v628["a"];
const v801=v628["a"];
const v802=v628["a"];
const v803=v628["a"];
const v804=v628["a"];
const v805=v628["a"];
const v806=v628["a"];
const v807=v628["a"];
const v808=v628["a"];
const v809=v628["a"];
const v810=v628["a"];
const v811=v628["a"];
const v812=v628["a"];
const v813=v628["a"];
const v814=v628["a"];
const v815=v628["a"];
const v816=v628["a"];
const v817=v628["a"];
const v818=v628["a"];
const v819=v628["a"];
const v820=v628["a"];
const v821=v628["a"];
const v822=v628["a"];
const v823=v628["a"];
const v824=v628["a"];
const v825=v628["a"];
const v826=v628["a"];
const v827=v628["a"];
const v828=v628["a"];
const v829=v628["a"];
const v830=v628["a"];
const v831=v628["a"];
const v832=v628["a"];
const v833=v628["a"];
const v834=v628["a"];
const v835=v628["a"];
const v836=v628["a"];
const v837=v628["a"];
const v838=v628["a"];
const v839=v628["a"];
const v840=v628["a"];
const v841=v628["a"];
const v842=v628["a"];
const v843=v628["a"];
const v844=v628["a"];
const v845=v628["a"];
const v846=v628["a"];
const v847=v628["a"];
const v848=v628["a"];
const v849=v628["a"];
const v850=v628["a"];
const v851=v628["a"];
const v852=v628["a"];
const v853=v628["a"];
const v854=v628["a"];
const v855=v628["a"];
const v856=v628["a"];
const v857=v628["a"];
const v858=v628["a"];
const v859=v628["a"];
const v860=v628["a"];
const v861=v628["a"];
const v862=v628["a"];
const v863=v628["a"];
const v864=v628["a"];
const v865=v628["a"];
const v866=v628["a"];
const v867=v628["a"];
const v868=v628["a"];
const v869=v628["a"];
const v870=v628["a"];
const v871=v628["a"];
const v872=v628["a"];
const v873=v628["a"];
const v874=v628["a"];
const v875=v628["a"];
const v876=v628["a"];
const v877=v628["a"];
const v878=v628["a"];
const v879=v628["a"];
const v880=v628["a"];
const v881=v628["a"];
const v882=v628["a"];
const v883=v628["a"];
const v884=v628["a"];
const v885=v628["a"];
const v886=v628["a"];
const v887=v628["a"];
const v888=v628["a"];
const v889=v628["a"];
const v890=v628["a"];
const v891=v628["a"];
const v892=v628["a"];
const v893=v628["a"];
const v894=v628["a"];
const v895=v628["a"];
const v896=v628["a"];
const v897=v628["a"];
const v898=v628["a"];
const v899=v628["a"];
const v900=v628["a"];
const v901=v628["a"];
const v902=v628["a"];
const v903=v628["a"];
const v904=v628["a"];
const v905=v628["a"];
const v906=v628["a"];
const v907=v628["a"];
const v908=v628["a"];
const v909=v628["a"];
const v910=v628["a"];
const v911=v628["a"];
const v912=v628["a"];
const v913=v628["a"];
const v914=v628["a"];
const v915=v628["a"];
const v916=v628["a"];
const v917=v628["a"];
const v918=v628["a"];
const v919=v628["a"];
const v920=v628["a"];
const v921=v628["a"];
const v922=v628["a"];
const v923=v628["a"];
const v924=v628["a"];
const v925=v628["a"];
const v926=v628["a"];
const v927=v628["a"];
const v928=v628["a"];
const v929=v628["a"];
const v930=[v630,v631,v632,v633,v634,v635,v636,v637,v638,v639,v640,v641,v642,v643,v644,v645,v646,v647,v648,v649,v650,v651,v652,v653,v654,v655,v656,v657,v658,v659,v660,v661,v662,v663,v664,v665,v666,v667,v668,v669,v670,v671,v672,v673,v674,v675,v676,v677,v678,v679,v680,v681,v682,v683,v684,v685,v686,v687,v688,v689,v690,v691,v692,v693,v694,v695,v696,v697,v698,v699,v700,v701,v702,v703,v704,v705,v706,v707,v708,v709,v710,v711,v712,v713,v714,v715,v716,v717,v718,v719,v720,v721,v722,v723,v724,v725,v726,v727,v728,v729,v730,v731,v732,v733,v734,v735,v736,v737,v738,v739,v740,v741,v742,v743,v744,v745,v746,v747,v748,v749,v750,v751,v752,v753,v754,v755,v756,v757,v758,v759,v760,v761,v762,v763,v764,v765,v766,v767,v768,v769,v770,v771,v772,v773,v774,v775,v776,v777,v778,v779,v780,v781,v782,v783,v784,v785,v786,v787,v788,v789,v790,v791,v792,v793,v794,v795,v796,v797,v798,v799,v800,v801,v802,v803,v804,v805,v806,v807,v808,v809,v810,v811,v812,v813,v814,v815,v816,v817,v818,v819,v820,v821,v822,v823,v824,v825,v826,v827,v828,v829,v830,v831,v832,v833,v834,v835,v836,v837,v838,v839,v840,v841,v842,v843,v844,v845,v846,v847,v848,v849,v850,v851,v852,v853,v854,v855,v856,v857,v858,v859,v860,v861,v862,v863,v864,v865,v866,v867,v868,v869,v870,v871,v872,v873,v874,v875,v876,v877,v878,v879,v880,v881,v882,v883,v884,v885,v886,v887,v888,v889,v890,v891,v892,v893,v894,v895,v896,v897,v898,v899,v900,v901,v902,v903,v904,v905,v906,v907,v908,v909,v910,v911,v912,v913,v914,v915,v916,v917,v918,v919,v920,v921,v922,v923,v924,v925,v926,v927,v928,v929];
const v931=v930.length;
for(let v932=0;v932<v931;v932++){
v629[v932]=__intoOutput22(v930[v932]);
}
return v931;}
function __into23(v933,v934,v935,v936){
const v937=false;
const v938="large";
const v939=[v933,v934];
const v940=({["a"]:v933,["b"]:v934,["index"]:v935,["stop"]:v937,["label"]:v938,["values"]:v939});
const v941=__into22(v940,v936);
return v941;}
const __namedTypes={"Lane":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"},"Nested":{"fields":[{"name":"lane","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"name":"extra","type":{"kind":"f64"}}],"kind":"record","name":"Nested"},"Owned":{"fields":[{"name":"values","type":{"kind":"temporary"}}],"kind":"record","name":"Owned"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v15","core_sha256":"10cf08fd4075a7b8b19e63e3c4a7061c97bf41b7aee5ca9b221a40d880b37f18","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"f32_storage":"native-number-with-exact-nonfinite-tags","functions":[{"destination":null,"index":0,"internal":false,"name":"advance","parallel":false,"params":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"destination":null,"index":1,"internal":false,"name":"drive","parallel":false,"params":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":2,"internal":false,"name":"projected","parallel":false,"params":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"kind":"f64"},"kind":"list"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":3,"internal":false,"name":"pick","parallel":false,"params":[{"name":"n","type":{"fields":[{"name":"lane","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"name":"extra","type":{"kind":"f64"}}],"kind":"record","name":"Nested"}}],"precondition":null,"result":{"element":{"kind":"f64"},"kind":"list"}},{"destination":null,"index":4,"internal":false,"name":"branch","parallel":false,"params":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"name":"n","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"destination":null,"index":5,"internal":false,"name":"selected","parallel":false,"params":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":6,"internal":false,"name":"nested","parallel":false,"params":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"kind":"f64"},"kind":"list"}},{"destination":null,"index":7,"internal":false,"name":"kept","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":8,"internal":false,"name":"aliases","parallel":false,"params":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"kind":"f64"},"kind":"list"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":9,"internal":true,"name":"last","parallel":false,"params":[{"name":"o","type":{"fields":[{"name":"values","type":{"kind":"temporary"}}],"kind":"record","name":"Owned"}}],"precondition":null,"result":{"element":{"kind":"f64"},"kind":"list"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":10,"internal":false,"name":"owned","parallel":false,"params":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"kind":"f64"},"kind":"list"}},{"destination":null,"index":11,"internal":false,"name":"fallible","parallel":false,"params":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}},{"destination":null,"index":12,"internal":false,"name":"chain0","parallel":false,"params":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"destination":null,"index":13,"internal":false,"name":"chain1","parallel":false,"params":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"destination":null,"index":14,"internal":false,"name":"chain2","parallel":false,"params":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"destination":null,"index":15,"internal":false,"name":"chain3","parallel":false,"params":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"destination":null,"index":16,"internal":false,"name":"chain4","parallel":false,"params":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"destination":null,"index":17,"internal":false,"name":"chain5","parallel":false,"params":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"destination":null,"index":18,"internal":false,"name":"chain6","parallel":false,"params":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"destination":null,"index":19,"internal":false,"name":"chain7","parallel":false,"params":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"destination":null,"index":20,"internal":false,"name":"chain8","parallel":false,"params":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"destination":null,"index":21,"internal":false,"name":"bounded","parallel":false,"params":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":22,"internal":false,"name":"large","parallel":false,"params":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"precondition":null,"result":{"element":{"kind":"f64"},"kind":"list"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":23,"internal":false,"name":"fallback","parallel":false,"params":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"kind":"f64"},"kind":"list"}}],"named_types":{"Lane":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"},"Nested":{"fields":[{"name":"lane","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"name":"extra","type":{"kind":"f64"}}],"kind":"record","name":"Nested"},"Owned":{"fields":[{"name":"values","type":{"kind":"temporary"}}],"kind":"record","name":"Owned"}},"prepared_compiled":{"evaluation":"lazy source-order; successful bindings only","functions":[{"factory":false,"function":"advance","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"drive","retained_bindings":1},{"delegated_calls":1,"factory":true,"function":"projected","retained_bindings":2},{"factory":false,"function":"pick","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"branch","retained_bindings":1},{"delegated_calls":1,"factory":true,"function":"selected","retained_bindings":1},{"delegated_calls":0,"factory":true,"function":"nested","retained_bindings":1},{"delegated_calls":0,"factory":true,"function":"kept","retained_bindings":1},{"delegated_calls":0,"factory":true,"function":"aliases","retained_bindings":2},{"factory":false,"function":"last","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"owned","reason":"no reusable captured work"},{"delegated_calls":1,"factory":true,"function":"fallible","retained_bindings":0},{"factory":false,"function":"chain0","reason":"no reusable captured work"},{"factory":false,"function":"chain1","reason":"no reusable captured work"},{"factory":false,"function":"chain2","reason":"no reusable captured work"},{"factory":false,"function":"chain3","reason":"no reusable captured work"},{"factory":false,"function":"chain4","reason":"no reusable captured work"},{"factory":false,"function":"chain5","reason":"no reusable captured work"},{"factory":false,"function":"chain6","reason":"no reusable captured work"},{"factory":false,"function":"chain7","reason":"no reusable captured work"},{"factory":false,"function":"chain8","reason":"no reusable captured work"},{"delegated_calls":1,"factory":true,"function":"bounded","retained_bindings":1},{"factory":false,"function":"large","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"fallback","retained_bindings":1}],"lifetime":"prepared token","semantics":"sealed-value-residual-v1"},"private_record_elisions":[],"private_sum_spines":[],"schema":1,"state":null,"wire":{"format":"ink-value-wire-v1","functions":{"advance":{"arguments":{"format":"ink-value-wire-v1","identity":"602c4e5703a43aa23338fa011d6642cda72de7cd07ff405e3e485c5881ba504a","named":{},"root":{"fields":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"19d74cac6aa3129f10262e59c194cad7f9b36ee41b7c4bb3bdfd434cf94ca065","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}},"aliases":{"arguments":{"format":"ink-value-wire-v1","identity":"707720be7d2fd978d5b1563e174624fbba446a8447b566b57a958b8ca5181174","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"152a8177038a47dcbc6416cb2d7d38cc76c42d7e55613dee4787f2dfb646e9e7","named":{},"root":{"element":{"kind":"f64"},"kind":"list"}}},"bounded":{"arguments":{"format":"ink-value-wire-v1","identity":"707720be7d2fd978d5b1563e174624fbba446a8447b566b57a958b8ca5181174","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"19d74cac6aa3129f10262e59c194cad7f9b36ee41b7c4bb3bdfd434cf94ca065","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}},"branch":{"arguments":{"format":"ink-value-wire-v1","identity":"4b085fdaecd4dcf6dfc12bd47603cd062a2d000a74079b635c8ef699ce28f16d","named":{},"root":{"fields":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"name":"n","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"19d74cac6aa3129f10262e59c194cad7f9b36ee41b7c4bb3bdfd434cf94ca065","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}},"chain0":{"arguments":{"format":"ink-value-wire-v1","identity":"602c4e5703a43aa23338fa011d6642cda72de7cd07ff405e3e485c5881ba504a","named":{},"root":{"fields":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"19d74cac6aa3129f10262e59c194cad7f9b36ee41b7c4bb3bdfd434cf94ca065","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}},"chain1":{"arguments":{"format":"ink-value-wire-v1","identity":"602c4e5703a43aa23338fa011d6642cda72de7cd07ff405e3e485c5881ba504a","named":{},"root":{"fields":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"19d74cac6aa3129f10262e59c194cad7f9b36ee41b7c4bb3bdfd434cf94ca065","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}},"chain2":{"arguments":{"format":"ink-value-wire-v1","identity":"602c4e5703a43aa23338fa011d6642cda72de7cd07ff405e3e485c5881ba504a","named":{},"root":{"fields":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"19d74cac6aa3129f10262e59c194cad7f9b36ee41b7c4bb3bdfd434cf94ca065","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}},"chain3":{"arguments":{"format":"ink-value-wire-v1","identity":"602c4e5703a43aa23338fa011d6642cda72de7cd07ff405e3e485c5881ba504a","named":{},"root":{"fields":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"19d74cac6aa3129f10262e59c194cad7f9b36ee41b7c4bb3bdfd434cf94ca065","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}},"chain4":{"arguments":{"format":"ink-value-wire-v1","identity":"602c4e5703a43aa23338fa011d6642cda72de7cd07ff405e3e485c5881ba504a","named":{},"root":{"fields":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"19d74cac6aa3129f10262e59c194cad7f9b36ee41b7c4bb3bdfd434cf94ca065","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}},"chain5":{"arguments":{"format":"ink-value-wire-v1","identity":"602c4e5703a43aa23338fa011d6642cda72de7cd07ff405e3e485c5881ba504a","named":{},"root":{"fields":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"19d74cac6aa3129f10262e59c194cad7f9b36ee41b7c4bb3bdfd434cf94ca065","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}},"chain6":{"arguments":{"format":"ink-value-wire-v1","identity":"602c4e5703a43aa23338fa011d6642cda72de7cd07ff405e3e485c5881ba504a","named":{},"root":{"fields":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"19d74cac6aa3129f10262e59c194cad7f9b36ee41b7c4bb3bdfd434cf94ca065","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}},"chain7":{"arguments":{"format":"ink-value-wire-v1","identity":"602c4e5703a43aa23338fa011d6642cda72de7cd07ff405e3e485c5881ba504a","named":{},"root":{"fields":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"19d74cac6aa3129f10262e59c194cad7f9b36ee41b7c4bb3bdfd434cf94ca065","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}},"chain8":{"arguments":{"format":"ink-value-wire-v1","identity":"602c4e5703a43aa23338fa011d6642cda72de7cd07ff405e3e485c5881ba504a","named":{},"root":{"fields":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"19d74cac6aa3129f10262e59c194cad7f9b36ee41b7c4bb3bdfd434cf94ca065","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}},"drive":{"arguments":{"format":"ink-value-wire-v1","identity":"707720be7d2fd978d5b1563e174624fbba446a8447b566b57a958b8ca5181174","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"19d74cac6aa3129f10262e59c194cad7f9b36ee41b7c4bb3bdfd434cf94ca065","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}},"fallback":{"arguments":{"format":"ink-value-wire-v1","identity":"707720be7d2fd978d5b1563e174624fbba446a8447b566b57a958b8ca5181174","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"152a8177038a47dcbc6416cb2d7d38cc76c42d7e55613dee4787f2dfb646e9e7","named":{},"root":{"element":{"kind":"f64"},"kind":"list"}}},"fallible":{"arguments":{"format":"ink-value-wire-v1","identity":"707720be7d2fd978d5b1563e174624fbba446a8447b566b57a958b8ca5181174","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"dd4eeb2390c05e915de706d8e703ebfa5f0eaf949aa9c10fc3f140c8053e212c","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}}},"kept":{"arguments":{"format":"ink-value-wire-v1","identity":"27ff6d09e405c9be34c98fc1ec4cceea33dbf645eaece1458018a3245a50aa33","named":{},"root":{"fields":[{"name":"xs","type":{"element":{"kind":"f64"},"kind":"list"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"19d74cac6aa3129f10262e59c194cad7f9b36ee41b7c4bb3bdfd434cf94ca065","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}},"large":{"arguments":{"format":"ink-value-wire-v1","identity":"602c4e5703a43aa23338fa011d6642cda72de7cd07ff405e3e485c5881ba504a","named":{},"root":{"fields":[{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"152a8177038a47dcbc6416cb2d7d38cc76c42d7e55613dee4787f2dfb646e9e7","named":{},"root":{"element":{"kind":"f64"},"kind":"list"}}},"last":{"unsupported":"unsupported wire descriptor"},"nested":{"arguments":{"format":"ink-value-wire-v1","identity":"707720be7d2fd978d5b1563e174624fbba446a8447b566b57a958b8ca5181174","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"152a8177038a47dcbc6416cb2d7d38cc76c42d7e55613dee4787f2dfb646e9e7","named":{},"root":{"element":{"kind":"f64"},"kind":"list"}}},"owned":{"arguments":{"format":"ink-value-wire-v1","identity":"707720be7d2fd978d5b1563e174624fbba446a8447b566b57a958b8ca5181174","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"152a8177038a47dcbc6416cb2d7d38cc76c42d7e55613dee4787f2dfb646e9e7","named":{},"root":{"element":{"kind":"f64"},"kind":"list"}}},"pick":{"arguments":{"format":"ink-value-wire-v1","identity":"616020740d1857bd448c624ef5c97b48d4c08dfdff08ae12b5beee1198a804f7","named":{},"root":{"fields":[{"name":"n","type":{"fields":[{"name":"lane","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"name":"extra","type":{"kind":"f64"}}],"kind":"record","name":"Nested"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"152a8177038a47dcbc6416cb2d7d38cc76c42d7e55613dee4787f2dfb646e9e7","named":{},"root":{"element":{"kind":"f64"},"kind":"list"}}},"projected":{"arguments":{"format":"ink-value-wire-v1","identity":"707720be7d2fd978d5b1563e174624fbba446a8447b566b57a958b8ca5181174","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"152a8177038a47dcbc6416cb2d7d38cc76c42d7e55613dee4787f2dfb646e9e7","named":{},"root":{"element":{"kind":"f64"},"kind":"list"}}},"selected":{"arguments":{"format":"ink-value-wire-v1","identity":"707720be7d2fd978d5b1563e174624fbba446a8447b566b57a958b8ca5181174","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}},{"name":"n","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"19d74cac6aa3129f10262e59c194cad7f9b36ee41b7c4bb3bdfd434cf94ca065","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}}}}};
const __implementations=[__fn0,__fn1,__fn2,__fn3,__fn4,__fn5,__fn6,__fn7,__fn8,__fn9,__fn10,__fn11,__fn12,__fn13,__fn14,__fn15,__fn16,__fn17,__fn18,__fn19,__fn20,__fn21,__fn22,__fn23];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
const __inputTypes=[{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}]},{"capture":[true,true,true],"types":[{"kind":"f64"},{"kind":"f64"},{"kind":"u32"}]},{"capture":[true,true,true],"types":[{"kind":"f64"},{"kind":"f64"},{"kind":"u32"}]},{"capture":[false],"types":[{"fields":[{"name":"lane","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"name":"extra","type":{"kind":"f64"}}],"kind":"record","name":"Nested"}]},{"capture":[false,true],"types":[{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"},{"kind":"u32"}]},{"capture":[true,true,true],"types":[{"kind":"f64"},{"kind":"f64"},{"kind":"u32"}]},{"capture":[true,true,true],"types":[{"kind":"f64"},{"kind":"f64"},{"kind":"u32"}]},{"capture":[true,false],"types":[{"element":{"kind":"f64"},"kind":"list"},{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}]},{"capture":[true,true,true],"types":[{"kind":"f64"},{"kind":"f64"},{"kind":"u32"}]},{"capture":[false],"types":[{"fields":[{"name":"values","type":{"kind":"temporary"}}],"kind":"record","name":"Owned"}]},{"capture":[true,true,true],"types":[{"kind":"f64"},{"kind":"f64"},{"kind":"u32"}]},{"capture":[true,true,true],"types":[{"kind":"f64"},{"kind":"f64"},{"kind":"u32"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}]},{"capture":[true,true,true],"types":[{"kind":"f64"},{"kind":"f64"},{"kind":"u32"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f64"}}],"kind":"record","name":"Lane"}]},{"capture":[true,true,true],"types":[{"kind":"f64"},{"kind":"f64"},{"kind":"u32"}]}];

// Descriptor work occurs once at module initialisation, never per word-list call.
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=> {
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const output=__representation(f.result,true);
  const body=__implementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
  const needsInput=input.some(c=>c!==__identity);
  const entry=!needsInput && output===__identity ? implementation :
    (...args)=>{const context=new WeakMap();return output(implementation(...(needsInput ? args.map((v,i)=>input[i](v,context)) : args)),context);};
  return [f.name,entry];
})));
export function call(name,args) {switch(name){case "last":throw new Error('temporary storage is internal to a pure invocation');}return functions[name](...args);}
// Shared bounded binary codec; generated code supplies exact descriptors.
export const valueWireFormat='ink-value-wire-v1';
// A connection agrees on the complete value schema before using this format.
// Version byte + schema-directed fields; schema identity is out of band.
export const compactValueWireFormat='ink-value-session-v1';
const wireMagic=Uint8Array.of(73,78,75,86,65,76,0,1);
const wireEncoder=new TextEncoder(),wireDecoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const wireDefaults=Object.freeze({bytes:16777216,nodes:1000000,depth:128}),wireDefaultOptions=Object.freeze({});
const wireDecimal=s=>typeof s==='string'&&/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(s);
function wireLimits(options){if(options===wireDefaultOptions||options===wireDefaults)return wireDefaults;const l={...wireDefaults,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>wireDefaults[k])throw Error('wire hard resource limit');return l;}
const wireFloat=new DataView(new ArrayBuffer(4));
function wireDecodeText(bytes,start,end){
 if(end-start<=16){let text='';for(let i=start;i<end;i++){const byte=bytes[i];if(byte>=128)return wireDecoder.decode(bytes.subarray(start,end));text+=String.fromCharCode(byte);}return text;}
 return wireDecoder.decode(bytes.subarray(start,end));
}
function wireUtf8Length(text){let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const wireOwn=(v,k)=>v!==null&&typeof v==='object'&&Object.hasOwn(v,k);
const wireTagged=(v,k)=>wireOwn(v,k)&&Object.keys(v).length===1;
const wireDouble=new DataView(new ArrayBuffer(8));
function wireF64Bits(v){
 if(typeof v==='number'&&Number.isFinite(v)){wireDouble.setFloat64(0,v,true);return wireDouble.getBigUint64(0,true);}
 if(!wireTagged(v,'F64Bits'))wireInvalidValue();const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))wireInvalidValue();
 const bits=BigInt(text);if(bits>18446744073709551615n)wireInvalidValue();return bits;
}
const wireCanonical=v=>Array.isArray(v)?'['+v.map(wireCanonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort((a,b)=>{const x=Array.from(a,c=>c.codePointAt(0)),y=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]-y[i];return x.length-y.length;}).map(k=>JSON.stringify(k)+':'+wireCanonical(v[k])).join(',')+'}':JSON.stringify(v);
export async function createValueCodec(root,named={}){
 const used=new Set(),budget={nodes:100000};
 function check(t,d=0){
  if(d>64||--budget.nodes<0)throw Error('wire descriptor limit');
  const keys={u32:['kind'],u64:['kind'],i32:['kind'],f32:['kind'],f64:['kind'],bool:['kind'],unit:['kind'],string:['kind'],int:['kind'],id:['kind','name'],ref:['kind','name'],enum:['kind','name','variants'],record:['kind','name','fields'],list:['kind','element'],option:['kind','element'],vector:['kind','element','size'],result:['kind','ok','error']}[t?.kind];
  if(!keys||Object.keys(t).length!==keys.length||keys.some(k=>!Object.hasOwn(t,k)))throw Error('invalid wire descriptor');
  if(keys.includes('name')&&(typeof t.name!=='string'||!t.name.isWellFormed()))throw Error('invalid descriptor name');
  if(t.kind==='ref'){if(!used.has(t.name)){used.add(t.name);if(named[t.name]?.kind!=='record'||named[t.name].name!==t.name)throw Error('unresolved wire reference');check(named[t.name],d+1);}}
  if(t.kind==='record'){if(!Array.isArray(t.fields))throw Error('wire fields');const names=new Set();for(const f of t.fields){if(Object.keys(f).length!==2||typeof f.name!=='string'||!f.name.isWellFormed()||names.has(f.name))throw Error('duplicate wire field');names.add(f.name);check(f.type,d+1);}}
  if(t.kind==='enum'&&(!Array.isArray(t.variants)||!t.variants.length||t.variants.length>64||t.variants.some(v=>typeof v!=='string'||!v.isWellFormed())||new Set(t.variants).size!==t.variants.length))throw Error('wire enum');
  if(['list','vector','option'].includes(t.kind)){if(t.kind==='vector'&&(!Number.isInteger(t.size)||t.size<1||t.size>64))throw Error('wire vector');check(t.element,d+1);}
  if(t.kind==='result'){check(t.ok,d+1);check(t.error,d+1);}
 }
 check(root);const names=Object.fromEntries([...used].sort().map(k=>[k,named[k]]));
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',wireEncoder.encode(wireCanonical({format:valueWireFormat,root,named:names}))));
 return new ValueCodec({format:valueWireFormat,root,named:names,identity:Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('')});
}
// Resolve immutable descriptor edges once. Logical validation traverses the
// literal schema; single-child nodes use a loop rather than recursive closures.
function wireValuePlan(codec){
 const seen=new WeakMap();let remaining=100000;
 const build=type=>{
  const t=codec.resolve(type);if(seen.has(t))return seen.get(t);
  if(--remaining<0)throw Error('wire descriptor limit');const p={kind:t.kind,type:t,decode:null,decodeCompact:null};seen.set(t,p);
  if(t.kind==='record')p.fields=t.fields.map(f=>({name:f.name,plan:build(f.type)}));
  if(t.kind==='list'||t.kind==='vector'||t.kind==='option')p.element=build(t.element);
  if(t.kind==='result'){p.ok=build(t.ok);p.error=build(t.error);}
  return p;
 };return build(codec.descriptor.root);
}
function wireBindDecodePlan(root,compact=false){
 const seen=new Set(),pending=[root];let flags=0;
 while(pending.length){
  const p=pending.pop();if(seen.has(p))continue;seen.add(p);if(compact)p.decodeCompact=compactDecodeOperation(p);else p.decode=wireDecodeOperation(p);
  if(p.fields?.length>4)flags|=1;
  if(p.kind==='u32'||p.kind==='i32'||p.kind==='u64'||p.kind==='f32'||p.kind==='f64')flags|=2;
  if(p.fields)for(const f of p.fields)pending.push(f.plan);
  if(p.element)pending.push(p.element);
  if(p.ok){pending.push(p.ok);pending.push(p.error);}
 }
 return flags|4;
}
// Select literal descriptor operations once, without runtime source generation
// or eval. Recursive edges call the completed plan. The generic scanner remains
// the visitor/validation path and an independent materialisation implementation.
function wireReadOperation(p){
 const t=p.type;
 let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':read=(r,end)=>{r.size(end,4);const value={F32Bits:r.view.getUint32(r.cursor,true)};r.cursor=end;return value;};break;
  case 'f64':read=(r,end)=>{r.size(end,8);const value={F64Bits:r.view.getBigUint64(r.cursor,true).toString()};r.cursor=end;return value;};break;
  case 'u64':read=(r,end)=>{r.size(end,8);const value=r.view.getBigUint64(r.cursor,true);r.cursor=end;return value;};break;
  case 'string':read=(r,end)=>r.text(end);break;
  case 'int':read=(r,end)=>{const text=r.text(end);if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=(r,end)=>{const text=r.text(end);if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=(r,end)=>{const text=r.text(end);if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{
    if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;
    if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');
    const values=new Array(n);for(let i=0;i<n;i++)values[i]=element.decode(r,end,d+1);return values;
   };break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1)});break;
    case 2:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1)});break;
    case 3:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1)});break;
    case 4:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1),[fs[3].name]:fs[3].plan.decode(r,end,d+1)});break;
    default:read=(r,end,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decode(r,end,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,end,d)=>{const tag=r.tag(end);return tag?{Some:p.element.decode(r,end,d+1)}:{None:null};};break;
  case 'result':read=(r,end,d)=>r.tag(end)?{Err:p.error.decode(r,end,d+1)}:{Ok:p.ok.decode(r,end,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function wireDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=wireReadOperation(field.plan),name=field.name;
  return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),childEnd=r.enter(end,d+1),item=read(r,childEnd,d+1);if(r.cursor!==childEnd)throw Error('trailing wire frame bytes');const value={[name]:item};if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
 }
 const read=wireReadOperation(p);
 return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
}
class WireDecodeCursor{
 constructor(bytes,view,limits){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
// Bind literal validation and postorder visitation once for every descriptor.
// No logical carriers are allocated; projection still validates every child.
function wireScanPlan(root){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,scan:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.scan=wireScanOperation(p);return p;
 };
 return build(root);
}
function wireScanOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':case 'f64':case 'u64':{const size=p.kind==='f32'?4:8;read=(r,end)=>{r.size(end,size);r.cursor=end;};break;}
  case 'string':read=(r,end)=>{let i=r.cursor;while(i<end&&r.bytes[i]<128)i++;if(i<end)wireDecoder.decode(r.bytes.subarray(r.cursor,end));r.cursor=end;};break;
  case 'int':case 'id':case 'enum':read=(r,end)=>{const text=r.text(end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');for(let i=0;i<n;i++)element.scan(r,end,d+1);};break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>{};break;
    case 1:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);};break;
    case 2:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);};break;
    case 3:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);};break;
    case 4:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);fs[3].plan.scan(r,end,d+1);};break;
    default:read=(r,end,d)=>{for(const f of fs)f.plan.scan(r,end,d+1);};
   }break;
  }
  case 'option':read=(r,end,d)=>{if(r.tag(end))p.element.scan(r,end,d+1);};break;
  case 'result':read=(r,end,d)=>{(r.tag(end)?p.error:p.ok).scan(r,end,d+1);};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return (r,parentEnd,d)=>{
  const end=r.enter(parentEnd,d),start=r.cursor,value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');
  const visitor=r.visitor;if(visitor&&(!r.selected||r.selected.has(t.name))){if(r.spans)visitor(t,r.bytes,start,end,d);else visitor(t,r.bytes.subarray(start,end),d);}
  return value;
 };
}
// Separate methods keep decoding's cursor callsites monomorphic. Both cursors
// are checked against the independent generic scanner and malformed fixtures.
class WireScanCursor{
 constructor(bytes,view,limits,visitor,selected,spans){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.visitor=visitor;this.selected=selected;this.spans=spans;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
function compactReadOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=()=>null;break;
  case 'bool':read=r=>{r.require(1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':case 'i32':read=r=>{r.require(4);const n=p.kind==='u32'?r.view.getUint32(r.cursor,true):r.view.getInt32(r.cursor,true);r.cursor+=4;return n;};break;
  case 'f32':read=r=>{r.require(4);const n=r.view.getUint32(r.cursor,true);r.cursor+=4;return {F32Bits:n};};break;
  case 'f64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return {F64Bits:n.toString()};};break;
  case 'u64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return n;};break;
  case 'string':read=r=>r.text();break;
  case 'int':read=r=>{const text=r.text();if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=r=>{const text=r.text();if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=r=>{const text=r.text();if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':read=(r,d)=>{const n=r.count();if(n>r.remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');const values=new Array(n);for(let i=0;i<n;i++)values[i]=p.element.decodeCompact(r,d+1);return values;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1)});break;
    case 2:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1)});break;
    case 3:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1)});break;
    case 4:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1),[fs[3].name]:fs[3].plan.decodeCompact(r,d+1)});break;
    default:read=(r,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decodeCompact(r,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,d)=>r.tag()?{Some:p.element.decodeCompact(r,d+1)}:{None:null};break;
  case 'result':read=(r,d)=>r.tag()?{Err:p.error.decodeCompact(r,d+1)}:{Ok:p.ok.decodeCompact(r,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function compactDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=compactReadOperation(field.plan),name=field.name;
  return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');if(d+1>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return {[name]:read(r,d+1)};};
 }
 const read=compactReadOperation(p);
 return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return read(r,d);};
}
class CompactDecodeCursor{
 constructor(bytes,limits,flags){this.bytes=bytes;this.view=flags&2?new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength):null;this.cursor=1;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 require(n){if(n>this.bytes.length-this.cursor)throw Error('truncated compact value');}
 count(){
  if(this.cursor>=this.bytes.length)throw Error('truncated compact value');
  const first=this.bytes[this.cursor++];if(first<128)return first;
  let value=first&127,scale=128;
  for(let i=1;i<5;i++){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const byte=this.bytes[this.cursor++];if(i===4&&byte>15)throw Error('compact count overflow');value+=(byte&127)*scale;if(byte<128){if(byte===0)throw Error('noncanonical compact count');return value;}scale*=128;}throw Error('compact count overflow');
 }
 tag(){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const tag=this.bytes[this.cursor++];if(tag>1)throw Error('wire sum tag');return tag;}
 text(){const n=this.count();this.require(n);const start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
function wireInvalidValue(){throw Error('invalid value for wire schema');}
// Capture has the canonical logical meaning of decode(encode(value)), without
// allocating wire bytes. A separate plan leaves validation/decoder hot shapes
// unchanged and never retains host input containers between calls.
function wireCapturePlan(root,checked=true){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,capture:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({name:f.name,plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.capture=checked?wireCaptureOperation(p):wireCopyOperation(p);return p;
 };return build(root);
}
function wireCaptureOperation(p){
 const t=p.type;let copy;
 switch(p.kind){
  case 'unit':copy=v=>{if(v!==null)wireInvalidValue();return null;};break;
  case 'bool':copy=(v,r)=>{if(typeof v!=='boolean')wireInvalidValue();r.add(1);return v;};break;
  case 'u32':case 'i32':{
   const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
   copy=(v,r)=>{if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();r.add(4);return v===0?0:v;};break;
  }
  case 'u64':copy=(v,r)=>{const kind=typeof v;if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();r.add(8);return n;};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'int':case 'id':case 'enum':copy=(v,r)=>{const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;if(typeof text!=='string'||!text.isWellFormed()||text.length>r.limit)wireInvalidValue();if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();r.add(wireUtf8Length(text));return p.kind==='int'?{Int:text}:text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   copy=(v,r,d)=>{if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();const n=v.length;if(n>r.remaining||size!==null&&n!==size)wireInvalidValue();r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=element.capture(v[i],r,d+1);return out;};break;
  }
  case 'record':{
   const fs=p.fields;let fields;
   switch(fs.length){
    case 0:fields=()=>({});break;
    case 1:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:fields=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }
   copy=(v,r,d)=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();for(const f of fs)if(!wireOwn(v,f.name))wireInvalidValue();return fields(v,r,d);};break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'None')&&v.None===null)return {None:null};if(wireTagged(v,'Some'))return {Some:p.element.capture(v.Some,r,d+1)};wireInvalidValue();};break;
  case 'result':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'Ok'))return {Ok:p.ok.capture(v.Ok,r,d+1)};if(wireTagged(v,'Err'))return {Err:p.error.capture(v.Err,r,d+1)};wireInvalidValue();};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
class WireCaptureCursor{
 constructor(limits){this.remaining=limits.nodes;this.depth=limits.depth;this.limit=limits.bytes;this.bytes=40;this.add(0);}
 add(n){this.bytes+=n;if(this.bytes>this.limit)throw Error('wire byte limit');}
 enter(depth,bytes){if(depth>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.add(bytes);}
 text(value){if(value.length>this.limit)throw Error('wire byte limit');this.add(wireUtf8Length(value));}
}
// Literal lowerers share this fixed resource policy with logical capture.
export function createValueCaptureBudget(options=wireDefaultOptions){return new WireCaptureCursor(wireLimits(options));}
// The trusted-value API has the same canonical copy and ownership semantics.
// Its caller supplies a stable value accepted by validateValue. Shape/range
// checks remain at external capture boundaries; resource limits still apply.
function wireCopyOperation(p){
 let copy;
 switch(p.kind){
  case 'unit':copy=()=>null;break;
  case 'bool':copy=(v,r)=>{r.add(1);return v;};break;
  case 'u32':copy=(v,r)=>{r.add(4);return v>>>0;};break;
  case 'i32':copy=(v,r)=>{r.add(4);return v|0;};break;
  case 'u64':copy=(v,r)=>{r.add(8);return BigInt(v);};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'){wireFloat.setFloat32(0,v,true);bits=wireFloat.getUint32(0,true);}else bits=v.F32Bits;r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'id':case 'enum':copy=(v,r)=>{r.add(wireUtf8Length(v));return v;};break;
  case 'int':copy=(v,r)=>{const text=typeof v==='bigint'?v.toString():v.Int;r.add(wireUtf8Length(text));return {Int:text};};break;
  case 'list':case 'vector':copy=(v,r,d)=>{const n=v.length;if(n>r.remaining)throw Error('wire sequence size');r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=p.element.capture(v[i],r,d+1);return out;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:copy=()=>({});break;
    case 1:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:copy=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'None')&&v.None===null?{None:null}:{Some:p.element.capture(v.Some,r,d+1)};};break;
  case 'result':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'Ok')?{Ok:p.ok.capture(v.Ok,r,d+1)}:{Err:p.error.capture(v.Err,r,d+1)};};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
// Emit the cached literal schema with one forward writer. Each value is checked
// where it is consumed; byte bounds belong to the writer, not a second size walk.
function wireEncodeValue(root,value,l,w){
 let remaining=l.nodes;const depthLimit=l.depth;
 const node=(p,v,d)=>{
  if(d>depthLimit||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type,start=w.beginNode();
  switch(p.kind){
   case 'unit':if(v!==null)wireInvalidValue();break;
   case 'bool':if(typeof v!=='boolean')wireInvalidValue();w.byte(+v);break;
   case 'u32':case 'i32':{
    const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
    if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();w.word(v>>>0);break;
   }
   case 'u64':{
    const kind=typeof v;
    if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
    const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();w.wide(n);break;
   }
   case 'f64':w.wide(wireF64Bits(v));break;
   case 'f32':{
    let bits;
    if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}
    else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
    w.word(bits);break;
   }
   case 'string':case 'int':case 'id':case 'enum':{
    const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
    if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&(typeof text!=='string'||!/^[0-9a-f]{32}$/.test(text))||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
    w.text(text);break;
   }
   case 'list':case 'vector':{
    if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
    if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
    w.count(v.length);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);break;
   }
   case 'record':{
    const fs=p.fields;
    if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
    for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
    for(let i=0;i<fs.length;i++){const f=fs[i];node(f.plan,v[f.name],d+1);}break;
   }
   case 'option':{
    if(wireTagged(v,'None')&&v.None===null)w.byte(0);
    else if(wireTagged(v,'Some')){w.byte(1);node(p.element,v.Some,d+1);}else wireInvalidValue();break;
   }
   case 'result':{
    if(wireTagged(v,'Ok')){w.byte(0);node(p.ok,v.Ok,d+1);}
    else if(wireTagged(v,'Err')){w.byte(1);node(p.error,v.Err,d+1);}else wireInvalidValue();break;
   }
   default:throw Error('unsupported wire kind');
  }
  w.endNode(start);
 };
 node(root,value,0);
}
function wireCheckValue(root,value,l){
 let remaining=l.nodes,total=40;
 const add=n=>{total+=n;if(total>l.bytes)throw Error('wire byte limit');};
 const node=(p,v,d)=>{
  while(true){
   if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
   const t=p.type;
   switch(p.kind){
    case 'unit':if(v!==null)wireInvalidValue();add(4);return;
    case 'bool':if(typeof v!=='boolean')wireInvalidValue();add(5);return;
    case 'u32':case 'i32':{
     const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
     if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();add(8);return;
    }
    case 'u64':{
     const kind=typeof v;
     if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
     const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();add(12);return;
    }
    case 'f64':wireF64Bits(v);add(12);return;
    case 'f32':{
     if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();}
     else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();const bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
     add(8);return;
    }
    case 'string':case 'int':case 'id':case 'enum':{
     const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
     if(typeof text!=='string'||!text.isWellFormed()||text.length>l.bytes)wireInvalidValue();
     if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
     add(4+wireUtf8Length(text));return;
    }
    case 'list':case 'vector':{
     if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
     if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
     add(8);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);return;
    }
    case 'record':{
     const fs=p.fields;
     if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
     for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
     add(4);if(!fs.length)return;
     for(let i=0;i<fs.length-1;i++)node(fs[i].plan,v[fs[i].name],d+1);
     const f=fs[fs.length-1];p=f.plan;v=v[f.name];d++;continue;
    }
    case 'option':{
     if(wireTagged(v,'None')&&v.None===null){add(5);return;}
     if(!wireTagged(v,'Some'))wireInvalidValue();add(5);p=p.element;v=v.Some;d++;continue;
    }
    case 'result':{
     if(wireTagged(v,'Ok')){add(5);p=p.ok;v=v.Ok;}
     else if(wireTagged(v,'Err')){add(5);p=p.error;v=v.Err;}else wireInvalidValue();
     d++;continue;
    }
    default:throw Error('unsupported wire kind');
   }
  }
 };
 node(root,value,0);if(total>l.bytes)throw Error('wire byte limit');
}
// A single cursor replaces per-node child closures and {end,value} temporaries.
// Projection filters limit callback materialisation, never schema validation.
function wireScanValue(root,bytes,view,l,materialize,visitor,selected,spans){
 let cursor=40,remaining=l.nodes;
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,parentEnd,d)=>{
  if(d>l.depth||--remaining<0||cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const t=p.type,start=cursor+4,end=start+view.getUint32(cursor,true);if(end>parentEnd)throw Error('truncated wire frame');cursor=start;let value;
  switch(p.kind){
   case 'unit':if(end-start!==0)throw Error('malformed wire scalar');value=null;break;
   case 'bool':if(end-start!==1)throw Error('malformed wire scalar');if(bytes[start]>1)throw Error('invalid wire Bool');value=!!bytes[start];cursor=end;break;
   case 'u32':case 'i32':if(end-start!==4)throw Error('malformed wire scalar');value=p.kind==='u32'?view.getUint32(start,true):view.getInt32(start,true);cursor=end;break;
   case 'f32':if(end-start!==4)throw Error('malformed wire scalar');if(materialize)value={F32Bits:view.getUint32(start,true)};cursor=end;break;
   case 'f64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value={F64Bits:view.getBigUint64(start,true).toString()};cursor=end;break;
   case 'u64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value=view.getBigUint64(start,true);cursor=end;break;
   case 'string':case 'int':case 'id':case 'enum':{
    if(p.kind==='string'&&!materialize){let i=start;while(i<end&&bytes[i]<128)i++;if(i<end)wireDecoder.decode(bytes.subarray(start,end));}
    else{const text=wireDecodeText(bytes,start,end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    cursor=end;break;
   }
   case 'list':case 'vector':{
    if(start+4>end)throw Error('wire list count');const n=view.getUint32(start,true);cursor+=4;
    if(n>remaining||n>Math.floor((end-cursor)/4)||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,end,d+1);if(materialize)value.push(child);}break;
   }
   case 'record':{
    const fs=p.fields;
    // Computed literal keys create own data properties even for __proto__ or
    // prototype setters. Common small records need no descriptor allocations.
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:value={};break;case 1:value={[fs[0].name]:node(fs[0].plan,end,d+1)};break;case 2:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1)};break;case 3:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1)};break;case 4:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1),[fs[3].name]:node(fs[3].plan,end,d+1)};break;}
    }else{if(materialize)value={};for(const f of fs){const child=node(f.plan,end,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}}break;
   }
   case 'option':case 'result':{
    if(start===end||bytes[cursor]>1)throw Error('wire sum tag');const tag=bytes[cursor++];
    if(p.kind==='option'&&tag===0){if(materialize)value={None:null};}
    else{const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,end,d+1);if(materialize)value={[label]:child};}break;
   }
   default:throw Error('unsupported wire kind');
  }
  if(cursor!==end)throw Error('trailing wire frame bytes');
  if(visitor&&(!selected||selected.has(t.name))){if(spans)visitor(t,bytes,start,end,d);else visitor(t,bytes.subarray(start,end),d);}
  return value;
 };
 const result=node(root,bytes.length,0);if(cursor!==bytes.length)throw Error('trailing wire bytes');return result;
}
export class ValueCodec{
 #hash;
 #header;
 #headerWords;
 #descriptor;
 #valuePlan;
 #compactCodec;
 #encoder;
 #decodeBound=0;
 #scanPlan=null;
 #capturePlan=null;
 #copyPlan=null;
 get descriptor(){return this.#descriptor;}
 constructor(descriptor){
  // This synchronous path is for compiler-generated immutable metadata. For
  // untrusted descriptors use createValueCodec and compare the computed identity.
  if(descriptor?.format!==valueWireFormat||!/^[0-9a-f]{64}$/.test(descriptor.identity))throw Error('invalid wire schema');
  this.#descriptor=structuredClone(descriptor);this.#hash=Uint8Array.from(descriptor.identity.match(/../g),s=>parseInt(s,16));
  this.#header=new Uint8Array(40);this.#header.set(wireMagic);this.#header.set(this.#hash,8);
  const headerView=new DataView(this.#header.buffer);this.#headerWords=Array.from({length:10},(_,i)=>headerView.getUint32(i*4,true));
  const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}};freeze(this.descriptor);this.#valuePlan=wireValuePlan(this);
 }
 resolve(t){for(let i=0;i<64;i++){if(t.kind!=='ref')return t;t=this.descriptor.named[t.name];if(!t)throw Error('wire reference');}throw Error('wire reference cycle');}
 validateValue(value,options=wireDefaultOptions){wireCheckValue(this.#valuePlan,value,wireLimits(options));return true;}
 capture(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#capturePlan??=wireCapturePlan(this.#valuePlan);return this.#capturePlan.capture(value,new WireCaptureCursor(limits),0);}
 copy(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#copyPlan??=wireCapturePlan(this.#valuePlan,false);return this.#copyPlan.capture(value,new WireCaptureCursor(limits),0);}
 compact(){return this.#compactCodec??=new CompactValueCodec(this);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new WireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.bytes(this.#header);wireEncodeValue(this.#valuePlan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new WireEncoder(options);w.bytes(wireMagic);w.bytes(this.#hash);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 scan(bytes,options=wireDefaultOptions,materialize=false,visitor=null,names=null,spans=false){
  const l=wireLimits(options);if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<44||bytes.length>l.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==this.#headerWords[i])throw Error('wire format or schema mismatch');
  if(names!==null&&(!Array.isArray(names)||names.length>100000||names.some(n=>typeof n!=='string')))throw Error('wire visitor names');
  if(materialize&&!visitor){this.#decodeBound||=wireBindDecodePlan(this.#valuePlan);const cursor=new WireDecodeCursor(bytes,view,l);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#valuePlan.decode(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  if(!materialize){this.#scanPlan??=wireScanPlan(this.#valuePlan);const cursor=new WireScanCursor(bytes,view,l,visitor,names===null?null:new Set(names),spans),value=this.#scanPlan.scan(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  return wireScanValue(this.#valuePlan,bytes,view,l,materialize,visitor,names===null?null:new Set(names),spans);
 }
 visit(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names);}
 visitSpans(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names,true);}
 validate(bytes,options=wireDefaultOptions){this.scan(bytes,options,false);return true;}
 decode(bytes,options=wireDefaultOptions){return this.scan(bytes,options,true);}
}

// Bounded forward emission avoids building and repeatedly joining child buffers.
class WireEncoder{
 #data=new Uint8Array(256);#view=new DataView(this.#data.buffer);#at=0;#remaining;#depth=0;#byteLimit;#depthLimit;
 active=false;
 constructor(options){this.reset(options);}
 reset(options){const limits=wireLimits(options);this.#byteLimit=limits.bytes;this.#depthLimit=limits.depth;this.#remaining=limits.nodes;this.#depth=0;this.#at=0;this.active=true;}
 get capacity(){return this.#data.length;}
 get position(){return this.#at;}
 beginNode(){const at=this.#at;this.word(0);return at;}
 endNode(at){this.patchWord(at,this.#at-at-4);}
 count(n){this.word(n);}
 beginCount(){const at=this.position;this.count(0);return at;}
 endCount(at,n){this.patchWord(at,n);}
 #reserve(size){
  const end=this.#at+size;if(end>this.#byteLimit)throw Error('wire byte limit');
  if(end>this.#data.length){const next=new Uint8Array(Math.min(this.#byteLimit,Math.max(end,this.#data.length*2)));next.set(this.#data.subarray(0,this.#at));this.#data=next;this.#view=new DataView(next.buffer);}
  return end;
 }
 bytes(bytes){const end=this.#reserve(bytes.length);this.#data.set(bytes,this.#at);this.#at=end;}
 byte(n){if(!Number.isInteger(n)||n<0||n>255)throw Error('wire byte range');this.#reserve(1);this.#data[this.#at++]=n;}
 word(n){if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire word range');const end=this.#reserve(4);this.#view.setUint32(this.#at,n,true);this.#at=end;}
 wide(n){if(typeof n!=='bigint'||n<0n||n>18446744073709551615n)throw Error('wire wide range');const end=this.#reserve(8);this.#view.setBigUint64(this.#at,n,true);this.#at=end;}
 text(text,count=false){
  if(typeof text!=='string')throw Error('wire Unicode');
  if(text.length<=16){
   let ascii=true;for(let i=0;i<text.length;i++)if(text.charCodeAt(i)>=128){ascii=false;break;}
   if(ascii){if(count)this.count(text.length);const end=this.#reserve(text.length);for(let i=0;i<text.length;i++)this.#data[this.#at+i]=text.charCodeAt(i);this.#at=end;return;}
  }
  if(!text.isWellFormed())throw Error('wire Unicode');const size=wireUtf8Length(text);if(count)this.count(size);
  const end=this.#reserve(size),r=wireEncoder.encodeInto(text,this.#data.subarray(this.#at,end));if(r.read!==text.length||r.written!==size)throw Error('wire UTF-8 size');this.#at=end;
 }
 patchWord(at,n){if(!Number.isInteger(at)||at<0||at+4>this.#at||!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire patch offset');this.#view.setUint32(at,n,true);}
 patchByte(at,n){if(!Number.isInteger(at)||at<0||at>=this.#at||!Number.isInteger(n)||n<0||n>255)throw Error('wire patch offset');this.#data[at]=n;}
 replace(at,removed,bytes){
  if(!Number.isInteger(at)||!Number.isInteger(removed)||at<0||removed<0||at+removed>this.#at||!(bytes instanceof Uint8Array))throw Error('wire replacement range');
  const extra=bytes.length-removed,end=extra>0?this.#reserve(extra):this.#at+extra;
  this.#data.copyWithin(at+bytes.length,at+removed,this.#at);this.#data.set(bytes,at);this.#at=end;
 }
 // Literal generated writers use balanced frames without per-node callbacks.
 // An exception abandons this invocation; encodeWith never reuses its writer.
 openFrame(){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;return at;}
 closeFrame(at){if(this.#depth===0)throw Error('wire frame boundary');this.#depth--;this.endNode(at);}
 frame(emit){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;try{emit(this);}finally{this.#depth--;}this.endNode(at);}
 reorder(start,spans){
  const sorted=spans.slice().sort((a,b)=>a[0]-b[0]);let at=start;
  for(const [a,b] of sorted){if(!Number.isInteger(a)||!Number.isInteger(b)||a!==at||b<a)throw Error('wire span permutation');at=b;}
  if(start<0||start>this.#at||at!==this.#at)throw Error('wire span permutation');
  if(spans.every((s,i)=>s===sorted[i]))return;
  const copy=this.#data.slice(start,this.#at);at=start;for(const [a,b] of spans){this.#data.set(copy.subarray(a-start,b-start),at);at+=b-a;}
 }
 finish(){if(this.#depth!==0)throw Error('wire frame boundary');return this.#data.slice(0,this.#at);}
}

class CompactWireEncoder extends WireEncoder{
 beginNode(){return 0;}
 endNode(){}
 endCount(at,n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  if(n<128){this.patchByte(at,n);return;}
  const bytes=[];while(n>=128){bytes.push(n%128+128);n=Math.floor(n/128);}bytes.push(n);this.replace(at,1,Uint8Array.from(bytes));
 }
 count(n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  while(n>=128){this.byte(n%128+128);n=Math.floor(n/128);}this.byte(n);
 }
 text(text){super.text(text,true);}
}

function compactScanValue(root,bytes,l,materialize){
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let cursor=1,remaining=l.nodes;
 const require=n=>{if(n>bytes.length-cursor)throw Error('truncated compact value');};
 const count=()=>{
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   require(1);const byte=bytes[cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }throw Error('compact count overflow');
 };
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,d)=>{
  if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type;let value;
  switch(p.kind){
   case 'unit':return null;
   case 'bool':require(1);if(bytes[cursor]>1)throw Error('invalid wire Bool');return !!bytes[cursor++];
   case 'u32':case 'i32':require(4);value=p.kind==='u32'?view.getUint32(cursor,true):view.getInt32(cursor,true);cursor+=4;return value;
   case 'f32':require(4);if(materialize)value={F32Bits:view.getUint32(cursor,true)};cursor+=4;return value;
   case 'f64':require(8);if(materialize)value={F64Bits:view.getBigUint64(cursor,true).toString()};cursor+=8;return value;
   case 'u64':require(8);if(materialize)value=view.getBigUint64(cursor,true);cursor+=8;return value;
   case 'string':case 'int':case 'id':case 'enum':{
    const n=count();require(n);const start=cursor;cursor+=n;
    if(p.kind==='string'&&!materialize){let i=start;while(i<cursor&&bytes[i]<128)i++;if(i<cursor)wireDecoder.decode(bytes.subarray(start,cursor));}
    else{const text=wireDecodeText(bytes,start,cursor);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    return value;
   }
   case 'list':case 'vector':{
    const n=count();if(n>remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,d+1);if(materialize)value.push(child);}return value;
   }
   case 'record':{
    const fs=p.fields;
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:return {};case 1:return {[fs[0].name]:node(fs[0].plan,d+1)};case 2:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1)};case 3:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1)};case 4:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1),[fs[3].name]:node(fs[3].plan,d+1)};}
    }
    if(materialize)value={};for(const f of fs){const child=node(f.plan,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}return value;
   }
   case 'option':case 'result':{
    require(1);const tag=bytes[cursor++];if(tag>1)throw Error('wire sum tag');
    if(p.kind==='option'&&tag===0)return materialize?{None:null}:undefined;
    const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,d+1);
    return materialize?{[label]:child}:undefined;
   }
   default:throw Error('unsupported wire kind');
  }
 };
 const value=node(root,0);if(cursor!==bytes.length)throw Error('trailing compact bytes');return value;
}

// General transport codec, independent of source rewrites and checkpoints.
// The sender/receiver must negotiate this exact identity and format. There is
// deliberately no claim that the bytes themselves identify their schema.
export class CompactValueCodec{
 #source;#plan;#encoder;#decodeBound=0;
 get format(){return compactValueWireFormat;}
 get identity(){return this.#source.descriptor.identity;}
 constructor(valueCodec){if(!(valueCodec instanceof ValueCodec))throw Error('compact codec requires a checked value codec');this.#source=valueCodec;this.#plan=wireValuePlan(valueCodec);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new CompactWireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.byte(1);wireEncodeValue(this.#plan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new CompactWireEncoder(options);w.byte(1);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 #scan(bytes,options,materialize){
  const l=wireLimits(options);
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<1||bytes.length>l.bytes)throw Error('wire byte limit or header');
  if(bytes[0]!==1)throw Error('compact format mismatch');
  if(materialize){this.#decodeBound||=wireBindDecodePlan(this.#plan,true);const cursor=new CompactDecodeCursor(bytes,l,this.#decodeBound);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#plan.decodeCompact(cursor,0);if(cursor.cursor!==bytes.length)throw Error('trailing compact bytes');return value;}
  return compactScanValue(this.#plan,bytes,l,materialize);
 }
 decode(bytes,options=wireDefaultOptions){return this.#scan(bytes,options,true);}
 validate(bytes,options=wireDefaultOptions){this.#scan(bytes,options,false);return true;}
}

// Compiler materialisers consume already validated bytes synchronously. This
// factory is for trusted emitted code, not untrusted descriptor/callback data.
// The complete generic validator runs before any compiler reader is invoked.
class ValidatedValueReader{
 constructor(bytes,compact){this.bytes=bytes;this.view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);this.cursor=compact?1:40;this.compact=compact;}
 frame(){if(this.compact)return 0;const end=this.cursor+4+this.view.getUint32(this.cursor,true);this.cursor+=4;return end;}
 finish(end){if(!this.compact&&this.cursor!==end)throw Error('compiled reader frame mismatch');}
 byte(){return this.bytes[this.cursor++];}
 word(){const n=this.view.getUint32(this.cursor,true);this.cursor+=4;return n;}
 signed(){const n=this.view.getInt32(this.cursor,true);this.cursor+=4;return n;}
 wide(){const n=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return n;}
 count(){if(!this.compact)return this.word();let n=0,scale=1,byte;do{byte=this.byte();n+=(byte&127)*scale;scale*=128;}while(byte>=128);return n;}
 text(end){const n=this.compact?this.count():end-this.cursor,start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
class CompiledCompactValueCodec extends CompactValueCodec{
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,true),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
}
class CompiledValueCodec extends ValueCodec{
 #read;#compiledCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,false),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
 compact(){return this.#compiledCompact??=new CompiledCompactValueCodec(this,this.#read);}
}
export function createCompiledValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new CompiledValueCodec(descriptor,read);}

// Trusted literal materialisers may use this checked reader to validate and
// construct in one traversal. The emitter must use frame/finish at every source
// node, typed text reads and counted sequence reads; arbitrary callbacks do not
// establish a schema correspondence proof. The independent scanner remains the
// validation oracle and the original factory retains its pre-validation path.
function literalValueHeader(identity){
 const bytes=new Uint8Array(40);bytes.set(wireMagic);
 for(let i=0;i<32;i++)bytes[i+8]=parseInt(identity.slice(i*2,i*2+2),16);
 const view=new DataView(bytes.buffer),words=new Uint32Array(10);
 for(let i=0;i<10;i++)words[i]=view.getUint32(i*4,true);
 return words;
}
class CheckedLiteralValueReader {
 constructor(bytes,header,compact,limits){
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<(compact?1:44)||bytes.length>limits.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  if(compact){if(bytes[0]!==1)throw Error('compact format mismatch');}
  else for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==header[i])throw Error('wire format or schema mismatch');
  this.bytes=bytes;this.view=view;
  this.cursor=compact?1:40;this.compact=compact;this.remaining=limits.nodes;this.depth=limits.depth;this.ends=[];
 }
 require(n){if(this.cursor+n>(this.ends.at(-1)??this.bytes.length))throw Error('truncated wire frame');}
 frame(){
  if(this.ends.length>this.depth||--this.remaining<0)throw Error('wire node or depth limit');
  let end=this.bytes.length;
  if(!this.compact){this.require(4);end=this.cursor+4+this.view.getUint32(this.cursor,true);this.require(end-this.cursor);this.cursor+=4;}
  this.ends.push(end);return this.compact?0:end;
 }
 finish(end){
  if(!this.ends.length||!this.compact&&(this.ends.at(-1)!==end||this.cursor!==end))throw Error('compiled reader frame mismatch');
  this.ends.pop();
 }
 byte(){this.require(1);const value=this.bytes[this.cursor++];if(value>1)throw Error('wire sum tag or Bool');return value;}
 word(){this.require(4);const value=this.view.getUint32(this.cursor,true);this.cursor+=4;return value;}
 signed(){this.require(4);const value=this.view.getInt32(this.cursor,true);this.cursor+=4;return value;}
 wide(){this.require(8);const value=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return value;}
 rawCount(){
  if(!this.compact)return this.word();
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   this.require(1);const byte=this.bytes[this.cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }
  throw Error('compact count overflow');
 }
 count(size){
  const value=this.rawCount();
  if(value>this.remaining||size!==undefined&&value!==size)throw Error('wire sequence size');
  return value;
 }
 text(end,kind='string',variants){
  const size=this.compact?this.rawCount():end-this.cursor;
  this.require(size);const start=this.cursor;this.cursor+=size;
  const value=wireDecodeText(this.bytes,start,this.cursor);
  if(kind==='int'&&!wireDecimal(value)||kind==='id'&&!/^[0-9a-f]{32}$/.test(value)||kind==='enum'&&!variants.includes(value))throw Error('malformed wire text');
  return value;
 }
 complete(){if(this.ends.length||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
// Compact source nodes have no individual frame ends: retain the same checked
// depth/node order using a counter, with bounds against the complete buffer.
class CheckedCompactLiteralValueReader extends CheckedLiteralValueReader {
 constructor(bytes,limits){super(bytes,null,true,limits);this.level=0;}
 require(n){if(this.cursor+n>this.bytes.length)throw Error('truncated wire frame');}
 frame(){if(this.level>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.level++;return 0;}
 finish(_end){if(!this.level)throw Error('compiled reader frame mismatch');this.level--;}
 complete(){if(this.level||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
class FusedCompactValueCodec extends CompactValueCodec {
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedCompactLiteralValueReader(bytes,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
}
class FusedValueCodec extends ValueCodec {
 #read;#header;#fusedCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;this.#header=literalValueHeader(this.descriptor.identity);}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedLiteralValueReader(bytes,this.#header,false,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
 compact(){return this.#fusedCompact??=new FusedCompactValueCodec(this,this.#read);}
}
export function createFusedValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new FusedValueCodec(descriptor,read);}
// JSON text is a boundary adapter to an ordinary recursive Ink datatype.
// No JavaScript Number conversion occurs for JSON numeric tokens.
export function jsonNumberToken(s){return typeof s==='string'&&/^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/.test(s);}
// JSON numeric tokens have an ASCII grammar. Check validated UTF-8 spans
// directly, preserving exact lexemes without allocating a decoded String.
function jsonNumberSpan(bytes,lo,hi){
 let at=lo;if(bytes[at]===45)at++;
 if(at>=hi)return false;
 if(bytes[at]===48)at++;
 else{if(bytes[at]<49||bytes[at]>57)return false;do{at++;}while(at<hi&&bytes[at]>=48&&bytes[at]<=57);}
 if(at<hi&&bytes[at]===46){const start=++at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 if(at<hi&&(bytes[at]===69||bytes[at]===101)){at++;if(at<hi&&(bytes[at]===43||bytes[at]===45))at++;const start=at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 return at===hi;
}
const jsonWireEncoder=new TextEncoder();
// Scalar conversion completes before writer callbacks; no per-value byte array.
const jsonFloatScratch=new DataView(new ArrayBuffer(4));
function jsonUtf8Length(text){if(text.length>16&&!/[^\x00-\x7f]/.test(text))return text.length;let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const jsonLimits={bytes:16777216,nodes:1000000,depth:128};
const jsonQuoters=new WeakSet();
/** Explicit, bounded reuse of immutable JSON string quotes. Cache payload bytes
 * are UTF-16 storage estimates; entry caps bound separate Map/object overhead.
 * Logical output budgets are charged again on every use, including cache hits.
 */
export function createJsonQuoter({maxEntries=1024,maxBytes=131072}={}){
 if(!Number.isSafeInteger(maxEntries)||maxEntries<0||maxEntries>65536||!Number.isSafeInteger(maxBytes)||maxBytes<0||maxBytes>16777216)throw Error('JSON quote cache budget');
 const entries=new Map();let bytes=0,hits=0,misses=0;
 const token=value=>{
  const prior=entries.get(value);if(prior!==undefined){hits++;return prior;}
  if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid JSON String');
  misses++;const text=JSON.stringify(value),size=2*(value.length+text.length),quoted=Object.freeze({text,utf8Bytes:jsonUtf8Length(text)});
  if(maxEntries&&size<=maxBytes){
   while(entries.size&&(entries.size>=maxEntries||bytes+size>maxBytes)){const key=entries.keys().next().value;bytes-=2*(key.length+entries.get(key).text.length);entries.delete(key);}
   entries.set(value,quoted);bytes+=size;
  }
  return quoted;
 };
 const quoter=Object.freeze({
  token,
  quote(value){return token(value).text;},
  clear(){entries.clear();bytes=0;},
  stats(){return {entries:entries.size,payload_bytes:bytes,hits,misses};},
 });jsonQuoters.add(quoter);return quoter;
}
function checkedJsonLimits(options){const l={...jsonLimits,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>jsonLimits[k])throw Error('JSON hard resource limit');return l;}
function jsonVariant(index,item){let payload=index===0?{}:{item0:item};if(index<5)payload={Ok:payload};for(let i=0;i<index;i++)payload={Err:payload};return {payload};}
export function parseJson(text,options={}){return parseJsonValue(text,options,null);}
function parseJsonValue(text,options,boundary){
 const p=new JsonWireReader(text,options);
 const value=(d,wireDepth=0)=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){boundary?.node(0,wireDepth);p.at+=4;return jsonVariant(0,null);}if(c==='t'&&text.startsWith('true',p.at)){boundary?.node(1,wireDepth);p.at+=4;return jsonVariant(1,true);}if(c==='f'&&text.startsWith('false',p.at)){boundary?.node(1,wireDepth);p.at+=5;return jsonVariant(1,false);}
  if(c==='"'){boundary?.node(3,wireDepth);const item=p.string();boundary?.text(item);return jsonVariant(3,item);}
  if(c==='['){boundary?.node(4,wireDepth);p.at++;const xs=[];if(!p.eat(']'))while(true){xs.push(value(d+1,wireDepth+8));if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}return jsonVariant(4,xs);}
  if(c==='{'){boundary?.node(5,wireDepth);p.at++;const xs=[],seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary?.member(key,wireDepth);if(!p.eat(':'))throw Error('JSON object colon');xs.push({key,value:value(d+1,wireDepth+9)});if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}return jsonVariant(5,xs);}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();boundary?.node(2,wireDepth);boundary?.text(token);return jsonVariant(2,token);}
  throw Error('invalid JSON value');
 };
 const out=value(0);p.finish();return out;
}
export function stringifyJson(value,options={}){return stringifyJsonValue(value,options,null);}
function stringifyJsonValue(value,options,boundary){
 const l=checkedJsonLimits(options);let remaining=l.nodes,bytes=0,output='';
 const emit=s=>{bytes+=jsonUtf8Length(s);if(bytes>l.bytes)throw Error('JSON byte limit');output+=s;};
 const write=(v,d,wireDepth=0)=>{
  if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');if(!v||Object.keys(v).length!==1||!Object.hasOwn(v,'payload'))throw Error('invalid JSON record');let p=v.payload,index=0;
  while(index<5&&p&&Object.hasOwn(p,'Err')){if(Object.keys(p).length!==1||boundary&&Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Err;index++;}
  if(index<5){if(!p||Object.keys(p).length!==1||!Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Ok;}
  if(!p||Object.keys(p).length!==(index===0?0:1)||index>0&&!Object.hasOwn(p,'item0'))throw Error('invalid JSON payload');const item=p.item0;boundary?.node(index,wireDepth);
  switch(index){
   case 0:emit('null');break;
   case 1:if(typeof item!=='boolean')throw Error('invalid JSON Boolean');emit(item?'true':'false');break;
   case 2:if(!jsonNumberToken(item))throw Error('invalid JSON number');boundary?.text(item);emit(item);break;
   case 3:if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary?.text(item);emit(JSON.stringify(item));break;
   case 4:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Array');const count=item.length;let visited=0;emit('[');item.forEach((x,i)=>{visited++;if(i)emit(',');write(x,d+1,wireDepth+8);});if(visited!==count)throw Error('invalid JSON Array');emit(']');break;}
   case 5:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Object');const count=item.length,seen=new Set();let visited=0;emit('{');item.forEach((m,i)=>{visited++;if(!m||Object.keys(m).length!==2||typeof m.key!=='string'||!m.key.isWellFormed()||!Object.hasOwn(m,'value')||boundary&&!Object.hasOwn(m,'key'))throw Error('invalid JSON member');if(seen.has(m.key))throw Error('duplicate JSON object key');seen.add(m.key);boundary?.member(m.key,wireDepth);if(i)emit(',');emit(JSON.stringify(m.key));emit(':');write(m.value,d+1,wireDepth+9);});if(visited!==count)throw Error('invalid JSON Object');emit('}');break;}
  }
 };write(value,0);return output;
}
// The adapter's schema is the fixed recursive JSON library shape checked by
// JsonCodec. Charge its ordinary record/sum/list wire nodes while parsing or
// rendering, rather than interpreting and walking the completed tree again.
function jsonBoundaryBudget(options){
 const l=checkedJsonLimits(options);let remaining=l.nodes,total=40;
 const charge=(nodes,bytes,depth)=>{remaining-=nodes;total+=bytes;if(remaining<0||depth>l.depth)throw Error('wire node or depth limit');if(total>l.bytes)throw Error('wire byte limit');};
 return {
  node(index,depth){charge(index===0?3:index<4?index+4:8,index===0?13:index===1?23:index===2?27:index===3?32:41,depth+(index===0?2:index<4?index+3:7));},
  text(text){charge(0,jsonUtf8Length(text),0);},
  member(key,depth){charge(2,8+jsonUtf8Length(key),depth+9);},
 };
}
function jsonSameSchema(a,b){
 if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;
 const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>Object.hasOwn(b,k)&&jsonSameSchema(a[k],b[k]));
}
// Host-object conversion is opt-in and JavaScript-only. Inspect data properties
// rather than invoking getters/toJSON; reflection is not a sandbox for proxies.
function jsonJSKeys(value){
 if(!value||typeof value!=='object')throw Error('expected a plain JavaScript object');
 const prototype=Object.getPrototypeOf(value);
 if(prototype!==Object.prototype&&prototype!==null)throw Error('expected a plain JavaScript object');
 const keys=Reflect.ownKeys(value);
 if(keys.some(k=>typeof k!=='string'))throw Error('JavaScript symbol keys are unsupported');
 return keys;
}
function jsonJSData(value,key){
 const property=Object.getOwnPropertyDescriptor(value,key);
 if(!property||!property.enumerable||!Object.hasOwn(property,'value'))throw Error('expected an enumerable own data property');
 return property.value;
}
function jsonJSRecord(value,names){
 const keys=jsonJSKeys(value);
 if(keys.length!==names.length||keys.some(k=>!names.includes(k)))throw Error('invalid JSON record or variant');
}
function jsonJSArray(value,remaining){
 if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype)throw Error('expected a plain JavaScript array');
 const length=value.length;
 if(length>remaining)throw Error('JSON node limit');
 const keys=Reflect.ownKeys(value);
 if(keys.length!==length+1||keys.some(k=>typeof k!=='string'||k!=='length'&&(!/^(0|[1-9][0-9]*)$/.test(k)||Number(k)>=length)))throw Error('sparse or decorated JavaScript arrays are unsupported');
 return length;
}
function jsonFromJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),active=new WeakSet();let remaining=limits.nodes;
 const text=value=>{if(!value.isWellFormed())throw Error('invalid JSON Unicode');boundary.text(value);return value;};
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  if(value===null){boundary.node(0,wireDepth);return jsonVariant(0);}
  switch(typeof value){
   case 'boolean':boundary.node(1,wireDepth);return jsonVariant(1,value);
   case 'string':boundary.node(3,wireDepth);return jsonVariant(3,text(value));
   case 'number':
    if(!Number.isFinite(value))throw Error('non-finite JavaScript numbers are unsupported');
    boundary.node(2,wireDepth);return jsonVariant(2,text(Object.is(value,-0)?'-0':String(value)));
   case 'bigint':boundary.node(2,wireDepth);return jsonVariant(2,text(String(value)));
   case 'object':break;
   default:throw Error('unsupported JavaScript value');
  }
  if(active.has(value))throw Error('cyclic JavaScript value');
  active.add(value);
  try{
   if(Array.isArray(value)){
    boundary.node(4,wireDepth);const count=jsonJSArray(value,remaining),items=[];
    for(let i=0;i<count;i++)items.push(visit(jsonJSData(value,String(i)),depth+1,wireDepth+8));
    return jsonVariant(4,items);
   }
   boundary.node(5,wireDepth);const keys=jsonJSKeys(value),members=[];
   if(keys.length>remaining)throw Error('JSON node limit');
   for(const key of keys){
    if(!key.isWellFormed())throw Error('invalid JSON Unicode');
    boundary.member(key,wireDepth);
    members.push({key,value:visit(jsonJSData(value,key),depth+1,wireDepth+9)});
   }
   return jsonVariant(5,members);
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
function jsonDecimalKey(token){
 const [,sign,whole,fraction='',exponent='0']=/^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(token);
 const digits=(whole+fraction).replace(/^0+/,'');
 if(!digits)return '0';
 const trimmed=digits.replace(/0+$/,'');
 return sign+trimmed+'e'+(Number(exponent)-fraction.length+digits.length-trimmed.length);
}
function jsonToJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),mode=options?.numbers??'number',active=new WeakSet();let remaining=limits.nodes;
 if(!['number','bigint','string'].includes(mode))throw Error('unknown JavaScript number policy');
 const number=token=>{
  if(!jsonNumberToken(token))throw Error('invalid JSON number');
  boundary.text(token);
  if(mode==='string')return token;
  if(mode==='bigint')return BigInt(jsonInteger(token,4096));
  const result=Number(token);
  if(!Number.isFinite(result)||jsonDecimalKey(token)!==jsonDecimalKey(String(result)))throw Error('JSON number loses precision as JavaScript Number; choose numbers: bigint or string');
  return result;
 };
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  jsonJSRecord(value,['payload']);
  if(active.has(value))throw Error('cyclic JSON value');
  active.add(value);
  try{
   let payload=jsonJSData(value,'payload'),index=0;
   while(index<5&&Object.hasOwn(payload,'Err')){jsonJSRecord(payload,['Err']);payload=jsonJSData(payload,'Err');index++;}
   if(index<5){jsonJSRecord(payload,['Ok']);payload=jsonJSData(payload,'Ok');}
   jsonJSRecord(payload,index===0?[]:['item0']);boundary.node(index,wireDepth);
   const item=index===0?null:jsonJSData(payload,'item0');
   if(index===0)return null;
   if(index===1){if(typeof item!=='boolean')throw Error('invalid JSON Boolean');return item;}
   if(index===2)return number(item);
   if(index===3){if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary.text(item);return item;}
   const count=jsonJSArray(item,remaining);
   if(index===4){const out=[];for(let i=0;i<count;i++)out.push(visit(jsonJSData(item,String(i)),depth+1,wireDepth+8));return out;}
   const out={},seen=new Set();
   for(let i=0;i<count;i++){
    const member=jsonJSData(item,String(i));jsonJSRecord(member,['key','value']);const key=jsonJSData(member,'key');
    if(typeof key!=='string'||!key.isWellFormed())throw Error('invalid JSON member key');
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary.member(key,wireDepth);
    Object.defineProperty(out,key,{value:visit(jsonJSData(member,'value'),depth+1,wireDepth+9),enumerable:true,writable:true,configurable:true});
   }
   return out;
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
const jsonConstructionPaths=Object.freeze(Array.from({length:6},(_,index)=>Object.freeze([0,...Array(index).fill(1),...(index<5?[0]:[]),0])));
function parseJsonConstructed(text,options,builder){
 const p=new JsonWireReader(text,options);
 const paths=jsonConstructionPaths;
 const fused=typeof builder.openPath==='function';
 const begin=index=>{if(fused){builder.openPath(paths[index]);return;}for(const choice of paths[index])builder.open(choice);};
 const end=index=>{for(let i=0;i<(fused?1:index<5?index+3:7);i++)builder.close();};
 const leaf=(index,item)=>{if(typeof builder.scalarPath==='function'){builder.scalarPath(paths[index],item);return;}begin(index);builder.scalar(item);end(index);};
 const value=d=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){p.at+=4;if(typeof builder.emptyPath==='function')builder.emptyPath(paths[0]);else{begin(0);end(0);}return;}
  if(c==='t'&&text.startsWith('true',p.at)){p.at+=4;leaf(1,true);return;}
  if(c==='f'&&text.startsWith('false',p.at)){p.at+=5;leaf(1,false);return;}
  if(c==='"'){leaf(3,p.string());return;}
  if(c==='['){begin(4);builder.open(0);p.at++;if(!p.eat(']'))while(true){value(d+1);if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}builder.close();end(4);return;}
  if(c==='{'){begin(5);builder.open(0);p.at++;const seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');builder.open(0);builder.scalar(key);value(d+1);builder.close();if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}builder.close();end(5);return;}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();leaf(2,token);return;}
  throw Error('invalid JSON value');
 };
 value(0);p.finish();return builder.finish();
}
const jsonCompiledRenderers=new WeakMap();
function compiledJsonRenderer(json,codec,unwrap){
 if(typeof codec?.reducer!=='function')throw Error('compiled JSON reduction unavailable');
 const source=codec.resolve(codec.descriptor.root),root=json.values.descriptor.root;
 const selected=unwrap&&source.kind==='result'?codec.resolve(source.ok):source;
 if(!jsonSameSchema(root,selected)||unwrap&&source.kind!=='result')throw Error('compiled JSON schema mismatch');
 let variants=root.fields[0].type;const roles=new Map([[root.name,'root']]);
 let member;
 for(let index=0;index<6;index++){
  const branch=index<5?variants.ok:variants;roles.set(branch.name,index);
  if(index===5){member=branch.fields[0].type.element.name;roles.set(member,'member');}
  if(index<5)variants=variants.error;
 }
 const nodeRoles=new Map();
 return codec.reducer((node,index)=>{
  const role=roles.get(node.name);nodeRoles.set(index,role);
  if(node.kind==='record'){
   if(role==='root')return value=>value;
   if(role==='member')return (key,value,context)=>{
    const text=(context.quoter?context.quote(key,true):context.add(JSON.stringify(key)+':'))+value,seen=context.members;
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);return text;
   };
   if(role===0)return context=>context.add('null');
   if(role===1)return (value,context)=>context.add(value?'true':'false');
   if(role===2)return (token,context)=>{if(!jsonNumberToken(token))throw Error('invalid JSON number');return context.add(token);};
   if(role===3)return (value,context)=>context.quoter?context.quote(value,false):context.add(JSON.stringify(value));
   if(role===4)return (value,context)=>{context.add('[]');return '['+value+']';};
   if(role===5)return (value,context)=>{context.add('{}');return '{'+value+'}';};
   return ()=>null;
  }
  if(node.kind==='list'||node.kind==='vector'){
   const members=nodeRoles.get(node.children[0])==='member';
   return {
    start:(_length,context)=>{
     const out={text:'',parent:members?context.members:null};
     if(members)context.members=new Set();return out;
    },
    step:(out,value,index,context)=>{out.text+=(index?context.add(','):'')+value;return out;},
    finish:(out,context)=>{if(members)context.members=out.parent;return out.text;},
   };
  }
  if(node.kind==='result'){
   // A Result<Json,E> boundary is explicitly requested by the caller. Ordinary
   // JSON's own sums only propagate an already rendered branch.
   if(unwrap&&nodeRoles.get(node.children[0])==='root')return (tag,value)=>{if(tag)throw Error('JSON result is Err');return value;};
   return (_tag,value)=>value;
  }
  if(node.kind==='string')return value=>{if(!value.isWellFormed())throw Error('invalid JSON String');return value;};
  return value=>value;
 });
}
export class JsonCodec{
 constructor(valueCodec){
  const root=valueCodec.descriptor.root,fields=root.fields;if(root.kind!=='record'||!Array.isArray(fields)||fields.length!==1||fields[0].name!=='payload')throw Error('JSON schema payload');let sum=fields[0].type;
  for(let i=0;i<6;i++){
   if(i<5&&sum.kind!=='result')throw Error('JSON schema sum');const branch=i<5?sum.ok:sum,fs=branch.fields;
   if(branch.kind!=='record'||!Array.isArray(fs)||fs.length!==(i?1:0)||i&&fs[0].name!=='item0')throw Error('JSON schema branch');
   if(i){const t=fs[0].type;if(i===1&&t.kind!=='bool'||(i===2||i===3)&&t.kind!=='string'||i===4&&(t.kind!=='list'||t.element.kind!=='ref'||t.element.name!==root.name))throw Error('JSON schema variant');if(i===5){const mf=t.element?.fields;if(t.kind!=='list'||t.element?.kind!=='record'||!Array.isArray(mf)||mf.length!==2||mf[0].name!=='key'||mf[0].type.kind!=='string'||mf[1].name!=='value'||mf[1].type.kind!=='ref'||mf[1].type.name!==root.name)throw Error('JSON schema member');}}
   if(i===2)this.numberBranch=branch.name;if(i===5)this.objectBranch=branch.name;
   if(i<5)sum=sum.error;
  }if(!jsonSameSchema(root,valueCodec.resolve({kind:'ref',name:root.name})))throw Error('JSON recursive schema mismatch');this.values=valueCodec;
 }
 parse(text,options={}){return parseJsonValue(text,options,jsonBoundaryBudget(options));}
 parseCompiled(codec,text,options={}){
  if(codec?.identity!==this.values.descriptor.identity||typeof codec.builder!=='function')throw Error('compiled JSON schema mismatch');
  const builder=codec.builder(options);try{return parseJsonConstructed(text,options,builder);}catch(error){builder.abort();throw error;}
 }
 stringify(value,options={}){return stringifyJsonValue(value,options,jsonBoundaryBudget(options));}
 stringifyCompiled(codec,handle,options={}){
  const limits=checkedJsonLimits(options),unwrap=options.unwrapResult===true;
  const quoter=options.quoter;if(quoter!==undefined&&!jsonQuoters.has(quoter))throw Error('JSON quote cache owner mismatch');
  let codecs=jsonCompiledRenderers.get(this);if(!codecs)jsonCompiledRenderers.set(this,codecs=new WeakMap());
  let renderers=codecs.get(codec);if(!renderers)codecs.set(codec,renderers=new Map());
  let render=renderers.get(unwrap);if(!render)renderers.set(unwrap,render=compiledJsonRenderer(this,codec,unwrap));
  let bytes=0;const context={
   quoter,
   add(text){bytes+=jsonUtf8Length(text);if(bytes>limits.bytes)throw Error('JSON byte limit');return text;},
   quote(value,colon){
    if(!quoter)return this.add(JSON.stringify(value)+(colon?':':''));
    const token=quoter.token(value);bytes+=token.utf8Bytes+(colon?1:0);if(bytes>limits.bytes)throw Error('JSON byte limit');return token.text+(colon?':':'');
   },
  };
  const text=render(handle,context,limits);
  return text;
 }
 fromJS(value,options={}){return jsonFromJS(value,options);}
 toJS(value,options={}){return jsonToJS(value,options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,false);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,false,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,true);}
 validateBinary(bytes,options={}){
  const decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});let view;
  this.values.visitSpans(bytes,(type,data,start,end)=>{
   view??=new DataView(data.buffer,data.byteOffset,data.byteLength);
   if(type.name===this.numberBranch){const length=view.getUint32(start,true);if(!jsonNumberSpan(data,start+4,start+4+length))throw Error('invalid JSON number token');}
   if(type.name===this.objectBranch){const listEnd=start+4+view.getUint32(start,true),count=view.getUint32(start+4,true),seen=new Set();let at=start+8;for(let i=0;i<count;i++){const memberEnd=at+4+view.getUint32(at,true),keyStart=at+8,keyEnd=keyStart+view.getUint32(at+4,true),key=decoder.decode(data.subarray(keyStart,keyEnd));if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);at=memberEnd;}if(at!==listEnd)throw Error('invalid JSON object frame');}
  },options,[this.numberBranch,this.objectBranch]);return true;

 }
}
function jsonUnpack(value){let p=value.payload,i=0;while(i<5&&Object.hasOwn(p,'Err')){p=p.Err;i++;}return [i,(i<5?p.Ok:p).item0];}
function jsonInteger(token,limit){
 if(!jsonNumberToken(token))throw Error('invalid JSON number');const negative=token[0]==='-',raw=negative?token.slice(1):token,[mantissa,exp='0']=raw.split(/[eE]/);let digits=mantissa.replace('.','');if(/^0+$/.test(digits))return '0';const exponent=Number(exp),fraction=mantissa.includes('.')?mantissa.length-mantissa.indexOf('.')-1:0,shift=exponent-fraction;
 if(!Number.isSafeInteger(exponent)||!Number.isSafeInteger(shift))throw Error('JSON integer exponent limit');
 if(shift<0){const cut=-shift;if(cut>=digits.length||!/^[0]+$/.test(digits.slice(-cut)))throw Error('JSON number is not an integer');digits=digits.slice(0,-cut);}else{if(digits.length+shift>limit)throw Error('JSON integer magnitude limit');digits+='0'.repeat(shift);}
 digits=digits.replace(/^0+/,'');if(digits.length>limit)throw Error('JSON integer magnitude limit');return (negative?'-':'')+digits;
}
function jsonBinary64Value(v){
 if(typeof v==='number')return v;
 const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid F64Bits');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');
 const b=new DataView(new ArrayBuffer(8));b.setBigUint64(0,bits,true);return b.getFloat64(0,true);
}
export class TypedJsonCodec{
 constructor(valueCodec){this.values=valueCodec;}
 decode(document,options={}){
  // Validate JSON-specific invariants before interpreting any tagged/record
  // shape, including duplicated names and malformed numeric tokens.
  stringifyJson(document,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const read=(type,value,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type),[kind,item]=jsonUnpack(value);const fail=()=>{throw Error('JSON does not match '+t.kind);};
   switch(t.kind){
    case 'unit':if(kind!==0)fail();return null;
    case 'bool':if(kind!==1)fail();return item;
    case 'u32':case 'u64':case 'i32':case 'int':{if(kind!==2)fail();const text=jsonInteger(item,t.kind==='int'?4096:t.kind==='u64'?20:10);return t.kind==='int'?{Int:text}:t.kind==='u64'?BigInt(text):Number(text);}
    case 'f64':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(8));if(!Number.isFinite(n))throw Error('JSON f64 overflow');b.setFloat64(0,n,true);return {F64Bits:b.getBigUint64(0,true).toString()};}
    case 'f32':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(4));b.setFloat32(0,n,true);if(!Number.isFinite(b.getFloat32(0,true)))throw Error('JSON f32 overflow');return {F32Bits:b.getUint32(0,true)};}
    case 'string':case 'enum':case 'id':if(kind!==3)fail();return item;
    case 'list':case 'vector':if(kind!==4)fail();return item.map(x=>read(t.element,x,d+1));
    case 'record':{if(kind!==5||item.length!==t.fields.length)throw Error('unknown or missing JSON record field');const fields=new Map(item.map(m=>[m.key,m.value])),out={};for(const f of t.fields){if(!fields.has(f.name))throw Error('missing JSON record field');Object.defineProperty(out,f.name,{value:read(f.type,fields.get(f.name),d+1),writable:true,enumerable:true,configurable:true});}return out;}
    case 'option':case 'result':{if(kind!==5||item.length!==1)fail();const m=item[0];if(t.kind==='option'&&m.key==='None'&&jsonUnpack(m.value)[0]===0)return {None:null};const child=t.kind==='option'&&m.key==='Some'?t.element:t.kind==='result'&&m.key==='Ok'?t.ok:t.kind==='result'&&m.key==='Err'?t.error:null;if(!child)fail();return {[m.key]:read(child,m.value,d+1)};}
    default:fail();
   }
  };
  const out=read(this.values.descriptor.root,document,0);this.values.validateValue(out,options);return out;
 }
 encode(value,options={}){
  this.values.validateValue(value,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const write=(type,v,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type);
   switch(t.kind){
    case 'unit':return jsonVariant(0);
    case 'bool':return jsonVariant(1,v);
    case 'u32':case 'u64':case 'i32':return jsonVariant(2,String(v));
    case 'int':return jsonVariant(2,typeof v==='bigint'?String(v):v.Int);
    case 'f64':{const n=jsonBinary64Value(v);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'f32':{let n;if(typeof v==='number')n=Math.fround(v);else{const b=new DataView(new ArrayBuffer(4));b.setUint32(0,v.F32Bits,true);n=b.getFloat32(0,true);}if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'string':case 'id':case 'enum':return jsonVariant(3,v);
    case 'list':case 'vector':return jsonVariant(4,Array.from(v,x=>write(t.element,x,d+1)));
    case 'record':return jsonVariant(5,t.fields.map(f=>({key:f.name,value:write(f.type,v[f.name],d+1)})));
    case 'option':return jsonVariant(5,[Object.hasOwn(v,'Some')?{key:'Some',value:write(t.element,v.Some,d+1)}:{key:'None',value:jsonVariant(0)}]);
    case 'result':return jsonVariant(5,[Object.hasOwn(v,'Ok')?{key:'Ok',value:write(t.ok,v.Ok,d+1)}:{key:'Err',value:write(t.error,v.Err,d+1)}]);
    default:throw Error('unsupported typed JSON descriptor');
   }
  };return write(this.values.descriptor.root,value,0);
 }
 parse(text,options={}){return this.decode(parseJson(text,options),options);}
 stringify(value,options={}){return stringifyJson(this.encode(value,options),options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,true);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,true,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,false);}
}

// Token reader shared by schema-directed and arbitrary-JSON wire emission.
class JsonWireReader{
 constructor(text,options){this.l=checkedJsonLimits(options);if(typeof text!=='string'||!text.isWellFormed()||text.length>this.l.bytes||jsonUtf8Length(text)>this.l.bytes)throw Error('JSON byte or Unicode limit');this.text=text;this.at=0;this.remaining=this.l.nodes;}
 ws(){while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(c!==32&&c!==9&&c!==10&&c!==13)break;this.at++;}}
 peek(){this.ws();return this.text[this.at];}
 eat(c){this.ws();if(this.text[this.at]===c){this.at++;return true;}return false;}
 node(d){if(d>this.l.depth||--this.remaining<0)throw Error('JSON node or depth limit');}
 string(){
  this.ws();const start=this.at;if(this.text[start]!=='"')throw Error('expected JSON string');
  const end=this.text.indexOf('"',start+1);if(end<0)throw Error('unterminated JSON string');
  const raw=this.text.slice(start+1,end);
  if(!raw.includes('\\')&&!/[\x00-\x1f]/.test(raw)){this.at=end+1;return raw;}
  this.at=start+1;while(this.at<this.text.length){if(this.text[this.at]==='"'){this.at++;const v=JSON.parse(this.text.slice(start,this.at));if(!v.isWellFormed())throw Error('invalid JSON Unicode');return v;}if(this.text[this.at]==='\\')this.at+=2;else this.at++;}throw Error('unterminated JSON string');
 }
 number(){const start=this.at;while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(!(c>=48&&c<=57||c===45||c===43||c===46||c===101||c===69))break;this.at++;}const token=this.text.slice(start,this.at);if(!jsonNumberToken(token))throw Error('invalid JSON number');return token;}
 leaf(d){this.node(d);const c=this.peek();if(c==='n'&&this.text.startsWith('null',this.at)){this.at+=4;return null;}if(c==='t'&&this.text.startsWith('true',this.at)){this.at+=4;return true;}if(c==='f'&&this.text.startsWith('false',this.at)){this.at+=5;return false;}if(c==='"')return this.string();if(c==='-'||c>='0'&&c<='9')return this.number();throw Error('invalid JSON scalar');}
 finish(){this.ws();if(this.at!==this.text.length)throw Error('trailing JSON text');}
}
function streamJsonBinary(values,text,options,typed,compact=false){
 const p=new JsonWireReader(text,options),utf8=jsonWireEncoder;
 const list=(w,open,close,item)=>{if(!p.eat(open))throw Error('JSON container shape');const at=w.beginCount();let count=0;if(!p.eat(close))while(true){item(w);count++;if(p.eat(close))break;if(!p.eat(','))throw Error('JSON container separator');}w.endCount(at,count);};
 const variant=(w,index,level,emit)=>{if(level<index)w.frame(w=>{w.byte(1);variant(w,index,level+1,emit);});else if(index<5)w.frame(w=>{w.byte(0);w.frame(emit);});else w.frame(emit);};
 const json=(w,d)=>{
  const ch=p.peek(),index=ch==='n'?0:ch==='t'||ch==='f'?1:ch==='-'||ch>='0'&&ch<='9'?2:ch==='"'?3:ch==='['?4:ch==='{'?5:-1;if(index<0)throw Error('invalid JSON value');
  const leaf=index<4?p.leaf(d):null;if(index>=4)p.node(d);
  w.frame(w=>variant(w,index,0,w=>{
   if(index===0)return;if(index===1){w.frame(w=>w.byte(+leaf));return;}
   if(index===2||index===3){w.frame(w=>w.text(leaf));return;}
   w.frame(w=>{if(index===4)list(w,'[',']',w=>json(w,d+1));else{const seen=new Set();list(w,'{','}',w=>{const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');w.frame(w=>{w.frame(w=>w.text(key));json(w,d+1);});});}});
  }));
 };
 const read=(type,w,d)=>{
  const t=values.resolve(type);w.frame(w=>{
   if(t.kind==='list'||t.kind==='vector'){p.node(d);list(w,'[',']',w=>read(t.element,w,d+1));return;}
   if(t.kind==='record'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON record');const start=w.position,spans=new Array(t.fields.length).fill(null);
    if(!p.eat('}'))while(true){const key=p.string(),i=t.fields.findIndex(f=>f.name===key);if(i<0)throw Error('unknown JSON record field');if(spans[i])throw Error('duplicate JSON record field');if(!p.eat(':'))throw Error('JSON record colon');const at=w.position;read(t.fields[i].type,w,d+1);spans[i]=[at,w.position];if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON record separator');}
    if(spans.some(s=>s===null))throw Error('missing JSON record field');w.reorder(start,spans);return;
   }
   if(t.kind==='option'||t.kind==='result'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON tagged value');const key=p.string();if(!p.eat(':'))throw Error('JSON tag colon');
    if(t.kind==='option'&&key==='None'){if(p.leaf(d+1)!==null)throw Error('JSON None payload');w.byte(0);}
    else{const child=t.kind==='option'&&key==='Some'?t.element:t.kind==='result'&&key==='Ok'?t.ok:t.kind==='result'&&key==='Err'?t.error:null;if(!child)throw Error('invalid JSON tag');w.byte(key==='Ok'?0:1);read(child,w,d+1);}
    if(!p.eat('}'))throw Error('expected exactly one JSON tag');return;
   }
   const ch=p.peek(),v=p.leaf(d),bad=()=>{throw Error('JSON does not match '+t.kind);};
   if(t.kind==='unit'){if(v!==null)bad();return;}
   if(t.kind==='bool'){if(typeof v!=='boolean')bad();w.byte(+v);return;}
   if(['string','id','enum'].includes(t.kind)){if(ch!=='"')bad();w.text(v);return;}
   if(ch!=='-'&&!(ch>='0'&&ch<='9'))bad();
   if(t.kind==='int'){w.text(jsonInteger(v,4096));return;}
   if(t.kind==='f64'){const n=Number(v);if(!Number.isFinite(n))throw Error('JSON f64 overflow');const b=new DataView(new ArrayBuffer(8));b.setFloat64(0,n,true);w.wide(b.getBigUint64(0,true));}
   else if(t.kind==='f32'){jsonFloatScratch.setFloat32(0,Number(v),true);if(!Number.isFinite(jsonFloatScratch.getFloat32(0,true)))throw Error('JSON f32 overflow');w.word(jsonFloatScratch.getUint32(0,true));}
   else{const n=BigInt(jsonInteger(v,t.kind==='u64'?20:10));if(t.kind==='u64'){if(n<0n||n>18446744073709551615n)bad();w.wide(n);}else if(t.kind==='u32'){if(n<0n||n>4294967295n)bad();w.word(Number(n));}else if(t.kind==='i32'){if(n< -2147483648n||n>2147483647n)bad();w.word(Number(n)>>>0);}else bad();}
  });
 };
 return (compact?values.compact():values).encodeWith(w=>{if(typed)read(values.descriptor.root,w,0);else json(w,0);p.finish();},options);
}

// Render validated bytes in a single traversal; only the final text is owned.
function streamWireJsonText(values,bytes,options,library){
 values.validate(bytes,options);const l=checkedJsonLimits(options),parts=[];let size=0,remaining=l.nodes;const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 const emit=s=>{size+=jsonUtf8Length(s);if(size>l.bytes)throw Error('JSON byte limit');parts.push(s);};
 const string=s=>emit(JSON.stringify(s));const node=d=>{if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');};
 const frame=(type,at)=>{const t=values.resolve(type),start=at+4,end=start+dv.getUint32(at,true);return{t,start,end};};
 const json=(type,at,d)=>{
  node(d);let root=frame(type,at),sum=frame(root.t.fields[0].type,root.start),index=0;
  while(index<5){const err=bytes[sum.start];sum=frame(err?sum.t.error:sum.t.ok,sum.start+1);if(!err)break;index++;}
  if(index===0){emit('null');return root.end;}
  const item=frame(sum.t.fields[0].type,sum.start);
  if(index===1)emit(bytes[item.start]?'true':'false');
  else if(index===2){const token=decoder.decode(bytes.subarray(item.start,item.end));if(!jsonNumberToken(token))throw Error('invalid JSON number token');emit(token);}
  else if(index===3)string(decoder.decode(bytes.subarray(item.start,item.end)));
  else{const count=dv.getUint32(item.start,true);let p=item.start+4;emit(index===4?'[':'{');const seen=new Set();for(let i=0;i<count;i++){if(i)emit(',');if(index===4)p=json(item.t.element,p,d+1);else{const member=frame(item.t.element,p),key=frame(member.t.fields[0].type,member.start),name=decoder.decode(bytes.subarray(key.start,key.end));if(seen.has(name))throw Error('duplicate JSON object key');seen.add(name);string(name);emit(':');json(member.t.fields[1].type,key.end,d+1);p=member.end;}}emit(index===4?']':'}');}
  return root.end;
 };
 const typed=(type,at,d)=>{
  node(d);const f=frame(type,at),t=f.t;let p=f.start;
  switch(t.kind){
   case 'unit':emit('null');break;
   case 'bool':emit(bytes[p]?'true':'false');break;
   case 'u32':emit(String(dv.getUint32(p,true)));break;
   case 'u64':emit(String(dv.getBigUint64(p,true)));break;
   case 'i32':emit(String(dv.getInt32(p,true)));break;
   case 'f64':{const n=dv.getFloat64(p,true);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'f32':{const n=dv.getFloat32(p,true);if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'int':emit(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'string':case 'id':case 'enum':string(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'list':case 'vector':{const n=dv.getUint32(p,true);p+=4;emit('[');for(let i=0;i<n;i++){if(i)emit(',');p=typed(t.element,p,d+1);}emit(']');break;}
   case 'record':emit('{');for(let i=0;i<t.fields.length;i++){if(i)emit(',');const field=t.fields[i];string(field.name);emit(':');p=typed(field.type,p,d+1);}emit('}');break;
   case 'option':case 'result':{const tag=bytes[p++],key=t.kind==='option'?(tag?'Some':'None'):tag?'Err':'Ok';emit('{');string(key);emit(':');if(t.kind==='option'&&!tag){node(d+1);emit('null');}else typed(t.kind==='option'?t.element:tag?t.error:t.ok,p,d+1);emit('}');break;}
   default:throw Error('unsupported typed JSON descriptor');
  }return f.end;
 };
 if(library)json(values.descriptor.root,40,0);else typed(values.descriptor.root,40,0);return parts.join('');
}

/** Owned, optional read view of arbitrary JSON. Auxiliary indexes contain member
 * offsets only. Logical order, exact number tokens and missing/null remain intact.
 * This does not transparently replace any compiled Ink action or its state.
 */
export function createJsonLookup(text,{stepEntries=16,minReads=4,maxEntries=4096,maxObjects=64,maxIndexBytes=262144,...limits}={}){
 for(const [v,max]of [[stepEntries,4096],[minReads,1000000],[maxEntries,1000000],[maxObjects,256],[maxIndexBytes,16777216]])if(!Number.isSafeInteger(v)||v<0||v>max)throw Error('JSON index budget');
 let root=parseJson(text,limits),indexes=new Map(),entries=0,indexBytes=0;
 const stats={reads:0,writes:0,scanned_members:0,index_hits:0,built_entries:0,invalidations:0};
 function parts(path){
  if(!Array.isArray(path))throw Error('JSON lookup path');const n=path.length;if(n>128)throw Error('JSON lookup path');
  const owned=[];for(let i=0;i<n;i++){const d=Object.getOwnPropertyDescriptor(path,String(i));if(!d||!Object.hasOwn(d,'value'))throw Error('JSON lookup path');const p=d.value;if(!(typeof p==='string'&&p.isWellFormed()&&p.length<=4096)&&!(Number.isSafeInteger(p)&&p>=0))throw Error('JSON lookup path');owned.push(p);}return owned;
 }
 function variant(value){let p=value.payload,index=0;while(index<5&&Object.hasOwn(p,'Err')){p=p.Err;index++;}return {index,item:(index<5?p.Ok:p).item0};}
 function resolve(document,path,indexed){
  let value=document,budget=stepEntries;
  for(let depth=0;depth<path.length;depth++){
   const part=path[depth],v=variant(value);
   if(typeof part==='number'){
    if(v.index!==4)throw Error('expected JSON array');if(part>=v.item.length)return {found:false};value=v.item[part];continue;
   }
   if(v.index!==5)throw Error('expected JSON object');
   const prefix=path.slice(0,depth),key=JSON.stringify(prefix),overhead=128+prefix.reduce((n,p)=>n+(typeof p==='string'?16+p.length*2:8),0);let idx=indexed?indexes.get(key):null;
   if(indexed&&!idx&&indexes.size<maxObjects&&indexBytes+overhead<=maxIndexBytes){idx={path:prefix,reads:0,cursor:0,keys:new Map(),bytes:overhead};indexes.set(key,idx);indexBytes+=overhead;}
   if(idx){
    idx.reads++;
    if(idx.reads>=minReads)while(budget>0&&idx.cursor<v.item.length&&entries<maxEntries){
     const member=v.item[idx.cursor],bytes=64+member.key.length*2;
     if(indexBytes+bytes>maxIndexBytes)break;
     idx.keys.set(member.key,idx.cursor++);idx.bytes+=bytes;indexBytes+=bytes;entries++;stats.built_entries++;budget--;
    }
    if(idx.keys.has(part)){stats.index_hits++;value=v.item[idx.keys.get(part)].value;continue;}
   }
   let found=false;
   for(let i=idx?.cursor??0;i<v.item.length;i++){if(indexed)stats.scanned_members++;if(v.item[i].key===part){value=v.item[i].value;found=true;break;}}
   if(!found)return {found:false};
  }
  return {found:true,value};
 }
 return {
  lookup(path){stats.reads++;const r=resolve(root,parts(path),true);return r.found?{found:true,value:structuredClone(r.value)}:r;},
  set(path,key,text){
   path=parts(path);if(typeof key!=='string'||!key.isWellFormed())throw Error('JSON object key');
   const replacement=parseJson(text,limits),next=structuredClone(root),r=resolve(next,path,false);
   if(!r.found)throw Error('JSON update path missing');const object=variant(r.value);if(object.index!==5)throw Error('expected JSON object');
   const members=[{key,value:replacement},...object.item.filter(m=>m.key!==key)];
   // Validate the complete resulting document before publishing a write.
   let payload=r.value.payload;for(let i=0;i<5;i++)payload=payload.Err;payload.item0=members;
   stringifyJson(next,limits);root=next;stats.writes++;
   for(const [id,idx]of indexes)if(idx.path.length>=path.length&&path.every((p,i)=>p===idx.path[i])){entries-=idx.keys.size;indexBytes-=idx.bytes;indexes.delete(id);stats.invalidations++;}
  },
  replace(text){const next=parseJson(text,limits);root=next;stats.writes++;stats.invalidations+=indexes.size;indexes.clear();entries=0;indexBytes=0;},
  stringify(){return stringifyJson(root,limits);},
  stats(){return {...stats,index_entries:entries,index_objects:indexes.size,index_bytes:indexBytes};}
 };
}
function __ownedValue5(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue1(value[i],budget,depth+1);return out;}
function __ownedValue6(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue0(value.Ok,budget,depth+1)}:{Err:__ownedValue4(value.Err,budget,depth+1)};}
function __ownedValue0(value,budget,depth){budget.enter(depth,4);return {["a"]:__ownedValue1(value["a"],budget,depth+1),["b"]:__ownedValue1(value["b"],budget,depth+1),["index"]:__ownedValue2(value["index"],budget,depth+1),["stop"]:__ownedValue3(value["stop"],budget,depth+1),["label"]:__ownedValue4(value["label"],budget,depth+1),["values"]:__ownedValue5(value["values"],budget,depth+1)};}
function __ownedValue3(value,budget,depth){budget.enter(depth,5);return value;}
function __ownedValue1(value,budget,depth){budget.enter(depth,12);return {F64Bits:__dfBits(value).toString()};}
function __ownedValue4(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __ownedValue2(value,budget,depth){budget.enter(depth,8);return value>>>0;}
const __ownedFunctions=Object.freeze(Object.fromEntries([["advance",__ownedValue0],["drive",__ownedValue0],["projected",__ownedValue5],["pick",__ownedValue5],["branch",__ownedValue0],["selected",__ownedValue0],["nested",__ownedValue5],["kept",__ownedValue0],["aliases",__ownedValue5],["owned",__ownedValue5],["fallible",__ownedValue6],["chain0",__ownedValue0],["chain1",__ownedValue0],["chain2",__ownedValue0],["chain3",__ownedValue0],["chain4",__ownedValue0],["chain5",__ownedValue0],["chain6",__ownedValue0],["chain7",__ownedValue0],["chain8",__ownedValue0],["bounded",__ownedValue0],["large",__ownedValue5],["fallback",__ownedValue5]]));
function __wireValue6(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue2(reader);reader.finish(end);return value;}
function __wireValue9(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue5(reader)}:{Ok:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue1(reader){const end=reader.frame();const value={["a"]:__wireValue2(reader),["b"]:__wireValue2(reader),["index"]:__wireValue3(reader),["stop"]:__wireValue4(reader),["label"]:__wireValue5(reader),["values"]:__wireValue6(reader)};reader.finish(end);return value;}
function __wireValue12(reader){const end=reader.frame();const value={["lane"]:__wireValue1(reader),["extra"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue11(reader){const end=reader.frame();const value={["n"]:__wireValue12(reader)};reader.finish(end);return value;}
function __wireValue8(reader){const end=reader.frame();const value={["r"]:__wireValue1(reader),["n"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue0(reader){const end=reader.frame();const value={["r"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue7(reader){const end=reader.frame();const value={["x"]:__wireValue2(reader),["y"]:__wireValue2(reader),["n"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue10(reader){const end=reader.frame();const value={["xs"]:__wireValue6(reader),["r"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue4(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __wireValue2(reader){const end=reader.frame();const value={F64Bits:reader.wide().toString()};reader.finish(end);return value;}
function __wireValue5(reader){const end=reader.frame();const value=reader.text(end,"string");reader.finish(end);return value;}
function __wireValue3(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
const __wireReaders=Object.freeze(Object.fromEntries([["advance",[__wireValue0,__wireValue1]],["aliases",[__wireValue7,__wireValue6]],["bounded",[__wireValue7,__wireValue1]],["branch",[__wireValue8,__wireValue1]],["chain0",[__wireValue0,__wireValue1]],["chain1",[__wireValue0,__wireValue1]],["chain2",[__wireValue0,__wireValue1]],["chain3",[__wireValue0,__wireValue1]],["chain4",[__wireValue0,__wireValue1]],["chain5",[__wireValue0,__wireValue1]],["chain6",[__wireValue0,__wireValue1]],["chain7",[__wireValue0,__wireValue1]],["chain8",[__wireValue0,__wireValue1]],["drive",[__wireValue7,__wireValue1]],["fallback",[__wireValue7,__wireValue6]],["fallible",[__wireValue7,__wireValue9]],["kept",[__wireValue10,__wireValue1]],["large",[__wireValue0,__wireValue6]],["nested",[__wireValue7,__wireValue6]],["owned",[__wireValue7,__wireValue6]],["pick",[__wireValue11,__wireValue6]],["projected",[__wireValue7,__wireValue6]],["selected",[__wireValue7,__wireValue1]]]));

const __ownedImplementations=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>{
 const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
 const body=__implementations[f.index];
 const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
 return [f.name,input.every(c=>c===__identity)?implementation:(...args)=>{const context=new WeakMap();return implementation(...args.map((v,i)=>input[i](v,context)));}];
})));

export const valueCodecs=(()=>{const codecs={};for(const [name,s] of Object.entries(metadata.wire.functions)){if(s.unsupported)continue;let value;Object.defineProperty(codecs,name,{enumerable:true,get:()=>value??=(Object.freeze(Object.hasOwn(__wireReaders,name)?{arguments:createCompiledValueCodec(s.arguments,__wireReaders[name][0]),result:createCompiledValueCodec(s.result,__wireReaders[name][1])}:{arguments:new ValueCodec(s.arguments),result:new ValueCodec(s.result)}))});}return Object.freeze(codecs);})();
function __callEncoded(name,bytes,limits,compact){
 const f=metadata.functions.find(f=>f.name===name&&!f.internal),codecs=valueCodecs[name];
 if(!f||!codecs)throw Error('unsupported binary function');
 const input=compact?codecs.arguments.compact():codecs.arguments,output=compact?codecs.result.compact():codecs.result;
 const entry=__compiledEntries.get(name);
 if(entry){
  const slot=compact?1:0;
  entry.argumentCodecs[slot]??=(entry.boundaryReaders[slot]?createFusedValueCodec:createCompiledValueCodec)(metadata.wire.functions[name].arguments,entry.arguments);
  const decoder=entry.argumentCodecs[slot];
  const values=(compact?decoder.compact():decoder).decode(bytes,limits),args=f.params.map(p=>values[p.name]);
  if(entry.precondition!==null&&__implementations[entry.precondition](...args)!==true)throw Error('contract precondition failed');
  return __compiledEncodeResult(entry,__implementations[entry.index](...args),limits,compact);
 }
 const values=input.decode(bytes,limits);
 const result=call(name,f.params.map(p=>values[p.name]));
 return output.encode(result,limits);
}
export function callBinary(name,bytes,limits={}){return __callEncoded(name,bytes,limits,false);}
export function callCompact(name,bytes,limits={}){return __callEncoded(name,bytes,limits,true);}
// Same stable, well-typed caller inputs as call; the result owns every container.
// The checked source return type justifies trusted copying, not arbitrary input.
export function callOwned(name,args,limits={}){
 if(!Object.hasOwn(__ownedFunctions,name)||!Object.hasOwn(functions,name))throw Error('unsupported owned function');
 const result=__ownedImplementations[name](...args);return __ownedFunctions[name](result,createValueCaptureBudget(limits),0);
}
function __privateCapture5(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture1(value[i],budget,depth+1);return out;}
function __privateCapture7(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture0(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture4(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture0(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"index")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"stop")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"label")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"values")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture1(value["a"],budget,depth+1),["b"]:__privateCapture1(value["b"],budget,depth+1),["index"]:__privateCapture2(value["index"],budget,depth+1),["stop"]:__privateCapture3(value["stop"],budget,depth+1),["label"]:__privateCapture4(value["label"],budget,depth+1),["values"]:__privateCapture5(value["values"],budget,depth+1)};}
function __privateCapture6(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"lane")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"extra")){throw Error('invalid value for wire schema');}return {["lane"]:__privateCapture0(value["lane"],budget,depth+1),["extra"]:__privateCapture1(value["extra"],budget,depth+1)};}
function __privateCapture3(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='boolean'){throw Error('invalid value for wire schema');}budget.add(1);return value;}
function __privateCapture1(value,budget,depth=0){budget.enter(depth,4);const result=__dfCapture(value);budget.add(8);return result;}
function __privateCapture4(value,budget,depth=0){budget.enter(depth,4);const text=value;if(typeof text!=='string'||!text.isWellFormed()||text.length>budget.limit){throw Error('invalid value for wire schema');}budget.text(text);return text;}
function __privateCapture2(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='number'||!Number.isInteger(value)||value<0||value>4294967295){throw Error('invalid value for wire schema');}budget.add(4);return value===0?0:value;}
function __privateWireValue5(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue1(reader);reader.finish(end);return value;}
function __privateWireValue12(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue4(reader)}:{Ok:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue0(reader){const end=reader.frame();const value={["a"]:__privateWireValue1(reader),["b"]:__privateWireValue1(reader),["index"]:__privateWireValue2(reader),["stop"]:__privateWireValue3(reader),["label"]:__privateWireValue4(reader),["values"]:__privateWireValue5(reader)};reader.finish(end);return value;}
function __privateWireValue8(reader){const end=reader.frame();const value={["lane"]:__privateWireValue0(reader),["extra"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue9(reader){const end=reader.frame();const value={["n"]:__privateWireValue8(reader)};reader.finish(end);return value;}
function __privateWireValue10(reader){const end=reader.frame();const value={["r"]:__privateWireValue0(reader),["n"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue6(reader){const end=reader.frame();const value={["r"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue7(reader){const end=reader.frame();const value={["x"]:__privateWireValue1(reader),["y"]:__privateWireValue1(reader),["n"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue11(reader){const end=reader.frame();const value={["xs"]:__privateWireValue5(reader),["r"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue3(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __privateWireValue1(reader){const end=reader.frame();const value=__dfFromBits(reader.wide());reader.finish(end);return value;}
function __privateWireValue4(reader){const end=reader.frame();const value=reader.text(end,"string");reader.finish(end);return value;}
function __privateWireValue2(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __compiledOwnedValue5(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue1(value[i],budget,depth+1);return out;}
function __compiledOwnedValue7(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue0(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue4(value.Err,budget,depth+1)};}
function __compiledOwnedValue0(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue1(value["a"],budget,depth+1),["b"]:__compiledOwnedValue1(value["b"],budget,depth+1),["index"]:__compiledOwnedValue2(value["index"],budget,depth+1),["stop"]:__compiledOwnedValue3(value["stop"],budget,depth+1),["label"]:__compiledOwnedValue4(value["label"],budget,depth+1),["values"]:__compiledOwnedValue5(value["values"],budget,depth+1)};}
function __compiledOwnedValue6(value,budget,depth){budget.enter(depth,4);return {["lane"]:__compiledOwnedValue0(value["lane"],budget,depth+1),["extra"]:__compiledOwnedValue1(value["extra"],budget,depth+1)};}
function __compiledOwnedValue3(value,budget,depth){budget.enter(depth,5);return value;}
function __compiledOwnedValue1(value,budget,depth){budget.enter(depth,12);return {F64Bits:__dfBits(value).toString()};}
function __compiledOwnedValue4(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __compiledOwnedValue2(value,budget,depth){budget.enter(depth,8);return value>>>0;}
function __privateWireWrite5(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite1(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite7(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite0(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite4(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite0(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["a"],compact);__privateWireWrite1(writer,value["b"],compact);__privateWireWrite2(writer,value["index"],compact);__privateWireWrite3(writer,value["stop"],compact);__privateWireWrite4(writer,value["label"],compact);__privateWireWrite5(writer,value["values"],compact);writer.closeFrame(frame);}
function __privateWireWrite6(writer,value,compact){const frame=writer.openFrame();__privateWireWrite0(writer,value["lane"],compact);__privateWireWrite1(writer,value["extra"],compact);writer.closeFrame(frame);}
function __privateWireWrite3(writer,value,compact){const frame=writer.openFrame();writer.byte(value?1:0);writer.closeFrame(frame);}
function __privateWireWrite1(writer,value,compact){const frame=writer.openFrame();writer.wide(__dfBits(value));writer.closeFrame(frame);}
function __privateWireWrite4(writer,value,compact){const frame=writer.openFrame();writer.text(value,compact);writer.closeFrame(frame);}
function __privateWireWrite2(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
// Handles have no mutable private payload surface. Membership and type identity
// are checked by this module's closure; copied/foreign objects cannot forge them.
const __compiledHandles=new WeakMap();
const __compiledBindings=new WeakMap();
function __compiledHandle(identity,value,guaranteed=false){
 const handle=Object.freeze(Object.create(null));
 __compiledHandles.set(handle,{identity,value,guaranteed});return handle;
}
function __compiledEntry(handle,identity){
 const entry=__compiledHandles.get(handle);
 if(!entry||entry.identity!==identity)throw Error('compiled value type or owner mismatch');
 return entry;
}
function __compiledUnwrap(handle,identity){return __compiledEntry(handle,identity).value;}
// Emit the portable schema's framing/scalar events without creating a buffer
// or exposing private composite nodes. Only this wrapper receives callbacks
// from the literal writer; host visitors never receive those closures.
function __compiledValueEvents(sink,limits){
 const methods=['begin','end','byte','word','wide','text','count'];
 for(const name of methods)if(typeof sink?.[name]!=='function')throw Error('compiled value visitor method: '+name);
 const budget=createValueCaptureBudget(limits);let depth=0,closed=false;
 const active=()=>{if(closed)throw Error('compiled value visitor is closed');};
 const writer=Object.freeze({
  openFrame(){active();budget.enter(depth,4);depth++;sink.begin();return 0;}
  ,closeFrame(){active();if(depth===0)throw Error('wire frame boundary');try{sink.end();}finally{depth--;}}
  ,frame(emit){active();budget.enter(depth,4);depth++;sink.begin();try{emit();sink.end();}finally{depth--;}}
  ,byte(value){active();budget.add(1);sink.byte(value);}
  ,word(value){active();budget.add(4);sink.word(value);}
  ,wide(value){active();budget.add(8);sink.wide(value);}
  ,text(value){active();budget.text(value);sink.text(value);}
  ,count(value){active();budget.add(4);if(value>budget.remaining)throw Error('wire sequence size');sink.count(value);}
 });
 return {writer,close(){closed=true;}};
}
function __compiledReduction(factory,root,reduce,identity){
 if(typeof factory!=='function')throw Error('compiled reduction factory');
 const reducers=[],seen=new Set(),nodes=__reductionNodes();
 const prepare=index=>{
  if(seen.has(index))return;seen.add(index);
  const node=nodes[index];
  for(const child of node.children)prepare(child);
  const reducer=factory(node,index);
  if(node.kind==='list'||node.kind==='vector'){
   const start=reducer?.start,step=reducer?.step,finish=reducer?.finish;
   if(typeof start!=='function'||typeof step!=='function'||typeof finish!=='function')throw Error('compiled collection reduction');
   reducers[index]=Object.freeze({start,step,finish});
  }else{
   if(typeof reducer!=='function')throw Error('compiled value reduction');
   reducers[index]=reducer;
  }
 };
 prepare(root);Object.freeze(reducers);
 return Object.freeze(function(handle,context,limits={}){
  const value=__compiledUnwrap(handle,identity),budget=createValueCaptureBudget(limits);
  return reduce(value,reducers,budget,0,context);
 });
}
function __compiledCodec(schema,capture,read,write,copy,constructorRoot,reductionRoot,reduce,portableFused=false,compactFused=false){
 const privateCodec=createCompiledValueCodec(schema,read),publicCodec=privateCodec;
 let fusedCodec;const fused=()=>fusedCodec??=createFusedValueCodec(schema,read);
 const identity=schema.identity;
 const codec=Object.freeze({
  identity,
  descriptor:publicCodec.descriptor,
  resolve(type){return publicCodec.resolve(type);},
  capture(value,limits={}){
   return __compiledHandle(identity,capture(value,createValueCaptureBudget(limits),0));
  },
  decode(bytes,limits={}){return __compiledHandle(identity,(portableFused?fused():privateCodec).decode(bytes,limits));},
  decodeCompact(bytes,limits={}){return __compiledHandle(identity,(compactFused?fused():privateCodec).compact().decode(bytes,limits));},
  decodeFused(bytes,limits={}){return __compiledHandle(identity,fused().decode(bytes,limits));},
  decodeCompactFused(bytes,limits={}){return __compiledHandle(identity,fused().compact().decode(bytes,limits));},
  encode(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.encodeWith(writer=>write(writer,value,false),limits);},
  encodeCompact(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.compact().encodeWith(writer=>write(writer,value,true),limits);},
  materialize(handle,limits={}){return copy(__compiledUnwrap(handle,identity),createValueCaptureBudget(limits),0);},
  builder(limits={}){return __valueBuilder(__constructorNodes(),constructorRoot,identity,limits);},
  reducer(factory){return __compiledReduction(factory,reductionRoot,reduce,identity);},
  visit(handle,sink,limits={}){
   const value=__compiledUnwrap(handle,identity),events=__compiledValueEvents(sink,limits);
   try{write(events.writer,value,false);}finally{events.close();}
  },
 });
 __compiledBindings.set(codec,{publicCodec,write,capture});return codec;
}

function __compiledEncodeResult(entry,value,limits,compact){
 const {publicCodec,write}=__compiledBindings.get(entry.result());
 return (compact?publicCodec.compact():publicCodec).encodeWith(writer=>write(writer,value,compact),limits);
}
let __constructorNodesValue;function __constructorNodes(){return __constructorNodesValue??=[{kind:'record',fields:["a","b","index","stop","label","values"],patterns:[{bytes:4,label:"record",children:[1,1,2,3,4,5],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1],["index"]:values[2],["stop"]:values[3],["label"]:values[4],["values"]:values[5]})}]},{kind:"f64",scalar:__privateCapture1},{kind:"u32",scalar:__privateCapture2},{kind:"bool",scalar:__privateCapture3},{kind:"string",scalar:__privateCapture4},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[1],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["lane","extra"],patterns:[{bytes:4,label:"record",children:[0,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["lane"]:values[0],["extra"]:values[1]})}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[0],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[4],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]}];}
// Typed input construction only: plans contain literal constructor/capture
// functions emitted from source schemas. No source expression evaluator.
// All frames and private values remain in this closure; callers receive only
// an owned opaque handle after one complete, well-typed root is constructed.
const __constructorPaths=new WeakMap();
function __valueBuilder(nodes,root,identity,limits){
 const budget=createValueCaptureBudget(limits),frames=[];
 let result,targetNode,targetDepth,complete=false,closed=false,failed=false,busy=false;
 const fail=message=>{failed=true;frames.length=0;result=undefined;throw Error(message);};
 const active=()=>{if(failed||closed)throw Error('value builder is closed');};
 const expected=()=>{
  if(!frames.length){if(complete)fail('value builder root already complete');targetNode=root;targetDepth=0;return;}
  const frame=frames.at(-1),position=frame.values.length;
  if(!frame.pattern.sequence&&position>=frame.pattern.children.length)fail('value builder constructor is full');
  targetNode=frame.pattern.sequence?frame.pattern.children[0]:frame.pattern.children[position];targetDepth=frame.depth+frame.pattern.childDepth;
 };
 const accept=value=>{
  if(frames.length)frames.at(-1).values.push(value);
  else{result=value;complete=true;}
 };
 const execute=(operation,first,second)=>{
  active();if(busy)throw Error('value builder operation already active');busy=true;
  try{return operation(first,second);}catch(error){failed=true;frames.length=0;result=undefined;throw error;}finally{busy=false;}
 };
 // Compile and cache constructor paths independently of the session's values.
 const pathPlan=(choices,startNode,startDepth)=>{
   if(!Array.isArray(choices)||choices.length===0||choices.length>128)fail('invalid value builder path');
   let cache=__constructorPaths.get(nodes);if(!cache){cache=new WeakMap();__constructorPaths.set(nodes,cache);}
   let entries=cache.get(choices),saved=entries?.get(startNode);
   if(saved)return saved;
   const path=[],charges=[];let node=startNode,depth=startDepth;
   for(let i=0;i<choices.length;i++){
    const choice=choices[i],patterns=nodes[node].patterns;
    if(!Number.isSafeInteger(choice)||choice<0||!patterns||choice>=patterns.length)fail('invalid value builder constructor');
    const pattern=patterns[choice];charges.push([pattern,depth-startDepth]);path.push({pattern,node:nodes[node]});
    if(i+1<choices.length){if(pattern.sequence||pattern.children.length!==1)fail('value builder path is not unary');node=pattern.children[0];depth+=pattern.childDepth;}
   }
   const terminal=path.at(-1).pattern;
   // Compose literal constructor functions once per path, instead of
   // allocating and interpreting another recursive closure for every value.
   const compose=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=args=>args[0];
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=args=>p.make([inner(args)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?compose(last+1):args=>args[0]):compose(last);
     return args=>node.flat(index,payload(args));
    }
    const inner=at+1<path.length?compose(at+1):null;
    if(pattern.transparent)return inner??(args=>args[0]);
    return inner?args=>pattern.make([inner(args)]):pattern.make;
   };
   const make=compose(0);
   // Scalar paths use the same literal constructors, but pass the leaf
   // directly through erased records and flat sums. No temporary argument
   // array is needed at those edges. Ordinary constructors keep their array
   // calling convention; no private value reaches the public builder API.
   const composeScalar=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=value=>value;
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=value=>p.make([inner(value)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?composeScalar(last+1):value=>value):composeScalar(last);
     return value=>node.flat(index,payload(value));
    }
    const inner=at+1<path.length?composeScalar(at+1):null;
    if(pattern.transparent)return inner??(value=>value);
    return inner?value=>pattern.make([inner(value)]):value=>pattern.make([value]);
   };
   const scalar=composeScalar(0);
   const pattern={...terminal,make};
   // Only frozen arrays of ordinary data properties can key reusable plans.
   // Mutable arrays and frozen accessor arrays retain checked per-call paths.
   const fixed=charges.every(([p])=>Number.isSafeInteger(p.bytes)&&p.bytes>=4);
   const plan={pattern,scalar,charges,offset:depth-startDepth,bytes:fixed?charges.reduce((n,[p])=>n+p.bytes,0):null};
   let reusable=Object.isFrozen(choices);
   for(let i=0;reusable&&i<choices.length;i++){const field=Object.getOwnPropertyDescriptor(choices,String(i));reusable=!!field&&Object.hasOwn(field,'value');}
   if(reusable){
    if(!entries){entries=new Map();cache.set(choices,entries);}entries.set(startNode,plan);
   }
   return plan;
 };
 const chargePath=(plan,depth)=>{
  // Each emitted constructor consumes one node and a fixed frame/tag cost.
  // Only take the combined charge when every original check would succeed.
  // Replaying the original order retains the exact first failure otherwise.
  if(plan.bytes!==null&&depth+plan.offset<=budget.depth&&plan.charges.length<=budget.remaining&&budget.bytes+plan.bytes<=budget.limit){
   budget.remaining-=plan.charges.length;budget.bytes+=plan.bytes;return;
  }
  for(const [pattern,offset]of plan.charges)pattern.charge(budget,depth+offset);
 };
 // Operations are allocated once per session, and share expected-node
 // scratch only while the existing reentrancy guard is held.
 const openOperation=(choice)=>{
   expected();const node=nodes[targetNode];
   if(!Number.isSafeInteger(choice)||choice<0||!node.patterns||choice>=node.patterns.length)fail('invalid value builder constructor');
   const pattern=node.patterns[choice];pattern.charge(budget,targetDepth);
   frames.push({pattern,depth:targetDepth,values:[]});
 };
 const openPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth);
   chargePath(plan,targetDepth);
   frames.push({pattern:plan.pattern,depth:targetDepth+plan.offset,values:[]});
 };
 const scalarPathOperation=(choices,value)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==1)fail('value builder path has no scalar leaf');
   const capture=nodes[pattern.children[0]].scalar;
   if(typeof capture!=='function')fail('value builder path has no scalar leaf');
   chargePath(plan,targetDepth);
   const leaf=capture(value,budget,targetDepth+plan.offset+pattern.childDepth);
   accept(plan.scalar(leaf));
 };
 const emptyPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==0)fail('value builder path is not empty');
   chargePath(plan,targetDepth);accept(pattern.make([]));
 };
 const scalarOperation=(value)=>{
   expected();const capture=nodes[targetNode].scalar;
   if(typeof capture!=='function')fail('value builder expects a constructor');
   accept(capture(value,budget,targetDepth));
 };
 const closeOperation=()=>{
   if(!frames.length)fail('value builder has no open constructor');
   const frame=frames.at(-1),pattern=frame.pattern,count=frame.values.length;
   if(!pattern.sequence&&count!==pattern.children.length||pattern.size!==undefined&&count!==pattern.size)fail('value builder constructor arity');
   if(pattern.sequence&&count>budget.limit)fail('wire sequence size');
   const value=pattern.make(frame.values);
   frames.pop();accept(value);
 };
 const finishOperation=()=>{
   if(frames.length||!complete)fail('value builder root is incomplete');
   closed=true;const handle=__compiledHandle(identity,result);result=undefined;return handle;
 };
 const api=Object.freeze({
  open(choice){return execute(openOperation,choice);},
  // Charge every source constructor even when unary paths share one frame.
  openPath(choices){return execute(openPathOperation,choices);},
  // Complete the path and leaf without intermediate session frames.
  scalarPath(choices,value){return execute(scalarPathOperation,choices,value);},
  emptyPath(choices){return execute(emptyPathOperation,choices);},
  scalar(value){return execute(scalarOperation,value);},
  close(){return execute(closeOperation);},
  finish(){return execute(finishOperation);},
  abort(){if(busy)throw Error('value builder operation already active');failed=true;frames.length=0;result=undefined;},
 });
 return api;
}
function __reduceValue0(value,r,b,d,c){b.enter(d,4);return r[0](__reduceValue1(value["a"],r,b,d+1,c),__reduceValue1(value["b"],r,b,d+1,c),__reduceValue2(value["index"],r,b,d+1,c),__reduceValue3(value["stop"],r,b,d+1,c),__reduceValue4(value["label"],r,b,d+1,c),__reduceValue5(value["values"],r,b,d+1,c),c);}
function __reduceValue1(value,r,b,d,c){b.enter(d,12);return r[1]({F64Bits:__dfBits(value).toString()},c);}
function __reduceValue2(value,r,b,d,c){b.enter(d,8);return r[2](value,c);}
function __reduceValue3(value,r,b,d,c){b.enter(d,5);return r[3](value,c);}
function __reduceValue4(value,r,b,d,c){b.enter(d,4);b.text(value);return r[4](value,c);}
function __reduceValue5(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[5];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue1(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue6(value,r,b,d,c){b.enter(d,4);return r[6](__reduceValue0(value["lane"],r,b,d+1,c),__reduceValue1(value["extra"],r,b,d+1,c),c);}
function __reduceValue7(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[7](0,__reduceValue0(value.Ok,r,b,d+1,c),c):r[7](1,__reduceValue4(value.Err,r,b,d+1,c),c);}
let __reductionNodeCache;function __reductionNodes(){return __reductionNodeCache??=Object.freeze([Object.freeze({"children":Object.freeze([1,1,2,3,4,5]),"fields":Object.freeze(["a","b","index","stop","label","values"]),"kind":"record","name":"Lane"}),Object.freeze({"children":Object.freeze([]),"kind":"f64"}),Object.freeze({"children":Object.freeze([]),"kind":"u32"}),Object.freeze({"children":Object.freeze([]),"kind":"bool"}),Object.freeze({"children":Object.freeze([]),"kind":"string"}),Object.freeze({"children":Object.freeze([1]),"kind":"list"}),Object.freeze({"children":Object.freeze([0,1]),"fields":Object.freeze(["lane","extra"]),"kind":"record","name":"Nested"}),Object.freeze({"children":Object.freeze([0,4]),"kind":"result"})]);}
function __compiledNamed0(){return {};}
let __compiledCodec0Value;function __compiledCodec0(){return __compiledCodec0Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"19d74cac6aa3129f10262e59c194cad7f9b36ee41b7c4bb3bdfd434cf94ca065","named":__compiledNamed0(),"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},__privateCapture0,__privateWireValue0,__privateWireWrite0,__compiledOwnedValue0,0,0,__reduceValue0,false,false);}
let __compiledCodec1Value;function __compiledCodec1(){return __compiledCodec1Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":__compiledNamed0(),"root":{"kind":"f64"}},__privateCapture1,__privateWireValue1,__privateWireWrite1,__compiledOwnedValue1,1,1,__reduceValue1,false,false);}
let __compiledCodec2Value;function __compiledCodec2(){return __compiledCodec2Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff","named":__compiledNamed0(),"root":{"kind":"u32"}},__privateCapture2,__privateWireValue2,__privateWireWrite2,__compiledOwnedValue2,2,2,__reduceValue2,false,false);}
let __compiledCodec3Value;function __compiledCodec3(){return __compiledCodec3Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"152a8177038a47dcbc6416cb2d7d38cc76c42d7e55613dee4787f2dfb646e9e7","named":__compiledNamed0(),"root":{"element":{"kind":"f64"},"kind":"list"}},__privateCapture5,__privateWireValue5,__privateWireWrite5,__compiledOwnedValue5,5,5,__reduceValue5,false,false);}
let __compiledCodec4Value;function __compiledCodec4(){return __compiledCodec4Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"f6a38740bfaa9df5b44d524912b5d37b67499c6f27409a66d8fd9bcf73101771","named":__compiledNamed0(),"root":{"fields":[{"name":"lane","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}},{"name":"extra","type":{"kind":"f64"}}],"kind":"record","name":"Nested"}},__privateCapture6,__privateWireValue8,__privateWireWrite6,__compiledOwnedValue6,6,6,__reduceValue6,false,false);}
let __compiledCodec5Value;function __compiledCodec5(){return __compiledCodec5Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"dd4eeb2390c05e915de706d8e703ebfa5f0eaf949aa9c10fc3f140c8053e212c","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}},{"name":"index","type":{"kind":"u32"}},{"name":"stop","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}},{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Lane"}}},__privateCapture7,__privateWireValue12,__privateWireWrite7,__compiledOwnedValue7,7,7,__reduceValue7,false,false);}
const __compiledEntries=new Map([["advance",{index:0,params:[__compiledCodec0],result:__compiledCodec0,arguments:__privateWireValue6,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["drive",{index:1,params:[__compiledCodec1,__compiledCodec1,__compiledCodec2],result:__compiledCodec0,arguments:__privateWireValue7,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["projected",{index:2,params:[__compiledCodec1,__compiledCodec1,__compiledCodec2],result:__compiledCodec3,arguments:__privateWireValue7,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["pick",{index:3,params:[__compiledCodec4],result:__compiledCodec3,arguments:__privateWireValue9,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["branch",{index:4,params:[__compiledCodec0,__compiledCodec2],result:__compiledCodec0,arguments:__privateWireValue10,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["selected",{index:5,params:[__compiledCodec1,__compiledCodec1,__compiledCodec2],result:__compiledCodec0,arguments:__privateWireValue7,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["nested",{index:6,params:[__compiledCodec1,__compiledCodec1,__compiledCodec2],result:__compiledCodec3,arguments:__privateWireValue7,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["kept",{index:7,params:[__compiledCodec3,__compiledCodec0],result:__compiledCodec0,arguments:__privateWireValue11,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["aliases",{index:8,params:[__compiledCodec1,__compiledCodec1,__compiledCodec2],result:__compiledCodec3,arguments:__privateWireValue7,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["owned",{index:10,params:[__compiledCodec1,__compiledCodec1,__compiledCodec2],result:__compiledCodec3,arguments:__privateWireValue7,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["fallible",{index:11,params:[__compiledCodec1,__compiledCodec1,__compiledCodec2],result:__compiledCodec5,arguments:__privateWireValue7,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["chain0",{index:12,params:[__compiledCodec0],result:__compiledCodec0,arguments:__privateWireValue6,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["chain1",{index:13,params:[__compiledCodec0],result:__compiledCodec0,arguments:__privateWireValue6,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["chain2",{index:14,params:[__compiledCodec0],result:__compiledCodec0,arguments:__privateWireValue6,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["chain3",{index:15,params:[__compiledCodec0],result:__compiledCodec0,arguments:__privateWireValue6,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["chain4",{index:16,params:[__compiledCodec0],result:__compiledCodec0,arguments:__privateWireValue6,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["chain5",{index:17,params:[__compiledCodec0],result:__compiledCodec0,arguments:__privateWireValue6,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["chain6",{index:18,params:[__compiledCodec0],result:__compiledCodec0,arguments:__privateWireValue6,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["chain7",{index:19,params:[__compiledCodec0],result:__compiledCodec0,arguments:__privateWireValue6,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["chain8",{index:20,params:[__compiledCodec0],result:__compiledCodec0,arguments:__privateWireValue6,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["bounded",{index:21,params:[__compiledCodec1,__compiledCodec1,__compiledCodec2],result:__compiledCodec0,arguments:__privateWireValue7,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["large",{index:22,params:[__compiledCodec0],result:__compiledCodec3,arguments:__privateWireValue6,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["fallback",{index:23,params:[__compiledCodec1,__compiledCodec1,__compiledCodec2],result:__compiledCodec3,arguments:__privateWireValue7,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}]]);

export const compiledValues=Object.freeze(Object.fromEntries([...__compiledEntries].map(([name,entry])=>[name,Object.freeze({get params(){return Object.freeze(entry.params.map(codec=>codec()));},get result(){return entry.result();}})])));
function __compiledValidate(entry,owned){
 const values=owned.map(v=>v.value);
 const established=entry.onlyTypeGuards&&entry.needsInvariants.every((needed,i)=>!needed||owned[i].guaranteed);
 if(entry.precondition!==null&&!established){
  if(__implementations[entry.precondition](...values)!==true)throw Error('contract precondition failed');
  for(let i=0;i<owned.length;i++)if(entry.needsInvariants[i])owned[i].guaranteed=true;
 }
 return values;
}
export function callCompiled(name,args){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(args)||args.length!==entry.params.length)throw Error('unsupported compiled call');
 const owned=entry.params.map((codec,i)=>__compiledEntry(args[i],codec().identity)),values=__compiledValidate(entry,owned);
 // Checked source outputs satisfy their declared value interfaces. Private
 // handles expose only detached copies and never retain mutable host inputs.
 return __compiledHandle(entry.result().identity,__implementations[entry.index](...values),true);
}

// Explicit sealed-value partial application. Each token owns a bounded set of
// lexical caches; no mutable host object, global memo table or error is retained.
const __preparedCompiled=new WeakMap();
export function prepareCompiled(name,bindings){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(bindings)||bindings.length>entry.params.length)throw Error('unsupported prepared compiled call');
 const captured=new Array(entry.params.length),fixed=new Array(entry.params.length).fill(false);
 for(const binding of bindings){
  if(!Array.isArray(binding)||binding.length!==2)throw Error('prepared compiled binding');
  const [index,handle]=binding;
  if(!Number.isInteger(index)||index<0||index>=fixed.length||fixed[index])throw Error('prepared compiled parameter');
  captured[index]=__compiledEntry(handle,entry.params[index]().identity);fixed[index]=true;
 }
 const remaining=fixed.flatMap((yes,i)=>yes?[]:[i]);
 const factory=__preparedFactories.get(entry.index);
 const run=factory?factory(fixed):__implementations[entry.index];
 const token=Object.freeze(Object.create(null));
 __preparedCompiled.set(token,{entry,captured,remaining,run});return token;
}
export function callPreparedCompiled(token,args){
 const prepared=__preparedCompiled.get(token);
 if(!prepared||!Array.isArray(args)||args.length!==prepared.remaining.length)throw Error('invalid prepared compiled call');
 const {entry,captured,remaining,run}=prepared,owned=captured.slice();
 for(let i=0;i<remaining.length;i++){const at=remaining[i];owned[at]=__compiledEntry(args[i],entry.params[at]().identity);}
 const values=__compiledValidate(entry,owned);
 return __compiledHandle(entry.result().identity,run(...values),true);
}
const __intoOutput2=__representation(metadata.functions[2].result.element,true);
const __intoOutput3=__representation(metadata.functions[3].result.element,true);
const __intoOutput6=__representation(metadata.functions[6].result.element,true);
const __intoOutput8=__representation(metadata.functions[8].result.element,true);
const __intoOutput9=__representation(metadata.functions[9].result.element,true);
const __intoOutput10=__representation(metadata.functions[10].result.element,true);
const __intoOutput22=__representation(metadata.functions[22].result.element,true);
const __intoOutput23=__representation(metadata.functions[23].result.element,true);
const __intoImplementations=[null,null,__into2,__into3,null,null,__into6,null,__into8,__into9,__into10,null,null,null,null,null,null,null,null,null,null,null,__into22,__into23];

export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>{
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const body=__intoImplementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args.slice(0,f.params.length))!==true)throw Error('contract precondition failed');return body(...args);};
  const entry=input.every(c=>c===__identity)?implementation:(...values)=>{const context=new WeakMap();return implementation(...input.map((convert,i)=>convert(values[i],context)),values[f.params.length]);};
  return [f.name,entry];
})));
export function callInto(name,args,destination){switch(name){case "last":throw new Error('temporary storage is internal to a pure invocation');}return functionsInto[name](...args,destination);}

function __preparedPart(mask,path){
 for(const field of path){
  if(mask===true)return true;
  if(!mask || typeof mask!=="object")return false;
  mask=Object.hasOwn(mask.fields,field)?mask.fields[field]:false;
 }
 return mask;
}
function __preparedStable(mask,path){const part=__preparedPart(mask,path);return part===true || (!!part && part.all===true);}
function __prepareFn1(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn1;const v949=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
let v948=false,v947;
return function(v943,v944,v945){let v946;if(v949&&v948){v946=v947;}else{
const v950=0;
const v951=false;
const v952="lane";
const v953=[v943,v944];
v946=({["a"]:v943,["b"]:v944,["index"]:v950,["stop"]:v951,["label"]:v952,["values"]:v953});if(v949){v947=v946;v948=true;}}
const v954=v946;
let v955=v954["a"];
let v956=v954["b"];
let v957=v954["index"];
let v958=v954["stop"];
let v959=v954["label"];
let v960=v954["values"];
for(let v962=0;v962<v945;v962++){
if(v958)break;
const v963=(v962>>>0);
const v964=7;
const v965=(v963===v964);
const v966=v955;
const v967=v956;
const v968=v959;
const v969=v960;
const v971=__dfNeg(v966);
v955=v967;
v956=v971;
v957=v963;
v958=v965;
v959=v968;
v960=v969;
}
return ({["a"]:v955,["b"]:v956,["index"]:v957,["stop"]:v958,["label"]:v959,["values"]:v960});};}
function __prepareFn2(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn2;const v978=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v977=false,v976;
const v981=depth<15&&__preparedFactories.has(1)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])));
let v979;
let v986=false,v985;
return function(v972,v973,v974){let v975;if(v978&&v977){v975=v976;}else{
let v982;if(v981){if(!v979){const v980=__preparedFactories.get(1);v979=v980([fixed[0],fixed[1],fixed[2]],depth+1);}v982=v979(v972,v973,v974);}else{v982=__fn1(v972,v973,v974);}
v975=v982;if(v978){v976=v975;v977=true;}}
const v983=v975;
let v984;if(v978&&v986){v984=v985;}else{
const v988=v983;
const v987=v988["b"];
const v990=v983;
const v989=v990["a"];
const v991=v987;
const v992=v989;
const v993=v975;
const v994=v993["index"];
const v995=v975;
const v996=v995["stop"];
const v997=v975;
const v998=v997["label"];
const v999=v975;
const v1000=v999["values"];
v984=({["a"]:v991,["b"]:v992,["index"]:v994,["stop"]:v996,["label"]:v998,["values"]:v1000});if(v978){v985=v984;v986=true;}}
const v1001=v984;
const v1002=v1001["a"];
const v1003=v983;
const v1004=v1003["a"];
const v1005=v984;
const v1006=v1005["b"];
const v1007=v983;
const v1008=v1007["b"];
const v1009=v984;
const v1010=v1009["values"];
let v1011;if(v974<v1010.length){v1011=v1010[v974];}else{
v1011=v972;}
const v1012=v1011;
const v1013=v984;
const v1014=v1013["index"];
return [v1002,v1004,v1006,v1008,v1012,v1014];};}
function __prepareFn4(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn4;const v1021=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
let v1020=false,v1019;
return function(v1016,v1017){let v1018;if(v1021&&v1020){v1018=v1019;}else{
const v1022=0;
const v1023=(v1017===v1022);
let v1024;if(v1023){
const v1026=v1016["b"];
const v1025=__dfNeg(v1026);
const v1027=v1025;
const v1028=v1016["b"];
const v1029=v1016["index"];
const v1030=v1016["stop"];
const v1031=v1016["label"];
const v1032=v1016["values"];
v1024=({["a"]:v1027,["b"]:v1028,["index"]:v1029,["stop"]:v1030,["label"]:v1031,["values"]:v1032});}else{
const v1034=v1016["a"];
const v1033=__dfNeg(v1034);
const v1035=v1016["a"];
const v1036=v1033;
const v1037=v1016["index"];
const v1038=v1016["stop"];
const v1039=v1016["label"];
const v1040=v1016["values"];
v1024=({["a"]:v1035,["b"]:v1036,["index"]:v1037,["stop"]:v1038,["label"]:v1039,["values"]:v1040});}
v1018=v1024;if(v1021){v1019=v1018;v1020=true;}}
const v1041=v1018;
const v1042=1;
const v1043=(v1017===v1042);
let v1044;if(v1043){
v1044=v1041;}else{
const v1045=v1041;
const v1046=v1045["values"];
const v1047=v1018;
const v1048=v1047["a"];
const v1049=v1018;
const v1050=v1049["b"];
const v1051=v1018;
const v1052=v1051["index"];
const v1053=v1018;
const v1054=v1053["stop"];
const v1055=v1018;
const v1056=v1055["label"];
const v1058=__dfNeg(v1048);
v1044=({["a"]:v1050,["b"]:v1058,["index"]:v1052,["stop"]:v1054,["label"]:v1056,["values"]:v1046});}
return v1044;};}
function __prepareFn5(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn5;const v1065=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v1064=false,v1063;
const v1070=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
const v1071={all:__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]),fields:{["a"]:fixed[0],["b"]:fixed[1],["index"]:fixed[2],["label"]:true,["stop"]:true,["values"]:v1070}};
const v1074=depth<15&&__preparedFactories.has(4)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v1072;
return function(v1059,v1060,v1061){let v1062;if(v1065&&v1064){v1062=v1063;}else{
const v1066=false;
const v1067="branch";
const v1068=[v1059,v1060];
v1062=({["a"]:v1059,["b"]:v1060,["index"]:v1061,["stop"]:v1066,["label"]:v1067,["values"]:v1068});if(v1065){v1063=v1062;v1064=true;}}
const v1069=v1062;
let v1075;if(v1074){if(!v1072){const v1073=__preparedFactories.get(4);v1072=v1073([v1071,fixed[2]],depth+1);}v1075=v1072(v1069,v1061);}else{v1075=__fn4(v1069,v1061);}
return v1075;};}
function __prepareFn6(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn6;const v1082=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v1081=false,v1080;
return function(v1076,v1077,v1078){let v1079;if(v1082&&v1081){v1079=v1080;}else{
const v1083=false;
const v1084="nested";
const v1085=[v1076,v1077];
v1079=({["a"]:v1076,["b"]:v1077,["index"]:v1078,["stop"]:v1083,["label"]:v1084,["values"]:v1085});if(v1082){v1080=v1079;v1081=true;}}
const v1087=v1079;
const v1088=__dfNeg(v1077);
const v1086=({["lane"]:v1087,["extra"]:v1088});
const v1089=v1086;
return __fn3(v1089);};}
function __prepareFn7(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],["values"]))))return __fn7;const v1095=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],["values"]);
let v1094=false,v1093;
return function(v1090,v1091){let v1092;if(v1095&&v1094){v1092=v1093;}else{
const v1096=v1091["values"];
const v1097=v1096.length;
const v1098=v1090.length;
const v1099=new Array(v1097+v1098);
for(let v1100=0;v1100<v1097;v1100++){v1099[v1100]=v1096[v1100];}
for(let v1101=0;v1101<v1098;v1101++){v1099[v1097+v1101]=v1090[v1101];}
v1092=v1099;if(v1095){v1093=v1092;v1094=true;}}
const v1102=v1091["a"];
const v1103=v1091["b"];
const v1104=v1091["index"];
const v1105=v1091["stop"];
const v1106=v1091["label"];
const v1107=v1092;
return ({["a"]:v1102,["b"]:v1103,["index"]:v1104,["stop"]:v1105,["label"]:v1106,["values"]:v1107});};}
function __prepareFn8(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn8;const v1115=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v1114=false,v1113;
let v1121=false,v1120;
return function(v1108,v1109,v1110){const v1111=[v1108,v1109];
let v1112;if(v1115&&v1114){v1112=v1113;}else{
const v1116=false;
const v1117="alias";
const v1118=v1111;
v1112=({["a"]:v1108,["b"]:v1109,["index"]:v1110,["stop"]:v1116,["label"]:v1117,["values"]:v1118});if(v1115){v1113=v1112;v1114=true;}}
let v1119;if(v1115&&v1121){v1119=v1120;}else{
const v1122=v1112;
let v1123=v1122["a"];
let v1124=v1122["b"];
let v1125=v1122["index"];
let v1126=v1122["stop"];
let v1127=v1122["label"];
let v1128=v1122["values"];
for(let v1130=0;v1130<v1110;v1130++){
if(false)break;
const v1131=(v1130>>>0);
const v1132=[v1131];
const v1134=v1128;
const v1135=v1134.length;
const v1136=v1132.length;
const v1137=new Array(v1135+v1136);
for(let v1138=0;v1138<v1135;v1138++){v1137[v1138]=v1134[v1138];}
for(let v1139=0;v1139<v1136;v1139++){v1137[v1135+v1139]=v1132[v1139];}
const v1140=v1123;
const v1141=v1124;
const v1142=v1125;
const v1143=v1126;
const v1144=v1127;
v1123=v1140;
v1124=v1141;
v1125=v1142;
v1126=v1143;
v1127=v1144;
v1128=v1137;
}
v1119=({["a"]:v1123,["b"]:v1124,["index"]:v1125,["stop"]:v1126,["label"]:v1127,["values"]:v1128});if(v1115){v1120=v1119;v1121=true;}}
const v1145=v1111;
const v1146=v1119;
const v1147=v1146["values"];
const v1148=v1145.length;
const v1149=v1147.length;
const v1150=new Array(v1148+v1149);
for(let v1151=0;v1151<v1148;v1151++){v1150[v1151]=v1145[v1151];}
for(let v1152=0;v1152<v1149;v1152++){v1150[v1148+v1152]=v1147[v1152];}
return v1150;};}
function __prepareFn11(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn11;const v1169=depth<15&&__preparedFactories.has(1)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])));
let v1167;
return function(v1156,v1157,v1158){const v1159=({Some:null});
let v1160;if(Object.hasOwn(v1159,"Some")){
const v1161=v1159["Some"];
const v1162=10;
v1160=((v1158) < (v1162));}else{
const v1163=null;
const v1164=10;
v1160=((v1158) < (v1164));}
const v1165=v1160;
let v1166;if(v1165){
let v1170;if(v1169){if(!v1167){const v1168=__preparedFactories.get(1);v1167=v1168([fixed[0],fixed[1],fixed[2]],depth+1);}v1170=v1167(v1156,v1157,v1158);}else{v1170=__fn1(v1156,v1157,v1158);}
const v1171=v1170;
v1166=({Ok:v1171});}else{
const v1173=({Some:null});
let v1174;if(Object.hasOwn(v1173,"Some")){
const v1175=v1173["Some"];
v1174="outside range";}else{
const v1176=null;
v1174="outside range";}
v1166=({Err:v1174});}
return v1166;};}
function __prepareFn21(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn21;const v1192=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
let v1191=false,v1190;
const v1196=depth<15&&__preparedFactories.has(1)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])));
let v1194;
return function(v1186,v1187,v1188){let v1189;if(v1192&&v1191){v1189=v1190;}else{
const v1193=0;
let v1197;if(v1196){if(!v1194){const v1195=__preparedFactories.get(1);v1194=v1195([fixed[0],fixed[1],true],depth+1);}v1197=v1194(v1186,v1187,v1193);}else{v1197=__fn1(v1186,v1187,v1193);}
v1189=v1197;if(v1192){v1190=v1189;v1191=true;}}
const v1198=v1189;
return __fn12(v1198);};}
function __prepareFn23(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn23;const v1206=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v1205=false,v1204;
return function(v1200,v1201,v1202){let v1203;if(v1206&&v1205){v1203=v1204;}else{
const v1207=false;
const v1208="large";
const v1209=[v1200,v1201];
v1203=({["a"]:v1200,["b"]:v1201,["index"]:v1202,["stop"]:v1207,["label"]:v1208,["values"]:v1209});if(v1206){v1204=v1203;v1205=true;}}
const v1210=v1203;
return __fn22(v1210);};}
const __preparedFactories=new Map([[1,__prepareFn1],[2,__prepareFn2],[4,__prepareFn4],[5,__prepareFn5],[6,__prepareFn6],[7,__prepareFn7],[8,__prepareFn8],[11,__prepareFn11],[21,__prepareFn21],[23,__prepareFn23]]);
