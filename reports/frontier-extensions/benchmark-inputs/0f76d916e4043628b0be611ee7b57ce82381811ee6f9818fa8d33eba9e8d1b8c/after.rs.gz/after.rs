// ink-definition-rust-v1: checked bodies; Rust/backend are trusted.
#![allow(non_camel_case_types, non_snake_case, non_upper_case_globals, dead_code, unused_variables, unused_parens, unused_unsafe, improper_ctypes_definitions)]
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_033c45808088fe0a648d64dec258316039932b49f07f4e454d52c957e4a72860 { C0(std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>) }
fn d_078801970e258a449094e4f1a34a7c597cf9efaed0ebf76d275af684278a4182(v0: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v1: u64,v2: u64,v3: u64,v4: u64,v5: bool) -> D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { d_1d52702454d42edb2a6d20018333f6c88e0adba2da5cdf7fb9d638d0760825ca(&(d_f137ad14880d722826ba61d21bb95fd94e16e99431673daf2aefe85791023a26(v0)),v1,v2,v3,v4,v5) }
fn d_092267d9d0f263d331187c01135ad89a90229fd7f3e3e4eb1a838e8f624d88ba(v6: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12,v7: u64) -> bool { match &(d_d9b80c6b218b452e1dd4fb3e00a29a4a93c866068e0e24d47e367971f6ab9551(v6,v7)) { D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f::C0 => { false },D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f::C1(v8) => { true } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_0b0e2c43282a1844f9ed4654ca532484ac8277b7e25126b42b5f9cf6a218769f { C0(std::sync::Arc<D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909>,bool,u64,std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>,std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>),C1(u64,u64,std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>) }
fn d_0df148d477a34f35afa45041954fafc281846045ea39dd1aff9349e58b5ae275(v9: &D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d) -> D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c { match v9 { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C0 => { D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c::C0 },D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C1(v11,v12) => { D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c::C1(((match v11.as_ref() { D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v13,v14) => { *v13 } }).wrapping_mul(0u64)).wrapping_add(1u64),std::sync::Arc::new(d_0df148d477a34f35afa45041954fafc281846045ea39dd1aff9349e58b5ae275(v12.as_ref()))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d { C0(std::sync::Arc<D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947>,std::sync::Arc<D_0b0e2c43282a1844f9ed4654ca532484ac8277b7e25126b42b5f9cf6a218769f>) }
fn d_1691274ad8e3cbf3637a8cbe78b99622f2b260479dad3f460bc3c5cc4396e523(v15: &D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d) -> D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d { match v15 { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C0 => { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C0 },D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C1(v17,v18) => { if ((match v17.as_ref() { D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v19,v20) => { *v20 } }) == (0u64)) { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C1(std::sync::Arc::clone(v17),std::sync::Arc::new(d_1691274ad8e3cbf3637a8cbe78b99622f2b260479dad3f460bc3c5cc4396e523(v18.as_ref()))) } else { d_1691274ad8e3cbf3637a8cbe78b99622f2b260479dad3f460bc3c5cc4396e523(v18.as_ref()) } } } }
fn d_169effbfcb50cd2ed72923ccc2a795d6980821d2b2701d5ac421fd362680b312(v21: &D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09,v22: u64,v23: u64,v24: bool) -> D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { match &(D_033c45808088fe0a648d64dec258316039932b49f07f4e454d52c957e4a72860::C0(std::sync::Arc::new(match v21 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v25) => { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::new(d_493605feb8b9d5528b2624ab3c80186adc7989b3bef45fdf612b120a44f234ec(&(match v21 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v26) => { (v26.as_ref()).clone() } }),v23))) } }))) { D_033c45808088fe0a648d64dec258316039932b49f07f4e454d52c957e4a72860::C0(v27) => { if v24 { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v28:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v28.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v30) => { if ((v22) == (18446744073709551615u64)) { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(1u64,v22,std::sync::Arc::new((v21).clone())) } else { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v30))),true,(v22).wrapping_add(1u64),std::sync::Arc::clone(v27),std::sync::Arc::clone({static v31:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v31.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v32) => { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v32))),false,v22,std::sync::Arc::new((v21).clone()),std::sync::Arc::clone({static v33:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v33.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } } } else { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v34:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v34.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v36) => { if ((v22) == (18446744073709551615u64)) { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(1u64,v22,std::sync::Arc::new((v21).clone())) } else { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v36))),true,(v22).wrapping_add(1u64),std::sync::Arc::clone(v27),std::sync::Arc::clone({static v37:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v37.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v38) => { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v38))),false,v22,std::sync::Arc::new((v21).clone()),std::sync::Arc::clone({static v39:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v39.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } } } } } }
fn d_18b5d58be78e1ad2dd90b6ce4bb60c933243735de7b53235ce6919518dc81bf1(v40: &D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d) -> D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { match v40 { D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d::C0(v41,v42) => { (v41.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_19d679ad098cdb52dd6cdea09954b257d0a0331fd2e0456130018fe62b18027a { C0(std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>) }
fn d_1ac082f699bf8e068df795bd7cd975c1c5ed13616fb850ecdfe304d187585d29(v43: &D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09) -> D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { match v43 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v44) => { D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947::C0(std::sync::Arc::clone(v44)) } } }
fn d_1d52702454d42edb2a6d20018333f6c88e0adba2da5cdf7fb9d638d0760825ca(v45: &D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09,v46: u64,v47: u64,v48: u64,v49: u64,v50: bool) -> D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { match &(D_ce1114335932a018fd7de6f6012e294c7e537e169c3e176cbac9e2f32333dd02::C0(std::sync::Arc::new(D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v48,v49)))) { D_ce1114335932a018fd7de6f6012e294c7e537e169c3e176cbac9e2f32333dd02::C0(v51) => { if d_092267d9d0f263d331187c01135ad89a90229fd7f3e3e4eb1a838e8f624d88ba(&(match v45 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v52) => { (v52.as_ref()).clone() } }),v47) { if d_092267d9d0f263d331187c01135ad89a90229fd7f3e3e4eb1a838e8f624d88ba(&(match v45 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v53) => { (v53.as_ref()).clone() } }),v47) { match &(D_033c45808088fe0a648d64dec258316039932b49f07f4e454d52c957e4a72860::C0(std::sync::Arc::new(match v45 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v54) => { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::new(d_a39c5e1dc42ba2302cbff5dfc8ac86a58485fa593e8aeaa181ba022329029480(&(match v45 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v55) => { (v55.as_ref()).clone() } }),v47,v51.as_ref()))) } }))) { D_033c45808088fe0a648d64dec258316039932b49f07f4e454d52c957e4a72860::C0(v56) => { match &(D_19d679ad098cdb52dd6cdea09954b257d0a0331fd2e0456130018fe62b18027a::C0(std::sync::Arc::new(d_93a2b8f313f7a616ffc4a18e06df602b7ff316c91398a730ba2941036ecbbf7f(&(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0),&(D_d762bb1af249ac8e4d79ab5c82bc7e5d6e1a8239b27bfd12dbfeb76c3db794a1::C0(v48)))))) { D_19d679ad098cdb52dd6cdea09954b257d0a0331fd2e0456130018fe62b18027a::C0(v58) => { if v50 { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v59:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v59.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v61) => { if ((v46) == (18446744073709551615u64)) { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(1u64,v46,std::sync::Arc::new((v45).clone())) } else { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v61))),true,(v46).wrapping_add(1u64),std::sync::Arc::clone(v56),std::sync::Arc::clone(v58)) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v62) => { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v62))),false,v46,std::sync::Arc::new((v45).clone()),std::sync::Arc::clone({static v63:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v63.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } } } else { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v64:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v64.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v66) => { if ((v46) == (18446744073709551615u64)) { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(1u64,v46,std::sync::Arc::new((v45).clone())) } else { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v66))),true,(v46).wrapping_add(1u64),std::sync::Arc::clone(v56),std::sync::Arc::clone(v58)) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v67) => { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v67))),false,v46,std::sync::Arc::new((v45).clone()),std::sync::Arc::clone({static v68:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v68.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } } } } } } } } else { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(2u64,v46,std::sync::Arc::new((v45).clone())) } } else { if d_092267d9d0f263d331187c01135ad89a90229fd7f3e3e4eb1a838e8f624d88ba(&(match v45 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v69) => { (v69.as_ref()).clone() } }),v47) { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(2u64,v46,std::sync::Arc::new((v45).clone())) } else { match &(D_033c45808088fe0a648d64dec258316039932b49f07f4e454d52c957e4a72860::C0(std::sync::Arc::new(match v45 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v70) => { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::new(d_ae0f22e30652d2ecfa186a0d9eb14aa190071b4cbbc659aaf64fb36d7c804c32(&(match v45 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v71) => { (v71.as_ref()).clone() } }),v47,v51.as_ref()))) } }))) { D_033c45808088fe0a648d64dec258316039932b49f07f4e454d52c957e4a72860::C0(v72) => { match &(D_19d679ad098cdb52dd6cdea09954b257d0a0331fd2e0456130018fe62b18027a::C0(std::sync::Arc::new(d_93a2b8f313f7a616ffc4a18e06df602b7ff316c91398a730ba2941036ecbbf7f(&(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0),&(D_d762bb1af249ac8e4d79ab5c82bc7e5d6e1a8239b27bfd12dbfeb76c3db794a1::C0(v48)))))) { D_19d679ad098cdb52dd6cdea09954b257d0a0331fd2e0456130018fe62b18027a::C0(v74) => { if v50 { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v75:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v75.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v77) => { if ((v46) == (18446744073709551615u64)) { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(1u64,v46,std::sync::Arc::new((v45).clone())) } else { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v77))),true,(v46).wrapping_add(1u64),std::sync::Arc::clone(v72),std::sync::Arc::clone(v74)) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v78) => { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v78))),false,v46,std::sync::Arc::new((v45).clone()),std::sync::Arc::clone({static v79:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v79.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } } } else { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v80:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v80.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v82) => { if ((v46) == (18446744073709551615u64)) { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(1u64,v46,std::sync::Arc::new((v45).clone())) } else { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v82))),true,(v46).wrapping_add(1u64),std::sync::Arc::clone(v72),std::sync::Arc::clone(v74)) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v83) => { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v83))),false,v46,std::sync::Arc::new((v45).clone()),std::sync::Arc::clone({static v84:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v84.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } } } } } } } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { C0(std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,bool,u64,std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>,std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>),C1(u64,u64,std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f { C0(u64,u64) }
fn d_300222f0cc42d25982a0dc83a70a0953a60a693f69843c455fc1522a20b2780a(v85: &D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c) -> u64 { match v85 { D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c::C0 => { 0u64 },D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c::C1(v86,v87) => { (*v86).wrapping_add(d_300222f0cc42d25982a0dc83a70a0953a60a693f69843c455fc1522a20b2780a(v87.as_ref())) } } }
fn d_33456c6b9ef6209c75a1f19999587acaaff98b6f47024a047476d87bf719f57c(v88: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v89: u64,v90: u64) -> D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8 { D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8::C0(std::sync::Arc::new((v88).clone()),std::sync::Arc::new(d_70bacf9b8624bdd9a8f584aa03722d95d1051fdcb8c44d367b01b7fce8459092(&(d_f137ad14880d722826ba61d21bb95fd94e16e99431673daf2aefe85791023a26(v88)),v89,v90))) }
fn d_339ea9795a9fb5362ebb41afe16c1a88b5685beb64f400ba4567207998880912(v91: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12) -> u64 { match v91 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { 0u64 },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v92,v93,v94) => { (d_c8e0ec35ff42fc35dbe08d2a152a31bf67eb4a25d96e8e86239aea41d14127a6(v93.as_ref())).wrapping_add(d_339ea9795a9fb5362ebb41afe16c1a88b5685beb64f400ba4567207998880912(v94.as_ref())) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d { C0,C1(std::sync::Arc<D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f>,std::sync::Arc<D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d>) }
impl D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_428cd75020fc377f328385bf1ea681bda58e85a4882778fa36fbace8789dcd7f(v95: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12) -> u64 { match v95 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { 0u64 },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v96,v97,v98) => { (d_64c4333b700447690b79063b3f8abad8a04de6e543670f5f5620c1a578032dab(v97.as_ref())).wrapping_add(d_428cd75020fc377f328385bf1ea681bda58e85a4882778fa36fbace8789dcd7f(v98.as_ref())) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_4443cf480c7d87b3e1503c4ebb3ba4af4cc63c226fbd45970d6aa0588b4f5df6 { C0(std::sync::Arc<D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f>,bool,u64,std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>,std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>),C1(u64,u64,std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>) }
fn d_4500923a8f2325614396f09c48314ab31d62c38e8bb2898f8c3fd89f1506cb7b(v99: &D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c) -> u64 { match v99 { D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c::C0 => { 0u64 },D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c::C1(v100,v101) => { (*v100).wrapping_add(d_4500923a8f2325614396f09c48314ab31d62c38e8bb2898f8c3fd89f1506cb7b(v101.as_ref())) } } }
fn d_493605feb8b9d5528b2624ab3c80186adc7989b3bef45fdf612b120a44f234ec(v102: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12,v103: u64) -> D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12 { match v102 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v105,v106,v107) => { if ((v103) == (*v105)) { d_493605feb8b9d5528b2624ab3c80186adc7989b3bef45fdf612b120a44f234ec(v107.as_ref(),v103) } else { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(*v105,std::sync::Arc::clone(v106),std::sync::Arc::new(d_493605feb8b9d5528b2624ab3c80186adc7989b3bef45fdf612b120a44f234ec(v107.as_ref(),v103))) } } } }
fn d_5d4516afea38bfac8defe45326edd81013d4f2368ba7b842b409b486ac83e056(v108: &D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d) -> D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c { match v108 { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C0 => { D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c::C0 },D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C1(v110,v111) => { D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c::C1(match v110.as_ref() { D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v112,v113) => { *v112 } },std::sync::Arc::new(d_5d4516afea38bfac8defe45326edd81013d4f2368ba7b842b409b486ac83e056(v111.as_ref()))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12 { C0,C1(u64,std::sync::Arc<D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f>,std::sync::Arc<D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12>) }
impl D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_64c4333b700447690b79063b3f8abad8a04de6e543670f5f5620c1a578032dab(v114: &D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f) -> u64 { d_4500923a8f2325614396f09c48314ab31d62c38e8bb2898f8c3fd89f1506cb7b(&(d_b5b3785bf5c36a5f32a81e2e2fd852ea130acb1898765e00fc03a2c38ffc65c9(&(d_a82826d647f5f0488744cbf5aa8586621bed5054ae8da89546985cbe1b090507(&(d_863f07ebd83e9326bff38920d071f225e63b8bbe3b977daf279f6091beb33266(&(D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(0u64,std::sync::Arc::new((v114).clone()),std::sync::Arc::clone({static v115:std::sync::OnceLock<std::sync::Arc<D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12>>=std::sync::OnceLock::new();v115.get_or_init(||std::sync::Arc::new(D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0))})))))))))) }
fn d_6e8888a76e07f3035b0524301c62e53b1c68ce7c95489907e2b906debbbda744(v116: &D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f) -> u64 { d_300222f0cc42d25982a0dc83a70a0953a60a693f69843c455fc1522a20b2780a(&(d_5d4516afea38bfac8defe45326edd81013d4f2368ba7b842b409b486ac83e056(&(d_ba579f4633fa40a0ba7a58c2b40103e522366fc115a62a2d4759d8b442d694e5(&(d_863f07ebd83e9326bff38920d071f225e63b8bbe3b977daf279f6091beb33266(&(D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(0u64,std::sync::Arc::new((v116).clone()),std::sync::Arc::clone({static v117:std::sync::OnceLock<std::sync::Arc<D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12>>=std::sync::OnceLock::new();v117.get_or_init(||std::sync::Arc::new(D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0))})))))))))) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c { C0,C1(u64,std::sync::Arc<D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c>) }
impl D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_70bacf9b8624bdd9a8f584aa03722d95d1051fdcb8c44d367b01b7fce8459092(v118: &D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09,v119: u64,v120: u64) -> D_4443cf480c7d87b3e1503c4ebb3ba4af4cc63c226fbd45970d6aa0588b4f5df6 { D_4443cf480c7d87b3e1503c4ebb3ba4af4cc63c226fbd45970d6aa0588b4f5df6::C0(std::sync::Arc::new(d_d9b80c6b218b452e1dd4fb3e00a29a4a93c866068e0e24d47e367971f6ab9551(&(match v118 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v121) => { (v121.as_ref()).clone() } }),v120)),false,v119,std::sync::Arc::new((v118).clone()),std::sync::Arc::clone({static v122:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v122.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) }
fn d_7597c22aa4906c1f171628b86c5e4a2fbebc3664346581bcbe807421448414b9(v123: &D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb) -> D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { (v123).clone() }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { C0(std::sync::Arc<D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12>) }
fn d_863f07ebd83e9326bff38920d071f225e63b8bbe3b977daf279f6091beb33266(v124: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12) -> D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d { match v124 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C0 },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v126,v127,v128) => { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C1(std::sync::Arc::clone(v127),std::sync::Arc::new(d_863f07ebd83e9326bff38920d071f225e63b8bbe3b977daf279f6091beb33266(v128.as_ref()))) } } }
fn d_888b8bd93f04a64c210531a7d78388965ff890a4358248b13d48bdddd2f53b55(v129: &D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d) -> D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c { match v129 { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C0 => { D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c::C0 },D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C1(v131,v132) => { D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c::C1(match v131.as_ref() { D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v133,v134) => { *v133 } },std::sync::Arc::new(d_888b8bd93f04a64c210531a7d78388965ff890a4358248b13d48bdddd2f53b55(v132.as_ref()))) } } }
fn d_8bbd18dbb03bbbe491373f380012e93500119152952f138315445682c93df40f(v135: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v136: u64,v137: u64,v138: bool) -> D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { d_169effbfcb50cd2ed72923ccc2a795d6980821d2b2701d5ac421fd362680b312(&(d_f137ad14880d722826ba61d21bb95fd94e16e99431673daf2aefe85791023a26(v135)),v136,v137,v138) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09 { C0(std::sync::Arc<D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12>) }
fn d_9126d0ca9d1c7293fa66db982b0a4d9214b66a38fa27c949b19c995fab0cd1d3(v139: &D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d) -> D_0b0e2c43282a1844f9ed4654ca532484ac8277b7e25126b42b5f9cf6a218769f { match v139 { D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d::C0(v140,v141) => { (v141.as_ref()).clone() } } }
fn d_922831f9215e53b2e0b7af9a61e802bbb4ede4ec6f4987d6f740f30f4c9a22f1(v142: &D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f) -> u64 { d_300222f0cc42d25982a0dc83a70a0953a60a693f69843c455fc1522a20b2780a(&(d_888b8bd93f04a64c210531a7d78388965ff890a4358248b13d48bdddd2f53b55(&(d_99b455af583f20d0f48215012efeb7b4f62a25ec3d25fe774e387c3356beb651(&(d_863f07ebd83e9326bff38920d071f225e63b8bbe3b977daf279f6091beb33266(&(D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(0u64,std::sync::Arc::new((v142).clone()),std::sync::Arc::clone({static v143:std::sync::OnceLock<std::sync::Arc<D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12>>=std::sync::OnceLock::new();v143.get_or_init(||std::sync::Arc::new(D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0))})))))))))) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f { C0(std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>),C1(std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>) }
fn d_93a2b8f313f7a616ffc4a18e06df602b7ff316c91398a730ba2941036ecbbf7f(v144: &D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7,v145: &D_d762bb1af249ac8e4d79ab5c82bc7e5d6e1a8239b27bfd12dbfeb76c3db794a1) -> D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7 { match v144 { D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0 => { D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C1(std::sync::Arc::new((v145).clone()),std::sync::Arc::clone({static v146:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v146.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) },D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C1(v147,v148) => { D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C1(std::sync::Arc::clone(v147),std::sync::Arc::new(d_93a2b8f313f7a616ffc4a18e06df602b7ff316c91398a730ba2941036ecbbf7f(v148.as_ref(),v145))) } } }
fn d_93a7e8cd0e5a222a206f264f0b79c862e12f4cbeae9998c2c3529263b38effd1(v149: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12) -> u64 { match v149 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { 0u64 },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v150,v151,v152) => { (d_922831f9215e53b2e0b7af9a61e802bbb4ede4ec6f4987d6f740f30f4c9a22f1(v151.as_ref())).wrapping_add(d_93a7e8cd0e5a222a206f264f0b79c862e12f4cbeae9998c2c3529263b38effd1(v152.as_ref())) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909 { C0(u64,u64,u64,u64) }
fn d_99b455af583f20d0f48215012efeb7b4f62a25ec3d25fe774e387c3356beb651(v153: &D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d) -> D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d { match v153 { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C0 => { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C0 },D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C1(v155,v156) => { if ((match v155.as_ref() { D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v157,v158) => { *v158 } }) > (1u64)) { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C1(std::sync::Arc::clone(v155),std::sync::Arc::new(d_99b455af583f20d0f48215012efeb7b4f62a25ec3d25fe774e387c3356beb651(v156.as_ref()))) } else { d_99b455af583f20d0f48215012efeb7b4f62a25ec3d25fe774e387c3356beb651(v156.as_ref()) } } } }
fn d_a39c5e1dc42ba2302cbff5dfc8ac86a58485fa593e8aeaa181ba022329029480(v159: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12,v160: u64,v161: &D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f) -> D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12 { match v159 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v163,v164,v165) => { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(*v163,std::sync::Arc::new(if ((v160) == (*v163)) { (v161).clone() } else { (v164.as_ref()).clone() }),std::sync::Arc::new(d_a39c5e1dc42ba2302cbff5dfc8ac86a58485fa593e8aeaa181ba022329029480(v165.as_ref(),v160,v161))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f { C0,C1(std::sync::Arc<D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f>) }
fn d_a82826d647f5f0488744cbf5aa8586621bed5054ae8da89546985cbe1b090507(v166: &D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d) -> D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d { match v166 { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C0 => { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C0 },D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C1(v168,v169) => { if ((match v168.as_ref() { D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v170,v171) => { *v171 } }) == (0u64)) { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C1(std::sync::Arc::clone(v168),std::sync::Arc::new(d_a82826d647f5f0488744cbf5aa8586621bed5054ae8da89546985cbe1b090507(v169.as_ref()))) } else { d_a82826d647f5f0488744cbf5aa8586621bed5054ae8da89546985cbe1b090507(v169.as_ref()) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8 { C0(std::sync::Arc<D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947>,std::sync::Arc<D_4443cf480c7d87b3e1503c4ebb3ba4af4cc63c226fbd45970d6aa0588b4f5df6>) }
fn d_ae0f22e30652d2ecfa186a0d9eb14aa190071b4cbbc659aaf64fb36d7c804c32(v172: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12,v173: u64,v174: &D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f) -> D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12 { match v172 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v173,std::sync::Arc::new((v174).clone()),std::sync::Arc::clone({static v175:std::sync::OnceLock<std::sync::Arc<D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12>>=std::sync::OnceLock::new();v175.get_or_init(||std::sync::Arc::new(D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0))})) },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v176,v177,v178) => { if ((v173) < (*v176)) { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v173,std::sync::Arc::new((v174).clone()),std::sync::Arc::new((v172).clone())) } else { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(*v176,std::sync::Arc::clone(v177),std::sync::Arc::new(d_ae0f22e30652d2ecfa186a0d9eb14aa190071b4cbbc659aaf64fb36d7c804c32(v178.as_ref(),v173,v174))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7 { C0,C1(std::sync::Arc<D_d762bb1af249ac8e4d79ab5c82bc7e5d6e1a8239b27bfd12dbfeb76c3db794a1>,std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>) }
impl D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_b5b3785bf5c36a5f32a81e2e2fd852ea130acb1898765e00fc03a2c38ffc65c9(v179: &D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d) -> D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c { match v179 { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C0 => { D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c::C0 },D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C1(v181,v182) => { D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c::C1(match v181.as_ref() { D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v183,v184) => { *v183 } },std::sync::Arc::new(d_b5b3785bf5c36a5f32a81e2e2fd852ea130acb1898765e00fc03a2c38ffc65c9(v182.as_ref()))) } } }
fn d_ba579f4633fa40a0ba7a58c2b40103e522366fc115a62a2d4759d8b442d694e5(v185: &D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d) -> D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d { match v185 { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C0 => { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C0 },D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C1(v187,v188) => { if ((match v187.as_ref() { D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v189,v190) => { *v190 } }) == (1u64)) { D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C1(std::sync::Arc::clone(v187),std::sync::Arc::new(d_ba579f4633fa40a0ba7a58c2b40103e522366fc115a62a2d4759d8b442d694e5(v188.as_ref()))) } else { d_ba579f4633fa40a0ba7a58c2b40103e522366fc115a62a2d4759d8b442d694e5(v188.as_ref()) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c { C0 }
impl D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_bad4531675bfd20a8a3f7ce392fa6ad32cf5d85ddcfdf7d34cb217f6bf0199c3(v191: &D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09,v192: u64) -> D_0b0e2c43282a1844f9ed4654ca532484ac8277b7e25126b42b5f9cf6a218769f { match v191 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v193) => { D_0b0e2c43282a1844f9ed4654ca532484ac8277b7e25126b42b5f9cf6a218769f::C0(std::sync::Arc::new(D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909::C0(d_428cd75020fc377f328385bf1ea681bda58e85a4882778fa36fbace8789dcd7f(v193.as_ref()),d_f9c551e778e84c5249121f3f1b4536fc8fc5bb3e489b681ea7438eb368eeb406(v193.as_ref()),d_93a7e8cd0e5a222a206f264f0b79c862e12f4cbeae9998c2c3529263b38effd1(v193.as_ref()),d_339ea9795a9fb5362ebb41afe16c1a88b5685beb64f400ba4567207998880912(v193.as_ref()))),false,v192,std::sync::Arc::new(D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::clone(v193))),std::sync::Arc::clone({static v194:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v194.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b { C0 }
impl D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_c8e0ec35ff42fc35dbe08d2a152a31bf67eb4a25d96e8e86239aea41d14127a6(v195: &D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f) -> u64 { d_300222f0cc42d25982a0dc83a70a0953a60a693f69843c455fc1522a20b2780a(&(d_0df148d477a34f35afa45041954fafc281846045ea39dd1aff9349e58b5ae275(&(d_1691274ad8e3cbf3637a8cbe78b99622f2b260479dad3f460bc3c5cc4396e523(&(d_863f07ebd83e9326bff38920d071f225e63b8bbe3b977daf279f6091beb33266(&(D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(0u64,std::sync::Arc::new((v195).clone()),std::sync::Arc::clone({static v196:std::sync::OnceLock<std::sync::Arc<D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12>>=std::sync::OnceLock::new();v196.get_or_init(||std::sync::Arc::new(D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0))})))))))))) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ce1114335932a018fd7de6f6012e294c7e537e169c3e176cbac9e2f32333dd02 { C0(std::sync::Arc<D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_d762bb1af249ac8e4d79ab5c82bc7e5d6e1a8239b27bfd12dbfeb76c3db794a1 { C0(u64) }
fn d_d7ff8aedf7aae4716808fd636578dc0d671e871536155c562959b4baf465587d(v197: &D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8) -> D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { match v197 { D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8::C0(v198,v199) => { (v198.as_ref()).clone() } } }
fn d_d9b80c6b218b452e1dd4fb3e00a29a4a93c866068e0e24d47e367971f6ab9551(v200: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12,v201: u64) -> D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f { match v200 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f::C0 },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v203,v204,v205) => { if ((v201) == (*v203)) { D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f::C1(std::sync::Arc::clone(v204)) } else { d_d9b80c6b218b452e1dd4fb3e00a29a4a93c866068e0e24d47e367971f6ab9551(v205.as_ref(),v201) } } } }
fn d_e7e3f6f6a18d556802511397e31f724999d41cbc83cb66b359c55ce8e3580257(v206: &D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8) -> D_4443cf480c7d87b3e1503c4ebb3ba4af4cc63c226fbd45970d6aa0588b4f5df6 { match v206 { D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8::C0(v207,v208) => { (v208.as_ref()).clone() } } }
fn d_ea0fea581c89e9160d21dba6ef54626f2630d3df039f15aff1c821cac5fe883e(v209: &D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb) -> D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { d_1ac082f699bf8e068df795bd7cd975c1c5ed13616fb850ecdfe304d187585d29(&(match v209 { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(v210,v211,v212,v213,v214) => { (v213.as_ref()).clone() },D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(v215,v216,v217) => { (v217.as_ref()).clone() } })) }
fn d_f137ad14880d722826ba61d21bb95fd94e16e99431673daf2aefe85791023a26(v218: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947) -> D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09 { match v218 { D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947::C0(v219) => { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::clone(v219)) } } }
fn d_f3dbaa07612bf8a8c58b8550b9dba0264d6d0c216afbeaf38b8dccf2043d2c59(v220: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v221: u64) -> D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d { D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d::C0(std::sync::Arc::new((v220).clone()),std::sync::Arc::new(d_bad4531675bfd20a8a3f7ce392fa6ad32cf5d85ddcfdf7d34cb217f6bf0199c3(&(d_f137ad14880d722826ba61d21bb95fd94e16e99431673daf2aefe85791023a26(v220)),v221))) }
fn d_f9c551e778e84c5249121f3f1b4536fc8fc5bb3e489b681ea7438eb368eeb406(v222: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12) -> u64 { match v222 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { 0u64 },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v223,v224,v225) => { (d_6e8888a76e07f3035b0524301c62e53b1c68ce7c95489907e2b906debbbda744(v224.as_ref())).wrapping_add(d_f9c551e778e84c5249121f3f1b4536fc8fc5bb3e489b681ea7438eb368eeb406(v225.as_ref())) } } }
pub fn f_078801970e258a449094e4f1a34a7c597cf9efaed0ebf76d275af684278a4182(v226: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v227: u64,v228: u64,v229: u64,v230: u64,v231: bool) -> D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { d_078801970e258a449094e4f1a34a7c597cf9efaed0ebf76d275af684278a4182(v226,v227,v228,v229,v230,v231) }
pub fn f_18b5d58be78e1ad2dd90b6ce4bb60c933243735de7b53235ce6919518dc81bf1(v232: &D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d) -> D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { d_18b5d58be78e1ad2dd90b6ce4bb60c933243735de7b53235ce6919518dc81bf1(v232) }
pub fn f_1ac082f699bf8e068df795bd7cd975c1c5ed13616fb850ecdfe304d187585d29(v233: &D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09) -> D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { d_1ac082f699bf8e068df795bd7cd975c1c5ed13616fb850ecdfe304d187585d29(v233) }
pub fn f_33456c6b9ef6209c75a1f19999587acaaff98b6f47024a047476d87bf719f57c(v234: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v235: u64,v236: u64) -> D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8 { d_33456c6b9ef6209c75a1f19999587acaaff98b6f47024a047476d87bf719f57c(v234,v235,v236) }
pub fn f_7597c22aa4906c1f171628b86c5e4a2fbebc3664346581bcbe807421448414b9(v237: &D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb) -> D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { d_7597c22aa4906c1f171628b86c5e4a2fbebc3664346581bcbe807421448414b9(v237) }
pub fn f_8bbd18dbb03bbbe491373f380012e93500119152952f138315445682c93df40f(v238: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v239: u64,v240: u64,v241: bool) -> D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { d_8bbd18dbb03bbbe491373f380012e93500119152952f138315445682c93df40f(v238,v239,v240,v241) }
pub fn f_9126d0ca9d1c7293fa66db982b0a4d9214b66a38fa27c949b19c995fab0cd1d3(v242: &D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d) -> D_0b0e2c43282a1844f9ed4654ca532484ac8277b7e25126b42b5f9cf6a218769f { d_9126d0ca9d1c7293fa66db982b0a4d9214b66a38fa27c949b19c995fab0cd1d3(v242) }
pub fn f_d7ff8aedf7aae4716808fd636578dc0d671e871536155c562959b4baf465587d(v243: &D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8) -> D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { d_d7ff8aedf7aae4716808fd636578dc0d671e871536155c562959b4baf465587d(v243) }
pub fn f_e7e3f6f6a18d556802511397e31f724999d41cbc83cb66b359c55ce8e3580257(v244: &D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8) -> D_4443cf480c7d87b3e1503c4ebb3ba4af4cc63c226fbd45970d6aa0588b4f5df6 { d_e7e3f6f6a18d556802511397e31f724999d41cbc83cb66b359c55ce8e3580257(v244) }
pub fn f_ea0fea581c89e9160d21dba6ef54626f2630d3df039f15aff1c821cac5fe883e(v245: &D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb) -> D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { d_ea0fea581c89e9160d21dba6ef54626f2630d3df039f15aff1c821cac5fe883e(v245) }
pub fn f_f137ad14880d722826ba61d21bb95fd94e16e99431673daf2aefe85791023a26(v246: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947) -> D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09 { d_f137ad14880d722826ba61d21bb95fd94e16e99431673daf2aefe85791023a26(v246) }
pub fn f_f3dbaa07612bf8a8c58b8550b9dba0264d6d0c216afbeaf38b8dccf2043d2c59(v247: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v248: u64) -> D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d { d_f3dbaa07612bf8a8c58b8550b9dba0264d6d0c216afbeaf38b8dccf2043d2c59(v247,v248) }
fn q_33456c6b9ef6209c75a1f19999587acaaff98b6f47024a047476d87bf719f57c(v0:&D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v1:u64,v2:u64)->D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f{match v0 { D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947::C0(v3) => { d_d9b80c6b218b452e1dd4fb3e00a29a4a93c866068e0e24d47e367971f6ab9551(v3.as_ref(),v2) } }}
fn q_f3dbaa07612bf8a8c58b8550b9dba0264d6d0c216afbeaf38b8dccf2043d2c59(v0:&D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v1:u64)->D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909{match v0 { D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947::C0(v2) => { D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909::C0(d_428cd75020fc377f328385bf1ea681bda58e85a4882778fa36fbace8789dcd7f(v2.as_ref()),d_f9c551e778e84c5249121f3f1b4536fc8fc5bb3e489b681ea7438eb368eeb406(v2.as_ref()),d_93a7e8cd0e5a222a206f264f0b79c862e12f4cbeae9998c2c3529263b38effd1(v2.as_ref()),d_339ea9795a9fb5362ebb41afe16c1a88b5685beb64f400ba4567207998880912(v2.as_ref())) } }}
fn t_33456c6b9ef6209c75a1f19999587acaaff98b6f47024a047476d87bf719f57c(v0:&D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v1:u64,v2:u64)->D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8{match v0 { D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947::C0(v3) => { D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8::C0(std::sync::Arc::new(D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947::C0(std::sync::Arc::clone(v3))),std::sync::Arc::new(D_4443cf480c7d87b3e1503c4ebb3ba4af4cc63c226fbd45970d6aa0588b4f5df6::C0(std::sync::Arc::new(d_d9b80c6b218b452e1dd4fb3e00a29a4a93c866068e0e24d47e367971f6ab9551(v3.as_ref(),v2)),false,v1,std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::clone({static v4:std::sync::OnceLock<std::sync::Arc<D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12>>=std::sync::OnceLock::new();v4.get_or_init(||std::sync::Arc::new(D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0))}))))}),std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})))) } }}
fn t_f3dbaa07612bf8a8c58b8550b9dba0264d6d0c216afbeaf38b8dccf2043d2c59(v0:&D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v1:u64)->D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d{match v0 { D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947::C0(v2) => { D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d::C0(std::sync::Arc::new(D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947::C0(std::sync::Arc::clone(v2))),std::sync::Arc::new(D_0b0e2c43282a1844f9ed4654ca532484ac8277b7e25126b42b5f9cf6a218769f::C0(std::sync::Arc::new(D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909::C0(d_428cd75020fc377f328385bf1ea681bda58e85a4882778fa36fbace8789dcd7f(v2.as_ref()),d_f9c551e778e84c5249121f3f1b4536fc8fc5bb3e489b681ea7438eb368eeb406(v2.as_ref()),d_93a7e8cd0e5a222a206f264f0b79c862e12f4cbeae9998c2c3529263b38effd1(v2.as_ref()),d_339ea9795a9fb5362ebb41afe16c1a88b5685beb64f400ba4567207998880912(v2.as_ref()))),false,v1,std::sync::Arc::clone({static v4:std::sync::OnceLock<std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>>=std::sync::OnceLock::new();v4.get_or_init(||std::sync::Arc::new(D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::clone({static v3:std::sync::OnceLock<std::sync::Arc<D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12>>=std::sync::OnceLock::new();v3.get_or_init(||std::sync::Arc::new(D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0))}))))}),std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})))) } }}

use serde_json::{Value as Json,json};
mod portable{
//! Shared, representation-independent snapshot codec. This module also ships
//! verbatim in generated applications; it has no AST/evaluator dependency.
use num_bigint::{BigInt, Sign};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::cmp::Ordering;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Schema {
    Unit,
    Bool,
    U32,
    U64,
    I32,
    F32,
    Vector(Box<Schema>, u8),
    Int,
    String,
    Id,
    Record(Vec<(String, Schema)>),
    Enum(Vec<String>),
    List(Box<Schema>),
    Option(Box<Schema>),
    Result(Box<Schema>, Box<Schema>),
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Layout {
    pub program: [u8; 32],
    pub schema: [u8; 32],
    pub roots: Vec<(String, Schema, Schema)>,
    pub events: Vec<(String, Schema)>,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Event {
    pub commit: u64,
    pub position: u64,
    pub channel: usize,
    pub value: Value,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Logical {
    pub version: u64,
    pub tables: Vec<Vec<(Value, Value)>>,
    pub outbox: Vec<Event>,
}
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub bytes: usize,
    pub values: usize,
    pub depth: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            bytes: 64 * 1024 * 1024,
            values: 1_000_000,
            depth: 128,
        }
    }
}
/// Magnitude bound for one exact integer. Decimal conversion is superlinear,
/// so without it a single large Int in a snapshot takes minutes to hours.
pub const MAX_INT_BYTES: usize = 4096;
const MAGIC: &[u8; 8] = b"VLSTATE\0";
const HEADER: usize = 8 + 2 + 2 + 32 + 32 + 8;
type R<T> = Result<T, String>;
fn u64_bytes(out: &mut Vec<u8>, v: u64) {
    out.extend_from_slice(&v.to_le_bytes());
}
fn count(out: &mut Vec<u8>, n: usize) {
    u64_bytes(out, n as u64);
}
fn raw(out: &mut Vec<u8>, b: &[u8]) {
    count(out, b.len());
    out.extend_from_slice(b);
}
fn tag<'a>(v: &'a Value, name: &str) -> R<&'a Value> {
    let o = v.as_object().ok_or("expected tagged object")?;
    if o.len() != 1 {
        return Err("expected exactly one tag".into());
    }
    o.get(name).ok_or("unexpected value tag".into())
}
fn integer(v: &Value) -> R<BigInt> {
    let s = tag(v, "Int")?.as_str().ok_or("expected Int string")?;
    // Every Int within the bound has fewer than 2.41 decimal digits per byte.
    if s.len() > MAX_INT_BYTES * 5 / 2 + 1 {
        return Err("snapshot Int exceeds size limit".into());
    }
    let n = s.parse::<BigInt>().map_err(|_| "invalid Int")?;
    if n.bits() > 8 * MAX_INT_BYTES as u64 {
        return Err("snapshot Int exceeds size limit".into());
    }
    if n.to_string() != s {
        return Err("noncanonical Int".into());
    }
    Ok(n)
}
fn identifier(v: &Value) -> R<u128> {
    let s = v.as_str().ok_or("expected ID")?;
    if s.len() != 32
        || !s
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err("noncanonical ID".into());
    }
    u128::from_str_radix(s, 16).map_err(|e| e.to_string())
}
fn compare(t: &Schema, a: &Value, b: &Value) -> R<Ordering> {
    Ok(match t {
        Schema::I32 => a
            .as_i64()
            .and_then(|n| i32::try_from(n).ok())
            .ok_or("invalid i32 key")?
            .cmp(
                &b.as_i64()
                    .and_then(|n| i32::try_from(n).ok())
                    .ok_or("invalid i32 key")?,
            ),
        Schema::U32 | Schema::U64 => a
            .as_u64()
            .ok_or("invalid key")?
            .cmp(&b.as_u64().ok_or("invalid key")?),
        Schema::String => a
            .as_str()
            .ok_or("invalid key")?
            .as_bytes()
            .cmp(b.as_str().ok_or("invalid key")?.as_bytes()),
        Schema::Id => identifier(a)?.cmp(&identifier(b)?),
        _ => return Err("unsupported snapshot key schema".into()),
    })
}
fn tick(left: &mut usize, depth: usize, limits: Limits) -> R<()> {
    if *left == 0 || depth > limits.depth {
        return Err("snapshot value/depth limit exceeded".into());
    }
    *left -= 1;
    Ok(())
}
fn encode_value(
    t: &Schema,
    v: &Value,
    out: &mut Vec<u8>,
    left: &mut usize,
    depth: usize,
    limits: Limits,
) -> R<()> {
    tick(left, depth, limits)?;
    match t {
        Schema::Unit => {
            if !v.is_null() {
                return Err("expected Unit".into());
            }
        }
        Schema::Bool => out.push(v.as_bool().ok_or("expected Bool")? as u8),
        Schema::U32 => out.extend_from_slice(
            &u32::try_from(v.as_u64().ok_or("expected u32")?)
                .map_err(|_| "u32 overflow")?
                .to_le_bytes(),
        ),
        Schema::U64 => u64_bytes(out, v.as_u64().ok_or("expected u64")?),
        Schema::I32 => out.extend_from_slice(
            &i32::try_from(v.as_i64().ok_or("expected i32")?)
                .map_err(|_| "i32 overflow")?
                .to_le_bytes(),
        ),
        Schema::F32 => {
            let bits = if let Some(b) = v.get("F32Bits") {
                if v.as_object().is_none_or(|o| o.len() != 1) {
                    return Err("expected only F32Bits field".into());
                }
                u32::try_from(b.as_u64().ok_or("expected f32 bits")?)
                    .map_err(|_| "f32 bits overflow")?
            } else {
                let f = v.as_f64().ok_or("expected f32")? as f32;
                if !f.is_finite() {
                    return Err("finite f32 or F32Bits required".into());
                }
                f.to_bits()
            };
            out.extend_from_slice(&bits.to_le_bytes());
        }
        Schema::Vector(inner, n) => {
            if !(2..=4).contains(n)
                || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
            {
                return Err("invalid vector schema".into());
            }
            let xs = v.as_array().ok_or("expected vector")?;
            if xs.len() != *n as usize {
                return Err("vector dimension mismatch".into());
            }
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Int => {
            let n = integer(v)?;
            let (sign, b) = n.to_bytes_le();
            out.push(match sign {
                Sign::NoSign => 0,
                Sign::Plus => 1,
                Sign::Minus => 2,
            });
            if sign == Sign::NoSign {
                raw(out, &[])
            } else {
                raw(out, &b)
            }
        }
        Schema::String => raw(out, v.as_str().ok_or("expected String")?.as_bytes()),
        Schema::Id => out.extend_from_slice(&identifier(v)?.to_le_bytes()),
        Schema::Enum(names) => {
            let s = v.as_str().ok_or("expected enum string")?;
            let index = names
                .iter()
                .position(|n| n == s)
                .ok_or("unknown enum variant")?;
            out.extend_from_slice(&(index as u32).to_le_bytes());
        }
        Schema::Record(fields) => {
            let obj = v.as_object().ok_or("expected record")?;
            if obj.len() != fields.len() {
                return Err("record field mismatch".into());
            }
            for (n, t) in fields {
                encode_value(
                    t,
                    obj.get(n).ok_or("missing record field")?,
                    out,
                    left,
                    depth + 1,
                    limits,
                )?;
            }
        }
        Schema::List(inner) => {
            let xs = v.as_array().ok_or("expected List")?;
            if xs.len() > *left {
                return Err("snapshot value limit exceeded".into());
            }
            count(out, xs.len());
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Option(inner) => {
            if let Ok(x) = tag(v, "Some") {
                out.push(1);
                encode_value(inner, x, out, left, depth + 1, limits)?;
            } else {
                if !tag(v, "None")?.is_null() {
                    return Err("invalid None".into());
                }
                out.push(0);
            }
        }
        Schema::Result(a, b) => {
            if let Ok(x) = tag(v, "Ok") {
                out.push(0);
                encode_value(a, x, out, left, depth + 1, limits)?;
            } else {
                out.push(1);
                encode_value(b, tag(v, "Err")?, out, left, depth + 1, limits)?;
            }
        }
    }
    if out.len() > limits.bytes {
        return Err("snapshot byte limit exceeded".into());
    }
    Ok(())
}
struct Reader<'a> {
    bytes: &'a [u8],
    at: usize,
    left: usize,
    limits: Limits,
}
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> R<&'a [u8]> {
        let end = self.at.checked_add(n).ok_or("snapshot length overflow")?;
        let b = self.bytes.get(self.at..end).ok_or("truncated snapshot")?;
        self.at = end;
        Ok(b)
    }
    fn byte(&mut self) -> R<u8> {
        Ok(self.take(1)?[0])
    }
    fn u32(&mut self) -> R<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn u64(&mut self) -> R<u64> {
        Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
    fn len(&mut self) -> R<usize> {
        usize::try_from(self.u64()?).map_err(|_| "snapshot length not addressable".into())
    }
    fn sequence(&mut self) -> R<usize> {
        let n = self.len()?;
        if n > self.left {
            return Err("snapshot value limit exceeded".into());
        }
        Ok(n)
    }
    fn raw(&mut self) -> R<&'a [u8]> {
        let n = self.len()?;
        self.take(n)
    }
    fn value(&mut self, t: &Schema, depth: usize) -> R<Value> {
        tick(&mut self.left, depth, self.limits)?;
        Ok(match t {
            Schema::Unit => Value::Null,
            Schema::Bool => match self.byte()? {
                0 => json!(false),
                1 => json!(true),
                _ => return Err("invalid Bool tag".into()),
            },
            Schema::U32 => json!(self.u32()?),
            Schema::U64 => json!(self.u64()?),
            Schema::I32 => json!(self.u32()? as i32),
            Schema::F32 => {
                let bits = self.u32()?;
                let f = f32::from_bits(bits);
                if f.is_finite() {
                    json!(f)
                } else {
                    json!({"F32Bits":bits})
                }
            }
            Schema::Vector(inner, n) => {
                if !(2..=4).contains(n)
                    || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
                {
                    return Err("invalid vector schema".into());
                }
                (0..*n)
                    .map(|_| self.value(inner, depth + 1))
                    .collect::<R<Vec<_>>>()?
                    .into()
            }
            Schema::Int => {
                let sign = self.byte()?;
                let bytes = self.raw()?;
                if bytes.len() > MAX_INT_BYTES {
                    return Err("snapshot Int exceeds size limit".into());
                }
                let sign = match sign {
                    0 if bytes.is_empty() => Sign::NoSign,
                    1 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Plus,
                    2 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Minus,
                    _ => return Err("noncanonical signed integer".into()),
                };
                json!({"Int":BigInt::from_bytes_le(sign,bytes).to_string()})
            }
            Schema::String => json!(std::str::from_utf8(self.raw()?).map_err(|_| "invalid UTF-8")?),
            Schema::Id => json!(format!(
                "{:032x}",
                u128::from_le_bytes(self.take(16)?.try_into().unwrap())
            )),
            Schema::Enum(names) => {
                json!(names.get(self.u32()? as usize).ok_or("invalid enum tag")?)
            }
            Schema::Record(fields) => {
                let mut obj = serde_json::Map::new();
                for (n, t) in fields {
                    obj.insert(n.clone(), self.value(t, depth + 1)?);
                }
                Value::Object(obj)
            }
            Schema::List(t) => {
                let n = self.sequence()?;
                let mut xs = Vec::new();
                for _ in 0..n {
                    xs.push(self.value(t, depth + 1)?);
                }
                Value::Array(xs)
            }
            Schema::Option(t) => match self.byte()? {
                0 => json!({"None":null}),
                1 => json!({"Some":self.value(t,depth+1)?}),
                _ => return Err("invalid Option tag".into()),
            },
            Schema::Result(a, b) => match self.byte()? {
                0 => json!({"Ok":self.value(a,depth+1)?}),
                1 => json!({"Err":self.value(b,depth+1)?}),
                _ => return Err("invalid Result tag".into()),
            },
        })
    }
}
fn event_order(e: &Event, version: u64, prior: Option<(u64, u64)>) -> R<()> {
    if e.commit == 0 || e.commit > version || prior.is_some_and(|p| p >= (e.commit, e.position)) {
        return Err("invalid snapshot event sequence".into());
    }
    Ok(())
}
pub fn encode(layout: &Layout, s: &Logical, limits: Limits) -> R<Vec<u8>> {
    if s.tables.len() != layout.roots.len() {
        return Err("snapshot root count mismatch".into());
    }
    let mut out = Vec::new();
    let mut left = limits.values;
    u64_bytes(&mut out, s.version);
    for (rows, (_, kt, vt)) in s.tables.iter().zip(&layout.roots) {
        if rows.len() > left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        count(&mut out, rows.len());
        let mut prior = None;
        for (k, v) in rows {
            if let Some(p) = prior {
                if compare(kt, p, k)? != Ordering::Less {
                    return Err("snapshot keys must be strictly ordered".into());
                }
            }
            encode_value(kt, k, &mut out, &mut left, 0, limits)?;
            encode_value(vt, v, &mut out, &mut left, 0, limits)?;
            prior = Some(k);
        }
    }
    count(&mut out, s.outbox.len());
    let mut prior = None;
    for e in &s.outbox {
        event_order(e, s.version, prior)?;
        let (_, t) = layout
            .events
            .get(e.channel)
            .ok_or("unknown event channel")?;
        u64_bytes(&mut out, e.commit);
        u64_bytes(&mut out, e.position);
        out.extend_from_slice(&(e.channel as u32).to_le_bytes());
        encode_value(t, &e.value, &mut out, &mut left, 0, limits)?;
        prior = Some((e.commit, e.position));
    }
    if HEADER
        .checked_add(out.len())
        .and_then(|n| n.checked_add(32))
        .is_none_or(|n| n > limits.bytes)
    {
        return Err("snapshot byte limit exceeded".into());
    }
    let mut bytes = Vec::new();
    bytes.extend_from_slice(MAGIC);
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&layout.program);
    bytes.extend_from_slice(&layout.schema);
    count(&mut bytes, out.len());
    bytes.extend_from_slice(&out);
    let digest = Sha256::digest(&bytes);
    bytes.extend_from_slice(&digest);
    Ok(bytes)
}
pub fn decode(layout: &Layout, bytes: &[u8], limits: Limits) -> R<Logical> {
    if bytes.len() > limits.bytes || bytes.len() < HEADER + 32 {
        return Err("snapshot byte length invalid".into());
    }
    if &bytes[..8] != MAGIC || bytes[8..12] != [1, 0, 1, 0] {
        return Err("snapshot format or semantics version mismatch".into());
    }
    if bytes[12..44] != layout.program || bytes[44..76] != layout.schema {
        return Err("snapshot program or schema identity mismatch".into());
    }
    let n = usize::try_from(u64::from_le_bytes(bytes[76..84].try_into().unwrap()))
        .map_err(|_| "snapshot length not addressable")?;
    if HEADER.checked_add(n).and_then(|v| v.checked_add(32)) != Some(bytes.len()) {
        return Err("snapshot payload length mismatch".into());
    }
    let end = bytes.len() - 32;
    if Sha256::digest(&bytes[..end]).as_slice() != &bytes[end..] {
        return Err("snapshot integrity check failed".into());
    }
    let mut r = Reader {
        bytes: &bytes[HEADER..end],
        at: 0,
        left: limits.values,
        limits,
    };
    let version = r.u64()?;
    let mut tables = vec![];
    for (_, kt, vt) in &layout.roots {
        let n = r.sequence()?;
        if n > r.left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        let mut rows: Vec<(Value, Value)> = vec![];
        for _ in 0..n {
            let k = r.value(kt, 0)?;
            let v = r.value(vt, 0)?;
            if let Some((prior, _)) = rows.last() {
                if compare(kt, prior, &k)? != Ordering::Less {
                    return Err("duplicate or unordered snapshot key".into());
                }
            }
            rows.push((k, v));
        }
        tables.push(rows);
    }
    let n = r.sequence()?;
    let mut outbox = vec![];
    let mut prior = None;
    for _ in 0..n {
        let commit = r.u64()?;
        let position = r.u64()?;
        let channel = r.u32()? as usize;
        let (_, t) = layout
            .events
            .get(channel)
            .ok_or("unknown snapshot event channel")?;
        let value = r.value(t, 0)?;
        let e = Event {
            commit,
            position,
            channel,
            value,
        };
        event_order(&e, version, prior)?;
        prior = Some((commit, position));
        outbox.push(e);
    }
    if r.at != r.bytes.len() {
        return Err("trailing snapshot payload".into());
    }
    Ok(Logical {
        version,
        tables,
        outbox,
    })
}

}
pub use portable::Limits as SnapshotLimits;
fn snapshot_layout()->portable::Layout{portable::Layout{program:[248, 162, 35, 111, 33, 221, 142, 208, 236, 67, 126, 20, 253, 225, 129, 51, 120, 20, 219, 8, 82, 190, 13, 158, 24, 211, 244, 72, 33, 151, 15, 82],schema:[25, 51, 42, 182, 190, 77, 138, 213, 99, 37, 162, 6, 160, 123, 99, 168, 218, 48, 21, 13, 197, 167, 238, 51, 123, 176, 66, 216, 5, 132, 214, 14],roots:vec![
("Rows".into(),portable::Schema::U64,portable::Schema::Record(vec![("amount".into(),portable::Schema::U64),("group".into(),portable::Schema::U64)])),
],events:vec![("seen".into(),portable::Schema::U64),
]}}
fn one_tag<'a>(v:&'a Json,_kind:&str)->Result<&'a serde_json::Map<String,Json>,String>{Ok(v.as_object().unwrap())}
fn read_0(v:&Json,d:usize)->Result<bool,String>{Ok(
v.as_bool().unwrap())}
fn write_0(v:&bool,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_1(v:&Json,d:usize)->Result<u64,String>{Ok(
v.as_u64().unwrap())}
fn write_1(v:&u64,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_2(v:&Json,d:usize)->Result<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c,String>{Ok(
{D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0})}
fn write_2(v:&D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c,d:usize)->Result<Json,String>{Ok(
Json::Null)}
fn read_3(v:&Json,d:usize)->Result<D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c,String>{Ok(
{let xs=v.as_array().unwrap();let mut tail=D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c::C0;for x in xs.iter().rev(){tail=D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c::C1(read_1(x,d+1)?,std::sync::Arc::new(tail));}tail})}
fn write_3(v:&D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c,d:usize)->Result<Json,String>{Ok(
{let mut cursor=v;let mut xs=vec![];loop{match cursor{D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c::C0=>break,D_6f0862aec0fbce772b94f4894b376af912c7dc16b48e98774fa0205c05e1859c::C1(x,tail)=>{xs.push(write_1(x,d+1)?);cursor=tail.as_ref();}}}Json::Array(xs)})}
fn read_4(v:&Json,d:usize)->Result<D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d,String>{Ok(
{let xs=v.as_array().unwrap();let mut tail=D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C0;for x in xs.iter().rev(){tail=D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C1(std::sync::Arc::new(read_7(x,d+1)?),std::sync::Arc::new(tail));}tail})}
fn write_4(v:&D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d,d:usize)->Result<Json,String>{Ok(
{let mut cursor=v;let mut xs=vec![];loop{match cursor{D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C0=>break,D_3942f6dbf5170775c1c863aa859f9f3a324e280f6528af9ae37367225ff80b7d::C1(x,tail)=>{xs.push(write_7(x,d+1)?);cursor=tail.as_ref();}}}Json::Array(xs)})}
fn read_5(v:&Json,d:usize)->Result<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b,String>{Ok(
{let text=v.as_str().unwrap();match text{"Error.Failed"=>D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0,_=>unreachable!("caller enum precondition")}})}
fn write_5(v:&D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b,d:usize)->Result<Json,String>{Ok(
match v{D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0=>json!("Error.Failed"),})}
fn read_6(v:&Json,d:usize)->Result<D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909,String>{Ok(
{let xs=v.as_object().unwrap();D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909::C0(read_1(xs.get("zero").unwrap(),d+1)?,read_1(xs.get("one").unwrap(),d+1)?,read_1(xs.get("other").unwrap(),d+1)?,read_1(xs.get("count").unwrap(),d+1)?)})}
fn write_6(v:&D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909,d:usize)->Result<Json,String>{Ok(
{let D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909::C0(b0,b1,b2,b3)=v;json!({"zero":write_1(&b0,d+1)?,"one":write_1(&b1,d+1)?,"other":write_1(&b2,d+1)?,"count":write_1(&b3,d+1)?})})}
fn read_7(v:&Json,d:usize)->Result<D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f,String>{Ok(
{let xs=v.as_object().unwrap();D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(read_1(xs.get("amount").unwrap(),d+1)?,read_1(xs.get("group").unwrap(),d+1)?)})}
fn write_7(v:&D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f,d:usize)->Result<Json,String>{Ok(
{let D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(b0,b1)=v;json!({"amount":write_1(&b0,d+1)?,"group":write_1(&b1,d+1)?})})}
fn read_8(v:&Json,d:usize)->Result<D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f::C1(std::sync::Arc::new(read_7(x,d+1)?))}else{D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f::C0}})}
fn write_8(v:&D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f,d:usize)->Result<Json,String>{Ok(
match v{D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f::C0=>json!({"None":null}),D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f::C1(x)=>json!({"Some":write_7(x,d+1)?})})}
fn read_9(v:&Json,d:usize)->Result<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f,String>{Ok(
{let xs=one_tag(v,"Result")?;if let Some(x)=xs.get("Ok"){D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::new(read_2(x,d+1)?))}else{let x=xs.get("Err").unwrap();D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::new(read_5(x,d+1)?))}})}
fn write_9(v:&D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f,d:usize)->Result<Json,String>{Ok(
match v{D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(x)=>json!({"Ok":write_2(x,d+1)?}),D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(x)=>json!({"Err":write_5(x,d+1)?})})}
fn logical_from_tables(tables:&[Vec<(Json,Json)>])->Result<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09,String>{if tables.len()!=1{return Err("representation table count mismatch".into())}
let rows=&tables[0];let mut root0=D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0;for (key,row) in rows.iter().rev(){root0=D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(read_1(key,0)?,std::sync::Arc::new(read_7(row,0)?),std::sync::Arc::new(root0));}
Ok(D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::new(root0)))}
fn logical_tables(state:&D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09)->Result<Vec<Vec<(Json,Json)>>,String>{let D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(r0)=state;
let mut rows0=vec![];let mut cursor=r0.as_ref();loop{match cursor{D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0=>break,D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(key,value,tail)=>{rows0.push((write_1(key,0)?,write_7(value,0)?));cursor=tail.as_ref();}}}
Ok(vec![rows0])}
fn logical_events(events:&D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7)->Result<Vec<(usize,Json)>,String>{let mut cursor=events;let mut out=vec![];loop{match cursor{D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0=>break,D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C1(event,tail)=>{let value=match event.as_ref(){
D_d762bb1af249ac8e4d79ab5c82bc7e5d6e1a8239b27bfd12dbfeb76c3db794a1::C0(value)=>(0,write_1(value,0)?),
};out.push(value);cursor=tail.as_ref();}}}Ok(out)}
pub use portable::Event;
pub struct Outcome<T>{pub result:T,pub committed:bool,pub version:u64,pub events:Vec<Event>}
pub struct OutcomeView<'a,T>{pub result:T,pub committed:bool,pub version:u64,pub events:&'a[Event]}
impl<T> OutcomeView<'_,T>{pub fn into_owned(self)->Outcome<T>{Outcome{result:self.result,committed:self.committed,version:self.version,events:self.events.to_vec()}}}
pub struct State{physical:D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,version:u64,outbox:Vec<portable::Event>,layout:portable::Layout}
impl State{
// CALLER CONTRACT: arguments must have the declared types and canonical values.
// No runtime type validation. Malformed input may panic, trap or corrupt state.
pub fn new()->Result<Self,String>{let logical=D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::new(D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0));Ok(Self{physical:f_1ac082f699bf8e068df795bd7cd975c1c5ed13616fb850ecdfe304d187585d29(&logical),version:0,outbox:vec![],layout:snapshot_layout()})}
pub fn restore(bytes:&[u8])->Result<Self,String>{let layout=snapshot_layout();let saved=portable::decode(&layout,bytes,SnapshotLimits::default())?;let logical=logical_from_tables(&saved.tables)?;Ok(Self{physical:f_1ac082f699bf8e068df795bd7cd975c1c5ed13616fb850ecdfe304d187585d29(&logical),version:saved.version,outbox:saved.outbox,layout})}
pub fn checkpoint(&self)->Result<Vec<u8>,String>{let logical=f_f137ad14880d722826ba61d21bb95fd94e16e99431673daf2aefe85791023a26(&(self.physical));portable::encode(&self.layout,&portable::Logical{version:self.version,tables:logical_tables(&logical)?,outbox:self.outbox.clone()},SnapshotLimits::default())}
pub fn version(&self)->u64{self.version}
pub fn outbox_json(&self)->Json{Json::Array(self.outbox.iter().map(|e|json!({"commit":e.commit,"position":e.position,"channel":self.layout.events[e.channel].0,"value":e.value})).collect())}
pub fn acknowledge_through(&mut self,commit:u64,position:u64){self.outbox.retain(|e|(e.commit,e.position)>(commit,position));}
pub fn query_groups(&self,)->D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909{q_f3dbaa07612bf8a8c58b8550b9dba0264d6d0c216afbeaf38b8dccf2043d2c59(&(self.physical),self.version)}
pub fn query_get(&self,a0:u64)->D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f{q_33456c6b9ef6209c75a1f19999587acaaff98b6f47024a047476d87bf719f57c(&(self.physical),self.version,a0)}
pub fn invoke_view_put(&mut self,a0:u64,a1:u64,a2:u64,a3:bool)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=f_078801970e258a449094e4f1a34a7c597cf9efaed0ebf76d275af684278a4182(&(self.physical),self.version,a0,a1,a2,a3);let observed=f_7597c22aa4906c1f171628b86c5e4a2fbebc3664346581bcbe807421448414b9(&(executed));let next=f_ea0fea581c89e9160d21dba6ef54626f2630d3df039f15aff1c821cac5fe883e(&(executed));
let(result,committed,version,events)=match &observed{D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_erase(&mut self,a0:u64,a1:bool)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=f_8bbd18dbb03bbbe491373f380012e93500119152952f138315445682c93df40f(&(self.physical),self.version,a0,a1);let observed=f_7597c22aa4906c1f171628b86c5e4a2fbebc3664346581bcbe807421448414b9(&(executed));let next=f_ea0fea581c89e9160d21dba6ef54626f2630d3df039f15aff1c821cac5fe883e(&(executed));
let(result,committed,version,events)=match &observed{D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_groups(&mut self,)->Result<OutcomeView<'_,D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909>,String>{
let result=q_f3dbaa07612bf8a8c58b8550b9dba0264d6d0c216afbeaf38b8dccf2043d2c59(&(self.physical),self.version);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_view_get(&mut self,a0:u64)->Result<OutcomeView<'_,D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f>,String>{
let result=q_33456c6b9ef6209c75a1f19999587acaaff98b6f47024a047476d87bf719f57c(&(self.physical),self.version,a0);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_json(&mut self,name:&str,args:&Json)->Result<Json,String>{match name{
"put"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_1(&xs[1],0)?;
let a2=read_1(&xs[2],0)?;
let a3=read_0(&xs[3],0)?;
let executed=f_078801970e258a449094e4f1a34a7c597cf9efaed0ebf76d275af684278a4182(&(self.physical),self.version,a0,a1,a2,a3);
let observed=f_7597c22aa4906c1f171628b86c5e4a2fbebc3664346581bcbe807421448414b9(&(executed));let next=f_ea0fea581c89e9160d21dba6ef54626f2630d3df039f15aff1c821cac5fe883e(&(executed));let(reply,committed,version,events)=match &observed{D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_9(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"erase"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_0(&xs[1],0)?;
let executed=f_8bbd18dbb03bbbe491373f380012e93500119152952f138315445682c93df40f(&(self.physical),self.version,a0,a1);
let observed=f_7597c22aa4906c1f171628b86c5e4a2fbebc3664346581bcbe807421448414b9(&(executed));let next=f_ea0fea581c89e9160d21dba6ef54626f2630d3df039f15aff1c821cac5fe883e(&(executed));let(reply,committed,version,events)=match &observed{D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_9(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"groups"=>{let xs=args.as_array().unwrap();
let reply=q_f3dbaa07612bf8a8c58b8550b9dba0264d6d0c216afbeaf38b8dccf2043d2c59(&(self.physical),self.version);let result=write_6(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
"get"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let reply=q_33456c6b9ef6209c75a1f19999587acaaff98b6f47024a047476d87bf719f57c(&(self.physical),self.version,a0);let result=write_8(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
_=>Err(format!("unknown action {name}"))}}}
