// ink-definition-rust-v1: checked bodies; Rust/backend are trusted.
#![allow(non_camel_case_types, non_snake_case, non_upper_case_globals, dead_code, unused_variables, unused_parens, unused_unsafe, improper_ctypes_definitions)]
fn d_00ac7e7cd0bc0ffe4cfb5c0152f80e39b767a57a16994cd72f8e4dae4391d71e(v0: &D_00c7f2c2f62a904dcb3deb3bf75cd1205869688513d42b2c7cc3954f74d91e30) -> D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351 { match v0 { D_00c7f2c2f62a904dcb3deb3bf75cd1205869688513d42b2c7cc3954f74d91e30::C0(v1,v2) => { (v1.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_00c7f2c2f62a904dcb3deb3bf75cd1205869688513d42b2c7cc3954f74d91e30 { C0(std::sync::Arc<D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351>,std::sync::Arc<D_a33fb21fa98f5296d71ff12fbda12456f198d0210773de677fdaa687f91b7393>) }
fn d_0ee743a0ab5550a7e4f886fe6a049d5d611588bcbcb3aa38832e3e8496fedeba(v3: &D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351,v4: u64,v5: u64,v6: bool) -> D_f5e573856b2863d790347b60e8f7df9bff798bc41392dbfba14079a236d4cd15 { D_f5e573856b2863d790347b60e8f7df9bff798bc41392dbfba14079a236d4cd15::C0(std::sync::Arc::new(d_d71435ad3bfe23b787260cc19f0a628e39428a45065153e66058176bf5602402(v3)),std::sync::Arc::new(d_9793770332df3138c3b012e84779ef25eb8cf793a4af0d4c7cd56f0d7ef85b7b(&(d_7f545b4f2164568b6108b56e37fbd551317029cc2531ad7eb19a551e557bcbfd(v3)),v4,v5,v6))) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026 { C0,C1(std::sync::Arc<D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5>,std::sync::Arc<D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026>) }
impl D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8 { C0,C1(u64,std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>) }
impl D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333 { C0(std::sync::Arc<D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0>) }
fn d_2620718ccbe9b25373b24bbf81c9b02b150bb6d1a96ff326d544d5d226565846(v7: &D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351,v8: u64,v9: u64,v10: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v11: bool) -> D_f5e573856b2863d790347b60e8f7df9bff798bc41392dbfba14079a236d4cd15 { D_f5e573856b2863d790347b60e8f7df9bff798bc41392dbfba14079a236d4cd15::C0(std::sync::Arc::new(d_d71435ad3bfe23b787260cc19f0a628e39428a45065153e66058176bf5602402(v7)),std::sync::Arc::new(d_f9144419d869e045d8833db100400fb668918bb11720d78b0b7be3d9daa6197f(&(d_7f545b4f2164568b6108b56e37fbd551317029cc2531ad7eb19a551e557bcbfd(v7)),v8,v9,v10,v11))) }
fn d_2fb2a5ea1a64a69afbaa25635d0d7fec1ac83057e15112811da15fedf24131b4(v12: &D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026,v13: u64) -> D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3 { match v12 { D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C0 => { D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C0 },D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C1(v15,v16) => { if ((v13) == (0u64)) { D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C1(std::sync::Arc::clone(v15)) } else { d_2fb2a5ea1a64a69afbaa25635d0d7fec1ac83057e15112811da15fedf24131b4(v16.as_ref(),(((v13).wrapping_sub(1u64)) & (4294967295u64))) } } } }
fn d_3027189a800129e578400787a58af9a0f869d870318e640ea8c20e92a4716ed3(v17: &D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351,v18: u64) -> D_eda088d5719bbdf20cbbe19303a4d6e6a523005313bfb8e7c854630d6ded9af1 { match v17 { D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351::C0(v19,v20) => { D_eda088d5719bbdf20cbbe19303a4d6e6a523005313bfb8e7c854630d6ded9af1::C0(std::sync::Arc::new((v17).clone()),std::sync::Arc::new(D_c1aefe13ad2329f4c7f817439d8190dae6c52af2b31ce3accc8371898e55432b::C0(std::sync::Arc::clone(v20),false,v18,std::sync::Arc::new(D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(std::sync::Arc::clone(v19))),std::sync::Arc::clone({static v21:std::sync::OnceLock<std::sync::Arc<D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44>>=std::sync::OnceLock::new();v21.get_or_init(||std::sync::Arc::new(D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44::C0))})))) } } }
fn d_31fe6602e4ee7a5db178e53dde982c0865df1891ac579afcb78a04557ac219dc(v22: &D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026,v23: &D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5) -> D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026 { match &(D_f60837a19af62184a4c3294896a2a4e927493474415026fc0ba068680f1107fb::C0(d_8e18927e0da738430b7c88025d7acd72a7da7d1acfc17e1cc31ebc2fbe86d7fc(v22))) { D_f60837a19af62184a4c3294896a2a4e927493474415026fc0ba068680f1107fb::C0(v24) => { match &(D_b21cb06bcd029ddfdbd04d843333cba7b10439be3eaa89ed539f15b9ecbb4335::C0(std::sync::Arc::new(D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(std::sync::Arc::new(d_686c91f949b3a6aba2f76fe5ad5ae235d46af7ae012cd5dff908fa47b20d4bd8(v22,v23)),*v24,false)))) { D_b21cb06bcd029ddfdbd04d843333cba7b10439be3eaa89ed539f15b9ecbb4335::C0(v25) => { match &(D_b21cb06bcd029ddfdbd04d843333cba7b10439be3eaa89ed539f15b9ecbb4335::C0(std::sync::Arc::new(d_5c6eb647835e558fd57c76b93e67e2aa9372a2b72014f439132d94d1abd27633(&(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(false,std::sync::Arc::clone({static v31:std::sync::OnceLock<std::sync::Arc<D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e>>=std::sync::OnceLock::new();v31.get_or_init(||std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(false,std::sync::Arc::clone({static v30:std::sync::OnceLock<std::sync::Arc<D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e>>=std::sync::OnceLock::new();v30.get_or_init(||std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(false,std::sync::Arc::clone({static v29:std::sync::OnceLock<std::sync::Arc<D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e>>=std::sync::OnceLock::new();v29.get_or_init(||std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(false,std::sync::Arc::clone({static v28:std::sync::OnceLock<std::sync::Arc<D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e>>=std::sync::OnceLock::new();v28.get_or_init(||std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(false,std::sync::Arc::clone({static v27:std::sync::OnceLock<std::sync::Arc<D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e>>=std::sync::OnceLock::new();v27.get_or_init(||std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(true,std::sync::Arc::clone({static v26:std::sync::OnceLock<std::sync::Arc<D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e>>=std::sync::OnceLock::new();v26.get_or_init(||std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C0))}))))}))))}))))}))))}))))}))),32u64,0u64,v25.as_ref())))) { D_b21cb06bcd029ddfdbd04d843333cba7b10439be3eaa89ed539f15b9ecbb4335::C0(v33) => { match v33.as_ref() { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v34,v35,v36) => { (v34.as_ref()).clone() } } } } } } } } }
fn d_361b33126df4c584aa0e1127c93c1ebf0ef95d5dc1359d5ff7d7115a4076be7c(v37: &D_f5e573856b2863d790347b60e8f7df9bff798bc41392dbfba14079a236d4cd15) -> D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351 { match v37 { D_f5e573856b2863d790347b60e8f7df9bff798bc41392dbfba14079a236d4cd15::C0(v38,v39) => { d_75f341ca2497983f1838cab25136b99f8fe8acc7635cd3cf2fd220390c1b722e(v38.as_ref(),v39.as_ref()) } } }
fn d_3897cfb53d05bdc45eda27662b9029e17686b836d9ff19ff7b2a2bc9625bb2ba(v40: &D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0,v41: u64) -> bool { match &(d_e991858a86d4b1c03de257d3ab316d2a3fa3ed38265965de647840dfe983ceb3(v40,v41)) { D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3::C0 => { false },D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3::C1(v42) => { true } } }
fn d_39979ea376d8e234081b1e1ddfa12d39266d92193413486fc9470727d1c9e574(v43: &D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5,v44: &D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5) -> bool { if ((match v43 { D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(v45,v46) => { *v46 } }) < (match v44 { D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(v47,v48) => { *v48 } })) { true } else { if ((match v43 { D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(v49,v50) => { *v50 } }) == (match v44 { D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(v51,v52) => { *v52 } })) { ((match v43 { D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(v53,v54) => { *v53 } }) < (match v44 { D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(v55,v56) => { *v55 } })) } else { false } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3 { C0,C1(std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44 { C0,C1(std::sync::Arc<D_b62e83ea6ba1bb4c8818da50869e95eb2e3541a4fd95e5251c2d6b998acfeadb>,std::sync::Arc<D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44>) }
impl D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_56751de214de1c672c34b9dd9fbc0544e62403208dc4f67373077a546df1c8ba(v57: &D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026) -> D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026 { match &(D_f60837a19af62184a4c3294896a2a4e927493474415026fc0ba068680f1107fb::C0(d_8e18927e0da738430b7c88025d7acd72a7da7d1acfc17e1cc31ebc2fbe86d7fc(v57))) { D_f60837a19af62184a4c3294896a2a4e927493474415026fc0ba068680f1107fb::C0(v58) => { match &(D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0::C0(std::sync::Arc::new(match &(d_2fb2a5ea1a64a69afbaa25635d0d7fec1ac83057e15112811da15fedf24131b4(v57,(((*v58).wrapping_sub(1u64)) & (4294967295u64)))) { D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C0 => { D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(0u64,0u64) },D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C1(v60) => { (v60.as_ref()).clone() } }))) { D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0::C0(v61) => { match &(D_b21cb06bcd029ddfdbd04d843333cba7b10439be3eaa89ed539f15b9ecbb4335::C0(std::sync::Arc::new(D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(std::sync::Arc::new(d_930717135a9d182c00421292ed66c95b9386dc498e2f2002aa6b92d74a2dec35(&(d_ebe560e0ad86af6a9330acbaf2d89bc9cc998a9fbcd90d35dc3a82145bf27b9d(v57,0u64,v61.as_ref())))),0u64,false)))) { D_b21cb06bcd029ddfdbd04d843333cba7b10439be3eaa89ed539f15b9ecbb4335::C0(v62) => { match &(D_b21cb06bcd029ddfdbd04d843333cba7b10439be3eaa89ed539f15b9ecbb4335::C0(std::sync::Arc::new(d_7d455a7a3f8b9a0488aeb8214ace13408bd790b314b823e14d7c192792fe4f67(&(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(false,std::sync::Arc::clone({static v68:std::sync::OnceLock<std::sync::Arc<D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e>>=std::sync::OnceLock::new();v68.get_or_init(||std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(false,std::sync::Arc::clone({static v67:std::sync::OnceLock<std::sync::Arc<D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e>>=std::sync::OnceLock::new();v67.get_or_init(||std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(false,std::sync::Arc::clone({static v66:std::sync::OnceLock<std::sync::Arc<D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e>>=std::sync::OnceLock::new();v66.get_or_init(||std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(false,std::sync::Arc::clone({static v65:std::sync::OnceLock<std::sync::Arc<D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e>>=std::sync::OnceLock::new();v65.get_or_init(||std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(false,std::sync::Arc::clone({static v64:std::sync::OnceLock<std::sync::Arc<D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e>>=std::sync::OnceLock::new();v64.get_or_init(||std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(true,std::sync::Arc::clone({static v63:std::sync::OnceLock<std::sync::Arc<D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e>>=std::sync::OnceLock::new();v63.get_or_init(||std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C0))}))))}))))}))))}))))}))))}))),32u64,0u64,v62.as_ref())))) { D_b21cb06bcd029ddfdbd04d843333cba7b10439be3eaa89ed539f15b9ecbb4335::C0(v70) => { match v70.as_ref() { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v71,v72,v73) => { (v71.as_ref()).clone() } } } } } } } } } } }
fn d_5b2b561b43fbc9fc3b1c470f965430122b532b97f0581c7596cfdaaa39f2da33(v74: &D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333) -> D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351 { match v74 { D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(v75) => { D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351::C0(std::sync::Arc::clone(v75),std::sync::Arc::new(match &(d_e991858a86d4b1c03de257d3ab316d2a3fa3ed38265965de647840dfe983ceb3(v75.as_ref(),0u64)) { D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3::C0 => { D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3::C0 },D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3::C1(v77) => { D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3::C1(std::sync::Arc::new(d_757ed99d59f0a130d21450582e38c9232fce5eac7260c76c62c9b0a05feb08e8(v77.as_ref()))) } })) } } }
fn d_5c6eb647835e558fd57c76b93e67e2aa9372a2b72014f439132d94d1abd27633(v78: &D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e,v79: u64,v80: u64,v81: &D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194) -> D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194 { if if ((v79) == (0u64)) { true } else { if match v81 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v82,v83,v84) => { *v84 } } { true } else { ((match v81 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v85,v86,v87) => { *v86 } }) == (0u64)) } } { (v81).clone() } else { match v78 { D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C0 => { (v81).clone() },D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(v88,v89) => { if *v88 { match &(D_b21cb06bcd029ddfdbd04d843333cba7b10439be3eaa89ed539f15b9ecbb4335::C0(std::sync::Arc::new(d_5c6eb647835e558fd57c76b93e67e2aa9372a2b72014f439132d94d1abd27633(v89.as_ref(),(v79).checked_div(2u64).unwrap_or(0),(((v80).wrapping_add((v79).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_5c6eb647835e558fd57c76b93e67e2aa9372a2b72014f439132d94d1abd27633(v89.as_ref(),(v79).checked_div(2u64).unwrap_or(0),v80,v81)))))) { D_b21cb06bcd029ddfdbd04d843333cba7b10439be3eaa89ed539f15b9ecbb4335::C0(v90) => { if if match v90.as_ref() { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v91,v92,v93) => { *v93 } } { true } else { ((match v90.as_ref() { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v94,v95,v96) => { *v95 } }) == (0u64)) } { (v90.as_ref()).clone() } else { d_794d113331ae340cc36cbed1fe9f659dc1fc073363663d4baa0bf18478a3a8cc(v90.as_ref()) } } } } else { d_5c6eb647835e558fd57c76b93e67e2aa9372a2b72014f439132d94d1abd27633(v89.as_ref(),(v79).checked_div(2u64).unwrap_or(0),(((v80).wrapping_add((v79).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_5c6eb647835e558fd57c76b93e67e2aa9372a2b72014f439132d94d1abd27633(v89.as_ref(),(v79).checked_div(2u64).unwrap_or(0),v80,v81))) } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_65c64225237a0e23811c934f9c65fa43f3c929ad11e29457eb9119eb219d8346 { C0 }
impl D_65c64225237a0e23811c934f9c65fa43f3c929ad11e29457eb9119eb219d8346{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_65c64225237a0e23811c934f9c65fa43f3c929ad11e29457eb9119eb219d8346{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_664e2e3419a2d16444c698a16774ab3ab53e7431a3ac8d6063618106e6d6f985(v97: &D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0,v98: u64) -> D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0 { match v97 { D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C0 => { D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C0 },D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C1(v100,v101,v102) => { if ((v98) == (*v100)) { d_664e2e3419a2d16444c698a16774ab3ab53e7431a3ac8d6063618106e6d6f985(v102.as_ref(),v98) } else { D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C1(*v100,std::sync::Arc::clone(v101),std::sync::Arc::new(d_664e2e3419a2d16444c698a16774ab3ab53e7431a3ac8d6063618106e6d6f985(v102.as_ref(),v98))) } } } }
fn d_686c91f949b3a6aba2f76fe5ad5ae235d46af7ae012cd5dff908fa47b20d4bd8(v103: &D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026,v104: &D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5) -> D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026 { match v103 { D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C0 => { D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C1(std::sync::Arc::new((v104).clone()),std::sync::Arc::clone({static v105:std::sync::OnceLock<std::sync::Arc<D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026>>=std::sync::OnceLock::new();v105.get_or_init(||std::sync::Arc::new(D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C0))})) },D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C1(v106,v107) => { D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C1(std::sync::Arc::clone(v106),std::sync::Arc::new(d_686c91f949b3a6aba2f76fe5ad5ae235d46af7ae012cd5dff908fa47b20d4bd8(v107.as_ref(),v104))) } } }
fn d_695ca14e25e5f08ca1404d5f405afb04d8407218c3af53a6ecb4f59e69ca33bd(v108: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v109: u64) -> D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8 { match v108 { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 => { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v109,std::sync::Arc::clone({static v110:std::sync::OnceLock<std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>>=std::sync::OnceLock::new();v110.get_or_init(||std::sync::Arc::new(D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0))})) },D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v111,v112) => { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(*v111,std::sync::Arc::new(d_695ca14e25e5f08ca1404d5f405afb04d8407218c3af53a6ecb4f59e69ca33bd(v112.as_ref(),v109))) } } }
fn d_6c6705e9a22bbd28f5b80f85716c88932a771750175ffec06db1eb9f8bf8477f(v113: &D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e,v114: u64,v115: u64,v116: &D_7ce0fdfaec5607097d66c8b8d679d2f9427c49a7502f4d4f2ebf9398a3906a61) -> D_7ce0fdfaec5607097d66c8b8d679d2f9427c49a7502f4d4f2ebf9398a3906a61 { if if ((v114) == (0u64)) { true } else { ((d_8e18927e0da738430b7c88025d7acd72a7da7d1acfc17e1cc31ebc2fbe86d7fc(&(match v116 { D_7ce0fdfaec5607097d66c8b8d679d2f9427c49a7502f4d4f2ebf9398a3906a61::C0(v117,v118) => { (v117.as_ref()).clone() } }))) == (0u64)) } { (v116).clone() } else { match v113 { D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C0 => { (v116).clone() },D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(v119,v120) => { if *v119 { match &(D_d9c8ddd7dd81d151944950e1acb87c3ab6bb9acc6ea964b4f19493c203956945::C0(std::sync::Arc::new(d_6c6705e9a22bbd28f5b80f85716c88932a771750175ffec06db1eb9f8bf8477f(v120.as_ref(),(v114).checked_div(2u64).unwrap_or(0),(((v115).wrapping_add((v114).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_6c6705e9a22bbd28f5b80f85716c88932a771750175ffec06db1eb9f8bf8477f(v120.as_ref(),(v114).checked_div(2u64).unwrap_or(0),v115,v116)))))) { D_d9c8ddd7dd81d151944950e1acb87c3ab6bb9acc6ea964b4f19493c203956945::C0(v121) => { if ((d_8e18927e0da738430b7c88025d7acd72a7da7d1acfc17e1cc31ebc2fbe86d7fc(&(match v121.as_ref() { D_7ce0fdfaec5607097d66c8b8d679d2f9427c49a7502f4d4f2ebf9398a3906a61::C0(v122,v123) => { (v122.as_ref()).clone() } }))) == (0u64)) { (v121.as_ref()).clone() } else { d_b49ff9b95a5c7163aba6ad15baf92896af132384165b93740839b8b0178da27f(v121.as_ref()) } } } } else { d_6c6705e9a22bbd28f5b80f85716c88932a771750175ffec06db1eb9f8bf8477f(v120.as_ref(),(v114).checked_div(2u64).unwrap_or(0),(((v115).wrapping_add((v114).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_6c6705e9a22bbd28f5b80f85716c88932a771750175ffec06db1eb9f8bf8477f(v120.as_ref(),(v114).checked_div(2u64).unwrap_or(0),v115,v116))) } } } } }
fn d_74ffd12a795b8b93feb4d82f843cf537d782c035b9310be9b913da8810e741a9(v124: &D_9fc4d638add12aee3a7502be8d258ed591363b7b572c6a438f6ef62deaac2376) -> D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e { match v124 { D_9fc4d638add12aee3a7502be8d258ed591363b7b572c6a438f6ef62deaac2376::C0 => { D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C0 },D_9fc4d638add12aee3a7502be8d258ed591363b7b572c6a438f6ef62deaac2376::C1(v126) => { D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (1u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (2u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (4u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (8u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (16u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (32u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (64u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (128u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (256u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (512u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (1024u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (2048u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (4096u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (8192u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (16384u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (32768u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (65536u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (131072u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (262144u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (524288u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (1048576u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (2097152u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (4194304u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (8388608u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (16777216u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (33554432u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (67108864u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (134217728u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (268435456u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (536870912u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (1073741824u64))) != (0u64)),std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(((((*v126) & (2147483648u64))) != (0u64)),std::sync::Arc::clone({static v127:std::sync::OnceLock<std::sync::Arc<D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e>>=std::sync::OnceLock::new();v127.get_or_init(||std::sync::Arc::new(D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C0))})))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) } } }
fn d_757ed99d59f0a130d21450582e38c9232fce5eac7260c76c62c9b0a05feb08e8(v128: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8) -> D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8 { match &(D_d9c8ddd7dd81d151944950e1acb87c3ab6bb9acc6ea964b4f19493c203956945::C0(std::sync::Arc::new(D_7ce0fdfaec5607097d66c8b8d679d2f9427c49a7502f4d4f2ebf9398a3906a61::C0(std::sync::Arc::new(d_d0fc7b7b67962970fb17711732afbaadc77896f1a06373f8d760999b4581a809(v128)),std::sync::Arc::clone({static v129:std::sync::OnceLock<std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>>=std::sync::OnceLock::new();v129.get_or_init(||std::sync::Arc::new(D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0))}))))) { D_d9c8ddd7dd81d151944950e1acb87c3ab6bb9acc6ea964b4f19493c203956945::C0(v130) => { match &(D_d9c8ddd7dd81d151944950e1acb87c3ab6bb9acc6ea964b4f19493c203956945::C0(std::sync::Arc::new(d_6c6705e9a22bbd28f5b80f85716c88932a771750175ffec06db1eb9f8bf8477f(&(d_74ffd12a795b8b93feb4d82f843cf537d782c035b9310be9b913da8810e741a9(&(if ((d_ce8322edd9fc3ce748d4118b3046705cc52d181bf064088b3ddf7a4056957384(v128)) == (0u64)) { D_9fc4d638add12aee3a7502be8d258ed591363b7b572c6a438f6ef62deaac2376::C0 } else { D_9fc4d638add12aee3a7502be8d258ed591363b7b572c6a438f6ef62deaac2376::C1(d_ce8322edd9fc3ce748d4118b3046705cc52d181bf064088b3ddf7a4056957384(v128)) }))),d_ce8322edd9fc3ce748d4118b3046705cc52d181bf064088b3ddf7a4056957384(v128),0u64,v130.as_ref())))) { D_d9c8ddd7dd81d151944950e1acb87c3ab6bb9acc6ea964b4f19493c203956945::C0(v132) => { match v132.as_ref() { D_7ce0fdfaec5607097d66c8b8d679d2f9427c49a7502f4d4f2ebf9398a3906a61::C0(v133,v134) => { (v134.as_ref()).clone() } } } } } } }
fn d_75f341ca2497983f1838cab25136b99f8fe8acc7635cd3cf2fd220390c1b722e(v135: &D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3,v136: &D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef) -> D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351 { match v136 { D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C0(v137,v138,v139,v140,v141) => { if *v138 { d_5b2b561b43fbc9fc3b1c470f965430122b532b97f0581c7596cfdaaa39f2da33(v140.as_ref()) } else { match v140.as_ref() { D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(v142) => { D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351::C0(std::sync::Arc::clone(v142),std::sync::Arc::new((v135).clone())) } } } },D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C1(v143,v144,v145) => { match v145.as_ref() { D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(v146) => { D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351::C0(std::sync::Arc::clone(v146),std::sync::Arc::new((v135).clone())) } } } } }
fn d_794d113331ae340cc36cbed1fe9f659dc1fc073363663d4baa0bf18478a3a8cc(v147: &D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194) -> D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194 { match &(D_f60837a19af62184a4c3294896a2a4e927493474415026fc0ba068680f1107fb::C0(if ((2u64) == (0u64)) { 0u64 } else { ((((match v147 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v148,v149,v150) => { *v149 } }).wrapping_sub(1u64)) & (4294967295u64))).checked_div(2u64).unwrap_or(0) })) { D_f60837a19af62184a4c3294896a2a4e927493474415026fc0ba068680f1107fb::C0(v151) => { match &(D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0::C0(std::sync::Arc::new(match &(d_2fb2a5ea1a64a69afbaa25635d0d7fec1ac83057e15112811da15fedf24131b4(&(match v147 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v152,v153,v154) => { (v152.as_ref()).clone() } }),match v147 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v155,v156,v157) => { *v156 } })) { D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C0 => { D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(0u64,0u64) },D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C1(v159) => { (v159.as_ref()).clone() } }))) { D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0::C0(v160) => { match &(D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0::C0(std::sync::Arc::new(match &(d_2fb2a5ea1a64a69afbaa25635d0d7fec1ac83057e15112811da15fedf24131b4(&(match v147 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v161,v162,v163) => { (v161.as_ref()).clone() } }),*v151)) { D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C0 => { D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(0u64,0u64) },D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C1(v165) => { (v165.as_ref()).clone() } }))) { D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0::C0(v166) => { if d_39979ea376d8e234081b1e1ddfa12d39266d92193413486fc9470727d1c9e574(v160.as_ref(),v166.as_ref()) { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(std::sync::Arc::new(match &(d_2fb2a5ea1a64a69afbaa25635d0d7fec1ac83057e15112811da15fedf24131b4(&(match v147 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v167,v168,v169) => { (v167.as_ref()).clone() } }),match v147 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v170,v171,v172) => { *v171 } })) { D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C0 => { match v147 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v173,v174,v175) => { (v173.as_ref()).clone() } } },D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C1(v176) => { match &(d_2fb2a5ea1a64a69afbaa25635d0d7fec1ac83057e15112811da15fedf24131b4(&(match v147 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v177,v178,v179) => { (v177.as_ref()).clone() } }),*v151)) { D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C0 => { match v147 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v180,v181,v182) => { (v180.as_ref()).clone() } } },D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C1(v183) => { d_ebe560e0ad86af6a9330acbaf2d89bc9cc998a9fbcd90d35dc3a82145bf27b9d(&(d_ebe560e0ad86af6a9330acbaf2d89bc9cc998a9fbcd90d35dc3a82145bf27b9d(&(match v147 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v184,v185,v186) => { (v184.as_ref()).clone() } }),match v147 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v187,v188,v189) => { *v188 } },v183.as_ref())),*v151,v176.as_ref()) } } } }),*v151,false) } else { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(std::sync::Arc::new(match v147 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v190,v191,v192) => { (v190.as_ref()).clone() } }),match v147 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v193,v194,v195) => { *v194 } },true) } } } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef { C0(std::sync::Arc<D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d>,bool,u64,std::sync::Arc<D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333>,std::sync::Arc<D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44>),C1(u64,u64,std::sync::Arc<D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_7ce0fdfaec5607097d66c8b8d679d2f9427c49a7502f4d4f2ebf9398a3906a61 { C0(std::sync::Arc<D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026>,std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>) }
fn d_7d455a7a3f8b9a0488aeb8214ace13408bd790b314b823e14d7c192792fe4f67(v196: &D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e,v197: u64,v198: u64,v199: &D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194) -> D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194 { if if ((v197) == (0u64)) { true } else { if match v199 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v200,v201,v202) => { *v202 } } { true } else { ((d_8e18927e0da738430b7c88025d7acd72a7da7d1acfc17e1cc31ebc2fbe86d7fc(&(match v199 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v203,v204,v205) => { (v203.as_ref()).clone() } }))) == (0u64)) } } { (v199).clone() } else { match v196 { D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C0 => { (v199).clone() },D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(v206,v207) => { if *v206 { match &(D_b21cb06bcd029ddfdbd04d843333cba7b10439be3eaa89ed539f15b9ecbb4335::C0(std::sync::Arc::new(d_7d455a7a3f8b9a0488aeb8214ace13408bd790b314b823e14d7c192792fe4f67(v207.as_ref(),(v197).checked_div(2u64).unwrap_or(0),(((v198).wrapping_add((v197).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_7d455a7a3f8b9a0488aeb8214ace13408bd790b314b823e14d7c192792fe4f67(v207.as_ref(),(v197).checked_div(2u64).unwrap_or(0),v198,v199)))))) { D_b21cb06bcd029ddfdbd04d843333cba7b10439be3eaa89ed539f15b9ecbb4335::C0(v208) => { if if match v208.as_ref() { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v209,v210,v211) => { *v211 } } { true } else { ((d_8e18927e0da738430b7c88025d7acd72a7da7d1acfc17e1cc31ebc2fbe86d7fc(&(match v208.as_ref() { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v212,v213,v214) => { (v212.as_ref()).clone() } }))) == (0u64)) } { (v208.as_ref()).clone() } else { d_f567de0303d56809175c5ecc5b9600982f9ad09f5a6260095012ac9a3c2fd621(v208.as_ref()) } } } } else { d_7d455a7a3f8b9a0488aeb8214ace13408bd790b314b823e14d7c192792fe4f67(v207.as_ref(),(v197).checked_div(2u64).unwrap_or(0),(((v198).wrapping_add((v197).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_7d455a7a3f8b9a0488aeb8214ace13408bd790b314b823e14d7c192792fe4f67(v207.as_ref(),(v197).checked_div(2u64).unwrap_or(0),v198,v199))) } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0 { C0(std::sync::Arc<D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5>) }
fn d_7f545b4f2164568b6108b56e37fbd551317029cc2531ad7eb19a551e557bcbfd(v215: &D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351) -> D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333 { match v215 { D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351::C0(v216,v217) => { D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(std::sync::Arc::clone(v216)) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0 { C0,C1(u64,std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>,std::sync::Arc<D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0>) }
impl D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_8e18927e0da738430b7c88025d7acd72a7da7d1acfc17e1cc31ebc2fbe86d7fc(v218: &D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026) -> u64 { match v218 { D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C0 => { 0u64 },D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C1(v219,v220) => { (((1u64).wrapping_add(d_8e18927e0da738430b7c88025d7acd72a7da7d1acfc17e1cc31ebc2fbe86d7fc(v220.as_ref()))) & (4294967295u64)) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194 { C0(std::sync::Arc<D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026>,u64,bool) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d { C0(std::sync::Arc<D_65c64225237a0e23811c934f9c65fa43f3c929ad11e29457eb9119eb219d8346>),C1(bool) }
fn d_930717135a9d182c00421292ed66c95b9386dc498e2f2002aa6b92d74a2dec35(v221: &D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026) -> D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026 { match v221 { D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C0 => { D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C0 },D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C1(v223,v224) => { match v224.as_ref() { D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C0 => { D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C0 },D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C1(v226,v227) => { D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C1(std::sync::Arc::clone(v223),std::sync::Arc::new(d_930717135a9d182c00421292ed66c95b9386dc498e2f2002aa6b92d74a2dec35(v224.as_ref()))) } } } } }
fn d_9793770332df3138c3b012e84779ef25eb8cf793a4af0d4c7cd56f0d7ef85b7b(v228: &D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333,v229: u64,v230: u64,v231: bool) -> D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef { match &(D_b2ef1e1494345c84efc6fb322810b6cecd0932e98d9687468c2372b51eb46a3f::C0(std::sync::Arc::new(match v228 { D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(v232) => { D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(std::sync::Arc::new(d_664e2e3419a2d16444c698a16774ab3ab53e7431a3ac8d6063618106e6d6f985(&(match v228 { D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(v233) => { (v233.as_ref()).clone() } }),v230))) } }))) { D_b2ef1e1494345c84efc6fb322810b6cecd0932e98d9687468c2372b51eb46a3f::C0(v234) => { if v231 { match &(D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C1(true)) { D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C0(v236) => { if ((v229) == (18446744073709551615u64)) { D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C1(1u64,v229,std::sync::Arc::new((v228).clone())) } else { D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C0(std::sync::Arc::new(D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C0(std::sync::Arc::clone(v236))),true,(v229).wrapping_add(1u64),std::sync::Arc::clone(v234),std::sync::Arc::clone({static v237:std::sync::OnceLock<std::sync::Arc<D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44>>=std::sync::OnceLock::new();v237.get_or_init(||std::sync::Arc::new(D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44::C0))})) } },D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C1(v238) => { D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C0(std::sync::Arc::new(D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C1(*v238)),false,v229,std::sync::Arc::new((v228).clone()),std::sync::Arc::clone({static v239:std::sync::OnceLock<std::sync::Arc<D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44>>=std::sync::OnceLock::new();v239.get_or_init(||std::sync::Arc::new(D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44::C0))})) } } } else { match &(D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C0(std::sync::Arc::clone({static v240:std::sync::OnceLock<std::sync::Arc<D_65c64225237a0e23811c934f9c65fa43f3c929ad11e29457eb9119eb219d8346>>=std::sync::OnceLock::new();v240.get_or_init(||std::sync::Arc::new(D_65c64225237a0e23811c934f9c65fa43f3c929ad11e29457eb9119eb219d8346::C0))}))) { D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C0(v242) => { if ((v229) == (18446744073709551615u64)) { D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C1(1u64,v229,std::sync::Arc::new((v228).clone())) } else { D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C0(std::sync::Arc::new(D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C0(std::sync::Arc::clone(v242))),true,(v229).wrapping_add(1u64),std::sync::Arc::clone(v234),std::sync::Arc::clone({static v243:std::sync::OnceLock<std::sync::Arc<D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44>>=std::sync::OnceLock::new();v243.get_or_init(||std::sync::Arc::new(D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44::C0))})) } },D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C1(v244) => { D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C0(std::sync::Arc::new(D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C1(*v244)),false,v229,std::sync::Arc::new((v228).clone()),std::sync::Arc::clone({static v245:std::sync::OnceLock<std::sync::Arc<D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44>>=std::sync::OnceLock::new();v245.get_or_init(||std::sync::Arc::new(D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44::C0))})) } } } } } }
fn d_9c54a93e10b9370069dd07a0280710f0378a51b0f3bfbb43435cc7a4ce2a3c40(v246: &D_eda088d5719bbdf20cbbe19303a4d6e6a523005313bfb8e7c854630d6ded9af1) -> D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351 { match v246 { D_eda088d5719bbdf20cbbe19303a4d6e6a523005313bfb8e7c854630d6ded9af1::C0(v247,v248) => { (v247.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_9fc4d638add12aee3a7502be8d258ed591363b7b572c6a438f6ef62deaac2376 { C0,C1(u64) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_a33fb21fa98f5296d71ff12fbda12456f198d0210773de677fdaa687f91b7393 { C0(std::sync::Arc<D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3>,bool,u64,std::sync::Arc<D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333>,std::sync::Arc<D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44>),C1(u64,u64,std::sync::Arc<D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_b21cb06bcd029ddfdbd04d843333cba7b10439be3eaa89ed539f15b9ecbb4335 { C0(std::sync::Arc<D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_b2ef1e1494345c84efc6fb322810b6cecd0932e98d9687468c2372b51eb46a3f { C0(std::sync::Arc<D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333>) }
fn d_b34f65a4ac99fc61943805e138e0962ea60ed5e82d8e63113d404875b447ca37(v249: &D_f5e573856b2863d790347b60e8f7df9bff798bc41392dbfba14079a236d4cd15) -> D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef { match v249 { D_f5e573856b2863d790347b60e8f7df9bff798bc41392dbfba14079a236d4cd15::C0(v250,v251) => { (v251.as_ref()).clone() } } }
fn d_b49ff9b95a5c7163aba6ad15baf92896af132384165b93740839b8b0178da27f(v252: &D_7ce0fdfaec5607097d66c8b8d679d2f9427c49a7502f4d4f2ebf9398a3906a61) -> D_7ce0fdfaec5607097d66c8b8d679d2f9427c49a7502f4d4f2ebf9398a3906a61 { match &(D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0::C0(std::sync::Arc::new(match &(d_2fb2a5ea1a64a69afbaa25635d0d7fec1ac83057e15112811da15fedf24131b4(&(match v252 { D_7ce0fdfaec5607097d66c8b8d679d2f9427c49a7502f4d4f2ebf9398a3906a61::C0(v253,v254) => { (v253.as_ref()).clone() } }),0u64)) { D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C0 => { D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(0u64,0u64) },D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C1(v256) => { (v256.as_ref()).clone() } }))) { D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0::C0(v257) => { D_7ce0fdfaec5607097d66c8b8d679d2f9427c49a7502f4d4f2ebf9398a3906a61::C0(std::sync::Arc::new(d_56751de214de1c672c34b9dd9fbc0544e62403208dc4f67373077a546df1c8ba(&(match v252 { D_7ce0fdfaec5607097d66c8b8d679d2f9427c49a7502f4d4f2ebf9398a3906a61::C0(v258,v259) => { (v258.as_ref()).clone() } }))),std::sync::Arc::new(d_695ca14e25e5f08ca1404d5f405afb04d8407218c3af53a6ecb4f59e69ca33bd(&(match v252 { D_7ce0fdfaec5607097d66c8b8d679d2f9427c49a7502f4d4f2ebf9398a3906a61::C0(v260,v261) => { (v261.as_ref()).clone() } }),match v257.as_ref() { D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(v262,v263) => { *v263 } }))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_b62e83ea6ba1bb4c8818da50869e95eb2e3541a4fd95e5251c2d6b998acfeadb { C0 }
impl D_b62e83ea6ba1bb4c8818da50869e95eb2e3541a4fd95e5251c2d6b998acfeadb{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_b62e83ea6ba1bb4c8818da50869e95eb2e3541a4fd95e5251c2d6b998acfeadb{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_c1aefe13ad2329f4c7f817439d8190dae6c52af2b31ce3accc8371898e55432b { C0(std::sync::Arc<D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3>,bool,u64,std::sync::Arc<D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333>,std::sync::Arc<D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44>),C1(u64,u64,std::sync::Arc<D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333>) }
fn d_c2da8606e6799596a3db4f0a63a6e8eca4702b496df02715d1b8b1d494151854(v264: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v265: u64) -> D_ea181aecd4a60ec6fb3737561b67d9ee7b10cbabdb8a455c94dfedd044eff0f6 { match v264 { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 => { D_ea181aecd4a60ec6fb3737561b67d9ee7b10cbabdb8a455c94dfedd044eff0f6::C0 },D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v267,v268) => { if ((v265) == (0u64)) { D_ea181aecd4a60ec6fb3737561b67d9ee7b10cbabdb8a455c94dfedd044eff0f6::C1(*v267) } else { d_c2da8606e6799596a3db4f0a63a6e8eca4702b496df02715d1b8b1d494151854(v268.as_ref(),(((v265).wrapping_sub(1u64)) & (4294967295u64))) } } } }
fn d_ca9403b27f96914bd3d6f53ac3594abd68c8ec627c24cedfb93f77b6700debf2(v269: &D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333,v270: u64,v271: u64) -> D_a33fb21fa98f5296d71ff12fbda12456f198d0210773de677fdaa687f91b7393 { D_a33fb21fa98f5296d71ff12fbda12456f198d0210773de677fdaa687f91b7393::C0(std::sync::Arc::new(d_e991858a86d4b1c03de257d3ab316d2a3fa3ed38265965de647840dfe983ceb3(&(match v269 { D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(v272) => { (v272.as_ref()).clone() } }),v271)),false,v270,std::sync::Arc::new((v269).clone()),std::sync::Arc::clone({static v273:std::sync::OnceLock<std::sync::Arc<D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44>>=std::sync::OnceLock::new();v273.get_or_init(||std::sync::Arc::new(D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44::C0))})) }
fn d_ce8322edd9fc3ce748d4118b3046705cc52d181bf064088b3ddf7a4056957384(v274: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8) -> u64 { match v274 { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 => { 0u64 },D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v275,v276) => { (((1u64).wrapping_add(d_ce8322edd9fc3ce748d4118b3046705cc52d181bf064088b3ddf7a4056957384(v276.as_ref()))) & (4294967295u64)) } } }
fn d_d0fc7b7b67962970fb17711732afbaadc77896f1a06373f8d760999b4581a809(v277: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8) -> D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026 { match &(D_d1e3d9719ff9b6c740884f30963246651c44dc4e5891b7d1fd00d408c18f83fa::C0(std::sync::Arc::clone({static v278:std::sync::OnceLock<std::sync::Arc<D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026>>=std::sync::OnceLock::new();v278.get_or_init(||std::sync::Arc::new(D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C0))}))) { D_d1e3d9719ff9b6c740884f30963246651c44dc4e5891b7d1fd00d408c18f83fa::C0(v280) => { d_d6bc9ce70dab588da34dc40d74114e3534bf00c0e6dcf6c44bc91dc913dd08b7(&(d_74ffd12a795b8b93feb4d82f843cf537d782c035b9310be9b913da8810e741a9(&(if ((d_ce8322edd9fc3ce748d4118b3046705cc52d181bf064088b3ddf7a4056957384(v277)) == (0u64)) { D_9fc4d638add12aee3a7502be8d258ed591363b7b572c6a438f6ef62deaac2376::C0 } else { D_9fc4d638add12aee3a7502be8d258ed591363b7b572c6a438f6ef62deaac2376::C1(d_ce8322edd9fc3ce748d4118b3046705cc52d181bf064088b3ddf7a4056957384(v277)) }))),d_ce8322edd9fc3ce748d4118b3046705cc52d181bf064088b3ddf7a4056957384(v277),0u64,v280.as_ref(),v277) } } }
fn d_d143ee1f7b615d949273e2864cc559e1f943993ae354d0d9d8513dc79a042dfe(v282: &D_eda088d5719bbdf20cbbe19303a4d6e6a523005313bfb8e7c854630d6ded9af1) -> D_c1aefe13ad2329f4c7f817439d8190dae6c52af2b31ce3accc8371898e55432b { match v282 { D_eda088d5719bbdf20cbbe19303a4d6e6a523005313bfb8e7c854630d6ded9af1::C0(v283,v284) => { (v284.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_d1e3d9719ff9b6c740884f30963246651c44dc4e5891b7d1fd00d408c18f83fa { C0(std::sync::Arc<D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026>) }
fn d_d6bc9ce70dab588da34dc40d74114e3534bf00c0e6dcf6c44bc91dc913dd08b7(v285: &D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e,v286: u64,v287: u64,v288: &D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026,v289: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8) -> D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026 { if if ((v286) == (0u64)) { true } else { false } { (v288).clone() } else { match v285 { D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C0 => { (v288).clone() },D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e::C1(v290,v291) => { if *v290 { match &(D_d1e3d9719ff9b6c740884f30963246651c44dc4e5891b7d1fd00d408c18f83fa::C0(std::sync::Arc::new(d_d6bc9ce70dab588da34dc40d74114e3534bf00c0e6dcf6c44bc91dc913dd08b7(v291.as_ref(),(v286).checked_div(2u64).unwrap_or(0),(((v287).wrapping_add((v286).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_d6bc9ce70dab588da34dc40d74114e3534bf00c0e6dcf6c44bc91dc913dd08b7(v291.as_ref(),(v286).checked_div(2u64).unwrap_or(0),v287,v288,v289)),v289)))) { D_d1e3d9719ff9b6c740884f30963246651c44dc4e5891b7d1fd00d408c18f83fa::C0(v292) => { if false { (v292.as_ref()).clone() } else { d_31fe6602e4ee7a5db178e53dde982c0865df1891ac579afcb78a04557ac219dc(v292.as_ref(),&(D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0((((v287).wrapping_add(((v286).checked_div(2u64).unwrap_or(0)).wrapping_mul(2u64))) & (4294967295u64)),match &(d_c2da8606e6799596a3db4f0a63a6e8eca4702b496df02715d1b8b1d494151854(v289,(((v287).wrapping_add(((v286).checked_div(2u64).unwrap_or(0)).wrapping_mul(2u64))) & (4294967295u64)))) { D_ea181aecd4a60ec6fb3737561b67d9ee7b10cbabdb8a455c94dfedd044eff0f6::C0 => { 0u64 },D_ea181aecd4a60ec6fb3737561b67d9ee7b10cbabdb8a455c94dfedd044eff0f6::C1(v293) => { *v293 } }))) } } } } else { d_d6bc9ce70dab588da34dc40d74114e3534bf00c0e6dcf6c44bc91dc913dd08b7(v291.as_ref(),(v286).checked_div(2u64).unwrap_or(0),(((v287).wrapping_add((v286).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_d6bc9ce70dab588da34dc40d74114e3534bf00c0e6dcf6c44bc91dc913dd08b7(v291.as_ref(),(v286).checked_div(2u64).unwrap_or(0),v287,v288,v289)),v289) } } } } }
fn d_d71435ad3bfe23b787260cc19f0a628e39428a45065153e66058176bf5602402(v294: &D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351) -> D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3 { match v294 { D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351::C0(v295,v296) => { (v296.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_d9c8ddd7dd81d151944950e1acb87c3ab6bb9acc6ea964b4f19493c203956945 { C0(std::sync::Arc<D_7ce0fdfaec5607097d66c8b8d679d2f9427c49a7502f4d4f2ebf9398a3906a61>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e { C0,C1(bool,std::sync::Arc<D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e>) }
impl D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_dbd1d22bc76002f3934efe5d9a438267671b59197aa4a5077313cc20f92b998e{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351 { C0(std::sync::Arc<D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0>,std::sync::Arc<D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3>) }
fn d_e4f2e80b120ad45fec7e622d3d553522dc6849e1723e54b57a367d969412507c(v297: &D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0,v298: u64,v299: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8) -> D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0 { match v297 { D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C0 => { D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C1(v298,std::sync::Arc::new((v299).clone()),std::sync::Arc::clone({static v300:std::sync::OnceLock<std::sync::Arc<D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0>>=std::sync::OnceLock::new();v300.get_or_init(||std::sync::Arc::new(D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C0))})) },D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C1(v301,v302,v303) => { if ((v298) < (*v301)) { D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C1(v298,std::sync::Arc::new((v299).clone()),std::sync::Arc::new((v297).clone())) } else { D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C1(*v301,std::sync::Arc::clone(v302),std::sync::Arc::new(d_e4f2e80b120ad45fec7e622d3d553522dc6849e1723e54b57a367d969412507c(v303.as_ref(),v298,v299))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5 { C0(u64,u64) }
fn d_e991858a86d4b1c03de257d3ab316d2a3fa3ed38265965de647840dfe983ceb3(v304: &D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0,v305: u64) -> D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3 { match v304 { D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C0 => { D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3::C0 },D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C1(v307,v308,v309) => { if ((v305) == (*v307)) { D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3::C1(std::sync::Arc::clone(v308)) } else { d_e991858a86d4b1c03de257d3ab316d2a3fa3ed38265965de647840dfe983ceb3(v309.as_ref(),v305) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ea181aecd4a60ec6fb3737561b67d9ee7b10cbabdb8a455c94dfedd044eff0f6 { C0,C1(u64) }
fn d_eb95847764654875914ebe91b106cff7388587dfc8aebdcb40754a9da32c6042(v310: &D_00c7f2c2f62a904dcb3deb3bf75cd1205869688513d42b2c7cc3954f74d91e30) -> D_a33fb21fa98f5296d71ff12fbda12456f198d0210773de677fdaa687f91b7393 { match v310 { D_00c7f2c2f62a904dcb3deb3bf75cd1205869688513d42b2c7cc3954f74d91e30::C0(v311,v312) => { (v312.as_ref()).clone() } } }
fn d_ebe560e0ad86af6a9330acbaf2d89bc9cc998a9fbcd90d35dc3a82145bf27b9d(v313: &D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026,v314: u64,v315: &D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5) -> D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026 { match v313 { D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C0 => { D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C0 },D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C1(v317,v318) => { if ((v314) == (0u64)) { D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C1(std::sync::Arc::new((v315).clone()),std::sync::Arc::clone(v318)) } else { D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C1(std::sync::Arc::clone(v317),std::sync::Arc::new(d_ebe560e0ad86af6a9330acbaf2d89bc9cc998a9fbcd90d35dc3a82145bf27b9d(v318.as_ref(),(((v314).wrapping_sub(1u64)) & (4294967295u64)),v315))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_eda088d5719bbdf20cbbe19303a4d6e6a523005313bfb8e7c854630d6ded9af1 { C0(std::sync::Arc<D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351>,std::sync::Arc<D_c1aefe13ad2329f4c7f817439d8190dae6c52af2b31ce3accc8371898e55432b>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3 { C0,C1(std::sync::Arc<D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5>) }
fn d_f567de0303d56809175c5ecc5b9600982f9ad09f5a6260095012ac9a3c2fd621(v319: &D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194) -> D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194 { match &(D_f60837a19af62184a4c3294896a2a4e927493474415026fc0ba068680f1107fb::C0(d_8e18927e0da738430b7c88025d7acd72a7da7d1acfc17e1cc31ebc2fbe86d7fc(&(match v319 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v320,v321,v322) => { (v320.as_ref()).clone() } })))) { D_f60837a19af62184a4c3294896a2a4e927493474415026fc0ba068680f1107fb::C0(v323) => { match &(D_f60837a19af62184a4c3294896a2a4e927493474415026fc0ba068680f1107fb::C0(((((((match v319 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v324,v325,v326) => { *v325 } }).wrapping_mul(2u64)) & (4294967295u64))).wrapping_add(1u64)) & (4294967295u64)))) { D_f60837a19af62184a4c3294896a2a4e927493474415026fc0ba068680f1107fb::C0(v327) => { match &(D_f60837a19af62184a4c3294896a2a4e927493474415026fc0ba068680f1107fb::C0((((*v327).wrapping_add(1u64)) & (4294967295u64)))) { D_f60837a19af62184a4c3294896a2a4e927493474415026fc0ba068680f1107fb::C0(v328) => { match &(D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0::C0(std::sync::Arc::new(match &(d_2fb2a5ea1a64a69afbaa25635d0d7fec1ac83057e15112811da15fedf24131b4(&(match v319 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v329,v330,v331) => { (v329.as_ref()).clone() } }),*v327)) { D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C0 => { D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(0u64,4294967295u64) },D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C1(v333) => { (v333.as_ref()).clone() } }))) { D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0::C0(v334) => { match &(D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0::C0(std::sync::Arc::new(match &(d_2fb2a5ea1a64a69afbaa25635d0d7fec1ac83057e15112811da15fedf24131b4(&(match v319 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v335,v336,v337) => { (v335.as_ref()).clone() } }),*v328)) { D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C0 => { D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(0u64,4294967295u64) },D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C1(v339) => { (v339.as_ref()).clone() } }))) { D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0::C0(v340) => { match &(D_f60837a19af62184a4c3294896a2a4e927493474415026fc0ba068680f1107fb::C0(if if ((*v328) < (*v323)) { d_39979ea376d8e234081b1e1ddfa12d39266d92193413486fc9470727d1c9e574(v340.as_ref(),v334.as_ref()) } else { false } { *v328 } else { *v327 })) { D_f60837a19af62184a4c3294896a2a4e927493474415026fc0ba068680f1107fb::C0(v341) => { match &(D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0::C0(std::sync::Arc::new(match &(d_2fb2a5ea1a64a69afbaa25635d0d7fec1ac83057e15112811da15fedf24131b4(&(match v319 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v342,v343,v344) => { (v342.as_ref()).clone() } }),*v341)) { D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C0 => { D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(0u64,4294967295u64) },D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C1(v346) => { (v346.as_ref()).clone() } }))) { D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0::C0(v347) => { match &(D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0::C0(std::sync::Arc::new(match &(d_2fb2a5ea1a64a69afbaa25635d0d7fec1ac83057e15112811da15fedf24131b4(&(match v319 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v348,v349,v350) => { (v348.as_ref()).clone() } }),match v319 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v351,v352,v353) => { *v352 } })) { D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C0 => { D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(0u64,0u64) },D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C1(v355) => { (v355.as_ref()).clone() } }))) { D_7dbf154f1a66fb59d16c07708528edcb7471267d116486d327278ae2f05c3fe0::C0(v356) => { if if ((*v341) < (*v323)) { d_39979ea376d8e234081b1e1ddfa12d39266d92193413486fc9470727d1c9e574(v347.as_ref(),v356.as_ref()) } else { false } { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(std::sync::Arc::new(match &(d_2fb2a5ea1a64a69afbaa25635d0d7fec1ac83057e15112811da15fedf24131b4(&(match v319 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v357,v358,v359) => { (v357.as_ref()).clone() } }),match v319 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v360,v361,v362) => { *v361 } })) { D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C0 => { match v319 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v363,v364,v365) => { (v363.as_ref()).clone() } } },D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C1(v366) => { match &(d_2fb2a5ea1a64a69afbaa25635d0d7fec1ac83057e15112811da15fedf24131b4(&(match v319 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v367,v368,v369) => { (v367.as_ref()).clone() } }),*v341)) { D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C0 => { match v319 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v370,v371,v372) => { (v370.as_ref()).clone() } } },D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C1(v373) => { d_ebe560e0ad86af6a9330acbaf2d89bc9cc998a9fbcd90d35dc3a82145bf27b9d(&(d_ebe560e0ad86af6a9330acbaf2d89bc9cc998a9fbcd90d35dc3a82145bf27b9d(&(match v319 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v374,v375,v376) => { (v374.as_ref()).clone() } }),match v319 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v377,v378,v379) => { *v378 } },v373.as_ref())),*v341,v366.as_ref()) } } } }),*v341,false) } else { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(std::sync::Arc::new(match v319 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v380,v381,v382) => { (v380.as_ref()).clone() } }),match v319 { D_8eabf165fec501c5cd629deac4d7cd2bcb28248ad757dca9423c65390aaaf194::C0(v383,v384,v385) => { *v384 } },true) } } } } } } } } } } } } } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_f5e573856b2863d790347b60e8f7df9bff798bc41392dbfba14079a236d4cd15 { C0(std::sync::Arc<D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3>,std::sync::Arc<D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_f60837a19af62184a4c3294896a2a4e927493474415026fc0ba068680f1107fb { C0(u64) }
fn d_f9144419d869e045d8833db100400fb668918bb11720d78b0b7be3d9daa6197f(v386: &D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333,v387: u64,v388: u64,v389: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v390: bool) -> D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef { match &(D_b2ef1e1494345c84efc6fb322810b6cecd0932e98d9687468c2372b51eb46a3f::C0(std::sync::Arc::new(match v386 { D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(v391) => { D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(std::sync::Arc::new(d_664e2e3419a2d16444c698a16774ab3ab53e7431a3ac8d6063618106e6d6f985(&(match v386 { D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(v392) => { (v392.as_ref()).clone() } }),v388))) } }))) { D_b2ef1e1494345c84efc6fb322810b6cecd0932e98d9687468c2372b51eb46a3f::C0(v393) => { if d_3897cfb53d05bdc45eda27662b9029e17686b836d9ff19ff7b2a2bc9625bb2ba(&(match v393.as_ref() { D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(v394) => { (v394.as_ref()).clone() } }),v388) { D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C1(2u64,v387,std::sync::Arc::new((v386).clone())) } else { match &(D_b2ef1e1494345c84efc6fb322810b6cecd0932e98d9687468c2372b51eb46a3f::C0(std::sync::Arc::new(match v393.as_ref() { D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(v395) => { D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(std::sync::Arc::new(d_e4f2e80b120ad45fec7e622d3d553522dc6849e1723e54b57a367d969412507c(&(match v393.as_ref() { D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(v396) => { (v396.as_ref()).clone() } }),v388,v389))) } }))) { D_b2ef1e1494345c84efc6fb322810b6cecd0932e98d9687468c2372b51eb46a3f::C0(v397) => { if v390 { match &(D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C1(true)) { D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C0(v399) => { if ((v387) == (18446744073709551615u64)) { D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C1(1u64,v387,std::sync::Arc::new((v386).clone())) } else { D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C0(std::sync::Arc::new(D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C0(std::sync::Arc::clone(v399))),true,(v387).wrapping_add(1u64),std::sync::Arc::clone(v397),std::sync::Arc::clone({static v400:std::sync::OnceLock<std::sync::Arc<D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44>>=std::sync::OnceLock::new();v400.get_or_init(||std::sync::Arc::new(D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44::C0))})) } },D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C1(v401) => { D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C0(std::sync::Arc::new(D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C1(*v401)),false,v387,std::sync::Arc::new((v386).clone()),std::sync::Arc::clone({static v402:std::sync::OnceLock<std::sync::Arc<D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44>>=std::sync::OnceLock::new();v402.get_or_init(||std::sync::Arc::new(D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44::C0))})) } } } else { match &(D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C0(std::sync::Arc::clone({static v403:std::sync::OnceLock<std::sync::Arc<D_65c64225237a0e23811c934f9c65fa43f3c929ad11e29457eb9119eb219d8346>>=std::sync::OnceLock::new();v403.get_or_init(||std::sync::Arc::new(D_65c64225237a0e23811c934f9c65fa43f3c929ad11e29457eb9119eb219d8346::C0))}))) { D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C0(v405) => { if ((v387) == (18446744073709551615u64)) { D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C1(1u64,v387,std::sync::Arc::new((v386).clone())) } else { D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C0(std::sync::Arc::new(D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C0(std::sync::Arc::clone(v405))),true,(v387).wrapping_add(1u64),std::sync::Arc::clone(v397),std::sync::Arc::clone({static v406:std::sync::OnceLock<std::sync::Arc<D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44>>=std::sync::OnceLock::new();v406.get_or_init(||std::sync::Arc::new(D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44::C0))})) } },D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C1(v407) => { D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C0(std::sync::Arc::new(D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C1(*v407)),false,v387,std::sync::Arc::new((v386).clone()),std::sync::Arc::clone({static v408:std::sync::OnceLock<std::sync::Arc<D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44>>=std::sync::OnceLock::new();v408.get_or_init(||std::sync::Arc::new(D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44::C0))})) } } } } } } } } }
fn d_fb1484fbdc138711cc4400b91bbad519648ae8a58d5cbc2b1ddaddd9e39a78ba(v409: &D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351,v410: u64,v411: u64) -> D_00c7f2c2f62a904dcb3deb3bf75cd1205869688513d42b2c7cc3954f74d91e30 { D_00c7f2c2f62a904dcb3deb3bf75cd1205869688513d42b2c7cc3954f74d91e30::C0(std::sync::Arc::new((v409).clone()),std::sync::Arc::new(d_ca9403b27f96914bd3d6f53ac3594abd68c8ec627c24cedfb93f77b6700debf2(&(d_7f545b4f2164568b6108b56e37fbd551317029cc2531ad7eb19a551e557bcbfd(v409)),v410,v411))) }
pub fn f_00ac7e7cd0bc0ffe4cfb5c0152f80e39b767a57a16994cd72f8e4dae4391d71e(v412: &D_00c7f2c2f62a904dcb3deb3bf75cd1205869688513d42b2c7cc3954f74d91e30) -> D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351 { d_00ac7e7cd0bc0ffe4cfb5c0152f80e39b767a57a16994cd72f8e4dae4391d71e(v412) }
pub fn f_0ee743a0ab5550a7e4f886fe6a049d5d611588bcbcb3aa38832e3e8496fedeba(v413: &D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351,v414: u64,v415: u64,v416: bool) -> D_f5e573856b2863d790347b60e8f7df9bff798bc41392dbfba14079a236d4cd15 { d_0ee743a0ab5550a7e4f886fe6a049d5d611588bcbcb3aa38832e3e8496fedeba(v413,v414,v415,v416) }
pub fn f_2620718ccbe9b25373b24bbf81c9b02b150bb6d1a96ff326d544d5d226565846(v417: &D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351,v418: u64,v419: u64,v420: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v421: bool) -> D_f5e573856b2863d790347b60e8f7df9bff798bc41392dbfba14079a236d4cd15 { d_2620718ccbe9b25373b24bbf81c9b02b150bb6d1a96ff326d544d5d226565846(v417,v418,v419,v420,v421) }
pub fn f_3027189a800129e578400787a58af9a0f869d870318e640ea8c20e92a4716ed3(v422: &D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351,v423: u64) -> D_eda088d5719bbdf20cbbe19303a4d6e6a523005313bfb8e7c854630d6ded9af1 { d_3027189a800129e578400787a58af9a0f869d870318e640ea8c20e92a4716ed3(v422,v423) }
pub fn f_361b33126df4c584aa0e1127c93c1ebf0ef95d5dc1359d5ff7d7115a4076be7c(v424: &D_f5e573856b2863d790347b60e8f7df9bff798bc41392dbfba14079a236d4cd15) -> D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351 { d_361b33126df4c584aa0e1127c93c1ebf0ef95d5dc1359d5ff7d7115a4076be7c(v424) }
pub fn f_5b2b561b43fbc9fc3b1c470f965430122b532b97f0581c7596cfdaaa39f2da33(v425: &D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333) -> D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351 { d_5b2b561b43fbc9fc3b1c470f965430122b532b97f0581c7596cfdaaa39f2da33(v425) }
pub fn f_7f545b4f2164568b6108b56e37fbd551317029cc2531ad7eb19a551e557bcbfd(v426: &D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351) -> D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333 { d_7f545b4f2164568b6108b56e37fbd551317029cc2531ad7eb19a551e557bcbfd(v426) }
pub fn f_9c54a93e10b9370069dd07a0280710f0378a51b0f3bfbb43435cc7a4ce2a3c40(v427: &D_eda088d5719bbdf20cbbe19303a4d6e6a523005313bfb8e7c854630d6ded9af1) -> D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351 { d_9c54a93e10b9370069dd07a0280710f0378a51b0f3bfbb43435cc7a4ce2a3c40(v427) }
pub fn f_b34f65a4ac99fc61943805e138e0962ea60ed5e82d8e63113d404875b447ca37(v428: &D_f5e573856b2863d790347b60e8f7df9bff798bc41392dbfba14079a236d4cd15) -> D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef { d_b34f65a4ac99fc61943805e138e0962ea60ed5e82d8e63113d404875b447ca37(v428) }
pub fn f_d143ee1f7b615d949273e2864cc559e1f943993ae354d0d9d8513dc79a042dfe(v429: &D_eda088d5719bbdf20cbbe19303a4d6e6a523005313bfb8e7c854630d6ded9af1) -> D_c1aefe13ad2329f4c7f817439d8190dae6c52af2b31ce3accc8371898e55432b { d_d143ee1f7b615d949273e2864cc559e1f943993ae354d0d9d8513dc79a042dfe(v429) }
pub fn f_eb95847764654875914ebe91b106cff7388587dfc8aebdcb40754a9da32c6042(v430: &D_00c7f2c2f62a904dcb3deb3bf75cd1205869688513d42b2c7cc3954f74d91e30) -> D_a33fb21fa98f5296d71ff12fbda12456f198d0210773de677fdaa687f91b7393 { d_eb95847764654875914ebe91b106cff7388587dfc8aebdcb40754a9da32c6042(v430) }
pub fn f_fb1484fbdc138711cc4400b91bbad519648ae8a58d5cbc2b1ddaddd9e39a78ba(v431: &D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351,v432: u64,v433: u64) -> D_00c7f2c2f62a904dcb3deb3bf75cd1205869688513d42b2c7cc3954f74d91e30 { d_fb1484fbdc138711cc4400b91bbad519648ae8a58d5cbc2b1ddaddd9e39a78ba(v431,v432,v433) }
fn q_3027189a800129e578400787a58af9a0f869d870318e640ea8c20e92a4716ed3(v0:&D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351,v1:u64)->D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3{match v0 { D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351::C0(v2,v3) => { (v3.as_ref()).clone() } }}
fn q_fb1484fbdc138711cc4400b91bbad519648ae8a58d5cbc2b1ddaddd9e39a78ba(v0:&D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351,v1:u64,v2:u64)->D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3{match v0 { D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351::C0(v3,v4) => { d_e991858a86d4b1c03de257d3ab316d2a3fa3ed38265965de647840dfe983ceb3(v3.as_ref(),v2) } }}
fn t_3027189a800129e578400787a58af9a0f869d870318e640ea8c20e92a4716ed3(v0:&D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351,v1:u64)->D_eda088d5719bbdf20cbbe19303a4d6e6a523005313bfb8e7c854630d6ded9af1{match v0 { D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351::C0(v2,v3) => { D_eda088d5719bbdf20cbbe19303a4d6e6a523005313bfb8e7c854630d6ded9af1::C0(std::sync::Arc::new(D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351::C0(std::sync::Arc::clone(v2),std::sync::Arc::clone(v3))),std::sync::Arc::new(D_c1aefe13ad2329f4c7f817439d8190dae6c52af2b31ce3accc8371898e55432b::C0(std::sync::Arc::clone(v3),false,v1,std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(std::sync::Arc::clone({static v4:std::sync::OnceLock<std::sync::Arc<D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0>>=std::sync::OnceLock::new();v4.get_or_init(||std::sync::Arc::new(D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C0))}))))}),std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44::C0))})))) } }}
fn t_fb1484fbdc138711cc4400b91bbad519648ae8a58d5cbc2b1ddaddd9e39a78ba(v0:&D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351,v1:u64,v2:u64)->D_00c7f2c2f62a904dcb3deb3bf75cd1205869688513d42b2c7cc3954f74d91e30{match v0 { D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351::C0(v3,v4) => { D_00c7f2c2f62a904dcb3deb3bf75cd1205869688513d42b2c7cc3954f74d91e30::C0(std::sync::Arc::new(D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351::C0(std::sync::Arc::clone(v3),std::sync::Arc::clone(v4))),std::sync::Arc::new(D_a33fb21fa98f5296d71ff12fbda12456f198d0210773de677fdaa687f91b7393::C0(std::sync::Arc::new(d_e991858a86d4b1c03de257d3ab316d2a3fa3ed38265965de647840dfe983ceb3(v3.as_ref(),v2)),false,v1,std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C0))}))))}),std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44::C0))})))) } }}

use serde_json::{Value as Json,json};
mod portable{
//! Shared, representation-independent snapshot codec. This module also ships
//! verbatim in generated applications; it has no AST/evaluator dependency.
use num_bigint::{BigInt, Sign};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::cmp::Ordering;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Schema {
    Unit,
    Bool,
    U32,
    U64,
    I32,
    F32,
    Vector(Box<Schema>, u8),
    Int,
    String,
    Id,
    Record(Vec<(String, Schema)>),
    Enum(Vec<String>),
    List(Box<Schema>),
    Option(Box<Schema>),
    Result(Box<Schema>, Box<Schema>),
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Layout {
    pub program: [u8; 32],
    pub schema: [u8; 32],
    pub roots: Vec<(String, Schema, Schema)>,
    pub events: Vec<(String, Schema)>,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Event {
    pub commit: u64,
    pub position: u64,
    pub channel: usize,
    pub value: Value,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Logical {
    pub version: u64,
    pub tables: Vec<Vec<(Value, Value)>>,
    pub outbox: Vec<Event>,
}
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub bytes: usize,
    pub values: usize,
    pub depth: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            bytes: 64 * 1024 * 1024,
            values: 1_000_000,
            depth: 128,
        }
    }
}
/// Magnitude bound for one exact integer. Decimal conversion is superlinear,
/// so without it a single large Int in a snapshot takes minutes to hours.
pub const MAX_INT_BYTES: usize = 4096;
const MAGIC: &[u8; 8] = b"VLSTATE\0";
const HEADER: usize = 8 + 2 + 2 + 32 + 32 + 8;
type R<T> = Result<T, String>;
fn u64_bytes(out: &mut Vec<u8>, v: u64) {
    out.extend_from_slice(&v.to_le_bytes());
}
fn count(out: &mut Vec<u8>, n: usize) {
    u64_bytes(out, n as u64);
}
fn raw(out: &mut Vec<u8>, b: &[u8]) {
    count(out, b.len());
    out.extend_from_slice(b);
}
fn tag<'a>(v: &'a Value, name: &str) -> R<&'a Value> {
    let o = v.as_object().ok_or("expected tagged object")?;
    if o.len() != 1 {
        return Err("expected exactly one tag".into());
    }
    o.get(name).ok_or("unexpected value tag".into())
}
fn integer(v: &Value) -> R<BigInt> {
    let s = tag(v, "Int")?.as_str().ok_or("expected Int string")?;
    // Every Int within the bound has fewer than 2.41 decimal digits per byte.
    if s.len() > MAX_INT_BYTES * 5 / 2 + 1 {
        return Err("snapshot Int exceeds size limit".into());
    }
    let n = s.parse::<BigInt>().map_err(|_| "invalid Int")?;
    if n.bits() > 8 * MAX_INT_BYTES as u64 {
        return Err("snapshot Int exceeds size limit".into());
    }
    if n.to_string() != s {
        return Err("noncanonical Int".into());
    }
    Ok(n)
}
fn identifier(v: &Value) -> R<u128> {
    let s = v.as_str().ok_or("expected ID")?;
    if s.len() != 32
        || !s
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err("noncanonical ID".into());
    }
    u128::from_str_radix(s, 16).map_err(|e| e.to_string())
}
fn compare(t: &Schema, a: &Value, b: &Value) -> R<Ordering> {
    Ok(match t {
        Schema::I32 => a
            .as_i64()
            .and_then(|n| i32::try_from(n).ok())
            .ok_or("invalid i32 key")?
            .cmp(
                &b.as_i64()
                    .and_then(|n| i32::try_from(n).ok())
                    .ok_or("invalid i32 key")?,
            ),
        Schema::U32 | Schema::U64 => a
            .as_u64()
            .ok_or("invalid key")?
            .cmp(&b.as_u64().ok_or("invalid key")?),
        Schema::String => a
            .as_str()
            .ok_or("invalid key")?
            .as_bytes()
            .cmp(b.as_str().ok_or("invalid key")?.as_bytes()),
        Schema::Id => identifier(a)?.cmp(&identifier(b)?),
        _ => return Err("unsupported snapshot key schema".into()),
    })
}
fn tick(left: &mut usize, depth: usize, limits: Limits) -> R<()> {
    if *left == 0 || depth > limits.depth {
        return Err("snapshot value/depth limit exceeded".into());
    }
    *left -= 1;
    Ok(())
}
fn encode_value(
    t: &Schema,
    v: &Value,
    out: &mut Vec<u8>,
    left: &mut usize,
    depth: usize,
    limits: Limits,
) -> R<()> {
    tick(left, depth, limits)?;
    match t {
        Schema::Unit => {
            if !v.is_null() {
                return Err("expected Unit".into());
            }
        }
        Schema::Bool => out.push(v.as_bool().ok_or("expected Bool")? as u8),
        Schema::U32 => out.extend_from_slice(
            &u32::try_from(v.as_u64().ok_or("expected u32")?)
                .map_err(|_| "u32 overflow")?
                .to_le_bytes(),
        ),
        Schema::U64 => u64_bytes(out, v.as_u64().ok_or("expected u64")?),
        Schema::I32 => out.extend_from_slice(
            &i32::try_from(v.as_i64().ok_or("expected i32")?)
                .map_err(|_| "i32 overflow")?
                .to_le_bytes(),
        ),
        Schema::F32 => {
            let bits = if let Some(b) = v.get("F32Bits") {
                if v.as_object().is_none_or(|o| o.len() != 1) {
                    return Err("expected only F32Bits field".into());
                }
                u32::try_from(b.as_u64().ok_or("expected f32 bits")?)
                    .map_err(|_| "f32 bits overflow")?
            } else {
                let f = v.as_f64().ok_or("expected f32")? as f32;
                if !f.is_finite() {
                    return Err("finite f32 or F32Bits required".into());
                }
                f.to_bits()
            };
            out.extend_from_slice(&bits.to_le_bytes());
        }
        Schema::Vector(inner, n) => {
            if !(2..=4).contains(n)
                || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
            {
                return Err("invalid vector schema".into());
            }
            let xs = v.as_array().ok_or("expected vector")?;
            if xs.len() != *n as usize {
                return Err("vector dimension mismatch".into());
            }
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Int => {
            let n = integer(v)?;
            let (sign, b) = n.to_bytes_le();
            out.push(match sign {
                Sign::NoSign => 0,
                Sign::Plus => 1,
                Sign::Minus => 2,
            });
            if sign == Sign::NoSign {
                raw(out, &[])
            } else {
                raw(out, &b)
            }
        }
        Schema::String => raw(out, v.as_str().ok_or("expected String")?.as_bytes()),
        Schema::Id => out.extend_from_slice(&identifier(v)?.to_le_bytes()),
        Schema::Enum(names) => {
            let s = v.as_str().ok_or("expected enum string")?;
            let index = names
                .iter()
                .position(|n| n == s)
                .ok_or("unknown enum variant")?;
            out.extend_from_slice(&(index as u32).to_le_bytes());
        }
        Schema::Record(fields) => {
            let obj = v.as_object().ok_or("expected record")?;
            if obj.len() != fields.len() {
                return Err("record field mismatch".into());
            }
            for (n, t) in fields {
                encode_value(
                    t,
                    obj.get(n).ok_or("missing record field")?,
                    out,
                    left,
                    depth + 1,
                    limits,
                )?;
            }
        }
        Schema::List(inner) => {
            let xs = v.as_array().ok_or("expected List")?;
            if xs.len() > *left {
                return Err("snapshot value limit exceeded".into());
            }
            count(out, xs.len());
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Option(inner) => {
            if let Ok(x) = tag(v, "Some") {
                out.push(1);
                encode_value(inner, x, out, left, depth + 1, limits)?;
            } else {
                if !tag(v, "None")?.is_null() {
                    return Err("invalid None".into());
                }
                out.push(0);
            }
        }
        Schema::Result(a, b) => {
            if let Ok(x) = tag(v, "Ok") {
                out.push(0);
                encode_value(a, x, out, left, depth + 1, limits)?;
            } else {
                out.push(1);
                encode_value(b, tag(v, "Err")?, out, left, depth + 1, limits)?;
            }
        }
    }
    if out.len() > limits.bytes {
        return Err("snapshot byte limit exceeded".into());
    }
    Ok(())
}
struct Reader<'a> {
    bytes: &'a [u8],
    at: usize,
    left: usize,
    limits: Limits,
}
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> R<&'a [u8]> {
        let end = self.at.checked_add(n).ok_or("snapshot length overflow")?;
        let b = self.bytes.get(self.at..end).ok_or("truncated snapshot")?;
        self.at = end;
        Ok(b)
    }
    fn byte(&mut self) -> R<u8> {
        Ok(self.take(1)?[0])
    }
    fn u32(&mut self) -> R<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn u64(&mut self) -> R<u64> {
        Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
    fn len(&mut self) -> R<usize> {
        usize::try_from(self.u64()?).map_err(|_| "snapshot length not addressable".into())
    }
    fn sequence(&mut self) -> R<usize> {
        let n = self.len()?;
        if n > self.left {
            return Err("snapshot value limit exceeded".into());
        }
        Ok(n)
    }
    fn raw(&mut self) -> R<&'a [u8]> {
        let n = self.len()?;
        self.take(n)
    }
    fn value(&mut self, t: &Schema, depth: usize) -> R<Value> {
        tick(&mut self.left, depth, self.limits)?;
        Ok(match t {
            Schema::Unit => Value::Null,
            Schema::Bool => match self.byte()? {
                0 => json!(false),
                1 => json!(true),
                _ => return Err("invalid Bool tag".into()),
            },
            Schema::U32 => json!(self.u32()?),
            Schema::U64 => json!(self.u64()?),
            Schema::I32 => json!(self.u32()? as i32),
            Schema::F32 => {
                let bits = self.u32()?;
                let f = f32::from_bits(bits);
                if f.is_finite() {
                    json!(f)
                } else {
                    json!({"F32Bits":bits})
                }
            }
            Schema::Vector(inner, n) => {
                if !(2..=4).contains(n)
                    || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
                {
                    return Err("invalid vector schema".into());
                }
                (0..*n)
                    .map(|_| self.value(inner, depth + 1))
                    .collect::<R<Vec<_>>>()?
                    .into()
            }
            Schema::Int => {
                let sign = self.byte()?;
                let bytes = self.raw()?;
                if bytes.len() > MAX_INT_BYTES {
                    return Err("snapshot Int exceeds size limit".into());
                }
                let sign = match sign {
                    0 if bytes.is_empty() => Sign::NoSign,
                    1 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Plus,
                    2 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Minus,
                    _ => return Err("noncanonical signed integer".into()),
                };
                json!({"Int":BigInt::from_bytes_le(sign,bytes).to_string()})
            }
            Schema::String => json!(std::str::from_utf8(self.raw()?).map_err(|_| "invalid UTF-8")?),
            Schema::Id => json!(format!(
                "{:032x}",
                u128::from_le_bytes(self.take(16)?.try_into().unwrap())
            )),
            Schema::Enum(names) => {
                json!(names.get(self.u32()? as usize).ok_or("invalid enum tag")?)
            }
            Schema::Record(fields) => {
                let mut obj = serde_json::Map::new();
                for (n, t) in fields {
                    obj.insert(n.clone(), self.value(t, depth + 1)?);
                }
                Value::Object(obj)
            }
            Schema::List(t) => {
                let n = self.sequence()?;
                let mut xs = Vec::new();
                for _ in 0..n {
                    xs.push(self.value(t, depth + 1)?);
                }
                Value::Array(xs)
            }
            Schema::Option(t) => match self.byte()? {
                0 => json!({"None":null}),
                1 => json!({"Some":self.value(t,depth+1)?}),
                _ => return Err("invalid Option tag".into()),
            },
            Schema::Result(a, b) => match self.byte()? {
                0 => json!({"Ok":self.value(a,depth+1)?}),
                1 => json!({"Err":self.value(b,depth+1)?}),
                _ => return Err("invalid Result tag".into()),
            },
        })
    }
}
fn event_order(e: &Event, version: u64, prior: Option<(u64, u64)>) -> R<()> {
    if e.commit == 0 || e.commit > version || prior.is_some_and(|p| p >= (e.commit, e.position)) {
        return Err("invalid snapshot event sequence".into());
    }
    Ok(())
}
pub fn encode(layout: &Layout, s: &Logical, limits: Limits) -> R<Vec<u8>> {
    if s.tables.len() != layout.roots.len() {
        return Err("snapshot root count mismatch".into());
    }
    let mut out = Vec::new();
    let mut left = limits.values;
    u64_bytes(&mut out, s.version);
    for (rows, (_, kt, vt)) in s.tables.iter().zip(&layout.roots) {
        if rows.len() > left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        count(&mut out, rows.len());
        let mut prior = None;
        for (k, v) in rows {
            if let Some(p) = prior {
                if compare(kt, p, k)? != Ordering::Less {
                    return Err("snapshot keys must be strictly ordered".into());
                }
            }
            encode_value(kt, k, &mut out, &mut left, 0, limits)?;
            encode_value(vt, v, &mut out, &mut left, 0, limits)?;
            prior = Some(k);
        }
    }
    count(&mut out, s.outbox.len());
    let mut prior = None;
    for e in &s.outbox {
        event_order(e, s.version, prior)?;
        let (_, t) = layout
            .events
            .get(e.channel)
            .ok_or("unknown event channel")?;
        u64_bytes(&mut out, e.commit);
        u64_bytes(&mut out, e.position);
        out.extend_from_slice(&(e.channel as u32).to_le_bytes());
        encode_value(t, &e.value, &mut out, &mut left, 0, limits)?;
        prior = Some((e.commit, e.position));
    }
    if HEADER
        .checked_add(out.len())
        .and_then(|n| n.checked_add(32))
        .is_none_or(|n| n > limits.bytes)
    {
        return Err("snapshot byte limit exceeded".into());
    }
    let mut bytes = Vec::new();
    bytes.extend_from_slice(MAGIC);
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&layout.program);
    bytes.extend_from_slice(&layout.schema);
    count(&mut bytes, out.len());
    bytes.extend_from_slice(&out);
    let digest = Sha256::digest(&bytes);
    bytes.extend_from_slice(&digest);
    Ok(bytes)
}
pub fn decode(layout: &Layout, bytes: &[u8], limits: Limits) -> R<Logical> {
    if bytes.len() > limits.bytes || bytes.len() < HEADER + 32 {
        return Err("snapshot byte length invalid".into());
    }
    if &bytes[..8] != MAGIC || bytes[8..12] != [1, 0, 1, 0] {
        return Err("snapshot format or semantics version mismatch".into());
    }
    if bytes[12..44] != layout.program || bytes[44..76] != layout.schema {
        return Err("snapshot program or schema identity mismatch".into());
    }
    let n = usize::try_from(u64::from_le_bytes(bytes[76..84].try_into().unwrap()))
        .map_err(|_| "snapshot length not addressable")?;
    if HEADER.checked_add(n).and_then(|v| v.checked_add(32)) != Some(bytes.len()) {
        return Err("snapshot payload length mismatch".into());
    }
    let end = bytes.len() - 32;
    if Sha256::digest(&bytes[..end]).as_slice() != &bytes[end..] {
        return Err("snapshot integrity check failed".into());
    }
    let mut r = Reader {
        bytes: &bytes[HEADER..end],
        at: 0,
        left: limits.values,
        limits,
    };
    let version = r.u64()?;
    let mut tables = vec![];
    for (_, kt, vt) in &layout.roots {
        let n = r.sequence()?;
        if n > r.left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        let mut rows: Vec<(Value, Value)> = vec![];
        for _ in 0..n {
            let k = r.value(kt, 0)?;
            let v = r.value(vt, 0)?;
            if let Some((prior, _)) = rows.last() {
                if compare(kt, prior, &k)? != Ordering::Less {
                    return Err("duplicate or unordered snapshot key".into());
                }
            }
            rows.push((k, v));
        }
        tables.push(rows);
    }
    let n = r.sequence()?;
    let mut outbox = vec![];
    let mut prior = None;
    for _ in 0..n {
        let commit = r.u64()?;
        let position = r.u64()?;
        let channel = r.u32()? as usize;
        let (_, t) = layout
            .events
            .get(channel)
            .ok_or("unknown snapshot event channel")?;
        let value = r.value(t, 0)?;
        let e = Event {
            commit,
            position,
            channel,
            value,
        };
        event_order(&e, version, prior)?;
        prior = Some((commit, position));
        outbox.push(e);
    }
    if r.at != r.bytes.len() {
        return Err("trailing snapshot payload".into());
    }
    Ok(Logical {
        version,
        tables,
        outbox,
    })
}

}
pub use portable::Limits as SnapshotLimits;
fn snapshot_layout()->portable::Layout{portable::Layout{program:[39, 157, 110, 160, 50, 177, 67, 219, 74, 159, 185, 95, 217, 23, 90, 243, 219, 40, 7, 6, 160, 224, 134, 101, 47, 101, 41, 78, 191, 120, 235, 178],schema:[53, 211, 22, 148, 136, 244, 152, 138, 65, 207, 129, 196, 245, 156, 237, 250, 108, 247, 213, 46, 78, 86, 144, 171, 22, 146, 85, 52, 152, 99, 69, 200],roots:vec![
("Inputs".into(),portable::Schema::U64,portable::Schema::List(Box::new(portable::Schema::U32))),
],events:vec![]}}
fn one_tag<'a>(v:&'a Json,_kind:&str)->Result<&'a serde_json::Map<String,Json>,String>{Ok(v.as_object().unwrap())}
fn read_0(v:&Json,d:usize)->Result<bool,String>{Ok(
v.as_bool().unwrap())}
fn write_0(v:&bool,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_1(v:&Json,d:usize)->Result<u64,String>{Ok(
v.as_u64().unwrap())}
fn write_1(v:&u64,d:usize)->Result<Json,String>{Ok(
{json!(v)})}
fn read_2(v:&Json,d:usize)->Result<u64,String>{Ok(
v.as_u64().unwrap())}
fn write_2(v:&u64,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_3(v:&Json,d:usize)->Result<D_65c64225237a0e23811c934f9c65fa43f3c929ad11e29457eb9119eb219d8346,String>{Ok(
{D_65c64225237a0e23811c934f9c65fa43f3c929ad11e29457eb9119eb219d8346::C0})}
fn write_3(v:&D_65c64225237a0e23811c934f9c65fa43f3c929ad11e29457eb9119eb219d8346,d:usize)->Result<Json,String>{Ok(
Json::Null)}
fn read_6(v:&Json,d:usize)->Result<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,String>{Ok(
{let xs=v.as_array().unwrap();let mut tail=D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0;for x in xs.iter().rev(){tail=D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(read_1(x,d+1)?,std::sync::Arc::new(tail));}tail})}
fn write_6(v:&D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,d:usize)->Result<Json,String>{Ok(
{let mut cursor=v;let mut xs=vec![];loop{match cursor{D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0=>break,D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(x,tail)=>{xs.push(write_1(x,d+1)?);cursor=tail.as_ref();}}}Json::Array(xs)})}
fn read_7(v:&Json,d:usize)->Result<D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026,String>{Ok(
{let xs=v.as_array().unwrap();let mut tail=D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C0;for x in xs.iter().rev(){tail=D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C1(std::sync::Arc::new(read_8(x,d+1)?),std::sync::Arc::new(tail));}tail})}
fn write_7(v:&D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026,d:usize)->Result<Json,String>{Ok(
{let mut cursor=v;let mut xs=vec![];loop{match cursor{D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C0=>break,D_1bed0cc0647bc3210984e6aeb14ebc71b729be46d4418fd801c7c97d9052d026::C1(x,tail)=>{xs.push(write_8(x,d+1)?);cursor=tail.as_ref();}}}Json::Array(xs)})}
fn read_8(v:&Json,d:usize)->Result<D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5,String>{Ok(
{let xs=v.as_object().unwrap();D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(read_1(xs.get("node").unwrap(),d+1)?,read_1(xs.get("priority").unwrap(),d+1)?)})}
fn write_8(v:&D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5,d:usize)->Result<Json,String>{Ok(
{let D_e6823ed0f62ebb2b214389664722743857bc3abe28f1cde5a96838d9b5fecce5::C0(b0,b1)=v;json!({"node":write_1(&b0,d+1)?,"priority":write_1(&b1,d+1)?})})}
fn read_11(v:&Json,d:usize)->Result<D_ea181aecd4a60ec6fb3737561b67d9ee7b10cbabdb8a455c94dfedd044eff0f6,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_ea181aecd4a60ec6fb3737561b67d9ee7b10cbabdb8a455c94dfedd044eff0f6::C1(read_1(x,d+1)?)}else{D_ea181aecd4a60ec6fb3737561b67d9ee7b10cbabdb8a455c94dfedd044eff0f6::C0}})}
fn write_11(v:&D_ea181aecd4a60ec6fb3737561b67d9ee7b10cbabdb8a455c94dfedd044eff0f6,d:usize)->Result<Json,String>{Ok(
match v{D_ea181aecd4a60ec6fb3737561b67d9ee7b10cbabdb8a455c94dfedd044eff0f6::C0=>json!({"None":null}),D_ea181aecd4a60ec6fb3737561b67d9ee7b10cbabdb8a455c94dfedd044eff0f6::C1(x)=>json!({"Some":write_1(x,d+1)?})})}
fn read_12(v:&Json,d:usize)->Result<D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3::C1(std::sync::Arc::new(read_6(x,d+1)?))}else{D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3::C0}})}
fn write_12(v:&D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3,d:usize)->Result<Json,String>{Ok(
match v{D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3::C0=>json!({"None":null}),D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3::C1(x)=>json!({"Some":write_6(x,d+1)?})})}
fn read_13(v:&Json,d:usize)->Result<D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C1(std::sync::Arc::new(read_8(x,d+1)?))}else{D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C0}})}
fn write_13(v:&D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3,d:usize)->Result<Json,String>{Ok(
match v{D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C0=>json!({"None":null}),D_f09905cc7af640978996db162361010685486f5632fbcffd9c5ecdcfcfb78dd3::C1(x)=>json!({"Some":write_8(x,d+1)?})})}
fn read_14(v:&Json,d:usize)->Result<D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d,String>{Ok(
{let xs=one_tag(v,"Result")?;if let Some(x)=xs.get("Ok"){D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C0(std::sync::Arc::new(read_3(x,d+1)?))}else{let x=xs.get("Err").unwrap();D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C1(read_0(x,d+1)?)}})}
fn write_14(v:&D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d,d:usize)->Result<Json,String>{Ok(
match v{D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C0(x)=>json!({"Ok":write_3(x,d+1)?}),D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d::C1(x)=>json!({"Err":write_0(x,d+1)?})})}
fn logical_from_tables(tables:&[Vec<(Json,Json)>])->Result<D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333,String>{if tables.len()!=1{return Err("representation table count mismatch".into())}
let rows=&tables[0];let mut root0=D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C0;for (key,row) in rows.iter().rev(){root0=D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C1(read_2(key,0)?,std::sync::Arc::new(read_6(row,0)?),std::sync::Arc::new(root0));}
Ok(D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(std::sync::Arc::new(root0)))}
fn logical_tables(state:&D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333)->Result<Vec<Vec<(Json,Json)>>,String>{let D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(r0)=state;
let mut rows0=vec![];let mut cursor=r0.as_ref();loop{match cursor{D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C0=>break,D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C1(key,value,tail)=>{rows0.push((write_2(key,0)?,write_6(value,0)?));cursor=tail.as_ref();}}}
Ok(vec![rows0])}
fn logical_events(events:&D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44)->Result<Vec<(usize,Json)>,String>{let mut cursor=events;let mut out=vec![];loop{match cursor{D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44::C0=>break,D_50d2652da71e69081bc5957753d69b6aaa190fada2825185fa26ba4cc9922a44::C1(event,tail)=>{let value=match event.as_ref(){
D_b62e83ea6ba1bb4c8818da50869e95eb2e3541a4fd95e5251c2d6b998acfeadb::C0=>return Err("unknown source event".into()),
};out.push(value);cursor=tail.as_ref();}}}Ok(out)}
pub use portable::Event;
pub struct Outcome<T>{pub result:T,pub committed:bool,pub version:u64,pub events:Vec<Event>}
pub struct OutcomeView<'a,T>{pub result:T,pub committed:bool,pub version:u64,pub events:&'a[Event]}
impl<T> OutcomeView<'_,T>{pub fn into_owned(self)->Outcome<T>{Outcome{result:self.result,committed:self.committed,version:self.version,events:self.events.to_vec()}}}
pub struct State{physical:D_dffc63fc561e68a59150d73e1af9ef3e1cada68106ad80343ccededa79195351,version:u64,outbox:Vec<portable::Event>,layout:portable::Layout}
impl State{
// CALLER CONTRACT: arguments must have the declared types and canonical values.
// No runtime type validation. Malformed input may panic, trap or corrupt state.
pub fn new()->Result<Self,String>{let logical=D_24d05f1897e36077e40441148b84ee9329332f247b0ae7cab022f468fc67c333::C0(std::sync::Arc::new(D_8665f4552fba37fd81a962bcb21a693462a90f1be293a21a738c7506b651b8e0::C0));Ok(Self{physical:f_5b2b561b43fbc9fc3b1c470f965430122b532b97f0581c7596cfdaaa39f2da33(&logical),version:0,outbox:vec![],layout:snapshot_layout()})}
pub fn restore(bytes:&[u8])->Result<Self,String>{let layout=snapshot_layout();let saved=portable::decode(&layout,bytes,SnapshotLimits::default())?;let logical=logical_from_tables(&saved.tables)?;Ok(Self{physical:f_5b2b561b43fbc9fc3b1c470f965430122b532b97f0581c7596cfdaaa39f2da33(&logical),version:saved.version,outbox:saved.outbox,layout})}
pub fn checkpoint(&self)->Result<Vec<u8>,String>{let logical=f_7f545b4f2164568b6108b56e37fbd551317029cc2531ad7eb19a551e557bcbfd(&(self.physical));portable::encode(&self.layout,&portable::Logical{version:self.version,tables:logical_tables(&logical)?,outbox:self.outbox.clone()},SnapshotLimits::default())}
pub fn version(&self)->u64{self.version}
pub fn outbox_json(&self)->Json{Json::Array(self.outbox.iter().map(|e|json!({"commit":e.commit,"position":e.position,"channel":self.layout.events[e.channel].0,"value":e.value})).collect())}
pub fn acknowledge_through(&mut self,commit:u64,position:u64){self.outbox.retain(|e|(e.commit,e.position)>(commit,position));}
pub fn query_sorted(&self,)->D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3{q_3027189a800129e578400787a58af9a0f869d870318e640ea8c20e92a4716ed3(&(self.physical),self.version)}
pub fn query_get(&self,a0:u64)->D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3{q_fb1484fbdc138711cc4400b91bbad519648ae8a58d5cbc2b1ddaddd9e39a78ba(&(self.physical),self.version,a0)}
pub fn invoke_view_put(&mut self,a0:u64,a1:&D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,a2:bool)->Result<OutcomeView<'_,D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d>,String>{
let executed=f_2620718ccbe9b25373b24bbf81c9b02b150bb6d1a96ff326d544d5d226565846(&(self.physical),self.version,a0,a1,a2);let observed=f_b34f65a4ac99fc61943805e138e0962ea60ed5e82d8e63113d404875b447ca37(&(executed));let next=f_361b33126df4c584aa0e1127c93c1ebf0ef95d5dc1359d5ff7d7115a4076be7c(&(executed));
let(result,committed,version,events)=match &observed{D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_erase(&mut self,a0:u64,a1:bool)->Result<OutcomeView<'_,D_8fb14104127d4588a0afebc43ecb6ea2d4d876435b463539861714a8cb32288d>,String>{
let executed=f_0ee743a0ab5550a7e4f886fe6a049d5d611588bcbcb3aa38832e3e8496fedeba(&(self.physical),self.version,a0,a1);let observed=f_b34f65a4ac99fc61943805e138e0962ea60ed5e82d8e63113d404875b447ca37(&(executed));let next=f_361b33126df4c584aa0e1127c93c1ebf0ef95d5dc1359d5ff7d7115a4076be7c(&(executed));
let(result,committed,version,events)=match &observed{D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_sorted(&mut self,)->Result<OutcomeView<'_,D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3>,String>{
let result=q_3027189a800129e578400787a58af9a0f869d870318e640ea8c20e92a4716ed3(&(self.physical),self.version);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_view_get(&mut self,a0:u64)->Result<OutcomeView<'_,D_3a20e3fcca28c0ee5f1747c791ed90fd54ed0b6c75188d45d78f7dcd68abe2b3>,String>{
let result=q_fb1484fbdc138711cc4400b91bbad519648ae8a58d5cbc2b1ddaddd9e39a78ba(&(self.physical),self.version,a0);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_json(&mut self,name:&str,args:&Json)->Result<Json,String>{match name{
"put"=>{let xs=args.as_array().unwrap();
let a0=read_2(&xs[0],0)?;
let a1=read_6(&xs[1],0)?;
let a2=read_0(&xs[2],0)?;
let executed=f_2620718ccbe9b25373b24bbf81c9b02b150bb6d1a96ff326d544d5d226565846(&(self.physical),self.version,a0,&(a1),a2);
let observed=f_b34f65a4ac99fc61943805e138e0962ea60ed5e82d8e63113d404875b447ca37(&(executed));let next=f_361b33126df4c584aa0e1127c93c1ebf0ef95d5dc1359d5ff7d7115a4076be7c(&(executed));let(reply,committed,version,events)=match &observed{D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_14(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&[];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"erase"=>{let xs=args.as_array().unwrap();
let a0=read_2(&xs[0],0)?;
let a1=read_0(&xs[1],0)?;
let executed=f_0ee743a0ab5550a7e4f886fe6a049d5d611588bcbcb3aa38832e3e8496fedeba(&(self.physical),self.version,a0,a1);
let observed=f_b34f65a4ac99fc61943805e138e0962ea60ed5e82d8e63113d404875b447ca37(&(executed));let next=f_361b33126df4c584aa0e1127c93c1ebf0ef95d5dc1359d5ff7d7115a4076be7c(&(executed));let(reply,committed,version,events)=match &observed{D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_79dd0c8568b30cfd5f1f8ab842cefbdda35f9879b519db52a5df27fe57a635ef::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_14(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&[];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"sorted"=>{let xs=args.as_array().unwrap();
let reply=q_3027189a800129e578400787a58af9a0f869d870318e640ea8c20e92a4716ed3(&(self.physical),self.version);let result=write_12(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
"get"=>{let xs=args.as_array().unwrap();
let a0=read_2(&xs[0],0)?;
let reply=q_fb1484fbdc138711cc4400b91bbad519648ae8a58d5cbc2b1ddaddd9e39a78ba(&(self.physical),self.version,a0);let result=write_12(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
_=>Err(format!("unknown action {name}"))}}}
