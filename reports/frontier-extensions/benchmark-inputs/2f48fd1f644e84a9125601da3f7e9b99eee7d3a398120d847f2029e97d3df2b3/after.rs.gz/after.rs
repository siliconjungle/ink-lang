// ink-definition-rust-v1: checked bodies; Rust/backend are trusted.
#![allow(non_camel_case_types, non_snake_case, non_upper_case_globals, dead_code, unused_variables, unused_parens, unused_unsafe, improper_ctypes_definitions)]
fn d_002fa87dc14fb22703d067bc5256bb42a441ff9bc957fdd023ea162e558462ba(v0: &D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd,v1: u64) -> bool { match &(d_8f49b0501dc5088b5b1fbb496bf7a43da0fc57cc982a3223cec950add0d80d8c(v0,v1)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { false },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v2) => { true } } }
fn d_03ff34b5386d1e23ed93a530286dcfa18b3c56053b5eabeb72372c1a2a11723b(v3: &D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b,v4: u64) -> D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea { match v3 { D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C0 => { D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea::C0 },D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C1(v6,v7,v8) => { if ((v4) == (*v6)) { D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea::C1(*v7) } else { d_03ff34b5386d1e23ed93a530286dcfa18b3c56053b5eabeb72372c1a2a11723b(v8.as_ref(),v4) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7 { C0 }
impl D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_09057230fba3197d24acf11d85f672c6c272b2c13015c0be441b90f6e99d6967(v9: &D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4,v10: u64,v11: u64,v12: &D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c,v13: bool) -> D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9 { match &(D_ed742c79021c129a74c485de3fde12f113f9e1f62fcdff87129f05a60f244981::C0(std::sync::Arc::new(match v9 { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v14) => { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::new(d_cf1230bd75cb8423314de8b7d3f4d503a062de575d48e96f3c36c0da9dcc1bce(&(match v9 { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v15) => { (v15.as_ref()).clone() } }),v11))) } }))) { D_ed742c79021c129a74c485de3fde12f113f9e1f62fcdff87129f05a60f244981::C0(v16) => { if d_5d52ea5a8e356f04093cac1a6710051c7c2d51db1cd9d2dfd20c3fd5caf5fb77(&(match v16.as_ref() { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v17) => { (v17.as_ref()).clone() } }),v11) { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(2u64,v10,std::sync::Arc::new((v9).clone())) } else { match &(D_ed742c79021c129a74c485de3fde12f113f9e1f62fcdff87129f05a60f244981::C0(std::sync::Arc::new(match v16.as_ref() { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v18) => { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::new(d_43bae9f2ef5694c4b79528f373bcea8d176e1e4987e703eee8ce693cd749aa53(&(match v16.as_ref() { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v19) => { (v19.as_ref()).clone() } }),v11,v12))) } }))) { D_ed742c79021c129a74c485de3fde12f113f9e1f62fcdff87129f05a60f244981::C0(v20) => { if v13 { match &(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(true)) { D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(v22) => { if ((v10) == (18446744073709551615u64)) { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(1u64,v10,std::sync::Arc::new((v9).clone())) } else { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(std::sync::Arc::new(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(std::sync::Arc::clone(v22))),true,(v10).wrapping_add(1u64),std::sync::Arc::clone(v20),std::sync::Arc::clone({static v23:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v23.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) } },D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(v24) => { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(std::sync::Arc::new(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(*v24)),false,v10,std::sync::Arc::new((v9).clone()),std::sync::Arc::clone({static v25:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v25.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) } } } else { match &(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(std::sync::Arc::clone({static v26:std::sync::OnceLock<std::sync::Arc<D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7>>=std::sync::OnceLock::new();v26.get_or_init(||std::sync::Arc::new(D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7::C0))}))) { D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(v28) => { if ((v10) == (18446744073709551615u64)) { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(1u64,v10,std::sync::Arc::new((v9).clone())) } else { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(std::sync::Arc::new(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(std::sync::Arc::clone(v28))),true,(v10).wrapping_add(1u64),std::sync::Arc::clone(v20),std::sync::Arc::clone({static v29:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v29.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) } },D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(v30) => { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(std::sync::Arc::new(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(*v30)),false,v10,std::sync::Arc::new((v9).clone()),std::sync::Arc::clone({static v31:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v31.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) } } } } } } } } }
fn d_0ed0c70186c5d63822b08f5fba5ddd2bccbdb0d4cf4eebe37775cb2841f7cecd(v32: &D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4,v33: u64,v34: u64) -> D_c4723b47c6e1d6bbaad257312e3775ae8ebc3ada669ec51045f34d4aefe99a68 { D_c4723b47c6e1d6bbaad257312e3775ae8ebc3ada669ec51045f34d4aefe99a68::C0(std::sync::Arc::new(d_201e280f19da197f80aaeeb90891c2afb639627134c77648eaa04371e3b5cdd6(&(match v32 { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v35) => { (v35.as_ref()).clone() } }),v34)),false,v33,std::sync::Arc::new((v32).clone()),std::sync::Arc::clone({static v36:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v36.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) }
fn d_10474bbc4ac74580f8be4e0fa212cee2c299d6988c03e31fe5089407d8cf0f2a(v37: &D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd,v38: u64,v39: u64) -> D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd { match v37 { D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C0 => { D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C1(v38,v39,std::sync::Arc::clone({static v40:std::sync::OnceLock<std::sync::Arc<D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd>>=std::sync::OnceLock::new();v40.get_or_init(||std::sync::Arc::new(D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C0))})) },D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C1(v41,v42,v43) => { if ((v38) < (*v41)) { D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C1(v38,v39,std::sync::Arc::new((v37).clone())) } else { D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C1(*v41,*v42,std::sync::Arc::new(d_10474bbc4ac74580f8be4e0fa212cee2c299d6988c03e31fe5089407d8cf0f2a(v43.as_ref(),v38,v39))) } } } }
fn d_1130456dc988c7b056c44f00ceed17b2362b848048cadc72cae8f9cb20efff83(v44: &D_987bdfeb29bf8c8194a0380157fa972a9aebb1b88b0f37bccc3668daaa1dd78f) -> D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14 { match v44 { D_987bdfeb29bf8c8194a0380157fa972a9aebb1b88b0f37bccc3668daaa1dd78f::C0(v45,v46) => { (v45.as_ref()).clone() } } }
fn d_1338047bd9cf52a17a4e86ffc009b659e90ff924cb48778cbcac39b169b0bbeb(v47: &D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301) -> D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9 { match v47 { D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301::C0 => { D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0 },D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301::C1(v49) => { D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (1u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (2u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (4u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (8u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (16u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (32u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (64u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (128u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (256u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (512u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (1024u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (2048u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (4096u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (8192u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (16384u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (32768u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (65536u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (131072u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (262144u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (524288u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (1048576u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (2097152u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (4194304u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (8388608u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (16777216u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (33554432u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (67108864u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (134217728u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (268435456u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (536870912u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (1073741824u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v49) & (2147483648u64))) != (0u64)),std::sync::Arc::clone({static v50:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v50.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0))})))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8 { C0,C1(u64,std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>) }
impl D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_201e280f19da197f80aaeeb90891c2afb639627134c77648eaa04371e3b5cdd6(v51: &D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462,v52: u64) -> D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2 { match v51 { D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0 => { D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C0 },D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(v54,v55,v56) => { if ((v52) == (*v54)) { D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C1(std::sync::Arc::clone(v55)) } else { d_201e280f19da197f80aaeeb90891c2afb639627134c77648eaa04371e3b5cdd6(v56.as_ref(),v52) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_2039380a191f87da8dbfd810ad313b62244825a051b4c0c3de52b6715baca512 { C0(std::sync::Arc<D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60>,bool,u64,std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>,std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>),C1(u64,u64,std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>) }
fn d_2293f25d58473c8c330a164f34117e9631296ac9eb2da0c26cb3fd0ce8cf093a(v57: &D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14,v58: u64,v59: u64) -> D_a73d54a65b8fc10db9e4a27ae68f045ef114804bfd375842190af18c88d39668 { D_a73d54a65b8fc10db9e4a27ae68f045ef114804bfd375842190af18c88d39668::C0(std::sync::Arc::new((v57).clone()),std::sync::Arc::new(d_0ed0c70186c5d63822b08f5fba5ddd2bccbdb0d4cf4eebe37775cb2841f7cecd(&(d_9f081cafe208680fa809ebb2efd71869fec94cb8acec485086fb085da04e3876(v57)),v58,v59))) }
fn d_233173ac9b19280e2ca75fd60b2c1eec94767f63b49507f3b5639702c686f8aa(v60: &D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9,v61: u64,v62: u64,v63: &D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39) -> D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39 { if if ((v61) == (0u64)) { true } else { if match v63 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v64,v65,v66,v67,v68,v69,v70,v71,v72,v73) => { *v71 } } { true } else { ((d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(&(match v63 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v74,v75,v76,v77,v78,v79,v80,v81,v82,v83) => { (v75.as_ref()).clone() } }))) == (0u64)) } } { (v63).clone() } else { match v60 { D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0 => { (v63).clone() },D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(v84,v85) => { if *v84 { match &(D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(std::sync::Arc::new(d_233173ac9b19280e2ca75fd60b2c1eec94767f63b49507f3b5639702c686f8aa(v85.as_ref(),(v61).checked_div(2u64).unwrap_or(0),(((v62).wrapping_add((v61).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_233173ac9b19280e2ca75fd60b2c1eec94767f63b49507f3b5639702c686f8aa(v85.as_ref(),(v61).checked_div(2u64).unwrap_or(0),v62,v63)))))) { D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(v86) => { if if match v86.as_ref() { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v87,v88,v89,v90,v91,v92,v93,v94,v95,v96) => { *v94 } } { true } else { ((d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(&(match v86.as_ref() { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v97,v98,v99,v100,v101,v102,v103,v104,v105,v106) => { (v98.as_ref()).clone() } }))) == (0u64)) } { (v86.as_ref()).clone() } else { d_599d0232d36959692a62209d86c61353da0eb94a68384f34652c80554a65fc29(v86.as_ref()) } } } } else { d_233173ac9b19280e2ca75fd60b2c1eec94767f63b49507f3b5639702c686f8aa(v85.as_ref(),(v61).checked_div(2u64).unwrap_or(0),(((v62).wrapping_add((v61).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_233173ac9b19280e2ca75fd60b2c1eec94767f63b49507f3b5639702c686f8aa(v85.as_ref(),(v61).checked_div(2u64).unwrap_or(0),v62,v63))) } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14 { C0(std::sync::Arc<D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462>,std::sync::Arc<D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60>) }
fn d_296c1313f43a3560a3058dea7dce95704f2bd50167c5009ee44c913ebf0341d9(v107: &D_987bdfeb29bf8c8194a0380157fa972a9aebb1b88b0f37bccc3668daaa1dd78f) -> D_2039380a191f87da8dbfd810ad313b62244825a051b4c0c3de52b6715baca512 { match v107 { D_987bdfeb29bf8c8194a0380157fa972a9aebb1b88b0f37bccc3668daaa1dd78f::C0(v108,v109) => { (v109.as_ref()).clone() } } }
fn d_2a8097b87d95e141f8f75c743ae736666ee38a1239b6ac0bf1df9446c69329bd(v110: &D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14,v111: u64) -> D_987bdfeb29bf8c8194a0380157fa972a9aebb1b88b0f37bccc3668daaa1dd78f { match v110 { D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14::C0(v112,v113) => { D_987bdfeb29bf8c8194a0380157fa972a9aebb1b88b0f37bccc3668daaa1dd78f::C0(std::sync::Arc::new((v110).clone()),std::sync::Arc::new(D_2039380a191f87da8dbfd810ad313b62244825a051b4c0c3de52b6715baca512::C0(std::sync::Arc::clone(v113),false,v111,std::sync::Arc::new(D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::clone(v112))),std::sync::Arc::clone({static v114:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v114.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})))) } } }
fn d_2b69c64cbe72e93b1b88f554091ce5857248e729631172c1b5518c2642c807f2(v115: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8) -> D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8 { match v115 { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 => { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 },D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v117,v118) => { if false { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(*v117,std::sync::Arc::new(d_2b69c64cbe72e93b1b88f554091ce5857248e729631172c1b5518c2642c807f2(v118.as_ref()))) } else { d_2b69c64cbe72e93b1b88f554091ce5857248e729631172c1b5518c2642c807f2(v118.as_ref()) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b { C0,C1(u64,bool,std::sync::Arc<D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b>) }
impl D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c { C0(std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>,u64,u64,u64,u64) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871 { C0,C1(std::sync::Arc<D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f>,std::sync::Arc<D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871>) }
impl D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301 { C0,C1(u64) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd { C0(std::sync::Arc<D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7>),C1(bool) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d { C0(std::sync::Arc<D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871>,u64,bool) }
fn d_3ec78a35272ed91061dacb8c052a158f10da108f6d53693c7b0661117c1a477a(v119: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v120: u64) -> D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531 { match v119 { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 => { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 },D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v122,v123) => { if ((v120) == (0u64)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(*v122) } else { d_3ec78a35272ed91061dacb8c052a158f10da108f6d53693c7b0661117c1a477a(v123.as_ref(),(((v120).wrapping_sub(1u64)) & (4294967295u64))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39 { C0(std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>,std::sync::Arc<D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871>,std::sync::Arc<D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd>,std::sync::Arc<D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b>,std::sync::Arc<D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd>,u64,u64,bool,u64,u64) }
fn d_40f81830bbf4127535b60ab6c9d54b1ffed69633c3d1e8eb4c12f7e778f3d35f(v124: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v125: u64) -> D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8 { match v124 { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 => { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v125,std::sync::Arc::clone({static v126:std::sync::OnceLock<std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>>=std::sync::OnceLock::new();v126.get_or_init(||std::sync::Arc::new(D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0))})) },D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v127,v128) => { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(*v127,std::sync::Arc::new(d_40f81830bbf4127535b60ab6c9d54b1ffed69633c3d1e8eb4c12f7e778f3d35f(v128.as_ref(),v125))) } } }
fn d_43bae9f2ef5694c4b79528f373bcea8d176e1e4987e703eee8ce693cd749aa53(v129: &D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462,v130: u64,v131: &D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c) -> D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462 { match v129 { D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0 => { D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(v130,std::sync::Arc::new((v131).clone()),std::sync::Arc::clone({static v132:std::sync::OnceLock<std::sync::Arc<D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462>>=std::sync::OnceLock::new();v132.get_or_init(||std::sync::Arc::new(D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0))})) },D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(v133,v134,v135) => { if ((v130) < (*v133)) { D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(v130,std::sync::Arc::new((v131).clone()),std::sync::Arc::new((v129).clone())) } else { D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(*v133,std::sync::Arc::clone(v134),std::sync::Arc::new(d_43bae9f2ef5694c4b79528f373bcea8d176e1e4987e703eee8ce693cd749aa53(v135.as_ref(),v130,v131))) } } } }
fn d_4662356d4b7aebe6e74645c080deab29c301ad4662c930b428d106d4173c856a(v136: &D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d) -> D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(&(match v136 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v137,v138,v139) => { (v137.as_ref()).clone() } })))) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v140) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(((((((match v136 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v141,v142,v143) => { *v142 } }).wrapping_mul(2u64)) & (4294967295u64))).wrapping_add(1u64)) & (4294967295u64)))) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v144) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0((((*v144).wrapping_add(1u64)) & (4294967295u64)))) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v145) => { match &(D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v136 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v146,v147,v148) => { (v146.as_ref()).clone() } }),*v144)) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(0u64,4294967295u64) },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v150) => { (v150.as_ref()).clone() } }))) { D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(v151) => { match &(D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v136 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v152,v153,v154) => { (v152.as_ref()).clone() } }),*v145)) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(0u64,4294967295u64) },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v156) => { (v156.as_ref()).clone() } }))) { D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(v157) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(if if ((*v145) < (*v140)) { d_9d672de3566f4e7ec38116f403ea277b7973fb397b44426e3ee7adf21bcd723f(v157.as_ref(),v151.as_ref()) } else { false } { *v145 } else { *v144 })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v158) => { match &(D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v136 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v159,v160,v161) => { (v159.as_ref()).clone() } }),*v158)) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(0u64,4294967295u64) },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v163) => { (v163.as_ref()).clone() } }))) { D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(v164) => { match &(D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v136 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v165,v166,v167) => { (v165.as_ref()).clone() } }),match v136 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v168,v169,v170) => { *v169 } })) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(0u64,0u64) },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v172) => { (v172.as_ref()).clone() } }))) { D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(v173) => { if if ((*v158) < (*v140)) { d_9d672de3566f4e7ec38116f403ea277b7973fb397b44426e3ee7adf21bcd723f(v164.as_ref(),v173.as_ref()) } else { false } { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v136 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v174,v175,v176) => { (v174.as_ref()).clone() } }),match v136 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v177,v178,v179) => { *v178 } })) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { match v136 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v180,v181,v182) => { (v180.as_ref()).clone() } } },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v183) => { match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v136 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v184,v185,v186) => { (v184.as_ref()).clone() } }),*v158)) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { match v136 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v187,v188,v189) => { (v187.as_ref()).clone() } } },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v190) => { d_b10f15633b5bbc9018929e4e8d67975c090e74e014a600622b2f569ce4917ba5(&(d_b10f15633b5bbc9018929e4e8d67975c090e74e014a600622b2f569ce4917ba5(&(match v136 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v191,v192,v193) => { (v191.as_ref()).clone() } }),match v136 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v194,v195,v196) => { *v195 } },v190.as_ref())),*v158,v183.as_ref()) } } } }),*v158,false) } else { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(std::sync::Arc::new(match v136 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v197,v198,v199) => { (v197.as_ref()).clone() } }),match v136 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v200,v201,v202) => { *v201 } },true) } } } } } } } } } } } } } } } } } }
fn d_47c6f29a9d5998d7f45ab4ec06f6b1162f003207ed846fd9209f2d4070389862(v203: &D_a73d54a65b8fc10db9e4a27ae68f045ef114804bfd375842190af18c88d39668) -> D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14 { match v203 { D_a73d54a65b8fc10db9e4a27ae68f045ef114804bfd375842190af18c88d39668::C0(v204,v205) => { (v204.as_ref()).clone() } } }
fn d_49b4b487a9bdb1923937b225e1a5b44124ebdcaa2d08461230f80e63f8ca3344(v206: &D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14,v207: u64,v208: u64,v209: &D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c,v210: bool) -> D_85eb081cb2c18b3f9f242ecd82b001fb620e3ec27703b9bd0c819c588e91d440 { D_85eb081cb2c18b3f9f242ecd82b001fb620e3ec27703b9bd0c819c588e91d440::C0(std::sync::Arc::new(d_9b0edc5144547f0c2191f9385effd157d7f21cab86e806971e0f3dda1748bba4(v206)),std::sync::Arc::new(d_09057230fba3197d24acf11d85f672c6c272b2c13015c0be441b90f6e99d6967(&(d_9f081cafe208680fa809ebb2efd71869fec94cb8acec485086fb085da04e3876(v206)),v207,v208,v209,v210))) }
fn d_4bcaeacdd73d19550690c4a882fec63ee438037ded707163ed56d320f45125a5(v211: &D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14,v212: u64,v213: u64,v214: bool) -> D_85eb081cb2c18b3f9f242ecd82b001fb620e3ec27703b9bd0c819c588e91d440 { D_85eb081cb2c18b3f9f242ecd82b001fb620e3ec27703b9bd0c819c588e91d440::C0(std::sync::Arc::new(d_9b0edc5144547f0c2191f9385effd157d7f21cab86e806971e0f3dda1748bba4(v211)),std::sync::Arc::new(d_9c3da9d34ec75222a22280aa83e3722a77986d6ed420dfb227c213c230e89897(&(d_9f081cafe208680fa809ebb2efd71869fec94cb8acec485086fb085da04e3876(v211)),v212,v213,v214))) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_4d68fd2c2ea116d87e7a4a150162c04ff1404fbc0d420ef69cf909b470f7e4a8 { C0(std::sync::Arc<D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_4e61cd2054b66259fa5fe6ff2848621d519f896c6b83b26615faed118e66c0c8 { C0 }
impl D_4e61cd2054b66259fa5fe6ff2848621d519f896c6b83b26615faed118e66c0c8{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_4e61cd2054b66259fa5fe6ff2848621d519f896c6b83b26615faed118e66c0c8{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_4e83072d158179b64b40df7986493710bb1d27812bc6ecdf11bb0c4a74d8c70d(v215: u64,v216: u64) -> u64 { if ((v215) > (v216)) { (((v215).wrapping_sub(v216)) & (4294967295u64)) } else { (((v216).wrapping_sub(v215)) & (4294967295u64)) } }
fn d_4fe8180484759596d66ae9f8476d235a3471baaf164ee96d74dafa98607dd2df(v217: &D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4) -> D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14 { match v217 { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v218) => { D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14::C0(std::sync::Arc::clone(v218),std::sync::Arc::new(match &(d_201e280f19da197f80aaeeb90891c2afb639627134c77648eaa04371e3b5cdd6(v218.as_ref(),0u64)) { D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C0 => { D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60::C0 },D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C1(v220) => { D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60::C1(std::sync::Arc::new(d_b49a17a751300394c261cc3b13d02c5f86514ef9f076c31c61a9a4ad1121d77f(&(match v220.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v221,v222,v223,v224,v225) => { (v221.as_ref()).clone() } }),match v220.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v226,v227,v228,v229,v230) => { *v227 } },match v220.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v231,v232,v233,v234,v235) => { *v233 } },match v220.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v236,v237,v238,v239,v240) => { *v239 } },match v220.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v241,v242,v243,v244,v245) => { *v245 } }))) } })) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243 { C0(std::sync::Arc<D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39>) }
fn d_54115d4ead942305e035cdfe49d61b727e56192d969e831e8b6c754a1c65c6f2(v246: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v247: u64,v248: u64,v249: u64,v250: u64) -> D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd { match &(D_7eea704e7e77d46b1d984e9cab6f33b597cec0eda67bef640bae88b296cdd277::C0(std::sync::Arc::clone({static v251:std::sync::OnceLock<std::sync::Arc<D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd>>=std::sync::OnceLock::new();v251.get_or_init(||std::sync::Arc::new(D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C0))}))) { D_7eea704e7e77d46b1d984e9cab6f33b597cec0eda67bef640bae88b296cdd277::C0(v253) => { match &(D_e76d71eacc94ee97e8a1a02d9b0750885675867ac52f6e28927a98226058c5ad::C0(std::sync::Arc::clone({static v254:std::sync::OnceLock<std::sync::Arc<D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871>>=std::sync::OnceLock::new();v254.get_or_init(||std::sync::Arc::new(D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0))}))) { D_e76d71eacc94ee97e8a1a02d9b0750885675867ac52f6e28927a98226058c5ad::C0(v256) => { match &(D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(std::sync::Arc::new(D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(std::sync::Arc::new((v246).clone()),std::sync::Arc::new(d_bf6aba90e46dc72ddc2215d097cea1f2923a96c4e3f4a35f12925a49df054182(v256.as_ref(),&(D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v248,d_9bb3ec8899fbd786e3a9c9196168dd3cb0314e9fe3d22b3d85e09e94d3dbe5cf(v248,v249,v247))))),std::sync::Arc::new(if d_002fa87dc14fb22703d067bc5256bb42a441ff9bc957fdd023ea162e558462ba(v253.as_ref(),v248) { d_5fe9167aff6b3b37e3ca66b5143100bd012f34939a1767db0e227ef4ac5bdb15(v253.as_ref(),v248,0u64) } else { d_10474bbc4ac74580f8be4e0fa212cee2c299d6988c03e31fe5089407d8cf0f2a(v253.as_ref(),v248,0u64) }),std::sync::Arc::clone({static v257:std::sync::OnceLock<std::sync::Arc<D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b>>=std::sync::OnceLock::new();v257.get_or_init(||std::sync::Arc::new(D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C0))}),std::sync::Arc::clone({static v258:std::sync::OnceLock<std::sync::Arc<D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd>>=std::sync::OnceLock::new();v258.get_or_init(||std::sync::Arc::new(D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C0))}),v247,v249,false,0u64,0u64)))) { D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(v259) => { match &(D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(std::sync::Arc::new(d_233173ac9b19280e2ca75fd60b2c1eec94767f63b49507f3b5639702c686f8aa(&(d_1338047bd9cf52a17a4e86ffc009b659e90ff924cb48778cbcac39b169b0bbeb(&(if ((v250) == (0u64)) { D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301::C0 } else { D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301::C1(v250) }))),v250,0u64,v259.as_ref())))) { D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(v261) => { d_9a6e77e0c0848f8c788a82eb6f3bec58f935fe6ed1104a61bbc9a86d40fd32fc(v261.as_ref(),v248) } } } } } } } } }
fn d_5505e7ee68449c43569a7ea9f8556dc190dcb184ac4512d57d25866601499382(v262: &D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b,v263: u64,v264: bool) -> D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b { match v262 { D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C0 => { D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C1(v263,v264,std::sync::Arc::clone({static v265:std::sync::OnceLock<std::sync::Arc<D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b>>=std::sync::OnceLock::new();v265.get_or_init(||std::sync::Arc::new(D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C0))})) },D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C1(v266,v267,v268) => { if ((v263) < (*v266)) { D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C1(v263,v264,std::sync::Arc::new((v262).clone())) } else { D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C1(*v266,*v267,std::sync::Arc::new(d_5505e7ee68449c43569a7ea9f8556dc190dcb184ac4512d57d25866601499382(v268.as_ref(),v263,v264))) } } } }
fn d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(v269: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8) -> u64 { match v269 { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 => { 0u64 },D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v270,v271) => { (((1u64).wrapping_add(d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(v271.as_ref()))) & (4294967295u64)) } } }
fn d_599d0232d36959692a62209d86c61353da0eb94a68384f34652c80554a65fc29(v272: &D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39) -> D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39 { match &(D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v272 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v273,v274,v275,v276,v277,v278,v279,v280,v281,v282) => { (v274.as_ref()).clone() } }),0u64)) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(0u64,0u64) },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v284) => { (v284.as_ref()).clone() } }))) { D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(v285) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(match v285.as_ref() { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v286,v287) => { *v286 } })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v288) => { match &(D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793::C0(d_675b1f4f897dbd6222dcc1a7905d41455272640b09efc4dda13c18702b3a72fd(&(match v272 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v289,v290,v291,v292,v293,v294,v295,v296,v297,v298) => { (v292.as_ref()).clone() } }),*v288))) { D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793::C0(v299) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(match &(d_8f49b0501dc5088b5b1fbb496bf7a43da0fc57cc982a3223cec950add0d80d8c(&(match v272 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v300,v301,v302,v303,v304,v305,v306,v307,v308,v309) => { (v302.as_ref()).clone() } }),*v288)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { 4294967295u64 },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v310) => { *v310 } })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v311) => { match &(D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(std::sync::Arc::new(D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(std::sync::Arc::new(match v272 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v312,v313,v314,v315,v316,v317,v318,v319,v320,v321) => { (v312.as_ref()).clone() } }),std::sync::Arc::new(d_883f464dad297c3ddf9b7e7cc33f90e47db3149f94ef0b14616a1c251e57cec7(&(match v272 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v322,v323,v324,v325,v326,v327,v328,v329,v330,v331) => { (v323.as_ref()).clone() } }))),std::sync::Arc::new(match v272 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v332,v333,v334,v335,v336,v337,v338,v339,v340,v341) => { (v334.as_ref()).clone() } }),std::sync::Arc::new(match v272 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v342,v343,v344,v345,v346,v347,v348,v349,v350,v351) => { (v345.as_ref()).clone() } }),std::sync::Arc::new(match v272 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v352,v353,v354,v355,v356,v357,v358,v359,v360,v361) => { (v356.as_ref()).clone() } }),match v272 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v362,v363,v364,v365,v366,v367,v368,v369,v370,v371) => { *v367 } },match v272 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v372,v373,v374,v375,v376,v377,v378,v379,v380,v381) => { *v378 } },((*v288) == (match v272 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v382,v383,v384,v385,v386,v387,v388,v389,v390,v391) => { *v388 } })),*v311,match v272 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v392,v393,v394,v395,v396,v397,v398,v399,v400,v401) => { *v401 } })))) { D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(v402) => { if if match v402.as_ref() { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v403,v404,v405,v406,v407,v408,v409,v410,v411,v412) => { *v410 } } { true } else { *v299 } { (v402.as_ref()).clone() } else { d_d82e40118f53bdfbefb5f85df702d7fa8fcacca63882a42262bfa5158e3ffe5f(v402.as_ref(),*v288) } } } } } } } } } } } }
fn d_5d52ea5a8e356f04093cac1a6710051c7c2d51db1cd9d2dfd20c3fd5caf5fb77(v413: &D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462,v414: u64) -> bool { match &(d_201e280f19da197f80aaeeb90891c2afb639627134c77648eaa04371e3b5cdd6(v413,v414)) { D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C0 => { false },D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C1(v415) => { true } } }
fn d_5fe9167aff6b3b37e3ca66b5143100bd012f34939a1767db0e227ef4ac5bdb15(v416: &D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd,v417: u64,v418: u64) -> D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd { match v416 { D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C0 => { D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C0 },D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C1(v420,v421,v422) => { D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C1(*v420,if ((v417) == (*v420)) { v418 } else { *v421 },std::sync::Arc::new(d_5fe9167aff6b3b37e3ca66b5143100bd012f34939a1767db0e227ef4ac5bdb15(v422.as_ref(),v417,v418))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_629702fff8bf26d1700c51e6d59e94b0faf5093d8d3e8cb0a184b7ac9f3f084a { C0(std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd { C0(bool,u64,u64,bool,std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>) }
fn d_6649fc617a1900b0cbc850819ce59715f07f3eb0bd93bb294005bf337538adeb(v423: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8) -> D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8 { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(v423))) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v424) => { match &(D_629702fff8bf26d1700c51e6d59e94b0faf5093d8d3e8cb0a184b7ac9f3f084a::C0(std::sync::Arc::new(d_f23e5e1ef33767cf923369310c51eeb75173bed11e5d3e4d87c4354e4e2aac2a(&(d_1338047bd9cf52a17a4e86ffc009b659e90ff924cb48778cbcac39b169b0bbeb(&(if ((if ((2u64) == (0u64)) { 0u64 } else { (*v424).checked_div(2u64).unwrap_or(0) }) == (0u64)) { D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301::C0 } else { D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301::C1(if ((2u64) == (0u64)) { 0u64 } else { (*v424).checked_div(2u64).unwrap_or(0) }) }))),if ((2u64) == (0u64)) { 0u64 } else { (*v424).checked_div(2u64).unwrap_or(0) },0u64,v423,*v424)))) { D_629702fff8bf26d1700c51e6d59e94b0faf5093d8d3e8cb0a184b7ac9f3f084a::C0(v426) => { (v426.as_ref()).clone() } } } } }
fn d_675b1f4f897dbd6222dcc1a7905d41455272640b09efc4dda13c18702b3a72fd(v427: &D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b,v428: u64) -> bool { match &(d_03ff34b5386d1e23ed93a530286dcfa18b3c56053b5eabeb72372c1a2a11723b(v427,v428)) { D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea::C0 => { false },D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea::C1(v429) => { true } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd { C0,C1(u64,u64,std::sync::Arc<D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd>) }
impl D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d { C0,C1(std::sync::Arc<D_4e61cd2054b66259fa5fe6ff2848621d519f896c6b83b26615faed118e66c0c8>,std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>) }
impl D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_7abfadbe3549dab1cc69baaa8a6b289ef7135e707fc1313b4d6eaaf6f7e6a614(v430: &D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60,v431: &D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9) -> D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14 { match v431 { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(v432,v433,v434,v435,v436) => { if *v433 { d_4fe8180484759596d66ae9f8476d235a3471baaf164ee96d74dafa98607dd2df(v435.as_ref()) } else { match v435.as_ref() { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v437) => { D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14::C0(std::sync::Arc::clone(v437),std::sync::Arc::new((v430).clone())) } } } },D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(v438,v439,v440) => { match v440.as_ref() { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v441) => { D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14::C0(std::sync::Arc::clone(v441),std::sync::Arc::new((v430).clone())) } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9 { C0,C1(bool,std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>) }
impl D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9 { C0(std::sync::Arc<D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd>,bool,u64,std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>,std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>),C1(u64,u64,std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_7eea704e7e77d46b1d984e9cab6f33b597cec0eda67bef640bae88b296cdd277 { C0(std::sync::Arc<D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69 { C0(std::sync::Arc<D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd>,std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>,u64,bool) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_85eb081cb2c18b3f9f242ecd82b001fb620e3ec27703b9bd0c819c588e91d440 { C0(std::sync::Arc<D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60>,std::sync::Arc<D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9>) }
fn d_883f464dad297c3ddf9b7e7cc33f90e47db3149f94ef0b14616a1c251e57cec7(v442: &D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871) -> D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871 { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(v442))) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v443) => { match &(D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(v442,(((*v443).wrapping_sub(1u64)) & (4294967295u64)))) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(0u64,0u64) },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v445) => { (v445.as_ref()).clone() } }))) { D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(v446) => { match &(D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(std::sync::Arc::new(D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(std::sync::Arc::new(d_c179b870391b842b9ab4fa27a89d903e157ec50d1aedf6dfdf82e22cd01ddf08(&(d_b10f15633b5bbc9018929e4e8d67975c090e74e014a600622b2f569ce4917ba5(v442,0u64,v446.as_ref())))),0u64,false)))) { D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(v447) => { match &(D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(std::sync::Arc::new(d_9922a5adf6482aba8c1c067bc95e952df2f0347f2ea5aec7895a4f08b21f8e6d(&(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v453:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v453.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v452:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v452.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v451:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v451.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v450:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v450.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v449:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v449.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(true,std::sync::Arc::clone({static v448:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v448.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0))}))))}))))}))))}))))}))))}))),32u64,0u64,v447.as_ref())))) { D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(v455) => { match v455.as_ref() { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v456,v457,v458) => { (v456.as_ref()).clone() } } } } } } } } } } }
fn d_8f49b0501dc5088b5b1fbb496bf7a43da0fc57cc982a3223cec950add0d80d8c(v459: &D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd,v460: u64) -> D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531 { match v459 { D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C0 => { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 },D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C1(v462,v463,v464) => { if ((v460) == (*v462)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(*v463) } else { d_8f49b0501dc5088b5b1fbb496bf7a43da0fc57cc982a3223cec950add0d80d8c(v464.as_ref(),v460) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6 { C0,C1(std::sync::Arc<D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f>) }
fn d_97618c4256a7c56a75c81c31e9035ca5a06eda577813ce92e9afb84b0dfb79e6(v465: &D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b,v466: u64,v467: bool) -> D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b { match v465 { D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C0 => { D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C0 },D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C1(v469,v470,v471) => { D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C1(*v469,if ((v466) == (*v469)) { v467 } else { *v470 },std::sync::Arc::new(d_97618c4256a7c56a75c81c31e9035ca5a06eda577813ce92e9afb84b0dfb79e6(v471.as_ref(),v466,v467))) } } }
fn d_9810c261dad317f7b06b890c118ad27801055f9efb8eebb59483c8572acec798(v472: &D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d) -> D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(if ((2u64) == (0u64)) { 0u64 } else { ((((match v472 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v473,v474,v475) => { *v474 } }).wrapping_sub(1u64)) & (4294967295u64))).checked_div(2u64).unwrap_or(0) })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v476) => { match &(D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v472 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v477,v478,v479) => { (v477.as_ref()).clone() } }),match v472 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v480,v481,v482) => { *v481 } })) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(0u64,0u64) },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v484) => { (v484.as_ref()).clone() } }))) { D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(v485) => { match &(D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v472 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v486,v487,v488) => { (v486.as_ref()).clone() } }),*v476)) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(0u64,0u64) },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v490) => { (v490.as_ref()).clone() } }))) { D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(v491) => { if d_9d672de3566f4e7ec38116f403ea277b7973fb397b44426e3ee7adf21bcd723f(v485.as_ref(),v491.as_ref()) { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v472 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v492,v493,v494) => { (v492.as_ref()).clone() } }),match v472 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v495,v496,v497) => { *v496 } })) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { match v472 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v498,v499,v500) => { (v498.as_ref()).clone() } } },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v501) => { match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v472 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v502,v503,v504) => { (v502.as_ref()).clone() } }),*v476)) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { match v472 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v505,v506,v507) => { (v505.as_ref()).clone() } } },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v508) => { d_b10f15633b5bbc9018929e4e8d67975c090e74e014a600622b2f569ce4917ba5(&(d_b10f15633b5bbc9018929e4e8d67975c090e74e014a600622b2f569ce4917ba5(&(match v472 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v509,v510,v511) => { (v509.as_ref()).clone() } }),match v472 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v512,v513,v514) => { *v513 } },v508.as_ref())),*v476,v501.as_ref()) } } } }),*v476,false) } else { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(std::sync::Arc::new(match v472 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v515,v516,v517) => { (v515.as_ref()).clone() } }),match v472 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v518,v519,v520) => { *v519 } },true) } } } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_987bdfeb29bf8c8194a0380157fa972a9aebb1b88b0f37bccc3668daaa1dd78f { C0(std::sync::Arc<D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14>,std::sync::Arc<D_2039380a191f87da8dbfd810ad313b62244825a051b4c0c3de52b6715baca512>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af { C0(u64) }
fn d_9922a5adf6482aba8c1c067bc95e952df2f0347f2ea5aec7895a4f08b21f8e6d(v521: &D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9,v522: u64,v523: u64,v524: &D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d) -> D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d { if if ((v522) == (0u64)) { true } else { if match v524 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v525,v526,v527) => { *v527 } } { true } else { ((d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(&(match v524 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v528,v529,v530) => { (v528.as_ref()).clone() } }))) == (0u64)) } } { (v524).clone() } else { match v521 { D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0 => { (v524).clone() },D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(v531,v532) => { if *v531 { match &(D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(std::sync::Arc::new(d_9922a5adf6482aba8c1c067bc95e952df2f0347f2ea5aec7895a4f08b21f8e6d(v532.as_ref(),(v522).checked_div(2u64).unwrap_or(0),(((v523).wrapping_add((v522).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_9922a5adf6482aba8c1c067bc95e952df2f0347f2ea5aec7895a4f08b21f8e6d(v532.as_ref(),(v522).checked_div(2u64).unwrap_or(0),v523,v524)))))) { D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(v533) => { if if match v533.as_ref() { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v534,v535,v536) => { *v536 } } { true } else { ((d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(&(match v533.as_ref() { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v537,v538,v539) => { (v537.as_ref()).clone() } }))) == (0u64)) } { (v533.as_ref()).clone() } else { d_4662356d4b7aebe6e74645c080deab29c301ad4662c930b428d106d4173c856a(v533.as_ref()) } } } } else { d_9922a5adf6482aba8c1c067bc95e952df2f0347f2ea5aec7895a4f08b21f8e6d(v532.as_ref(),(v522).checked_div(2u64).unwrap_or(0),(((v523).wrapping_add((v522).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_9922a5adf6482aba8c1c067bc95e952df2f0347f2ea5aec7895a4f08b21f8e6d(v532.as_ref(),(v522).checked_div(2u64).unwrap_or(0),v523,v524))) } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa { C0(std::sync::Arc<D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f>) }
fn d_9a6e77e0c0848f8c788a82eb6f3bec58f935fe6ed1104a61bbc9a86d40fd32fc(v540: &D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39,v541: u64) -> D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd { match &(D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793::C0(if ((match v540 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v542,v543,v544,v545,v546,v547,v548,v549,v550,v551) => { *v549 } }) == (false)) { ((d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(&(match v540 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v552,v553,v554,v555,v556,v557,v558,v559,v560,v561) => { (v553.as_ref()).clone() } }))) > (0u64)) } else { false })) { D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793::C0(v562) => { match &(D_4d68fd2c2ea116d87e7a4a150162c04ff1404fbc0d420ef69cf909b470f7e4a8::C0(std::sync::Arc::new(D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(std::sync::Arc::new(match v540 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v563,v564,v565,v566,v567,v568,v569,v570,v571,v572) => { (v567.as_ref()).clone() } }),std::sync::Arc::clone({static v573:std::sync::OnceLock<std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>>=std::sync::OnceLock::new();v573.get_or_init(||std::sync::Arc::new(D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0))}),match v540 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v574,v575,v576,v577,v578,v579,v580,v581,v582,v583) => { *v580 } },((match v540 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v584,v585,v586,v587,v588,v589,v590,v591,v592,v593) => { *v591 } }) == (false)))))) { D_4d68fd2c2ea116d87e7a4a150162c04ff1404fbc0d420ef69cf909b470f7e4a8::C0(v594) => { match &(D_4d68fd2c2ea116d87e7a4a150162c04ff1404fbc0d420ef69cf909b470f7e4a8::C0(std::sync::Arc::new(d_fa8e70b6c7edb6eeac653ac7e50a93414822a4c906b31b18ff715fb31e358a61(&(d_1338047bd9cf52a17a4e86ffc009b659e90ff924cb48778cbcac39b169b0bbeb(&(if ((d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(&(match v540 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v595,v596,v597,v598,v599,v600,v601,v602,v603,v604) => { (v595.as_ref()).clone() } }))) == (0u64)) { D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301::C0 } else { D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301::C1(d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(&(match v540 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v606,v607,v608,v609,v610,v611,v612,v613,v614,v615) => { (v606.as_ref()).clone() } }))) }))),d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(&(match v540 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v616,v617,v618,v619,v620,v621,v622,v623,v624,v625) => { (v616.as_ref()).clone() } })),0u64,v594.as_ref(),v541)))) { D_4d68fd2c2ea116d87e7a4a150162c04ff1404fbc0d420ef69cf909b470f7e4a8::C0(v626) => { D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd::C0(match v540 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v627,v628,v629,v630,v631,v632,v633,v634,v635,v636) => { *v634 } },match v540 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v637,v638,v639,v640,v641,v642,v643,v644,v645,v646) => { *v645 } },match v540 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v647,v648,v649,v650,v651,v652,v653,v654,v655,v656) => { *v656 } },*v562,std::sync::Arc::new(d_6649fc617a1900b0cbc850819ce59715f07f3eb0bd93bb294005bf337538adeb(&(match v626.as_ref() { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v657,v658,v659,v660) => { (v658.as_ref()).clone() } })))) } } } } } } }
fn d_9b0edc5144547f0c2191f9385effd157d7f21cab86e806971e0f3dda1748bba4(v661: &D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14) -> D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60 { match v661 { D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14::C0(v662,v663) => { (v663.as_ref()).clone() } } }
fn d_9bb3ec8899fbd786e3a9c9196168dd3cb0314e9fe3d22b3d85e09e94d3dbe5cf(v664: u64,v665: u64,v666: u64) -> u64 { (((d_4e83072d158179b64b40df7986493710bb1d27812bc6ecdf11bb0c4a74d8c70d(if ((v666) == (0u64)) { 0u64 } else { (v664).checked_rem(v666).unwrap_or(0) },if ((v666) == (0u64)) { 0u64 } else { (v665).checked_rem(v666).unwrap_or(0) })).wrapping_add(d_4e83072d158179b64b40df7986493710bb1d27812bc6ecdf11bb0c4a74d8c70d(if ((v666) == (0u64)) { 0u64 } else { (v664).checked_div(v666).unwrap_or(0) },if ((v666) == (0u64)) { 0u64 } else { (v665).checked_div(v666).unwrap_or(0) }))) & (4294967295u64)) }
fn d_9c3da9d34ec75222a22280aa83e3722a77986d6ed420dfb227c213c230e89897(v667: &D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4,v668: u64,v669: u64,v670: bool) -> D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9 { match &(D_ed742c79021c129a74c485de3fde12f113f9e1f62fcdff87129f05a60f244981::C0(std::sync::Arc::new(match v667 { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v671) => { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::new(d_cf1230bd75cb8423314de8b7d3f4d503a062de575d48e96f3c36c0da9dcc1bce(&(match v667 { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v672) => { (v672.as_ref()).clone() } }),v669))) } }))) { D_ed742c79021c129a74c485de3fde12f113f9e1f62fcdff87129f05a60f244981::C0(v673) => { if v670 { match &(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(true)) { D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(v675) => { if ((v668) == (18446744073709551615u64)) { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(1u64,v668,std::sync::Arc::new((v667).clone())) } else { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(std::sync::Arc::new(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(std::sync::Arc::clone(v675))),true,(v668).wrapping_add(1u64),std::sync::Arc::clone(v673),std::sync::Arc::clone({static v676:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v676.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) } },D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(v677) => { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(std::sync::Arc::new(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(*v677)),false,v668,std::sync::Arc::new((v667).clone()),std::sync::Arc::clone({static v678:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v678.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) } } } else { match &(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(std::sync::Arc::clone({static v679:std::sync::OnceLock<std::sync::Arc<D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7>>=std::sync::OnceLock::new();v679.get_or_init(||std::sync::Arc::new(D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7::C0))}))) { D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(v681) => { if ((v668) == (18446744073709551615u64)) { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(1u64,v668,std::sync::Arc::new((v667).clone())) } else { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(std::sync::Arc::new(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(std::sync::Arc::clone(v681))),true,(v668).wrapping_add(1u64),std::sync::Arc::clone(v673),std::sync::Arc::clone({static v682:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v682.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) } },D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(v683) => { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(std::sync::Arc::new(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(*v683)),false,v668,std::sync::Arc::new((v667).clone()),std::sync::Arc::clone({static v684:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v684.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) } } } } } }
fn d_9d672de3566f4e7ec38116f403ea277b7973fb397b44426e3ee7adf21bcd723f(v685: &D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f,v686: &D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f) -> bool { if ((match v685 { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v687,v688) => { *v688 } }) < (match v686 { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v689,v690) => { *v690 } })) { true } else { if ((match v685 { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v691,v692) => { *v692 } }) == (match v686 { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v693,v694) => { *v694 } })) { ((match v685 { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v695,v696) => { *v695 } }) < (match v686 { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v697,v698) => { *v697 } })) } else { false } } }
fn d_9f081cafe208680fa809ebb2efd71869fec94cb8acec485086fb085da04e3876(v699: &D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14) -> D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4 { match v699 { D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14::C0(v700,v701) => { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::clone(v700)) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9 { C0(std::sync::Arc<D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d>) }
fn d_a408c40899090290509b564bb15de3b0e046dc2ffc24bae39b3e6dec92bee7ce(v702: &D_85eb081cb2c18b3f9f242ecd82b001fb620e3ec27703b9bd0c819c588e91d440) -> D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14 { match v702 { D_85eb081cb2c18b3f9f242ecd82b001fb620e3ec27703b9bd0c819c588e91d440::C0(v703,v704) => { d_7abfadbe3549dab1cc69baaa8a6b289ef7135e707fc1313b4d6eaaf6f7e6a614(v703.as_ref(),v704.as_ref()) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_a73d54a65b8fc10db9e4a27ae68f045ef114804bfd375842190af18c88d39668 { C0(std::sync::Arc<D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14>,std::sync::Arc<D_c4723b47c6e1d6bbaad257312e3775ae8ebc3ada669ec51045f34d4aefe99a68>) }
fn d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(v705: &D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871,v706: u64) -> D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6 { match v705 { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 => { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 },D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(v708,v709) => { if ((v706) == (0u64)) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(std::sync::Arc::clone(v708)) } else { d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(v709.as_ref(),(((v706).wrapping_sub(1u64)) & (4294967295u64))) } } } }
fn d_b10f15633b5bbc9018929e4e8d67975c090e74e014a600622b2f569ce4917ba5(v710: &D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871,v711: u64,v712: &D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f) -> D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871 { match v710 { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 => { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 },D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(v714,v715) => { if ((v711) == (0u64)) { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(std::sync::Arc::new((v712).clone()),std::sync::Arc::clone(v715)) } else { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(std::sync::Arc::clone(v714),std::sync::Arc::new(d_b10f15633b5bbc9018929e4e8d67975c090e74e014a600622b2f569ce4917ba5(v715.as_ref(),(((v711).wrapping_sub(1u64)) & (4294967295u64)),v712))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f { C0(u64,u64) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4 { C0(std::sync::Arc<D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462>) }
fn d_b49a17a751300394c261cc3b13d02c5f86514ef9f076c31c61a9a4ad1121d77f(v716: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v717: u64,v718: u64,v719: u64,v720: u64) -> D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd { match &(D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793::C0(if if if if if if ((v717) > (0u64)) { ((d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(v716)) > (0u64)) } else { false } { ((if ((v717) == (0u64)) { 1u64 } else { (d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(v716)).checked_rem(v717).unwrap_or(0) }) == (0u64)) } else { false } { ((v718) < (d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(v716))) } else { false } { ((v719) < (d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(v716))) } else { false } { ((match &(d_3ec78a35272ed91061dacb8c052a158f10da108f6d53693c7b0661117c1a477a(v716,v718)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { 1u64 },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v721) => { *v721 } }) == (0u64)) } else { false } { ((match &(d_3ec78a35272ed91061dacb8c052a158f10da108f6d53693c7b0661117c1a477a(v716,v719)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { 1u64 },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v722) => { *v722 } }) == (0u64)) } else { false })) { D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793::C0(v723) => { if *v723 { d_54115d4ead942305e035cdfe49d61b727e56192d969e831e8b6c754a1c65c6f2(v716,v717,v718,v719,v720) } else { D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd::C0(false,0u64,0u64,false,std::sync::Arc::new(d_2b69c64cbe72e93b1b88f554091ce5857248e729631172c1b5518c2642c807f2(v716))) } } } }
fn d_bf6aba90e46dc72ddc2215d097cea1f2923a96c4e3f4a35f12925a49df054182(v724: &D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871,v725: &D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f) -> D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871 { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(v724))) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v726) => { match &(D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(std::sync::Arc::new(D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(std::sync::Arc::new(d_c846feedade08b7e208a1ef904f8d843db007f1b3e3a3ef6af35a8b81ad87676(v724,v725)),*v726,false)))) { D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(v727) => { match &(D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(std::sync::Arc::new(d_f27de552516fbc855a6704e6cb1adf85ea68f335192ed7a6481f821689b356ad(&(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v733:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v733.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v732:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v732.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v731:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v731.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v730:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v730.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v729:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v729.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(true,std::sync::Arc::clone({static v728:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v728.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0))}))))}))))}))))}))))}))))}))),32u64,0u64,v727.as_ref())))) { D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(v735) => { match v735.as_ref() { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v736,v737,v738) => { (v736.as_ref()).clone() } } } } } } } } }
fn d_c179b870391b842b9ab4fa27a89d903e157ec50d1aedf6dfdf82e22cd01ddf08(v739: &D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871) -> D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871 { match v739 { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 => { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 },D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(v741,v742) => { match v742.as_ref() { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 => { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 },D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(v744,v745) => { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(std::sync::Arc::clone(v741),std::sync::Arc::new(d_c179b870391b842b9ab4fa27a89d903e157ec50d1aedf6dfdf82e22cd01ddf08(v742.as_ref()))) } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_c4723b47c6e1d6bbaad257312e3775ae8ebc3ada669ec51045f34d4aefe99a68 { C0(std::sync::Arc<D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2>,bool,u64,std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>,std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>),C1(u64,u64,std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462 { C0,C1(u64,std::sync::Arc<D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c>,std::sync::Arc<D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462>) }
impl D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_c846feedade08b7e208a1ef904f8d843db007f1b3e3a3ef6af35a8b81ad87676(v746: &D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871,v747: &D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f) -> D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871 { match v746 { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 => { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(std::sync::Arc::new((v747).clone()),std::sync::Arc::clone({static v748:std::sync::OnceLock<std::sync::Arc<D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871>>=std::sync::OnceLock::new();v748.get_or_init(||std::sync::Arc::new(D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0))})) },D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(v749,v750) => { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(std::sync::Arc::clone(v749),std::sync::Arc::new(d_c846feedade08b7e208a1ef904f8d843db007f1b3e3a3ef6af35a8b81ad87676(v750.as_ref(),v747))) } } }
fn d_cb7b07399d66ae3a9db3cf1914bc36b56912d97d339ccc4b4d5943e8c9f40094(v751: &D_85eb081cb2c18b3f9f242ecd82b001fb620e3ec27703b9bd0c819c588e91d440) -> D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9 { match v751 { D_85eb081cb2c18b3f9f242ecd82b001fb620e3ec27703b9bd0c819c588e91d440::C0(v752,v753) => { (v753.as_ref()).clone() } } }
fn d_cf1230bd75cb8423314de8b7d3f4d503a062de575d48e96f3c36c0da9dcc1bce(v754: &D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462,v755: u64) -> D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462 { match v754 { D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0 => { D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0 },D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(v757,v758,v759) => { if ((v755) == (*v757)) { d_cf1230bd75cb8423314de8b7d3f4d503a062de575d48e96f3c36c0da9dcc1bce(v759.as_ref(),v755) } else { D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(*v757,std::sync::Arc::clone(v758),std::sync::Arc::new(d_cf1230bd75cb8423314de8b7d3f4d503a062de575d48e96f3c36c0da9dcc1bce(v759.as_ref(),v755))) } } } }
fn d_d534958d72b8d1d985bd319d9188a99463f32295f906a8a663b3b711ef45d1d1(v760: &D_a73d54a65b8fc10db9e4a27ae68f045ef114804bfd375842190af18c88d39668) -> D_c4723b47c6e1d6bbaad257312e3775ae8ebc3ada669ec51045f34d4aefe99a68 { match v760 { D_a73d54a65b8fc10db9e4a27ae68f045ef114804bfd375842190af18c88d39668::C0(v761,v762) => { (v762.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea { C0,C1(bool) }
fn d_d82e40118f53bdfbefb5f85df702d7fa8fcacca63882a42262bfa5158e3ffe5f(v763: &D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39,v764: u64) -> D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39 { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(&(match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v765,v766,v767,v768,v769,v770,v771,v772,v773,v774) => { (v765.as_ref()).clone() } })))) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v775) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(if ((match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v776,v777,v778,v779,v780,v781,v782,v783,v784,v785) => { *v781 } }) == (0u64)) { 0u64 } else { (v764).checked_rem(match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v786,v787,v788,v789,v790,v791,v792,v793,v794,v795) => { *v791 } }).unwrap_or(0) })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v796) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(if ((*v796) > (0u64)) { (((v764).wrapping_sub(1u64)) & (4294967295u64)) } else { v764 })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v797) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(if if (((((*v796).wrapping_add(1u64)) & (4294967295u64))) < (match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v798,v799,v800,v801,v802,v803,v804,v805,v806,v807) => { *v803 } })) { (((((v764).wrapping_add(1u64)) & (4294967295u64))) < (*v775)) } else { false } { (((v764).wrapping_add(1u64)) & (4294967295u64)) } else { v764 })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v808) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(if ((v764) >= (match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v809,v810,v811,v812,v813,v814,v815,v816,v817,v818) => { *v814 } })) { (((v764).wrapping_sub(match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v819,v820,v821,v822,v823,v824,v825,v826,v827,v828) => { *v824 } })) & (4294967295u64)) } else { v764 })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v829) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(if (((((v764).wrapping_add(match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v830,v831,v832,v833,v834,v835,v836,v837,v838,v839) => { *v835 } })) & (4294967295u64))) < (*v775)) { (((v764).wrapping_add(match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v840,v841,v842,v843,v844,v845,v846,v847,v848,v849) => { *v845 } })) & (4294967295u64)) } else { v764 })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v850) => { match &(D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(std::sync::Arc::new(D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(std::sync::Arc::new(match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v851,v852,v853,v854,v855,v856,v857,v858,v859,v860) => { (v851.as_ref()).clone() } }),std::sync::Arc::new(match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v861,v862,v863,v864,v865,v866,v867,v868,v869,v870) => { (v862.as_ref()).clone() } }),std::sync::Arc::new(match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v871,v872,v873,v874,v875,v876,v877,v878,v879,v880) => { (v873.as_ref()).clone() } }),std::sync::Arc::new(if d_675b1f4f897dbd6222dcc1a7905d41455272640b09efc4dda13c18702b3a72fd(&(match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v881,v882,v883,v884,v885,v886,v887,v888,v889,v890) => { (v884.as_ref()).clone() } }),v764) { d_97618c4256a7c56a75c81c31e9035ca5a06eda577813ce92e9afb84b0dfb79e6(&(match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v891,v892,v893,v894,v895,v896,v897,v898,v899,v900) => { (v894.as_ref()).clone() } }),v764,true) } else { d_5505e7ee68449c43569a7ea9f8556dc190dcb184ac4512d57d25866601499382(&(match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v901,v902,v903,v904,v905,v906,v907,v908,v909,v910) => { (v904.as_ref()).clone() } }),v764,true) }),std::sync::Arc::new(match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v911,v912,v913,v914,v915,v916,v917,v918,v919,v920) => { (v915.as_ref()).clone() } }),match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v921,v922,v923,v924,v925,v926,v927,v928,v929,v930) => { *v926 } },match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v931,v932,v933,v934,v935,v936,v937,v938,v939,v940) => { *v937 } },false,0u64,(((match v763 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v941,v942,v943,v944,v945,v946,v947,v948,v949,v950) => { *v950 } }).wrapping_add(1u64)) & (4294967295u64)))))) { D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(v951) => { match &(D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(std::sync::Arc::new(d_f17a4f88d452bbfddc3faeacc61a045b96954656a47606cb20189965b548d35c(v951.as_ref(),v764,*v797)))) { D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(v952) => { match &(D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(std::sync::Arc::new(d_f17a4f88d452bbfddc3faeacc61a045b96954656a47606cb20189965b548d35c(v952.as_ref(),v764,*v808)))) { D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(v953) => { match &(D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(std::sync::Arc::new(d_f17a4f88d452bbfddc3faeacc61a045b96954656a47606cb20189965b548d35c(v953.as_ref(),v764,*v829)))) { D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(v954) => { d_f17a4f88d452bbfddc3faeacc61a045b96954656a47606cb20189965b548d35c(v954.as_ref(),v764,*v850) } } } } } } } } } } } } } } } } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60 { C0,C1(std::sync::Arc<D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd>) }
fn d_da597886f363927b5d21a122bbee3f2543e42db5ead2b6de0c13dd969f1da4fa(v955: &D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69,v956: u64) -> D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69 { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(match &(d_8f49b0501dc5088b5b1fbb496bf7a43da0fc57cc982a3223cec950add0d80d8c(&(match v955 { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v957,v958,v959,v960) => { (v957.as_ref()).clone() } }),match v955 { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v961,v962,v963,v964) => { *v963 } })) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { v956 },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v965) => { *v965 } })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v966) => { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(std::sync::Arc::new(match v955 { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v967,v968,v969,v970) => { (v967.as_ref()).clone() } }),std::sync::Arc::new(d_40f81830bbf4127535b60ab6c9d54b1ffed69633c3d1e8eb4c12f7e778f3d35f(&(match v955 { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v971,v972,v973,v974) => { (v972.as_ref()).clone() } }),match v955 { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v975,v976,v977,v978) => { *v977 } })),*v966,((match v955 { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v979,v980,v981,v982) => { *v981 } }) == (v956))) } } }
fn d_dafb03cc83093cc54f68a0af33b8eed41b88d9b5efa7f70ab30ed00a20fc0b1c(v983: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v984: u64,v985: u64) -> D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8 { match v983 { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 => { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 },D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v987,v988) => { if ((v984) == (0u64)) { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v985,std::sync::Arc::clone(v988)) } else { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(*v987,std::sync::Arc::new(d_dafb03cc83093cc54f68a0af33b8eed41b88d9b5efa7f70ab30ed00a20fc0b1c(v988.as_ref(),(((v984).wrapping_sub(1u64)) & (4294967295u64)),v985))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_e76d71eacc94ee97e8a1a02d9b0750885675867ac52f6e28927a98226058c5ad { C0(std::sync::Arc<D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871>) }
fn d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(v989: &D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871) -> u64 { match v989 { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 => { 0u64 },D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(v990,v991) => { (((1u64).wrapping_add(d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(v991.as_ref()))) & (4294967295u64)) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ed742c79021c129a74c485de3fde12f113f9e1f62fcdff87129f05a60f244981 { C0(std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>) }
fn d_f17a4f88d452bbfddc3faeacc61a045b96954656a47606cb20189965b548d35c(v992: &D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39,v993: u64,v994: u64) -> D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39 { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0((((match &(d_8f49b0501dc5088b5b1fbb496bf7a43da0fc57cc982a3223cec950add0d80d8c(&(match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v995,v996,v997,v998,v999,v1000,v1001,v1002,v1003,v1004) => { (v997.as_ref()).clone() } }),v993)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { 0u64 },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v1005) => { *v1005 } }).wrapping_add(1u64)) & (4294967295u64)))) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v1006) => { match &(D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793::C0(if if ((match &(d_3ec78a35272ed91061dacb8c052a158f10da108f6d53693c7b0661117c1a477a(&(match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1007,v1008,v1009,v1010,v1011,v1012,v1013,v1014,v1015,v1016) => { (v1007.as_ref()).clone() } }),v994)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { 1u64 },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v1017) => { *v1017 } }) == (0u64)) { ((d_675b1f4f897dbd6222dcc1a7905d41455272640b09efc4dda13c18702b3a72fd(&(match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1018,v1019,v1020,v1021,v1022,v1023,v1024,v1025,v1026,v1027) => { (v1021.as_ref()).clone() } }),v994)) == (false)) } else { false } { ((*v1006) < (match &(d_8f49b0501dc5088b5b1fbb496bf7a43da0fc57cc982a3223cec950add0d80d8c(&(match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1028,v1029,v1030,v1031,v1032,v1033,v1034,v1035,v1036,v1037) => { (v1030.as_ref()).clone() } }),v994)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { 4294967295u64 },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v1038) => { *v1038 } })) } else { false })) { D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793::C0(v1039) => { if *v1039 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(std::sync::Arc::new(match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1040,v1041,v1042,v1043,v1044,v1045,v1046,v1047,v1048,v1049) => { (v1040.as_ref()).clone() } }),std::sync::Arc::new(d_bf6aba90e46dc72ddc2215d097cea1f2923a96c4e3f4a35f12925a49df054182(&(match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1050,v1051,v1052,v1053,v1054,v1055,v1056,v1057,v1058,v1059) => { (v1051.as_ref()).clone() } }),&(D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v994,(((*v1006).wrapping_add(d_9bb3ec8899fbd786e3a9c9196168dd3cb0314e9fe3d22b3d85e09e94d3dbe5cf(v994,match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1060,v1061,v1062,v1063,v1064,v1065,v1066,v1067,v1068,v1069) => { *v1066 } },match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1070,v1071,v1072,v1073,v1074,v1075,v1076,v1077,v1078,v1079) => { *v1075 } }))) & (4294967295u64)))))),std::sync::Arc::new(if d_002fa87dc14fb22703d067bc5256bb42a441ff9bc957fdd023ea162e558462ba(&(match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1080,v1081,v1082,v1083,v1084,v1085,v1086,v1087,v1088,v1089) => { (v1082.as_ref()).clone() } }),v994) { d_5fe9167aff6b3b37e3ca66b5143100bd012f34939a1767db0e227ef4ac5bdb15(&(match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1090,v1091,v1092,v1093,v1094,v1095,v1096,v1097,v1098,v1099) => { (v1092.as_ref()).clone() } }),v994,*v1006) } else { d_10474bbc4ac74580f8be4e0fa212cee2c299d6988c03e31fe5089407d8cf0f2a(&(match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1100,v1101,v1102,v1103,v1104,v1105,v1106,v1107,v1108,v1109) => { (v1102.as_ref()).clone() } }),v994,*v1006) }),std::sync::Arc::new(match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1110,v1111,v1112,v1113,v1114,v1115,v1116,v1117,v1118,v1119) => { (v1113.as_ref()).clone() } }),std::sync::Arc::new(if d_002fa87dc14fb22703d067bc5256bb42a441ff9bc957fdd023ea162e558462ba(&(match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1120,v1121,v1122,v1123,v1124,v1125,v1126,v1127,v1128,v1129) => { (v1124.as_ref()).clone() } }),v994) { d_5fe9167aff6b3b37e3ca66b5143100bd012f34939a1767db0e227ef4ac5bdb15(&(match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1130,v1131,v1132,v1133,v1134,v1135,v1136,v1137,v1138,v1139) => { (v1134.as_ref()).clone() } }),v994,v993) } else { d_10474bbc4ac74580f8be4e0fa212cee2c299d6988c03e31fe5089407d8cf0f2a(&(match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1140,v1141,v1142,v1143,v1144,v1145,v1146,v1147,v1148,v1149) => { (v1144.as_ref()).clone() } }),v994,v993) }),match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1150,v1151,v1152,v1153,v1154,v1155,v1156,v1157,v1158,v1159) => { *v1155 } },match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1160,v1161,v1162,v1163,v1164,v1165,v1166,v1167,v1168,v1169) => { *v1166 } },match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1170,v1171,v1172,v1173,v1174,v1175,v1176,v1177,v1178,v1179) => { *v1177 } },match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1180,v1181,v1182,v1183,v1184,v1185,v1186,v1187,v1188,v1189) => { *v1188 } },match v992 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1190,v1191,v1192,v1193,v1194,v1195,v1196,v1197,v1198,v1199) => { *v1199 } }) } else { (v992).clone() } } } } } }
fn d_f23e5e1ef33767cf923369310c51eeb75173bed11e5d3e4d87c4354e4e2aac2a(v1200: &D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9,v1201: u64,v1202: u64,v1203: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v1204: u64) -> D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8 { if if ((v1201) == (0u64)) { true } else { false } { (v1203).clone() } else { match v1200 { D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0 => { (v1203).clone() },D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(v1205,v1206) => { if *v1205 { match &(D_629702fff8bf26d1700c51e6d59e94b0faf5093d8d3e8cb0a184b7ac9f3f084a::C0(std::sync::Arc::new(d_f23e5e1ef33767cf923369310c51eeb75173bed11e5d3e4d87c4354e4e2aac2a(v1206.as_ref(),(v1201).checked_div(2u64).unwrap_or(0),(((v1202).wrapping_add((v1201).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_f23e5e1ef33767cf923369310c51eeb75173bed11e5d3e4d87c4354e4e2aac2a(v1206.as_ref(),(v1201).checked_div(2u64).unwrap_or(0),v1202,v1203,v1204)),v1204)))) { D_629702fff8bf26d1700c51e6d59e94b0faf5093d8d3e8cb0a184b7ac9f3f084a::C0(v1207) => { if false { (v1207.as_ref()).clone() } else { match &(d_3ec78a35272ed91061dacb8c052a158f10da108f6d53693c7b0661117c1a477a(v1207.as_ref(),(((v1202).wrapping_add(((v1201).checked_div(2u64).unwrap_or(0)).wrapping_mul(2u64))) & (4294967295u64)))) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { (v1207.as_ref()).clone() },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v1208) => { match &(d_3ec78a35272ed91061dacb8c052a158f10da108f6d53693c7b0661117c1a477a(v1207.as_ref(),((((((v1204).wrapping_sub(1u64)) & (4294967295u64))).wrapping_sub((((v1202).wrapping_add(((v1201).checked_div(2u64).unwrap_or(0)).wrapping_mul(2u64))) & (4294967295u64)))) & (4294967295u64)))) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { (v1207.as_ref()).clone() },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v1209) => { d_dafb03cc83093cc54f68a0af33b8eed41b88d9b5efa7f70ab30ed00a20fc0b1c(&(d_dafb03cc83093cc54f68a0af33b8eed41b88d9b5efa7f70ab30ed00a20fc0b1c(v1207.as_ref(),(((v1202).wrapping_add(((v1201).checked_div(2u64).unwrap_or(0)).wrapping_mul(2u64))) & (4294967295u64)),*v1209)),((((((v1204).wrapping_sub(1u64)) & (4294967295u64))).wrapping_sub((((v1202).wrapping_add(((v1201).checked_div(2u64).unwrap_or(0)).wrapping_mul(2u64))) & (4294967295u64)))) & (4294967295u64)),*v1208) } } } } } } } } else { d_f23e5e1ef33767cf923369310c51eeb75173bed11e5d3e4d87c4354e4e2aac2a(v1206.as_ref(),(v1201).checked_div(2u64).unwrap_or(0),(((v1202).wrapping_add((v1201).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_f23e5e1ef33767cf923369310c51eeb75173bed11e5d3e4d87c4354e4e2aac2a(v1206.as_ref(),(v1201).checked_div(2u64).unwrap_or(0),v1202,v1203,v1204)),v1204) } } } } }
fn d_f27de552516fbc855a6704e6cb1adf85ea68f335192ed7a6481f821689b356ad(v1210: &D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9,v1211: u64,v1212: u64,v1213: &D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d) -> D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d { if if ((v1211) == (0u64)) { true } else { if match v1213 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v1214,v1215,v1216) => { *v1216 } } { true } else { ((match v1213 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v1217,v1218,v1219) => { *v1218 } }) == (0u64)) } } { (v1213).clone() } else { match v1210 { D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0 => { (v1213).clone() },D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(v1220,v1221) => { if *v1220 { match &(D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(std::sync::Arc::new(d_f27de552516fbc855a6704e6cb1adf85ea68f335192ed7a6481f821689b356ad(v1221.as_ref(),(v1211).checked_div(2u64).unwrap_or(0),(((v1212).wrapping_add((v1211).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_f27de552516fbc855a6704e6cb1adf85ea68f335192ed7a6481f821689b356ad(v1221.as_ref(),(v1211).checked_div(2u64).unwrap_or(0),v1212,v1213)))))) { D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(v1222) => { if if match v1222.as_ref() { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v1223,v1224,v1225) => { *v1225 } } { true } else { ((match v1222.as_ref() { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v1226,v1227,v1228) => { *v1227 } }) == (0u64)) } { (v1222.as_ref()).clone() } else { d_9810c261dad317f7b06b890c118ad27801055f9efb8eebb59483c8572acec798(v1222.as_ref()) } } } } else { d_f27de552516fbc855a6704e6cb1adf85ea68f335192ed7a6481f821689b356ad(v1221.as_ref(),(v1211).checked_div(2u64).unwrap_or(0),(((v1212).wrapping_add((v1211).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_f27de552516fbc855a6704e6cb1adf85ea68f335192ed7a6481f821689b356ad(v1221.as_ref(),(v1211).checked_div(2u64).unwrap_or(0),v1212,v1213))) } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793 { C0(bool) }
fn d_fa8e70b6c7edb6eeac653ac7e50a93414822a4c906b31b18ff715fb31e358a61(v1229: &D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9,v1230: u64,v1231: u64,v1232: &D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69,v1233: u64) -> D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69 { if if ((v1230) == (0u64)) { true } else { match v1232 { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v1234,v1235,v1236,v1237) => { *v1237 } } } { (v1232).clone() } else { match v1229 { D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0 => { (v1232).clone() },D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(v1238,v1239) => { if *v1238 { match &(D_4d68fd2c2ea116d87e7a4a150162c04ff1404fbc0d420ef69cf909b470f7e4a8::C0(std::sync::Arc::new(d_fa8e70b6c7edb6eeac653ac7e50a93414822a4c906b31b18ff715fb31e358a61(v1239.as_ref(),(v1230).checked_div(2u64).unwrap_or(0),(((v1231).wrapping_add((v1230).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_fa8e70b6c7edb6eeac653ac7e50a93414822a4c906b31b18ff715fb31e358a61(v1239.as_ref(),(v1230).checked_div(2u64).unwrap_or(0),v1231,v1232,v1233)),v1233)))) { D_4d68fd2c2ea116d87e7a4a150162c04ff1404fbc0d420ef69cf909b470f7e4a8::C0(v1240) => { if match v1240.as_ref() { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v1241,v1242,v1243,v1244) => { *v1244 } } { (v1240.as_ref()).clone() } else { d_da597886f363927b5d21a122bbee3f2543e42db5ead2b6de0c13dd969f1da4fa(v1240.as_ref(),v1233) } } } } else { d_fa8e70b6c7edb6eeac653ac7e50a93414822a4c906b31b18ff715fb31e358a61(v1239.as_ref(),(v1230).checked_div(2u64).unwrap_or(0),(((v1231).wrapping_add((v1230).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_fa8e70b6c7edb6eeac653ac7e50a93414822a4c906b31b18ff715fb31e358a61(v1239.as_ref(),(v1230).checked_div(2u64).unwrap_or(0),v1231,v1232,v1233)),v1233) } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2 { C0,C1(std::sync::Arc<D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531 { C0,C1(u64) }
pub fn f_1130456dc988c7b056c44f00ceed17b2362b848048cadc72cae8f9cb20efff83(v1245: &D_987bdfeb29bf8c8194a0380157fa972a9aebb1b88b0f37bccc3668daaa1dd78f) -> D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14 { d_1130456dc988c7b056c44f00ceed17b2362b848048cadc72cae8f9cb20efff83(v1245) }
pub fn f_2293f25d58473c8c330a164f34117e9631296ac9eb2da0c26cb3fd0ce8cf093a(v1246: &D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14,v1247: u64,v1248: u64) -> D_a73d54a65b8fc10db9e4a27ae68f045ef114804bfd375842190af18c88d39668 { d_2293f25d58473c8c330a164f34117e9631296ac9eb2da0c26cb3fd0ce8cf093a(v1246,v1247,v1248) }
pub fn f_296c1313f43a3560a3058dea7dce95704f2bd50167c5009ee44c913ebf0341d9(v1249: &D_987bdfeb29bf8c8194a0380157fa972a9aebb1b88b0f37bccc3668daaa1dd78f) -> D_2039380a191f87da8dbfd810ad313b62244825a051b4c0c3de52b6715baca512 { d_296c1313f43a3560a3058dea7dce95704f2bd50167c5009ee44c913ebf0341d9(v1249) }
pub fn f_2a8097b87d95e141f8f75c743ae736666ee38a1239b6ac0bf1df9446c69329bd(v1250: &D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14,v1251: u64) -> D_987bdfeb29bf8c8194a0380157fa972a9aebb1b88b0f37bccc3668daaa1dd78f { d_2a8097b87d95e141f8f75c743ae736666ee38a1239b6ac0bf1df9446c69329bd(v1250,v1251) }
pub fn f_47c6f29a9d5998d7f45ab4ec06f6b1162f003207ed846fd9209f2d4070389862(v1252: &D_a73d54a65b8fc10db9e4a27ae68f045ef114804bfd375842190af18c88d39668) -> D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14 { d_47c6f29a9d5998d7f45ab4ec06f6b1162f003207ed846fd9209f2d4070389862(v1252) }
pub fn f_49b4b487a9bdb1923937b225e1a5b44124ebdcaa2d08461230f80e63f8ca3344(v1253: &D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14,v1254: u64,v1255: u64,v1256: &D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c,v1257: bool) -> D_85eb081cb2c18b3f9f242ecd82b001fb620e3ec27703b9bd0c819c588e91d440 { d_49b4b487a9bdb1923937b225e1a5b44124ebdcaa2d08461230f80e63f8ca3344(v1253,v1254,v1255,v1256,v1257) }
pub fn f_4bcaeacdd73d19550690c4a882fec63ee438037ded707163ed56d320f45125a5(v1258: &D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14,v1259: u64,v1260: u64,v1261: bool) -> D_85eb081cb2c18b3f9f242ecd82b001fb620e3ec27703b9bd0c819c588e91d440 { d_4bcaeacdd73d19550690c4a882fec63ee438037ded707163ed56d320f45125a5(v1258,v1259,v1260,v1261) }
pub fn f_4fe8180484759596d66ae9f8476d235a3471baaf164ee96d74dafa98607dd2df(v1262: &D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4) -> D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14 { d_4fe8180484759596d66ae9f8476d235a3471baaf164ee96d74dafa98607dd2df(v1262) }
pub fn f_9f081cafe208680fa809ebb2efd71869fec94cb8acec485086fb085da04e3876(v1263: &D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14) -> D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4 { d_9f081cafe208680fa809ebb2efd71869fec94cb8acec485086fb085da04e3876(v1263) }
pub fn f_a408c40899090290509b564bb15de3b0e046dc2ffc24bae39b3e6dec92bee7ce(v1264: &D_85eb081cb2c18b3f9f242ecd82b001fb620e3ec27703b9bd0c819c588e91d440) -> D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14 { d_a408c40899090290509b564bb15de3b0e046dc2ffc24bae39b3e6dec92bee7ce(v1264) }
pub fn f_cb7b07399d66ae3a9db3cf1914bc36b56912d97d339ccc4b4d5943e8c9f40094(v1265: &D_85eb081cb2c18b3f9f242ecd82b001fb620e3ec27703b9bd0c819c588e91d440) -> D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9 { d_cb7b07399d66ae3a9db3cf1914bc36b56912d97d339ccc4b4d5943e8c9f40094(v1265) }
pub fn f_d534958d72b8d1d985bd319d9188a99463f32295f906a8a663b3b711ef45d1d1(v1266: &D_a73d54a65b8fc10db9e4a27ae68f045ef114804bfd375842190af18c88d39668) -> D_c4723b47c6e1d6bbaad257312e3775ae8ebc3ada669ec51045f34d4aefe99a68 { d_d534958d72b8d1d985bd319d9188a99463f32295f906a8a663b3b711ef45d1d1(v1266) }
fn q_2293f25d58473c8c330a164f34117e9631296ac9eb2da0c26cb3fd0ce8cf093a(v0:&D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14,v1:u64,v2:u64)->D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2{match v0 { D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14::C0(v3,v4) => { d_201e280f19da197f80aaeeb90891c2afb639627134c77648eaa04371e3b5cdd6(v3.as_ref(),v2) } }}
fn q_2a8097b87d95e141f8f75c743ae736666ee38a1239b6ac0bf1df9446c69329bd(v0:&D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14,v1:u64)->D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60{match v0 { D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14::C0(v2,v3) => { (v3.as_ref()).clone() } }}
fn t_2293f25d58473c8c330a164f34117e9631296ac9eb2da0c26cb3fd0ce8cf093a(v0:&D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14,v1:u64,v2:u64)->D_a73d54a65b8fc10db9e4a27ae68f045ef114804bfd375842190af18c88d39668{match v0 { D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14::C0(v3,v4) => { D_a73d54a65b8fc10db9e4a27ae68f045ef114804bfd375842190af18c88d39668::C0(std::sync::Arc::new(D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14::C0(std::sync::Arc::clone(v3),std::sync::Arc::clone(v4))),std::sync::Arc::new(D_c4723b47c6e1d6bbaad257312e3775ae8ebc3ada669ec51045f34d4aefe99a68::C0(std::sync::Arc::new(d_201e280f19da197f80aaeeb90891c2afb639627134c77648eaa04371e3b5cdd6(v3.as_ref(),v2)),false,v1,std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0))}))))}),std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})))) } }}
fn t_2a8097b87d95e141f8f75c743ae736666ee38a1239b6ac0bf1df9446c69329bd(v0:&D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14,v1:u64)->D_987bdfeb29bf8c8194a0380157fa972a9aebb1b88b0f37bccc3668daaa1dd78f{match v0 { D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14::C0(v2,v3) => { D_987bdfeb29bf8c8194a0380157fa972a9aebb1b88b0f37bccc3668daaa1dd78f::C0(std::sync::Arc::new(D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14::C0(std::sync::Arc::clone(v2),std::sync::Arc::clone(v3))),std::sync::Arc::new(D_2039380a191f87da8dbfd810ad313b62244825a051b4c0c3de52b6715baca512::C0(std::sync::Arc::clone(v3),false,v1,std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::clone({static v4:std::sync::OnceLock<std::sync::Arc<D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462>>=std::sync::OnceLock::new();v4.get_or_init(||std::sync::Arc::new(D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0))}))))}),std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})))) } }}

use serde_json::{Value as Json,json};
mod portable{
//! Shared, representation-independent snapshot codec. This module also ships
//! verbatim in generated applications; it has no AST/evaluator dependency.
use num_bigint::{BigInt, Sign};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::cmp::Ordering;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Schema {
    Unit,
    Bool,
    U32,
    U64,
    I32,
    F32,
    Vector(Box<Schema>, u8),
    Int,
    String,
    Id,
    Record(Vec<(String, Schema)>),
    Enum(Vec<String>),
    List(Box<Schema>),
    Option(Box<Schema>),
    Result(Box<Schema>, Box<Schema>),
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Layout {
    pub program: [u8; 32],
    pub schema: [u8; 32],
    pub roots: Vec<(String, Schema, Schema)>,
    pub events: Vec<(String, Schema)>,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Event {
    pub commit: u64,
    pub position: u64,
    pub channel: usize,
    pub value: Value,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Logical {
    pub version: u64,
    pub tables: Vec<Vec<(Value, Value)>>,
    pub outbox: Vec<Event>,
}
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub bytes: usize,
    pub values: usize,
    pub depth: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            bytes: 64 * 1024 * 1024,
            values: 1_000_000,
            depth: 128,
        }
    }
}
/// Magnitude bound for one exact integer. Decimal conversion is superlinear,
/// so without it a single large Int in a snapshot takes minutes to hours.
pub const MAX_INT_BYTES: usize = 4096;
const MAGIC: &[u8; 8] = b"VLSTATE\0";
const HEADER: usize = 8 + 2 + 2 + 32 + 32 + 8;
type R<T> = Result<T, String>;
fn u64_bytes(out: &mut Vec<u8>, v: u64) {
    out.extend_from_slice(&v.to_le_bytes());
}
fn count(out: &mut Vec<u8>, n: usize) {
    u64_bytes(out, n as u64);
}
fn raw(out: &mut Vec<u8>, b: &[u8]) {
    count(out, b.len());
    out.extend_from_slice(b);
}
fn tag<'a>(v: &'a Value, name: &str) -> R<&'a Value> {
    let o = v.as_object().ok_or("expected tagged object")?;
    if o.len() != 1 {
        return Err("expected exactly one tag".into());
    }
    o.get(name).ok_or("unexpected value tag".into())
}
fn integer(v: &Value) -> R<BigInt> {
    let s = tag(v, "Int")?.as_str().ok_or("expected Int string")?;
    // Every Int within the bound has fewer than 2.41 decimal digits per byte.
    if s.len() > MAX_INT_BYTES * 5 / 2 + 1 {
        return Err("snapshot Int exceeds size limit".into());
    }
    let n = s.parse::<BigInt>().map_err(|_| "invalid Int")?;
    if n.bits() > 8 * MAX_INT_BYTES as u64 {
        return Err("snapshot Int exceeds size limit".into());
    }
    if n.to_string() != s {
        return Err("noncanonical Int".into());
    }
    Ok(n)
}
fn identifier(v: &Value) -> R<u128> {
    let s = v.as_str().ok_or("expected ID")?;
    if s.len() != 32
        || !s
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err("noncanonical ID".into());
    }
    u128::from_str_radix(s, 16).map_err(|e| e.to_string())
}
fn compare(t: &Schema, a: &Value, b: &Value) -> R<Ordering> {
    Ok(match t {
        Schema::I32 => a
            .as_i64()
            .and_then(|n| i32::try_from(n).ok())
            .ok_or("invalid i32 key")?
            .cmp(
                &b.as_i64()
                    .and_then(|n| i32::try_from(n).ok())
                    .ok_or("invalid i32 key")?,
            ),
        Schema::U32 | Schema::U64 => a
            .as_u64()
            .ok_or("invalid key")?
            .cmp(&b.as_u64().ok_or("invalid key")?),
        Schema::String => a
            .as_str()
            .ok_or("invalid key")?
            .as_bytes()
            .cmp(b.as_str().ok_or("invalid key")?.as_bytes()),
        Schema::Id => identifier(a)?.cmp(&identifier(b)?),
        _ => return Err("unsupported snapshot key schema".into()),
    })
}
fn tick(left: &mut usize, depth: usize, limits: Limits) -> R<()> {
    if *left == 0 || depth > limits.depth {
        return Err("snapshot value/depth limit exceeded".into());
    }
    *left -= 1;
    Ok(())
}
fn encode_value(
    t: &Schema,
    v: &Value,
    out: &mut Vec<u8>,
    left: &mut usize,
    depth: usize,
    limits: Limits,
) -> R<()> {
    tick(left, depth, limits)?;
    match t {
        Schema::Unit => {
            if !v.is_null() {
                return Err("expected Unit".into());
            }
        }
        Schema::Bool => out.push(v.as_bool().ok_or("expected Bool")? as u8),
        Schema::U32 => out.extend_from_slice(
            &u32::try_from(v.as_u64().ok_or("expected u32")?)
                .map_err(|_| "u32 overflow")?
                .to_le_bytes(),
        ),
        Schema::U64 => u64_bytes(out, v.as_u64().ok_or("expected u64")?),
        Schema::I32 => out.extend_from_slice(
            &i32::try_from(v.as_i64().ok_or("expected i32")?)
                .map_err(|_| "i32 overflow")?
                .to_le_bytes(),
        ),
        Schema::F32 => {
            let bits = if let Some(b) = v.get("F32Bits") {
                if v.as_object().is_none_or(|o| o.len() != 1) {
                    return Err("expected only F32Bits field".into());
                }
                u32::try_from(b.as_u64().ok_or("expected f32 bits")?)
                    .map_err(|_| "f32 bits overflow")?
            } else {
                let f = v.as_f64().ok_or("expected f32")? as f32;
                if !f.is_finite() {
                    return Err("finite f32 or F32Bits required".into());
                }
                f.to_bits()
            };
            out.extend_from_slice(&bits.to_le_bytes());
        }
        Schema::Vector(inner, n) => {
            if !(2..=4).contains(n)
                || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
            {
                return Err("invalid vector schema".into());
            }
            let xs = v.as_array().ok_or("expected vector")?;
            if xs.len() != *n as usize {
                return Err("vector dimension mismatch".into());
            }
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Int => {
            let n = integer(v)?;
            let (sign, b) = n.to_bytes_le();
            out.push(match sign {
                Sign::NoSign => 0,
                Sign::Plus => 1,
                Sign::Minus => 2,
            });
            if sign == Sign::NoSign {
                raw(out, &[])
            } else {
                raw(out, &b)
            }
        }
        Schema::String => raw(out, v.as_str().ok_or("expected String")?.as_bytes()),
        Schema::Id => out.extend_from_slice(&identifier(v)?.to_le_bytes()),
        Schema::Enum(names) => {
            let s = v.as_str().ok_or("expected enum string")?;
            let index = names
                .iter()
                .position(|n| n == s)
                .ok_or("unknown enum variant")?;
            out.extend_from_slice(&(index as u32).to_le_bytes());
        }
        Schema::Record(fields) => {
            let obj = v.as_object().ok_or("expected record")?;
            if obj.len() != fields.len() {
                return Err("record field mismatch".into());
            }
            for (n, t) in fields {
                encode_value(
                    t,
                    obj.get(n).ok_or("missing record field")?,
                    out,
                    left,
                    depth + 1,
                    limits,
                )?;
            }
        }
        Schema::List(inner) => {
            let xs = v.as_array().ok_or("expected List")?;
            if xs.len() > *left {
                return Err("snapshot value limit exceeded".into());
            }
            count(out, xs.len());
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Option(inner) => {
            if let Ok(x) = tag(v, "Some") {
                out.push(1);
                encode_value(inner, x, out, left, depth + 1, limits)?;
            } else {
                if !tag(v, "None")?.is_null() {
                    return Err("invalid None".into());
                }
                out.push(0);
            }
        }
        Schema::Result(a, b) => {
            if let Ok(x) = tag(v, "Ok") {
                out.push(0);
                encode_value(a, x, out, left, depth + 1, limits)?;
            } else {
                out.push(1);
                encode_value(b, tag(v, "Err")?, out, left, depth + 1, limits)?;
            }
        }
    }
    if out.len() > limits.bytes {
        return Err("snapshot byte limit exceeded".into());
    }
    Ok(())
}
struct Reader<'a> {
    bytes: &'a [u8],
    at: usize,
    left: usize,
    limits: Limits,
}
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> R<&'a [u8]> {
        let end = self.at.checked_add(n).ok_or("snapshot length overflow")?;
        let b = self.bytes.get(self.at..end).ok_or("truncated snapshot")?;
        self.at = end;
        Ok(b)
    }
    fn byte(&mut self) -> R<u8> {
        Ok(self.take(1)?[0])
    }
    fn u32(&mut self) -> R<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn u64(&mut self) -> R<u64> {
        Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
    fn len(&mut self) -> R<usize> {
        usize::try_from(self.u64()?).map_err(|_| "snapshot length not addressable".into())
    }
    fn sequence(&mut self) -> R<usize> {
        let n = self.len()?;
        if n > self.left {
            return Err("snapshot value limit exceeded".into());
        }
        Ok(n)
    }
    fn raw(&mut self) -> R<&'a [u8]> {
        let n = self.len()?;
        self.take(n)
    }
    fn value(&mut self, t: &Schema, depth: usize) -> R<Value> {
        tick(&mut self.left, depth, self.limits)?;
        Ok(match t {
            Schema::Unit => Value::Null,
            Schema::Bool => match self.byte()? {
                0 => json!(false),
                1 => json!(true),
                _ => return Err("invalid Bool tag".into()),
            },
            Schema::U32 => json!(self.u32()?),
            Schema::U64 => json!(self.u64()?),
            Schema::I32 => json!(self.u32()? as i32),
            Schema::F32 => {
                let bits = self.u32()?;
                let f = f32::from_bits(bits);
                if f.is_finite() {
                    json!(f)
                } else {
                    json!({"F32Bits":bits})
                }
            }
            Schema::Vector(inner, n) => {
                if !(2..=4).contains(n)
                    || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
                {
                    return Err("invalid vector schema".into());
                }
                (0..*n)
                    .map(|_| self.value(inner, depth + 1))
                    .collect::<R<Vec<_>>>()?
                    .into()
            }
            Schema::Int => {
                let sign = self.byte()?;
                let bytes = self.raw()?;
                if bytes.len() > MAX_INT_BYTES {
                    return Err("snapshot Int exceeds size limit".into());
                }
                let sign = match sign {
                    0 if bytes.is_empty() => Sign::NoSign,
                    1 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Plus,
                    2 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Minus,
                    _ => return Err("noncanonical signed integer".into()),
                };
                json!({"Int":BigInt::from_bytes_le(sign,bytes).to_string()})
            }
            Schema::String => json!(std::str::from_utf8(self.raw()?).map_err(|_| "invalid UTF-8")?),
            Schema::Id => json!(format!(
                "{:032x}",
                u128::from_le_bytes(self.take(16)?.try_into().unwrap())
            )),
            Schema::Enum(names) => {
                json!(names.get(self.u32()? as usize).ok_or("invalid enum tag")?)
            }
            Schema::Record(fields) => {
                let mut obj = serde_json::Map::new();
                for (n, t) in fields {
                    obj.insert(n.clone(), self.value(t, depth + 1)?);
                }
                Value::Object(obj)
            }
            Schema::List(t) => {
                let n = self.sequence()?;
                let mut xs = Vec::new();
                for _ in 0..n {
                    xs.push(self.value(t, depth + 1)?);
                }
                Value::Array(xs)
            }
            Schema::Option(t) => match self.byte()? {
                0 => json!({"None":null}),
                1 => json!({"Some":self.value(t,depth+1)?}),
                _ => return Err("invalid Option tag".into()),
            },
            Schema::Result(a, b) => match self.byte()? {
                0 => json!({"Ok":self.value(a,depth+1)?}),
                1 => json!({"Err":self.value(b,depth+1)?}),
                _ => return Err("invalid Result tag".into()),
            },
        })
    }
}
fn event_order(e: &Event, version: u64, prior: Option<(u64, u64)>) -> R<()> {
    if e.commit == 0 || e.commit > version || prior.is_some_and(|p| p >= (e.commit, e.position)) {
        return Err("invalid snapshot event sequence".into());
    }
    Ok(())
}
pub fn encode(layout: &Layout, s: &Logical, limits: Limits) -> R<Vec<u8>> {
    if s.tables.len() != layout.roots.len() {
        return Err("snapshot root count mismatch".into());
    }
    let mut out = Vec::new();
    let mut left = limits.values;
    u64_bytes(&mut out, s.version);
    for (rows, (_, kt, vt)) in s.tables.iter().zip(&layout.roots) {
        if rows.len() > left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        count(&mut out, rows.len());
        let mut prior = None;
        for (k, v) in rows {
            if let Some(p) = prior {
                if compare(kt, p, k)? != Ordering::Less {
                    return Err("snapshot keys must be strictly ordered".into());
                }
            }
            encode_value(kt, k, &mut out, &mut left, 0, limits)?;
            encode_value(vt, v, &mut out, &mut left, 0, limits)?;
            prior = Some(k);
        }
    }
    count(&mut out, s.outbox.len());
    let mut prior = None;
    for e in &s.outbox {
        event_order(e, s.version, prior)?;
        let (_, t) = layout
            .events
            .get(e.channel)
            .ok_or("unknown event channel")?;
        u64_bytes(&mut out, e.commit);
        u64_bytes(&mut out, e.position);
        out.extend_from_slice(&(e.channel as u32).to_le_bytes());
        encode_value(t, &e.value, &mut out, &mut left, 0, limits)?;
        prior = Some((e.commit, e.position));
    }
    if HEADER
        .checked_add(out.len())
        .and_then(|n| n.checked_add(32))
        .is_none_or(|n| n > limits.bytes)
    {
        return Err("snapshot byte limit exceeded".into());
    }
    let mut bytes = Vec::new();
    bytes.extend_from_slice(MAGIC);
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&layout.program);
    bytes.extend_from_slice(&layout.schema);
    count(&mut bytes, out.len());
    bytes.extend_from_slice(&out);
    let digest = Sha256::digest(&bytes);
    bytes.extend_from_slice(&digest);
    Ok(bytes)
}
pub fn decode(layout: &Layout, bytes: &[u8], limits: Limits) -> R<Logical> {
    if bytes.len() > limits.bytes || bytes.len() < HEADER + 32 {
        return Err("snapshot byte length invalid".into());
    }
    if &bytes[..8] != MAGIC || bytes[8..12] != [1, 0, 1, 0] {
        return Err("snapshot format or semantics version mismatch".into());
    }
    if bytes[12..44] != layout.program || bytes[44..76] != layout.schema {
        return Err("snapshot program or schema identity mismatch".into());
    }
    let n = usize::try_from(u64::from_le_bytes(bytes[76..84].try_into().unwrap()))
        .map_err(|_| "snapshot length not addressable")?;
    if HEADER.checked_add(n).and_then(|v| v.checked_add(32)) != Some(bytes.len()) {
        return Err("snapshot payload length mismatch".into());
    }
    let end = bytes.len() - 32;
    if Sha256::digest(&bytes[..end]).as_slice() != &bytes[end..] {
        return Err("snapshot integrity check failed".into());
    }
    let mut r = Reader {
        bytes: &bytes[HEADER..end],
        at: 0,
        left: limits.values,
        limits,
    };
    let version = r.u64()?;
    let mut tables = vec![];
    for (_, kt, vt) in &layout.roots {
        let n = r.sequence()?;
        if n > r.left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        let mut rows: Vec<(Value, Value)> = vec![];
        for _ in 0..n {
            let k = r.value(kt, 0)?;
            let v = r.value(vt, 0)?;
            if let Some((prior, _)) = rows.last() {
                if compare(kt, prior, &k)? != Ordering::Less {
                    return Err("duplicate or unordered snapshot key".into());
                }
            }
            rows.push((k, v));
        }
        tables.push(rows);
    }
    let n = r.sequence()?;
    let mut outbox = vec![];
    let mut prior = None;
    for _ in 0..n {
        let commit = r.u64()?;
        let position = r.u64()?;
        let channel = r.u32()? as usize;
        let (_, t) = layout
            .events
            .get(channel)
            .ok_or("unknown snapshot event channel")?;
        let value = r.value(t, 0)?;
        let e = Event {
            commit,
            position,
            channel,
            value,
        };
        event_order(&e, version, prior)?;
        prior = Some((commit, position));
        outbox.push(e);
    }
    if r.at != r.bytes.len() {
        return Err("trailing snapshot payload".into());
    }
    Ok(Logical {
        version,
        tables,
        outbox,
    })
}

}
pub use portable::Limits as SnapshotLimits;
fn snapshot_layout()->portable::Layout{portable::Layout{program:[198, 250, 5, 100, 156, 198, 184, 164, 211, 225, 119, 254, 12, 101, 97, 28, 119, 18, 228, 201, 97, 90, 9, 239, 53, 254, 180, 41, 67, 157, 95, 243],schema:[100, 158, 40, 254, 106, 233, 63, 3, 104, 14, 41, 32, 114, 78, 131, 217, 86, 160, 145, 67, 151, 190, 67, 95, 14, 123, 126, 238, 228, 124, 115, 222],roots:vec![
("Inputs".into(),portable::Schema::U64,portable::Schema::Record(vec![("grid".into(),portable::Schema::List(Box::new(portable::Schema::U32))),("width".into(),portable::Schema::U32),("start".into(),portable::Schema::U32),("goal".into(),portable::Schema::U32),("limit".into(),portable::Schema::U32)])),
],events:vec![]}}
fn one_tag<'a>(v:&'a Json,_kind:&str)->Result<&'a serde_json::Map<String,Json>,String>{Ok(v.as_object().unwrap())}
fn read_0(v:&Json,d:usize)->Result<bool,String>{Ok(
v.as_bool().unwrap())}
fn write_0(v:&bool,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_1(v:&Json,d:usize)->Result<u64,String>{Ok(
v.as_u64().unwrap())}
fn write_1(v:&u64,d:usize)->Result<Json,String>{Ok(
{json!(v)})}
fn read_2(v:&Json,d:usize)->Result<u64,String>{Ok(
v.as_u64().unwrap())}
fn write_2(v:&u64,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_3(v:&Json,d:usize)->Result<D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7,String>{Ok(
{D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7::C0})}
fn write_3(v:&D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7,d:usize)->Result<Json,String>{Ok(
Json::Null)}
fn read_6(v:&Json,d:usize)->Result<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,String>{Ok(
{let xs=v.as_array().unwrap();let mut tail=D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0;for x in xs.iter().rev(){tail=D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(read_1(x,d+1)?,std::sync::Arc::new(tail));}tail})}
fn write_6(v:&D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,d:usize)->Result<Json,String>{Ok(
{let mut cursor=v;let mut xs=vec![];loop{match cursor{D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0=>break,D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(x,tail)=>{xs.push(write_1(x,d+1)?);cursor=tail.as_ref();}}}Json::Array(xs)})}
fn read_7(v:&Json,d:usize)->Result<D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871,String>{Ok(
{let xs=v.as_array().unwrap();let mut tail=D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0;for x in xs.iter().rev(){tail=D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(std::sync::Arc::new(read_10(x,d+1)?),std::sync::Arc::new(tail));}tail})}
fn write_7(v:&D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871,d:usize)->Result<Json,String>{Ok(
{let mut cursor=v;let mut xs=vec![];loop{match cursor{D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0=>break,D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(x,tail)=>{xs.push(write_10(x,d+1)?);cursor=tail.as_ref();}}}Json::Array(xs)})}
fn read_10(v:&Json,d:usize)->Result<D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f,String>{Ok(
{let xs=v.as_object().unwrap();D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(read_1(xs.get("node").unwrap(),d+1)?,read_1(xs.get("priority").unwrap(),d+1)?)})}
fn write_10(v:&D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f,d:usize)->Result<Json,String>{Ok(
{let D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(b0,b1)=v;json!({"node":write_1(&b0,d+1)?,"priority":write_1(&b1,d+1)?})})}
fn read_11(v:&Json,d:usize)->Result<D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c,String>{Ok(
{let xs=v.as_object().unwrap();D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(std::sync::Arc::new(read_6(xs.get("grid").unwrap(),d+1)?),read_1(xs.get("width").unwrap(),d+1)?,read_1(xs.get("start").unwrap(),d+1)?,read_1(xs.get("goal").unwrap(),d+1)?,read_1(xs.get("limit").unwrap(),d+1)?)})}
fn write_11(v:&D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c,d:usize)->Result<Json,String>{Ok(
{let D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(b0,b1,b2,b3,b4)=v;json!({"grid":write_6(&b0,d+1)?,"width":write_1(&b1,d+1)?,"start":write_1(&b2,d+1)?,"goal":write_1(&b3,d+1)?,"limit":write_1(&b4,d+1)?})})}
fn read_14(v:&Json,d:usize)->Result<D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd,String>{Ok(
{let xs=v.as_object().unwrap();D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd::C0(read_0(xs.get("found").unwrap(),d+1)?,read_1(xs.get("distance").unwrap(),d+1)?,read_1(xs.get("expanded").unwrap(),d+1)?,read_0(xs.get("limited").unwrap(),d+1)?,std::sync::Arc::new(read_6(xs.get("path").unwrap(),d+1)?))})}
fn write_14(v:&D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd,d:usize)->Result<Json,String>{Ok(
{let D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd::C0(b0,b1,b2,b3,b4)=v;json!({"found":write_0(&b0,d+1)?,"distance":write_1(&b1,d+1)?,"expanded":write_1(&b2,d+1)?,"limited":write_0(&b3,d+1)?,"path":write_6(&b4,d+1)?})})}
fn read_16(v:&Json,d:usize)->Result<D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea::C1(read_0(x,d+1)?)}else{D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea::C0}})}
fn write_16(v:&D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea,d:usize)->Result<Json,String>{Ok(
match v{D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea::C0=>json!({"None":null}),D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea::C1(x)=>json!({"Some":write_0(x,d+1)?})})}
fn read_17(v:&Json,d:usize)->Result<D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(read_1(x,d+1)?)}else{D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0}})}
fn write_17(v:&D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531,d:usize)->Result<Json,String>{Ok(
match v{D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0=>json!({"None":null}),D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(x)=>json!({"Some":write_1(x,d+1)?})})}
fn read_18(v:&Json,d:usize)->Result<D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(std::sync::Arc::new(read_10(x,d+1)?))}else{D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0}})}
fn write_18(v:&D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6,d:usize)->Result<Json,String>{Ok(
match v{D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0=>json!({"None":null}),D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(x)=>json!({"Some":write_10(x,d+1)?})})}
fn read_19(v:&Json,d:usize)->Result<D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C1(std::sync::Arc::new(read_11(x,d+1)?))}else{D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C0}})}
fn write_19(v:&D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2,d:usize)->Result<Json,String>{Ok(
match v{D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C0=>json!({"None":null}),D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C1(x)=>json!({"Some":write_11(x,d+1)?})})}
fn read_20(v:&Json,d:usize)->Result<D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60::C1(std::sync::Arc::new(read_14(x,d+1)?))}else{D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60::C0}})}
fn write_20(v:&D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60,d:usize)->Result<Json,String>{Ok(
match v{D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60::C0=>json!({"None":null}),D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60::C1(x)=>json!({"Some":write_14(x,d+1)?})})}
fn read_21(v:&Json,d:usize)->Result<D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd,String>{Ok(
{let xs=one_tag(v,"Result")?;if let Some(x)=xs.get("Ok"){D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(std::sync::Arc::new(read_3(x,d+1)?))}else{let x=xs.get("Err").unwrap();D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(read_0(x,d+1)?)}})}
fn write_21(v:&D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd,d:usize)->Result<Json,String>{Ok(
match v{D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(x)=>json!({"Ok":write_3(x,d+1)?}),D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(x)=>json!({"Err":write_0(x,d+1)?})})}
fn logical_from_tables(tables:&[Vec<(Json,Json)>])->Result<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4,String>{if tables.len()!=1{return Err("representation table count mismatch".into())}
let rows=&tables[0];let mut root0=D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0;for (key,row) in rows.iter().rev(){root0=D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(read_2(key,0)?,std::sync::Arc::new(read_11(row,0)?),std::sync::Arc::new(root0));}
Ok(D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::new(root0)))}
fn logical_tables(state:&D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4)->Result<Vec<Vec<(Json,Json)>>,String>{let D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(r0)=state;
let mut rows0=vec![];let mut cursor=r0.as_ref();loop{match cursor{D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0=>break,D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(key,value,tail)=>{rows0.push((write_2(key,0)?,write_11(value,0)?));cursor=tail.as_ref();}}}
Ok(vec![rows0])}
fn logical_events(events:&D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d)->Result<Vec<(usize,Json)>,String>{let mut cursor=events;let mut out=vec![];loop{match cursor{D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0=>break,D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C1(event,tail)=>{let value=match event.as_ref(){
D_4e61cd2054b66259fa5fe6ff2848621d519f896c6b83b26615faed118e66c0c8::C0=>return Err("unknown source event".into()),
};out.push(value);cursor=tail.as_ref();}}}Ok(out)}
pub use portable::Event;
pub struct Outcome<T>{pub result:T,pub committed:bool,pub version:u64,pub events:Vec<Event>}
pub struct OutcomeView<'a,T>{pub result:T,pub committed:bool,pub version:u64,pub events:&'a[Event]}
impl<T> OutcomeView<'_,T>{pub fn into_owned(self)->Outcome<T>{Outcome{result:self.result,committed:self.committed,version:self.version,events:self.events.to_vec()}}}
pub struct State{physical:D_27fcf37c92b3c0dc357fdfecee8deb0efc2aaf93def02f07e9d1b73203b22d14,version:u64,outbox:Vec<portable::Event>,layout:portable::Layout}
impl State{
// CALLER CONTRACT: arguments must have the declared types and canonical values.
// No runtime type validation. Malformed input may panic, trap or corrupt state.
pub fn new()->Result<Self,String>{let logical=D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::new(D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0));Ok(Self{physical:f_4fe8180484759596d66ae9f8476d235a3471baaf164ee96d74dafa98607dd2df(&logical),version:0,outbox:vec![],layout:snapshot_layout()})}
pub fn restore(bytes:&[u8])->Result<Self,String>{let layout=snapshot_layout();let saved=portable::decode(&layout,bytes,SnapshotLimits::default())?;let logical=logical_from_tables(&saved.tables)?;Ok(Self{physical:f_4fe8180484759596d66ae9f8476d235a3471baaf164ee96d74dafa98607dd2df(&logical),version:saved.version,outbox:saved.outbox,layout})}
pub fn checkpoint(&self)->Result<Vec<u8>,String>{let logical=f_9f081cafe208680fa809ebb2efd71869fec94cb8acec485086fb085da04e3876(&(self.physical));portable::encode(&self.layout,&portable::Logical{version:self.version,tables:logical_tables(&logical)?,outbox:self.outbox.clone()},SnapshotLimits::default())}
pub fn version(&self)->u64{self.version}
pub fn outbox_json(&self)->Json{Json::Array(self.outbox.iter().map(|e|json!({"commit":e.commit,"position":e.position,"channel":self.layout.events[e.channel].0,"value":e.value})).collect())}
pub fn acknowledge_through(&mut self,commit:u64,position:u64){self.outbox.retain(|e|(e.commit,e.position)>(commit,position));}
pub fn query_route(&self,)->D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60{q_2a8097b87d95e141f8f75c743ae736666ee38a1239b6ac0bf1df9446c69329bd(&(self.physical),self.version)}
pub fn query_get(&self,a0:u64)->D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2{q_2293f25d58473c8c330a164f34117e9631296ac9eb2da0c26cb3fd0ce8cf093a(&(self.physical),self.version,a0)}
pub fn invoke_view_put(&mut self,a0:u64,a1:&D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c,a2:bool)->Result<OutcomeView<'_,D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd>,String>{
let executed=f_49b4b487a9bdb1923937b225e1a5b44124ebdcaa2d08461230f80e63f8ca3344(&(self.physical),self.version,a0,a1,a2);let observed=f_cb7b07399d66ae3a9db3cf1914bc36b56912d97d339ccc4b4d5943e8c9f40094(&(executed));let next=f_a408c40899090290509b564bb15de3b0e046dc2ffc24bae39b3e6dec92bee7ce(&(executed));
let(result,committed,version,events)=match &observed{D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_erase(&mut self,a0:u64,a1:bool)->Result<OutcomeView<'_,D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd>,String>{
let executed=f_4bcaeacdd73d19550690c4a882fec63ee438037ded707163ed56d320f45125a5(&(self.physical),self.version,a0,a1);let observed=f_cb7b07399d66ae3a9db3cf1914bc36b56912d97d339ccc4b4d5943e8c9f40094(&(executed));let next=f_a408c40899090290509b564bb15de3b0e046dc2ffc24bae39b3e6dec92bee7ce(&(executed));
let(result,committed,version,events)=match &observed{D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_route(&mut self,)->Result<OutcomeView<'_,D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60>,String>{
let result=q_2a8097b87d95e141f8f75c743ae736666ee38a1239b6ac0bf1df9446c69329bd(&(self.physical),self.version);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_view_get(&mut self,a0:u64)->Result<OutcomeView<'_,D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2>,String>{
let result=q_2293f25d58473c8c330a164f34117e9631296ac9eb2da0c26cb3fd0ce8cf093a(&(self.physical),self.version,a0);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_json(&mut self,name:&str,args:&Json)->Result<Json,String>{match name{
"put"=>{let xs=args.as_array().unwrap();
let a0=read_2(&xs[0],0)?;
let a1=read_11(&xs[1],0)?;
let a2=read_0(&xs[2],0)?;
let executed=f_49b4b487a9bdb1923937b225e1a5b44124ebdcaa2d08461230f80e63f8ca3344(&(self.physical),self.version,a0,&(a1),a2);
let observed=f_cb7b07399d66ae3a9db3cf1914bc36b56912d97d339ccc4b4d5943e8c9f40094(&(executed));let next=f_a408c40899090290509b564bb15de3b0e046dc2ffc24bae39b3e6dec92bee7ce(&(executed));let(reply,committed,version,events)=match &observed{D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_21(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&[];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"erase"=>{let xs=args.as_array().unwrap();
let a0=read_2(&xs[0],0)?;
let a1=read_0(&xs[1],0)?;
let executed=f_4bcaeacdd73d19550690c4a882fec63ee438037ded707163ed56d320f45125a5(&(self.physical),self.version,a0,a1);
let observed=f_cb7b07399d66ae3a9db3cf1914bc36b56912d97d339ccc4b4d5943e8c9f40094(&(executed));let next=f_a408c40899090290509b564bb15de3b0e046dc2ffc24bae39b3e6dec92bee7ce(&(executed));let(reply,committed,version,events)=match &observed{D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_21(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&[];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"route"=>{let xs=args.as_array().unwrap();
let reply=q_2a8097b87d95e141f8f75c743ae736666ee38a1239b6ac0bf1df9446c69329bd(&(self.physical),self.version);let result=write_20(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
"get"=>{let xs=args.as_array().unwrap();
let a0=read_2(&xs[0],0)?;
let reply=q_2293f25d58473c8c330a164f34117e9631296ac9eb2da0c26cb3fd0ce8cf093a(&(self.physical),self.version,a0);let result=write_19(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
_=>Err(format!("unknown action {name}"))}}}
