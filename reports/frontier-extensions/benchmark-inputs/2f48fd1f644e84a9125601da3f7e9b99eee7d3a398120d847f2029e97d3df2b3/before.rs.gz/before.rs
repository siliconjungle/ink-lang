// ink-definition-rust-v1: checked bodies; Rust/backend are trusted.
#![allow(non_camel_case_types, non_snake_case, non_upper_case_globals, dead_code, unused_variables, unused_parens, unused_unsafe, improper_ctypes_definitions)]
fn d_002fa87dc14fb22703d067bc5256bb42a441ff9bc957fdd023ea162e558462ba(v0: &D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd,v1: u64) -> bool { match &(d_8f49b0501dc5088b5b1fbb496bf7a43da0fc57cc982a3223cec950add0d80d8c(v0,v1)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { false },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v2) => { true } } }
fn d_03ff34b5386d1e23ed93a530286dcfa18b3c56053b5eabeb72372c1a2a11723b(v3: &D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b,v4: u64) -> D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea { match v3 { D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C0 => { D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea::C0 },D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C1(v6,v7,v8) => { if ((v4) == (*v6)) { D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea::C1(*v7) } else { d_03ff34b5386d1e23ed93a530286dcfa18b3c56053b5eabeb72372c1a2a11723b(v8.as_ref(),v4) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7 { C0 }
impl D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_09057230fba3197d24acf11d85f672c6c272b2c13015c0be441b90f6e99d6967(v9: &D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4,v10: u64,v11: u64,v12: &D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c,v13: bool) -> D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9 { match &(D_ed742c79021c129a74c485de3fde12f113f9e1f62fcdff87129f05a60f244981::C0(std::sync::Arc::new(match v9 { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v14) => { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::new(d_cf1230bd75cb8423314de8b7d3f4d503a062de575d48e96f3c36c0da9dcc1bce(&(match v9 { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v15) => { (v15.as_ref()).clone() } }),v11))) } }))) { D_ed742c79021c129a74c485de3fde12f113f9e1f62fcdff87129f05a60f244981::C0(v16) => { if d_5d52ea5a8e356f04093cac1a6710051c7c2d51db1cd9d2dfd20c3fd5caf5fb77(&(match v16.as_ref() { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v17) => { (v17.as_ref()).clone() } }),v11) { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(2u64,v10,std::sync::Arc::new((v9).clone())) } else { match &(D_ed742c79021c129a74c485de3fde12f113f9e1f62fcdff87129f05a60f244981::C0(std::sync::Arc::new(match v16.as_ref() { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v18) => { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::new(d_43bae9f2ef5694c4b79528f373bcea8d176e1e4987e703eee8ce693cd749aa53(&(match v16.as_ref() { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v19) => { (v19.as_ref()).clone() } }),v11,v12))) } }))) { D_ed742c79021c129a74c485de3fde12f113f9e1f62fcdff87129f05a60f244981::C0(v20) => { if v13 { match &(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(true)) { D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(v22) => { if ((v10) == (18446744073709551615u64)) { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(1u64,v10,std::sync::Arc::new((v9).clone())) } else { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(std::sync::Arc::new(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(std::sync::Arc::clone(v22))),true,(v10).wrapping_add(1u64),std::sync::Arc::clone(v20),std::sync::Arc::clone({static v23:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v23.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) } },D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(v24) => { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(std::sync::Arc::new(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(*v24)),false,v10,std::sync::Arc::new((v9).clone()),std::sync::Arc::clone({static v25:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v25.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) } } } else { match &(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(std::sync::Arc::clone({static v26:std::sync::OnceLock<std::sync::Arc<D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7>>=std::sync::OnceLock::new();v26.get_or_init(||std::sync::Arc::new(D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7::C0))}))) { D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(v28) => { if ((v10) == (18446744073709551615u64)) { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(1u64,v10,std::sync::Arc::new((v9).clone())) } else { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(std::sync::Arc::new(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(std::sync::Arc::clone(v28))),true,(v10).wrapping_add(1u64),std::sync::Arc::clone(v20),std::sync::Arc::clone({static v29:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v29.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) } },D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(v30) => { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(std::sync::Arc::new(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(*v30)),false,v10,std::sync::Arc::new((v9).clone()),std::sync::Arc::clone({static v31:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v31.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) } } } } } } } } }
fn d_0ed0c70186c5d63822b08f5fba5ddd2bccbdb0d4cf4eebe37775cb2841f7cecd(v32: &D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4,v33: u64,v34: u64) -> D_c4723b47c6e1d6bbaad257312e3775ae8ebc3ada669ec51045f34d4aefe99a68 { D_c4723b47c6e1d6bbaad257312e3775ae8ebc3ada669ec51045f34d4aefe99a68::C0(std::sync::Arc::new(d_201e280f19da197f80aaeeb90891c2afb639627134c77648eaa04371e3b5cdd6(&(match v32 { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v35) => { (v35.as_ref()).clone() } }),v34)),false,v33,std::sync::Arc::new((v32).clone()),std::sync::Arc::clone({static v36:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v36.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) }
fn d_10474bbc4ac74580f8be4e0fa212cee2c299d6988c03e31fe5089407d8cf0f2a(v37: &D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd,v38: u64,v39: u64) -> D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd { match v37 { D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C0 => { D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C1(v38,v39,std::sync::Arc::clone({static v40:std::sync::OnceLock<std::sync::Arc<D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd>>=std::sync::OnceLock::new();v40.get_or_init(||std::sync::Arc::new(D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C0))})) },D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C1(v41,v42,v43) => { if ((v38) < (*v41)) { D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C1(v38,v39,std::sync::Arc::new((v37).clone())) } else { D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C1(*v41,*v42,std::sync::Arc::new(d_10474bbc4ac74580f8be4e0fa212cee2c299d6988c03e31fe5089407d8cf0f2a(v43.as_ref(),v38,v39))) } } } }
fn d_1338047bd9cf52a17a4e86ffc009b659e90ff924cb48778cbcac39b169b0bbeb(v44: &D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301) -> D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9 { match v44 { D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301::C0 => { D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0 },D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301::C1(v46) => { D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (1u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (2u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (4u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (8u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (16u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (32u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (64u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (128u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (256u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (512u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (1024u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (2048u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (4096u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (8192u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (16384u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (32768u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (65536u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (131072u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (262144u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (524288u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (1048576u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (2097152u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (4194304u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (8388608u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (16777216u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (33554432u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (67108864u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (134217728u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (268435456u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (536870912u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (1073741824u64))) != (0u64)),std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(((((*v46) & (2147483648u64))) != (0u64)),std::sync::Arc::clone({static v47:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v47.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0))})))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))))) } } }
fn d_187292ac266e47508456207738c31f8ed95e66636f4545e364e133428466ee7c(v48: &D_fdf257bc2584502163667d3ea4dbd18025f65af51919f5dc5f35439fd24e1fef) -> D_c4723b47c6e1d6bbaad257312e3775ae8ebc3ada669ec51045f34d4aefe99a68 { match v48 { D_fdf257bc2584502163667d3ea4dbd18025f65af51919f5dc5f35439fd24e1fef::C0(v49,v50) => { (v50.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8 { C0,C1(u64,std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>) }
impl D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_201e280f19da197f80aaeeb90891c2afb639627134c77648eaa04371e3b5cdd6(v51: &D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462,v52: u64) -> D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2 { match v51 { D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0 => { D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C0 },D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(v54,v55,v56) => { if ((v52) == (*v54)) { D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C1(std::sync::Arc::clone(v55)) } else { d_201e280f19da197f80aaeeb90891c2afb639627134c77648eaa04371e3b5cdd6(v56.as_ref(),v52) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_2039380a191f87da8dbfd810ad313b62244825a051b4c0c3de52b6715baca512 { C0(std::sync::Arc<D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60>,bool,u64,std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>,std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>),C1(u64,u64,std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>) }
fn d_233173ac9b19280e2ca75fd60b2c1eec94767f63b49507f3b5639702c686f8aa(v57: &D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9,v58: u64,v59: u64,v60: &D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39) -> D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39 { if if ((v58) == (0u64)) { true } else { if match v60 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v61,v62,v63,v64,v65,v66,v67,v68,v69,v70) => { *v68 } } { true } else { ((d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(&(match v60 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v71,v72,v73,v74,v75,v76,v77,v78,v79,v80) => { (v72.as_ref()).clone() } }))) == (0u64)) } } { (v60).clone() } else { match v57 { D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0 => { (v60).clone() },D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(v81,v82) => { if *v81 { match &(D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(std::sync::Arc::new(d_233173ac9b19280e2ca75fd60b2c1eec94767f63b49507f3b5639702c686f8aa(v82.as_ref(),(v58).checked_div(2u64).unwrap_or(0),(((v59).wrapping_add((v58).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_233173ac9b19280e2ca75fd60b2c1eec94767f63b49507f3b5639702c686f8aa(v82.as_ref(),(v58).checked_div(2u64).unwrap_or(0),v59,v60)))))) { D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(v83) => { if if match v83.as_ref() { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v84,v85,v86,v87,v88,v89,v90,v91,v92,v93) => { *v91 } } { true } else { ((d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(&(match v83.as_ref() { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v94,v95,v96,v97,v98,v99,v100,v101,v102,v103) => { (v95.as_ref()).clone() } }))) == (0u64)) } { (v83.as_ref()).clone() } else { d_599d0232d36959692a62209d86c61353da0eb94a68384f34652c80554a65fc29(v83.as_ref()) } } } } else { d_233173ac9b19280e2ca75fd60b2c1eec94767f63b49507f3b5639702c686f8aa(v82.as_ref(),(v58).checked_div(2u64).unwrap_or(0),(((v59).wrapping_add((v58).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_233173ac9b19280e2ca75fd60b2c1eec94767f63b49507f3b5639702c686f8aa(v82.as_ref(),(v58).checked_div(2u64).unwrap_or(0),v59,v60))) } } } } }
fn d_2b69c64cbe72e93b1b88f554091ce5857248e729631172c1b5518c2642c807f2(v104: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8) -> D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8 { match v104 { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 => { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 },D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v106,v107) => { if false { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(*v106,std::sync::Arc::new(d_2b69c64cbe72e93b1b88f554091ce5857248e729631172c1b5518c2642c807f2(v107.as_ref()))) } else { d_2b69c64cbe72e93b1b88f554091ce5857248e729631172c1b5518c2642c807f2(v107.as_ref()) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b { C0,C1(u64,bool,std::sync::Arc<D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b>) }
impl D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c { C0(std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>,u64,u64,u64,u64) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871 { C0,C1(std::sync::Arc<D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f>,std::sync::Arc<D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871>) }
impl D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301 { C0,C1(u64) }
fn d_38f19433a51fb11a49e83af2a67a8238c5549ed37cdfbe13e98bdd148bac8b8d(v108: &D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f,v109: u64,v110: u64) -> D_fdf257bc2584502163667d3ea4dbd18025f65af51919f5dc5f35439fd24e1fef { D_fdf257bc2584502163667d3ea4dbd18025f65af51919f5dc5f35439fd24e1fef::C0(std::sync::Arc::new((v108).clone()),std::sync::Arc::new(d_0ed0c70186c5d63822b08f5fba5ddd2bccbdb0d4cf4eebe37775cb2841f7cecd(&(d_8f8f9cf94b421df1993f5b3088dbaeb4cdbf8902174eb4cc7e959206aeb63d80(v108)),v109,v110))) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd { C0(std::sync::Arc<D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7>),C1(bool) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d { C0(std::sync::Arc<D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871>,u64,bool) }
fn d_3d49fac84fd706ca4d2bddc3c53e21f9c8d82e8a70ee8b81def02800d29a11f7(v111: &D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4) -> D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f { match v111 { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v112) => { D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f::C0(std::sync::Arc::clone(v112)) } } }
fn d_3ec78a35272ed91061dacb8c052a158f10da108f6d53693c7b0661117c1a477a(v113: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v114: u64) -> D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531 { match v113 { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 => { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 },D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v116,v117) => { if ((v114) == (0u64)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(*v116) } else { d_3ec78a35272ed91061dacb8c052a158f10da108f6d53693c7b0661117c1a477a(v117.as_ref(),(((v114).wrapping_sub(1u64)) & (4294967295u64))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39 { C0(std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>,std::sync::Arc<D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871>,std::sync::Arc<D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd>,std::sync::Arc<D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b>,std::sync::Arc<D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd>,u64,u64,bool,u64,u64) }
fn d_40f81830bbf4127535b60ab6c9d54b1ffed69633c3d1e8eb4c12f7e778f3d35f(v118: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v119: u64) -> D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8 { match v118 { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 => { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v119,std::sync::Arc::clone({static v120:std::sync::OnceLock<std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>>=std::sync::OnceLock::new();v120.get_or_init(||std::sync::Arc::new(D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0))})) },D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v121,v122) => { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(*v121,std::sync::Arc::new(d_40f81830bbf4127535b60ab6c9d54b1ffed69633c3d1e8eb4c12f7e778f3d35f(v122.as_ref(),v119))) } } }
fn d_43bae9f2ef5694c4b79528f373bcea8d176e1e4987e703eee8ce693cd749aa53(v123: &D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462,v124: u64,v125: &D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c) -> D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462 { match v123 { D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0 => { D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(v124,std::sync::Arc::new((v125).clone()),std::sync::Arc::clone({static v126:std::sync::OnceLock<std::sync::Arc<D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462>>=std::sync::OnceLock::new();v126.get_or_init(||std::sync::Arc::new(D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0))})) },D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(v127,v128,v129) => { if ((v124) < (*v127)) { D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(v124,std::sync::Arc::new((v125).clone()),std::sync::Arc::new((v123).clone())) } else { D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(*v127,std::sync::Arc::clone(v128),std::sync::Arc::new(d_43bae9f2ef5694c4b79528f373bcea8d176e1e4987e703eee8ce693cd749aa53(v129.as_ref(),v124,v125))) } } } }
fn d_4662356d4b7aebe6e74645c080deab29c301ad4662c930b428d106d4173c856a(v130: &D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d) -> D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(&(match v130 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v131,v132,v133) => { (v131.as_ref()).clone() } })))) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v134) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(((((((match v130 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v135,v136,v137) => { *v136 } }).wrapping_mul(2u64)) & (4294967295u64))).wrapping_add(1u64)) & (4294967295u64)))) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v138) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0((((*v138).wrapping_add(1u64)) & (4294967295u64)))) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v139) => { match &(D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v130 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v140,v141,v142) => { (v140.as_ref()).clone() } }),*v138)) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(0u64,4294967295u64) },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v144) => { (v144.as_ref()).clone() } }))) { D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(v145) => { match &(D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v130 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v146,v147,v148) => { (v146.as_ref()).clone() } }),*v139)) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(0u64,4294967295u64) },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v150) => { (v150.as_ref()).clone() } }))) { D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(v151) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(if if ((*v139) < (*v134)) { d_9d672de3566f4e7ec38116f403ea277b7973fb397b44426e3ee7adf21bcd723f(v151.as_ref(),v145.as_ref()) } else { false } { *v139 } else { *v138 })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v152) => { match &(D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v130 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v153,v154,v155) => { (v153.as_ref()).clone() } }),*v152)) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(0u64,4294967295u64) },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v157) => { (v157.as_ref()).clone() } }))) { D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(v158) => { match &(D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v130 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v159,v160,v161) => { (v159.as_ref()).clone() } }),match v130 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v162,v163,v164) => { *v163 } })) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(0u64,0u64) },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v166) => { (v166.as_ref()).clone() } }))) { D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(v167) => { if if ((*v152) < (*v134)) { d_9d672de3566f4e7ec38116f403ea277b7973fb397b44426e3ee7adf21bcd723f(v158.as_ref(),v167.as_ref()) } else { false } { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v130 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v168,v169,v170) => { (v168.as_ref()).clone() } }),match v130 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v171,v172,v173) => { *v172 } })) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { match v130 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v174,v175,v176) => { (v174.as_ref()).clone() } } },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v177) => { match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v130 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v178,v179,v180) => { (v178.as_ref()).clone() } }),*v152)) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { match v130 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v181,v182,v183) => { (v181.as_ref()).clone() } } },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v184) => { d_b10f15633b5bbc9018929e4e8d67975c090e74e014a600622b2f569ce4917ba5(&(d_b10f15633b5bbc9018929e4e8d67975c090e74e014a600622b2f569ce4917ba5(&(match v130 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v185,v186,v187) => { (v185.as_ref()).clone() } }),match v130 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v188,v189,v190) => { *v189 } },v184.as_ref())),*v152,v177.as_ref()) } } } }),*v152,false) } else { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(std::sync::Arc::new(match v130 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v191,v192,v193) => { (v191.as_ref()).clone() } }),match v130 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v194,v195,v196) => { *v195 } },true) } } } } } } } } } } } } } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_4d68fd2c2ea116d87e7a4a150162c04ff1404fbc0d420ef69cf909b470f7e4a8 { C0(std::sync::Arc<D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_4e61cd2054b66259fa5fe6ff2848621d519f896c6b83b26615faed118e66c0c8 { C0 }
impl D_4e61cd2054b66259fa5fe6ff2848621d519f896c6b83b26615faed118e66c0c8{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_4e61cd2054b66259fa5fe6ff2848621d519f896c6b83b26615faed118e66c0c8{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_4e83072d158179b64b40df7986493710bb1d27812bc6ecdf11bb0c4a74d8c70d(v197: u64,v198: u64) -> u64 { if ((v197) > (v198)) { (((v197).wrapping_sub(v198)) & (4294967295u64)) } else { (((v198).wrapping_sub(v197)) & (4294967295u64)) } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243 { C0(std::sync::Arc<D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39>) }
fn d_54115d4ead942305e035cdfe49d61b727e56192d969e831e8b6c754a1c65c6f2(v199: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v200: u64,v201: u64,v202: u64,v203: u64) -> D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd { match &(D_7eea704e7e77d46b1d984e9cab6f33b597cec0eda67bef640bae88b296cdd277::C0(std::sync::Arc::clone({static v204:std::sync::OnceLock<std::sync::Arc<D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd>>=std::sync::OnceLock::new();v204.get_or_init(||std::sync::Arc::new(D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C0))}))) { D_7eea704e7e77d46b1d984e9cab6f33b597cec0eda67bef640bae88b296cdd277::C0(v206) => { match &(D_e76d71eacc94ee97e8a1a02d9b0750885675867ac52f6e28927a98226058c5ad::C0(std::sync::Arc::clone({static v207:std::sync::OnceLock<std::sync::Arc<D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871>>=std::sync::OnceLock::new();v207.get_or_init(||std::sync::Arc::new(D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0))}))) { D_e76d71eacc94ee97e8a1a02d9b0750885675867ac52f6e28927a98226058c5ad::C0(v209) => { match &(D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(std::sync::Arc::new(D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(std::sync::Arc::new((v199).clone()),std::sync::Arc::new(d_bf6aba90e46dc72ddc2215d097cea1f2923a96c4e3f4a35f12925a49df054182(v209.as_ref(),&(D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v201,d_9bb3ec8899fbd786e3a9c9196168dd3cb0314e9fe3d22b3d85e09e94d3dbe5cf(v201,v202,v200))))),std::sync::Arc::new(if d_002fa87dc14fb22703d067bc5256bb42a441ff9bc957fdd023ea162e558462ba(v206.as_ref(),v201) { d_5fe9167aff6b3b37e3ca66b5143100bd012f34939a1767db0e227ef4ac5bdb15(v206.as_ref(),v201,0u64) } else { d_10474bbc4ac74580f8be4e0fa212cee2c299d6988c03e31fe5089407d8cf0f2a(v206.as_ref(),v201,0u64) }),std::sync::Arc::clone({static v210:std::sync::OnceLock<std::sync::Arc<D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b>>=std::sync::OnceLock::new();v210.get_or_init(||std::sync::Arc::new(D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C0))}),std::sync::Arc::clone({static v211:std::sync::OnceLock<std::sync::Arc<D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd>>=std::sync::OnceLock::new();v211.get_or_init(||std::sync::Arc::new(D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C0))}),v200,v202,false,0u64,0u64)))) { D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(v212) => { match &(D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(std::sync::Arc::new(d_233173ac9b19280e2ca75fd60b2c1eec94767f63b49507f3b5639702c686f8aa(&(d_1338047bd9cf52a17a4e86ffc009b659e90ff924cb48778cbcac39b169b0bbeb(&(if ((v203) == (0u64)) { D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301::C0 } else { D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301::C1(v203) }))),v203,0u64,v212.as_ref())))) { D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(v214) => { d_9a6e77e0c0848f8c788a82eb6f3bec58f935fe6ed1104a61bbc9a86d40fd32fc(v214.as_ref(),v201) } } } } } } } } }
fn d_5505e7ee68449c43569a7ea9f8556dc190dcb184ac4512d57d25866601499382(v215: &D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b,v216: u64,v217: bool) -> D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b { match v215 { D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C0 => { D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C1(v216,v217,std::sync::Arc::clone({static v218:std::sync::OnceLock<std::sync::Arc<D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b>>=std::sync::OnceLock::new();v218.get_or_init(||std::sync::Arc::new(D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C0))})) },D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C1(v219,v220,v221) => { if ((v216) < (*v219)) { D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C1(v216,v217,std::sync::Arc::new((v215).clone())) } else { D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C1(*v219,*v220,std::sync::Arc::new(d_5505e7ee68449c43569a7ea9f8556dc190dcb184ac4512d57d25866601499382(v221.as_ref(),v216,v217))) } } } }
fn d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(v222: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8) -> u64 { match v222 { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 => { 0u64 },D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v223,v224) => { (((1u64).wrapping_add(d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(v224.as_ref()))) & (4294967295u64)) } } }
fn d_599d0232d36959692a62209d86c61353da0eb94a68384f34652c80554a65fc29(v225: &D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39) -> D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39 { match &(D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v225 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v226,v227,v228,v229,v230,v231,v232,v233,v234,v235) => { (v227.as_ref()).clone() } }),0u64)) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(0u64,0u64) },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v237) => { (v237.as_ref()).clone() } }))) { D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(v238) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(match v238.as_ref() { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v239,v240) => { *v239 } })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v241) => { match &(D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793::C0(d_675b1f4f897dbd6222dcc1a7905d41455272640b09efc4dda13c18702b3a72fd(&(match v225 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v242,v243,v244,v245,v246,v247,v248,v249,v250,v251) => { (v245.as_ref()).clone() } }),*v241))) { D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793::C0(v252) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(match &(d_8f49b0501dc5088b5b1fbb496bf7a43da0fc57cc982a3223cec950add0d80d8c(&(match v225 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v253,v254,v255,v256,v257,v258,v259,v260,v261,v262) => { (v255.as_ref()).clone() } }),*v241)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { 4294967295u64 },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v263) => { *v263 } })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v264) => { match &(D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(std::sync::Arc::new(D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(std::sync::Arc::new(match v225 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v265,v266,v267,v268,v269,v270,v271,v272,v273,v274) => { (v265.as_ref()).clone() } }),std::sync::Arc::new(d_883f464dad297c3ddf9b7e7cc33f90e47db3149f94ef0b14616a1c251e57cec7(&(match v225 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v275,v276,v277,v278,v279,v280,v281,v282,v283,v284) => { (v276.as_ref()).clone() } }))),std::sync::Arc::new(match v225 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v285,v286,v287,v288,v289,v290,v291,v292,v293,v294) => { (v287.as_ref()).clone() } }),std::sync::Arc::new(match v225 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v295,v296,v297,v298,v299,v300,v301,v302,v303,v304) => { (v298.as_ref()).clone() } }),std::sync::Arc::new(match v225 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v305,v306,v307,v308,v309,v310,v311,v312,v313,v314) => { (v309.as_ref()).clone() } }),match v225 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v315,v316,v317,v318,v319,v320,v321,v322,v323,v324) => { *v320 } },match v225 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v325,v326,v327,v328,v329,v330,v331,v332,v333,v334) => { *v331 } },((*v241) == (match v225 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v335,v336,v337,v338,v339,v340,v341,v342,v343,v344) => { *v341 } })),*v264,match v225 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v345,v346,v347,v348,v349,v350,v351,v352,v353,v354) => { *v354 } })))) { D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(v355) => { if if match v355.as_ref() { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v356,v357,v358,v359,v360,v361,v362,v363,v364,v365) => { *v363 } } { true } else { *v252 } { (v355.as_ref()).clone() } else { d_d82e40118f53bdfbefb5f85df702d7fa8fcacca63882a42262bfa5158e3ffe5f(v355.as_ref(),*v241) } } } } } } } } } } } }
fn d_5d52ea5a8e356f04093cac1a6710051c7c2d51db1cd9d2dfd20c3fd5caf5fb77(v366: &D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462,v367: u64) -> bool { match &(d_201e280f19da197f80aaeeb90891c2afb639627134c77648eaa04371e3b5cdd6(v366,v367)) { D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C0 => { false },D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C1(v368) => { true } } }
fn d_5fe9167aff6b3b37e3ca66b5143100bd012f34939a1767db0e227ef4ac5bdb15(v369: &D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd,v370: u64,v371: u64) -> D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd { match v369 { D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C0 => { D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C0 },D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C1(v373,v374,v375) => { D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C1(*v373,if ((v370) == (*v373)) { v371 } else { *v374 },std::sync::Arc::new(d_5fe9167aff6b3b37e3ca66b5143100bd012f34939a1767db0e227ef4ac5bdb15(v375.as_ref(),v370,v371))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_629702fff8bf26d1700c51e6d59e94b0faf5093d8d3e8cb0a184b7ac9f3f084a { C0(std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd { C0(bool,u64,u64,bool,std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>) }
fn d_6649fc617a1900b0cbc850819ce59715f07f3eb0bd93bb294005bf337538adeb(v376: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8) -> D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8 { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(v376))) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v377) => { match &(D_629702fff8bf26d1700c51e6d59e94b0faf5093d8d3e8cb0a184b7ac9f3f084a::C0(std::sync::Arc::new(d_f23e5e1ef33767cf923369310c51eeb75173bed11e5d3e4d87c4354e4e2aac2a(&(d_1338047bd9cf52a17a4e86ffc009b659e90ff924cb48778cbcac39b169b0bbeb(&(if ((if ((2u64) == (0u64)) { 0u64 } else { (*v377).checked_div(2u64).unwrap_or(0) }) == (0u64)) { D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301::C0 } else { D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301::C1(if ((2u64) == (0u64)) { 0u64 } else { (*v377).checked_div(2u64).unwrap_or(0) }) }))),if ((2u64) == (0u64)) { 0u64 } else { (*v377).checked_div(2u64).unwrap_or(0) },0u64,v376,*v377)))) { D_629702fff8bf26d1700c51e6d59e94b0faf5093d8d3e8cb0a184b7ac9f3f084a::C0(v379) => { (v379.as_ref()).clone() } } } } }
fn d_675b1f4f897dbd6222dcc1a7905d41455272640b09efc4dda13c18702b3a72fd(v380: &D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b,v381: u64) -> bool { match &(d_03ff34b5386d1e23ed93a530286dcfa18b3c56053b5eabeb72372c1a2a11723b(v380,v381)) { D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea::C0 => { false },D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea::C1(v382) => { true } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd { C0,C1(u64,u64,std::sync::Arc<D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd>) }
impl D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_6b63cf5afc61090ec31102a63c1b59b4f108d50a99efcdc94e1504146dfea6ed(v383: &D_8cd109016fb88165d696167165db16dd2341ce7ca00316b445b4798973b64c2f) -> D_2039380a191f87da8dbfd810ad313b62244825a051b4c0c3de52b6715baca512 { match v383 { D_8cd109016fb88165d696167165db16dd2341ce7ca00316b445b4798973b64c2f::C0(v384,v385) => { (v385.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d { C0,C1(std::sync::Arc<D_4e61cd2054b66259fa5fe6ff2848621d519f896c6b83b26615faed118e66c0c8>,std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>) }
impl D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_71b03b379e93896fd4cd5fe78abc55e3eab05402dfa2a7c0412027448b40ccfe(v386: &D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4,v387: u64) -> D_2039380a191f87da8dbfd810ad313b62244825a051b4c0c3de52b6715baca512 { D_2039380a191f87da8dbfd810ad313b62244825a051b4c0c3de52b6715baca512::C0(std::sync::Arc::new(match &(d_201e280f19da197f80aaeeb90891c2afb639627134c77648eaa04371e3b5cdd6(&(match v386 { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v388) => { (v388.as_ref()).clone() } }),0u64)) { D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C0 => { D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60::C0 },D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C1(v390) => { D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60::C1(std::sync::Arc::new(d_b49a17a751300394c261cc3b13d02c5f86514ef9f076c31c61a9a4ad1121d77f(&(match v390.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v391,v392,v393,v394,v395) => { (v391.as_ref()).clone() } }),match v390.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v396,v397,v398,v399,v400) => { *v397 } },match v390.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v401,v402,v403,v404,v405) => { *v403 } },match v390.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v406,v407,v408,v409,v410) => { *v409 } },match v390.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v411,v412,v413,v414,v415) => { *v415 } }))) } }),false,v387,std::sync::Arc::new((v386).clone()),std::sync::Arc::clone({static v416:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v416.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9 { C0,C1(bool,std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>) }
impl D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9 { C0(std::sync::Arc<D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd>,bool,u64,std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>,std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>),C1(u64,u64,std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_7eea704e7e77d46b1d984e9cab6f33b597cec0eda67bef640bae88b296cdd277 { C0(std::sync::Arc<D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69 { C0(std::sync::Arc<D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd>,std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>,u64,bool) }
fn d_883f464dad297c3ddf9b7e7cc33f90e47db3149f94ef0b14616a1c251e57cec7(v417: &D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871) -> D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871 { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(v417))) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v418) => { match &(D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(v417,(((*v418).wrapping_sub(1u64)) & (4294967295u64)))) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(0u64,0u64) },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v420) => { (v420.as_ref()).clone() } }))) { D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(v421) => { match &(D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(std::sync::Arc::new(D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(std::sync::Arc::new(d_c179b870391b842b9ab4fa27a89d903e157ec50d1aedf6dfdf82e22cd01ddf08(&(d_b10f15633b5bbc9018929e4e8d67975c090e74e014a600622b2f569ce4917ba5(v417,0u64,v421.as_ref())))),0u64,false)))) { D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(v422) => { match &(D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(std::sync::Arc::new(d_9922a5adf6482aba8c1c067bc95e952df2f0347f2ea5aec7895a4f08b21f8e6d(&(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v428:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v428.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v427:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v427.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v426:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v426.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v425:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v425.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v424:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v424.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(true,std::sync::Arc::clone({static v423:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v423.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0))}))))}))))}))))}))))}))))}))),32u64,0u64,v422.as_ref())))) { D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(v430) => { match v430.as_ref() { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v431,v432,v433) => { (v431.as_ref()).clone() } } } } } } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_8cd109016fb88165d696167165db16dd2341ce7ca00316b445b4798973b64c2f { C0(std::sync::Arc<D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f>,std::sync::Arc<D_2039380a191f87da8dbfd810ad313b62244825a051b4c0c3de52b6715baca512>) }
fn d_8f49b0501dc5088b5b1fbb496bf7a43da0fc57cc982a3223cec950add0d80d8c(v434: &D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd,v435: u64) -> D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531 { match v434 { D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C0 => { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 },D_6a86152ebae714830a28f70ff0c691aba6740ed78c1403472852bac06cd706fd::C1(v437,v438,v439) => { if ((v435) == (*v437)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(*v438) } else { d_8f49b0501dc5088b5b1fbb496bf7a43da0fc57cc982a3223cec950add0d80d8c(v439.as_ref(),v435) } } } }
fn d_8f8f9cf94b421df1993f5b3088dbaeb4cdbf8902174eb4cc7e959206aeb63d80(v440: &D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f) -> D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4 { match v440 { D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f::C0(v441) => { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::clone(v441)) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6 { C0,C1(std::sync::Arc<D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f>) }
fn d_97618c4256a7c56a75c81c31e9035ca5a06eda577813ce92e9afb84b0dfb79e6(v442: &D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b,v443: u64,v444: bool) -> D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b { match v442 { D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C0 => { D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C0 },D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C1(v446,v447,v448) => { D_2bb518afa8c0418d27fab697c257a178cf91ada4eff6dd7df327b742fc1d4c9b::C1(*v446,if ((v443) == (*v446)) { v444 } else { *v447 },std::sync::Arc::new(d_97618c4256a7c56a75c81c31e9035ca5a06eda577813ce92e9afb84b0dfb79e6(v448.as_ref(),v443,v444))) } } }
fn d_9810c261dad317f7b06b890c118ad27801055f9efb8eebb59483c8572acec798(v449: &D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d) -> D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(if ((2u64) == (0u64)) { 0u64 } else { ((((match v449 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v450,v451,v452) => { *v451 } }).wrapping_sub(1u64)) & (4294967295u64))).checked_div(2u64).unwrap_or(0) })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v453) => { match &(D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v449 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v454,v455,v456) => { (v454.as_ref()).clone() } }),match v449 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v457,v458,v459) => { *v458 } })) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(0u64,0u64) },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v461) => { (v461.as_ref()).clone() } }))) { D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(v462) => { match &(D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v449 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v463,v464,v465) => { (v463.as_ref()).clone() } }),*v453)) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(0u64,0u64) },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v467) => { (v467.as_ref()).clone() } }))) { D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa::C0(v468) => { if d_9d672de3566f4e7ec38116f403ea277b7973fb397b44426e3ee7adf21bcd723f(v462.as_ref(),v468.as_ref()) { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(std::sync::Arc::new(match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v449 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v469,v470,v471) => { (v469.as_ref()).clone() } }),match v449 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v472,v473,v474) => { *v473 } })) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { match v449 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v475,v476,v477) => { (v475.as_ref()).clone() } } },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v478) => { match &(d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(&(match v449 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v479,v480,v481) => { (v479.as_ref()).clone() } }),*v453)) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 => { match v449 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v482,v483,v484) => { (v482.as_ref()).clone() } } },D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(v485) => { d_b10f15633b5bbc9018929e4e8d67975c090e74e014a600622b2f569ce4917ba5(&(d_b10f15633b5bbc9018929e4e8d67975c090e74e014a600622b2f569ce4917ba5(&(match v449 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v486,v487,v488) => { (v486.as_ref()).clone() } }),match v449 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v489,v490,v491) => { *v490 } },v485.as_ref())),*v453,v478.as_ref()) } } } }),*v453,false) } else { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(std::sync::Arc::new(match v449 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v492,v493,v494) => { (v492.as_ref()).clone() } }),match v449 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v495,v496,v497) => { *v496 } },true) } } } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af { C0(u64) }
fn d_9922a5adf6482aba8c1c067bc95e952df2f0347f2ea5aec7895a4f08b21f8e6d(v498: &D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9,v499: u64,v500: u64,v501: &D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d) -> D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d { if if ((v499) == (0u64)) { true } else { if match v501 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v502,v503,v504) => { *v504 } } { true } else { ((d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(&(match v501 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v505,v506,v507) => { (v505.as_ref()).clone() } }))) == (0u64)) } } { (v501).clone() } else { match v498 { D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0 => { (v501).clone() },D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(v508,v509) => { if *v508 { match &(D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(std::sync::Arc::new(d_9922a5adf6482aba8c1c067bc95e952df2f0347f2ea5aec7895a4f08b21f8e6d(v509.as_ref(),(v499).checked_div(2u64).unwrap_or(0),(((v500).wrapping_add((v499).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_9922a5adf6482aba8c1c067bc95e952df2f0347f2ea5aec7895a4f08b21f8e6d(v509.as_ref(),(v499).checked_div(2u64).unwrap_or(0),v500,v501)))))) { D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(v510) => { if if match v510.as_ref() { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v511,v512,v513) => { *v513 } } { true } else { ((d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(&(match v510.as_ref() { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v514,v515,v516) => { (v514.as_ref()).clone() } }))) == (0u64)) } { (v510.as_ref()).clone() } else { d_4662356d4b7aebe6e74645c080deab29c301ad4662c930b428d106d4173c856a(v510.as_ref()) } } } } else { d_9922a5adf6482aba8c1c067bc95e952df2f0347f2ea5aec7895a4f08b21f8e6d(v509.as_ref(),(v499).checked_div(2u64).unwrap_or(0),(((v500).wrapping_add((v499).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_9922a5adf6482aba8c1c067bc95e952df2f0347f2ea5aec7895a4f08b21f8e6d(v509.as_ref(),(v499).checked_div(2u64).unwrap_or(0),v500,v501))) } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_99a2efcc518203247df119c7b128306a3b58dcaf0364ffc53a69de71953425fa { C0(std::sync::Arc<D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f>) }
fn d_9a6e77e0c0848f8c788a82eb6f3bec58f935fe6ed1104a61bbc9a86d40fd32fc(v517: &D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39,v518: u64) -> D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd { match &(D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793::C0(if ((match v517 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v519,v520,v521,v522,v523,v524,v525,v526,v527,v528) => { *v526 } }) == (false)) { ((d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(&(match v517 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v529,v530,v531,v532,v533,v534,v535,v536,v537,v538) => { (v530.as_ref()).clone() } }))) > (0u64)) } else { false })) { D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793::C0(v539) => { match &(D_4d68fd2c2ea116d87e7a4a150162c04ff1404fbc0d420ef69cf909b470f7e4a8::C0(std::sync::Arc::new(D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(std::sync::Arc::new(match v517 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v540,v541,v542,v543,v544,v545,v546,v547,v548,v549) => { (v544.as_ref()).clone() } }),std::sync::Arc::clone({static v550:std::sync::OnceLock<std::sync::Arc<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8>>=std::sync::OnceLock::new();v550.get_or_init(||std::sync::Arc::new(D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0))}),match v517 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v551,v552,v553,v554,v555,v556,v557,v558,v559,v560) => { *v557 } },((match v517 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v561,v562,v563,v564,v565,v566,v567,v568,v569,v570) => { *v568 } }) == (false)))))) { D_4d68fd2c2ea116d87e7a4a150162c04ff1404fbc0d420ef69cf909b470f7e4a8::C0(v571) => { match &(D_4d68fd2c2ea116d87e7a4a150162c04ff1404fbc0d420ef69cf909b470f7e4a8::C0(std::sync::Arc::new(d_fa8e70b6c7edb6eeac653ac7e50a93414822a4c906b31b18ff715fb31e358a61(&(d_1338047bd9cf52a17a4e86ffc009b659e90ff924cb48778cbcac39b169b0bbeb(&(if ((d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(&(match v517 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v572,v573,v574,v575,v576,v577,v578,v579,v580,v581) => { (v572.as_ref()).clone() } }))) == (0u64)) { D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301::C0 } else { D_32010337428015e0476401985a6a574e15a6c34205b7cabe4251162019d1d301::C1(d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(&(match v517 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v583,v584,v585,v586,v587,v588,v589,v590,v591,v592) => { (v583.as_ref()).clone() } }))) }))),d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(&(match v517 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v593,v594,v595,v596,v597,v598,v599,v600,v601,v602) => { (v593.as_ref()).clone() } })),0u64,v571.as_ref(),v518)))) { D_4d68fd2c2ea116d87e7a4a150162c04ff1404fbc0d420ef69cf909b470f7e4a8::C0(v603) => { D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd::C0(match v517 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v604,v605,v606,v607,v608,v609,v610,v611,v612,v613) => { *v611 } },match v517 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v614,v615,v616,v617,v618,v619,v620,v621,v622,v623) => { *v622 } },match v517 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v624,v625,v626,v627,v628,v629,v630,v631,v632,v633) => { *v633 } },*v539,std::sync::Arc::new(d_6649fc617a1900b0cbc850819ce59715f07f3eb0bd93bb294005bf337538adeb(&(match v603.as_ref() { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v634,v635,v636,v637) => { (v635.as_ref()).clone() } })))) } } } } } } }
fn d_9bb3ec8899fbd786e3a9c9196168dd3cb0314e9fe3d22b3d85e09e94d3dbe5cf(v638: u64,v639: u64,v640: u64) -> u64 { (((d_4e83072d158179b64b40df7986493710bb1d27812bc6ecdf11bb0c4a74d8c70d(if ((v640) == (0u64)) { 0u64 } else { (v638).checked_rem(v640).unwrap_or(0) },if ((v640) == (0u64)) { 0u64 } else { (v639).checked_rem(v640).unwrap_or(0) })).wrapping_add(d_4e83072d158179b64b40df7986493710bb1d27812bc6ecdf11bb0c4a74d8c70d(if ((v640) == (0u64)) { 0u64 } else { (v638).checked_div(v640).unwrap_or(0) },if ((v640) == (0u64)) { 0u64 } else { (v639).checked_div(v640).unwrap_or(0) }))) & (4294967295u64)) }
fn d_9c3da9d34ec75222a22280aa83e3722a77986d6ed420dfb227c213c230e89897(v641: &D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4,v642: u64,v643: u64,v644: bool) -> D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9 { match &(D_ed742c79021c129a74c485de3fde12f113f9e1f62fcdff87129f05a60f244981::C0(std::sync::Arc::new(match v641 { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v645) => { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::new(d_cf1230bd75cb8423314de8b7d3f4d503a062de575d48e96f3c36c0da9dcc1bce(&(match v641 { D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(v646) => { (v646.as_ref()).clone() } }),v643))) } }))) { D_ed742c79021c129a74c485de3fde12f113f9e1f62fcdff87129f05a60f244981::C0(v647) => { if v644 { match &(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(true)) { D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(v649) => { if ((v642) == (18446744073709551615u64)) { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(1u64,v642,std::sync::Arc::new((v641).clone())) } else { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(std::sync::Arc::new(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(std::sync::Arc::clone(v649))),true,(v642).wrapping_add(1u64),std::sync::Arc::clone(v647),std::sync::Arc::clone({static v650:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v650.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) } },D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(v651) => { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(std::sync::Arc::new(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(*v651)),false,v642,std::sync::Arc::new((v641).clone()),std::sync::Arc::clone({static v652:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v652.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) } } } else { match &(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(std::sync::Arc::clone({static v653:std::sync::OnceLock<std::sync::Arc<D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7>>=std::sync::OnceLock::new();v653.get_or_init(||std::sync::Arc::new(D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7::C0))}))) { D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(v655) => { if ((v642) == (18446744073709551615u64)) { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(1u64,v642,std::sync::Arc::new((v641).clone())) } else { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(std::sync::Arc::new(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(std::sync::Arc::clone(v655))),true,(v642).wrapping_add(1u64),std::sync::Arc::clone(v647),std::sync::Arc::clone({static v656:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v656.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) } },D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(v657) => { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(std::sync::Arc::new(D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(*v657)),false,v642,std::sync::Arc::new((v641).clone()),std::sync::Arc::clone({static v658:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v658.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})) } } } } } }
fn d_9d672de3566f4e7ec38116f403ea277b7973fb397b44426e3ee7adf21bcd723f(v659: &D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f,v660: &D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f) -> bool { if ((match v659 { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v661,v662) => { *v662 } }) < (match v660 { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v663,v664) => { *v664 } })) { true } else { if ((match v659 { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v665,v666) => { *v666 } }) == (match v660 { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v667,v668) => { *v668 } })) { ((match v659 { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v669,v670) => { *v669 } }) < (match v660 { D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v671,v672) => { *v671 } })) } else { false } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9 { C0(std::sync::Arc<D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f { C0(std::sync::Arc<D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462>) }
fn d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(v673: &D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871,v674: u64) -> D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6 { match v673 { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 => { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0 },D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(v676,v677) => { if ((v674) == (0u64)) { D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(std::sync::Arc::clone(v676)) } else { d_a9414e3cb01b123b61446d43b4715b52ee97aa2bb7c39c0395242c84c2d1ffa0(v677.as_ref(),(((v674).wrapping_sub(1u64)) & (4294967295u64))) } } } }
fn d_b0495dc3a518a6f02848318dcbb318a833d40709e5d01598ece43f47bc462e33(v678: &D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f,v679: u64,v680: u64,v681: bool) -> D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9 { d_9c3da9d34ec75222a22280aa83e3722a77986d6ed420dfb227c213c230e89897(&(d_8f8f9cf94b421df1993f5b3088dbaeb4cdbf8902174eb4cc7e959206aeb63d80(v678)),v679,v680,v681) }
fn d_b10f15633b5bbc9018929e4e8d67975c090e74e014a600622b2f569ce4917ba5(v682: &D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871,v683: u64,v684: &D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f) -> D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871 { match v682 { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 => { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 },D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(v686,v687) => { if ((v683) == (0u64)) { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(std::sync::Arc::new((v684).clone()),std::sync::Arc::clone(v687)) } else { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(std::sync::Arc::clone(v686),std::sync::Arc::new(d_b10f15633b5bbc9018929e4e8d67975c090e74e014a600622b2f569ce4917ba5(v687.as_ref(),(((v683).wrapping_sub(1u64)) & (4294967295u64)),v684))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f { C0(u64,u64) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4 { C0(std::sync::Arc<D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462>) }
fn d_b49a17a751300394c261cc3b13d02c5f86514ef9f076c31c61a9a4ad1121d77f(v688: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v689: u64,v690: u64,v691: u64,v692: u64) -> D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd { match &(D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793::C0(if if if if if if ((v689) > (0u64)) { ((d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(v688)) > (0u64)) } else { false } { ((if ((v689) == (0u64)) { 1u64 } else { (d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(v688)).checked_rem(v689).unwrap_or(0) }) == (0u64)) } else { false } { ((v690) < (d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(v688))) } else { false } { ((v691) < (d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(v688))) } else { false } { ((match &(d_3ec78a35272ed91061dacb8c052a158f10da108f6d53693c7b0661117c1a477a(v688,v690)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { 1u64 },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v693) => { *v693 } }) == (0u64)) } else { false } { ((match &(d_3ec78a35272ed91061dacb8c052a158f10da108f6d53693c7b0661117c1a477a(v688,v691)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { 1u64 },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v694) => { *v694 } }) == (0u64)) } else { false })) { D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793::C0(v695) => { if *v695 { d_54115d4ead942305e035cdfe49d61b727e56192d969e831e8b6c754a1c65c6f2(v688,v689,v690,v691,v692) } else { D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd::C0(false,0u64,0u64,false,std::sync::Arc::new(d_2b69c64cbe72e93b1b88f554091ce5857248e729631172c1b5518c2642c807f2(v688))) } } } }
fn d_bbd5ed7008af8380acd37020844e9c2db02554d2a7eb796bc069d4b765a1a27e(v696: &D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9) -> D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f { d_3d49fac84fd706ca4d2bddc3c53e21f9c8d82e8a70ee8b81def02800d29a11f7(&(match v696 { D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(v697,v698,v699,v700,v701) => { (v700.as_ref()).clone() },D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(v702,v703,v704) => { (v704.as_ref()).clone() } })) }
fn d_bf6aba90e46dc72ddc2215d097cea1f2923a96c4e3f4a35f12925a49df054182(v705: &D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871,v706: &D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f) -> D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871 { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(v705))) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v707) => { match &(D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(std::sync::Arc::new(D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(std::sync::Arc::new(d_c846feedade08b7e208a1ef904f8d843db007f1b3e3a3ef6af35a8b81ad87676(v705,v706)),*v707,false)))) { D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(v708) => { match &(D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(std::sync::Arc::new(d_f27de552516fbc855a6704e6cb1adf85ea68f335192ed7a6481f821689b356ad(&(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v714:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v714.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v713:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v713.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v712:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v712.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v711:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v711.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(false,std::sync::Arc::clone({static v710:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v710.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(true,std::sync::Arc::clone({static v709:std::sync::OnceLock<std::sync::Arc<D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9>>=std::sync::OnceLock::new();v709.get_or_init(||std::sync::Arc::new(D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0))}))))}))))}))))}))))}))))}))),32u64,0u64,v708.as_ref())))) { D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(v716) => { match v716.as_ref() { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v717,v718,v719) => { (v717.as_ref()).clone() } } } } } } } } }
fn d_c179b870391b842b9ab4fa27a89d903e157ec50d1aedf6dfdf82e22cd01ddf08(v720: &D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871) -> D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871 { match v720 { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 => { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 },D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(v722,v723) => { match v723.as_ref() { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 => { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 },D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(v725,v726) => { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(std::sync::Arc::clone(v722),std::sync::Arc::new(d_c179b870391b842b9ab4fa27a89d903e157ec50d1aedf6dfdf82e22cd01ddf08(v723.as_ref()))) } } } } }
fn d_c27382cc26c2f2d698bb22075c8a32db4b69b31a5b94ff0ab658949e35b639e5(v727: &D_fdf257bc2584502163667d3ea4dbd18025f65af51919f5dc5f35439fd24e1fef) -> D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f { match v727 { D_fdf257bc2584502163667d3ea4dbd18025f65af51919f5dc5f35439fd24e1fef::C0(v728,v729) => { (v728.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_c4723b47c6e1d6bbaad257312e3775ae8ebc3ada669ec51045f34d4aefe99a68 { C0(std::sync::Arc<D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2>,bool,u64,std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>,std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>),C1(u64,u64,std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462 { C0,C1(u64,std::sync::Arc<D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c>,std::sync::Arc<D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462>) }
impl D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_c846feedade08b7e208a1ef904f8d843db007f1b3e3a3ef6af35a8b81ad87676(v730: &D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871,v731: &D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f) -> D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871 { match v730 { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 => { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(std::sync::Arc::new((v731).clone()),std::sync::Arc::clone({static v732:std::sync::OnceLock<std::sync::Arc<D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871>>=std::sync::OnceLock::new();v732.get_or_init(||std::sync::Arc::new(D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0))})) },D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(v733,v734) => { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(std::sync::Arc::clone(v733),std::sync::Arc::new(d_c846feedade08b7e208a1ef904f8d843db007f1b3e3a3ef6af35a8b81ad87676(v734.as_ref(),v731))) } } }
fn d_c9ae8314360fd86b1545c14505dc08313b35ba9b057fa47da87c0631868a13b5(v735: &D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9) -> D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9 { (v735).clone() }
fn d_cf1230bd75cb8423314de8b7d3f4d503a062de575d48e96f3c36c0da9dcc1bce(v736: &D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462,v737: u64) -> D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462 { match v736 { D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0 => { D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0 },D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(v739,v740,v741) => { if ((v737) == (*v739)) { d_cf1230bd75cb8423314de8b7d3f4d503a062de575d48e96f3c36c0da9dcc1bce(v741.as_ref(),v737) } else { D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(*v739,std::sync::Arc::clone(v740),std::sync::Arc::new(d_cf1230bd75cb8423314de8b7d3f4d503a062de575d48e96f3c36c0da9dcc1bce(v741.as_ref(),v737))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea { C0,C1(bool) }
fn d_d82e40118f53bdfbefb5f85df702d7fa8fcacca63882a42262bfa5158e3ffe5f(v742: &D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39,v743: u64) -> D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39 { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(d_5698b240635cf9b67979d677328a35644584eddfde74b9e43ebe3af9af10e81a(&(match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v744,v745,v746,v747,v748,v749,v750,v751,v752,v753) => { (v744.as_ref()).clone() } })))) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v754) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(if ((match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v755,v756,v757,v758,v759,v760,v761,v762,v763,v764) => { *v760 } }) == (0u64)) { 0u64 } else { (v743).checked_rem(match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v765,v766,v767,v768,v769,v770,v771,v772,v773,v774) => { *v770 } }).unwrap_or(0) })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v775) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(if ((*v775) > (0u64)) { (((v743).wrapping_sub(1u64)) & (4294967295u64)) } else { v743 })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v776) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(if if (((((*v775).wrapping_add(1u64)) & (4294967295u64))) < (match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v777,v778,v779,v780,v781,v782,v783,v784,v785,v786) => { *v782 } })) { (((((v743).wrapping_add(1u64)) & (4294967295u64))) < (*v754)) } else { false } { (((v743).wrapping_add(1u64)) & (4294967295u64)) } else { v743 })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v787) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(if ((v743) >= (match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v788,v789,v790,v791,v792,v793,v794,v795,v796,v797) => { *v793 } })) { (((v743).wrapping_sub(match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v798,v799,v800,v801,v802,v803,v804,v805,v806,v807) => { *v803 } })) & (4294967295u64)) } else { v743 })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v808) => { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(if (((((v743).wrapping_add(match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v809,v810,v811,v812,v813,v814,v815,v816,v817,v818) => { *v814 } })) & (4294967295u64))) < (*v754)) { (((v743).wrapping_add(match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v819,v820,v821,v822,v823,v824,v825,v826,v827,v828) => { *v824 } })) & (4294967295u64)) } else { v743 })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v829) => { match &(D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(std::sync::Arc::new(D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(std::sync::Arc::new(match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v830,v831,v832,v833,v834,v835,v836,v837,v838,v839) => { (v830.as_ref()).clone() } }),std::sync::Arc::new(match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v840,v841,v842,v843,v844,v845,v846,v847,v848,v849) => { (v841.as_ref()).clone() } }),std::sync::Arc::new(match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v850,v851,v852,v853,v854,v855,v856,v857,v858,v859) => { (v852.as_ref()).clone() } }),std::sync::Arc::new(if d_675b1f4f897dbd6222dcc1a7905d41455272640b09efc4dda13c18702b3a72fd(&(match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v860,v861,v862,v863,v864,v865,v866,v867,v868,v869) => { (v863.as_ref()).clone() } }),v743) { d_97618c4256a7c56a75c81c31e9035ca5a06eda577813ce92e9afb84b0dfb79e6(&(match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v870,v871,v872,v873,v874,v875,v876,v877,v878,v879) => { (v873.as_ref()).clone() } }),v743,true) } else { d_5505e7ee68449c43569a7ea9f8556dc190dcb184ac4512d57d25866601499382(&(match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v880,v881,v882,v883,v884,v885,v886,v887,v888,v889) => { (v883.as_ref()).clone() } }),v743,true) }),std::sync::Arc::new(match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v890,v891,v892,v893,v894,v895,v896,v897,v898,v899) => { (v894.as_ref()).clone() } }),match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v900,v901,v902,v903,v904,v905,v906,v907,v908,v909) => { *v905 } },match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v910,v911,v912,v913,v914,v915,v916,v917,v918,v919) => { *v916 } },false,0u64,(((match v742 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v920,v921,v922,v923,v924,v925,v926,v927,v928,v929) => { *v929 } }).wrapping_add(1u64)) & (4294967295u64)))))) { D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(v930) => { match &(D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(std::sync::Arc::new(d_f17a4f88d452bbfddc3faeacc61a045b96954656a47606cb20189965b548d35c(v930.as_ref(),v743,*v776)))) { D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(v931) => { match &(D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(std::sync::Arc::new(d_f17a4f88d452bbfddc3faeacc61a045b96954656a47606cb20189965b548d35c(v931.as_ref(),v743,*v787)))) { D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(v932) => { match &(D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(std::sync::Arc::new(d_f17a4f88d452bbfddc3faeacc61a045b96954656a47606cb20189965b548d35c(v932.as_ref(),v743,*v808)))) { D_50d418f37e4dde286a5237fde12afafeebfc14fcc47c30978ff4c6e889240243::C0(v933) => { d_f17a4f88d452bbfddc3faeacc61a045b96954656a47606cb20189965b548d35c(v933.as_ref(),v743,*v829) } } } } } } } } } } } } } } } } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60 { C0,C1(std::sync::Arc<D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd>) }
fn d_da597886f363927b5d21a122bbee3f2543e42db5ead2b6de0c13dd969f1da4fa(v934: &D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69,v935: u64) -> D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69 { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(match &(d_8f49b0501dc5088b5b1fbb496bf7a43da0fc57cc982a3223cec950add0d80d8c(&(match v934 { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v936,v937,v938,v939) => { (v936.as_ref()).clone() } }),match v934 { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v940,v941,v942,v943) => { *v942 } })) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { v935 },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v944) => { *v944 } })) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v945) => { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(std::sync::Arc::new(match v934 { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v946,v947,v948,v949) => { (v946.as_ref()).clone() } }),std::sync::Arc::new(d_40f81830bbf4127535b60ab6c9d54b1ffed69633c3d1e8eb4c12f7e778f3d35f(&(match v934 { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v950,v951,v952,v953) => { (v951.as_ref()).clone() } }),match v934 { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v954,v955,v956,v957) => { *v956 } })),*v945,((match v934 { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v958,v959,v960,v961) => { *v960 } }) == (v935))) } } }
fn d_dafb03cc83093cc54f68a0af33b8eed41b88d9b5efa7f70ab30ed00a20fc0b1c(v962: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v963: u64,v964: u64) -> D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8 { match v962 { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 => { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0 },D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v966,v967) => { if ((v963) == (0u64)) { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(v964,std::sync::Arc::clone(v967)) } else { D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(*v966,std::sync::Arc::new(d_dafb03cc83093cc54f68a0af33b8eed41b88d9b5efa7f70ab30ed00a20fc0b1c(v967.as_ref(),(((v963).wrapping_sub(1u64)) & (4294967295u64)),v964))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_e76d71eacc94ee97e8a1a02d9b0750885675867ac52f6e28927a98226058c5ad { C0(std::sync::Arc<D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871>) }
fn d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(v968: &D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871) -> u64 { match v968 { D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0 => { 0u64 },D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(v969,v970) => { (((1u64).wrapping_add(d_e7cef9a01b69b893880696b8a4a0a29a72c2c5ddbe06846e9754f588e0391259(v970.as_ref()))) & (4294967295u64)) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ed742c79021c129a74c485de3fde12f113f9e1f62fcdff87129f05a60f244981 { C0(std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>) }
fn d_f17a4f88d452bbfddc3faeacc61a045b96954656a47606cb20189965b548d35c(v971: &D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39,v972: u64,v973: u64) -> D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39 { match &(D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0((((match &(d_8f49b0501dc5088b5b1fbb496bf7a43da0fc57cc982a3223cec950add0d80d8c(&(match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v974,v975,v976,v977,v978,v979,v980,v981,v982,v983) => { (v976.as_ref()).clone() } }),v972)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { 0u64 },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v984) => { *v984 } }).wrapping_add(1u64)) & (4294967295u64)))) { D_98af435b8b616ddca7d9cab42ec186ea99e5fcf68108044eaafab505c731b2af::C0(v985) => { match &(D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793::C0(if if ((match &(d_3ec78a35272ed91061dacb8c052a158f10da108f6d53693c7b0661117c1a477a(&(match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v986,v987,v988,v989,v990,v991,v992,v993,v994,v995) => { (v986.as_ref()).clone() } }),v973)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { 1u64 },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v996) => { *v996 } }) == (0u64)) { ((d_675b1f4f897dbd6222dcc1a7905d41455272640b09efc4dda13c18702b3a72fd(&(match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v997,v998,v999,v1000,v1001,v1002,v1003,v1004,v1005,v1006) => { (v1000.as_ref()).clone() } }),v973)) == (false)) } else { false } { ((*v985) < (match &(d_8f49b0501dc5088b5b1fbb496bf7a43da0fc57cc982a3223cec950add0d80d8c(&(match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1007,v1008,v1009,v1010,v1011,v1012,v1013,v1014,v1015,v1016) => { (v1009.as_ref()).clone() } }),v973)) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { 4294967295u64 },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v1017) => { *v1017 } })) } else { false })) { D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793::C0(v1018) => { if *v1018 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(std::sync::Arc::new(match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1019,v1020,v1021,v1022,v1023,v1024,v1025,v1026,v1027,v1028) => { (v1019.as_ref()).clone() } }),std::sync::Arc::new(d_bf6aba90e46dc72ddc2215d097cea1f2923a96c4e3f4a35f12925a49df054182(&(match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1029,v1030,v1031,v1032,v1033,v1034,v1035,v1036,v1037,v1038) => { (v1030.as_ref()).clone() } }),&(D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(v973,(((*v985).wrapping_add(d_9bb3ec8899fbd786e3a9c9196168dd3cb0314e9fe3d22b3d85e09e94d3dbe5cf(v973,match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1039,v1040,v1041,v1042,v1043,v1044,v1045,v1046,v1047,v1048) => { *v1045 } },match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1049,v1050,v1051,v1052,v1053,v1054,v1055,v1056,v1057,v1058) => { *v1054 } }))) & (4294967295u64)))))),std::sync::Arc::new(if d_002fa87dc14fb22703d067bc5256bb42a441ff9bc957fdd023ea162e558462ba(&(match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1059,v1060,v1061,v1062,v1063,v1064,v1065,v1066,v1067,v1068) => { (v1061.as_ref()).clone() } }),v973) { d_5fe9167aff6b3b37e3ca66b5143100bd012f34939a1767db0e227ef4ac5bdb15(&(match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1069,v1070,v1071,v1072,v1073,v1074,v1075,v1076,v1077,v1078) => { (v1071.as_ref()).clone() } }),v973,*v985) } else { d_10474bbc4ac74580f8be4e0fa212cee2c299d6988c03e31fe5089407d8cf0f2a(&(match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1079,v1080,v1081,v1082,v1083,v1084,v1085,v1086,v1087,v1088) => { (v1081.as_ref()).clone() } }),v973,*v985) }),std::sync::Arc::new(match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1089,v1090,v1091,v1092,v1093,v1094,v1095,v1096,v1097,v1098) => { (v1092.as_ref()).clone() } }),std::sync::Arc::new(if d_002fa87dc14fb22703d067bc5256bb42a441ff9bc957fdd023ea162e558462ba(&(match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1099,v1100,v1101,v1102,v1103,v1104,v1105,v1106,v1107,v1108) => { (v1103.as_ref()).clone() } }),v973) { d_5fe9167aff6b3b37e3ca66b5143100bd012f34939a1767db0e227ef4ac5bdb15(&(match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1109,v1110,v1111,v1112,v1113,v1114,v1115,v1116,v1117,v1118) => { (v1113.as_ref()).clone() } }),v973,v972) } else { d_10474bbc4ac74580f8be4e0fa212cee2c299d6988c03e31fe5089407d8cf0f2a(&(match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1119,v1120,v1121,v1122,v1123,v1124,v1125,v1126,v1127,v1128) => { (v1123.as_ref()).clone() } }),v973,v972) }),match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1129,v1130,v1131,v1132,v1133,v1134,v1135,v1136,v1137,v1138) => { *v1134 } },match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1139,v1140,v1141,v1142,v1143,v1144,v1145,v1146,v1147,v1148) => { *v1145 } },match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1149,v1150,v1151,v1152,v1153,v1154,v1155,v1156,v1157,v1158) => { *v1156 } },match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1159,v1160,v1161,v1162,v1163,v1164,v1165,v1166,v1167,v1168) => { *v1167 } },match v971 { D_3fa3b646b9f20d2dd78a7d0388a6fc9a0e493a04ea22e6f41988b6b381292a39::C0(v1169,v1170,v1171,v1172,v1173,v1174,v1175,v1176,v1177,v1178) => { *v1178 } }) } else { (v971).clone() } } } } } }
fn d_f23e5e1ef33767cf923369310c51eeb75173bed11e5d3e4d87c4354e4e2aac2a(v1179: &D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9,v1180: u64,v1181: u64,v1182: &D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,v1183: u64) -> D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8 { if if ((v1180) == (0u64)) { true } else { false } { (v1182).clone() } else { match v1179 { D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0 => { (v1182).clone() },D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(v1184,v1185) => { if *v1184 { match &(D_629702fff8bf26d1700c51e6d59e94b0faf5093d8d3e8cb0a184b7ac9f3f084a::C0(std::sync::Arc::new(d_f23e5e1ef33767cf923369310c51eeb75173bed11e5d3e4d87c4354e4e2aac2a(v1185.as_ref(),(v1180).checked_div(2u64).unwrap_or(0),(((v1181).wrapping_add((v1180).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_f23e5e1ef33767cf923369310c51eeb75173bed11e5d3e4d87c4354e4e2aac2a(v1185.as_ref(),(v1180).checked_div(2u64).unwrap_or(0),v1181,v1182,v1183)),v1183)))) { D_629702fff8bf26d1700c51e6d59e94b0faf5093d8d3e8cb0a184b7ac9f3f084a::C0(v1186) => { if false { (v1186.as_ref()).clone() } else { match &(d_3ec78a35272ed91061dacb8c052a158f10da108f6d53693c7b0661117c1a477a(v1186.as_ref(),(((v1181).wrapping_add(((v1180).checked_div(2u64).unwrap_or(0)).wrapping_mul(2u64))) & (4294967295u64)))) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { (v1186.as_ref()).clone() },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v1187) => { match &(d_3ec78a35272ed91061dacb8c052a158f10da108f6d53693c7b0661117c1a477a(v1186.as_ref(),((((((v1183).wrapping_sub(1u64)) & (4294967295u64))).wrapping_sub((((v1181).wrapping_add(((v1180).checked_div(2u64).unwrap_or(0)).wrapping_mul(2u64))) & (4294967295u64)))) & (4294967295u64)))) { D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0 => { (v1186.as_ref()).clone() },D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(v1188) => { d_dafb03cc83093cc54f68a0af33b8eed41b88d9b5efa7f70ab30ed00a20fc0b1c(&(d_dafb03cc83093cc54f68a0af33b8eed41b88d9b5efa7f70ab30ed00a20fc0b1c(v1186.as_ref(),(((v1181).wrapping_add(((v1180).checked_div(2u64).unwrap_or(0)).wrapping_mul(2u64))) & (4294967295u64)),*v1188)),((((((v1183).wrapping_sub(1u64)) & (4294967295u64))).wrapping_sub((((v1181).wrapping_add(((v1180).checked_div(2u64).unwrap_or(0)).wrapping_mul(2u64))) & (4294967295u64)))) & (4294967295u64)),*v1187) } } } } } } } } else { d_f23e5e1ef33767cf923369310c51eeb75173bed11e5d3e4d87c4354e4e2aac2a(v1185.as_ref(),(v1180).checked_div(2u64).unwrap_or(0),(((v1181).wrapping_add((v1180).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_f23e5e1ef33767cf923369310c51eeb75173bed11e5d3e4d87c4354e4e2aac2a(v1185.as_ref(),(v1180).checked_div(2u64).unwrap_or(0),v1181,v1182,v1183)),v1183) } } } } }
fn d_f27de552516fbc855a6704e6cb1adf85ea68f335192ed7a6481f821689b356ad(v1189: &D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9,v1190: u64,v1191: u64,v1192: &D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d) -> D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d { if if ((v1190) == (0u64)) { true } else { if match v1192 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v1193,v1194,v1195) => { *v1195 } } { true } else { ((match v1192 { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v1196,v1197,v1198) => { *v1197 } }) == (0u64)) } } { (v1192).clone() } else { match v1189 { D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0 => { (v1192).clone() },D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(v1199,v1200) => { if *v1199 { match &(D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(std::sync::Arc::new(d_f27de552516fbc855a6704e6cb1adf85ea68f335192ed7a6481f821689b356ad(v1200.as_ref(),(v1190).checked_div(2u64).unwrap_or(0),(((v1191).wrapping_add((v1190).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_f27de552516fbc855a6704e6cb1adf85ea68f335192ed7a6481f821689b356ad(v1200.as_ref(),(v1190).checked_div(2u64).unwrap_or(0),v1191,v1192)))))) { D_a0201e3875b79969add21779b1b7c8f803369cc9609570974dc2c58aa848fea9::C0(v1201) => { if if match v1201.as_ref() { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v1202,v1203,v1204) => { *v1204 } } { true } else { ((match v1201.as_ref() { D_3d1846c37e842f6ef342cea3499ef91bfea13d6190463bc9b48f4c42ff80781d::C0(v1205,v1206,v1207) => { *v1206 } }) == (0u64)) } { (v1201.as_ref()).clone() } else { d_9810c261dad317f7b06b890c118ad27801055f9efb8eebb59483c8572acec798(v1201.as_ref()) } } } } else { d_f27de552516fbc855a6704e6cb1adf85ea68f335192ed7a6481f821689b356ad(v1200.as_ref(),(v1190).checked_div(2u64).unwrap_or(0),(((v1191).wrapping_add((v1190).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_f27de552516fbc855a6704e6cb1adf85ea68f335192ed7a6481f821689b356ad(v1200.as_ref(),(v1190).checked_div(2u64).unwrap_or(0),v1191,v1192))) } } } } }
fn d_f5a862ed3be98953915ddfce4c8d32ecbb4575d2b148fbf0b1d1bc4e6e9a8a9a(v1208: &D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f,v1209: u64,v1210: u64,v1211: &D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c,v1212: bool) -> D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9 { d_09057230fba3197d24acf11d85f672c6c272b2c13015c0be441b90f6e99d6967(&(d_8f8f9cf94b421df1993f5b3088dbaeb4cdbf8902174eb4cc7e959206aeb63d80(v1208)),v1209,v1210,v1211,v1212) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_f90cdf66561db58ea416e6df6dd713ead894db2079290c193de3b9407828b793 { C0(bool) }
fn d_fa8e70b6c7edb6eeac653ac7e50a93414822a4c906b31b18ff715fb31e358a61(v1213: &D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9,v1214: u64,v1215: u64,v1216: &D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69,v1217: u64) -> D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69 { if if ((v1214) == (0u64)) { true } else { match v1216 { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v1218,v1219,v1220,v1221) => { *v1221 } } } { (v1216).clone() } else { match v1213 { D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C0 => { (v1216).clone() },D_7af4df24c8d149c2373fbd367e6190aad1be4306864961ec362c0224cd580ed9::C1(v1222,v1223) => { if *v1222 { match &(D_4d68fd2c2ea116d87e7a4a150162c04ff1404fbc0d420ef69cf909b470f7e4a8::C0(std::sync::Arc::new(d_fa8e70b6c7edb6eeac653ac7e50a93414822a4c906b31b18ff715fb31e358a61(v1223.as_ref(),(v1214).checked_div(2u64).unwrap_or(0),(((v1215).wrapping_add((v1214).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_fa8e70b6c7edb6eeac653ac7e50a93414822a4c906b31b18ff715fb31e358a61(v1223.as_ref(),(v1214).checked_div(2u64).unwrap_or(0),v1215,v1216,v1217)),v1217)))) { D_4d68fd2c2ea116d87e7a4a150162c04ff1404fbc0d420ef69cf909b470f7e4a8::C0(v1224) => { if match v1224.as_ref() { D_8110cc078591517f277e40732eeb6a23a6e0fa7fc147cd6fa2c6b343acf43c69::C0(v1225,v1226,v1227,v1228) => { *v1228 } } { (v1224.as_ref()).clone() } else { d_da597886f363927b5d21a122bbee3f2543e42db5ead2b6de0c13dd969f1da4fa(v1224.as_ref(),v1217) } } } } else { d_fa8e70b6c7edb6eeac653ac7e50a93414822a4c906b31b18ff715fb31e358a61(v1223.as_ref(),(v1214).checked_div(2u64).unwrap_or(0),(((v1215).wrapping_add((v1214).checked_div(2u64).unwrap_or(0))) & (4294967295u64)),&(d_fa8e70b6c7edb6eeac653ac7e50a93414822a4c906b31b18ff715fb31e358a61(v1223.as_ref(),(v1214).checked_div(2u64).unwrap_or(0),v1215,v1216,v1217)),v1217) } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2 { C0,C1(std::sync::Arc<D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c>) }
fn d_fd80e0a5a22cb43bd4874e05a4a453616e976167dc3d449c7de11b3d67e6eb72(v1229: &D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f,v1230: u64) -> D_8cd109016fb88165d696167165db16dd2341ce7ca00316b445b4798973b64c2f { D_8cd109016fb88165d696167165db16dd2341ce7ca00316b445b4798973b64c2f::C0(std::sync::Arc::new((v1229).clone()),std::sync::Arc::new(d_71b03b379e93896fd4cd5fe78abc55e3eab05402dfa2a7c0412027448b40ccfe(&(d_8f8f9cf94b421df1993f5b3088dbaeb4cdbf8902174eb4cc7e959206aeb63d80(v1229)),v1230))) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_fdf257bc2584502163667d3ea4dbd18025f65af51919f5dc5f35439fd24e1fef { C0(std::sync::Arc<D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f>,std::sync::Arc<D_c4723b47c6e1d6bbaad257312e3775ae8ebc3ada669ec51045f34d4aefe99a68>) }
fn d_fe690522706f76952f83700f36307be1da8bcd81045843614616a8392bdb8f44(v1231: &D_8cd109016fb88165d696167165db16dd2341ce7ca00316b445b4798973b64c2f) -> D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f { match v1231 { D_8cd109016fb88165d696167165db16dd2341ce7ca00316b445b4798973b64c2f::C0(v1232,v1233) => { (v1232.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531 { C0,C1(u64) }
pub fn f_187292ac266e47508456207738c31f8ed95e66636f4545e364e133428466ee7c(v1234: &D_fdf257bc2584502163667d3ea4dbd18025f65af51919f5dc5f35439fd24e1fef) -> D_c4723b47c6e1d6bbaad257312e3775ae8ebc3ada669ec51045f34d4aefe99a68 { d_187292ac266e47508456207738c31f8ed95e66636f4545e364e133428466ee7c(v1234) }
pub fn f_38f19433a51fb11a49e83af2a67a8238c5549ed37cdfbe13e98bdd148bac8b8d(v1235: &D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f,v1236: u64,v1237: u64) -> D_fdf257bc2584502163667d3ea4dbd18025f65af51919f5dc5f35439fd24e1fef { d_38f19433a51fb11a49e83af2a67a8238c5549ed37cdfbe13e98bdd148bac8b8d(v1235,v1236,v1237) }
pub fn f_3d49fac84fd706ca4d2bddc3c53e21f9c8d82e8a70ee8b81def02800d29a11f7(v1238: &D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4) -> D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f { d_3d49fac84fd706ca4d2bddc3c53e21f9c8d82e8a70ee8b81def02800d29a11f7(v1238) }
pub fn f_6b63cf5afc61090ec31102a63c1b59b4f108d50a99efcdc94e1504146dfea6ed(v1239: &D_8cd109016fb88165d696167165db16dd2341ce7ca00316b445b4798973b64c2f) -> D_2039380a191f87da8dbfd810ad313b62244825a051b4c0c3de52b6715baca512 { d_6b63cf5afc61090ec31102a63c1b59b4f108d50a99efcdc94e1504146dfea6ed(v1239) }
pub fn f_8f8f9cf94b421df1993f5b3088dbaeb4cdbf8902174eb4cc7e959206aeb63d80(v1240: &D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f) -> D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4 { d_8f8f9cf94b421df1993f5b3088dbaeb4cdbf8902174eb4cc7e959206aeb63d80(v1240) }
pub fn f_b0495dc3a518a6f02848318dcbb318a833d40709e5d01598ece43f47bc462e33(v1241: &D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f,v1242: u64,v1243: u64,v1244: bool) -> D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9 { d_b0495dc3a518a6f02848318dcbb318a833d40709e5d01598ece43f47bc462e33(v1241,v1242,v1243,v1244) }
pub fn f_bbd5ed7008af8380acd37020844e9c2db02554d2a7eb796bc069d4b765a1a27e(v1245: &D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9) -> D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f { d_bbd5ed7008af8380acd37020844e9c2db02554d2a7eb796bc069d4b765a1a27e(v1245) }
pub fn f_c27382cc26c2f2d698bb22075c8a32db4b69b31a5b94ff0ab658949e35b639e5(v1246: &D_fdf257bc2584502163667d3ea4dbd18025f65af51919f5dc5f35439fd24e1fef) -> D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f { d_c27382cc26c2f2d698bb22075c8a32db4b69b31a5b94ff0ab658949e35b639e5(v1246) }
pub fn f_c9ae8314360fd86b1545c14505dc08313b35ba9b057fa47da87c0631868a13b5(v1247: &D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9) -> D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9 { d_c9ae8314360fd86b1545c14505dc08313b35ba9b057fa47da87c0631868a13b5(v1247) }
pub fn f_f5a862ed3be98953915ddfce4c8d32ecbb4575d2b148fbf0b1d1bc4e6e9a8a9a(v1248: &D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f,v1249: u64,v1250: u64,v1251: &D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c,v1252: bool) -> D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9 { d_f5a862ed3be98953915ddfce4c8d32ecbb4575d2b148fbf0b1d1bc4e6e9a8a9a(v1248,v1249,v1250,v1251,v1252) }
pub fn f_fd80e0a5a22cb43bd4874e05a4a453616e976167dc3d449c7de11b3d67e6eb72(v1253: &D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f,v1254: u64) -> D_8cd109016fb88165d696167165db16dd2341ce7ca00316b445b4798973b64c2f { d_fd80e0a5a22cb43bd4874e05a4a453616e976167dc3d449c7de11b3d67e6eb72(v1253,v1254) }
pub fn f_fe690522706f76952f83700f36307be1da8bcd81045843614616a8392bdb8f44(v1255: &D_8cd109016fb88165d696167165db16dd2341ce7ca00316b445b4798973b64c2f) -> D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f { d_fe690522706f76952f83700f36307be1da8bcd81045843614616a8392bdb8f44(v1255) }
fn q_38f19433a51fb11a49e83af2a67a8238c5549ed37cdfbe13e98bdd148bac8b8d(v0:&D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f,v1:u64,v2:u64)->D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2{match v0 { D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f::C0(v3) => { d_201e280f19da197f80aaeeb90891c2afb639627134c77648eaa04371e3b5cdd6(v3.as_ref(),v2) } }}
fn q_fd80e0a5a22cb43bd4874e05a4a453616e976167dc3d449c7de11b3d67e6eb72(v0:&D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f,v1:u64)->D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60{match v0 { D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f::C0(v2) => { match &(d_201e280f19da197f80aaeeb90891c2afb639627134c77648eaa04371e3b5cdd6(v2.as_ref(),0u64)) { D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C0 => { D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60::C0 },D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C1(v4) => { D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60::C1(std::sync::Arc::new(d_b49a17a751300394c261cc3b13d02c5f86514ef9f076c31c61a9a4ad1121d77f(&(match v4.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v5,v6,v7,v8,v9) => { (v5.as_ref()).clone() } }),match v4.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v10,v11,v12,v13,v14) => { *v11 } },match v4.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v15,v16,v17,v18,v19) => { *v17 } },match v4.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v20,v21,v22,v23,v24) => { *v23 } },match v4.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v25,v26,v27,v28,v29) => { *v29 } }))) } } } }}
fn t_38f19433a51fb11a49e83af2a67a8238c5549ed37cdfbe13e98bdd148bac8b8d(v0:&D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f,v1:u64,v2:u64)->D_fdf257bc2584502163667d3ea4dbd18025f65af51919f5dc5f35439fd24e1fef{match v0 { D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f::C0(v3) => { D_fdf257bc2584502163667d3ea4dbd18025f65af51919f5dc5f35439fd24e1fef::C0(std::sync::Arc::new(D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f::C0(std::sync::Arc::clone(v3))),std::sync::Arc::new(D_c4723b47c6e1d6bbaad257312e3775ae8ebc3ada669ec51045f34d4aefe99a68::C0(std::sync::Arc::new(d_201e280f19da197f80aaeeb90891c2afb639627134c77648eaa04371e3b5cdd6(v3.as_ref(),v2)),false,v1,std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::clone({static v4:std::sync::OnceLock<std::sync::Arc<D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462>>=std::sync::OnceLock::new();v4.get_or_init(||std::sync::Arc::new(D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0))}))))}),std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})))) } }}
fn t_fd80e0a5a22cb43bd4874e05a4a453616e976167dc3d449c7de11b3d67e6eb72(v0:&D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f,v1:u64)->D_8cd109016fb88165d696167165db16dd2341ce7ca00316b445b4798973b64c2f{match v0 { D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f::C0(v2) => { D_8cd109016fb88165d696167165db16dd2341ce7ca00316b445b4798973b64c2f::C0(std::sync::Arc::new(D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f::C0(std::sync::Arc::clone(v2))),std::sync::Arc::new(D_2039380a191f87da8dbfd810ad313b62244825a051b4c0c3de52b6715baca512::C0(std::sync::Arc::new(match &(d_201e280f19da197f80aaeeb90891c2afb639627134c77648eaa04371e3b5cdd6(v2.as_ref(),0u64)) { D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C0 => { D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60::C0 },D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C1(v4) => { D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60::C1(std::sync::Arc::new(d_b49a17a751300394c261cc3b13d02c5f86514ef9f076c31c61a9a4ad1121d77f(&(match v4.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v5,v6,v7,v8,v9) => { (v5.as_ref()).clone() } }),match v4.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v10,v11,v12,v13,v14) => { *v11 } },match v4.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v15,v16,v17,v18,v19) => { *v17 } },match v4.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v20,v21,v22,v23,v24) => { *v23 } },match v4.as_ref() { D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(v25,v26,v27,v28,v29) => { *v29 } }))) } }),false,v1,std::sync::Arc::clone({static v31:std::sync::OnceLock<std::sync::Arc<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4>>=std::sync::OnceLock::new();v31.get_or_init(||std::sync::Arc::new(D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::clone({static v30:std::sync::OnceLock<std::sync::Arc<D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462>>=std::sync::OnceLock::new();v30.get_or_init(||std::sync::Arc::new(D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0))}))))}),std::sync::Arc::clone({static v32:std::sync::OnceLock<std::sync::Arc<D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d>>=std::sync::OnceLock::new();v32.get_or_init(||std::sync::Arc::new(D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0))})))) } }}

use serde_json::{Value as Json,json};
mod portable{
//! Shared, representation-independent snapshot codec. This module also ships
//! verbatim in generated applications; it has no AST/evaluator dependency.
use num_bigint::{BigInt, Sign};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::cmp::Ordering;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Schema {
    Unit,
    Bool,
    U32,
    U64,
    I32,
    F32,
    Vector(Box<Schema>, u8),
    Int,
    String,
    Id,
    Record(Vec<(String, Schema)>),
    Enum(Vec<String>),
    List(Box<Schema>),
    Option(Box<Schema>),
    Result(Box<Schema>, Box<Schema>),
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Layout {
    pub program: [u8; 32],
    pub schema: [u8; 32],
    pub roots: Vec<(String, Schema, Schema)>,
    pub events: Vec<(String, Schema)>,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Event {
    pub commit: u64,
    pub position: u64,
    pub channel: usize,
    pub value: Value,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Logical {
    pub version: u64,
    pub tables: Vec<Vec<(Value, Value)>>,
    pub outbox: Vec<Event>,
}
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub bytes: usize,
    pub values: usize,
    pub depth: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            bytes: 64 * 1024 * 1024,
            values: 1_000_000,
            depth: 128,
        }
    }
}
/// Magnitude bound for one exact integer. Decimal conversion is superlinear,
/// so without it a single large Int in a snapshot takes minutes to hours.
pub const MAX_INT_BYTES: usize = 4096;
const MAGIC: &[u8; 8] = b"VLSTATE\0";
const HEADER: usize = 8 + 2 + 2 + 32 + 32 + 8;
type R<T> = Result<T, String>;
fn u64_bytes(out: &mut Vec<u8>, v: u64) {
    out.extend_from_slice(&v.to_le_bytes());
}
fn count(out: &mut Vec<u8>, n: usize) {
    u64_bytes(out, n as u64);
}
fn raw(out: &mut Vec<u8>, b: &[u8]) {
    count(out, b.len());
    out.extend_from_slice(b);
}
fn tag<'a>(v: &'a Value, name: &str) -> R<&'a Value> {
    let o = v.as_object().ok_or("expected tagged object")?;
    if o.len() != 1 {
        return Err("expected exactly one tag".into());
    }
    o.get(name).ok_or("unexpected value tag".into())
}
fn integer(v: &Value) -> R<BigInt> {
    let s = tag(v, "Int")?.as_str().ok_or("expected Int string")?;
    // Every Int within the bound has fewer than 2.41 decimal digits per byte.
    if s.len() > MAX_INT_BYTES * 5 / 2 + 1 {
        return Err("snapshot Int exceeds size limit".into());
    }
    let n = s.parse::<BigInt>().map_err(|_| "invalid Int")?;
    if n.bits() > 8 * MAX_INT_BYTES as u64 {
        return Err("snapshot Int exceeds size limit".into());
    }
    if n.to_string() != s {
        return Err("noncanonical Int".into());
    }
    Ok(n)
}
fn identifier(v: &Value) -> R<u128> {
    let s = v.as_str().ok_or("expected ID")?;
    if s.len() != 32
        || !s
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err("noncanonical ID".into());
    }
    u128::from_str_radix(s, 16).map_err(|e| e.to_string())
}
fn compare(t: &Schema, a: &Value, b: &Value) -> R<Ordering> {
    Ok(match t {
        Schema::I32 => a
            .as_i64()
            .and_then(|n| i32::try_from(n).ok())
            .ok_or("invalid i32 key")?
            .cmp(
                &b.as_i64()
                    .and_then(|n| i32::try_from(n).ok())
                    .ok_or("invalid i32 key")?,
            ),
        Schema::U32 | Schema::U64 => a
            .as_u64()
            .ok_or("invalid key")?
            .cmp(&b.as_u64().ok_or("invalid key")?),
        Schema::String => a
            .as_str()
            .ok_or("invalid key")?
            .as_bytes()
            .cmp(b.as_str().ok_or("invalid key")?.as_bytes()),
        Schema::Id => identifier(a)?.cmp(&identifier(b)?),
        _ => return Err("unsupported snapshot key schema".into()),
    })
}
fn tick(left: &mut usize, depth: usize, limits: Limits) -> R<()> {
    if *left == 0 || depth > limits.depth {
        return Err("snapshot value/depth limit exceeded".into());
    }
    *left -= 1;
    Ok(())
}
fn encode_value(
    t: &Schema,
    v: &Value,
    out: &mut Vec<u8>,
    left: &mut usize,
    depth: usize,
    limits: Limits,
) -> R<()> {
    tick(left, depth, limits)?;
    match t {
        Schema::Unit => {
            if !v.is_null() {
                return Err("expected Unit".into());
            }
        }
        Schema::Bool => out.push(v.as_bool().ok_or("expected Bool")? as u8),
        Schema::U32 => out.extend_from_slice(
            &u32::try_from(v.as_u64().ok_or("expected u32")?)
                .map_err(|_| "u32 overflow")?
                .to_le_bytes(),
        ),
        Schema::U64 => u64_bytes(out, v.as_u64().ok_or("expected u64")?),
        Schema::I32 => out.extend_from_slice(
            &i32::try_from(v.as_i64().ok_or("expected i32")?)
                .map_err(|_| "i32 overflow")?
                .to_le_bytes(),
        ),
        Schema::F32 => {
            let bits = if let Some(b) = v.get("F32Bits") {
                if v.as_object().is_none_or(|o| o.len() != 1) {
                    return Err("expected only F32Bits field".into());
                }
                u32::try_from(b.as_u64().ok_or("expected f32 bits")?)
                    .map_err(|_| "f32 bits overflow")?
            } else {
                let f = v.as_f64().ok_or("expected f32")? as f32;
                if !f.is_finite() {
                    return Err("finite f32 or F32Bits required".into());
                }
                f.to_bits()
            };
            out.extend_from_slice(&bits.to_le_bytes());
        }
        Schema::Vector(inner, n) => {
            if !(2..=4).contains(n)
                || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
            {
                return Err("invalid vector schema".into());
            }
            let xs = v.as_array().ok_or("expected vector")?;
            if xs.len() != *n as usize {
                return Err("vector dimension mismatch".into());
            }
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Int => {
            let n = integer(v)?;
            let (sign, b) = n.to_bytes_le();
            out.push(match sign {
                Sign::NoSign => 0,
                Sign::Plus => 1,
                Sign::Minus => 2,
            });
            if sign == Sign::NoSign {
                raw(out, &[])
            } else {
                raw(out, &b)
            }
        }
        Schema::String => raw(out, v.as_str().ok_or("expected String")?.as_bytes()),
        Schema::Id => out.extend_from_slice(&identifier(v)?.to_le_bytes()),
        Schema::Enum(names) => {
            let s = v.as_str().ok_or("expected enum string")?;
            let index = names
                .iter()
                .position(|n| n == s)
                .ok_or("unknown enum variant")?;
            out.extend_from_slice(&(index as u32).to_le_bytes());
        }
        Schema::Record(fields) => {
            let obj = v.as_object().ok_or("expected record")?;
            if obj.len() != fields.len() {
                return Err("record field mismatch".into());
            }
            for (n, t) in fields {
                encode_value(
                    t,
                    obj.get(n).ok_or("missing record field")?,
                    out,
                    left,
                    depth + 1,
                    limits,
                )?;
            }
        }
        Schema::List(inner) => {
            let xs = v.as_array().ok_or("expected List")?;
            if xs.len() > *left {
                return Err("snapshot value limit exceeded".into());
            }
            count(out, xs.len());
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Option(inner) => {
            if let Ok(x) = tag(v, "Some") {
                out.push(1);
                encode_value(inner, x, out, left, depth + 1, limits)?;
            } else {
                if !tag(v, "None")?.is_null() {
                    return Err("invalid None".into());
                }
                out.push(0);
            }
        }
        Schema::Result(a, b) => {
            if let Ok(x) = tag(v, "Ok") {
                out.push(0);
                encode_value(a, x, out, left, depth + 1, limits)?;
            } else {
                out.push(1);
                encode_value(b, tag(v, "Err")?, out, left, depth + 1, limits)?;
            }
        }
    }
    if out.len() > limits.bytes {
        return Err("snapshot byte limit exceeded".into());
    }
    Ok(())
}
struct Reader<'a> {
    bytes: &'a [u8],
    at: usize,
    left: usize,
    limits: Limits,
}
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> R<&'a [u8]> {
        let end = self.at.checked_add(n).ok_or("snapshot length overflow")?;
        let b = self.bytes.get(self.at..end).ok_or("truncated snapshot")?;
        self.at = end;
        Ok(b)
    }
    fn byte(&mut self) -> R<u8> {
        Ok(self.take(1)?[0])
    }
    fn u32(&mut self) -> R<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn u64(&mut self) -> R<u64> {
        Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
    fn len(&mut self) -> R<usize> {
        usize::try_from(self.u64()?).map_err(|_| "snapshot length not addressable".into())
    }
    fn sequence(&mut self) -> R<usize> {
        let n = self.len()?;
        if n > self.left {
            return Err("snapshot value limit exceeded".into());
        }
        Ok(n)
    }
    fn raw(&mut self) -> R<&'a [u8]> {
        let n = self.len()?;
        self.take(n)
    }
    fn value(&mut self, t: &Schema, depth: usize) -> R<Value> {
        tick(&mut self.left, depth, self.limits)?;
        Ok(match t {
            Schema::Unit => Value::Null,
            Schema::Bool => match self.byte()? {
                0 => json!(false),
                1 => json!(true),
                _ => return Err("invalid Bool tag".into()),
            },
            Schema::U32 => json!(self.u32()?),
            Schema::U64 => json!(self.u64()?),
            Schema::I32 => json!(self.u32()? as i32),
            Schema::F32 => {
                let bits = self.u32()?;
                let f = f32::from_bits(bits);
                if f.is_finite() {
                    json!(f)
                } else {
                    json!({"F32Bits":bits})
                }
            }
            Schema::Vector(inner, n) => {
                if !(2..=4).contains(n)
                    || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
                {
                    return Err("invalid vector schema".into());
                }
                (0..*n)
                    .map(|_| self.value(inner, depth + 1))
                    .collect::<R<Vec<_>>>()?
                    .into()
            }
            Schema::Int => {
                let sign = self.byte()?;
                let bytes = self.raw()?;
                if bytes.len() > MAX_INT_BYTES {
                    return Err("snapshot Int exceeds size limit".into());
                }
                let sign = match sign {
                    0 if bytes.is_empty() => Sign::NoSign,
                    1 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Plus,
                    2 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Minus,
                    _ => return Err("noncanonical signed integer".into()),
                };
                json!({"Int":BigInt::from_bytes_le(sign,bytes).to_string()})
            }
            Schema::String => json!(std::str::from_utf8(self.raw()?).map_err(|_| "invalid UTF-8")?),
            Schema::Id => json!(format!(
                "{:032x}",
                u128::from_le_bytes(self.take(16)?.try_into().unwrap())
            )),
            Schema::Enum(names) => {
                json!(names.get(self.u32()? as usize).ok_or("invalid enum tag")?)
            }
            Schema::Record(fields) => {
                let mut obj = serde_json::Map::new();
                for (n, t) in fields {
                    obj.insert(n.clone(), self.value(t, depth + 1)?);
                }
                Value::Object(obj)
            }
            Schema::List(t) => {
                let n = self.sequence()?;
                let mut xs = Vec::new();
                for _ in 0..n {
                    xs.push(self.value(t, depth + 1)?);
                }
                Value::Array(xs)
            }
            Schema::Option(t) => match self.byte()? {
                0 => json!({"None":null}),
                1 => json!({"Some":self.value(t,depth+1)?}),
                _ => return Err("invalid Option tag".into()),
            },
            Schema::Result(a, b) => match self.byte()? {
                0 => json!({"Ok":self.value(a,depth+1)?}),
                1 => json!({"Err":self.value(b,depth+1)?}),
                _ => return Err("invalid Result tag".into()),
            },
        })
    }
}
fn event_order(e: &Event, version: u64, prior: Option<(u64, u64)>) -> R<()> {
    if e.commit == 0 || e.commit > version || prior.is_some_and(|p| p >= (e.commit, e.position)) {
        return Err("invalid snapshot event sequence".into());
    }
    Ok(())
}
pub fn encode(layout: &Layout, s: &Logical, limits: Limits) -> R<Vec<u8>> {
    if s.tables.len() != layout.roots.len() {
        return Err("snapshot root count mismatch".into());
    }
    let mut out = Vec::new();
    let mut left = limits.values;
    u64_bytes(&mut out, s.version);
    for (rows, (_, kt, vt)) in s.tables.iter().zip(&layout.roots) {
        if rows.len() > left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        count(&mut out, rows.len());
        let mut prior = None;
        for (k, v) in rows {
            if let Some(p) = prior {
                if compare(kt, p, k)? != Ordering::Less {
                    return Err("snapshot keys must be strictly ordered".into());
                }
            }
            encode_value(kt, k, &mut out, &mut left, 0, limits)?;
            encode_value(vt, v, &mut out, &mut left, 0, limits)?;
            prior = Some(k);
        }
    }
    count(&mut out, s.outbox.len());
    let mut prior = None;
    for e in &s.outbox {
        event_order(e, s.version, prior)?;
        let (_, t) = layout
            .events
            .get(e.channel)
            .ok_or("unknown event channel")?;
        u64_bytes(&mut out, e.commit);
        u64_bytes(&mut out, e.position);
        out.extend_from_slice(&(e.channel as u32).to_le_bytes());
        encode_value(t, &e.value, &mut out, &mut left, 0, limits)?;
        prior = Some((e.commit, e.position));
    }
    if HEADER
        .checked_add(out.len())
        .and_then(|n| n.checked_add(32))
        .is_none_or(|n| n > limits.bytes)
    {
        return Err("snapshot byte limit exceeded".into());
    }
    let mut bytes = Vec::new();
    bytes.extend_from_slice(MAGIC);
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&layout.program);
    bytes.extend_from_slice(&layout.schema);
    count(&mut bytes, out.len());
    bytes.extend_from_slice(&out);
    let digest = Sha256::digest(&bytes);
    bytes.extend_from_slice(&digest);
    Ok(bytes)
}
pub fn decode(layout: &Layout, bytes: &[u8], limits: Limits) -> R<Logical> {
    if bytes.len() > limits.bytes || bytes.len() < HEADER + 32 {
        return Err("snapshot byte length invalid".into());
    }
    if &bytes[..8] != MAGIC || bytes[8..12] != [1, 0, 1, 0] {
        return Err("snapshot format or semantics version mismatch".into());
    }
    if bytes[12..44] != layout.program || bytes[44..76] != layout.schema {
        return Err("snapshot program or schema identity mismatch".into());
    }
    let n = usize::try_from(u64::from_le_bytes(bytes[76..84].try_into().unwrap()))
        .map_err(|_| "snapshot length not addressable")?;
    if HEADER.checked_add(n).and_then(|v| v.checked_add(32)) != Some(bytes.len()) {
        return Err("snapshot payload length mismatch".into());
    }
    let end = bytes.len() - 32;
    if Sha256::digest(&bytes[..end]).as_slice() != &bytes[end..] {
        return Err("snapshot integrity check failed".into());
    }
    let mut r = Reader {
        bytes: &bytes[HEADER..end],
        at: 0,
        left: limits.values,
        limits,
    };
    let version = r.u64()?;
    let mut tables = vec![];
    for (_, kt, vt) in &layout.roots {
        let n = r.sequence()?;
        if n > r.left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        let mut rows: Vec<(Value, Value)> = vec![];
        for _ in 0..n {
            let k = r.value(kt, 0)?;
            let v = r.value(vt, 0)?;
            if let Some((prior, _)) = rows.last() {
                if compare(kt, prior, &k)? != Ordering::Less {
                    return Err("duplicate or unordered snapshot key".into());
                }
            }
            rows.push((k, v));
        }
        tables.push(rows);
    }
    let n = r.sequence()?;
    let mut outbox = vec![];
    let mut prior = None;
    for _ in 0..n {
        let commit = r.u64()?;
        let position = r.u64()?;
        let channel = r.u32()? as usize;
        let (_, t) = layout
            .events
            .get(channel)
            .ok_or("unknown snapshot event channel")?;
        let value = r.value(t, 0)?;
        let e = Event {
            commit,
            position,
            channel,
            value,
        };
        event_order(&e, version, prior)?;
        prior = Some((commit, position));
        outbox.push(e);
    }
    if r.at != r.bytes.len() {
        return Err("trailing snapshot payload".into());
    }
    Ok(Logical {
        version,
        tables,
        outbox,
    })
}

}
pub use portable::Limits as SnapshotLimits;
fn snapshot_layout()->portable::Layout{portable::Layout{program:[198, 250, 5, 100, 156, 198, 184, 164, 211, 225, 119, 254, 12, 101, 97, 28, 119, 18, 228, 201, 97, 90, 9, 239, 53, 254, 180, 41, 67, 157, 95, 243],schema:[100, 158, 40, 254, 106, 233, 63, 3, 104, 14, 41, 32, 114, 78, 131, 217, 86, 160, 145, 67, 151, 190, 67, 95, 14, 123, 126, 238, 228, 124, 115, 222],roots:vec![
("Inputs".into(),portable::Schema::U64,portable::Schema::Record(vec![("grid".into(),portable::Schema::List(Box::new(portable::Schema::U32))),("width".into(),portable::Schema::U32),("start".into(),portable::Schema::U32),("goal".into(),portable::Schema::U32),("limit".into(),portable::Schema::U32)])),
],events:vec![]}}
fn one_tag<'a>(v:&'a Json,_kind:&str)->Result<&'a serde_json::Map<String,Json>,String>{Ok(v.as_object().unwrap())}
fn read_0(v:&Json,d:usize)->Result<bool,String>{Ok(
v.as_bool().unwrap())}
fn write_0(v:&bool,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_1(v:&Json,d:usize)->Result<u64,String>{Ok(
v.as_u64().unwrap())}
fn write_1(v:&u64,d:usize)->Result<Json,String>{Ok(
{json!(v)})}
fn read_2(v:&Json,d:usize)->Result<u64,String>{Ok(
v.as_u64().unwrap())}
fn write_2(v:&u64,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_3(v:&Json,d:usize)->Result<D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7,String>{Ok(
{D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7::C0})}
fn write_3(v:&D_05730c2218512f3da9b8289d64b583a881b0b94cc7e4dc3a02d450d67cfb7ab7,d:usize)->Result<Json,String>{Ok(
Json::Null)}
fn read_6(v:&Json,d:usize)->Result<D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,String>{Ok(
{let xs=v.as_array().unwrap();let mut tail=D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0;for x in xs.iter().rev(){tail=D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(read_1(x,d+1)?,std::sync::Arc::new(tail));}tail})}
fn write_6(v:&D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8,d:usize)->Result<Json,String>{Ok(
{let mut cursor=v;let mut xs=vec![];loop{match cursor{D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C0=>break,D_1c1110f0dde3f83f59c0da8360688e05472c3be86534bd8ff5f837bee54bc1d8::C1(x,tail)=>{xs.push(write_1(x,d+1)?);cursor=tail.as_ref();}}}Json::Array(xs)})}
fn read_7(v:&Json,d:usize)->Result<D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871,String>{Ok(
{let xs=v.as_array().unwrap();let mut tail=D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0;for x in xs.iter().rev(){tail=D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(std::sync::Arc::new(read_10(x,d+1)?),std::sync::Arc::new(tail));}tail})}
fn write_7(v:&D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871,d:usize)->Result<Json,String>{Ok(
{let mut cursor=v;let mut xs=vec![];loop{match cursor{D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C0=>break,D_309ea7c7a0361706fb9236608ad516e7e98b11f81257f4959a74a9d8c955d871::C1(x,tail)=>{xs.push(write_10(x,d+1)?);cursor=tail.as_ref();}}}Json::Array(xs)})}
fn read_10(v:&Json,d:usize)->Result<D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f,String>{Ok(
{let xs=v.as_object().unwrap();D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(read_1(xs.get("node").unwrap(),d+1)?,read_1(xs.get("priority").unwrap(),d+1)?)})}
fn write_10(v:&D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f,d:usize)->Result<Json,String>{Ok(
{let D_b33e92915940c7f982612d722e183b702775d124c0ae25026e72a472bc77ec1f::C0(b0,b1)=v;json!({"node":write_1(&b0,d+1)?,"priority":write_1(&b1,d+1)?})})}
fn read_11(v:&Json,d:usize)->Result<D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c,String>{Ok(
{let xs=v.as_object().unwrap();D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(std::sync::Arc::new(read_6(xs.get("grid").unwrap(),d+1)?),read_1(xs.get("width").unwrap(),d+1)?,read_1(xs.get("start").unwrap(),d+1)?,read_1(xs.get("goal").unwrap(),d+1)?,read_1(xs.get("limit").unwrap(),d+1)?)})}
fn write_11(v:&D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c,d:usize)->Result<Json,String>{Ok(
{let D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c::C0(b0,b1,b2,b3,b4)=v;json!({"grid":write_6(&b0,d+1)?,"width":write_1(&b1,d+1)?,"start":write_1(&b2,d+1)?,"goal":write_1(&b3,d+1)?,"limit":write_1(&b4,d+1)?})})}
fn read_14(v:&Json,d:usize)->Result<D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd,String>{Ok(
{let xs=v.as_object().unwrap();D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd::C0(read_0(xs.get("found").unwrap(),d+1)?,read_1(xs.get("distance").unwrap(),d+1)?,read_1(xs.get("expanded").unwrap(),d+1)?,read_0(xs.get("limited").unwrap(),d+1)?,std::sync::Arc::new(read_6(xs.get("path").unwrap(),d+1)?))})}
fn write_14(v:&D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd,d:usize)->Result<Json,String>{Ok(
{let D_6393a86b5fe8ce2afef70274bd2fa7794abb4355f584ac957b4204f88de9abdd::C0(b0,b1,b2,b3,b4)=v;json!({"found":write_0(&b0,d+1)?,"distance":write_1(&b1,d+1)?,"expanded":write_1(&b2,d+1)?,"limited":write_0(&b3,d+1)?,"path":write_6(&b4,d+1)?})})}
fn read_16(v:&Json,d:usize)->Result<D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea::C1(read_0(x,d+1)?)}else{D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea::C0}})}
fn write_16(v:&D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea,d:usize)->Result<Json,String>{Ok(
match v{D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea::C0=>json!({"None":null}),D_d7438fdef1f1faf76a9d1541c868b94578a495aa156bb5bb96e2186f7ab117ea::C1(x)=>json!({"Some":write_0(x,d+1)?})})}
fn read_17(v:&Json,d:usize)->Result<D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(read_1(x,d+1)?)}else{D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0}})}
fn write_17(v:&D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531,d:usize)->Result<Json,String>{Ok(
match v{D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C0=>json!({"None":null}),D_ff0a9c503e37175ee20c95f4260397ae29e05ee7afef0d62d89bdd6b00e16531::C1(x)=>json!({"Some":write_1(x,d+1)?})})}
fn read_18(v:&Json,d:usize)->Result<D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(std::sync::Arc::new(read_10(x,d+1)?))}else{D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0}})}
fn write_18(v:&D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6,d:usize)->Result<Json,String>{Ok(
match v{D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C0=>json!({"None":null}),D_951a7af7d89fc050feebf18f27d6a9edcd98765e9be903952ae108bc9eebeea6::C1(x)=>json!({"Some":write_10(x,d+1)?})})}
fn read_19(v:&Json,d:usize)->Result<D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C1(std::sync::Arc::new(read_11(x,d+1)?))}else{D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C0}})}
fn write_19(v:&D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2,d:usize)->Result<Json,String>{Ok(
match v{D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C0=>json!({"None":null}),D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2::C1(x)=>json!({"Some":write_11(x,d+1)?})})}
fn read_20(v:&Json,d:usize)->Result<D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60::C1(std::sync::Arc::new(read_14(x,d+1)?))}else{D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60::C0}})}
fn write_20(v:&D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60,d:usize)->Result<Json,String>{Ok(
match v{D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60::C0=>json!({"None":null}),D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60::C1(x)=>json!({"Some":write_14(x,d+1)?})})}
fn read_21(v:&Json,d:usize)->Result<D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd,String>{Ok(
{let xs=one_tag(v,"Result")?;if let Some(x)=xs.get("Ok"){D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(std::sync::Arc::new(read_3(x,d+1)?))}else{let x=xs.get("Err").unwrap();D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(read_0(x,d+1)?)}})}
fn write_21(v:&D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd,d:usize)->Result<Json,String>{Ok(
match v{D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C0(x)=>json!({"Ok":write_3(x,d+1)?}),D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd::C1(x)=>json!({"Err":write_0(x,d+1)?})})}
fn logical_from_tables(tables:&[Vec<(Json,Json)>])->Result<D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4,String>{if tables.len()!=1{return Err("representation table count mismatch".into())}
let rows=&tables[0];let mut root0=D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0;for (key,row) in rows.iter().rev(){root0=D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(read_2(key,0)?,std::sync::Arc::new(read_11(row,0)?),std::sync::Arc::new(root0));}
Ok(D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::new(root0)))}
fn logical_tables(state:&D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4)->Result<Vec<Vec<(Json,Json)>>,String>{let D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(r0)=state;
let mut rows0=vec![];let mut cursor=r0.as_ref();loop{match cursor{D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0=>break,D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C1(key,value,tail)=>{rows0.push((write_2(key,0)?,write_11(value,0)?));cursor=tail.as_ref();}}}
Ok(vec![rows0])}
fn logical_events(events:&D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d)->Result<Vec<(usize,Json)>,String>{let mut cursor=events;let mut out=vec![];loop{match cursor{D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C0=>break,D_6dee19ef17ae52064c34bae0dfa0ab3bb8251401a2d61dbbd8159a021f6d5e5d::C1(event,tail)=>{let value=match event.as_ref(){
D_4e61cd2054b66259fa5fe6ff2848621d519f896c6b83b26615faed118e66c0c8::C0=>return Err("unknown source event".into()),
};out.push(value);cursor=tail.as_ref();}}}Ok(out)}
pub use portable::Event;
pub struct Outcome<T>{pub result:T,pub committed:bool,pub version:u64,pub events:Vec<Event>}
pub struct OutcomeView<'a,T>{pub result:T,pub committed:bool,pub version:u64,pub events:&'a[Event]}
impl<T> OutcomeView<'_,T>{pub fn into_owned(self)->Outcome<T>{Outcome{result:self.result,committed:self.committed,version:self.version,events:self.events.to_vec()}}}
pub struct State{physical:D_a5f9c97c7c4111738df193596f226e09a28ed113d959b0d7ffa30c241849ed4f,version:u64,outbox:Vec<portable::Event>,layout:portable::Layout}
impl State{
// CALLER CONTRACT: arguments must have the declared types and canonical values.
// No runtime type validation. Malformed input may panic, trap or corrupt state.
pub fn new()->Result<Self,String>{let logical=D_b33ecdfe8a4690fedacb7eecab9023ff7ad9362d49f46eceb5694776b7753ac4::C0(std::sync::Arc::new(D_c594ab4dd94ef6d6275c32b07708f643bdffeb3187f37318f443f9192a4e4462::C0));Ok(Self{physical:f_3d49fac84fd706ca4d2bddc3c53e21f9c8d82e8a70ee8b81def02800d29a11f7(&logical),version:0,outbox:vec![],layout:snapshot_layout()})}
pub fn restore(bytes:&[u8])->Result<Self,String>{let layout=snapshot_layout();let saved=portable::decode(&layout,bytes,SnapshotLimits::default())?;let logical=logical_from_tables(&saved.tables)?;Ok(Self{physical:f_3d49fac84fd706ca4d2bddc3c53e21f9c8d82e8a70ee8b81def02800d29a11f7(&logical),version:saved.version,outbox:saved.outbox,layout})}
pub fn checkpoint(&self)->Result<Vec<u8>,String>{let logical=f_8f8f9cf94b421df1993f5b3088dbaeb4cdbf8902174eb4cc7e959206aeb63d80(&(self.physical));portable::encode(&self.layout,&portable::Logical{version:self.version,tables:logical_tables(&logical)?,outbox:self.outbox.clone()},SnapshotLimits::default())}
pub fn version(&self)->u64{self.version}
pub fn outbox_json(&self)->Json{Json::Array(self.outbox.iter().map(|e|json!({"commit":e.commit,"position":e.position,"channel":self.layout.events[e.channel].0,"value":e.value})).collect())}
pub fn acknowledge_through(&mut self,commit:u64,position:u64){self.outbox.retain(|e|(e.commit,e.position)>(commit,position));}
pub fn query_route(&self,)->D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60{q_fd80e0a5a22cb43bd4874e05a4a453616e976167dc3d449c7de11b3d67e6eb72(&(self.physical),self.version)}
pub fn query_get(&self,a0:u64)->D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2{q_38f19433a51fb11a49e83af2a67a8238c5549ed37cdfbe13e98bdd148bac8b8d(&(self.physical),self.version,a0)}
pub fn invoke_view_put(&mut self,a0:u64,a1:&D_2c984bdc136c059c3c5556b5a32fba01b3f47212e0b8955def94b15bdd16ae1c,a2:bool)->Result<OutcomeView<'_,D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd>,String>{
let executed=f_f5a862ed3be98953915ddfce4c8d32ecbb4575d2b148fbf0b1d1bc4e6e9a8a9a(&(self.physical),self.version,a0,a1,a2);let observed=f_c9ae8314360fd86b1545c14505dc08313b35ba9b057fa47da87c0631868a13b5(&(executed));let next=f_bbd5ed7008af8380acd37020844e9c2db02554d2a7eb796bc069d4b765a1a27e(&(executed));
let(result,committed,version,events)=match &observed{D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_erase(&mut self,a0:u64,a1:bool)->Result<OutcomeView<'_,D_3b623415c29221ad5c1958d8b9c5c0ba7ef93b6e5968917197d597fad3863afd>,String>{
let executed=f_b0495dc3a518a6f02848318dcbb318a833d40709e5d01598ece43f47bc462e33(&(self.physical),self.version,a0,a1);let observed=f_c9ae8314360fd86b1545c14505dc08313b35ba9b057fa47da87c0631868a13b5(&(executed));let next=f_bbd5ed7008af8380acd37020844e9c2db02554d2a7eb796bc069d4b765a1a27e(&(executed));
let(result,committed,version,events)=match &observed{D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_route(&mut self,)->Result<OutcomeView<'_,D_d998dbeb5f3ec854fb768e3685963b0540f14a7981b6c2bf86d6f2efda9e8c60>,String>{
let result=q_fd80e0a5a22cb43bd4874e05a4a453616e976167dc3d449c7de11b3d67e6eb72(&(self.physical),self.version);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_view_get(&mut self,a0:u64)->Result<OutcomeView<'_,D_fb0b1d06fb9e936810a56a090598c38173557318720c27298afd52b597646ae2>,String>{
let result=q_38f19433a51fb11a49e83af2a67a8238c5549ed37cdfbe13e98bdd148bac8b8d(&(self.physical),self.version,a0);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_json(&mut self,name:&str,args:&Json)->Result<Json,String>{match name{
"put"=>{let xs=args.as_array().unwrap();
let a0=read_2(&xs[0],0)?;
let a1=read_11(&xs[1],0)?;
let a2=read_0(&xs[2],0)?;
let executed=f_f5a862ed3be98953915ddfce4c8d32ecbb4575d2b148fbf0b1d1bc4e6e9a8a9a(&(self.physical),self.version,a0,&(a1),a2);
let observed=f_c9ae8314360fd86b1545c14505dc08313b35ba9b057fa47da87c0631868a13b5(&(executed));let next=f_bbd5ed7008af8380acd37020844e9c2db02554d2a7eb796bc069d4b765a1a27e(&(executed));let(reply,committed,version,events)=match &observed{D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_21(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&[];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"erase"=>{let xs=args.as_array().unwrap();
let a0=read_2(&xs[0],0)?;
let a1=read_0(&xs[1],0)?;
let executed=f_b0495dc3a518a6f02848318dcbb318a833d40709e5d01598ece43f47bc462e33(&(self.physical),self.version,a0,a1);
let observed=f_c9ae8314360fd86b1545c14505dc08313b35ba9b057fa47da87c0631868a13b5(&(executed));let next=f_bbd5ed7008af8380acd37020844e9c2db02554d2a7eb796bc069d4b765a1a27e(&(executed));let(reply,committed,version,events)=match &observed{D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_7edd3a3b4ec99ccdb9b98000a919f3c520257caba3be8460c8190e51a8b098f9::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_21(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&[];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"route"=>{let xs=args.as_array().unwrap();
let reply=q_fd80e0a5a22cb43bd4874e05a4a453616e976167dc3d449c7de11b3d67e6eb72(&(self.physical),self.version);let result=write_20(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
"get"=>{let xs=args.as_array().unwrap();
let a0=read_2(&xs[0],0)?;
let reply=q_38f19433a51fb11a49e83af2a67a8238c5549ed37cdfbe13e98bdd148bac8b8d(&(self.physical),self.version,a0);let result=write_19(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
_=>Err(format!("unknown action {name}"))}}}
