// ink-definition-rust-v1: checked bodies; Rust/backend are trusted.
#![allow(non_camel_case_types, non_snake_case, non_upper_case_globals, dead_code, unused_variables, unused_parens, unused_unsafe, improper_ctypes_definitions)]
fn d_032a364e8a34afe888b5d9fed35bb97982af66f07c2416efa23fa10b5237ae78(v0: &D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137) -> D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02 { match v0 { D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(v1,v2) => { (v2.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137 { C0(std::sync::Arc<D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309>,std::sync::Arc<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>) }
fn d_0900fba64a35ccd23b12d65b9242aea97f99a8aed476ca57bd06b8388e4cb3ad(v3: &D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509,v4: u64) -> D_4d1049a47004c682dcf4717c72a504f6a1142daa6269909aa545b5f38784fb83 { D_4d1049a47004c682dcf4717c72a504f6a1142daa6269909aa545b5f38784fb83::C0(std::sync::Arc::new(d_11f378157b6afd30b3f86407e42418d8dba81e613bcd30cae824ec555ec68624(&(match v3 { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v5) => { (v5.as_ref()).clone() } }),0u64)),false,v4,std::sync::Arc::new((v3).clone()),std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0))})) }
fn d_0c9452de974f4e5b2178ff221a5a6eb52bfb4c4a7f1dd4e653a83f494b0b7239(v7: &D_ee3d9aaeddca35ac200632aed38110428546945c6219e3196487a040eec1a20f) -> D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137 { match v7 { D_ee3d9aaeddca35ac200632aed38110428546945c6219e3196487a040eec1a20f::C0(v8,v9) => { (v8.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_0d78b1d5938a72f4e766aa53b436ed45f19108f0ed45fcc47a2afacbb60c1daf { C0(std::sync::Arc<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,std::sync::Arc<D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98>) }
fn d_11f378157b6afd30b3f86407e42418d8dba81e613bcd30cae824ec555ec68624(v10: &D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309,v11: u64) -> D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef { match v10 { D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C0 => { D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C0 },D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C1(v13,v14,v15) => { if ((v11) == (*v13)) { D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C1(std::sync::Arc::clone(v14)) } else { d_11f378157b6afd30b3f86407e42418d8dba81e613bcd30cae824ec555ec68624(v15.as_ref(),v11) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509 { C0(std::sync::Arc<D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20 { C0,C1(std::sync::Arc<D_fc426eef7c3c750934cf861b3cee7a9e903d1ec0fb7cb0c93810522138fe3beb>,std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>) }
impl D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_1f614a08186a45a711e098ccd0c9d9749f5cb68022b0d297e1cb0671c692d8d6(v16: &D_602b08d99f472b9ea6d552fcf3c0abbd7646c403544e5f16162b7a3ef57bd71d,v17: &D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98) -> D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137 { match v16 { D_602b08d99f472b9ea6d552fcf3c0abbd7646c403544e5f16162b7a3ef57bd71d::C0(v18,v19) => { match v17 { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(v20,v21,v22,v23,v24) => { if *v21 { match v23.as_ref() { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v25) => { D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(std::sync::Arc::clone(v25),std::sync::Arc::clone(v19)) } } } else { match v23.as_ref() { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v26) => { D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(std::sync::Arc::clone(v26),std::sync::Arc::clone(v18)) } } } },D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(v27,v28,v29) => { match v29.as_ref() { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v30) => { D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(std::sync::Arc::clone(v30),std::sync::Arc::clone(v18)) } } } } } } }
fn d_2383bd4d7012fe43708ac92db7cdbc59f45e8f850ad075363ddcdff1f1354d67(v31: &D_888e96714649850029c3ccf57c839df807b5be39c96364755bc2d73fbb20f3f0) -> D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137 { match v31 { D_888e96714649850029c3ccf57c839df807b5be39c96364755bc2d73fbb20f3f0::C0(v32,v33) => { d_1f614a08186a45a711e098ccd0c9d9749f5cb68022b0d297e1cb0671c692d8d6(v32.as_ref(),v33.as_ref()) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_2599767f63dfd7fae6a8c59296739abd402fc8c73e9ffa2f37e6426257ca00f0 { C0(std::sync::Arc<D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309 { C0,C1(u64,std::sync::Arc<D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b>,std::sync::Arc<D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309>) }
impl D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_26dfac283d58899a8ed6701369293027cbeb88cb4084bcd60cfdeb7ac1427941(v34: &D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509,v35: u64,v36: u64,v37: bool) -> D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98 { match &(D_2599767f63dfd7fae6a8c59296739abd402fc8c73e9ffa2f37e6426257ca00f0::C0(std::sync::Arc::new(match &(d_11f378157b6afd30b3f86407e42418d8dba81e613bcd30cae824ec555ec68624(&(match v34 { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v38) => { (v38.as_ref()).clone() } }),0u64)) { D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C0 => { D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b::C0(0u64,0u64) },D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C1(v40) => { (v40.as_ref()).clone() } }))) { D_2599767f63dfd7fae6a8c59296739abd402fc8c73e9ffa2f37e6426257ca00f0::C0(v41) => { if d_6be7bd8a0c89986cc25117ee9589091dc6a9c867ab20cb3bee70ee55446bf688(&(match v34 { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v42) => { (v42.as_ref()).clone() } }),0u64) { if d_6be7bd8a0c89986cc25117ee9589091dc6a9c867ab20cb3bee70ee55446bf688(&(match v34 { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v43) => { (v43.as_ref()).clone() } }),0u64) { match &(D_27213b95d6b4652ea993843c7bc51f65b2ef4ad833e91df9c90a2be75236756d::C0(std::sync::Arc::new(match v34 { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v44) => { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(std::sync::Arc::new(d_78aa0f6f85ba82af01da5288d7ece86ad59961ec219dcbd447a96aed746728f1(&(match v34 { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v45) => { (v45.as_ref()).clone() } }),0u64,&(D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b::C0(match v41.as_ref() { D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b::C0(v46,v47) => { *v46 } },v36))))) } }))) { D_27213b95d6b4652ea993843c7bc51f65b2ef4ad833e91df9c90a2be75236756d::C0(v48) => { match &(D_35dab86c92f51804ed80bac666a1b55fb30abe60bad88831aad3c0fd9286c058::C0(std::sync::Arc::new(d_4145259ab456e3822eb12c401ead834afed768fa6c453d2d0b2f9f1baa7c8cda(&(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0),&(D_fc426eef7c3c750934cf861b3cee7a9e903d1ec0fb7cb0c93810522138fe3beb::C0(v36)))))) { D_35dab86c92f51804ed80bac666a1b55fb30abe60bad88831aad3c0fd9286c058::C0(v50) => { if v37 { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v51:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v51.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v53) => { if ((v35) == (18446744073709551615u64)) { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(1u64,v35,std::sync::Arc::new((v34).clone())) } else { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v53))),true,(v35).wrapping_add(1u64),std::sync::Arc::clone(v48),std::sync::Arc::clone(v50)) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v54) => { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v54))),false,v35,std::sync::Arc::new((v34).clone()),std::sync::Arc::clone({static v55:std::sync::OnceLock<std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>>=std::sync::OnceLock::new();v55.get_or_init(||std::sync::Arc::new(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0))})) } } } else { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v56:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v56.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v58) => { if ((v35) == (18446744073709551615u64)) { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(1u64,v35,std::sync::Arc::new((v34).clone())) } else { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v58))),true,(v35).wrapping_add(1u64),std::sync::Arc::clone(v48),std::sync::Arc::clone(v50)) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v59) => { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v59))),false,v35,std::sync::Arc::new((v34).clone()),std::sync::Arc::clone({static v60:std::sync::OnceLock<std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>>=std::sync::OnceLock::new();v60.get_or_init(||std::sync::Arc::new(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0))})) } } } } } } } } else { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(2u64,v35,std::sync::Arc::new((v34).clone())) } } else { match &(D_35dab86c92f51804ed80bac666a1b55fb30abe60bad88831aad3c0fd9286c058::C0(std::sync::Arc::new(d_4145259ab456e3822eb12c401ead834afed768fa6c453d2d0b2f9f1baa7c8cda(&(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0),&(D_fc426eef7c3c750934cf861b3cee7a9e903d1ec0fb7cb0c93810522138fe3beb::C0(v36)))))) { D_35dab86c92f51804ed80bac666a1b55fb30abe60bad88831aad3c0fd9286c058::C0(v62) => { if v37 { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v63:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v63.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v65) => { if ((v35) == (18446744073709551615u64)) { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(1u64,v35,std::sync::Arc::new((v34).clone())) } else { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v65))),true,(v35).wrapping_add(1u64),std::sync::Arc::new((v34).clone()),std::sync::Arc::clone(v62)) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v66) => { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v66))),false,v35,std::sync::Arc::new((v34).clone()),std::sync::Arc::clone({static v67:std::sync::OnceLock<std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>>=std::sync::OnceLock::new();v67.get_or_init(||std::sync::Arc::new(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0))})) } } } else { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v68:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v68.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v70) => { if ((v35) == (18446744073709551615u64)) { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(1u64,v35,std::sync::Arc::new((v34).clone())) } else { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v70))),true,(v35).wrapping_add(1u64),std::sync::Arc::new((v34).clone()),std::sync::Arc::clone(v62)) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v71) => { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v71))),false,v35,std::sync::Arc::new((v34).clone()),std::sync::Arc::clone({static v72:std::sync::OnceLock<std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>>=std::sync::OnceLock::new();v72.get_or_init(||std::sync::Arc::new(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0))})) } } } } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_27213b95d6b4652ea993843c7bc51f65b2ef4ad833e91df9c90a2be75236756d { C0(std::sync::Arc<D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98 { C0(std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,bool,u64,std::sync::Arc<D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509>,std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>),C1(u64,u64,std::sync::Arc<D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509>) }
fn d_353f09c226d31be205942e7b2ef21dc7e88942ba9cc70f9a2db4aea5af8c47b5(v73: &D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137,v74: u64,v75: u64,v76: bool) -> D_888e96714649850029c3ccf57c839df807b5be39c96364755bc2d73fbb20f3f0 { D_888e96714649850029c3ccf57c839df807b5be39c96364755bc2d73fbb20f3f0::C0(std::sync::Arc::new(match v73 { D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(v77,v78) => { D_602b08d99f472b9ea6d552fcf3c0abbd7646c403544e5f16162b7a3ef57bd71d::C0(std::sync::Arc::clone(v78),std::sync::Arc::clone(v78)) } }),std::sync::Arc::new(d_26dfac283d58899a8ed6701369293027cbeb88cb4084bcd60cfdeb7ac1427941(&(d_8d859b516f09d0102733c638cef1c2be93f67be7c7ccf64e306addb6d4e3674c(v73)),v74,v75,v76))) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_35dab86c92f51804ed80bac666a1b55fb30abe60bad88831aad3c0fd9286c058 { C0(std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_3c52607eabb6810be3176db1e4e8d0232c421864cac351ce6ea360fc2b4d0663 { C0(std::sync::Arc<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,bool,u64,std::sync::Arc<D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509>,std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>),C1(u64,u64,std::sync::Arc<D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_3dc578d87eac27804493752682c292176f98cf6674f0f7891d92c6ef06223ec9 { C0(std::sync::Arc<D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137>,std::sync::Arc<D_3c52607eabb6810be3176db1e4e8d0232c421864cac351ce6ea360fc2b4d0663>) }
fn d_4145259ab456e3822eb12c401ead834afed768fa6c453d2d0b2f9f1baa7c8cda(v79: &D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20,v80: &D_fc426eef7c3c750934cf861b3cee7a9e903d1ec0fb7cb0c93810522138fe3beb) -> D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20 { match v79 { D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0 => { D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C1(std::sync::Arc::new((v80).clone()),std::sync::Arc::clone({static v81:std::sync::OnceLock<std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>>=std::sync::OnceLock::new();v81.get_or_init(||std::sync::Arc::new(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0))})) },D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C1(v82,v83) => { D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C1(std::sync::Arc::clone(v82),std::sync::Arc::new(d_4145259ab456e3822eb12c401ead834afed768fa6c453d2d0b2f9f1baa7c8cda(v83.as_ref(),v80))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef { C0,C1(std::sync::Arc<D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b>) }
fn d_4befcac2cc4e51504d3d48a463be5cae4fc0a56c8ef57f474457ed59b7c0112a(v84: &D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509) -> D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137 { match v84 { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v85) => { D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(std::sync::Arc::clone(v85),std::sync::Arc::new(match &(d_11f378157b6afd30b3f86407e42418d8dba81e613bcd30cae824ec555ec68624(v85.as_ref(),0u64)) { D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C0 => { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 },D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C1(v87) => { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(match v87.as_ref() { D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b::C0(v88,v89) => { *v88 } }) } })) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_4d1049a47004c682dcf4717c72a504f6a1142daa6269909aa545b5f38784fb83 { C0(std::sync::Arc<D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef>,bool,u64,std::sync::Arc<D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509>,std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>),C1(u64,u64,std::sync::Arc<D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509>) }
fn d_4db9ce74c132da1855368a774cbbd015cace74d7b3627b2ab0e67d4e1a9e6c1d(v90: &D_3dc578d87eac27804493752682c292176f98cf6674f0f7891d92c6ef06223ec9) -> D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137 { match v90 { D_3dc578d87eac27804493752682c292176f98cf6674f0f7891d92c6ef06223ec9::C0(v91,v92) => { (v91.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_602b08d99f472b9ea6d552fcf3c0abbd7646c403544e5f16162b7a3ef57bd71d { C0(std::sync::Arc<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,std::sync::Arc<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>) }
fn d_62b044ffba65d4309923acbb82370519117374f99e6948877d253b52a094e92a(v93: &D_ee3d9aaeddca35ac200632aed38110428546945c6219e3196487a040eec1a20f) -> D_4d1049a47004c682dcf4717c72a504f6a1142daa6269909aa545b5f38784fb83 { match v93 { D_ee3d9aaeddca35ac200632aed38110428546945c6219e3196487a040eec1a20f::C0(v94,v95) => { (v95.as_ref()).clone() } } }
fn d_640d7da843a469d516ae50e7370b56756d2c6a7ebaf9d6a94014c86ecbeafdfc(v96: &D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137,v97: u64) -> D_3dc578d87eac27804493752682c292176f98cf6674f0f7891d92c6ef06223ec9 { match v96 { D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(v98,v99) => { D_3dc578d87eac27804493752682c292176f98cf6674f0f7891d92c6ef06223ec9::C0(std::sync::Arc::new((v96).clone()),std::sync::Arc::new(D_3c52607eabb6810be3176db1e4e8d0232c421864cac351ce6ea360fc2b4d0663::C0(std::sync::Arc::clone(v99),false,v97,std::sync::Arc::new(D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(std::sync::Arc::clone(v98))),std::sync::Arc::clone({static v100:std::sync::OnceLock<std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>>=std::sync::OnceLock::new();v100.get_or_init(||std::sync::Arc::new(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0))})))) } } }
fn d_6aa13a62c49816c4fe39d82705720ac9cbe8f598ec146dcaadb2365bd4499da4(v101: &D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02,v102: &D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98) -> D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137 { match v102 { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(v103,v104,v105,v106,v107) => { if *v104 { d_4befcac2cc4e51504d3d48a463be5cae4fc0a56c8ef57f474457ed59b7c0112a(v106.as_ref()) } else { match v106.as_ref() { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v108) => { D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(std::sync::Arc::clone(v108),std::sync::Arc::new((v101).clone())) } } } },D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(v109,v110,v111) => { match v111.as_ref() { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v112) => { D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(std::sync::Arc::clone(v112),std::sync::Arc::new((v101).clone())) } } } } }
fn d_6be7bd8a0c89986cc25117ee9589091dc6a9c867ab20cb3bee70ee55446bf688(v113: &D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309,v114: u64) -> bool { match &(d_11f378157b6afd30b3f86407e42418d8dba81e613bcd30cae824ec555ec68624(v113,v114)) { D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C0 => { false },D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C1(v115) => { true } } }
fn d_78aa0f6f85ba82af01da5288d7ece86ad59961ec219dcbd447a96aed746728f1(v116: &D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309,v117: u64,v118: &D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b) -> D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309 { match v116 { D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C0 => { D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C0 },D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C1(v120,v121,v122) => { D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C1(*v120,std::sync::Arc::new(if ((v117) == (*v120)) { (v118).clone() } else { (v121.as_ref()).clone() }),std::sync::Arc::new(d_78aa0f6f85ba82af01da5288d7ece86ad59961ec219dcbd447a96aed746728f1(v122.as_ref(),v117,v118))) } } }
fn d_85b72909ebbc9f3efd2a7c30b02be71454508361b9696d1777310a56c9f53ada(v123: &D_888e96714649850029c3ccf57c839df807b5be39c96364755bc2d73fbb20f3f0) -> D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98 { match v123 { D_888e96714649850029c3ccf57c839df807b5be39c96364755bc2d73fbb20f3f0::C0(v124,v125) => { (v125.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_888e96714649850029c3ccf57c839df807b5be39c96364755bc2d73fbb20f3f0 { C0(std::sync::Arc<D_602b08d99f472b9ea6d552fcf3c0abbd7646c403544e5f16162b7a3ef57bd71d>,std::sync::Arc<D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98>) }
fn d_8d859b516f09d0102733c638cef1c2be93f67be7c7ccf64e306addb6d4e3674c(v126: &D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137) -> D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509 { match v126 { D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(v127,v128) => { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(std::sync::Arc::clone(v127)) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f { C0(std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>),C1(std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>) }
fn d_a00de82c5d5cc6f736811b0d6c5a58f99998ba771cc4f49d6f41b1dc0a3f3e03(v129: &D_3dc578d87eac27804493752682c292176f98cf6674f0f7891d92c6ef06223ec9) -> D_3c52607eabb6810be3176db1e4e8d0232c421864cac351ce6ea360fc2b4d0663 { match v129 { D_3dc578d87eac27804493752682c292176f98cf6674f0f7891d92c6ef06223ec9::C0(v130,v131) => { (v131.as_ref()).clone() } } }
fn d_a1dc870d7d48dc12c6703fe7b7aa507f8adfa036f46b4bf733e004e5594adbe1(v132: &D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309,v133: u64,v134: &D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b) -> D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309 { match v132 { D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C0 => { D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C1(v133,std::sync::Arc::new((v134).clone()),std::sync::Arc::clone({static v135:std::sync::OnceLock<std::sync::Arc<D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309>>=std::sync::OnceLock::new();v135.get_or_init(||std::sync::Arc::new(D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C0))})) },D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C1(v136,v137,v138) => { if ((v133) < (*v136)) { D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C1(v133,std::sync::Arc::new((v134).clone()),std::sync::Arc::new((v132).clone())) } else { D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C1(*v136,std::sync::Arc::clone(v137),std::sync::Arc::new(d_a1dc870d7d48dc12c6703fe7b7aa507f8adfa036f46b4bf733e004e5594adbe1(v138.as_ref(),v133,v134))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02 { C0,C1(u64) }
fn d_b389e407b941ff048508dbefa8df3b5fa3bb5ee7b9441f4ddba0e25a20818dd5(v139: &D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137,v140: u64) -> D_ee3d9aaeddca35ac200632aed38110428546945c6219e3196487a040eec1a20f { D_ee3d9aaeddca35ac200632aed38110428546945c6219e3196487a040eec1a20f::C0(std::sync::Arc::new((v139).clone()),std::sync::Arc::new(d_0900fba64a35ccd23b12d65b9242aea97f99a8aed476ca57bd06b8388e4cb3ad(&(d_8d859b516f09d0102733c638cef1c2be93f67be7c7ccf64e306addb6d4e3674c(v139)),v140))) }
fn d_b9eaec0e1d831f7f70b6447dcc8f9a793e89e8764cbc185440ff4d8043495000(v141: &D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137,v142: u64,v143: u64,v144: u64) -> D_0d78b1d5938a72f4e766aa53b436ed45f19108f0ed45fcc47a2afacbb60c1daf { D_0d78b1d5938a72f4e766aa53b436ed45f19108f0ed45fcc47a2afacbb60c1daf::C0(std::sync::Arc::new(d_032a364e8a34afe888b5d9fed35bb97982af66f07c2416efa23fa10b5237ae78(v141)),std::sync::Arc::new(d_c9aff5947c1d8c65af5342a5ef61d3b54125f3012159564bee504f4a4474bc25(&(d_8d859b516f09d0102733c638cef1c2be93f67be7c7ccf64e306addb6d4e3674c(v141)),v142,v143,v144))) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c { C0 }
impl D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b { C0 }
impl D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_c9aff5947c1d8c65af5342a5ef61d3b54125f3012159564bee504f4a4474bc25(v145: &D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509,v146: u64,v147: u64,v148: u64) -> D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98 { match &(D_27213b95d6b4652ea993843c7bc51f65b2ef4ad833e91df9c90a2be75236756d::C0(std::sync::Arc::new(match v145 { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v149) => { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(std::sync::Arc::new(d_fc41573696e0f613a2331c5e0ac0058151c9d9ee4fade12a544a0d20704603ed(&(match v145 { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v150) => { (v150.as_ref()).clone() } }),0u64))) } }))) { D_27213b95d6b4652ea993843c7bc51f65b2ef4ad833e91df9c90a2be75236756d::C0(v151) => { if d_6be7bd8a0c89986cc25117ee9589091dc6a9c867ab20cb3bee70ee55446bf688(&(match v151.as_ref() { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v152) => { (v152.as_ref()).clone() } }),0u64) { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(2u64,v146,std::sync::Arc::new((v145).clone())) } else { match &(D_27213b95d6b4652ea993843c7bc51f65b2ef4ad833e91df9c90a2be75236756d::C0(std::sync::Arc::new(match v151.as_ref() { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v153) => { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(std::sync::Arc::new(d_a1dc870d7d48dc12c6703fe7b7aa507f8adfa036f46b4bf733e004e5594adbe1(&(match v151.as_ref() { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v154) => { (v154.as_ref()).clone() } }),0u64,&(D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b::C0(v147,v148))))) } }))) { D_27213b95d6b4652ea993843c7bc51f65b2ef4ad833e91df9c90a2be75236756d::C0(v155) => { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v156:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v156.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v158) => { if ((v146) == (18446744073709551615u64)) { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(1u64,v146,std::sync::Arc::new((v145).clone())) } else { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v158))),true,(v146).wrapping_add(1u64),std::sync::Arc::clone(v155),std::sync::Arc::clone({static v159:std::sync::OnceLock<std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>>=std::sync::OnceLock::new();v159.get_or_init(||std::sync::Arc::new(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0))})) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v160) => { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v160))),false,v146,std::sync::Arc::new((v145).clone()),std::sync::Arc::clone({static v161:std::sync::OnceLock<std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>>=std::sync::OnceLock::new();v161.get_or_init(||std::sync::Arc::new(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0))})) } } } } } } } }
fn d_cabad30d24ac7dab792243485e30fcba3ce2ab742c1a83b8bb04ae880ef1530b(v162: &D_0d78b1d5938a72f4e766aa53b436ed45f19108f0ed45fcc47a2afacbb60c1daf) -> D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137 { match v162 { D_0d78b1d5938a72f4e766aa53b436ed45f19108f0ed45fcc47a2afacbb60c1daf::C0(v163,v164) => { d_6aa13a62c49816c4fe39d82705720ac9cbe8f598ec146dcaadb2365bd4499da4(v163.as_ref(),v164.as_ref()) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b { C0(u64,u64) }
fn d_ed4ffe1eb66254bf4ba6309e33708db25573c1f6925351cbb8825c2ef8c8e786(v165: &D_0d78b1d5938a72f4e766aa53b436ed45f19108f0ed45fcc47a2afacbb60c1daf) -> D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98 { match v165 { D_0d78b1d5938a72f4e766aa53b436ed45f19108f0ed45fcc47a2afacbb60c1daf::C0(v166,v167) => { (v167.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ee3d9aaeddca35ac200632aed38110428546945c6219e3196487a040eec1a20f { C0(std::sync::Arc<D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137>,std::sync::Arc<D_4d1049a47004c682dcf4717c72a504f6a1142daa6269909aa545b5f38784fb83>) }
fn d_f034536be086f5136c211b786fdfe802d3be37ccbeb3a5d60db76870d0028c02(v168: &D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509,v169: u64,v170: u64) -> D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98 { match &(D_2599767f63dfd7fae6a8c59296739abd402fc8c73e9ffa2f37e6426257ca00f0::C0(std::sync::Arc::new(match &(d_11f378157b6afd30b3f86407e42418d8dba81e613bcd30cae824ec555ec68624(&(match v168 { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v171) => { (v171.as_ref()).clone() } }),0u64)) { D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C0 => { D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b::C0(0u64,0u64) },D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C1(v173) => { (v173.as_ref()).clone() } }))) { D_2599767f63dfd7fae6a8c59296739abd402fc8c73e9ffa2f37e6426257ca00f0::C0(v174) => { if d_6be7bd8a0c89986cc25117ee9589091dc6a9c867ab20cb3bee70ee55446bf688(&(match v168 { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v175) => { (v175.as_ref()).clone() } }),0u64) { if d_6be7bd8a0c89986cc25117ee9589091dc6a9c867ab20cb3bee70ee55446bf688(&(match v168 { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v176) => { (v176.as_ref()).clone() } }),0u64) { match &(D_27213b95d6b4652ea993843c7bc51f65b2ef4ad833e91df9c90a2be75236756d::C0(std::sync::Arc::new(match v168 { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v177) => { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(std::sync::Arc::new(d_78aa0f6f85ba82af01da5288d7ece86ad59961ec219dcbd447a96aed746728f1(&(match v168 { D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(v178) => { (v178.as_ref()).clone() } }),0u64,&(D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b::C0(v170,match v174.as_ref() { D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b::C0(v179,v180) => { *v180 } }))))) } }))) { D_27213b95d6b4652ea993843c7bc51f65b2ef4ad833e91df9c90a2be75236756d::C0(v181) => { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v182:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v182.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v184) => { if ((v169) == (18446744073709551615u64)) { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(1u64,v169,std::sync::Arc::new((v168).clone())) } else { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v184))),true,(v169).wrapping_add(1u64),std::sync::Arc::clone(v181),std::sync::Arc::clone({static v185:std::sync::OnceLock<std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>>=std::sync::OnceLock::new();v185.get_or_init(||std::sync::Arc::new(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0))})) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v186) => { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v186))),false,v169,std::sync::Arc::new((v168).clone()),std::sync::Arc::clone({static v187:std::sync::OnceLock<std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>>=std::sync::OnceLock::new();v187.get_or_init(||std::sync::Arc::new(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0))})) } } } } } else { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(2u64,v169,std::sync::Arc::new((v168).clone())) } } else { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v188:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v188.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v190) => { if ((v169) == (18446744073709551615u64)) { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(1u64,v169,std::sync::Arc::new((v168).clone())) } else { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v190))),true,(v169).wrapping_add(1u64),std::sync::Arc::new((v168).clone()),std::sync::Arc::clone({static v191:std::sync::OnceLock<std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>>=std::sync::OnceLock::new();v191.get_or_init(||std::sync::Arc::new(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0))})) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v192) => { D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v192))),false,v169,std::sync::Arc::new((v168).clone()),std::sync::Arc::clone({static v193:std::sync::OnceLock<std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>>=std::sync::OnceLock::new();v193.get_or_init(||std::sync::Arc::new(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0))})) } } } } } }
fn d_fbc3e6fa8037535c617459131bd4e0a5597fba0831a126187465f70be1f2f9a8(v194: &D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137,v195: u64,v196: u64) -> D_888e96714649850029c3ccf57c839df807b5be39c96364755bc2d73fbb20f3f0 { D_888e96714649850029c3ccf57c839df807b5be39c96364755bc2d73fbb20f3f0::C0(std::sync::Arc::new(match v194 { D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(v197,v198) => { D_602b08d99f472b9ea6d552fcf3c0abbd7646c403544e5f16162b7a3ef57bd71d::C0(std::sync::Arc::clone(v198),std::sync::Arc::new(if match &(d_11f378157b6afd30b3f86407e42418d8dba81e613bcd30cae824ec555ec68624(v197.as_ref(),0u64)) { D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C0 => { false },D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C1(v199) => { true } } { if match &(d_11f378157b6afd30b3f86407e42418d8dba81e613bcd30cae824ec555ec68624(v197.as_ref(),0u64)) { D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C0 => { false },D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C1(v200) => { true } } { if ((v195) == (18446744073709551615u64)) { (v198.as_ref()).clone() } else { match v198.as_ref() { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v202) => { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(match &(D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b::C0(v196,match &(match &(d_11f378157b6afd30b3f86407e42418d8dba81e613bcd30cae824ec555ec68624(v197.as_ref(),0u64)) { D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C0 => { D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b::C0(0u64,0u64) },D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C1(v204) => { (v204.as_ref()).clone() } }) { D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b::C0(v205,v206) => { *v206 } })) { D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b::C0(v207,v208) => { *v207 } }) } } } } else { (v198.as_ref()).clone() } } else { (v198.as_ref()).clone() })) } }),std::sync::Arc::new(d_f034536be086f5136c211b786fdfe802d3be37ccbeb3a5d60db76870d0028c02(&(d_8d859b516f09d0102733c638cef1c2be93f67be7c7ccf64e306addb6d4e3674c(v194)),v195,v196))) }
fn d_fc41573696e0f613a2331c5e0ac0058151c9d9ee4fade12a544a0d20704603ed(v209: &D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309,v210: u64) -> D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309 { match v209 { D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C0 => { D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C0 },D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C1(v212,v213,v214) => { if ((v210) == (*v212)) { d_fc41573696e0f613a2331c5e0ac0058151c9d9ee4fade12a544a0d20704603ed(v214.as_ref(),v210) } else { D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C1(*v212,std::sync::Arc::clone(v213),std::sync::Arc::new(d_fc41573696e0f613a2331c5e0ac0058151c9d9ee4fade12a544a0d20704603ed(v214.as_ref(),v210))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_fc426eef7c3c750934cf861b3cee7a9e903d1ec0fb7cb0c93810522138fe3beb { C0(u64) }
pub fn f_0c9452de974f4e5b2178ff221a5a6eb52bfb4c4a7f1dd4e653a83f494b0b7239(v215: &D_ee3d9aaeddca35ac200632aed38110428546945c6219e3196487a040eec1a20f) -> D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137 { d_0c9452de974f4e5b2178ff221a5a6eb52bfb4c4a7f1dd4e653a83f494b0b7239(v215) }
pub fn f_2383bd4d7012fe43708ac92db7cdbc59f45e8f850ad075363ddcdff1f1354d67(v216: &D_888e96714649850029c3ccf57c839df807b5be39c96364755bc2d73fbb20f3f0) -> D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137 { d_2383bd4d7012fe43708ac92db7cdbc59f45e8f850ad075363ddcdff1f1354d67(v216) }
pub fn f_353f09c226d31be205942e7b2ef21dc7e88942ba9cc70f9a2db4aea5af8c47b5(v217: &D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137,v218: u64,v219: u64,v220: bool) -> D_888e96714649850029c3ccf57c839df807b5be39c96364755bc2d73fbb20f3f0 { d_353f09c226d31be205942e7b2ef21dc7e88942ba9cc70f9a2db4aea5af8c47b5(v217,v218,v219,v220) }
pub fn f_4befcac2cc4e51504d3d48a463be5cae4fc0a56c8ef57f474457ed59b7c0112a(v221: &D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509) -> D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137 { d_4befcac2cc4e51504d3d48a463be5cae4fc0a56c8ef57f474457ed59b7c0112a(v221) }
pub fn f_4db9ce74c132da1855368a774cbbd015cace74d7b3627b2ab0e67d4e1a9e6c1d(v222: &D_3dc578d87eac27804493752682c292176f98cf6674f0f7891d92c6ef06223ec9) -> D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137 { d_4db9ce74c132da1855368a774cbbd015cace74d7b3627b2ab0e67d4e1a9e6c1d(v222) }
pub fn f_62b044ffba65d4309923acbb82370519117374f99e6948877d253b52a094e92a(v223: &D_ee3d9aaeddca35ac200632aed38110428546945c6219e3196487a040eec1a20f) -> D_4d1049a47004c682dcf4717c72a504f6a1142daa6269909aa545b5f38784fb83 { d_62b044ffba65d4309923acbb82370519117374f99e6948877d253b52a094e92a(v223) }
pub fn f_640d7da843a469d516ae50e7370b56756d2c6a7ebaf9d6a94014c86ecbeafdfc(v224: &D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137,v225: u64) -> D_3dc578d87eac27804493752682c292176f98cf6674f0f7891d92c6ef06223ec9 { d_640d7da843a469d516ae50e7370b56756d2c6a7ebaf9d6a94014c86ecbeafdfc(v224,v225) }
pub fn f_85b72909ebbc9f3efd2a7c30b02be71454508361b9696d1777310a56c9f53ada(v226: &D_888e96714649850029c3ccf57c839df807b5be39c96364755bc2d73fbb20f3f0) -> D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98 { d_85b72909ebbc9f3efd2a7c30b02be71454508361b9696d1777310a56c9f53ada(v226) }
pub fn f_8d859b516f09d0102733c638cef1c2be93f67be7c7ccf64e306addb6d4e3674c(v227: &D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137) -> D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509 { d_8d859b516f09d0102733c638cef1c2be93f67be7c7ccf64e306addb6d4e3674c(v227) }
pub fn f_a00de82c5d5cc6f736811b0d6c5a58f99998ba771cc4f49d6f41b1dc0a3f3e03(v228: &D_3dc578d87eac27804493752682c292176f98cf6674f0f7891d92c6ef06223ec9) -> D_3c52607eabb6810be3176db1e4e8d0232c421864cac351ce6ea360fc2b4d0663 { d_a00de82c5d5cc6f736811b0d6c5a58f99998ba771cc4f49d6f41b1dc0a3f3e03(v228) }
pub fn f_b389e407b941ff048508dbefa8df3b5fa3bb5ee7b9441f4ddba0e25a20818dd5(v229: &D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137,v230: u64) -> D_ee3d9aaeddca35ac200632aed38110428546945c6219e3196487a040eec1a20f { d_b389e407b941ff048508dbefa8df3b5fa3bb5ee7b9441f4ddba0e25a20818dd5(v229,v230) }
pub fn f_b9eaec0e1d831f7f70b6447dcc8f9a793e89e8764cbc185440ff4d8043495000(v231: &D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137,v232: u64,v233: u64,v234: u64) -> D_0d78b1d5938a72f4e766aa53b436ed45f19108f0ed45fcc47a2afacbb60c1daf { d_b9eaec0e1d831f7f70b6447dcc8f9a793e89e8764cbc185440ff4d8043495000(v231,v232,v233,v234) }
pub fn f_cabad30d24ac7dab792243485e30fcba3ce2ab742c1a83b8bb04ae880ef1530b(v235: &D_0d78b1d5938a72f4e766aa53b436ed45f19108f0ed45fcc47a2afacbb60c1daf) -> D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137 { d_cabad30d24ac7dab792243485e30fcba3ce2ab742c1a83b8bb04ae880ef1530b(v235) }
pub fn f_ed4ffe1eb66254bf4ba6309e33708db25573c1f6925351cbb8825c2ef8c8e786(v236: &D_0d78b1d5938a72f4e766aa53b436ed45f19108f0ed45fcc47a2afacbb60c1daf) -> D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98 { d_ed4ffe1eb66254bf4ba6309e33708db25573c1f6925351cbb8825c2ef8c8e786(v236) }
pub fn f_fbc3e6fa8037535c617459131bd4e0a5597fba0831a126187465f70be1f2f9a8(v237: &D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137,v238: u64,v239: u64) -> D_888e96714649850029c3ccf57c839df807b5be39c96364755bc2d73fbb20f3f0 { d_fbc3e6fa8037535c617459131bd4e0a5597fba0831a126187465f70be1f2f9a8(v237,v238,v239) }
fn q_640d7da843a469d516ae50e7370b56756d2c6a7ebaf9d6a94014c86ecbeafdfc(v0:&D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137,v1:u64)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{match v0 { D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(v2,v3) => { (v3.as_ref()).clone() } }}
fn q_b389e407b941ff048508dbefa8df3b5fa3bb5ee7b9441f4ddba0e25a20818dd5(v0:&D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137,v1:u64)->D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef{match v0 { D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(v2,v3) => { d_11f378157b6afd30b3f86407e42418d8dba81e613bcd30cae824ec555ec68624(v2.as_ref(),0u64) } }}
fn t_640d7da843a469d516ae50e7370b56756d2c6a7ebaf9d6a94014c86ecbeafdfc(v0:&D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137,v1:u64)->D_3dc578d87eac27804493752682c292176f98cf6674f0f7891d92c6ef06223ec9{match v0 { D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(v2,v3) => { D_3dc578d87eac27804493752682c292176f98cf6674f0f7891d92c6ef06223ec9::C0(std::sync::Arc::new(D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(std::sync::Arc::clone(v2),std::sync::Arc::clone(v3))),std::sync::Arc::new(D_3c52607eabb6810be3176db1e4e8d0232c421864cac351ce6ea360fc2b4d0663::C0(std::sync::Arc::clone(v3),false,v1,std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(std::sync::Arc::clone({static v4:std::sync::OnceLock<std::sync::Arc<D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309>>=std::sync::OnceLock::new();v4.get_or_init(||std::sync::Arc::new(D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C0))}))))}),std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0))})))) } }}
fn t_b389e407b941ff048508dbefa8df3b5fa3bb5ee7b9441f4ddba0e25a20818dd5(v0:&D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137,v1:u64)->D_ee3d9aaeddca35ac200632aed38110428546945c6219e3196487a040eec1a20f{match v0 { D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(v2,v3) => { D_ee3d9aaeddca35ac200632aed38110428546945c6219e3196487a040eec1a20f::C0(std::sync::Arc::new(D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137::C0(std::sync::Arc::clone(v2),std::sync::Arc::clone(v3))),std::sync::Arc::new(D_4d1049a47004c682dcf4717c72a504f6a1142daa6269909aa545b5f38784fb83::C0(std::sync::Arc::new(d_11f378157b6afd30b3f86407e42418d8dba81e613bcd30cae824ec555ec68624(v2.as_ref(),0u64)),false,v1,std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(std::sync::Arc::clone({static v4:std::sync::OnceLock<std::sync::Arc<D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309>>=std::sync::OnceLock::new();v4.get_or_init(||std::sync::Arc::new(D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C0))}))))}),std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0))})))) } }}

use serde_json::{Value as Json,json};
mod portable{
//! Shared, representation-independent snapshot codec. This module also ships
//! verbatim in generated applications; it has no AST/evaluator dependency.
use num_bigint::{BigInt, Sign};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::cmp::Ordering;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Schema {
    Unit,
    Bool,
    U32,
    U64,
    I32,
    F32,
    Vector(Box<Schema>, u8),
    Int,
    String,
    Id,
    Record(Vec<(String, Schema)>),
    Enum(Vec<String>),
    List(Box<Schema>),
    Option(Box<Schema>),
    Result(Box<Schema>, Box<Schema>),
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Layout {
    pub program: [u8; 32],
    pub schema: [u8; 32],
    pub roots: Vec<(String, Schema, Schema)>,
    pub events: Vec<(String, Schema)>,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Event {
    pub commit: u64,
    pub position: u64,
    pub channel: usize,
    pub value: Value,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Logical {
    pub version: u64,
    pub tables: Vec<Vec<(Value, Value)>>,
    pub outbox: Vec<Event>,
}
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub bytes: usize,
    pub values: usize,
    pub depth: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            bytes: 64 * 1024 * 1024,
            values: 1_000_000,
            depth: 128,
        }
    }
}
/// Magnitude bound for one exact integer. Decimal conversion is superlinear,
/// so without it a single large Int in a snapshot takes minutes to hours.
pub const MAX_INT_BYTES: usize = 4096;
const MAGIC: &[u8; 8] = b"VLSTATE\0";
const HEADER: usize = 8 + 2 + 2 + 32 + 32 + 8;
type R<T> = Result<T, String>;
fn u64_bytes(out: &mut Vec<u8>, v: u64) {
    out.extend_from_slice(&v.to_le_bytes());
}
fn count(out: &mut Vec<u8>, n: usize) {
    u64_bytes(out, n as u64);
}
fn raw(out: &mut Vec<u8>, b: &[u8]) {
    count(out, b.len());
    out.extend_from_slice(b);
}
fn tag<'a>(v: &'a Value, name: &str) -> R<&'a Value> {
    let o = v.as_object().ok_or("expected tagged object")?;
    if o.len() != 1 {
        return Err("expected exactly one tag".into());
    }
    o.get(name).ok_or("unexpected value tag".into())
}
fn integer(v: &Value) -> R<BigInt> {
    let s = tag(v, "Int")?.as_str().ok_or("expected Int string")?;
    // Every Int within the bound has fewer than 2.41 decimal digits per byte.
    if s.len() > MAX_INT_BYTES * 5 / 2 + 1 {
        return Err("snapshot Int exceeds size limit".into());
    }
    let n = s.parse::<BigInt>().map_err(|_| "invalid Int")?;
    if n.bits() > 8 * MAX_INT_BYTES as u64 {
        return Err("snapshot Int exceeds size limit".into());
    }
    if n.to_string() != s {
        return Err("noncanonical Int".into());
    }
    Ok(n)
}
fn identifier(v: &Value) -> R<u128> {
    let s = v.as_str().ok_or("expected ID")?;
    if s.len() != 32
        || !s
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err("noncanonical ID".into());
    }
    u128::from_str_radix(s, 16).map_err(|e| e.to_string())
}
fn compare(t: &Schema, a: &Value, b: &Value) -> R<Ordering> {
    Ok(match t {
        Schema::I32 => a
            .as_i64()
            .and_then(|n| i32::try_from(n).ok())
            .ok_or("invalid i32 key")?
            .cmp(
                &b.as_i64()
                    .and_then(|n| i32::try_from(n).ok())
                    .ok_or("invalid i32 key")?,
            ),
        Schema::U32 | Schema::U64 => a
            .as_u64()
            .ok_or("invalid key")?
            .cmp(&b.as_u64().ok_or("invalid key")?),
        Schema::String => a
            .as_str()
            .ok_or("invalid key")?
            .as_bytes()
            .cmp(b.as_str().ok_or("invalid key")?.as_bytes()),
        Schema::Id => identifier(a)?.cmp(&identifier(b)?),
        _ => return Err("unsupported snapshot key schema".into()),
    })
}
fn tick(left: &mut usize, depth: usize, limits: Limits) -> R<()> {
    if *left == 0 || depth > limits.depth {
        return Err("snapshot value/depth limit exceeded".into());
    }
    *left -= 1;
    Ok(())
}
fn encode_value(
    t: &Schema,
    v: &Value,
    out: &mut Vec<u8>,
    left: &mut usize,
    depth: usize,
    limits: Limits,
) -> R<()> {
    tick(left, depth, limits)?;
    match t {
        Schema::Unit => {
            if !v.is_null() {
                return Err("expected Unit".into());
            }
        }
        Schema::Bool => out.push(v.as_bool().ok_or("expected Bool")? as u8),
        Schema::U32 => out.extend_from_slice(
            &u32::try_from(v.as_u64().ok_or("expected u32")?)
                .map_err(|_| "u32 overflow")?
                .to_le_bytes(),
        ),
        Schema::U64 => u64_bytes(out, v.as_u64().ok_or("expected u64")?),
        Schema::I32 => out.extend_from_slice(
            &i32::try_from(v.as_i64().ok_or("expected i32")?)
                .map_err(|_| "i32 overflow")?
                .to_le_bytes(),
        ),
        Schema::F32 => {
            let bits = if let Some(b) = v.get("F32Bits") {
                if v.as_object().is_none_or(|o| o.len() != 1) {
                    return Err("expected only F32Bits field".into());
                }
                u32::try_from(b.as_u64().ok_or("expected f32 bits")?)
                    .map_err(|_| "f32 bits overflow")?
            } else {
                let f = v.as_f64().ok_or("expected f32")? as f32;
                if !f.is_finite() {
                    return Err("finite f32 or F32Bits required".into());
                }
                f.to_bits()
            };
            out.extend_from_slice(&bits.to_le_bytes());
        }
        Schema::Vector(inner, n) => {
            if !(2..=4).contains(n)
                || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
            {
                return Err("invalid vector schema".into());
            }
            let xs = v.as_array().ok_or("expected vector")?;
            if xs.len() != *n as usize {
                return Err("vector dimension mismatch".into());
            }
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Int => {
            let n = integer(v)?;
            let (sign, b) = n.to_bytes_le();
            out.push(match sign {
                Sign::NoSign => 0,
                Sign::Plus => 1,
                Sign::Minus => 2,
            });
            if sign == Sign::NoSign {
                raw(out, &[])
            } else {
                raw(out, &b)
            }
        }
        Schema::String => raw(out, v.as_str().ok_or("expected String")?.as_bytes()),
        Schema::Id => out.extend_from_slice(&identifier(v)?.to_le_bytes()),
        Schema::Enum(names) => {
            let s = v.as_str().ok_or("expected enum string")?;
            let index = names
                .iter()
                .position(|n| n == s)
                .ok_or("unknown enum variant")?;
            out.extend_from_slice(&(index as u32).to_le_bytes());
        }
        Schema::Record(fields) => {
            let obj = v.as_object().ok_or("expected record")?;
            if obj.len() != fields.len() {
                return Err("record field mismatch".into());
            }
            for (n, t) in fields {
                encode_value(
                    t,
                    obj.get(n).ok_or("missing record field")?,
                    out,
                    left,
                    depth + 1,
                    limits,
                )?;
            }
        }
        Schema::List(inner) => {
            let xs = v.as_array().ok_or("expected List")?;
            if xs.len() > *left {
                return Err("snapshot value limit exceeded".into());
            }
            count(out, xs.len());
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Option(inner) => {
            if let Ok(x) = tag(v, "Some") {
                out.push(1);
                encode_value(inner, x, out, left, depth + 1, limits)?;
            } else {
                if !tag(v, "None")?.is_null() {
                    return Err("invalid None".into());
                }
                out.push(0);
            }
        }
        Schema::Result(a, b) => {
            if let Ok(x) = tag(v, "Ok") {
                out.push(0);
                encode_value(a, x, out, left, depth + 1, limits)?;
            } else {
                out.push(1);
                encode_value(b, tag(v, "Err")?, out, left, depth + 1, limits)?;
            }
        }
    }
    if out.len() > limits.bytes {
        return Err("snapshot byte limit exceeded".into());
    }
    Ok(())
}
struct Reader<'a> {
    bytes: &'a [u8],
    at: usize,
    left: usize,
    limits: Limits,
}
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> R<&'a [u8]> {
        let end = self.at.checked_add(n).ok_or("snapshot length overflow")?;
        let b = self.bytes.get(self.at..end).ok_or("truncated snapshot")?;
        self.at = end;
        Ok(b)
    }
    fn byte(&mut self) -> R<u8> {
        Ok(self.take(1)?[0])
    }
    fn u32(&mut self) -> R<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn u64(&mut self) -> R<u64> {
        Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
    fn len(&mut self) -> R<usize> {
        usize::try_from(self.u64()?).map_err(|_| "snapshot length not addressable".into())
    }
    fn sequence(&mut self) -> R<usize> {
        let n = self.len()?;
        if n > self.left {
            return Err("snapshot value limit exceeded".into());
        }
        Ok(n)
    }
    fn raw(&mut self) -> R<&'a [u8]> {
        let n = self.len()?;
        self.take(n)
    }
    fn value(&mut self, t: &Schema, depth: usize) -> R<Value> {
        tick(&mut self.left, depth, self.limits)?;
        Ok(match t {
            Schema::Unit => Value::Null,
            Schema::Bool => match self.byte()? {
                0 => json!(false),
                1 => json!(true),
                _ => return Err("invalid Bool tag".into()),
            },
            Schema::U32 => json!(self.u32()?),
            Schema::U64 => json!(self.u64()?),
            Schema::I32 => json!(self.u32()? as i32),
            Schema::F32 => {
                let bits = self.u32()?;
                let f = f32::from_bits(bits);
                if f.is_finite() {
                    json!(f)
                } else {
                    json!({"F32Bits":bits})
                }
            }
            Schema::Vector(inner, n) => {
                if !(2..=4).contains(n)
                    || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
                {
                    return Err("invalid vector schema".into());
                }
                (0..*n)
                    .map(|_| self.value(inner, depth + 1))
                    .collect::<R<Vec<_>>>()?
                    .into()
            }
            Schema::Int => {
                let sign = self.byte()?;
                let bytes = self.raw()?;
                if bytes.len() > MAX_INT_BYTES {
                    return Err("snapshot Int exceeds size limit".into());
                }
                let sign = match sign {
                    0 if bytes.is_empty() => Sign::NoSign,
                    1 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Plus,
                    2 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Minus,
                    _ => return Err("noncanonical signed integer".into()),
                };
                json!({"Int":BigInt::from_bytes_le(sign,bytes).to_string()})
            }
            Schema::String => json!(std::str::from_utf8(self.raw()?).map_err(|_| "invalid UTF-8")?),
            Schema::Id => json!(format!(
                "{:032x}",
                u128::from_le_bytes(self.take(16)?.try_into().unwrap())
            )),
            Schema::Enum(names) => {
                json!(names.get(self.u32()? as usize).ok_or("invalid enum tag")?)
            }
            Schema::Record(fields) => {
                let mut obj = serde_json::Map::new();
                for (n, t) in fields {
                    obj.insert(n.clone(), self.value(t, depth + 1)?);
                }
                Value::Object(obj)
            }
            Schema::List(t) => {
                let n = self.sequence()?;
                let mut xs = Vec::new();
                for _ in 0..n {
                    xs.push(self.value(t, depth + 1)?);
                }
                Value::Array(xs)
            }
            Schema::Option(t) => match self.byte()? {
                0 => json!({"None":null}),
                1 => json!({"Some":self.value(t,depth+1)?}),
                _ => return Err("invalid Option tag".into()),
            },
            Schema::Result(a, b) => match self.byte()? {
                0 => json!({"Ok":self.value(a,depth+1)?}),
                1 => json!({"Err":self.value(b,depth+1)?}),
                _ => return Err("invalid Result tag".into()),
            },
        })
    }
}
fn event_order(e: &Event, version: u64, prior: Option<(u64, u64)>) -> R<()> {
    if e.commit == 0 || e.commit > version || prior.is_some_and(|p| p >= (e.commit, e.position)) {
        return Err("invalid snapshot event sequence".into());
    }
    Ok(())
}
pub fn encode(layout: &Layout, s: &Logical, limits: Limits) -> R<Vec<u8>> {
    if s.tables.len() != layout.roots.len() {
        return Err("snapshot root count mismatch".into());
    }
    let mut out = Vec::new();
    let mut left = limits.values;
    u64_bytes(&mut out, s.version);
    for (rows, (_, kt, vt)) in s.tables.iter().zip(&layout.roots) {
        if rows.len() > left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        count(&mut out, rows.len());
        let mut prior = None;
        for (k, v) in rows {
            if let Some(p) = prior {
                if compare(kt, p, k)? != Ordering::Less {
                    return Err("snapshot keys must be strictly ordered".into());
                }
            }
            encode_value(kt, k, &mut out, &mut left, 0, limits)?;
            encode_value(vt, v, &mut out, &mut left, 0, limits)?;
            prior = Some(k);
        }
    }
    count(&mut out, s.outbox.len());
    let mut prior = None;
    for e in &s.outbox {
        event_order(e, s.version, prior)?;
        let (_, t) = layout
            .events
            .get(e.channel)
            .ok_or("unknown event channel")?;
        u64_bytes(&mut out, e.commit);
        u64_bytes(&mut out, e.position);
        out.extend_from_slice(&(e.channel as u32).to_le_bytes());
        encode_value(t, &e.value, &mut out, &mut left, 0, limits)?;
        prior = Some((e.commit, e.position));
    }
    if HEADER
        .checked_add(out.len())
        .and_then(|n| n.checked_add(32))
        .is_none_or(|n| n > limits.bytes)
    {
        return Err("snapshot byte limit exceeded".into());
    }
    let mut bytes = Vec::new();
    bytes.extend_from_slice(MAGIC);
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&layout.program);
    bytes.extend_from_slice(&layout.schema);
    count(&mut bytes, out.len());
    bytes.extend_from_slice(&out);
    let digest = Sha256::digest(&bytes);
    bytes.extend_from_slice(&digest);
    Ok(bytes)
}
pub fn decode(layout: &Layout, bytes: &[u8], limits: Limits) -> R<Logical> {
    if bytes.len() > limits.bytes || bytes.len() < HEADER + 32 {
        return Err("snapshot byte length invalid".into());
    }
    if &bytes[..8] != MAGIC || bytes[8..12] != [1, 0, 1, 0] {
        return Err("snapshot format or semantics version mismatch".into());
    }
    if bytes[12..44] != layout.program || bytes[44..76] != layout.schema {
        return Err("snapshot program or schema identity mismatch".into());
    }
    let n = usize::try_from(u64::from_le_bytes(bytes[76..84].try_into().unwrap()))
        .map_err(|_| "snapshot length not addressable")?;
    if HEADER.checked_add(n).and_then(|v| v.checked_add(32)) != Some(bytes.len()) {
        return Err("snapshot payload length mismatch".into());
    }
    let end = bytes.len() - 32;
    if Sha256::digest(&bytes[..end]).as_slice() != &bytes[end..] {
        return Err("snapshot integrity check failed".into());
    }
    let mut r = Reader {
        bytes: &bytes[HEADER..end],
        at: 0,
        left: limits.values,
        limits,
    };
    let version = r.u64()?;
    let mut tables = vec![];
    for (_, kt, vt) in &layout.roots {
        let n = r.sequence()?;
        if n > r.left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        let mut rows: Vec<(Value, Value)> = vec![];
        for _ in 0..n {
            let k = r.value(kt, 0)?;
            let v = r.value(vt, 0)?;
            if let Some((prior, _)) = rows.last() {
                if compare(kt, prior, &k)? != Ordering::Less {
                    return Err("duplicate or unordered snapshot key".into());
                }
            }
            rows.push((k, v));
        }
        tables.push(rows);
    }
    let n = r.sequence()?;
    let mut outbox = vec![];
    let mut prior = None;
    for _ in 0..n {
        let commit = r.u64()?;
        let position = r.u64()?;
        let channel = r.u32()? as usize;
        let (_, t) = layout
            .events
            .get(channel)
            .ok_or("unknown snapshot event channel")?;
        let value = r.value(t, 0)?;
        let e = Event {
            commit,
            position,
            channel,
            value,
        };
        event_order(&e, version, prior)?;
        prior = Some((commit, position));
        outbox.push(e);
    }
    if r.at != r.bytes.len() {
        return Err("trailing snapshot payload".into());
    }
    Ok(Logical {
        version,
        tables,
        outbox,
    })
}

}
pub use portable::Limits as SnapshotLimits;
fn snapshot_layout()->portable::Layout{portable::Layout{program:[115, 136, 244, 170, 153, 147, 40, 27, 111, 95, 101, 183, 30, 60, 245, 176, 200, 64, 56, 241, 141, 239, 121, 151, 93, 232, 92, 65, 196, 92, 32, 4],schema:[65, 74, 241, 51, 226, 178, 231, 244, 255, 79, 34, 159, 15, 119, 255, 62, 9, 70, 189, 6, 24, 224, 209, 119, 6, 6, 1, 69, 25, 13, 152, 234],roots:vec![
("Rows".into(),portable::Schema::U64,portable::Schema::Record(vec![("amount".into(),portable::Schema::U64),("label".into(),portable::Schema::U64)])),
],events:vec![("seen".into(),portable::Schema::U64),
]}}
fn one_tag<'a>(v:&'a Json,_kind:&str)->Result<&'a serde_json::Map<String,Json>,String>{Ok(v.as_object().unwrap())}
fn read_0(v:&Json,d:usize)->Result<bool,String>{Ok(
v.as_bool().unwrap())}
fn write_0(v:&bool,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_1(v:&Json,d:usize)->Result<u64,String>{Ok(
v.as_u64().unwrap())}
fn write_1(v:&u64,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_2(v:&Json,d:usize)->Result<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c,String>{Ok(
{D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0})}
fn write_2(v:&D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c,d:usize)->Result<Json,String>{Ok(
Json::Null)}
fn read_3(v:&Json,d:usize)->Result<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b,String>{Ok(
{let text=v.as_str().unwrap();match text{"Error.Failed"=>D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0,_=>unreachable!("caller enum precondition")}})}
fn write_3(v:&D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b,d:usize)->Result<Json,String>{Ok(
match v{D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0=>json!("Error.Failed"),})}
fn read_4(v:&Json,d:usize)->Result<D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b,String>{Ok(
{let xs=v.as_object().unwrap();D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b::C0(read_1(xs.get("amount").unwrap(),d+1)?,read_1(xs.get("label").unwrap(),d+1)?)})}
fn write_4(v:&D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b,d:usize)->Result<Json,String>{Ok(
{let D_ce938945122d9d29865bde9f8361d874f73815bacfc5f6d23f34a3ab03e26c4b::C0(b0,b1)=v;json!({"amount":write_1(&b0,d+1)?,"label":write_1(&b1,d+1)?})})}
fn read_5(v:&Json,d:usize)->Result<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(read_1(x,d+1)?)}else{D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0}})}
fn write_5(v:&D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02,d:usize)->Result<Json,String>{Ok(
match v{D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0=>json!({"None":null}),D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(x)=>json!({"Some":write_1(x,d+1)?})})}
fn read_6(v:&Json,d:usize)->Result<D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C1(std::sync::Arc::new(read_4(x,d+1)?))}else{D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C0}})}
fn write_6(v:&D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef,d:usize)->Result<Json,String>{Ok(
match v{D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C0=>json!({"None":null}),D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef::C1(x)=>json!({"Some":write_4(x,d+1)?})})}
fn read_7(v:&Json,d:usize)->Result<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f,String>{Ok(
{let xs=one_tag(v,"Result")?;if let Some(x)=xs.get("Ok"){D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::new(read_2(x,d+1)?))}else{let x=xs.get("Err").unwrap();D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::new(read_3(x,d+1)?))}})}
fn write_7(v:&D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f,d:usize)->Result<Json,String>{Ok(
match v{D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(x)=>json!({"Ok":write_2(x,d+1)?}),D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(x)=>json!({"Err":write_3(x,d+1)?})})}
fn logical_from_tables(tables:&[Vec<(Json,Json)>])->Result<D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509,String>{if tables.len()!=1{return Err("representation table count mismatch".into())}
let rows=&tables[0];let mut root0=D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C0;for (key,row) in rows.iter().rev(){root0=D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C1(read_1(key,0)?,std::sync::Arc::new(read_4(row,0)?),std::sync::Arc::new(root0));}
Ok(D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(std::sync::Arc::new(root0)))}
fn logical_tables(state:&D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509)->Result<Vec<Vec<(Json,Json)>>,String>{let D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(r0)=state;
let mut rows0=vec![];let mut cursor=r0.as_ref();loop{match cursor{D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C0=>break,D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C1(key,value,tail)=>{rows0.push((write_1(key,0)?,write_4(value,0)?));cursor=tail.as_ref();}}}
Ok(vec![rows0])}
fn logical_events(events:&D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20)->Result<Vec<(usize,Json)>,String>{let mut cursor=events;let mut out=vec![];loop{match cursor{D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C0=>break,D_1dcfc8e06e8b4aaf50f3ace480a5cfa0ba324d49bcd54a578adb3cf93cb69a20::C1(event,tail)=>{let value=match event.as_ref(){
D_fc426eef7c3c750934cf861b3cee7a9e903d1ec0fb7cb0c93810522138fe3beb::C0(value)=>(0,write_1(value,0)?),
};out.push(value);cursor=tail.as_ref();}}}Ok(out)}
pub use portable::Event;
pub struct Outcome<T>{pub result:T,pub committed:bool,pub version:u64,pub events:Vec<Event>}
pub struct OutcomeView<'a,T>{pub result:T,pub committed:bool,pub version:u64,pub events:&'a[Event]}
impl<T> OutcomeView<'_,T>{pub fn into_owned(self)->Outcome<T>{Outcome{result:self.result,committed:self.committed,version:self.version,events:self.events.to_vec()}}}
pub struct State{physical:D_06f64f1773b80405baed6ebb7301ce3b2e55f4375767b5eec8fe897f8a64e137,version:u64,outbox:Vec<portable::Event>,layout:portable::Layout}
impl State{
// CALLER CONTRACT: arguments must have the declared types and canonical values.
// No runtime type validation. Malformed input may panic, trap or corrupt state.
pub fn new()->Result<Self,String>{let logical=D_1797fbdbd514595d4299d9ebd79204d40d9dcfe5bd94cdeb5c7882d78d50c509::C0(std::sync::Arc::new(D_26c1ee32e04965f8833c1fb91b039840d23634880485e907229e0ccec9c5e309::C0));Ok(Self{physical:f_4befcac2cc4e51504d3d48a463be5cae4fc0a56c8ef57f474457ed59b7c0112a(&logical),version:0,outbox:vec![],layout:snapshot_layout()})}
pub fn restore(bytes:&[u8])->Result<Self,String>{let layout=snapshot_layout();let saved=portable::decode(&layout,bytes,SnapshotLimits::default())?;let logical=logical_from_tables(&saved.tables)?;Ok(Self{physical:f_4befcac2cc4e51504d3d48a463be5cae4fc0a56c8ef57f474457ed59b7c0112a(&logical),version:saved.version,outbox:saved.outbox,layout})}
pub fn checkpoint(&self)->Result<Vec<u8>,String>{let logical=f_8d859b516f09d0102733c638cef1c2be93f67be7c7ccf64e306addb6d4e3674c(&(self.physical));portable::encode(&self.layout,&portable::Logical{version:self.version,tables:logical_tables(&logical)?,outbox:self.outbox.clone()},SnapshotLimits::default())}
pub fn version(&self)->u64{self.version}
pub fn outbox_json(&self)->Json{Json::Array(self.outbox.iter().map(|e|json!({"commit":e.commit,"position":e.position,"channel":self.layout.events[e.channel].0,"value":e.value})).collect())}
pub fn acknowledge_through(&mut self,commit:u64,position:u64){self.outbox.retain(|e|(e.commit,e.position)>(commit,position));}
pub fn query_cached(&self,)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{q_640d7da843a469d516ae50e7370b56756d2c6a7ebaf9d6a94014c86ecbeafdfc(&(self.physical),self.version)}
pub fn query_row(&self,)->D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef{q_b389e407b941ff048508dbefa8df3b5fa3bb5ee7b9441f4ddba0e25a20818dd5(&(self.physical),self.version)}
pub fn invoke_view_put(&mut self,a0:u64,a1:u64)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=f_b9eaec0e1d831f7f70b6447dcc8f9a793e89e8764cbc185440ff4d8043495000(&(self.physical),self.version,a0,a1);let observed=f_ed4ffe1eb66254bf4ba6309e33708db25573c1f6925351cbb8825c2ef8c8e786(&(executed));let next=f_cabad30d24ac7dab792243485e30fcba3ce2ab742c1a83b8bb04ae880ef1530b(&(executed));
let(result,committed,version,events)=match &observed{D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_label(&mut self,a0:u64,a1:bool)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=f_353f09c226d31be205942e7b2ef21dc7e88942ba9cc70f9a2db4aea5af8c47b5(&(self.physical),self.version,a0,a1);let observed=f_85b72909ebbc9f3efd2a7c30b02be71454508361b9696d1777310a56c9f53ada(&(executed));let next=f_2383bd4d7012fe43708ac92db7cdbc59f45e8f850ad075363ddcdff1f1354d67(&(executed));
let(result,committed,version,events)=match &observed{D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_amount(&mut self,a0:u64)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=f_fbc3e6fa8037535c617459131bd4e0a5597fba0831a126187465f70be1f2f9a8(&(self.physical),self.version,a0);let observed=f_85b72909ebbc9f3efd2a7c30b02be71454508361b9696d1777310a56c9f53ada(&(executed));let next=f_2383bd4d7012fe43708ac92db7cdbc59f45e8f850ad075363ddcdff1f1354d67(&(executed));
let(result,committed,version,events)=match &observed{D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_cached(&mut self,)->Result<OutcomeView<'_,D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,String>{
let result=q_640d7da843a469d516ae50e7370b56756d2c6a7ebaf9d6a94014c86ecbeafdfc(&(self.physical),self.version);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_view_row(&mut self,)->Result<OutcomeView<'_,D_425c07f05e1bb7a7aa5efa5e7beb5c7a471652c6900f812ca3264c3bbd29fcef>,String>{
let result=q_b389e407b941ff048508dbefa8df3b5fa3bb5ee7b9441f4ddba0e25a20818dd5(&(self.physical),self.version);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_json(&mut self,name:&str,args:&Json)->Result<Json,String>{match name{
"put"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_1(&xs[1],0)?;
let executed=f_b9eaec0e1d831f7f70b6447dcc8f9a793e89e8764cbc185440ff4d8043495000(&(self.physical),self.version,a0,a1);
let observed=f_ed4ffe1eb66254bf4ba6309e33708db25573c1f6925351cbb8825c2ef8c8e786(&(executed));let next=f_cabad30d24ac7dab792243485e30fcba3ce2ab742c1a83b8bb04ae880ef1530b(&(executed));let(reply,committed,version,events)=match &observed{D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_7(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"label"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_0(&xs[1],0)?;
let executed=f_353f09c226d31be205942e7b2ef21dc7e88942ba9cc70f9a2db4aea5af8c47b5(&(self.physical),self.version,a0,a1);
let observed=f_85b72909ebbc9f3efd2a7c30b02be71454508361b9696d1777310a56c9f53ada(&(executed));let next=f_2383bd4d7012fe43708ac92db7cdbc59f45e8f850ad075363ddcdff1f1354d67(&(executed));let(reply,committed,version,events)=match &observed{D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_7(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"amount"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let executed=f_fbc3e6fa8037535c617459131bd4e0a5597fba0831a126187465f70be1f2f9a8(&(self.physical),self.version,a0);
let observed=f_85b72909ebbc9f3efd2a7c30b02be71454508361b9696d1777310a56c9f53ada(&(executed));let next=f_2383bd4d7012fe43708ac92db7cdbc59f45e8f850ad075363ddcdff1f1354d67(&(executed));let(reply,committed,version,events)=match &observed{D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_2899c21da93435b34cd67e4cc8eb01fa031bcc297978b0e5073b703de3a9ee98::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_7(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"cached"=>{let xs=args.as_array().unwrap();
let reply=q_640d7da843a469d516ae50e7370b56756d2c6a7ebaf9d6a94014c86ecbeafdfc(&(self.physical),self.version);let result=write_5(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
"row"=>{let xs=args.as_array().unwrap();
let reply=q_b389e407b941ff048508dbefa8df3b5fa3bb5ee7b9441f4ddba0e25a20818dd5(&(self.physical),self.version);let result=write_6(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
_=>Err(format!("unknown action {name}"))}}}
