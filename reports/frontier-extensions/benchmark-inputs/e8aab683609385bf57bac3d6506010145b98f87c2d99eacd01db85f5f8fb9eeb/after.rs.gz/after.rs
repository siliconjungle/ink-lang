// ink-definition-rust-v1: checked bodies; Rust/backend are trusted.
#![allow(non_camel_case_types, non_snake_case, non_upper_case_globals, dead_code, unused_variables, unused_parens, unused_unsafe, improper_ctypes_definitions)]
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { C0,C1(u64,std::sync::Arc<D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b>) }
impl D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_050b373a79d555c2577b1594d727d6cf1a60f9d11529a88ab3da5b35c5a8e44c(v0: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a,v1: u64,v2: u64) -> D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { match v0 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v3,v4) => { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_50c6c395084616f9cf6a84c8e8d2ce70d6746e042d9806094ed93d60eebb1efd(v3.as_ref(),v1,v2)),std::sync::Arc::new(d_71ef1cbc686007bd38b0eee5db382b08020455dcaa4fc18959fbc042b3c67cd2(v3.as_ref(),v4.as_ref(),v1,v2))) } } }
fn d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v5: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v6: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v7: u64) -> D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02 { match v5 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v9,v10) => { match v6 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v12,v13) => { if ((v7) == (*v9)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(*v12) } else { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v10.as_ref(),v13.as_ref(),v7) } } } } } }
fn d_0f72639bc22b7c66a0c4460f1ea76c92f1ef2a27fbc93b826a9b1adfb7364826(v14: &D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575,v15: u64,v16: u64) -> D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575 { match v14 { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v17,v18,v19) => { d_f3d84a09c00f9b9752567b30e82ffc354d1fa1f9a4b33dcef12815c9b0a5bf6e(&(d_050b373a79d555c2577b1594d727d6cf1a60f9d11529a88ab3da5b35c5a8e44c(v17.as_ref(),v15,v16))) } } }
fn d_12362e281b3997963ae3c26e64de0c549b3052123196bcb5943a98de1f80e587(v20: &D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v21: u64) -> D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2 { match v20 { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(v22) => { D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v22))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(d_9670664fef031f15b2ee3c9d84e390cfde6f6c2c66559222355f3dcca0d443e1(v22.as_ref(),1u64)),false,v21,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(v22.as_ref())))),std::sync::Arc::clone({static v23:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v23.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } }
fn d_123eeb8d1a7e1d3772fae8d3ad2ec9d2289248bb2b6e36e438abb059cb1eb75b(v24: &D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2) -> D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303 { match v24 { D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2::C0(v25,v26) => { (v25.as_ref()).clone() } } }
fn d_1242bcb235dc8376a3b3666718bf63c51093f71356dd18708bf5b17137d855d0(v27: &D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v27 { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(v29,v30,v31) => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v30,std::sync::Arc::new(d_1242bcb235dc8376a3b3666718bf63c51093f71356dd18708bf5b17137d855d0(v31.as_ref()))) } } }
fn d_1881825c3f574a11fbb010086ab9aec16a5ac4fa46edee59189929ab417e8320(v32: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v32 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v34,v35) => { if ((((*v34) & (1u64))) != (0u64)) { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v34,std::sync::Arc::new(d_1881825c3f574a11fbb010086ab9aec16a5ac4fa46edee59189929ab417e8320(v35.as_ref()))) } else { d_1881825c3f574a11fbb010086ab9aec16a5ac4fa46edee59189929ab417e8320(v35.as_ref()) } } } }
fn d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v36: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a,v37: u64) -> D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02 { match v36 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v38,v39) => { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v38.as_ref(),v39.as_ref(),v37) } } }
fn d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(v40: &D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575) -> D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807 { match v40 { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v41,v42,v43) => { d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v41.as_ref()) } } }
fn d_1fa0d7c9a94ed7c13756f1d32ce86aecfadf222cf31d8027044d8cc4e83fd5e8(v44: &D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d) -> D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303 { match v44 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v45) => { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::new(d_d00cb023eff964401d32da9ce9a579964f89bde0ae8a9adbe183eb582af47d85(v45.as_ref()))) } } }
fn d_21a235cc347ec2416702c8248af926191a466c46fb54e6f14f7f7aab47e28a94(v46: &D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d) -> D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303 { match v46 { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(v47,v48) => { (v47.as_ref()).clone() } } }
fn d_2d42d9268a1e573f85e6080f48affbb86fb914a83996ff48604b0d6b860d629d(v49: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a) -> D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { match v49 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v50,v51) => { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_38996718901144391920ab324037fe67cfa94128d5093229f1e168ad1d649125(v50.as_ref())),std::sync::Arc::new(d_7d84e45dda7fb319dd2f7196ff39fbe5b5af66a23bab631ffcb0a09b5653e3a9(v50.as_ref(),v51.as_ref()))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303 { C0(std::sync::Arc<D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575>) }
fn d_31da817461332a272329ebaf8d8b88dd1d957e34b37ae8df6eb4420cfcf2cc0d(v52: &D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v52 { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(v54,v55,v56) => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v54,std::sync::Arc::new(d_31da817461332a272329ebaf8d8b88dd1d957e34b37ae8df6eb4420cfcf2cc0d(v56.as_ref()))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2 { C0(std::sync::Arc<D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303>,std::sync::Arc<D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994>) }
fn d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v57: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a) -> D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807 { match v57 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v58,v59) => { d_8c71c9ec54433ede7b1b11cf4d4e65e192bf24e83eb2912562d70a1052e368ac(v58.as_ref(),v59.as_ref()) } } }
fn d_353625e8f5afea9bd0cb854674538d244f4fbb2136ba9af1241ed806b47eceb6(v60: &D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v61: u64,v62: u64,v63: bool) -> D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d { match v60 { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(v64) => { if v63 { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v64))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v66:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v66.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v65:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v65.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v61,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(v64.as_ref())))),std::sync::Arc::clone({static v67:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v67.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } else { if ((v61) == (18446744073709551615u64)) { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v64))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v61,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(v64.as_ref()))))))) } else { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::new(d_efd5504b47980833a0494fa271c2a4628acc3f2f4f7de9e6cbfac50a7947b6a8(&(d_efd5504b47980833a0494fa271c2a4628acc3f2f4f7de9e6cbfac50a7947b6a8(v64.as_ref(),v62)),v62)))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v69:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v69.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v68:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v68.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v61).wrapping_add(1u64),std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(&(d_efd5504b47980833a0494fa271c2a4628acc3f2f4f7de9e6cbfac50a7947b6a8(&(d_efd5504b47980833a0494fa271c2a4628acc3f2f4f7de9e6cbfac50a7947b6a8(v64.as_ref(),v62)),v62)))))),std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(std::sync::Arc::new(D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(v62)),std::sync::Arc::clone({static v70:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v70.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))))) } } } } }
fn d_3656b75bbdd1c96448eb777c3d928a445e8c03f0ce56581048ef0d1c9a1ac5bc(v71: &D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v72: u64) -> D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2 { match v71 { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(v73) => { D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v73))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(d_9670664fef031f15b2ee3c9d84e390cfde6f6c2c66559222355f3dcca0d443e1(v73.as_ref(),0u64)),false,v72,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(v73.as_ref())))),std::sync::Arc::clone({static v74:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v74.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } }
fn d_38996718901144391920ab324037fe67cfa94128d5093229f1e168ad1d649125(v75: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v75 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v77,v78) => { if ((((*v77) & (1u64))) == (0u64)) { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v77,std::sync::Arc::new(d_38996718901144391920ab324037fe67cfa94128d5093229f1e168ad1d649125(v78.as_ref()))) } else { d_38996718901144391920ab324037fe67cfa94128d5093229f1e168ad1d649125(v78.as_ref()) } } } }
fn d_3b70ef55c71639277b04dbb2f126534f6cc99e8d2576cb1493ee85c592da045e(v79: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v80: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v79 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v82,v83) => { if ((v80) == (*v82)) { d_3b70ef55c71639277b04dbb2f126534f6cc99e8d2576cb1493ee85c592da045e(v83.as_ref(),v80) } else { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v82,std::sync::Arc::new(d_3b70ef55c71639277b04dbb2f126534f6cc99e8d2576cb1493ee85c592da045e(v83.as_ref(),v80))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d { C0(std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>) }
fn d_50c6c395084616f9cf6a84c8e8d2ce70d6746e042d9806094ed93d60eebb1efd(v84: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v85: u64,v86: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v84 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v88,v89) => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v88,std::sync::Arc::new(d_50c6c395084616f9cf6a84c8e8d2ce70d6746e042d9806094ed93d60eebb1efd(v89.as_ref(),v85,v86))) } } }
fn d_54dd99bd961ff76b6f2d72c0de32fb2796619a2a2f0c82a14590fb7cce7ba4f4(v90: &D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d) -> D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953 { match v90 { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(v91,v92) => { (v92.as_ref()).clone() } } }
fn d_5a06c1e0f1bfd57716580fd5d6f2633571ffebb7ad2375b325be26e4d8b2da16(v93: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v94: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v95: u64,v96: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v93 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v96,std::sync::Arc::clone({static v97:std::sync::OnceLock<std::sync::Arc<D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b>>=std::sync::OnceLock::new();v97.get_or_init(||std::sync::Arc::new(D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0))})) },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v98,v99) => { match v94 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v101,v102) => { if ((v95) < (*v98)) { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v96,std::sync::Arc::new((v94).clone())) } else { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v101,std::sync::Arc::new(d_5a06c1e0f1bfd57716580fd5d6f2633571ffebb7ad2375b325be26e4d8b2da16(v99.as_ref(),v102.as_ref(),v95,v96))) } } } } } }
fn d_5a15529df8e4cb28cdeb094163a2a1077596795737689d8bdbc6eced560f087d(v103: &D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v104: u64,v105: u64,v106: u64,v107: bool) -> D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d { match v103 { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(v108) => { if match &(d_9670664fef031f15b2ee3c9d84e390cfde6f6c2c66559222355f3dcca0d443e1(v108.as_ref(),v105)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v109) => { true } } { if match &(d_9670664fef031f15b2ee3c9d84e390cfde6f6c2c66559222355f3dcca0d443e1(v108.as_ref(),v105)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v110) => { true } } { if v107 { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v108))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v112:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v112.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v111:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v111.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v104,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(v108.as_ref())))),std::sync::Arc::clone({static v113:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v113.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } else { if ((v104) == (18446744073709551615u64)) { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v108))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v104,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(v108.as_ref()))))))) } else { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::new(d_0f72639bc22b7c66a0c4460f1ea76c92f1ef2a27fbc93b826a9b1adfb7364826(v108.as_ref(),v105,v106)))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v115:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v115.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v114:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v114.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v104).wrapping_add(1u64),std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(&(d_0f72639bc22b7c66a0c4460f1ea76c92f1ef2a27fbc93b826a9b1adfb7364826(v108.as_ref(),v105,v106)))))),std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(std::sync::Arc::new(D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(v106)),std::sync::Arc::clone({static v116:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v116.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))))) } } } else { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v108))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v104,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(v108.as_ref()))))))) } } else { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v108))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v118:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v118.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v117:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v117.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v104,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(v108.as_ref())))),std::sync::Arc::clone({static v119:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v119.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } } }
fn d_5f0900131561b92872eac9e671f62e8756b7d4b399c712ce5573bb0d2565f847(v120: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v121: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v120 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v123,v124) => { match v121 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v126,v127) => { if ((((*v123) & (1u64))) != (0u64)) { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v126,std::sync::Arc::new(d_5f0900131561b92872eac9e671f62e8756b7d4b399c712ce5573bb0d2565f847(v124.as_ref(),v127.as_ref()))) } else { d_5f0900131561b92872eac9e671f62e8756b7d4b399c712ce5573bb0d2565f847(v124.as_ref(),v127.as_ref()) } } } } } }
fn d_628112b4225a92fe017b1672ebd914fc21f26f8767111f6bb0834b048c08fdfa(v128: &D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2) -> D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { match v128 { D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2::C0(v129,v130) => { (v130.as_ref()).clone() } } }
fn d_6d98cae700f619afa661030e6c7acff0fcd9f1032ad88974ee37dce0a8651070(v131: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a) -> D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { match v131 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v132,v133) => { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_1881825c3f574a11fbb010086ab9aec16a5ac4fa46edee59189929ab417e8320(v132.as_ref())),std::sync::Arc::new(d_5f0900131561b92872eac9e671f62e8756b7d4b399c712ce5573bb0d2565f847(v132.as_ref(),v133.as_ref()))) } } }
fn d_6f951a654c399751d2ab43fc23ac5c97a43a73b65d7184b52a00fec1c245c84c(v134: &D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807) -> D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_31da817461332a272329ebaf8d8b88dd1d957e34b37ae8df6eb4420cfcf2cc0d(v134)),std::sync::Arc::new(d_1242bcb235dc8376a3b3666718bf63c51093f71356dd18708bf5b17137d855d0(v134))) }
fn d_71ef1cbc686007bd38b0eee5db382b08020455dcaa4fc18959fbc042b3c67cd2(v135: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v136: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v137: u64,v138: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v135 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v140,v141) => { match v136 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v143,v144) => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(if ((v137) == (*v140)) { v138 } else { *v143 },std::sync::Arc::new(d_71ef1cbc686007bd38b0eee5db382b08020455dcaa4fc18959fbc042b3c67cd2(v141.as_ref(),v144.as_ref(),v137,v138))) } } } } }
fn d_74f987be179aff0a70be67aaf7a687192b43fbb60977140ba326b2adef21e03c(v145: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a,v146: u64,v147: u64) -> D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { match v145 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v148,v149) => { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_e7f3abf6f9dd0953bd24c47e8f8d261bd6b25dca50d60e76c02bfaf73890cf93(v148.as_ref(),v146,v147)),std::sync::Arc::new(d_5a06c1e0f1bfd57716580fd5d6f2633571ffebb7ad2375b325be26e4d8b2da16(v148.as_ref(),v149.as_ref(),v146,v147))) } } }
fn d_75b36e9bcc8983f503aed6cc3390d40933b881806b71b241d41d15f5ee405815(v150: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v151: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v152: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v150 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v154,v155) => { match v151 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v157,v158) => { if ((v152) == (*v154)) { d_75b36e9bcc8983f503aed6cc3390d40933b881806b71b241d41d15f5ee405815(v155.as_ref(),v158.as_ref(),v152) } else { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v157,std::sync::Arc::new(d_75b36e9bcc8983f503aed6cc3390d40933b881806b71b241d41d15f5ee405815(v155.as_ref(),v158.as_ref(),v152))) } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807 { C0,C1(u64,u64,std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>) }
impl D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_7d84e45dda7fb319dd2f7196ff39fbe5b5af66a23bab631ffcb0a09b5653e3a9(v159: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v160: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v159 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v162,v163) => { match v160 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v165,v166) => { if ((((*v162) & (1u64))) == (0u64)) { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v165,std::sync::Arc::new(d_7d84e45dda7fb319dd2f7196ff39fbe5b5af66a23bab631ffcb0a09b5653e3a9(v163.as_ref(),v166.as_ref()))) } else { d_7d84e45dda7fb319dd2f7196ff39fbe5b5af66a23bab631ffcb0a09b5653e3a9(v163.as_ref(),v166.as_ref()) } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953 { C0(std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,bool,u64,std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>,std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>),C1(u64,u64,std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>) }
fn d_8c71c9ec54433ede7b1b11cf4d4e65e192bf24e83eb2912562d70a1052e368ac(v167: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v168: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b) -> D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807 { match v167 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v170,v171) => { match v168 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v173,v174) => { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(*v170,*v173,std::sync::Arc::new(d_8c71c9ec54433ede7b1b11cf4d4e65e192bf24e83eb2912562d70a1052e368ac(v171.as_ref(),v174.as_ref()))) } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f { C0(std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>),C1(std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de { C0,C1(std::sync::Arc<D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6>,std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>) }
impl D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_9670664fef031f15b2ee3c9d84e390cfde6f6c2c66559222355f3dcca0d443e1(v175: &D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575,v176: u64) -> D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02 { match v175 { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v177,v178,v179) => { if ((((v176) & (1u64))) != (0u64)) { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v179.as_ref(),v176) } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v178.as_ref(),v176) } } } }
fn d_9bc49f94718bc036cc9ddff09c1c68b115e7c6476a12355d708959e5c6d5efdb(v180: &D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303) -> D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d { match v180 { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(v181) => { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(v181.as_ref()))) } } }
fn d_9c35951fbd2f936287a47cd9bdae516aa294e04d31fdd0aeec0f641695ba6846(v182: &D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v183: u64,v184: u64,v185: u64) -> D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d { match v182 { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(v186) => { if match &(d_9670664fef031f15b2ee3c9d84e390cfde6f6c2c66559222355f3dcca0d443e1(v186.as_ref(),v184)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v187) => { true } } { if match &(d_9670664fef031f15b2ee3c9d84e390cfde6f6c2c66559222355f3dcca0d443e1(v186.as_ref(),v184)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v188) => { true } } { if ((v183) == (18446744073709551615u64)) { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v186))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v183,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(v186.as_ref()))))))) } else { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::new(d_0f72639bc22b7c66a0c4460f1ea76c92f1ef2a27fbc93b826a9b1adfb7364826(v186.as_ref(),v184,v185)))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v190:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v190.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v189:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v189.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v183).wrapping_add(1u64),std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(&(d_0f72639bc22b7c66a0c4460f1ea76c92f1ef2a27fbc93b826a9b1adfb7364826(v186.as_ref(),v184,v185)))))),std::sync::Arc::clone({static v191:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v191.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } else { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v186))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v183,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(v186.as_ref()))))))) } } else { if match &(d_9670664fef031f15b2ee3c9d84e390cfde6f6c2c66559222355f3dcca0d443e1(v186.as_ref(),v184)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v192) => { true } } { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v186))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v183,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(v186.as_ref()))))))) } else { if ((v183) == (18446744073709551615u64)) { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v186))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v183,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(v186.as_ref()))))))) } else { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::new(d_f50e4ffe66c6ffab1bb1e319728bf08491d516d6f5b68a43e67ad2525fd5917a(v186.as_ref(),v184,v185)))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v194:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v194.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v193:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v193.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v183).wrapping_add(1u64),std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(&(d_f50e4ffe66c6ffab1bb1e319728bf08491d516d6f5b68a43e67ad2525fd5917a(v186.as_ref(),v184,v185)))))),std::sync::Arc::clone({static v195:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v195.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02 { C0,C1(u64) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c { C0 }
impl D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_c061f819d93d0e92b7620b91c0bb193c0a900f150010b0ebd924f32ad5f29602(v196: &D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v197: u64,v198: u64) -> D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2 { match v196 { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(v199) => { D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v199))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(d_9670664fef031f15b2ee3c9d84e390cfde6f6c2c66559222355f3dcca0d443e1(v199.as_ref(),v198)),false,v197,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_1af76c783f2d881ac6b348fd79564a7daab4e56f7e6749e9428039f87cbc4018(v199.as_ref())))),std::sync::Arc::clone({static v200:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v200.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575 { C0(std::sync::Arc<D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a>,std::sync::Arc<D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a>,std::sync::Arc<D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b { C0 }
impl D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_d00cb023eff964401d32da9ce9a579964f89bde0ae8a9adbe183eb582af47d85(v201: &D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807) -> D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575 { d_f3d84a09c00f9b9752567b30e82ffc354d1fa1f9a4b33dcef12815c9b0a5bf6e(&(d_6f951a654c399751d2ab43fc23ac5c97a43a73b65d7184b52a00fec1c245c84c(v201))) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6 { C0(u64) }
fn d_df95fd31337deaad84f3abe0d6c13adc30ae22013972652e3b6e45d2fff2139c(v202: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a,v203: u64) -> D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { match v202 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v204,v205) => { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_3b70ef55c71639277b04dbb2f126534f6cc99e8d2576cb1493ee85c592da045e(v204.as_ref(),v203)),std::sync::Arc::new(d_75b36e9bcc8983f503aed6cc3390d40933b881806b71b241d41d15f5ee405815(v204.as_ref(),v205.as_ref(),v203))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d { C0(std::sync::Arc<D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303>,std::sync::Arc<D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953>) }
fn d_e7f3abf6f9dd0953bd24c47e8f8d261bd6b25dca50d60e76c02bfaf73890cf93(v206: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v207: u64,v208: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v206 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v207,std::sync::Arc::clone({static v209:std::sync::OnceLock<std::sync::Arc<D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b>>=std::sync::OnceLock::new();v209.get_or_init(||std::sync::Arc::new(D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0))})) },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v210,v211) => { if ((v207) < (*v210)) { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v207,std::sync::Arc::new((v206).clone())) } else { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v210,std::sync::Arc::new(d_e7f3abf6f9dd0953bd24c47e8f8d261bd6b25dca50d60e76c02bfaf73890cf93(v211.as_ref(),v207,v208))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { C0(std::sync::Arc<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,bool,u64,std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>,std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>),C1(u64,u64,std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>) }
fn d_efd5504b47980833a0494fa271c2a4628acc3f2f4f7de9e6cbfac50a7947b6a8(v212: &D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575,v213: u64) -> D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575 { match v212 { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v214,v215,v216) => { d_f3d84a09c00f9b9752567b30e82ffc354d1fa1f9a4b33dcef12815c9b0a5bf6e(&(d_df95fd31337deaad84f3abe0d6c13adc30ae22013972652e3b6e45d2fff2139c(v214.as_ref(),v213))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { C0(std::sync::Arc<D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b>,std::sync::Arc<D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b>) }
fn d_f3d84a09c00f9b9752567b30e82ffc354d1fa1f9a4b33dcef12815c9b0a5bf6e(v217: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a) -> D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575 { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(std::sync::Arc::new((v217).clone()),std::sync::Arc::new(d_2d42d9268a1e573f85e6080f48affbb86fb914a83996ff48604b0d6b860d629d(v217)),std::sync::Arc::new(d_6d98cae700f619afa661030e6c7acff0fcd9f1032ad88974ee37dce0a8651070(v217))) }
fn d_f50e4ffe66c6ffab1bb1e319728bf08491d516d6f5b68a43e67ad2525fd5917a(v218: &D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575,v219: u64,v220: u64) -> D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575 { match v218 { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v221,v222,v223) => { d_f3d84a09c00f9b9752567b30e82ffc354d1fa1f9a4b33dcef12815c9b0a5bf6e(&(d_74f987be179aff0a70be67aaf7a687192b43fbb60977140ba326b2adef21e03c(v221.as_ref(),v219,v220))) } } }
pub fn f_12362e281b3997963ae3c26e64de0c549b3052123196bcb5943a98de1f80e587(v224: &D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v225: u64) -> D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2 { d_12362e281b3997963ae3c26e64de0c549b3052123196bcb5943a98de1f80e587(v224,v225) }
pub fn f_123eeb8d1a7e1d3772fae8d3ad2ec9d2289248bb2b6e36e438abb059cb1eb75b(v226: &D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2) -> D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303 { d_123eeb8d1a7e1d3772fae8d3ad2ec9d2289248bb2b6e36e438abb059cb1eb75b(v226) }
pub fn f_1fa0d7c9a94ed7c13756f1d32ce86aecfadf222cf31d8027044d8cc4e83fd5e8(v227: &D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d) -> D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303 { d_1fa0d7c9a94ed7c13756f1d32ce86aecfadf222cf31d8027044d8cc4e83fd5e8(v227) }
pub fn f_21a235cc347ec2416702c8248af926191a466c46fb54e6f14f7f7aab47e28a94(v228: &D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d) -> D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303 { d_21a235cc347ec2416702c8248af926191a466c46fb54e6f14f7f7aab47e28a94(v228) }
pub fn f_353625e8f5afea9bd0cb854674538d244f4fbb2136ba9af1241ed806b47eceb6(v229: &D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v230: u64,v231: u64,v232: bool) -> D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d { d_353625e8f5afea9bd0cb854674538d244f4fbb2136ba9af1241ed806b47eceb6(v229,v230,v231,v232) }
pub fn f_3656b75bbdd1c96448eb777c3d928a445e8c03f0ce56581048ef0d1c9a1ac5bc(v233: &D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v234: u64) -> D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2 { d_3656b75bbdd1c96448eb777c3d928a445e8c03f0ce56581048ef0d1c9a1ac5bc(v233,v234) }
pub fn f_54dd99bd961ff76b6f2d72c0de32fb2796619a2a2f0c82a14590fb7cce7ba4f4(v235: &D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d) -> D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953 { d_54dd99bd961ff76b6f2d72c0de32fb2796619a2a2f0c82a14590fb7cce7ba4f4(v235) }
pub fn f_5a15529df8e4cb28cdeb094163a2a1077596795737689d8bdbc6eced560f087d(v236: &D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v237: u64,v238: u64,v239: u64,v240: bool) -> D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d { d_5a15529df8e4cb28cdeb094163a2a1077596795737689d8bdbc6eced560f087d(v236,v237,v238,v239,v240) }
pub fn f_628112b4225a92fe017b1672ebd914fc21f26f8767111f6bb0834b048c08fdfa(v241: &D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2) -> D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { d_628112b4225a92fe017b1672ebd914fc21f26f8767111f6bb0834b048c08fdfa(v241) }
pub fn f_9bc49f94718bc036cc9ddff09c1c68b115e7c6476a12355d708959e5c6d5efdb(v242: &D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303) -> D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d { d_9bc49f94718bc036cc9ddff09c1c68b115e7c6476a12355d708959e5c6d5efdb(v242) }
pub fn f_9c35951fbd2f936287a47cd9bdae516aa294e04d31fdd0aeec0f641695ba6846(v243: &D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v244: u64,v245: u64,v246: u64) -> D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d { d_9c35951fbd2f936287a47cd9bdae516aa294e04d31fdd0aeec0f641695ba6846(v243,v244,v245,v246) }
pub fn f_c061f819d93d0e92b7620b91c0bb193c0a900f150010b0ebd924f32ad5f29602(v247: &D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v248: u64,v249: u64) -> D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2 { d_c061f819d93d0e92b7620b91c0bb193c0a900f150010b0ebd924f32ad5f29602(v247,v248,v249) }
fn q_12362e281b3997963ae3c26e64de0c549b3052123196bcb5943a98de1f80e587(v0:&D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v1:u64)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{match v0 { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(v2) => { match v2.as_ref() { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v3,v4,v5) => { if ((((1u64) & (1u64))) != (0u64)) { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v5.as_ref(),1u64) } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v4.as_ref(),1u64) } } } } }}
fn q_3656b75bbdd1c96448eb777c3d928a445e8c03f0ce56581048ef0d1c9a1ac5bc(v0:&D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v1:u64)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{match v0 { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(v2) => { match v2.as_ref() { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v3,v4,v5) => { if ((((0u64) & (1u64))) != (0u64)) { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v5.as_ref(),0u64) } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v4.as_ref(),0u64) } } } } }}
fn q_c061f819d93d0e92b7620b91c0bb193c0a900f150010b0ebd924f32ad5f29602(v0:&D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v1:u64,v2:u64)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{match v0 { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(v3) => { match v3.as_ref() { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v4,v5,v6) => { if ((((v2) & (1u64))) != (0u64)) { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v6.as_ref(),v2) } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v5.as_ref(),v2) } } } } }}
fn t_12362e281b3997963ae3c26e64de0c549b3052123196bcb5943a98de1f80e587(v0:&D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v1:u64)->D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2{match v0 { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(v2) => { D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v2))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(match v2.as_ref() { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v3,v4,v5) => { if ((((1u64) & (1u64))) != (0u64)) { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v5.as_ref(),1u64) } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v4.as_ref(),1u64) } } }),false,v1,std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v8:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v8.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } }}
fn t_353625e8f5afea9bd0cb854674538d244f4fbb2136ba9af1241ed806b47eceb6(v0:&D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v1:u64,v2:u64,v3:bool)->D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d{match v0 { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(v4) => { if v3 { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v1,std::sync::Arc::clone({static v8:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v8.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v9:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v9.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } else { if ((v1) == (18446744073709551615u64)) { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v1,std::sync::Arc::clone({static v11:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v11.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v10:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v10.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } else { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::new(match &(match v4.as_ref() { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v12,v13,v14) => { d_f3d84a09c00f9b9752567b30e82ffc354d1fa1f9a4b33dcef12815c9b0a5bf6e(&(d_df95fd31337deaad84f3abe0d6c13adc30ae22013972652e3b6e45d2fff2139c(v12.as_ref(),v2))) } }) { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v15,v16,v17) => { d_f3d84a09c00f9b9752567b30e82ffc354d1fa1f9a4b33dcef12815c9b0a5bf6e(&(d_df95fd31337deaad84f3abe0d6c13adc30ae22013972652e3b6e45d2fff2139c(v15.as_ref(),v2))) } }))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v19:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v19.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v18:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v18.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v1).wrapping_add(1u64),std::sync::Arc::clone({static v21:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v21.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v20:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v20.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(std::sync::Arc::new(D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(v2)),std::sync::Arc::clone({static v22:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v22.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))))) } } } }}
fn t_3656b75bbdd1c96448eb777c3d928a445e8c03f0ce56581048ef0d1c9a1ac5bc(v0:&D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v1:u64)->D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2{match v0 { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(v2) => { D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v2))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(match v2.as_ref() { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v3,v4,v5) => { if ((((0u64) & (1u64))) != (0u64)) { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v5.as_ref(),0u64) } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v4.as_ref(),0u64) } } }),false,v1,std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v8:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v8.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } }}
fn t_5a15529df8e4cb28cdeb094163a2a1077596795737689d8bdbc6eced560f087d(v0:&D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v1:u64,v2:u64,v3:u64,v4:bool)->D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d{match v0 { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(v5) => { if match &(match v5.as_ref() { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v6,v7,v8) => { if ((((v2) & (1u64))) != (0u64)) { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v8.as_ref(),v2) } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v7.as_ref(),v2) } } }) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v9) => { true } } { if match &(match v5.as_ref() { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v10,v11,v12) => { if ((((v2) & (1u64))) != (0u64)) { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v12.as_ref(),v2) } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v11.as_ref(),v2) } } }) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v13) => { true } } { if v4 { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v5))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v15:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v15.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v14:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v14.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v1,std::sync::Arc::clone({static v17:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v17.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v16:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v16.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v18:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v18.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } else { if ((v1) == (18446744073709551615u64)) { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v5))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v1,std::sync::Arc::clone({static v20:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v20.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v19:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v19.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } else { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::new(match v5.as_ref() { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v21,v22,v23) => { d_f3d84a09c00f9b9752567b30e82ffc354d1fa1f9a4b33dcef12815c9b0a5bf6e(&(d_050b373a79d555c2577b1594d727d6cf1a60f9d11529a88ab3da5b35c5a8e44c(v21.as_ref(),v2,v3))) } }))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v25:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v25.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v24:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v24.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v1).wrapping_add(1u64),std::sync::Arc::clone({static v27:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v27.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v26:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v26.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(std::sync::Arc::new(D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(v3)),std::sync::Arc::clone({static v28:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v28.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))))) } } } else { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v5))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v1,std::sync::Arc::clone({static v30:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v30.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v29:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v29.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } } else { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v5))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v32:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v32.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v31:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v31.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v1,std::sync::Arc::clone({static v34:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v34.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v33:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v33.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v35:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v35.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } }}
fn t_9c35951fbd2f936287a47cd9bdae516aa294e04d31fdd0aeec0f641695ba6846(v0:&D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v1:u64,v2:u64,v3:u64)->D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d{match v0 { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(v4) => { if match &(match v4.as_ref() { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v5,v6,v7) => { if ((((v2) & (1u64))) != (0u64)) { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v7.as_ref(),v2) } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v6.as_ref(),v2) } } }) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v8) => { true } } { if match &(match v4.as_ref() { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v9,v10,v11) => { if ((((v2) & (1u64))) != (0u64)) { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v11.as_ref(),v2) } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v10.as_ref(),v2) } } }) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v12) => { true } } { if ((v1) == (18446744073709551615u64)) { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v1,std::sync::Arc::clone({static v14:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v14.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v13:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v13.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } else { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::new(match v4.as_ref() { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v15,v16,v17) => { d_f3d84a09c00f9b9752567b30e82ffc354d1fa1f9a4b33dcef12815c9b0a5bf6e(&(d_050b373a79d555c2577b1594d727d6cf1a60f9d11529a88ab3da5b35c5a8e44c(v15.as_ref(),v2,v3))) } }))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v19:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v19.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v18:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v18.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v1).wrapping_add(1u64),std::sync::Arc::clone({static v21:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v21.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v20:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v20.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v22:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v22.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } else { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v1,std::sync::Arc::clone({static v24:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v24.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v23:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v23.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } } else { if match &(match v4.as_ref() { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v25,v26,v27) => { if ((((v2) & (1u64))) != (0u64)) { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v27.as_ref(),v2) } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v26.as_ref(),v2) } } }) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v28) => { true } } { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v1,std::sync::Arc::clone({static v30:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v30.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v29:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v29.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } else { if ((v1) == (18446744073709551615u64)) { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v1,std::sync::Arc::clone({static v32:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v32.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v31:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v31.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } else { D_e77303108299882459b6f49ff75e0428056e4a58eefda517fb50d5b606af3b2d::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::new(match v4.as_ref() { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v33,v34,v35) => { d_f3d84a09c00f9b9752567b30e82ffc354d1fa1f9a4b33dcef12815c9b0a5bf6e(&(d_74f987be179aff0a70be67aaf7a687192b43fbb60977140ba326b2adef21e03c(v33.as_ref(),v2,v3))) } }))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v37:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v37.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v36:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v36.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v1).wrapping_add(1u64),std::sync::Arc::clone({static v39:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v39.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v38:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v38.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v40:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v40.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } } } }}
fn t_c061f819d93d0e92b7620b91c0bb193c0a900f150010b0ebd924f32ad5f29602(v0:&D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,v1:u64,v2:u64)->D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2{match v0 { D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(v3) => { D_322726746356989dbb793aa2f5058aa8745bff76bcd682c9a4c63b3a7a4fb7c2::C0(std::sync::Arc::new(D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303::C0(std::sync::Arc::clone(v3))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(match v3.as_ref() { D_c5a82e65ace83dd2b6290044926ecde8e926ce4bc4a2a916c7d3fc4ba397d575::C0(v4,v5,v6) => { if ((((v2) & (1u64))) != (0u64)) { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v6.as_ref(),v2) } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v5.as_ref(),v2) } } }),false,v1,std::sync::Arc::clone({static v8:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v8.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v9:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v9.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } }}

use serde_json::{Value as Json,json};
mod portable{
//! Shared, representation-independent snapshot codec. This module also ships
//! verbatim in generated applications; it has no AST/evaluator dependency.
use num_bigint::{BigInt, Sign};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::cmp::Ordering;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Schema {
    Unit,
    Bool,
    U32,
    U64,
    I32,
    F32,
    Vector(Box<Schema>, u8),
    Int,
    String,
    Id,
    Record(Vec<(String, Schema)>),
    Enum(Vec<String>),
    List(Box<Schema>),
    Option(Box<Schema>),
    Result(Box<Schema>, Box<Schema>),
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Layout {
    pub program: [u8; 32],
    pub schema: [u8; 32],
    pub roots: Vec<(String, Schema, Schema)>,
    pub events: Vec<(String, Schema)>,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Event {
    pub commit: u64,
    pub position: u64,
    pub channel: usize,
    pub value: Value,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Logical {
    pub version: u64,
    pub tables: Vec<Vec<(Value, Value)>>,
    pub outbox: Vec<Event>,
}
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub bytes: usize,
    pub values: usize,
    pub depth: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            bytes: 64 * 1024 * 1024,
            values: 1_000_000,
            depth: 128,
        }
    }
}
/// Magnitude bound for one exact integer. Decimal conversion is superlinear,
/// so without it a single large Int in a snapshot takes minutes to hours.
pub const MAX_INT_BYTES: usize = 4096;
const MAGIC: &[u8; 8] = b"VLSTATE\0";
const HEADER: usize = 8 + 2 + 2 + 32 + 32 + 8;
type R<T> = Result<T, String>;
fn u64_bytes(out: &mut Vec<u8>, v: u64) {
    out.extend_from_slice(&v.to_le_bytes());
}
fn count(out: &mut Vec<u8>, n: usize) {
    u64_bytes(out, n as u64);
}
fn raw(out: &mut Vec<u8>, b: &[u8]) {
    count(out, b.len());
    out.extend_from_slice(b);
}
fn tag<'a>(v: &'a Value, name: &str) -> R<&'a Value> {
    let o = v.as_object().ok_or("expected tagged object")?;
    if o.len() != 1 {
        return Err("expected exactly one tag".into());
    }
    o.get(name).ok_or("unexpected value tag".into())
}
fn integer(v: &Value) -> R<BigInt> {
    let s = tag(v, "Int")?.as_str().ok_or("expected Int string")?;
    // Every Int within the bound has fewer than 2.41 decimal digits per byte.
    if s.len() > MAX_INT_BYTES * 5 / 2 + 1 {
        return Err("snapshot Int exceeds size limit".into());
    }
    let n = s.parse::<BigInt>().map_err(|_| "invalid Int")?;
    if n.bits() > 8 * MAX_INT_BYTES as u64 {
        return Err("snapshot Int exceeds size limit".into());
    }
    if n.to_string() != s {
        return Err("noncanonical Int".into());
    }
    Ok(n)
}
fn identifier(v: &Value) -> R<u128> {
    let s = v.as_str().ok_or("expected ID")?;
    if s.len() != 32
        || !s
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err("noncanonical ID".into());
    }
    u128::from_str_radix(s, 16).map_err(|e| e.to_string())
}
fn compare(t: &Schema, a: &Value, b: &Value) -> R<Ordering> {
    Ok(match t {
        Schema::I32 => a
            .as_i64()
            .and_then(|n| i32::try_from(n).ok())
            .ok_or("invalid i32 key")?
            .cmp(
                &b.as_i64()
                    .and_then(|n| i32::try_from(n).ok())
                    .ok_or("invalid i32 key")?,
            ),
        Schema::U32 | Schema::U64 => a
            .as_u64()
            .ok_or("invalid key")?
            .cmp(&b.as_u64().ok_or("invalid key")?),
        Schema::String => a
            .as_str()
            .ok_or("invalid key")?
            .as_bytes()
            .cmp(b.as_str().ok_or("invalid key")?.as_bytes()),
        Schema::Id => identifier(a)?.cmp(&identifier(b)?),
        _ => return Err("unsupported snapshot key schema".into()),
    })
}
fn tick(left: &mut usize, depth: usize, limits: Limits) -> R<()> {
    if *left == 0 || depth > limits.depth {
        return Err("snapshot value/depth limit exceeded".into());
    }
    *left -= 1;
    Ok(())
}
fn encode_value(
    t: &Schema,
    v: &Value,
    out: &mut Vec<u8>,
    left: &mut usize,
    depth: usize,
    limits: Limits,
) -> R<()> {
    tick(left, depth, limits)?;
    match t {
        Schema::Unit => {
            if !v.is_null() {
                return Err("expected Unit".into());
            }
        }
        Schema::Bool => out.push(v.as_bool().ok_or("expected Bool")? as u8),
        Schema::U32 => out.extend_from_slice(
            &u32::try_from(v.as_u64().ok_or("expected u32")?)
                .map_err(|_| "u32 overflow")?
                .to_le_bytes(),
        ),
        Schema::U64 => u64_bytes(out, v.as_u64().ok_or("expected u64")?),
        Schema::I32 => out.extend_from_slice(
            &i32::try_from(v.as_i64().ok_or("expected i32")?)
                .map_err(|_| "i32 overflow")?
                .to_le_bytes(),
        ),
        Schema::F32 => {
            let bits = if let Some(b) = v.get("F32Bits") {
                if v.as_object().is_none_or(|o| o.len() != 1) {
                    return Err("expected only F32Bits field".into());
                }
                u32::try_from(b.as_u64().ok_or("expected f32 bits")?)
                    .map_err(|_| "f32 bits overflow")?
            } else {
                let f = v.as_f64().ok_or("expected f32")? as f32;
                if !f.is_finite() {
                    return Err("finite f32 or F32Bits required".into());
                }
                f.to_bits()
            };
            out.extend_from_slice(&bits.to_le_bytes());
        }
        Schema::Vector(inner, n) => {
            if !(2..=4).contains(n)
                || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
            {
                return Err("invalid vector schema".into());
            }
            let xs = v.as_array().ok_or("expected vector")?;
            if xs.len() != *n as usize {
                return Err("vector dimension mismatch".into());
            }
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Int => {
            let n = integer(v)?;
            let (sign, b) = n.to_bytes_le();
            out.push(match sign {
                Sign::NoSign => 0,
                Sign::Plus => 1,
                Sign::Minus => 2,
            });
            if sign == Sign::NoSign {
                raw(out, &[])
            } else {
                raw(out, &b)
            }
        }
        Schema::String => raw(out, v.as_str().ok_or("expected String")?.as_bytes()),
        Schema::Id => out.extend_from_slice(&identifier(v)?.to_le_bytes()),
        Schema::Enum(names) => {
            let s = v.as_str().ok_or("expected enum string")?;
            let index = names
                .iter()
                .position(|n| n == s)
                .ok_or("unknown enum variant")?;
            out.extend_from_slice(&(index as u32).to_le_bytes());
        }
        Schema::Record(fields) => {
            let obj = v.as_object().ok_or("expected record")?;
            if obj.len() != fields.len() {
                return Err("record field mismatch".into());
            }
            for (n, t) in fields {
                encode_value(
                    t,
                    obj.get(n).ok_or("missing record field")?,
                    out,
                    left,
                    depth + 1,
                    limits,
                )?;
            }
        }
        Schema::List(inner) => {
            let xs = v.as_array().ok_or("expected List")?;
            if xs.len() > *left {
                return Err("snapshot value limit exceeded".into());
            }
            count(out, xs.len());
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Option(inner) => {
            if let Ok(x) = tag(v, "Some") {
                out.push(1);
                encode_value(inner, x, out, left, depth + 1, limits)?;
            } else {
                if !tag(v, "None")?.is_null() {
                    return Err("invalid None".into());
                }
                out.push(0);
            }
        }
        Schema::Result(a, b) => {
            if let Ok(x) = tag(v, "Ok") {
                out.push(0);
                encode_value(a, x, out, left, depth + 1, limits)?;
            } else {
                out.push(1);
                encode_value(b, tag(v, "Err")?, out, left, depth + 1, limits)?;
            }
        }
    }
    if out.len() > limits.bytes {
        return Err("snapshot byte limit exceeded".into());
    }
    Ok(())
}
struct Reader<'a> {
    bytes: &'a [u8],
    at: usize,
    left: usize,
    limits: Limits,
}
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> R<&'a [u8]> {
        let end = self.at.checked_add(n).ok_or("snapshot length overflow")?;
        let b = self.bytes.get(self.at..end).ok_or("truncated snapshot")?;
        self.at = end;
        Ok(b)
    }
    fn byte(&mut self) -> R<u8> {
        Ok(self.take(1)?[0])
    }
    fn u32(&mut self) -> R<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn u64(&mut self) -> R<u64> {
        Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
    fn len(&mut self) -> R<usize> {
        usize::try_from(self.u64()?).map_err(|_| "snapshot length not addressable".into())
    }
    fn sequence(&mut self) -> R<usize> {
        let n = self.len()?;
        if n > self.left {
            return Err("snapshot value limit exceeded".into());
        }
        Ok(n)
    }
    fn raw(&mut self) -> R<&'a [u8]> {
        let n = self.len()?;
        self.take(n)
    }
    fn value(&mut self, t: &Schema, depth: usize) -> R<Value> {
        tick(&mut self.left, depth, self.limits)?;
        Ok(match t {
            Schema::Unit => Value::Null,
            Schema::Bool => match self.byte()? {
                0 => json!(false),
                1 => json!(true),
                _ => return Err("invalid Bool tag".into()),
            },
            Schema::U32 => json!(self.u32()?),
            Schema::U64 => json!(self.u64()?),
            Schema::I32 => json!(self.u32()? as i32),
            Schema::F32 => {
                let bits = self.u32()?;
                let f = f32::from_bits(bits);
                if f.is_finite() {
                    json!(f)
                } else {
                    json!({"F32Bits":bits})
                }
            }
            Schema::Vector(inner, n) => {
                if !(2..=4).contains(n)
                    || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
                {
                    return Err("invalid vector schema".into());
                }
                (0..*n)
                    .map(|_| self.value(inner, depth + 1))
                    .collect::<R<Vec<_>>>()?
                    .into()
            }
            Schema::Int => {
                let sign = self.byte()?;
                let bytes = self.raw()?;
                if bytes.len() > MAX_INT_BYTES {
                    return Err("snapshot Int exceeds size limit".into());
                }
                let sign = match sign {
                    0 if bytes.is_empty() => Sign::NoSign,
                    1 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Plus,
                    2 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Minus,
                    _ => return Err("noncanonical signed integer".into()),
                };
                json!({"Int":BigInt::from_bytes_le(sign,bytes).to_string()})
            }
            Schema::String => json!(std::str::from_utf8(self.raw()?).map_err(|_| "invalid UTF-8")?),
            Schema::Id => json!(format!(
                "{:032x}",
                u128::from_le_bytes(self.take(16)?.try_into().unwrap())
            )),
            Schema::Enum(names) => {
                json!(names.get(self.u32()? as usize).ok_or("invalid enum tag")?)
            }
            Schema::Record(fields) => {
                let mut obj = serde_json::Map::new();
                for (n, t) in fields {
                    obj.insert(n.clone(), self.value(t, depth + 1)?);
                }
                Value::Object(obj)
            }
            Schema::List(t) => {
                let n = self.sequence()?;
                let mut xs = Vec::new();
                for _ in 0..n {
                    xs.push(self.value(t, depth + 1)?);
                }
                Value::Array(xs)
            }
            Schema::Option(t) => match self.byte()? {
                0 => json!({"None":null}),
                1 => json!({"Some":self.value(t,depth+1)?}),
                _ => return Err("invalid Option tag".into()),
            },
            Schema::Result(a, b) => match self.byte()? {
                0 => json!({"Ok":self.value(a,depth+1)?}),
                1 => json!({"Err":self.value(b,depth+1)?}),
                _ => return Err("invalid Result tag".into()),
            },
        })
    }
}
fn event_order(e: &Event, version: u64, prior: Option<(u64, u64)>) -> R<()> {
    if e.commit == 0 || e.commit > version || prior.is_some_and(|p| p >= (e.commit, e.position)) {
        return Err("invalid snapshot event sequence".into());
    }
    Ok(())
}
pub fn encode(layout: &Layout, s: &Logical, limits: Limits) -> R<Vec<u8>> {
    if s.tables.len() != layout.roots.len() {
        return Err("snapshot root count mismatch".into());
    }
    let mut out = Vec::new();
    let mut left = limits.values;
    u64_bytes(&mut out, s.version);
    for (rows, (_, kt, vt)) in s.tables.iter().zip(&layout.roots) {
        if rows.len() > left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        count(&mut out, rows.len());
        let mut prior = None;
        for (k, v) in rows {
            if let Some(p) = prior {
                if compare(kt, p, k)? != Ordering::Less {
                    return Err("snapshot keys must be strictly ordered".into());
                }
            }
            encode_value(kt, k, &mut out, &mut left, 0, limits)?;
            encode_value(vt, v, &mut out, &mut left, 0, limits)?;
            prior = Some(k);
        }
    }
    count(&mut out, s.outbox.len());
    let mut prior = None;
    for e in &s.outbox {
        event_order(e, s.version, prior)?;
        let (_, t) = layout
            .events
            .get(e.channel)
            .ok_or("unknown event channel")?;
        u64_bytes(&mut out, e.commit);
        u64_bytes(&mut out, e.position);
        out.extend_from_slice(&(e.channel as u32).to_le_bytes());
        encode_value(t, &e.value, &mut out, &mut left, 0, limits)?;
        prior = Some((e.commit, e.position));
    }
    if HEADER
        .checked_add(out.len())
        .and_then(|n| n.checked_add(32))
        .is_none_or(|n| n > limits.bytes)
    {
        return Err("snapshot byte limit exceeded".into());
    }
    let mut bytes = Vec::new();
    bytes.extend_from_slice(MAGIC);
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&layout.program);
    bytes.extend_from_slice(&layout.schema);
    count(&mut bytes, out.len());
    bytes.extend_from_slice(&out);
    let digest = Sha256::digest(&bytes);
    bytes.extend_from_slice(&digest);
    Ok(bytes)
}
pub fn decode(layout: &Layout, bytes: &[u8], limits: Limits) -> R<Logical> {
    if bytes.len() > limits.bytes || bytes.len() < HEADER + 32 {
        return Err("snapshot byte length invalid".into());
    }
    if &bytes[..8] != MAGIC || bytes[8..12] != [1, 0, 1, 0] {
        return Err("snapshot format or semantics version mismatch".into());
    }
    if bytes[12..44] != layout.program || bytes[44..76] != layout.schema {
        return Err("snapshot program or schema identity mismatch".into());
    }
    let n = usize::try_from(u64::from_le_bytes(bytes[76..84].try_into().unwrap()))
        .map_err(|_| "snapshot length not addressable")?;
    if HEADER.checked_add(n).and_then(|v| v.checked_add(32)) != Some(bytes.len()) {
        return Err("snapshot payload length mismatch".into());
    }
    let end = bytes.len() - 32;
    if Sha256::digest(&bytes[..end]).as_slice() != &bytes[end..] {
        return Err("snapshot integrity check failed".into());
    }
    let mut r = Reader {
        bytes: &bytes[HEADER..end],
        at: 0,
        left: limits.values,
        limits,
    };
    let version = r.u64()?;
    let mut tables = vec![];
    for (_, kt, vt) in &layout.roots {
        let n = r.sequence()?;
        if n > r.left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        let mut rows: Vec<(Value, Value)> = vec![];
        for _ in 0..n {
            let k = r.value(kt, 0)?;
            let v = r.value(vt, 0)?;
            if let Some((prior, _)) = rows.last() {
                if compare(kt, prior, &k)? != Ordering::Less {
                    return Err("duplicate or unordered snapshot key".into());
                }
            }
            rows.push((k, v));
        }
        tables.push(rows);
    }
    let n = r.sequence()?;
    let mut outbox = vec![];
    let mut prior = None;
    for _ in 0..n {
        let commit = r.u64()?;
        let position = r.u64()?;
        let channel = r.u32()? as usize;
        let (_, t) = layout
            .events
            .get(channel)
            .ok_or("unknown snapshot event channel")?;
        let value = r.value(t, 0)?;
        let e = Event {
            commit,
            position,
            channel,
            value,
        };
        event_order(&e, version, prior)?;
        prior = Some((commit, position));
        outbox.push(e);
    }
    if r.at != r.bytes.len() {
        return Err("trailing snapshot payload".into());
    }
    Ok(Logical {
        version,
        tables,
        outbox,
    })
}

}
pub use portable::Limits as SnapshotLimits;
fn snapshot_layout()->portable::Layout{portable::Layout{program:[255, 4, 117, 215, 71, 163, 245, 79, 91, 5, 184, 13, 208, 246, 185, 97, 201, 75, 126, 146, 140, 93, 124, 164, 47, 146, 227, 5, 76, 237, 154, 239],schema:[192, 141, 16, 114, 17, 172, 249, 182, 219, 154, 142, 125, 228, 252, 175, 89, 60, 246, 149, 204, 109, 105, 172, 253, 213, 158, 150, 88, 181, 131, 24, 90],roots:vec![
("Rows".into(),portable::Schema::U64,portable::Schema::U64),
],events:vec![("seen".into(),portable::Schema::U64),
]}}
fn one_tag<'a>(v:&'a Json,_kind:&str)->Result<&'a serde_json::Map<String,Json>,String>{Ok(v.as_object().unwrap())}
fn read_0(v:&Json,d:usize)->Result<bool,String>{Ok(
v.as_bool().unwrap())}
fn write_0(v:&bool,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_1(v:&Json,d:usize)->Result<u64,String>{Ok(
v.as_u64().unwrap())}
fn write_1(v:&u64,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_2(v:&Json,d:usize)->Result<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c,String>{Ok(
{D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0})}
fn write_2(v:&D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c,d:usize)->Result<Json,String>{Ok(
Json::Null)}
fn read_3(v:&Json,d:usize)->Result<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b,String>{Ok(
{let text=v.as_str().unwrap();match text{"Error.Failed"=>D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0,_=>unreachable!("caller enum precondition")}})}
fn write_3(v:&D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b,d:usize)->Result<Json,String>{Ok(
match v{D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0=>json!("Error.Failed"),})}
fn read_4(v:&Json,d:usize)->Result<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(read_1(x,d+1)?)}else{D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0}})}
fn write_4(v:&D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02,d:usize)->Result<Json,String>{Ok(
match v{D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0=>json!({"None":null}),D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(x)=>json!({"Some":write_1(x,d+1)?})})}
fn read_5(v:&Json,d:usize)->Result<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f,String>{Ok(
{let xs=one_tag(v,"Result")?;if let Some(x)=xs.get("Ok"){D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::new(read_2(x,d+1)?))}else{let x=xs.get("Err").unwrap();D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::new(read_3(x,d+1)?))}})}
fn write_5(v:&D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f,d:usize)->Result<Json,String>{Ok(
match v{D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(x)=>json!({"Ok":write_2(x,d+1)?}),D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(x)=>json!({"Err":write_3(x,d+1)?})})}
fn logical_from_tables(tables:&[Vec<(Json,Json)>])->Result<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d,String>{if tables.len()!=1{return Err("representation table count mismatch".into())}
let rows=&tables[0];let mut root0=D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0;for (key,row) in rows.iter().rev(){root0=D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(read_1(key,0)?,read_1(row,0)?,std::sync::Arc::new(root0));}
Ok(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(root0)))}
fn logical_tables(state:&D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d)->Result<Vec<Vec<(Json,Json)>>,String>{let D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(r0)=state;
let mut rows0=vec![];let mut cursor=r0.as_ref();loop{match cursor{D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0=>break,D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(key,value,tail)=>{rows0.push((write_1(key,0)?,write_1(value,0)?));cursor=tail.as_ref();}}}
Ok(vec![rows0])}
fn logical_events(events:&D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de)->Result<Vec<(usize,Json)>,String>{let mut cursor=events;let mut out=vec![];loop{match cursor{D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0=>break,D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(event,tail)=>{let value=match event.as_ref(){
D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(value)=>(0,write_1(value,0)?),
};out.push(value);cursor=tail.as_ref();}}}Ok(out)}
pub use portable::Event;
pub struct Outcome<T>{pub result:T,pub committed:bool,pub version:u64,pub events:Vec<Event>}
pub struct OutcomeView<'a,T>{pub result:T,pub committed:bool,pub version:u64,pub events:&'a[Event]}
impl<T> OutcomeView<'_,T>{pub fn into_owned(self)->Outcome<T>{Outcome{result:self.result,committed:self.committed,version:self.version,events:self.events.to_vec()}}}
pub struct State{physical:D_30561b9c7db0fd3298022981b38be32ce503397e5be360f6ebc632e559ec0303,version:u64,outbox:Vec<portable::Event>,layout:portable::Layout}
impl State{
// CALLER CONTRACT: arguments must have the declared types and canonical values.
// No runtime type validation. Malformed input may panic, trap or corrupt state.
pub fn new()->Result<Self,String>{let logical=D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0));Ok(Self{physical:f_1fa0d7c9a94ed7c13756f1d32ce86aecfadf222cf31d8027044d8cc4e83fd5e8(&logical),version:0,outbox:vec![],layout:snapshot_layout()})}
pub fn restore(bytes:&[u8])->Result<Self,String>{let layout=snapshot_layout();let saved=portable::decode(&layout,bytes,SnapshotLimits::default())?;let logical=logical_from_tables(&saved.tables)?;Ok(Self{physical:f_1fa0d7c9a94ed7c13756f1d32ce86aecfadf222cf31d8027044d8cc4e83fd5e8(&logical),version:saved.version,outbox:saved.outbox,layout})}
pub fn checkpoint(&self)->Result<Vec<u8>,String>{let logical=f_9bc49f94718bc036cc9ddff09c1c68b115e7c6476a12355d708959e5c6d5efdb(&(self.physical));portable::encode(&self.layout,&portable::Logical{version:self.version,tables:logical_tables(&logical)?,outbox:self.outbox.clone()},SnapshotLimits::default())}
pub fn version(&self)->u64{self.version}
pub fn outbox_json(&self)->Json{Json::Array(self.outbox.iter().map(|e|json!({"commit":e.commit,"position":e.position,"channel":self.layout.events[e.channel].0,"value":e.value})).collect())}
pub fn acknowledge_through(&mut self,commit:u64,position:u64){self.outbox.retain(|e|(e.commit,e.position)>(commit,position));}
pub fn query_zero(&self,)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{q_3656b75bbdd1c96448eb777c3d928a445e8c03f0ce56581048ef0d1c9a1ac5bc(&(self.physical),self.version)}
pub fn query_get(&self,a0:u64)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{q_c061f819d93d0e92b7620b91c0bb193c0a900f150010b0ebd924f32ad5f29602(&(self.physical),self.version,a0)}
pub fn query_one(&self,)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{q_12362e281b3997963ae3c26e64de0c549b3052123196bcb5943a98de1f80e587(&(self.physical),self.version)}
pub fn invoke_view_put(&mut self,a0:u64,a1:u64)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=t_9c35951fbd2f936287a47cd9bdae516aa294e04d31fdd0aeec0f641695ba6846(&(self.physical),self.version,a0,a1);let observed=f_54dd99bd961ff76b6f2d72c0de32fb2796619a2a2f0c82a14590fb7cce7ba4f4(&(executed));let next=f_21a235cc347ec2416702c8248af926191a466c46fb54e6f14f7f7aab47e28a94(&(executed));
let(result,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_replace(&mut self,a0:u64,a1:u64,a2:bool)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=t_5a15529df8e4cb28cdeb094163a2a1077596795737689d8bdbc6eced560f087d(&(self.physical),self.version,a0,a1,a2);let observed=f_54dd99bd961ff76b6f2d72c0de32fb2796619a2a2f0c82a14590fb7cce7ba4f4(&(executed));let next=f_21a235cc347ec2416702c8248af926191a466c46fb54e6f14f7f7aab47e28a94(&(executed));
let(result,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_erase(&mut self,a0:u64,a1:bool)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=t_353625e8f5afea9bd0cb854674538d244f4fbb2136ba9af1241ed806b47eceb6(&(self.physical),self.version,a0,a1);let observed=f_54dd99bd961ff76b6f2d72c0de32fb2796619a2a2f0c82a14590fb7cce7ba4f4(&(executed));let next=f_21a235cc347ec2416702c8248af926191a466c46fb54e6f14f7f7aab47e28a94(&(executed));
let(result,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_zero(&mut self,)->Result<OutcomeView<'_,D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,String>{
let result=q_3656b75bbdd1c96448eb777c3d928a445e8c03f0ce56581048ef0d1c9a1ac5bc(&(self.physical),self.version);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_view_get(&mut self,a0:u64)->Result<OutcomeView<'_,D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,String>{
let result=q_c061f819d93d0e92b7620b91c0bb193c0a900f150010b0ebd924f32ad5f29602(&(self.physical),self.version,a0);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_view_one(&mut self,)->Result<OutcomeView<'_,D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,String>{
let result=q_12362e281b3997963ae3c26e64de0c549b3052123196bcb5943a98de1f80e587(&(self.physical),self.version);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_json(&mut self,name:&str,args:&Json)->Result<Json,String>{match name{
"put"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_1(&xs[1],0)?;
let executed=t_9c35951fbd2f936287a47cd9bdae516aa294e04d31fdd0aeec0f641695ba6846(&(self.physical),self.version,a0,a1);
let observed=f_54dd99bd961ff76b6f2d72c0de32fb2796619a2a2f0c82a14590fb7cce7ba4f4(&(executed));let next=f_21a235cc347ec2416702c8248af926191a466c46fb54e6f14f7f7aab47e28a94(&(executed));let(reply,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_5(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"replace"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_1(&xs[1],0)?;
let a2=read_0(&xs[2],0)?;
let executed=t_5a15529df8e4cb28cdeb094163a2a1077596795737689d8bdbc6eced560f087d(&(self.physical),self.version,a0,a1,a2);
let observed=f_54dd99bd961ff76b6f2d72c0de32fb2796619a2a2f0c82a14590fb7cce7ba4f4(&(executed));let next=f_21a235cc347ec2416702c8248af926191a466c46fb54e6f14f7f7aab47e28a94(&(executed));let(reply,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_5(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"erase"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_0(&xs[1],0)?;
let executed=t_353625e8f5afea9bd0cb854674538d244f4fbb2136ba9af1241ed806b47eceb6(&(self.physical),self.version,a0,a1);
let observed=f_54dd99bd961ff76b6f2d72c0de32fb2796619a2a2f0c82a14590fb7cce7ba4f4(&(executed));let next=f_21a235cc347ec2416702c8248af926191a466c46fb54e6f14f7f7aab47e28a94(&(executed));let(reply,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_5(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"zero"=>{let xs=args.as_array().unwrap();
let reply=q_3656b75bbdd1c96448eb777c3d928a445e8c03f0ce56581048ef0d1c9a1ac5bc(&(self.physical),self.version);let result=write_4(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
"get"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let reply=q_c061f819d93d0e92b7620b91c0bb193c0a900f150010b0ebd924f32ad5f29602(&(self.physical),self.version,a0);let result=write_4(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
"one"=>{let xs=args.as_array().unwrap();
let reply=q_12362e281b3997963ae3c26e64de0c549b3052123196bcb5943a98de1f80e587(&(self.physical),self.version);let result=write_4(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
_=>Err(format!("unknown action {name}"))}}}
