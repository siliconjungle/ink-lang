// ink-definition-rust-v1: checked bodies; Rust/backend are trusted.
#![allow(non_camel_case_types, non_snake_case, non_upper_case_globals, dead_code, unused_variables, unused_parens, unused_unsafe, improper_ctypes_definitions)]
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { C0,C1(u64,std::sync::Arc<D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b>) }
impl D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_050b373a79d555c2577b1594d727d6cf1a60f9d11529a88ab3da5b35c5a8e44c(v0: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a,v1: u64,v2: u64) -> D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { match v0 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v3,v4) => { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_50c6c395084616f9cf6a84c8e8d2ce70d6746e042d9806094ed93d60eebb1efd(v3.as_ref(),v1,v2)),std::sync::Arc::new(d_71ef1cbc686007bd38b0eee5db382b08020455dcaa4fc18959fbc042b3c67cd2(v3.as_ref(),v4.as_ref(),v1,v2))) } } }
fn d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v5: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v6: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v7: u64) -> D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02 { match v5 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v9,v10) => { match v6 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v12,v13) => { if ((v7) == (*v9)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(*v12) } else { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v10.as_ref(),v13.as_ref(),v7) } } } } } }
fn d_1242bcb235dc8376a3b3666718bf63c51093f71356dd18708bf5b17137d855d0(v14: &D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v14 { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(v16,v17,v18) => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v17,std::sync::Arc::new(d_1242bcb235dc8376a3b3666718bf63c51093f71356dd18708bf5b17137d855d0(v18.as_ref()))) } } }
fn d_13383bb021a496f46e5c221fcc119b83f058c88a3aeb894d16cf3e940529a73d(v19: &D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8) -> D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d { match v19 { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(v20) => { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v20.as_ref()))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8 { C0(std::sync::Arc<D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a>) }
fn d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v21: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a,v22: u64) -> D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02 { match v21 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v23,v24) => { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v23.as_ref(),v24.as_ref(),v22) } } }
fn d_31da817461332a272329ebaf8d8b88dd1d957e34b37ae8df6eb4420cfcf2cc0d(v25: &D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v25 { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(v27,v28,v29) => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v27,std::sync::Arc::new(d_31da817461332a272329ebaf8d8b88dd1d957e34b37ae8df6eb4420cfcf2cc0d(v29.as_ref()))) } } }
fn d_32d8eb00f1c14d65ee1e9bcb63c2d346a4a0dfb462d877162c591fd67cde3333(v30: &D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v31: u64) -> D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76 { match v30 { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(v32) => { D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v32))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v32.as_ref(),0u64)),false,v31,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v32.as_ref())))),std::sync::Arc::clone({static v33:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v33.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } }
fn d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v34: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a) -> D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807 { match v34 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v35,v36) => { d_8c71c9ec54433ede7b1b11cf4d4e65e192bf24e83eb2912562d70a1052e368ac(v35.as_ref(),v36.as_ref()) } } }
fn d_38c41f3a25a0d4a109cc5dd244db885004f777daa2d390a72dfc261ba7e4d991(v37: &D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76) -> D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8 { match v37 { D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76::C0(v38,v39) => { (v38.as_ref()).clone() } } }
fn d_3b70ef55c71639277b04dbb2f126534f6cc99e8d2576cb1493ee85c592da045e(v40: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v41: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v40 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v43,v44) => { if ((v41) == (*v43)) { d_3b70ef55c71639277b04dbb2f126534f6cc99e8d2576cb1493ee85c592da045e(v44.as_ref(),v41) } else { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v43,std::sync::Arc::new(d_3b70ef55c71639277b04dbb2f126534f6cc99e8d2576cb1493ee85c592da045e(v44.as_ref(),v41))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d { C0(std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>) }
fn d_50c6c395084616f9cf6a84c8e8d2ce70d6746e042d9806094ed93d60eebb1efd(v45: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v46: u64,v47: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v45 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v49,v50) => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v49,std::sync::Arc::new(d_50c6c395084616f9cf6a84c8e8d2ce70d6746e042d9806094ed93d60eebb1efd(v50.as_ref(),v46,v47))) } } }
fn d_52b3364f042aeec1d1ab03c2e590c0a1ad64048ce1065617e01ef12e356f71de(v51: &D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3) -> D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8 { match v51 { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(v52,v53) => { (v52.as_ref()).clone() } } }
fn d_5a06c1e0f1bfd57716580fd5d6f2633571ffebb7ad2375b325be26e4d8b2da16(v54: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v55: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v56: u64,v57: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v54 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v57,std::sync::Arc::clone({static v58:std::sync::OnceLock<std::sync::Arc<D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b>>=std::sync::OnceLock::new();v58.get_or_init(||std::sync::Arc::new(D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0))})) },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v59,v60) => { match v55 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v62,v63) => { if ((v56) < (*v59)) { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v57,std::sync::Arc::new((v55).clone())) } else { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v62,std::sync::Arc::new(d_5a06c1e0f1bfd57716580fd5d6f2633571ffebb7ad2375b325be26e4d8b2da16(v60.as_ref(),v63.as_ref(),v56,v57))) } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76 { C0(std::sync::Arc<D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8>,std::sync::Arc<D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994>) }
fn d_6f89259f76d8459d1446802cfbe1beab8eab0089cf176a377ef57570d174e855(v64: &D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v65: u64,v66: u64) -> D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76 { match v64 { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(v67) => { D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v67))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v67.as_ref(),v66)),false,v65,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v67.as_ref())))),std::sync::Arc::clone({static v68:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v68.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } }
fn d_6f951a654c399751d2ab43fc23ac5c97a43a73b65d7184b52a00fec1c245c84c(v69: &D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807) -> D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_31da817461332a272329ebaf8d8b88dd1d957e34b37ae8df6eb4420cfcf2cc0d(v69)),std::sync::Arc::new(d_1242bcb235dc8376a3b3666718bf63c51093f71356dd18708bf5b17137d855d0(v69))) }
fn d_71ef1cbc686007bd38b0eee5db382b08020455dcaa4fc18959fbc042b3c67cd2(v70: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v71: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v72: u64,v73: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v70 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v75,v76) => { match v71 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v78,v79) => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(if ((v72) == (*v75)) { v73 } else { *v78 },std::sync::Arc::new(d_71ef1cbc686007bd38b0eee5db382b08020455dcaa4fc18959fbc042b3c67cd2(v76.as_ref(),v79.as_ref(),v72,v73))) } } } } }
fn d_74eaa58afd0c8c1c32b227627a4c500cf7cc3679f11be601dd3fb9d5ab31abc4(v80: &D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v81: u64,v82: u64,v83: u64) -> D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3 { match v80 { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(v84) => { if match &(d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v84.as_ref(),v82)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v85) => { true } } { if match &(d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v84.as_ref(),v82)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v86) => { true } } { if ((v81) == (18446744073709551615u64)) { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v84))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v81,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v84.as_ref()))))))) } else { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::new(d_050b373a79d555c2577b1594d727d6cf1a60f9d11529a88ab3da5b35c5a8e44c(v84.as_ref(),v82,v83)))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v88:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v88.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v87:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v87.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v81).wrapping_add(1u64),std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(&(d_050b373a79d555c2577b1594d727d6cf1a60f9d11529a88ab3da5b35c5a8e44c(v84.as_ref(),v82,v83)))))),std::sync::Arc::clone({static v89:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v89.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } else { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v84))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v81,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v84.as_ref()))))))) } } else { if match &(d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v84.as_ref(),v82)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v90) => { true } } { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v84))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v81,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v84.as_ref()))))))) } else { if ((v81) == (18446744073709551615u64)) { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v84))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v81,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v84.as_ref()))))))) } else { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::new(d_74f987be179aff0a70be67aaf7a687192b43fbb60977140ba326b2adef21e03c(v84.as_ref(),v82,v83)))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v92:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v92.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v91:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v91.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v81).wrapping_add(1u64),std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(&(d_74f987be179aff0a70be67aaf7a687192b43fbb60977140ba326b2adef21e03c(v84.as_ref(),v82,v83)))))),std::sync::Arc::clone({static v93:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v93.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } } } } }
fn d_74f987be179aff0a70be67aaf7a687192b43fbb60977140ba326b2adef21e03c(v94: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a,v95: u64,v96: u64) -> D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { match v94 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v97,v98) => { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_e7f3abf6f9dd0953bd24c47e8f8d261bd6b25dca50d60e76c02bfaf73890cf93(v97.as_ref(),v95,v96)),std::sync::Arc::new(d_5a06c1e0f1bfd57716580fd5d6f2633571ffebb7ad2375b325be26e4d8b2da16(v97.as_ref(),v98.as_ref(),v95,v96))) } } }
fn d_75b36e9bcc8983f503aed6cc3390d40933b881806b71b241d41d15f5ee405815(v99: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v100: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v101: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v99 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v103,v104) => { match v100 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v106,v107) => { if ((v101) == (*v103)) { d_75b36e9bcc8983f503aed6cc3390d40933b881806b71b241d41d15f5ee405815(v104.as_ref(),v107.as_ref(),v101) } else { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v106,std::sync::Arc::new(d_75b36e9bcc8983f503aed6cc3390d40933b881806b71b241d41d15f5ee405815(v104.as_ref(),v107.as_ref(),v101))) } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807 { C0,C1(u64,u64,std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>) }
impl D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_7e073df7e15b460e7b36bbcaa09dc13ff3e8edce961808bd40245f3847aa6575(v108: &D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d) -> D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8 { match v108 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v109) => { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::new(d_6f951a654c399751d2ab43fc23ac5c97a43a73b65d7184b52a00fec1c245c84c(v109.as_ref()))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953 { C0(std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,bool,u64,std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>,std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>),C1(u64,u64,std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>) }
fn d_7fe1c26b37bc99c3fbd2990341be945929045f0f5eb871c32ba6cbe0361b9baa(v110: &D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v111: u64,v112: u64,v113: bool) -> D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3 { match v110 { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(v114) => { if v113 { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v114))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v116:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v116.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v115:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v115.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v111,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v114.as_ref())))),std::sync::Arc::clone({static v117:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v117.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } else { if ((v111) == (18446744073709551615u64)) { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v114))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v111,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v114.as_ref()))))))) } else { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::new(d_df95fd31337deaad84f3abe0d6c13adc30ae22013972652e3b6e45d2fff2139c(&(d_df95fd31337deaad84f3abe0d6c13adc30ae22013972652e3b6e45d2fff2139c(v114.as_ref(),v112)),v112)))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v119:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v119.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v118:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v118.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v111).wrapping_add(1u64),std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(&(d_df95fd31337deaad84f3abe0d6c13adc30ae22013972652e3b6e45d2fff2139c(&(d_df95fd31337deaad84f3abe0d6c13adc30ae22013972652e3b6e45d2fff2139c(v114.as_ref(),v112)),v112)))))),std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(std::sync::Arc::new(D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(v112)),std::sync::Arc::clone({static v120:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v120.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))))) } } } } }
fn d_8c71c9ec54433ede7b1b11cf4d4e65e192bf24e83eb2912562d70a1052e368ac(v121: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v122: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b) -> D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807 { match v121 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v124,v125) => { match v122 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v127,v128) => { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(*v124,*v127,std::sync::Arc::new(d_8c71c9ec54433ede7b1b11cf4d4e65e192bf24e83eb2912562d70a1052e368ac(v125.as_ref(),v128.as_ref()))) } } } } }
fn d_8cf537a6f275e681ccd1c722183466a72c3cef925fa799180bb63110f3942bcc(v129: &D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76) -> D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { match v129 { D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76::C0(v130,v131) => { (v131.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f { C0(std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>),C1(std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de { C0,C1(std::sync::Arc<D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6>,std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>) }
impl D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3 { C0(std::sync::Arc<D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8>,std::sync::Arc<D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02 { C0,C1(u64) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c { C0 }
impl D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_bc22a9f9bebbae59c6383d19f7f6c15b3cb7077283df64748192f7cfce71e2bb(v132: &D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v133: u64,v134: u64,v135: u64,v136: bool) -> D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3 { match v132 { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(v137) => { if match &(d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v137.as_ref(),v134)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v138) => { true } } { if match &(d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v137.as_ref(),v134)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v139) => { true } } { if v136 { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v137))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v141:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v141.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v140:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v140.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v133,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v137.as_ref())))),std::sync::Arc::clone({static v142:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v142.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } else { if ((v133) == (18446744073709551615u64)) { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v137))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v133,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v137.as_ref()))))))) } else { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::new(d_050b373a79d555c2577b1594d727d6cf1a60f9d11529a88ab3da5b35c5a8e44c(v137.as_ref(),v134,v135)))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v144:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v144.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v143:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v143.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v133).wrapping_add(1u64),std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(&(d_050b373a79d555c2577b1594d727d6cf1a60f9d11529a88ab3da5b35c5a8e44c(v137.as_ref(),v134,v135)))))),std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(std::sync::Arc::new(D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(v135)),std::sync::Arc::clone({static v145:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v145.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))))) } } } else { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v137))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v133,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v137.as_ref()))))))) } } else { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v137))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v147:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v147.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v146:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v146.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v133,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v137.as_ref())))),std::sync::Arc::clone({static v148:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v148.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b { C0 }
impl D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_cf93ff2613b2f954b4cc9567499b126525e85b8f3c5d940c086428428167b05d(v149: &D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3) -> D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953 { match v149 { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(v150,v151) => { (v151.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6 { C0(u64) }
fn d_df95fd31337deaad84f3abe0d6c13adc30ae22013972652e3b6e45d2fff2139c(v152: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a,v153: u64) -> D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { match v152 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v154,v155) => { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_3b70ef55c71639277b04dbb2f126534f6cc99e8d2576cb1493ee85c592da045e(v154.as_ref(),v153)),std::sync::Arc::new(d_75b36e9bcc8983f503aed6cc3390d40933b881806b71b241d41d15f5ee405815(v154.as_ref(),v155.as_ref(),v153))) } } }
fn d_e7f3abf6f9dd0953bd24c47e8f8d261bd6b25dca50d60e76c02bfaf73890cf93(v156: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v157: u64,v158: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v156 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v157,std::sync::Arc::clone({static v159:std::sync::OnceLock<std::sync::Arc<D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b>>=std::sync::OnceLock::new();v159.get_or_init(||std::sync::Arc::new(D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0))})) },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v160,v161) => { if ((v157) < (*v160)) { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v157,std::sync::Arc::new((v156).clone())) } else { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v160,std::sync::Arc::new(d_e7f3abf6f9dd0953bd24c47e8f8d261bd6b25dca50d60e76c02bfaf73890cf93(v161.as_ref(),v157,v158))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { C0(std::sync::Arc<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,bool,u64,std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>,std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>),C1(u64,u64,std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { C0(std::sync::Arc<D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b>,std::sync::Arc<D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b>) }
fn d_fa41c269d695fb91d2319cca0a104200e12361ff953d31d53e5b418d68f91fe5(v162: &D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v163: u64) -> D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76 { match v162 { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(v164) => { D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v164))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v164.as_ref(),1u64)),false,v163,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v164.as_ref())))),std::sync::Arc::clone({static v165:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v165.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } }
pub fn f_13383bb021a496f46e5c221fcc119b83f058c88a3aeb894d16cf3e940529a73d(v166: &D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8) -> D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d { d_13383bb021a496f46e5c221fcc119b83f058c88a3aeb894d16cf3e940529a73d(v166) }
pub fn f_32d8eb00f1c14d65ee1e9bcb63c2d346a4a0dfb462d877162c591fd67cde3333(v167: &D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v168: u64) -> D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76 { d_32d8eb00f1c14d65ee1e9bcb63c2d346a4a0dfb462d877162c591fd67cde3333(v167,v168) }
pub fn f_38c41f3a25a0d4a109cc5dd244db885004f777daa2d390a72dfc261ba7e4d991(v169: &D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76) -> D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8 { d_38c41f3a25a0d4a109cc5dd244db885004f777daa2d390a72dfc261ba7e4d991(v169) }
pub fn f_52b3364f042aeec1d1ab03c2e590c0a1ad64048ce1065617e01ef12e356f71de(v170: &D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3) -> D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8 { d_52b3364f042aeec1d1ab03c2e590c0a1ad64048ce1065617e01ef12e356f71de(v170) }
pub fn f_6f89259f76d8459d1446802cfbe1beab8eab0089cf176a377ef57570d174e855(v171: &D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v172: u64,v173: u64) -> D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76 { d_6f89259f76d8459d1446802cfbe1beab8eab0089cf176a377ef57570d174e855(v171,v172,v173) }
pub fn f_74eaa58afd0c8c1c32b227627a4c500cf7cc3679f11be601dd3fb9d5ab31abc4(v174: &D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v175: u64,v176: u64,v177: u64) -> D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3 { d_74eaa58afd0c8c1c32b227627a4c500cf7cc3679f11be601dd3fb9d5ab31abc4(v174,v175,v176,v177) }
pub fn f_7e073df7e15b460e7b36bbcaa09dc13ff3e8edce961808bd40245f3847aa6575(v178: &D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d) -> D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8 { d_7e073df7e15b460e7b36bbcaa09dc13ff3e8edce961808bd40245f3847aa6575(v178) }
pub fn f_7fe1c26b37bc99c3fbd2990341be945929045f0f5eb871c32ba6cbe0361b9baa(v179: &D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v180: u64,v181: u64,v182: bool) -> D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3 { d_7fe1c26b37bc99c3fbd2990341be945929045f0f5eb871c32ba6cbe0361b9baa(v179,v180,v181,v182) }
pub fn f_8cf537a6f275e681ccd1c722183466a72c3cef925fa799180bb63110f3942bcc(v183: &D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76) -> D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { d_8cf537a6f275e681ccd1c722183466a72c3cef925fa799180bb63110f3942bcc(v183) }
pub fn f_bc22a9f9bebbae59c6383d19f7f6c15b3cb7077283df64748192f7cfce71e2bb(v184: &D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v185: u64,v186: u64,v187: u64,v188: bool) -> D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3 { d_bc22a9f9bebbae59c6383d19f7f6c15b3cb7077283df64748192f7cfce71e2bb(v184,v185,v186,v187,v188) }
pub fn f_cf93ff2613b2f954b4cc9567499b126525e85b8f3c5d940c086428428167b05d(v189: &D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3) -> D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953 { d_cf93ff2613b2f954b4cc9567499b126525e85b8f3c5d940c086428428167b05d(v189) }
pub fn f_fa41c269d695fb91d2319cca0a104200e12361ff953d31d53e5b418d68f91fe5(v190: &D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v191: u64) -> D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76 { d_fa41c269d695fb91d2319cca0a104200e12361ff953d31d53e5b418d68f91fe5(v190,v191) }
fn q_32d8eb00f1c14d65ee1e9bcb63c2d346a4a0dfb462d877162c591fd67cde3333(v0:&D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v1:u64)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{match v0 { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(v2) => { match v2.as_ref() { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v3,v4) => { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v3.as_ref(),v4.as_ref(),0u64) } } } }}
fn q_6f89259f76d8459d1446802cfbe1beab8eab0089cf176a377ef57570d174e855(v0:&D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v1:u64,v2:u64)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{match v0 { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(v3) => { match v3.as_ref() { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v4,v5) => { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v4.as_ref(),v5.as_ref(),v2) } } } }}
fn q_fa41c269d695fb91d2319cca0a104200e12361ff953d31d53e5b418d68f91fe5(v0:&D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v1:u64)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{match v0 { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(v2) => { match v2.as_ref() { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v3,v4) => { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v3.as_ref(),v4.as_ref(),1u64) } } } }}
fn t_32d8eb00f1c14d65ee1e9bcb63c2d346a4a0dfb462d877162c591fd67cde3333(v0:&D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v1:u64)->D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76{match v0 { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(v2) => { D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v2))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(match v2.as_ref() { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v3,v4) => { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v3.as_ref(),v4.as_ref(),0u64) } }),false,v1,std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } }}
fn t_6f89259f76d8459d1446802cfbe1beab8eab0089cf176a377ef57570d174e855(v0:&D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v1:u64,v2:u64)->D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76{match v0 { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(v3) => { D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v3))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(match v3.as_ref() { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v4,v5) => { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v4.as_ref(),v5.as_ref(),v2) } }),false,v1,std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v8:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v8.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } }}
fn t_74eaa58afd0c8c1c32b227627a4c500cf7cc3679f11be601dd3fb9d5ab31abc4(v0:&D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v1:u64,v2:u64,v3:u64)->D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3{match v0 { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(v4) => { if match &(match v4.as_ref() { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v5,v6) => { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v5.as_ref(),v6.as_ref(),v2) } }) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v7) => { true } } { if match &(match v4.as_ref() { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v8,v9) => { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v8.as_ref(),v9.as_ref(),v2) } }) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v10) => { true } } { if ((v1) == (18446744073709551615u64)) { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v1,std::sync::Arc::clone({static v12:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v12.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v11:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v11.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } else { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::new(match v4.as_ref() { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v13,v14) => { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_50c6c395084616f9cf6a84c8e8d2ce70d6746e042d9806094ed93d60eebb1efd(v13.as_ref(),v2,v3)),std::sync::Arc::new(d_71ef1cbc686007bd38b0eee5db382b08020455dcaa4fc18959fbc042b3c67cd2(v13.as_ref(),v14.as_ref(),v2,v3))) } }))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v16:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v16.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v15:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v15.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v1).wrapping_add(1u64),std::sync::Arc::clone({static v18:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v18.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v17:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v17.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v19:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v19.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } else { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v1,std::sync::Arc::clone({static v21:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v21.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v20:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v20.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } } else { if match &(match v4.as_ref() { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v22,v23) => { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v22.as_ref(),v23.as_ref(),v2) } }) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v24) => { true } } { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v1,std::sync::Arc::clone({static v26:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v26.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v25:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v25.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } else { if ((v1) == (18446744073709551615u64)) { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v1,std::sync::Arc::clone({static v28:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v28.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v27:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v27.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } else { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::new(match v4.as_ref() { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v29,v30) => { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_e7f3abf6f9dd0953bd24c47e8f8d261bd6b25dca50d60e76c02bfaf73890cf93(v29.as_ref(),v2,v3)),std::sync::Arc::new(d_5a06c1e0f1bfd57716580fd5d6f2633571ffebb7ad2375b325be26e4d8b2da16(v29.as_ref(),v30.as_ref(),v2,v3))) } }))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v32:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v32.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v31:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v31.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v1).wrapping_add(1u64),std::sync::Arc::clone({static v34:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v34.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v33:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v33.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v35:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v35.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } } } }}
fn t_7fe1c26b37bc99c3fbd2990341be945929045f0f5eb871c32ba6cbe0361b9baa(v0:&D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v1:u64,v2:u64,v3:bool)->D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3{match v0 { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(v4) => { if v3 { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v1,std::sync::Arc::clone({static v8:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v8.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v9:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v9.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } else { if ((v1) == (18446744073709551615u64)) { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v1,std::sync::Arc::clone({static v11:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v11.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v10:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v10.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } else { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::new(match &(match v4.as_ref() { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v12,v13) => { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_3b70ef55c71639277b04dbb2f126534f6cc99e8d2576cb1493ee85c592da045e(v12.as_ref(),v2)),std::sync::Arc::new(d_75b36e9bcc8983f503aed6cc3390d40933b881806b71b241d41d15f5ee405815(v12.as_ref(),v13.as_ref(),v2))) } }) { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v14,v15) => { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_3b70ef55c71639277b04dbb2f126534f6cc99e8d2576cb1493ee85c592da045e(v14.as_ref(),v2)),std::sync::Arc::new(d_75b36e9bcc8983f503aed6cc3390d40933b881806b71b241d41d15f5ee405815(v14.as_ref(),v15.as_ref(),v2))) } }))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v17:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v17.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v16:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v16.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v1).wrapping_add(1u64),std::sync::Arc::clone({static v19:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v19.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v18:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v18.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(std::sync::Arc::new(D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(v2)),std::sync::Arc::clone({static v20:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v20.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))))) } } } }}
fn t_bc22a9f9bebbae59c6383d19f7f6c15b3cb7077283df64748192f7cfce71e2bb(v0:&D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v1:u64,v2:u64,v3:u64,v4:bool)->D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3{match v0 { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(v5) => { if match &(match v5.as_ref() { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v6,v7) => { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v6.as_ref(),v7.as_ref(),v2) } }) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v8) => { true } } { if match &(match v5.as_ref() { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v9,v10) => { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v9.as_ref(),v10.as_ref(),v2) } }) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v11) => { true } } { if v4 { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v5))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v13:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v13.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v12:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v12.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v1,std::sync::Arc::clone({static v15:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v15.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v14:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v14.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v16:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v16.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } else { if ((v1) == (18446744073709551615u64)) { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v5))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v1,std::sync::Arc::clone({static v18:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v18.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v17:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v17.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } else { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::new(match v5.as_ref() { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v19,v20) => { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_50c6c395084616f9cf6a84c8e8d2ce70d6746e042d9806094ed93d60eebb1efd(v19.as_ref(),v2,v3)),std::sync::Arc::new(d_71ef1cbc686007bd38b0eee5db382b08020455dcaa4fc18959fbc042b3c67cd2(v19.as_ref(),v20.as_ref(),v2,v3))) } }))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v22:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v22.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v21:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v21.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v1).wrapping_add(1u64),std::sync::Arc::clone({static v24:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v24.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v23:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v23.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(std::sync::Arc::new(D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(v3)),std::sync::Arc::clone({static v25:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v25.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))))) } } } else { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v5))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v1,std::sync::Arc::clone({static v27:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v27.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v26:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v26.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } } else { D_a87d37218f4731bf8e244e76cd7625f5005d62743482550c135a19a4d4b272b3::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v5))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v29:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v29.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v28:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v28.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v1,std::sync::Arc::clone({static v31:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v31.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v30:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v30.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v32:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v32.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } }}
fn t_fa41c269d695fb91d2319cca0a104200e12361ff953d31d53e5b418d68f91fe5(v0:&D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,v1:u64)->D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76{match v0 { D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(v2) => { D_69d4ac59df5146cfea466d4e8b714997dd007a3b860ab2fa3da62e4bae3aed76::C0(std::sync::Arc::new(D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8::C0(std::sync::Arc::clone(v2))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(match v2.as_ref() { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v3,v4) => { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v3.as_ref(),v4.as_ref(),1u64) } }),false,v1,std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } }}

use serde_json::{Value as Json,json};
mod portable{
//! Shared, representation-independent snapshot codec. This module also ships
//! verbatim in generated applications; it has no AST/evaluator dependency.
use num_bigint::{BigInt, Sign};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::cmp::Ordering;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Schema {
    Unit,
    Bool,
    U32,
    U64,
    I32,
    F32,
    Vector(Box<Schema>, u8),
    Int,
    String,
    Id,
    Record(Vec<(String, Schema)>),
    Enum(Vec<String>),
    List(Box<Schema>),
    Option(Box<Schema>),
    Result(Box<Schema>, Box<Schema>),
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Layout {
    pub program: [u8; 32],
    pub schema: [u8; 32],
    pub roots: Vec<(String, Schema, Schema)>,
    pub events: Vec<(String, Schema)>,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Event {
    pub commit: u64,
    pub position: u64,
    pub channel: usize,
    pub value: Value,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Logical {
    pub version: u64,
    pub tables: Vec<Vec<(Value, Value)>>,
    pub outbox: Vec<Event>,
}
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub bytes: usize,
    pub values: usize,
    pub depth: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            bytes: 64 * 1024 * 1024,
            values: 1_000_000,
            depth: 128,
        }
    }
}
/// Magnitude bound for one exact integer. Decimal conversion is superlinear,
/// so without it a single large Int in a snapshot takes minutes to hours.
pub const MAX_INT_BYTES: usize = 4096;
const MAGIC: &[u8; 8] = b"VLSTATE\0";
const HEADER: usize = 8 + 2 + 2 + 32 + 32 + 8;
type R<T> = Result<T, String>;
fn u64_bytes(out: &mut Vec<u8>, v: u64) {
    out.extend_from_slice(&v.to_le_bytes());
}
fn count(out: &mut Vec<u8>, n: usize) {
    u64_bytes(out, n as u64);
}
fn raw(out: &mut Vec<u8>, b: &[u8]) {
    count(out, b.len());
    out.extend_from_slice(b);
}
fn tag<'a>(v: &'a Value, name: &str) -> R<&'a Value> {
    let o = v.as_object().ok_or("expected tagged object")?;
    if o.len() != 1 {
        return Err("expected exactly one tag".into());
    }
    o.get(name).ok_or("unexpected value tag".into())
}
fn integer(v: &Value) -> R<BigInt> {
    let s = tag(v, "Int")?.as_str().ok_or("expected Int string")?;
    // Every Int within the bound has fewer than 2.41 decimal digits per byte.
    if s.len() > MAX_INT_BYTES * 5 / 2 + 1 {
        return Err("snapshot Int exceeds size limit".into());
    }
    let n = s.parse::<BigInt>().map_err(|_| "invalid Int")?;
    if n.bits() > 8 * MAX_INT_BYTES as u64 {
        return Err("snapshot Int exceeds size limit".into());
    }
    if n.to_string() != s {
        return Err("noncanonical Int".into());
    }
    Ok(n)
}
fn identifier(v: &Value) -> R<u128> {
    let s = v.as_str().ok_or("expected ID")?;
    if s.len() != 32
        || !s
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err("noncanonical ID".into());
    }
    u128::from_str_radix(s, 16).map_err(|e| e.to_string())
}
fn compare(t: &Schema, a: &Value, b: &Value) -> R<Ordering> {
    Ok(match t {
        Schema::I32 => a
            .as_i64()
            .and_then(|n| i32::try_from(n).ok())
            .ok_or("invalid i32 key")?
            .cmp(
                &b.as_i64()
                    .and_then(|n| i32::try_from(n).ok())
                    .ok_or("invalid i32 key")?,
            ),
        Schema::U32 | Schema::U64 => a
            .as_u64()
            .ok_or("invalid key")?
            .cmp(&b.as_u64().ok_or("invalid key")?),
        Schema::String => a
            .as_str()
            .ok_or("invalid key")?
            .as_bytes()
            .cmp(b.as_str().ok_or("invalid key")?.as_bytes()),
        Schema::Id => identifier(a)?.cmp(&identifier(b)?),
        _ => return Err("unsupported snapshot key schema".into()),
    })
}
fn tick(left: &mut usize, depth: usize, limits: Limits) -> R<()> {
    if *left == 0 || depth > limits.depth {
        return Err("snapshot value/depth limit exceeded".into());
    }
    *left -= 1;
    Ok(())
}
fn encode_value(
    t: &Schema,
    v: &Value,
    out: &mut Vec<u8>,
    left: &mut usize,
    depth: usize,
    limits: Limits,
) -> R<()> {
    tick(left, depth, limits)?;
    match t {
        Schema::Unit => {
            if !v.is_null() {
                return Err("expected Unit".into());
            }
        }
        Schema::Bool => out.push(v.as_bool().ok_or("expected Bool")? as u8),
        Schema::U32 => out.extend_from_slice(
            &u32::try_from(v.as_u64().ok_or("expected u32")?)
                .map_err(|_| "u32 overflow")?
                .to_le_bytes(),
        ),
        Schema::U64 => u64_bytes(out, v.as_u64().ok_or("expected u64")?),
        Schema::I32 => out.extend_from_slice(
            &i32::try_from(v.as_i64().ok_or("expected i32")?)
                .map_err(|_| "i32 overflow")?
                .to_le_bytes(),
        ),
        Schema::F32 => {
            let bits = if let Some(b) = v.get("F32Bits") {
                if v.as_object().is_none_or(|o| o.len() != 1) {
                    return Err("expected only F32Bits field".into());
                }
                u32::try_from(b.as_u64().ok_or("expected f32 bits")?)
                    .map_err(|_| "f32 bits overflow")?
            } else {
                let f = v.as_f64().ok_or("expected f32")? as f32;
                if !f.is_finite() {
                    return Err("finite f32 or F32Bits required".into());
                }
                f.to_bits()
            };
            out.extend_from_slice(&bits.to_le_bytes());
        }
        Schema::Vector(inner, n) => {
            if !(2..=4).contains(n)
                || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
            {
                return Err("invalid vector schema".into());
            }
            let xs = v.as_array().ok_or("expected vector")?;
            if xs.len() != *n as usize {
                return Err("vector dimension mismatch".into());
            }
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Int => {
            let n = integer(v)?;
            let (sign, b) = n.to_bytes_le();
            out.push(match sign {
                Sign::NoSign => 0,
                Sign::Plus => 1,
                Sign::Minus => 2,
            });
            if sign == Sign::NoSign {
                raw(out, &[])
            } else {
                raw(out, &b)
            }
        }
        Schema::String => raw(out, v.as_str().ok_or("expected String")?.as_bytes()),
        Schema::Id => out.extend_from_slice(&identifier(v)?.to_le_bytes()),
        Schema::Enum(names) => {
            let s = v.as_str().ok_or("expected enum string")?;
            let index = names
                .iter()
                .position(|n| n == s)
                .ok_or("unknown enum variant")?;
            out.extend_from_slice(&(index as u32).to_le_bytes());
        }
        Schema::Record(fields) => {
            let obj = v.as_object().ok_or("expected record")?;
            if obj.len() != fields.len() {
                return Err("record field mismatch".into());
            }
            for (n, t) in fields {
                encode_value(
                    t,
                    obj.get(n).ok_or("missing record field")?,
                    out,
                    left,
                    depth + 1,
                    limits,
                )?;
            }
        }
        Schema::List(inner) => {
            let xs = v.as_array().ok_or("expected List")?;
            if xs.len() > *left {
                return Err("snapshot value limit exceeded".into());
            }
            count(out, xs.len());
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Option(inner) => {
            if let Ok(x) = tag(v, "Some") {
                out.push(1);
                encode_value(inner, x, out, left, depth + 1, limits)?;
            } else {
                if !tag(v, "None")?.is_null() {
                    return Err("invalid None".into());
                }
                out.push(0);
            }
        }
        Schema::Result(a, b) => {
            if let Ok(x) = tag(v, "Ok") {
                out.push(0);
                encode_value(a, x, out, left, depth + 1, limits)?;
            } else {
                out.push(1);
                encode_value(b, tag(v, "Err")?, out, left, depth + 1, limits)?;
            }
        }
    }
    if out.len() > limits.bytes {
        return Err("snapshot byte limit exceeded".into());
    }
    Ok(())
}
struct Reader<'a> {
    bytes: &'a [u8],
    at: usize,
    left: usize,
    limits: Limits,
}
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> R<&'a [u8]> {
        let end = self.at.checked_add(n).ok_or("snapshot length overflow")?;
        let b = self.bytes.get(self.at..end).ok_or("truncated snapshot")?;
        self.at = end;
        Ok(b)
    }
    fn byte(&mut self) -> R<u8> {
        Ok(self.take(1)?[0])
    }
    fn u32(&mut self) -> R<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn u64(&mut self) -> R<u64> {
        Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
    fn len(&mut self) -> R<usize> {
        usize::try_from(self.u64()?).map_err(|_| "snapshot length not addressable".into())
    }
    fn sequence(&mut self) -> R<usize> {
        let n = self.len()?;
        if n > self.left {
            return Err("snapshot value limit exceeded".into());
        }
        Ok(n)
    }
    fn raw(&mut self) -> R<&'a [u8]> {
        let n = self.len()?;
        self.take(n)
    }
    fn value(&mut self, t: &Schema, depth: usize) -> R<Value> {
        tick(&mut self.left, depth, self.limits)?;
        Ok(match t {
            Schema::Unit => Value::Null,
            Schema::Bool => match self.byte()? {
                0 => json!(false),
                1 => json!(true),
                _ => return Err("invalid Bool tag".into()),
            },
            Schema::U32 => json!(self.u32()?),
            Schema::U64 => json!(self.u64()?),
            Schema::I32 => json!(self.u32()? as i32),
            Schema::F32 => {
                let bits = self.u32()?;
                let f = f32::from_bits(bits);
                if f.is_finite() {
                    json!(f)
                } else {
                    json!({"F32Bits":bits})
                }
            }
            Schema::Vector(inner, n) => {
                if !(2..=4).contains(n)
                    || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
                {
                    return Err("invalid vector schema".into());
                }
                (0..*n)
                    .map(|_| self.value(inner, depth + 1))
                    .collect::<R<Vec<_>>>()?
                    .into()
            }
            Schema::Int => {
                let sign = self.byte()?;
                let bytes = self.raw()?;
                if bytes.len() > MAX_INT_BYTES {
                    return Err("snapshot Int exceeds size limit".into());
                }
                let sign = match sign {
                    0 if bytes.is_empty() => Sign::NoSign,
                    1 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Plus,
                    2 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Minus,
                    _ => return Err("noncanonical signed integer".into()),
                };
                json!({"Int":BigInt::from_bytes_le(sign,bytes).to_string()})
            }
            Schema::String => json!(std::str::from_utf8(self.raw()?).map_err(|_| "invalid UTF-8")?),
            Schema::Id => json!(format!(
                "{:032x}",
                u128::from_le_bytes(self.take(16)?.try_into().unwrap())
            )),
            Schema::Enum(names) => {
                json!(names.get(self.u32()? as usize).ok_or("invalid enum tag")?)
            }
            Schema::Record(fields) => {
                let mut obj = serde_json::Map::new();
                for (n, t) in fields {
                    obj.insert(n.clone(), self.value(t, depth + 1)?);
                }
                Value::Object(obj)
            }
            Schema::List(t) => {
                let n = self.sequence()?;
                let mut xs = Vec::new();
                for _ in 0..n {
                    xs.push(self.value(t, depth + 1)?);
                }
                Value::Array(xs)
            }
            Schema::Option(t) => match self.byte()? {
                0 => json!({"None":null}),
                1 => json!({"Some":self.value(t,depth+1)?}),
                _ => return Err("invalid Option tag".into()),
            },
            Schema::Result(a, b) => match self.byte()? {
                0 => json!({"Ok":self.value(a,depth+1)?}),
                1 => json!({"Err":self.value(b,depth+1)?}),
                _ => return Err("invalid Result tag".into()),
            },
        })
    }
}
fn event_order(e: &Event, version: u64, prior: Option<(u64, u64)>) -> R<()> {
    if e.commit == 0 || e.commit > version || prior.is_some_and(|p| p >= (e.commit, e.position)) {
        return Err("invalid snapshot event sequence".into());
    }
    Ok(())
}
pub fn encode(layout: &Layout, s: &Logical, limits: Limits) -> R<Vec<u8>> {
    if s.tables.len() != layout.roots.len() {
        return Err("snapshot root count mismatch".into());
    }
    let mut out = Vec::new();
    let mut left = limits.values;
    u64_bytes(&mut out, s.version);
    for (rows, (_, kt, vt)) in s.tables.iter().zip(&layout.roots) {
        if rows.len() > left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        count(&mut out, rows.len());
        let mut prior = None;
        for (k, v) in rows {
            if let Some(p) = prior {
                if compare(kt, p, k)? != Ordering::Less {
                    return Err("snapshot keys must be strictly ordered".into());
                }
            }
            encode_value(kt, k, &mut out, &mut left, 0, limits)?;
            encode_value(vt, v, &mut out, &mut left, 0, limits)?;
            prior = Some(k);
        }
    }
    count(&mut out, s.outbox.len());
    let mut prior = None;
    for e in &s.outbox {
        event_order(e, s.version, prior)?;
        let (_, t) = layout
            .events
            .get(e.channel)
            .ok_or("unknown event channel")?;
        u64_bytes(&mut out, e.commit);
        u64_bytes(&mut out, e.position);
        out.extend_from_slice(&(e.channel as u32).to_le_bytes());
        encode_value(t, &e.value, &mut out, &mut left, 0, limits)?;
        prior = Some((e.commit, e.position));
    }
    if HEADER
        .checked_add(out.len())
        .and_then(|n| n.checked_add(32))
        .is_none_or(|n| n > limits.bytes)
    {
        return Err("snapshot byte limit exceeded".into());
    }
    let mut bytes = Vec::new();
    bytes.extend_from_slice(MAGIC);
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&layout.program);
    bytes.extend_from_slice(&layout.schema);
    count(&mut bytes, out.len());
    bytes.extend_from_slice(&out);
    let digest = Sha256::digest(&bytes);
    bytes.extend_from_slice(&digest);
    Ok(bytes)
}
pub fn decode(layout: &Layout, bytes: &[u8], limits: Limits) -> R<Logical> {
    if bytes.len() > limits.bytes || bytes.len() < HEADER + 32 {
        return Err("snapshot byte length invalid".into());
    }
    if &bytes[..8] != MAGIC || bytes[8..12] != [1, 0, 1, 0] {
        return Err("snapshot format or semantics version mismatch".into());
    }
    if bytes[12..44] != layout.program || bytes[44..76] != layout.schema {
        return Err("snapshot program or schema identity mismatch".into());
    }
    let n = usize::try_from(u64::from_le_bytes(bytes[76..84].try_into().unwrap()))
        .map_err(|_| "snapshot length not addressable")?;
    if HEADER.checked_add(n).and_then(|v| v.checked_add(32)) != Some(bytes.len()) {
        return Err("snapshot payload length mismatch".into());
    }
    let end = bytes.len() - 32;
    if Sha256::digest(&bytes[..end]).as_slice() != &bytes[end..] {
        return Err("snapshot integrity check failed".into());
    }
    let mut r = Reader {
        bytes: &bytes[HEADER..end],
        at: 0,
        left: limits.values,
        limits,
    };
    let version = r.u64()?;
    let mut tables = vec![];
    for (_, kt, vt) in &layout.roots {
        let n = r.sequence()?;
        if n > r.left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        let mut rows: Vec<(Value, Value)> = vec![];
        for _ in 0..n {
            let k = r.value(kt, 0)?;
            let v = r.value(vt, 0)?;
            if let Some((prior, _)) = rows.last() {
                if compare(kt, prior, &k)? != Ordering::Less {
                    return Err("duplicate or unordered snapshot key".into());
                }
            }
            rows.push((k, v));
        }
        tables.push(rows);
    }
    let n = r.sequence()?;
    let mut outbox = vec![];
    let mut prior = None;
    for _ in 0..n {
        let commit = r.u64()?;
        let position = r.u64()?;
        let channel = r.u32()? as usize;
        let (_, t) = layout
            .events
            .get(channel)
            .ok_or("unknown snapshot event channel")?;
        let value = r.value(t, 0)?;
        let e = Event {
            commit,
            position,
            channel,
            value,
        };
        event_order(&e, version, prior)?;
        prior = Some((commit, position));
        outbox.push(e);
    }
    if r.at != r.bytes.len() {
        return Err("trailing snapshot payload".into());
    }
    Ok(Logical {
        version,
        tables,
        outbox,
    })
}

}
pub use portable::Limits as SnapshotLimits;
fn snapshot_layout()->portable::Layout{portable::Layout{program:[255, 4, 117, 215, 71, 163, 245, 79, 91, 5, 184, 13, 208, 246, 185, 97, 201, 75, 126, 146, 140, 93, 124, 164, 47, 146, 227, 5, 76, 237, 154, 239],schema:[192, 141, 16, 114, 17, 172, 249, 182, 219, 154, 142, 125, 228, 252, 175, 89, 60, 246, 149, 204, 109, 105, 172, 253, 213, 158, 150, 88, 181, 131, 24, 90],roots:vec![
("Rows".into(),portable::Schema::U64,portable::Schema::U64),
],events:vec![("seen".into(),portable::Schema::U64),
]}}
fn one_tag<'a>(v:&'a Json,_kind:&str)->Result<&'a serde_json::Map<String,Json>,String>{Ok(v.as_object().unwrap())}
fn read_0(v:&Json,d:usize)->Result<bool,String>{Ok(
v.as_bool().unwrap())}
fn write_0(v:&bool,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_1(v:&Json,d:usize)->Result<u64,String>{Ok(
v.as_u64().unwrap())}
fn write_1(v:&u64,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_2(v:&Json,d:usize)->Result<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c,String>{Ok(
{D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0})}
fn write_2(v:&D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c,d:usize)->Result<Json,String>{Ok(
Json::Null)}
fn read_3(v:&Json,d:usize)->Result<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b,String>{Ok(
{let text=v.as_str().unwrap();match text{"Error.Failed"=>D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0,_=>unreachable!("caller enum precondition")}})}
fn write_3(v:&D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b,d:usize)->Result<Json,String>{Ok(
match v{D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0=>json!("Error.Failed"),})}
fn read_4(v:&Json,d:usize)->Result<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(read_1(x,d+1)?)}else{D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0}})}
fn write_4(v:&D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02,d:usize)->Result<Json,String>{Ok(
match v{D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0=>json!({"None":null}),D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(x)=>json!({"Some":write_1(x,d+1)?})})}
fn read_5(v:&Json,d:usize)->Result<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f,String>{Ok(
{let xs=one_tag(v,"Result")?;if let Some(x)=xs.get("Ok"){D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::new(read_2(x,d+1)?))}else{let x=xs.get("Err").unwrap();D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::new(read_3(x,d+1)?))}})}
fn write_5(v:&D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f,d:usize)->Result<Json,String>{Ok(
match v{D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(x)=>json!({"Ok":write_2(x,d+1)?}),D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(x)=>json!({"Err":write_3(x,d+1)?})})}
fn logical_from_tables(tables:&[Vec<(Json,Json)>])->Result<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d,String>{if tables.len()!=1{return Err("representation table count mismatch".into())}
let rows=&tables[0];let mut root0=D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0;for (key,row) in rows.iter().rev(){root0=D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(read_1(key,0)?,read_1(row,0)?,std::sync::Arc::new(root0));}
Ok(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(root0)))}
fn logical_tables(state:&D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d)->Result<Vec<Vec<(Json,Json)>>,String>{let D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(r0)=state;
let mut rows0=vec![];let mut cursor=r0.as_ref();loop{match cursor{D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0=>break,D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(key,value,tail)=>{rows0.push((write_1(key,0)?,write_1(value,0)?));cursor=tail.as_ref();}}}
Ok(vec![rows0])}
fn logical_events(events:&D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de)->Result<Vec<(usize,Json)>,String>{let mut cursor=events;let mut out=vec![];loop{match cursor{D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0=>break,D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(event,tail)=>{let value=match event.as_ref(){
D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(value)=>(0,write_1(value,0)?),
};out.push(value);cursor=tail.as_ref();}}}Ok(out)}
pub use portable::Event;
pub struct Outcome<T>{pub result:T,pub committed:bool,pub version:u64,pub events:Vec<Event>}
pub struct OutcomeView<'a,T>{pub result:T,pub committed:bool,pub version:u64,pub events:&'a[Event]}
impl<T> OutcomeView<'_,T>{pub fn into_owned(self)->Outcome<T>{Outcome{result:self.result,committed:self.committed,version:self.version,events:self.events.to_vec()}}}
pub struct State{physical:D_168416e46f55a9d54afaf2b0d0ff9a5bca3650d410a530773c3aa5557c9be9d8,version:u64,outbox:Vec<portable::Event>,layout:portable::Layout}
impl State{
// CALLER CONTRACT: arguments must have the declared types and canonical values.
// No runtime type validation. Malformed input may panic, trap or corrupt state.
pub fn new()->Result<Self,String>{let logical=D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0));Ok(Self{physical:f_7e073df7e15b460e7b36bbcaa09dc13ff3e8edce961808bd40245f3847aa6575(&logical),version:0,outbox:vec![],layout:snapshot_layout()})}
pub fn restore(bytes:&[u8])->Result<Self,String>{let layout=snapshot_layout();let saved=portable::decode(&layout,bytes,SnapshotLimits::default())?;let logical=logical_from_tables(&saved.tables)?;Ok(Self{physical:f_7e073df7e15b460e7b36bbcaa09dc13ff3e8edce961808bd40245f3847aa6575(&logical),version:saved.version,outbox:saved.outbox,layout})}
pub fn checkpoint(&self)->Result<Vec<u8>,String>{let logical=f_13383bb021a496f46e5c221fcc119b83f058c88a3aeb894d16cf3e940529a73d(&(self.physical));portable::encode(&self.layout,&portable::Logical{version:self.version,tables:logical_tables(&logical)?,outbox:self.outbox.clone()},SnapshotLimits::default())}
pub fn version(&self)->u64{self.version}
pub fn outbox_json(&self)->Json{Json::Array(self.outbox.iter().map(|e|json!({"commit":e.commit,"position":e.position,"channel":self.layout.events[e.channel].0,"value":e.value})).collect())}
pub fn acknowledge_through(&mut self,commit:u64,position:u64){self.outbox.retain(|e|(e.commit,e.position)>(commit,position));}
pub fn query_zero(&self,)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{q_32d8eb00f1c14d65ee1e9bcb63c2d346a4a0dfb462d877162c591fd67cde3333(&(self.physical),self.version)}
pub fn query_get(&self,a0:u64)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{q_6f89259f76d8459d1446802cfbe1beab8eab0089cf176a377ef57570d174e855(&(self.physical),self.version,a0)}
pub fn query_one(&self,)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{q_fa41c269d695fb91d2319cca0a104200e12361ff953d31d53e5b418d68f91fe5(&(self.physical),self.version)}
pub fn invoke_view_put(&mut self,a0:u64,a1:u64)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=t_74eaa58afd0c8c1c32b227627a4c500cf7cc3679f11be601dd3fb9d5ab31abc4(&(self.physical),self.version,a0,a1);let observed=f_cf93ff2613b2f954b4cc9567499b126525e85b8f3c5d940c086428428167b05d(&(executed));let next=f_52b3364f042aeec1d1ab03c2e590c0a1ad64048ce1065617e01ef12e356f71de(&(executed));
let(result,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_replace(&mut self,a0:u64,a1:u64,a2:bool)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=t_bc22a9f9bebbae59c6383d19f7f6c15b3cb7077283df64748192f7cfce71e2bb(&(self.physical),self.version,a0,a1,a2);let observed=f_cf93ff2613b2f954b4cc9567499b126525e85b8f3c5d940c086428428167b05d(&(executed));let next=f_52b3364f042aeec1d1ab03c2e590c0a1ad64048ce1065617e01ef12e356f71de(&(executed));
let(result,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_erase(&mut self,a0:u64,a1:bool)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=t_7fe1c26b37bc99c3fbd2990341be945929045f0f5eb871c32ba6cbe0361b9baa(&(self.physical),self.version,a0,a1);let observed=f_cf93ff2613b2f954b4cc9567499b126525e85b8f3c5d940c086428428167b05d(&(executed));let next=f_52b3364f042aeec1d1ab03c2e590c0a1ad64048ce1065617e01ef12e356f71de(&(executed));
let(result,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_zero(&mut self,)->Result<OutcomeView<'_,D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,String>{
let result=q_32d8eb00f1c14d65ee1e9bcb63c2d346a4a0dfb462d877162c591fd67cde3333(&(self.physical),self.version);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_view_get(&mut self,a0:u64)->Result<OutcomeView<'_,D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,String>{
let result=q_6f89259f76d8459d1446802cfbe1beab8eab0089cf176a377ef57570d174e855(&(self.physical),self.version,a0);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_view_one(&mut self,)->Result<OutcomeView<'_,D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,String>{
let result=q_fa41c269d695fb91d2319cca0a104200e12361ff953d31d53e5b418d68f91fe5(&(self.physical),self.version);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_json(&mut self,name:&str,args:&Json)->Result<Json,String>{match name{
"put"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_1(&xs[1],0)?;
let executed=t_74eaa58afd0c8c1c32b227627a4c500cf7cc3679f11be601dd3fb9d5ab31abc4(&(self.physical),self.version,a0,a1);
let observed=f_cf93ff2613b2f954b4cc9567499b126525e85b8f3c5d940c086428428167b05d(&(executed));let next=f_52b3364f042aeec1d1ab03c2e590c0a1ad64048ce1065617e01ef12e356f71de(&(executed));let(reply,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_5(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"replace"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_1(&xs[1],0)?;
let a2=read_0(&xs[2],0)?;
let executed=t_bc22a9f9bebbae59c6383d19f7f6c15b3cb7077283df64748192f7cfce71e2bb(&(self.physical),self.version,a0,a1,a2);
let observed=f_cf93ff2613b2f954b4cc9567499b126525e85b8f3c5d940c086428428167b05d(&(executed));let next=f_52b3364f042aeec1d1ab03c2e590c0a1ad64048ce1065617e01ef12e356f71de(&(executed));let(reply,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_5(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"erase"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_0(&xs[1],0)?;
let executed=t_7fe1c26b37bc99c3fbd2990341be945929045f0f5eb871c32ba6cbe0361b9baa(&(self.physical),self.version,a0,a1);
let observed=f_cf93ff2613b2f954b4cc9567499b126525e85b8f3c5d940c086428428167b05d(&(executed));let next=f_52b3364f042aeec1d1ab03c2e590c0a1ad64048ce1065617e01ef12e356f71de(&(executed));let(reply,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_5(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"zero"=>{let xs=args.as_array().unwrap();
let reply=q_32d8eb00f1c14d65ee1e9bcb63c2d346a4a0dfb462d877162c591fd67cde3333(&(self.physical),self.version);let result=write_4(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
"get"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let reply=q_6f89259f76d8459d1446802cfbe1beab8eab0089cf176a377ef57570d174e855(&(self.physical),self.version,a0);let result=write_4(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
"one"=>{let xs=args.as_array().unwrap();
let reply=q_fa41c269d695fb91d2319cca0a104200e12361ff953d31d53e5b418d68f91fe5(&(self.physical),self.version);let result=write_4(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
_=>Err(format!("unknown action {name}"))}}}
