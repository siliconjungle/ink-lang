mod before;
mod after;
use std::{alloc::{GlobalAlloc,Layout,System},hint::black_box,sync::atomic::{AtomicUsize,Ordering},time::Instant};
use serde_json::{Value as Json,json};
use sha2::{Digest,Sha256};
struct Count;
static LIVE:AtomicUsize=AtomicUsize::new(0);
static PEAK:AtomicUsize=AtomicUsize::new(0);
static ALLOCS:AtomicUsize=AtomicUsize::new(0);
fn added(n:usize){ALLOCS.fetch_add(1,Ordering::Relaxed);let live=LIVE.fetch_add(n,Ordering::Relaxed)+n;PEAK.fetch_max(live,Ordering::Relaxed);}
unsafe impl GlobalAlloc for Count {
 unsafe fn alloc(&self,l:Layout)->*mut u8 {let p=System.alloc(l);if !p.is_null(){added(l.size());}p}
 unsafe fn dealloc(&self,p:*mut u8,l:Layout){System.dealloc(p,l);LIVE.fetch_sub(l.size(),Ordering::Relaxed);}
 unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {let q=System.realloc(p,l,n);if !q.is_null(){ALLOCS.fetch_add(1,Ordering::Relaxed);if n>=l.size(){let live=LIVE.fetch_add(n-l.size(),Ordering::Relaxed)+n-l.size();PEAK.fetch_max(live,Ordering::Relaxed);}else{LIVE.fetch_sub(l.size()-n,Ordering::Relaxed);}}q}
}
#[cfg(counted)] #[global_allocator] static GLOBAL:Count=Count;

trait Database:Sized{fn new()->Self;fn restore(b:&[u8])->Self;fn checkpoint(&self)->Vec<u8>;fn call(&mut self,name:&str,args:&Json)->Json;fn ack(&mut self);}
macro_rules! adapter{($m:ident)=>{impl Database for $m::State{
fn new()->Self{Self::new().unwrap()}fn restore(b:&[u8])->Self{Self::restore(b).unwrap()}fn checkpoint(&self)->Vec<u8>{Self::checkpoint(self).unwrap()}
fn call(&mut self,name:&str,args:&Json)->Json{self.invoke_json(name,args).unwrap()}fn ack(&mut self){self.acknowledge_through(u64::MAX,u64::MAX)}
}}}adapter!(before);adapter!(after);
fn phase(repeats:usize,mut f:impl FnMut())->Json {
 let before=LIVE.load(Ordering::Relaxed);PEAK.store(before,Ordering::Relaxed);ALLOCS.store(0,Ordering::Relaxed);
 let start=Instant::now();for _ in 0..repeats{f();}let ns=start.elapsed().as_nanos();
 let allocations=ALLOCS.load(Ordering::Relaxed);let peak=PEAK.load(Ordering::Relaxed)-before;
 let after=LIVE.load(Ordering::Relaxed);
 json!({"repeats":repeats,"total_ns":ns as u64,"allocations":allocations,"peak_added_bytes":peak,"live_delta_bytes":after as i64-before as i64})
}

fn configuration(kind:&str,n:usize)->(Vec<Json>,&'static str,Json,&'static str,Json,&'static str,Json){
 let mid=(n/2)as u64;
 match kind{
 "field"=>(vec![json!([41,0])],"cached",json!([]),"label",json!([99,false]),"label",json!([17,true])),
 "shared"=>( (0..n).map(|i|json!([i,i])).collect(),"zero",json!([]),"put",json!([mid,99]),"erase",json!([mid,true])),
 "ordered"=>( (0..n).map(|i|json!([i,i,i%2==0,false])).collect(),"active",json!([]),"put",json!([mid,99,true,false]),"put",json!([mid,17,false,true])),
 "grouped"|"memo"|"fused"|"memo-fused"=>( (0..n).map(|i|json!([i,i,i%3,false])).collect(),"groups",json!([]),"put",json!([mid,99,1,false]),"put",json!([mid,17,0,true])),
 "dense"=>( (0..n).map(|i|json!([i,i])).collect(),"get",json!([0]),"put",json!([mid,99]),"erase",json!([mid,true])),
 "index"=>( (0..n).map(|i|json!([i,i])).collect(),"get",json!([mid]),"put",json!([mid,99]),"erase",json!([mid,true])),
 _=>panic!("kind")
 }
}
fn sample<D:Database>(kind:&str,n:usize)->Json{
 let (population,query,query_args,update,update_args,abort_action,abort_args)=configuration(kind,n);
 let startup=phase(32,||{black_box(D::new());});
 let before=LIVE.load(Ordering::Relaxed);let mut state=None;
 let initialise=phase(1,||{let mut db=D::new();for args in &population {db.call("put",args);db.ack();}state=Some(db);});
 let state_bytes=LIVE.load(Ordering::Relaxed)-before;let mut state=state.unwrap();
 let expected=state.call(query,&query_args);assert_eq!(expected["committed"],false);
 let query_json=phase(64,||{assert_eq!(black_box(state.call(query,&query_args)),expected);});
 let update_json=phase(32,||{assert_eq!(state.call(update,&update_args)["committed"],true);state.ack();});
 let saved=state.checkpoint();let after_reply=state.call(query,&query_args);
 let abort=phase(32,||{assert_eq!(state.call(abort_action,&abort_args)["committed"],false);});
 assert_eq!(state.checkpoint(),saved);
 let checkpoint=phase(8,||{black_box(state.checkpoint());});
 let restore=phase(8,||{black_box(D::restore(&saved));});assert_eq!(D::restore(&saved).checkpoint(),saved);
 let snapshot_sha256=format!("{:x}",Sha256::digest(&saved));
 let mut state=Some(state);let teardown=phase(1,||{drop(state.take());});
 json!({"startup":startup,"initialise":initialise,"query_json":query_json,"update_json":update_json,"abort":abort,"checkpoint":checkpoint,"restore":restore,"teardown":teardown,"state_requested_bytes":state_bytes,"snapshot_sha256":snapshot_sha256,"query_result":expected,"after_query_result":after_reply})
}
fn main(){let args:Vec<String>=std::env::args().collect();let n=args[3].parse().unwrap();let value=if args[1]=="before"{sample::<before::State>(&args[2],n)}else{sample::<after::State>(&args[2],n)};println!("{value}");}
