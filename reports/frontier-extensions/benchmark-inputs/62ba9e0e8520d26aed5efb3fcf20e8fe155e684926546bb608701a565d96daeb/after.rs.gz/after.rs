// ink-definition-rust-v1: checked bodies; Rust/backend are trusted.
#![allow(non_camel_case_types, non_snake_case, non_upper_case_globals, dead_code, unused_variables, unused_parens, unused_unsafe, improper_ctypes_definitions)]
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { C0,C1(u64,std::sync::Arc<D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b>) }
impl D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_02d3762066072e038d19e014f67775be3a6889735bf2e45723337b253d11c14b(v0: &D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa,v1: u64,v2: u64) -> D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa { match v0 { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v3,v4,v5) => { d_328c1b242187c34c181493001f639f84692ad9b9c55360f17301b6919dee1584(&(d_050b373a79d555c2577b1594d727d6cf1a60f9d11529a88ab3da5b35c5a8e44c(v3.as_ref(),v1,v2))) } } }
fn d_050b373a79d555c2577b1594d727d6cf1a60f9d11529a88ab3da5b35c5a8e44c(v6: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a,v7: u64,v8: u64) -> D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { match v6 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v9,v10) => { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_50c6c395084616f9cf6a84c8e8d2ce70d6746e042d9806094ed93d60eebb1efd(v9.as_ref(),v7,v8)),std::sync::Arc::new(d_71ef1cbc686007bd38b0eee5db382b08020455dcaa4fc18959fbc042b3c67cd2(v9.as_ref(),v10.as_ref(),v7,v8))) } } }
fn d_07a3a714c1d097faca974ce75b4a4916e4cda121c308be3bc9c8fd846859116e(v11: &D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c) -> D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d { match v11 { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(v12) => { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(v12.as_ref()))) } } }
fn d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v13: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v14: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v15: u64) -> D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02 { match v13 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v17,v18) => { match v14 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v20,v21) => { if ((v15) == (*v17)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(*v20) } else { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v18.as_ref(),v21.as_ref(),v15) } } } } } }
fn d_0849b1170431e1782069b241090d953722c415caac185d3582f0a7a37a326eb6(v22: &D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v23: u64,v24: u64,v25: bool) -> D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590 { match v22 { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(v26) => { if v25 { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v26))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v28:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v28.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v27:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v27.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v23,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(v26.as_ref())))),std::sync::Arc::clone({static v29:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v29.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } else { if ((v23) == (18446744073709551615u64)) { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v26))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v23,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(v26.as_ref()))))))) } else { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::new(d_32a25a53fb194cac4c90a34b8a97d0a4e81749ce791e8f3973f7f226317bb856(&(d_32a25a53fb194cac4c90a34b8a97d0a4e81749ce791e8f3973f7f226317bb856(v26.as_ref(),v24)),v24)))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v31:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v31.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v30:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v30.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v23).wrapping_add(1u64),std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(&(d_32a25a53fb194cac4c90a34b8a97d0a4e81749ce791e8f3973f7f226317bb856(&(d_32a25a53fb194cac4c90a34b8a97d0a4e81749ce791e8f3973f7f226317bb856(v26.as_ref(),v24)),v24)))))),std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(std::sync::Arc::new(D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(v24)),std::sync::Arc::clone({static v32:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v32.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))))) } } } } }
fn d_0d2d282affe6a4603c864201753bd83cb0dba367470d89e794c4868975eacdde(v33: &D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v34: u64) -> D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67 { match v33 { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(v35) => { D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v35))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(d_f4e83d557844a9f6e215f34ed486b4d100a72c7058e5f1d3a66238cc74d4c9cf(v35.as_ref(),0u64)),false,v34,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(v35.as_ref())))),std::sync::Arc::clone({static v36:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v36.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } }
fn d_1242bcb235dc8376a3b3666718bf63c51093f71356dd18708bf5b17137d855d0(v37: &D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v37 { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(v39,v40,v41) => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v40,std::sync::Arc::new(d_1242bcb235dc8376a3b3666718bf63c51093f71356dd18708bf5b17137d855d0(v41.as_ref()))) } } }
fn d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v42: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a,v43: u64) -> D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02 { match v42 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v44,v45) => { d_0829b19013ac548fb1df8ef2b158ca32b8a3fe2f7082efe0eb6d7ff78c3c6a28(v44.as_ref(),v45.as_ref(),v43) } } }
fn d_249611d2a195d44b1c1be6ba8614aaed70d7da25ed80ba38993f7969849f16e3(v46: &D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67) -> D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { match v46 { D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67::C0(v47,v48) => { (v48.as_ref()).clone() } } }
fn d_31da817461332a272329ebaf8d8b88dd1d957e34b37ae8df6eb4420cfcf2cc0d(v49: &D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v49 { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(v51,v52,v53) => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v51,std::sync::Arc::new(d_31da817461332a272329ebaf8d8b88dd1d957e34b37ae8df6eb4420cfcf2cc0d(v53.as_ref()))) } } }
fn d_328c1b242187c34c181493001f639f84692ad9b9c55360f17301b6919dee1584(v54: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a) -> D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(std::sync::Arc::new((v54).clone()),std::sync::Arc::new(d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v54,0u64)),std::sync::Arc::new(d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v54,1u64))) }
fn d_32a25a53fb194cac4c90a34b8a97d0a4e81749ce791e8f3973f7f226317bb856(v55: &D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa,v56: u64) -> D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa { match v55 { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v57,v58,v59) => { d_328c1b242187c34c181493001f639f84692ad9b9c55360f17301b6919dee1584(&(d_df95fd31337deaad84f3abe0d6c13adc30ae22013972652e3b6e45d2fff2139c(v57.as_ref(),v56))) } } }
fn d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(v60: &D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa) -> D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807 { match v60 { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v61,v62,v63) => { d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v61.as_ref()) } } }
fn d_3443c866ee44fd36617be1f3c3056d267e22893ed3c64ee9f6925527680ee426(v64: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a) -> D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807 { match v64 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v65,v66) => { d_8c71c9ec54433ede7b1b11cf4d4e65e192bf24e83eb2912562d70a1052e368ac(v65.as_ref(),v66.as_ref()) } } }
fn d_383855817467a8b6d62a13479e6071c56b353bd3143830bacc503493b693e224(v67: &D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67) -> D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c { match v67 { D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67::C0(v68,v69) => { (v68.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c { C0(std::sync::Arc<D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa>) }
fn d_3b70ef55c71639277b04dbb2f126534f6cc99e8d2576cb1493ee85c592da045e(v70: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v71: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v70 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v73,v74) => { if ((v71) == (*v73)) { d_3b70ef55c71639277b04dbb2f126534f6cc99e8d2576cb1493ee85c592da045e(v74.as_ref(),v71) } else { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v73,std::sync::Arc::new(d_3b70ef55c71639277b04dbb2f126534f6cc99e8d2576cb1493ee85c592da045e(v74.as_ref(),v71))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67 { C0(std::sync::Arc<D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c>,std::sync::Arc<D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d { C0(std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>) }
fn d_50c6c395084616f9cf6a84c8e8d2ce70d6746e042d9806094ed93d60eebb1efd(v75: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v76: u64,v77: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v75 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v79,v80) => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v79,std::sync::Arc::new(d_50c6c395084616f9cf6a84c8e8d2ce70d6746e042d9806094ed93d60eebb1efd(v80.as_ref(),v76,v77))) } } }
fn d_56233322e6aef441d071f3912ee80c75739535e1cf2c82bca04f6bf35c07659a(v81: &D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807) -> D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa { d_328c1b242187c34c181493001f639f84692ad9b9c55360f17301b6919dee1584(&(d_6f951a654c399751d2ab43fc23ac5c97a43a73b65d7184b52a00fec1c245c84c(v81))) }
fn d_5a06c1e0f1bfd57716580fd5d6f2633571ffebb7ad2375b325be26e4d8b2da16(v82: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v83: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v84: u64,v85: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v82 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v85,std::sync::Arc::clone({static v86:std::sync::OnceLock<std::sync::Arc<D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b>>=std::sync::OnceLock::new();v86.get_or_init(||std::sync::Arc::new(D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0))})) },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v87,v88) => { match v83 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v90,v91) => { if ((v84) < (*v87)) { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v85,std::sync::Arc::new((v83).clone())) } else { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v90,std::sync::Arc::new(d_5a06c1e0f1bfd57716580fd5d6f2633571ffebb7ad2375b325be26e4d8b2da16(v88.as_ref(),v91.as_ref(),v84,v85))) } } } } } }
fn d_5d884283e2959b79470f28da074d7e6ba7f349b2763ef943962635123d15f7d4(v92: &D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590) -> D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953 { match v92 { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(v93,v94) => { (v94.as_ref()).clone() } } }
fn d_63badbf0ed518faff3fb607c7046bb50a5bdbcb2df55dfedbbb3de80b775cba9(v95: &D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v96: u64,v97: u64) -> D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67 { match v95 { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(v98) => { D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v98))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(d_f4e83d557844a9f6e215f34ed486b4d100a72c7058e5f1d3a66238cc74d4c9cf(v98.as_ref(),v97)),false,v96,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(v98.as_ref())))),std::sync::Arc::clone({static v99:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v99.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590 { C0(std::sync::Arc<D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c>,std::sync::Arc<D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953>) }
fn d_6ea322a022e0bd401044d173f88216217ce2d2822356472a2758efddbf779926(v100: &D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v101: u64,v102: u64,v103: u64) -> D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590 { match v100 { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(v104) => { if match &(d_f4e83d557844a9f6e215f34ed486b4d100a72c7058e5f1d3a66238cc74d4c9cf(v104.as_ref(),v102)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v105) => { true } } { if match &(d_f4e83d557844a9f6e215f34ed486b4d100a72c7058e5f1d3a66238cc74d4c9cf(v104.as_ref(),v102)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v106) => { true } } { if ((v101) == (18446744073709551615u64)) { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v104))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v101,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(v104.as_ref()))))))) } else { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::new(d_02d3762066072e038d19e014f67775be3a6889735bf2e45723337b253d11c14b(v104.as_ref(),v102,v103)))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v108:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v108.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v107:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v107.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v101).wrapping_add(1u64),std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(&(d_02d3762066072e038d19e014f67775be3a6889735bf2e45723337b253d11c14b(v104.as_ref(),v102,v103)))))),std::sync::Arc::clone({static v109:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v109.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } else { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v104))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v101,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(v104.as_ref()))))))) } } else { if match &(d_f4e83d557844a9f6e215f34ed486b4d100a72c7058e5f1d3a66238cc74d4c9cf(v104.as_ref(),v102)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v110) => { true } } { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v104))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v101,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(v104.as_ref()))))))) } else { if ((v101) == (18446744073709551615u64)) { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v104))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v101,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(v104.as_ref()))))))) } else { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::new(d_b7aff086a60c00831e32cdd72a65198b5e97e0652fa2392088fc21cad4e0de00(v104.as_ref(),v102,v103)))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v112:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v112.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v111:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v111.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v101).wrapping_add(1u64),std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(&(d_b7aff086a60c00831e32cdd72a65198b5e97e0652fa2392088fc21cad4e0de00(v104.as_ref(),v102,v103)))))),std::sync::Arc::clone({static v113:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v113.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } } } } }
fn d_6f951a654c399751d2ab43fc23ac5c97a43a73b65d7184b52a00fec1c245c84c(v114: &D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807) -> D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_31da817461332a272329ebaf8d8b88dd1d957e34b37ae8df6eb4420cfcf2cc0d(v114)),std::sync::Arc::new(d_1242bcb235dc8376a3b3666718bf63c51093f71356dd18708bf5b17137d855d0(v114))) }
fn d_71ef1cbc686007bd38b0eee5db382b08020455dcaa4fc18959fbc042b3c67cd2(v115: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v116: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v117: u64,v118: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v115 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v120,v121) => { match v116 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v123,v124) => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(if ((v117) == (*v120)) { v118 } else { *v123 },std::sync::Arc::new(d_71ef1cbc686007bd38b0eee5db382b08020455dcaa4fc18959fbc042b3c67cd2(v121.as_ref(),v124.as_ref(),v117,v118))) } } } } }
fn d_74f987be179aff0a70be67aaf7a687192b43fbb60977140ba326b2adef21e03c(v125: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a,v126: u64,v127: u64) -> D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { match v125 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v128,v129) => { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_e7f3abf6f9dd0953bd24c47e8f8d261bd6b25dca50d60e76c02bfaf73890cf93(v128.as_ref(),v126,v127)),std::sync::Arc::new(d_5a06c1e0f1bfd57716580fd5d6f2633571ffebb7ad2375b325be26e4d8b2da16(v128.as_ref(),v129.as_ref(),v126,v127))) } } }
fn d_75b36e9bcc8983f503aed6cc3390d40933b881806b71b241d41d15f5ee405815(v130: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v131: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v132: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v130 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v134,v135) => { match v131 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v137,v138) => { if ((v132) == (*v134)) { d_75b36e9bcc8983f503aed6cc3390d40933b881806b71b241d41d15f5ee405815(v135.as_ref(),v138.as_ref(),v132) } else { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v137,std::sync::Arc::new(d_75b36e9bcc8983f503aed6cc3390d40933b881806b71b241d41d15f5ee405815(v135.as_ref(),v138.as_ref(),v132))) } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807 { C0,C1(u64,u64,std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>) }
impl D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953 { C0(std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,bool,u64,std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>,std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>),C1(u64,u64,std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>) }
fn d_81b9db563571007004127ada27e40a97fb701fb791575f4f5860a64709b39c4f(v139: &D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d) -> D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c { match v139 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v140) => { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::new(d_56233322e6aef441d071f3912ee80c75739535e1cf2c82bca04f6bf35c07659a(v140.as_ref()))) } } }
fn d_8c71c9ec54433ede7b1b11cf4d4e65e192bf24e83eb2912562d70a1052e368ac(v141: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v142: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b) -> D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807 { match v141 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v144,v145) => { match v142 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v147,v148) => { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(*v144,*v147,std::sync::Arc::new(d_8c71c9ec54433ede7b1b11cf4d4e65e192bf24e83eb2912562d70a1052e368ac(v145.as_ref(),v148.as_ref()))) } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f { C0(std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>),C1(std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de { C0,C1(std::sync::Arc<D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6>,std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>) }
impl D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02 { C0,C1(u64) }
fn d_b7aff086a60c00831e32cdd72a65198b5e97e0652fa2392088fc21cad4e0de00(v149: &D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa,v150: u64,v151: u64) -> D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa { match v149 { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v152,v153,v154) => { d_328c1b242187c34c181493001f639f84692ad9b9c55360f17301b6919dee1584(&(d_74f987be179aff0a70be67aaf7a687192b43fbb60977140ba326b2adef21e03c(v152.as_ref(),v150,v151))) } } }
fn d_b9602508123863ebff312e2dbe1b8ff6383ab16bf8f9cbf1c294d29020b4d130(v155: &D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590) -> D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c { match v155 { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(v156,v157) => { (v156.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c { C0 }
impl D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b { C0 }
impl D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_ca1e82dddcc30b723beb5bf4d49df01029f09035e5c25a272ac71636114fa39c(v158: &D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v159: u64) -> D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67 { match v158 { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(v160) => { D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v160))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(d_f4e83d557844a9f6e215f34ed486b4d100a72c7058e5f1d3a66238cc74d4c9cf(v160.as_ref(),1u64)),false,v159,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(v160.as_ref())))),std::sync::Arc::clone({static v161:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v161.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa { C0(std::sync::Arc<D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a>,std::sync::Arc<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,std::sync::Arc<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6 { C0(u64) }
fn d_df95fd31337deaad84f3abe0d6c13adc30ae22013972652e3b6e45d2fff2139c(v162: &D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a,v163: u64) -> D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { match v162 { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(v164,v165) => { D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a::C0(std::sync::Arc::new(d_3b70ef55c71639277b04dbb2f126534f6cc99e8d2576cb1493ee85c592da045e(v164.as_ref(),v163)),std::sync::Arc::new(d_75b36e9bcc8983f503aed6cc3390d40933b881806b71b241d41d15f5ee405815(v164.as_ref(),v165.as_ref(),v163))) } } }
fn d_e7f3abf6f9dd0953bd24c47e8f8d261bd6b25dca50d60e76c02bfaf73890cf93(v166: &D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b,v167: u64,v168: u64) -> D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b { match v166 { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0 => { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v167,std::sync::Arc::clone({static v169:std::sync::OnceLock<std::sync::Arc<D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b>>=std::sync::OnceLock::new();v169.get_or_init(||std::sync::Arc::new(D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C0))})) },D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v170,v171) => { if ((v167) < (*v170)) { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(v167,std::sync::Arc::new((v166).clone())) } else { D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b::C1(*v170,std::sync::Arc::new(d_e7f3abf6f9dd0953bd24c47e8f8d261bd6b25dca50d60e76c02bfaf73890cf93(v171.as_ref(),v167,v168))) } } } }
fn d_eb29f27edc9357a8508b7f19d795f0543c27d10e6d1d03f8b4354a1f89676b03(v172: &D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v173: u64,v174: u64,v175: u64,v176: bool) -> D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590 { match v172 { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(v177) => { if match &(d_f4e83d557844a9f6e215f34ed486b4d100a72c7058e5f1d3a66238cc74d4c9cf(v177.as_ref(),v174)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v178) => { true } } { if match &(d_f4e83d557844a9f6e215f34ed486b4d100a72c7058e5f1d3a66238cc74d4c9cf(v177.as_ref(),v174)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v179) => { true } } { if v176 { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v177))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v181:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v181.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v180:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v180.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v173,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(v177.as_ref())))),std::sync::Arc::clone({static v182:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v182.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } else { if ((v173) == (18446744073709551615u64)) { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v177))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v173,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(v177.as_ref()))))))) } else { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::new(d_02d3762066072e038d19e014f67775be3a6889735bf2e45723337b253d11c14b(v177.as_ref(),v174,v175)))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v184:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v184.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v183:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v183.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v173).wrapping_add(1u64),std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(&(d_02d3762066072e038d19e014f67775be3a6889735bf2e45723337b253d11c14b(v177.as_ref(),v174,v175)))))),std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(std::sync::Arc::new(D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(v175)),std::sync::Arc::clone({static v185:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v185.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))))) } } } else { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v177))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v173,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(v177.as_ref()))))))) } } else { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v177))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v187:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v187.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v186:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v186.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v173,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_342a56a80ef78fa84cee322b3ec2ea02b569194d4f22e55fd01fea3611b4d43f(v177.as_ref())))),std::sync::Arc::clone({static v188:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v188.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { C0(std::sync::Arc<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,bool,u64,std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>,std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>),C1(u64,u64,std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_f232465ba7574c4ee992dbc473c77cd444a51a268cb5f70f8359e8e6148dfb9a { C0(std::sync::Arc<D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b>,std::sync::Arc<D_0263de7b3bb5fdaab90dbd4ee8bdd661af6857c6aae7108beff5ad9c8d8be74b>) }
fn d_f4e83d557844a9f6e215f34ed486b4d100a72c7058e5f1d3a66238cc74d4c9cf(v189: &D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa,v190: u64) -> D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02 { match v189 { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v191,v192,v193) => { if ((v190) == (0u64)) { (v192.as_ref()).clone() } else { if ((v190) == (1u64)) { (v193.as_ref()).clone() } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v191.as_ref(),v190) } } } } }
pub fn f_07a3a714c1d097faca974ce75b4a4916e4cda121c308be3bc9c8fd846859116e(v194: &D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c) -> D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d { d_07a3a714c1d097faca974ce75b4a4916e4cda121c308be3bc9c8fd846859116e(v194) }
pub fn f_0849b1170431e1782069b241090d953722c415caac185d3582f0a7a37a326eb6(v195: &D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v196: u64,v197: u64,v198: bool) -> D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590 { d_0849b1170431e1782069b241090d953722c415caac185d3582f0a7a37a326eb6(v195,v196,v197,v198) }
pub fn f_0d2d282affe6a4603c864201753bd83cb0dba367470d89e794c4868975eacdde(v199: &D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v200: u64) -> D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67 { d_0d2d282affe6a4603c864201753bd83cb0dba367470d89e794c4868975eacdde(v199,v200) }
pub fn f_249611d2a195d44b1c1be6ba8614aaed70d7da25ed80ba38993f7969849f16e3(v201: &D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67) -> D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { d_249611d2a195d44b1c1be6ba8614aaed70d7da25ed80ba38993f7969849f16e3(v201) }
pub fn f_383855817467a8b6d62a13479e6071c56b353bd3143830bacc503493b693e224(v202: &D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67) -> D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c { d_383855817467a8b6d62a13479e6071c56b353bd3143830bacc503493b693e224(v202) }
pub fn f_5d884283e2959b79470f28da074d7e6ba7f349b2763ef943962635123d15f7d4(v203: &D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590) -> D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953 { d_5d884283e2959b79470f28da074d7e6ba7f349b2763ef943962635123d15f7d4(v203) }
pub fn f_63badbf0ed518faff3fb607c7046bb50a5bdbcb2df55dfedbbb3de80b775cba9(v204: &D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v205: u64,v206: u64) -> D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67 { d_63badbf0ed518faff3fb607c7046bb50a5bdbcb2df55dfedbbb3de80b775cba9(v204,v205,v206) }
pub fn f_6ea322a022e0bd401044d173f88216217ce2d2822356472a2758efddbf779926(v207: &D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v208: u64,v209: u64,v210: u64) -> D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590 { d_6ea322a022e0bd401044d173f88216217ce2d2822356472a2758efddbf779926(v207,v208,v209,v210) }
pub fn f_81b9db563571007004127ada27e40a97fb701fb791575f4f5860a64709b39c4f(v211: &D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d) -> D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c { d_81b9db563571007004127ada27e40a97fb701fb791575f4f5860a64709b39c4f(v211) }
pub fn f_b9602508123863ebff312e2dbe1b8ff6383ab16bf8f9cbf1c294d29020b4d130(v212: &D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590) -> D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c { d_b9602508123863ebff312e2dbe1b8ff6383ab16bf8f9cbf1c294d29020b4d130(v212) }
pub fn f_ca1e82dddcc30b723beb5bf4d49df01029f09035e5c25a272ac71636114fa39c(v213: &D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v214: u64) -> D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67 { d_ca1e82dddcc30b723beb5bf4d49df01029f09035e5c25a272ac71636114fa39c(v213,v214) }
pub fn f_eb29f27edc9357a8508b7f19d795f0543c27d10e6d1d03f8b4354a1f89676b03(v215: &D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v216: u64,v217: u64,v218: u64,v219: bool) -> D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590 { d_eb29f27edc9357a8508b7f19d795f0543c27d10e6d1d03f8b4354a1f89676b03(v215,v216,v217,v218,v219) }
fn q_0d2d282affe6a4603c864201753bd83cb0dba367470d89e794c4868975eacdde(v0:&D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v1:u64)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{match v0 { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(v2) => { match v2.as_ref() { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v3,v4,v5) => { if ((0u64) == (0u64)) { (v4.as_ref()).clone() } else { if ((0u64) == (1u64)) { (v5.as_ref()).clone() } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v3.as_ref(),0u64) } } } } } }}
fn q_63badbf0ed518faff3fb607c7046bb50a5bdbcb2df55dfedbbb3de80b775cba9(v0:&D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v1:u64,v2:u64)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{match v0 { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(v3) => { match v3.as_ref() { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v4,v5,v6) => { if ((v2) == (0u64)) { (v5.as_ref()).clone() } else { if ((v2) == (1u64)) { (v6.as_ref()).clone() } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v4.as_ref(),v2) } } } } } }}
fn q_ca1e82dddcc30b723beb5bf4d49df01029f09035e5c25a272ac71636114fa39c(v0:&D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v1:u64)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{match v0 { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(v2) => { match v2.as_ref() { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v3,v4,v5) => { if ((1u64) == (0u64)) { (v4.as_ref()).clone() } else { if ((1u64) == (1u64)) { (v5.as_ref()).clone() } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v3.as_ref(),1u64) } } } } } }}
fn t_0849b1170431e1782069b241090d953722c415caac185d3582f0a7a37a326eb6(v0:&D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v1:u64,v2:u64,v3:bool)->D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590{match v0 { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(v4) => { if v3 { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v1,std::sync::Arc::clone({static v8:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v8.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v9:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v9.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } else { if ((v1) == (18446744073709551615u64)) { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v1,std::sync::Arc::clone({static v11:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v11.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v10:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v10.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } else { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::new(match &(match v4.as_ref() { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v12,v13,v14) => { d_328c1b242187c34c181493001f639f84692ad9b9c55360f17301b6919dee1584(&(d_df95fd31337deaad84f3abe0d6c13adc30ae22013972652e3b6e45d2fff2139c(v12.as_ref(),v2))) } }) { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v15,v16,v17) => { d_328c1b242187c34c181493001f639f84692ad9b9c55360f17301b6919dee1584(&(d_df95fd31337deaad84f3abe0d6c13adc30ae22013972652e3b6e45d2fff2139c(v15.as_ref(),v2))) } }))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v19:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v19.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v18:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v18.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v1).wrapping_add(1u64),std::sync::Arc::clone({static v21:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v21.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v20:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v20.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(std::sync::Arc::new(D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(v2)),std::sync::Arc::clone({static v22:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v22.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))))) } } } }}
fn t_0d2d282affe6a4603c864201753bd83cb0dba367470d89e794c4868975eacdde(v0:&D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v1:u64)->D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67{match v0 { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(v2) => { D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v2))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(match v2.as_ref() { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v3,v4,v5) => { if ((0u64) == (0u64)) { (v4.as_ref()).clone() } else { if ((0u64) == (1u64)) { (v5.as_ref()).clone() } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v3.as_ref(),0u64) } } } }),false,v1,std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v8:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v8.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } }}
fn t_63badbf0ed518faff3fb607c7046bb50a5bdbcb2df55dfedbbb3de80b775cba9(v0:&D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v1:u64,v2:u64)->D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67{match v0 { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(v3) => { D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v3))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(match v3.as_ref() { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v4,v5,v6) => { if ((v2) == (0u64)) { (v5.as_ref()).clone() } else { if ((v2) == (1u64)) { (v6.as_ref()).clone() } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v4.as_ref(),v2) } } } }),false,v1,std::sync::Arc::clone({static v8:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v8.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v9:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v9.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } }}
fn t_6ea322a022e0bd401044d173f88216217ce2d2822356472a2758efddbf779926(v0:&D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v1:u64,v2:u64,v3:u64)->D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590{match v0 { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(v4) => { if match &(match v4.as_ref() { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v5,v6,v7) => { if ((v2) == (0u64)) { (v6.as_ref()).clone() } else { if ((v2) == (1u64)) { (v7.as_ref()).clone() } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v5.as_ref(),v2) } } } }) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v8) => { true } } { if match &(match v4.as_ref() { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v9,v10,v11) => { if ((v2) == (0u64)) { (v10.as_ref()).clone() } else { if ((v2) == (1u64)) { (v11.as_ref()).clone() } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v9.as_ref(),v2) } } } }) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v12) => { true } } { if ((v1) == (18446744073709551615u64)) { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v1,std::sync::Arc::clone({static v14:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v14.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v13:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v13.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } else { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::new(match v4.as_ref() { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v15,v16,v17) => { d_328c1b242187c34c181493001f639f84692ad9b9c55360f17301b6919dee1584(&(d_050b373a79d555c2577b1594d727d6cf1a60f9d11529a88ab3da5b35c5a8e44c(v15.as_ref(),v2,v3))) } }))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v19:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v19.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v18:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v18.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v1).wrapping_add(1u64),std::sync::Arc::clone({static v21:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v21.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v20:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v20.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v22:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v22.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } else { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v1,std::sync::Arc::clone({static v24:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v24.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v23:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v23.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } } else { if match &(match v4.as_ref() { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v25,v26,v27) => { if ((v2) == (0u64)) { (v26.as_ref()).clone() } else { if ((v2) == (1u64)) { (v27.as_ref()).clone() } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v25.as_ref(),v2) } } } }) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v28) => { true } } { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v1,std::sync::Arc::clone({static v30:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v30.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v29:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v29.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } else { if ((v1) == (18446744073709551615u64)) { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v1,std::sync::Arc::clone({static v32:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v32.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v31:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v31.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } else { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::new(match v4.as_ref() { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v33,v34,v35) => { d_328c1b242187c34c181493001f639f84692ad9b9c55360f17301b6919dee1584(&(d_74f987be179aff0a70be67aaf7a687192b43fbb60977140ba326b2adef21e03c(v33.as_ref(),v2,v3))) } }))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v37:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v37.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v36:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v36.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v1).wrapping_add(1u64),std::sync::Arc::clone({static v39:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v39.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v38:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v38.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v40:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v40.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } } } }}
fn t_ca1e82dddcc30b723beb5bf4d49df01029f09035e5c25a272ac71636114fa39c(v0:&D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v1:u64)->D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67{match v0 { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(v2) => { D_46ff75b627efbd9d8db513e7aaf8e12e5b9b8dd8f3eccd84b0a8071ebf079e67::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v2))),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(match v2.as_ref() { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v3,v4,v5) => { if ((1u64) == (0u64)) { (v4.as_ref()).clone() } else { if ((1u64) == (1u64)) { (v5.as_ref()).clone() } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v3.as_ref(),1u64) } } } }),false,v1,std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v8:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v8.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } }}
fn t_eb29f27edc9357a8508b7f19d795f0543c27d10e6d1d03f8b4354a1f89676b03(v0:&D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,v1:u64,v2:u64,v3:u64,v4:bool)->D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590{match v0 { D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(v5) => { if match &(match v5.as_ref() { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v6,v7,v8) => { if ((v2) == (0u64)) { (v7.as_ref()).clone() } else { if ((v2) == (1u64)) { (v8.as_ref()).clone() } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v6.as_ref(),v2) } } } }) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v9) => { true } } { if match &(match v5.as_ref() { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v10,v11,v12) => { if ((v2) == (0u64)) { (v11.as_ref()).clone() } else { if ((v2) == (1u64)) { (v12.as_ref()).clone() } else { d_199c66913e5f58936c80e9fb840c45132f6c212458a166668d67d8263eae2613(v10.as_ref(),v2) } } } }) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v13) => { true } } { if v4 { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v5))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v15:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v15.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v14:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v14.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v1,std::sync::Arc::clone({static v17:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v17.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v16:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v16.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v18:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v18.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } else { if ((v1) == (18446744073709551615u64)) { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v5))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v1,std::sync::Arc::clone({static v20:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v20.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v19:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v19.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } else { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::new(match v5.as_ref() { D_ce170b1e2ee491b26725ac34b6ef708ab1967f5c4508e715dd7296558fa7c8fa::C0(v21,v22,v23) => { d_328c1b242187c34c181493001f639f84692ad9b9c55360f17301b6919dee1584(&(d_050b373a79d555c2577b1594d727d6cf1a60f9d11529a88ab3da5b35c5a8e44c(v21.as_ref(),v2,v3))) } }))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v25:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v25.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v24:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v24.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v1).wrapping_add(1u64),std::sync::Arc::clone({static v27:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v27.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v26:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v26.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(std::sync::Arc::new(D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(v3)),std::sync::Arc::clone({static v28:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v28.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))))) } } } else { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v5))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v1,std::sync::Arc::clone({static v30:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v30.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v29:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v29.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))})))) } } else { D_67d1912098a4208787e9529fca7edd1ba29916a4846b01c877864b96f72ab590::C0(std::sync::Arc::new(D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c::C0(std::sync::Arc::clone(v5))),std::sync::Arc::new(D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::clone({static v32:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v32.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v31:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v31.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v1,std::sync::Arc::clone({static v34:std::sync::OnceLock<std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>>=std::sync::OnceLock::new();v34.get_or_init(||std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone({static v33:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v33.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))}))))}),std::sync::Arc::clone({static v35:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v35.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } }}

use serde_json::{Value as Json,json};
mod portable{
//! Shared, representation-independent snapshot codec. This module also ships
//! verbatim in generated applications; it has no AST/evaluator dependency.
use num_bigint::{BigInt, Sign};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::cmp::Ordering;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Schema {
    Unit,
    Bool,
    U32,
    U64,
    I32,
    F32,
    Vector(Box<Schema>, u8),
    Int,
    String,
    Id,
    Record(Vec<(String, Schema)>),
    Enum(Vec<String>),
    List(Box<Schema>),
    Option(Box<Schema>),
    Result(Box<Schema>, Box<Schema>),
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Layout {
    pub program: [u8; 32],
    pub schema: [u8; 32],
    pub roots: Vec<(String, Schema, Schema)>,
    pub events: Vec<(String, Schema)>,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Event {
    pub commit: u64,
    pub position: u64,
    pub channel: usize,
    pub value: Value,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Logical {
    pub version: u64,
    pub tables: Vec<Vec<(Value, Value)>>,
    pub outbox: Vec<Event>,
}
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub bytes: usize,
    pub values: usize,
    pub depth: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            bytes: 64 * 1024 * 1024,
            values: 1_000_000,
            depth: 128,
        }
    }
}
/// Magnitude bound for one exact integer. Decimal conversion is superlinear,
/// so without it a single large Int in a snapshot takes minutes to hours.
pub const MAX_INT_BYTES: usize = 4096;
const MAGIC: &[u8; 8] = b"VLSTATE\0";
const HEADER: usize = 8 + 2 + 2 + 32 + 32 + 8;
type R<T> = Result<T, String>;
fn u64_bytes(out: &mut Vec<u8>, v: u64) {
    out.extend_from_slice(&v.to_le_bytes());
}
fn count(out: &mut Vec<u8>, n: usize) {
    u64_bytes(out, n as u64);
}
fn raw(out: &mut Vec<u8>, b: &[u8]) {
    count(out, b.len());
    out.extend_from_slice(b);
}
fn tag<'a>(v: &'a Value, name: &str) -> R<&'a Value> {
    let o = v.as_object().ok_or("expected tagged object")?;
    if o.len() != 1 {
        return Err("expected exactly one tag".into());
    }
    o.get(name).ok_or("unexpected value tag".into())
}
fn integer(v: &Value) -> R<BigInt> {
    let s = tag(v, "Int")?.as_str().ok_or("expected Int string")?;
    // Every Int within the bound has fewer than 2.41 decimal digits per byte.
    if s.len() > MAX_INT_BYTES * 5 / 2 + 1 {
        return Err("snapshot Int exceeds size limit".into());
    }
    let n = s.parse::<BigInt>().map_err(|_| "invalid Int")?;
    if n.bits() > 8 * MAX_INT_BYTES as u64 {
        return Err("snapshot Int exceeds size limit".into());
    }
    if n.to_string() != s {
        return Err("noncanonical Int".into());
    }
    Ok(n)
}
fn identifier(v: &Value) -> R<u128> {
    let s = v.as_str().ok_or("expected ID")?;
    if s.len() != 32
        || !s
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err("noncanonical ID".into());
    }
    u128::from_str_radix(s, 16).map_err(|e| e.to_string())
}
fn compare(t: &Schema, a: &Value, b: &Value) -> R<Ordering> {
    Ok(match t {
        Schema::I32 => a
            .as_i64()
            .and_then(|n| i32::try_from(n).ok())
            .ok_or("invalid i32 key")?
            .cmp(
                &b.as_i64()
                    .and_then(|n| i32::try_from(n).ok())
                    .ok_or("invalid i32 key")?,
            ),
        Schema::U32 | Schema::U64 => a
            .as_u64()
            .ok_or("invalid key")?
            .cmp(&b.as_u64().ok_or("invalid key")?),
        Schema::String => a
            .as_str()
            .ok_or("invalid key")?
            .as_bytes()
            .cmp(b.as_str().ok_or("invalid key")?.as_bytes()),
        Schema::Id => identifier(a)?.cmp(&identifier(b)?),
        _ => return Err("unsupported snapshot key schema".into()),
    })
}
fn tick(left: &mut usize, depth: usize, limits: Limits) -> R<()> {
    if *left == 0 || depth > limits.depth {
        return Err("snapshot value/depth limit exceeded".into());
    }
    *left -= 1;
    Ok(())
}
fn encode_value(
    t: &Schema,
    v: &Value,
    out: &mut Vec<u8>,
    left: &mut usize,
    depth: usize,
    limits: Limits,
) -> R<()> {
    tick(left, depth, limits)?;
    match t {
        Schema::Unit => {
            if !v.is_null() {
                return Err("expected Unit".into());
            }
        }
        Schema::Bool => out.push(v.as_bool().ok_or("expected Bool")? as u8),
        Schema::U32 => out.extend_from_slice(
            &u32::try_from(v.as_u64().ok_or("expected u32")?)
                .map_err(|_| "u32 overflow")?
                .to_le_bytes(),
        ),
        Schema::U64 => u64_bytes(out, v.as_u64().ok_or("expected u64")?),
        Schema::I32 => out.extend_from_slice(
            &i32::try_from(v.as_i64().ok_or("expected i32")?)
                .map_err(|_| "i32 overflow")?
                .to_le_bytes(),
        ),
        Schema::F32 => {
            let bits = if let Some(b) = v.get("F32Bits") {
                if v.as_object().is_none_or(|o| o.len() != 1) {
                    return Err("expected only F32Bits field".into());
                }
                u32::try_from(b.as_u64().ok_or("expected f32 bits")?)
                    .map_err(|_| "f32 bits overflow")?
            } else {
                let f = v.as_f64().ok_or("expected f32")? as f32;
                if !f.is_finite() {
                    return Err("finite f32 or F32Bits required".into());
                }
                f.to_bits()
            };
            out.extend_from_slice(&bits.to_le_bytes());
        }
        Schema::Vector(inner, n) => {
            if !(2..=4).contains(n)
                || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
            {
                return Err("invalid vector schema".into());
            }
            let xs = v.as_array().ok_or("expected vector")?;
            if xs.len() != *n as usize {
                return Err("vector dimension mismatch".into());
            }
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Int => {
            let n = integer(v)?;
            let (sign, b) = n.to_bytes_le();
            out.push(match sign {
                Sign::NoSign => 0,
                Sign::Plus => 1,
                Sign::Minus => 2,
            });
            if sign == Sign::NoSign {
                raw(out, &[])
            } else {
                raw(out, &b)
            }
        }
        Schema::String => raw(out, v.as_str().ok_or("expected String")?.as_bytes()),
        Schema::Id => out.extend_from_slice(&identifier(v)?.to_le_bytes()),
        Schema::Enum(names) => {
            let s = v.as_str().ok_or("expected enum string")?;
            let index = names
                .iter()
                .position(|n| n == s)
                .ok_or("unknown enum variant")?;
            out.extend_from_slice(&(index as u32).to_le_bytes());
        }
        Schema::Record(fields) => {
            let obj = v.as_object().ok_or("expected record")?;
            if obj.len() != fields.len() {
                return Err("record field mismatch".into());
            }
            for (n, t) in fields {
                encode_value(
                    t,
                    obj.get(n).ok_or("missing record field")?,
                    out,
                    left,
                    depth + 1,
                    limits,
                )?;
            }
        }
        Schema::List(inner) => {
            let xs = v.as_array().ok_or("expected List")?;
            if xs.len() > *left {
                return Err("snapshot value limit exceeded".into());
            }
            count(out, xs.len());
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Option(inner) => {
            if let Ok(x) = tag(v, "Some") {
                out.push(1);
                encode_value(inner, x, out, left, depth + 1, limits)?;
            } else {
                if !tag(v, "None")?.is_null() {
                    return Err("invalid None".into());
                }
                out.push(0);
            }
        }
        Schema::Result(a, b) => {
            if let Ok(x) = tag(v, "Ok") {
                out.push(0);
                encode_value(a, x, out, left, depth + 1, limits)?;
            } else {
                out.push(1);
                encode_value(b, tag(v, "Err")?, out, left, depth + 1, limits)?;
            }
        }
    }
    if out.len() > limits.bytes {
        return Err("snapshot byte limit exceeded".into());
    }
    Ok(())
}
struct Reader<'a> {
    bytes: &'a [u8],
    at: usize,
    left: usize,
    limits: Limits,
}
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> R<&'a [u8]> {
        let end = self.at.checked_add(n).ok_or("snapshot length overflow")?;
        let b = self.bytes.get(self.at..end).ok_or("truncated snapshot")?;
        self.at = end;
        Ok(b)
    }
    fn byte(&mut self) -> R<u8> {
        Ok(self.take(1)?[0])
    }
    fn u32(&mut self) -> R<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn u64(&mut self) -> R<u64> {
        Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
    fn len(&mut self) -> R<usize> {
        usize::try_from(self.u64()?).map_err(|_| "snapshot length not addressable".into())
    }
    fn sequence(&mut self) -> R<usize> {
        let n = self.len()?;
        if n > self.left {
            return Err("snapshot value limit exceeded".into());
        }
        Ok(n)
    }
    fn raw(&mut self) -> R<&'a [u8]> {
        let n = self.len()?;
        self.take(n)
    }
    fn value(&mut self, t: &Schema, depth: usize) -> R<Value> {
        tick(&mut self.left, depth, self.limits)?;
        Ok(match t {
            Schema::Unit => Value::Null,
            Schema::Bool => match self.byte()? {
                0 => json!(false),
                1 => json!(true),
                _ => return Err("invalid Bool tag".into()),
            },
            Schema::U32 => json!(self.u32()?),
            Schema::U64 => json!(self.u64()?),
            Schema::I32 => json!(self.u32()? as i32),
            Schema::F32 => {
                let bits = self.u32()?;
                let f = f32::from_bits(bits);
                if f.is_finite() {
                    json!(f)
                } else {
                    json!({"F32Bits":bits})
                }
            }
            Schema::Vector(inner, n) => {
                if !(2..=4).contains(n)
                    || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
                {
                    return Err("invalid vector schema".into());
                }
                (0..*n)
                    .map(|_| self.value(inner, depth + 1))
                    .collect::<R<Vec<_>>>()?
                    .into()
            }
            Schema::Int => {
                let sign = self.byte()?;
                let bytes = self.raw()?;
                if bytes.len() > MAX_INT_BYTES {
                    return Err("snapshot Int exceeds size limit".into());
                }
                let sign = match sign {
                    0 if bytes.is_empty() => Sign::NoSign,
                    1 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Plus,
                    2 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Minus,
                    _ => return Err("noncanonical signed integer".into()),
                };
                json!({"Int":BigInt::from_bytes_le(sign,bytes).to_string()})
            }
            Schema::String => json!(std::str::from_utf8(self.raw()?).map_err(|_| "invalid UTF-8")?),
            Schema::Id => json!(format!(
                "{:032x}",
                u128::from_le_bytes(self.take(16)?.try_into().unwrap())
            )),
            Schema::Enum(names) => {
                json!(names.get(self.u32()? as usize).ok_or("invalid enum tag")?)
            }
            Schema::Record(fields) => {
                let mut obj = serde_json::Map::new();
                for (n, t) in fields {
                    obj.insert(n.clone(), self.value(t, depth + 1)?);
                }
                Value::Object(obj)
            }
            Schema::List(t) => {
                let n = self.sequence()?;
                let mut xs = Vec::new();
                for _ in 0..n {
                    xs.push(self.value(t, depth + 1)?);
                }
                Value::Array(xs)
            }
            Schema::Option(t) => match self.byte()? {
                0 => json!({"None":null}),
                1 => json!({"Some":self.value(t,depth+1)?}),
                _ => return Err("invalid Option tag".into()),
            },
            Schema::Result(a, b) => match self.byte()? {
                0 => json!({"Ok":self.value(a,depth+1)?}),
                1 => json!({"Err":self.value(b,depth+1)?}),
                _ => return Err("invalid Result tag".into()),
            },
        })
    }
}
fn event_order(e: &Event, version: u64, prior: Option<(u64, u64)>) -> R<()> {
    if e.commit == 0 || e.commit > version || prior.is_some_and(|p| p >= (e.commit, e.position)) {
        return Err("invalid snapshot event sequence".into());
    }
    Ok(())
}
pub fn encode(layout: &Layout, s: &Logical, limits: Limits) -> R<Vec<u8>> {
    if s.tables.len() != layout.roots.len() {
        return Err("snapshot root count mismatch".into());
    }
    let mut out = Vec::new();
    let mut left = limits.values;
    u64_bytes(&mut out, s.version);
    for (rows, (_, kt, vt)) in s.tables.iter().zip(&layout.roots) {
        if rows.len() > left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        count(&mut out, rows.len());
        let mut prior = None;
        for (k, v) in rows {
            if let Some(p) = prior {
                if compare(kt, p, k)? != Ordering::Less {
                    return Err("snapshot keys must be strictly ordered".into());
                }
            }
            encode_value(kt, k, &mut out, &mut left, 0, limits)?;
            encode_value(vt, v, &mut out, &mut left, 0, limits)?;
            prior = Some(k);
        }
    }
    count(&mut out, s.outbox.len());
    let mut prior = None;
    for e in &s.outbox {
        event_order(e, s.version, prior)?;
        let (_, t) = layout
            .events
            .get(e.channel)
            .ok_or("unknown event channel")?;
        u64_bytes(&mut out, e.commit);
        u64_bytes(&mut out, e.position);
        out.extend_from_slice(&(e.channel as u32).to_le_bytes());
        encode_value(t, &e.value, &mut out, &mut left, 0, limits)?;
        prior = Some((e.commit, e.position));
    }
    if HEADER
        .checked_add(out.len())
        .and_then(|n| n.checked_add(32))
        .is_none_or(|n| n > limits.bytes)
    {
        return Err("snapshot byte limit exceeded".into());
    }
    let mut bytes = Vec::new();
    bytes.extend_from_slice(MAGIC);
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&layout.program);
    bytes.extend_from_slice(&layout.schema);
    count(&mut bytes, out.len());
    bytes.extend_from_slice(&out);
    let digest = Sha256::digest(&bytes);
    bytes.extend_from_slice(&digest);
    Ok(bytes)
}
pub fn decode(layout: &Layout, bytes: &[u8], limits: Limits) -> R<Logical> {
    if bytes.len() > limits.bytes || bytes.len() < HEADER + 32 {
        return Err("snapshot byte length invalid".into());
    }
    if &bytes[..8] != MAGIC || bytes[8..12] != [1, 0, 1, 0] {
        return Err("snapshot format or semantics version mismatch".into());
    }
    if bytes[12..44] != layout.program || bytes[44..76] != layout.schema {
        return Err("snapshot program or schema identity mismatch".into());
    }
    let n = usize::try_from(u64::from_le_bytes(bytes[76..84].try_into().unwrap()))
        .map_err(|_| "snapshot length not addressable")?;
    if HEADER.checked_add(n).and_then(|v| v.checked_add(32)) != Some(bytes.len()) {
        return Err("snapshot payload length mismatch".into());
    }
    let end = bytes.len() - 32;
    if Sha256::digest(&bytes[..end]).as_slice() != &bytes[end..] {
        return Err("snapshot integrity check failed".into());
    }
    let mut r = Reader {
        bytes: &bytes[HEADER..end],
        at: 0,
        left: limits.values,
        limits,
    };
    let version = r.u64()?;
    let mut tables = vec![];
    for (_, kt, vt) in &layout.roots {
        let n = r.sequence()?;
        if n > r.left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        let mut rows: Vec<(Value, Value)> = vec![];
        for _ in 0..n {
            let k = r.value(kt, 0)?;
            let v = r.value(vt, 0)?;
            if let Some((prior, _)) = rows.last() {
                if compare(kt, prior, &k)? != Ordering::Less {
                    return Err("duplicate or unordered snapshot key".into());
                }
            }
            rows.push((k, v));
        }
        tables.push(rows);
    }
    let n = r.sequence()?;
    let mut outbox = vec![];
    let mut prior = None;
    for _ in 0..n {
        let commit = r.u64()?;
        let position = r.u64()?;
        let channel = r.u32()? as usize;
        let (_, t) = layout
            .events
            .get(channel)
            .ok_or("unknown snapshot event channel")?;
        let value = r.value(t, 0)?;
        let e = Event {
            commit,
            position,
            channel,
            value,
        };
        event_order(&e, version, prior)?;
        prior = Some((commit, position));
        outbox.push(e);
    }
    if r.at != r.bytes.len() {
        return Err("trailing snapshot payload".into());
    }
    Ok(Logical {
        version,
        tables,
        outbox,
    })
}

}
pub use portable::Limits as SnapshotLimits;
fn snapshot_layout()->portable::Layout{portable::Layout{program:[255, 4, 117, 215, 71, 163, 245, 79, 91, 5, 184, 13, 208, 246, 185, 97, 201, 75, 126, 146, 140, 93, 124, 164, 47, 146, 227, 5, 76, 237, 154, 239],schema:[192, 141, 16, 114, 17, 172, 249, 182, 219, 154, 142, 125, 228, 252, 175, 89, 60, 246, 149, 204, 109, 105, 172, 253, 213, 158, 150, 88, 181, 131, 24, 90],roots:vec![
("Rows".into(),portable::Schema::U64,portable::Schema::U64),
],events:vec![("seen".into(),portable::Schema::U64),
]}}
fn one_tag<'a>(v:&'a Json,_kind:&str)->Result<&'a serde_json::Map<String,Json>,String>{Ok(v.as_object().unwrap())}
fn read_0(v:&Json,d:usize)->Result<bool,String>{Ok(
v.as_bool().unwrap())}
fn write_0(v:&bool,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_1(v:&Json,d:usize)->Result<u64,String>{Ok(
v.as_u64().unwrap())}
fn write_1(v:&u64,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_2(v:&Json,d:usize)->Result<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c,String>{Ok(
{D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0})}
fn write_2(v:&D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c,d:usize)->Result<Json,String>{Ok(
Json::Null)}
fn read_3(v:&Json,d:usize)->Result<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b,String>{Ok(
{let text=v.as_str().unwrap();match text{"Error.Failed"=>D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0,_=>unreachable!("caller enum precondition")}})}
fn write_3(v:&D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b,d:usize)->Result<Json,String>{Ok(
match v{D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0=>json!("Error.Failed"),})}
fn read_4(v:&Json,d:usize)->Result<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(read_1(x,d+1)?)}else{D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0}})}
fn write_4(v:&D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02,d:usize)->Result<Json,String>{Ok(
match v{D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0=>json!({"None":null}),D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(x)=>json!({"Some":write_1(x,d+1)?})})}
fn read_5(v:&Json,d:usize)->Result<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f,String>{Ok(
{let xs=one_tag(v,"Result")?;if let Some(x)=xs.get("Ok"){D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::new(read_2(x,d+1)?))}else{let x=xs.get("Err").unwrap();D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::new(read_3(x,d+1)?))}})}
fn write_5(v:&D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f,d:usize)->Result<Json,String>{Ok(
match v{D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(x)=>json!({"Ok":write_2(x,d+1)?}),D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(x)=>json!({"Err":write_3(x,d+1)?})})}
fn logical_from_tables(tables:&[Vec<(Json,Json)>])->Result<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d,String>{if tables.len()!=1{return Err("representation table count mismatch".into())}
let rows=&tables[0];let mut root0=D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0;for (key,row) in rows.iter().rev(){root0=D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(read_1(key,0)?,read_1(row,0)?,std::sync::Arc::new(root0));}
Ok(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(root0)))}
fn logical_tables(state:&D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d)->Result<Vec<Vec<(Json,Json)>>,String>{let D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(r0)=state;
let mut rows0=vec![];let mut cursor=r0.as_ref();loop{match cursor{D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0=>break,D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(key,value,tail)=>{rows0.push((write_1(key,0)?,write_1(value,0)?));cursor=tail.as_ref();}}}
Ok(vec![rows0])}
fn logical_events(events:&D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de)->Result<Vec<(usize,Json)>,String>{let mut cursor=events;let mut out=vec![];loop{match cursor{D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0=>break,D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(event,tail)=>{let value=match event.as_ref(){
D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(value)=>(0,write_1(value,0)?),
};out.push(value);cursor=tail.as_ref();}}}Ok(out)}
pub use portable::Event;
pub struct Outcome<T>{pub result:T,pub committed:bool,pub version:u64,pub events:Vec<Event>}
pub struct OutcomeView<'a,T>{pub result:T,pub committed:bool,pub version:u64,pub events:&'a[Event]}
impl<T> OutcomeView<'_,T>{pub fn into_owned(self)->Outcome<T>{Outcome{result:self.result,committed:self.committed,version:self.version,events:self.events.to_vec()}}}
pub struct State{physical:D_3aa9f818616e8eaced928c3a7551a0cc302315fa9e33160f90eafe322a2ff73c,version:u64,outbox:Vec<portable::Event>,layout:portable::Layout}
impl State{
// CALLER CONTRACT: arguments must have the declared types and canonical values.
// No runtime type validation. Malformed input may panic, trap or corrupt state.
pub fn new()->Result<Self,String>{let logical=D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0));Ok(Self{physical:f_81b9db563571007004127ada27e40a97fb701fb791575f4f5860a64709b39c4f(&logical),version:0,outbox:vec![],layout:snapshot_layout()})}
pub fn restore(bytes:&[u8])->Result<Self,String>{let layout=snapshot_layout();let saved=portable::decode(&layout,bytes,SnapshotLimits::default())?;let logical=logical_from_tables(&saved.tables)?;Ok(Self{physical:f_81b9db563571007004127ada27e40a97fb701fb791575f4f5860a64709b39c4f(&logical),version:saved.version,outbox:saved.outbox,layout})}
pub fn checkpoint(&self)->Result<Vec<u8>,String>{let logical=f_07a3a714c1d097faca974ce75b4a4916e4cda121c308be3bc9c8fd846859116e(&(self.physical));portable::encode(&self.layout,&portable::Logical{version:self.version,tables:logical_tables(&logical)?,outbox:self.outbox.clone()},SnapshotLimits::default())}
pub fn version(&self)->u64{self.version}
pub fn outbox_json(&self)->Json{Json::Array(self.outbox.iter().map(|e|json!({"commit":e.commit,"position":e.position,"channel":self.layout.events[e.channel].0,"value":e.value})).collect())}
pub fn acknowledge_through(&mut self,commit:u64,position:u64){self.outbox.retain(|e|(e.commit,e.position)>(commit,position));}
pub fn query_zero(&self,)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{q_0d2d282affe6a4603c864201753bd83cb0dba367470d89e794c4868975eacdde(&(self.physical),self.version)}
pub fn query_get(&self,a0:u64)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{q_63badbf0ed518faff3fb607c7046bb50a5bdbcb2df55dfedbbb3de80b775cba9(&(self.physical),self.version,a0)}
pub fn query_one(&self,)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{q_ca1e82dddcc30b723beb5bf4d49df01029f09035e5c25a272ac71636114fa39c(&(self.physical),self.version)}
pub fn invoke_view_put(&mut self,a0:u64,a1:u64)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=t_6ea322a022e0bd401044d173f88216217ce2d2822356472a2758efddbf779926(&(self.physical),self.version,a0,a1);let observed=f_5d884283e2959b79470f28da074d7e6ba7f349b2763ef943962635123d15f7d4(&(executed));let next=f_b9602508123863ebff312e2dbe1b8ff6383ab16bf8f9cbf1c294d29020b4d130(&(executed));
let(result,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_replace(&mut self,a0:u64,a1:u64,a2:bool)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=t_eb29f27edc9357a8508b7f19d795f0543c27d10e6d1d03f8b4354a1f89676b03(&(self.physical),self.version,a0,a1,a2);let observed=f_5d884283e2959b79470f28da074d7e6ba7f349b2763ef943962635123d15f7d4(&(executed));let next=f_b9602508123863ebff312e2dbe1b8ff6383ab16bf8f9cbf1c294d29020b4d130(&(executed));
let(result,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_erase(&mut self,a0:u64,a1:bool)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=t_0849b1170431e1782069b241090d953722c415caac185d3582f0a7a37a326eb6(&(self.physical),self.version,a0,a1);let observed=f_5d884283e2959b79470f28da074d7e6ba7f349b2763ef943962635123d15f7d4(&(executed));let next=f_b9602508123863ebff312e2dbe1b8ff6383ab16bf8f9cbf1c294d29020b4d130(&(executed));
let(result,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_zero(&mut self,)->Result<OutcomeView<'_,D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,String>{
let result=q_0d2d282affe6a4603c864201753bd83cb0dba367470d89e794c4868975eacdde(&(self.physical),self.version);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_view_get(&mut self,a0:u64)->Result<OutcomeView<'_,D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,String>{
let result=q_63badbf0ed518faff3fb607c7046bb50a5bdbcb2df55dfedbbb3de80b775cba9(&(self.physical),self.version,a0);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_view_one(&mut self,)->Result<OutcomeView<'_,D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,String>{
let result=q_ca1e82dddcc30b723beb5bf4d49df01029f09035e5c25a272ac71636114fa39c(&(self.physical),self.version);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_json(&mut self,name:&str,args:&Json)->Result<Json,String>{match name{
"put"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_1(&xs[1],0)?;
let executed=t_6ea322a022e0bd401044d173f88216217ce2d2822356472a2758efddbf779926(&(self.physical),self.version,a0,a1);
let observed=f_5d884283e2959b79470f28da074d7e6ba7f349b2763ef943962635123d15f7d4(&(executed));let next=f_b9602508123863ebff312e2dbe1b8ff6383ab16bf8f9cbf1c294d29020b4d130(&(executed));let(reply,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_5(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"replace"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_1(&xs[1],0)?;
let a2=read_0(&xs[2],0)?;
let executed=t_eb29f27edc9357a8508b7f19d795f0543c27d10e6d1d03f8b4354a1f89676b03(&(self.physical),self.version,a0,a1,a2);
let observed=f_5d884283e2959b79470f28da074d7e6ba7f349b2763ef943962635123d15f7d4(&(executed));let next=f_b9602508123863ebff312e2dbe1b8ff6383ab16bf8f9cbf1c294d29020b4d130(&(executed));let(reply,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_5(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"erase"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_0(&xs[1],0)?;
let executed=t_0849b1170431e1782069b241090d953722c415caac185d3582f0a7a37a326eb6(&(self.physical),self.version,a0,a1);
let observed=f_5d884283e2959b79470f28da074d7e6ba7f349b2763ef943962635123d15f7d4(&(executed));let next=f_b9602508123863ebff312e2dbe1b8ff6383ab16bf8f9cbf1c294d29020b4d130(&(executed));let(reply,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_5(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"zero"=>{let xs=args.as_array().unwrap();
let reply=q_0d2d282affe6a4603c864201753bd83cb0dba367470d89e794c4868975eacdde(&(self.physical),self.version);let result=write_4(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
"get"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let reply=q_63badbf0ed518faff3fb607c7046bb50a5bdbcb2df55dfedbbb3de80b775cba9(&(self.physical),self.version,a0);let result=write_4(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
"one"=>{let xs=args.as_array().unwrap();
let reply=q_ca1e82dddcc30b723beb5bf4d49df01029f09035e5c25a272ac71636114fa39c(&(self.physical),self.version);let result=write_4(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
_=>Err(format!("unknown action {name}"))}}}
