mod before;mod after;
use std::{alloc::{GlobalAlloc,Layout,System},hint::black_box,sync::atomic::{AtomicUsize,Ordering},time::Instant};
use serde_json::{Value as Json,json};
use sha2::{Digest,Sha256};
struct Count;
static LIVE:AtomicUsize=AtomicUsize::new(0);
static PEAK:AtomicUsize=AtomicUsize::new(0);
static ALLOCS:AtomicUsize=AtomicUsize::new(0);
fn added(n:usize){ALLOCS.fetch_add(1,Ordering::Relaxed);let live=LIVE.fetch_add(n,Ordering::Relaxed)+n;PEAK.fetch_max(live,Ordering::Relaxed);}
unsafe impl GlobalAlloc for Count {
 unsafe fn alloc(&self,l:Layout)->*mut u8 {let p=System.alloc(l);if !p.is_null(){added(l.size());}p}
 unsafe fn dealloc(&self,p:*mut u8,l:Layout){System.dealloc(p,l);LIVE.fetch_sub(l.size(),Ordering::Relaxed);}
 unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {let q=System.realloc(p,l,n);if !q.is_null(){ALLOCS.fetch_add(1,Ordering::Relaxed);if n>=l.size(){let live=LIVE.fetch_add(n-l.size(),Ordering::Relaxed)+n-l.size();PEAK.fetch_max(live,Ordering::Relaxed);}else{LIVE.fetch_sub(l.size()-n,Ordering::Relaxed);}}q}
}
#[cfg(counted)] #[global_allocator] static GLOBAL:Count=Count;
fn phase(repeats:usize,mut f:impl FnMut())->Json {
 let before=LIVE.load(Ordering::Relaxed);PEAK.store(before,Ordering::Relaxed);ALLOCS.store(0,Ordering::Relaxed);
 let start=Instant::now();for _ in 0..repeats{f();}let ns=start.elapsed().as_nanos();
 let allocations=ALLOCS.load(Ordering::Relaxed);let peak=PEAK.load(Ordering::Relaxed)-before;
 let after=LIVE.load(Ordering::Relaxed);
 json!({"repeats":repeats,"total_ns":ns as u64,"allocations":allocations,"peak_added_bytes":peak,"live_delta_bytes":after as i64-before as i64})
}

trait Database:Sized{fn new()->Self;fn call(&mut self,args:&Json)->Json;fn checkpoint(&self)->Vec<u8>;fn restore(b:&[u8])->Self;}
macro_rules! adapter{($m:ident)=>{impl Database for $m::State{fn new()->Self{Self::new()}fn call(&mut self,args:&Json)->Json{self.invoke_json("route",args).unwrap()}fn checkpoint(&self)->Vec<u8>{Self::checkpoint(self).unwrap()}fn restore(b:&[u8])->Self{Self::restore(b).unwrap()}}}}adapter!(before);adapter!(after);
fn sample<D:Database>(width:usize)->Json{
 let args=json!([vec![0u32;width*width],width,0,width*width-1,width*width*8]);
 let startup=phase(32,||{black_box(D::new());});let mut state=D::new();let saved=state.checkpoint();let mut expected=None;
 let cold=phase(1,||{expected=Some(state.call(&args));});let expected=expected.unwrap();assert_eq!(expected["result"]["found"],true);assert_eq!(expected["result"]["distance"],2*(width-1));
 let warm=phase(32,||{assert_eq!(black_box(state.call(&args)),expected);});assert_eq!(state.checkpoint(),saved);
 let checkpoint=phase(32,||{black_box(state.checkpoint());});let restore=phase(32,||{black_box(D::restore(&saved));});let retained=LIVE.load(Ordering::Relaxed);
 let mut state=Some(state);let teardown=phase(1,||{drop(state.take());});
 json!({"startup":startup,"cold_query":cold,"warm_query":warm,"checkpoint":checkpoint,"restore":restore,"teardown":teardown,"requested_live_bytes_after_warm":retained,"snapshot_sha256":format!("{:x}",Sha256::digest(&saved)),"result_sha256":format!("{:x}",Sha256::digest(serde_json::to_vec(&expected).unwrap()))})
}
fn main(){let args:Vec<String>=std::env::args().collect();let width=args[2].parse().unwrap();let v=if args[1]=="before"{sample::<before::State>(width)}else{sample::<after::State>(width)};println!("{v}");}
