#![allow(non_camel_case_types,non_snake_case,unused_variables,unused_parens,dead_code)]
// Shared support for generated native applications. No parser or evaluator.
// CALLER CONTRACT: correctly typed, canonical arguments; no runtime type validation.
// Malformed arguments may panic or produce incorrect results. Native raw ABIs may corrupt memory.
use num_bigint::BigInt;
use serde_json::{Value as Json, json};
use std::collections::BTreeMap;
pub trait Wire: Sized {
    fn to_json(&self) -> Json;
    fn from_json(v: &Json) -> Result<Self, String>;
}
macro_rules! unsigned_wire {
    ($t:ty) => { impl Wire for $t {
        fn to_json(&self) -> Json { json!(self) }
        fn from_json(v:&Json)->Result<Self,String> { Ok(v.as_u64().unwrap() as $t) }
    } };
}
unsigned_wire!(u32); unsigned_wire!(u64);
impl Wire for () {
    fn to_json(&self)->Json { Json::Null }
    fn from_json(v:&Json)->Result<Self,String>{ let _=v;Ok(()) }
}
impl Wire for bool {
    fn to_json(&self)->Json{json!(self)}
    fn from_json(v:&Json)->Result<Self,String>{Ok(v.as_bool().unwrap())}
}
impl Wire for String {
    fn to_json(&self)->Json{json!(self)}
    fn from_json(v:&Json)->Result<Self,String>{Ok(v.as_str().unwrap().to_owned())}
}
impl Wire for BigInt {
    fn to_json(&self)->Json{json!({"Int":self.to_string()})}
    fn from_json(v:&Json)->Result<Self,String>{v.get("Int").and_then(Json::as_str).map(str::to_owned).unwrap_or_else(||v.to_string()).parse().map_or_else(|_|panic!("caller Int precondition"),Ok)}
}
impl<T:Wire> Wire for Vec<T> {
    fn to_json(&self)->Json{self.iter().map(Wire::to_json).collect()}
    fn from_json(v:&Json)->Result<Self,String>{v.as_array().unwrap().iter().map(T::from_json).collect()}
}
impl<T:Wire> Wire for Option<T> {
    fn to_json(&self)->Json{match self{Some(v)=>json!({"Some":v.to_json()}),None=>json!({"None":null})}}
    fn from_json(v:&Json)->Result<Self,String>{
        let obj=v.as_object().unwrap();
        if let Some(x)=obj.get("Some"){Ok(Some(T::from_json(x)?))}
        else {Ok(None)}
    }
}
impl<T:Wire,E:Wire> Wire for Result<T,E> {
    fn to_json(&self)->Json{match self{Ok(v)=>json!({"Ok":v.to_json()}),Err(e)=>json!({"Err":e.to_json()})}}
    fn from_json(v:&Json)->Result<Self,String>{
        let obj=v.as_object().unwrap();
        if let Some(x)=obj.get("Ok"){Ok(Ok(T::from_json(x)?))}
        else {Ok(Err(E::from_json(obj.get("Err").unwrap())?))}
    }
}
#[derive(Clone, Debug)]
pub struct Event {pub commit:u64,pub position:u64,pub data:EventData}
impl Event {
    pub fn to_json(&self)->Json {let (channel,value)=self.data.wire();json!({"commit":self.commit,"position":self.position,"channel":channel,"value":value})}
}
#[derive(Clone, Debug)]
pub struct Outcome<T> {pub result:T,pub committed:bool,pub version:u64,pub events:Vec<Event>}
impl<T:Wire> Outcome<T> {
    pub fn to_json(&self)->Json {json!({"result":self.result.to_json(),"committed":self.committed,"version":self.version,"events":self.events.iter().map(Event::to_json).collect::<Vec<_>>()})}
}
// The borrow prevents further mutation of State while these event references
// exist. Keeping an outcome independently still uses the existing owned API.
#[derive(Debug)]
pub struct OutcomeView<'a,T> {pub result:T,pub committed:bool,pub version:u64,pub events:&'a [Event]}
impl<T> OutcomeView<'_,T> {
    pub fn into_owned(self)->Outcome<T>{Outcome{result:self.result,committed:self.committed,version:self.version,events:self.events.to_vec()}}
}
impl<T:Wire> OutcomeView<'_,T> {
    pub fn to_json(&self)->Json {json!({"result":self.result.to_json(),"committed":self.committed,"version":self.version,"events":self.events.iter().map(Event::to_json).collect::<Vec<_>>()})}
}

impl Wire for i32 {
 fn to_json(&self)->Json{json!(self)}
 fn from_json(v:&Json)->Result<Self,String>{Ok(v.as_i64().unwrap() as i32)}
}
impl Wire for f32 {
 fn to_json(&self)->Json{if self.is_finite(){json!(self)}else{json!({"F32Bits":self.to_bits()})}}
 fn from_json(v:&Json)->Result<Self,String>{
  Ok(if let Some(n)=v.as_f64(){n as f32}else{Self::from_bits(v["F32Bits"].as_u64().unwrap() as u32)})
 }
}
impl<T:Wire,const N:usize> Wire for [T;N] {
 fn to_json(&self)->Json{self.iter().map(Wire::to_json).collect()}
 fn from_json(v:&Json)->Result<Self,String>{let a=v.as_array().unwrap();Ok(std::array::from_fn(|i|T::from_json(&a[i]).unwrap()))}
}

#[derive(Clone,Copy,Debug,PartialEq,Eq)] pub enum InkArithmeticError {Overflow}
impl Wire for InkArithmeticError {
 fn to_json(&self)->Json{json!("ArithmeticError.Overflow")}
 fn from_json(v:&Json)->Result<Self,String>{let _=v;Ok(Self::Overflow)}
}

impl<T:Wire> Wire for Box<T> { fn to_json(&self)->Json { (**self).to_json() } fn from_json(v:&Json)->Result<Self,String> { Ok(Box::new(T::from_json(v)?)) } }

// Structural stored-data identity is separate from scalar IEEE equality.
trait InkDataEq { fn ink_data_eq(&self,other:&Self)->bool; }
macro_rules! data_eq {($($t:ty),*)=>{$(impl InkDataEq for $t{fn ink_data_eq(&self,other:&Self)->bool{self==other}})*};}
data_eq!((),bool,u32,u64,i32,BigInt,String,InkArithmeticError);
impl InkDataEq for f32{fn ink_data_eq(&self,other:&Self)->bool{self.to_bits()==other.to_bits()}}
impl<T:InkDataEq> InkDataEq for Box<T>{fn ink_data_eq(&self,other:&Self)->bool{(**self).ink_data_eq(&**other)}}
impl<T:InkDataEq> InkDataEq for Vec<T>{fn ink_data_eq(&self,other:&Self)->bool{self.len()==other.len()&&self.iter().zip(other).all(|(a,b)|a.ink_data_eq(b))}}
impl<T:InkDataEq,const N:usize> InkDataEq for [T;N]{fn ink_data_eq(&self,other:&Self)->bool{self.iter().zip(other).all(|(a,b)|a.ink_data_eq(b))}}
impl<T:InkDataEq> InkDataEq for Option<T>{fn ink_data_eq(&self,other:&Self)->bool{match(self,other){(Some(a),Some(b))=>a.ink_data_eq(b),(None,None)=>true,_=>false}}}
impl<T:InkDataEq,E:InkDataEq> InkDataEq for Result<T,E>{fn ink_data_eq(&self,other:&Self)->bool{match(self,other){(Ok(a),Ok(b))=>a.ink_data_eq(b),(Err(a),Err(b))=>a.ink_data_eq(b),_=>false}}}

mod temporary {
// Native ownership is represented directly. Checked source moves the owner;
// read methods and stopping predicates borrow it. No interior aliasing.
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct OwnedBuffer<T>(Vec<T>);
impl<T: Clone> OwnedBuffer<T> {
    pub fn new(xs: Vec<T>) -> Self {
        Self(xs)
    }
    pub fn len(&self) -> u32 {
        self.0.len().try_into().expect("buffer exceeds u32")
    }
    pub fn get(&self, i: u32) -> Option<T> {
        self.0.get(i as usize).cloned()
    }
    pub fn set(mut self, i: u32, value: T) -> Self {
        if let Some(v) = self.0.get_mut(i as usize) {
            *v = value;
        }
        self
    }
    pub fn swap(mut self, a: u32, b: u32) -> Self {
        if (a as usize) < self.0.len() && (b as usize) < self.0.len() {
            self.0.swap(a as usize, b as usize);
        }
        self
    }
    pub fn push(mut self, value: T) -> Self {
        assert!(self.len() < u32::MAX, "buffer length exhausted");
        self.0.push(value);
        self
    }
    pub fn pop(mut self) -> Self {
        self.0.pop();
        self
    }
    pub fn truncate(mut self, n: u32) -> Self {
        self.0.truncate(n as usize);
        self
    }
    pub fn split(mut self, at: u32) -> (Self, Self) {
        let right = self.0.split_off((at as usize).min(self.0.len()));
        (self, Self(right))
    }
    pub fn append(mut self, mut other: Self) -> Self {
        self.0.append(&mut other.0);
        self
    }
    pub fn freeze(self) -> Vec<T> {
        self.0
    }
}
// Exact dense scalar scratch with bounded per-thread allocation reuse. Keys
// outside the dense domain migrate all live entries into the ordered fallback.
const INK_DENSE_LIMIT: usize = 4096;
const INK_SCRATCH_RETAIN: usize = 2048;
const INK_SCRATCH_POOL_LIMIT: usize = 8;
std::thread_local! {static INK_MAP_POOL:std::cell::RefCell<Vec<Box<dyn std::any::Any>>>=const{std::cell::RefCell::new(Vec::new())};}
#[derive(Clone, Debug)]
struct InkSlot<K,V> { epoch:u64, value:Option<(K,V)> }
#[derive(Clone, Debug)]
struct InkDense<K,V> { epoch:u64, length:usize, slots:Vec<InkSlot<K,V>> }
impl<K:'static,V:'static> InkDense<K,V> {
    fn fresh()->Self {
        let old=INK_MAP_POOL.with(|pool| {let mut pool=pool.borrow_mut();let at=pool.iter().position(|p|p.as_ref().is::<Self>());at.map(|i|*pool.swap_remove(i).downcast::<Self>().unwrap())});
        let mut scratch=old.unwrap_or(Self{epoch:0,length:0,slots:vec![]});
        if scratch.epoch==u64::MAX {for slot in &mut scratch.slots {slot.epoch=0;slot.value=None;}scratch.epoch=1;}
        else {scratch.epoch+=1;}
        scratch.length=0;scratch
    }
}
fn ink_dense_index<K:'static>(key:&K)->Option<usize> {
    let any=key as &dyn std::any::Any;
    let index=if let Some(&x)=any.downcast_ref::<u32>() {x as u64}
        else if let Some(&x)=any.downcast_ref::<u64>() {x}
        else if let Some(&x)=any.downcast_ref::<i32>() {u64::try_from(x).ok()?}
        else if let Some(&x)=any.downcast_ref::<bool>() {u64::from(x)} else {return None};
    if index<INK_DENSE_LIMIT as u64 {Some(index as usize)}else{None}
}
fn ink_scalar<T:'static>()->bool {
    let id=std::any::TypeId::of::<T>();[std::any::TypeId::of::<u32>(),std::any::TypeId::of::<u64>(),std::any::TypeId::of::<i32>(),std::any::TypeId::of::<bool>()].contains(&id)
}
#[derive(Clone, Debug)]
enum InkMapStorage<K:Ord,V> { Sparse(std::collections::BTreeMap<K,V>), Dense(InkDense<K,V>) }
#[derive(Clone, Debug)]
pub struct OwnedMap<K:Ord+'static,V:'static>(InkMapStorage<K,V>);
impl<K:Ord+Clone+'static,V:Clone+'static> OwnedMap<K,V> {
    pub fn new()->Self {
        if ink_scalar::<K>()&&ink_scalar::<V>() {Self(InkMapStorage::Dense(InkDense::fresh()))}
        else {Self::new_sparse()}
    }
    pub fn new_sparse()->Self {Self(InkMapStorage::Sparse(std::collections::BTreeMap::new()))}
    fn entries(&self)->Box<dyn Iterator<Item=(&K,&V)>+'_> {
        match &self.0 {
            InkMapStorage::Sparse(map)=>Box::new(map.iter()),
            InkMapStorage::Dense(s)=>Box::new(s.slots.iter().filter(move|x|x.epoch==s.epoch).filter_map(|x|x.value.as_ref().map(|(k,v)|(k,v)))),
        }
    }
    pub fn len(&self)->u32 {match &self.0 {InkMapStorage::Sparse(map)=>map.len(),InkMapStorage::Dense(s)=>s.length}.try_into().expect("map exceeds u32")}
    pub fn get(&self,key:&K)->Option<V> {
        match &self.0 {
            InkMapStorage::Sparse(map)=>map.get(key).cloned(),
            InkMapStorage::Dense(s)=>ink_dense_index(key).and_then(|i|s.slots.get(i)).filter(|x|x.epoch==s.epoch).and_then(|x|x.value.as_ref().map(|(_,v)|v.clone())),
        }
    }
    pub fn contains(&self,key:&K)->bool {self.get(key).is_some()}
    pub fn set(mut self,key:K,value:V)->Self {
        if let InkMapStorage::Dense(s)=&mut self.0 {
            if let Some(index)=ink_dense_index(&key).filter(|&i|i<=s.slots.len().saturating_mul(8)+64) {
                s.slots.resize_with(s.slots.len().max(index+1),||InkSlot{epoch:0,value:None});
                let slot=&mut s.slots[index];if slot.epoch!=s.epoch||slot.value.is_none(){s.length+=1;}
                slot.value=Some((key,value));slot.epoch=s.epoch;return self;
            }
            let mut ordered=std::collections::BTreeMap::new();
            for slot in &mut s.slots {if slot.epoch==s.epoch {if let Some((k,v))=slot.value.take(){ordered.insert(k,v);}}}
            ordered.insert(key,value);
            let old=std::mem::replace(&mut self.0,InkMapStorage::Sparse(ordered));
            if let InkMapStorage::Dense(s)=old {ink_recycle(s);}
        } else if let InkMapStorage::Sparse(map)=&mut self.0 {map.insert(key,value);}
        self
    }
    pub fn remove(mut self,key:&K)->Self {
        match &mut self.0 {
            InkMapStorage::Sparse(map)=>{map.remove(key);},
            InkMapStorage::Dense(s)=>{if let Some(slot)=ink_dense_index(key).and_then(|i|s.slots.get_mut(i)){if slot.epoch==s.epoch&&slot.value.take().is_some(){s.length-=1;slot.epoch=0;}}},
        }self
    }
    pub fn keys(&self)->Vec<K>{self.entries().map(|(k,_)|k.clone()).collect()}
    pub fn values(&self)->Vec<V>{self.entries().map(|(_,v)|v.clone()).collect()}
}
fn ink_recycle<K:'static,V:'static>(scratch:InkDense<K,V>) {
    if scratch.slots.capacity()<=INK_SCRATCH_RETAIN {INK_MAP_POOL.with(|pool|{let mut pool=pool.borrow_mut();if pool.len()<INK_SCRATCH_POOL_LIMIT {pool.push(Box::new(scratch));}});}
}
impl<K:Ord+'static,V:'static> Drop for OwnedMap<K,V> {
    fn drop(&mut self) {if matches!(self.0,InkMapStorage::Dense(_)){if let InkMapStorage::Dense(s)=std::mem::replace(&mut self.0,InkMapStorage::Sparse(std::collections::BTreeMap::new())){ink_recycle(s);}}}
}
impl<K:Ord+Clone+'static,V:Clone+PartialEq+'static> PartialEq for OwnedMap<K,V>{fn eq(&self,other:&Self)->bool{self.entries().eq(other.entries())}}
impl<K:Ord+Clone+'static,V:Clone+Eq+'static> Eq for OwnedMap<K,V>{}
impl<K:Ord+Clone+'static,V:Clone+Ord+'static> Ord for OwnedMap<K,V>{fn cmp(&self,other:&Self)->std::cmp::Ordering{self.entries().cmp(other.entries())}}
impl<K:Ord+Clone+'static,V:Clone+PartialOrd+'static> PartialOrd for OwnedMap<K,V>{fn partial_cmp(&self,other:&Self)->Option<std::cmp::Ordering>{self.entries().partial_cmp(other.entries())}}

// Bounded fork/join execution. Each worker owns a disjoint mutable slice;
// joining retains source order. Nested parallel requests execute sequentially.
std::thread_local! {static INK_PARALLEL_DEPTH:std::cell::Cell<u32>=const{std::cell::Cell::new(0)};}
struct InkParallelGuard(u32);
impl InkParallelGuard {
    fn enter() -> Self {
        Self(INK_PARALLEL_DEPTH.with(|d| {
            let old = d.get();
            d.set(old + 1);
            old
        }))
    }
}
impl Drop for InkParallelGuard {
    fn drop(&mut self) {
        INK_PARALLEL_DEPTH.with(|d| d.set(self.0));
    }
}
fn ink_parallel_workers(len: usize, grain: u32) -> usize {
    if cfg!(target_arch = "wasm32") {
        return 1;
    }
    if INK_PARALLEL_DEPTH.with(|d| d.get() > 0) {
        return 1;
    }
    let available = std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1);
    let requested = std::env::var("INK_THREADS")
        .ok()
        .and_then(|s| s.parse::<usize>().ok())
        .unwrap_or(available)
        .clamp(1, 32);
    requested.min(len / (grain.max(1) as usize)).max(1)
}
pub fn ink_parallel_map<T: Clone + Sync, U: Send, F: Fn(u32, T) -> U + Sync>(
    xs: Vec<T>,
    grain: u32,
    f: F,
) -> Vec<U> {
    let workers = ink_parallel_workers(xs.len(), grain);
    let _guard = InkParallelGuard::enter();
    if workers == 1 {
        return xs
            .into_iter()
            .enumerate()
            .map(|(i, x)| f(i as u32, x))
            .collect();
    }
    let chunk = (xs.len() + workers - 1) / workers;
    std::thread::scope(|scope| {
        let handles = xs
            .chunks(chunk)
            .enumerate()
            .map(|(part, slice)| {
                let f = &f;
                scope.spawn(move || {
                    let _guard = InkParallelGuard::enter();
                    slice
                        .iter()
                        .cloned()
                        .enumerate()
                        .map(|(i, x)| f((part * chunk + i) as u32, x))
                        .collect::<Vec<U>>()
                })
            })
            .collect::<Vec<_>>();
        let mut output = Vec::with_capacity(xs.len());
        for handle in handles {
            output.extend(handle.join().expect("parallel worker failed"));
        }
        output
    })
}
pub fn ink_parallel_update<T: Clone + Send, F: Fn(u32, T) -> T + Sync>(
    mut xs: Vec<T>,
    grain: u32,
    f: F,
) -> Vec<T> {
    let workers = ink_parallel_workers(xs.len(), grain);
    let _guard = InkParallelGuard::enter();
    if workers == 1 {
        for (i, x) in xs.iter_mut().enumerate() {
            *x = f(i as u32, x.clone());
        }
        return xs;
    }
    let chunk = (xs.len() + workers - 1) / workers;
    std::thread::scope(|scope| {
        for (part, slice) in xs.chunks_mut(chunk).enumerate() {
            let f = &f;
            scope.spawn(move || {
                let _guard = InkParallelGuard::enter();
                for (i, x) in slice.iter_mut().enumerate() {
                    *x = f((part * chunk + i) as u32, x.clone());
                }
            });
        }
    });
    xs
}

}
use temporary::{OwnedBuffer,OwnedMap,ink_parallel_map,ink_parallel_update};

impl<T:Clone> Wire for OwnedBuffer<T>{fn from_json(_: &Json)->Result<Self,String>{Err("temporary storage is internal to a pure invocation".into())}fn to_json(&self)->Json{Json::Null}}
impl<K:Ord+Clone+'static,V:Clone+'static> Wire for OwnedMap<K,V>{fn from_json(_: &Json)->Result<Self,String>{Err("temporary storage is internal to a pure invocation".into())}fn to_json(&self)->Json{Json::Null}}
impl<T:Clone> InkDataEq for OwnedBuffer<T>{fn ink_data_eq(&self,_:&Self)->bool{panic!("temporary storage has no value equality")}}
impl<K:Ord+Clone+'static,V:Clone+'static> InkDataEq for OwnedMap<K,V>{fn ink_data_eq(&self,_:&Self)->bool{panic!("temporary storage has no value equality")}}

mod transaction {
//! Fixed transaction primitives, shared verbatim with generated execution.
//! These describe the base protocol; they select no optimisation or layout.

pub const SEMANTICS: &str = "ink-change-boundary-v1";

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Decision {
    Rollback,
    Commit { version: u64 },
    Exhausted,
}

/// A domain error wins over commit exhaustion. The body has already run;
/// both Rollback and Exhausted require restoration of its tentative effects.
#[inline]
pub fn decide(version: u64, succeeded: bool) -> Decision {
    if !succeeded {
        Decision::Rollback
    } else if let Some(version) = version.checked_add(1) {
        Decision::Commit { version }
    } else {
        Decision::Exhausted
    }
}

/// A nested change's error cannot be captured or ignored by its caller.
/// The outer Err exits the caller; the inner Result is its ordinary value.
#[inline]
pub fn nested_change<T, E>(result: Result<T, E>) -> Result<Result<T, E>, E> {
    match result {
        value @ Ok(_) => Ok(value),
        Err(error) => Err(error),
    }
}

#[derive(Debug, PartialEq, Eq)]
pub struct Publication<T> {
    pub commit: u64,
    pub position: u64,
    pub value: T,
}

/// Preserve staged order and number the committed suffix from zero, regardless
/// of earlier outbox contents. Publication neither clones nor reorders payloads.
pub fn publish<T>(
    version: u64,
    staged: impl Iterator<Item = T>,
) -> impl Iterator<Item = Publication<T>> {
    staged
        .enumerate()
        .map(move |(position, value)| Publication {
            commit: version,
            position: position as u64,
            value,
        })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn domain_errors_precede_exhaustion_and_success_never_wraps() {
        for version in [0, 1, 1 << 63, u64::MAX - 1, u64::MAX] {
            assert_eq!(decide(version, false), Decision::Rollback);
            assert_eq!(
                decide(version, true),
                match version.checked_add(1) {
                    Some(version) => Decision::Commit { version },
                    None => Decision::Exhausted,
                }
            );
        }
    }

    #[test]
    fn nested_result_and_ordered_publication_move_payloads() {
        struct Owned(&'static str);
        assert!(nested_change::<Owned, _>(Err(Owned("error"))).is_err());
        let value = nested_change::<_, Owned>(Ok(Owned("value")))
            .ok()
            .unwrap()
            .ok()
            .unwrap();
        let events: Vec<_> = publish(u64::MAX, [value, Owned("second")].into_iter()).collect();
        assert_eq!(events[0].commit, u64::MAX);
        assert_eq!(events[0].position, 0);
        assert_eq!(events[0].value.0, "value");
        assert_eq!(events[1].position, 1);
        assert_eq!(events[1].value.0, "second");
        assert_eq!(publish::<Owned>(2, std::iter::empty()).count(), 0);
    }
}

}

mod portable {
//! Shared, representation-independent snapshot codec. This module also ships
//! verbatim in generated applications; it has no AST/evaluator dependency.
use num_bigint::{BigInt, Sign};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::cmp::Ordering;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Schema {
    Unit,
    Bool,
    U32,
    U64,
    I32,
    F32,
    Vector(Box<Schema>, u8),
    Int,
    String,
    Id,
    Record(Vec<(String, Schema)>),
    Enum(Vec<String>),
    List(Box<Schema>),
    Option(Box<Schema>),
    Result(Box<Schema>, Box<Schema>),
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Layout {
    pub program: [u8; 32],
    pub schema: [u8; 32],
    pub roots: Vec<(String, Schema, Schema)>,
    pub events: Vec<(String, Schema)>,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Event {
    pub commit: u64,
    pub position: u64,
    pub channel: usize,
    pub value: Value,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Logical {
    pub version: u64,
    pub tables: Vec<Vec<(Value, Value)>>,
    pub outbox: Vec<Event>,
}
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub bytes: usize,
    pub values: usize,
    pub depth: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            bytes: 64 * 1024 * 1024,
            values: 1_000_000,
            depth: 128,
        }
    }
}
/// Magnitude bound for one exact integer. Decimal conversion is superlinear,
/// so without it a single large Int in a snapshot takes minutes to hours.
pub const MAX_INT_BYTES: usize = 4096;
const MAGIC: &[u8; 8] = b"VLSTATE\0";
const HEADER: usize = 8 + 2 + 2 + 32 + 32 + 8;
type R<T> = Result<T, String>;
fn u64_bytes(out: &mut Vec<u8>, v: u64) {
    out.extend_from_slice(&v.to_le_bytes());
}
fn count(out: &mut Vec<u8>, n: usize) {
    u64_bytes(out, n as u64);
}
fn raw(out: &mut Vec<u8>, b: &[u8]) {
    count(out, b.len());
    out.extend_from_slice(b);
}
fn tag<'a>(v: &'a Value, name: &str) -> R<&'a Value> {
    let o = v.as_object().ok_or("expected tagged object")?;
    if o.len() != 1 {
        return Err("expected exactly one tag".into());
    }
    o.get(name).ok_or("unexpected value tag".into())
}
fn integer(v: &Value) -> R<BigInt> {
    let s = tag(v, "Int")?.as_str().ok_or("expected Int string")?;
    // Every Int within the bound has fewer than 2.41 decimal digits per byte.
    if s.len() > MAX_INT_BYTES * 5 / 2 + 1 {
        return Err("snapshot Int exceeds size limit".into());
    }
    let n = s.parse::<BigInt>().map_err(|_| "invalid Int")?;
    if n.bits() > 8 * MAX_INT_BYTES as u64 {
        return Err("snapshot Int exceeds size limit".into());
    }
    if n.to_string() != s {
        return Err("noncanonical Int".into());
    }
    Ok(n)
}
fn identifier(v: &Value) -> R<u128> {
    let s = v.as_str().ok_or("expected ID")?;
    if s.len() != 32
        || !s
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err("noncanonical ID".into());
    }
    u128::from_str_radix(s, 16).map_err(|e| e.to_string())
}
fn compare(t: &Schema, a: &Value, b: &Value) -> R<Ordering> {
    Ok(match t {
        Schema::I32 => a
            .as_i64()
            .and_then(|n| i32::try_from(n).ok())
            .ok_or("invalid i32 key")?
            .cmp(
                &b.as_i64()
                    .and_then(|n| i32::try_from(n).ok())
                    .ok_or("invalid i32 key")?,
            ),
        Schema::U32 | Schema::U64 => a
            .as_u64()
            .ok_or("invalid key")?
            .cmp(&b.as_u64().ok_or("invalid key")?),
        Schema::String => a
            .as_str()
            .ok_or("invalid key")?
            .as_bytes()
            .cmp(b.as_str().ok_or("invalid key")?.as_bytes()),
        Schema::Id => identifier(a)?.cmp(&identifier(b)?),
        _ => return Err("unsupported snapshot key schema".into()),
    })
}
fn tick(left: &mut usize, depth: usize, limits: Limits) -> R<()> {
    if *left == 0 || depth > limits.depth {
        return Err("snapshot value/depth limit exceeded".into());
    }
    *left -= 1;
    Ok(())
}
fn encode_value(
    t: &Schema,
    v: &Value,
    out: &mut Vec<u8>,
    left: &mut usize,
    depth: usize,
    limits: Limits,
) -> R<()> {
    tick(left, depth, limits)?;
    match t {
        Schema::Unit => {
            if !v.is_null() {
                return Err("expected Unit".into());
            }
        }
        Schema::Bool => out.push(v.as_bool().ok_or("expected Bool")? as u8),
        Schema::U32 => out.extend_from_slice(
            &u32::try_from(v.as_u64().ok_or("expected u32")?)
                .map_err(|_| "u32 overflow")?
                .to_le_bytes(),
        ),
        Schema::U64 => u64_bytes(out, v.as_u64().ok_or("expected u64")?),
        Schema::I32 => out.extend_from_slice(
            &i32::try_from(v.as_i64().ok_or("expected i32")?)
                .map_err(|_| "i32 overflow")?
                .to_le_bytes(),
        ),
        Schema::F32 => {
            let bits = if let Some(b) = v.get("F32Bits") {
                if v.as_object().is_none_or(|o| o.len() != 1) {
                    return Err("expected only F32Bits field".into());
                }
                u32::try_from(b.as_u64().ok_or("expected f32 bits")?)
                    .map_err(|_| "f32 bits overflow")?
            } else {
                let f = v.as_f64().ok_or("expected f32")? as f32;
                if !f.is_finite() {
                    return Err("finite f32 or F32Bits required".into());
                }
                f.to_bits()
            };
            out.extend_from_slice(&bits.to_le_bytes());
        }
        Schema::Vector(inner, n) => {
            if !(2..=4).contains(n)
                || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
            {
                return Err("invalid vector schema".into());
            }
            let xs = v.as_array().ok_or("expected vector")?;
            if xs.len() != *n as usize {
                return Err("vector dimension mismatch".into());
            }
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Int => {
            let n = integer(v)?;
            let (sign, b) = n.to_bytes_le();
            out.push(match sign {
                Sign::NoSign => 0,
                Sign::Plus => 1,
                Sign::Minus => 2,
            });
            if sign == Sign::NoSign {
                raw(out, &[])
            } else {
                raw(out, &b)
            }
        }
        Schema::String => raw(out, v.as_str().ok_or("expected String")?.as_bytes()),
        Schema::Id => out.extend_from_slice(&identifier(v)?.to_le_bytes()),
        Schema::Enum(names) => {
            let s = v.as_str().ok_or("expected enum string")?;
            let index = names
                .iter()
                .position(|n| n == s)
                .ok_or("unknown enum variant")?;
            out.extend_from_slice(&(index as u32).to_le_bytes());
        }
        Schema::Record(fields) => {
            let obj = v.as_object().ok_or("expected record")?;
            if obj.len() != fields.len() {
                return Err("record field mismatch".into());
            }
            for (n, t) in fields {
                encode_value(
                    t,
                    obj.get(n).ok_or("missing record field")?,
                    out,
                    left,
                    depth + 1,
                    limits,
                )?;
            }
        }
        Schema::List(inner) => {
            let xs = v.as_array().ok_or("expected List")?;
            if xs.len() > *left {
                return Err("snapshot value limit exceeded".into());
            }
            count(out, xs.len());
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Option(inner) => {
            if let Ok(x) = tag(v, "Some") {
                out.push(1);
                encode_value(inner, x, out, left, depth + 1, limits)?;
            } else {
                if !tag(v, "None")?.is_null() {
                    return Err("invalid None".into());
                }
                out.push(0);
            }
        }
        Schema::Result(a, b) => {
            if let Ok(x) = tag(v, "Ok") {
                out.push(0);
                encode_value(a, x, out, left, depth + 1, limits)?;
            } else {
                out.push(1);
                encode_value(b, tag(v, "Err")?, out, left, depth + 1, limits)?;
            }
        }
    }
    if out.len() > limits.bytes {
        return Err("snapshot byte limit exceeded".into());
    }
    Ok(())
}
struct Reader<'a> {
    bytes: &'a [u8],
    at: usize,
    left: usize,
    limits: Limits,
}
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> R<&'a [u8]> {
        let end = self.at.checked_add(n).ok_or("snapshot length overflow")?;
        let b = self.bytes.get(self.at..end).ok_or("truncated snapshot")?;
        self.at = end;
        Ok(b)
    }
    fn byte(&mut self) -> R<u8> {
        Ok(self.take(1)?[0])
    }
    fn u32(&mut self) -> R<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn u64(&mut self) -> R<u64> {
        Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
    fn len(&mut self) -> R<usize> {
        usize::try_from(self.u64()?).map_err(|_| "snapshot length not addressable".into())
    }
    fn sequence(&mut self) -> R<usize> {
        let n = self.len()?;
        if n > self.left {
            return Err("snapshot value limit exceeded".into());
        }
        Ok(n)
    }
    fn raw(&mut self) -> R<&'a [u8]> {
        let n = self.len()?;
        self.take(n)
    }
    fn value(&mut self, t: &Schema, depth: usize) -> R<Value> {
        tick(&mut self.left, depth, self.limits)?;
        Ok(match t {
            Schema::Unit => Value::Null,
            Schema::Bool => match self.byte()? {
                0 => json!(false),
                1 => json!(true),
                _ => return Err("invalid Bool tag".into()),
            },
            Schema::U32 => json!(self.u32()?),
            Schema::U64 => json!(self.u64()?),
            Schema::I32 => json!(self.u32()? as i32),
            Schema::F32 => {
                let bits = self.u32()?;
                let f = f32::from_bits(bits);
                if f.is_finite() {
                    json!(f)
                } else {
                    json!({"F32Bits":bits})
                }
            }
            Schema::Vector(inner, n) => {
                if !(2..=4).contains(n)
                    || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
                {
                    return Err("invalid vector schema".into());
                }
                (0..*n)
                    .map(|_| self.value(inner, depth + 1))
                    .collect::<R<Vec<_>>>()?
                    .into()
            }
            Schema::Int => {
                let sign = self.byte()?;
                let bytes = self.raw()?;
                if bytes.len() > MAX_INT_BYTES {
                    return Err("snapshot Int exceeds size limit".into());
                }
                let sign = match sign {
                    0 if bytes.is_empty() => Sign::NoSign,
                    1 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Plus,
                    2 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Minus,
                    _ => return Err("noncanonical signed integer".into()),
                };
                json!({"Int":BigInt::from_bytes_le(sign,bytes).to_string()})
            }
            Schema::String => json!(std::str::from_utf8(self.raw()?).map_err(|_| "invalid UTF-8")?),
            Schema::Id => json!(format!(
                "{:032x}",
                u128::from_le_bytes(self.take(16)?.try_into().unwrap())
            )),
            Schema::Enum(names) => {
                json!(names.get(self.u32()? as usize).ok_or("invalid enum tag")?)
            }
            Schema::Record(fields) => {
                let mut obj = serde_json::Map::new();
                for (n, t) in fields {
                    obj.insert(n.clone(), self.value(t, depth + 1)?);
                }
                Value::Object(obj)
            }
            Schema::List(t) => {
                let n = self.sequence()?;
                let mut xs = Vec::new();
                for _ in 0..n {
                    xs.push(self.value(t, depth + 1)?);
                }
                Value::Array(xs)
            }
            Schema::Option(t) => match self.byte()? {
                0 => json!({"None":null}),
                1 => json!({"Some":self.value(t,depth+1)?}),
                _ => return Err("invalid Option tag".into()),
            },
            Schema::Result(a, b) => match self.byte()? {
                0 => json!({"Ok":self.value(a,depth+1)?}),
                1 => json!({"Err":self.value(b,depth+1)?}),
                _ => return Err("invalid Result tag".into()),
            },
        })
    }
}
fn event_order(e: &Event, version: u64, prior: Option<(u64, u64)>) -> R<()> {
    if e.commit == 0 || e.commit > version || prior.is_some_and(|p| p >= (e.commit, e.position)) {
        return Err("invalid snapshot event sequence".into());
    }
    Ok(())
}
pub fn encode(layout: &Layout, s: &Logical, limits: Limits) -> R<Vec<u8>> {
    if s.tables.len() != layout.roots.len() {
        return Err("snapshot root count mismatch".into());
    }
    let mut out = Vec::new();
    let mut left = limits.values;
    u64_bytes(&mut out, s.version);
    for (rows, (_, kt, vt)) in s.tables.iter().zip(&layout.roots) {
        if rows.len() > left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        count(&mut out, rows.len());
        let mut prior = None;
        for (k, v) in rows {
            if let Some(p) = prior {
                if compare(kt, p, k)? != Ordering::Less {
                    return Err("snapshot keys must be strictly ordered".into());
                }
            }
            encode_value(kt, k, &mut out, &mut left, 0, limits)?;
            encode_value(vt, v, &mut out, &mut left, 0, limits)?;
            prior = Some(k);
        }
    }
    count(&mut out, s.outbox.len());
    let mut prior = None;
    for e in &s.outbox {
        event_order(e, s.version, prior)?;
        let (_, t) = layout
            .events
            .get(e.channel)
            .ok_or("unknown event channel")?;
        u64_bytes(&mut out, e.commit);
        u64_bytes(&mut out, e.position);
        out.extend_from_slice(&(e.channel as u32).to_le_bytes());
        encode_value(t, &e.value, &mut out, &mut left, 0, limits)?;
        prior = Some((e.commit, e.position));
    }
    if HEADER
        .checked_add(out.len())
        .and_then(|n| n.checked_add(32))
        .is_none_or(|n| n > limits.bytes)
    {
        return Err("snapshot byte limit exceeded".into());
    }
    let mut bytes = Vec::new();
    bytes.extend_from_slice(MAGIC);
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&layout.program);
    bytes.extend_from_slice(&layout.schema);
    count(&mut bytes, out.len());
    bytes.extend_from_slice(&out);
    let digest = Sha256::digest(&bytes);
    bytes.extend_from_slice(&digest);
    Ok(bytes)
}
pub fn decode(layout: &Layout, bytes: &[u8], limits: Limits) -> R<Logical> {
    if bytes.len() > limits.bytes || bytes.len() < HEADER + 32 {
        return Err("snapshot byte length invalid".into());
    }
    if &bytes[..8] != MAGIC || bytes[8..12] != [1, 0, 1, 0] {
        return Err("snapshot format or semantics version mismatch".into());
    }
    if bytes[12..44] != layout.program || bytes[44..76] != layout.schema {
        return Err("snapshot program or schema identity mismatch".into());
    }
    let n = usize::try_from(u64::from_le_bytes(bytes[76..84].try_into().unwrap()))
        .map_err(|_| "snapshot length not addressable")?;
    if HEADER.checked_add(n).and_then(|v| v.checked_add(32)) != Some(bytes.len()) {
        return Err("snapshot payload length mismatch".into());
    }
    let end = bytes.len() - 32;
    if Sha256::digest(&bytes[..end]).as_slice() != &bytes[end..] {
        return Err("snapshot integrity check failed".into());
    }
    let mut r = Reader {
        bytes: &bytes[HEADER..end],
        at: 0,
        left: limits.values,
        limits,
    };
    let version = r.u64()?;
    let mut tables = vec![];
    for (_, kt, vt) in &layout.roots {
        let n = r.sequence()?;
        if n > r.left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        let mut rows: Vec<(Value, Value)> = vec![];
        for _ in 0..n {
            let k = r.value(kt, 0)?;
            let v = r.value(vt, 0)?;
            if let Some((prior, _)) = rows.last() {
                if compare(kt, prior, &k)? != Ordering::Less {
                    return Err("duplicate or unordered snapshot key".into());
                }
            }
            rows.push((k, v));
        }
        tables.push(rows);
    }
    let n = r.sequence()?;
    let mut outbox = vec![];
    let mut prior = None;
    for _ in 0..n {
        let commit = r.u64()?;
        let position = r.u64()?;
        let channel = r.u32()? as usize;
        let (_, t) = layout
            .events
            .get(channel)
            .ok_or("unknown snapshot event channel")?;
        let value = r.value(t, 0)?;
        let e = Event {
            commit,
            position,
            channel,
            value,
        };
        event_order(&e, version, prior)?;
        prior = Some((commit, position));
        outbox.push(e);
    }
    if r.at != r.bytes.len() {
        return Err("trailing snapshot payload".into());
    }
    Ok(Logical {
        version,
        tables,
        outbox,
    })
}

}
pub use portable::Limits as SnapshotLimits;
fn snapshot_layout()->portable::Layout{portable::Layout{program:[231, 175, 224, 55, 17, 26, 143, 201, 197, 170, 134, 72, 100, 51, 49, 96, 68, 237, 112, 126, 238, 148, 227, 124, 94, 216, 213, 117, 221, 236, 240, 200],schema:[27, 41, 215, 18, 112, 184, 218, 100, 92, 19, 149, 231, 187, 232, 226, 176, 54, 103, 167, 84, 223, 212, 4, 171, 143, 234, 59, 25, 27, 147, 199, 243],roots:vec![
],events:vec![]}}
#[derive(Clone,Debug,PartialEq,Eq)] pub struct l_Entry{pub l_node:u32,pub l_priority:u32}
impl Wire for l_Entry {fn to_json(&self)->Json{json!({
"node":self.l_node.to_json(),
"priority":self.l_priority.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_node:<u32 as Wire>::from_json(obj.get("node").unwrap())?,
l_priority:<u32 as Wire>::from_json(obj.get("priority").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq,Eq)] pub struct l_HeapWork{pub l_heap:OwnedBuffer<l_Entry>,pub l_index:u32,pub l_done:bool}
impl Wire for l_HeapWork {fn to_json(&self)->Json{json!({
"heap":self.l_heap.to_json(),
"index":self.l_index.to_json(),
"done":self.l_done.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_heap:<OwnedBuffer<l_Entry> as Wire>::from_json(obj.get("heap").unwrap())?,
l_index:<u32 as Wire>::from_json(obj.get("index").unwrap())?,
l_done:<bool as Wire>::from_json(obj.get("done").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq,Eq)] pub struct l_PathWork{pub l_parents:OwnedMap<u32,u32>,pub l_path:OwnedBuffer<u32>,pub l_node:u32,pub l_done:bool}
impl Wire for l_PathWork {fn to_json(&self)->Json{json!({
"parents":self.l_parents.to_json(),
"path":self.l_path.to_json(),
"node":self.l_node.to_json(),
"done":self.l_done.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_parents:<OwnedMap<u32,u32> as Wire>::from_json(obj.get("parents").unwrap())?,
l_path:<OwnedBuffer<u32> as Wire>::from_json(obj.get("path").unwrap())?,
l_node:<u32 as Wire>::from_json(obj.get("node").unwrap())?,
l_done:<bool as Wire>::from_json(obj.get("done").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq,Eq)] pub struct l_Route{pub l_found:bool,pub l_distance:u32,pub l_expanded:u32,pub l_limited:bool,pub l_path:Vec<u32>}
impl Wire for l_Route {fn to_json(&self)->Json{json!({
"found":self.l_found.to_json(),
"distance":self.l_distance.to_json(),
"expanded":self.l_expanded.to_json(),
"limited":self.l_limited.to_json(),
"path":self.l_path.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_found:<bool as Wire>::from_json(obj.get("found").unwrap())?,
l_distance:<u32 as Wire>::from_json(obj.get("distance").unwrap())?,
l_expanded:<u32 as Wire>::from_json(obj.get("expanded").unwrap())?,
l_limited:<bool as Wire>::from_json(obj.get("limited").unwrap())?,
l_path:<Vec<u32> as Wire>::from_json(obj.get("path").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq,Eq)] pub struct l_Search{pub l_grid:OwnedBuffer<u32>,pub l_queue:OwnedBuffer<l_Entry>,pub l_costs:OwnedMap<u32,u32>,pub l_closed:OwnedMap<u32,bool>,pub l_parents:OwnedMap<u32,u32>,pub l_width:u32,pub l_goal:u32,pub l_found:bool,pub l_distance:u32,pub l_expanded:u32}
impl Wire for l_Search {fn to_json(&self)->Json{json!({
"grid":self.l_grid.to_json(),
"queue":self.l_queue.to_json(),
"costs":self.l_costs.to_json(),
"closed":self.l_closed.to_json(),
"parents":self.l_parents.to_json(),
"width":self.l_width.to_json(),
"goal":self.l_goal.to_json(),
"found":self.l_found.to_json(),
"distance":self.l_distance.to_json(),
"expanded":self.l_expanded.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_grid:<OwnedBuffer<u32> as Wire>::from_json(obj.get("grid").unwrap())?,
l_queue:<OwnedBuffer<l_Entry> as Wire>::from_json(obj.get("queue").unwrap())?,
l_costs:<OwnedMap<u32,u32> as Wire>::from_json(obj.get("costs").unwrap())?,
l_closed:<OwnedMap<u32,bool> as Wire>::from_json(obj.get("closed").unwrap())?,
l_parents:<OwnedMap<u32,u32> as Wire>::from_json(obj.get("parents").unwrap())?,
l_width:<u32 as Wire>::from_json(obj.get("width").unwrap())?,
l_goal:<u32 as Wire>::from_json(obj.get("goal").unwrap())?,
l_found:<bool as Wire>::from_json(obj.get("found").unwrap())?,
l_distance:<u32 as Wire>::from_json(obj.get("distance").unwrap())?,
l_expanded:<u32 as Wire>::from_json(obj.get("expanded").unwrap())?,
})}}
#[derive(Clone,Debug,PartialEq,Eq)] pub struct l_SortWork{pub l_heap:OwnedBuffer<l_Entry>,pub l_output:OwnedBuffer<u32>}
impl Wire for l_SortWork {fn to_json(&self)->Json{json!({
"heap":self.l_heap.to_json(),
"output":self.l_output.to_json(),
})} fn from_json(v:&Json)->Result<Self,String>{let obj=v.as_object().unwrap();Ok(Self{
l_heap:<OwnedBuffer<l_Entry> as Wire>::from_json(obj.get("heap").unwrap())?,
l_output:<OwnedBuffer<u32> as Wire>::from_json(obj.get("output").unwrap())?,
})}}
impl InkDataEq for l_Entry {fn ink_data_eq(&self,other:&Self)->bool{self.l_node.ink_data_eq(&other.l_node)&&self.l_priority.ink_data_eq(&other.l_priority)}}
impl InkDataEq for l_HeapWork {fn ink_data_eq(&self,other:&Self)->bool{self.l_heap.ink_data_eq(&other.l_heap)&&self.l_index.ink_data_eq(&other.l_index)&&self.l_done.ink_data_eq(&other.l_done)}}
impl InkDataEq for l_PathWork {fn ink_data_eq(&self,other:&Self)->bool{self.l_parents.ink_data_eq(&other.l_parents)&&self.l_path.ink_data_eq(&other.l_path)&&self.l_node.ink_data_eq(&other.l_node)&&self.l_done.ink_data_eq(&other.l_done)}}
impl InkDataEq for l_Route {fn ink_data_eq(&self,other:&Self)->bool{self.l_found.ink_data_eq(&other.l_found)&&self.l_distance.ink_data_eq(&other.l_distance)&&self.l_expanded.ink_data_eq(&other.l_expanded)&&self.l_limited.ink_data_eq(&other.l_limited)&&self.l_path.ink_data_eq(&other.l_path)}}
impl InkDataEq for l_Search {fn ink_data_eq(&self,other:&Self)->bool{self.l_grid.ink_data_eq(&other.l_grid)&&self.l_queue.ink_data_eq(&other.l_queue)&&self.l_costs.ink_data_eq(&other.l_costs)&&self.l_closed.ink_data_eq(&other.l_closed)&&self.l_parents.ink_data_eq(&other.l_parents)&&self.l_width.ink_data_eq(&other.l_width)&&self.l_goal.ink_data_eq(&other.l_goal)&&self.l_found.ink_data_eq(&other.l_found)&&self.l_distance.ink_data_eq(&other.l_distance)&&self.l_expanded.ink_data_eq(&other.l_expanded)}}
impl InkDataEq for l_SortWork {fn ink_data_eq(&self,other:&Self)->bool{self.l_heap.ink_data_eq(&other.l_heap)&&self.l_output.ink_data_eq(&other.l_output)}}
#[derive(Clone,Debug)] pub enum EventData {
}
impl EventData {fn wire(&self)->(&'static str,Json){match *self {
}}}
enum Undo {
}
pub struct State {version:u64,staged:Vec<EventData>,outbox:Vec<Event>,undo:Vec<Undo>,
}
impl Default for State {fn default()->Self{Self::new()}}
impl State {pub fn new()->Self{Self{version:0,staged:vec![],outbox:vec![],undo:vec![],
}}
pub fn version(&self)->u64{self.version}
pub fn outbox(&self)->&[Event]{&self.outbox}
pub fn acknowledge_through(&mut self,commit:u64,position:u64){self.outbox.retain(|e|(e.commit,e.position)>(commit,position));}
pub fn checkpoint(&self)->Result<Vec<u8>,String>{self.checkpoint_with_limits(SnapshotLimits::default())}
pub fn checkpoint_with_limits(&self,limits:SnapshotLimits)->Result<Vec<u8>,String>{if !self.undo.is_empty()||!self.staged.is_empty(){return Err("checkpoint requires transaction boundary".into())}let layout=snapshot_layout();let tables=vec![];let outbox=self.outbox.iter().map(|e|{let(channel,value)=match e.data{};portable::Event{commit:e.commit,position:e.position,channel,value}}).collect();portable::encode(&layout,&portable::Logical{version:self.version,tables,outbox},limits)}
pub fn restore(bytes:&[u8])->Result<Self,String>{Self::restore_with_limits(bytes,SnapshotLimits::default())}
pub fn restore_with_limits(bytes:&[u8],limits:SnapshotLimits)->Result<Self,String>{let layout=snapshot_layout();let logical=portable::decode(&layout,bytes,limits)?;let mut state=Self::new();state.version=logical.version;let mut tables=logical.tables.into_iter();state.outbox=logical.outbox.into_iter().map(|e|{let data=match e.channel{_=>return Err("unknown event channel".into())};Ok(Event{commit:e.commit,position:e.position,data})}).collect::<Result<Vec<_>,String>>()?;Ok(state)}
fn rollback(&mut self){for undo in self.undo.drain(..).rev(){match undo{
}}self.staged.clear();}
pub fn function_l_entry_less(&self,l_a:l_Entry,l_b:l_Entry)->bool{(((((l_a.clone()).l_priority.clone()) < ((l_b.clone()).l_priority.clone()))) || ((((((l_a.clone()).l_priority.clone()) == ((l_b.clone()).l_priority.clone()))) && ((((l_a.clone()).l_node.clone()) < ((l_b.clone()).l_node.clone()))))))}
fn function_l_bubble(&self,l_s:l_HeapWork)->l_HeapWork{{let ink_local_2:u32={let ink_local_0=((l_s).l_index.clone()).wrapping_sub(1u32);let ink_local_1=2u32;if ink_local_1==0  {0u32} else {ink_local_0 / ink_local_1}};{let ink_local_5:l_Entry=((l_s).l_heap).get((l_s).l_index.clone()).unwrap_or_else(||{let ink_local_3=0u32;let ink_local_4=0u32;l_Entry{l_node:ink_local_3,l_priority:ink_local_4}});{let ink_local_8:l_Entry=((l_s).l_heap).get(ink_local_2.clone()).unwrap_or_else(||{let ink_local_6=0u32;let ink_local_7=0u32;l_Entry{l_node:ink_local_6,l_priority:ink_local_7}});if {let ink_local_9=ink_local_5.clone();let ink_local_10=ink_local_8.clone();self.function_l_entry_less(ink_local_9,ink_local_10)} {{let ink_local_11=((l_s).l_heap).swap((l_s).l_index.clone(),ink_local_2.clone());let ink_local_12=ink_local_2.clone();let ink_local_13=false;l_HeapWork{l_heap:ink_local_11,l_index:ink_local_12,l_done:ink_local_13}}} else {{let ink_local_14=(l_s).l_heap;let ink_local_15=(l_s).l_index.clone();let ink_local_16=true;l_HeapWork{l_heap:ink_local_14,l_index:ink_local_15,l_done:ink_local_16}}}}}}}
fn function_l_heap_push(&self,l_heap:OwnedBuffer<l_Entry>,l_entry:l_Entry)->OwnedBuffer<l_Entry>{{let ink_local_0:u32=(l_heap).len();{let ink_local_4:l_HeapWork={let ink_local_1=(l_heap).push(l_entry.clone());let ink_local_2=ink_local_0.clone();let ink_local_3=false;l_HeapWork{l_heap:ink_local_1,l_index:ink_local_2,l_done:ink_local_3}};{let ink_local_11:l_HeapWork={let ink_local_10=32u32;let mut ink_local_9=ink_local_4;for ink_local_6 in 0..ink_local_10 {let ink_local_5=&ink_local_9;if (((ink_local_5).l_done.clone()) || ((((ink_local_5).l_index.clone()) == (0u32)))) {break;}let ink_local_7=ink_local_9;ink_local_9={let ink_local_8=ink_local_7;self.function_l_bubble(ink_local_8)};}ink_local_9};(ink_local_11).l_heap}}}}
fn function_l_sink(&self,l_s:l_HeapWork)->l_HeapWork{{let ink_local_0:u32=((l_s).l_heap).len();{let ink_local_1:u32=(((l_s).l_index.clone()).wrapping_mul(2u32)).wrapping_add(1u32);{let ink_local_2:u32=(ink_local_1.clone()).wrapping_add(1u32);{let ink_local_5:l_Entry=((l_s).l_heap).get(ink_local_1.clone()).unwrap_or_else(||{let ink_local_3=0u32;let ink_local_4=4294967295u32;l_Entry{l_node:ink_local_3,l_priority:ink_local_4}});{let ink_local_8:l_Entry=((l_s).l_heap).get(ink_local_2.clone()).unwrap_or_else(||{let ink_local_6=0u32;let ink_local_7=4294967295u32;l_Entry{l_node:ink_local_6,l_priority:ink_local_7}});{let ink_local_11:u32=if ((((ink_local_2.clone()) < (ink_local_0.clone()))) && ({let ink_local_9=ink_local_8.clone();let ink_local_10=ink_local_5.clone();self.function_l_entry_less(ink_local_9,ink_local_10)})) {ink_local_2.clone()} else {ink_local_1.clone()};{let ink_local_14:l_Entry=((l_s).l_heap).get(ink_local_11.clone()).unwrap_or_else(||{let ink_local_12=0u32;let ink_local_13=4294967295u32;l_Entry{l_node:ink_local_12,l_priority:ink_local_13}});{let ink_local_17:l_Entry=((l_s).l_heap).get((l_s).l_index.clone()).unwrap_or_else(||{let ink_local_15=0u32;let ink_local_16=0u32;l_Entry{l_node:ink_local_15,l_priority:ink_local_16}});if ((((ink_local_11.clone()) < (ink_local_0.clone()))) && ({let ink_local_18=ink_local_14.clone();let ink_local_19=ink_local_17.clone();self.function_l_entry_less(ink_local_18,ink_local_19)})) {{let ink_local_20=((l_s).l_heap).swap((l_s).l_index.clone(),ink_local_11.clone());let ink_local_21=ink_local_11.clone();let ink_local_22=false;l_HeapWork{l_heap:ink_local_20,l_index:ink_local_21,l_done:ink_local_22}}} else {{let ink_local_23=(l_s).l_heap;let ink_local_24=(l_s).l_index.clone();let ink_local_25=true;l_HeapWork{l_heap:ink_local_23,l_index:ink_local_24,l_done:ink_local_25}}}}}}}}}}}}
fn function_l_heap_pop(&self,l_heap:OwnedBuffer<l_Entry>)->OwnedBuffer<l_Entry>{{let ink_local_0:u32=(l_heap).len();{let ink_local_3:l_Entry=(l_heap).get((ink_local_0.clone()).wrapping_sub(1u32)).unwrap_or_else(||{let ink_local_1=0u32;let ink_local_2=0u32;l_Entry{l_node:ink_local_1,l_priority:ink_local_2}});{let ink_local_7:l_HeapWork={let ink_local_4=((l_heap).set(0u32,ink_local_3.clone())).pop();let ink_local_5=0u32;let ink_local_6=false;l_HeapWork{l_heap:ink_local_4,l_index:ink_local_5,l_done:ink_local_6}};{let ink_local_14:l_HeapWork={let ink_local_13=32u32;let mut ink_local_12=ink_local_7;for ink_local_9 in 0..ink_local_13 {let ink_local_8=&ink_local_12;if (((ink_local_8).l_done.clone()) || (((((ink_local_8).l_heap).len()) == (0u32)))) {break;}let ink_local_10=ink_local_12;ink_local_12={let ink_local_11=ink_local_10;self.function_l_sink(ink_local_11)};}ink_local_12};(ink_local_14).l_heap}}}}}
fn function_l_heap_build(&self,l_xs:Vec<u32>)->OwnedBuffer<l_Entry>{{let ink_local_0:OwnedBuffer<l_Entry>=OwnedBuffer::new(vec![]);{let ink_local_11=(l_xs).len() as u32;let mut ink_local_10=ink_local_0;for ink_local_2 in 0..ink_local_11 {let ink_local_1=&ink_local_10;if false {break;}let ink_local_3=ink_local_10;ink_local_10={let ink_local_4=ink_local_3;let ink_local_9={let ink_local_5=ink_local_2.clone();let ink_local_8={let ink_local_6=&l_xs;let ink_local_7=ink_local_2.clone();match ink_local_6.get(ink_local_7 as usize){Some(v)=>v.clone(),None=>0u32}};l_Entry{l_node:ink_local_5,l_priority:ink_local_8}};self.function_l_heap_push(ink_local_4,ink_local_9)};}ink_local_10}}}
fn function_l_sort_step(&self,l_s:l_SortWork)->l_SortWork{{let ink_local_2:l_Entry=((l_s).l_heap).get(0u32).unwrap_or_else(||{let ink_local_0=0u32;let ink_local_1=0u32;l_Entry{l_node:ink_local_0,l_priority:ink_local_1}});{let ink_local_4={let ink_local_3=(l_s).l_heap;self.function_l_heap_pop(ink_local_3)};let ink_local_5=((l_s).l_output).push((ink_local_2.clone()).l_priority.clone());l_SortWork{l_heap:ink_local_4,l_output:ink_local_5}}}}
pub fn function_l_heap_sorted(&self,l_xs:Vec<u32>)->Vec<u32>{{let ink_local_3:l_SortWork={let ink_local_1={let ink_local_0=l_xs.clone();self.function_l_heap_build(ink_local_0)};let ink_local_2=OwnedBuffer::new(vec![]);l_SortWork{l_heap:ink_local_1,l_output:ink_local_2}};{let ink_local_10:l_SortWork={let ink_local_9=(l_xs).len() as u32;let mut ink_local_8=ink_local_3;for ink_local_5 in 0..ink_local_9 {let ink_local_4=&ink_local_8;if ((((ink_local_4).l_heap).len()) == (0u32)) {break;}let ink_local_6=ink_local_8;ink_local_8={let ink_local_7=ink_local_6;self.function_l_sort_step(ink_local_7)};}ink_local_8};((ink_local_10).l_output).freeze()}}}
pub fn function_l_difference(&self,l_a:u32,l_b:u32)->u32{if ((l_a.clone()) > (l_b.clone())) {(l_a.clone()).wrapping_sub(l_b.clone())} else {(l_b.clone()).wrapping_sub(l_a.clone())}}
pub fn function_l_heuristic(&self,l_node:u32,l_goal:u32,l_width:u32)->u32{({let ink_local_2={let ink_local_0=l_node.clone();let ink_local_1=l_width.clone();if ink_local_1==0  {0u32} else {ink_local_0 % ink_local_1}};let ink_local_5={let ink_local_3=l_goal.clone();let ink_local_4=l_width.clone();if ink_local_4==0  {0u32} else {ink_local_3 % ink_local_4}};self.function_l_difference(ink_local_2,ink_local_5)}).wrapping_add({let ink_local_8={let ink_local_6=l_node.clone();let ink_local_7=l_width.clone();if ink_local_7==0  {0u32} else {ink_local_6 / ink_local_7}};let ink_local_11={let ink_local_9=l_goal.clone();let ink_local_10=l_width.clone();if ink_local_10==0  {0u32} else {ink_local_9 / ink_local_10}};self.function_l_difference(ink_local_8,ink_local_11)})}
fn function_l_relax(&self,l_s:l_Search,l_from:u32,l_to:u32)->l_Search{{let ink_local_0:u32=(((l_s).l_costs).get(&l_from.clone()).unwrap_or_else(||0u32)).wrapping_add(1u32);{let ink_local_1:bool=((((((((l_s).l_grid).get(l_to.clone()).unwrap_or_else(||1u32)) == (0u32))) && (((((l_s).l_closed).contains(&l_to.clone())) == (false))))) && (((ink_local_0.clone()) < (((l_s).l_costs).get(&l_to.clone()).unwrap_or_else(||4294967295u32)))));if ink_local_1.clone() {{let ink_local_2=(l_s).l_grid;let ink_local_10={let ink_local_3=(l_s).l_queue;let ink_local_9={let ink_local_4=l_to.clone();let ink_local_8=(ink_local_0.clone()).wrapping_add({let ink_local_5=l_to.clone();let ink_local_6=(l_s).l_goal.clone();let ink_local_7=(l_s).l_width.clone();self.function_l_heuristic(ink_local_5,ink_local_6,ink_local_7)});l_Entry{l_node:ink_local_4,l_priority:ink_local_8}};self.function_l_heap_push(ink_local_3,ink_local_9)};let ink_local_11=((l_s).l_costs).set(l_to.clone(),ink_local_0.clone());let ink_local_12=(l_s).l_closed;let ink_local_13=((l_s).l_parents).set(l_to.clone(),l_from.clone());let ink_local_14=(l_s).l_width.clone();let ink_local_15=(l_s).l_goal.clone();let ink_local_16=(l_s).l_found.clone();let ink_local_17=(l_s).l_distance.clone();let ink_local_18=(l_s).l_expanded.clone();l_Search{l_grid:ink_local_2,l_queue:ink_local_10,l_costs:ink_local_11,l_closed:ink_local_12,l_parents:ink_local_13,l_width:ink_local_14,l_goal:ink_local_15,l_found:ink_local_16,l_distance:ink_local_17,l_expanded:ink_local_18}}} else {l_s}}}}
fn function_l_expand(&self,l_s:l_Search,l_node:u32)->l_Search{{let ink_local_0:u32=((l_s).l_grid).len();{let ink_local_3:u32={let ink_local_1=l_node.clone();let ink_local_2=(l_s).l_width.clone();if ink_local_2==0  {0u32} else {ink_local_1 % ink_local_2}};{let ink_local_4:u32=if ((ink_local_3.clone()) > (0u32)) {(l_node.clone()).wrapping_sub(1u32)} else {l_node.clone()};{let ink_local_5:u32=if (((((ink_local_3.clone()).wrapping_add(1u32)) < ((l_s).l_width.clone()))) && ((((l_node.clone()).wrapping_add(1u32)) < (ink_local_0.clone())))) {(l_node.clone()).wrapping_add(1u32)} else {l_node.clone()};{let ink_local_6:u32=if ((l_node.clone()) >= ((l_s).l_width.clone())) {(l_node.clone()).wrapping_sub((l_s).l_width.clone())} else {l_node.clone()};{let ink_local_7:u32=if (((l_node.clone()).wrapping_add((l_s).l_width.clone())) < (ink_local_0.clone())) {(l_node.clone()).wrapping_add((l_s).l_width.clone())} else {l_node.clone()};{let ink_local_18:l_Search={let ink_local_8=(l_s).l_grid;let ink_local_9=(l_s).l_queue;let ink_local_10=(l_s).l_costs;let ink_local_11=((l_s).l_closed).set(l_node.clone(),true);let ink_local_12=(l_s).l_parents;let ink_local_13=(l_s).l_width.clone();let ink_local_14=(l_s).l_goal.clone();let ink_local_15=false;let ink_local_16=0u32;let ink_local_17=((l_s).l_expanded.clone()).wrapping_add(1u32);l_Search{l_grid:ink_local_8,l_queue:ink_local_9,l_costs:ink_local_10,l_closed:ink_local_11,l_parents:ink_local_12,l_width:ink_local_13,l_goal:ink_local_14,l_found:ink_local_15,l_distance:ink_local_16,l_expanded:ink_local_17}};{let ink_local_22:l_Search={let ink_local_19=ink_local_18;let ink_local_20=l_node.clone();let ink_local_21=ink_local_4.clone();self.function_l_relax(ink_local_19,ink_local_20,ink_local_21)};{let ink_local_26:l_Search={let ink_local_23=ink_local_22;let ink_local_24=l_node.clone();let ink_local_25=ink_local_5.clone();self.function_l_relax(ink_local_23,ink_local_24,ink_local_25)};{let ink_local_30:l_Search={let ink_local_27=ink_local_26;let ink_local_28=l_node.clone();let ink_local_29=ink_local_6.clone();self.function_l_relax(ink_local_27,ink_local_28,ink_local_29)};{let ink_local_31=ink_local_30;let ink_local_32=l_node.clone();let ink_local_33=ink_local_7.clone();self.function_l_relax(ink_local_31,ink_local_32,ink_local_33)}}}}}}}}}}}}
fn function_l_search_step(&self,l_s:l_Search)->l_Search{{let ink_local_2:l_Entry=((l_s).l_queue).get(0u32).unwrap_or_else(||{let ink_local_0=0u32;let ink_local_1=0u32;l_Entry{l_node:ink_local_0,l_priority:ink_local_1}});{let ink_local_3:u32=(ink_local_2.clone()).l_node.clone();{let ink_local_4:bool=((l_s).l_closed).contains(&ink_local_3.clone());{let ink_local_5:u32=((l_s).l_costs).get(&ink_local_3.clone()).unwrap_or_else(||4294967295u32);{let ink_local_17:l_Search={let ink_local_6=(l_s).l_grid;let ink_local_8={let ink_local_7=(l_s).l_queue;self.function_l_heap_pop(ink_local_7)};let ink_local_9=(l_s).l_costs;let ink_local_10=(l_s).l_closed;let ink_local_11=(l_s).l_parents;let ink_local_12=(l_s).l_width.clone();let ink_local_13=(l_s).l_goal.clone();let ink_local_14=((ink_local_3.clone()) == ((l_s).l_goal.clone()));let ink_local_15=ink_local_5.clone();let ink_local_16=(l_s).l_expanded.clone();l_Search{l_grid:ink_local_6,l_queue:ink_local_8,l_costs:ink_local_9,l_closed:ink_local_10,l_parents:ink_local_11,l_width:ink_local_12,l_goal:ink_local_13,l_found:ink_local_14,l_distance:ink_local_15,l_expanded:ink_local_16}};if (((ink_local_17).l_found.clone()) || (ink_local_4.clone())) {ink_local_17} else {{let ink_local_18=ink_local_17;let ink_local_19=ink_local_3.clone();self.function_l_expand(ink_local_18,ink_local_19)}}}}}}}}
fn function_l_path_step(&self,l_s:l_PathWork,l_start:u32)->l_PathWork{{let ink_local_0:u32=((l_s).l_parents).get(&(l_s).l_node.clone()).unwrap_or_else(||l_start.clone());{let ink_local_1=(l_s).l_parents;let ink_local_2=((l_s).l_path).push((l_s).l_node.clone());let ink_local_3=ink_local_0.clone();let ink_local_4=(((l_s).l_node.clone()) == (l_start.clone()));l_PathWork{l_parents:ink_local_1,l_path:ink_local_2,l_node:ink_local_3,l_done:ink_local_4}}}}
fn function_l_reverse(&self,l_path:OwnedBuffer<u32>)->Vec<u32>{{let ink_local_0:u32=(l_path).len();{let ink_local_8:OwnedBuffer<u32>={let ink_local_7={let ink_local_1=ink_local_0.clone();let ink_local_2=2u32;if ink_local_2==0  {0u32} else {ink_local_1 / ink_local_2}};let mut ink_local_6=l_path;for ink_local_4 in 0..ink_local_7 {let ink_local_3=&ink_local_6;if false {break;}let ink_local_5=ink_local_6;ink_local_6=(ink_local_5).swap(ink_local_4.clone(),((ink_local_0.clone()).wrapping_sub(1u32)).wrapping_sub(ink_local_4.clone()));}ink_local_6};(ink_local_8).freeze()}}}
fn function_l_finish(&self,l_s:l_Search,l_start:u32)->l_Route{{let ink_local_0:bool=(((((l_s).l_found.clone()) == (false))) && (((((l_s).l_queue).len()) > (0u32))));{let ink_local_5:l_PathWork={let ink_local_1=(l_s).l_parents;let ink_local_2=OwnedBuffer::new(vec![]);let ink_local_3=(l_s).l_goal.clone();let ink_local_4=(((l_s).l_found.clone()) == (false));l_PathWork{l_parents:ink_local_1,l_path:ink_local_2,l_node:ink_local_3,l_done:ink_local_4}};{let ink_local_13:l_PathWork={let ink_local_12=((l_s).l_grid).len();let mut ink_local_11=ink_local_5;for ink_local_7 in 0..ink_local_12 {let ink_local_6=&ink_local_11;if (ink_local_6).l_done.clone() {break;}let ink_local_8=ink_local_11;ink_local_11={let ink_local_9=ink_local_8;let ink_local_10=l_start.clone();self.function_l_path_step(ink_local_9,ink_local_10)};}ink_local_11};{let ink_local_14=(l_s).l_found.clone();let ink_local_15=(l_s).l_distance.clone();let ink_local_16=(l_s).l_expanded.clone();let ink_local_17=ink_local_0.clone();let ink_local_19={let ink_local_18=(ink_local_13).l_path;self.function_l_reverse(ink_local_18)};l_Route{l_found:ink_local_14,l_distance:ink_local_15,l_expanded:ink_local_16,l_limited:ink_local_17,l_path:ink_local_19}}}}}}
pub fn function_l_astar(&self,l_grid:Vec<u32>,l_width:u32,l_start:u32,l_goal:u32,l_limit:u32)->l_Route{{let ink_local_6:bool=((((((((((((((l_width.clone()) > (0u32))) && ((((l_grid).len() as u32) > (0u32))))) && ((({let ink_local_0=(l_grid).len() as u32;let ink_local_1=l_width.clone();if ink_local_1==0  {1u32} else {ink_local_0 % ink_local_1}}) == (0u32))))) && (((l_start.clone()) < ((l_grid).len() as u32))))) && (((l_goal.clone()) < ((l_grid).len() as u32))))) && ((({let ink_local_2=&l_grid;let ink_local_3=l_start.clone();match ink_local_2.get(ink_local_3 as usize){Some(v)=>v.clone(),None=>1u32}}) == (0u32))))) && ((({let ink_local_4=&l_grid;let ink_local_5=l_goal.clone();match ink_local_4.get(ink_local_5 as usize){Some(v)=>v.clone(),None=>1u32}}) == (0u32))));if ink_local_6.clone() {{let ink_local_7=l_grid.clone();let ink_local_8=l_width.clone();let ink_local_9=l_start.clone();let ink_local_10=l_goal.clone();let ink_local_11=l_limit.clone();self.function_l_search(ink_local_7,ink_local_8,ink_local_9,ink_local_10,ink_local_11)}} else {{let ink_local_12=false;let ink_local_13=0u32;let ink_local_14=0u32;let ink_local_15=false;let ink_local_17=((l_grid).iter().cloned()).filter(|ink_ref|{let ink_local_16=ink_ref.clone();false}).collect::<Vec<_>>();l_Route{l_found:ink_local_12,l_distance:ink_local_13,l_expanded:ink_local_14,l_limited:ink_local_15,l_path:ink_local_17}}}}}
pub fn function_l_search(&self,l_grid:Vec<u32>,l_width:u32,l_start:u32,l_goal:u32,l_limit:u32)->l_Route{{let ink_local_0:OwnedMap<u32,u32>=OwnedMap::new_sparse();{let ink_local_1:OwnedBuffer<l_Entry>=OwnedBuffer::new(vec![]);{let ink_local_19:l_Search={let ink_local_2=OwnedBuffer::new(l_grid.clone());let ink_local_10={let ink_local_3=ink_local_1;let ink_local_9={let ink_local_4=l_start.clone();let ink_local_8={let ink_local_5=l_start.clone();let ink_local_6=l_goal.clone();let ink_local_7=l_width.clone();self.function_l_heuristic(ink_local_5,ink_local_6,ink_local_7)};l_Entry{l_node:ink_local_4,l_priority:ink_local_8}};self.function_l_heap_push(ink_local_3,ink_local_9)};let ink_local_11=(ink_local_0).set(l_start.clone(),0u32);let ink_local_12=OwnedMap::new_sparse();let ink_local_13=OwnedMap::new_sparse();let ink_local_14=l_width.clone();let ink_local_15=l_goal.clone();let ink_local_16=false;let ink_local_17=0u32;let ink_local_18=0u32;l_Search{l_grid:ink_local_2,l_queue:ink_local_10,l_costs:ink_local_11,l_closed:ink_local_12,l_parents:ink_local_13,l_width:ink_local_14,l_goal:ink_local_15,l_found:ink_local_16,l_distance:ink_local_17,l_expanded:ink_local_18}};{let ink_local_26:l_Search={let ink_local_25=l_limit.clone();let mut ink_local_24=ink_local_19;for ink_local_21 in 0..ink_local_25 {let ink_local_20=&ink_local_24;if (((ink_local_20).l_found.clone()) || (((((ink_local_20).l_queue).len()) == (0u32)))) {break;}let ink_local_22=ink_local_24;ink_local_24={let ink_local_23=ink_local_22;self.function_l_search_step(ink_local_23)};}ink_local_24};{let ink_local_27=ink_local_26;let ink_local_28=l_start.clone();self.function_l_finish(ink_local_27,ink_local_28)}}}}}}
fn action_l_route(&mut self,l_grid:Vec<u32>,l_width:u32,l_start:u32,l_goal:u32,l_limit:u32)->l_Route{return {let tmp_1:Vec<u32>=l_grid;let tmp_2:u32=l_width;let tmp_3:u32=l_start;let tmp_4:u32=l_goal;let tmp_5:u32=l_limit;self.function_l_astar(tmp_1,tmp_2,tmp_3,tmp_4,tmp_5)};
}
pub fn invoke_view_l_route(&mut self,l_grid:Vec<u32>,l_width:u32,l_start:u32,l_goal:u32,l_limit:u32)->Result<OutcomeView<'_,l_Route>,String>{let result=self.action_l_route(l_grid,l_width,l_start,l_goal,l_limit);
Ok(OutcomeView{result,committed:false,version:self.version,events:&[]})}
pub fn invoke_l_route(&mut self,l_grid:Vec<u32>,l_width:u32,l_start:u32,l_goal:u32,l_limit:u32)->Result<Outcome<l_Route>,String>{self.invoke_view_l_route(l_grid,l_width,l_start,l_goal,l_limit).map(OutcomeView::into_owned)}
pub fn call_json(&mut self,name:&str,args:&Json)->Result<Json,String>{let args=args.as_array().unwrap();match name{
"entry_less"=>{let a0=<l_Entry as Wire>::from_json(&args[0])?;let a1=<l_Entry as Wire>::from_json(&args[1])?;Ok(self.function_l_entry_less(a0,a1).to_json())},
"bubble"=>Err("temporary storage is internal to a pure invocation".into()),
"heap_push"=>Err("temporary storage is internal to a pure invocation".into()),
"sink"=>Err("temporary storage is internal to a pure invocation".into()),
"heap_pop"=>Err("temporary storage is internal to a pure invocation".into()),
"heap_build"=>Err("temporary storage is internal to a pure invocation".into()),
"sort_step"=>Err("temporary storage is internal to a pure invocation".into()),
"heap_sorted"=>{let a0=<Vec<u32> as Wire>::from_json(&args[0])?;Ok(self.function_l_heap_sorted(a0).to_json())},
"difference"=>{let a0=<u32 as Wire>::from_json(&args[0])?;let a1=<u32 as Wire>::from_json(&args[1])?;Ok(self.function_l_difference(a0,a1).to_json())},
"heuristic"=>{let a0=<u32 as Wire>::from_json(&args[0])?;let a1=<u32 as Wire>::from_json(&args[1])?;let a2=<u32 as Wire>::from_json(&args[2])?;Ok(self.function_l_heuristic(a0,a1,a2).to_json())},
"relax"=>Err("temporary storage is internal to a pure invocation".into()),
"expand"=>Err("temporary storage is internal to a pure invocation".into()),
"search_step"=>Err("temporary storage is internal to a pure invocation".into()),
"path_step"=>Err("temporary storage is internal to a pure invocation".into()),
"reverse"=>Err("temporary storage is internal to a pure invocation".into()),
"finish"=>Err("temporary storage is internal to a pure invocation".into()),
"astar"=>{let a0=<Vec<u32> as Wire>::from_json(&args[0])?;let a1=<u32 as Wire>::from_json(&args[1])?;let a2=<u32 as Wire>::from_json(&args[2])?;let a3=<u32 as Wire>::from_json(&args[3])?;let a4=<u32 as Wire>::from_json(&args[4])?;Ok(self.function_l_astar(a0,a1,a2,a3,a4).to_json())},
"search"=>{let a0=<Vec<u32> as Wire>::from_json(&args[0])?;let a1=<u32 as Wire>::from_json(&args[1])?;let a2=<u32 as Wire>::from_json(&args[2])?;let a3=<u32 as Wire>::from_json(&args[3])?;let a4=<u32 as Wire>::from_json(&args[4])?;Ok(self.function_l_search(a0,a1,a2,a3,a4).to_json())},
_=>Err("unknown function".into())}}
pub fn invoke_json(&mut self,name:&str,args:&Json)->Result<Json,String>{let args=args.as_array().unwrap();match name{
"route"=>{let a0=<Vec<u32> as Wire>::from_json(&args[0])?;let a1=<u32 as Wire>::from_json(&args[1])?;let a2=<u32 as Wire>::from_json(&args[2])?;let a3=<u32 as Wire>::from_json(&args[3])?;let a4=<u32 as Wire>::from_json(&args[4])?;Ok(self.invoke_view_l_route(a0,a1,a2,a3,a4)?.to_json())},
_=>Err("unknown action".into())}}}
// Appended verbatim to generated applications. This is a host ABI, not an optimiser.
mod state_wasm {
    use super::*;
    use std::cell::RefCell;
    const MAX_BUFFER: usize = 64 * 1024 * 1024;
    const MAX_TOTAL: usize = 128 * 1024 * 1024;
    const MAX_JSON: usize = 4 * 1024 * 1024;
    const MAX_BUFFERS: usize = 256;
    const MAX_STATES: usize = 128;
    struct Registry {
        next: u32,
        states: BTreeMap<u32, State>,
        buffers: BTreeMap<u32, Vec<u8>>,
        bytes: usize,
        error: String,
    }
    impl Registry {
        fn new() -> Self {
            Self {
                next: 0,
                states: BTreeMap::new(),
                buffers: BTreeMap::new(),
                bytes: 0,
                error: String::new(),
            }
        }
        fn id(&mut self) -> Result<u32, String> {
            self.next = self
                .next
                .checked_add(1)
                .ok_or("ABI handle sequence exhausted")?;
            Ok(self.next)
        }
        fn fail(&mut self, error: impl Into<String>) -> u32 {
            self.error = error.into();
            0
        }
        fn insert_buffer(&mut self, bytes: Vec<u8>) -> Result<u32, String> {
            if bytes.len() > MAX_BUFFER
                || self.buffers.len() >= MAX_BUFFERS
                || self
                    .bytes
                    .checked_add(bytes.len())
                    .is_none_or(|n| n > MAX_TOTAL)
            {
                return Err("ABI buffer limit".into());
            }
            let id = self.id()?;
            self.bytes += bytes.len();
            self.buffers.insert(id, bytes);
            Ok(id)
        }
        fn reserve_output(&mut self) -> Result<u32, String> {
            // Reserve an output slot and enough accounting space before a change.
            if self
                .bytes
                .checked_add(MAX_BUFFER)
                .is_none_or(|n| n > MAX_TOTAL)
            {
                return Err("ABI output capacity unavailable".into());
            }
            self.insert_buffer(Vec::new())
        }
        fn finish(&mut self, id: u32, bytes: Vec<u8>) -> u32 {
            self.bytes += bytes.len();
            *self.buffers.get_mut(&id).expect("reserved output slot") = bytes;
            id
        }
        fn envelope(&mut self, id: u32, result: Result<Json, String>, committed: bool) -> u32 {
            let payload = match result {
                Ok(value) => serde_json::json!({"ok":value}),
                Err(message) => {
                    serde_json::json!({"error":{"message":message,"committed":committed}})
                }
            };
            let mut bytes = serde_json::to_vec(&payload).expect("JSON value serialization");
            if bytes.len() > MAX_BUFFER {
                bytes=serde_json::to_vec(&serde_json::json!({"error":{"message":"ABI response exceeds 64 MiB","committed":committed}})).expect("JSON error serialization");
            }
            self.finish(id, bytes)
        }
    }
    thread_local! {static REGISTRY:RefCell<Registry>=RefCell::new(Registry::new());}
    
    pub extern "C" fn lang_abi_version() -> u32 {
        1
    }
    
    pub extern "C" fn lang_buffer_alloc(length: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            let length = length as usize;
            if length > MAX_BUFFER
                || r.buffers.len() >= MAX_BUFFERS
                || r.bytes.checked_add(length).is_none_or(|n| n > MAX_TOTAL)
            {
                return r.fail("ABI buffer limit");
            }
            match r.insert_buffer(vec![0; length]) {
                Ok(id) => id,
                Err(e) => r.fail(e),
            }
        })
    }
    
    pub extern "C" fn lang_buffer_ptr(handle: u32) -> usize {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            match r.buffers.get(&handle) {
                Some(bytes) => bytes.as_ptr() as usize,
                None => r.fail("unknown buffer handle") as usize,
            }
        })
    }
    
    pub extern "C" fn lang_buffer_len(handle: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            match r.buffers.get(&handle) {
                Some(bytes) => bytes.len() as u32,
                None => r.fail("unknown buffer handle"),
            }
        })
    }
    
    pub extern "C" fn lang_buffer_free(handle: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            match r.buffers.remove(&handle) {
                Some(bytes) => {
                    r.bytes -= bytes.len();
                    1
                }
                None => r.fail("unknown buffer handle"),
            }
        })
    }
    
    pub extern "C" fn lang_error() -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            let bytes = r.error.as_bytes().to_vec();
            match r.insert_buffer(bytes) {
                Ok(id) => id,
                Err(_) => 0,
            }
        })
    }
    
    pub extern "C" fn lang_init() -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            if r.states.len() >= MAX_STATES {
                return r.fail("ABI state handle limit");
            }
            match r.id() {
                Ok(id) => {
                    r.states.insert(id, State::new());
                    id
                }
                Err(e) => r.fail(e),
            }
        })
    }
    
    pub extern "C" fn lang_state_drop(handle: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            if r.states.remove(&handle).is_some() {
                1
            } else {
                r.fail("unknown state handle")
            }
        })
    }
    
    pub extern "C" fn lang_restore(buffer: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            if r.states.len() >= MAX_STATES {
                return r.fail("ABI state handle limit");
            }
            let id = match r.id() {
                Ok(id) => id,
                Err(e) => return r.fail(e),
            };
            let Some(bytes) = r.buffers.get(&buffer) else {
                return r.fail("unknown buffer handle");
            };
            match State::restore(bytes) {
                Ok(state) => {
                    r.states.insert(id, state);
                    id
                }
                Err(e) => r.fail(e),
            }
        })
    }
    
    pub extern "C" fn lang_checkpoint(state: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            let id = match r.reserve_output() {
                Ok(id) => id,
                Err(e) => return r.fail(e),
            };
            let result = r
                .states
                .get(&state)
                .ok_or_else(|| "unknown state handle".to_string())
                .and_then(|s| s.checkpoint());
            match result {
                Ok(bytes) => r.finish(id, bytes),
                Err(e) => {
                    r.buffers.remove(&id);
                    r.fail(e)
                }
            }
        })
    }
    
    pub extern "C" fn lang_invoke(state: u32, request: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            let id = match r.reserve_output() {
                Ok(id) => id,
                Err(e) => return r.fail(e),
            };
            let result = (|| -> Result<Json, String> {
                let bytes = r.buffers.get(&request).ok_or("unknown buffer handle")?;
                if bytes.len() > MAX_JSON {
                    return Err("ABI request exceeds 4 MiB".into());
                }
                let message: Json = serde_json::from_slice(bytes).map_err(|e| e.to_string())?;
                let pure = message.get("pure").and_then(Json::as_str);
                let name = pure
                    .or_else(|| message.get("call").and_then(Json::as_str))
                    .ok_or("request needs call or pure")?;
                let args = message.get("args").ok_or("request needs args")?;
                let state = r.states.get_mut(&state).ok_or("unknown state handle")?;
                if pure.is_some() {
                    state.call_json(name, args)
                } else {
                    state.invoke_json(name, args)
                }
            })();
            let committed = result
                .as_ref()
                .ok()
                .and_then(|v| v.get("committed"))
                .and_then(Json::as_bool)
                .unwrap_or(false);
            r.envelope(id, result, committed)
        })
    }
    
    pub extern "C" fn lang_events(state: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            let id = match r.reserve_output() {
                Ok(id) => id,
                Err(e) => return r.fail(e),
            };
            let result = r
                .states
                .get(&state)
                .ok_or_else(|| "unknown state handle".into())
                .map(|s| Json::Array(s.outbox().iter().map(Event::to_json).collect()));
            r.envelope(id, result, false)
        })
    }
    
    pub extern "C" fn lang_acknowledge(state: u32, commit: u64, position: u64) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            match r.states.get_mut(&state) {
                Some(s) => {
                    s.acknowledge_through(commit, position);
                    1
                }
                None => r.fail("unknown state handle"),
            }
        })
    }
    
    pub extern "C" fn lang_version(state: u32) -> u64 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            match r.states.get(&state) {
                Some(s) => s.version(),
                None => {
                    r.fail("unknown state handle");
                    0
                }
            }
        })
    }
}