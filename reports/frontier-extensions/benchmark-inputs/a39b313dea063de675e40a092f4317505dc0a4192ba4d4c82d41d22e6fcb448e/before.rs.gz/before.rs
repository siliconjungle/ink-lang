// ink-definition-rust-v1: checked bodies; Rust/backend are trusted.
#![allow(non_camel_case_types, non_snake_case, non_upper_case_globals, dead_code, unused_variables, unused_parens, unused_unsafe, improper_ctypes_definitions)]
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505 { C0(std::sync::Arc<D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6>,std::sync::Arc<D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6>) }
fn d_085e4620e533011070d4f570ac5c06b1ab91d1c609efb5f416a780c8601c01ef(v0: &D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d,v1: u64,v2: u64,v3: u64) -> D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953 { if d_bbe104df4fca4be006eea2e68096614f9aa005ed5dcea4182b1d0a54dfb9bfb4(&(match v0 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v4) => { (v4.as_ref()).clone() } }),v2) { if d_bbe104df4fca4be006eea2e68096614f9aa005ed5dcea4182b1d0a54dfb9bfb4(&(match v0 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v5) => { (v5.as_ref()).clone() } }),v2) { match &(D_ab57314b103b0272026ef00a59bec076220a16d0626b34bb3da1512f510d5c1c::C0(std::sync::Arc::new(match v0 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v6) => { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_e7930df47ea24625591b2eb42d304876a45965ec2a66e0d4f3679ab164d36cea(&(match v0 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v7) => { (v7.as_ref()).clone() } }),v2,v3))) } }))) { D_ab57314b103b0272026ef00a59bec076220a16d0626b34bb3da1512f510d5c1c::C0(v8) => { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v9:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v9.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v11) => { if ((v1) == (18446744073709551615u64)) { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v1,std::sync::Arc::new((v0).clone())) } else { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v11))),true,(v1).wrapping_add(1u64),std::sync::Arc::clone(v8),std::sync::Arc::clone({static v12:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v12.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v13) => { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v13))),false,v1,std::sync::Arc::new((v0).clone()),std::sync::Arc::clone({static v14:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v14.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})) } } } } } else { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v1,std::sync::Arc::new((v0).clone())) } } else { if d_bbe104df4fca4be006eea2e68096614f9aa005ed5dcea4182b1d0a54dfb9bfb4(&(match v0 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v15) => { (v15.as_ref()).clone() } }),v2) { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v1,std::sync::Arc::new((v0).clone())) } else { match &(D_ab57314b103b0272026ef00a59bec076220a16d0626b34bb3da1512f510d5c1c::C0(std::sync::Arc::new(match v0 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v16) => { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_45191bef560e6321dce74a5a209a55eb52a4cf4c218e01d243a6aa036a818eae(&(match v0 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v17) => { (v17.as_ref()).clone() } }),v2,v3))) } }))) { D_ab57314b103b0272026ef00a59bec076220a16d0626b34bb3da1512f510d5c1c::C0(v18) => { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v19:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v19.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v21) => { if ((v1) == (18446744073709551615u64)) { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v1,std::sync::Arc::new((v0).clone())) } else { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v21))),true,(v1).wrapping_add(1u64),std::sync::Arc::clone(v18),std::sync::Arc::clone({static v22:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v22.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v23) => { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v23))),false,v1,std::sync::Arc::new((v0).clone()),std::sync::Arc::clone({static v24:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v24.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})) } } } } } } }
fn d_19fd6a05c9451d80f3a04bda53f317bd8d95d561982b61c433ccebe072735f19(v25: &D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0,v26: u64,v27: u64,v28: bool) -> D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505 { D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505::C0(std::sync::Arc::new(d_bb55bd440029d5f4a76f0ae82022ad4afd52a3a35ba4cbf391e41cf3eb9ccd2a(&(d_627505f9e165ea82f5eed062485e5d2368fd30dd79ef454b213f924d0bdf231a(v25)),v26,v27,v28)),std::sync::Arc::new(d_bb55bd440029d5f4a76f0ae82022ad4afd52a3a35ba4cbf391e41cf3eb9ccd2a(&(d_336cd12dc037c4064a3344f2adf032f87bbcee24ef5cceac82ba9fe7ba9b31d8(v25)),v26,v27,v28))) }
fn d_21163bddc0daf69cd090e6166b6be75f6a355bdc1b68e104532689262e58dd92(v29: &D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d,v30: u64) -> D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(d_54bcba3d562a98540c4f4f84d132b173bf4776981a8aeeeae4b8bc29b7575eaf(&(match v29 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v31) => { (v31.as_ref()).clone() } }),1u64)),false,v30,std::sync::Arc::new((v29).clone()),std::sync::Arc::clone({static v32:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v32.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})) }
fn d_2263b5eb9269f7e9a75e38f9673c49ba70d5bc3a902f72d6aeb6be842b416532(v33: &D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505) -> D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953 { d_85f50dd4659a64fd96acd5d37fdc45b6398b5364be3cafa2916fde7129b3bf27(&(d_9bdfce55f6959f13d000e5636e87179c66aa36206d2fd3092cc20dd794043b1f(v33))) }
fn d_25290b8ad08213c57ce2a4f3f95e447e0cf16bab8cc47873800b253904170edc(v34: &D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b) -> D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02 { match v34 { D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b::C0(v35,v36) => { (v36.as_ref()).clone() } } }
fn d_25c3d00f3c6cdac96b6b1fbfd31135d12b92c542280a1f07962897470923109d(v37: &D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d) -> D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b { match v37 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v38) => { D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b::C0(std::sync::Arc::clone(v38),std::sync::Arc::new(d_54bcba3d562a98540c4f4f84d132b173bf4776981a8aeeeae4b8bc29b7575eaf(v38.as_ref(),0u64))) } } }
fn d_2c9eab9de06ed39b8eb124ed389b986b7e05e8893bcc7ea19c93bc31f2f35f39(v39: &D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d) -> D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0 { D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0::C0(std::sync::Arc::new(d_25c3d00f3c6cdac96b6b1fbfd31135d12b92c542280a1f07962897470923109d(v39)),std::sync::Arc::new(d_5e89fa5d684d22d65683e9a31a4dc01b43911dbbf7e41e0b3b227a00981cb685(v39))) }
fn d_2de7d1bc1c1d6759770609ee2df3faa1bfde7917e3e2b6c303cab72c0ee37c72(v40: &D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b,v41: u64,v42: u64) -> D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80 { D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80::C0(std::sync::Arc::new((v40).clone()),std::sync::Arc::new(d_b10f744f50ab01d06502c772c5bad94fd866376588b667bda83d9f974b4febaf(&(d_93b041b45ae9b073d3911aad0b2f6ce2bcfb4b341c7a6623f18f0bd9ed8b9638(v40)),v41,v42))) }
fn d_336cd12dc037c4064a3344f2adf032f87bbcee24ef5cceac82ba9fe7ba9b31d8(v43: &D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0) -> D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b { match v43 { D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0::C0(v44,v45) => { (v45.as_ref()).clone() } } }
fn d_3c9eb542f08149286c9d998d27320395969df3830112d4f0615cdab27a95e784(v46: &D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b) -> D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80 { match v46 { D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b::C0(v47,v48) => { (v47.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0 { C0(std::sync::Arc<D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b>,std::sync::Arc<D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b>) }
fn d_45191bef560e6321dce74a5a209a55eb52a4cf4c218e01d243a6aa036a818eae(v49: &D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807,v50: u64,v51: u64) -> D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807 { match v49 { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 => { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(v50,v51,std::sync::Arc::clone({static v52:std::sync::OnceLock<std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>>=std::sync::OnceLock::new();v52.get_or_init(||std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0))})) },D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(v53,v54,v55) => { if ((v50) < (*v53)) { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(v50,v51,std::sync::Arc::new((v49).clone())) } else { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(*v53,*v54,std::sync::Arc::new(d_45191bef560e6321dce74a5a209a55eb52a4cf4c218e01d243a6aa036a818eae(v55.as_ref(),v50,v51))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d { C0(std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>) }
fn d_4f8ac751c074a8155c4b54e72a7019524725403dbbce8eb31591bf754c4b1f71(v56: &D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807,v57: u64) -> D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807 { match v56 { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 => { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 },D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(v59,v60,v61) => { if ((v57) == (*v59)) { d_4f8ac751c074a8155c4b54e72a7019524725403dbbce8eb31591bf754c4b1f71(v61.as_ref(),v57) } else { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(*v59,*v60,std::sync::Arc::new(d_4f8ac751c074a8155c4b54e72a7019524725403dbbce8eb31591bf754c4b1f71(v61.as_ref(),v57))) } } } }
fn d_52e1b0a635f40e8072e849dff10257d6736accad3cc25a42ac700354b5b133d4(v62: &D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b,v63: u64) -> D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80 { D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80::C0(std::sync::Arc::new((v62).clone()),std::sync::Arc::new(d_21163bddc0daf69cd090e6166b6be75f6a355bdc1b68e104532689262e58dd92(&(d_93b041b45ae9b073d3911aad0b2f6ce2bcfb4b341c7a6623f18f0bd9ed8b9638(v62)),v63))) }
fn d_54adb086766361e578dee6224e7198b84792161999e94a1635a03923971cdf95(v64: &D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6) -> D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b { match v64 { D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6::C0(v65,v66) => { d_c805ea1822318f322f4650ebe3f83c76599482fdbac9d564b6028d7e64a15db7(v65.as_ref(),v66.as_ref()) } } }
fn d_54bcba3d562a98540c4f4f84d132b173bf4776981a8aeeeae4b8bc29b7575eaf(v67: &D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807,v68: u64) -> D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02 { match v67 { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 => { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 },D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(v70,v71,v72) => { if ((v68) == (*v70)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(*v71) } else { d_54bcba3d562a98540c4f4f84d132b173bf4776981a8aeeeae4b8bc29b7575eaf(v72.as_ref(),v68) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b { C0(std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>,std::sync::Arc<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>) }
fn d_5643959afe0ba43633a80d3519ff35a112f6c6e379780b92f7a28f0b2f6524ce(v73: &D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b,v74: u64,v75: u64,v76: u64,v77: bool) -> D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6 { D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6::C0(std::sync::Arc::new(d_25290b8ad08213c57ce2a4f3f95e447e0cf16bab8cc47873800b253904170edc(v73)),std::sync::Arc::new(d_da9453e15172c24d7be5dcbb69c1af51b8a23438072a7cbdd4a3efe5e2bf9cf2(&(d_93b041b45ae9b073d3911aad0b2f6ce2bcfb4b341c7a6623f18f0bd9ed8b9638(v73)),v74,v75,v76,v77))) }
fn d_5c73f995f9cff667f3e888ecac8a8df68dffa3985201a12d5fd98fe10205e9c0(v78: &D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b) -> D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { d_81ae83a2547f8c774230ab6411fd069781ca60a1e6fc009ec4ec72fb733bd7be(&(d_5e81cafbe357d9d73bb384dbfdb6130544c53646b7222307acaf0699f385a61f(v78))) }
fn d_5e81cafbe357d9d73bb384dbfdb6130544c53646b7222307acaf0699f385a61f(v79: &D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b) -> D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80 { match v79 { D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b::C0(v80,v81) => { (v81.as_ref()).clone() } } }
fn d_5e89fa5d684d22d65683e9a31a4dc01b43911dbbf7e41e0b3b227a00981cb685(v82: &D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d) -> D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b { match v82 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v83) => { D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b::C0(std::sync::Arc::clone(v83),std::sync::Arc::new(d_54bcba3d562a98540c4f4f84d132b173bf4776981a8aeeeae4b8bc29b7575eaf(v83.as_ref(),1u64))) } } }
fn d_627505f9e165ea82f5eed062485e5d2368fd30dd79ef454b213f924d0bdf231a(v84: &D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0) -> D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b { match v84 { D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0::C0(v85,v86) => { (v85.as_ref()).clone() } } }
fn d_6aabb96e85bedc706067338784f31268e2dc62ba3b1b871822535bb89bdd03cf(v87: &D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505) -> D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6 { match v87 { D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505::C0(v88,v89) => { (v89.as_ref()).clone() } } }
fn d_77b52735ece6d80a4a3cb661508a41a39f770e5a55e0e3c14dcacee6c9a65682(v90: &D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505) -> D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0 { D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0::C0(std::sync::Arc::new(d_b139c74a2d9a4e87c01a36c6e67b03b82ae5f0e8fbeaf2bd4fe0d7140eac68d4(&(d_9bdfce55f6959f13d000e5636e87179c66aa36206d2fd3092cc20dd794043b1f(v90)))),std::sync::Arc::new(d_54adb086766361e578dee6224e7198b84792161999e94a1635a03923971cdf95(&(d_6aabb96e85bedc706067338784f31268e2dc62ba3b1b871822535bb89bdd03cf(v90))))) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807 { C0,C1(u64,u64,std::sync::Arc<D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807>) }
impl D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_7b197326fc888ef93ee28e71a73b411aab2cb2d191d61ed845adc65de3b38e62(v91: &D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d,v92: u64) -> D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(d_54bcba3d562a98540c4f4f84d132b173bf4776981a8aeeeae4b8bc29b7575eaf(&(match v91 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v93) => { (v93.as_ref()).clone() } }),0u64)),false,v92,std::sync::Arc::new((v91).clone()),std::sync::Arc::clone({static v94:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v94.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})) }
fn d_7c02c3910178043903d3a4605b0d5855de61b0c0294406085101d5fa6413dce8(v95: &D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0,v96: u64) -> D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b { D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b::C0(std::sync::Arc::new(d_52e1b0a635f40e8072e849dff10257d6736accad3cc25a42ac700354b5b133d4(&(d_627505f9e165ea82f5eed062485e5d2368fd30dd79ef454b213f924d0bdf231a(v95)),v96)),std::sync::Arc::new(d_fee1fbb6a4f20504a92de0f40e45486bab8eb7a0d728309287d95ecef2948e99(&(d_336cd12dc037c4064a3344f2adf032f87bbcee24ef5cceac82ba9fe7ba9b31d8(v95)),v96))) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953 { C0(std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,bool,u64,std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>,std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>),C1(u64,u64,std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>) }
fn d_81ae83a2547f8c774230ab6411fd069781ca60a1e6fc009ec4ec72fb733bd7be(v97: &D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80) -> D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { match v97 { D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80::C0(v98,v99) => { (v99.as_ref()).clone() } } }
fn d_85f50dd4659a64fd96acd5d37fdc45b6398b5364be3cafa2916fde7129b3bf27(v100: &D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6) -> D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953 { match v100 { D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6::C0(v101,v102) => { (v102.as_ref()).clone() } } }
fn d_866da10b06d58c18bf6296decb365e59a596e066c99fec92cfed3eee3677a73b(v103: &D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b) -> D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0 { D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0::C0(std::sync::Arc::new(d_a0b9cd463ffd6503c5fda299618dbacc0d19e64fcba7c85fd3efcbb453b158ad(&(d_3c9eb542f08149286c9d998d27320395969df3830112d4f0615cdab27a95e784(v103)))),std::sync::Arc::new(d_a0b9cd463ffd6503c5fda299618dbacc0d19e64fcba7c85fd3efcbb453b158ad(&(d_5e81cafbe357d9d73bb384dbfdb6130544c53646b7222307acaf0699f385a61f(v103))))) }
fn d_8c36212ea83cb1e8952c3208b0c795ece0dede334f7972fa2e26ee5947258f46(v104: &D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b,v105: u64,v106: u64,v107: u64) -> D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6 { D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6::C0(std::sync::Arc::new(d_25290b8ad08213c57ce2a4f3f95e447e0cf16bab8cc47873800b253904170edc(v104)),std::sync::Arc::new(d_085e4620e533011070d4f570ac5c06b1ab91d1c609efb5f416a780c8601c01ef(&(d_93b041b45ae9b073d3911aad0b2f6ce2bcfb4b341c7a6623f18f0bd9ed8b9638(v104)),v105,v106,v107))) }
fn d_9063820602ccd275a202bb104089b363dc20d7b3e480d238108a8de2f452f303(v108: &D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d,v109: u64,v110: u64,v111: bool) -> D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953 { match &(D_ab57314b103b0272026ef00a59bec076220a16d0626b34bb3da1512f510d5c1c::C0(std::sync::Arc::new(match v108 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v112) => { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_4f8ac751c074a8155c4b54e72a7019524725403dbbce8eb31591bf754c4b1f71(&(match v108 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v113) => { (v113.as_ref()).clone() } }),v110))) } }))) { D_ab57314b103b0272026ef00a59bec076220a16d0626b34bb3da1512f510d5c1c::C0(v114) => { match &(D_ab57314b103b0272026ef00a59bec076220a16d0626b34bb3da1512f510d5c1c::C0(std::sync::Arc::new(match v114.as_ref() { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v115) => { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_4f8ac751c074a8155c4b54e72a7019524725403dbbce8eb31591bf754c4b1f71(&(match v114.as_ref() { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v116) => { (v116.as_ref()).clone() } }),v110))) } }))) { D_ab57314b103b0272026ef00a59bec076220a16d0626b34bb3da1512f510d5c1c::C0(v117) => { match &(D_ec21787fe3ff78105676887cec8738e3a4e334a83aed8e76eb2f3fe58014b8bb::C0(std::sync::Arc::new(d_a64f68dae0d3ccf95f269a25f7b92345158dfbb266707927a0733b9dfaddbbcc(&(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0),&(D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(v110)))))) { D_ec21787fe3ff78105676887cec8738e3a4e334a83aed8e76eb2f3fe58014b8bb::C0(v119) => { if v111 { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v120:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v120.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v122) => { if ((v109) == (18446744073709551615u64)) { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v109,std::sync::Arc::new((v108).clone())) } else { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v122))),true,(v109).wrapping_add(1u64),std::sync::Arc::clone(v117),std::sync::Arc::clone(v119)) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v123) => { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v123))),false,v109,std::sync::Arc::new((v108).clone()),std::sync::Arc::clone({static v124:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v124.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})) } } } else { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v125:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v125.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v127) => { if ((v109) == (18446744073709551615u64)) { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v109,std::sync::Arc::new((v108).clone())) } else { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v127))),true,(v109).wrapping_add(1u64),std::sync::Arc::clone(v117),std::sync::Arc::clone(v119)) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v128) => { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v128))),false,v109,std::sync::Arc::new((v108).clone()),std::sync::Arc::clone({static v129:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v129.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})) } } } } } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f { C0(std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>),C1(std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>) }
fn d_925c36680abdc0c03563189333b337cfd21aeed464b48af0ce0bb3216d4fc211(v130: &D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0) -> D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d { d_93b041b45ae9b073d3911aad0b2f6ce2bcfb4b341c7a6623f18f0bd9ed8b9638(&(d_627505f9e165ea82f5eed062485e5d2368fd30dd79ef454b213f924d0bdf231a(v130))) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de { C0,C1(std::sync::Arc<D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6>,std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>) }
impl D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_93b041b45ae9b073d3911aad0b2f6ce2bcfb4b341c7a6623f18f0bd9ed8b9638(v131: &D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b) -> D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d { match v131 { D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b::C0(v132,v133) => { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone(v132)) } } }
fn d_98245cdc846e03122c9a93db472402fbdad8ffcba4a5a33eaf802b87b1b34bca(v134: &D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b) -> D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { d_81ae83a2547f8c774230ab6411fd069781ca60a1e6fc009ec4ec72fb733bd7be(&(d_3c9eb542f08149286c9d998d27320395969df3830112d4f0615cdab27a95e784(v134))) }
fn d_9bdfce55f6959f13d000e5636e87179c66aa36206d2fd3092cc20dd794043b1f(v135: &D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505) -> D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6 { match v135 { D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505::C0(v136,v137) => { (v136.as_ref()).clone() } } }
fn d_a0b9cd463ffd6503c5fda299618dbacc0d19e64fcba7c85fd3efcbb453b158ad(v138: &D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80) -> D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b { match v138 { D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80::C0(v139,v140) => { (v139.as_ref()).clone() } } }
fn d_a5e262efe2370368a99a21fbbb42d370f5093fbef0c950803661020614d360b7(v141: &D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b,v142: u64) -> D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80 { D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80::C0(std::sync::Arc::new((v141).clone()),std::sync::Arc::new(d_7b197326fc888ef93ee28e71a73b411aab2cb2d191d61ed845adc65de3b38e62(&(d_93b041b45ae9b073d3911aad0b2f6ce2bcfb4b341c7a6623f18f0bd9ed8b9638(v141)),v142))) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80 { C0(std::sync::Arc<D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b>,std::sync::Arc<D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994>) }
fn d_a64f68dae0d3ccf95f269a25f7b92345158dfbb266707927a0733b9dfaddbbcc(v143: &D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de,v144: &D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6) -> D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de { match v143 { D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0 => { D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(std::sync::Arc::new((v144).clone()),std::sync::Arc::clone({static v145:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v145.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})) },D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(v146,v147) => { D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(std::sync::Arc::clone(v146),std::sync::Arc::new(d_a64f68dae0d3ccf95f269a25f7b92345158dfbb266707927a0733b9dfaddbbcc(v147.as_ref(),v144))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02 { C0,C1(u64) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ab57314b103b0272026ef00a59bec076220a16d0626b34bb3da1512f510d5c1c { C0(std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b { C0(std::sync::Arc<D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80>,std::sync::Arc<D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80>) }
fn d_b10f744f50ab01d06502c772c5bad94fd866376588b667bda83d9f974b4febaf(v148: &D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d,v149: u64,v150: u64) -> D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::new(d_54bcba3d562a98540c4f4f84d132b173bf4776981a8aeeeae4b8bc29b7575eaf(&(match v148 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v151) => { (v151.as_ref()).clone() } }),v150)),false,v149,std::sync::Arc::new((v148).clone()),std::sync::Arc::clone({static v152:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v152.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})) }
fn d_b139c74a2d9a4e87c01a36c6e67b03b82ae5f0e8fbeaf2bd4fe0d7140eac68d4(v153: &D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6) -> D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b { match v153 { D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6::C0(v154,v155) => { d_c2b66fa85a6ae6bc01ef3172519b8b883eebec53f72414f526b82a5fdba52dbf(v154.as_ref(),v155.as_ref()) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c { C0 }
impl D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_bb55bd440029d5f4a76f0ae82022ad4afd52a3a35ba4cbf391e41cf3eb9ccd2a(v156: &D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b,v157: u64,v158: u64,v159: bool) -> D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6 { D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6::C0(std::sync::Arc::new(d_25290b8ad08213c57ce2a4f3f95e447e0cf16bab8cc47873800b253904170edc(v156)),std::sync::Arc::new(d_9063820602ccd275a202bb104089b363dc20d7b3e480d238108a8de2f452f303(&(d_93b041b45ae9b073d3911aad0b2f6ce2bcfb4b341c7a6623f18f0bd9ed8b9638(v156)),v157,v158,v159))) }
fn d_bba9c18cac7538bc1012fae0186904dd64a249ed17ec5d2c36a62b59cf4f1126(v160: &D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0,v161: u64,v162: u64,v163: u64,v164: bool) -> D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505 { D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505::C0(std::sync::Arc::new(d_5643959afe0ba43633a80d3519ff35a112f6c6e379780b92f7a28f0b2f6524ce(&(d_627505f9e165ea82f5eed062485e5d2368fd30dd79ef454b213f924d0bdf231a(v160)),v161,v162,v163,v164)),std::sync::Arc::new(d_5643959afe0ba43633a80d3519ff35a112f6c6e379780b92f7a28f0b2f6524ce(&(d_336cd12dc037c4064a3344f2adf032f87bbcee24ef5cceac82ba9fe7ba9b31d8(v160)),v161,v162,v163,v164))) }
fn d_bbe104df4fca4be006eea2e68096614f9aa005ed5dcea4182b1d0a54dfb9bfb4(v165: &D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807,v166: u64) -> bool { match &(d_54bcba3d562a98540c4f4f84d132b173bf4776981a8aeeeae4b8bc29b7575eaf(v165,v166)) { D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0 => { false },D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(v167) => { true } } }
fn d_c2b66fa85a6ae6bc01ef3172519b8b883eebec53f72414f526b82a5fdba52dbf(v168: &D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02,v169: &D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953) -> D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b { match v169 { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(v170,v171,v172,v173,v174) => { if *v171 { d_25c3d00f3c6cdac96b6b1fbfd31135d12b92c542280a1f07962897470923109d(v173.as_ref()) } else { match v173.as_ref() { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v175) => { D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b::C0(std::sync::Arc::clone(v175),std::sync::Arc::new((v168).clone())) } } } },D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(v176,v177,v178) => { match v178.as_ref() { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v179) => { D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b::C0(std::sync::Arc::clone(v179),std::sync::Arc::new((v168).clone())) } } } } }
fn d_c300c32f81d32f6873540ab0ca914988c5b3e4b1e768b172bc87ab17ab53d26a(v180: &D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0,v181: u64,v182: u64) -> D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b { D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b::C0(std::sync::Arc::new(d_2de7d1bc1c1d6759770609ee2df3faa1bfde7917e3e2b6c303cab72c0ee37c72(&(d_627505f9e165ea82f5eed062485e5d2368fd30dd79ef454b213f924d0bdf231a(v180)),v181,v182)),std::sync::Arc::new(d_2de7d1bc1c1d6759770609ee2df3faa1bfde7917e3e2b6c303cab72c0ee37c72(&(d_336cd12dc037c4064a3344f2adf032f87bbcee24ef5cceac82ba9fe7ba9b31d8(v180)),v181,v182))) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b { C0 }
impl D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_c805ea1822318f322f4650ebe3f83c76599482fdbac9d564b6028d7e64a15db7(v183: &D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02,v184: &D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953) -> D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b { match v184 { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(v185,v186,v187,v188,v189) => { if *v186 { d_5e89fa5d684d22d65683e9a31a4dc01b43911dbbf7e41e0b3b227a00981cb685(v188.as_ref()) } else { match v188.as_ref() { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v190) => { D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b::C0(std::sync::Arc::clone(v190),std::sync::Arc::new((v183).clone())) } } } },D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(v191,v192,v193) => { match v193.as_ref() { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v194) => { D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b::C0(std::sync::Arc::clone(v194),std::sync::Arc::new((v183).clone())) } } } } }
fn d_cd11f970081e39840e1cc3a9500589d375bd7e174626d29021b086d90eaea308(v195: &D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0,v196: u64,v197: u64,v198: u64) -> D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505 { D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505::C0(std::sync::Arc::new(d_8c36212ea83cb1e8952c3208b0c795ece0dede334f7972fa2e26ee5947258f46(&(d_627505f9e165ea82f5eed062485e5d2368fd30dd79ef454b213f924d0bdf231a(v195)),v196,v197,v198)),std::sync::Arc::new(d_8c36212ea83cb1e8952c3208b0c795ece0dede334f7972fa2e26ee5947258f46(&(d_336cd12dc037c4064a3344f2adf032f87bbcee24ef5cceac82ba9fe7ba9b31d8(v195)),v196,v197,v198))) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6 { C0(u64) }
fn d_da9453e15172c24d7be5dcbb69c1af51b8a23438072a7cbdd4a3efe5e2bf9cf2(v199: &D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d,v200: u64,v201: u64,v202: u64,v203: bool) -> D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953 { if d_bbe104df4fca4be006eea2e68096614f9aa005ed5dcea4182b1d0a54dfb9bfb4(&(match v199 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v204) => { (v204.as_ref()).clone() } }),v201) { if d_bbe104df4fca4be006eea2e68096614f9aa005ed5dcea4182b1d0a54dfb9bfb4(&(match v199 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v205) => { (v205.as_ref()).clone() } }),v201) { match &(D_ab57314b103b0272026ef00a59bec076220a16d0626b34bb3da1512f510d5c1c::C0(std::sync::Arc::new(match v199 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v206) => { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(d_e7930df47ea24625591b2eb42d304876a45965ec2a66e0d4f3679ab164d36cea(&(match v199 { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v207) => { (v207.as_ref()).clone() } }),v201,v202))) } }))) { D_ab57314b103b0272026ef00a59bec076220a16d0626b34bb3da1512f510d5c1c::C0(v208) => { match &(D_ec21787fe3ff78105676887cec8738e3a4e334a83aed8e76eb2f3fe58014b8bb::C0(std::sync::Arc::new(d_a64f68dae0d3ccf95f269a25f7b92345158dfbb266707927a0733b9dfaddbbcc(&(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0),&(D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(v202)))))) { D_ec21787fe3ff78105676887cec8738e3a4e334a83aed8e76eb2f3fe58014b8bb::C0(v210) => { if v203 { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v211:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v211.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v213) => { if ((v200) == (18446744073709551615u64)) { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v200,std::sync::Arc::new((v199).clone())) } else { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v213))),true,(v200).wrapping_add(1u64),std::sync::Arc::clone(v208),std::sync::Arc::clone(v210)) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v214) => { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v214))),false,v200,std::sync::Arc::new((v199).clone()),std::sync::Arc::clone({static v215:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v215.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})) } } } else { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v216:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v216.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v218) => { if ((v200) == (18446744073709551615u64)) { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v200,std::sync::Arc::new((v199).clone())) } else { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v218))),true,(v200).wrapping_add(1u64),std::sync::Arc::clone(v208),std::sync::Arc::clone(v210)) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v219) => { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v219))),false,v200,std::sync::Arc::new((v199).clone()),std::sync::Arc::clone({static v220:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v220.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})) } } } } } } } } else { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(2u64,v200,std::sync::Arc::new((v199).clone())) } } else { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v221:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v221.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v223) => { if ((v200) == (18446744073709551615u64)) { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(1u64,v200,std::sync::Arc::new((v199).clone())) } else { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v223))),true,(v200).wrapping_add(1u64),std::sync::Arc::new((v199).clone()),std::sync::Arc::clone({static v224:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v224.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v225) => { D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v225))),false,v200,std::sync::Arc::new((v199).clone()),std::sync::Arc::clone({static v226:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v226.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_de5e808a5015e569a7b8f87b5339e6aab85c00f434136f16f3414e326609eeb6 { C0(std::sync::Arc<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,std::sync::Arc<D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953>) }
fn d_e55487630754135401796588e05c6372eee03487f5fec4dcb6448144c068365e(v227: &D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0,v228: u64) -> D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b { D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b::C0(std::sync::Arc::new(d_fee1fbb6a4f20504a92de0f40e45486bab8eb7a0d728309287d95ecef2948e99(&(d_627505f9e165ea82f5eed062485e5d2368fd30dd79ef454b213f924d0bdf231a(v227)),v228)),std::sync::Arc::new(d_a5e262efe2370368a99a21fbbb42d370f5093fbef0c950803661020614d360b7(&(d_336cd12dc037c4064a3344f2adf032f87bbcee24ef5cceac82ba9fe7ba9b31d8(v227)),v228))) }
fn d_e7930df47ea24625591b2eb42d304876a45965ec2a66e0d4f3679ab164d36cea(v229: &D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807,v230: u64,v231: u64) -> D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807 { match v229 { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 => { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0 },D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(v233,v234,v235) => { D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(*v233,if ((v230) == (*v233)) { v231 } else { *v234 },std::sync::Arc::new(d_e7930df47ea24625591b2eb42d304876a45965ec2a66e0d4f3679ab164d36cea(v235.as_ref(),v230,v231))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ec21787fe3ff78105676887cec8738e3a4e334a83aed8e76eb2f3fe58014b8bb { C0(std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { C0(std::sync::Arc<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,bool,u64,std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>,std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>),C1(u64,u64,std::sync::Arc<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d>) }
fn d_fee1fbb6a4f20504a92de0f40e45486bab8eb7a0d728309287d95ecef2948e99(v236: &D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b,v237: u64) -> D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80 { match v236 { D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b::C0(v238,v239) => { D_a62607809ed445e4fbf7dbff3b48704b3c2873f305f5f11c2558cab9b54aba80::C0(std::sync::Arc::new((v236).clone()),std::sync::Arc::new(D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(std::sync::Arc::clone(v239),false,v237,std::sync::Arc::new(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone(v238))),std::sync::Arc::clone({static v240:std::sync::OnceLock<std::sync::Arc<D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de>>=std::sync::OnceLock::new();v240.get_or_init(||std::sync::Arc::new(D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0))})))) } } }
pub fn f_19fd6a05c9451d80f3a04bda53f317bd8d95d561982b61c433ccebe072735f19(v241: &D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0,v242: u64,v243: u64,v244: bool) -> D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505 { d_19fd6a05c9451d80f3a04bda53f317bd8d95d561982b61c433ccebe072735f19(v241,v242,v243,v244) }
pub fn f_2263b5eb9269f7e9a75e38f9673c49ba70d5bc3a902f72d6aeb6be842b416532(v245: &D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505) -> D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953 { d_2263b5eb9269f7e9a75e38f9673c49ba70d5bc3a902f72d6aeb6be842b416532(v245) }
pub fn f_2c9eab9de06ed39b8eb124ed389b986b7e05e8893bcc7ea19c93bc31f2f35f39(v246: &D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d) -> D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0 { d_2c9eab9de06ed39b8eb124ed389b986b7e05e8893bcc7ea19c93bc31f2f35f39(v246) }
pub fn f_5c73f995f9cff667f3e888ecac8a8df68dffa3985201a12d5fd98fe10205e9c0(v247: &D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b) -> D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { d_5c73f995f9cff667f3e888ecac8a8df68dffa3985201a12d5fd98fe10205e9c0(v247) }
pub fn f_77b52735ece6d80a4a3cb661508a41a39f770e5a55e0e3c14dcacee6c9a65682(v248: &D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505) -> D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0 { d_77b52735ece6d80a4a3cb661508a41a39f770e5a55e0e3c14dcacee6c9a65682(v248) }
pub fn f_7c02c3910178043903d3a4605b0d5855de61b0c0294406085101d5fa6413dce8(v249: &D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0,v250: u64) -> D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b { d_7c02c3910178043903d3a4605b0d5855de61b0c0294406085101d5fa6413dce8(v249,v250) }
pub fn f_866da10b06d58c18bf6296decb365e59a596e066c99fec92cfed3eee3677a73b(v251: &D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b) -> D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0 { d_866da10b06d58c18bf6296decb365e59a596e066c99fec92cfed3eee3677a73b(v251) }
pub fn f_925c36680abdc0c03563189333b337cfd21aeed464b48af0ce0bb3216d4fc211(v252: &D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0) -> D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d { d_925c36680abdc0c03563189333b337cfd21aeed464b48af0ce0bb3216d4fc211(v252) }
pub fn f_98245cdc846e03122c9a93db472402fbdad8ffcba4a5a33eaf802b87b1b34bca(v253: &D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b) -> D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994 { d_98245cdc846e03122c9a93db472402fbdad8ffcba4a5a33eaf802b87b1b34bca(v253) }
pub fn f_bba9c18cac7538bc1012fae0186904dd64a249ed17ec5d2c36a62b59cf4f1126(v254: &D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0,v255: u64,v256: u64,v257: u64,v258: bool) -> D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505 { d_bba9c18cac7538bc1012fae0186904dd64a249ed17ec5d2c36a62b59cf4f1126(v254,v255,v256,v257,v258) }
pub fn f_c300c32f81d32f6873540ab0ca914988c5b3e4b1e768b172bc87ab17ab53d26a(v259: &D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0,v260: u64,v261: u64) -> D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b { d_c300c32f81d32f6873540ab0ca914988c5b3e4b1e768b172bc87ab17ab53d26a(v259,v260,v261) }
pub fn f_cd11f970081e39840e1cc3a9500589d375bd7e174626d29021b086d90eaea308(v262: &D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0,v263: u64,v264: u64,v265: u64) -> D_08311cf6b07eefadceaab1dbc2f9ed1a05fc0a73acf94497fd8f9db693a7f505 { d_cd11f970081e39840e1cc3a9500589d375bd7e174626d29021b086d90eaea308(v262,v263,v264,v265) }
pub fn f_e55487630754135401796588e05c6372eee03487f5fec4dcb6448144c068365e(v266: &D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0,v267: u64) -> D_af9b782702c7293d35a8c90c5fbe70feeacf51a2a1180f0f3edd1179e8aebd7b { d_e55487630754135401796588e05c6372eee03487f5fec4dcb6448144c068365e(v266,v267) }
fn q_c300c32f81d32f6873540ab0ca914988c5b3e4b1e768b172bc87ab17ab53d26a(v0:&D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0,v1:u64,v2:u64)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{match v0 { D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0::C0(v3,v4) => { d_54bcba3d562a98540c4f4f84d132b173bf4776981a8aeeeae4b8bc29b7575eaf(&(match &(match v3.as_ref() { D_5571f1e59a4a30cab3dca86ab26ca51294b3d64796a4f552070d94ba62fe494b::C0(v5,v6) => { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::clone(v5)) } }) { D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(v7) => { (v7.as_ref()).clone() } }),v2) } }}

use serde_json::{Value as Json,json};
mod portable{
//! Shared, representation-independent snapshot codec. This module also ships
//! verbatim in generated applications; it has no AST/evaluator dependency.
use num_bigint::{BigInt, Sign};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::cmp::Ordering;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Schema {
    Unit,
    Bool,
    U32,
    U64,
    I32,
    F32,
    Vector(Box<Schema>, u8),
    Int,
    String,
    Id,
    Record(Vec<(String, Schema)>),
    Enum(Vec<String>),
    List(Box<Schema>),
    Option(Box<Schema>),
    Result(Box<Schema>, Box<Schema>),
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Layout {
    pub program: [u8; 32],
    pub schema: [u8; 32],
    pub roots: Vec<(String, Schema, Schema)>,
    pub events: Vec<(String, Schema)>,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Event {
    pub commit: u64,
    pub position: u64,
    pub channel: usize,
    pub value: Value,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Logical {
    pub version: u64,
    pub tables: Vec<Vec<(Value, Value)>>,
    pub outbox: Vec<Event>,
}
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub bytes: usize,
    pub values: usize,
    pub depth: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            bytes: 64 * 1024 * 1024,
            values: 1_000_000,
            depth: 128,
        }
    }
}
/// Magnitude bound for one exact integer. Decimal conversion is superlinear,
/// so without it a single large Int in a snapshot takes minutes to hours.
pub const MAX_INT_BYTES: usize = 4096;
const MAGIC: &[u8; 8] = b"VLSTATE\0";
const HEADER: usize = 8 + 2 + 2 + 32 + 32 + 8;
type R<T> = Result<T, String>;
fn u64_bytes(out: &mut Vec<u8>, v: u64) {
    out.extend_from_slice(&v.to_le_bytes());
}
fn count(out: &mut Vec<u8>, n: usize) {
    u64_bytes(out, n as u64);
}
fn raw(out: &mut Vec<u8>, b: &[u8]) {
    count(out, b.len());
    out.extend_from_slice(b);
}
fn tag<'a>(v: &'a Value, name: &str) -> R<&'a Value> {
    let o = v.as_object().ok_or("expected tagged object")?;
    if o.len() != 1 {
        return Err("expected exactly one tag".into());
    }
    o.get(name).ok_or("unexpected value tag".into())
}
fn integer(v: &Value) -> R<BigInt> {
    let s = tag(v, "Int")?.as_str().ok_or("expected Int string")?;
    // Every Int within the bound has fewer than 2.41 decimal digits per byte.
    if s.len() > MAX_INT_BYTES * 5 / 2 + 1 {
        return Err("snapshot Int exceeds size limit".into());
    }
    let n = s.parse::<BigInt>().map_err(|_| "invalid Int")?;
    if n.bits() > 8 * MAX_INT_BYTES as u64 {
        return Err("snapshot Int exceeds size limit".into());
    }
    if n.to_string() != s {
        return Err("noncanonical Int".into());
    }
    Ok(n)
}
fn identifier(v: &Value) -> R<u128> {
    let s = v.as_str().ok_or("expected ID")?;
    if s.len() != 32
        || !s
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err("noncanonical ID".into());
    }
    u128::from_str_radix(s, 16).map_err(|e| e.to_string())
}
fn compare(t: &Schema, a: &Value, b: &Value) -> R<Ordering> {
    Ok(match t {
        Schema::I32 => a
            .as_i64()
            .and_then(|n| i32::try_from(n).ok())
            .ok_or("invalid i32 key")?
            .cmp(
                &b.as_i64()
                    .and_then(|n| i32::try_from(n).ok())
                    .ok_or("invalid i32 key")?,
            ),
        Schema::U32 | Schema::U64 => a
            .as_u64()
            .ok_or("invalid key")?
            .cmp(&b.as_u64().ok_or("invalid key")?),
        Schema::String => a
            .as_str()
            .ok_or("invalid key")?
            .as_bytes()
            .cmp(b.as_str().ok_or("invalid key")?.as_bytes()),
        Schema::Id => identifier(a)?.cmp(&identifier(b)?),
        _ => return Err("unsupported snapshot key schema".into()),
    })
}
fn tick(left: &mut usize, depth: usize, limits: Limits) -> R<()> {
    if *left == 0 || depth > limits.depth {
        return Err("snapshot value/depth limit exceeded".into());
    }
    *left -= 1;
    Ok(())
}
fn encode_value(
    t: &Schema,
    v: &Value,
    out: &mut Vec<u8>,
    left: &mut usize,
    depth: usize,
    limits: Limits,
) -> R<()> {
    tick(left, depth, limits)?;
    match t {
        Schema::Unit => {
            if !v.is_null() {
                return Err("expected Unit".into());
            }
        }
        Schema::Bool => out.push(v.as_bool().ok_or("expected Bool")? as u8),
        Schema::U32 => out.extend_from_slice(
            &u32::try_from(v.as_u64().ok_or("expected u32")?)
                .map_err(|_| "u32 overflow")?
                .to_le_bytes(),
        ),
        Schema::U64 => u64_bytes(out, v.as_u64().ok_or("expected u64")?),
        Schema::I32 => out.extend_from_slice(
            &i32::try_from(v.as_i64().ok_or("expected i32")?)
                .map_err(|_| "i32 overflow")?
                .to_le_bytes(),
        ),
        Schema::F32 => {
            let bits = if let Some(b) = v.get("F32Bits") {
                if v.as_object().is_none_or(|o| o.len() != 1) {
                    return Err("expected only F32Bits field".into());
                }
                u32::try_from(b.as_u64().ok_or("expected f32 bits")?)
                    .map_err(|_| "f32 bits overflow")?
            } else {
                let f = v.as_f64().ok_or("expected f32")? as f32;
                if !f.is_finite() {
                    return Err("finite f32 or F32Bits required".into());
                }
                f.to_bits()
            };
            out.extend_from_slice(&bits.to_le_bytes());
        }
        Schema::Vector(inner, n) => {
            if !(2..=4).contains(n)
                || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
            {
                return Err("invalid vector schema".into());
            }
            let xs = v.as_array().ok_or("expected vector")?;
            if xs.len() != *n as usize {
                return Err("vector dimension mismatch".into());
            }
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Int => {
            let n = integer(v)?;
            let (sign, b) = n.to_bytes_le();
            out.push(match sign {
                Sign::NoSign => 0,
                Sign::Plus => 1,
                Sign::Minus => 2,
            });
            if sign == Sign::NoSign {
                raw(out, &[])
            } else {
                raw(out, &b)
            }
        }
        Schema::String => raw(out, v.as_str().ok_or("expected String")?.as_bytes()),
        Schema::Id => out.extend_from_slice(&identifier(v)?.to_le_bytes()),
        Schema::Enum(names) => {
            let s = v.as_str().ok_or("expected enum string")?;
            let index = names
                .iter()
                .position(|n| n == s)
                .ok_or("unknown enum variant")?;
            out.extend_from_slice(&(index as u32).to_le_bytes());
        }
        Schema::Record(fields) => {
            let obj = v.as_object().ok_or("expected record")?;
            if obj.len() != fields.len() {
                return Err("record field mismatch".into());
            }
            for (n, t) in fields {
                encode_value(
                    t,
                    obj.get(n).ok_or("missing record field")?,
                    out,
                    left,
                    depth + 1,
                    limits,
                )?;
            }
        }
        Schema::List(inner) => {
            let xs = v.as_array().ok_or("expected List")?;
            if xs.len() > *left {
                return Err("snapshot value limit exceeded".into());
            }
            count(out, xs.len());
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Option(inner) => {
            if let Ok(x) = tag(v, "Some") {
                out.push(1);
                encode_value(inner, x, out, left, depth + 1, limits)?;
            } else {
                if !tag(v, "None")?.is_null() {
                    return Err("invalid None".into());
                }
                out.push(0);
            }
        }
        Schema::Result(a, b) => {
            if let Ok(x) = tag(v, "Ok") {
                out.push(0);
                encode_value(a, x, out, left, depth + 1, limits)?;
            } else {
                out.push(1);
                encode_value(b, tag(v, "Err")?, out, left, depth + 1, limits)?;
            }
        }
    }
    if out.len() > limits.bytes {
        return Err("snapshot byte limit exceeded".into());
    }
    Ok(())
}
struct Reader<'a> {
    bytes: &'a [u8],
    at: usize,
    left: usize,
    limits: Limits,
}
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> R<&'a [u8]> {
        let end = self.at.checked_add(n).ok_or("snapshot length overflow")?;
        let b = self.bytes.get(self.at..end).ok_or("truncated snapshot")?;
        self.at = end;
        Ok(b)
    }
    fn byte(&mut self) -> R<u8> {
        Ok(self.take(1)?[0])
    }
    fn u32(&mut self) -> R<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn u64(&mut self) -> R<u64> {
        Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
    fn len(&mut self) -> R<usize> {
        usize::try_from(self.u64()?).map_err(|_| "snapshot length not addressable".into())
    }
    fn sequence(&mut self) -> R<usize> {
        let n = self.len()?;
        if n > self.left {
            return Err("snapshot value limit exceeded".into());
        }
        Ok(n)
    }
    fn raw(&mut self) -> R<&'a [u8]> {
        let n = self.len()?;
        self.take(n)
    }
    fn value(&mut self, t: &Schema, depth: usize) -> R<Value> {
        tick(&mut self.left, depth, self.limits)?;
        Ok(match t {
            Schema::Unit => Value::Null,
            Schema::Bool => match self.byte()? {
                0 => json!(false),
                1 => json!(true),
                _ => return Err("invalid Bool tag".into()),
            },
            Schema::U32 => json!(self.u32()?),
            Schema::U64 => json!(self.u64()?),
            Schema::I32 => json!(self.u32()? as i32),
            Schema::F32 => {
                let bits = self.u32()?;
                let f = f32::from_bits(bits);
                if f.is_finite() {
                    json!(f)
                } else {
                    json!({"F32Bits":bits})
                }
            }
            Schema::Vector(inner, n) => {
                if !(2..=4).contains(n)
                    || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
                {
                    return Err("invalid vector schema".into());
                }
                (0..*n)
                    .map(|_| self.value(inner, depth + 1))
                    .collect::<R<Vec<_>>>()?
                    .into()
            }
            Schema::Int => {
                let sign = self.byte()?;
                let bytes = self.raw()?;
                if bytes.len() > MAX_INT_BYTES {
                    return Err("snapshot Int exceeds size limit".into());
                }
                let sign = match sign {
                    0 if bytes.is_empty() => Sign::NoSign,
                    1 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Plus,
                    2 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Minus,
                    _ => return Err("noncanonical signed integer".into()),
                };
                json!({"Int":BigInt::from_bytes_le(sign,bytes).to_string()})
            }
            Schema::String => json!(std::str::from_utf8(self.raw()?).map_err(|_| "invalid UTF-8")?),
            Schema::Id => json!(format!(
                "{:032x}",
                u128::from_le_bytes(self.take(16)?.try_into().unwrap())
            )),
            Schema::Enum(names) => {
                json!(names.get(self.u32()? as usize).ok_or("invalid enum tag")?)
            }
            Schema::Record(fields) => {
                let mut obj = serde_json::Map::new();
                for (n, t) in fields {
                    obj.insert(n.clone(), self.value(t, depth + 1)?);
                }
                Value::Object(obj)
            }
            Schema::List(t) => {
                let n = self.sequence()?;
                let mut xs = Vec::new();
                for _ in 0..n {
                    xs.push(self.value(t, depth + 1)?);
                }
                Value::Array(xs)
            }
            Schema::Option(t) => match self.byte()? {
                0 => json!({"None":null}),
                1 => json!({"Some":self.value(t,depth+1)?}),
                _ => return Err("invalid Option tag".into()),
            },
            Schema::Result(a, b) => match self.byte()? {
                0 => json!({"Ok":self.value(a,depth+1)?}),
                1 => json!({"Err":self.value(b,depth+1)?}),
                _ => return Err("invalid Result tag".into()),
            },
        })
    }
}
fn event_order(e: &Event, version: u64, prior: Option<(u64, u64)>) -> R<()> {
    if e.commit == 0 || e.commit > version || prior.is_some_and(|p| p >= (e.commit, e.position)) {
        return Err("invalid snapshot event sequence".into());
    }
    Ok(())
}
pub fn encode(layout: &Layout, s: &Logical, limits: Limits) -> R<Vec<u8>> {
    if s.tables.len() != layout.roots.len() {
        return Err("snapshot root count mismatch".into());
    }
    let mut out = Vec::new();
    let mut left = limits.values;
    u64_bytes(&mut out, s.version);
    for (rows, (_, kt, vt)) in s.tables.iter().zip(&layout.roots) {
        if rows.len() > left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        count(&mut out, rows.len());
        let mut prior = None;
        for (k, v) in rows {
            if let Some(p) = prior {
                if compare(kt, p, k)? != Ordering::Less {
                    return Err("snapshot keys must be strictly ordered".into());
                }
            }
            encode_value(kt, k, &mut out, &mut left, 0, limits)?;
            encode_value(vt, v, &mut out, &mut left, 0, limits)?;
            prior = Some(k);
        }
    }
    count(&mut out, s.outbox.len());
    let mut prior = None;
    for e in &s.outbox {
        event_order(e, s.version, prior)?;
        let (_, t) = layout
            .events
            .get(e.channel)
            .ok_or("unknown event channel")?;
        u64_bytes(&mut out, e.commit);
        u64_bytes(&mut out, e.position);
        out.extend_from_slice(&(e.channel as u32).to_le_bytes());
        encode_value(t, &e.value, &mut out, &mut left, 0, limits)?;
        prior = Some((e.commit, e.position));
    }
    if HEADER
        .checked_add(out.len())
        .and_then(|n| n.checked_add(32))
        .is_none_or(|n| n > limits.bytes)
    {
        return Err("snapshot byte limit exceeded".into());
    }
    let mut bytes = Vec::new();
    bytes.extend_from_slice(MAGIC);
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&layout.program);
    bytes.extend_from_slice(&layout.schema);
    count(&mut bytes, out.len());
    bytes.extend_from_slice(&out);
    let digest = Sha256::digest(&bytes);
    bytes.extend_from_slice(&digest);
    Ok(bytes)
}
pub fn decode(layout: &Layout, bytes: &[u8], limits: Limits) -> R<Logical> {
    if bytes.len() > limits.bytes || bytes.len() < HEADER + 32 {
        return Err("snapshot byte length invalid".into());
    }
    if &bytes[..8] != MAGIC || bytes[8..12] != [1, 0, 1, 0] {
        return Err("snapshot format or semantics version mismatch".into());
    }
    if bytes[12..44] != layout.program || bytes[44..76] != layout.schema {
        return Err("snapshot program or schema identity mismatch".into());
    }
    let n = usize::try_from(u64::from_le_bytes(bytes[76..84].try_into().unwrap()))
        .map_err(|_| "snapshot length not addressable")?;
    if HEADER.checked_add(n).and_then(|v| v.checked_add(32)) != Some(bytes.len()) {
        return Err("snapshot payload length mismatch".into());
    }
    let end = bytes.len() - 32;
    if Sha256::digest(&bytes[..end]).as_slice() != &bytes[end..] {
        return Err("snapshot integrity check failed".into());
    }
    let mut r = Reader {
        bytes: &bytes[HEADER..end],
        at: 0,
        left: limits.values,
        limits,
    };
    let version = r.u64()?;
    let mut tables = vec![];
    for (_, kt, vt) in &layout.roots {
        let n = r.sequence()?;
        if n > r.left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        let mut rows: Vec<(Value, Value)> = vec![];
        for _ in 0..n {
            let k = r.value(kt, 0)?;
            let v = r.value(vt, 0)?;
            if let Some((prior, _)) = rows.last() {
                if compare(kt, prior, &k)? != Ordering::Less {
                    return Err("duplicate or unordered snapshot key".into());
                }
            }
            rows.push((k, v));
        }
        tables.push(rows);
    }
    let n = r.sequence()?;
    let mut outbox = vec![];
    let mut prior = None;
    for _ in 0..n {
        let commit = r.u64()?;
        let position = r.u64()?;
        let channel = r.u32()? as usize;
        let (_, t) = layout
            .events
            .get(channel)
            .ok_or("unknown snapshot event channel")?;
        let value = r.value(t, 0)?;
        let e = Event {
            commit,
            position,
            channel,
            value,
        };
        event_order(&e, version, prior)?;
        prior = Some((commit, position));
        outbox.push(e);
    }
    if r.at != r.bytes.len() {
        return Err("trailing snapshot payload".into());
    }
    Ok(Logical {
        version,
        tables,
        outbox,
    })
}

}
pub use portable::Limits as SnapshotLimits;
fn snapshot_layout()->portable::Layout{portable::Layout{program:[255, 4, 117, 215, 71, 163, 245, 79, 91, 5, 184, 13, 208, 246, 185, 97, 201, 75, 126, 146, 140, 93, 124, 164, 47, 146, 227, 5, 76, 237, 154, 239],schema:[192, 141, 16, 114, 17, 172, 249, 182, 219, 154, 142, 125, 228, 252, 175, 89, 60, 246, 149, 204, 109, 105, 172, 253, 213, 158, 150, 88, 181, 131, 24, 90],roots:vec![
("Rows".into(),portable::Schema::U64,portable::Schema::U64),
],events:vec![("seen".into(),portable::Schema::U64),
]}}
fn one_tag<'a>(v:&'a Json,_kind:&str)->Result<&'a serde_json::Map<String,Json>,String>{Ok(v.as_object().unwrap())}
fn read_0(v:&Json,d:usize)->Result<bool,String>{Ok(
v.as_bool().unwrap())}
fn write_0(v:&bool,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_1(v:&Json,d:usize)->Result<u64,String>{Ok(
v.as_u64().unwrap())}
fn write_1(v:&u64,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_2(v:&Json,d:usize)->Result<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c,String>{Ok(
{D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0})}
fn write_2(v:&D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c,d:usize)->Result<Json,String>{Ok(
Json::Null)}
fn read_3(v:&Json,d:usize)->Result<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b,String>{Ok(
{let text=v.as_str().unwrap();match text{"Error.Failed"=>D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0,_=>unreachable!("caller enum precondition")}})}
fn write_3(v:&D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b,d:usize)->Result<Json,String>{Ok(
match v{D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0=>json!("Error.Failed"),})}
fn read_4(v:&Json,d:usize)->Result<D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(read_1(x,d+1)?)}else{D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0}})}
fn write_4(v:&D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02,d:usize)->Result<Json,String>{Ok(
match v{D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C0=>json!({"None":null}),D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02::C1(x)=>json!({"Some":write_1(x,d+1)?})})}
fn read_5(v:&Json,d:usize)->Result<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f,String>{Ok(
{let xs=one_tag(v,"Result")?;if let Some(x)=xs.get("Ok"){D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::new(read_2(x,d+1)?))}else{let x=xs.get("Err").unwrap();D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::new(read_3(x,d+1)?))}})}
fn write_5(v:&D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f,d:usize)->Result<Json,String>{Ok(
match v{D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(x)=>json!({"Ok":write_2(x,d+1)?}),D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(x)=>json!({"Err":write_3(x,d+1)?})})}
fn logical_from_tables(tables:&[Vec<(Json,Json)>])->Result<D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d,String>{if tables.len()!=1{return Err("representation table count mismatch".into())}
let rows=&tables[0];let mut root0=D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0;for (key,row) in rows.iter().rev(){root0=D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(read_1(key,0)?,read_1(row,0)?,std::sync::Arc::new(root0));}
Ok(D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(root0)))}
fn logical_tables(state:&D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d)->Result<Vec<Vec<(Json,Json)>>,String>{let D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(r0)=state;
let mut rows0=vec![];let mut cursor=r0.as_ref();loop{match cursor{D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0=>break,D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C1(key,value,tail)=>{rows0.push((write_1(key,0)?,write_1(value,0)?));cursor=tail.as_ref();}}}
Ok(vec![rows0])}
fn logical_events(events:&D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de)->Result<Vec<(usize,Json)>,String>{let mut cursor=events;let mut out=vec![];loop{match cursor{D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C0=>break,D_9357bd5ffdfa39fb71893752143f6f3e82211764ea6e2ebecc32db45603f47de::C1(event,tail)=>{let value=match event.as_ref(){
D_d341df03e65ba87aece99a3f59cb1b883b5170ca37b2b72dc08f925ef2e88cf6::C0(value)=>(0,write_1(value,0)?),
};out.push(value);cursor=tail.as_ref();}}}Ok(out)}
pub use portable::Event;
pub struct Outcome<T>{pub result:T,pub committed:bool,pub version:u64,pub events:Vec<Event>}
pub struct OutcomeView<'a,T>{pub result:T,pub committed:bool,pub version:u64,pub events:&'a[Event]}
impl<T> OutcomeView<'_,T>{pub fn into_owned(self)->Outcome<T>{Outcome{result:self.result,committed:self.committed,version:self.version,events:self.events.to_vec()}}}
pub struct State{physical:D_3e3ae5893f983699684c661a34d34cffac8f569720981bbc5a577ab153ad6fe0,version:u64,outbox:Vec<portable::Event>,layout:portable::Layout}
impl State{
// CALLER CONTRACT: arguments must have the declared types and canonical values.
// No runtime type validation. Malformed input may panic, trap or corrupt state.
pub fn new()->Result<Self,String>{let logical=D_477c777e40eab12cb541a19959c187d141eddd3559fd8c916be58fc4a5c6588d::C0(std::sync::Arc::new(D_77ca894c927fc1c282d3be50a38614e6e26294539ec386e9dc469a45188b4807::C0));Ok(Self{physical:f_2c9eab9de06ed39b8eb124ed389b986b7e05e8893bcc7ea19c93bc31f2f35f39(&logical),version:0,outbox:vec![],layout:snapshot_layout()})}
pub fn restore(bytes:&[u8])->Result<Self,String>{let layout=snapshot_layout();let saved=portable::decode(&layout,bytes,SnapshotLimits::default())?;let logical=logical_from_tables(&saved.tables)?;Ok(Self{physical:f_2c9eab9de06ed39b8eb124ed389b986b7e05e8893bcc7ea19c93bc31f2f35f39(&logical),version:saved.version,outbox:saved.outbox,layout})}
pub fn checkpoint(&self)->Result<Vec<u8>,String>{let logical=f_925c36680abdc0c03563189333b337cfd21aeed464b48af0ce0bb3216d4fc211(&(self.physical));portable::encode(&self.layout,&portable::Logical{version:self.version,tables:logical_tables(&logical)?,outbox:self.outbox.clone()},SnapshotLimits::default())}
pub fn version(&self)->u64{self.version}
pub fn outbox_json(&self)->Json{Json::Array(self.outbox.iter().map(|e|json!({"commit":e.commit,"position":e.position,"channel":self.layout.events[e.channel].0,"value":e.value})).collect())}
pub fn acknowledge_through(&mut self,commit:u64,position:u64){self.outbox.retain(|e|(e.commit,e.position)>(commit,position));}
pub fn query_get(&self,a0:u64)->D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02{q_c300c32f81d32f6873540ab0ca914988c5b3e4b1e768b172bc87ab17ab53d26a(&(self.physical),self.version,a0)}
pub fn invoke_view_put(&mut self,a0:u64,a1:u64)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=f_cd11f970081e39840e1cc3a9500589d375bd7e174626d29021b086d90eaea308(&(self.physical),self.version,a0,a1);let observed=f_2263b5eb9269f7e9a75e38f9673c49ba70d5bc3a902f72d6aeb6be842b416532(&(executed));let next=f_77b52735ece6d80a4a3cb661508a41a39f770e5a55e0e3c14dcacee6c9a65682(&(executed));
let(result,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_replace(&mut self,a0:u64,a1:u64,a2:bool)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=f_bba9c18cac7538bc1012fae0186904dd64a249ed17ec5d2c36a62b59cf4f1126(&(self.physical),self.version,a0,a1,a2);let observed=f_2263b5eb9269f7e9a75e38f9673c49ba70d5bc3a902f72d6aeb6be842b416532(&(executed));let next=f_77b52735ece6d80a4a3cb661508a41a39f770e5a55e0e3c14dcacee6c9a65682(&(executed));
let(result,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_erase(&mut self,a0:u64,a1:bool)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=f_19fd6a05c9451d80f3a04bda53f317bd8d95d561982b61c433ccebe072735f19(&(self.physical),self.version,a0,a1);let observed=f_2263b5eb9269f7e9a75e38f9673c49ba70d5bc3a902f72d6aeb6be842b416532(&(executed));let next=f_77b52735ece6d80a4a3cb661508a41a39f770e5a55e0e3c14dcacee6c9a65682(&(executed));
let(result,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_zero(&mut self,)->Result<OutcomeView<'_,D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,String>{
let executed=f_e55487630754135401796588e05c6372eee03487f5fec4dcb6448144c068365e(&(self.physical),self.version);let observed=f_98245cdc846e03122c9a93db472402fbdad8ffcba4a5a33eaf802b87b1b34bca(&(executed));let next=f_866da10b06d58c18bf6296decb365e59a596e066c99fec92cfed3eee3677a73b(&(executed));
let(result,committed,version,events)=match &observed{D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_get(&mut self,a0:u64)->Result<OutcomeView<'_,D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,String>{
let result=q_c300c32f81d32f6873540ab0ca914988c5b3e4b1e768b172bc87ab17ab53d26a(&(self.physical),self.version,a0);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_view_one(&mut self,)->Result<OutcomeView<'_,D_aa14bc35dba77b8cf23390ef63c403282076d7395f8b1e08fe723e0442331e02>,String>{
let executed=f_7c02c3910178043903d3a4605b0d5855de61b0c0294406085101d5fa6413dce8(&(self.physical),self.version);let observed=f_5c73f995f9cff667f3e888ecac8a8df68dffa3985201a12d5fd98fe10205e9c0(&(executed));let next=f_866da10b06d58c18bf6296decb365e59a596e066c99fec92cfed3eee3677a73b(&(executed));
let(result,committed,version,events)=match &observed{D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_json(&mut self,name:&str,args:&Json)->Result<Json,String>{match name{
"put"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_1(&xs[1],0)?;
let executed=f_cd11f970081e39840e1cc3a9500589d375bd7e174626d29021b086d90eaea308(&(self.physical),self.version,a0,a1);
let observed=f_2263b5eb9269f7e9a75e38f9673c49ba70d5bc3a902f72d6aeb6be842b416532(&(executed));let next=f_77b52735ece6d80a4a3cb661508a41a39f770e5a55e0e3c14dcacee6c9a65682(&(executed));let(reply,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_5(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"replace"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_1(&xs[1],0)?;
let a2=read_0(&xs[2],0)?;
let executed=f_bba9c18cac7538bc1012fae0186904dd64a249ed17ec5d2c36a62b59cf4f1126(&(self.physical),self.version,a0,a1,a2);
let observed=f_2263b5eb9269f7e9a75e38f9673c49ba70d5bc3a902f72d6aeb6be842b416532(&(executed));let next=f_77b52735ece6d80a4a3cb661508a41a39f770e5a55e0e3c14dcacee6c9a65682(&(executed));let(reply,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_5(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"erase"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_0(&xs[1],0)?;
let executed=f_19fd6a05c9451d80f3a04bda53f317bd8d95d561982b61c433ccebe072735f19(&(self.physical),self.version,a0,a1);
let observed=f_2263b5eb9269f7e9a75e38f9673c49ba70d5bc3a902f72d6aeb6be842b416532(&(executed));let next=f_77b52735ece6d80a4a3cb661508a41a39f770e5a55e0e3c14dcacee6c9a65682(&(executed));let(reply,committed,version,events)=match &observed{D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_7e3de0e05b03ab7ebd9951a381d1559a6333c92d9086509b366f2646f4959953::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_5(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"zero"=>{let xs=args.as_array().unwrap();
let executed=f_e55487630754135401796588e05c6372eee03487f5fec4dcb6448144c068365e(&(self.physical),self.version);
let observed=f_98245cdc846e03122c9a93db472402fbdad8ffcba4a5a33eaf802b87b1b34bca(&(executed));let next=f_866da10b06d58c18bf6296decb365e59a596e066c99fec92cfed3eee3677a73b(&(executed));let(reply,committed,version,events)=match &observed{D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_4(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"get"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let reply=q_c300c32f81d32f6873540ab0ca914988c5b3e4b1e768b172bc87ab17ab53d26a(&(self.physical),self.version,a0);let result=write_4(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
"one"=>{let xs=args.as_array().unwrap();
let executed=f_7c02c3910178043903d3a4605b0d5855de61b0c0294406085101d5fa6413dce8(&(self.physical),self.version);
let observed=f_5c73f995f9cff667f3e888ecac8a8df68dffa3985201a12d5fd98fe10205e9c0(&(executed));let next=f_866da10b06d58c18bf6296decb365e59a596e066c99fec92cfed3eee3677a73b(&(executed));let(reply,committed,version,events)=match &observed{D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_ee13e42c75b135dfd11e2faca05f4a73928a264f121170c3deefe54d14ef0994::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_4(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
_=>Err(format!("unknown action {name}"))}}}
