// ink-definition-rust-v1: checked bodies; Rust/backend are trusted.
#![allow(non_camel_case_types, non_snake_case, non_upper_case_globals, dead_code, unused_variables, unused_parens, unused_unsafe, improper_ctypes_definitions)]
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c { C0(std::sync::Arc<D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f>,std::sync::Arc<D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f>,std::sync::Arc<D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8>) }
fn d_04210576c3a626734f0564d48fcbe38306a24f3c475fb09584eba71037b9dbee(v0: &D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f,v1: &D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f,v2: &D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8) -> D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b { match v0 { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 => { D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0 },D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v4,v5) => { match v1 { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 => { D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0 },D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v7,v8) => { match v2 { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C0 => { D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0 },D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C1(v10,v11) => { D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C1(*v4,std::sync::Arc::new(D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(*v7,*v10)),std::sync::Arc::new(d_04210576c3a626734f0564d48fcbe38306a24f3c475fb09584eba71037b9dbee(v5.as_ref(),v8.as_ref(),v11.as_ref()))) } } } } } } }
fn d_05b35f718738a8ff16105c92cffce3f1d433e94c2dbe5fa10ec8c03a412887cc(v12: &D_c6e18934f89a127a9ca97e28120f7b4dae0b2f72fc9e5e62da89cb11ac5e349f) -> D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3 { match v12 { D_c6e18934f89a127a9ca97e28120f7b4dae0b2f72fc9e5e62da89cb11ac5e349f::C0(v13,v14) => { (v13.as_ref()).clone() } } }
fn d_0b982fd2b6391928763d719a50612950cee49583e3934abdf7d18bb0e619e8c1(v15: &D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f,v16: u64,v17: &D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35) -> D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f { match v15 { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 => { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 },D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v19,v20) => { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(*v19,std::sync::Arc::new(d_0b982fd2b6391928763d719a50612950cee49583e3934abdf7d18bb0e619e8c1(v20.as_ref(),v16,v17))) } } }
fn d_0bf83650bcfdbd190544da387ad02598ad70554e40e83072712ed13471990e6e(v21: &D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v22: u64,v23: u64,v24: u64,v25: bool,v26: bool) -> D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc { match v21 { D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(v27) => { if match &(d_dcfdd3b0c06c31a484ff265ec23c28b4882f59271cec70cfab00818d3631da64(v27.as_ref(),v23)) { D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C0 => { false },D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C1(v28) => { true } } { if match &(d_dcfdd3b0c06c31a484ff265ec23c28b4882f59271cec70cfab00818d3631da64(v27.as_ref(),v23)) { D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C0 => { false },D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C1(v29) => { true } } { if v26 { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v27))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C0(std::sync::Arc::clone({static v31:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v31.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v30:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v30.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v22,std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(v27.as_ref())))),std::sync::Arc::clone({static v32:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v32.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))) } else { if ((v22) == (18446744073709551615u64)) { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v27))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C1(1u64,v22,std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(v27.as_ref()))))))) } else { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::new(d_ddefedd1864a6e83371d34240fea38b7725293012b229843de5781a298026179(v27.as_ref(),v23,&(D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(v24,v25)))))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C0(std::sync::Arc::clone({static v34:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v34.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v33:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v33.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v22).wrapping_add(1u64),std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(&(d_ddefedd1864a6e83371d34240fea38b7725293012b229843de5781a298026179(v27.as_ref(),v23,&(D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(v24,v25)))))))),std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C1(std::sync::Arc::new(D_8b7223f44550c57238cd939cbe116ed7e80287159078a8661acaa3dbfebbf710::C0(v24)),std::sync::Arc::clone({static v35:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v35.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))))) } } } else { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v27))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C1(2u64,v22,std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(v27.as_ref()))))))) } } else { if match &(d_dcfdd3b0c06c31a484ff265ec23c28b4882f59271cec70cfab00818d3631da64(v27.as_ref(),v23)) { D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C0 => { false },D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C1(v36) => { true } } { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v27))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C1(2u64,v22,std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(v27.as_ref()))))))) } else { if v26 { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v27))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C0(std::sync::Arc::clone({static v38:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v38.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v37:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v37.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v22,std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(v27.as_ref())))),std::sync::Arc::clone({static v39:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v39.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))) } else { if ((v22) == (18446744073709551615u64)) { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v27))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C1(1u64,v22,std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(v27.as_ref()))))))) } else { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::new(d_ccb1711c3e25d0868083165d7620ce564c9ca47805cafb833623a724d7ca3e0e(v27.as_ref(),v23,&(D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(v24,v25)))))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C0(std::sync::Arc::clone({static v41:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v41.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v40:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v40.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v22).wrapping_add(1u64),std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(&(d_ccb1711c3e25d0868083165d7620ce564c9ca47805cafb833623a724d7ca3e0e(v27.as_ref(),v23,&(D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(v24,v25)))))))),std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C1(std::sync::Arc::new(D_8b7223f44550c57238cd939cbe116ed7e80287159078a8661acaa3dbfebbf710::C0(v24)),std::sync::Arc::clone({static v42:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v42.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))))) } } } } } } }
fn d_1bf9f324ff14604a8479d92d0673ba7817f4f4db1459a278dd4c7e8bbc61b030(v43: &D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b) -> D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(std::sync::Arc::new(d_d7af8c79e0b2e74f8bed6f57b1be109c542ce849b7058e7cc0920fe7ffd2318d(v43)),std::sync::Arc::new(d_54ce1d308199f05b8ce4d57e0d83f1d8a78bc4fc0eb916e29d4fdbfe8302baea(v43)),std::sync::Arc::new(d_607aed6a8c97238fb692f2f3e31c8eb256eceae93b9a64591e2c9e17a9c4c915(v43))) }
fn d_31471f9a4bece4081d730de7b0ac9e047a15c3a8e89ec14bf27a66d4a289e337(v44: &D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f,v45: &D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f,v46: u64) -> D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f { match v44 { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 => { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 },D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v48,v49) => { match v45 { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 => { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 },D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v51,v52) => { if ((v46) == (*v48)) { d_31471f9a4bece4081d730de7b0ac9e047a15c3a8e89ec14bf27a66d4a289e337(v49.as_ref(),v52.as_ref(),v46) } else { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(*v51,std::sync::Arc::new(d_31471f9a4bece4081d730de7b0ac9e047a15c3a8e89ec14bf27a66d4a289e337(v49.as_ref(),v52.as_ref(),v46))) } } } } } }
fn d_3c35f145ded0923d7489d9f90b1273aabcc977066dcb675aefcaa105a3598349(v53: &D_799ec20899b773b740ef6c0a75a1d3303d5ba6c40f2c7f7a485fc84eeead1fa1) -> D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3 { match v53 { D_799ec20899b773b740ef6c0a75a1d3303d5ba6c40f2c7f7a485fc84eeead1fa1::C0(v54,v55) => { (v54.as_ref()).clone() } } }
fn d_3d6065c942df749ac13dcef8bd1153164b17230a5d04b9bba383a34374a44f56(v56: &D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f,v57: &D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8,v58: u64) -> D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8 { match v56 { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 => { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C0 },D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v60,v61) => { match v57 { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C0 => { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C0 },D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C1(v63,v64) => { if ((v58) == (*v60)) { d_3d6065c942df749ac13dcef8bd1153164b17230a5d04b9bba383a34374a44f56(v61.as_ref(),v64.as_ref(),v58) } else { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C1(*v63,std::sync::Arc::new(d_3d6065c942df749ac13dcef8bd1153164b17230a5d04b9bba383a34374a44f56(v61.as_ref(),v64.as_ref(),v58))) } } } } } }
fn d_3e928e5104313d2a5e33ccd583b4bcf8cc8db73d365ae76945595fe4d2100e24(v65: &D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f,v66: u64,v67: &D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35) -> D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f { match v65 { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 => { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v66,std::sync::Arc::clone({static v68:std::sync::OnceLock<std::sync::Arc<D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f>>=std::sync::OnceLock::new();v68.get_or_init(||std::sync::Arc::new(D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0))})) },D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v69,v70) => { if ((v66) < (*v69)) { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v66,std::sync::Arc::new((v65).clone())) } else { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(*v69,std::sync::Arc::new(d_3e928e5104313d2a5e33ccd583b4bcf8cc8db73d365ae76945595fe4d2100e24(v70.as_ref(),v66,v67))) } } } }
fn d_3f40bf8e14929e7ff60751467f1e58a11267fc524c5a652ed4c6d441bc71b543(v71: &D_799ec20899b773b740ef6c0a75a1d3303d5ba6c40f2c7f7a485fc84eeead1fa1) -> D_548ce20936d42cf48446b970822fdf70e1d3d401f99a81d4590eca85e61e7186 { match v71 { D_799ec20899b773b740ef6c0a75a1d3303d5ba6c40f2c7f7a485fc84eeead1fa1::C0(v72,v73) => { (v73.as_ref()).clone() } } }
fn d_4b466800a1bb5271ff1a5afb1ea70dde74ce8d17c311f1661c291ed15e4e91d5(v74: &D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f,v75: &D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8,v76: u64,v77: &D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35) -> D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8 { match v74 { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 => { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C0 },D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v79,v80) => { match v75 { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C0 => { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C0 },D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C1(v82,v83) => { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C1(if ((v76) == (*v79)) { d_be8c528bc87f74b73c5d91151691079cbe732be12c52750beac54cc343f7b3a6(v77) } else { *v82 },std::sync::Arc::new(d_4b466800a1bb5271ff1a5afb1ea70dde74ce8d17c311f1661c291ed15e4e91d5(v80.as_ref(),v83.as_ref(),v76,v77))) } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_548ce20936d42cf48446b970822fdf70e1d3d401f99a81d4590eca85e61e7186 { C0(std::sync::Arc<D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c>,bool,u64,std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>,std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>),C1(u64,u64,std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>) }
fn d_54ce1d308199f05b8ce4d57e0d83f1d8a78bc4fc0eb916e29d4fdbfe8302baea(v84: &D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b) -> D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f { match v84 { D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0 => { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 },D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C1(v86,v87,v88) => { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(d_dfc3b394ffbe2c7eab413f96ebd4e7ee0d19974c6fbeeb165c3922e4b1b5af6b(v87.as_ref()),std::sync::Arc::new(d_54ce1d308199f05b8ce4d57e0d83f1d8a78bc4fc0eb916e29d4fdbfe8302baea(v88.as_ref()))) } } }
fn d_57d512bd0bff4fe10cabe2410394a99131b5be1a3ec4000856b63de656a8ca8b(v89: &D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5) -> D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c { match v89 { D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5::C0 => { D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c::C0 },D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5::C1(v91,v92) => { D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c::C1((match v91.as_ref() { D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(v93,v94) => { *v93 } }).wrapping_add(17u64),std::sync::Arc::new(d_57d512bd0bff4fe10cabe2410394a99131b5be1a3ec4000856b63de656a8ca8b(v92.as_ref()))) } } }
fn d_607aed6a8c97238fb692f2f3e31c8eb256eceae93b9a64591e2c9e17a9c4c915(v95: &D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b) -> D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8 { match v95 { D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0 => { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C0 },D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C1(v97,v98,v99) => { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C1(d_be8c528bc87f74b73c5d91151691079cbe732be12c52750beac54cc343f7b3a6(v98.as_ref()),std::sync::Arc::new(d_607aed6a8c97238fb692f2f3e31c8eb256eceae93b9a64591e2c9e17a9c4c915(v99.as_ref()))) } } }
fn d_629f7a4ad515d70fc0e7f3068e39a6243d0bfbcd4c4dbf0f1319a93213bfa0d7(v100: &D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b) -> D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5 { match v100 { D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0 => { D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5::C0 },D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C1(v102,v103,v104) => { D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5::C1(std::sync::Arc::clone(v103),std::sync::Arc::new(d_629f7a4ad515d70fc0e7f3068e39a6243d0bfbcd4c4dbf0f1319a93213bfa0d7(v104.as_ref()))) } } }
fn d_62c2a7ea9c4c0a744a1ff5a102c2d1b905e643da0435c33af3f7e8c78d13eb7a(v105: &D_ab9393c95fe3f75a805a10badd9b1bb7d63a9264d7cf119d64112d4103f50497) -> D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3 { match v105 { D_ab9393c95fe3f75a805a10badd9b1bb7d63a9264d7cf119d64112d4103f50497::C0(v106,v107) => { (v106.as_ref()).clone() } } }
fn d_67c53b78dd64ef73225ce6d130855043fd3c3d135aab02945783f38847ba0ef3(v108: &D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc) -> D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3 { match v108 { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(v109,v110) => { (v109.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6 { C0(std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,bool,u64,std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>,std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>),C1(u64,u64,std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8 { C0,C1(bool,std::sync::Arc<D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8>) }
impl D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_799ec20899b773b740ef6c0a75a1d3303d5ba6c40f2c7f7a485fc84eeead1fa1 { C0(std::sync::Arc<D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3>,std::sync::Arc<D_548ce20936d42cf48446b970822fdf70e1d3d401f99a81d4590eca85e61e7186>) }
fn d_7af037a656d4292fe754db65086906e11e98c60a674eedb8f4316f39833149c2(v111: &D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9) -> D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3 { match v111 { D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(v112) => { D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::new(d_1bf9f324ff14604a8479d92d0673ba7817f4f4db1459a278dd4c7e8bbc61b030(v112.as_ref()))) } } }
fn d_7da4832b1664ff7eeaa1fdb35bd4917cd9f6214d95e09712c4f80cc551e6beab(v113: &D_c6e18934f89a127a9ca97e28120f7b4dae0b2f72fc9e5e62da89cb11ac5e349f) -> D_99f53aeb8f076c38706bff6d0b9aa5c255348d00cad3af6266f9b39b0e3dad71 { match v113 { D_c6e18934f89a127a9ca97e28120f7b4dae0b2f72fc9e5e62da89cb11ac5e349f::C0(v114,v115) => { (v115.as_ref()).clone() } } }
fn d_805ade521daff0c649689bf56487a91a251edd7500bbb4dd5459563052b3199e(v116: &D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v117: u64) -> D_799ec20899b773b740ef6c0a75a1d3303d5ba6c40f2c7f7a485fc84eeead1fa1 { match v116 { D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(v118) => { D_799ec20899b773b740ef6c0a75a1d3303d5ba6c40f2c7f7a485fc84eeead1fa1::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v118))),std::sync::Arc::new(D_548ce20936d42cf48446b970822fdf70e1d3d401f99a81d4590eca85e61e7186::C0(std::sync::Arc::new(d_fb22abcd0a943f146b954e22a72ad1551b4326d9c11092d2e28d3fb1034d53e3(&(d_629f7a4ad515d70fc0e7f3068e39a6243d0bfbcd4c4dbf0f1319a93213bfa0d7(&(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(v118.as_ref())))))),false,v117,std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(v118.as_ref())))),std::sync::Arc::clone({static v119:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v119.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc { C0(std::sync::Arc<D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3>,std::sync::Arc<D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8 { C0,C1(std::sync::Arc<D_8b7223f44550c57238cd939cbe116ed7e80287159078a8661acaa3dbfebbf710>,std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>) }
impl D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_8b7223f44550c57238cd939cbe116ed7e80287159078a8661acaa3dbfebbf710 { C0(u64) }
fn d_8d9310644fb06564c4c73eeab228c2d0605b9ece24c12e77b619743ded78adeb(v120: &D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f,v121: u64) -> D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f { match v120 { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 => { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 },D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v123,v124) => { if ((v121) == (*v123)) { d_8d9310644fb06564c4c73eeab228c2d0605b9ece24c12e77b619743ded78adeb(v124.as_ref(),v121) } else { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(*v123,std::sync::Arc::new(d_8d9310644fb06564c4c73eeab228c2d0605b9ece24c12e77b619743ded78adeb(v124.as_ref(),v121))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c { C0,C1(u64,std::sync::Arc<D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c>) }
impl D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f { C0(std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>),C1(std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35 { C0(u64,bool) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5 { C0,C1(std::sync::Arc<D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35>,std::sync::Arc<D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5>) }
impl D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_992aadd990d6ea3445c428be3d6cdfdfd91818aff21808181c84cfc921134d5b(v125: &D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v126: u64,v127: u64) -> D_ab9393c95fe3f75a805a10badd9b1bb7d63a9264d7cf119d64112d4103f50497 { match v125 { D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(v128) => { D_ab9393c95fe3f75a805a10badd9b1bb7d63a9264d7cf119d64112d4103f50497::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v128))),std::sync::Arc::new(D_b1a5d8158cf96a21a2a63a286973fe921db4ef11e83e74610785a82d7f8ee982::C0(std::sync::Arc::new(d_dcfdd3b0c06c31a484ff265ec23c28b4882f59271cec70cfab00818d3631da64(v128.as_ref(),v127)),false,v126,std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(v128.as_ref())))),std::sync::Arc::clone({static v129:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v129.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_99f53aeb8f076c38706bff6d0b9aa5c255348d00cad3af6266f9b39b0e3dad71 { C0(std::sync::Arc<D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c>,bool,u64,std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>,std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>),C1(u64,u64,std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>) }
fn d_a3259e858c597b768ef00e518f0baaa43c2d3969b96a39f77854db2b6dba0add(v130: &D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f,v131: &D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f,v132: u64,v133: &D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35) -> D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f { match v130 { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 => { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 },D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v135,v136) => { match v131 { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 => { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 },D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v138,v139) => { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(if ((v132) == (*v135)) { d_dfc3b394ffbe2c7eab413f96ebd4e7ee0d19974c6fbeeb165c3922e4b1b5af6b(v133) } else { *v138 },std::sync::Arc::new(d_a3259e858c597b768ef00e518f0baaa43c2d3969b96a39f77854db2b6dba0add(v136.as_ref(),v139.as_ref(),v132,v133))) } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ab9393c95fe3f75a805a10badd9b1bb7d63a9264d7cf119d64112d4103f50497 { C0(std::sync::Arc<D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3>,std::sync::Arc<D_b1a5d8158cf96a21a2a63a286973fe921db4ef11e83e74610785a82d7f8ee982>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_b1a5d8158cf96a21a2a63a286973fe921db4ef11e83e74610785a82d7f8ee982 { C0(std::sync::Arc<D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca>,bool,u64,std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>,std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>),C1(u64,u64,std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>) }
fn d_b5a1f2bc26b2b94fd3de0a34f9a110eb4cffef63d034aaee8b7e63733b797250(v140: &D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v141: u64) -> D_c6e18934f89a127a9ca97e28120f7b4dae0b2f72fc9e5e62da89cb11ac5e349f { match v140 { D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(v142) => { D_c6e18934f89a127a9ca97e28120f7b4dae0b2f72fc9e5e62da89cb11ac5e349f::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v142))),std::sync::Arc::new(D_99f53aeb8f076c38706bff6d0b9aa5c255348d00cad3af6266f9b39b0e3dad71::C0(std::sync::Arc::new(d_57d512bd0bff4fe10cabe2410394a99131b5be1a3ec4000856b63de656a8ca8b(&(d_d559f58d28d03530e320cc77eb04c44c8ad2622236e76349e7c46f0c2f6a393b(&(d_629f7a4ad515d70fc0e7f3068e39a6243d0bfbcd4c4dbf0f1319a93213bfa0d7(&(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(v142.as_ref())))))))),false,v141,std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(v142.as_ref())))),std::sync::Arc::clone({static v143:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v143.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c { C0 }
impl D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_be8c528bc87f74b73c5d91151691079cbe732be12c52750beac54cc343f7b3a6(v144: &D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35) -> bool { match v144 { D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(v145,v146) => { *v146 } } }
fn d_c46fbad8dbeff2e42d83cfff4fc0fe8157d5781258e95ee57e7f6d93e4858a4d(v147: &D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3) -> D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9 { match v147 { D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(v148) => { D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(v148.as_ref()))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3 { C0(std::sync::Arc<D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b { C0 }
impl D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_c6e18934f89a127a9ca97e28120f7b4dae0b2f72fc9e5e62da89cb11ac5e349f { C0(std::sync::Arc<D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3>,std::sync::Arc<D_99f53aeb8f076c38706bff6d0b9aa5c255348d00cad3af6266f9b39b0e3dad71>) }
fn d_ccb1711c3e25d0868083165d7620ce564c9ca47805cafb833623a724d7ca3e0e(v149: &D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c,v150: u64,v151: &D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35) -> D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c { match v149 { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v152,v153,v154) => { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(std::sync::Arc::new(d_3e928e5104313d2a5e33ccd583b4bcf8cc8db73d365ae76945595fe4d2100e24(v152.as_ref(),v150,v151)),std::sync::Arc::new(d_f75221ea73295120a9ac05ecc65e965025ec2daa68f6d05b8f6c4c24277d2d02(v152.as_ref(),v153.as_ref(),v150,v151)),std::sync::Arc::new(d_e395f848e68fdc190b517a4cf9a073fb650629e6a07088bb92e6be3ef3c74a2b(v152.as_ref(),v154.as_ref(),v150,v151))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f { C0,C1(u64,std::sync::Arc<D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f>) }
impl D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_d559f58d28d03530e320cc77eb04c44c8ad2622236e76349e7c46f0c2f6a393b(v155: &D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5) -> D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5 { match v155 { D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5::C0 => { D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5::C0 },D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5::C1(v157,v158) => { if match v157.as_ref() { D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(v159,v160) => { *v160 } } { D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5::C1(std::sync::Arc::clone(v157),std::sync::Arc::new(d_d559f58d28d03530e320cc77eb04c44c8ad2622236e76349e7c46f0c2f6a393b(v158.as_ref()))) } else { d_d559f58d28d03530e320cc77eb04c44c8ad2622236e76349e7c46f0c2f6a393b(v158.as_ref()) } } } }
fn d_d7af8c79e0b2e74f8bed6f57b1be109c542ce849b7058e7cc0920fe7ffd2318d(v161: &D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b) -> D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f { match v161 { D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0 => { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 },D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C1(v163,v164,v165) => { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(*v163,std::sync::Arc::new(d_d7af8c79e0b2e74f8bed6f57b1be109c542ce849b7058e7cc0920fe7ffd2318d(v165.as_ref()))) } } }
fn d_dcfdd3b0c06c31a484ff265ec23c28b4882f59271cec70cfab00818d3631da64(v166: &D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c,v167: u64) -> D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca { match v166 { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v168,v169,v170) => { d_f8911165da36a0c55d91155abe7089769076a5b44749b9858cbdf6afc15bedbd(v168.as_ref(),v169.as_ref(),v170.as_ref(),v167) } } }
fn d_ddefedd1864a6e83371d34240fea38b7725293012b229843de5781a298026179(v171: &D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c,v172: u64,v173: &D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35) -> D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c { match v171 { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v174,v175,v176) => { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(std::sync::Arc::new(d_0b982fd2b6391928763d719a50612950cee49583e3934abdf7d18bb0e619e8c1(v174.as_ref(),v172,v173)),std::sync::Arc::new(d_a3259e858c597b768ef00e518f0baaa43c2d3969b96a39f77854db2b6dba0add(v174.as_ref(),v175.as_ref(),v172,v173)),std::sync::Arc::new(d_4b466800a1bb5271ff1a5afb1ea70dde74ce8d17c311f1661c291ed15e4e91d5(v174.as_ref(),v176.as_ref(),v172,v173))) } } }
fn d_dfc3b394ffbe2c7eab413f96ebd4e7ee0d19974c6fbeeb165c3922e4b1b5af6b(v177: &D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35) -> u64 { match v177 { D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(v178,v179) => { *v178 } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b { C0,C1(u64,std::sync::Arc<D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35>,std::sync::Arc<D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b>) }
impl D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_e395f848e68fdc190b517a4cf9a073fb650629e6a07088bb92e6be3ef3c74a2b(v180: &D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f,v181: &D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8,v182: u64,v183: &D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35) -> D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8 { match v180 { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 => { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C1(d_be8c528bc87f74b73c5d91151691079cbe732be12c52750beac54cc343f7b3a6(v183),std::sync::Arc::clone({static v184:std::sync::OnceLock<std::sync::Arc<D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8>>=std::sync::OnceLock::new();v184.get_or_init(||std::sync::Arc::new(D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C0))})) },D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v185,v186) => { match v181 { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C0 => { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C0 },D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C1(v188,v189) => { if ((v182) < (*v185)) { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C1(d_be8c528bc87f74b73c5d91151691079cbe732be12c52750beac54cc343f7b3a6(v183),std::sync::Arc::new((v181).clone())) } else { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C1(*v188,std::sync::Arc::new(d_e395f848e68fdc190b517a4cf9a073fb650629e6a07088bb92e6be3ef3c74a2b(v186.as_ref(),v189.as_ref(),v182,v183))) } } } } } }
fn d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(v190: &D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c) -> D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b { match v190 { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v191,v192,v193) => { d_04210576c3a626734f0564d48fcbe38306a24f3c475fb09584eba71037b9dbee(v191.as_ref(),v192.as_ref(),v193.as_ref()) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9 { C0(std::sync::Arc<D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b>) }
fn d_ea5f0d65802654041bcf8bd1f21a1d65f2fd57c86271a947922917f28dc19d04(v194: &D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c,v195: u64) -> D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c { match v194 { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v196,v197,v198) => { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(std::sync::Arc::new(d_8d9310644fb06564c4c73eeab228c2d0605b9ece24c12e77b619743ded78adeb(v196.as_ref(),v195)),std::sync::Arc::new(d_31471f9a4bece4081d730de7b0ac9e047a15c3a8e89ec14bf27a66d4a289e337(v196.as_ref(),v197.as_ref(),v195)),std::sync::Arc::new(d_3d6065c942df749ac13dcef8bd1153164b17230a5d04b9bba383a34374a44f56(v196.as_ref(),v198.as_ref(),v195))) } } }
fn d_f1e255729a1d1cf2b57a9974f4b6e6e1a48272e2de6bbfdc9e3a3d20a2557bcd(v199: &D_ab9393c95fe3f75a805a10badd9b1bb7d63a9264d7cf119d64112d4103f50497) -> D_b1a5d8158cf96a21a2a63a286973fe921db4ef11e83e74610785a82d7f8ee982 { match v199 { D_ab9393c95fe3f75a805a10badd9b1bb7d63a9264d7cf119d64112d4103f50497::C0(v200,v201) => { (v201.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca { C0,C1(std::sync::Arc<D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35>) }
fn d_f6623c7ce0f53190d8640cf021f9f92cc3da4f2c085f631391e7bdfea9ed8c35(v202: &D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc) -> D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6 { match v202 { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(v203,v204) => { (v204.as_ref()).clone() } } }
fn d_f75221ea73295120a9ac05ecc65e965025ec2daa68f6d05b8f6c4c24277d2d02(v205: &D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f,v206: &D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f,v207: u64,v208: &D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35) -> D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f { match v205 { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 => { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(d_dfc3b394ffbe2c7eab413f96ebd4e7ee0d19974c6fbeeb165c3922e4b1b5af6b(v208),std::sync::Arc::clone({static v209:std::sync::OnceLock<std::sync::Arc<D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f>>=std::sync::OnceLock::new();v209.get_or_init(||std::sync::Arc::new(D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0))})) },D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v210,v211) => { match v206 { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 => { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 },D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v213,v214) => { if ((v207) < (*v210)) { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(d_dfc3b394ffbe2c7eab413f96ebd4e7ee0d19974c6fbeeb165c3922e4b1b5af6b(v208),std::sync::Arc::new((v206).clone())) } else { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(*v213,std::sync::Arc::new(d_f75221ea73295120a9ac05ecc65e965025ec2daa68f6d05b8f6c4c24277d2d02(v211.as_ref(),v214.as_ref(),v207,v208))) } } } } } }
fn d_f8911165da36a0c55d91155abe7089769076a5b44749b9858cbdf6afc15bedbd(v215: &D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f,v216: &D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f,v217: &D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8,v218: u64) -> D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca { match v215 { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 => { D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C0 },D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v220,v221) => { match v216 { D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C0 => { D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C0 },D_d0dcb99b200b274146b8b79a01379380c1a30da88487166558a9cb57176bf43f::C1(v223,v224) => { match v217 { D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C0 => { D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C0 },D_6a32837ba6ac976605970ace421efa95799f7a6451ff0b8b413834e54f58b5c8::C1(v226,v227) => { if ((v218) == (*v220)) { D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C1(std::sync::Arc::new(D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(*v223,*v226))) } else { d_f8911165da36a0c55d91155abe7089769076a5b44749b9858cbdf6afc15bedbd(v221.as_ref(),v224.as_ref(),v227.as_ref(),v218) } } } } } } } }
fn d_fa33e6b732bef6b27b165fa24638af475965821471e7112dcae8eaa93ffb07fb(v228: &D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v229: u64,v230: u64,v231: bool) -> D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc { match v228 { D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(v232) => { if v231 { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v232))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C0(std::sync::Arc::clone({static v234:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v234.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v233:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v233.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v229,std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(v232.as_ref())))),std::sync::Arc::clone({static v235:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v235.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))) } else { if ((v229) == (18446744073709551615u64)) { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v232))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C1(1u64,v229,std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(v232.as_ref()))))))) } else { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::new(d_ea5f0d65802654041bcf8bd1f21a1d65f2fd57c86271a947922917f28dc19d04(v232.as_ref(),v230)))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C0(std::sync::Arc::clone({static v237:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v237.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v236:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v236.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v229).wrapping_add(1u64),std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(d_e5b7dc3a9d275c88156116089daf248cd072ded229ced5fc9bc2d37525690ca2(&(d_ea5f0d65802654041bcf8bd1f21a1d65f2fd57c86271a947922917f28dc19d04(v232.as_ref(),v230)))))),std::sync::Arc::clone({static v238:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v238.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))) } } } } }
fn d_fb22abcd0a943f146b954e22a72ad1551b4326d9c11092d2e28d3fb1034d53e3(v239: &D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5) -> D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c { match v239 { D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5::C0 => { D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c::C0 },D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5::C1(v241,v242) => { D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c::C1(match v241.as_ref() { D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(v243,v244) => { *v243 } },std::sync::Arc::new(d_fb22abcd0a943f146b954e22a72ad1551b4326d9c11092d2e28d3fb1034d53e3(v242.as_ref()))) } } }
pub fn f_05b35f718738a8ff16105c92cffce3f1d433e94c2dbe5fa10ec8c03a412887cc(v245: &D_c6e18934f89a127a9ca97e28120f7b4dae0b2f72fc9e5e62da89cb11ac5e349f) -> D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3 { d_05b35f718738a8ff16105c92cffce3f1d433e94c2dbe5fa10ec8c03a412887cc(v245) }
pub fn f_0bf83650bcfdbd190544da387ad02598ad70554e40e83072712ed13471990e6e(v246: &D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v247: u64,v248: u64,v249: u64,v250: bool,v251: bool) -> D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc { d_0bf83650bcfdbd190544da387ad02598ad70554e40e83072712ed13471990e6e(v246,v247,v248,v249,v250,v251) }
pub fn f_3c35f145ded0923d7489d9f90b1273aabcc977066dcb675aefcaa105a3598349(v252: &D_799ec20899b773b740ef6c0a75a1d3303d5ba6c40f2c7f7a485fc84eeead1fa1) -> D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3 { d_3c35f145ded0923d7489d9f90b1273aabcc977066dcb675aefcaa105a3598349(v252) }
pub fn f_3f40bf8e14929e7ff60751467f1e58a11267fc524c5a652ed4c6d441bc71b543(v253: &D_799ec20899b773b740ef6c0a75a1d3303d5ba6c40f2c7f7a485fc84eeead1fa1) -> D_548ce20936d42cf48446b970822fdf70e1d3d401f99a81d4590eca85e61e7186 { d_3f40bf8e14929e7ff60751467f1e58a11267fc524c5a652ed4c6d441bc71b543(v253) }
pub fn f_62c2a7ea9c4c0a744a1ff5a102c2d1b905e643da0435c33af3f7e8c78d13eb7a(v254: &D_ab9393c95fe3f75a805a10badd9b1bb7d63a9264d7cf119d64112d4103f50497) -> D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3 { d_62c2a7ea9c4c0a744a1ff5a102c2d1b905e643da0435c33af3f7e8c78d13eb7a(v254) }
pub fn f_67c53b78dd64ef73225ce6d130855043fd3c3d135aab02945783f38847ba0ef3(v255: &D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc) -> D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3 { d_67c53b78dd64ef73225ce6d130855043fd3c3d135aab02945783f38847ba0ef3(v255) }
pub fn f_7af037a656d4292fe754db65086906e11e98c60a674eedb8f4316f39833149c2(v256: &D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9) -> D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3 { d_7af037a656d4292fe754db65086906e11e98c60a674eedb8f4316f39833149c2(v256) }
pub fn f_7da4832b1664ff7eeaa1fdb35bd4917cd9f6214d95e09712c4f80cc551e6beab(v257: &D_c6e18934f89a127a9ca97e28120f7b4dae0b2f72fc9e5e62da89cb11ac5e349f) -> D_99f53aeb8f076c38706bff6d0b9aa5c255348d00cad3af6266f9b39b0e3dad71 { d_7da4832b1664ff7eeaa1fdb35bd4917cd9f6214d95e09712c4f80cc551e6beab(v257) }
pub fn f_805ade521daff0c649689bf56487a91a251edd7500bbb4dd5459563052b3199e(v258: &D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v259: u64) -> D_799ec20899b773b740ef6c0a75a1d3303d5ba6c40f2c7f7a485fc84eeead1fa1 { d_805ade521daff0c649689bf56487a91a251edd7500bbb4dd5459563052b3199e(v258,v259) }
pub fn f_992aadd990d6ea3445c428be3d6cdfdfd91818aff21808181c84cfc921134d5b(v260: &D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v261: u64,v262: u64) -> D_ab9393c95fe3f75a805a10badd9b1bb7d63a9264d7cf119d64112d4103f50497 { d_992aadd990d6ea3445c428be3d6cdfdfd91818aff21808181c84cfc921134d5b(v260,v261,v262) }
pub fn f_b5a1f2bc26b2b94fd3de0a34f9a110eb4cffef63d034aaee8b7e63733b797250(v263: &D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v264: u64) -> D_c6e18934f89a127a9ca97e28120f7b4dae0b2f72fc9e5e62da89cb11ac5e349f { d_b5a1f2bc26b2b94fd3de0a34f9a110eb4cffef63d034aaee8b7e63733b797250(v263,v264) }
pub fn f_c46fbad8dbeff2e42d83cfff4fc0fe8157d5781258e95ee57e7f6d93e4858a4d(v265: &D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3) -> D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9 { d_c46fbad8dbeff2e42d83cfff4fc0fe8157d5781258e95ee57e7f6d93e4858a4d(v265) }
pub fn f_f1e255729a1d1cf2b57a9974f4b6e6e1a48272e2de6bbfdc9e3a3d20a2557bcd(v266: &D_ab9393c95fe3f75a805a10badd9b1bb7d63a9264d7cf119d64112d4103f50497) -> D_b1a5d8158cf96a21a2a63a286973fe921db4ef11e83e74610785a82d7f8ee982 { d_f1e255729a1d1cf2b57a9974f4b6e6e1a48272e2de6bbfdc9e3a3d20a2557bcd(v266) }
pub fn f_f6623c7ce0f53190d8640cf021f9f92cc3da4f2c085f631391e7bdfea9ed8c35(v267: &D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc) -> D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6 { d_f6623c7ce0f53190d8640cf021f9f92cc3da4f2c085f631391e7bdfea9ed8c35(v267) }
pub fn f_fa33e6b732bef6b27b165fa24638af475965821471e7112dcae8eaa93ffb07fb(v268: &D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v269: u64,v270: u64,v271: bool) -> D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc { d_fa33e6b732bef6b27b165fa24638af475965821471e7112dcae8eaa93ffb07fb(v268,v269,v270,v271) }
fn q_805ade521daff0c649689bf56487a91a251edd7500bbb4dd5459563052b3199e(v0:&D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v1:u64)->D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c{match v0 { D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(v2) => { d_fb22abcd0a943f146b954e22a72ad1551b4326d9c11092d2e28d3fb1034d53e3(&(d_629f7a4ad515d70fc0e7f3068e39a6243d0bfbcd4c4dbf0f1319a93213bfa0d7(&(match v2.as_ref() { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v3,v4,v5) => { d_04210576c3a626734f0564d48fcbe38306a24f3c475fb09584eba71037b9dbee(v3.as_ref(),v4.as_ref(),v5.as_ref()) } })))) } }}
fn q_992aadd990d6ea3445c428be3d6cdfdfd91818aff21808181c84cfc921134d5b(v0:&D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v1:u64,v2:u64)->D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca{match v0 { D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(v3) => { match v3.as_ref() { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v4,v5,v6) => { d_f8911165da36a0c55d91155abe7089769076a5b44749b9858cbdf6afc15bedbd(v4.as_ref(),v5.as_ref(),v6.as_ref(),v2) } } } }}
fn q_b5a1f2bc26b2b94fd3de0a34f9a110eb4cffef63d034aaee8b7e63733b797250(v0:&D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v1:u64)->D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c{match v0 { D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(v2) => { d_57d512bd0bff4fe10cabe2410394a99131b5be1a3ec4000856b63de656a8ca8b(&(d_d559f58d28d03530e320cc77eb04c44c8ad2622236e76349e7c46f0c2f6a393b(&(d_629f7a4ad515d70fc0e7f3068e39a6243d0bfbcd4c4dbf0f1319a93213bfa0d7(&(match v2.as_ref() { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v3,v4,v5) => { d_04210576c3a626734f0564d48fcbe38306a24f3c475fb09584eba71037b9dbee(v3.as_ref(),v4.as_ref(),v5.as_ref()) } })))))) } }}
fn t_0bf83650bcfdbd190544da387ad02598ad70554e40e83072712ed13471990e6e(v0:&D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v1:u64,v2:u64,v3:u64,v4:bool,v5:bool)->D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc{match v0 { D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(v6) => { if match &(match v6.as_ref() { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v7,v8,v9) => { d_f8911165da36a0c55d91155abe7089769076a5b44749b9858cbdf6afc15bedbd(v7.as_ref(),v8.as_ref(),v9.as_ref(),v2) } }) { D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C0 => { false },D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C1(v10) => { true } } { if match &(match v6.as_ref() { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v11,v12,v13) => { d_f8911165da36a0c55d91155abe7089769076a5b44749b9858cbdf6afc15bedbd(v11.as_ref(),v12.as_ref(),v13.as_ref(),v2) } }) { D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C0 => { false },D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C1(v14) => { true } } { if v5 { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v6))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C0(std::sync::Arc::clone({static v16:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v16.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v15:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v15.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v1,std::sync::Arc::clone({static v18:std::sync::OnceLock<std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>>=std::sync::OnceLock::new();v18.get_or_init(||std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::clone({static v17:std::sync::OnceLock<std::sync::Arc<D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b>>=std::sync::OnceLock::new();v17.get_or_init(||std::sync::Arc::new(D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0))}))))}),std::sync::Arc::clone({static v19:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v19.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))) } else { if ((v1) == (18446744073709551615u64)) { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v6))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C1(1u64,v1,std::sync::Arc::clone({static v21:std::sync::OnceLock<std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>>=std::sync::OnceLock::new();v21.get_or_init(||std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::clone({static v20:std::sync::OnceLock<std::sync::Arc<D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b>>=std::sync::OnceLock::new();v20.get_or_init(||std::sync::Arc::new(D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0))}))))})))) } else { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::new(match v6.as_ref() { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v22,v23,v24) => { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(std::sync::Arc::new(d_0b982fd2b6391928763d719a50612950cee49583e3934abdf7d18bb0e619e8c1(v22.as_ref(),v2,&(D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(v3,v4)))),std::sync::Arc::new(d_a3259e858c597b768ef00e518f0baaa43c2d3969b96a39f77854db2b6dba0add(v22.as_ref(),v23.as_ref(),v2,&(D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(v3,v4)))),std::sync::Arc::new(d_4b466800a1bb5271ff1a5afb1ea70dde74ce8d17c311f1661c291ed15e4e91d5(v22.as_ref(),v24.as_ref(),v2,&(D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(v3,v4))))) } }))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C0(std::sync::Arc::clone({static v26:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v26.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v25:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v25.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v1).wrapping_add(1u64),std::sync::Arc::clone({static v28:std::sync::OnceLock<std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>>=std::sync::OnceLock::new();v28.get_or_init(||std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::clone({static v27:std::sync::OnceLock<std::sync::Arc<D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b>>=std::sync::OnceLock::new();v27.get_or_init(||std::sync::Arc::new(D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0))}))))}),std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C1(std::sync::Arc::new(D_8b7223f44550c57238cd939cbe116ed7e80287159078a8661acaa3dbfebbf710::C0(v3)),std::sync::Arc::clone({static v29:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v29.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))))) } } } else { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v6))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C1(2u64,v1,std::sync::Arc::clone({static v31:std::sync::OnceLock<std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>>=std::sync::OnceLock::new();v31.get_or_init(||std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::clone({static v30:std::sync::OnceLock<std::sync::Arc<D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b>>=std::sync::OnceLock::new();v30.get_or_init(||std::sync::Arc::new(D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0))}))))})))) } } else { if match &(match v6.as_ref() { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v32,v33,v34) => { d_f8911165da36a0c55d91155abe7089769076a5b44749b9858cbdf6afc15bedbd(v32.as_ref(),v33.as_ref(),v34.as_ref(),v2) } }) { D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C0 => { false },D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C1(v35) => { true } } { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v6))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C1(2u64,v1,std::sync::Arc::clone({static v37:std::sync::OnceLock<std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>>=std::sync::OnceLock::new();v37.get_or_init(||std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::clone({static v36:std::sync::OnceLock<std::sync::Arc<D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b>>=std::sync::OnceLock::new();v36.get_or_init(||std::sync::Arc::new(D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0))}))))})))) } else { if v5 { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v6))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C0(std::sync::Arc::clone({static v39:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v39.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v38:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v38.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v1,std::sync::Arc::clone({static v41:std::sync::OnceLock<std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>>=std::sync::OnceLock::new();v41.get_or_init(||std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::clone({static v40:std::sync::OnceLock<std::sync::Arc<D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b>>=std::sync::OnceLock::new();v40.get_or_init(||std::sync::Arc::new(D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0))}))))}),std::sync::Arc::clone({static v42:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v42.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))) } else { if ((v1) == (18446744073709551615u64)) { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v6))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C1(1u64,v1,std::sync::Arc::clone({static v44:std::sync::OnceLock<std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>>=std::sync::OnceLock::new();v44.get_or_init(||std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::clone({static v43:std::sync::OnceLock<std::sync::Arc<D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b>>=std::sync::OnceLock::new();v43.get_or_init(||std::sync::Arc::new(D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0))}))))})))) } else { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::new(match v6.as_ref() { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v45,v46,v47) => { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(std::sync::Arc::new(d_3e928e5104313d2a5e33ccd583b4bcf8cc8db73d365ae76945595fe4d2100e24(v45.as_ref(),v2,&(D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(v3,v4)))),std::sync::Arc::new(d_f75221ea73295120a9ac05ecc65e965025ec2daa68f6d05b8f6c4c24277d2d02(v45.as_ref(),v46.as_ref(),v2,&(D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(v3,v4)))),std::sync::Arc::new(d_e395f848e68fdc190b517a4cf9a073fb650629e6a07088bb92e6be3ef3c74a2b(v45.as_ref(),v47.as_ref(),v2,&(D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(v3,v4))))) } }))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C0(std::sync::Arc::clone({static v49:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v49.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v48:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v48.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v1).wrapping_add(1u64),std::sync::Arc::clone({static v51:std::sync::OnceLock<std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>>=std::sync::OnceLock::new();v51.get_or_init(||std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::clone({static v50:std::sync::OnceLock<std::sync::Arc<D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b>>=std::sync::OnceLock::new();v50.get_or_init(||std::sync::Arc::new(D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0))}))))}),std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C1(std::sync::Arc::new(D_8b7223f44550c57238cd939cbe116ed7e80287159078a8661acaa3dbfebbf710::C0(v3)),std::sync::Arc::clone({static v52:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v52.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))))) } } } } } }}
fn t_805ade521daff0c649689bf56487a91a251edd7500bbb4dd5459563052b3199e(v0:&D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v1:u64)->D_799ec20899b773b740ef6c0a75a1d3303d5ba6c40f2c7f7a485fc84eeead1fa1{match v0 { D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(v2) => { D_799ec20899b773b740ef6c0a75a1d3303d5ba6c40f2c7f7a485fc84eeead1fa1::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v2))),std::sync::Arc::new(D_548ce20936d42cf48446b970822fdf70e1d3d401f99a81d4590eca85e61e7186::C0(std::sync::Arc::new(d_fb22abcd0a943f146b954e22a72ad1551b4326d9c11092d2e28d3fb1034d53e3(&(d_629f7a4ad515d70fc0e7f3068e39a6243d0bfbcd4c4dbf0f1319a93213bfa0d7(&(match v2.as_ref() { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v3,v4,v5) => { d_04210576c3a626734f0564d48fcbe38306a24f3c475fb09584eba71037b9dbee(v3.as_ref(),v4.as_ref(),v5.as_ref()) } }))))),false,v1,std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0))}))))}),std::sync::Arc::clone({static v8:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v8.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))) } }}
fn t_992aadd990d6ea3445c428be3d6cdfdfd91818aff21808181c84cfc921134d5b(v0:&D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v1:u64,v2:u64)->D_ab9393c95fe3f75a805a10badd9b1bb7d63a9264d7cf119d64112d4103f50497{match v0 { D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(v3) => { D_ab9393c95fe3f75a805a10badd9b1bb7d63a9264d7cf119d64112d4103f50497::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v3))),std::sync::Arc::new(D_b1a5d8158cf96a21a2a63a286973fe921db4ef11e83e74610785a82d7f8ee982::C0(std::sync::Arc::new(match v3.as_ref() { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v4,v5,v6) => { d_f8911165da36a0c55d91155abe7089769076a5b44749b9858cbdf6afc15bedbd(v4.as_ref(),v5.as_ref(),v6.as_ref(),v2) } }),false,v1,std::sync::Arc::clone({static v8:std::sync::OnceLock<std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>>=std::sync::OnceLock::new();v8.get_or_init(||std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0))}))))}),std::sync::Arc::clone({static v9:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v9.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))) } }}
fn t_b5a1f2bc26b2b94fd3de0a34f9a110eb4cffef63d034aaee8b7e63733b797250(v0:&D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v1:u64)->D_c6e18934f89a127a9ca97e28120f7b4dae0b2f72fc9e5e62da89cb11ac5e349f{match v0 { D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(v2) => { D_c6e18934f89a127a9ca97e28120f7b4dae0b2f72fc9e5e62da89cb11ac5e349f::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v2))),std::sync::Arc::new(D_99f53aeb8f076c38706bff6d0b9aa5c255348d00cad3af6266f9b39b0e3dad71::C0(std::sync::Arc::new(d_57d512bd0bff4fe10cabe2410394a99131b5be1a3ec4000856b63de656a8ca8b(&(d_d559f58d28d03530e320cc77eb04c44c8ad2622236e76349e7c46f0c2f6a393b(&(d_629f7a4ad515d70fc0e7f3068e39a6243d0bfbcd4c4dbf0f1319a93213bfa0d7(&(match v2.as_ref() { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v3,v4,v5) => { d_04210576c3a626734f0564d48fcbe38306a24f3c475fb09584eba71037b9dbee(v3.as_ref(),v4.as_ref(),v5.as_ref()) } }))))))),false,v1,std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0))}))))}),std::sync::Arc::clone({static v8:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v8.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))) } }}
fn t_fa33e6b732bef6b27b165fa24638af475965821471e7112dcae8eaa93ffb07fb(v0:&D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,v1:u64,v2:u64,v3:bool)->D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc{match v0 { D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(v4) => { if v3 { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C0(std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))))}),false,v1,std::sync::Arc::clone({static v8:std::sync::OnceLock<std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>>=std::sync::OnceLock::new();v8.get_or_init(||std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::clone({static v7:std::sync::OnceLock<std::sync::Arc<D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b>>=std::sync::OnceLock::new();v7.get_or_init(||std::sync::Arc::new(D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0))}))))}),std::sync::Arc::clone({static v9:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v9.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))) } else { if ((v1) == (18446744073709551615u64)) { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::clone(v4))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C1(1u64,v1,std::sync::Arc::clone({static v11:std::sync::OnceLock<std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>>=std::sync::OnceLock::new();v11.get_or_init(||std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::clone({static v10:std::sync::OnceLock<std::sync::Arc<D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b>>=std::sync::OnceLock::new();v10.get_or_init(||std::sync::Arc::new(D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0))}))))})))) } else { D_835ee8ee342a212900f7e90aff7aa2ed161772d59a80156d41a45dba35ba6bcc::C0(std::sync::Arc::new(D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3::C0(std::sync::Arc::new(match v4.as_ref() { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(v12,v13,v14) => { D_005a1f443c8d7f4b953061059b3d7d7ac3f8b9be8073ef746ac9de0ae80aab4c::C0(std::sync::Arc::new(d_8d9310644fb06564c4c73eeab228c2d0605b9ece24c12e77b619743ded78adeb(v12.as_ref(),v2)),std::sync::Arc::new(d_31471f9a4bece4081d730de7b0ac9e047a15c3a8e89ec14bf27a66d4a289e337(v12.as_ref(),v13.as_ref(),v2)),std::sync::Arc::new(d_3d6065c942df749ac13dcef8bd1153164b17230a5d04b9bba383a34374a44f56(v12.as_ref(),v14.as_ref(),v2))) } }))),std::sync::Arc::new(D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C0(std::sync::Arc::clone({static v16:std::sync::OnceLock<std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>>=std::sync::OnceLock::new();v16.get_or_init(||std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v15:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v15.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))))}),true,(v1).wrapping_add(1u64),std::sync::Arc::clone({static v18:std::sync::OnceLock<std::sync::Arc<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9>>=std::sync::OnceLock::new();v18.get_or_init(||std::sync::Arc::new(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::clone({static v17:std::sync::OnceLock<std::sync::Arc<D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b>>=std::sync::OnceLock::new();v17.get_or_init(||std::sync::Arc::new(D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0))}))))}),std::sync::Arc::clone({static v19:std::sync::OnceLock<std::sync::Arc<D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8>>=std::sync::OnceLock::new();v19.get_or_init(||std::sync::Arc::new(D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0))})))) } } } }}

use serde_json::{Value as Json,json};
mod portable{
//! Shared, representation-independent snapshot codec. This module also ships
//! verbatim in generated applications; it has no AST/evaluator dependency.
use num_bigint::{BigInt, Sign};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::cmp::Ordering;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Schema {
    Unit,
    Bool,
    U32,
    U64,
    I32,
    F32,
    Vector(Box<Schema>, u8),
    Int,
    String,
    Id,
    Record(Vec<(String, Schema)>),
    Enum(Vec<String>),
    List(Box<Schema>),
    Option(Box<Schema>),
    Result(Box<Schema>, Box<Schema>),
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Layout {
    pub program: [u8; 32],
    pub schema: [u8; 32],
    pub roots: Vec<(String, Schema, Schema)>,
    pub events: Vec<(String, Schema)>,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Event {
    pub commit: u64,
    pub position: u64,
    pub channel: usize,
    pub value: Value,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Logical {
    pub version: u64,
    pub tables: Vec<Vec<(Value, Value)>>,
    pub outbox: Vec<Event>,
}
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub bytes: usize,
    pub values: usize,
    pub depth: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            bytes: 64 * 1024 * 1024,
            values: 1_000_000,
            depth: 128,
        }
    }
}
/// Magnitude bound for one exact integer. Decimal conversion is superlinear,
/// so without it a single large Int in a snapshot takes minutes to hours.
pub const MAX_INT_BYTES: usize = 4096;
const MAGIC: &[u8; 8] = b"VLSTATE\0";
const HEADER: usize = 8 + 2 + 2 + 32 + 32 + 8;
type R<T> = Result<T, String>;
fn u64_bytes(out: &mut Vec<u8>, v: u64) {
    out.extend_from_slice(&v.to_le_bytes());
}
fn count(out: &mut Vec<u8>, n: usize) {
    u64_bytes(out, n as u64);
}
fn raw(out: &mut Vec<u8>, b: &[u8]) {
    count(out, b.len());
    out.extend_from_slice(b);
}
fn tag<'a>(v: &'a Value, name: &str) -> R<&'a Value> {
    let o = v.as_object().ok_or("expected tagged object")?;
    if o.len() != 1 {
        return Err("expected exactly one tag".into());
    }
    o.get(name).ok_or("unexpected value tag".into())
}
fn integer(v: &Value) -> R<BigInt> {
    let s = tag(v, "Int")?.as_str().ok_or("expected Int string")?;
    // Every Int within the bound has fewer than 2.41 decimal digits per byte.
    if s.len() > MAX_INT_BYTES * 5 / 2 + 1 {
        return Err("snapshot Int exceeds size limit".into());
    }
    let n = s.parse::<BigInt>().map_err(|_| "invalid Int")?;
    if n.bits() > 8 * MAX_INT_BYTES as u64 {
        return Err("snapshot Int exceeds size limit".into());
    }
    if n.to_string() != s {
        return Err("noncanonical Int".into());
    }
    Ok(n)
}
fn identifier(v: &Value) -> R<u128> {
    let s = v.as_str().ok_or("expected ID")?;
    if s.len() != 32
        || !s
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err("noncanonical ID".into());
    }
    u128::from_str_radix(s, 16).map_err(|e| e.to_string())
}
fn compare(t: &Schema, a: &Value, b: &Value) -> R<Ordering> {
    Ok(match t {
        Schema::I32 => a
            .as_i64()
            .and_then(|n| i32::try_from(n).ok())
            .ok_or("invalid i32 key")?
            .cmp(
                &b.as_i64()
                    .and_then(|n| i32::try_from(n).ok())
                    .ok_or("invalid i32 key")?,
            ),
        Schema::U32 | Schema::U64 => a
            .as_u64()
            .ok_or("invalid key")?
            .cmp(&b.as_u64().ok_or("invalid key")?),
        Schema::String => a
            .as_str()
            .ok_or("invalid key")?
            .as_bytes()
            .cmp(b.as_str().ok_or("invalid key")?.as_bytes()),
        Schema::Id => identifier(a)?.cmp(&identifier(b)?),
        _ => return Err("unsupported snapshot key schema".into()),
    })
}
fn tick(left: &mut usize, depth: usize, limits: Limits) -> R<()> {
    if *left == 0 || depth > limits.depth {
        return Err("snapshot value/depth limit exceeded".into());
    }
    *left -= 1;
    Ok(())
}
fn encode_value(
    t: &Schema,
    v: &Value,
    out: &mut Vec<u8>,
    left: &mut usize,
    depth: usize,
    limits: Limits,
) -> R<()> {
    tick(left, depth, limits)?;
    match t {
        Schema::Unit => {
            if !v.is_null() {
                return Err("expected Unit".into());
            }
        }
        Schema::Bool => out.push(v.as_bool().ok_or("expected Bool")? as u8),
        Schema::U32 => out.extend_from_slice(
            &u32::try_from(v.as_u64().ok_or("expected u32")?)
                .map_err(|_| "u32 overflow")?
                .to_le_bytes(),
        ),
        Schema::U64 => u64_bytes(out, v.as_u64().ok_or("expected u64")?),
        Schema::I32 => out.extend_from_slice(
            &i32::try_from(v.as_i64().ok_or("expected i32")?)
                .map_err(|_| "i32 overflow")?
                .to_le_bytes(),
        ),
        Schema::F32 => {
            let bits = if let Some(b) = v.get("F32Bits") {
                if v.as_object().is_none_or(|o| o.len() != 1) {
                    return Err("expected only F32Bits field".into());
                }
                u32::try_from(b.as_u64().ok_or("expected f32 bits")?)
                    .map_err(|_| "f32 bits overflow")?
            } else {
                let f = v.as_f64().ok_or("expected f32")? as f32;
                if !f.is_finite() {
                    return Err("finite f32 or F32Bits required".into());
                }
                f.to_bits()
            };
            out.extend_from_slice(&bits.to_le_bytes());
        }
        Schema::Vector(inner, n) => {
            if !(2..=4).contains(n)
                || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
            {
                return Err("invalid vector schema".into());
            }
            let xs = v.as_array().ok_or("expected vector")?;
            if xs.len() != *n as usize {
                return Err("vector dimension mismatch".into());
            }
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Int => {
            let n = integer(v)?;
            let (sign, b) = n.to_bytes_le();
            out.push(match sign {
                Sign::NoSign => 0,
                Sign::Plus => 1,
                Sign::Minus => 2,
            });
            if sign == Sign::NoSign {
                raw(out, &[])
            } else {
                raw(out, &b)
            }
        }
        Schema::String => raw(out, v.as_str().ok_or("expected String")?.as_bytes()),
        Schema::Id => out.extend_from_slice(&identifier(v)?.to_le_bytes()),
        Schema::Enum(names) => {
            let s = v.as_str().ok_or("expected enum string")?;
            let index = names
                .iter()
                .position(|n| n == s)
                .ok_or("unknown enum variant")?;
            out.extend_from_slice(&(index as u32).to_le_bytes());
        }
        Schema::Record(fields) => {
            let obj = v.as_object().ok_or("expected record")?;
            if obj.len() != fields.len() {
                return Err("record field mismatch".into());
            }
            for (n, t) in fields {
                encode_value(
                    t,
                    obj.get(n).ok_or("missing record field")?,
                    out,
                    left,
                    depth + 1,
                    limits,
                )?;
            }
        }
        Schema::List(inner) => {
            let xs = v.as_array().ok_or("expected List")?;
            if xs.len() > *left {
                return Err("snapshot value limit exceeded".into());
            }
            count(out, xs.len());
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Option(inner) => {
            if let Ok(x) = tag(v, "Some") {
                out.push(1);
                encode_value(inner, x, out, left, depth + 1, limits)?;
            } else {
                if !tag(v, "None")?.is_null() {
                    return Err("invalid None".into());
                }
                out.push(0);
            }
        }
        Schema::Result(a, b) => {
            if let Ok(x) = tag(v, "Ok") {
                out.push(0);
                encode_value(a, x, out, left, depth + 1, limits)?;
            } else {
                out.push(1);
                encode_value(b, tag(v, "Err")?, out, left, depth + 1, limits)?;
            }
        }
    }
    if out.len() > limits.bytes {
        return Err("snapshot byte limit exceeded".into());
    }
    Ok(())
}
struct Reader<'a> {
    bytes: &'a [u8],
    at: usize,
    left: usize,
    limits: Limits,
}
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> R<&'a [u8]> {
        let end = self.at.checked_add(n).ok_or("snapshot length overflow")?;
        let b = self.bytes.get(self.at..end).ok_or("truncated snapshot")?;
        self.at = end;
        Ok(b)
    }
    fn byte(&mut self) -> R<u8> {
        Ok(self.take(1)?[0])
    }
    fn u32(&mut self) -> R<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn u64(&mut self) -> R<u64> {
        Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
    fn len(&mut self) -> R<usize> {
        usize::try_from(self.u64()?).map_err(|_| "snapshot length not addressable".into())
    }
    fn sequence(&mut self) -> R<usize> {
        let n = self.len()?;
        if n > self.left {
            return Err("snapshot value limit exceeded".into());
        }
        Ok(n)
    }
    fn raw(&mut self) -> R<&'a [u8]> {
        let n = self.len()?;
        self.take(n)
    }
    fn value(&mut self, t: &Schema, depth: usize) -> R<Value> {
        tick(&mut self.left, depth, self.limits)?;
        Ok(match t {
            Schema::Unit => Value::Null,
            Schema::Bool => match self.byte()? {
                0 => json!(false),
                1 => json!(true),
                _ => return Err("invalid Bool tag".into()),
            },
            Schema::U32 => json!(self.u32()?),
            Schema::U64 => json!(self.u64()?),
            Schema::I32 => json!(self.u32()? as i32),
            Schema::F32 => {
                let bits = self.u32()?;
                let f = f32::from_bits(bits);
                if f.is_finite() {
                    json!(f)
                } else {
                    json!({"F32Bits":bits})
                }
            }
            Schema::Vector(inner, n) => {
                if !(2..=4).contains(n)
                    || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
                {
                    return Err("invalid vector schema".into());
                }
                (0..*n)
                    .map(|_| self.value(inner, depth + 1))
                    .collect::<R<Vec<_>>>()?
                    .into()
            }
            Schema::Int => {
                let sign = self.byte()?;
                let bytes = self.raw()?;
                if bytes.len() > MAX_INT_BYTES {
                    return Err("snapshot Int exceeds size limit".into());
                }
                let sign = match sign {
                    0 if bytes.is_empty() => Sign::NoSign,
                    1 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Plus,
                    2 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Minus,
                    _ => return Err("noncanonical signed integer".into()),
                };
                json!({"Int":BigInt::from_bytes_le(sign,bytes).to_string()})
            }
            Schema::String => json!(std::str::from_utf8(self.raw()?).map_err(|_| "invalid UTF-8")?),
            Schema::Id => json!(format!(
                "{:032x}",
                u128::from_le_bytes(self.take(16)?.try_into().unwrap())
            )),
            Schema::Enum(names) => {
                json!(names.get(self.u32()? as usize).ok_or("invalid enum tag")?)
            }
            Schema::Record(fields) => {
                let mut obj = serde_json::Map::new();
                for (n, t) in fields {
                    obj.insert(n.clone(), self.value(t, depth + 1)?);
                }
                Value::Object(obj)
            }
            Schema::List(t) => {
                let n = self.sequence()?;
                let mut xs = Vec::new();
                for _ in 0..n {
                    xs.push(self.value(t, depth + 1)?);
                }
                Value::Array(xs)
            }
            Schema::Option(t) => match self.byte()? {
                0 => json!({"None":null}),
                1 => json!({"Some":self.value(t,depth+1)?}),
                _ => return Err("invalid Option tag".into()),
            },
            Schema::Result(a, b) => match self.byte()? {
                0 => json!({"Ok":self.value(a,depth+1)?}),
                1 => json!({"Err":self.value(b,depth+1)?}),
                _ => return Err("invalid Result tag".into()),
            },
        })
    }
}
fn event_order(e: &Event, version: u64, prior: Option<(u64, u64)>) -> R<()> {
    if e.commit == 0 || e.commit > version || prior.is_some_and(|p| p >= (e.commit, e.position)) {
        return Err("invalid snapshot event sequence".into());
    }
    Ok(())
}
pub fn encode(layout: &Layout, s: &Logical, limits: Limits) -> R<Vec<u8>> {
    if s.tables.len() != layout.roots.len() {
        return Err("snapshot root count mismatch".into());
    }
    let mut out = Vec::new();
    let mut left = limits.values;
    u64_bytes(&mut out, s.version);
    for (rows, (_, kt, vt)) in s.tables.iter().zip(&layout.roots) {
        if rows.len() > left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        count(&mut out, rows.len());
        let mut prior = None;
        for (k, v) in rows {
            if let Some(p) = prior {
                if compare(kt, p, k)? != Ordering::Less {
                    return Err("snapshot keys must be strictly ordered".into());
                }
            }
            encode_value(kt, k, &mut out, &mut left, 0, limits)?;
            encode_value(vt, v, &mut out, &mut left, 0, limits)?;
            prior = Some(k);
        }
    }
    count(&mut out, s.outbox.len());
    let mut prior = None;
    for e in &s.outbox {
        event_order(e, s.version, prior)?;
        let (_, t) = layout
            .events
            .get(e.channel)
            .ok_or("unknown event channel")?;
        u64_bytes(&mut out, e.commit);
        u64_bytes(&mut out, e.position);
        out.extend_from_slice(&(e.channel as u32).to_le_bytes());
        encode_value(t, &e.value, &mut out, &mut left, 0, limits)?;
        prior = Some((e.commit, e.position));
    }
    if HEADER
        .checked_add(out.len())
        .and_then(|n| n.checked_add(32))
        .is_none_or(|n| n > limits.bytes)
    {
        return Err("snapshot byte limit exceeded".into());
    }
    let mut bytes = Vec::new();
    bytes.extend_from_slice(MAGIC);
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&layout.program);
    bytes.extend_from_slice(&layout.schema);
    count(&mut bytes, out.len());
    bytes.extend_from_slice(&out);
    let digest = Sha256::digest(&bytes);
    bytes.extend_from_slice(&digest);
    Ok(bytes)
}
pub fn decode(layout: &Layout, bytes: &[u8], limits: Limits) -> R<Logical> {
    if bytes.len() > limits.bytes || bytes.len() < HEADER + 32 {
        return Err("snapshot byte length invalid".into());
    }
    if &bytes[..8] != MAGIC || bytes[8..12] != [1, 0, 1, 0] {
        return Err("snapshot format or semantics version mismatch".into());
    }
    if bytes[12..44] != layout.program || bytes[44..76] != layout.schema {
        return Err("snapshot program or schema identity mismatch".into());
    }
    let n = usize::try_from(u64::from_le_bytes(bytes[76..84].try_into().unwrap()))
        .map_err(|_| "snapshot length not addressable")?;
    if HEADER.checked_add(n).and_then(|v| v.checked_add(32)) != Some(bytes.len()) {
        return Err("snapshot payload length mismatch".into());
    }
    let end = bytes.len() - 32;
    if Sha256::digest(&bytes[..end]).as_slice() != &bytes[end..] {
        return Err("snapshot integrity check failed".into());
    }
    let mut r = Reader {
        bytes: &bytes[HEADER..end],
        at: 0,
        left: limits.values,
        limits,
    };
    let version = r.u64()?;
    let mut tables = vec![];
    for (_, kt, vt) in &layout.roots {
        let n = r.sequence()?;
        if n > r.left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        let mut rows: Vec<(Value, Value)> = vec![];
        for _ in 0..n {
            let k = r.value(kt, 0)?;
            let v = r.value(vt, 0)?;
            if let Some((prior, _)) = rows.last() {
                if compare(kt, prior, &k)? != Ordering::Less {
                    return Err("duplicate or unordered snapshot key".into());
                }
            }
            rows.push((k, v));
        }
        tables.push(rows);
    }
    let n = r.sequence()?;
    let mut outbox = vec![];
    let mut prior = None;
    for _ in 0..n {
        let commit = r.u64()?;
        let position = r.u64()?;
        let channel = r.u32()? as usize;
        let (_, t) = layout
            .events
            .get(channel)
            .ok_or("unknown snapshot event channel")?;
        let value = r.value(t, 0)?;
        let e = Event {
            commit,
            position,
            channel,
            value,
        };
        event_order(&e, version, prior)?;
        prior = Some((commit, position));
        outbox.push(e);
    }
    if r.at != r.bytes.len() {
        return Err("trailing snapshot payload".into());
    }
    Ok(Logical {
        version,
        tables,
        outbox,
    })
}

}
pub use portable::Limits as SnapshotLimits;
fn snapshot_layout()->portable::Layout{portable::Layout{program:[153, 6, 120, 37, 126, 3, 82, 214, 242, 144, 179, 134, 196, 131, 95, 173, 172, 22, 64, 66, 31, 116, 87, 155, 111, 15, 183, 96, 214, 71, 138, 175],schema:[27, 31, 172, 251, 153, 194, 107, 69, 108, 37, 233, 150, 108, 188, 242, 28, 13, 0, 120, 87, 184, 170, 31, 110, 10, 244, 191, 19, 232, 221, 5, 253],roots:vec![
("Rows".into(),portable::Schema::U64,portable::Schema::Record(vec![("amount".into(),portable::Schema::U64),("active".into(),portable::Schema::Bool)])),
],events:vec![("seen".into(),portable::Schema::U64),
]}}
fn one_tag<'a>(v:&'a Json,_kind:&str)->Result<&'a serde_json::Map<String,Json>,String>{Ok(v.as_object().unwrap())}
fn read_0(v:&Json,d:usize)->Result<bool,String>{Ok(
v.as_bool().unwrap())}
fn write_0(v:&bool,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_1(v:&Json,d:usize)->Result<u64,String>{Ok(
v.as_u64().unwrap())}
fn write_1(v:&u64,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_2(v:&Json,d:usize)->Result<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c,String>{Ok(
{D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0})}
fn write_2(v:&D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c,d:usize)->Result<Json,String>{Ok(
Json::Null)}
fn read_3(v:&Json,d:usize)->Result<D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c,String>{Ok(
{let xs=v.as_array().unwrap();let mut tail=D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c::C0;for x in xs.iter().rev(){tail=D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c::C1(read_1(x,d+1)?,std::sync::Arc::new(tail));}tail})}
fn write_3(v:&D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c,d:usize)->Result<Json,String>{Ok(
{let mut cursor=v;let mut xs=vec![];loop{match cursor{D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c::C0=>break,D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c::C1(x,tail)=>{xs.push(write_1(x,d+1)?);cursor=tail.as_ref();}}}Json::Array(xs)})}
fn read_4(v:&Json,d:usize)->Result<D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5,String>{Ok(
{let xs=v.as_array().unwrap();let mut tail=D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5::C0;for x in xs.iter().rev(){tail=D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5::C1(std::sync::Arc::new(read_6(x,d+1)?),std::sync::Arc::new(tail));}tail})}
fn write_4(v:&D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5,d:usize)->Result<Json,String>{Ok(
{let mut cursor=v;let mut xs=vec![];loop{match cursor{D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5::C0=>break,D_989c1f570c3e6a77987be1f0ed9a15db10b0997feb8797bd769eae64c2c320f5::C1(x,tail)=>{xs.push(write_6(x,d+1)?);cursor=tail.as_ref();}}}Json::Array(xs)})}
fn read_5(v:&Json,d:usize)->Result<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b,String>{Ok(
{let text=v.as_str().unwrap();match text{"Error.Failed"=>D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0,_=>unreachable!("caller enum precondition")}})}
fn write_5(v:&D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b,d:usize)->Result<Json,String>{Ok(
match v{D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0=>json!("Error.Failed"),})}
fn read_6(v:&Json,d:usize)->Result<D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35,String>{Ok(
{let xs=v.as_object().unwrap();D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(read_1(xs.get("amount").unwrap(),d+1)?,read_0(xs.get("active").unwrap(),d+1)?)})}
fn write_6(v:&D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35,d:usize)->Result<Json,String>{Ok(
{let D_9393432148f6452d244d6e5f271287d4b34b1990f2a8f535c7f91c35c091dd35::C0(b0,b1)=v;json!({"amount":write_1(&b0,d+1)?,"active":write_0(&b1,d+1)?})})}
fn read_7(v:&Json,d:usize)->Result<D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C1(std::sync::Arc::new(read_6(x,d+1)?))}else{D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C0}})}
fn write_7(v:&D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca,d:usize)->Result<Json,String>{Ok(
match v{D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C0=>json!({"None":null}),D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca::C1(x)=>json!({"Some":write_6(x,d+1)?})})}
fn read_8(v:&Json,d:usize)->Result<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f,String>{Ok(
{let xs=one_tag(v,"Result")?;if let Some(x)=xs.get("Ok"){D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::new(read_2(x,d+1)?))}else{let x=xs.get("Err").unwrap();D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::new(read_5(x,d+1)?))}})}
fn write_8(v:&D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f,d:usize)->Result<Json,String>{Ok(
match v{D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(x)=>json!({"Ok":write_2(x,d+1)?}),D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(x)=>json!({"Err":write_5(x,d+1)?})})}
fn logical_from_tables(tables:&[Vec<(Json,Json)>])->Result<D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9,String>{if tables.len()!=1{return Err("representation table count mismatch".into())}
let rows=&tables[0];let mut root0=D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0;for (key,row) in rows.iter().rev(){root0=D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C1(read_1(key,0)?,std::sync::Arc::new(read_6(row,0)?),std::sync::Arc::new(root0));}
Ok(D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(root0)))}
fn logical_tables(state:&D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9)->Result<Vec<Vec<(Json,Json)>>,String>{let D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(r0)=state;
let mut rows0=vec![];let mut cursor=r0.as_ref();loop{match cursor{D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0=>break,D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C1(key,value,tail)=>{rows0.push((write_1(key,0)?,write_6(value,0)?));cursor=tail.as_ref();}}}
Ok(vec![rows0])}
fn logical_events(events:&D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8)->Result<Vec<(usize,Json)>,String>{let mut cursor=events;let mut out=vec![];loop{match cursor{D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C0=>break,D_85ca59f044325c4a37e15c5613e9b98e79ed54d591bfec20e943c057624b23f8::C1(event,tail)=>{let value=match event.as_ref(){
D_8b7223f44550c57238cd939cbe116ed7e80287159078a8661acaa3dbfebbf710::C0(value)=>(0,write_1(value,0)?),
};out.push(value);cursor=tail.as_ref();}}}Ok(out)}
pub use portable::Event;
pub struct Outcome<T>{pub result:T,pub committed:bool,pub version:u64,pub events:Vec<Event>}
pub struct OutcomeView<'a,T>{pub result:T,pub committed:bool,pub version:u64,pub events:&'a[Event]}
impl<T> OutcomeView<'_,T>{pub fn into_owned(self)->Outcome<T>{Outcome{result:self.result,committed:self.committed,version:self.version,events:self.events.to_vec()}}}
pub struct State{physical:D_c57d683db9b191325682b824b40a3b1ddcb53a99daac0115be4325aa0c9bf3b3,version:u64,outbox:Vec<portable::Event>,layout:portable::Layout}
impl State{
// CALLER CONTRACT: arguments must have the declared types and canonical values.
// No runtime type validation. Malformed input may panic, trap or corrupt state.
pub fn new()->Result<Self,String>{let logical=D_e5e2177fe6c8e5912f3c06de1e0155552540794673afdad01001b52ff5643bc9::C0(std::sync::Arc::new(D_e11b77a569586df9a5a7e7bcfab406f6cfa22d8ed1f9898d699b6c71844afa2b::C0));Ok(Self{physical:f_7af037a656d4292fe754db65086906e11e98c60a674eedb8f4316f39833149c2(&logical),version:0,outbox:vec![],layout:snapshot_layout()})}
pub fn restore(bytes:&[u8])->Result<Self,String>{let layout=snapshot_layout();let saved=portable::decode(&layout,bytes,SnapshotLimits::default())?;let logical=logical_from_tables(&saved.tables)?;Ok(Self{physical:f_7af037a656d4292fe754db65086906e11e98c60a674eedb8f4316f39833149c2(&logical),version:saved.version,outbox:saved.outbox,layout})}
pub fn checkpoint(&self)->Result<Vec<u8>,String>{let logical=f_c46fbad8dbeff2e42d83cfff4fc0fe8157d5781258e95ee57e7f6d93e4858a4d(&(self.physical));portable::encode(&self.layout,&portable::Logical{version:self.version,tables:logical_tables(&logical)?,outbox:self.outbox.clone()},SnapshotLimits::default())}
pub fn version(&self)->u64{self.version}
pub fn outbox_json(&self)->Json{Json::Array(self.outbox.iter().map(|e|json!({"commit":e.commit,"position":e.position,"channel":self.layout.events[e.channel].0,"value":e.value})).collect())}
pub fn acknowledge_through(&mut self,commit:u64,position:u64){self.outbox.retain(|e|(e.commit,e.position)>(commit,position));}
pub fn query_active(&self,)->D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c{q_b5a1f2bc26b2b94fd3de0a34f9a110eb4cffef63d034aaee8b7e63733b797250(&(self.physical),self.version)}
pub fn query_all(&self,)->D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c{q_805ade521daff0c649689bf56487a91a251edd7500bbb4dd5459563052b3199e(&(self.physical),self.version)}
pub fn query_get(&self,a0:u64)->D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca{q_992aadd990d6ea3445c428be3d6cdfdfd91818aff21808181c84cfc921134d5b(&(self.physical),self.version,a0)}
pub fn invoke_view_put(&mut self,a0:u64,a1:u64,a2:bool,a3:bool)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=t_0bf83650bcfdbd190544da387ad02598ad70554e40e83072712ed13471990e6e(&(self.physical),self.version,a0,a1,a2,a3);let observed=f_f6623c7ce0f53190d8640cf021f9f92cc3da4f2c085f631391e7bdfea9ed8c35(&(executed));let next=f_67c53b78dd64ef73225ce6d130855043fd3c3d135aab02945783f38847ba0ef3(&(executed));
let(result,committed,version,events)=match &observed{D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_erase(&mut self,a0:u64,a1:bool)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=t_fa33e6b732bef6b27b165fa24638af475965821471e7112dcae8eaa93ffb07fb(&(self.physical),self.version,a0,a1);let observed=f_f6623c7ce0f53190d8640cf021f9f92cc3da4f2c085f631391e7bdfea9ed8c35(&(executed));let next=f_67c53b78dd64ef73225ce6d130855043fd3c3d135aab02945783f38847ba0ef3(&(executed));
let(result,committed,version,events)=match &observed{D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_active(&mut self,)->Result<OutcomeView<'_,D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c>,String>{
let result=q_b5a1f2bc26b2b94fd3de0a34f9a110eb4cffef63d034aaee8b7e63733b797250(&(self.physical),self.version);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_view_all(&mut self,)->Result<OutcomeView<'_,D_8dcbf34b5fd4c68ba7a7892f3bcfa83b94d97c74c67e0ba8623ebf3ba3eaff4c>,String>{
let result=q_805ade521daff0c649689bf56487a91a251edd7500bbb4dd5459563052b3199e(&(self.physical),self.version);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_view_get(&mut self,a0:u64)->Result<OutcomeView<'_,D_f2b76adfa54cd1958c76de9a271a794ec73372ceba0cefe52674314cd04413ca>,String>{
let result=q_992aadd990d6ea3445c428be3d6cdfdfd91818aff21808181c84cfc921134d5b(&(self.physical),self.version,a0);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_json(&mut self,name:&str,args:&Json)->Result<Json,String>{match name{
"put"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_1(&xs[1],0)?;
let a2=read_0(&xs[2],0)?;
let a3=read_0(&xs[3],0)?;
let executed=t_0bf83650bcfdbd190544da387ad02598ad70554e40e83072712ed13471990e6e(&(self.physical),self.version,a0,a1,a2,a3);
let observed=f_f6623c7ce0f53190d8640cf021f9f92cc3da4f2c085f631391e7bdfea9ed8c35(&(executed));let next=f_67c53b78dd64ef73225ce6d130855043fd3c3d135aab02945783f38847ba0ef3(&(executed));let(reply,committed,version,events)=match &observed{D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_8(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"erase"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_0(&xs[1],0)?;
let executed=t_fa33e6b732bef6b27b165fa24638af475965821471e7112dcae8eaa93ffb07fb(&(self.physical),self.version,a0,a1);
let observed=f_f6623c7ce0f53190d8640cf021f9f92cc3da4f2c085f631391e7bdfea9ed8c35(&(executed));let next=f_67c53b78dd64ef73225ce6d130855043fd3c3d135aab02945783f38847ba0ef3(&(executed));let(reply,committed,version,events)=match &observed{D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_6807e8193a22f1229a127b28b4c88774866674246b261c234729e42d515f35c6::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_8(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"active"=>{let xs=args.as_array().unwrap();
let reply=q_b5a1f2bc26b2b94fd3de0a34f9a110eb4cffef63d034aaee8b7e63733b797250(&(self.physical),self.version);let result=write_3(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
"all"=>{let xs=args.as_array().unwrap();
let reply=q_805ade521daff0c649689bf56487a91a251edd7500bbb4dd5459563052b3199e(&(self.physical),self.version);let result=write_3(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
"get"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let reply=q_992aadd990d6ea3445c428be3d6cdfdfd91818aff21808181c84cfc921134d5b(&(self.physical),self.version,a0);let result=write_7(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
_=>Err(format!("unknown action {name}"))}}}
