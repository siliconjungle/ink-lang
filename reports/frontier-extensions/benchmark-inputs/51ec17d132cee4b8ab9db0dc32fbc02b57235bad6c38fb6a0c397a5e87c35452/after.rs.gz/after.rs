// ink-definition-rust-v1: checked bodies; Rust/backend are trusted.
#![allow(non_camel_case_types, non_snake_case, non_upper_case_globals, dead_code, unused_variables, unused_parens, unused_unsafe, improper_ctypes_definitions)]
// Bounded memoisation of pure scalar functions over immutable shared inputs.
// Weak owners and pointer equality authenticate identity; addresses alone never
// qualify a hit. No data result is retained and calls with owned inputs bypass.
#[derive(Clone, Copy)]
enum InkMemoScalar { Word(u64), Flag(bool) }
trait InkMemoResult: Copy {
    fn store(self) -> InkMemoScalar;
    fn load(value: InkMemoScalar) -> Option<Self>;
}
impl InkMemoResult for u64 {
    fn store(self) -> InkMemoScalar { InkMemoScalar::Word(self) }
    fn load(v: InkMemoScalar) -> Option<Self> { match v { InkMemoScalar::Word(x)=>Some(x),_=>None } }
}
impl InkMemoResult for bool {
    fn store(self) -> InkMemoScalar { InkMemoScalar::Flag(self) }
    fn load(v: InkMemoScalar) -> Option<Self> { match v { InkMemoScalar::Flag(x)=>Some(x),_=>None } }
}
struct InkMemoEntry {
    input: std::sync::Weak<dyn std::any::Any>,
    function: &'static str,
    arguments: [u64; 4],
    value: InkMemoScalar,
}
std::thread_local! {static INK_IDENTITY_MEMO:std::cell::RefCell<Vec<InkMemoEntry>>=const{std::cell::RefCell::new(Vec::new())};}
fn ink_identity_memo<T:'static,V:InkMemoResult>(input:&std::sync::Arc<T>,function:&'static str,arguments:[u64;4],compute:impl FnOnce()->V)->V {
    let found=INK_IDENTITY_MEMO.with(|cache| {
        let mut cache=cache.borrow_mut();
        cache.retain(|entry|entry.input.strong_count()>0);
        cache.iter().rev().find_map(|entry| {
            if entry.function!=function||entry.arguments!=arguments{return None;}
            let owner=entry.input.upgrade()?;
            if !std::ptr::eq(owner.downcast_ref::<T>()?,input.as_ref()){return None;}
            V::load(entry.value)
        })
    });
    if let Some(value)=found{return value;}
    // Computing can recursively enter the cache; hold no RefCell borrow here.
    let value=compute();
    let owner:std::sync::Arc<dyn std::any::Any>=input.clone();
    let weak=std::sync::Arc::downgrade(&owner);
    INK_IDENTITY_MEMO.with(|cache| {
        let mut cache=cache.borrow_mut();
        if cache.len()==64 {cache.remove(0);}
        cache.push(InkMemoEntry{input:weak,function,arguments,value:value.store()});
    });
    value
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_033c45808088fe0a648d64dec258316039932b49f07f4e454d52c957e4a72860 { C0(std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>) }
fn d_078801970e258a449094e4f1a34a7c597cf9efaed0ebf76d275af684278a4182(v0: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v1: u64,v2: u64,v3: u64,v4: u64,v5: bool) -> D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { d_1d52702454d42edb2a6d20018333f6c88e0adba2da5cdf7fb9d638d0760825ca(&(d_f137ad14880d722826ba61d21bb95fd94e16e99431673daf2aefe85791023a26(v0)),v1,v2,v3,v4,v5) }
fn d_092267d9d0f263d331187c01135ad89a90229fd7f3e3e4eb1a838e8f624d88ba(v6: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12,v7: u64) -> bool { match &(d_d9b80c6b218b452e1dd4fb3e00a29a4a93c866068e0e24d47e367971f6ab9551(v6,v7)) { D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f::C0 => { false },D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f::C1(v8) => { true } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_0b0e2c43282a1844f9ed4654ca532484ac8277b7e25126b42b5f9cf6a218769f { C0(std::sync::Arc<D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909>,bool,u64,std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>,std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>),C1(u64,u64,std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d { C0(std::sync::Arc<D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947>,std::sync::Arc<D_0b0e2c43282a1844f9ed4654ca532484ac8277b7e25126b42b5f9cf6a218769f>) }
fn d_169effbfcb50cd2ed72923ccc2a795d6980821d2b2701d5ac421fd362680b312(v9: &D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09,v10: u64,v11: u64,v12: bool) -> D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { match &(D_033c45808088fe0a648d64dec258316039932b49f07f4e454d52c957e4a72860::C0(std::sync::Arc::new(match v9 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v13) => { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::new(d_493605feb8b9d5528b2624ab3c80186adc7989b3bef45fdf612b120a44f234ec(&(match v9 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v14) => { (v14.as_ref()).clone() } }),v11))) } }))) { D_033c45808088fe0a648d64dec258316039932b49f07f4e454d52c957e4a72860::C0(v15) => { if v12 { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v16:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v16.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v18) => { if ((v10) == (18446744073709551615u64)) { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(1u64,v10,std::sync::Arc::new((v9).clone())) } else { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v18))),true,(v10).wrapping_add(1u64),std::sync::Arc::clone(v15),std::sync::Arc::clone({static v19:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v19.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v20) => { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v20))),false,v10,std::sync::Arc::new((v9).clone()),std::sync::Arc::clone({static v21:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v21.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } } } else { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v22:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v22.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v24) => { if ((v10) == (18446744073709551615u64)) { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(1u64,v10,std::sync::Arc::new((v9).clone())) } else { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v24))),true,(v10).wrapping_add(1u64),std::sync::Arc::clone(v15),std::sync::Arc::clone({static v25:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v25.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v26) => { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v26))),false,v10,std::sync::Arc::new((v9).clone()),std::sync::Arc::clone({static v27:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v27.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } } } } } }
fn d_18b5d58be78e1ad2dd90b6ce4bb60c933243735de7b53235ce6919518dc81bf1(v28: &D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d) -> D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { match v28 { D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d::C0(v29,v30) => { (v29.as_ref()).clone() } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_19d679ad098cdb52dd6cdea09954b257d0a0331fd2e0456130018fe62b18027a { C0(std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>) }
fn d_1ac082f699bf8e068df795bd7cd975c1c5ed13616fb850ecdfe304d187585d29(v31: &D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09) -> D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { match v31 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v32) => { D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947::C0(std::sync::Arc::clone(v32)) } } }
fn d_1d52702454d42edb2a6d20018333f6c88e0adba2da5cdf7fb9d638d0760825ca(v33: &D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09,v34: u64,v35: u64,v36: u64,v37: u64,v38: bool) -> D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { match &(D_ce1114335932a018fd7de6f6012e294c7e537e169c3e176cbac9e2f32333dd02::C0(std::sync::Arc::new(D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v36,v37)))) { D_ce1114335932a018fd7de6f6012e294c7e537e169c3e176cbac9e2f32333dd02::C0(v39) => { if d_092267d9d0f263d331187c01135ad89a90229fd7f3e3e4eb1a838e8f624d88ba(&(match v33 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v40) => { (v40.as_ref()).clone() } }),v35) { if d_092267d9d0f263d331187c01135ad89a90229fd7f3e3e4eb1a838e8f624d88ba(&(match v33 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v41) => { (v41.as_ref()).clone() } }),v35) { match &(D_033c45808088fe0a648d64dec258316039932b49f07f4e454d52c957e4a72860::C0(std::sync::Arc::new(match v33 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v42) => { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::new(d_a39c5e1dc42ba2302cbff5dfc8ac86a58485fa593e8aeaa181ba022329029480(&(match v33 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v43) => { (v43.as_ref()).clone() } }),v35,v39.as_ref()))) } }))) { D_033c45808088fe0a648d64dec258316039932b49f07f4e454d52c957e4a72860::C0(v44) => { match &(D_19d679ad098cdb52dd6cdea09954b257d0a0331fd2e0456130018fe62b18027a::C0(std::sync::Arc::new(d_93a2b8f313f7a616ffc4a18e06df602b7ff316c91398a730ba2941036ecbbf7f(&(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0),&(D_d762bb1af249ac8e4d79ab5c82bc7e5d6e1a8239b27bfd12dbfeb76c3db794a1::C0(v36)))))) { D_19d679ad098cdb52dd6cdea09954b257d0a0331fd2e0456130018fe62b18027a::C0(v46) => { if v38 { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v47:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v47.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v49) => { if ((v34) == (18446744073709551615u64)) { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(1u64,v34,std::sync::Arc::new((v33).clone())) } else { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v49))),true,(v34).wrapping_add(1u64),std::sync::Arc::clone(v44),std::sync::Arc::clone(v46)) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v50) => { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v50))),false,v34,std::sync::Arc::new((v33).clone()),std::sync::Arc::clone({static v51:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v51.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } } } else { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v52:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v52.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v54) => { if ((v34) == (18446744073709551615u64)) { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(1u64,v34,std::sync::Arc::new((v33).clone())) } else { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v54))),true,(v34).wrapping_add(1u64),std::sync::Arc::clone(v44),std::sync::Arc::clone(v46)) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v55) => { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v55))),false,v34,std::sync::Arc::new((v33).clone()),std::sync::Arc::clone({static v56:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v56.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } } } } } } } } else { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(2u64,v34,std::sync::Arc::new((v33).clone())) } } else { if d_092267d9d0f263d331187c01135ad89a90229fd7f3e3e4eb1a838e8f624d88ba(&(match v33 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v57) => { (v57.as_ref()).clone() } }),v35) { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(2u64,v34,std::sync::Arc::new((v33).clone())) } else { match &(D_033c45808088fe0a648d64dec258316039932b49f07f4e454d52c957e4a72860::C0(std::sync::Arc::new(match v33 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v58) => { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::new(d_ae0f22e30652d2ecfa186a0d9eb14aa190071b4cbbc659aaf64fb36d7c804c32(&(match v33 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v59) => { (v59.as_ref()).clone() } }),v35,v39.as_ref()))) } }))) { D_033c45808088fe0a648d64dec258316039932b49f07f4e454d52c957e4a72860::C0(v60) => { match &(D_19d679ad098cdb52dd6cdea09954b257d0a0331fd2e0456130018fe62b18027a::C0(std::sync::Arc::new(d_93a2b8f313f7a616ffc4a18e06df602b7ff316c91398a730ba2941036ecbbf7f(&(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0),&(D_d762bb1af249ac8e4d79ab5c82bc7e5d6e1a8239b27bfd12dbfeb76c3db794a1::C0(v36)))))) { D_19d679ad098cdb52dd6cdea09954b257d0a0331fd2e0456130018fe62b18027a::C0(v62) => { if v38 { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone({static v63:std::sync::OnceLock<std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>>=std::sync::OnceLock::new();v63.get_or_init(||std::sync::Arc::new(D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v65) => { if ((v34) == (18446744073709551615u64)) { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(1u64,v34,std::sync::Arc::new((v33).clone())) } else { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v65))),true,(v34).wrapping_add(1u64),std::sync::Arc::clone(v60),std::sync::Arc::clone(v62)) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v66) => { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v66))),false,v34,std::sync::Arc::new((v33).clone()),std::sync::Arc::clone({static v67:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v67.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } } } else { match &(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone({static v68:std::sync::OnceLock<std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>>=std::sync::OnceLock::new();v68.get_or_init(||std::sync::Arc::new(D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0))}))) { D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(v70) => { if ((v34) == (18446744073709551615u64)) { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(1u64,v34,std::sync::Arc::new((v33).clone())) } else { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::clone(v70))),true,(v34).wrapping_add(1u64),std::sync::Arc::clone(v60),std::sync::Arc::clone(v62)) } },D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(v71) => { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(std::sync::Arc::new(D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::clone(v71))),false,v34,std::sync::Arc::new((v33).clone()),std::sync::Arc::clone({static v72:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v72.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } } } } } } } } } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { C0(std::sync::Arc<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,bool,u64,std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>,std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>),C1(u64,u64,std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f { C0(u64,u64) }
fn d_27995365df0ae852ed100b979814b00d496cc378abe96f2613f9ea62f373d763(v73: &D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f) -> u64 { if ((match v73 { D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v74,v75) => { *v75 } }) == (0u64)) { (match v73 { D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v76,v77) => { *v76 } }).wrapping_add(0u64) } else { 0u64 } }
fn d_33456c6b9ef6209c75a1f19999587acaaff98b6f47024a047476d87bf719f57c(v78: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v79: u64,v80: u64) -> D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8 { D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8::C0(std::sync::Arc::new((v78).clone()),std::sync::Arc::new(d_70bacf9b8624bdd9a8f584aa03722d95d1051fdcb8c44d367b01b7fce8459092(&(d_f137ad14880d722826ba61d21bb95fd94e16e99431673daf2aefe85791023a26(v78)),v79,v80))) }
fn d_3e765fb2dac2f4fd3ae584d8063b55c1488dad6e63a6a381bef64a61be9b2e6b(v81: &D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f) -> u64 { if ((match v81 { D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v82,v83) => { *v83 } }) > (1u64)) { (match v81 { D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v84,v85) => { *v84 } }).wrapping_add(0u64) } else { 0u64 } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_4443cf480c7d87b3e1503c4ebb3ba4af4cc63c226fbd45970d6aa0588b4f5df6 { C0(std::sync::Arc<D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f>,bool,u64,std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>,std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>),C1(u64,u64,std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>) }
fn d_493605feb8b9d5528b2624ab3c80186adc7989b3bef45fdf612b120a44f234ec(v86: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12,v87: u64) -> D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12 { match v86 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v89,v90,v91) => { if ((v87) == (*v89)) { d_493605feb8b9d5528b2624ab3c80186adc7989b3bef45fdf612b120a44f234ec(v91.as_ref(),v87) } else { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(*v89,std::sync::Arc::clone(v90),std::sync::Arc::new(d_493605feb8b9d5528b2624ab3c80186adc7989b3bef45fdf612b120a44f234ec(v91.as_ref(),v87))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12 { C0,C1(u64,std::sync::Arc<D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f>,std::sync::Arc<D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12>) }
impl D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
fn d_70bacf9b8624bdd9a8f584aa03722d95d1051fdcb8c44d367b01b7fce8459092(v92: &D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09,v93: u64,v94: u64) -> D_4443cf480c7d87b3e1503c4ebb3ba4af4cc63c226fbd45970d6aa0588b4f5df6 { D_4443cf480c7d87b3e1503c4ebb3ba4af4cc63c226fbd45970d6aa0588b4f5df6::C0(std::sync::Arc::new(d_d9b80c6b218b452e1dd4fb3e00a29a4a93c866068e0e24d47e367971f6ab9551(&(match v92 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v95) => { (v95.as_ref()).clone() } }),v94)),false,v93,std::sync::Arc::new((v92).clone()),std::sync::Arc::clone({static v96:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v96.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) }
fn d_7597c22aa4906c1f171628b86c5e4a2fbebc3664346581bcbe807421448414b9(v97: &D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb) -> D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { (v97).clone() }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { C0(std::sync::Arc<D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12>) }
fn d_7840a2afe0925805f95a6e2ffdc85afa314904d56817f9ea17b021d701182e0b(v98: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12) -> u64 { match v98 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { 0u64 },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v99,v100,v101) => { (d_27995365df0ae852ed100b979814b00d496cc378abe96f2613f9ea62f373d763(v100.as_ref())).wrapping_add(d_7840a2afe0925805f95a6e2ffdc85afa314904d56817f9ea17b021d701182e0b(v101.as_ref())) } } }
fn d_8bbd18dbb03bbbe491373f380012e93500119152952f138315445682c93df40f(v102: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v103: u64,v104: u64,v105: bool) -> D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { d_169effbfcb50cd2ed72923ccc2a795d6980821d2b2701d5ac421fd362680b312(&(d_f137ad14880d722826ba61d21bb95fd94e16e99431673daf2aefe85791023a26(v102)),v103,v104,v105) }
fn d_8c62ac74e36ae3f7587ce59bef3582325183a604b75f16d5377e951900932bf4(v106: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12) -> u64 { match v106 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { 0u64 },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v107,v108,v109) => { (d_a91b3bbd2a309c6076b827daa6f78bf5ea624db5195e84c25ebcdac1ae71303c(v108.as_ref())).wrapping_add(d_8c62ac74e36ae3f7587ce59bef3582325183a604b75f16d5377e951900932bf4(v109.as_ref())) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09 { C0(std::sync::Arc<D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12>) }
fn d_9126d0ca9d1c7293fa66db982b0a4d9214b66a38fa27c949b19c995fab0cd1d3(v110: &D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d) -> D_0b0e2c43282a1844f9ed4654ca532484ac8277b7e25126b42b5f9cf6a218769f { match v110 { D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d::C0(v111,v112) => { (v112.as_ref()).clone() } } }
fn d_9160059557fdbf93dc236b98c24dde5150c9c690af362a58dce9f1fe58a83e79(v113: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12) -> u64 { match v113 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { 0u64 },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v114,v115,v116) => { (d_3e765fb2dac2f4fd3ae584d8063b55c1488dad6e63a6a381bef64a61be9b2e6b(v115.as_ref())).wrapping_add(d_9160059557fdbf93dc236b98c24dde5150c9c690af362a58dce9f1fe58a83e79(v116.as_ref())) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f { C0(std::sync::Arc<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c>),C1(std::sync::Arc<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b>) }
fn d_93a2b8f313f7a616ffc4a18e06df602b7ff316c91398a730ba2941036ecbbf7f(v117: &D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7,v118: &D_d762bb1af249ac8e4d79ab5c82bc7e5d6e1a8239b27bfd12dbfeb76c3db794a1) -> D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7 { match v117 { D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0 => { D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C1(std::sync::Arc::new((v118).clone()),std::sync::Arc::clone({static v119:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v119.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) },D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C1(v120,v121) => { D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C1(std::sync::Arc::clone(v120),std::sync::Arc::new(d_93a2b8f313f7a616ffc4a18e06df602b7ff316c91398a730ba2941036ecbbf7f(v121.as_ref(),v118))) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909 { C0(u64,u64,u64,u64) }
fn d_a31c77328e79510dd0d950aff8e6f58fd7bbd71bfb152c12fcaead232f39bc49(v122: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v123: u64) -> D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d { D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d::C0(std::sync::Arc::new((v122).clone()),std::sync::Arc::new(d_decb950abb4a2af58ac21fb87465ba946829483a7d181837e41ecbb53174cdd7(&(d_f137ad14880d722826ba61d21bb95fd94e16e99431673daf2aefe85791023a26(v122)),v123))) }
fn d_a39c5e1dc42ba2302cbff5dfc8ac86a58485fa593e8aeaa181ba022329029480(v124: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12,v125: u64,v126: &D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f) -> D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12 { match v124 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v128,v129,v130) => { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(*v128,std::sync::Arc::new(if ((v125) == (*v128)) { (v126).clone() } else { (v129.as_ref()).clone() }),std::sync::Arc::new(d_a39c5e1dc42ba2302cbff5dfc8ac86a58485fa593e8aeaa181ba022329029480(v130.as_ref(),v125,v126))) } } }
fn d_a4eeba09c4ca5e3389e7e40acc1d8b63a7a62efedd789764e28d0e65321c46e1(v131: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12) -> u64 { match v131 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { 0u64 },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v132,v133,v134) => { (d_f0d34c0ca9cb9421b4a6587e7b52db20bf85198dca82dacb5ec9d9e333fe7a4c(v133.as_ref())).wrapping_add(d_a4eeba09c4ca5e3389e7e40acc1d8b63a7a62efedd789764e28d0e65321c46e1(v134.as_ref())) } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f { C0,C1(std::sync::Arc<D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f>) }
fn d_a91b3bbd2a309c6076b827daa6f78bf5ea624db5195e84c25ebcdac1ae71303c(v135: &D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f) -> u64 { if ((match v135 { D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v136,v137) => { *v137 } }) == (1u64)) { (match v135 { D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v138,v139) => { *v138 } }).wrapping_add(0u64) } else { 0u64 } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8 { C0(std::sync::Arc<D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947>,std::sync::Arc<D_4443cf480c7d87b3e1503c4ebb3ba4af4cc63c226fbd45970d6aa0588b4f5df6>) }
fn d_ae0f22e30652d2ecfa186a0d9eb14aa190071b4cbbc659aaf64fb36d7c804c32(v140: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12,v141: u64,v142: &D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f) -> D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12 { match v140 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v141,std::sync::Arc::new((v142).clone()),std::sync::Arc::clone({static v143:std::sync::OnceLock<std::sync::Arc<D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12>>=std::sync::OnceLock::new();v143.get_or_init(||std::sync::Arc::new(D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0))})) },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v144,v145,v146) => { if ((v141) < (*v144)) { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v141,std::sync::Arc::new((v142).clone()),std::sync::Arc::new((v140).clone())) } else { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(*v144,std::sync::Arc::clone(v145),std::sync::Arc::new(d_ae0f22e30652d2ecfa186a0d9eb14aa190071b4cbbc659aaf64fb36d7c804c32(v146.as_ref(),v141,v142))) } } } }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7 { C0,C1(std::sync::Arc<D_d762bb1af249ac8e4d79ab5c82bc7e5d6e1a8239b27bfd12dbfeb76c3db794a1>,std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>) }
impl D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,Self::C1(_,tail)=>Some(std::mem::replace(tail,std::sync::Arc::new(Self::C0))),}}}
impl Drop for D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c { C0 }
impl D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b { C0 }
impl D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b{fn take_tail(&mut self)->Option<std::sync::Arc<Self>>{match self{Self::C0=>None,}}}
impl Drop for D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b{fn drop(&mut self){let mut pending=self.take_tail();while let Some(tail)=pending{match std::sync::Arc::try_unwrap(tail){Ok(mut node)=>pending=node.take_tail(),Err(_)=>break,}}}}
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_ce1114335932a018fd7de6f6012e294c7e537e169c3e176cbac9e2f32333dd02 { C0(std::sync::Arc<D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f>) }
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum D_d762bb1af249ac8e4d79ab5c82bc7e5d6e1a8239b27bfd12dbfeb76c3db794a1 { C0(u64) }
fn d_d7ff8aedf7aae4716808fd636578dc0d671e871536155c562959b4baf465587d(v147: &D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8) -> D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { match v147 { D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8::C0(v148,v149) => { (v148.as_ref()).clone() } } }
fn d_d9b80c6b218b452e1dd4fb3e00a29a4a93c866068e0e24d47e367971f6ab9551(v150: &D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12,v151: u64) -> D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f { match v150 { D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0 => { D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f::C0 },D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(v153,v154,v155) => { if ((v151) == (*v153)) { D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f::C1(std::sync::Arc::clone(v154)) } else { d_d9b80c6b218b452e1dd4fb3e00a29a4a93c866068e0e24d47e367971f6ab9551(v155.as_ref(),v151) } } } }
fn d_decb950abb4a2af58ac21fb87465ba946829483a7d181837e41ecbb53174cdd7(v156: &D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09,v157: u64) -> D_0b0e2c43282a1844f9ed4654ca532484ac8277b7e25126b42b5f9cf6a218769f { match v156 { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(v158) => { D_0b0e2c43282a1844f9ed4654ca532484ac8277b7e25126b42b5f9cf6a218769f::C0(std::sync::Arc::new(D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909::C0(ink_identity_memo(&(v158),"7840a2afe0925805f95a6e2ffdc85afa314904d56817f9ea17b021d701182e0b",[0u64,0u64,0u64,0u64],||d_7840a2afe0925805f95a6e2ffdc85afa314904d56817f9ea17b021d701182e0b(v158.as_ref())),ink_identity_memo(&(v158),"8c62ac74e36ae3f7587ce59bef3582325183a604b75f16d5377e951900932bf4",[0u64,0u64,0u64,0u64],||d_8c62ac74e36ae3f7587ce59bef3582325183a604b75f16d5377e951900932bf4(v158.as_ref())),ink_identity_memo(&(v158),"9160059557fdbf93dc236b98c24dde5150c9c690af362a58dce9f1fe58a83e79",[0u64,0u64,0u64,0u64],||d_9160059557fdbf93dc236b98c24dde5150c9c690af362a58dce9f1fe58a83e79(v158.as_ref())),ink_identity_memo(&(v158),"a4eeba09c4ca5e3389e7e40acc1d8b63a7a62efedd789764e28d0e65321c46e1",[0u64,0u64,0u64,0u64],||d_a4eeba09c4ca5e3389e7e40acc1d8b63a7a62efedd789764e28d0e65321c46e1(v158.as_ref())))),false,v157,std::sync::Arc::new(D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::clone(v158))),std::sync::Arc::clone({static v159:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v159.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})) } } }
fn d_e7e3f6f6a18d556802511397e31f724999d41cbc83cb66b359c55ce8e3580257(v160: &D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8) -> D_4443cf480c7d87b3e1503c4ebb3ba4af4cc63c226fbd45970d6aa0588b4f5df6 { match v160 { D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8::C0(v161,v162) => { (v162.as_ref()).clone() } } }
fn d_ea0fea581c89e9160d21dba6ef54626f2630d3df039f15aff1c821cac5fe883e(v163: &D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb) -> D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { d_1ac082f699bf8e068df795bd7cd975c1c5ed13616fb850ecdfe304d187585d29(&(match v163 { D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(v164,v165,v166,v167,v168) => { (v167.as_ref()).clone() },D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(v169,v170,v171) => { (v171.as_ref()).clone() } })) }
fn d_f0d34c0ca9cb9421b4a6587e7b52db20bf85198dca82dacb5ec9d9e333fe7a4c(v172: &D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f) -> u64 { if ((match v172 { D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v173,v174) => { *v174 } }) == (0u64)) { (((match v172 { D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(v175,v176) => { *v175 } }).wrapping_mul(0u64)).wrapping_add(1u64)).wrapping_add(0u64) } else { 0u64 } }
fn d_f137ad14880d722826ba61d21bb95fd94e16e99431673daf2aefe85791023a26(v177: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947) -> D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09 { match v177 { D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947::C0(v178) => { D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::clone(v178)) } } }
pub fn f_078801970e258a449094e4f1a34a7c597cf9efaed0ebf76d275af684278a4182(v179: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v180: u64,v181: u64,v182: u64,v183: u64,v184: bool) -> D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { d_078801970e258a449094e4f1a34a7c597cf9efaed0ebf76d275af684278a4182(v179,v180,v181,v182,v183,v184) }
pub fn f_18b5d58be78e1ad2dd90b6ce4bb60c933243735de7b53235ce6919518dc81bf1(v185: &D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d) -> D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { d_18b5d58be78e1ad2dd90b6ce4bb60c933243735de7b53235ce6919518dc81bf1(v185) }
pub fn f_1ac082f699bf8e068df795bd7cd975c1c5ed13616fb850ecdfe304d187585d29(v186: &D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09) -> D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { d_1ac082f699bf8e068df795bd7cd975c1c5ed13616fb850ecdfe304d187585d29(v186) }
pub fn f_33456c6b9ef6209c75a1f19999587acaaff98b6f47024a047476d87bf719f57c(v187: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v188: u64,v189: u64) -> D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8 { d_33456c6b9ef6209c75a1f19999587acaaff98b6f47024a047476d87bf719f57c(v187,v188,v189) }
pub fn f_7597c22aa4906c1f171628b86c5e4a2fbebc3664346581bcbe807421448414b9(v190: &D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb) -> D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { d_7597c22aa4906c1f171628b86c5e4a2fbebc3664346581bcbe807421448414b9(v190) }
pub fn f_8bbd18dbb03bbbe491373f380012e93500119152952f138315445682c93df40f(v191: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v192: u64,v193: u64,v194: bool) -> D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb { d_8bbd18dbb03bbbe491373f380012e93500119152952f138315445682c93df40f(v191,v192,v193,v194) }
pub fn f_9126d0ca9d1c7293fa66db982b0a4d9214b66a38fa27c949b19c995fab0cd1d3(v195: &D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d) -> D_0b0e2c43282a1844f9ed4654ca532484ac8277b7e25126b42b5f9cf6a218769f { d_9126d0ca9d1c7293fa66db982b0a4d9214b66a38fa27c949b19c995fab0cd1d3(v195) }
pub fn f_a31c77328e79510dd0d950aff8e6f58fd7bbd71bfb152c12fcaead232f39bc49(v196: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v197: u64) -> D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d { d_a31c77328e79510dd0d950aff8e6f58fd7bbd71bfb152c12fcaead232f39bc49(v196,v197) }
pub fn f_d7ff8aedf7aae4716808fd636578dc0d671e871536155c562959b4baf465587d(v198: &D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8) -> D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { d_d7ff8aedf7aae4716808fd636578dc0d671e871536155c562959b4baf465587d(v198) }
pub fn f_e7e3f6f6a18d556802511397e31f724999d41cbc83cb66b359c55ce8e3580257(v199: &D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8) -> D_4443cf480c7d87b3e1503c4ebb3ba4af4cc63c226fbd45970d6aa0588b4f5df6 { d_e7e3f6f6a18d556802511397e31f724999d41cbc83cb66b359c55ce8e3580257(v199) }
pub fn f_ea0fea581c89e9160d21dba6ef54626f2630d3df039f15aff1c821cac5fe883e(v200: &D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb) -> D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947 { d_ea0fea581c89e9160d21dba6ef54626f2630d3df039f15aff1c821cac5fe883e(v200) }
pub fn f_f137ad14880d722826ba61d21bb95fd94e16e99431673daf2aefe85791023a26(v201: &D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947) -> D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09 { d_f137ad14880d722826ba61d21bb95fd94e16e99431673daf2aefe85791023a26(v201) }
fn q_33456c6b9ef6209c75a1f19999587acaaff98b6f47024a047476d87bf719f57c(v0:&D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v1:u64,v2:u64)->D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f{match v0 { D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947::C0(v3) => { d_d9b80c6b218b452e1dd4fb3e00a29a4a93c866068e0e24d47e367971f6ab9551(v3.as_ref(),v2) } }}
fn q_a31c77328e79510dd0d950aff8e6f58fd7bbd71bfb152c12fcaead232f39bc49(v0:&D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v1:u64)->D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909{match v0 { D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947::C0(v2) => { D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909::C0(ink_identity_memo(&(v2),"7840a2afe0925805f95a6e2ffdc85afa314904d56817f9ea17b021d701182e0b",[0u64,0u64,0u64,0u64],||d_7840a2afe0925805f95a6e2ffdc85afa314904d56817f9ea17b021d701182e0b(v2.as_ref())),ink_identity_memo(&(v2),"8c62ac74e36ae3f7587ce59bef3582325183a604b75f16d5377e951900932bf4",[0u64,0u64,0u64,0u64],||d_8c62ac74e36ae3f7587ce59bef3582325183a604b75f16d5377e951900932bf4(v2.as_ref())),ink_identity_memo(&(v2),"9160059557fdbf93dc236b98c24dde5150c9c690af362a58dce9f1fe58a83e79",[0u64,0u64,0u64,0u64],||d_9160059557fdbf93dc236b98c24dde5150c9c690af362a58dce9f1fe58a83e79(v2.as_ref())),ink_identity_memo(&(v2),"a4eeba09c4ca5e3389e7e40acc1d8b63a7a62efedd789764e28d0e65321c46e1",[0u64,0u64,0u64,0u64],||d_a4eeba09c4ca5e3389e7e40acc1d8b63a7a62efedd789764e28d0e65321c46e1(v2.as_ref()))) } }}
fn t_33456c6b9ef6209c75a1f19999587acaaff98b6f47024a047476d87bf719f57c(v0:&D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v1:u64,v2:u64)->D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8{match v0 { D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947::C0(v3) => { D_aa681c4c105d8cd91405782b2b5acf9e9dde674ccade0cfb6861e96d4f16b2d8::C0(std::sync::Arc::new(D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947::C0(std::sync::Arc::clone(v3))),std::sync::Arc::new(D_4443cf480c7d87b3e1503c4ebb3ba4af4cc63c226fbd45970d6aa0588b4f5df6::C0(std::sync::Arc::new(d_d9b80c6b218b452e1dd4fb3e00a29a4a93c866068e0e24d47e367971f6ab9551(v3.as_ref(),v2)),false,v1,std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::clone({static v4:std::sync::OnceLock<std::sync::Arc<D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12>>=std::sync::OnceLock::new();v4.get_or_init(||std::sync::Arc::new(D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0))}))))}),std::sync::Arc::clone({static v6:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v6.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})))) } }}
fn t_a31c77328e79510dd0d950aff8e6f58fd7bbd71bfb152c12fcaead232f39bc49(v0:&D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,v1:u64)->D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d{match v0 { D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947::C0(v2) => { D_139e7cabca1d4aaa04ed72312b054b7e2cb3f1d398e38e847745540d1d43741d::C0(std::sync::Arc::new(D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947::C0(std::sync::Arc::clone(v2))),std::sync::Arc::new(D_0b0e2c43282a1844f9ed4654ca532484ac8277b7e25126b42b5f9cf6a218769f::C0(std::sync::Arc::new(D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909::C0(ink_identity_memo(&(v2),"7840a2afe0925805f95a6e2ffdc85afa314904d56817f9ea17b021d701182e0b",[0u64,0u64,0u64,0u64],||d_7840a2afe0925805f95a6e2ffdc85afa314904d56817f9ea17b021d701182e0b(v2.as_ref())),ink_identity_memo(&(v2),"8c62ac74e36ae3f7587ce59bef3582325183a604b75f16d5377e951900932bf4",[0u64,0u64,0u64,0u64],||d_8c62ac74e36ae3f7587ce59bef3582325183a604b75f16d5377e951900932bf4(v2.as_ref())),ink_identity_memo(&(v2),"9160059557fdbf93dc236b98c24dde5150c9c690af362a58dce9f1fe58a83e79",[0u64,0u64,0u64,0u64],||d_9160059557fdbf93dc236b98c24dde5150c9c690af362a58dce9f1fe58a83e79(v2.as_ref())),ink_identity_memo(&(v2),"a4eeba09c4ca5e3389e7e40acc1d8b63a7a62efedd789764e28d0e65321c46e1",[0u64,0u64,0u64,0u64],||d_a4eeba09c4ca5e3389e7e40acc1d8b63a7a62efedd789764e28d0e65321c46e1(v2.as_ref())))),false,v1,std::sync::Arc::clone({static v4:std::sync::OnceLock<std::sync::Arc<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09>>=std::sync::OnceLock::new();v4.get_or_init(||std::sync::Arc::new(D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::clone({static v3:std::sync::OnceLock<std::sync::Arc<D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12>>=std::sync::OnceLock::new();v3.get_or_init(||std::sync::Arc::new(D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0))}))))}),std::sync::Arc::clone({static v5:std::sync::OnceLock<std::sync::Arc<D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7>>=std::sync::OnceLock::new();v5.get_or_init(||std::sync::Arc::new(D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0))})))) } }}

use serde_json::{Value as Json,json};
mod portable{
//! Shared, representation-independent snapshot codec. This module also ships
//! verbatim in generated applications; it has no AST/evaluator dependency.
use num_bigint::{BigInt, Sign};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::cmp::Ordering;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Schema {
    Unit,
    Bool,
    U32,
    U64,
    I32,
    F32,
    Vector(Box<Schema>, u8),
    Int,
    String,
    Id,
    Record(Vec<(String, Schema)>),
    Enum(Vec<String>),
    List(Box<Schema>),
    Option(Box<Schema>),
    Result(Box<Schema>, Box<Schema>),
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Layout {
    pub program: [u8; 32],
    pub schema: [u8; 32],
    pub roots: Vec<(String, Schema, Schema)>,
    pub events: Vec<(String, Schema)>,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Event {
    pub commit: u64,
    pub position: u64,
    pub channel: usize,
    pub value: Value,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Logical {
    pub version: u64,
    pub tables: Vec<Vec<(Value, Value)>>,
    pub outbox: Vec<Event>,
}
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub bytes: usize,
    pub values: usize,
    pub depth: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            bytes: 64 * 1024 * 1024,
            values: 1_000_000,
            depth: 128,
        }
    }
}
/// Magnitude bound for one exact integer. Decimal conversion is superlinear,
/// so without it a single large Int in a snapshot takes minutes to hours.
pub const MAX_INT_BYTES: usize = 4096;
const MAGIC: &[u8; 8] = b"VLSTATE\0";
const HEADER: usize = 8 + 2 + 2 + 32 + 32 + 8;
type R<T> = Result<T, String>;
fn u64_bytes(out: &mut Vec<u8>, v: u64) {
    out.extend_from_slice(&v.to_le_bytes());
}
fn count(out: &mut Vec<u8>, n: usize) {
    u64_bytes(out, n as u64);
}
fn raw(out: &mut Vec<u8>, b: &[u8]) {
    count(out, b.len());
    out.extend_from_slice(b);
}
fn tag<'a>(v: &'a Value, name: &str) -> R<&'a Value> {
    let o = v.as_object().ok_or("expected tagged object")?;
    if o.len() != 1 {
        return Err("expected exactly one tag".into());
    }
    o.get(name).ok_or("unexpected value tag".into())
}
fn integer(v: &Value) -> R<BigInt> {
    let s = tag(v, "Int")?.as_str().ok_or("expected Int string")?;
    // Every Int within the bound has fewer than 2.41 decimal digits per byte.
    if s.len() > MAX_INT_BYTES * 5 / 2 + 1 {
        return Err("snapshot Int exceeds size limit".into());
    }
    let n = s.parse::<BigInt>().map_err(|_| "invalid Int")?;
    if n.bits() > 8 * MAX_INT_BYTES as u64 {
        return Err("snapshot Int exceeds size limit".into());
    }
    if n.to_string() != s {
        return Err("noncanonical Int".into());
    }
    Ok(n)
}
fn identifier(v: &Value) -> R<u128> {
    let s = v.as_str().ok_or("expected ID")?;
    if s.len() != 32
        || !s
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err("noncanonical ID".into());
    }
    u128::from_str_radix(s, 16).map_err(|e| e.to_string())
}
fn compare(t: &Schema, a: &Value, b: &Value) -> R<Ordering> {
    Ok(match t {
        Schema::I32 => a
            .as_i64()
            .and_then(|n| i32::try_from(n).ok())
            .ok_or("invalid i32 key")?
            .cmp(
                &b.as_i64()
                    .and_then(|n| i32::try_from(n).ok())
                    .ok_or("invalid i32 key")?,
            ),
        Schema::U32 | Schema::U64 => a
            .as_u64()
            .ok_or("invalid key")?
            .cmp(&b.as_u64().ok_or("invalid key")?),
        Schema::String => a
            .as_str()
            .ok_or("invalid key")?
            .as_bytes()
            .cmp(b.as_str().ok_or("invalid key")?.as_bytes()),
        Schema::Id => identifier(a)?.cmp(&identifier(b)?),
        _ => return Err("unsupported snapshot key schema".into()),
    })
}
fn tick(left: &mut usize, depth: usize, limits: Limits) -> R<()> {
    if *left == 0 || depth > limits.depth {
        return Err("snapshot value/depth limit exceeded".into());
    }
    *left -= 1;
    Ok(())
}
fn encode_value(
    t: &Schema,
    v: &Value,
    out: &mut Vec<u8>,
    left: &mut usize,
    depth: usize,
    limits: Limits,
) -> R<()> {
    tick(left, depth, limits)?;
    match t {
        Schema::Unit => {
            if !v.is_null() {
                return Err("expected Unit".into());
            }
        }
        Schema::Bool => out.push(v.as_bool().ok_or("expected Bool")? as u8),
        Schema::U32 => out.extend_from_slice(
            &u32::try_from(v.as_u64().ok_or("expected u32")?)
                .map_err(|_| "u32 overflow")?
                .to_le_bytes(),
        ),
        Schema::U64 => u64_bytes(out, v.as_u64().ok_or("expected u64")?),
        Schema::I32 => out.extend_from_slice(
            &i32::try_from(v.as_i64().ok_or("expected i32")?)
                .map_err(|_| "i32 overflow")?
                .to_le_bytes(),
        ),
        Schema::F32 => {
            let bits = if let Some(b) = v.get("F32Bits") {
                if v.as_object().is_none_or(|o| o.len() != 1) {
                    return Err("expected only F32Bits field".into());
                }
                u32::try_from(b.as_u64().ok_or("expected f32 bits")?)
                    .map_err(|_| "f32 bits overflow")?
            } else {
                let f = v.as_f64().ok_or("expected f32")? as f32;
                if !f.is_finite() {
                    return Err("finite f32 or F32Bits required".into());
                }
                f.to_bits()
            };
            out.extend_from_slice(&bits.to_le_bytes());
        }
        Schema::Vector(inner, n) => {
            if !(2..=4).contains(n)
                || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
            {
                return Err("invalid vector schema".into());
            }
            let xs = v.as_array().ok_or("expected vector")?;
            if xs.len() != *n as usize {
                return Err("vector dimension mismatch".into());
            }
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Int => {
            let n = integer(v)?;
            let (sign, b) = n.to_bytes_le();
            out.push(match sign {
                Sign::NoSign => 0,
                Sign::Plus => 1,
                Sign::Minus => 2,
            });
            if sign == Sign::NoSign {
                raw(out, &[])
            } else {
                raw(out, &b)
            }
        }
        Schema::String => raw(out, v.as_str().ok_or("expected String")?.as_bytes()),
        Schema::Id => out.extend_from_slice(&identifier(v)?.to_le_bytes()),
        Schema::Enum(names) => {
            let s = v.as_str().ok_or("expected enum string")?;
            let index = names
                .iter()
                .position(|n| n == s)
                .ok_or("unknown enum variant")?;
            out.extend_from_slice(&(index as u32).to_le_bytes());
        }
        Schema::Record(fields) => {
            let obj = v.as_object().ok_or("expected record")?;
            if obj.len() != fields.len() {
                return Err("record field mismatch".into());
            }
            for (n, t) in fields {
                encode_value(
                    t,
                    obj.get(n).ok_or("missing record field")?,
                    out,
                    left,
                    depth + 1,
                    limits,
                )?;
            }
        }
        Schema::List(inner) => {
            let xs = v.as_array().ok_or("expected List")?;
            if xs.len() > *left {
                return Err("snapshot value limit exceeded".into());
            }
            count(out, xs.len());
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits)?;
            }
        }
        Schema::Option(inner) => {
            if let Ok(x) = tag(v, "Some") {
                out.push(1);
                encode_value(inner, x, out, left, depth + 1, limits)?;
            } else {
                if !tag(v, "None")?.is_null() {
                    return Err("invalid None".into());
                }
                out.push(0);
            }
        }
        Schema::Result(a, b) => {
            if let Ok(x) = tag(v, "Ok") {
                out.push(0);
                encode_value(a, x, out, left, depth + 1, limits)?;
            } else {
                out.push(1);
                encode_value(b, tag(v, "Err")?, out, left, depth + 1, limits)?;
            }
        }
    }
    if out.len() > limits.bytes {
        return Err("snapshot byte limit exceeded".into());
    }
    Ok(())
}
struct Reader<'a> {
    bytes: &'a [u8],
    at: usize,
    left: usize,
    limits: Limits,
}
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> R<&'a [u8]> {
        let end = self.at.checked_add(n).ok_or("snapshot length overflow")?;
        let b = self.bytes.get(self.at..end).ok_or("truncated snapshot")?;
        self.at = end;
        Ok(b)
    }
    fn byte(&mut self) -> R<u8> {
        Ok(self.take(1)?[0])
    }
    fn u32(&mut self) -> R<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn u64(&mut self) -> R<u64> {
        Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
    fn len(&mut self) -> R<usize> {
        usize::try_from(self.u64()?).map_err(|_| "snapshot length not addressable".into())
    }
    fn sequence(&mut self) -> R<usize> {
        let n = self.len()?;
        if n > self.left {
            return Err("snapshot value limit exceeded".into());
        }
        Ok(n)
    }
    fn raw(&mut self) -> R<&'a [u8]> {
        let n = self.len()?;
        self.take(n)
    }
    fn value(&mut self, t: &Schema, depth: usize) -> R<Value> {
        tick(&mut self.left, depth, self.limits)?;
        Ok(match t {
            Schema::Unit => Value::Null,
            Schema::Bool => match self.byte()? {
                0 => json!(false),
                1 => json!(true),
                _ => return Err("invalid Bool tag".into()),
            },
            Schema::U32 => json!(self.u32()?),
            Schema::U64 => json!(self.u64()?),
            Schema::I32 => json!(self.u32()? as i32),
            Schema::F32 => {
                let bits = self.u32()?;
                let f = f32::from_bits(bits);
                if f.is_finite() {
                    json!(f)
                } else {
                    json!({"F32Bits":bits})
                }
            }
            Schema::Vector(inner, n) => {
                if !(2..=4).contains(n)
                    || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
                {
                    return Err("invalid vector schema".into());
                }
                (0..*n)
                    .map(|_| self.value(inner, depth + 1))
                    .collect::<R<Vec<_>>>()?
                    .into()
            }
            Schema::Int => {
                let sign = self.byte()?;
                let bytes = self.raw()?;
                if bytes.len() > MAX_INT_BYTES {
                    return Err("snapshot Int exceeds size limit".into());
                }
                let sign = match sign {
                    0 if bytes.is_empty() => Sign::NoSign,
                    1 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Plus,
                    2 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Minus,
                    _ => return Err("noncanonical signed integer".into()),
                };
                json!({"Int":BigInt::from_bytes_le(sign,bytes).to_string()})
            }
            Schema::String => json!(std::str::from_utf8(self.raw()?).map_err(|_| "invalid UTF-8")?),
            Schema::Id => json!(format!(
                "{:032x}",
                u128::from_le_bytes(self.take(16)?.try_into().unwrap())
            )),
            Schema::Enum(names) => {
                json!(names.get(self.u32()? as usize).ok_or("invalid enum tag")?)
            }
            Schema::Record(fields) => {
                let mut obj = serde_json::Map::new();
                for (n, t) in fields {
                    obj.insert(n.clone(), self.value(t, depth + 1)?);
                }
                Value::Object(obj)
            }
            Schema::List(t) => {
                let n = self.sequence()?;
                let mut xs = Vec::new();
                for _ in 0..n {
                    xs.push(self.value(t, depth + 1)?);
                }
                Value::Array(xs)
            }
            Schema::Option(t) => match self.byte()? {
                0 => json!({"None":null}),
                1 => json!({"Some":self.value(t,depth+1)?}),
                _ => return Err("invalid Option tag".into()),
            },
            Schema::Result(a, b) => match self.byte()? {
                0 => json!({"Ok":self.value(a,depth+1)?}),
                1 => json!({"Err":self.value(b,depth+1)?}),
                _ => return Err("invalid Result tag".into()),
            },
        })
    }
}
fn event_order(e: &Event, version: u64, prior: Option<(u64, u64)>) -> R<()> {
    if e.commit == 0 || e.commit > version || prior.is_some_and(|p| p >= (e.commit, e.position)) {
        return Err("invalid snapshot event sequence".into());
    }
    Ok(())
}
pub fn encode(layout: &Layout, s: &Logical, limits: Limits) -> R<Vec<u8>> {
    if s.tables.len() != layout.roots.len() {
        return Err("snapshot root count mismatch".into());
    }
    let mut out = Vec::new();
    let mut left = limits.values;
    u64_bytes(&mut out, s.version);
    for (rows, (_, kt, vt)) in s.tables.iter().zip(&layout.roots) {
        if rows.len() > left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        count(&mut out, rows.len());
        let mut prior = None;
        for (k, v) in rows {
            if let Some(p) = prior {
                if compare(kt, p, k)? != Ordering::Less {
                    return Err("snapshot keys must be strictly ordered".into());
                }
            }
            encode_value(kt, k, &mut out, &mut left, 0, limits)?;
            encode_value(vt, v, &mut out, &mut left, 0, limits)?;
            prior = Some(k);
        }
    }
    count(&mut out, s.outbox.len());
    let mut prior = None;
    for e in &s.outbox {
        event_order(e, s.version, prior)?;
        let (_, t) = layout
            .events
            .get(e.channel)
            .ok_or("unknown event channel")?;
        u64_bytes(&mut out, e.commit);
        u64_bytes(&mut out, e.position);
        out.extend_from_slice(&(e.channel as u32).to_le_bytes());
        encode_value(t, &e.value, &mut out, &mut left, 0, limits)?;
        prior = Some((e.commit, e.position));
    }
    if HEADER
        .checked_add(out.len())
        .and_then(|n| n.checked_add(32))
        .is_none_or(|n| n > limits.bytes)
    {
        return Err("snapshot byte limit exceeded".into());
    }
    let mut bytes = Vec::new();
    bytes.extend_from_slice(MAGIC);
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&layout.program);
    bytes.extend_from_slice(&layout.schema);
    count(&mut bytes, out.len());
    bytes.extend_from_slice(&out);
    let digest = Sha256::digest(&bytes);
    bytes.extend_from_slice(&digest);
    Ok(bytes)
}
pub fn decode(layout: &Layout, bytes: &[u8], limits: Limits) -> R<Logical> {
    if bytes.len() > limits.bytes || bytes.len() < HEADER + 32 {
        return Err("snapshot byte length invalid".into());
    }
    if &bytes[..8] != MAGIC || bytes[8..12] != [1, 0, 1, 0] {
        return Err("snapshot format or semantics version mismatch".into());
    }
    if bytes[12..44] != layout.program || bytes[44..76] != layout.schema {
        return Err("snapshot program or schema identity mismatch".into());
    }
    let n = usize::try_from(u64::from_le_bytes(bytes[76..84].try_into().unwrap()))
        .map_err(|_| "snapshot length not addressable")?;
    if HEADER.checked_add(n).and_then(|v| v.checked_add(32)) != Some(bytes.len()) {
        return Err("snapshot payload length mismatch".into());
    }
    let end = bytes.len() - 32;
    if Sha256::digest(&bytes[..end]).as_slice() != &bytes[end..] {
        return Err("snapshot integrity check failed".into());
    }
    let mut r = Reader {
        bytes: &bytes[HEADER..end],
        at: 0,
        left: limits.values,
        limits,
    };
    let version = r.u64()?;
    let mut tables = vec![];
    for (_, kt, vt) in &layout.roots {
        let n = r.sequence()?;
        if n > r.left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        let mut rows: Vec<(Value, Value)> = vec![];
        for _ in 0..n {
            let k = r.value(kt, 0)?;
            let v = r.value(vt, 0)?;
            if let Some((prior, _)) = rows.last() {
                if compare(kt, prior, &k)? != Ordering::Less {
                    return Err("duplicate or unordered snapshot key".into());
                }
            }
            rows.push((k, v));
        }
        tables.push(rows);
    }
    let n = r.sequence()?;
    let mut outbox = vec![];
    let mut prior = None;
    for _ in 0..n {
        let commit = r.u64()?;
        let position = r.u64()?;
        let channel = r.u32()? as usize;
        let (_, t) = layout
            .events
            .get(channel)
            .ok_or("unknown snapshot event channel")?;
        let value = r.value(t, 0)?;
        let e = Event {
            commit,
            position,
            channel,
            value,
        };
        event_order(&e, version, prior)?;
        prior = Some((commit, position));
        outbox.push(e);
    }
    if r.at != r.bytes.len() {
        return Err("trailing snapshot payload".into());
    }
    Ok(Logical {
        version,
        tables,
        outbox,
    })
}

}
pub use portable::Limits as SnapshotLimits;
fn snapshot_layout()->portable::Layout{portable::Layout{program:[248, 162, 35, 111, 33, 221, 142, 208, 236, 67, 126, 20, 253, 225, 129, 51, 120, 20, 219, 8, 82, 190, 13, 158, 24, 211, 244, 72, 33, 151, 15, 82],schema:[25, 51, 42, 182, 190, 77, 138, 213, 99, 37, 162, 6, 160, 123, 99, 168, 218, 48, 21, 13, 197, 167, 238, 51, 123, 176, 66, 216, 5, 132, 214, 14],roots:vec![
("Rows".into(),portable::Schema::U64,portable::Schema::Record(vec![("amount".into(),portable::Schema::U64),("group".into(),portable::Schema::U64)])),
],events:vec![("seen".into(),portable::Schema::U64),
]}}
fn one_tag<'a>(v:&'a Json,_kind:&str)->Result<&'a serde_json::Map<String,Json>,String>{Ok(v.as_object().unwrap())}
fn read_0(v:&Json,d:usize)->Result<bool,String>{Ok(
v.as_bool().unwrap())}
fn write_0(v:&bool,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_1(v:&Json,d:usize)->Result<u64,String>{Ok(
v.as_u64().unwrap())}
fn write_1(v:&u64,d:usize)->Result<Json,String>{Ok(
json!(v))}
fn read_2(v:&Json,d:usize)->Result<D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c,String>{Ok(
{D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c::C0})}
fn write_2(v:&D_baa9fb170ac2322a5cbf5fab9c84873a889f82bfd5054af51e8177bfc756899c,d:usize)->Result<Json,String>{Ok(
Json::Null)}
fn read_5(v:&Json,d:usize)->Result<D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b,String>{Ok(
{let text=v.as_str().unwrap();match text{"Error.Failed"=>D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0,_=>unreachable!("caller enum precondition")}})}
fn write_5(v:&D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b,d:usize)->Result<Json,String>{Ok(
match v{D_c6927b0865f87bb196f15f68b8badb81fa1be85d4df74ec9dc19dc46fb41576b::C0=>json!("Error.Failed"),})}
fn read_6(v:&Json,d:usize)->Result<D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909,String>{Ok(
{let xs=v.as_object().unwrap();D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909::C0(read_1(xs.get("zero").unwrap(),d+1)?,read_1(xs.get("one").unwrap(),d+1)?,read_1(xs.get("other").unwrap(),d+1)?,read_1(xs.get("count").unwrap(),d+1)?)})}
fn write_6(v:&D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909,d:usize)->Result<Json,String>{Ok(
{let D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909::C0(b0,b1,b2,b3)=v;json!({"zero":write_1(&b0,d+1)?,"one":write_1(&b1,d+1)?,"other":write_1(&b2,d+1)?,"count":write_1(&b3,d+1)?})})}
fn read_7(v:&Json,d:usize)->Result<D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f,String>{Ok(
{let xs=v.as_object().unwrap();D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(read_1(xs.get("amount").unwrap(),d+1)?,read_1(xs.get("group").unwrap(),d+1)?)})}
fn write_7(v:&D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f,d:usize)->Result<Json,String>{Ok(
{let D_215f1988e0a4fdacc8137a23ea1add557e914b7eece919e8e934778f57d5b35f::C0(b0,b1)=v;json!({"amount":write_1(&b0,d+1)?,"group":write_1(&b1,d+1)?})})}
fn read_8(v:&Json,d:usize)->Result<D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f,String>{Ok(
{let xs=one_tag(v,"Option")?;if let Some(x)=xs.get("Some"){D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f::C1(std::sync::Arc::new(read_7(x,d+1)?))}else{D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f::C0}})}
fn write_8(v:&D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f,d:usize)->Result<Json,String>{Ok(
match v{D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f::C0=>json!({"None":null}),D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f::C1(x)=>json!({"Some":write_7(x,d+1)?})})}
fn read_9(v:&Json,d:usize)->Result<D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f,String>{Ok(
{let xs=one_tag(v,"Result")?;if let Some(x)=xs.get("Ok"){D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(std::sync::Arc::new(read_2(x,d+1)?))}else{let x=xs.get("Err").unwrap();D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(std::sync::Arc::new(read_5(x,d+1)?))}})}
fn write_9(v:&D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f,d:usize)->Result<Json,String>{Ok(
match v{D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C0(x)=>json!({"Ok":write_2(x,d+1)?}),D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f::C1(x)=>json!({"Err":write_5(x,d+1)?})})}
fn logical_from_tables(tables:&[Vec<(Json,Json)>])->Result<D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09,String>{if tables.len()!=1{return Err("representation table count mismatch".into())}
let rows=&tables[0];let mut root0=D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0;for (key,row) in rows.iter().rev(){root0=D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(read_1(key,0)?,std::sync::Arc::new(read_7(row,0)?),std::sync::Arc::new(root0));}
Ok(D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::new(root0)))}
fn logical_tables(state:&D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09)->Result<Vec<Vec<(Json,Json)>>,String>{let D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(r0)=state;
let mut rows0=vec![];let mut cursor=r0.as_ref();loop{match cursor{D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0=>break,D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C1(key,value,tail)=>{rows0.push((write_1(key,0)?,write_7(value,0)?));cursor=tail.as_ref();}}}
Ok(vec![rows0])}
fn logical_events(events:&D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7)->Result<Vec<(usize,Json)>,String>{let mut cursor=events;let mut out=vec![];loop{match cursor{D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C0=>break,D_b4d0f9b60a552013f78ef04199e0d2ca5520c3ed5626d4f42e876d42fc41f8e7::C1(event,tail)=>{let value=match event.as_ref(){
D_d762bb1af249ac8e4d79ab5c82bc7e5d6e1a8239b27bfd12dbfeb76c3db794a1::C0(value)=>(0,write_1(value,0)?),
};out.push(value);cursor=tail.as_ref();}}}Ok(out)}
pub use portable::Event;
pub struct Outcome<T>{pub result:T,pub committed:bool,pub version:u64,pub events:Vec<Event>}
pub struct OutcomeView<'a,T>{pub result:T,pub committed:bool,pub version:u64,pub events:&'a[Event]}
impl<T> OutcomeView<'_,T>{pub fn into_owned(self)->Outcome<T>{Outcome{result:self.result,committed:self.committed,version:self.version,events:self.events.to_vec()}}}
pub struct State{physical:D_76575cf1ee15f1bf520c65543eb372ea3fb93cec792c839f76341962a00e9947,version:u64,outbox:Vec<portable::Event>,layout:portable::Layout}
impl State{
// CALLER CONTRACT: arguments must have the declared types and canonical values.
// No runtime type validation. Malformed input may panic, trap or corrupt state.
pub fn new()->Result<Self,String>{let logical=D_8eb9db7b6de245ed4143af498b25a4a6f826ac268eacd4277ef972b44197fe09::C0(std::sync::Arc::new(D_626c3b47cc607cc0ec9e21cb6d05aac99aca953f387247ecbc4ebe3b1acb2e12::C0));Ok(Self{physical:f_1ac082f699bf8e068df795bd7cd975c1c5ed13616fb850ecdfe304d187585d29(&logical),version:0,outbox:vec![],layout:snapshot_layout()})}
pub fn restore(bytes:&[u8])->Result<Self,String>{let layout=snapshot_layout();let saved=portable::decode(&layout,bytes,SnapshotLimits::default())?;let logical=logical_from_tables(&saved.tables)?;Ok(Self{physical:f_1ac082f699bf8e068df795bd7cd975c1c5ed13616fb850ecdfe304d187585d29(&logical),version:saved.version,outbox:saved.outbox,layout})}
pub fn checkpoint(&self)->Result<Vec<u8>,String>{let logical=f_f137ad14880d722826ba61d21bb95fd94e16e99431673daf2aefe85791023a26(&(self.physical));portable::encode(&self.layout,&portable::Logical{version:self.version,tables:logical_tables(&logical)?,outbox:self.outbox.clone()},SnapshotLimits::default())}
pub fn version(&self)->u64{self.version}
pub fn outbox_json(&self)->Json{Json::Array(self.outbox.iter().map(|e|json!({"commit":e.commit,"position":e.position,"channel":self.layout.events[e.channel].0,"value":e.value})).collect())}
pub fn acknowledge_through(&mut self,commit:u64,position:u64){self.outbox.retain(|e|(e.commit,e.position)>(commit,position));}
pub fn query_groups(&self,)->D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909{q_a31c77328e79510dd0d950aff8e6f58fd7bbd71bfb152c12fcaead232f39bc49(&(self.physical),self.version)}
pub fn query_get(&self,a0:u64)->D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f{q_33456c6b9ef6209c75a1f19999587acaaff98b6f47024a047476d87bf719f57c(&(self.physical),self.version,a0)}
pub fn invoke_view_put(&mut self,a0:u64,a1:u64,a2:u64,a3:bool)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=f_078801970e258a449094e4f1a34a7c597cf9efaed0ebf76d275af684278a4182(&(self.physical),self.version,a0,a1,a2,a3);let observed=f_7597c22aa4906c1f171628b86c5e4a2fbebc3664346581bcbe807421448414b9(&(executed));let next=f_ea0fea581c89e9160d21dba6ef54626f2630d3df039f15aff1c821cac5fe883e(&(executed));
let(result,committed,version,events)=match &observed{D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_erase(&mut self,a0:u64,a1:bool)->Result<OutcomeView<'_,D_92368800572ebbcfe203c07e2d7e7e00d60743f84b2b815a526d470566792f7f>,String>{
let executed=f_8bbd18dbb03bbbe491373f380012e93500119152952f138315445682c93df40f(&(self.physical),self.version,a0,a1);let observed=f_7597c22aa4906c1f171628b86c5e4a2fbebc3664346581bcbe807421448414b9(&(executed));let next=f_ea0fea581c89e9160d21dba6ef54626f2630d3df039f15aff1c821cac5fe883e(&(executed));
let(result,committed,version,events)=match &observed{D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(reply,committed,version,_,events)=>(reply.as_ref().clone(),*committed,*version,events),D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(..)=>return Err("commit sequence exhausted".into())};let start=self.outbox.len();let staged=logical_events(events)?;if committed{self.outbox.try_reserve(staged.len()).map_err(|_|"outbox allocation failure")?;for(position,(channel,value))in staged.into_iter().enumerate(){self.outbox.push(Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(OutcomeView{result,committed,version,events:&self.outbox[start..]})}
pub fn invoke_view_groups(&mut self,)->Result<OutcomeView<'_,D_98bb83eb82880e507fc88bfcd28de21a712b06bca8d90ecf06dd10da4c90f909>,String>{
let result=q_a31c77328e79510dd0d950aff8e6f58fd7bbd71bfb152c12fcaead232f39bc49(&(self.physical),self.version);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_view_get(&mut self,a0:u64)->Result<OutcomeView<'_,D_a7326c99ad1f7e147305d44668e22f1ac6a2a4b41e0e614429e9039bc754091f>,String>{
let result=q_33456c6b9ef6209c75a1f19999587acaaff98b6f47024a047476d87bf719f57c(&(self.physical),self.version,a0);Ok(OutcomeView{result,committed:false,version:self.version,events:&self.outbox[self.outbox.len()..]})}
pub fn invoke_json(&mut self,name:&str,args:&Json)->Result<Json,String>{match name{
"put"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_1(&xs[1],0)?;
let a2=read_1(&xs[2],0)?;
let a3=read_0(&xs[3],0)?;
let executed=f_078801970e258a449094e4f1a34a7c597cf9efaed0ebf76d275af684278a4182(&(self.physical),self.version,a0,a1,a2,a3);
let observed=f_7597c22aa4906c1f171628b86c5e4a2fbebc3664346581bcbe807421448414b9(&(executed));let next=f_ea0fea581c89e9160d21dba6ef54626f2630d3df039f15aff1c821cac5fe883e(&(executed));let(reply,committed,version,events)=match &observed{D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_9(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"erase"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let a1=read_0(&xs[1],0)?;
let executed=f_8bbd18dbb03bbbe491373f380012e93500119152952f138315445682c93df40f(&(self.physical),self.version,a0,a1);
let observed=f_7597c22aa4906c1f171628b86c5e4a2fbebc3664346581bcbe807421448414b9(&(executed));let next=f_ea0fea581c89e9160d21dba6ef54626f2630d3df039f15aff1c821cac5fe883e(&(executed));let(reply,committed,version,events)=match &observed{D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C0(reply,committed,version,_,events)=>(reply,*committed,*version,events),D_1d9095390a8cfe8c9b3d0611e22bd977c9bda454d2e86a8580e7f81b36a6fecb::C1(..)=>return Err("commit sequence exhausted".into())};let result=write_9(reply,0)?;let staged=logical_events(events)?;let mut published=vec![];
if committed{let channels:&[&str]=&["seen"];for(position,(channel,value))in staged.into_iter().enumerate(){published.push(json!({"commit":version,"position":position as u64,"channel":channels[channel],"value":value}));self.outbox.push(portable::Event{commit:version,position:position as u64,channel,value});}}self.physical=next;self.version=version;Ok(json!({"result":result,"committed":committed,"version":version,"events":published}))},
"groups"=>{let xs=args.as_array().unwrap();
let reply=q_a31c77328e79510dd0d950aff8e6f58fd7bbd71bfb152c12fcaead232f39bc49(&(self.physical),self.version);let result=write_6(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
"get"=>{let xs=args.as_array().unwrap();
let a0=read_1(&xs[0],0)?;
let reply=q_33456c6b9ef6209c75a1f19999587acaaff98b6f47024a047476d87bf719f57c(&(self.physical),self.version,a0);let result=write_8(&reply,0)?;Ok(json!({"result":result,"committed":false,"version":self.version,"events":[]}))},
_=>Err(format!("unknown action {name}"))}}}
