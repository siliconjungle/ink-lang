//! Literal checked definition bodies with a bounded, target-neutral word ABI.
use ink_core::{
    definition::CheckedDefinition,
    library::Object,
    logic::{Declaration, Sort, Term},
    LangResult,
};
use serde_json::json;
use std::collections::{BTreeMap, BTreeSet};
pub struct Emission {
    pub c: String,
    pub manifest: serde_json::Value,
}
struct Lower<'a> {
    objects: &'a BTreeMap<String, Object>,
    selected: BTreeSet<String>,
    types: BTreeMap<String, usize>,
    next: usize,
    nodes: usize,
}
impl Lower<'_> {
    fn fresh(&mut self) -> String {
        let n = format!("v{}", self.next);
        self.next += 1;
        n
    }
    fn select_sort(&mut self, s: &Sort) -> LangResult<()> {
        if let Sort::Data(id) = s {
            self.select(id)?;
        }
        Ok(())
    }
    fn select(&mut self, id: &str) -> LangResult<()> {
        if !self.selected.insert(id.into()) {
            return Ok(());
        }
        let d = self
            .objects
            .get(id)
            .ok_or("missing definition dependency")?
            .declaration
            .clone();
        match d {
            Declaration::Datatype { constructors } => {
                for c in constructors {
                    for s in c.fields {
                        self.select_sort(&s)?;
                    }
                }
            }
            Declaration::Function {
                params,
                result,
                body,
                ..
            } => {
                for (_, s) in params {
                    self.select_sort(&s)?;
                }
                self.select_sort(&result)?;
                self.select_term(&body, 0)?;
            }
            _ => return Err("non-executable dependency".into()),
        }
        Ok(())
    }
    fn step(&mut self, depth: usize) -> LangResult<()> {
        self.nodes += 1;
        if depth > 128 || self.nodes > 200000 {
            return Err("definition lowering resource limit".into());
        }
        Ok(())
    }
    fn select_term(&mut self, t: &Term, depth: usize) -> LangResult<()> {
        self.step(depth)?;
        match t {
            Term::Construct {
                datatype,
                arguments,
                ..
            } => {
                self.select(datatype)?;
                for a in arguments {
                    self.select_term(a, depth + 1)?;
                }
            }
            Term::Call {
                function,
                arguments,
            } => {
                self.select(function)?;
                for a in arguments {
                    self.select_term(a, depth + 1)?;
                }
            }
            Term::SelfCall(args) => {
                for a in args {
                    self.select_term(a, depth + 1)?;
                }
            }
            Term::Binary { left, right, .. } => {
                self.select_term(left, depth + 1)?;
                self.select_term(right, depth + 1)?;
            }
            Term::If {
                condition,
                on_true,
                on_false,
            } => {
                self.select_term(condition, depth + 1)?;
                self.select_term(on_true, depth + 1)?;
                self.select_term(on_false, depth + 1)?;
            }
            Term::Match {
                scrutinee,
                branches,
            } => {
                self.select_term(scrutinee, depth + 1)?;
                for b in branches {
                    self.select_term(&b.body, depth + 1)?;
                }
            }
            _ => (),
        }
        Ok(())
    }
    fn validation(&self, s: &Sort, value: &str, current: &str) -> LangResult<String> {
        Ok(match s {
            Sort::Bool => format!("({value}.tag==0&&{value}.bits<=1)"),
            Sort::U64 => format!("({value}.tag==1)"),
            Sort::Data(id) => format!("valid_{id}(ctx,{value},depth+1)"),
            Sort::SelfType => format!("valid_{current}(ctx,{value},depth+1)"),
        })
    }
    fn expr(
        &mut self,
        t: &Term,
        env: &BTreeMap<String, String>,
        current: &str,
        lines: &mut String,
        depth: usize,
    ) -> LangResult<String> {
        self.step(depth)?;
        let value = match t {
            Term::Var(n) => {
                return env
                    .get(n)
                    .cloned()
                    .ok_or("unbound definition variable".into())
            }
            Term::Bool(b) => format!("def_scalar(0,{})", u8::from(*b)),
            Term::U64(n) => format!("def_scalar(1,UINT64_C({n}))"),
            Term::Construct {
                datatype,
                constructor,
                arguments,
            } => {
                let args = arguments
                    .iter()
                    .map(|a| self.expr(a, env, current, lines, depth + 1))
                    .collect::<LangResult<Vec<_>>>()?;
                format!(
                    "def_construct(ctx,{}, {constructor}, {}, {})",
                    self.types[datatype],
                    args.len(),
                    if args.is_empty() {
                        "0".into()
                    } else {
                        format!("(DefValue[]){{{}}}", args.join(","))
                    }
                )
            }
            Term::Call {
                function,
                arguments,
            } => self.call(function, arguments, env, current, lines, depth)?,
            Term::SelfCall(arguments) => {
                self.call(current, arguments, env, current, lines, depth)?
            }
            Term::Binary { op, left, right } => {
                let a = self.expr(left, env, current, lines, depth + 1)?;
                let b = self.expr(right, env, current, lines, depth + 1)?;
                if let Some(operator)=op.strip_prefix("f32:") {
                    let index=["+","-","*","neg","==","!=","<","<=",">",">=","sqrt","div","floor","ceil","trunc","round_ties_even","is_nan","is_finite"].iter().position(|x|*x==operator).ok_or("binary32 operator")?;
                    format!("def_scalar({},f32_word({index},{a}.bits,{b}.bits))",usize::from(index<4 || (10..16).contains(&index)))
                } else {match op.as_str() {
                    "quot" | "rem" => format!("def_scalar(1,({b}.bits?({a}.bits {} {b}.bits):0))",if op=="quot"{"/"}else{"%"}),
                    "&" => format!("def_scalar(1,{a}.bits&{b}.bits)"),
                    "+" | "-" | "*" => format!("def_scalar(1,{a}.bits{op}{b}.bits)"),
                    "==" => format!("def_scalar(0,def_equal(ctx,{a},{b},0))"),
                    "!=" => format!("def_scalar(0,!def_equal(ctx,{a},{b},0))"),
                    "&&" => format!("def_scalar(0,{a}.bits&{b}.bits)"),
                    "||" => format!("def_scalar(0,{a}.bits|{b}.bits)"),
                    "<" | "<=" | ">" | ">=" => format!("def_scalar(0,{a}.bits{op}{b}.bits)"),
                    _ => return Err("unsupported definition primitive".into()),
                }}
            }
            Term::If {
                condition,
                on_true,
                on_false,
            } => {
                let c = self.expr(condition, env, current, lines, depth + 1)?;
                let out = self.fresh();
                lines.push_str(&format!("DefValue {out};if({c}.bits){{"));
                let a = self.expr(on_true, env, current, lines, depth + 1)?;
                lines.push_str(&format!("{out}={a};}}else{{"));
                let b = self.expr(on_false, env, current, lines, depth + 1)?;
                lines.push_str(&format!("{out}={b};}}"));
                return Ok(out);
            }
            Term::Match {
                scrutinee,
                branches,
            } => {
                let v = self.expr(scrutinee, env, current, lines, depth + 1)?;
                let out = self.fresh();
                lines.push_str(&format!(
                    "DefValue {out}=def_scalar(0,0);switch({v}.constructor){{"
                ));
                for (i, b) in branches.iter().enumerate() {
                    let mut local = env.clone();
                    lines.push_str(&format!("case {i}:{{"));
                    for (j, n) in b.bindings.iter().enumerate() {
                        let binder = self.fresh();
                        lines.push_str(&format!("DefValue {binder}={v}.arguments[{j}];"));
                        local.insert(n.clone(), binder);
                    }
                    let x = self.expr(&b.body, &local, current, lines, depth + 1)?;
                    lines.push_str(&format!("{out}={x};break;}}"));
                }
                lines.push_str("default:ctx->error=1;return def_scalar(0,0);}");
                return Ok(out);
            }
        };
        let out = self.fresh();
        lines.push_str(&format!(
            "DefValue {out}={value};if(ctx->error)return def_scalar(0,0);"
        ));
        Ok(out)
    }
    fn call(
        &mut self,
        id: &str,
        args: &[Term],
        env: &BTreeMap<String, String>,
        current: &str,
        lines: &mut String,
        depth: usize,
    ) -> LangResult<String> {
        let args = args
            .iter()
            .map(|a| self.expr(a, env, current, lines, depth + 1))
            .collect::<LangResult<Vec<_>>>()?;
        Ok(format!(
            "d_{id}(ctx{})",
            if args.is_empty() {
                String::new()
            } else {
                format!(",{}", args.join(","))
            }
        ))
    }
}
pub fn lower(checked: &CheckedDefinition) -> LangResult<Emission> {
    let objects = checked
        .bundle()
        .objects
        .iter()
        .map(|(id, raw)| {
            Ok((
                id.clone(),
                serde_json::from_str::<Object>(raw).map_err(|e| e.to_string())?,
            ))
        })
        .collect::<LangResult<BTreeMap<_, _>>>()?;
    let mut lower = Lower {
        objects: &objects,
        selected: BTreeSet::new(),
        types: BTreeMap::new(),
        next: 0,
        nodes: 0,
    };
    for id in checked.exports() {
        lower.select(checked.choices().get(id).unwrap_or(id))?;
    }
    let ids: Vec<_> = lower
        .selected
        .iter()
        .filter(|id| matches!(objects[*id].declaration, Declaration::Datatype { .. }))
        .cloned()
        .collect();
    lower.types = ids
        .iter()
        .enumerate()
        .map(|(i, id)| (id.clone(), i))
        .collect();
    let mut source = include_str!("portable_definition.c").to_owned()+include_str!("definition-f32.c.txt");
    for id in &lower.selected {
        match &objects[id].declaration {
            Declaration::Datatype { .. } => source.push_str(&format!(
                "static int valid_{id}(DefContext*,DefValue,uint32_t);\n"
            )),
            Declaration::Function { params, .. } => source.push_str(&format!(
                "static DefValue d_{id}(DefContext*{});\n",
                (0..params.len()).map(|_| ",DefValue").collect::<String>()
            )),
            _ => return Err("non-executable selected definition".into()),
        }
    }
    for id in lower.selected.clone() {
        match &objects[&id].declaration {
            Declaration::Datatype { constructors } => {
                source.push_str(&format!("static int valid_{id}(DefContext*ctx,DefValue v,uint32_t depth){{if(depth>64||!def_tick(ctx)||v.tag!=2||v.datatype!={})return 0;switch(v.constructor){{",lower.types[&id]));
                for (i, c) in constructors.iter().enumerate() {
                    source.push_str(&format!("case {i}:return v.count=={}", c.fields.len()));
                    for (j, s) in c.fields.iter().enumerate() {
                        source.push_str(&format!(
                            "&&{}",
                            lower.validation(s, &format!("v.arguments[{j}]"), &id)?
                        ));
                    }
                    source.push(';');
                }
                source.push_str("default:return 0;}}\n");
            }
            Declaration::Function { params, body, .. } => {
                let mut env = BTreeMap::new();
                let mut args = vec![];
                for (n, _) in params {
                    let v = lower.fresh();
                    env.insert(n.clone(), v.clone());
                    args.push(format!(",DefValue {v}"));
                }
                let mut lines = String::new();
                let value = lower.expr(body, &env, &id, &mut lines, 0)?;
                source.push_str(&format!("static DefValue d_{id}(DefContext*ctx{}){{if(!def_tick(ctx))return def_scalar(0,0);{lines}return {value};}}\n",args.join("")));
            }
            _ => unreachable!(),
        }
    }
    source.push_str("uint32_t ink_definition_call(uint32_t function,const uint32_t*input,uint32_t words){DefContext storage={0,0,100000000};DefContext*ctx=&storage;DefValue args[64];uint32_t count=0;if(!def_input(ctx,input,words,args,&count))return 0;DefValue result=def_scalar(0,0);switch(function){\n");
    for (i, id) in checked.exports().iter().enumerate() {
        let Declaration::Function { params, .. } = &objects[id].declaration else {
            return Err("definition export is not a function".into());
        };
        if params.len() > 64 {
            return Err("definition parameter limit".into());
        }
        source.push_str(&format!(
            "case {i}:{{uint32_t depth=0;if(count!={}",
            params.len()
        ));
        for (j, (_, s)) in params.iter().enumerate() {
            source.push_str(&format!(
                "||!({})",
                lower.validation(s, &format!("args[{j}]"), id)?
            ));
        }
        source.push_str(")return 0;result=d_");
        source.push_str(checked.choices().get(id).unwrap_or(id));
        source.push_str("(ctx");
        for j in 0..params.len() {
            source.push_str(&format!(",args[{j}]"));
        }
        source.push_str(");break;}\n");
    }
    source.push_str("default:return 0;}if(ctx->error)return 0;def_output_count=0;def_output_words=3;def_output[1]=1;uint32_t root=def_write(ctx,result,0);if(ctx->error)return 0;def_output[0]=def_output_count;def_output[2]=root;return def_output_words;}\n");
    if source.len() > 16000000 {
        return Err("definition source size limit".into());
    }
    let identity = ink_core::registry::identity(&(
        "ink-sealed-executable-v1",
        checked.bundle_sha256(),
        checked.exports(),
        checked.choices(),
    ))?;
    Ok(Emission {
        c: source,
        manifest: json!({"schema":1,"semantics":"ink-definition-c-words-v1","executable":identity,"exports":checked.exports(),"datatypes":ids,"checked_closure":checked.closure(),"executable_closure":lower.selected,"trusted":["literal C emitter","word codecs","C compiler or WebAssembly engine"]}),
    })
}
