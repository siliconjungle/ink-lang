use ink_core::{core::Type, LangResult};
pub fn expression(n: &str, a: &[String], first: Option<&Type>) -> LangResult<String> {
    let x = &a[0];
    Ok(match n {
        "sqrt" => format!("ink_f32_canonical(__builtin_sqrtf({x}))"),
        "f32_div" => format!("ink_f32_canonical(({x})/({}))", a[1]),
        "floor" | "ceil" | "trunc" => format!("ink_f32_canonical(__builtin_{n}f({x}))"),
        "round_ties_even" => format!("ink_round_ties_even({x})"),
        "is_nan" => format!("(__builtin_isnan({x})!=0)"),
        "is_finite" => format!("(__builtin_isfinite({x})!=0)"),
        "f32_bits" => format!("ink_f32_bits({x})"),
        "f32_from_bits" => format!("ink_f32({x})"),
        "f32_from_u32" | "f32_from_u64" | "f32_from_i32" => format!("((float)({x}))"),
        "popcount" | "leading_zeros" | "trailing_zeros" => {
            let wide = first == Some(&Type::U64);
            let width = if wide { 64 } else { 32 };
            let arg = format!("(({} )({x}))", if wide { "uint64_t" } else { "uint32_t" });
            let op = match n {
                "popcount" => "popcount",
                "leading_zeros" => "clz",
                _ => "ctz",
            };
            // Bind once: even an ordinary helper may contain emitted loops/side effects.
            if n == "popcount" {
                format!("__builtin_{op}{}({arg})", if wide { "ll" } else { "" })
            } else {
                format!("ink_{op}{width}({arg})")
            }
        }
        _ => return Err(format!("primitive {n} requires complete value ABI")),
    })
}
