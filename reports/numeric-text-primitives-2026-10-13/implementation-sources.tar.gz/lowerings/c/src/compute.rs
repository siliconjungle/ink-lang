//! C pure compute lowering. Logical values have a versioned packed ABI;
//! shader eligibility does not assert or select an optimisation law.
use crate::{check, core, syntax::*, LangResult};
use std::collections::BTreeMap;
type Env = BTreeMap<String, (String, Type)>;
// Check free references with lexical shadowing; let initializers are outside
// the new binding's scope. This recognizes no algebraic identity.
pub use ink_core::compute_values::needed;

fn name(t: &Type) -> LangResult<String> {
    Ok(match t {
        Type::U32 => "uint32_t".into(),
        Type::U64 => "uint64_t".into(),
        Type::I32 => "int32_t".into(),
        Type::F32 => "float".into(),
        Type::Bool => "uint32_t".into(),
        Type::Vector(t, n) => format!("ink_v{n}_{}", name(t)?.replace("_t", "")),
        Type::Named(n) => format!("ink_r_{n}"),
        Type::List(t) | Type::Buffer(t) => format!("ink_l_{}", name(t)?.replace("_t", "")),
        _ => {
            return Err(
                "compute ABI supports numeric, Bool, vector, flat record and list values".into(),
            )
        }
    })
}

fn lanes(t: &Type, p: &Program, _gpu: bool) -> LangResult<usize> {
    ink_abi::flat_width(&ink_abi::describe(t, &p.records, &p.enums, &p.ids)?)
}

struct Emitter<'a> {
    p: &'a Program,
    lines: String,
    next: usize,
    budget: usize,
    depth: usize,
}
impl Emitter<'_> {
    fn fresh(&mut self) -> String {
        let n = format!("t{}", self.next);
        self.next += 1;
        n
    }
    fn line(&mut self, s: impl AsRef<str>) {
        self.lines.push_str(s.as_ref());
        self.lines.push('\n');
    }
    fn types(env: &Env) -> check::Env {
        env.iter()
            .map(|(n, (_, t))| (n.clone(), t.clone()))
            .collect()
    }
    fn ty(&self, t: &Type) -> LangResult<String> {
        {
            name(t)
        }
    }
    fn bind(&mut self, t: &Type, v: &str) -> LangResult<String> {
        let n = self.fresh();
        let ty = self.ty(t)?;
        self.line(format!("{ty} {n}={v};"));
        {
            self.line(format!("(void){n};"));
        }
        Ok(n)
    }
    fn add(&self, op: &str, a: &str, b: &str, t: &Type) -> String {
        if *t == Type::I32 && ["+", "-", "*"].contains(&op) {
            {
                format!("ink_i32((uint32_t)({a}) {op} (uint32_t)({b}))")
            }
        } else if *t == Type::F32 && ["+", "-", "*"].contains(&op) {
            format!("ink_f32_canonical({a} {op} {b})")
        } else {
            format!("({a} {op} {b})")
        }
    }

    fn scalar(&mut self, e: &Expr, env: &Env, t: &Type) -> LangResult<String> {
        if self.depth >= 48 {
            return Err(
                "scalar lowering depth budget exceeded; use shallower helpers for GPU execution"
                    .into(),
            );
        }
        self.depth += 1;
        let result = self.scalar_inner(e, env, t);
        self.depth -= 1;
        result
    }
    fn scalar_inner(&mut self, e: &Expr, env: &Env, t: &Type) -> LangResult<String> {
        if self.budget == 0 {
            return Err("compute expression budget exceeded".into());
        }
        self.budget -= 1;
        check::infer_as(e, &Self::types(env), self.p, t)?;
        match e {
            Expr::Num(n) => Ok(match t {
                Type::F32 => {
                    format!("{n}.0f")
                }
                Type::I32 => format!("{n}{}", { "" }),
                Type::U64 => format!("UINT64_C({n})"),
                _ => format!("{n}u"),
            }),
            Expr::Float(bits) => Ok(format!("ink_f32({bits}u)")),
            Expr::Bool(b) => Ok((*b as u8).to_string()),
            Expr::Var(n) => env
                .get(n)
                .map(|(v, _)| v.clone())
                .ok_or("unknown compute binding".into()),
            Expr::Neg(x) => {
                if *t == Type::I32 {
                    if let Expr::Num(n) = **x {
                        if n == 2147483648 {
                            return Ok("ink_i32(2147483648u)".into());
                        }
                    }
                }
                let a = self.scalar(x, env, t)?;
                Ok(if *t == Type::I32 {
                    self.add("-", "0", &a, t)
                } else if *t == Type::U32 {
                    format!("(0u - ({a}))")
                } else {
                    format!("(-({a}))")
                })
            }
            Expr::Let(n, annotation, x, b) => {
                let xt = check::infer_context(x, &Self::types(env), self.p, annotation.as_deref())?;
                let a = if matches!(xt, Type::List(_)) {
                    self.list(x, env, Some(&xt))?
                } else {
                    self.scalar(x, env, &xt)?
                };
                let v = self.bind(&xt, &a)?;
                let mut local = env.clone();
                local.insert(n.clone(), (v, xt));
                self.scalar(b, &local, t)
            }
            Expr::Field(x, n) => {
                let xt = check::infer(x, &Self::types(env), self.p)?;
                let a = self.scalar(x, env, &xt)?;
                Ok(format!(
                    "({a}).{}",
                    if matches!(xt, Type::Named(_)) {
                        format!("ink_f_{n}")
                    } else {
                        n.clone()
                    }
                ))
            }
            Expr::Record(n, fields) => {
                let schema = self.p.records[n].clone();
                let mut xs = Vec::new();
                for (k, t) in &schema {
                    let e = &fields
                        .iter()
                        .find(|(f, _)| f == k)
                        .ok_or("record field missing")?
                        .1;
                    let a = self.scalar(e, env, t)?;
                    xs.push(self.bind(t, &a)?);
                }
                Ok(format!("(ink_r_{n}){{{}}}", xs.join(",")))
            }
            Expr::Binary(op, a, b) => {
                let ot = if check::is_number(t) {
                    t.clone()
                } else {
                    check::hint(a, &Self::types(env), self.p)
                        .or_else(|| check::hint(b, &Self::types(env), self.p))
                        .unwrap_or(Type::Bool)
                };
                let x = self.scalar(a, env, &ot)?;
                let x = self.bind(&ot, &x)?;
                if op == "&&" || op == "||" {
                    let out = self.bind(t, &x)?;
                    self.line(format!(
                        "if ({}{out}) {{",
                        if op == "||" { "!" } else { "" }
                    ));
                    let y = self.scalar(b, env, &ot)?;
                    self.line(format!("{out}={y};\n}}"));
                    Ok(out)
                } else {
                    let y = self.scalar(b, env, &ot)?;

                    Ok(self.add(op, &x, &y, &ot))
                }
            }
            Expr::Call(n,a) if ink_core::primitives::primitive(n) => {
                let first=if ink_core::primitives::bit_count(n){a.first().map(|a|check::infer(a,&Self::types(env),self.p)).transpose()?}else{None};
                let (params,_)=ink_core::primitives::signature(n,first.as_ref())?;
                let values=a.iter().zip(params).map(|(a,t)|self.scalar(a,env,&t)).collect::<LangResult<Vec<_>>>()?;
                crate::primitive_emit::expression(n,&values,first.as_ref())
            }
            Expr::Call(n, a) if n == "choose" => {
                let c = self.scalar(&a[0], env, &Type::Bool)?;
                let out = self.fresh();
                let ty = self.ty(t)?;
                self.line(format!("{ty} {out};"));
                self.line(format!("if ({c}) {{"));
                let x = self.scalar(&a[1], env, t)?;
                self.line(format!("{out}={x};\n}} else {{"));
                let y = self.scalar(&a[2], env, t)?;
                self.line(format!("{out}={y};\n}}"));
                Ok(out)
            }
            Expr::Call(n, a) if ["vec2", "vec3", "vec4"].contains(&n.as_str()) => {
                let Type::Vector(et, _) = t else {
                    return Err("vector type missing".into());
                };
                let mut xs = Vec::new();
                for x in a {
                    let v = self.scalar(x, env, et)?;
                    xs.push(self.bind(et, &v)?);
                }
                Ok(format!("({}){{{}}}", name(t)?, xs.join(",")))
            }
            Expr::Call(n, a) if n == "buffer" => {
                let Type::Buffer(inner) = t else {
                    unreachable!()
                };
                let list = Type::List(inner.clone());
                let input = self.list(&a[0], env, Some(&list))?;
                let input = self.bind(&list, &input)?;
                let out = self.fresh();
                self.line(format!("{} {out}={{ink_alloc({input}.len,sizeof({})),{input}.len}};ink_copy({out}.data,{input}.data,{input}.len*sizeof({}));", name(t)?, name(inner)?, name(inner)?));
                Ok(out)
            }
            Expr::Method(xs, n, _)
                if matches!(xs.as_ref(), Expr::Var(v) if v == "Buffer") && n == "empty" =>
            {
                let out = self.fresh();
                let Type::Buffer(inner) = t else {
                    unreachable!()
                };
                self.line(format!(
                    "{} {out}={{ink_alloc(0,sizeof({})),0}};",
                    name(t)?,
                    name(inner)?
                ));
                Ok(out)
            }
            Expr::Call(n, a) if n == "buffer_fill" => {
                let Type::Buffer(inner) = t else {
                    unreachable!()
                };
                let len = self.scalar(&a[0], env, &Type::U32)?;
                let len = self.bind(&Type::U32, &len)?;
                let value = self.scalar(&a[1], env, inner)?;
                let value = self.bind(inner, &value)?;
                let out = self.fresh();
                let i = self.fresh();
                self.line(format!("{} {out}={{ink_alloc((size_t){len},sizeof({})),{len}}};for(uint32_t {i}=0;{i}<{len};{i}++){{{out}.data[{i}]={value};}}",name(t)?,name(inner)?));
                Ok(out)
            }
            Expr::Call(n, a) if n == "length" => {
                let xs = self.list(&a[0], env, None)?;
                Ok(format!("(uint32_t)({xs}.len)"))
            }
            Expr::Method(xs, n, a)
                if matches!(
                    check::infer(xs, &Self::types(env), self.p)?,
                    Type::Buffer(_)
                ) =>
            {
                let xt = check::infer(xs, &Self::types(env), self.p)?;
                let Type::Buffer(inner) = &xt else {
                    unreachable!()
                };
                let b = self.scalar(xs, env, &xt)?;
                let b = self.bind(&xt, &b)?;
                if n == "len" {
                    return Ok(format!("(uint32_t){b}.len"));
                }
                if n == "pop" {
                    self.line(format!("if({b}.len){{{b}.len--;}}"));
                    return Ok(b);
                }
                if n == "split_at" {
                    let at = self.scalar(&a[0], env, &Type::U32)?;
                    let at = self.bind(&Type::U32, &at)?;
                    let left = self.fresh();
                    let right = self.fresh();
                    // Consuming the owner permits disjoint views. Neither view
                    // may write outside its logical length; push/append allocate.
                    self.line(format!("size_t split_{left}={at}<{b}.len?{at}:{b}.len;{} {left}={{{b}.data,split_{left}}};{} {right}={{{b}.data+split_{left},{b}.len-split_{left}}};", name(&xt)?, name(&xt)?));
                    let Expr::Lambda(l, rest) = &a[1] else {
                        unreachable!()
                    };
                    let Expr::Lambda(r, body) = rest.as_ref() else {
                        unreachable!()
                    };
                    let mut local = env.clone();
                    local.insert(l.clone(), (left, xt.clone()));
                    local.insert(r.clone(), (right, xt.clone()));
                    return self.scalar(body, &local, &xt);
                }
                if n == "append" || n == "push" {
                    let other = if n == "append" {
                        let other = self.scalar(&a[0], env, &xt)?;
                        Some(self.bind(&xt, &other)?)
                    } else {
                        None
                    };
                    let value = if n == "push" {
                        let value = self.scalar(&a[0], env, inner)?;
                        Some(self.bind(inner, &value)?)
                    } else {
                        None
                    };
                    let extra = other
                        .as_ref()
                        .map(|v| format!("{v}.len"))
                        .unwrap_or("1".into());
                    let out = self.fresh();
                    self.line(format!("if(({extra})>UINT32_MAX||{b}.len>UINT32_MAX-({extra}))ink_fail();{} {out}={{ink_alloc({b}.len+({extra}),sizeof({})),{b}.len+({extra})}};ink_copy({out}.data,{b}.data,{b}.len*sizeof({}));", name(&xt)?, name(inner)?, name(inner)?));
                    if let Some(other) = other {
                        self.line(format!(
                            "ink_copy({out}.data+{b}.len,{other}.data,{other}.len*sizeof({}));",
                            name(inner)?
                        ));
                    } else {
                        self.line(format!("{out}.data[{b}.len]={};", value.unwrap()));
                    }
                    return Ok(out);
                }
                if n == "filter" {
                    let i = self.fresh();
                    let len = self.fresh();
                    self.line(format!(
                        "size_t {len}=0;for(uint32_t {i}=0;{i}<{b}.len;{i}++){{"
                    ));
                    let Expr::Lambda(item, body) = &a[0] else {
                        unreachable!()
                    };
                    let mut local = env.clone();
                    local.insert(item.clone(), (format!("{b}.data[{i}]"), *inner.clone()));
                    let pred = self.scalar(body, &local, &Type::Bool)?;
                    self.line(format!(
                        "if({pred}){{{b}.data[{len}++]={b}.data[{i}];}}}}{b}.len={len};"
                    ));
                    return Ok(b);
                }
                if ["map", "map_indexed", "scan"].contains(&n.as_str()) {
                    let i = self.fresh();
                    let acc = if n == "scan" {
                        Some(self.bind(inner, "0")?)
                    } else {
                        None
                    };
                    self.line(format!("for(uint32_t {i}=0;{i}<{b}.len;{i}++){{"));
                    let value = if let Some(acc) = acc {
                        self.line(format!(
                            "{acc}={};",
                            self.add("+", &acc, &format!("{b}.data[{i}]"), inner)
                        ));
                        acc
                    } else {
                        let Expr::Lambda(first, rest) = &a[0] else {
                            unreachable!()
                        };
                        let mut local = env.clone();
                        let body = if n == "map_indexed" {
                            let Expr::Lambda(item, body) = rest.as_ref() else {
                                unreachable!()
                            };
                            local.insert(first.clone(), (i.clone(), Type::U32));
                            local.insert(item.clone(), (format!("{b}.data[{i}]"), *inner.clone()));
                            body.as_ref()
                        } else {
                            local.insert(first.clone(), (format!("{b}.data[{i}]"), *inner.clone()));
                            rest.as_ref()
                        };
                        self.scalar(body, &local, inner)?
                    };
                    self.line(format!("{b}.data[{i}]={value};}}"));
                    return Ok(b);
                }
                if n == "map_parallel" {
                    self.scalar(&a[0], env, &Type::U32)?;
                    let Expr::Lambda(index, rest) = &a[1] else {
                        unreachable!()
                    };
                    let Expr::Lambda(item, body) = rest.as_ref() else {
                        unreachable!()
                    };
                    let i = self.fresh();
                    self.line(format!("for(uint32_t {i}=0;{i}<{b}.len;{i}++){{"));
                    let mut local = env.clone();
                    local.insert(index.clone(), (i.clone(), Type::U32));
                    local.insert(item.clone(), (format!("{b}.data[{i}]"), *inner.clone()));
                    let value = self.scalar(body, &local, inner)?;
                    self.line(format!("{b}.data[{i}]={value};}}"));
                    return Ok(b);
                }
                if !["at_or", "set", "swap", "truncate"].contains(&n.as_str()) {
                    return Err("unsupported packed CPU buffer method".into());
                };
                let i = self.scalar(&a[0], env, &Type::U32)?;
                let i = self.bind(&Type::U32, &i)?;
                match n.as_str() {
                    "at_or" => {
                        let out = self.fresh();
                        self.line(format!(
                            "{} {out};if({i}<{b}.len){{{out}={b}.data[{i}];}}else{{",
                            name(inner)?
                        ));
                        let v = self.scalar(&a[1], env, inner)?;
                        self.line(format!("{out}={v};}}"));
                        Ok(out)
                    }
                    "set" => {
                        let v = self.scalar(&a[1], env, inner)?;
                        self.line(format!("if({i}<{b}.len){{{b}.data[{i}]={v};}}"));
                        Ok(b)
                    }
                    "swap" => {
                        let j = self.scalar(&a[1], env, &Type::U32)?;
                        let j = self.bind(&Type::U32, &j)?;
                        let temp = self.fresh();
                        self.line(format!("if({i}<{b}.len&&{j}<{b}.len){{{} {temp}={b}.data[{i}];{b}.data[{i}]={b}.data[{j}];{b}.data[{j}]={temp};}}",name(inner)?));
                        Ok(b)
                    }
                    "truncate" => {
                        self.line(format!("if({i}<{b}.len){{{b}.len={i};}}"));
                        Ok(b)
                    }
                    _ => unreachable!(),
                }
            }
            Expr::Call(n, a) if n == "repeat_until" => {
                let limit = self.scalar(&a[0], env, &Type::U32)?;
                let limit = self.bind(&Type::U32, &limit)?;
                let initial = self.scalar(&a[1], env, t)?;
                let out = self.bind(t, &initial)?;
                let Expr::Lambda(stop_param, stop_body) = &a[2] else {
                    unreachable!()
                };
                let Expr::Lambda(index, rest) = &a[3] else {
                    unreachable!()
                };
                let Expr::Lambda(acc, body) = rest.as_ref() else {
                    unreachable!()
                };
                let i = self.fresh();
                self.line(format!("for(uint32_t {i}=0;{i}<{limit};{i}++){{"));
                let mut stop_env = env.clone();
                stop_env.insert(stop_param.clone(), (out.clone(), t.clone()));
                let stop = self.scalar(stop_body, &stop_env, &Type::Bool)?;
                self.line(format!("if({stop})break;"));
                let mut local = env.clone();
                local.insert(index.clone(), (i, Type::U32));
                local.insert(acc.clone(), (out.clone(), t.clone()));
                let next = self.scalar(body, &local, t)?;
                self.line(format!("{out}={next};}}"));
                Ok(out)
            }
            Expr::Call(n, a) if n == "repeat" => {
                let Expr::Num(bound) = a[0] else {
                    return Err("literal loop bound missing".into());
                };
                let Expr::Lambda(i, inner) = &a[2] else {
                    return Err("loop lambda missing".into());
                };
                let Expr::Lambda(acc, b) = inner.as_ref() else {
                    return Err("loop accumulator missing".into());
                };
                let x = self.scalar(&a[1], env, t)?;
                let out = self.bind(t, &x)?;
                let idx = self.fresh();
                self.line(format!("for(uint32_t {idx}=0;{idx}<{bound}u;{idx}++){{"));
                let mut local = env.clone();
                local.insert(i.clone(), (idx, Type::U32));
                local.insert(acc.clone(), (out.clone(), t.clone()));
                let v = self.scalar(b, &local, t)?;
                self.line(format!("{out}={v};\n}}"));
                Ok(out)
            }
            Expr::Call(n, a) if n == "quot_or" || n == "rem_or" => {
                let x = self.scalar(&a[0], env, t)?;
                let x = self.bind(t, &x)?;
                let y = self.scalar(&a[1], env, t)?;
                let y = self.bind(t, &y)?;
                let out = self.fresh();
                let ty = self.ty(t)?;
                self.line(format!("{ty} {out};"));
                let overflow = if *t == Type::I32 {
                    format!(" || ({x}=={} && {y}==-1)", { "ink_i32(2147483648u)" })
                } else {
                    String::new()
                };
                self.line(format!("if ({y}==0{overflow}) {{"));
                let fallback = self.scalar(&a[2], env, t)?;
                self.line(format!(
                    "{out}={fallback};\n}} else {{ {out}={x} {} {y}; }}",
                    if n == "quot_or" { "/" } else { "%" }
                ));
                Ok(out)
            }
            Expr::Method(xs, n, a) if n == "at_or" => {
                let lt = check::infer(xs, &Self::types(env), self.p)?;
                let Type::List(_et) = &lt else {
                    return Err("list required".into());
                };
                let l = self.list(xs, env, Some(&lt))?;
                let l = self.bind(&lt, &l)?;
                let idx = self.scalar(&a[0], env, &Type::U32)?;
                let idx = self.bind(&Type::U32, &idx)?;
                let out = self.fresh();
                let ty = self.ty(t)?;
                self.line(format!("{ty} {out};"));
                let (len, read) = { (format!("{l}.len"), format!("{l}.data[{idx}]")) };
                self.line(format!("if ({idx} < {len}) {{ {out}={read}; }} else {{"));
                let v = self.scalar(&a[1], env, t)?;
                self.line(format!("{out}={v};\n}}"));
                Ok(out)
            }
            Expr::Call(n, a) if n == "fold_until" => {
                let lt = check::infer(&a[0], &Self::types(env), self.p)?;
                let Type::List(inner) = &lt else {
                    return Err("fold input".into());
                };
                let l = self.list(&a[0], env, Some(&lt))?;
                let l = self.bind(&lt, &l)?;
                let initial = self.scalar(&a[1], env, t)?;
                let out = self.bind(t, &initial)?;
                let i = self.fresh();
                self.line(format!("for(size_t {i}=0;{i}<{l}.len;{i}++){{"));
                let element = self.bind(inner, &format!("{l}.data[{i}]"))?;
                let callback = |this: &mut Self, e: &Expr, output: &Type| -> LangResult<String> {
                    let Expr::Lambda(item, rest) = e else {
                        return Err("fold lambda".into());
                    };
                    let Expr::Lambda(acc, body) = rest.as_ref() else {
                        return Err("fold nested lambda".into());
                    };
                    let mut local = env.clone();
                    local.insert(item.clone(), (element.clone(), inner.as_ref().clone()));
                    local.insert(acc.clone(), (out.clone(), t.clone()));
                    this.scalar(body, &local, output)
                };
                let stop = callback(self, &a[2], &Type::Bool)?;
                let stop = self.bind(&Type::Bool, &stop)?;
                let value = callback(self, &a[3], t)?;
                self.line(format!("{out}={value};if({stop})break;}}"));
                Ok(out)
            }
            Expr::Call(n, a) if (n == "sum" || n == "count" || n == "foldr" || n == "foldl") => {
                let list_type = Type::List(Box::new(t.clone()));
                let l = self.list(&a[0], env, if n == "sum" { Some(&list_type) } else { None })?;
                let lt = check::infer_context(
                    &a[0],
                    &Self::types(env),
                    self.p,
                    if n == "sum" { Some(&list_type) } else { None },
                )?;
                let l = self.bind(&lt, &l)?;
                if n == "count" {
                    return Ok(format!("((uint64_t){l}.len)"));
                }
                let initial = if n == "foldr" || n == "foldl" {
                    self.scalar(&a[1], env, t)?
                } else {
                    "0".into()
                };
                let out = self.bind(t, &initial)?;
                let i = self.fresh();
                if n == "sum" {
                    self.line(format!("for(size_t {i}=0;{i}<{l}.len;{i}++){{"));
                    self.line(format!(
                        "{out}={};",
                        self.add("+", &out, &format!("{l}.data[{i}]"), t)
                    ));
                } else {
                    let Expr::Lambda(item, b) = &a[2] else {
                        return Err("fold lambda missing".into());
                    };
                    let Expr::Lambda(rest, b) = b.as_ref() else {
                        return Err("fold lambda missing".into());
                    };
                    self.line(if n=="foldl" {format!("for(size_t {i}=0;{i}<{l}.len;{i}++){{")}else{format!("for(size_t {i}={l}.len;{i}>0;){{ --{i};")});
                    let mut local = env.clone();
                    let Type::List(item_type) = check::infer(&a[0], &Self::types(env), self.p)?
                    else {
                        return Err("fold list type".into());
                    };
                    local.insert(item.clone(), (format!("{l}.data[{i}]"), *item_type));
                    local.insert(rest.clone(), (out.clone(), t.clone()));
                    let v = self.scalar(b, &local, t)?;
                    self.line(format!("{out}={v};"));
                }
                self.line("}");
                Ok(out)
            }
            Expr::Call(n, a) => {
                let f = self
                    .p
                    .functions
                    .iter()
                    .find(|f| &f.name == n)
                    .ok_or("unknown compute function")?
                    .clone();
                let mut values = Vec::new();
                for ((_, ty), a) in f.params.iter().zip(a) {
                    let v = if matches!(ty, Type::List(_)) {
                        self.list(a, env, Some(ty))?
                    } else {
                        self.scalar(a, env, ty)?
                    };
                    values.push(self.bind(ty, &v)?);
                }
                Ok(format!("lang_fn_{n}({})", values.join(",")))
            }
            _ => Err("unsupported scalar compute expression".into()),
        }
    }
    fn list(&mut self, e: &Expr, env: &Env, want: Option<&Type>) -> LangResult<String> {
        self.list_output(e, env, want, None)
    }
    // Only the terminal producer receives caller storage. Eager intermediates
    // retain their ordinary allocation and evaluation semantics.
    fn list_output(
        &mut self,
        e: &Expr,
        env: &Env,
        want: Option<&Type>,
        destination: Option<&str>,
    ) -> LangResult<String> {
        let t = check::infer_context(e, &Self::types(env), self.p, want)?;
        let Type::List(et) = &t else {
            return Err("list required".into());
        };
        if let Expr::Call(n, a) = e {
            if n == "parallel_map" {
                let input = self.list(&a[0], env, None)?;
                let input = self.bind(&check::infer(&a[0], &Self::types(env), self.p)?, &input)?;
                self.scalar(&a[1], env, &Type::U32)?;
                let mut local = env.clone();
                local.insert(
                    "__parallel_input".into(),
                    (input, check::infer(&a[0], &Self::types(env), self.p)?),
                );
                return self.list_output(
                    &Expr::Method(
                        Box::new(Expr::Var("__parallel_input".into())),
                        "map_indexed".into(),
                        vec![a[2].clone()],
                    ),
                    &local,
                    Some(&t),
                    destination,
                );
            }
        }
        match e {
            Expr::Var(n) => {
                let value = env.get(n).map(|(v, _)| v.clone()).ok_or("unknown list")?;
                if let Some(destination) = destination {
                    let value = self.bind(&t, &value)?;
                    let out = self.fresh();
                    self.line(format!(
                        "{} {out}={{{destination},{value}.len}};",
                        name(&t)?
                    ));
                    self.line(format!(
                        "ink_copy({out}.data,{value}.data,{value}.len*sizeof({}));",
                        name(et)?
                    ));
                    Ok(out)
                } else {
                    Ok(value)
                }
            }
            Expr::Let(n, annotation, x, b) => {
                let xt = check::infer_context(x, &Self::types(env), self.p, annotation.as_deref())?;
                if destination.is_some()
                    && xt == t
                    && ink_core::collection_facts::returned_alias(b, n)
                {
                    return self.list_output(x, env, Some(&t), destination);
                }
                let v = if matches!(xt, Type::List(_)) {
                    self.list(x, env, Some(&xt))?
                } else {
                    self.scalar(x, env, &xt)?
                };
                let v = self.bind(&xt, &v)?;
                let mut local = env.clone();
                local.insert(n.clone(), (v, xt));
                self.list_output(b, &local, Some(&t), destination)
            }
            Expr::Call(n, a) if n == "choose" => {
                let c = self.scalar(&a[0], env, &Type::Bool)?;
                let out = self.fresh();
                self.line(format!("{} {out}; if({c}){{", name(&t)?));
                let x = self.list_output(&a[1], env, Some(&t), destination)?;
                self.line(format!("{out}={x}; }}else{{"));
                let y = self.list_output(&a[2], env, Some(&t), destination)?;
                self.line(format!("{out}={y}; }}"));
                Ok(out)
            }
            Expr::Call(n, a) if n == "repeat" => {
                let Expr::Num(bound) = a[0] else {
                    return Err("loop bound".into());
                };
                let initial = self.list(&a[1], env, Some(&t))?;
                let out = self.bind(&t, &initial)?;
                let Expr::Lambda(index, inner) = &a[2] else {
                    return Err("loop index".into());
                };
                let Expr::Lambda(acc, body) = inner.as_ref() else {
                    return Err("loop accumulator".into());
                };
                let i = self.fresh();
                self.line(format!("for(uint32_t {i}=0;{i}<{bound}u;{i}++){{"));
                let mut local = env.clone();
                local.insert(index.clone(), (i, Type::U32));
                local.insert(acc.clone(), (out.clone(), t.clone()));
                let next = self.list(body, &local, Some(&t))?;
                self.line(format!("{out}={next};}}"));
                Ok(out)
            }
            Expr::Call(n, a) => {
                let f = self
                    .p
                    .functions
                    .iter()
                    .find(|f| &f.name == n)
                    .ok_or("unknown function")?
                    .clone();
                let mut values = Vec::new();
                for ((_, ty), a) in f.params.iter().zip(a) {
                    let v = if matches!(ty, Type::List(_)) {
                        self.list(a, env, Some(ty))?
                    } else {
                        self.scalar(a, env, ty)?
                    };
                    values.push(self.bind(ty, &v)?);
                }
                if let Some(destination) = destination {
                    let len = self.fresh();
                    values.push(destination.to_owned());
                    self.line(format!(
                        "size_t {len}=lang_fn_{n}_into({});",
                        values.join(",")
                    ));
                    let out = self.fresh();
                    self.line(format!("{} {out}={{{destination},{len}}};", name(&t)?));
                    Ok(out)
                } else {
                    Ok(format!("lang_fn_{n}({})", values.join(",")))
                }
            }
            Expr::Method(xs, m, _)
                if m == "freeze"
                    && matches!(
                        check::infer(xs, &Self::types(env), self.p)?,
                        Type::Buffer(_)
                    ) =>
            {
                let owner_type = Type::Buffer(et.clone());
                let value = self.scalar(xs, env, &owner_type)?;
                let value = self.bind(&owner_type, &value)?;
                if let Some(destination) = destination {
                    self.line(format!(
                        "ink_copy({destination},{value}.data,{value}.len*sizeof({}));",
                        name(et)?
                    ));
                    let out = self.fresh();
                    self.line(format!(
                        "{} {out}={{{destination},{value}.len}};",
                        name(&t)?
                    ));
                    Ok(out)
                } else {
                    Ok(value)
                }
            }
            Expr::Method(xs, m, a) if m == "concat" => {
                let left = self.list(xs, env, Some(&t))?;
                let left = self.bind(&t, &left)?;
                let right = self.list(&a[0], env, Some(&t))?;
                let right = self.bind(&t, &right)?;
                let len = self.fresh();
                // Length overflow is an allocation invariant, not an input type check.
                self.line(format!("if({left}.len>SIZE_MAX-{right}.len) ink_fail();"));
                self.line(format!("size_t {len}={left}.len+{right}.len;"));
                let out = self.fresh();
                let storage = destination
                    .map(str::to_owned)
                    .unwrap_or(format!("ink_alloc({len},sizeof({}))", name(et)?));
                self.line(format!("{} {out}={{{storage},{len}}};", name(&t)?,));
                // Byte copies preserve F32 payloads and all flat element layouts.
                self.line(format!(
                    "ink_copy({out}.data,{left}.data,{left}.len*sizeof({}));",
                    name(et)?
                ));
                self.line(format!(
                    "ink_copy({out}.data+{left}.len,{right}.data,{right}.len*sizeof({}));",
                    name(et)?
                ));
                Ok(out)
            }
            Expr::Method(xs, m, a) => {
                let src = self.list(xs, env, if m == "filter" { Some(&t) } else { None })?;
                let source_type = check::infer_context(
                    xs,
                    &Self::types(env),
                    self.p,
                    if m == "filter" { Some(&t) } else { None },
                )?;
                let src = self.bind(&source_type, &src)?;
                let Type::List(st) = source_type else {
                    return Err("list required".into());
                };
                let other = if m == "zip" {
                    let value = self.list(&a[0], env, None)?;
                    let ty = check::infer(&a[0], &Self::types(env), self.p)?;
                    Some(self.bind(&ty, &value)?)
                } else {
                    None
                };
                let len = other
                    .as_ref()
                    .map(|o| format!("({src}.len < {o}.len ? {src}.len : {o}.len)"))
                    .unwrap_or(format!("{src}.len"));
                let out = self.fresh();
                let storage = if let Some(destination) = destination {
                    destination.to_owned()
                } else {
                    format!("ink_alloc({len},sizeof({}))", name(et)?)
                };
                self.line(format!("{} {out}={{{storage},{len}}};", name(&t)?,));
                let i = self.fresh();
                if m == "filter" {
                    self.line(format!("{out}.len=0;"));
                }
                if m == "scan" {
                    let acc = self.bind(et, "0")?;
                    self.line(format!(
                        "for(size_t {i}=0;{i}<{len};{i}++){{ {acc}={}; {out}.data[{i}]={acc}; }}",
                        self.add("+", &acc, &format!("{src}.data[{i}]"), et)
                    ));
                    return Ok(out);
                }
                if m == "sort" {
                    self.line(format!(
                        "for(size_t {i}=0;{i}<{len};{i}++) {out}.data[{i}]={src}.data[{i}];"
                    ));
                    // Ascending integer sort is a primitive; no rewrite rule.
                    let ty = name(et)?;
                    let sift=format!("while(root<end/2){{size_t child=root*2+1;if(child+1<end&&{out}.data[child]<{out}.data[child+1])++child;if({out}.data[root]>={out}.data[child])break;{ty} temp={out}.data[root];{out}.data[root]={out}.data[child];{out}.data[child]=temp;root=child;}}");
                    self.line(format!("for(size_t start={len}/2;start>0;){{--start;size_t root=start,end={len};{sift}}}"));
                    self.line(format!("for(size_t end={len};end>1;){{--end;{ty} temp={out}.data[0];{out}.data[0]={out}.data[end];{out}.data[end]=temp;size_t root=0;{sift}}}"));
                    return Ok(out);
                }
                let lambda = if m == "zip" { &a[1] } else { &a[0] };
                let Expr::Lambda(n, b) = lambda else {
                    return Err("collection lambda missing".into());
                };
                let mut local = env.clone();
                self.line(format!("for(size_t {i}=0;{i}<{len};{i}++){{"));
                let body = if m == "map_indexed" {
                    let Expr::Lambda(v, b) = b.as_ref() else {
                        return Err("indexed lambda missing".into());
                    };
                    local.insert(n.clone(), (format!("(uint32_t){i}"), Type::U32));
                    local.insert(v.clone(), (format!("{src}.data[{i}]"), *st));
                    b.as_ref()
                } else if m == "zip" {
                    let Expr::Lambda(v, b) = b.as_ref() else {
                        return Err("zip lambda missing".into());
                    };
                    let Type::List(ot) = check::infer(&a[0], &Self::types(env), self.p)? else {
                        return Err("zip list missing".into());
                    };
                    local.insert(n.clone(), (format!("{src}.data[{i}]"), *st));
                    local.insert(v.clone(), (format!("{}.data[{i}]", other.unwrap()), *ot));
                    b.as_ref()
                } else {
                    local.insert(n.clone(), (format!("{src}.data[{i}]"), *st));
                    b.as_ref()
                };
                let v = self.scalar(body, &local, if m == "filter" { &Type::Bool } else { et })?;
                self.line(if m == "filter" {
                    format!("if({v}) {out}.data[{out}.len++]={src}.data[{i}];")
                } else {
                    format!("{out}.data[{i}]={v};")
                });
                self.line("}");
                Ok(out)
            }
            _ => Err("unsupported list expression".into()),
        }
    }
}
// Packed storage avoids vec3 padding, Bool storage restrictions and host-specific
// struct alignment. The descriptor defines word order independently of placement.

fn types(p: &Program, _gpu: bool) -> LangResult<String> {
    let mut out = String::new();

    let mut ts = BTreeMap::new();
    fn collect(t: &Type, p: &Program, ts: &mut BTreeMap<String, Type>) -> LangResult<()> {
        match t {
            Type::Vector(et, _) | Type::List(et) => collect(et, p, ts)?,
            Type::Named(n) => {
                for (_, t) in p.records.get(n).ok_or("unknown record")? {
                    collect(t, p, ts)?
                }
            }
            _ => {}
        }
        ts.insert(name(t)?, t.clone());
        Ok(())
    }
    // Local vectors/records and intermediate scalar arrays need declarations
    // even when they are absent from the exported signatures.
    for t in [Type::U32, Type::U64, Type::I32, Type::F32, Type::Bool] {
        collect(&Type::List(Box::new(t.clone())), p, &mut ts)?;
        if matches!(t, Type::U32 | Type::I32 | Type::F32) {
            for n in 2..=4 {
                collect(
                    &Type::List(Box::new(Type::Vector(Box::new(t.clone()), n))),
                    p,
                    &mut ts,
                )?;
            }
        }
    }
    for n in p.records.keys() {
        collect(&Type::List(Box::new(Type::Named(n.clone()))), p, &mut ts)?;
    }
    for f in &p.functions {
        for (_, t) in &f.params {
            collect(t, p, &mut ts)?
        }
        collect(&f.result, p, &mut ts)?;
    }
    out.push_str(include_str!("primitives.c.txt"));
    out.push_str("static __attribute__((noinline,unused)) float ink_f32_canonical(float value){return value!=value?ink_f32(0x7fc00000u):value;}\n");
    let mut pending = ts;
    let mut done = std::collections::BTreeSet::new();
    while !pending.is_empty() {
        let ready = pending
            .iter()
            .find(|(_, t)| match t {
                Type::Vector(t, _) | Type::List(t) => done.contains(&name(t).unwrap()),
                Type::Named(n) => p.records[n]
                    .iter()
                    .all(|(_, t)| done.contains(&name(t).unwrap())),
                _ => true,
            })
            .map(|(n, t)| (n.clone(), t.clone()))
            .ok_or("recursive compute records are unsupported")?;
        let (n, t) = ready;
        match &t {
            Type::Vector(et, size) => {
                out.push_str(&format!("typedef struct {{"));
                for field in ["x", "y", "z", "w"].iter().take(*size as usize) {
                    out.push_str(&format!("{} {field};", name(et)?));
                }
                out.push_str(&format!("}} {n};\n"));
            }
            Type::Named(r) => {
                out.push_str("typedef struct __attribute__((packed, aligned(4))) {");
                for (f, t) in &p.records[r] {
                    out.push_str(&format!("{} ink_f_{f};", name(t)?));
                }
                out.push_str(&format!("}} {n};\n"));
            }
            Type::List(et) => out.push_str(&format!(
                "typedef struct {{ {} *data; size_t len; }} {n};\n",
                name(et)?
            )),
            _ => {}
        }
        if !matches!(t, Type::List(_)) {
            out.push_str(&format!(
                "_Static_assert(sizeof({n})=={},\"packed compute layout\");\n",
                lanes(&t, p, false)? * 4
            ));
        }
        done.insert(n.clone());
        pending.remove(&n);
    }
    Ok(out)
}
fn validate_layouts(p: &Program) -> LangResult<()> {
    fn value(t: &Type, p: &Program, depth: usize, _record: bool) -> LangResult<()> {
        if depth > 32 {
            return Err("recursive/deep compute layout is unsupported".into());
        }
        match t {
            Type::U32 | Type::I32 | Type::F32 | Type::Bool => Ok(()),
            Type::U64 => Ok(()),
            Type::Vector(t, n)
                if (2..=4).contains(n) && matches!(**t, Type::U32 | Type::I32 | Type::F32) =>
            {
                Ok(())
            }
            Type::Named(n) => {
                let fields = p.records.get(n).ok_or("unknown compute record")?;
                if fields.is_empty() {
                    return Err("compute record must have fields".into());
                }
                for (_, t) in fields {
                    value(t, p, depth + 1, true)?;
                }
                Ok(())
            }
            _ => Err(
                "compute layouts require numeric/Bool values, vectors, or fixed-width records"
                    .into(),
            ),
        }
    }
    for n in p.records.keys() {
        value(&Type::Named(n.clone()), p, 0, false)?;
    }
    for f in &p.functions {
        for t in f
            .params
            .iter()
            .map(|(_, t)| t)
            .chain(std::iter::once(&f.result))
        {
            if let Type::List(t) = t {
                value(t, p, 0, false)?;
            } else {
                value(t, p, 0, false)?;
            }
        }
    }
    Ok(())
}
fn ingress(out: &mut String, f: &Function) -> LangResult<Vec<String>> {
    let mut args = Vec::new();
    for (j, (_, t)) in f.params.iter().enumerate() {
        if let Type::List(et) = t {
            // Packed U32 and Bool words have the exact uint32_t layout. Pure
            // operations allocate writable outputs; caller input stays alive
            // through result use. Other layouts retain their representation copy.
            if matches!(**et, Type::U32 | Type::Bool) {
                out.push_str(&format!("uint32_t *a{j}=(uint32_t *)data[{j}];"));
            } else {
                out.push_str(&format!("{} *a{j}=ink_alloc(lengths[{j}],sizeof({}));ink_copy(a{j},data[{j}],lengths[{j}]*sizeof({}));",name(et)?,name(et)?,name(et)?));
            }
            args.push(format!("({}){{a{j},lengths[{j}]}}", name(t)?));
        } else {
            out.push_str(&format!(
                "{} a{j};ink_copy(&a{j},data[{j}],sizeof(a{j}));",
                name(t)?
            ));
            args.push(format!("a{j}"));
        }
    }
    Ok(args)
}

pub fn emit_c(p: &Program) -> LangResult<String> {
    core::CheckedModule::from_source(p.clone())?.pure_program()?;
    validate_layouts(p)?;
    let mut out = String::from("#include <stdint.h>\n#include <stddef.h>\n#include <stdbool.h>\n#pragma STDC FP_CONTRACT OFF\n#if defined(__clang__)\n#pragma clang diagnostic ignored \"-Wparentheses-equality\"\n#pragma clang diagnostic ignored \"-Wtautological-compare\"\n#endif\n");
    out.push_str(include_str!("../runtime/compute-alloc.c"));
    out.push_str(&types(p, false)?);
    for f in &p.functions {
        let args = f
            .params
            .iter()
            .enumerate()
            .map(|(i, (_, t))| Ok(format!("{} a{i}", name(t)?)))
            .collect::<LangResult<Vec<_>>>()?;
        out.push_str(&format!(
            "{} lang_fn_{}({});\n",
            name(&f.result)?,
            f.name,
            if args.is_empty() {
                "void".into()
            } else {
                args.join(",")
            }
        ));
        if let Type::List(et) = &f.result {
            let mut into_args = args.clone();
            into_args.push(format!("{} *destination", name(et)?));
            out.push_str(&format!(
                "size_t lang_fn_{}_into({});\n",
                f.name,
                into_args.join(",")
            ));
        }
    }
    for f in &p.functions {
        let args = f
            .params
            .iter()
            .enumerate()
            .map(|(i, (_, t))| Ok(format!("{} a{i}", name(t)?)))
            .collect::<LangResult<Vec<_>>>()?;
        out.push_str(&format!(
            "{} lang_fn_{}({}){{\n",
            name(&f.result)?,
            f.name,
            if args.is_empty() {
                "void".into()
            } else {
                args.join(",")
            }
        ));
        let env = f
            .params
            .iter()
            .enumerate()
            .map(|(i, (n, t))| (n.clone(), (format!("a{i}"), t.clone())))
            .collect();
        let mut em = Emitter {
            p,
            lines: String::new(),
            next: 0,
            budget: 100000,
            depth: 0,
        };
        for (i, _) in f.params.iter().enumerate() {
            em.line(format!("(void)a{i};"));
        }
        let v = if matches!(f.result, Type::List(_)) {
            em.list(&f.body, &env, Some(&f.result))?
        } else {
            em.scalar(&f.body, &env, &f.result)?
        };
        em.line(format!("return {v};"));
        out.push_str(&em.lines);
        out.push_str("}\n");
    }
    // A separate explicit destination capability. Caller capacity, alignment,
    // lifetime and disjointness are contracts, never runtime input checks.
    for f in &p.functions {
        let Type::List(et) = &f.result else {
            continue;
        };
        let mut args = f
            .params
            .iter()
            .enumerate()
            .map(|(i, (_, t))| Ok(format!("{} a{i}", name(t)?)))
            .collect::<LangResult<Vec<_>>>()?;
        args.push(format!("{} *destination", name(et)?));
        out.push_str(&format!(
            "size_t lang_fn_{}_into({}){{\n",
            f.name,
            args.join(",")
        ));
        let env = f
            .params
            .iter()
            .enumerate()
            .map(|(i, (n, t))| (n.clone(), (format!("a{i}"), t.clone())))
            .collect();
        let mut em = Emitter {
            p,
            lines: String::new(),
            next: 0,
            budget: 100000,
            depth: 0,
        };
        for (i, _) in f.params.iter().enumerate() {
            em.line(format!("(void)a{i};"));
        }
        let result = em.list_output(&f.body, &env, Some(&f.result), Some("destination"))?;
        em.line(format!("return {result}.len;"));
        out.push_str(&em.lines);
        out.push_str("}\n");
    }
    out.push_str("size_t ink_compute_into(uint32_t function,const void *const *data,const size_t *lengths,void *destination){(void)data;(void)lengths;(void)destination;switch(function){\n");
    for (i, f) in p.functions.iter().enumerate() {
        let Type::List(et) = &f.result else {
            continue;
        };
        out.push_str(&format!("case {i}:{{"));
        let mut args = ingress(&mut out, f)?;
        args.push(format!("({} *)destination", name(et)?));
        out.push_str(&format!(
            "return lang_fn_{}_into({})*{};}}\n",
            f.name,
            args.join(","),
            lanes(et, p, false)?
        ));
    }
    out.push_str("default:ink_fail();}return 0;}\n");
    out.push_str("void ink_compute_call(uint32_t function,const void *const *data,const size_t *lengths,void **output,size_t *count){ (void)data;(void)lengths;switch(function){\n");
    for (i, f) in p.functions.iter().enumerate() {
        out.push_str(&format!("case {i}:{{"));
        let args = ingress(&mut out, f)?;
        out.push_str(&format!(
            "{} result=lang_fn_{}({});",
            name(&f.result)?,
            f.name,
            args.join(",")
        ));
        if let Type::List(et) = &f.result {
            out.push_str(&format!(
                "*output=result.data;*count=result.len*{};",
                lanes(et, p, false)?
            ));
        } else {
            out.push_str(&format!(
                "{} *copy=ink_alloc(1,sizeof(result));*copy=result;*output=copy;*count={};",
                name(&f.result)?,
                lanes(&f.result, p, false)?
            ));
        }
        out.push_str("break;}\n");
    }
    out.push_str("default:ink_fail();}}\n");
    // Known scalar result layouts need no result arena object or output header.
    // The host selects the dispatcher from the checked function descriptor.
    for wide in [false, true] {
        let (result_type, suffix) = if wide {
            ("uint64_t", "64")
        } else {
            ("uint32_t", "32")
        };
        out.push_str(&format!("{result_type} ink_compute_scalar{suffix}(uint32_t function,const void *const *data,const size_t *lengths){{ (void)data;(void)lengths;switch(function){{\n"));
        for (i, f) in p.functions.iter().enumerate() {
            if if wide {
                f.result != Type::U64
            } else {
                !matches!(f.result, Type::U32 | Type::I32 | Type::Bool | Type::F32)
            } {
                continue;
            }
            out.push_str(&format!("case {i}:{{"));
            let args = ingress(&mut out, f)?;
            out.push_str(&format!(
                "{} result=lang_fn_{}({});",
                name(&f.result)?,
                f.name,
                args.join(",")
            ));
            if f.result == Type::F32 {
                out.push_str("uint32_t bits;ink_copy(&bits,&result,sizeof(bits));return bits;");
            } else {
                out.push_str(&format!("return ({result_type})result;"));
            }
            out.push_str("}\n");
        }
        out.push_str("default:ink_fail();}return 0;}\n");
    }
    Ok(out)
}
