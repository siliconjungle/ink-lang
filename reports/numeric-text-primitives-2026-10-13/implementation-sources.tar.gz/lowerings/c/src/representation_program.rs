//! Standalone representation functions using a type-specific borrowed native ABI.
//! The ordinary generated Rust host owns immutable data, JSON and snapshots.
use ink_core::{
    logic::{Declaration, Sort, Term},
    representation::CheckedRepresentation,
    LangResult,
};
use std::{collections::BTreeMap, fmt::Write};
pub struct Emission {
    pub c: String,
    pub rust: String,
}
#[derive(Clone)]
struct Expr {
    code: String,
    sort: Sort,
}
struct Lower<'a> {
    ds: &'a BTreeMap<String, Declaration>,
    next: usize,
    linear_step: bool,
    recursive_sites: usize,
    recursive_site: usize,
}
fn resolved(s: &Sort, id: &str) -> Sort {
    if *s == Sort::SelfType {
        Sort::Data(id.into())
    } else {
        s.clone()
    }
}
fn ty(s: &Sort) -> LangResult<String> {
    Ok(match s {
        Sort::Bool => "bool".into(),
        Sort::U64 => "uint64_t".into(),
        Sort::Data(id) => format!("const D_{id}*"),
        _ => return Err("unresolved native C sort".into()),
    })
}
impl Lower<'_> {
    fn expr(
        &mut self,
        t: &Term,
        env: &BTreeMap<String, Expr>,
        current: &str,
        out: &mut String,
    ) -> LangResult<Expr> {
        if self.next > 100_000 {
            return Err("native C emission limit".into());
        }
        let name = format!("v{}", self.next);
        self.next += 1;
        if let Term::Var(n) = t {
            return env.get(n).cloned().ok_or("native C variable".into());
        }
        let (code, sort) = match t {
            Term::Bool(b) => (b.to_string(), Sort::Bool),
            Term::U64(n) => (format!("UINT64_C({n})"), Sort::U64),
            Term::Construct {
                datatype,
                constructor,
                arguments,
            } => {
                let xs = arguments
                    .iter()
                    .map(|a| self.expr(a, env, current, out).map(|e| e.code))
                    .collect::<LangResult<Vec<_>>>()?;
                (
                    format!("ink_rep_new_{datatype}_{constructor}({})", xs.join(",")),
                    Sort::Data(datatype.clone()),
                )
            }
            Term::SelfCall(arguments) if self.linear_step => {
                let Declaration::Function {result,..}=&self.ds[current]else{unreachable!()};
                let result=result.clone();
                let args=arguments.iter().enumerate().map(|(i,a)|self.expr(a,env,current,out).map(|e|format!(".a{i}={}",e.code))).collect::<LangResult<Vec<_>>>()?;
                let code=if self.recursive_sites==1 {
                    writeln!(out,"if(!ink_has_resume)return (S_{current}){{.ready=false,{}}};",args.join(",")).unwrap();
                    "ink_resume".into()
                } else {
                    let site=self.recursive_site;self.recursive_site+=1;
                    writeln!(out,"if(!ink_known[{site}])return (S_{current}){{.ready=false,.site={site},{}}};",args.join(",")).unwrap();
                    format!("ink_values[{site}]")
                };
                (code,result)
            }
            Term::Call { arguments, .. } | Term::SelfCall(arguments) => {
                let id = if let Term::Call { function, .. } = t {
                    function
                } else {
                    current
                };
                let Declaration::Function { result, .. } = &self.ds[id] else {
                    return Err("native C function".into());
                };
                let sort = result.clone();
                let xs = arguments
                    .iter()
                    .map(|a| self.expr(a, env, current, out).map(|e| e.code))
                    .collect::<LangResult<Vec<_>>>()?;
                (format!("d_{id}({})", xs.join(",")), sort)
            }
            Term::Binary { op, left, right } => {
                let a = self.expr(left, env, current, out)?;
                let b = self.expr(right, env, current, out)?;
                if let Some(operator) = op.strip_prefix("f32:") {
                    let index = ["+", "-", "*", "neg", "==", "!=", "<", "<=", ">", ">="]
                        .iter()
                        .position(|x| *x == operator)
                        .ok_or("binary32 operator")?;
                    (
                        format!("f32_word({index},{},{})", a.code, b.code),
                        if index < 4 { Sort::U64 } else { Sort::Bool },
                    )
                } else {
                    if op == "quot" || op == "rem" {
                        return Ok(Expr {
                            code: format!(
                                "({}?({} {} {}):0)",
                                b.code,
                                a.code,
                                if op == "quot" { "/" } else { "%" },
                                b.code
                            ),
                            sort: Sort::U64,
                        });
                    }
                    let sort = if ["+", "-", "*", "&"].contains(&op.as_str()) {
                        Sort::U64
                    } else {
                        Sort::Bool
                    };
                    (format!("({} {op} {})", a.code, b.code), sort)
                }
            }
            Term::If {
                condition,
                on_true,
                on_false,
            } => {
                let c = self.expr(condition, env, current, out)?;
                let mut aa = String::new();
                let a = self.expr(on_true, env, current, &mut aa)?;
                let mut bb = String::new();
                let b = self.expr(on_false, env, current, &mut bb)?;
                writeln!(
                    out,
                    "{} {name};if({}){{{aa}{name}={};}}else{{{bb}{name}={};}}",
                    ty(&a.sort)?,
                    c.code,
                    a.code,
                    b.code
                )
                .unwrap();
                return Ok(Expr {
                    code: name,
                    sort: a.sort,
                });
            }
            Term::Match {
                scrutinee,
                branches,
            } => {
                let c = self.expr(scrutinee, env, current, out)?;
                let Sort::Data(id) = &c.sort else {
                    return Err("native C match datatype".into());
                };
                let Declaration::Datatype { constructors } = &self.ds[id] else {
                    return Err("native C match".into());
                };
                let mut arms = String::new();
                let mut sort = None;
                for (i, b) in branches.iter().enumerate() {
                    let mut local = env.clone();
                    for (j, n) in b.bindings.iter().enumerate() {
                        local.insert(
                            n.clone(),
                            Expr {
                                code: format!("ink_rep_get_{id}_{i}_{j}({})", c.code),
                                sort: resolved(&constructors[i].fields[j], id),
                            },
                        );
                    }
                    let mut body = String::new();
                    let result = self.expr(&b.body, &local, current, &mut body)?;
                    sort = Some(result.sort);
                    writeln!(arms, "case {i}:{{{body}{name}={};break;}}", result.code).unwrap();
                }
                let sort = sort.ok_or("empty native C match")?;
                writeln!(
                    out,
                    "{} {name};switch(ink_rep_tag_{id}({})){{{arms}default:__builtin_trap();}}",
                    ty(&sort)?,
                    c.code
                )
                .unwrap();
                return Ok(Expr { code: name, sort });
            }
            Term::Var(_) => unreachable!(),
        };
        writeln!(out, "{} {name}={code};", ty(&sort)?).unwrap();
        Ok(Expr { code: name, sort })
    }
}
pub fn lower(checked: &CheckedRepresentation) -> LangResult<Emission> {
    let definition = checked.definition();
    let mut ds = definition.reachable_executable_declarations()?;
    let (extras, _) = ink_core::field_projection::host_observers(checked)?;
    let exports = definition
        .exports()
        .iter()
        .chain(extras.keys())
        .cloned()
        .collect::<Vec<_>>();
    ds.extend(extras);
    let queries = checked.projection().codec_declarations()?;
    ds.extend(queries.clone());
    let mut c=String::from("// Literal checked bodies; borrowed typed objects, no interpreter or checker.\n#include <stdint.h>\n#include <stdbool.h>\n#include <stddef.h>\nextern void* ink_native_frames_resize(void*,size_t,size_t,size_t);\n");
    c.push_str(include_str!("definition-f32.c.txt"));
    for (id, d) in &ds {
        if matches!(d, Declaration::Datatype { .. }) {
            writeln!(c, "typedef struct D_{id} D_{id};").unwrap();
        }
    }
    for (id, d) in &ds {
        match d {
            Declaration::Datatype { constructors } => {
                writeln!(c, "extern uint32_t ink_rep_tag_{id}(const D_{id}*);").unwrap();
                for (i, ctor) in constructors.iter().enumerate() {
                    let fields = ctor
                        .fields
                        .iter()
                        .map(|s| resolved(s, id))
                        .collect::<Vec<_>>();
                    let params = fields.iter().map(ty).collect::<LangResult<Vec<_>>>()?;
                    writeln!(
                        c,
                        "extern const D_{id}* ink_rep_new_{id}_{i}({});",
                        if params.is_empty() {
                            "void".into()
                        } else {
                            params.join(",")
                        }
                    )
                    .unwrap();
                    for (j, s) in fields.iter().enumerate() {
                        writeln!(
                            c,
                            "extern {} ink_rep_get_{id}_{i}_{j}(const D_{id}*);",
                            ty(s)?
                        )
                        .unwrap();
                    }
                }
            }
            Declaration::Function { params, result, .. } => {
                let params = params
                    .iter()
                    .map(|(_, s)| ty(s))
                    .collect::<LangResult<Vec<_>>>()?;
                writeln!(
                    c,
                    "static {} d_{id}({});",
                    ty(result)?,
                    if params.is_empty() {
                        "void".into()
                    } else {
                        params.join(",")
                    }
                )
                .unwrap();
            }
            _ => return Err("non-executable native C declaration".into()),
        }
    }
    let mut lower = Lower { ds: &ds, next: 0, linear_step: false, recursive_sites:0,recursive_site:0 };
    for (id, d) in &ds {
        if let Declaration::Function {
            params,
            result,
            body,
            ..
        } = d
        {
            let env = params
                .iter()
                .enumerate()
                .map(|(i, (n, s))| {
                    (
                        n.clone(),
                        Expr {
                            code: format!("a{i}"),
                            sort: s.clone(),
                        },
                    )
                })
                .collect();
            let inputs = params
                .iter()
                .enumerate()
                .map(|(i, (_, s))| Ok(format!("{} a{i}", ty(s)?)))
                .collect::<LangResult<Vec<_>>>()?;
            let mut recursive_sites=0;
            ink_core::logic::walk_term(body,|t|if matches!(t,Term::SelfCall(_)){recursive_sites+=1});
            lower.linear_step=(1..=64).contains(&recursive_sites);
            lower.recursive_sites=recursive_sites;lower.recursive_site=0;
            let mut body_code = String::new();
            let value = lower.expr(body, &env, id, &mut body_code)?;
            if lower.linear_step {
                lower.linear_step=false;
                let output=ty(result)?;
                let fields=params.iter().enumerate().map(|(i,(_,s))|Ok(format!("{} a{i};",ty(s)?))).collect::<LangResult<Vec<_>>>()?.join("");
                let init=(0..params.len()).map(|i|format!(".a{i}=a{i}")).collect::<Vec<_>>().join(",");
                let copy=(0..params.len()).map(|i|format!("a{i}=step.a{i};")).collect::<Vec<_>>().join("");
                let args=(0..params.len()).map(|i|format!("a{i}")).collect::<Vec<_>>().join(",");
                let frame_args=(0..params.len()).map(|i|format!("frames[count].a{i}")).collect::<Vec<_>>().join(",");
                if recursive_sites==1 {
                writeln!(c,"typedef struct{{{fields}bool ready;{output} value;}} S_{id};\nstatic S_{id} s_{id}({},bool ink_has_resume,{output} ink_resume){{{body_code}return (S_{id}){{.ready=true,.value={}}};}}",inputs.join(","),value.code).unwrap();
                // Explicit frames hold only typed arguments. No runtime syntax,
                // function registry, proof object or algorithm-specific rule.
                writeln!(c,"static {output} d_{id}({}){{S_{id} *frames=NULL;size_t count=0,capacity=0,limit=64000000/sizeof(*frames);if(limit>1000000)limit=1000000;{output} result;for(;;){{S_{id} step=s_{id}({args},false,({output}){{0}});if(step.ready){{result=step.value;break;}}if(count>=limit)__builtin_trap();if(count==capacity){{size_t previous=capacity;capacity=capacity?capacity*2:64;if(capacity>limit)capacity=limit;S_{id}*grown=ink_native_frames_resize(frames,previous*sizeof(*frames),capacity*sizeof(*frames),_Alignof(S_{id}));if(!grown)__builtin_trap();frames=grown;}}frames[count++]=(S_{id}){{{init}}};{copy}}}while(count){{--count;S_{id} step=s_{id}({frame_args},true,result);if(!step.ready)__builtin_trap();result=step.value;}}ink_native_frames_resize(frames,capacity*sizeof(*frames),0,_Alignof(S_{id}));return result;}}",inputs.join(",")).unwrap();
                } else {
                    let current_args=(0..params.len()).map(|i|format!("ink_frame.a{i}")).collect::<Vec<_>>().join(",");
                    writeln!(c,"typedef struct{{{fields}bool ready;{output} value;size_t site;bool known[{recursive_sites}];{output} values[{recursive_sites}];}} S_{id};\nstatic S_{id} s_{id}({},const bool* ink_known,const {output}* ink_values){{{body_code}return (S_{id}){{.ready=true,.value={}}};}}",inputs.join(","),value.code).unwrap();
                    writeln!(c,"static {output} d_{id}({}){{S_{id} ink_frame={{{init}}};S_{id}*frames=NULL;size_t count=0,capacity=0,limit=64000000/sizeof(S_{id});if(limit>1000000)limit=1000000;for(;;){{S_{id} step=s_{id}({current_args},ink_frame.known,ink_frame.values);if(step.ready){{if(!count){{ink_native_frames_resize(frames,capacity*sizeof(*frames),0,_Alignof(S_{id}));return step.value;}}S_{id} parent=frames[--count];parent.known[parent.site]=true;parent.values[parent.site]=step.value;ink_frame=parent;}}else{{if(count>=limit)__builtin_trap();if(count==capacity){{size_t previous=capacity;capacity=capacity?capacity*2:64;if(capacity>limit)capacity=limit;S_{id}*grown=ink_native_frames_resize(frames,previous*sizeof(*frames),capacity*sizeof(*frames),_Alignof(S_{id}));if(!grown)__builtin_trap();frames=grown;}}ink_frame.site=step.site;frames[count++]=ink_frame;ink_frame=step;}}}}}}",inputs.join(",")).unwrap();
                }
                continue;
            }
            writeln!(
                c,
                "static {} d_{id}({}){{{body_code}return {};}}",
                ty(result)?,
                if inputs.is_empty() {
                    "void".into()
                } else {
                    inputs.join(",")
                },
                value.code
            )
            .unwrap();
        }
    }
    for id in exports.iter().chain(queries.iter().filter_map(|(id,d)|matches!(d,Declaration::Function{..}).then_some(id))) {
        let target = definition.choices().get(id).unwrap_or(id);
        let Declaration::Function { params, result, .. } = &ds[target] else {
            unreachable!()
        };
        let inputs = params
            .iter()
            .enumerate()
            .map(|(i, (_, s))| Ok(format!("{} a{i}", ty(s)?)))
            .collect::<LangResult<Vec<_>>>()?;
        let args = (0..params.len())
            .map(|i| format!("a{i}"))
            .collect::<Vec<_>>()
            .join(",");
        writeln!(
            c,
            "{} ink_rep_f_{id}({}){{return d_{target}({args});}}",
            ty(result)?,
            if inputs.is_empty() {
                "void".into()
            } else {
                inputs.join(",")
            }
        )
        .unwrap();
    }
    if c.len() > 16_000_000 {
        return Err("native C source size limit".into());
    }
    Ok(Emission {
        c,
        rust: ink_lowering_rust::representation_program::lower_c_host(checked)?,
    })
}
