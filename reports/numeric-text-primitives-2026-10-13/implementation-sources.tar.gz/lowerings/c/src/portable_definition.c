#include <stdint.h>
#include <stddef.h>
// Immutable constructors share their argument arrays within one bounded call.
// Words are postorder nodes; child indices must point strictly backwards.
typedef struct DefValue {uint32_t tag,datatype,constructor,count;uint64_t bits;struct DefValue*arguments;} DefValue;
typedef struct {uint32_t error,top;uint64_t fuel;} DefContext;
static union {uint64_t align;unsigned char bytes[32*1024*1024];} def_arena;
static uint32_t def_input_words[4*1024*1024],def_output[4*1024*1024];
static uint32_t def_output_words,def_output_count;
uint32_t*ink_definition_input(void){return def_input_words;}
uint32_t*ink_definition_result(void){return def_output;}
static int def_tick(DefContext*ctx){if(ctx->error)return 0;if(!ctx->fuel){ctx->error=1;return 0;}--ctx->fuel;return 1;}
static void*def_alloc(DefContext*ctx,uint32_t count,uint32_t width){uint64_t start=((uint64_t)ctx->top+7)&~UINT64_C(7),end=start+(uint64_t)count*width;if(end>sizeof(def_arena.bytes)){ctx->error=1;return 0;}ctx->top=(uint32_t)end;return def_arena.bytes+start;}
static DefValue def_scalar(uint32_t tag,uint64_t bits){DefValue v={tag,0,0,0,bits,0};return v;}
static DefValue def_construct(DefContext*ctx,uint32_t datatype,uint32_t constructor,uint32_t count,const DefValue*args){DefValue v={2,datatype,constructor,count,0,0};if(count>64){ctx->error=1;return v;}v.arguments=def_alloc(ctx,count,sizeof(DefValue));if(ctx->error)return v;for(uint32_t i=0;i<count;i++)v.arguments[i]=args[i];return v;}
static int def_equal(DefContext*ctx,DefValue a,DefValue b,uint32_t depth){if(depth>128||!def_tick(ctx)){ctx->error=1;return 0;}if(a.tag!=b.tag)return 0;if(a.tag!=2)return a.bits==b.bits;if(a.datatype!=b.datatype||a.constructor!=b.constructor||a.count!=b.count)return 0;for(uint32_t i=0;i<a.count;i++)if(!def_equal(ctx,a.arguments[i],b.arguments[i],depth+1))return 0;return 1;}
static int def_input(DefContext*ctx,const uint32_t*in,uint32_t words,DefValue*args,uint32_t*count){
 if(words<2||words>4*1024*1024||in[0]>100000||in[1]>64||words<2+in[1])return 0;
 uint32_t nodes=in[0],position=2+in[1];DefValue*values=def_alloc(ctx,nodes,sizeof(DefValue));uint32_t*used=def_alloc(ctx,nodes,sizeof(uint32_t));uint32_t*depths=def_alloc(ctx,nodes,sizeof(uint32_t));if(ctx->error)return 0;for(uint32_t i=0;i<nodes;i++){used[i]=0;depths[i]=0;}
 for(uint32_t i=0;i<nodes;i++){
  if(position>words||words-position<6)return 0;uint32_t tag=in[position],n=in[position+5];if(tag>2||n>64||words-position-6<n)return 0;
  DefValue v={tag,in[position+3],in[position+4],n,(uint64_t)in[position+1]|((uint64_t)in[position+2]<<32),0};
  if(tag!=2){if(n||v.datatype||v.constructor||(tag==0&&v.bits>1))return 0;}
  else{if(v.bits)return 0;v.arguments=def_alloc(ctx,n,sizeof(DefValue));if(ctx->error)return 0;for(uint32_t j=0;j<n;j++){uint32_t child=in[position+6+j];if(child>=i||used[child])return 0;used[child]=1;uint32_t depth=depths[child]+1;if(depth>64)return 0;if(depth>depths[i])depths[i]=depth;v.arguments[j]=values[child];}}
  values[i]=v;position+=6+n;
 }
 if(position!=words)return 0;*count=in[1];for(uint32_t i=0;i<*count;i++){uint32_t root=in[2+i];if(root>=nodes||used[root])return 0;used[root]=1;args[i]=values[root];}for(uint32_t i=0;i<nodes;i++){if(!used[i])return 0;}return 1;
}
static uint32_t def_write(DefContext*ctx,DefValue v,uint32_t depth){
 if(depth>64||!def_tick(ctx)||def_output_count>=100000){ctx->error=1;return 0;}uint32_t children[64];if(v.count>64){ctx->error=1;return 0;}for(uint32_t i=0;i<v.count;i++)children[i]=def_write(ctx,v.arguments[i],depth+1);if(ctx->error)return 0;
 if(def_output_words>4*1024*1024-6-v.count){ctx->error=1;return 0;}uint32_t p=def_output_words;def_output[p]=v.tag;def_output[p+1]=(uint32_t)v.bits;def_output[p+2]=(uint32_t)(v.bits>>32);def_output[p+3]=v.datatype;def_output[p+4]=v.constructor;def_output[p+5]=v.count;for(uint32_t i=0;i<v.count;i++)def_output[p+6+i]=children[i];def_output_words+=6+v.count;return def_output_count++;
}
