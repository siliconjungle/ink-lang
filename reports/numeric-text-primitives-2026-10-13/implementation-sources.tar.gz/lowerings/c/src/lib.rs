pub use ink_core::*;
pub mod compute;
mod primitive_emit;
pub mod native;

pub mod complete;
pub mod definition;

pub mod representation_program;

pub mod portable_definition;
