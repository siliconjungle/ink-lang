fn main(){cc::Build::new().file("../gpu/f0/native/cpu.c").opt_level(3).compile("part0");
cc::Build::new().file("../gpu/f2/native/cpu.c").opt_level(3).compile("part2");
cc::Build::new().file("../gpu/f3/native/cpu.c").opt_level(3).compile("part3");
cc::Build::new().file("../gpu/f4/native/cpu.c").opt_level(3).compile("part4");
cc::Build::new().file("../gpu/f6/native/cpu.c").opt_level(3).compile("part6");
cc::Build::new().file("../gpu/f7/native/cpu.c").opt_level(3).compile("part7");
cc::Build::new().file("../gpu/f8/native/cpu.c").opt_level(3).compile("part8");
}