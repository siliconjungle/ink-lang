#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#pragma STDC FP_CONTRACT OFF
#if defined(__clang__)
#pragma clang diagnostic ignored "-Wparentheses-equality"
#pragma clang diagnostic ignored "-Wtautological-compare"
#endif
/* A call-scoped arena. Returned arrays live until ink_part0_ink_compute_reset. */
#if defined(__wasm__)
extern unsigned char __heap_base;
static size_t ink_part0_ink_top;
static void ink_part0_ink_fail(void){__builtin_trap();}
void ink_part0_ink_compute_reset(void){ink_part0_ink_top=(size_t)&__heap_base;}
size_t ink_part0_ink_compute_mark(void){if(!ink_part0_ink_top)ink_part0_ink_compute_reset();return ink_part0_ink_top;}
void ink_part0_ink_compute_rewind(size_t mark){ink_part0_ink_top=mark;}
void *ink_part0_ink_alloc(size_t count,size_t width){
 if(!width||count>SIZE_MAX/width||ink_part0_ink_top>SIZE_MAX-7)ink_part0_ink_fail();
 if(!ink_part0_ink_top)ink_part0_ink_compute_reset();size_t start=(ink_part0_ink_top+7)&~(size_t)7;
 size_t bytes=(count?count:1)*width;if(bytes>SIZE_MAX-start)ink_part0_ink_fail();ink_part0_ink_top=start+bytes;
 size_t pages=(ink_part0_ink_top+65535)/65536,old=__builtin_wasm_memory_size(0);
 if(pages>old&&__builtin_wasm_memory_grow(0,pages-old)==(size_t)-1)ink_part0_ink_fail();return(void*)start;
}
#else
#include <stdlib.h>
typedef struct ink_part0_ink_block {struct ink_part0_ink_block *next; uint64_t align;} ink_part0_ink_block;
static _Thread_local ink_part0_ink_block *ink_part0_ink_blocks;
static void ink_part0_ink_fail(void){abort();}
void ink_part0_ink_compute_reset(void){while(ink_part0_ink_blocks){ink_part0_ink_block *b=ink_part0_ink_blocks;ink_part0_ink_blocks=b->next;free(b);}}
size_t ink_part0_ink_compute_mark(void){return (size_t)ink_part0_ink_blocks;}
void ink_part0_ink_compute_rewind(size_t mark){while(ink_part0_ink_blocks!=(ink_part0_ink_block*)mark){ink_part0_ink_block*b=ink_part0_ink_blocks;ink_part0_ink_blocks=b->next;free(b);}}
void *ink_part0_ink_alloc(size_t count,size_t width){if(!width||count>SIZE_MAX/width)ink_part0_ink_fail();size_t bytes=(count?count:1)*width;if(bytes>SIZE_MAX-sizeof(ink_part0_ink_block))ink_part0_ink_fail();ink_part0_ink_block*b=malloc(sizeof(*b)+bytes);if(!b)ink_part0_ink_fail();b->next=ink_part0_ink_blocks;ink_part0_ink_blocks=b;return b+1;}
#endif
static __attribute__((unused)) float ink_part0_ink_f32(uint32_t bits){union{uint32_t u;float f;}v={.u=bits};return v.f;}
static __attribute__((unused)) int32_t ink_part0_ink_i32(uint32_t bits){union{uint32_t u;int32_t i;}v={.u=bits};return v.i;}

static __attribute__((unused)) void ink_part0_ink_copy(void *to,const void *from,size_t bytes){unsigned char *dst=to;const unsigned char *src=from;for(size_t i=0;i<bytes;i++)dst[i]=src[i];}
#if defined(__wasm__)
void *memcpy(void *to,const void *from,size_t bytes){ink_part0_ink_copy(to,from,bytes);return to;}
void *memset(void *to,int value,size_t bytes){unsigned char *dst=to;for(size_t i=0;i<bytes;i++)dst[i]=(unsigned char)value;return to;}
#endif
static __attribute__((unused)) uint32_t ink_part0_ink_clz32(uint32_t x){return x?__builtin_clz(x):32u;}
static __attribute__((unused)) uint32_t ink_part0_ink_ctz32(uint32_t x){return x?__builtin_ctz(x):32u;}
static __attribute__((unused)) uint32_t ink_part0_ink_clz64(uint64_t x){return x?__builtin_clzll(x):64u;}
static __attribute__((unused)) uint32_t ink_part0_ink_ctz64(uint64_t x){return x?__builtin_ctzll(x):64u;}
static __attribute__((unused)) float ink_part0_ink_round_ties_even(float x){
 union {float f;uint32_t u;}v={.f=x};uint32_t a=v.u&0x7fffffffu;
 if(a>0x7f800000u){v.u=0x7fc00000u;return v.f;}if(a>=0x4b000000u)return x;
 float y=__builtin_fabsf(x),i=__builtin_floorf(y),r=y-i;
 if(r>0.5f||(r==0.5f&&((uint32_t)i&1u)))i+=1.0f;
 return __builtin_copysignf(i,x);
}

static __attribute__((unused)) uint32_t ink_part0_ink_f32_bits(float x){union{float f;uint32_t u;}v={.f=x};return v.u;}
static __attribute__((noinline,unused)) float ink_part0_ink_f32_canonical(float value){return value!=value?ink_part0_ink_f32(0x7fc00000u):value;}
_Static_assert(sizeof(float)==4,"packed compute layout");
typedef struct { float *data; size_t len; } ink_part0_ink_l_float;
typedef struct {float x;float y;} ink_part0_ink_v2_float;
_Static_assert(sizeof(ink_part0_ink_v2_float)==8,"packed compute layout");
typedef struct { ink_part0_ink_v2_float *data; size_t len; } ink_part0_ink_l_ink_v2_float;
typedef struct {float x;float y;float z;} ink_part0_ink_v3_float;
_Static_assert(sizeof(ink_part0_ink_v3_float)==12,"packed compute layout");
typedef struct { ink_part0_ink_v3_float *data; size_t len; } ink_part0_ink_l_ink_v3_float;
typedef struct {float x;float y;float z;float w;} ink_part0_ink_v4_float;
_Static_assert(sizeof(ink_part0_ink_v4_float)==16,"packed compute layout");
typedef struct { ink_part0_ink_v4_float *data; size_t len; } ink_part0_ink_l_ink_v4_float;
_Static_assert(sizeof(int32_t)==4,"packed compute layout");
typedef struct { int32_t *data; size_t len; } ink_part0_ink_l_int32;
typedef struct {int32_t x;int32_t y;} ink_part0_ink_v2_int32;
_Static_assert(sizeof(ink_part0_ink_v2_int32)==8,"packed compute layout");
typedef struct { ink_part0_ink_v2_int32 *data; size_t len; } ink_part0_ink_l_ink_v2_int32;
typedef struct {int32_t x;int32_t y;int32_t z;} ink_part0_ink_v3_int32;
_Static_assert(sizeof(ink_part0_ink_v3_int32)==12,"packed compute layout");
typedef struct { ink_part0_ink_v3_int32 *data; size_t len; } ink_part0_ink_l_ink_v3_int32;
typedef struct {int32_t x;int32_t y;int32_t z;int32_t w;} ink_part0_ink_v4_int32;
_Static_assert(sizeof(ink_part0_ink_v4_int32)==16,"packed compute layout");
typedef struct { ink_part0_ink_v4_int32 *data; size_t len; } ink_part0_ink_l_ink_v4_int32;
_Static_assert(sizeof(uint32_t)==4,"packed compute layout");
typedef struct { uint32_t *data; size_t len; } ink_part0_ink_l_uint32;
typedef struct __attribute__((packed, aligned(4))) {uint32_t ink_part0_ink_f_root;uint32_t ink_part0_ink_f_quotient;uint32_t ink_part0_ink_f_floored;uint32_t ink_part0_ink_f_ceiled;uint32_t ink_part0_ink_f_truncated;uint32_t ink_part0_ink_f_rounded;uint32_t ink_part0_ink_f_nan;uint32_t ink_part0_ink_f_finite;} ink_part0_ink_r_Ops;
_Static_assert(sizeof(ink_part0_ink_r_Ops)==32,"packed compute layout");
typedef struct { ink_part0_ink_r_Ops *data; size_t len; } ink_part0_ink_l_ink_r_Ops;
typedef struct {uint32_t x;uint32_t y;} ink_part0_ink_v2_uint32;
_Static_assert(sizeof(ink_part0_ink_v2_uint32)==8,"packed compute layout");
typedef struct { ink_part0_ink_v2_uint32 *data; size_t len; } ink_part0_ink_l_ink_v2_uint32;
typedef struct {uint32_t x;uint32_t y;uint32_t z;} ink_part0_ink_v3_uint32;
_Static_assert(sizeof(ink_part0_ink_v3_uint32)==12,"packed compute layout");
typedef struct { ink_part0_ink_v3_uint32 *data; size_t len; } ink_part0_ink_l_ink_v3_uint32;
typedef struct {uint32_t x;uint32_t y;uint32_t z;uint32_t w;} ink_part0_ink_v4_uint32;
_Static_assert(sizeof(ink_part0_ink_v4_uint32)==16,"packed compute layout");
typedef struct { ink_part0_ink_v4_uint32 *data; size_t len; } ink_part0_ink_l_ink_v4_uint32;
_Static_assert(sizeof(uint64_t)==8,"packed compute layout");
typedef struct { uint64_t *data; size_t len; } ink_part0_ink_l_uint64;
ink_part0_ink_l_ink_r_Ops ink_part0_lang_fn_float_ops(ink_part0_ink_l_ink_v2_float a0);
size_t ink_part0_lang_fn_float_ops_into(ink_part0_ink_l_ink_v2_float a0,ink_part0_ink_r_Ops *destination);
ink_part0_ink_l_ink_r_Ops ink_part0_lang_fn_float_ops(ink_part0_ink_l_ink_v2_float a0){
(void)a0;
ink_part0_ink_l_ink_v2_float t0=a0;
(void)t0;
ink_part0_ink_l_ink_r_Ops t1={ink_part0_ink_alloc(t0.len,sizeof(ink_part0_ink_r_Ops)),t0.len};
for(size_t t2=0;t2<t0.len;t2++){
uint32_t t3=ink_part0_ink_f32_bits(ink_part0_ink_f32_canonical(__builtin_sqrtf((t0.data[t2]).x)));
(void)t3;
uint32_t t4=ink_part0_ink_f32_bits(ink_part0_ink_f32_canonical(((t0.data[t2]).x)/((t0.data[t2]).y)));
(void)t4;
uint32_t t5=ink_part0_ink_f32_bits(ink_part0_ink_f32_canonical(__builtin_floorf((t0.data[t2]).x)));
(void)t5;
uint32_t t6=ink_part0_ink_f32_bits(ink_part0_ink_f32_canonical(__builtin_ceilf((t0.data[t2]).x)));
(void)t6;
uint32_t t7=ink_part0_ink_f32_bits(ink_part0_ink_f32_canonical(__builtin_truncf((t0.data[t2]).x)));
(void)t7;
uint32_t t8=ink_part0_ink_f32_bits(ink_part0_ink_round_ties_even((t0.data[t2]).x));
(void)t8;
uint32_t t9=(__builtin_isnan((t0.data[t2]).x)!=0);
(void)t9;
uint32_t t10=(__builtin_isfinite((t0.data[t2]).x)!=0);
(void)t10;
t1.data[t2]=(ink_part0_ink_r_Ops){t3,t4,t5,t6,t7,t8,t9,t10};
}
return t1;
}
size_t ink_part0_lang_fn_float_ops_into(ink_part0_ink_l_ink_v2_float a0,ink_part0_ink_r_Ops *destination){
(void)a0;
ink_part0_ink_l_ink_v2_float t0=a0;
(void)t0;
ink_part0_ink_l_ink_r_Ops t1={destination,t0.len};
for(size_t t2=0;t2<t0.len;t2++){
uint32_t t3=ink_part0_ink_f32_bits(ink_part0_ink_f32_canonical(__builtin_sqrtf((t0.data[t2]).x)));
(void)t3;
uint32_t t4=ink_part0_ink_f32_bits(ink_part0_ink_f32_canonical(((t0.data[t2]).x)/((t0.data[t2]).y)));
(void)t4;
uint32_t t5=ink_part0_ink_f32_bits(ink_part0_ink_f32_canonical(__builtin_floorf((t0.data[t2]).x)));
(void)t5;
uint32_t t6=ink_part0_ink_f32_bits(ink_part0_ink_f32_canonical(__builtin_ceilf((t0.data[t2]).x)));
(void)t6;
uint32_t t7=ink_part0_ink_f32_bits(ink_part0_ink_f32_canonical(__builtin_truncf((t0.data[t2]).x)));
(void)t7;
uint32_t t8=ink_part0_ink_f32_bits(ink_part0_ink_round_ties_even((t0.data[t2]).x));
(void)t8;
uint32_t t9=(__builtin_isnan((t0.data[t2]).x)!=0);
(void)t9;
uint32_t t10=(__builtin_isfinite((t0.data[t2]).x)!=0);
(void)t10;
t1.data[t2]=(ink_part0_ink_r_Ops){t3,t4,t5,t6,t7,t8,t9,t10};
}
return t1.len;
}
size_t ink_part0_ink_compute_into(uint32_t function,const void *const *data,const size_t *lengths,void *destination){(void)data;(void)lengths;(void)destination;switch(function){
case 0:{ink_part0_ink_v2_float *a0=ink_part0_ink_alloc(lengths[0],sizeof(ink_part0_ink_v2_float));ink_part0_ink_copy(a0,data[0],lengths[0]*sizeof(ink_part0_ink_v2_float));return ink_part0_lang_fn_float_ops_into((ink_part0_ink_l_ink_v2_float){a0,lengths[0]},(ink_part0_ink_r_Ops *)destination)*8;}
default:ink_part0_ink_fail();}return 0;}
void ink_part0_ink_compute_call(uint32_t function,const void *const *data,const size_t *lengths,void **output,size_t *count){ (void)data;(void)lengths;switch(function){
case 0:{ink_part0_ink_v2_float *a0=ink_part0_ink_alloc(lengths[0],sizeof(ink_part0_ink_v2_float));ink_part0_ink_copy(a0,data[0],lengths[0]*sizeof(ink_part0_ink_v2_float));ink_part0_ink_l_ink_r_Ops result=ink_part0_lang_fn_float_ops((ink_part0_ink_l_ink_v2_float){a0,lengths[0]});*output=result.data;*count=result.len*8;break;}
default:ink_part0_ink_fail();}}
uint32_t ink_part0_ink_compute_scalar32(uint32_t function,const void *const *data,const size_t *lengths){ (void)data;(void)lengths;switch(function){
default:ink_part0_ink_fail();}return 0;}
uint64_t ink_part0_ink_compute_scalar64(uint32_t function,const void *const *data,const size_t *lengths){ (void)data;(void)lengths;switch(function){
default:ink_part0_ink_fail();}return 0;}
