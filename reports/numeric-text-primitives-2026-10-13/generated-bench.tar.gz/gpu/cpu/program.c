#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>
typedef struct InkContext InkContext;
extern uint64_t ink_literal(InkContext*,uint32_t,uint64_t,const char*,size_t);
extern uint64_t ink_op(InkContext*,const char*,const uint64_t*,size_t);
/* Frame tokens delimit invocation-local scratch. Only the returned handle and
 * pre-frame handles survive finish; tokens are private to literal emitted code. */
extern uint64_t ink_value_frame(InkContext*);
extern uint64_t ink_value_finish_frame(InkContext*,uint64_t,uint64_t);
extern uint64_t ink_item(InkContext*,uint64_t,size_t);
extern void ink_append(InkContext*,uint64_t,uint64_t);
extern size_t ink_length(InkContext*,uint64_t);
extern bool ink_bool(InkContext*,uint64_t);
extern uint32_t ink_u32(InkContext*,uint64_t);
extern bool ink_failed(InkContext*);
extern bool ink_tick(InkContext*);
extern uint64_t ink_error(InkContext*,const char*);
extern uint64_t ink_finish_action(InkContext*,uint64_t);
uint64_t ink_program_call(InkContext*,uint32_t,uint32_t,const uint64_t*,size_t);

typedef uint64_t (*InkParallelCallback)(InkContext*,uint32_t,uint64_t,const uint64_t*);
extern uint64_t ink_parallel(InkContext*,uint64_t,uint32_t,uint32_t,const uint64_t*,size_t,uint32_t);
static uint64_t pure0(InkContext*ctx,uint64_t a0);
static uint64_t pure1(InkContext*ctx,uint64_t a0);
static uint64_t pure2(InkContext*ctx,uint64_t a0);
static uint64_t pure3(InkContext*ctx,uint64_t a0);
static uint64_t pure4(InkContext*ctx,uint64_t a0);
static uint64_t pure5(InkContext*ctx,uint64_t a0);
static uint64_t pure6(InkContext*ctx,uint64_t a0);
static uint64_t pure7(InkContext*ctx,uint64_t a0);
static uint64_t pure8(InkContext*ctx,uint64_t a0);
static uint64_t pure9(InkContext*ctx,uint64_t a0);
static uint64_t pure10(InkContext*ctx,uint64_t a0,uint64_t a1);
static uint64_t pure11(InkContext*ctx,uint64_t a0,uint64_t a1,uint64_t a2);
static uint64_t pure12(InkContext*ctx,uint64_t a0,uint64_t a1);
static uint64_t pure13(InkContext*ctx,uint64_t a0,uint64_t a1,uint64_t a2);
static uint64_t pure0(InkContext*ctx,uint64_t a0){if(!ink_tick(ctx))return 0;
uint64_t v0=ink_op(ctx,"list",NULL,0);if(ink_failed(ctx))return 0;
size_t v2=ink_length(ctx,a0);
for(size_t v1=0;v1<v2;v1++){if(!ink_tick(ctx))return 0;
uint64_t v3=ink_item(ctx,a0,v1);if(ink_failed(ctx))return 0;
uint64_t v4=ink_op(ctx,"field:x",(uint64_t[]){v3},1);if(ink_failed(ctx))return 0;
uint64_t v5=ink_op(ctx,"sqrt",(uint64_t[]){v4},1);if(ink_failed(ctx))return 0;
uint64_t v6=ink_op(ctx,"f32_bits",(uint64_t[]){v5},1);if(ink_failed(ctx))return 0;
uint64_t v7=ink_op(ctx,"field:x",(uint64_t[]){v3},1);if(ink_failed(ctx))return 0;
uint64_t v8=ink_op(ctx,"field:y",(uint64_t[]){v3},1);if(ink_failed(ctx))return 0;
uint64_t v9=ink_op(ctx,"f32_div",(uint64_t[]){v7,v8},2);if(ink_failed(ctx))return 0;
uint64_t v10=ink_op(ctx,"f32_bits",(uint64_t[]){v9},1);if(ink_failed(ctx))return 0;
uint64_t v11=ink_op(ctx,"field:x",(uint64_t[]){v3},1);if(ink_failed(ctx))return 0;
uint64_t v12=ink_op(ctx,"floor",(uint64_t[]){v11},1);if(ink_failed(ctx))return 0;
uint64_t v13=ink_op(ctx,"f32_bits",(uint64_t[]){v12},1);if(ink_failed(ctx))return 0;
uint64_t v14=ink_op(ctx,"field:x",(uint64_t[]){v3},1);if(ink_failed(ctx))return 0;
uint64_t v15=ink_op(ctx,"ceil",(uint64_t[]){v14},1);if(ink_failed(ctx))return 0;
uint64_t v16=ink_op(ctx,"f32_bits",(uint64_t[]){v15},1);if(ink_failed(ctx))return 0;
uint64_t v17=ink_op(ctx,"field:x",(uint64_t[]){v3},1);if(ink_failed(ctx))return 0;
uint64_t v18=ink_op(ctx,"trunc",(uint64_t[]){v17},1);if(ink_failed(ctx))return 0;
uint64_t v19=ink_op(ctx,"f32_bits",(uint64_t[]){v18},1);if(ink_failed(ctx))return 0;
uint64_t v20=ink_op(ctx,"field:x",(uint64_t[]){v3},1);if(ink_failed(ctx))return 0;
uint64_t v21=ink_op(ctx,"round_ties_even",(uint64_t[]){v20},1);if(ink_failed(ctx))return 0;
uint64_t v22=ink_op(ctx,"f32_bits",(uint64_t[]){v21},1);if(ink_failed(ctx))return 0;
uint64_t v23=ink_op(ctx,"field:x",(uint64_t[]){v3},1);if(ink_failed(ctx))return 0;
uint64_t v24=ink_op(ctx,"is_nan",(uint64_t[]){v23},1);if(ink_failed(ctx))return 0;
uint64_t v25=ink_op(ctx,"field:x",(uint64_t[]){v3},1);if(ink_failed(ctx))return 0;
uint64_t v26=ink_op(ctx,"is_finite",(uint64_t[]){v25},1);if(ink_failed(ctx))return 0;
uint64_t v27=ink_op(ctx,"record:Ops",(uint64_t[]){v6,v10,v13,v16,v19,v22,v24,v26},8);if(ink_failed(ctx))return 0;
ink_append(ctx,v0,v27);if(ink_failed(ctx))return 0;
}
return v0;}
static uint64_t pure1(InkContext*ctx,uint64_t a0){if(!ink_tick(ctx))return 0;
uint64_t v28=ink_op(ctx,"u32_from_f32",(uint64_t[]){a0},1);if(ink_failed(ctx))return 0;
uint64_t v29=ink_op(ctx,"u64_from_f32",(uint64_t[]){a0},1);if(ink_failed(ctx))return 0;
uint64_t v30=ink_op(ctx,"i32_from_f32",(uint64_t[]){a0},1);if(ink_failed(ctx))return 0;
uint64_t v31=ink_op(ctx,"int_from_f32",(uint64_t[]){a0},1);if(ink_failed(ctx))return 0;
uint64_t v32=ink_op(ctx,"record:Casts",(uint64_t[]){v28,v29,v30,v31},4);if(ink_failed(ctx))return 0;
return v32;}
static uint64_t pure2(InkContext*ctx,uint64_t a0){if(!ink_tick(ctx))return 0;
uint64_t v33=ink_op(ctx,"list",NULL,0);if(ink_failed(ctx))return 0;
size_t v35=ink_length(ctx,a0);
for(size_t v34=0;v34<v35;v34++){if(!ink_tick(ctx))return 0;
uint64_t v36=ink_item(ctx,a0,v34);if(ink_failed(ctx))return 0;
uint64_t v37=ink_op(ctx,"f32_from_u64",(uint64_t[]){v36},1);if(ink_failed(ctx))return 0;
uint64_t v38=ink_op(ctx,"f32_bits",(uint64_t[]){v37},1);if(ink_failed(ctx))return 0;
ink_append(ctx,v33,v38);if(ink_failed(ctx))return 0;
}
return v33;}
static uint64_t pure3(InkContext*ctx,uint64_t a0){if(!ink_tick(ctx))return 0;
uint64_t v39=ink_op(ctx,"f32_from_u32",(uint64_t[]){a0},1);if(ink_failed(ctx))return 0;
uint64_t v40=ink_op(ctx,"f32_bits",(uint64_t[]){v39},1);if(ink_failed(ctx))return 0;
return v40;}
static uint64_t pure4(InkContext*ctx,uint64_t a0){if(!ink_tick(ctx))return 0;
uint64_t v41=ink_op(ctx,"f32_from_i32",(uint64_t[]){a0},1);if(ink_failed(ctx))return 0;
uint64_t v42=ink_op(ctx,"f32_bits",(uint64_t[]){v41},1);if(ink_failed(ctx))return 0;
return v42;}
static uint64_t pure5(InkContext*ctx,uint64_t a0){if(!ink_tick(ctx))return 0;
uint64_t v43=ink_op(ctx,"f32_from_int",(uint64_t[]){a0},1);if(ink_failed(ctx))return 0;
uint64_t v44=ink_op(ctx,"f32_bits",(uint64_t[]){v43},1);if(ink_failed(ctx))return 0;
return v44;}
static uint64_t pure6(InkContext*ctx,uint64_t a0){if(!ink_tick(ctx))return 0;
uint64_t v45=ink_op(ctx,"list",NULL,0);if(ink_failed(ctx))return 0;
size_t v47=ink_length(ctx,a0);
for(size_t v46=0;v46<v47;v46++){if(!ink_tick(ctx))return 0;
uint64_t v48=ink_item(ctx,a0,v46);if(ink_failed(ctx))return 0;
uint64_t v49=ink_op(ctx,"popcount",(uint64_t[]){v48},1);if(ink_failed(ctx))return 0;
uint64_t v50=ink_op(ctx,"leading_zeros",(uint64_t[]){v48},1);if(ink_failed(ctx))return 0;
uint64_t v51=ink_op(ctx,"trailing_zeros",(uint64_t[]){v48},1);if(ink_failed(ctx))return 0;
uint64_t v52=ink_op(ctx,"vector",(uint64_t[]){v49,v50,v51},3);if(ink_failed(ctx))return 0;
ink_append(ctx,v45,v52);if(ink_failed(ctx))return 0;
}
return v45;}
static uint64_t pure7(InkContext*ctx,uint64_t a0){if(!ink_tick(ctx))return 0;
uint64_t v53=ink_op(ctx,"popcount",(uint64_t[]){a0},1);if(ink_failed(ctx))return 0;
uint64_t v54=ink_op(ctx,"leading_zeros",(uint64_t[]){a0},1);if(ink_failed(ctx))return 0;
uint64_t v55=ink_op(ctx,"trailing_zeros",(uint64_t[]){a0},1);if(ink_failed(ctx))return 0;
uint64_t v56=ink_op(ctx,"vector",(uint64_t[]){v53,v54,v55},3);if(ink_failed(ctx))return 0;
return v56;}
static uint64_t pure8(InkContext*ctx,uint64_t a0){if(!ink_tick(ctx))return 0;
uint64_t v57=ink_op(ctx,"popcount",(uint64_t[]){a0},1);if(ink_failed(ctx))return 0;
uint64_t v58=ink_op(ctx,"leading_zeros",(uint64_t[]){a0},1);if(ink_failed(ctx))return 0;
uint64_t v59=ink_op(ctx,"trailing_zeros",(uint64_t[]){a0},1);if(ink_failed(ctx))return 0;
uint64_t v60=ink_op(ctx,"vector",(uint64_t[]){v57,v58,v59},3);if(ink_failed(ctx))return 0;
return v60;}
static uint64_t pure9(InkContext*ctx,uint64_t a0){if(!ink_tick(ctx))return 0;
uint64_t v61=ink_op(ctx,"string_byte_len",(uint64_t[]){a0},1);if(ink_failed(ctx))return 0;
return v61;}
static uint64_t pure10(InkContext*ctx,uint64_t a0,uint64_t a1){if(!ink_tick(ctx))return 0;
uint64_t v62=ink_op(ctx,"string_byte_at",(uint64_t[]){a0,a1},2);if(ink_failed(ctx))return 0;
return v62;}
static uint64_t pure11(InkContext*ctx,uint64_t a0,uint64_t a1,uint64_t a2){if(!ink_tick(ctx))return 0;
uint64_t v63=ink_op(ctx,"string_slice",(uint64_t[]){a0,a1,a2},3);if(ink_failed(ctx))return 0;
return v63;}
static uint64_t pure12(InkContext*ctx,uint64_t a0,uint64_t a1){if(!ink_tick(ctx))return 0;
uint64_t v64=ink_op(ctx,"string_concat",(uint64_t[]){a0,a1},2);if(ink_failed(ctx))return 0;
return v64;}
static uint64_t pure13(InkContext*ctx,uint64_t a0,uint64_t a1,uint64_t a2){if(!ink_tick(ctx))return 0;
uint64_t v65=ink_op(ctx,"string_find",(uint64_t[]){a0,a1,a2},3);if(ink_failed(ctx))return 0;
return v65;}
uint64_t ink_parallel_callback(InkContext*ctx,uint32_t callback,uint32_t index,uint64_t item,const uint64_t*captures){switch(callback){
default:return ink_error(ctx,"unknown compiled parallel callback");}}
uint64_t ink_program_call(InkContext*ctx,uint32_t kind,uint32_t index,const uint64_t*args,size_t length){switch(kind){
case 0:switch(index){
case 0:if(length!=1)return ink_error(ctx,"argument count mismatch");return pure0(ctx,args[0]);
case 1:if(length!=1)return ink_error(ctx,"argument count mismatch");return pure1(ctx,args[0]);
case 2:if(length!=1)return ink_error(ctx,"argument count mismatch");return pure2(ctx,args[0]);
case 3:if(length!=1)return ink_error(ctx,"argument count mismatch");return pure3(ctx,args[0]);
case 4:if(length!=1)return ink_error(ctx,"argument count mismatch");return pure4(ctx,args[0]);
case 5:if(length!=1)return ink_error(ctx,"argument count mismatch");return pure5(ctx,args[0]);
case 6:if(length!=1)return ink_error(ctx,"argument count mismatch");return pure6(ctx,args[0]);
case 7:if(length!=1)return ink_error(ctx,"argument count mismatch");return pure7(ctx,args[0]);
case 8:if(length!=1)return ink_error(ctx,"argument count mismatch");return pure8(ctx,args[0]);
case 9:if(length!=1)return ink_error(ctx,"argument count mismatch");return pure9(ctx,args[0]);
case 10:if(length!=2)return ink_error(ctx,"argument count mismatch");return pure10(ctx,args[0],args[1]);
case 11:if(length!=3)return ink_error(ctx,"argument count mismatch");return pure11(ctx,args[0],args[1],args[2]);
case 12:if(length!=2)return ink_error(ctx,"argument count mismatch");return pure12(ctx,args[0],args[1]);
case 13:if(length!=3)return ink_error(ctx,"argument count mismatch");return pure13(ctx,args[0],args[1],args[2]);
default:return ink_error(ctx,"unknown function index");}
case 1:switch(index){
default:return ink_error(ctx,"unknown function index");}
case 2:switch(index){
default:return ink_error(ctx,"unknown function index");}
default:return ink_error(ctx,"unknown call kind");}}
