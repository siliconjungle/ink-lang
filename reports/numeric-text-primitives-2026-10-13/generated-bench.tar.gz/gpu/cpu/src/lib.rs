#![allow(dead_code)]
mod portable {
//! Shared, representation-independent snapshot codec. This module also ships
//! verbatim in generated applications; it has no AST/evaluator dependency.
use num_bigint::{BigInt, Sign};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::cmp::Ordering;

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Schema {
    Unit,
    Bool,
    U32,
    U64,
    I32,
    F32,
    Vector(Box<Schema>, u8),
    Int,
    String,
    Id,
    Record(Vec<(String, Schema)>),
    Bind(String,Box<Schema>),
    Ref(String),
    Enum(Vec<String>),
    List(Box<Schema>),
    Option(Box<Schema>),
    Result(Box<Schema>, Box<Schema>),
}
/// Literal snapshot descriptors, distinct from public value ABI descriptors.
pub fn descriptor(s:&Schema)->Value {
    match s {
        Schema::Bind(n,t)=>json!({"kind":"bind","name":n,"body":descriptor(t)}),
        Schema::Ref(n)=>json!({"kind":"ref","name":n}),
        Schema::Record(fs)=>json!({"kind":"record","fields":fs.iter().map(|(n,t)|json!({"name":n,"type":descriptor(t)})).collect::<Vec<_>>()}),
        Schema::Enum(xs)=>json!({"kind":"enum","variants":xs}),
        Schema::List(t)=>json!({"kind":"list","element":descriptor(t)}),
        Schema::Option(t)=>json!({"kind":"option","element":descriptor(t)}),
        Schema::Result(a,b)=>json!({"kind":"result","ok":descriptor(a),"error":descriptor(b)}),
        Schema::Vector(t,n)=>json!({"kind":"vector","element":descriptor(t),"size":n}),
        _=>json!({"kind":match s {Schema::Unit=>"unit",Schema::Bool=>"bool",Schema::U32=>"u32",Schema::U64=>"u64",Schema::I32=>"i32",Schema::F32=>"f32",Schema::Int=>"int",Schema::String=>"string",Schema::Id=>"id",_=>unreachable!()}}),
    }
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Layout {
    pub program: [u8; 32],
    pub schema: [u8; 32],
    pub roots: Vec<(String, Schema, Schema)>,
    pub events: Vec<(String, Schema)>,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Event {
    pub commit: u64,
    pub position: u64,
    pub channel: usize,
    pub value: Value,
}
#[derive(Clone, Debug, PartialEq)]
pub struct Logical {
    pub version: u64,
    pub tables: Vec<Vec<(Value, Value)>>,
    pub outbox: Vec<Event>,
}
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub bytes: usize,
    pub values: usize,
    pub depth: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            bytes: 64 * 1024 * 1024,
            values: 1_000_000,
            depth: 128,
        }
    }
}
/// Magnitude bound for one exact integer. Decimal conversion is superlinear,
/// so without it a single large Int in a snapshot takes minutes to hours.
pub const MAX_INT_BYTES: usize = 4096;
const MAGIC: &[u8; 8] = b"VLSTATE\0";
const HEADER: usize = 8 + 2 + 2 + 32 + 32 + 8;
type R<T> = Result<T, String>;
fn u64_bytes(out: &mut Vec<u8>, v: u64) {
    out.extend_from_slice(&v.to_le_bytes());
}
fn count(out: &mut Vec<u8>, n: usize) {
    u64_bytes(out, n as u64);
}
fn raw(out: &mut Vec<u8>, b: &[u8]) {
    count(out, b.len());
    out.extend_from_slice(b);
}
fn tag<'a>(v: &'a Value, name: &str) -> R<&'a Value> {
    let o = v.as_object().ok_or("expected tagged object")?;
    if o.len() != 1 {
        return Err("expected exactly one tag".into());
    }
    o.get(name).ok_or("unexpected value tag".into())
}
fn integer(v: &Value) -> R<BigInt> {
    let s = tag(v, "Int")?.as_str().ok_or("expected Int string")?;
    // Every Int within the bound has fewer than 2.41 decimal digits per byte.
    if s.len() > MAX_INT_BYTES * 5 / 2 + 1 {
        return Err("snapshot Int exceeds size limit".into());
    }
    let n = s.parse::<BigInt>().map_err(|_| "invalid Int")?;
    if n.bits() > 8 * MAX_INT_BYTES as u64 {
        return Err("snapshot Int exceeds size limit".into());
    }
    if n.to_string() != s {
        return Err("noncanonical Int".into());
    }
    Ok(n)
}
fn identifier(v: &Value) -> R<u128> {
    let s = v.as_str().ok_or("expected ID")?;
    if s.len() != 32
        || !s
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err("noncanonical ID".into());
    }
    u128::from_str_radix(s, 16).map_err(|e| e.to_string())
}
fn compare(t: &Schema, a: &Value, b: &Value) -> R<Ordering> {
    Ok(match t {
        Schema::Bool=>a.as_bool().ok_or("invalid Bool key")?.cmp(&b.as_bool().ok_or("invalid Bool key")?),
        Schema::I32 => a
            .as_i64()
            .and_then(|n| i32::try_from(n).ok())
            .ok_or("invalid i32 key")?
            .cmp(
                &b.as_i64()
                    .and_then(|n| i32::try_from(n).ok())
                    .ok_or("invalid i32 key")?,
            ),
        Schema::U32 | Schema::U64 => a
            .as_u64()
            .ok_or("invalid key")?
            .cmp(&b.as_u64().ok_or("invalid key")?),
        Schema::String => a
            .as_str()
            .ok_or("invalid key")?
            .as_bytes()
            .cmp(b.as_str().ok_or("invalid key")?.as_bytes()),
        Schema::Id => identifier(a)?.cmp(&identifier(b)?),
        _ => return Err("unsupported snapshot key schema".into()),
    })
}
fn tick(left: &mut usize, depth: usize, limits: Limits) -> R<()> {
    if *left == 0 || depth > limits.depth {
        return Err("snapshot value/depth limit exceeded".into());
    }
    *left -= 1;
    Ok(())
}
fn encode_value<'s>(
    t: &'s Schema,
    v: &Value,
    out: &mut Vec<u8>,
    left: &mut usize,
    depth: usize,
    limits: Limits,
    bindings: &mut Vec<(&'s str,&'s Schema)>,
) -> R<()> {
    tick(left, depth, limits)?;
    match t {
        Schema::Bind(name,body) => {
            bindings.push((name,body));
            let result=encode_value(body,v,out,left,depth+1,limits,bindings);
            bindings.pop();result?;
        }
        Schema::Ref(name) => {
            let body=bindings.iter().rev().find(|(n,_)|*n==name).map(|(_,s)|*s).ok_or("unbound recursive snapshot schema")?;
            encode_value(body,v,out,left,depth+1,limits,bindings)?;
        }
        Schema::Unit => {
            if !v.is_null() {
                return Err("expected Unit".into());
            }
        }
        Schema::Bool => out.push(v.as_bool().ok_or("expected Bool")? as u8),
        Schema::U32 => out.extend_from_slice(
            &u32::try_from(v.as_u64().ok_or("expected u32")?)
                .map_err(|_| "u32 overflow")?
                .to_le_bytes(),
        ),
        Schema::U64 => u64_bytes(out, v.as_u64().ok_or("expected u64")?),
        Schema::I32 => out.extend_from_slice(
            &i32::try_from(v.as_i64().ok_or("expected i32")?)
                .map_err(|_| "i32 overflow")?
                .to_le_bytes(),
        ),
        Schema::F32 => {
            let bits = if let Some(b) = v.get("F32Bits") {
                if v.as_object().is_none_or(|o| o.len() != 1) {
                    return Err("expected only F32Bits field".into());
                }
                u32::try_from(b.as_u64().ok_or("expected f32 bits")?)
                    .map_err(|_| "f32 bits overflow")?
            } else {
                let f = v.as_f64().ok_or("expected f32")? as f32;
                if !f.is_finite() {
                    return Err("finite f32 or F32Bits required".into());
                }
                f.to_bits()
            };
            out.extend_from_slice(&bits.to_le_bytes());
        }
        Schema::Vector(inner, n) => {
            if !(2..=4).contains(n)
                || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
            {
                return Err("invalid vector schema".into());
            }
            let xs = v.as_array().ok_or("expected vector")?;
            if xs.len() != *n as usize {
                return Err("vector dimension mismatch".into());
            }
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits,bindings)?;
            }
        }
        Schema::Int => {
            let n = integer(v)?;
            let (sign, b) = n.to_bytes_le();
            out.push(match sign {
                Sign::NoSign => 0,
                Sign::Plus => 1,
                Sign::Minus => 2,
            });
            if sign == Sign::NoSign {
                raw(out, &[])
            } else {
                raw(out, &b)
            }
        }
        Schema::String => raw(out, v.as_str().ok_or("expected String")?.as_bytes()),
        Schema::Id => out.extend_from_slice(&identifier(v)?.to_le_bytes()),
        Schema::Enum(names) => {
            let s = v.as_str().ok_or("expected enum string")?;
            let index = names
                .iter()
                .position(|n| n == s)
                .ok_or("unknown enum variant")?;
            out.extend_from_slice(&(index as u32).to_le_bytes());
        }
        Schema::Record(fields) => {
            let obj = v.as_object().ok_or("expected record")?;
            if obj.len() != fields.len() {
                return Err("record field mismatch".into());
            }
            for (n, t) in fields {
                encode_value(
                    t,
                    obj.get(n).ok_or("missing record field")?,
                    out,
                    left,
                    depth + 1,
                    limits,
                    bindings,
                )?;
            }
        }
        Schema::List(inner) => {
            let xs = v.as_array().ok_or("expected List")?;
            if xs.len() > *left {
                return Err("snapshot value limit exceeded".into());
            }
            count(out, xs.len());
            for x in xs {
                encode_value(inner, x, out, left, depth + 1, limits,bindings)?;
            }
        }
        Schema::Option(inner) => {
            if let Ok(x) = tag(v, "Some") {
                out.push(1);
                encode_value(inner, x, out, left, depth + 1, limits,bindings)?;
            } else {
                if !tag(v, "None")?.is_null() {
                    return Err("invalid None".into());
                }
                out.push(0);
            }
        }
        Schema::Result(a, b) => {
            if let Ok(x) = tag(v, "Ok") {
                out.push(0);
                encode_value(a, x, out, left, depth + 1, limits,bindings)?;
            } else {
                out.push(1);
                encode_value(b, tag(v, "Err")?, out, left, depth + 1, limits,bindings)?;
            }
        }
    }
    if out.len() > limits.bytes {
        return Err("snapshot byte limit exceeded".into());
    }
    Ok(())
}
struct Reader<'a> {
    bytes: &'a [u8],
    at: usize,
    left: usize,
    limits: Limits,
}
impl<'a> Reader<'a> {
    fn take(&mut self, n: usize) -> R<&'a [u8]> {
        let end = self.at.checked_add(n).ok_or("snapshot length overflow")?;
        let b = self.bytes.get(self.at..end).ok_or("truncated snapshot")?;
        self.at = end;
        Ok(b)
    }
    fn byte(&mut self) -> R<u8> {
        Ok(self.take(1)?[0])
    }
    fn u32(&mut self) -> R<u32> {
        Ok(u32::from_le_bytes(self.take(4)?.try_into().unwrap()))
    }
    fn u64(&mut self) -> R<u64> {
        Ok(u64::from_le_bytes(self.take(8)?.try_into().unwrap()))
    }
    fn len(&mut self) -> R<usize> {
        usize::try_from(self.u64()?).map_err(|_| "snapshot length not addressable".into())
    }
    fn sequence(&mut self) -> R<usize> {
        let n = self.len()?;
        if n > self.left {
            return Err("snapshot value limit exceeded".into());
        }
        Ok(n)
    }
    fn raw(&mut self) -> R<&'a [u8]> {
        let n = self.len()?;
        self.take(n)
    }
    fn value(&mut self, t: &Schema, depth: usize) -> R<Value> {
        self.value_scoped(t,depth,&mut vec![])
    }
    fn value_scoped<'s>(&mut self,t:&'s Schema,depth:usize,bindings:&mut Vec<(&'s str,&'s Schema)>)->R<Value>{
        tick(&mut self.left, depth, self.limits)?;
        Ok(match t {
            Schema::Bind(name,body) => {
                bindings.push((name,body));let result=self.value_scoped(body,depth+1,bindings);bindings.pop();result?
            }
            Schema::Ref(name) => {
                let body=bindings.iter().rev().find(|(n,_)|*n==name).map(|(_,s)|*s).ok_or("unbound recursive snapshot schema")?;
                self.value_scoped(body,depth+1,bindings)?
            }
            Schema::Unit => Value::Null,
            Schema::Bool => match self.byte()? {
                0 => json!(false),
                1 => json!(true),
                _ => return Err("invalid Bool tag".into()),
            },
            Schema::U32 => json!(self.u32()?),
            Schema::U64 => json!(self.u64()?),
            Schema::I32 => json!(self.u32()? as i32),
            Schema::F32 => {
                let bits = self.u32()?;
                let f = f32::from_bits(bits);
                if f.is_finite() {
                    json!(f)
                } else {
                    json!({"F32Bits":bits})
                }
            }
            Schema::Vector(inner, n) => {
                if !(2..=4).contains(n)
                    || !matches!(inner.as_ref(), Schema::U32 | Schema::I32 | Schema::F32)
                {
                    return Err("invalid vector schema".into());
                }
                (0..*n)
                    .map(|_| self.value_scoped(inner, depth + 1,bindings))
                    .collect::<R<Vec<_>>>()?
                    .into()
            }
            Schema::Int => {
                let sign = self.byte()?;
                let bytes = self.raw()?;
                if bytes.len() > MAX_INT_BYTES {
                    return Err("snapshot Int exceeds size limit".into());
                }
                let sign = match sign {
                    0 if bytes.is_empty() => Sign::NoSign,
                    1 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Plus,
                    2 if !bytes.is_empty() && bytes.last() != Some(&0) => Sign::Minus,
                    _ => return Err("noncanonical signed integer".into()),
                };
                json!({"Int":BigInt::from_bytes_le(sign,bytes).to_string()})
            }
            Schema::String => json!(std::str::from_utf8(self.raw()?).map_err(|_| "invalid UTF-8")?),
            Schema::Id => json!(format!(
                "{:032x}",
                u128::from_le_bytes(self.take(16)?.try_into().unwrap())
            )),
            Schema::Enum(names) => {
                json!(names.get(self.u32()? as usize).ok_or("invalid enum tag")?)
            }
            Schema::Record(fields) => {
                let mut obj = serde_json::Map::new();
                for (n, t) in fields {
                    obj.insert(n.clone(), self.value_scoped(t, depth + 1,bindings)?);
                }
                Value::Object(obj)
            }
            Schema::List(t) => {
                let n = self.sequence()?;
                let mut xs = Vec::new();
                for _ in 0..n {
                    xs.push(self.value_scoped(t, depth + 1,bindings)?);
                }
                Value::Array(xs)
            }
            Schema::Option(t) => match self.byte()? {
                0 => json!({"None":null}),
                1 => json!({"Some":self.value_scoped(t,depth+1,bindings)?}),
                _ => return Err("invalid Option tag".into()),
            },
            Schema::Result(a, b) => match self.byte()? {
                0 => json!({"Ok":self.value_scoped(a,depth+1,bindings)?}),
                1 => json!({"Err":self.value_scoped(b,depth+1,bindings)?}),
                _ => return Err("invalid Result tag".into()),
            },
        })
    }
}
fn event_order(e: &Event, version: u64, prior: Option<(u64, u64)>) -> R<()> {
    if e.commit == 0 || e.commit > version || prior.is_some_and(|p| p >= (e.commit, e.position)) {
        return Err("invalid snapshot event sequence".into());
    }
    Ok(())
}
pub fn encode(layout: &Layout, s: &Logical, limits: Limits) -> R<Vec<u8>> {
    if s.tables.len() != layout.roots.len() {
        return Err("snapshot root count mismatch".into());
    }
    let mut out = Vec::new();
    let mut left = limits.values;
    u64_bytes(&mut out, s.version);
    for (rows, (_, kt, vt)) in s.tables.iter().zip(&layout.roots) {
        if rows.len() > left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        count(&mut out, rows.len());
        let mut prior = None;
        for (k, v) in rows {
            if let Some(p) = prior {
                if compare(kt, p, k)? != Ordering::Less {
                    return Err("snapshot keys must be strictly ordered".into());
                }
            }
            encode_value(kt, k, &mut out, &mut left, 0, limits,&mut vec![])?;
            encode_value(vt, v, &mut out, &mut left, 0, limits,&mut vec![])?;
            prior = Some(k);
        }
    }
    count(&mut out, s.outbox.len());
    let mut prior = None;
    for e in &s.outbox {
        event_order(e, s.version, prior)?;
        let (_, t) = layout
            .events
            .get(e.channel)
            .ok_or("unknown event channel")?;
        u64_bytes(&mut out, e.commit);
        u64_bytes(&mut out, e.position);
        out.extend_from_slice(&(e.channel as u32).to_le_bytes());
        encode_value(t, &e.value, &mut out, &mut left, 0, limits,&mut vec![])?;
        prior = Some((e.commit, e.position));
    }
    if HEADER
        .checked_add(out.len())
        .and_then(|n| n.checked_add(32))
        .is_none_or(|n| n > limits.bytes)
    {
        return Err("snapshot byte limit exceeded".into());
    }
    let mut bytes = Vec::new();
    bytes.extend_from_slice(MAGIC);
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&1u16.to_le_bytes());
    bytes.extend_from_slice(&layout.program);
    bytes.extend_from_slice(&layout.schema);
    count(&mut bytes, out.len());
    bytes.extend_from_slice(&out);
    let digest = Sha256::digest(&bytes);
    bytes.extend_from_slice(&digest);
    Ok(bytes)
}
pub fn decode(layout: &Layout, bytes: &[u8], limits: Limits) -> R<Logical> {
    if bytes.len() > limits.bytes || bytes.len() < HEADER + 32 {
        return Err("snapshot byte length invalid".into());
    }
    if &bytes[..8] != MAGIC || bytes[8..12] != [1, 0, 1, 0] {
        return Err("snapshot format or semantics version mismatch".into());
    }
    if bytes[12..44] != layout.program || bytes[44..76] != layout.schema {
        return Err("snapshot program or schema identity mismatch".into());
    }
    let n = usize::try_from(u64::from_le_bytes(bytes[76..84].try_into().unwrap()))
        .map_err(|_| "snapshot length not addressable")?;
    if HEADER.checked_add(n).and_then(|v| v.checked_add(32)) != Some(bytes.len()) {
        return Err("snapshot payload length mismatch".into());
    }
    let end = bytes.len() - 32;
    if Sha256::digest(&bytes[..end]).as_slice() != &bytes[end..] {
        return Err("snapshot integrity check failed".into());
    }
    let mut r = Reader {
        bytes: &bytes[HEADER..end],
        at: 0,
        left: limits.values,
        limits,
    };
    let version = r.u64()?;
    let mut tables = vec![];
    for (_, kt, vt) in &layout.roots {
        let n = r.sequence()?;
        if n > r.left / 2 {
            return Err("snapshot row limit exceeded".into());
        }
        let mut rows: Vec<(Value, Value)> = vec![];
        for _ in 0..n {
            let k = r.value(kt, 0)?;
            let v = r.value(vt, 0)?;
            if let Some((prior, _)) = rows.last() {
                if compare(kt, prior, &k)? != Ordering::Less {
                    return Err("duplicate or unordered snapshot key".into());
                }
            }
            rows.push((k, v));
        }
        tables.push(rows);
    }
    let n = r.sequence()?;
    let mut outbox = vec![];
    let mut prior = None;
    for _ in 0..n {
        let commit = r.u64()?;
        let position = r.u64()?;
        let channel = r.u32()? as usize;
        let (_, t) = layout
            .events
            .get(channel)
            .ok_or("unknown snapshot event channel")?;
        let value = r.value(t, 0)?;
        let e = Event {
            commit,
            position,
            channel,
            value,
        };
        event_order(&e, version, prior)?;
        prior = Some((commit, position));
        outbox.push(e);
    }
    if r.at != r.bytes.len() {
        return Err("trailing snapshot payload".into());
    }
    Ok(Logical {
        version,
        tables,
        outbox,
    })
}

#[cfg(test)]
mod recursive_schema_tests {
    use super::*;
    fn node(next:Schema)->Schema {Schema::Record(vec![("value".into(),Schema::U64),("next".into(),Schema::Option(Box::new(next)))])}
    fn layout(value:Schema)->Layout {Layout{program:[1;32],schema:[2;32],roots:vec![("Rows".into(),Schema::U64,value)],events:vec![]}}
    #[test]
    fn recursive_schema_preserves_wire_bytes_and_rejects_truncation() {
        let bound=layout(Schema::Bind("Node".into(),Box::new(node(Schema::Ref("Node".into())))));
        let unrolled=layout(node(node(Schema::Unit)));
        let logical=Logical{version:4,tables:vec![vec![(json!(3),json!({"value":7,"next":{"Some":{"value":9,"next":{"None":null}}}}))]],outbox:vec![]};
        let bytes=encode(&bound,&logical,Limits::default()).unwrap();
        assert_eq!(bytes,encode(&unrolled,&logical,Limits::default()).unwrap());
        assert_eq!(logical,decode(&bound,&bytes,Limits::default()).unwrap());
        assert!(decode(&bound,&bytes[..bytes.len()-1],Limits::default()).is_err());
        assert!(decode(&bound,&bytes,Limits{depth:3,..Limits::default()}).unwrap_err().contains("depth"));
    }
    #[test]
    fn schema_references_cannot_escape_or_loop_without_consuming_budget() {
        let logical=Logical{version:0,tables:vec![vec![(json!(0),Value::Null)]],outbox:vec![]};
        assert!(encode(&layout(Schema::Ref("Missing".into())),&logical,Limits::default()).unwrap_err().contains("unbound"));
        let cyclic=layout(Schema::Bind("X".into(),Box::new(Schema::Ref("X".into()))));
        assert!(encode(&cyclic,&logical,Limits{depth:8,..Limits::default()}).unwrap_err().contains("depth"));
    }
}

}
pub use portable::Limits as SnapshotLimits;
mod transaction {
//! Fixed transaction primitives, shared verbatim with generated execution.
//! These describe the base protocol; they select no optimisation or layout.

pub const SEMANTICS: &str = "ink-change-boundary-v1";

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Decision {
    Rollback,
    Commit { version: u64 },
    Exhausted,
}

/// A domain error wins over commit exhaustion. The body has already run;
/// both Rollback and Exhausted require restoration of its tentative effects.
#[inline]
pub fn decide(version: u64, succeeded: bool) -> Decision {
    if !succeeded {
        Decision::Rollback
    } else if let Some(version) = version.checked_add(1) {
        Decision::Commit { version }
    } else {
        Decision::Exhausted
    }
}

/// A nested change's error cannot be captured or ignored by its caller.
/// The outer Err exits the caller; the inner Result is its ordinary value.
#[inline]
pub fn nested_change<T, E>(result: Result<T, E>) -> Result<Result<T, E>, E> {
    match result {
        value @ Ok(_) => Ok(value),
        Err(error) => Err(error),
    }
}

#[derive(Debug, PartialEq, Eq)]
pub struct Publication<T> {
    pub commit: u64,
    pub position: u64,
    pub value: T,
}

/// Preserve staged order and number the committed suffix from zero, regardless
/// of earlier outbox contents. Publication neither clones nor reorders payloads.
pub fn publish<T>(
    version: u64,
    staged: impl Iterator<Item = T>,
) -> impl Iterator<Item = Publication<T>> {
    staged
        .enumerate()
        .map(move |(position, value)| Publication {
            commit: version,
            position: position as u64,
            value,
        })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn domain_errors_precede_exhaustion_and_success_never_wraps() {
        for version in [0, 1, 1 << 63, u64::MAX - 1, u64::MAX] {
            assert_eq!(decide(version, false), Decision::Rollback);
            assert_eq!(
                decide(version, true),
                match version.checked_add(1) {
                    Some(version) => Decision::Commit { version },
                    None => Decision::Exhausted,
                }
            );
        }
    }

    #[test]
    fn nested_result_and_ordered_publication_move_payloads() {
        struct Owned(&'static str);
        assert!(nested_change::<Owned, _>(Err(Owned("error"))).is_err());
        let value = nested_change::<_, Owned>(Ok(Owned("value")))
            .ok()
            .unwrap()
            .ok()
            .unwrap();
        let events: Vec<_> = publish(u64::MAX, [value, Owned("second")].into_iter()).collect();
        assert_eq!(events[0].commit, u64::MAX);
        assert_eq!(events[0].position, 0);
        assert_eq!(events[0].value.0, "value");
        assert_eq!(events[1].position, 1);
        assert_eq!(events[1].value.0, "second");
        assert_eq!(publish::<Owned>(2, std::iter::empty()).count(), 0);
    }
}

}
mod temporary {
// Affine owners use a Vec directly until partitioned. Partitions share one
// allocation with disjoint logical ranges. Checked source cannot retain the old
// owner or escape a partition; growth detaches a range before it can overlap.
#[derive(Clone, Debug)]
enum InkBufferStorage<T> {
    Owned(Vec<T>),
    Shared { data:std::rc::Rc<std::cell::RefCell<Vec<T>>>, start:usize, end:usize },
}
#[derive(Clone, Debug)]
pub struct OwnedBuffer<T>(InkBufferStorage<T>);
impl<T:Clone> OwnedBuffer<T> {
    pub fn new(xs:Vec<T>)->Self { Self(InkBufferStorage::Owned(xs)) }
    // Opaque native handles are invocation-local aliases, not source owners.
    pub fn shared(xs:Vec<T>)->Self { let end=xs.len();Self(InkBufferStorage::Shared{data:std::rc::Rc::new(std::cell::RefCell::new(xs)),start:0,end}) }
    fn read<R>(&self,f:impl FnOnce(&[T])->R)->R {match &self.0 {
        InkBufferStorage::Owned(xs)=>f(xs),
        InkBufferStorage::Shared{start,end,..} if start==end=>f(&[]),
        InkBufferStorage::Shared{data,start,end}=>f(&data.borrow()[*start..*end]),
    }}
    fn edit<R>(&mut self,f:impl FnOnce(&mut [T])->R)->R {match &mut self.0 {
        InkBufferStorage::Owned(xs)=>f(xs),
        InkBufferStorage::Shared{start,end,..} if start==end=>f(&mut []),
        InkBufferStorage::Shared{data,start,end}=>f(&mut data.borrow_mut()[*start..*end]),
    }}
    pub fn len(&self)->u32 {let n=match &self.0 {InkBufferStorage::Owned(xs)=>xs.len(),InkBufferStorage::Shared{start,end,..}=>end-start};n.try_into().expect("buffer exceeds u32")}
    pub fn get(&self,i:u32)->Option<T>{self.read(|xs|xs.get(i as usize).cloned())}
    pub fn with_item<R>(&self,i:u32,f:impl FnOnce(Option<&T>)->R)->R {self.read(|xs|f(xs.get(i as usize)))}
    pub unsafe fn get_unchecked(&self,i:u32)->T {self.read(|xs|unsafe{xs.get_unchecked(i as usize).clone()})}
    pub fn set(mut self,i:u32,value:T)->Self {self.edit(|xs|if let Some(x)=xs.get_mut(i as usize){*x=value});self}
    pub fn swap(mut self,a:u32,b:u32)->Self {self.edit(|xs|if (a as usize)<xs.len()&&(b as usize)<xs.len(){xs.swap(a as usize,b as usize)});self}
    pub fn fill_range(mut self,start:u32,count:u32,value:T)->Self {
        self.edit(|xs|{let start=(start as usize).min(xs.len());let count=(count as usize).min(xs.len()-start);xs[start..start+count].fill(value)});self
    }
    pub fn copy_within(mut self,source:u32,destination:u32,count:u32)->Self {
        self.edit(|xs|{
            let source=(source as usize).min(xs.len());let destination=(destination as usize).min(xs.len());
            let count=(count as usize).min(xs.len()-source).min(xs.len()-destination);
            if source==destination{return}
            if destination>source {for i in (0..count).rev(){xs[destination+i]=xs[source+i].clone();}}
            else {for i in 0..count{xs[destination+i]=xs[source+i].clone();}}
        });self
    }
    pub fn map_inplace(mut self,mut f:impl FnMut(T)->T)->Self {self.edit(|xs|for x in xs{*x=f(x.clone())});self}
    pub fn map_indexed_inplace(mut self,mut f:impl FnMut(u32,T)->T)->Self {self.edit(|xs|for(i,x)in xs.iter_mut().enumerate(){*x=f(i as u32,x.clone())});self}
    pub fn scan_inplace(mut self,acc:T,mut f:impl FnMut(T,T)->T)->Self {let mut state=Some(acc);self.edit(|xs|for x in xs{let next=f(state.take().expect("scan state"),x.clone());*x=next.clone();state=Some(next)});self}
    pub fn filter_inplace(mut self,mut f:impl FnMut(T)->bool)->Self {
        let kept=self.edit(|xs|{let mut n=0;for i in 0..xs.len(){if f(xs[i].clone()){xs.swap(n,i);n+=1}}n});
        self.truncate(kept as u32)
    }
    pub fn pop(self)->Self {let n=self.len().saturating_sub(1);self.truncate(n)}
    pub fn truncate(mut self,n:u32)->Self {match &mut self.0 {
        InkBufferStorage::Owned(xs)=>xs.truncate(n as usize),
        InkBufferStorage::Shared{start,end,..}=>*end=*start+((*end-*start).min(n as usize)),
    };self}
    pub fn push(mut self,value:T)->Self {
        assert!(self.len()<u32::MAX,"buffer length exhausted");
        match &mut self.0 {
            InkBufferStorage::Owned(xs)=>{xs.push(value);return self},
            InkBufferStorage::Shared{data,start,end} if *start==0&&*end==data.borrow().len()=>{data.borrow_mut().push(value);*end+=1;return self},
            _=>{},
        }
        let mut xs=self.freeze();xs.push(value);Self::new(xs)
    }
    pub fn split(self,at:u32)->(Self,Self){
        if at==0 || at>=self.len(){
            let empty=if matches!(&self.0,InkBufferStorage::Shared{..}){Self::shared(Vec::new())}else{Self::new(Vec::new())};
            return if at==0 {(empty,self)}else{(self,empty)}
        }
        let (data,start,end)=match self.0 {
            InkBufferStorage::Owned(xs)=>{let end=xs.len();(std::rc::Rc::new(std::cell::RefCell::new(xs)),0,end)},
            InkBufferStorage::Shared{data,start,end}=>(data,start,end),
        };
        let cut=start+(at as usize).min(end-start);
        (Self(InkBufferStorage::Shared{data:data.clone(),start,end:cut}),Self(InkBufferStorage::Shared{data,start:cut,end}))
    }
    pub fn append(self,other:Self)->Self {
        if let (InkBufferStorage::Shared{data,start,end},InkBufferStorage::Shared{data:rhs,start:rstart,end:rend})=(&self.0,&other.0) {
            if std::rc::Rc::ptr_eq(data,rhs)&&end==rstart {return Self(InkBufferStorage::Shared{data:data.clone(),start:*start,end:*rend})}
        }
        let mut rhs=other.freeze();
        let mut left=self;
        if let InkBufferStorage::Shared{data,start,end}=&mut left.0 {
            if *start==0&&*end==data.borrow().len(){data.borrow_mut().append(&mut rhs);*end=data.borrow().len();return left}
        }
        let mut xs=left.freeze();xs.append(&mut rhs);Self::new(xs)
    }
    // Opaque handles obey checked source moves. Other nonempty aliases are
    // dead after this transfer; empty scoped partitions remain usable.
    pub fn freeze_handle(self)->Vec<T>{
        if let InkBufferStorage::Shared{data,start,end}=&self.0 {
            if start==end{return Vec::new()}
            if *start==0&&*end==data.borrow().len(){return std::mem::take(&mut *data.borrow_mut())}
        }
        self.freeze()
    }
    pub fn freeze(self)->Vec<T>{match self.0 {
        InkBufferStorage::Owned(xs)=>xs,
        InkBufferStorage::Shared{start,end,..} if start==end=>Vec::new(),
        InkBufferStorage::Shared{data,start,end}=>match std::rc::Rc::try_unwrap(data) {
            Ok(cell)=>{let mut xs=cell.into_inner();xs.truncate(end);if start==0{xs}else{xs.drain(..start);xs}},
            Err(data)=>data.borrow()[start..end].to_vec(),
        }
    }}
}
impl<T:Clone+PartialEq> PartialEq for OwnedBuffer<T>{fn eq(&self,r:&Self)->bool{self.read(|a|r.read(|b|a==b))}}
impl<T:Clone+Eq> Eq for OwnedBuffer<T>{}
impl<T:Clone+PartialOrd> PartialOrd for OwnedBuffer<T>{fn partial_cmp(&self,r:&Self)->Option<std::cmp::Ordering>{self.read(|a|r.read(|b|a.partial_cmp(b)))}}
impl<T:Clone+Ord> Ord for OwnedBuffer<T>{fn cmp(&self,r:&Self)->std::cmp::Ordering{self.read(|a|r.read(|b|a.cmp(b)))}}
// Exact dense scalar scratch with bounded per-thread allocation reuse. Keys
// outside the dense domain migrate all live entries into the ordered fallback.
const INK_DENSE_LIMIT: usize = 4096;
const INK_SCRATCH_RETAIN: usize = 2048;
const INK_SCRATCH_POOL_LIMIT: usize = 8;
std::thread_local! {static INK_MAP_POOL:std::cell::RefCell<Vec<Box<dyn std::any::Any>>>=const{std::cell::RefCell::new(Vec::new())};}
#[derive(Clone, Debug)]
struct InkSlot<K,V> { epoch:u64, value:Option<(K,V)> }
#[derive(Clone, Debug)]
struct InkDense<K,V> { epoch:u64, length:usize, slots:Vec<InkSlot<K,V>> }
impl<K:'static,V:'static> InkDense<K,V> {
    fn fresh()->Self {
        let old=INK_MAP_POOL.with(|pool| {let mut pool=pool.borrow_mut();let at=pool.iter().position(|p|p.as_ref().is::<Self>());at.map(|i|*pool.swap_remove(i).downcast::<Self>().unwrap())});
        let mut scratch=old.unwrap_or(Self{epoch:0,length:0,slots:vec![]});
        if scratch.epoch==u64::MAX {for slot in &mut scratch.slots {slot.epoch=0;slot.value=None;}scratch.epoch=1;}
        else {scratch.epoch+=1;}
        scratch.length=0;scratch
    }
}
fn ink_dense_index<K:'static>(key:&K)->Option<usize> {
    let any=key as &dyn std::any::Any;
    let index=if let Some(&x)=any.downcast_ref::<u32>() {x as u64}
        else if let Some(&x)=any.downcast_ref::<u64>() {x}
        else if let Some(&x)=any.downcast_ref::<i32>() {u64::try_from(x).ok()?}
        else if let Some(&x)=any.downcast_ref::<bool>() {u64::from(x)} else {return None};
    if index<INK_DENSE_LIMIT as u64 {Some(index as usize)}else{None}
}
fn ink_scalar<T:'static>()->bool {
    let id=std::any::TypeId::of::<T>();[std::any::TypeId::of::<u32>(),std::any::TypeId::of::<u64>(),std::any::TypeId::of::<i32>(),std::any::TypeId::of::<bool>()].contains(&id)
}
#[derive(Clone, Debug)]
enum InkMapStorage<K:Ord+'static,V:'static> { Sparse(std::collections::BTreeMap<K,V>), Dense(InkDense<K,V>), Shared(std::rc::Rc<std::cell::RefCell<OwnedMap<K,V>>>) }
#[derive(Clone, Debug)]
pub struct OwnedMap<K:Ord+'static,V:'static>(InkMapStorage<K,V>);
impl<K:Ord+Clone+'static,V:Clone+'static> OwnedMap<K,V> {
    pub fn new()->Self {
        if ink_scalar::<K>()&&ink_scalar::<V>() {Self(InkMapStorage::Dense(InkDense::fresh()))}
        else {Self::new_sparse()}
    }
    pub fn shared()->Self {Self(InkMapStorage::Shared(std::rc::Rc::new(std::cell::RefCell::new(Self::new()))))}
    pub fn new_sparse()->Self {Self(InkMapStorage::Sparse(std::collections::BTreeMap::new()))}
    fn entries(&self)->Box<dyn Iterator<Item=(K,V)>+'_> {
        match &self.0 {
            InkMapStorage::Shared(map)=>Box::new(map.borrow().entries().collect::<Vec<_>>().into_iter()),
            InkMapStorage::Sparse(map)=>Box::new(map.iter().map(|(k,v)|(k.clone(),v.clone()))),
            InkMapStorage::Dense(s)=>Box::new(s.slots.iter().filter(move|x|x.epoch==s.epoch).filter_map(|x|x.value.as_ref().map(|(k,v)|(k.clone(),v.clone())))),
        }
    }
    pub fn len(&self)->u32 {match &self.0 {InkMapStorage::Sparse(map)=>map.len(),InkMapStorage::Dense(s)=>s.length,InkMapStorage::Shared(map)=>return map.borrow().len()}.try_into().expect("map exceeds u32")}
    pub fn get(&self,key:&K)->Option<V> {
        match &self.0 {
            InkMapStorage::Shared(map)=>map.borrow().get(key),
            InkMapStorage::Sparse(map)=>map.get(key).cloned(),
            InkMapStorage::Dense(s)=>ink_dense_index(key).and_then(|i|s.slots.get(i)).filter(|x|x.epoch==s.epoch).and_then(|x|x.value.as_ref().map(|(_,v)|v.clone())),
        }
    }
    pub fn contains(&self,key:&K)->bool {self.get(key).is_some()}
    pub fn set(mut self,key:K,value:V)->Self {
        if let InkMapStorage::Shared(data)=&self.0 {let mut map=data.borrow_mut();let old=std::mem::replace(&mut *map,Self::new_sparse());*map=old.set(key,value);drop(map);return self;}
        if let InkMapStorage::Dense(s)=&mut self.0 {
            if let Some(index)=ink_dense_index(&key).filter(|&i|i<=s.slots.len().saturating_mul(8)+64) {
                s.slots.resize_with(s.slots.len().max(index+1),||InkSlot{epoch:0,value:None});
                let slot=&mut s.slots[index];if slot.epoch!=s.epoch||slot.value.is_none(){s.length+=1;}
                slot.value=Some((key,value));slot.epoch=s.epoch;return self;
            }
            let mut ordered=std::collections::BTreeMap::new();
            for slot in &mut s.slots {if slot.epoch==s.epoch {if let Some((k,v))=slot.value.take(){ordered.insert(k,v);}}}
            ordered.insert(key,value);
            let old=std::mem::replace(&mut self.0,InkMapStorage::Sparse(ordered));
            if let InkMapStorage::Dense(s)=old {ink_recycle(s);}
        } else if let InkMapStorage::Sparse(map)=&mut self.0 {map.insert(key,value);}
        self
    }
    pub fn remove(mut self,key:&K)->Self {
        if let InkMapStorage::Shared(data)=&self.0 {let mut map=data.borrow_mut();let old=std::mem::replace(&mut *map,Self::new_sparse());*map=old.remove(key);drop(map);return self;}
        match &mut self.0 {
            InkMapStorage::Shared(_)=>unreachable!("shared handled above"),
            InkMapStorage::Sparse(map)=>{map.remove(key);},
            InkMapStorage::Dense(s)=>{if let Some(slot)=ink_dense_index(key).and_then(|i|s.slots.get_mut(i)){if slot.epoch==s.epoch&&slot.value.take().is_some(){s.length-=1;slot.epoch=0;}}},
        }self
    }
    pub fn keys(&self)->Vec<K>{self.entries().map(|(k,_)|k.clone()).collect()}
    pub fn values(&self)->Vec<V>{self.entries().map(|(_,v)|v.clone()).collect()}
}
fn ink_recycle<K:'static,V:'static>(scratch:InkDense<K,V>) {
    if scratch.slots.capacity()<=INK_SCRATCH_RETAIN {INK_MAP_POOL.with(|pool|{let mut pool=pool.borrow_mut();if pool.len()<INK_SCRATCH_POOL_LIMIT {pool.push(Box::new(scratch));}});}
}
impl<K:Ord+'static,V:'static> Drop for OwnedMap<K,V> {
    fn drop(&mut self) {if matches!(self.0,InkMapStorage::Dense(_)){if let InkMapStorage::Dense(s)=std::mem::replace(&mut self.0,InkMapStorage::Sparse(std::collections::BTreeMap::new())){ink_recycle(s);}}}
}
impl<K:Ord+Clone+'static,V:Clone+PartialEq+'static> PartialEq for OwnedMap<K,V>{fn eq(&self,other:&Self)->bool{self.entries().eq(other.entries())}}
impl<K:Ord+Clone+'static,V:Clone+Eq+'static> Eq for OwnedMap<K,V>{}
impl<K:Ord+Clone+'static,V:Clone+Ord+'static> Ord for OwnedMap<K,V>{fn cmp(&self,other:&Self)->std::cmp::Ordering{self.entries().cmp(other.entries())}}
impl<K:Ord+Clone+'static,V:Clone+PartialOrd+'static> PartialOrd for OwnedMap<K,V>{fn partial_cmp(&self,other:&Self)->Option<std::cmp::Ordering>{self.entries().partial_cmp(other.entries())}}

// Bounded fork/join execution. Each worker owns a disjoint mutable slice;
// joining retains source order. Nested parallel requests execute sequentially.
std::thread_local! {static INK_PARALLEL_DEPTH:std::cell::Cell<u32>=const{std::cell::Cell::new(0)};}
struct InkParallelGuard(u32);
impl InkParallelGuard {
    fn enter() -> Self {
        Self(INK_PARALLEL_DEPTH.with(|d| {
            let old = d.get();
            d.set(old + 1);
            old
        }))
    }
}
impl Drop for InkParallelGuard {
    fn drop(&mut self) {
        INK_PARALLEL_DEPTH.with(|d| d.set(self.0));
    }
}
fn ink_parallel_workers(len: usize, grain: u32) -> usize {
    if cfg!(target_arch = "wasm32") {
        return 1;
    }
    if INK_PARALLEL_DEPTH.with(|d| d.get() > 0) {
        return 1;
    }
    let available = std::thread::available_parallelism()
        .map(|n| n.get())
        .unwrap_or(1);
    let requested = std::env::var("INK_THREADS")
        .ok()
        .and_then(|s| s.parse::<usize>().ok())
        .unwrap_or(available)
        .clamp(1, 32);
    requested.min(len / (grain.max(1) as usize)).max(1)
}
pub fn ink_parallel_map<T: Clone + Sync, U: Send, F: Fn(u32, T) -> U + Sync>(
    xs: Vec<T>,
    grain: u32,
    f: F,
) -> Vec<U> {
    let workers = ink_parallel_workers(xs.len(), grain);
    let _guard = InkParallelGuard::enter();
    if workers == 1 {
        return xs
            .into_iter()
            .enumerate()
            .map(|(i, x)| f(i as u32, x))
            .collect();
    }
    let chunk = (xs.len() + workers - 1) / workers;
    ink_parallel_start_receipt();
    std::thread::scope(|scope| {
        let handles = xs
            .chunks(chunk)
            .enumerate()
            .map(|(part, slice)| {
                let f = &f;
                scope.spawn(move || {
                    let _guard = InkParallelGuard::enter();
                    ink_parallel_record_thread();
                    slice
                        .iter()
                        .cloned()
                        .enumerate()
                        .map(|(i, x)| f((part * chunk + i) as u32, x))
                        .collect::<Vec<U>>()
                })
            })
            .collect::<Vec<_>>();
        let mut output = Vec::with_capacity(xs.len());
        for handle in handles {
            output.extend(handle.join().expect("parallel worker failed"));
        }
        output
    })
}
pub fn ink_parallel_update<T: Clone + Send, F: Fn(u32, T) -> T + Sync>(
    mut xs: Vec<T>,
    grain: u32,
    f: F,
) -> Vec<T> {
    let workers = ink_parallel_workers(xs.len(), grain);
    let _guard = InkParallelGuard::enter();
    if workers == 1 {
        for (i, x) in xs.iter_mut().enumerate() {
            *x = f(i as u32, x.clone());
        }
        return xs;
    }
    let chunk = (xs.len() + workers - 1) / workers;
    ink_parallel_start_receipt();
    std::thread::scope(|scope| {
        for (part, slice) in xs.chunks_mut(chunk).enumerate() {
            let f = &f;
            scope.spawn(move || {
                let _guard = InkParallelGuard::enter();
                ink_parallel_record_thread();
                for (i, x) in slice.iter_mut().enumerate() {
                    *x = f((part * chunk + i) as u32, x.clone());
                }
            });
        }
    });
    xs
}

pub fn ink_parallel_nested()->bool{INK_PARALLEL_DEPTH.with(|d|d.get()>0)}
pub fn with_parallel_worker<T>(f:impl FnOnce()->T)->T{let _guard=InkParallelGuard::enter();f()}

// Diagnostic receipt counts actual entered OS threads, never planned jobs.
static INK_PARALLEL_RECEIPT: std::sync::LazyLock<std::sync::Mutex<(u64,std::collections::BTreeSet<String>,std::collections::BTreeSet<String>)>> = std::sync::LazyLock::new(||std::sync::Mutex::new((0,std::collections::BTreeSet::new(),std::collections::BTreeSet::new())));
fn ink_parallel_start_receipt(){INK_PARALLEL_RECEIPT.lock().expect("parallel receipt lock").2.clear();}
fn ink_parallel_record_thread(){let mut r=INK_PARALLEL_RECEIPT.lock().expect("parallel receipt lock");r.0+=1;let id=format!("{:?}",std::thread::current().id());r.1.insert(id.clone());r.2.insert(id);}
pub fn ink_parallel_statistics()->(u64,Vec<String>,Vec<String>){let r=INK_PARALLEL_RECEIPT.lock().expect("parallel receipt lock");(r.0,r.1.iter().cloned().collect(),r.2.iter().cloned().collect())}

#[inline(never)]
pub fn ink_f32(value:f32)->f32{if value.is_nan(){f32::from_bits(0x7fc00000)}else{value}}

// An explicit private-vector representation of the same affine Buffer value.
// Splitting copies into independent owners; allocation identity is unobservable.
// Selected by a checked physical plan, never by a workload matcher.
#[derive(Clone,Debug,PartialEq,Eq,PartialOrd,Ord)]
pub struct DirectBuffer<T>(Vec<T>);
impl<T:Clone> DirectBuffer<T> {
    pub fn new(xs:Vec<T>)->Self {Self(xs)}
    pub fn shared(xs:Vec<T>)->Self {Self(xs)}
    pub fn len(&self)->u32 {self.0.len().try_into().expect("buffer exceeds u32")}
    pub fn get(&self,i:u32)->Option<T>{self.0.get(i as usize).cloned()}
    pub fn with_item<R>(&self,i:u32,f:impl FnOnce(Option<&T>)->R)->R{f(self.0.get(i as usize))}
    pub unsafe fn get_unchecked(&self,i:u32)->T{self.0.get_unchecked(i as usize).clone()}
    pub fn set(mut self,i:u32,v:T)->Self{if let Some(x)=self.0.get_mut(i as usize){*x=v;}self}
    pub fn swap(mut self,a:u32,b:u32)->Self{if(a as usize)<self.0.len()&&(b as usize)<self.0.len(){self.0.swap(a as usize,b as usize);}self}
    pub fn fill_range(mut self,start:u32,count:u32,v:T)->Self{let a=(start as usize).min(self.0.len());let n=(count as usize).min(self.0.len()-a);self.0[a..a+n].fill(v);self}
    pub fn copy_within(mut self,source:u32,destination:u32,count:u32)->Self{
        let a=(source as usize).min(self.0.len());let b=(destination as usize).min(self.0.len());let n=(count as usize).min(self.0.len()-a).min(self.0.len()-b);
        if b>a {for i in (0..n).rev(){self.0[b+i]=self.0[a+i].clone();}}else if a!=b {for i in 0..n{self.0[b+i]=self.0[a+i].clone();}}self
    }
    pub fn map_inplace(mut self,mut f:impl FnMut(T)->T)->Self{for v in &mut self.0{*v=f(v.clone());}self}
    pub fn map_indexed_inplace(mut self,mut f:impl FnMut(u32,T)->T)->Self{for(i,v)in self.0.iter_mut().enumerate(){*v=f(i as u32,v.clone());}self}
    pub fn scan_inplace(mut self,initial:T,mut f:impl FnMut(T,T)->T)->Self{let mut acc=initial;for v in &mut self.0{acc=f(acc,v.clone());*v=acc.clone();}self}
    pub fn filter_inplace(mut self,mut f:impl FnMut(T)->bool)->Self{self.0.retain(|v|f(v.clone()));self}
    pub fn truncate(mut self,n:u32)->Self{self.0.truncate(n as usize);self}
    pub fn pop(mut self)->Self{self.0.pop();self}
    pub fn push(mut self,v:T)->Self{assert!(self.0.len()<u32::MAX as usize,"buffer length exhausted");self.0.push(v);self}
    pub fn split(mut self,at:u32)->(Self,Self){let right=self.0.split_off((at as usize).min(self.0.len()));(self,Self(right))}
    pub fn append(mut self,mut other:Self)->Self{self.0.append(&mut other.0);self}
    pub fn freeze(self)->Vec<T>{self.0}
    pub fn freeze_handle(self)->Vec<T>{self.0}
}

// Lossless scalar columns. Values outside the preferred lane promote storage;
// promotion checks value validity, never runtime profitability.
#[derive(Clone,Debug)]
enum InkWordLanes { U8(Vec<u8>), U16(Vec<u16>), U32(Vec<u32>), U64(Vec<u64>) }
#[derive(Clone,Debug)]
pub struct PackedWords<const BITS:u8,const BASE:u8=64>{data:InkWordLanes}
impl<const BITS:u8,const BASE:u8> Default for PackedWords<BITS,BASE>{fn default()->Self{Self{data:match BITS{8=>InkWordLanes::U8(vec![]),16=>InkWordLanes::U16(vec![]),32=>InkWordLanes::U32(vec![]),64=>InkWordLanes::U64(vec![]),_=>panic!("invalid packed word width")}}}}
impl<const BITS:u8,const BASE:u8> PackedWords<BITS,BASE>{
 pub fn with_capacity(n:usize)->Self{Self{data:match BITS{8=>InkWordLanes::U8(Vec::with_capacity(n)),16=>InkWordLanes::U16(Vec::with_capacity(n)),32=>InkWordLanes::U32(Vec::with_capacity(n)),64=>InkWordLanes::U64(Vec::with_capacity(n)),_=>panic!("invalid packed word width")}}}
 pub fn prepare_push(&mut self,x:u64){if !self.fits(x){self.promote(x);}self.reserve(1);}
 pub fn reserve(&mut self,n:usize){match &mut self.data{InkWordLanes::U8(v)=>v.reserve(n),InkWordLanes::U16(v)=>v.reserve(n),InkWordLanes::U32(v)=>v.reserve(n),InkWordLanes::U64(v)=>v.reserve(n)}}
 pub fn prepare_append(&mut self,other:&Self){if other.len()==0{return;}let bound=match other.data{InkWordLanes::U8(_)=>u8::MAX as u64,InkWordLanes::U16(_)=>u16::MAX as u64,InkWordLanes::U32(_)=>u32::MAX as u64,InkWordLanes::U64(_)=>u64::MAX};if !self.fits(bound){self.promote(bound);}self.reserve(other.len());}
 pub fn len(&self)->usize{match &self.data{InkWordLanes::U8(v)=>v.len(),InkWordLanes::U16(v)=>v.len(),InkWordLanes::U32(v)=>v.len(),InkWordLanes::U64(v)=>v.len()}}
 pub fn storage_identity(&self)->usize{match &self.data{InkWordLanes::U8(v)=>v.as_ptr()as usize,InkWordLanes::U16(v)=>v.as_ptr()as usize,InkWordLanes::U32(v)=>v.as_ptr()as usize,InkWordLanes::U64(v)=>v.as_ptr()as usize}}
 pub fn payload_bytes(&self)->usize{self.len()*match self.data{InkWordLanes::U8(_)=>1,InkWordLanes::U16(_)=>2,InkWordLanes::U32(_)=>4,InkWordLanes::U64(_)=>8}}
 pub fn get(&self,i:usize)->u64{assert!(i<self.len());unsafe{self.get_unchecked(i)}}
 pub unsafe fn get_unchecked(&self,i:usize)->u64{match &self.data{InkWordLanes::U8(v)=>*v.get_unchecked(i)as u64,InkWordLanes::U16(v)=>*v.get_unchecked(i)as u64,InkWordLanes::U32(v)=>*v.get_unchecked(i)as u64,InkWordLanes::U64(v)=>*v.get_unchecked(i)}}
 fn fits(&self,x:u64)->bool{match self.data{InkWordLanes::U8(_)=>x<=u8::MAX as u64,InkWordLanes::U16(_)=>x<=u16::MAX as u64,InkWordLanes::U32(_)=>x<=u32::MAX as u64,InkWordLanes::U64(_)=>true}}
 fn promote(&mut self,value:u64){let xs=(0..self.len()).map(|i|self.get(i)).collect::<Vec<_>>();self.data=if BASE<=32&&value<=u32::MAX as u64{InkWordLanes::U32(xs.into_iter().map(|v|v as u32).collect())}else{InkWordLanes::U64(xs)};}
 pub fn push(&mut self,x:u64){if !self.fits(x){self.promote(x);}match &mut self.data{InkWordLanes::U8(v)=>v.push(x as u8),InkWordLanes::U16(v)=>v.push(x as u16),InkWordLanes::U32(v)=>v.push(x as u32),InkWordLanes::U64(v)=>v.push(x)}}
 pub fn set(&mut self,i:usize,x:u64){assert!(i<self.len());if !self.fits(x){self.promote(x);}match &mut self.data{InkWordLanes::U8(v)=>v[i]=x as u8,InkWordLanes::U16(v)=>v[i]=x as u16,InkWordLanes::U32(v)=>v[i]=x as u32,InkWordLanes::U64(v)=>v[i]=x}}
 pub fn truncate(&mut self,n:usize){match &mut self.data{InkWordLanes::U8(v)=>v.truncate(n),InkWordLanes::U16(v)=>v.truncate(n),InkWordLanes::U32(v)=>v.truncate(n),InkWordLanes::U64(v)=>v.truncate(n)}}
}
#[derive(Clone,Debug,Default)]
pub struct PackedBits{len:usize,words:Vec<u64>}
impl PackedBits{
 pub fn with_capacity(n:usize)->Self{Self{len:0,words:Vec::with_capacity(n.div_ceil(64))}}
 pub fn reserve(&mut self,n:usize){let total=self.len.checked_add(n).expect("bit length overflow").div_ceil(64);self.words.reserve(total-self.words.len());}
 pub fn prepare_push(&mut self,_:bool){self.reserve(1);}
 pub fn prepare_append(&mut self,other:&Self){self.reserve(other.len());}
 pub fn len(&self)->usize{self.len}
 pub fn payload_bytes(&self)->usize{self.words.len()*8}
 pub fn storage_identity(&self)->usize{self.words.as_ptr()as usize}
 pub fn get(&self,i:usize)->bool{assert!(i<self.len);unsafe{self.get_unchecked(i)}}
 pub unsafe fn get_unchecked(&self,i:usize)->bool{(*self.words.get_unchecked(i/64)&(1u64<<(i%64)))!=0}
 pub fn push(&mut self,x:bool){if self.len%64==0{self.words.push(0);}let i=self.len;self.len+=1;self.set(i,x);}
 pub fn set(&mut self,i:usize,x:bool){assert!(i<self.len);let mask=1u64<<(i%64);let w=&mut self.words[i/64];*w=(*w&!mask)|if x{mask}else{0};}
 pub fn truncate(&mut self,n:usize){self.len=self.len.min(n);self.words.truncate(self.len.div_ceil(64));if self.len%64!=0{if let Some(last)=self.words.last_mut(){*last&=(1u64<<(self.len%64))-1;}}}
}

// Fixed scalar/text execution support. Float arithmetic canonicalises NaNs.
pub fn ink_sqrt(x:f32)->f32{ink_f32(x.sqrt())}
pub fn ink_f32_div(x:f32,y:f32)->f32{ink_f32(x/y)}
pub fn ink_floor(x:f32)->f32{ink_f32(x.floor())}
pub fn ink_ceil(x:f32)->f32{ink_f32(x.ceil())}
pub fn ink_trunc(x:f32)->f32{ink_f32(x.trunc())}
pub fn ink_round_ties_even(x:f32)->f32{ink_f32(x.round_ties_even())}
pub fn ink_u32_from_f32(x:f32)->Option<u32>{let x=x.trunc();(x.is_finite()&&x>=0.0&&x<4294967296.0).then(||x as u32)}
pub fn ink_u64_from_f32(x:f32)->Option<u64>{let x=x.trunc();(x.is_finite()&&x>=0.0&&x<18446744073709551616.0).then(||x as u64)}
pub fn ink_i32_from_f32(x:f32)->Option<i32>{let x=x.trunc();(x.is_finite()&&x>=-2147483648.0&&x<2147483648.0).then(||x as i32)}
pub fn ink_string_byte_len(x:&str)->u32{x.len().try_into().expect("String exceeds U32 byte length")}
pub fn ink_string_byte_at(x:&str,i:u32)->Option<u32>{x.as_bytes().get(i as usize).map(|b|*b as u32)}
pub fn ink_string_slice(x:&str,a:u32,b:u32)->Option<String>{x.get(a as usize..b as usize).map(str::to_owned)}
pub fn ink_string_concat(a:&str,b:&str)->String{assert!(a.len().checked_add(b.len()).is_some_and(|n|n<=u32::MAX as usize),"String exceeds U32 byte length");format!("{a}{b}")}
pub fn ink_string_find(x:&str,needle:&str,from:u32)->Option<u32>{x.get(from as usize..).and_then(|s|s.find(needle)).map(|i|from+i as u32)}

pub fn ink_int_from_f32(x:f32)->Option<num_bigint::BigInt>{
 if !x.is_finite(){return None;}let b=x.to_bits();let e=((b>>23)&255) as i32-127;
 if e<0{return Some(0.into());}let m=(b&0x7fffff)|0x800000;let n=num_bigint::BigInt::from(m);
 let v=if e>=23{n<<((e-23) as usize)}else{n>>((23-e) as usize)};
 Some(if b&0x80000000!=0{-v}else{v})
}
pub fn ink_f32_from_int(x:&num_bigint::BigInt)->f32{
 use num_bigint::{BigUint,Sign};let a=x.magnitude();let bits=a.bits();let sign=if x.sign()==Sign::Minus{0x80000000}else{0};
 if bits==0{return 0.0;}if bits<=24{let n=a.to_u32_digits()[0] as f32;return if sign==0{n}else{-n};}
 if bits>128{return f32::from_bits(sign|0x7f800000);}
 let shift=(bits-24) as usize;let q=a>>shift;let mut m=q.to_u32_digits()[0];let rem=a-(&q<<shift);let half=BigUint::from(1u32)<<(shift-1);
 if rem>half||(rem==half&&m&1!=0){m+=1;}let mut e=bits as u32-1+127;
 if m==0x1000000{m>>=1;e+=1;}if e>=255{return f32::from_bits(sign|0x7f800000);}
 f32::from_bits(sign|(e<<23)|(m&0x7fffff))
}

}
use temporary::{OwnedBuffer,OwnedMap};
/// Literal tags for the handle-based value ABI. Shared by emitters and support.
#[repr(u32)]
#[derive(Clone,Copy,Debug,PartialEq,Eq)]
pub enum InkValueKind {Unit=0,Bool=1,U32=2,U64=3,I32=4,F32=5,Int=6,String=7,Enum=8}
impl InkValueKind {
    pub fn from_raw(n:u32)->Option<Self>{Some(match n{0=>Self::Unit,1=>Self::Bool,2=>Self::U32,3=>Self::U64,4=>Self::I32,5=>Self::F32,6=>Self::Int,7=>Self::String,8=>Self::Enum,_=>return None})}
}
// Primitive value/storage runtime for literal emitted C. No parser or evaluator.
use num_bigint::BigInt;
use serde_json::{json, Value as Json};
use std::collections::BTreeMap;
use std::ffi::{c_char, CStr};
use std::borrow::Cow;
#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
enum V {
    Unit,
    Bool(bool),
    U32(u32),
    U64(u64),
    I32(i32),
    F32(u32),
    Int(BigInt),
    String(String),
    Id(String, u128),
    Record(String, BTreeMap<String, V>),
    Enum(String),
    Option(Option<Box<V>>),
    Result(bool, Box<V>),
    List(Vec<V>),
    Vector(Vec<V>),
    Buffer(OwnedBuffer<V>),
    Map(OwnedMap<V,V>),
}
impl V {
    fn weight(&self) -> usize {
        64 + match self {
            Self::Int(v) => (v.bits() as usize + 7) / 8,
            Self::String(v) | Self::Enum(v) => v.len(),
            Self::Record(_, fs) => fs.values().map(Self::weight).sum(),
            Self::List(xs) | Self::Vector(xs) => xs.iter().map(Self::weight).sum(),
            Self::Option(Some(v)) | Self::Result(_, v) => v.weight(),
            _ => 0,
        }
    }
    fn json(&self) -> Json {
        match self {
            Self::Buffer(_) | Self::Map(_) => Json::Null,
            Self::Unit => Json::Null,
            Self::Bool(v) => json!(v),
            Self::U32(v) => json!(v),
            Self::U64(v) => json!(v),
            Self::I32(v) => json!(v),
            Self::F32(b) => {
                let f = f32::from_bits(*b);
                if f.is_finite() {
                    json!(f)
                } else {
                    json!({"F32Bits":b})
                }
            }
            Self::Int(v) => json!({"Int":v.to_string()}),
            Self::String(v) | Self::Enum(v) => json!(v),
            Self::Id(_, v) => json!(format!("{v:032x}")),
            Self::Record(_, fs) => fs.iter().map(|(k, v)| (k.clone(), v.json())).collect(),
            Self::Option(Some(v)) => json!({"Some":v.json()}),
            Self::Option(None) => json!({"None":null}),
            Self::Result(true, v) => json!({"Ok":v.json()}),
            Self::Result(false, v) => json!({"Err":v.json()}),
            Self::List(xs) | Self::Vector(xs) => xs.iter().map(Self::json).collect(),
        }
    }
}
type R<T> = Result<T, String>;
// Scalar binary32 comparisons use IEEE semantics. Contained binary32 values
// remain stored bit carriers through V's structural equality and ordering.
fn compare_values(op: &str, left: &V, right: &V) -> V {
    let equal = if let (V::F32(x), V::F32(y)) = (left, right) {
        f32::from_bits(*x) == f32::from_bits(*y)
    } else {
        left == right
    };
    let order = if let (V::F32(x), V::F32(y)) = (left, right) {
        f32::from_bits(*x).partial_cmp(&f32::from_bits(*y))
    } else {
        Some(left.cmp(right))
    };
    use std::cmp::Ordering::*;
    V::Bool(match op {
        "==" => equal,
        "!=" => !equal,
        "<" => order == Some(Less),
        ">" => order == Some(Greater),
        "<=" => matches!(order, Some(Less | Equal)),
        _ => matches!(order, Some(Greater | Equal)),
    })
}
fn from_json(v: &Json, t: &Json, meta: &Json, left: &mut usize, depth: usize) -> R<V> {
    if depth > 128 || *left == 0 {
        return Err("value resource limit exceeded".into());
    }
    *left -= 1;
    if let Some(kind) = t.as_str() {
        return Ok(match kind {
            "Unit" if v.is_null() => V::Unit,
            "Bool" => V::Bool(v.as_bool().ok_or("expected Bool")?),
            "U32" => V::U32(
                v.as_u64()
                    .and_then(|n| u32::try_from(n).ok())
                    .ok_or("expected u32")?,
            ),
            "U64" => {
                let n = if let Some(n) = v.as_u64() {
                    n
                } else {
                    let s = v.as_str().ok_or("expected u64")?;
                    let n = s.parse::<u64>().map_err(|_| "expected u64")?;
                    if n.to_string() != s {
                        return Err("noncanonical u64".into());
                    }
                    n
                };
                V::U64(n)
            }
            "I32" => V::I32(
                v.as_i64()
                    .and_then(|n| i32::try_from(n).ok())
                    .ok_or("expected i32")?,
            ),
            "F32" => {
                if let Some(n) = v.as_f64() {
                    let f = n as f32;
                    if !f.is_finite() {
                        return Err("f32 overflow".into());
                    }
                    V::F32(f.to_bits())
                } else {
                    let o = v.as_object().ok_or("expected F32Bits")?;
                    if o.len() != 1 {
                        return Err("expected F32Bits".into());
                    }
                    V::F32(
                        o.get("F32Bits")
                            .and_then(Json::as_u64)
                            .and_then(|n| u32::try_from(n).ok())
                            .ok_or("invalid F32Bits")?,
                    )
                }
            }
            "Int" => {
                let text = v
                    .get("Int")
                    .and_then(Json::as_str)
                    .map(str::to_owned)
                    .unwrap_or_else(|| v.to_string());
                if text.len() > 1000000 {
                    return Err("Int input exceeds resource limit".into());
                }
                V::Int(text.parse().map_err(|_| "expected Int")?)
            }
            "String" => V::String(v.as_str().ok_or("expected String")?.into()),
            _ => return Err("unsupported primitive type".into()),
        });
    }
    let object = t.as_object().ok_or("invalid compiled type")?;
    let (kind, inner) = object.iter().next().ok_or("empty compiled type")?;
    Ok(match kind.as_str() {
        "List" => V::List(
            v.as_array()
                .ok_or("expected List")?
                .iter()
                .map(|x| from_json(x, inner, meta, left, depth + 1))
                .collect::<R<Vec<_>>>()?,
        ),
        "Vector" => {
            let xs = v.as_array().ok_or("expected vector")?;
            let parts = inner.as_array().ok_or("vector type")?;
            if xs.len() != parts[1].as_u64().ok_or("vector size")? as usize {
                return Err("vector dimension mismatch".into());
            }
            V::Vector(
                xs.iter()
                    .map(|x| from_json(x, &parts[0], meta, left, depth + 1))
                    .collect::<R<Vec<_>>>()?,
            )
        }
        "Option" => {
            let obj = v.as_object().ok_or("expected Option")?;
            if obj.len() != 1 {
                return Err("expected one tag".into());
            }
            if let Some(x) = obj.get("Some") {
                V::Option(Some(Box::new(from_json(x, inner, meta, left, depth + 1)?)))
            } else if obj.get("None") == Some(&Json::Null) {
                V::Option(None)
            } else {
                return Err("invalid Option".into());
            }
        }
        "Result" => {
            let obj = v.as_object().ok_or("expected Result")?;
            if obj.len() != 1 {
                return Err("expected one tag".into());
            }
            let ts = inner.as_array().ok_or("result type")?;
            if let Some(x) = obj.get("Ok") {
                V::Result(true, Box::new(from_json(x, &ts[0], meta, left, depth + 1)?))
            } else if let Some(x) = obj.get("Err") {
                V::Result(
                    false,
                    Box::new(from_json(x, &ts[1], meta, left, depth + 1)?),
                )
            } else {
                return Err("invalid Result".into());
            }
        }
        "Named" => {
            let name = inner.as_str().ok_or("named type")?;
            if meta["ids"]
                .as_array()
                .is_some_and(|xs| xs.iter().any(|x| x == name))
            {
                let s = v.as_str().ok_or("expected ID")?;
                if s.len() != 32 || !s.bytes().all(|b| b.is_ascii_hexdigit()) {
                    return Err("invalid ID".into());
                }
                V::Id(
                    name.into(),
                    u128::from_str_radix(s, 16).map_err(|_| "invalid ID")?,
                )
            } else if name == "ArithmeticError" {
                if v.as_str() != Some("ArithmeticError.Overflow") {
                    return Err("invalid arithmetic error".into());
                }
                V::Enum("ArithmeticError.Overflow".into())
            } else if let Some(fs) = meta["records"].get(name).and_then(Json::as_array) {
                let obj = v.as_object().ok_or("expected record")?;
                if obj.len() != fs.len() {
                    return Err("record field mismatch".into());
                }
                let mut values = BTreeMap::new();
                for f in fs {
                    let key = f[0].as_str().ok_or("field name")?;
                    values.insert(
                        key.into(),
                        from_json(
                            obj.get(key).ok_or("missing field")?,
                            &f[1],
                            meta,
                            left,
                            depth + 1,
                        )?,
                    );
                }
                V::Record(name.into(), values)
            } else {
                let s = v.as_str().ok_or("expected enum")?;
                let prefix = format!("{name}.");
                let variant = s.strip_prefix(&prefix).ok_or("enum type mismatch")?;
                if !meta["enums"][name]
                    .as_array()
                    .is_some_and(|vs| vs.iter().any(|v| v == variant))
                {
                    return Err("invalid enum variant".into());
                }
                V::Enum(s.into())
            }
        }
        _ => return Err("unsupported compiled type".into()),
    })
}
#[derive(Clone, Debug)]
enum Failure {
    Host(String),
    Abort(V),
}
pub struct InkContext {
    values: Vec<V>,
    error: Option<Failure>,
    fuel: u64,
    arena_bytes: usize,
    meta: Json,
    tables: Vec<BTreeMap<V, V>>,
    undo: BTreeMap<(usize, V), Option<V>>,
    version: u64,
    staged: Vec<(String, V)>,
    outbox: Vec<Event>,
}
#[derive(Clone, Debug)]
pub struct Event {
    pub commit: u64,
    pub position: u64,
    pub channel: String,
    value: V,
}
impl Event {
    pub fn to_json(&self) -> Json {
        json!({"commit":self.commit,"position":self.position,"channel":self.channel,"value":self.value.json()})
    }
}
impl InkContext {
    fn rollback(&mut self) {
        while let Some(((index, key), old)) = self.undo.pop_last() {
            match old {
                Some(value) => { self.tables[index].insert(key, value); }
                None => { self.tables[index].remove(&key); }
            }
        }
    }
    fn put(&mut self, v: V) -> u64 {
        // Opaque value handles carry fixed-width scalar payloads directly.
        // Heap values remain arena indices; language and snapshot types do not change.
        let immediate = match &v {
            V::Unit => Some((1u64, 0u32)),
            V::Bool(x) => Some((2, *x as u32)),
            V::U32(x) => Some((3, *x)),
            V::I32(x) => Some((4, *x as u32)),
            V::F32(x) => Some((5, *x)),
            _ => None,
        };
        if let Some((tag, bits)) = immediate {
            return (tag << 32) | u64::from(bits);
        }
        let n = v.weight();
        if n > 64 * 1024 * 1024 - self.arena_bytes {
            return self.fail("Ink value arena limit exceeded".into());
        }
        self.arena_bytes += n;
        self.values.push(v);
        self.values.len() as u64
    }
    fn value(&self, h: u64) -> R<V> {
        let bits = h as u32;
        match h >> 32 {
            1 if bits == 0 => Ok(V::Unit),
            2 if bits <= 1 => Ok(V::Bool(bits != 0)),
            3 => Ok(V::U32(bits)),
            4 => Ok(V::I32(bits as i32)),
            5 => Ok(V::F32(bits)),
            0 => self
                .values
                .get(
                    usize::try_from(h.checked_sub(1).ok_or("invalid value handle")?)
                        .map_err(|_| "invalid value handle")?,
                )
                .cloned()
                .ok_or("invalid value handle".into()),
            _ => Err("invalid value handle".into()),
        }
    }
    // Heap handles borrow their existing value. Immediate scalar handles need
    // only a stack value, never a heap allocation or a composite clone.
    fn borrowed_value(&self, h: u64) -> R<Cow<'_, V>> {
        if h >> 32 == 0 {
            let index = usize::try_from(h.checked_sub(1).ok_or("invalid value handle")?)
                .map_err(|_| "invalid value handle")?;
            self.values.get(index).map(Cow::Borrowed).ok_or_else(|| "invalid value handle".into())
        } else {
            self.value(h).map(Cow::Owned)
        }
    }
    // Only fixed read-only primitive semantics live here. Source algorithms,
    // hoisting and other equality-law choices remain in knowledge.
    fn borrowed_primitive(&self, op: &str, handles: &[u64]) -> R<Option<V>> {
        if handles.len() == 1 {
            if op == "list_length" {
                let value = self.borrowed_value(handles[0])?;
                let V::List(xs) = value.as_ref() else { return Err("list length".into()); };
                return Ok(Some(V::U32(xs.len().try_into().map_err(|_| "list exceeds u32")?)));
            }
            if let Some(field) = op.strip_prefix("field:") {
                let value = self.borrowed_value(handles[0])?;
                let selected: R<V> = match value.as_ref() {
                    V::Record(_, fields) => fields.get(field).cloned().ok_or_else(|| "unknown field".into()),
                    V::Vector(xs) => ["x", "y", "z", "w"].iter().position(|f| *f == field)
                        .and_then(|i| xs.get(i)).cloned().ok_or_else(|| "unknown component".into()),
                    _ => Err("field requires record/vector".into()),
                };
                return Ok(Some(selected?));
            }
            if let Some(tag) = op.strip_prefix("tag:") {
                let value = self.borrowed_value(handles[0])?;
                return Ok(Some(V::Bool(matches!((value.as_ref(), tag),
                    (V::Option(Some(_)), "Some") | (V::Result(true, _), "Ok")
                    | (V::Result(false, _), "Err")))));
            }
        }
        if handles.len() == 2 && matches!(op, "==" | "!=" | "<" | ">" | "<=" | ">=") {
            let left = self.borrowed_value(handles[0])?;
            let right = self.borrowed_value(handles[1])?;
            return Ok(Some(compare_values(op, left.as_ref(), right.as_ref())));
        }
        Ok(None)
    }
    fn fail(&mut self, e: String) -> u64 {
        if self.error.is_none() {
            self.error = Some(Failure::Host(e))
        }
        0
    }
    fn result(&mut self, r: R<V>) -> u64 {
        match r {
            Ok(v) => self.put(v),
            Err(e) => self.fail(e),
        }
    }
    fn tick(&mut self) -> bool {
        if self.error.is_some() {
            return false;
        }
        if self.fuel == 0 {
            self.fail("Ink execution budget exhausted".into());
            false
        } else {
            self.fuel -= 1;
            true
        }
    }
    fn primitive(&mut self, op: &str, a: &mut [V]) -> R<V> {
        if op=="f32_from_int" {let V::Int(x)=&a[0]else{return Err("expected Int".into())};return Ok(V::F32(temporary::ink_f32_from_int(x).to_bits()));}
        if op=="int_from_f32" {let V::F32(x)=a[0]else{return Err("expected F32".into())};return Ok(V::Option(temporary::ink_int_from_f32(f32::from_bits(x)).map(|x|Box::new(V::Int(x)))));}
        if ["sqrt","f32_div","floor","ceil","trunc","round_ties_even","is_nan","is_finite","f32_bits","u32_from_f32","u64_from_f32","i32_from_f32"].contains(&op) {
            let V::F32(bits)=a[0] else{return Err("expected F32".into())};let x=f32::from_bits(bits);
            return Ok(match op {
                "is_nan"=>V::Bool(x.is_nan()),"is_finite"=>V::Bool(x.is_finite()),"f32_bits"=>V::U32(bits),
                "u32_from_f32"=>V::Option(temporary::ink_u32_from_f32(x).map(|x|Box::new(V::U32(x)))),
                "u64_from_f32"=>V::Option(temporary::ink_u64_from_f32(x).map(|x|Box::new(V::U64(x)))),
                "i32_from_f32"=>V::Option(temporary::ink_i32_from_f32(x).map(|x|Box::new(V::I32(x)))),
                _=>{let r=match op {
                    "sqrt"=>temporary::ink_sqrt(x),"floor"=>temporary::ink_floor(x),"ceil"=>temporary::ink_ceil(x),"trunc"=>temporary::ink_trunc(x),"round_ties_even"=>temporary::ink_round_ties_even(x),
                    "f32_div"=>{let V::F32(y)=a[1]else{return Err("expected F32 divisor".into())};temporary::ink_f32_div(x,f32::from_bits(y))},_=>unreachable!()};V::F32(r.to_bits())}
            });
        }
        if ["f32_from_u32","f32_from_u64","f32_from_i32","f32_from_bits"].contains(&op){return Ok(V::F32(match (&a[0],op){(V::U32(x),"f32_from_bits")=>*x,(V::U32(x),_)=> (*x as f32).to_bits(),(V::U64(x),_)=> (*x as f32).to_bits(),(V::I32(x),_)=> (*x as f32).to_bits(),_=>return Err("float conversion type".into())}));}
        if ["popcount","leading_zeros","trailing_zeros"].contains(&op){
            macro_rules! count {($x:expr)=>{match op{"popcount"=>$x.count_ones(),"leading_zeros"=>$x.leading_zeros(),_=>$x.trailing_zeros()}}}
            return Ok(V::U32(match &a[0]{V::U32(x)=>count!(*x),V::U64(x)=>count!(*x),V::I32(x)=>count!(*x),_=>return Err("expected word".into())}));
        }
        if op.starts_with("string_"){
            let V::String(x)=&a[0]else{return Err("expected String".into())};
            let u=|i|if let V::U32(x)=a[i]{Ok(x)}else{Err("expected U32")};
            let option=|x:Option<V>|V::Option(x.map(Box::new));
            return Ok(match op{
                "string_byte_len"=>V::U32(temporary::ink_string_byte_len(x)),
                "string_byte_at"=>option(temporary::ink_string_byte_at(x,u(1)?).map(V::U32)),
                "string_slice"=>option(temporary::ink_string_slice(x,u(1)?,u(2)?).map(V::String)),
                "string_concat"=>{let V::String(y)=&a[1]else{return Err("expected String".into())};V::String(temporary::ink_string_concat(x,y))},
                "string_find"=>{let V::String(y)=&a[1]else{return Err("expected String".into())};option(temporary::ink_string_find(x,y,u(2)?).map(V::U32))},
                _=>return Err("unknown string primitive".into())
            });
        }
        if ["word_not","word_and","word_or","word_xor","wrapping_shl","wrapping_shr","rotate_left","rotate_right"].contains(&op) {
            macro_rules! apply {($x:expr,$variant:ident)=>{{
                let x=*$x;
                let r=if op=="word_not" {!x} else if ["wrapping_shl","wrapping_shr","rotate_left","rotate_right"].contains(&op) {
                    let V::U32(k)=a[1] else{return Err("word shift count".into())};
                    match op {"wrapping_shl"=>x.wrapping_shl(k),"wrapping_shr"=>x.wrapping_shr(k),"rotate_left"=>x.rotate_left(k),_=>x.rotate_right(k)}
                } else {let V::$variant(y)=a[1] else{return Err("word operand type".into())};match op {"word_and"=>x&y,"word_or"=>x|y,_=>x^y}};
                V::$variant(r)
            }};}
            return Ok(match &a[0] {V::U32(x)=>apply!(x,U32),V::U64(x)=>apply!(x,U64),V::I32(x)=>apply!(x,I32),_=>return Err("word type".into())});
        }
        if op=="list_length" {let V::List(xs)=&a[0] else{return Err("list length".into())};return Ok(V::U32(xs.len().try_into().map_err(|_|"list exceeds u32")?));}
        if op=="buffer_empty" {return Ok(V::Buffer(OwnedBuffer::shared(vec![])));}
        if op=="map_empty" {return Ok(V::Map(OwnedMap::shared()));}
        if op=="buffer_new" {let V::List(xs)=std::mem::replace(&mut a[0],V::Unit) else{return Err("buffer list".into())};return Ok(V::Buffer(OwnedBuffer::shared(xs)));}
        if op=="buffer_fill" {
            let V::U32(n)=a[0] else{return Err("buffer length".into())};if n>1000000{return Err("temporary allocation limit exceeded".into())};
            let weight=(n as usize).checked_mul(a[1].weight()).ok_or("temporary allocation limit exceeded")?;
            if weight>64*1024*1024-self.arena_bytes{return Err("temporary allocation limit exceeded".into())};self.arena_bytes+=weight;
            return Ok(V::Buffer(OwnedBuffer::shared(vec![a[1].clone();n as usize])));
        }
        if op=="buffer_split" {
            let V::Buffer(b)=a[0].clone() else{return Err("buffer receiver".into())};
            let V::U32(at)=a[1] else{return Err("buffer index".into())};
            let (l,r)=b.split(at);return Ok(V::List(vec![V::Buffer(l),V::Buffer(r)]));
        }
        if op=="buffer_append" {
            let (V::Buffer(left),V::Buffer(right))=(a[0].clone(),a[1].clone()) else{return Err("buffer append".into())};
            if (left.len() as u64)+(right.len() as u64)>1000000{return Err("temporary allocation limit exceeded".into())};
            return Ok(V::Buffer(left.append(right)));
        }
        if op=="list_drop"||op=="list_take" {
            let V::List(mut xs)=std::mem::replace(&mut a[0],V::Unit) else{return Err("list slice".into())};
            let V::U32(k)=a[1] else{return Err("list slice count".into())};let k=(k as usize).min(xs.len());
            if op=="list_drop"{xs.drain(..k);}else{xs.truncate(k);}
            return Ok(V::List(xs));
        }
        if let Some(method)=op.strip_prefix("buffer_") {
            let V::Buffer(b)=a[0].clone() else{return Err("buffer receiver".into())};
            let index=|v:&V|->R<u32>{if let V::U32(x)=v{Ok(*x)}else{Err("buffer index".into())}};
            return Ok(match method {
                "len"=>V::U32(b.len()),"freeze"=>V::List(b.freeze_handle()),"pop"=>V::Buffer(b.pop()),
                "contains"=>V::Bool(index(&a[1])?<b.len()),"get"=>b.get(index(&a[1])?).ok_or("buffer index outside bounds")?,
                "set"=>V::Buffer(b.set(index(&a[1])?,a[2].clone())),"swap"=>V::Buffer(b.swap(index(&a[1])?,index(&a[2])?)),
                "fill_range"=>{let start=index(&a[1])?;let count=index(&a[2])?.min(b.len().saturating_sub(start));let cost=(count as u64).saturating_mul(1+a[3].weight() as u64);if cost>self.fuel{return Err("Ink execution budget exhausted".into())};self.fuel-=cost;V::Buffer(b.fill_range(start,count,a[3].clone()))},
                "copy_within"=>{let source=index(&a[1])?;let destination=index(&a[2])?;let count=index(&a[3])?.min(b.len().saturating_sub(source)).min(b.len().saturating_sub(destination));let mut cost=0u64;for i in 0..count{cost=cost.saturating_add(1+b.with_item(source+i,|v|v.unwrap().weight()) as u64);}if cost>self.fuel{return Err("Ink execution budget exhausted".into())};self.fuel-=cost;V::Buffer(b.copy_within(source,destination,count))},
                "push"=>{if b.len()>=1000000{return Err("temporary allocation limit exceeded".into())};let weight=a[1].weight();if weight>64*1024*1024-self.arena_bytes{return Err("temporary allocation limit exceeded".into())};self.arena_bytes+=weight;V::Buffer(b.push(a[1].clone()))},
                "truncate"=>V::Buffer(b.truncate(index(&a[1])?)),_=>return Err("buffer method".into())
            });
        }
        if let Some(method)=op.strip_prefix("map_") {
            let V::Map(m)=a[0].clone() else{return Err("map receiver".into())};
            return Ok(match method {
                "len"=>V::U32(m.len()),"keys"=>V::List(m.keys()),"values"=>V::List(m.values()),
                "contains"=>V::Bool(m.contains(&a[1])),"get"=>m.get(&a[1]).ok_or("missing map key")?,
                "set"=>{let weight=a[1].weight()+a[2].weight();if weight>64*1024*1024-self.arena_bytes{return Err("temporary allocation limit exceeded".into())};self.arena_bytes+=weight;V::Map(m.set(a[1].clone(),a[2].clone()))},
                "remove"=>V::Map(m.remove(&a[1])),_=>return Err("map method".into())
            });
        }
        if let Some(name) = op.strip_prefix("record:") {
            let fs = self.meta["records"][name]
                .as_array()
                .ok_or("record schema")?;
            if fs.len() != a.len() {
                return Err("record arity".into());
            }
            return Ok(V::Record(
                name.into(),
                fs.iter()
                    .zip(a.iter_mut())
                    .map(|(f, v)| (f[0].as_str().unwrap().into(), std::mem::replace(v, V::Unit)))
                    .collect(),
            ));
        }
        if let Some(field) = op.strip_prefix("field:") {
            return match &a[0] {
                V::Record(_, fs) => fs.get(field).cloned().ok_or("unknown field".into()),
                V::Vector(xs) => ["x", "y", "z", "w"]
                    .iter()
                    .position(|f| *f == field)
                    .and_then(|i| xs.get(i))
                    .cloned()
                    .ok_or("unknown component".into()),
                _ => Err("field requires record/vector".into()),
            };
        }
        if let Some(tag) = op.strip_prefix("tag:") {
            return Ok(V::Bool(matches!(
                (&a[0], tag),
                (V::Option(Some(_)), "Some")
                    | (V::Result(true, _), "Ok")
                    | (V::Result(false, _), "Err")
            )));
        }
        if let Some(name) = op.strip_prefix("emit:") {
            self.staged.push((name.into(), a[0].clone()));
            return Ok(V::Unit);
        }
        if let Some(table) = op.strip_prefix("table:") {
            let (index, method) = table.split_once(':').ok_or("table operation")?;
            let index = index.parse::<usize>().map_err(|_| "table index")?;
            if let Some(other)=method.strip_prefix("intersect_table:") {
                let other=other.parse::<usize>().map_err(|_|"table index")?;
                let a=self.tables.get(index).ok_or("table index")?;
                let b=self.tables.get(other).ok_or("table index")?;
                let (small,large)=if a.len()<=b.len(){(a,b)}else{(b,a)};
                return Ok(V::List(small.keys().filter(|k|large.contains_key(*k)).cloned().collect()));
            }
            if method == "intersect_keys" {
                let V::List(keys) = &a[0] else { return Err("bulk keys".into()); };
                let selected: std::collections::BTreeSet<_> = keys.iter().collect();
                return Ok(V::List(self.tables[index].keys().filter(|k| selected.contains(k)).cloned().collect()));
            }
            if method == "put_many" || method == "remove_many" {
                let V::List(keys) = &a[0] else { return Err("bulk keys".into()); };
                if method == "put_many" {
                    let V::List(values) = &a[1] else { return Err("bulk values".into()); };
                    if keys.len() != values.len() { return Ok(V::Result(false, Box::new(V::String("table bulk length mismatch".into())))); }

                    for (key, value) in keys.iter().zip(values) { let old=self.tables[index].insert(key.clone(), value.clone()); self.undo.entry((index, key.clone())).or_insert(old); }
                    return Ok(V::Result(true, Box::new(V::Unit)));
                }
                for key in keys { if let Some(old)=self.tables[index].remove(key) { self.undo.entry((index,key.clone())).or_insert(Some(old)); } }
                return Ok(V::Unit);
            }
            let t = self.tables.get_mut(index).ok_or("table index")?;
            return Ok(match method {
                "values" => V::List(t.values().cloned().collect()),
                "keys" => V::List(t.keys().cloned().collect()),
                "scan_get" => t.get(&a[0]).cloned().ok_or("scan key absent")?,
                "get" => V::Option(t.get(&a[0]).cloned().map(Box::new)),
                "contains" => V::Bool(t.contains_key(&a[0])),
                "remove" => {
                    let old = t.remove(&a[0]);
                    let result = V::Option(old.clone().map(Box::new));
                    if old.is_some() { self.undo.entry((index, a[0].clone())).or_insert(old); }
                    result
                },
                "insert" => {
                    if t.contains_key(&a[0]) {
                        return Err("insert key already present".into());
                    }
                    let key = a[0].clone();
                    let old = t.insert(key.clone(), a[1].clone());
                    self.undo.entry((index, key)).or_insert(old);
                    V::Unit
                }
                "replace" | "put" => {
                    if method == "replace" && !t.contains_key(&a[0]) {
                        return Err("replace key absent".into());
                    }
                    let key = a[0].clone();
                    let old = t.insert(key.clone(), a[1].clone());
                    self.undo.entry((index, key)).or_insert(old);
                    V::Unit
                }
                _ => return Err("table method".into()),
            });
        }
        Ok(match op {
            "list" => V::List(a.iter_mut().map(|v| std::mem::replace(v, V::Unit)).collect()),
            "vector" => V::Vector(
                a.iter_mut()
                    .map(|v| std::mem::replace(v, V::Unit))
                    .collect(),
            ),
            "Some" => V::Option(Some(Box::new(a[0].clone()))),
            "None" => V::Option(None),
            "Ok" | "Err" => V::Result(op == "Ok", Box::new(a[0].clone())),
            "unwrap" => match &a[0] {
                V::Option(Some(v)) | V::Result(_, v) => *v.clone(),
                _ => return Err("expected wrapped value".into()),
            },
            "try" | "nested_change" => match &a[0] {
                V::Result(false, e) => {
                    self.error = Some(Failure::Abort(*e.clone()));
                    return Ok(V::Unit);
                }
                V::Result(true, v) => {
                    if op == "try" {
                        *v.clone()
                    } else {
                        a[0].clone()
                    }
                }
                _ => return Err("expected Result".into()),
            },
            "ok_or" => match &a[0] {
                V::Option(Some(v)) => V::Result(true, v.clone()),
                V::Option(None) => V::Result(false, Box::new(a[1].clone())),
                _ => return Err("expected Option".into()),
            },
            "Int" => V::Int(match &a[0] {
                V::U32(n) => BigInt::from(*n),
                V::U64(n) => BigInt::from(*n),
                V::I32(n) => BigInt::from(*n),
                V::Int(n) => n.clone(),
                _ => return Err("expected integer".into()),
            }),
            "sort" => match &a[0] {
                V::List(xs) => {
                    let mut xs = xs.clone();
                    xs.sort();
                    V::List(xs)
                }
                _ => return Err("expected list".into()),
            },
            "div_ok" => V::Bool(!matches!(
                (&a[0], &a[1]),
                (_, V::U32(0)) | (_, V::U64(0)) | (_, V::I32(0)) | (V::I32(i32::MIN), V::I32(-1))
            )),
            "neg" => match &a[0] {
                V::U32(n) => V::U32(n.wrapping_neg()),
                V::U64(n) => V::U64(n.wrapping_neg()),
                V::I32(n) => V::I32(n.wrapping_neg()),
                V::Int(n) => V::Int(-n),
                V::F32(n) => V::F32(n ^ 0x80000000),
                _ => return Err("numeric negation".into()),
            },
            "==" | "!=" | "<" | ">" | "<=" | ">=" => {
                compare_values(op, &a[0], &a[1])
            }
            "checked_add" | "checked_sub" | "checked_mul" => {
                let value = match (&a[0], &a[1]) {
                    (V::I32(x), V::I32(y)) => match op {
                        "checked_add" => x.checked_add(*y),
                        "checked_sub" => x.checked_sub(*y),
                        _ => x.checked_mul(*y),
                    }
                    .map(V::I32),
                    (V::U32(x), V::U32(y)) => match op {
                        "checked_add" => x.checked_add(*y),
                        "checked_sub" => x.checked_sub(*y),
                        _ => x.checked_mul(*y),
                    }
                    .map(V::U32),
                    (V::U64(x), V::U64(y)) => match op {
                        "checked_add" => x.checked_add(*y),
                        "checked_sub" => x.checked_sub(*y),
                        _ => x.checked_mul(*y),
                    }
                    .map(V::U64),
                    _ => return Err("checked arithmetic types".into()),
                };
                if let Some(v) = value {
                    V::Result(true, Box::new(v))
                } else {
                    V::Result(false, Box::new(V::Enum("ArithmeticError.Overflow".into())))
                }
            }
            "+" | "-" | "*" | "quot" | "rem" => match (&a[0], &a[1]) {
                (V::U32(x), V::U32(y)) => V::U32(match op {
                    "+" => x.wrapping_add(*y),
                    "-" => x.wrapping_sub(*y),
                    "*" => x.wrapping_mul(*y),
                    "quot" => x.checked_div(*y).ok_or("invalid division")?,
                    _ => x.checked_rem(*y).ok_or("invalid division")?,
                }),
                (V::U64(x), V::U64(y)) => V::U64(match op {
                    "+" => x.wrapping_add(*y),
                    "-" => x.wrapping_sub(*y),
                    "*" => x.wrapping_mul(*y),
                    "quot" => x.checked_div(*y).ok_or("invalid division")?,
                    _ => x.checked_rem(*y).ok_or("invalid division")?,
                }),
                (V::I32(x), V::I32(y)) => V::I32(match op {
                    "+" => x.wrapping_add(*y),
                    "-" => x.wrapping_sub(*y),
                    "*" => x.wrapping_mul(*y),
                    "quot" => x.checked_div(*y).ok_or("invalid division")?,
                    _ => x.checked_rem(*y).ok_or("invalid division")?,
                }),
                (V::F32(x), V::F32(y)) => {
                    let x = f32::from_bits(*x);
                    let y = f32::from_bits(*y);
                    V::F32(arithmetic_f32_bits(
                        match op {
                            "+" => x + y,
                            "-" => x - y,
                            "*" => x * y,
                            _ => return Err("float division".into()),
                        },
                    ))
                }
                (V::Int(x), V::Int(y)) => V::Int(match op {
                    "+" => x + y,
                    "-" => x - y,
                    "*" => x * y,
                    _ => return Err("exact division unsupported".into()),
                }),
                _ => return Err("numeric operand types".into()),
            },
            _ => return Err(format!("unknown primitive {op}")),
        })
    }
}
unsafe extern "C" {
    fn ink_program_call(
        ctx: *mut std::ffi::c_void,
        kind: u32,
        index: u32,
        args: *const u64,
        len: usize,
    ) -> u64;
}
// Transport excludes local owners at the type level. Private worker owners may
// exist inside callbacks, but cannot be shared or returned across the boundary.
#[derive(Clone)]
enum FrozenV {Unit,Bool(bool),U32(u32),U64(u64),I32(i32),F32(u32),Int(BigInt),String(String),Id(String,u128),Record(String,BTreeMap<String,FrozenV>),Enum(String),Option(Option<Box<FrozenV>>),Result(bool,Box<FrozenV>),List(Vec<FrozenV>),Vector(Vec<FrozenV>)}
impl FrozenV {
    fn capture(v:V)->R<Self>{Ok(match v{
        V::Unit=>Self::Unit,V::Bool(x)=>Self::Bool(x),V::U32(x)=>Self::U32(x),V::U64(x)=>Self::U64(x),V::I32(x)=>Self::I32(x),V::F32(x)=>Self::F32(x),V::Int(x)=>Self::Int(x),V::String(x)=>Self::String(x),V::Id(n,x)=>Self::Id(n,x),V::Enum(x)=>Self::Enum(x),
        V::Record(n,xs)=>Self::Record(n,xs.into_iter().map(|(k,v)|Ok((k,Self::capture(v)?))).collect::<R<_>>()?),
        V::Option(x)=>Self::Option(x.map(|x|Self::capture(*x).map(Box::new)).transpose()?),V::Result(b,x)=>Self::Result(b,Box::new(Self::capture(*x)?)),
        V::List(xs)=>Self::List(xs.into_iter().map(Self::capture).collect::<R<_>>()?),V::Vector(xs)=>Self::Vector(xs.into_iter().map(Self::capture).collect::<R<_>>()?),V::Buffer(_)|V::Map(_)=>return Err("owned value crossed parallel boundary".into()),
    })}
    fn wire(&self)->Json{match self{
      Self::Unit=>json!(["Unit"]),Self::Bool(x)=>json!(["Bool",x]),Self::U32(x)=>json!(["U32",x]),Self::U64(x)=>json!(["U64",x.to_string()]),Self::I32(x)=>json!(["I32",x]),Self::F32(x)=>json!(["F32",x]),Self::Int(x)=>json!(["Int",x.to_string()]),Self::String(x)=>json!(["String",x]),Self::Enum(x)=>json!(["Enum",x]),Self::Id(n,x)=>json!(["Id",n,x.to_string()]),Self::Record(n,fs)=>json!(["Record",n,fs.iter().map(|(k,v)|(k.clone(),v.wire())).collect::<serde_json::Map<_,_>>()]),Self::Option(x)=>json!(["Option",x.as_ref().map(|x|x.wire())]),Self::Result(b,x)=>json!(["Result",b,x.wire()]),Self::List(xs)=>json!(["List",xs.iter().map(Self::wire).collect::<Vec<_>>()]),Self::Vector(xs)=>json!(["Vector",xs.iter().map(Self::wire).collect::<Vec<_>>()])}}
    fn from_wire(v:&Json,depth:usize,budget:&mut usize)->R<Self>{if depth>64||*budget==0{return Err("parallel value limit".into());}*budget-=1;let a=v.as_array().ok_or("parallel value")?;let tag=a.first().and_then(Json::as_str).ok_or("parallel value tag")?;let n=|i:usize|a.get(i).ok_or("parallel value field");let string=|i:usize|n(i)?.as_str().map(str::to_owned).ok_or("parallel string");Ok(match tag{
      "Unit" if a.len()==1=>Self::Unit,"Bool" if a.len()==2=>Self::Bool(n(1)?.as_bool().ok_or("parallel Bool")?),"U32" if a.len()==2=>Self::U32(n(1)?.as_u64().and_then(|x|x.try_into().ok()).ok_or("parallel U32")?),"U64" if a.len()==2=>Self::U64(string(1)?.parse().map_err(|_|"parallel U64")?),"I32" if a.len()==2=>Self::I32(n(1)?.as_i64().and_then(|x|x.try_into().ok()).ok_or("parallel I32")?),"F32" if a.len()==2=>Self::F32(n(1)?.as_u64().and_then(|x|x.try_into().ok()).ok_or("parallel F32")?),"Int" if a.len()==2=>Self::Int(string(1)?.parse().map_err(|_|"parallel Int")?),"String" if a.len()==2=>Self::String(string(1)?),"Enum" if a.len()==2=>Self::Enum(string(1)?),"Id" if a.len()==3=>Self::Id(string(1)?,string(2)?.parse().map_err(|_|"parallel ID")?),"Record" if a.len()==3=>Self::Record(string(1)?,n(2)?.as_object().ok_or("parallel record")?.iter().map(|(k,v)|Ok((k.clone(),Self::from_wire(v,depth+1,budget)?))).collect::<R<_>>()?),"Option" if a.len()==2=>Self::Option(if n(1)?.is_null(){None}else{Some(Box::new(Self::from_wire(n(1)?,depth+1,budget)?))}),"Result" if a.len()==3=>Self::Result(n(1)?.as_bool().ok_or("parallel Result")?,Box::new(Self::from_wire(n(2)?,depth+1,budget)?)),"List"|"Vector" if a.len()==2=>{let xs=n(1)?.as_array().ok_or("parallel list")?.iter().map(|v|Self::from_wire(v,depth+1,budget)).collect::<R<Vec<_>>>()?;if tag=="List"{Self::List(xs)}else{Self::Vector(xs)}},_=>return Err("parallel value shape".into())})}
    fn value(self)->V{match self{Self::Unit=>V::Unit,Self::Bool(x)=>V::Bool(x),Self::U32(x)=>V::U32(x),Self::U64(x)=>V::U64(x),Self::I32(x)=>V::I32(x),Self::F32(x)=>V::F32(x),Self::Int(x)=>V::Int(x),Self::String(x)=>V::String(x),Self::Id(n,x)=>V::Id(n,x),Self::Enum(x)=>V::Enum(x),Self::Record(n,xs)=>V::Record(n,xs.into_iter().map(|(k,v)|(k,v.value())).collect()),Self::Option(x)=>V::Option(x.map(|x|Box::new(x.value()))),Self::Result(b,x)=>V::Result(b,Box::new(x.value())),Self::List(xs)=>V::List(xs.into_iter().map(Self::value).collect()),Self::Vector(xs)=>V::Vector(xs.into_iter().map(Self::value).collect())}}
}
// Diagnostic receipt counts actual entered OS threads, never planned jobs.
static INK_PARALLEL_RECEIPT: std::sync::LazyLock<std::sync::Mutex<(u64,std::collections::BTreeSet<String>,std::collections::BTreeSet<String>)>> = std::sync::LazyLock::new(||std::sync::Mutex::new((0,std::collections::BTreeSet::new(),std::collections::BTreeSet::new())));
fn ink_parallel_start_receipt(){INK_PARALLEL_RECEIPT.lock().expect("parallel receipt lock").2.clear();}
fn ink_parallel_record_thread(){let mut r=INK_PARALLEL_RECEIPT.lock().expect("parallel receipt lock");r.0+=1;let id=format!("{:?}",std::thread::current().id());r.1.insert(id.clone());r.2.insert(id);}
pub fn ink_parallel_statistics()->(u64,Vec<String>,Vec<String>){let r=INK_PARALLEL_RECEIPT.lock().expect("parallel receipt lock");(r.0,r.1.iter().cloned().collect(),r.2.iter().cloned().collect())}

// Pure callbacks get independent arenas; no table or event storage crosses workers.
thread_local! {static PARALLEL_DEPTH: std::cell::Cell<u32> = const { std::cell::Cell::new(0) };}
unsafe extern "C"{fn ink_parallel_callback(ctx:*mut std::ffi::c_void,callback:u32,index:u32,item:u64,captures:*const u64)->u64;}
#[no_mangle]
pub unsafe extern "C" fn ink_parallel(ctx:*mut InkContext,input:u64,grain:u32,callback:u32,captures:*const u64,count:usize,buffer:u32)->u64 {
    let c=&mut *ctx;
    let result=(||->R<V>{
        let input=c.value(input)?;
        let items=match input { V::List(xs) if buffer==0 => xs, V::Buffer(xs) if buffer==1 => xs.freeze(), _=>return Err("parallel input type".into()) };
        let handles=if count==0 { &[] } else { std::slice::from_raw_parts(captures,count) };
        let captures=handles.iter().map(|h|FrozenV::capture(c.value(*h)?)).collect::<R<Vec<_>>>()?;
        let items=items.into_iter().map(FrozenV::capture).collect::<R<Vec<_>>>()?;
        let meta=c.meta.clone();
        #[cfg(target_arch="wasm32")]
        if !PARALLEL_DEPTH.with(|d|d.get()>0)&&items.len()/(grain.max(1) as usize)>=2{
            let values=__ink_parallel_host(json!({"callback":callback,"items":items.iter().map(FrozenV::wire).collect::<Vec<_>>(),"captures":captures.iter().map(FrozenV::wire).collect::<Vec<_>>(),"grain":grain}))?;
            let mut budget=1000000;
            let output=values.as_array().ok_or("parallel output array")?.iter().map(|v|FrozenV::from_wire(v,0,&mut budget).map(FrozenV::value)).collect::<R<Vec<_>>>()?;
            if output.len()!=items.len(){return Err("parallel result length".into());}
            return Ok(if buffer==1{V::Buffer(OwnedBuffer::shared(output))}else{V::List(output)});
        }

        let requested=std::env::var("INK_THREADS").ok().and_then(|x|x.parse::<usize>().ok()).unwrap_or_else(||std::thread::available_parallelism().map(|x|x.get()).unwrap_or(1)).clamp(1,32);
        let workers=if cfg!(target_arch="wasm32")||PARALLEL_DEPTH.with(|d|d.get()>0) {1} else {requested.min(items.len()/(grain.max(1) as usize)).max(1)};
        let chunk=items.len().div_ceil(workers).max(1);
        let run=|start:usize,xs:&[FrozenV]|->R<Vec<FrozenV>>{
            struct Guard(u32);impl Drop for Guard{fn drop(&mut self){PARALLEL_DEPTH.with(|d|d.set(self.0));}}
            let _guard=Guard(PARALLEL_DEPTH.with(|d|{let old=d.get();d.set(old+1);old}));
            let mut local=InkContext{values:vec![],error:None,fuel:100000000,arena_bytes:0,meta:meta.clone(),tables:vec![],undo:BTreeMap::new(),version:0,staged:vec![],outbox:vec![]};
            let captures=captures.iter().cloned().map(|v|local.put(v.value())).collect::<Vec<_>>();
            let mut out=Vec::with_capacity(xs.len());
            for (i,item) in xs.iter().enumerate(){
                let item=local.put(item.clone().value());
                let result=ink_parallel_callback((&mut local as *mut InkContext).cast(),callback,(start+i).try_into().map_err(|_|"parallel index limit")?,item,captures.as_ptr());
                if let Some(error)=local.error.take(){return Err(match error{Failure::Host(e)=>e,Failure::Abort(_)=>"pure callback aborted".into()});}
                out.push(FrozenV::capture(local.value(result)?)?);
                // Captures remain valid, invocation-local temporaries do not accumulate.
                local.values.truncate(captures.iter().filter(|h|**h>>32==0).count());
                local.arena_bytes=local.values.iter().map(V::weight).sum();
            }
            Ok(out)
        };
        let output=if workers==1 {run(0,&items)?} else {ink_parallel_start_receipt();std::thread::scope(|scope|{
            let joins=items.chunks(chunk).enumerate().map(|(i,xs)|scope.spawn(move||{ink_parallel_record_thread();run(i*chunk,xs)})).collect::<Vec<_>>();
            let mut out=Vec::with_capacity(items.len());
            for task in joins {out.extend(task.join().map_err(|_|"parallel worker panicked")??);}
            Ok::<_,String>(out)
        })?};
        let output=output.into_iter().map(FrozenV::value).collect();
        Ok(if buffer==1 {V::Buffer(OwnedBuffer::shared(output))} else {V::List(output)})
    })();
    c.result(result)
}
#[no_mangle]
pub unsafe extern "C" fn ink_failed(ctx: *mut InkContext) -> bool {
    (*ctx).error.is_some()
}
#[no_mangle]
pub unsafe extern "C" fn ink_tick(ctx: *mut InkContext) -> bool {
    (*ctx).tick()
}
#[no_mangle]
pub unsafe extern "C" fn ink_error(ctx: *mut InkContext, text: *const c_char) -> u64 {
    (*ctx).fail(CStr::from_ptr(text).to_string_lossy().into())
}
#[no_mangle]
pub unsafe extern "C" fn ink_literal(
    ctx: *mut InkContext,
    kind: u32,
    n: u64,
    text: *const c_char,
    len: usize,
) -> u64 {
    let c = &mut *ctx;
    if !c.tick() {
        return 0;
    }
    let r = (|| -> R<V> {
        Ok(match InkValueKind::from_raw(kind).ok_or("invalid literal kind")? {
            InkValueKind::Unit => V::Unit,
            InkValueKind::Bool => V::Bool(n != 0),
            InkValueKind::U32 => V::U32(n as u32),
            InkValueKind::U64 => V::U64(n),
            InkValueKind::I32 => V::I32(n as i32),
            InkValueKind::F32 => V::F32(n as u32),
            InkValueKind::Int => V::Int(BigInt::from(n)),
            tag @ (InkValueKind::String | InkValueKind::Enum) => {
                let text = std::str::from_utf8(std::slice::from_raw_parts(text as *const u8, len))
                    .map_err(|_| "invalid UTF-8")?
                    .to_owned();
                if tag == InkValueKind::String {
                    V::String(text)
                } else {
                    V::Enum(text)
                }
            }
        })
    })();
    c.result(r)
}
#[no_mangle]
pub unsafe extern "C" fn ink_op(
    ctx: *mut InkContext,
    op: *const c_char,
    args: *const u64,
    n: usize,
) -> u64 {
    let c = &mut *ctx;
    if !c.tick() {
        return 0;
    }
    let r = (|| -> R<V> {
        let op = CStr::from_ptr(op)
            .to_str()
            .map_err(|_| "invalid primitive")?;
        let hs = if n == 0 {
            &[]
        } else {
            std::slice::from_raw_parts(args, n)
        };
        if let Some(value) = c.borrowed_primitive(op, hs)? {
            return Ok(value);
        }
        // Most primitives have at most four operands; keep their scratch values
        // on the stack rather than allocating a fresh Vec for every operation.
        if hs.len() <= 4 {
            let mut scratch: [V; 4] = std::array::from_fn(|_| V::Unit);
            for (slot, h) in scratch.iter_mut().zip(hs) {
                *slot = c.value(*h)?;
            }
            c.primitive(op, &mut scratch[..hs.len()])
        } else {
            let mut vs = hs.iter().map(|h| c.value(*h)).collect::<R<Vec<_>>>()?;
            c.primitive(op, &mut vs)
        }
    })();
    if c.error.is_some() {
        0
    } else {
        c.result(r)
    }
}
// Frames scope only transient value handles. Tables, journals, events and
// captures before the frame are independent owned values and remain untouched.
#[no_mangle]
pub unsafe extern "C" fn ink_value_frame(ctx:*mut InkContext)->u64 {
    let c=&*ctx;
    ((c.arena_bytes as u64)<<32)|(c.values.len() as u64)
}
#[no_mangle]
pub unsafe extern "C" fn ink_value_finish_frame(ctx:*mut InkContext,frame:u64,value:u64)->u64 {
    let c=&mut *ctx;let length=frame as u32 as usize;let bytes=(frame>>32)as usize;
    if length>c.values.len() || bytes>c.arena_bytes {return c.fail("invalid value frame".into());}
    let result=if value>>32==0 && value>0 {
        let index=(value-1)as usize;
        if index>=c.values.len(){return c.fail("invalid value handle".into());}
        if index>=length {Ok(std::mem::replace(&mut c.values[index],V::Unit))}else{c.value(value)}
    }else{c.value(value)};
    c.values.truncate(length);c.arena_bytes=bytes;c.result(result)
}
#[no_mangle]
pub unsafe extern "C" fn ink_item(ctx: *mut InkContext, h: u64, i: usize) -> u64 {
    let c = &mut *ctx;
    let r = match h
        .checked_sub(1)
        .and_then(|n| usize::try_from(n).ok())
        .and_then(|i| c.values.get(i))
    {
        Some(V::List(xs) | V::Vector(xs)) => {
            xs.get(i).cloned().ok_or("index outside collection".into())
        }
        _ => Err("expected collection".into()),
    };
    c.result(r)
}
#[no_mangle]
pub unsafe extern "C" fn ink_length(ctx: *mut InkContext, h: u64) -> usize {
    let c = &mut *ctx;
    match h
        .checked_sub(1)
        .and_then(|n| usize::try_from(n).ok())
        .and_then(|i| c.values.get(i))
    {
        Some(V::List(xs) | V::Vector(xs)) => xs.len(),
        _ => {
            c.fail("expected collection".into());
            0
        }
    }
}
#[no_mangle]
pub unsafe extern "C" fn ink_append(ctx: *mut InkContext, h: u64, item: u64) {
    let c = &mut *ctx;
    if !c.tick() {
        return;
    }
    match c.value(item) {
        Ok(v) => match h
            .checked_sub(1)
            .and_then(|n| usize::try_from(n).ok())
            .and_then(|i| c.values.get_mut(i))
        {
            Some(V::List(xs)) => {
                let weight = v.weight();
                if weight > 64 * 1024 * 1024 - c.arena_bytes {
                    c.fail("Ink value arena limit exceeded".into());
                } else {
                    c.arena_bytes += weight;
                    xs.push(v);
                }
            }
            _ => {
                c.fail("expected list".into());
            }
        },
        Err(e) => {
            c.fail(e);
        }
    }
}
#[no_mangle]
pub unsafe extern "C" fn ink_bool(ctx: *mut InkContext, h: u64) -> bool {
    let c = &mut *ctx;
    match c.value(h) {
        Ok(V::Bool(v)) => v,
        _ => {
            c.fail("expected Bool".into());
            false
        }
    }
}
#[no_mangle]
pub unsafe extern "C" fn ink_u32(ctx: *mut InkContext, h: u64) -> u32 {
    let c = &mut *ctx;
    match c.value(h) {
        Ok(V::U32(v)) => v,
        _ => {
            c.fail("expected u32".into());
            0
        }
    }
}
#[no_mangle]
pub unsafe extern "C" fn ink_finish_action(ctx: *mut InkContext, h: u64) -> u64 {
    let c = &mut *ctx;
    match c.error.take() {
        Some(Failure::Abort(v)) => c.put(V::Result(false, Box::new(v))),
        Some(e) => {
            c.error = Some(e);
            0
        }
        None => h,
    }
}
struct HostTransaction { version: u64, removed: Vec<Event>, undo: BTreeMap<(usize, V), Option<V>> }
pub struct State {
    ctx: Box<InkContext>,
    host: Option<HostTransaction>,
}
impl State {
    pub fn parallel_statistics()->Json{let(n,ids,last)=ink_parallel_statistics();json!({"workers":n,"workerIds":ids,"lastWorkerIds":last})}
    pub fn new() -> Self {
        let meta: Json =
            serde_json::from_str(include_str!("metadata.json")).expect("compiled metadata");
        let count = meta["roots"].as_array().unwrap().len();
        Self {
            host: None,
            ctx: Box::new(InkContext {
                meta,
                tables: vec![BTreeMap::new(); count],
                undo: BTreeMap::new(),
                values: vec![],
                error: None,
                fuel: 100000000,
                arena_bytes: 0,
                version: 0,
                staged: vec![],
                outbox: vec![],
            }),
        }
    }
    #[cfg(target_arch="wasm32")]
    pub fn parallel_worker(&mut self,task:&Json)->R<Json>{
        let callback=task["callback"].as_u64().and_then(|x|x.try_into().ok()).ok_or("parallel callback")?;
        let start=task["start"].as_u64().and_then(|x|u32::try_from(x).ok()).ok_or("parallel start")?;
        let mut budget=1000000;
        let captures=task["captures"].as_array().ok_or("parallel captures")?.iter().map(|v|FrozenV::from_wire(v,0,&mut budget).map(|v|self.ctx.put(v.value()))).collect::<R<Vec<_>>>()?;
        struct Guard(u32);impl Drop for Guard{fn drop(&mut self){PARALLEL_DEPTH.with(|d|d.set(self.0));}}
        let _guard=Guard(PARALLEL_DEPTH.with(|d|{let old=d.get();d.set(old+1);old}));
        let captured_count=self.ctx.values.len();let mut out=vec![];
        for (i,item) in task["items"].as_array().ok_or("parallel items")?.iter().enumerate(){
            let item=self.ctx.put(FrozenV::from_wire(item,0,&mut budget)?.value());
            let value=unsafe{ink_parallel_callback((&mut *self.ctx as *mut InkContext).cast(),callback,start.checked_add(i.try_into().map_err(|_|"parallel index")?).ok_or("parallel index")?,item,captures.as_ptr())};
            if let Some(error)=self.ctx.error.take(){return Err(match error{Failure::Host(e)=>e,Failure::Abort(_)=>"parallel abort".into()});}
            out.push(FrozenV::capture(self.ctx.value(value)?)?.wire());self.ctx.values.truncate(captured_count);self.ctx.arena_bytes=self.ctx.values.iter().map(V::weight).sum();
        }Ok(Json::Array(out))
    }
    fn call(&mut self, name: &str, args: &Json, kind: u32) -> R<Json> {
        let section = if kind == 0 { "functions" } else { "actions" };
        let declarations = self.ctx.meta[section]
            .as_array()
            .ok_or("compiled declarations")?;
        let (index, d) = declarations
            .iter()
            .enumerate()
            .find(|(_, d)| d["name"] == name)
            .ok_or_else(|| format!("unknown {section} {name}"))?;
        let guard = d["precondition"].as_str().map(str::to_owned);
        let change = d["change"].as_bool().unwrap_or(false);
        let fallible = d["result"].get("Result").is_some();
        if kind==0 && d["internal"].as_bool()==Some(true) {return Err("temporary storage is internal to a pure invocation".into());}
        let args = args.as_array().ok_or("expected argument array")?;
        let params = d["params"].as_array().ok_or("compiled parameters")?;
        if args.len() != params.len() {
            return Err("argument count mismatch".into());
        }
        let mut left = 1000000;
        let captured = args
            .iter()
            .zip(params)
            .map(|(v, t)| from_json(v, t, &self.ctx.meta, &mut left, 0))
            .collect::<R<Vec<_>>>()?;
        if let Some(guard)=guard {
            let predicate=self.call(&guard,&Json::Array(args.clone()),kind)?;
            let valid=if kind==0{predicate.as_bool()}else{predicate["result"].as_bool()};
            if valid!=Some(true){return Err("contract precondition failed".into());}
        }
        self.ctx.values.clear();
        self.ctx.arena_bytes = 0;
        self.ctx.error = None;
        self.ctx.fuel = 100000000;
        self.ctx.staged.clear();
        let handles = captured
            .into_iter()
            .map(|v| self.ctx.put(v))
            .collect::<Vec<_>>();
        let version = self.ctx.version;
        let h = unsafe {
            ink_program_call(
                (&mut *self.ctx as *mut InkContext).cast(),
                kind,
                index as u32,
                handles.as_ptr(),
                handles.len(),
            )
        };
        let result = if let Some(e) = self.ctx.error.take() {
            Err(match e {
                Failure::Host(e) => e,
                Failure::Abort(_) => "unhandled domain error".into(),
            })
        } else {
            self.ctx.value(h).map(|v| v.json())
        };
        if kind == 0 {
            self.ctx.values.clear();
            return result;
        }
        match result {
            Err(e) => {
                self.ctx.rollback();
                self.ctx.staged.clear();
                self.ctx.values.clear();
                Err(e)
            }
            Ok(result) => {
                let succeeded = !fallible || result.get("Ok").is_some();
                if change {
                    let next = match transaction::decide(version, succeeded) {
                        transaction::Decision::Rollback => {
                            self.ctx.rollback();
                            self.ctx.staged.clear();
                            self.ctx.values.clear();
                            return Ok(
                                json!({"result":result,"committed":false,"version":version,"events":[]}),
                            );
                        }
                        transaction::Decision::Exhausted => {
                            self.ctx.rollback();
                            self.ctx.staged.clear();
                            self.ctx.values.clear();
                            return Err("commit sequence exhausted".into());
                        }
                        transaction::Decision::Commit { version } => version,
                    };
                    if let Some(host) = &mut self.host {
                        // Each action owns a separate before-image map. Only successful
                        // actions contribute the first image of a cell to the host journal.
                        for (cell, old) in std::mem::take(&mut self.ctx.undo) {
                            host.undo.entry(cell).or_insert(old);
                        }
                    } else { self.ctx.undo.clear(); }
                    self.ctx.version = next;
                    let events = transaction::publish(next, self.ctx.staged.drain(..))
                        .map(|p| {
                            let (channel, value) = p.value;
                            Event {
                                commit: p.commit,
                                position: p.position,
                                channel,
                                value,
                            }
                        })
                        .collect::<Vec<_>>();
                    let wire = events.iter().map(Event::to_json).collect::<Vec<_>>();
                    self.ctx.outbox.extend(events);
                    self.ctx.values.clear();
                    Ok(json!({"result":result,"committed":true,"version":next,"events":wire}))
                } else {
                    self.ctx.rollback();
                    self.ctx.staged.clear();
                    self.ctx.values.clear();
                    Ok(json!({"result":result,"committed":false,"version":version,"events":[]}))
                }
            }
        }
    }
    pub fn call_json(&mut self, name: &str, args: &Json) -> R<Json> {
        self.call(name, args, 0)
    }
    pub fn invoke_json(&mut self, name: &str, args: &Json) -> R<Json> {
        self.call(name, args, 1)
    }
    pub fn version(&self) -> u64 {
        self.ctx.version
    }
    pub fn outbox(&self) -> &[Event] {
        &self.ctx.outbox
    }
    pub fn begin_transaction(&mut self) -> R<bool> {
        if self.host.is_some() || !self.ctx.undo.is_empty() || !self.ctx.staged.is_empty() { return Err("transaction already in progress".into()); }
        self.host = Some(HostTransaction { version: self.ctx.version, removed: vec![], undo: BTreeMap::new() }); Ok(true)
    }
    pub fn commit_transaction(&mut self) { self.host = None; self.ctx.undo.clear(); }
    pub fn rollback_transaction(&mut self) {
        if let Some(host) = self.host.take() {
            self.ctx.rollback(); self.ctx.undo = host.undo; self.ctx.rollback(); self.ctx.version = host.version;
            self.ctx.outbox.retain(|e| e.commit <= host.version);
            let mut restored = host.removed; restored.append(&mut self.ctx.outbox); self.ctx.outbox = restored;
        }
    }
    pub fn acknowledge_through(&mut self, commit: u64, position: u64) {
        for e in std::mem::take(&mut self.ctx.outbox) {
            if (e.commit, e.position) > (commit, position) { self.ctx.outbox.push(e); }
            else if let Some(host) = &mut self.host { host.removed.push(e); }
        }
    }
    pub fn checkpoint(&self) -> R<Vec<u8>> {
        self.checkpoint_with_limits(portable::Limits::default())
    }
    pub fn checkpoint_with_limits(&self, limits: portable::Limits) -> R<Vec<u8>> {
        let layout = snapshot_layout(&self.ctx.meta)?;
        let mut roots = self.ctx.meta["roots"]
            .as_array()
            .unwrap()
            .iter()
            .enumerate()
            .collect::<Vec<_>>();
        roots.sort_by(|a, b| a.1["name"].as_str().cmp(&b.1["name"].as_str()));
        let tables = roots
            .iter()
            .map(|(i, _)| {
                self.ctx.tables[*i]
                    .iter()
                    .map(|(k, v)| (k.json(), v.json()))
                    .collect()
            })
            .collect();
        let outbox = self
            .ctx
            .outbox
            .iter()
            .map(|e| {
                Ok(portable::Event {
                    commit: e.commit,
                    position: e.position,
                    channel: layout
                        .events
                        .iter()
                        .position(|(n, _)| n == &e.channel)
                        .ok_or("event channel")?,
                    value: e.value.json(),
                })
            })
            .collect::<R<Vec<_>>>()?;
        portable::encode(
            &layout,
            &portable::Logical {
                version: self.ctx.version,
                tables,
                outbox,
            },
            limits,
        )
    }
    pub fn restore(bytes: &[u8]) -> R<Self> {
        Self::restore_with_limits(bytes, portable::Limits::default())
    }
    pub fn restore_with_limits(bytes: &[u8], limits: portable::Limits) -> R<Self> {
        let mut s = Self::new();
        let layout = snapshot_layout(&s.ctx.meta)?;
        let logical = portable::decode(&layout, bytes, limits)?;
        let mut roots = s.ctx.meta["roots"]
            .as_array()
            .unwrap()
            .iter()
            .enumerate()
            .collect::<Vec<_>>();
        roots.sort_by(|a, b| a.1["name"].as_str().cmp(&b.1["name"].as_str()));
        let mut left = 1000000;
        for ((index, r), rows) in roots.iter().zip(logical.tables) {
            let kt = &r["type"]["Table"][0];
            let vt = &r["type"]["Table"][1];
            for (k, v) in rows {
                s.ctx.tables[*index].insert(
                    from_json(&k, kt, &s.ctx.meta, &mut left, 0)?,
                    from_json(&v, vt, &s.ctx.meta, &mut left, 0)?,
                );
            }
        }
        s.ctx.version = logical.version;
        let event_names = s.ctx.meta["events"]
            .as_object()
            .unwrap()
            .keys()
            .cloned()
            .collect::<Vec<_>>();
        for e in logical.outbox {
            let channel = event_names[e.channel].clone();
            let value = from_json(
                &e.value,
                &s.ctx.meta["events"][&channel],
                &s.ctx.meta,
                &mut left,
                0,
            )?;
            s.ctx.outbox.push(Event {
                commit: e.commit,
                position: e.position,
                channel,
                value,
            });
        }
        let guards = s.ctx.meta["invariant_checks"].as_array().cloned().unwrap_or_default();
        for guard in guards {
            let name = guard.as_str().ok_or("invalid invariant metadata")?;
            if s.invoke_json(name, &json!([]))?["result"] != Json::Bool(true) {
                return Err("snapshot violates state invariant".into());
            }
        }
        Ok(s)
    }
}
fn snapshot_schema(t:&Json,meta:&Json,stack:&mut Vec<String>,budget:&mut usize,depth:usize)->R<portable::Schema>{
    if depth>128||*budget==0{return Err("snapshot schema resource limit".into());}*budget-=1;
    use portable::Schema as S;
    Ok(if let Some(n) = t.as_str() {
        match n {
            "Unit" => S::Unit,
            "Bool" => S::Bool,
            "U32" => S::U32,
            "U64" => S::U64,
            "I32" => S::I32,
            "F32" => S::F32,
            "Int" => S::Int,
            "String" => S::String,
            _ => return Err("unsupported state schema".into()),
        }
    } else {
        let (kind, v) = t
            .as_object()
            .and_then(|o| o.iter().next())
            .ok_or("schema")?;
        match kind.as_str() {
            "List" => S::List(Box::new(snapshot_schema(v,meta,stack,budget,depth+1)?)),
            "Vector" => S::Vector(
                Box::new(snapshot_schema(&v[0],meta,stack,budget,depth+1)?),
                u8::try_from(v[1].as_u64().ok_or("vector dimension")?)
                    .map_err(|_| "vector dimension")?,
            ),
            "Option" => S::Option(Box::new(snapshot_schema(v,meta,stack,budget,depth+1)?)),
            "Result" => S::Result(
                Box::new(snapshot_schema(&v[0],meta,stack,budget,depth+1)?),
                Box::new(snapshot_schema(&v[1],meta,stack,budget,depth+1)?),
            ),
            "Named" => {
                let n = v.as_str().ok_or("named schema")?;
                if meta["ids"].as_array().unwrap().iter().any(|id| id == n) {
                    S::Id
                } else if let Some(fs) = meta["records"].get(n).and_then(Json::as_array) {
                    if stack.iter().any(|name|name==n){return Ok(S::Ref(n.into()));}
                    stack.push(n.into());
                    let fields=fs.iter().map(|f|Ok((f[0].as_str().unwrap().into(),snapshot_schema(&f[1],meta,stack,budget,depth+1)?))).collect::<R<Vec<_>>>()?;
                    stack.pop();
                    let body=S::Record(fields);
                    if meta["recursive_records"].as_array().is_some_and(|names|names.iter().any(|name|name==n)){S::Bind(n.into(),Box::new(body))}else{body}
                } else {
                    S::Enum(
                        meta["enums"][n]
                            .as_array()
                            .ok_or("enum schema")?
                            .iter()
                            .map(|v| format!("{n}.{}", v.as_str().unwrap()))
                            .collect(),
                    )
                }
            }
            _ => return Err("state schema".into()),
        }
    })
}
fn snapshot_layout(meta: &Json) -> R<portable::Layout> {
    let mut stack=vec![];let mut budget=100_000;
    let mut roots = meta["roots"].as_array().unwrap().iter().collect::<Vec<_>>();
    roots.sort_by(|a, b| a["name"].as_str().cmp(&b["name"].as_str()));
    Ok(portable::Layout {
        program: serde_json::from_value(meta["snapshot_program"].clone())
            .map_err(|e| e.to_string())?,
        schema: serde_json::from_value(meta["snapshot_schema"].clone())
            .map_err(|e| e.to_string())?,
        roots: roots
            .iter()
            .map(|r| {
                Ok((
                    r["name"].as_str().unwrap().into(),
                    snapshot_schema(&r["type"]["Table"][0],meta,&mut stack,&mut budget,0)?,
                    snapshot_schema(&r["type"]["Table"][1],meta,&mut stack,&mut budget,0)?,
                ))
            })
            .collect::<R<_>>()?,
        events: meta["events"]
            .as_object()
            .unwrap()
            .iter()
            .map(|(n, t)| Ok((n.clone(), snapshot_schema(t,meta,&mut stack,&mut budget,0)?)))
            .collect::<R<_>>()?,
    })
}

#[inline(never)]
fn arithmetic_f32_bits(value:f32)->u32{if value.is_nan(){0x7fc00000}else{value.to_bits()}}

mod value_wire {
//! Bounded, schema-bound portable values. Networking is deliberately external.
//! The descriptor and codecs are operationally trusted, not proof certificates.
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet};
pub const FORMAT: &str = "ink-value-wire-v1";
pub const MAGIC: &[u8; 8] = b"INKVAL\0\x01";
#[derive(Clone, Copy, Debug)]
pub struct Limits {
    pub bytes: usize,
    pub nodes: usize,
    pub depth: usize,
}
impl Default for Limits {
    fn default() -> Self {
        Self {
            bytes: 16 * 1024 * 1024,
            nodes: 1_000_000,
            depth: 128,
        }
    }
}
impl Limits {
    pub fn checked(self) -> Result<Self, String> {
        let max = Self::default();
        if self.bytes > max.bytes || self.nodes > max.nodes || self.depth > max.depth {
            return Err("wire hard resource limit".into());
        }
        Ok(self)
    }
}
#[derive(Clone, Debug)]
pub struct Schema {
    root: Value,
    named: BTreeMap<String, Value>,
    identity: [u8; 32],
}
impl Schema {
    pub fn new(root: Value, named: BTreeMap<String, Value>) -> Result<Self, String> {
        fn check(
            t: &Value,
            named: &BTreeMap<String, Value>,
            used: &mut BTreeSet<String>,
            depth: usize,
            budget: &mut usize,
        ) -> Result<(), String> {
            if depth > 64 || *budget == 0 {
                return Err("wire descriptor limit".into());
            }
            *budget -= 1;
            let obj = t.as_object().ok_or("invalid wire descriptor")?;
            let kind = t["kind"].as_str().ok_or("missing wire kind")?;
            let keys: &[&str] = match kind {
                "u32" | "u64" | "i32" | "f32" | "bool" | "unit" | "string" | "int" => &["kind"],
                "id" | "ref" => &["kind", "name"],
                "enum" => &["kind", "name", "variants"],
                "record" => &["kind", "name", "fields"],
                "list" | "option" => &["kind", "element"],
                "vector" => &["kind", "element", "size"],
                "result" => &["kind", "ok", "error"],
                _ => return Err("unsupported wire descriptor".into()),
            };
            if obj.len() != keys.len() || keys.iter().any(|k| !obj.contains_key(*k)) {
                return Err("invalid wire descriptor fields".into());
            }
            match kind {
                "id" | "ref" | "enum" | "record" => {
                    t["name"].as_str().ok_or("missing descriptor name")?;
                }
                _ => {}
            }
            match kind {
                "ref" => {
                    let n = t["name"].as_str().unwrap();
                    if used.insert(n.into()) {
                        let d = named.get(n).ok_or("unresolved wire reference")?;
                        if d["kind"] != "record" || d["name"] != n {
                            return Err("invalid named wire reference".into());
                        }
                        check(d, named, used, depth + 1, budget)?;
                    }
                }
                "record" => {
                    let mut seen = BTreeSet::new();
                    for f in t["fields"].as_array().ok_or("missing descriptor fields")? {
                        if f.as_object().is_none_or(|o| o.len() != 2)
                            || !seen.insert(f["name"].as_str().ok_or("invalid field name")?)
                        {
                            return Err("invalid or duplicate wire field".into());
                        }
                        check(&f["type"], named, used, depth + 1, budget)?;
                    }
                }
                "enum" => {
                    let variants = t["variants"].as_array().ok_or("missing variants")?;
                    let mut seen = BTreeSet::new();
                    if variants.is_empty() || variants.len() > 64 {
                        return Err("wire enum limit".into());
                    }
                    for v in variants {
                        if !seen.insert(v.as_str().ok_or("invalid variant")?) {
                            return Err("duplicate variant".into());
                        }
                    }
                }
                "vector" => {
                    if t["size"].as_u64().is_none_or(|n| n == 0 || n > 64) {
                        return Err("invalid vector size".into());
                    }
                    check(&t["element"], named, used, depth + 1, budget)?;
                }
                "list" | "option" => check(&t["element"], named, used, depth + 1, budget)?,
                "result" => {
                    check(&t["ok"], named, used, depth + 1, budget)?;
                    check(&t["error"], named, used, depth + 1, budget)?;
                }
                _ => {}
            }
            Ok(())
        }
        let mut used = BTreeSet::new();
        check(&root, &named, &mut used, 0, &mut 100_000)?;
        let named = named
            .into_iter()
            .filter(|(k, _)| used.contains(k))
            .collect::<BTreeMap<_, _>>();
        let identity = Sha256::digest(
            serde_json::to_vec(&json!({"format":FORMAT,"root":root,"named":named}))
                .map_err(|e| e.to_string())?,
        )
        .into();
        Ok(Self {
            root,
            named,
            identity,
        })
    }
    pub fn root(&self) -> &Value {
        &self.root
    }
    pub fn named(&self) -> &BTreeMap<String, Value> {
        &self.named
    }
    pub fn identity(&self) -> String {
        self.identity.iter().map(|b| format!("{b:02x}")).collect()
    }
    pub fn descriptor(&self) -> Value {
        json!({"format":FORMAT,"root":self.root,"named":self.named,"identity":self.identity()})
    }
    pub fn from_descriptor(v: &Value) -> Result<Self, String> {
        if v["format"] != FORMAT || v.as_object().is_none_or(|o| o.len() != 4) {
            return Err("invalid wire schema envelope".into());
        }
        let s = Self::new(
            v["root"].clone(),
            serde_json::from_value(v["named"].clone()).map_err(|e| e.to_string())?,
        )?;
        if v["identity"] != s.identity() {
            return Err("wire schema identity mismatch".into());
        }
        Ok(s)
    }
    pub(crate) fn resolve<'a>(&'a self, mut t: &'a Value) -> Result<&'a Value, String> {
        for _ in 0..64 {
            if t["kind"] != "ref" {
                return Ok(t);
            }
            t = self
                .named
                .get(t["name"].as_str().ok_or("wire reference name")?)
                .ok_or("wire reference")?;
        }
        Err("wire reference cycle".into())
    }
    pub fn encode(&self, value: &Value, limits: Limits) -> Result<Vec<u8>, String> {
        let limits = limits.checked()?;
        if limits.bytes < 44 {
            return Err("wire byte limit".into());
        }
        let mut out = Vec::new();
        out.extend(MAGIC);
        out.extend(self.identity);
        encode(
            self,
            &self.root,
            value,
            &mut out,
            &mut limits.nodes.clone(),
            0,
            limits,
        )?;
        // Encoding validation is also a check on public numeric/string carriers.
        self.validate(&out, limits)?;
        Ok(out)
    }
    pub fn validate<'a>(
        &'a self,
        bytes: &'a [u8],
        limits: Limits,
    ) -> Result<Validated<'a>, String> {
        let limits = limits.checked()?;
        if bytes.len() > limits.bytes || bytes.len() < 44 {
            return Err("wire byte limit or truncated header".into());
        }
        if &bytes[..8] != MAGIC || bytes[8..40] != self.identity {
            return Err("wire format or schema mismatch".into());
        }
        let mut pos = 40;
        walk(
            self,
            &self.root,
            bytes,
            &mut pos,
            &mut limits.nodes.clone(),
            0,
            limits,
            false,
        )?;
        if pos != bytes.len() {
            return Err("trailing wire bytes".into());
        }
        Ok(Validated {
            schema: self,
            ty: &self.root,
            bytes: &bytes[40..],
            limits,
        })
    }
    pub fn decode(&self, bytes: &[u8], limits: Limits) -> Result<Value, String> {
        self.validate(bytes, limits)?.materialize()
    }
    /// Emit frames directly from a native value or a streaming input adapter.
    /// Final validation binds the emitted shape to this exact schema.
    pub fn encode_with(
        &self,
        limits: Limits,
        emit: impl FnOnce(&mut Encoder) -> Result<(), String>,
    ) -> Result<Vec<u8>, String> {
        let mut writer = Encoder::new(limits)?;
        writer.bytes(MAGIC)?;
        writer.bytes(&self.identity)?;
        emit(&mut writer)?;
        self.validate(&writer.out, limits)?;
        Ok(writer.out)
    }
}

/// Bounded forward frame writer, shared by native and streaming codecs.
/// It carries resource accounting; only Schema::encode_with authenticates types.
pub struct Encoder {
    out: Vec<u8>,
    limits: Limits,
    remaining: usize,
    depth: usize,
}
impl Encoder {
    fn new(limits: Limits) -> Result<Self, String> {
        let limits = limits.checked()?;
        Ok(Self {
            out: Vec::new(),
            remaining: limits.nodes,
            depth: 0,
            limits,
        })
    }
    pub fn position(&self) -> usize {
        self.out.len()
    }
    pub fn bytes(&mut self, bytes: &[u8]) -> Result<(), String> {
        if bytes.len() > self.limits.bytes.saturating_sub(self.out.len()) {
            return Err("wire byte limit".into());
        }
        self.out.extend_from_slice(bytes);
        Ok(())
    }
    pub fn word(&mut self, value: u32) -> Result<(), String> {
        self.bytes(&value.to_le_bytes())
    }
    pub fn patch_word(&mut self, at: usize, value: u32) -> Result<(), String> {
        let end = at.checked_add(4).ok_or("wire offset overflow")?;
        self.out
            .get_mut(at..end)
            .ok_or("wire patch offset")?
            .copy_from_slice(&value.to_le_bytes());
        Ok(())
    }
    pub fn frame(
        &mut self,
        emit: impl FnOnce(&mut Self) -> Result<(), String>,
    ) -> Result<(), String> {
        count(&mut self.remaining, self.depth, self.limits)?;
        let at = self.position();
        self.word(0)?;
        self.depth += 1;
        let result = emit(self);
        self.depth -= 1;
        result?;
        let length = u32::try_from(self.position() - at - 4).map_err(|_| "wire frame overflow")?;
        self.patch_word(at, length)
    }
    /// Reorder a contiguous suffix using a checked permutation of its spans.
    /// Already ordered fields incur no copy. This supports unordered text records.
    pub fn reorder(&mut self, start: usize, spans: &[(usize, usize)]) -> Result<(), String> {
        let mut sorted = spans.to_vec();
        sorted.sort_unstable();
        let mut at = start;
        for &(a, b) in &sorted {
            if a != at || b < a {
                return Err("wire span permutation".into());
            }
            at = b;
        }
        if start > self.out.len() || at != self.out.len() {
            return Err("wire span permutation".into());
        }
        if sorted == spans {
            return Ok(());
        }
        let mut ordered = Vec::with_capacity(self.out.len() - start);
        for &(a, b) in spans {
            ordered.extend_from_slice(self.out.get(a..b).ok_or("wire span offset")?);
        }
        self.out[start..].copy_from_slice(&ordered);
        Ok(())
    }
}
fn count(budget: &mut usize, depth: usize, limits: Limits) -> Result<(), String> {
    if *budget == 0 || depth > limits.depth {
        return Err("wire node or depth limit".into());
    }
    *budget -= 1;
    Ok(())
}
fn decimal(s: &str) -> bool {
    let b = s.strip_prefix('-').unwrap_or(s);
    !b.is_empty()
        && b.bytes().all(|b| b.is_ascii_digit())
        && (b == "0" || !b.starts_with('0'))
        && s != "-0"
}
fn tag<'a>(v: &'a Value, n: &str) -> Result<&'a Value, String> {
    if v.as_object().is_some_and(|o| o.len() == 1) {
        v.get(n).ok_or("invalid wire value tag".into())
    } else {
        Err("invalid wire value tag".into())
    }
}
fn encode(
    s: &Schema,
    t: &Value,
    v: &Value,
    out: &mut Vec<u8>,
    budget: &mut usize,
    d: usize,
    limits: Limits,
) -> Result<(), String> {
    count(budget, d, limits)?;
    let t = s.resolve(t)?;
    let at = out.len();
    out.extend([0; 4]);
    let error = || "invalid value for wire schema".to_string();
    match t["kind"].as_str().ok_or_else(error)? {
        "unit" => {
            if !v.is_null() {
                return Err(error());
            }
        }
        "bool" => out.push(u8::from(v.as_bool().ok_or_else(error)?)),
        "u32" => out.extend(
            u32::try_from(v.as_u64().ok_or_else(error)?)
                .map_err(|_| error())?
                .to_le_bytes(),
        ),
        "i32" => out.extend(
            i32::try_from(v.as_i64().ok_or_else(error)?)
                .map_err(|_| error())?
                .to_le_bytes(),
        ),
        "u64" => {
            let n = if let Some(n) = v.as_u64() {
                n
            } else {
                let text = v.as_str().ok_or_else(error)?;
                if !decimal(text) || text.starts_with('-') {
                    return Err(error());
                }
                text.parse::<u64>().map_err(|_| error())?
            };
            out.extend(n.to_le_bytes());
        }
        "f32" => {
            let bits = if let Some(n) = v.as_f64() {
                let f = n as f32;
                if !f.is_finite() {
                    return Err(error());
                }
                f.to_bits()
            } else {
                u32::try_from(tag(v, "F32Bits")?.as_u64().ok_or_else(error)?)
                    .map_err(|_| error())?
            };
            out.extend(bits.to_le_bytes());
        }
        "string" | "int" | "id" | "enum" => {
            let text = if t["kind"] == "int" {
                tag(v, "Int")?.as_str().ok_or_else(error)?
            } else {
                v.as_str().ok_or_else(error)?
            };
            if text.len() > limits.bytes.saturating_sub(out.len()) {
                return Err("wire byte limit".into());
            }
            if t["kind"] == "int" && !decimal(text) {
                return Err(error());
            }
            if t["kind"] == "enum" && !t["variants"].as_array().unwrap().contains(v) {
                return Err(error());
            }
            if t["kind"] == "id"
                && (text.len() != 32
                    || !text
                        .bytes()
                        .all(|b| b.is_ascii_hexdigit() && !b.is_ascii_uppercase()))
            {
                return Err(error());
            }
            out.extend(text.as_bytes());
        }
        "list" | "vector" => {
            let xs = v.as_array().ok_or_else(error)?;
            if xs.len() > *budget
                || t["kind"] == "vector" && Some(xs.len() as u64) != t["size"].as_u64()
            {
                return Err(error());
            }
            out.extend(u32::try_from(xs.len()).map_err(|_| error())?.to_le_bytes());
            for x in xs {
                encode(s, &t["element"], x, out, budget, d + 1, limits)?;
            }
        }
        "record" => {
            let o = v.as_object().ok_or_else(error)?;
            let fs = t["fields"].as_array().unwrap();
            if o.len() != fs.len() {
                return Err(error());
            }
            for f in fs {
                encode(
                    s,
                    &f["type"],
                    o.get(f["name"].as_str().unwrap()).ok_or_else(error)?,
                    out,
                    budget,
                    d + 1,
                    limits,
                )?;
            }
        }
        "option" => {
            if let Ok(x) = tag(v, "Some") {
                out.push(1);
                encode(s, &t["element"], x, out, budget, d + 1, limits)?;
            } else {
                if !tag(v, "None")?.is_null() {
                    return Err(error());
                }
                out.push(0);
            }
        }
        "result" => {
            if let Ok(x) = tag(v, "Ok") {
                out.push(0);
                encode(s, &t["ok"], x, out, budget, d + 1, limits)?;
            } else {
                out.push(1);
                encode(s, &t["error"], tag(v, "Err")?, out, budget, d + 1, limits)?;
            }
        }
        _ => return Err(error()),
    }
    if out.len() > limits.bytes {
        return Err("wire byte limit".into());
    }
    let len = u32::try_from(out.len() - at - 4).map_err(|_| "wire frame overflow")?;
    out[at..at + 4].copy_from_slice(&len.to_le_bytes());
    Ok(())
}
fn u32_at(bytes: &[u8], pos: usize) -> Result<u32, String> {
    Ok(u32::from_le_bytes(
        bytes
            .get(pos..pos.checked_add(4).ok_or("wire offset overflow")?)
            .ok_or("truncated wire length")?
            .try_into()
            .unwrap(),
    ))
}
fn frame(bytes: &[u8], pos: usize) -> Result<(usize, usize), String> {
    let start = pos.checked_add(4).ok_or("wire offset overflow")?;
    let end = start
        .checked_add(u32_at(bytes, pos)? as usize)
        .ok_or("wire length overflow")?;
    if end > bytes.len() {
        return Err("truncated wire frame".into());
    }
    Ok((start, end))
}
fn walk(
    s: &Schema,
    t: &Value,
    bytes: &[u8],
    pos: &mut usize,
    budget: &mut usize,
    d: usize,
    limits: Limits,
    materialize: bool,
) -> Result<Option<Value>, String> {
    count(budget, d, limits)?;
    let t = s.resolve(t)?;
    let (start, end) = frame(bytes, *pos)?;
    *pos = end;
    let body = &bytes[start..end];
    let mut p = 0;
    let error = || "malformed wire value".to_string();
    let value = match t["kind"].as_str().ok_or_else(error)? {
        "unit" => {
            if !body.is_empty() {
                return Err(error());
            }
            Value::Null
        }
        "bool" => {
            if body.len() != 1 || body[0] > 1 {
                return Err(error());
            }
            Value::Bool(body[0] == 1)
        }
        "u32" | "i32" | "f32" => {
            if body.len() != 4 {
                return Err(error());
            }
            let bits = u32_at(body, 0)?;
            match t["kind"].as_str().unwrap() {
                "u32" => json!(bits),
                "i32" => json!(bits as i32),
                _ => {
                    if materialize {
                        json!({"F32Bits":bits})
                    } else {
                        Value::Null
                    }
                }
            }
        }
        "u64" => {
            if body.len() != 8 {
                return Err(error());
            }
            json!(u64::from_le_bytes(body.try_into().unwrap()))
        }
        "string" | "int" | "id" | "enum" => {
            let text = std::str::from_utf8(body).map_err(|_| error())?;
            if t["kind"] == "int" && !decimal(text)
                || t["kind"] == "enum"
                    && !t["variants"]
                        .as_array()
                        .unwrap()
                        .iter()
                        .any(|v| v.as_str() == Some(text))
                || t["kind"] == "id"
                    && (text.len() != 32
                        || !text
                            .bytes()
                            .all(|b| b.is_ascii_hexdigit() && !b.is_ascii_uppercase()))
            {
                return Err(error());
            }
            if materialize {
                if t["kind"] == "int" {
                    json!({"Int":text})
                } else {
                    json!(text)
                }
            } else {
                Value::Null
            }
        }
        "list" | "vector" => {
            let n = u32_at(body, 0)? as usize;
            p = 4;
            if n > *budget
                || n > body.len().saturating_sub(4) / 4
                || t["kind"] == "vector" && Some(n as u64) != t["size"].as_u64()
            {
                return Err(error());
            }
            let mut xs = vec![];
            for _ in 0..n {
                if let Some(x) = walk(
                    s,
                    &t["element"],
                    body,
                    &mut p,
                    budget,
                    d + 1,
                    limits,
                    materialize,
                )? {
                    xs.push(x);
                }
            }
            if p != body.len() {
                return Err(error());
            }
            Value::Array(xs)
        }
        "record" => {
            let mut fields = serde_json::Map::new();
            for f in t["fields"].as_array().unwrap() {
                if let Some(x) = walk(
                    s,
                    &f["type"],
                    body,
                    &mut p,
                    budget,
                    d + 1,
                    limits,
                    materialize,
                )? {
                    fields.insert(f["name"].as_str().unwrap().into(), x);
                }
            }
            if p != body.len() {
                return Err(error());
            }
            Value::Object(fields)
        }
        "option" | "result" => {
            let b = *body.first().ok_or_else(error)?;
            if b > 1 {
                return Err(error());
            }
            p = 1;
            if t["kind"] == "option" && b == 0 {
                if body.len() != 1 {
                    return Err(error());
                }
                if materialize {
                    json!({"None":null})
                } else {
                    Value::Null
                }
            } else {
                let (tag, child) = if t["kind"] == "option" {
                    ("Some", &t["element"])
                } else if b == 0 {
                    ("Ok", &t["ok"])
                } else {
                    ("Err", &t["error"])
                };
                let x = walk(s, child, body, &mut p, budget, d + 1, limits, materialize)?;
                if p != body.len() {
                    return Err(error());
                }
                if let Some(x) = x {
                    json!({tag:x})
                } else {
                    Value::Null
                }
            }
        }
        _ => return Err(error()),
    };
    Ok(materialize.then_some(value))
}
/// Borrowed access to already structurally validated bytes. Rust borrowing
/// prevents mutation while this validation witness exists. No JSON tree is built.
#[derive(Clone, Copy)]
pub struct Validated<'a> {
    schema: &'a Schema,
    ty: &'a Value,
    bytes: &'a [u8],
    limits: Limits,
}
impl<'a> Validated<'a> {
    pub fn descriptor(&self) -> Result<&'a Value, String> {
        self.schema.resolve(self.ty)
    }
    pub fn limits(&self) -> Limits {
        self.limits
    }
    pub fn kind(&self) -> Result<&'a str, String> {
        self.schema.resolve(self.ty)?["kind"]
            .as_str()
            .ok_or("wire kind".into())
    }
    pub fn require_kind(&self, kind: &str) -> Result<(), String> {
        if self.kind()? == kind {
            Ok(())
        } else {
            Err("wire native type mismatch".into())
        }
    }
    pub fn require_name(&self, name: &str) -> Result<(), String> {
        if self.schema.resolve(self.ty)?["name"] == name {
            Ok(())
        } else {
            Err("wire nominal type mismatch".into())
        }
    }
    /// Scalar bytes or a container body; safe to borrow for the witness lifetime.
    pub fn body(&self) -> Result<&'a [u8], String> {
        let (a, b) = frame(self.bytes, 0)?;
        Ok(&self.bytes[a..b])
    }
    pub fn fields(&self) -> Result<Fields<'a>, String> {
        self.require_kind("record")?;
        let t = self.schema.resolve(self.ty)?;
        Ok(Fields {
            parent: *self,
            fields: t["fields"].as_array().unwrap().iter(),
            body: self.body()?,
            position: 0,
        })
    }
    pub fn payload(&self) -> &'a [u8] {
        self.bytes
    }
    pub fn materialize(&self) -> Result<Value, String> {
        let mut p = 0;
        walk(
            self.schema,
            self.ty,
            self.bytes,
            &mut p,
            &mut self.limits.nodes.clone(),
            0,
            self.limits,
            true,
        )?
        .ok_or("wire decode".into())
    }
    pub fn field(&self, name: &str) -> Result<Option<Self>, String> {
        let t = self.schema.resolve(self.ty)?;
        if t["kind"] != "record" {
            return Err("wire view is not a record".into());
        }
        let (start, end) = frame(self.bytes, 0)?;
        let body = &self.bytes[start..end];
        let mut p = 0;
        for f in t["fields"].as_array().unwrap() {
            let (_, next) = frame(body, p)?;
            if f["name"] == name {
                return Ok(Some(Self {
                    schema: self.schema,
                    ty: &f["type"],
                    bytes: &body[p..next],
                    limits: self.limits,
                }));
            }
            p = next;
        }
        Ok(None)
    }
    pub fn at(&self, index: usize) -> Result<Option<Self>, String> {
        let t = self.schema.resolve(self.ty)?;
        if t["kind"] != "list" && t["kind"] != "vector" {
            return Err("wire view is not a sequence".into());
        }
        let (start, end) = frame(self.bytes, 0)?;
        let body = &self.bytes[start..end];
        let n = u32_at(body, 0)? as usize;
        if index >= n {
            return Ok(None);
        }
        let mut p = 4;
        for i in 0..n {
            let (_, next) = frame(body, p)?;
            if i == index {
                return Ok(Some(Self {
                    schema: self.schema,
                    ty: &t["element"],
                    bytes: &body[p..next],
                    limits: self.limits,
                }));
            }
            p = next;
        }
        Ok(None)
    }
}

impl<'a> Validated<'a> {
    pub fn text(&self) -> Result<&'a str, String> {
        let t = self.schema.resolve(self.ty)?;
        if !["string", "int", "id", "enum"].contains(&t["kind"].as_str().unwrap_or("")) {
            return Err("wire view is not text".into());
        }
        let (a, b) = frame(self.bytes, 0)?;
        std::str::from_utf8(&self.bytes[a..b]).map_err(|e| e.to_string())
    }
    pub fn len(&self) -> Result<usize, String> {
        let t = self.schema.resolve(self.ty)?;
        if t["kind"] != "list" && t["kind"] != "vector" {
            return Err("wire view is not a sequence".into());
        }
        let (a, _) = frame(self.bytes, 0)?;
        Ok(u32_at(self.bytes, a)? as usize)
    }
    pub fn is_empty(&self) -> Result<bool, String> {
        Ok(self.len()? == 0)
    }
    pub fn variant(&self) -> Result<(bool, Option<Self>), String> {
        let t = self.schema.resolve(self.ty)?;
        if t["kind"] != "option" && t["kind"] != "result" {
            return Err("wire view is not a sum".into());
        }
        let (a, b) = frame(self.bytes, 0)?;
        let tag = self.bytes[a] == 1;
        if t["kind"] == "option" && !tag {
            return Ok((false, None));
        }
        let ty = if t["kind"] == "option" {
            &t["element"]
        } else if tag {
            &t["error"]
        } else {
            &t["ok"]
        };
        Ok((
            tag,
            Some(Self {
                schema: self.schema,
                ty,
                bytes: &self.bytes[a + 1..b],
                limits: self.limits,
            }),
        ))
    }
}

/// A single forward traversal over a validated sequence, without repeated scans.
pub struct Items<'a> {
    schema: &'a Schema,
    ty: &'a Value,
    body: &'a [u8],
    position: usize,
    left: usize,
    limits: Limits,
}
impl<'a> Iterator for Items<'a> {
    type Item = Result<Validated<'a>, String>;
    fn next(&mut self) -> Option<Self::Item> {
        if self.left == 0 {
            return None;
        }
        self.left -= 1;
        let at = self.position;
        Some(frame(self.body, at).map(|(_, end)| {
            self.position = end;
            Validated {
                schema: self.schema,
                ty: self.ty,
                bytes: &self.body[at..end],
                limits: self.limits,
            }
        }))
    }
}
impl<'a> Validated<'a> {
    pub fn items(&self) -> Result<Items<'a>, String> {
        let t = self.schema.resolve(self.ty)?;
        if t["kind"] != "list" && t["kind"] != "vector" {
            return Err("wire view is not a sequence".into());
        }
        let (a, b) = frame(self.bytes, 0)?;
        let body = &self.bytes[a..b];
        Ok(Items {
            schema: self.schema,
            ty: &t["element"],
            body,
            position: 4,
            left: u32_at(body, 0)? as usize,
            limits: self.limits,
        })
    }
}

/// Declaration-order record traversal without repeated name scans.
pub struct Fields<'a> {
    parent: Validated<'a>,
    fields: std::slice::Iter<'a, Value>,
    body: &'a [u8],
    position: usize,
}
impl<'a> Iterator for Fields<'a> {
    type Item = Result<Validated<'a>, String>;
    fn next(&mut self) -> Option<Self::Item> {
        let f = self.fields.next()?;
        let at = self.position;
        Some(frame(self.body, at).map(|(_, end)| {
            self.position = end;
            Validated {
                schema: self.parent.schema,
                ty: &f["type"],
                bytes: &self.body[at..end],
                limits: self.parent.limits,
            }
        }))
    }
}

/// Optional O(1) sequence access. Construction is a single scan; offsets are u32
/// because the authenticated wire is bounded to 16 MiB. The witness borrows it.
pub struct SequenceIndex<'a> {
    parent: Validated<'a>,
    offsets: Vec<u32>,
}
impl<'a> SequenceIndex<'a> {
    pub fn len(&self) -> usize {
        self.offsets.len()
    }
    pub fn is_empty(&self) -> bool {
        self.offsets.is_empty()
    }
    pub fn retained_bytes(&self) -> usize {
        self.offsets.capacity() * std::mem::size_of::<u32>()
    }
    pub fn at(&self, index: usize) -> Result<Option<Validated<'a>>, String> {
        let Some(&at) = self.offsets.get(index) else {
            return Ok(None);
        };
        let t = self.parent.schema.resolve(self.parent.ty)?;
        let body = self.parent.body()?;
        let (_, end) = frame(body, at as usize)?;
        Ok(Some(Validated {
            schema: self.parent.schema,
            ty: &t["element"],
            bytes: &body[at as usize..end],
            limits: self.parent.limits,
        }))
    }
}
impl<'a> Validated<'a> {
    pub fn index(&self) -> Result<SequenceIndex<'a>, String> {
        let items = self.items()?;
        let mut offsets = Vec::with_capacity(items.left);
        let mut at = 4usize;
        for item in items {
            let item = item?;
            offsets.push(u32::try_from(at).map_err(|_| "wire index offset")?);
            at += item.bytes.len();
        }
        Ok(SequenceIndex {
            parent: *self,
            offsets,
        })
    }
}

}
pub use value_wire::Limits as ValueWireLimits;
pub const INK_WIRE_CONTRACT:&str=include_str!("wire.json");
// Generic pure-call binary boundary. Types and schema identities are emitted
// from the complete checked source. This adapter does no networking.
impl State {
 fn binary_schema_map()->&'static std::collections::BTreeMap<String,(value_wire::Schema,value_wire::Schema)>{
  static SCHEMAS:std::sync::OnceLock<std::collections::BTreeMap<String,(value_wire::Schema,value_wire::Schema)>>=std::sync::OnceLock::new();
  SCHEMAS.get_or_init(||{
   let manifest:Json=serde_json::from_str(INK_WIRE_CONTRACT).expect("compiled wire metadata");
   manifest["functions"].as_object().expect("compiled functions").iter().filter(|(_,v)|v.get("unsupported").is_none()).map(|(name,v)|{
    (name.clone(),(value_wire::Schema::from_descriptor(&v["arguments"]).expect("compiled argument schema"),value_wire::Schema::from_descriptor(&v["result"]).expect("compiled result schema")))
   }).collect()
  })
 }
 pub fn binary_schemas(name:&str)->Result<&'static (value_wire::Schema,value_wire::Schema),String>{Self::binary_schema_map().get(name).ok_or("unsupported binary function".into())}
 pub fn binary_function(index:u32)->Result<&'static str,String>{Self::binary_schema_map().keys().nth(index as usize).map(String::as_str).ok_or("unknown binary function index".into())}

 pub fn validate_binary_arguments<'a>(name:&str,bytes:&'a[u8],limits:ValueWireLimits)->Result<value_wire::Validated<'a>,String>{Self::binary_schemas(name)?.0.validate(bytes,limits)}
 pub fn call_binary(&mut self,name:&str,bytes:&[u8],limits:ValueWireLimits)->Result<Vec<u8>,String>{
  let (input,output)=Self::binary_schemas(name)?;
  let record=input.validate(bytes,limits)?;
  self.binary_call_frame(name,record,output,limits)
 }
}
// Direct portable frames for the ordinary C value runtime. No document carrier.
fn binary_dynamic_value(view:value_wire::Validated<'_>)->R<V>{
 let t=view.descriptor()?;
 Ok(match view.kind()?{
  "unit"=>V::Unit,
  "bool"=>V::Bool(view.body()?[0]!=0),
  "u32"=>V::U32(u32::from_le_bytes(view.body()?.try_into().unwrap())),
  "u64"=>V::U64(u64::from_le_bytes(view.body()?.try_into().unwrap())),
  "i32"=>V::I32(i32::from_le_bytes(view.body()?.try_into().unwrap())),
  "f32"=>V::F32(u32::from_le_bytes(view.body()?.try_into().unwrap())),
  "int"=>{let text=view.text()?;if text.len()>1000000{return Err("Int input exceeds resource limit".into());}V::Int(text.parse().map_err(|_|"binary Int")?)},
  "string"=>V::String(view.text()?.into()),
  "enum"=>V::Enum(view.text()?.into()),
  "id"=>V::Id(t["name"].as_str().unwrap().into(),u128::from_str_radix(view.text()?,16).map_err(|_|"binary ID")?),
  "record"=>V::Record(t["name"].as_str().unwrap().into(),t["fields"].as_array().unwrap().iter().zip(view.fields()?).map(|(f,x)|Ok((f["name"].as_str().unwrap().into(),binary_dynamic_value(x?)?))).collect::<R<_>>()?),
  "list"=>V::List(view.items()?.map(|x|binary_dynamic_value(x?)).collect::<R<_>>()?),
  "vector"=>V::Vector(view.items()?.map(|x|binary_dynamic_value(x?)).collect::<R<_>>()?),
  "option"=>{let(_,child)=view.variant()?;V::Option(child.map(|x|binary_dynamic_value(x).map(Box::new)).transpose()?)},
  "result"=>{let(err,child)=view.variant()?;V::Result(!err,Box::new(binary_dynamic_value(child.ok_or("binary result payload")?)?))},
  _=>return Err("unsupported binary value".into()),
 })
}
fn binary_dynamic_write(s:&value_wire::Schema,t:&Json,v:&V,w:&mut value_wire::Encoder)->R<()>{
 let t=s.resolve(t)?;
 w.frame(|w|{
  match (t["kind"].as_str().unwrap(),v){
   ("unit",V::Unit)=>{},("bool",V::Bool(b))=>w.bytes(&[u8::from(*b)])?,
   ("u32",V::U32(n))=>w.bytes(&n.to_le_bytes())?,("u64",V::U64(n))=>w.bytes(&n.to_le_bytes())?,
   ("i32",V::I32(n))=>w.bytes(&n.to_le_bytes())?,("f32",V::F32(n))=>w.bytes(&n.to_le_bytes())?,
   ("int",V::Int(n))=>w.bytes(n.to_string().as_bytes())?,
   ("string",V::String(n))|("enum",V::Enum(n))=>w.bytes(n.as_bytes())?,
   ("id",V::Id(_,n))=>w.bytes(format!("{n:032x}").as_bytes())?,
   ("record",V::Record(_,fs))=>{for f in t["fields"].as_array().unwrap(){binary_dynamic_write(s,&f["type"],fs.get(f["name"].as_str().unwrap()).ok_or("binary result field")?,w)?;}},
   ("list",V::List(xs))|("vector",V::Vector(xs))=>{w.word(xs.len().try_into().map_err(|_|"binary sequence size")?)?;for x in xs{binary_dynamic_write(s,&t["element"],x,w)?;}},
   ("option",V::Option(None))=>w.bytes(&[0])?,
   ("option",V::Option(Some(x)))=>{w.bytes(&[1])?;binary_dynamic_write(s,&t["element"],x,w)?;},
   ("result",V::Result(ok,x))=>{w.bytes(&[u8::from(!ok)])?;binary_dynamic_write(s,if *ok{&t["ok"]}else{&t["error"]},x,w)?;},
   _=>return Err("binary result type mismatch".into()),
  }Ok(())
 })
}
impl State{
 fn binary_pure_index(&mut self,index:usize,captured:Vec<V>)->R<V>{
  self.ctx.values.clear();self.ctx.arena_bytes=0;self.ctx.error=None;self.ctx.fuel=100000000;self.ctx.staged.clear();
  let handles=captured.into_iter().map(|v|self.ctx.put(v)).collect::<Vec<_>>();
  let result=(||{
   if self.ctx.error.is_some(){return Err("Ink value arena limit exceeded".into());}
   let h=unsafe{ink_program_call((&mut *self.ctx as *mut InkContext).cast(),0,index as u32,handles.as_ptr(),handles.len())};
   if let Some(e)=self.ctx.error.take(){return Err(match e{Failure::Host(e)=>e,Failure::Abort(_)=>"unhandled domain error".into()});}
   self.ctx.value(h)
  })();
  self.ctx.values.clear();self.ctx.arena_bytes=0;result
 }
 fn binary_call_frame(&mut self,name:&str,record:value_wire::Validated<'_>,output:&value_wire::Schema,limits:ValueWireLimits)->R<Vec<u8>>{
  let declarations=self.ctx.meta["functions"].as_array().ok_or("compiled functions")?;
  let(index,d)=declarations.iter().enumerate().find(|(_,d)|d["name"]==name).ok_or("unknown binary function")?;
  if d["internal"].as_bool()==Some(true){return Err("temporary storage is internal to a pure invocation".into());}
  let guard=d["precondition"].as_str().map(|name|declarations.iter().position(|d|d["name"]==name).ok_or("compiled precondition")).transpose()?;
  let captured=record.fields()?.map(|x|binary_dynamic_value(x?)).collect::<R<Vec<_>>>()?;
  if let Some(guard)=guard{if self.binary_pure_index(guard,captured.clone())?!=V::Bool(true){return Err("contract precondition failed".into());}}
  let result=self.binary_pure_index(index,captured)?;
  output.encode_with(limits,|w|binary_dynamic_write(output,output.root(),&result,w))
 }
}
// Appended verbatim to generated applications. This is a host ABI, not an optimiser.
mod state_wasm {
    use super::*;
    use std::cell::RefCell;
    const MAX_BUFFER: usize = 64 * 1024 * 1024;
    const MAX_TOTAL: usize = 128 * 1024 * 1024;
    const MAX_JSON: usize = 4 * 1024 * 1024;
    const MAX_BUFFERS: usize = 256;
    const MAX_STATES: usize = 128;
    struct Registry {
        next: u32,
        states: BTreeMap<u32, State>,
        buffers: BTreeMap<u32, Vec<u8>>,
        bytes: usize,
        error: String,
    }
    impl Registry {
        fn new() -> Self {
            Self {
                next: 0,
                states: BTreeMap::new(),
                buffers: BTreeMap::new(),
                bytes: 0,
                error: String::new(),
            }
        }
        fn id(&mut self) -> Result<u32, String> {
            self.next = self
                .next
                .checked_add(1)
                .ok_or("ABI handle sequence exhausted")?;
            Ok(self.next)
        }
        fn fail(&mut self, error: impl Into<String>) -> u32 {
            self.error = error.into();
            0
        }
        fn insert_buffer(&mut self, bytes: Vec<u8>) -> Result<u32, String> {
            if bytes.len() > MAX_BUFFER
                || self.buffers.len() >= MAX_BUFFERS
                || self
                    .bytes
                    .checked_add(bytes.len())
                    .is_none_or(|n| n > MAX_TOTAL)
            {
                return Err("ABI buffer limit".into());
            }
            let id = self.id()?;
            self.bytes += bytes.len();
            self.buffers.insert(id, bytes);
            Ok(id)
        }
        fn reserve_output(&mut self) -> Result<u32, String> {
            // Reserve an output slot and enough accounting space before a change.
            if self
                .bytes
                .checked_add(MAX_BUFFER)
                .is_none_or(|n| n > MAX_TOTAL)
            {
                return Err("ABI output capacity unavailable".into());
            }
            self.insert_buffer(Vec::new())
        }
        fn finish(&mut self, id: u32, bytes: Vec<u8>) -> u32 {
            self.bytes += bytes.len();
            *self.buffers.get_mut(&id).expect("reserved output slot") = bytes;
            id
        }
        fn envelope(&mut self, id: u32, result: Result<Json, String>, committed: bool) -> u32 {
            let payload = match result {
                Ok(value) => serde_json::json!({"ok":value}),
                Err(message) => {
                    serde_json::json!({"error":{"message":message,"committed":committed}})
                }
            };
            let mut bytes = serde_json::to_vec(&payload).expect("JSON value serialization");
            if bytes.len() > MAX_BUFFER {
                bytes=serde_json::to_vec(&serde_json::json!({"error":{"message":"ABI response exceeds 64 MiB","committed":committed}})).expect("JSON error serialization");
            }
            self.finish(id, bytes)
        }
    }
    thread_local! {static REGISTRY:RefCell<Registry>=RefCell::new(Registry::new());}
    #[no_mangle]
    pub extern "C" fn lang_abi_version() -> u32 {
        1
    }
    #[no_mangle]
    pub extern "C" fn lang_buffer_alloc(length: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            let length = length as usize;
            if length > MAX_BUFFER
                || r.buffers.len() >= MAX_BUFFERS
                || r.bytes.checked_add(length).is_none_or(|n| n > MAX_TOTAL)
            {
                return r.fail("ABI buffer limit");
            }
            match r.insert_buffer(vec![0; length]) {
                Ok(id) => id,
                Err(e) => r.fail(e),
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_buffer_ptr(handle: u32) -> usize {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            match r.buffers.get(&handle) {
                Some(bytes) => bytes.as_ptr() as usize,
                None => r.fail("unknown buffer handle") as usize,
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_buffer_len(handle: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            match r.buffers.get(&handle) {
                Some(bytes) => bytes.len() as u32,
                None => r.fail("unknown buffer handle"),
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_buffer_free(handle: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            match r.buffers.remove(&handle) {
                Some(bytes) => {
                    r.bytes -= bytes.len();
                    1
                }
                None => r.fail("unknown buffer handle"),
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_error() -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            let bytes = r.error.as_bytes().to_vec();
            match r.insert_buffer(bytes) {
                Ok(id) => id,
                Err(_) => 0,
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_init() -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            if r.states.len() >= MAX_STATES {
                return r.fail("ABI state handle limit");
            }
            match r.id() {
                Ok(id) => {
                    r.states.insert(id, State::new());
                    id
                }
                Err(e) => r.fail(e),
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_state_drop(handle: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            if r.states.remove(&handle).is_some() {
                1
            } else {
                r.fail("unknown state handle")
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_restore(buffer: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            if r.states.len() >= MAX_STATES {
                return r.fail("ABI state handle limit");
            }
            let id = match r.id() {
                Ok(id) => id,
                Err(e) => return r.fail(e),
            };
            let Some(bytes) = r.buffers.get(&buffer) else {
                return r.fail("unknown buffer handle");
            };
            match State::restore(bytes) {
                Ok(state) => {
                    r.states.insert(id, state);
                    id
                }
                Err(e) => r.fail(e),
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_checkpoint(state: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            let id = match r.reserve_output() {
                Ok(id) => id,
                Err(e) => return r.fail(e),
            };
            let result = r
                .states
                .get(&state)
                .ok_or_else(|| "unknown state handle".to_string())
                .and_then(|s| s.checkpoint());
            match result {
                Ok(bytes) => r.finish(id, bytes),
                Err(e) => {
                    r.buffers.remove(&id);
                    r.fail(e)
                }
            }
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_invoke(state: u32, request: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            let id = match r.reserve_output() {
                Ok(id) => id,
                Err(e) => return r.fail(e),
            };
            let result = (|| -> Result<Json, String> {
                let bytes = r.buffers.get(&request).ok_or("unknown buffer handle")?;
                if bytes.len() > MAX_JSON {
                    return Err("ABI request exceeds 4 MiB".into());
                }
                let message: Json = serde_json::from_slice(bytes).map_err(|e| e.to_string())?;
                let pure = message.get("pure").and_then(Json::as_str);
                let name = pure
                    .or_else(|| message.get("call").and_then(Json::as_str))
                    .ok_or("request needs call or pure")?;
                let args = message.get("args").ok_or("request needs args")?;
                let state = r.states.get_mut(&state).ok_or("unknown state handle")?;
                if pure.is_some() {
                    state.call_json(name, args)
                } else {
                    state.invoke_json(name, args)
                }
            })();
            let committed = result
                .as_ref()
                .ok()
                .and_then(|v| v.get("committed"))
                .and_then(Json::as_bool)
                .unwrap_or(false);
            r.envelope(id, result, committed)
        })
    }
    // A generic raw-byte operation boundary. The optional value-wire export
    // supplies the operation; representation runtimes need no value-wire code.
    pub(crate) fn invoke_bytes(state:u32,request:u32,operation:impl FnOnce(&mut State,&[u8])->Result<Vec<u8>,String>)->u32{
        REGISTRY.with(|registry|{
            let mut r=registry.borrow_mut();
            let id=match r.reserve_output(){Ok(id)=>id,Err(e)=>return r.fail(e)};
            let result=(||{
                let Registry{states,buffers,..}=&mut *r;
                let bytes=buffers.get(&request).ok_or("unknown buffer handle")?;
                operation(states.get_mut(&state).ok_or("unknown state handle")?,bytes)
            })();
            match result{Ok(bytes) if bytes.len()<=MAX_BUFFER=>r.finish(id,bytes),Ok(_)=>{r.buffers.remove(&id);r.fail("ABI binary output limit")},Err(e)=>{r.buffers.remove(&id);r.fail(e)}}
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_events(state: u32) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            let id = match r.reserve_output() {
                Ok(id) => id,
                Err(e) => return r.fail(e),
            };
            let result = r
                .states
                .get(&state)
                .ok_or_else(|| "unknown state handle".into())
                .map(|s| Json::Array(s.outbox().iter().map(Event::to_json).collect()));
            r.envelope(id, result, false)
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_acknowledge(state: u32, commit: u64, position: u64) -> u32 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            match r.states.get_mut(&state) {
                Some(s) => {
                    s.acknowledge_through(commit, position);
                    1
                }
                None => r.fail("unknown state handle"),
            }
        })
    }
    // Optional ABI-v1 retained-operation extension. Older hosts may ignore it.
    #[no_mangle]
    pub extern "C" fn lang_transaction_begin(state:u32)->u32 {
        REGISTRY.with(|r| {let mut r=r.borrow_mut();
            let result=r.states.get_mut(&state).ok_or_else(||"unknown state handle".to_owned()).and_then(|s|s.begin_transaction());
            match result {Ok(true)=>1,Ok(false)=>2,Err(e)=>r.fail(e)}
        })
    }
    #[no_mangle]
    pub extern "C" fn lang_transaction_commit(state:u32)->u32 {
        REGISTRY.with(|r| {let mut r=r.borrow_mut();match r.states.get_mut(&state){Some(s)=>{s.commit_transaction();1},None=>r.fail("unknown state handle")}})
    }
    #[no_mangle]
    pub extern "C" fn lang_transaction_rollback(state:u32)->u32 {
        REGISTRY.with(|r| {let mut r=r.borrow_mut();match r.states.get_mut(&state){Some(s)=>{s.rollback_transaction();1},None=>r.fail("unknown state handle")}})
    }
    #[no_mangle]
    pub extern "C" fn lang_version(state: u32) -> u64 {
        REGISTRY.with(|r| {
            let mut r = r.borrow_mut();
            match r.states.get(&state) {
                Some(s) => s.version(),
                None => {
                    r.fail("unknown state handle");
                    0
                }
            }
        })
    }
}

// Per-instance task transport is separate from the state-handle registry. Host
// scheduling can re-enter this ABI without borrowing or publishing transaction state.
#[cfg(target_arch="wasm32")]
thread_local! {static PARALLEL_IO:std::cell::RefCell<Vec<u8>>=const{std::cell::RefCell::new(Vec::new())};}
#[cfg(target_arch="wasm32")]
#[link(wasm_import_module="ink_parallel")]
unsafe extern "C" {#[link_name="run"] fn __ink_parallel_import(ptr:u32,len:u32)->u32;}
#[cfg(target_arch="wasm32")]
fn __ink_parallel_host(task:Json)->Result<Json,String>{
    let bytes=serde_json::to_vec(&task).map_err(|e|e.to_string())?;
    if bytes.len()>64*1024*1024{return Err("parallel request limit".into());}
    let length=unsafe{__ink_parallel_import(bytes.as_ptr() as u32,bytes.len() as u32)};
    PARALLEL_IO.with(|io|{let io=io.borrow();if length as usize!=io.len(){return Err("parallel response length".into());}let reply:Json=serde_json::from_slice(&io).map_err(|e|e.to_string())?;if let Some(error)=reply["error"].as_str(){return Err(error.into());}reply.get("ok").cloned().ok_or("parallel response envelope".into())})
}
#[cfg(target_arch="wasm32")]
#[no_mangle]
pub extern "C" fn lang_parallel_alloc(len:u32)->u32{if len>64*1024*1024{return 0;}PARALLEL_IO.with(|io|{let mut io=io.borrow_mut();io.resize(len as usize,0);io.as_mut_ptr() as u32})}
#[cfg(target_arch="wasm32")]
#[no_mangle]
pub extern "C" fn lang_parallel_ptr()->u32{PARALLEL_IO.with(|io|io.borrow().as_ptr() as u32)}
#[cfg(target_arch="wasm32")]
#[no_mangle]
pub unsafe extern "C" fn lang_parallel_worker(ptr:u32,len:u32)->u32{
    let result=(||->Result<Json,String>{if len>64*1024*1024{return Err("parallel request limit".into());}let task:Json=serde_json::from_slice(std::slice::from_raw_parts(ptr as *const u8,len as usize)).map_err(|e|e.to_string())?;State::new().parallel_worker(&task)})();
    let reply=match result{Ok(v)=>json!({"ok":v}),Err(e)=>json!({"error":e})};
    let bytes=serde_json::to_vec(&reply).expect("parallel response");if bytes.len()>64*1024*1024{return 0;}
    let len=bytes.len() as u32;PARALLEL_IO.with(|io|*io.borrow_mut()=bytes);len
}
// Optional raw binary extension. Arguments and results bind compiled schemas;
// the existing registry owns handles and reports UTF-8 errors through lang_error.
#[no_mangle]
pub extern "C" fn lang_call_binary(state:u32,function:u32,arguments:u32)->u32{
 state_wasm::invoke_bytes(state,arguments,|s,bytes|s.call_binary(State::binary_function(function)?,bytes,ValueWireLimits::default()))
}
#[cfg(not(target_arch = "wasm32"))]
pub mod durable;
#[cfg(not(target_arch = "wasm32"))]
impl durable::CompiledState for State {
    fn create() -> Self {
        Self::new()
    }
    fn restore(bytes: &[u8]) -> Result<Self, String> {
        Self::restore(bytes)
    }
    fn checkpoint(&self) -> Result<Vec<u8>, String> {
        self.checkpoint()
    }
    fn invoke(
        &mut self,
        call: &str,
        args: &serde_json::Value,
    ) -> Result<serde_json::Value, String> {
        self.invoke_json(call, args)
    }
    fn pure(&mut self, call: &str, args: &serde_json::Value) -> Result<serde_json::Value, String> {
        self.call_json(call, args)
    }
    fn events(&self) -> Vec<serde_json::Value> {
        self.outbox().iter().map(Event::to_json).collect()
    }
    fn acknowledge(&mut self, commit: u64, position: u64) {
        self.acknowledge_through(commit, position)
    }
    fn begin_transaction(&mut self) -> Result<bool, String> {
        self.begin_transaction()
    }
    fn commit_transaction(&mut self) {
        self.commit_transaction()
    }
    fn rollback_transaction(&mut self) {
        self.rollback_transaction()
    }
    fn version(&self) -> u64 {
        self.version()
    }
}
#[cfg(not(target_arch = "wasm32"))]
pub type DurableState = durable::Host<State, durable::FileStore>;
