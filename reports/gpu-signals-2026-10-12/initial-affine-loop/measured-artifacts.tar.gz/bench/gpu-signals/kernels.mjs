// Exact wrapping-u32 controls. All calls return fresh owned output containers.
export function kernel(xs,kind){
 if(kind==='cheap-sum'){let sum=0;for(let k=0;k<xs.length;k++)sum=(sum+((Math.imul(xs[k],17)+1)>>>0))>>>0;return sum;}
 const out=new Array(xs.length),rounds=kind==='feedback32'?32:1,steps=kind==='heavy512'?512:64;
 for(let k=0;k<xs.length;k++){
  let v=xs[k];
  if(kind==='affine')v=(Math.imul(v,17)+1)>>>0;
  else for(let r=0;r<rounds;r++)for(let i=0;i<steps;i++)v=(Math.imul(v,1664525)+1013904223+i)>>>0;
  out[k]=v;
 }
 return out;
}
export const data=(n,seed)=>Uint32Array.from({length:n},(_,i)=>(Math.imul(i,2654435761)+seed)>>>0);
