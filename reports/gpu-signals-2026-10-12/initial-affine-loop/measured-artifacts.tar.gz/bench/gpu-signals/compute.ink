module GpuSignals;
fn cheap(xs:List<u32>)->u32 {return sum(xs.map(fn(x)=>x*17+1));}
fn heavy(xs:List<u32>)->List<u32> {return xs.map(fn(x)=>repeat(512,x,fn(i)=>fn(v)=>v*1664525+1013904223+i));}
fn total(xs:List<u32>)->u32 {return sum(xs);}
fn step(xs:List<u32>)->List<u32> {return xs.map(fn(x)=>repeat(64,x,fn(i)=>fn(v)=>v*1664525+1013904223+i));}
fn affine(xs:List<u32>)->List<u32> {return xs.map(fn(x)=>x*17+1);}
