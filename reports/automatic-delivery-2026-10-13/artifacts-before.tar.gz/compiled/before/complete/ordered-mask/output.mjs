function __fn0(v0,v1){
const v2=v0;
const v3=v2.length;
const v4=[];
for(let v5=0;v5<v3;v5++){
const v6=v2[v5];
const v7=v6;
const v8=v1;
if(((v7) >= (v8))){v4.push(v6);}
}
const v9=v4;
const v10=v9.length;
const v11=new Array(v10);
for(let v12=0;v12<v10;v12++){
const v13=v9[v12];
const v14=v13;
const v15=13;
const v16=(Math.imul(v14,v15) >>> 0);
const v17=7;
v11[v12]=(((v16) + (v17)) >>> 0);
}
const v18=v11;
let v19=19;
for(let v20=0;v20<v18.length;v20++){
const v21=v18[v20];
const v22=v21;
const v23=v19;
v19=(((v22) - (v23)) >>> 0);
}
return v19;}
const __namedTypes={};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"b1ec27d9a84ae3ac3b90f14ce9ffe807e8ce25c3b5ed5e4ae6c5688f830b60b2","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":null,"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"cut","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"u32"}}],"named_types":{},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[null];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
