function __fn0(v0,v1){
const v2=v0;
const v3=v2.length;
const v4=[];
for(let v5=0;v5<v3;v5++){
const v6=v2[v5];
const v7=v6;
if(v7["valid"]){v4.push(v6);}
}
const v8=v4;
const v9=v8.length;
const v10=new Array(v9);
for(let v11=0;v11<v9;v11++){
const v12=v8[v11];
const v13=v12;
const v14=v13["value"];
const v15=v1;
v10[v11]=((v14) > (v15));
}
const v16=v10;
let v17=false;
for(let v18=0;v18<v16.length;v18++){
const v19=v16[v18];
const v20=v17;
let v21=v20;if(!v21){
v21=v19;}
v17=v21;
}
return v17;}
const __namedTypes={"Reading":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"valid","type":{"kind":"bool"}},{"name":"channel","type":{"kind":"u32"}}],"kind":"record","name":"Reading"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"8b04f64772f35d6084251741c966d819953f9c6d38f969d9ebd2ddfda0cf0c9a","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":null,"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"valid","type":{"kind":"bool"}},{"name":"channel","type":{"kind":"u32"}}],"kind":"record","name":"Reading"},"kind":"list"}},{"name":"cut","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"bool"}}],"named_types":{"Reading":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"valid","type":{"kind":"bool"}},{"name":"channel","type":{"kind":"u32"}}],"kind":"record","name":"Reading"}},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[null];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
