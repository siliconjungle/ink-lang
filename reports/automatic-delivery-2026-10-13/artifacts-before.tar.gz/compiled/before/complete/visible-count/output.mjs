function __fn0(v0,v1){
const v2=v0;
const v3=v2.length;
const v4=[];
for(let v5=0;v5<v3;v5++){
const v6=v2[v5];
const v7=v6;
const v8=v7["visible"];
let v9=v8;if(v9){
const v10=v6;
const v11=v10["opacity"];
const v12=v1;
v9=((v11) >= (v12));}
if(v9){v4.push(v6);}
}
const v13=v4;
const v14=v13.length;
const v15=new Array(v14);
for(let v16=0;v16<v14;v16++){
const v17=v13[v16];
const v18=v17;
v15[v16]=v18["id"];
}
return (v15).length;}
const __namedTypes={"Layer":{"fields":[{"name":"id","type":{"kind":"u32"}},{"name":"opacity","type":{"kind":"u32"}},{"name":"visible","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}}],"kind":"record","name":"Layer"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v3","core_sha256":"dccb19fc01efd3b60bc3ba7b7a8a6c3edd9650c64bd1a73fcc245b152038c211","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":null,"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"fields":[{"name":"id","type":{"kind":"u32"}},{"name":"opacity","type":{"kind":"u32"}},{"name":"visible","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}}],"kind":"record","name":"Layer"},"kind":"list"}},{"name":"cut","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"u32"}}],"named_types":{"Layer":{"fields":[{"name":"id","type":{"kind":"u32"}},{"name":"opacity","type":{"kind":"u32"}},{"name":"visible","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}}],"kind":"record","name":"Layer"}},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[null];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
