function __fn0(v0){
const v1=v0;
const v2=v1.length;
const v3=[];
for(let v4=0;v4<v2;v4++){
const v5=v1[v4];
const v6=v5;
if(v6["valid"]){v3.push(v5);}
}
const v7=v3;
const v8=v7.length;
const v9=new Array(v8);
for(let v10=0;v10<v8;v10++){
const v11=v7[v10];
const v12=v11;
v9[v10]=v12["value"];
}
const v13=v9;
let v14=0;
for(let v15=0;v15<v13.length;v15++){
const v16=v13[v15];
const v17=v14;
const v18=v16;
v14=(((v17) + (v18)) >>> 0);
}
return v14;}
const __namedTypes={"Reading":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"valid","type":{"kind":"bool"}},{"name":"channel","type":{"kind":"u32"}}],"kind":"record","name":"Reading"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"e76c21912a2b130b3415f64cc7d3690ec7d77a3a886b308ee78c2ecf5e21f72a","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":null,"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"valid","type":{"kind":"bool"}},{"name":"channel","type":{"kind":"u32"}}],"kind":"record","name":"Reading"},"kind":"list"}}],"precondition":null,"result":{"kind":"u32"}}],"named_types":{"Reading":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"valid","type":{"kind":"bool"}},{"name":"channel","type":{"kind":"u32"}}],"kind":"record","name":"Reading"}},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[null];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
