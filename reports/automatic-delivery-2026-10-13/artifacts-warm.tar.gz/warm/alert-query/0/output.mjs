function __fn0(v0,v1){
const v2=v0;
let v3=false;
for(let v4=0;v4<v2.length;v4++){
const v5=v2[v4];
const v6=v5;
const v7=v6;
let v8;if(v7["valid"]){
const v9=v5;
const v10=v9;
const v11=v10["value"];
const v12=v1;
const v13=((v11) > (v12));
const v14=v3;
const v15=v14;
let v16=v15;if(!v16){
v16=v13;}
v8=v16;}else{
v8=v3;}
v3=v8;
}
return v3;}
const __namedTypes={"Reading":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"valid","type":{"kind":"bool"}},{"name":"channel","type":{"kind":"u32"}}],"kind":"record","name":"Reading"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"4c8562e2f8bba0c4f68313e4f3dd8abfd21e6e74a9b7108c8473ae8352b7e4b7","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":null,"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"valid","type":{"kind":"bool"}},{"name":"channel","type":{"kind":"u32"}}],"kind":"record","name":"Reading"},"kind":"list"}},{"name":"cut","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"bool"}}],"named_types":{"Reading":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"valid","type":{"kind":"bool"}},{"name":"channel","type":{"kind":"u32"}}],"kind":"record","name":"Reading"}},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[null];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
