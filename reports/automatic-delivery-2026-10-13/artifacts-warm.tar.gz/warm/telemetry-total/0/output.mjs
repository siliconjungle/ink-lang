function __fn0(v0){
const v1=v0;
let v2=0;
for(let v3=0;v3<v1.length;v3++){
const v4=v1[v3];
const v5=v4;
const v6=v5;
let v7;if(v6["valid"]){
const v8=v4;
const v9=v8;
const v10=v9["value"];
const v11=v2;
const v12=v11;
const v13=v10;
v7=(((v12) + (v13)) >>> 0);}else{
v7=v2;}
v2=v7;
}
return v2;}
const __namedTypes={"Reading":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"valid","type":{"kind":"bool"}},{"name":"channel","type":{"kind":"u32"}}],"kind":"record","name":"Reading"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"970a3d4dfdff29918310223897e6f83e26d35705fc0ceb14d920e1731170e0d4","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":null,"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"valid","type":{"kind":"bool"}},{"name":"channel","type":{"kind":"u32"}}],"kind":"record","name":"Reading"},"kind":"list"}}],"precondition":null,"result":{"kind":"u32"}}],"named_types":{"Reading":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"valid","type":{"kind":"bool"}},{"name":"channel","type":{"kind":"u32"}}],"kind":"record","name":"Reading"}},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[null];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
