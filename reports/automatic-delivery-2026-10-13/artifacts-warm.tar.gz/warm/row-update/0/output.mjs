function __fn0(v0,v1){
const v2=v0;
const v3=v2.length;
const v4=new Array(v3);
for(let v5=0;v5<v3;v5++){
const v6=v2[v5];
const v7=v6;
const v8=v7["id"];
const v9=v6;
let v10;if(v9["visible"]){
const v11=v6;
const v12=v11["opacity"];
const v13=v1;
v10=(((v12) + (v13)) >>> 0);}else{
const v14=v6;
v10=v14["opacity"];}
const v15=v10;
const v16=v6;
const v17=v16["visible"];
const v18=v6;
const v19=v18["label"];
v4[v5]=({["id"]:v8,["opacity"]:v15,["visible"]:v17,["label"]:v19});
}
return v4;}
function __into0(v20,v21,v22){
const v23=v20;
const v24=v23.length;
for(let v26=0;v26<v24;v26++){
const v27=v23[v26];
const v28=v27;
const v29=v28["id"];
const v30=v27;
let v31;if(v30["visible"]){
const v32=v27;
const v33=v32["opacity"];
const v34=v21;
v31=(((v33) + (v34)) >>> 0);}else{
const v35=v27;
v31=v35["opacity"];}
const v36=v31;
const v37=v27;
const v38=v37["visible"];
const v39=v27;
const v40=v39["label"];
v22[v26]=({["id"]:v29,["opacity"]:v36,["visible"]:v38,["label"]:v40});
}
return v24;}
const __namedTypes={"Layer":{"fields":[{"name":"id","type":{"kind":"u32"}},{"name":"opacity","type":{"kind":"u32"}},{"name":"visible","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}}],"kind":"record","name":"Layer"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v2","core_sha256":"f99fbcd148ea9a6564e516c37be348e07867dce379c0984618bd89a32fadaeb8","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"fields":[{"name":"id","type":{"kind":"u32"}},{"name":"opacity","type":{"kind":"u32"}},{"name":"visible","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}}],"kind":"record","name":"Layer"},"kind":"list"}},{"name":"delta","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"fields":[{"name":"id","type":{"kind":"u32"}},{"name":"opacity","type":{"kind":"u32"}},{"name":"visible","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}}],"kind":"record","name":"Layer"},"kind":"list"}}],"named_types":{"Layer":{"fields":[{"name":"id","type":{"kind":"u32"}},{"name":"opacity","type":{"kind":"u32"}},{"name":"visible","type":{"kind":"bool"}},{"name":"label","type":{"kind":"string"}}],"kind":"record","name":"Layer"}},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[__into0];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
