function __fn0(v0,v1){
const v2=v0;
let v3=19;
for(let v4=0;v4<v2.length;v4++){
const v5=v2[v4];
const v6=v5;
const v7=v6;
const v8=v1;
let v9;if(((v7) >= (v8))){
const v10=v5;
const v11=v10;
const v12=13;
const v13=(Math.imul(v11,v12) >>> 0);
const v14=7;
const v15=(((v13) + (v14)) >>> 0);
const v16=v3;
const v17=v15;
const v18=v16;
v9=(((v17) - (v18)) >>> 0);}else{
v9=v3;}
v3=v9;
}
return v3;}
const __namedTypes={};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"522a9ebb0d15342bec600fef1a81c81c03a8c4903082a6cc92a14f0e7c7d1d93","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":null,"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"u32"},"kind":"list"}},{"name":"cut","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"u32"}}],"named_types":{},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[null];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
