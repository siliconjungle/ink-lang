function __fn0(v0){
const v1=v0;
const v2=v1.length;
const v3=new Array(v2);
for(let v4=0;v4<v2;v4++){
const v5=v1[v4];
const v6=v5;
v3[v4]=v6["channel"];
}
return v3;}
function __into0(v7,v8){
const v9=v7;
const v10=v9.length;
for(let v12=0;v12<v10;v12++){
const v13=v9[v12];
const v14=v13;
v8[v12]=v14["channel"];
}
return v10;}
const __namedTypes={"Reading":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"valid","type":{"kind":"bool"}},{"name":"channel","type":{"kind":"u32"}}],"kind":"record","name":"Reading"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v2","core_sha256":"a8b6eaec064c57340345e5380e14181f129e4e7dbf5f7ce756446ad0819c5205","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"valid","type":{"kind":"bool"}},{"name":"channel","type":{"kind":"u32"}}],"kind":"record","name":"Reading"},"kind":"list"}}],"precondition":null,"result":{"element":{"kind":"u32"},"kind":"list"}}],"named_types":{"Reading":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"valid","type":{"kind":"bool"}},{"name":"channel","type":{"kind":"u32"}}],"kind":"record","name":"Reading"}},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[__into0];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
