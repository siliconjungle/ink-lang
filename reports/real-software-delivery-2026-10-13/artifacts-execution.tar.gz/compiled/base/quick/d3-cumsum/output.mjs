function __fn0(v0){
const v1=v0;
const v2=0;
const v3=[];
let v4=({["sum"]:v2,["output"]:v3});
for(let v5=0;v5<v1.length;v5++){
const v6=v1[v5];
const v7=v4;
const v8=v7["sum"];
const v9=v6;
const v10=(((v8) + (v9)) >>> 0);
const v11=v4;
const v12=v11["output"];
const v13=v4;
const v14=v13["sum"];
const v15=v6;
const v16=(((v14) + (v15)) >>> 0);
const v17=[v16];
const v18=v12.length;
const v19=v17.length;
const v20=new Array(v18+v19);
for(let v21=0;v21<v18;v21++){v20[v21]=v12[v21];}
for(let v22=0;v22<v19;v22++){v20[v18+v22]=v17[v22];}
const v23=v20;
v4=({["sum"]:v10,["output"]:v23});
}
const v24=v4;
const v25=v24;
return v25["output"];}
function __into0(v26,v27){
const v28=v26;
const v29=0;
const v30=[];
let v31=({["sum"]:v29,["output"]:v30});
for(let v32=0;v32<v28.length;v32++){
const v33=v28[v32];
const v34=v31;
const v35=v34["sum"];
const v36=v33;
const v37=(((v35) + (v36)) >>> 0);
const v38=v31;
const v39=v38["output"];
const v40=v31;
const v41=v40["sum"];
const v42=v33;
const v43=(((v41) + (v42)) >>> 0);
const v44=[v43];
const v45=v39.length;
const v46=v44.length;
const v47=new Array(v45+v46);
for(let v48=0;v48<v45;v48++){v47[v48]=v39[v48];}
for(let v49=0;v49<v46;v49++){v47[v45+v49]=v44[v49];}
const v50=v47;
v31=({["sum"]:v37,["output"]:v50});
}
const v51=v31;
const v52=v51;
const v53=v52["output"];
const v54=v53.length;
for(let v55=0;v55<v54;v55++){
v27[v55]=v53[v55];
}
return v54;}
const __namedTypes={"Scan":{"fields":[{"name":"sum","type":{"kind":"u32"}},{"name":"output","type":{"element":{"kind":"u32"},"kind":"list"}}],"kind":"record","name":"Scan"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"82db7fc4c33789bb61342220c8be7b570bbcc388dd8ac1cb5b55ab53fc5ab0c8","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"u32"},"kind":"list"}}],"precondition":null,"result":{"element":{"kind":"u32"},"kind":"list"}}],"named_types":{"Scan":{"fields":[{"name":"sum","type":{"kind":"u32"}},{"name":"output","type":{"element":{"kind":"u32"},"kind":"list"}}],"kind":"record","name":"Scan"}},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[__into0];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
