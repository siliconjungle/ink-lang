module D3MinColdProfile;
record ColdExtremum { valid:Bool,value:u32, }
pub fn run(xs:List<u32>)->ColdExtremum{return foldl(xs,ColdExtremum{valid:false,value:0},fn(x)=>fn(a)=>choose(!a.valid || a.value>x,ColdExtremum{valid:true,value:x},a));}
