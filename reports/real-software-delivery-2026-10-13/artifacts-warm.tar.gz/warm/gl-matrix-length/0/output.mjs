// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output) {
  const convert=__representationRaw(type,output);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output) {
  switch (type.kind) {
    case 'ref': return (value,context)=>__representation(__namedTypes[type.name],output)(value,context);
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output),err=__representation(type.error,output);
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f32': return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      const fields = type.fields.map(field => [field.name, __representation(field.type, output)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
function __fn0(v0){
const v1=v0;
const v2=v1.length;
const v3=new Array(v2);
for(let v4=0;v4<v2;v4++){
const v5=v1[v4];
const v6=v5;
const v7=v6["x"];
const v8=v5;
const v9=v8["x"];
const v10=__bits(__float(v7) * __float(v9));
const v11=v5;
const v12=v11["y"];
const v13=v5;
const v14=v13["y"];
const v15=__bits(__float(v12) * __float(v14));
const v16=__bits(__float(v10) + __float(v15));
const v17=v5;
const v18=v17["z"];
const v19=v5;
const v20=v19["z"];
const v21=__bits(__float(v18) * __float(v20));
v3[v4]=__bits(__float(v16) + __float(v21));
}
return v3;}
function __into0(v22,v23){
const v24=v22;
const v25=v24.length;
for(let v27=0;v27<v25;v27++){
const v28=v24[v27];
const v29=v28;
const v30=v29["x"];
const v31=v28;
const v32=v31["x"];
const v33=__bits(__float(v30) * __float(v32));
const v34=v28;
const v35=v34["y"];
const v36=v28;
const v37=v36["y"];
const v38=__bits(__float(v35) * __float(v37));
const v39=__bits(__float(v33) + __float(v38));
const v40=v28;
const v41=v40["z"];
const v42=v28;
const v43=v42["z"];
const v44=__bits(__float(v41) * __float(v43));
v23[v27]=__intoOutput0(__bits(__float(v39) + __float(v44)));
}
return v25;}
const __namedTypes={"V":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}},{"name":"z","type":{"kind":"f32"}}],"kind":"record","name":"V"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v7","core_sha256":"a446b64e341fa2b46a22b31cd08d9a53856423478e1a1cda877d91c8e11b6d3a","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}},{"name":"z","type":{"kind":"f32"}}],"kind":"record","name":"V"},"kind":"list"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}}],"named_types":{"V":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}},{"name":"z","type":{"kind":"f32"}}],"kind":"record","name":"V"}},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
const __inputTypes=[[{"element":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}},{"name":"z","type":{"kind":"f32"}}],"kind":"record","name":"V"},"kind":"list"}]];

// Descriptor work occurs once at module initialisation, never per word-list call.
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=> {
  const input=__inputTypes[f.index].map(t=>__representation(t,false));
  const output=__representation(f.result,true);
  const body=__implementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
  const needsInput=input.some(c=>c!==__identity);
  const entry=!needsInput && output===__identity ? implementation :
    (...args)=>{const context=new WeakMap();return output(implementation(...(needsInput ? args.map((v,i)=>input[i](v,context)) : args)));};
  return [f.name,entry];
})));
export function call(name,args) { return functions[name](...args); }
const __intoOutput0=__representation(metadata.functions[0].result.element,true);
const __intoImplementations=[__into0];

export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>{
  const input=__inputTypes[f.index].map(t=>__representation(t,false));
  const body=__intoImplementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args.slice(0,f.params.length))!==true)throw Error('contract precondition failed');return body(...args);};
  const entry=input.every(c=>c===__identity)?implementation:(...values)=>{const context=new WeakMap();return implementation(...input.map((convert,i)=>convert(values[i],context)),values[f.params.length]);};
  return [f.name,entry];
})));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
