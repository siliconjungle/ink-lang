// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output) {
  const convert=__representationRaw(type,output);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output) {
  switch (type.kind) {
    case 'ref': return (value,context)=>__representation(__namedTypes[type.name],output)(value,context);
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output),err=__representation(type.error,output);
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f32': return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      const fields = type.fields.map(field => [field.name, __representation(field.type, output)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
function __fn0(v0){
const v1=v0;
const v2=false;
const v3=0;
const v4=0;
const v5=0;
const v6=({["x"]:v3,["y"]:v4,["z"]:v5});
const v7=0;
const v8=0;
const v9=0;
const v10=({["x"]:v7,["y"]:v8,["z"]:v9});
let v11=({["valid"]:v2,["min"]:v6,["max"]:v10});
for(let v12=0;v12<v1.length;v12++){
const v13=v1[v12];
const v14=true;
const v15=v11;
const v16=v15["valid"];
const v17=false;
const v18=(v16===v17);
let v19=v18;if(!v19){
const v20=v13;
const v21=v20["x"];
const v22=v11;
const v23=v22["min"];
const v24=v23["x"];
v19=((__float(v21)) < (__float(v24)));}
let v25;if(v19){
const v26=v13;
v25=v26["x"];}else{
const v27=v11;
const v28=v27["min"];
v25=v28["x"];}
const v29=v25;
const v30=v11;
const v31=v30["valid"];
const v32=false;
const v33=(v31===v32);
let v34=v33;if(!v34){
const v35=v13;
const v36=v35["y"];
const v37=v11;
const v38=v37["min"];
const v39=v38["y"];
v34=((__float(v36)) < (__float(v39)));}
let v40;if(v34){
const v41=v13;
v40=v41["y"];}else{
const v42=v11;
const v43=v42["min"];
v40=v43["y"];}
const v44=v40;
const v45=v11;
const v46=v45["valid"];
const v47=false;
const v48=(v46===v47);
let v49=v48;if(!v49){
const v50=v13;
const v51=v50["z"];
const v52=v11;
const v53=v52["min"];
const v54=v53["z"];
v49=((__float(v51)) < (__float(v54)));}
let v55;if(v49){
const v56=v13;
v55=v56["z"];}else{
const v57=v11;
const v58=v57["min"];
v55=v58["z"];}
const v59=v55;
const v60=({["x"]:v29,["y"]:v44,["z"]:v59});
const v61=v11;
const v62=v61["valid"];
const v63=false;
const v64=(v62===v63);
let v65=v64;if(!v65){
const v66=v13;
const v67=v66["x"];
const v68=v11;
const v69=v68["max"];
const v70=v69["x"];
v65=((__float(v67)) > (__float(v70)));}
let v71;if(v65){
const v72=v13;
v71=v72["x"];}else{
const v73=v11;
const v74=v73["max"];
v71=v74["x"];}
const v75=v71;
const v76=v11;
const v77=v76["valid"];
const v78=false;
const v79=(v77===v78);
let v80=v79;if(!v80){
const v81=v13;
const v82=v81["y"];
const v83=v11;
const v84=v83["max"];
const v85=v84["y"];
v80=((__float(v82)) > (__float(v85)));}
let v86;if(v80){
const v87=v13;
v86=v87["y"];}else{
const v88=v11;
const v89=v88["max"];
v86=v89["y"];}
const v90=v86;
const v91=v11;
const v92=v91["valid"];
const v93=false;
const v94=(v92===v93);
let v95=v94;if(!v95){
const v96=v13;
const v97=v96["z"];
const v98=v11;
const v99=v98["max"];
const v100=v99["z"];
v95=((__float(v97)) > (__float(v100)));}
let v101;if(v95){
const v102=v13;
v101=v102["z"];}else{
const v103=v11;
const v104=v103["max"];
v101=v104["z"];}
const v105=v101;
const v106=({["x"]:v75,["y"]:v90,["z"]:v105});
v11=({["valid"]:v14,["min"]:v60,["max"]:v106});
}
return v11;}
const __namedTypes={"Bounds":{"fields":[{"name":"valid","type":{"kind":"bool"}},{"name":"min","type":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}},{"name":"z","type":{"kind":"f32"}}],"kind":"record","name":"P"}},{"name":"max","type":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}},{"name":"z","type":{"kind":"f32"}}],"kind":"record","name":"P"}}],"kind":"record","name":"Bounds"},"P":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}},{"name":"z","type":{"kind":"f32"}}],"kind":"record","name":"P"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"f6374c601c1705a2c20e848c459c19f69d0e6e86f6c2b7f16f33d5f3ab702d65","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":null,"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}},{"name":"z","type":{"kind":"f32"}}],"kind":"record","name":"P"},"kind":"list"}}],"precondition":null,"result":{"fields":[{"name":"valid","type":{"kind":"bool"}},{"name":"min","type":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}},{"name":"z","type":{"kind":"f32"}}],"kind":"record","name":"P"}},{"name":"max","type":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}},{"name":"z","type":{"kind":"f32"}}],"kind":"record","name":"P"}}],"kind":"record","name":"Bounds"}}],"named_types":{"Bounds":{"fields":[{"name":"valid","type":{"kind":"bool"}},{"name":"min","type":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}},{"name":"z","type":{"kind":"f32"}}],"kind":"record","name":"P"}},{"name":"max","type":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}},{"name":"z","type":{"kind":"f32"}}],"kind":"record","name":"P"}}],"kind":"record","name":"Bounds"},"P":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}},{"name":"z","type":{"kind":"f32"}}],"kind":"record","name":"P"}},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
const __inputTypes=[[{"element":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}},{"name":"z","type":{"kind":"f32"}}],"kind":"record","name":"P"},"kind":"list"}]];

// Descriptor work occurs once at module initialisation, never per word-list call.
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=> {
  const input=__inputTypes[f.index].map(t=>__representation(t,false));
  const output=__representation(f.result,true);
  const body=__implementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
  const needsInput=input.some(c=>c!==__identity);
  const entry=!needsInput && output===__identity ? implementation :
    (...args)=>{const context=new WeakMap();return output(implementation(...(needsInput ? args.map((v,i)=>input[i](v,context)) : args)));};
  return [f.name,entry];
})));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[null];

export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>{
  const input=__inputTypes[f.index].map(t=>__representation(t,false));
  const body=__intoImplementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args.slice(0,f.params.length))!==true)throw Error('contract precondition failed');return body(...args);};
  const entry=input.every(c=>c===__identity)?implementation:(...values)=>{const context=new WeakMap();return implementation(...input.map((convert,i)=>convert(values[i],context)),values[f.params.length]);};
  return [f.name,entry];
})));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
