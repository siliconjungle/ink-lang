function __fn0(v0){
const v1=v0;
const v2=(v0).length;
const v3=1;
const v4=(((v2) - (v3)) >>> 0);
let v5;if(v4<v1.length){v5=v1[v4];}else{
const v6=0;
const v7=0;
v5=({["x"]:v6,["y"]:v7});}
const v8=v5;
const v9=v0;
const v10=v8;
const v11=0;
let v12=({["last"]:v10,["area"]:v11});
for(let v13=0;v13<v9.length;v13++){
const v14=v9[v13];
const v15=v14;
const v16=v12;
const v17=v16["area"];
const v18=v12;
const v19=v18["last"];
const v20=v19["x"];
const v21=v14;
const v22=v21["x"];
const v23=(((v20) - (v22)) | 0);
const v24=v14;
const v25=v24["y"];
const v26=v12;
const v27=v26["last"];
const v28=v27["y"];
const v29=(((v25) + (v28)) | 0);
const v30=Math.imul(v23,v29);
const v31=(((v17) + (v30)) | 0);
v12=({["last"]:v15,["area"]:v31});
}
const v32=v12;
const v33=v32;
return v33["area"];}
const __namedTypes={"P":{"fields":[{"name":"x","type":{"kind":"i32"}},{"name":"y","type":{"kind":"i32"}}],"kind":"record","name":"P"},"Scan":{"fields":[{"name":"last","type":{"fields":[{"name":"x","type":{"kind":"i32"}},{"name":"y","type":{"kind":"i32"}}],"kind":"record","name":"P"}},{"name":"area","type":{"kind":"i32"}}],"kind":"record","name":"Scan"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"30a30a7b8d91fc0ac0ddce6133c5c8a6cc584e899b8f9fd2207d7e422c08cc81","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":null,"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"fields":[{"name":"x","type":{"kind":"i32"}},{"name":"y","type":{"kind":"i32"}}],"kind":"record","name":"P"},"kind":"list"}}],"precondition":null,"result":{"kind":"i32"}}],"named_types":{"P":{"fields":[{"name":"x","type":{"kind":"i32"}},{"name":"y","type":{"kind":"i32"}}],"kind":"record","name":"P"},"Scan":{"fields":[{"name":"last","type":{"fields":[{"name":"x","type":{"kind":"i32"}},{"name":"y","type":{"kind":"i32"}}],"kind":"record","name":"P"}},{"name":"area","type":{"kind":"i32"}}],"kind":"record","name":"Scan"}},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[null];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
