function __fn0(v0){
const v1=v0;
const v2=false;
const v3=0;
let v4=({["valid"]:v2,["value"]:v3});
for(let v5=0;v5<v1.length;v5++){
const v6=v1[v5];
const v7=v4;
const v8=v7["valid"];
const v9=false;
const v10=(v8===v9);
let v11=v10;if(!v11){
const v12=v4;
const v13=v12["value"];
const v14=v6;
v11=((v13) < (v14));}
let v15;if(v11){
const v16=true;
const v17=v6;
v15=({["valid"]:v16,["value"]:v17});}else{
v15=v4;}
v4=v15;
}
return v4;}
const __namedTypes={"Extremum":{"fields":[{"name":"valid","type":{"kind":"bool"}},{"name":"value","type":{"kind":"u32"}}],"kind":"record","name":"Extremum"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"9661faf80cbfe7040a133adc98852bbf8a1bb0e6fbfe22169435c906c963538b","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"functions":[{"destination":null,"index":0,"internal":false,"name":"run","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"u32"},"kind":"list"}}],"precondition":null,"result":{"fields":[{"name":"valid","type":{"kind":"bool"}},{"name":"value","type":{"kind":"u32"}}],"kind":"record","name":"Extremum"}}],"named_types":{"Extremum":{"fields":[{"name":"valid","type":{"kind":"bool"}},{"name":"value","type":{"kind":"u32"}}],"kind":"record","name":"Extremum"}},"schema":1,"state":null};
const __implementations=[__fn0];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>[f.name,__implementations[f.index]])));
export function call(name,args) { return functions[name](...args); }
const __intoImplementations=[null];
export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>[f.name,__intoImplementations[f.index]])));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}
