"""Untrusted source-contract proof authoring and canonical database publication.

Every proposed proof is replayed against the compiler's source-derived obligation.
The catalogue records correctness; measurements separately establish profitability.
"""
import argparse, json, subprocess
from pathlib import Path
from ink_knowledge.store import Store, entry, semantic_entry, identity
from producers.equational import Tactic
from producers.action_replacement import var, cons, convert
from producers.point_delta import sub, normal
from producers.beta_specialization15 import beta_normalize

MATH='first-order-inductive-equality-v1'

def pure_proposals(goal):
    """Ordinary proof terms, independent of proposition/algorithm names.

    Enumerate conversion, scoped hypotheses, Boolean splitting and induction.
    The compiler replays every proposal. Bounded failure grants no assumption.
    """
    yield 'Normalize'
    for i in range(len(goal['conditions'])):yield {'Hypothesis':i}
    yield {'Linear':dict(premises=[])}
    for i in range(len(goal['conditions'])):yield {'Linear':dict(premises=[[i,1]])}
    if len(goal['conditions'])>1:yield {'Linear':dict(premises=[[i,1]for i in range(len(goal['conditions']))])}
    from ink_planner.semantic_search import children
    conditions=[];seen=set()
    def visit(term,depth=0):
        if depth>64:return
        node=term.get('node')
        if isinstance(node,dict)and 'Lambda'in node:return
        if term.get('sort')=={'Value':'Bool'}:
            data=json.dumps(term,sort_keys=True)
            if '"Bound"'not in data and data not in seen:
                seen.add(data);conditions.append(term)
        for child in children(term):visit(child,depth+1)
    for term in [goal['goal']['from'],goal['goal']['to']]:visit(term)
    for name,sort in goal['params'].items():
        if sort=={'Value':'Bool'}:
            term=dict(sort=sort,node={'Free':name})
            if term not in conditions:conditions.append(term)
    conditions=[c for c in conditions if not isinstance(c['node'],dict)or 'Bool'not in c['node']][:12]
    for condition in conditions:
        yield {'Cases':dict(condition=condition,on_false='Normalize',on_true='Normalize')}
    # Compose a bounded set of cases rather than recognise a particular formula.
    if 1<len(conditions)<=4:
        proof='Normalize'
        for condition in reversed(conditions):proof={'Cases':dict(condition=condition,on_false=proof,on_true=proof)}
        yield proof
    for name,sort in goal['params'].items():
        if isinstance(sort,dict)and isinstance(sort.get('Value'),dict)and 'List'in sort['Value']:
            head,tail='contract_head','contract_tail'
            while head in goal['params']:head+='_' 
            while tail in goal['params']:tail+='_' 
            yield {'Induction':dict(variable=name,names=[head,tail],base='Normalize',step='Normalize')}

def rewrite_proposals(goal,store,limit=64):
    """Compose ordinary database laws through the exact obligation context.

    This bounded search has no privileged collection/property names. Lambda
    interiors are left to binder-aware producers; closed argument positions
    support arbitrary surrounding observations, including multiset contracts.
    """
    from ink_planner.semantic_search import children,match,substitute,replace,key
    from producers.beta_specialization15 import lift_use
    def positions(term,path=()):
        yield path,term
        if isinstance(term['node'],dict)and 'Lambda'in term['node']:return
        for i,child in enumerate(children(term)):yield from positions(child,path+(i,))
    def size(term):return 1+sum(size(child)for child in children(term))
    frontier=[(goal['goal']['from'],None,())];seen={key(goal['goal']['from'])};attempts=0
    cache={}
    for _ in range(8):
        next_frontier=[]
        for body,prior,dependencies in frontier:
            for path,target in positions(body):
                node=target['node']
                if not isinstance(node,dict)or 'Op'not in node:continue
                operation=node['Op'][0];query_key=(key(target['sort']),operation)
                if query_key not in cache:
                    rows=[];after=None
                    while len(rows)<1024:
                        page=store.query(kind='rewrite',semantics='ink-conditional-laws-v1',result=target['sort'],operation=operation,after=after,limit=128)
                        for ident in page:
                            payload=store.object(ident)['payload']
                            head=payload['from'].get('node',{})
                            if isinstance(head,dict)and head.get('Op',[None])[0]==operation:rows.append((ident,payload))
                        if len(page)<128:break
                        after=page[-1]
                    cache[query_key]=rows
                for ident,law in cache[query_key]:
                        args={}
                        if law.get('types')or law.get('assumptions'):continue
                        if not match(law['from'],target,law['params'],args)or set(args)!=set(law['params']):continue
                        replacement=substitute(law['to'],args)
                        if size(replacement)>=size(target):continue
                        updated=replace(body,path,replacement);fingerprint=key(updated)
                        if fingerprint in seen:continue
                        seen.add(fingerprint)
                        roots=tuple(sorted(set(dependencies)|{ident}));bundle=store.bundle(roots)
                        use={'Use':dict(law=ident,arguments=args,premises=['Normalize']*len(law['conditions']))}
                        step=lift_use(body,path,use)
                        chain=step if prior is None else {'Trans':dict(middle=body,left=prior,right=step)}
                        reduced={**goal,'goal':dict(**{'from':updated,'to':goal['goal']['to']})}
                        # Replay even small proof proposals before retaining a path.
                        for terminal in pure_proposals(reduced):
                            if attempts>=limit:return
                            attempts+=1
                            yield {'Trans':dict(middle=updated,left=chain,right=terminal)},bundle
                        next_frontier.append((updated,chain,roots))
                        if len(next_frontier)>=8:break
                if len(next_frontier)>=8:break
            if len(next_frontier)>=8:break
        frontier=next_frontier
        if not frontier:return

def references(value):
    if isinstance(value,list):return set().union(*(references(x) for x in value))
    if not isinstance(value,dict):return set()
    found={v for k,v in value.items() if k in ('Data','datatype','function','theorem') and isinstance(v,str) and len(v)==64}
    return found|set().union(*(references(x) for x in value.values()))

def context_for(context,goal):
    """Keep only definitions and value types actually mentioned by this law."""
    functions=set();types=set()
    def scan(t):
        if isinstance(t,dict):
            op=t.get('Op')
            if isinstance(op,list) and op and isinstance(op[0],str) and op[0].startswith('call:') and op[0][5:] in context['definitions']:functions.add(op[0][5:])
            if isinstance(t.get('Named'),str):types.add(t['Named'])
            for v in t.values():scan(v)
        elif isinstance(t,list):
            for v in t:scan(v)
    scan(goal);seen=set()
    while functions-seen:
        name=next(iter(functions-seen));seen.add(name);definition=context['definitions'][name]
        scan(definition);functions.update(definition['definition']['callees'])
    seen_types=set()
    while types-seen_types:
        name=next(iter(types-seen_types));seen_types.add(name);scan(context['records'].get(name,[]))
    return dict(schema=1,definitions={n:context['definitions'][n] for n in sorted(functions)},records={n:t for n,t in context['records'].items() if n in types},enums={n:t for n,t in context['enums'].items() if n in types},**({'ids':[n for n in context.get('ids',[]) if n in types]} if any(n in types for n in context.get('ids',[])) else {}))

def state_proof(objects,a,z,params,hyp=(),depth=0,serial=None,aliases=None):
    """Bounded ordinary constructor induction and Boolean case proof search."""
    if depth>18:raise ValueError('contract proof search depth')
    serial=serial if serial is not None else [0,0]
    serial[1]+=1
    if serial[1]>100000:raise ValueError("contract proof search node budget")
    class ContractTactic(Tactic):
        def norm(self, value):
            def reflexive(t):
                if isinstance(t,list):return [reflexive(x) for x in t]
                if not isinstance(t,dict):return t
                t={k:reflexive(v) for k,v in t.items()}
                if 'Binary' in t:
                    b=t['Binary']
                    if b['op']=='==' and b['left']==b['right']:return {'Bool':True}
                return t
            value=super().norm(value)
            for _ in range(32):
                updated=reflexive(value)
                if updated==value:return value
                value=super().norm(updated)
            raise ValueError('contract normalization budget')
    tactic=ContractTactic(objects)
    from producers.action_replacement import trans
    from producers.point_delta import lift
    from producers.equational import alpha
    def replace(t,old,new):
        if alpha(t)==alpha(old):return new
        if isinstance(t,dict):return {k:replace(v,old,new) for k,v in t.items()}
        if isinstance(t,list):return [replace(v,old,new) for v in t]
        return t
    from producers.point_delta import free_variables
    aliases=aliases or {}
    def canonical(value):
        current=tactic.norm(value);proof=convert(value,current)
        def find(t):
            if isinstance(t,dict):
                if 'Call' in t and t['Call']['function'] in aliases and free_variables(t)<=params.keys():
                    target,_=aliases[t['Call']['function']];args=t['Call']['arguments']
                    if target is not None or (len(args)==2 and alpha(args[0])==alpha(args[1])):return t
                for x in t.values():
                    found=find(x)
                    if found:return found
            elif isinstance(t,list):
                for x in t:
                    found=find(x)
                    if found:return found
        for _ in range(256):
            found=find(current)
            if found is None:return current,proof
            target,theorem=aliases[found['Call']['function']]
            replacement={'Call':dict(function=target,arguments=found['Call']['arguments'])} if target is not None else {'Bool':True}
            following=replace(current,found,replacement)
            use={'Use':dict(theorem=theorem,arguments=found['Call']['arguments'] if target is not None else found['Call']['arguments'][:1],premises=[])}
            proof=trans(proof,lift(use,replace(current,found,var('delta_hole'))),convert(following,tactic.norm(following)))
            current=tactic.norm(following)
        raise ValueError('contract alias rewrite budget')
    facts=[]
    for x,y,i in hyp:
        xx,px=canonical(x);yy,py=canonical(y)
        facts.append((xx,yy,trans({'Sym':px},{'Hypothesis':i},py)))
    def contradiction():
        for x,y,proof in facts:
            if 'Bool' in x and 'Bool' in y and x!=y:
                context={'If':dict(condition=var('delta_hole'),on_true=a if x['Bool'] else z,on_false=z if x['Bool'] else a)}
                return trans(convert(a,sub(context,{'delta_hole':x})),lift(proof,context),convert(sub(context,{'delta_hole':y}),z))
        return None
    impossible=contradiction()
    if impossible:return impossible
    def simplify(value,others):
        current,proof=canonical(value)
        for _ in range(16):
            changed=False
            for x,y,p in others:
                if x==y:continue
                following=replace(current,x,y)
                if following!=current:
                    updated,computed=canonical(following)
                    proof=trans(proof,lift(p,replace(current,x,var('delta_hole'))),computed)
                    current=updated;changed=True;break
            if not changed:return current,proof
        raise ValueError('contract fact rewrite budget')
    for _ in range(4):
        updated=False
        for i,(x,y,p) in enumerate(facts):
            others=facts[:i]+facts[i+1:];xx,px=simplify(x,others);yy,py=simplify(y,others)
            if (xx,yy)!=(x,y):facts[i]=(xx,yy,trans({'Sym':px},p,py));updated=True
            impossible=contradiction()
            if impossible:return impossible
        if not updated:break
    na,pa=simplify(a,facts);nz,pz=simplify(z,facts)
    def nodes(t):
        if isinstance(t,dict):
            yield t
            if 'Match' in t:yield from nodes(t['Match']['scrutinee']);return
            for x in t.values():yield from nodes(x)
        elif isinstance(t,list):
            for x in t:yield from nodes(x)
    if na==nz or ('Binary' in na and na['Binary']['op']=='==' and na['Binary']['left']==na['Binary']['right'] and nz=={'Bool':True}):
        return trans(pa,convert(na,nz),{'Sym':pz})
    from producers.point_delta import free_variables
    for t in nodes([na,nz]):
        if 'If' in t and not any(n in free_variables(t['If']['condition']) and isinstance(sort,dict) and 'Data' in sort and all(n not in free_variables(x)|free_variables(y) for x,y,_ in hyp) for n,sort in params.items()):
            condition=t['If']['condition'];cases={}
            for field,flag in [('on_false',False),('on_true',True)]:
                cases[field]=state_proof(objects,a,z,params,[*hyp,(condition,{'Bool':flag},len(hyp))],depth+1,serial,aliases)
            return {'BoolSplit':dict(condition=condition,**{'from':a,'to':z},**cases)}
    from producers.point_delta import free_variables
    # Eliminate an observed constructor shared with a premise without inventing
    # an induction hypothesis for that premise.
    def all_nodes(t):
        if isinstance(t,dict):
            yield t
            for x in t.values():yield from all_nodes(x)
        elif isinstance(t,list):
            for x in t:yield from all_nodes(x)
    premise_nodes=list(all_nodes([x for x,y,p in facts]))
    for node in nodes([na,nz]):
        if 'Match' not in node:continue
        scrutinee=node['Match']['scrutinee']
        if 'Call' not in scrutinee or not any(alpha(scrutinee)==alpha(x) for x in premise_nodes) or not free_variables(scrutinee)<=params.keys():continue
        sort=objects[scrutinee['Call']['function']]['payload']['declaration']['Function']['result']
        if not isinstance(sort,dict) or 'Data' not in sort:continue
        datatype=sort['Data'];cases=[]
        for i,c in enumerate(objects[datatype]['payload']['declaration']['Datatype']['constructors']):
            serial[0]+=1;names=[f'contract_observed_{serial[0]}_{j}' for j in range(len(c['fields']))]
            fields=[sort if t=='SelfType' else t for t in c['fields']];local={**params,**dict(zip(names,fields))}
            value=cons(datatype,i,[var(n) for n in names])
            proof=state_proof(objects,a,z,local,[*hyp,(scrutinee,value,len(hyp))],depth+1,serial,aliases)
            cases.append(dict(bindings=names,proof=proof))
        return {'Cases':dict(scrutinee=scrutinee,**{'from':a,'to':z},cases=cases)}
    free=free_variables(na)|free_variables(nz)
    preferred=[]
    for node in nodes([na,nz]):
        if 'Match' in node and 'Var' in node['Match']['scrutinee']:
            preferred.append(node['Match']['scrutinee']['Var'])
        if 'Call' in node:
            call=node['Call'];definition=objects[call['function']]['payload']['declaration'].get('Function')
            if definition and definition['recursive'] is not None:
                argument=call['arguments'][definition['recursive']]
                if 'Var' in argument:preferred.append(argument['Var'])
    for variable in dict.fromkeys([*preferred,*params]):
        if variable not in params:continue
        sort=params[variable]
        if variable not in free or not isinstance(sort,dict) or 'Data' not in sort:continue
        datatype=sort['Data'];d=objects[datatype]['payload']['declaration']
        if 'Datatype' not in d:continue
        induct=all(variable not in free_variables(x)|free_variables(y) for x,y,_ in hyp)
        cases=[]
        for i,c in enumerate(d['Datatype']['constructors']):
            serial[0]+=1;names=[f'contract_case_{serial[0]}_{j}' for j in range(len(c['fields']))]
            value=cons(datatype,i,[var(n) for n in names]);binding={variable:value};local={n:t for n,t in params.items() if n!=variable}
            fields=[sort if t=='SelfType' else t for t in c['fields']];local.update(zip(names,fields))
            premises=list(hyp) if induct else [(sub(x,binding),sub(y,binding),j) for x,y,j in hyp]
            if induct:
                for name,field in zip(names,fields):
                    if field==sort:premises.append((sub(a,{variable:var(name)}),sub(z,{variable:var(name)}),len(premises)))
            proof=state_proof(objects,sub(a,binding),sub(z,binding),local,premises,depth+1,serial,aliases)
            cases.append(dict(bindings=names,proof=proof))
        return {('Induction' if induct else 'Cases'):dict(variable=variable,**{'from':a,'to':z},cases=cases)}
    raise ValueError('unclosed contract state goal '+str((na,nz))[:600])

def author(compiler,source,directory,bodies=None,source_evidence=None):
    compiler=str(Path(compiler).resolve());source=str(Path(source).resolve())
    directory=Path(directory).resolve();directory.mkdir(parents=True,exist_ok=True)
    options=["--core"] if Path(source).suffix==".json" else []
    if source_evidence:options += ['--contract-proofs',str(Path(source_evidence).resolve())]
    if bodies:options += ['--refinement-bodies',str(Path(bodies).resolve())]
    export=directory/'obligations.json'
    subprocess.run([compiler,'emit-contract-obligations',source,'-o',str(export),*options],check=True,capture_output=True,text=True)
    goals=json.loads(export.read_text());pure_objects={};state_objects=dict((goals['state'] or {}).get('objects',{}));pure_roots=[];state_roots=[]
    proofs={};state_proofs={};names={};installed=Store(Path(__file__).resolve().parents[1])
    def check(g,proof,bundle=None):
        path=directory/'trial.json';path.write_text(json.dumps(dict(proof=proof,knowledge=bundle)))
        trial=subprocess.run([compiler,'check-contract-proof',source,g['name'],str(path),*options],capture_output=True,text=True)
        if trial.returncode:(directory/"last-check-error.txt").write_text(trial.stderr)
        return trial.returncode==0
    for g in goals['pure']:
        proof=next((p for p in pure_proposals(g) if check(g,p)),None);dependencies=[]
        if proof is None:
            from producers.semantic_observations import proposals
            for candidate,bundle in proposals(g,installed,goals['definition_context']):
                if check(g,candidate,bundle):
                    proof=candidate;dependencies=bundle['roots'];pure_objects.update(bundle['objects']);break
        if proof is None:
            for candidate,bundle in rewrite_proposals(g,installed):
                if check(g,candidate,bundle):
                    proof=candidate;dependencies=bundle['roots'];pure_objects.update(bundle['objects']);break
        if proof is None:raise ValueError('no checked proof for '+g['name'])
        law=dict(schema=1,semantics='ink-conditional-laws-v1',params=g['params'],conditions=g['conditions'],**g['goal'],proof=proof,dependencies=dependencies,definition_context=context_for(goals['definition_context'],g))
        obj=semantic_entry(law);i=identity(obj);pure_objects[i]=obj;pure_roots.append(i);names['contract.'+g['name']]=i
        proofs[g['name']]={'Use':dict(law=i,arguments={n:dict(sort=t,node={'Free':n}) for n,t in g['params'].items()},premises=[{'Hypothesis':j} for j in range(len(g['conditions']))])}
    def add(declaration):
        d=declaration['Theorem'];deps=references(declaration);pending=list(deps)
        while pending:
            for dep in state_objects[pending.pop()]['dependencies']:
                if dep not in deps:deps.add(dep);pending.append(dep)
        obj=entry('theorem',MATH,dict(declaration=declaration),deps,parameters=dict(d['params']),conditions=d['conditions']);i=identity(obj);state_objects[i]=obj;return i
    # Alpha-equivalent generated traversals still have independent canonical IDs.
    # Propose ordinary induction theorems between them; never identify their
    # meanings merely from names or syntax in the trusted kernel.
    from producers.equational import alpha
    aliases={};classes={};pending={i:o['payload']['declaration']['Function'] for i,o in state_objects.items() if 'Function' in o['payload']['declaration']}
    def canonical_calls(x):
        if isinstance(x,list):return [canonical_calls(v) for v in x]
        if not isinstance(x,dict):return x
        return {k:(aliases[v][0] if k=='function' and v in aliases else canonical_calls(v)) for k,v in x.items()}
    while pending:
        ready=[i for i,d in pending.items() if not (references(d)&pending.keys())]
        if not ready:break
        for i in ready:
            d=pending.pop(i);params=[(f'contract_alias_{j}',t) for j,(_,t) in enumerate(d['params'])]
            body=alpha(canonical_calls(sub(d['body'],{n:var(m) for (n,_),(m,_) in zip(d['params'],params)})))
            key=json.dumps([params,d['result'],d['recursive'],body],sort_keys=True)
            if key not in classes:classes[key]=i;continue
            target=classes[key];args=[var(n) for n,_ in params]
            a={'Call':dict(function=i,arguments=args)};z={'Call':dict(function=target,arguments=args)}
            (directory/'progress.json').write_text(json.dumps(dict(phase="traversal-equivalence",function=i,target=target)))
            try:proof=state_proof(state_objects,a,z,dict(params),aliases=aliases)
            except ValueError:continue
            theorem=add({'Theorem':dict(params=params,conditions=[],**{'from':a,'to':z},proof=proof)})
            aliases[i]=(target,theorem)
    # Propose reflexivity for homogeneous Boolean relations over data. This is
    # search, not recognition authority: induction must prove each candidate.
    for i,obj in list(state_objects.items()):
        d=obj['payload']['declaration'].get('Function')
        if i in aliases or not d or d['result']!='Bool' or len(d['params'])!=2:continue
        sort=d['params'][0][1]
        if sort!=d['params'][1][1] or not isinstance(sort,dict) or 'Data' not in sort:continue
        params=[('contract_reflexive',sort)];argument=var(params[0][0])
        a={'Call':dict(function=i,arguments=[argument,argument])};z={'Bool':True}
        try:proof=state_proof(state_objects,a,z,dict(params),aliases=aliases)
        except ValueError:continue
        theorem=add({'Theorem':dict(params=params,conditions=[],**{'from':a,'to':z},proof=proof)})
        aliases[i]=(None,theorem)
    for number,g in enumerate((goals['state'] or {}).get('obligations',[])):
        (directory/'progress.json').write_text(json.dumps(dict(phase='state-obligation',name=g['name'])))
        from producers.point_delta import free_variables
        a,z=g['goal']['from'],g['goal']['to'];all_conditions=g['conditions']
        data_names={n for n,t in g['params'] if isinstance(t,dict) and 'Data' in t}
        subsets=[list(range(len(all_conditions))),*[[i for i,c in enumerate(all_conditions) if variable not in (free_variables(c['from'])|free_variables(c['to']))] for variable,_ in g['params'] if variable in data_names],[]]
        subsets=list(dict.fromkeys(tuple(indices) for indices in subsets))
        subsets=[list(indices) for indices in subsets]
        success=False;errors=[]
        direct=next((p for p in [convert(a,z),*[{'Hypothesis':i} for i in range(len(all_conditions))]] if check(g,p)),None)
        ordered=[subsets[0]] if direct is not None else [*subsets[1:],subsets[0]]
        for attempt,indices in enumerate(ordered):
            (directory/'progress.json').write_text(json.dumps(dict(phase='state-obligation',name=g['name'],conditions=indices)))
            conditions=[all_conditions[i] for i in indices];hyp=[(c['from'],c['to'],i) for i,c in enumerate(conditions)]
            try:
                proof=direct if direct is not None else state_proof(state_objects,a,z,dict(g['params']),hyp,aliases=aliases if indices else {})
            except ValueError as error:errors.append(str(error));continue
            i=add({'Theorem':dict(params=g['params'],conditions=conditions,**g['goal'],proof=proof)})
            trial=Store.publish(directory/'trials'/f'{number}-{attempt}',state_objects.values())
            use={'Use':dict(theorem=i,arguments=[var(n) for n,_ in g['params']],premises=[{'Hypothesis':j} for j in indices])}
            if check(g,use,trial.bundle([i])):
                state_roots.append(i);names['contract.'+g['name']]=i;state_proofs[g['name']]=use;success=True;break
            state_objects.pop(i)
        if not success:raise ValueError('no checked state proof for '+g['name']+': '+'; '.join(errors)[-1200:])
    store=Store.publish(directory,[*pure_objects.values(),*state_objects.values()],names)
    evidence=dict(schema=1,semantics=goals['semantics'],source_sha256=goals['source_sha256'],proofs=proofs,state_proofs=state_proofs,knowledge=store.bundle(pure_roots) if pure_roots else None,state_knowledge=store.bundle(state_roots) if state_roots else None)
    (directory/'progress.json').write_text(json.dumps(dict(phase='proofs-replayed',pure=len(proofs),state=len(state_proofs))))
    target=directory/'evidence.json';target.write_text(json.dumps(evidence,separators=(',',':'))+'\n')
    if not bodies:subprocess.run([compiler,'check-contracts',source,'--contract-proofs',str(target),*(['--core'] if Path(source).suffix=='.json' else [])],check=True,capture_output=True,text=True)
    return evidence,store

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('source');p.add_argument('output');p.add_argument('--compiler',required=True);p.add_argument('--bodies');p.add_argument('--source-evidence');a=p.parse_args()
    author(a.compiler,a.source,a.output,a.bodies,a.source_evidence)
    print('Checked contract evidence and canonical entries:',a.output)
if __name__=='__main__':main()
