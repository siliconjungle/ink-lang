pub fn initial_state()->Result<State,String>{State::restore(include_bytes!("../initial.snapshot"))}
