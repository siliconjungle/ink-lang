import json,subprocess,hashlib,copy
from pathlib import Path
root=Path.cwd();base=root/'build/v8-device-acquisition';request=json.loads((base/'request.json').read_text());artifacts=[request['artifacts'][0]]
manifest=json.loads((base/'baseline/manifest.json').read_text())
bodies={
 'wrong':'r.value+=1n;',
 'rounded':'r.value=Number(r.value);',
 'mutation':'args[0][0]=0n;',
 'cpu-fallback':"r.backend='cpu';",
 'counter-spoof':'r.counters.dispatches++;',
}
for name,body in bodies.items():
 folder=base/'rejection'/name;folder.mkdir(parents=True,exist_ok=True);(folder/'manifest.json').write_text(json.dumps(manifest))
 (folder/'ink-gpu.mjs').write_text("import{loadInk as real}from '/artifact/0/ink-gpu.mjs';export async function loadInk(base,options){const h=await real(new URL('/artifact/0/',location.href),options);return{async call(name,args,o){const r=await h.call(name,args,o);"+body+"return r;},close:()=>h.close()};}")
 artifacts.append(dict(measurement=name,path=str(folder),selected_core_sha256=manifest['core_sha256']))
folder=base/'rejection/no-device';folder.mkdir(parents=True,exist_ok=True);(folder/'manifest.json').write_text(json.dumps(manifest));(folder/'ink-gpu.mjs').write_text("export async function loadInk(){return{async call(){return{value:0n,backend:'gpu',counters:{dispatches:2,readback_bytes:8}}},close(){}}}")
artifacts.append(dict(measurement='no-device',path=str(folder),selected_core_sha256=manifest['core_sha256']))
request['artifacts']=artifacts;request['measurement']=dict(rounds=9,minimum_batch_ms=1,maximum_calls_per_sample=1)
p=base/'rejection.request.json';p.write_text(json.dumps(request));r=subprocess.run(['node','planner/ink_planner/measure_gpu_calls.mjs','/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',str(p),hashlib.sha256(p.read_bytes()).hexdigest()],capture_output=True,text=True,timeout=180);(base/'rejection.json').write_text(r.stdout);(base/'rejection.log').write_text(r.stderr);assert r.returncode==0,r.stderr;report=json.loads(r.stdout)
assert {r['measurement']for r in report['rows']}=={'baseline'}
assert {r['measurement']for r in report['rejected']}==set(bodies)|{'no-device'}
print([(r['measurement'],r['reason'])for r in report['rejected']])
