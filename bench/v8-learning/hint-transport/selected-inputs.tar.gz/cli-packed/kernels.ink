module bitvector_proofs;

fn add_commute(p0: u64, p1: u64) -> u64 { return (p0 + p1); }
