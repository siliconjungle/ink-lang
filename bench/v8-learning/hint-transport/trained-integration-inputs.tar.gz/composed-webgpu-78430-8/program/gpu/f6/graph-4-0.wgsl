// Exact wrapping u64 over two storage lanes. No floating point intermediates.
struct InkU64 {lo:u32,hi:u32,}
struct InkDiv64 {quotient:InkU64,remainder:InkU64,}
fn ink_u64_shl(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64(a.lo<<k,(a.hi<<k)|(a.lo>>(32u-k)));}return InkU64(0u,a.lo<<(k-32u));}
fn ink_u64_shr(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64((a.lo>>k)|(a.hi<<(32u-k)),a.hi>>k);}return InkU64(a.hi>>(k-32u),0u);}
fn ink_u64_rol(a:InkU64,count:u32)->InkU64{let k=count&63u;let l=ink_u64_shl(a,k);let r=ink_u64_shr(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_ror(a:InkU64,count:u32)->InkU64{let k=count&63u;let r=ink_u64_shr(a,k);let l=ink_u64_shl(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_eq(a:InkU64,b:InkU64)->bool{return a.lo==b.lo&&a.hi==b.hi;}
fn ink_u64_lt(a:InkU64,b:InkU64)->bool{return a.hi<b.hi||(a.hi==b.hi&&a.lo<b.lo);}
fn ink_u64_add(a:InkU64,b:InkU64)->InkU64{let lo=a.lo+b.lo;return InkU64(lo,a.hi+b.hi+select(0u,1u,lo<a.lo));}
fn ink_u64_sub(a:InkU64,b:InkU64)->InkU64{return InkU64(a.lo-b.lo,a.hi-b.hi-select(0u,1u,a.lo<b.lo));}
fn ink_u64_mul(a:InkU64,b:InkU64)->InkU64{let al=a.lo&65535u;let ah=a.lo>>16u;let bl=b.lo&65535u;let bh=b.lo>>16u;let p=al*bl;let x=ah*bl;let y=al*bh;let mid=(p>>16u)+(x&65535u)+(y&65535u);let high=ah*bh+(x>>16u)+(y>>16u)+(mid>>16u);return InkU64((mid<<16u)|(p&65535u),high+a.lo*b.hi+a.hi*b.lo);}
fn ink_u64_div(a:InkU64,b:InkU64)->InkDiv64{var q=InkU64(0u,0u);var r=InkU64(0u,0u);var cursor=64u;loop{if(cursor==0u){break;}cursor--;var bit=0u;if(cursor>=32u){bit=(a.hi>>(cursor-32u))&1u;}else{bit=(a.lo>>cursor)&1u;}let overflow=r.hi>>31u;r=InkU64((r.lo<<1u)|bit,(r.hi<<1u)|(r.lo>>31u));if(overflow!=0u||!ink_u64_lt(r,b)){r=ink_u64_sub(r,b);if(cursor>=32u){q.hi|=1u<<(cursor-32u);}else{q.lo|=1u<<cursor;}}}return InkDiv64(q,r);}
// Binary32 evaluated with integer lanes: round-to-nearest, ties-to-even,
// gradual underflow, signed zero and canonical arithmetic NaN.
fn ink_f32_nan(x:u32)->bool{return (x&0x7fffffffu)>0x7f800000u;}
fn ink_f32_eq(a:u32,b:u32)->bool{return !ink_f32_nan(a)&&!ink_f32_nan(b)&&(a==b||((a|b)&0x7fffffffu)==0u);}
fn ink_f32_lt(a:u32,b:u32)->bool{
 if(ink_f32_nan(a)||ink_f32_nan(b)||ink_f32_eq(a,b)){return false;}
 if((a^b)&0x80000000u)!=0u{return (a&0x80000000u)!=0u;}
 if((a&0x80000000u)!=0u){return a>b;}return a<b;
}
fn ink_f32_jam(x:u32,n:u32)->u32{if(n==0u){return x;}if(n>=32u){return select(0u,1u,x!=0u);}return (x>>n)|select(0u,1u,(x&((1u<<n)-1u))!=0u);}
fn ink_f32_round(sign:u32,exponent:i32,extended:u32)->u32{
 var e=exponent;var s=extended;
 if(e<1i){s=ink_f32_jam(s,u32(1i-e));e=1i;}
 let tail=s&7u;var sig=s>>3u;
 if(tail>4u||(tail==4u&&(sig&1u)!=0u)){sig++;}
 if(sig>=0x1000000u){sig>>=1u;e++;}
 if(e>=255i){return sign|0x7f800000u;}
 if(sig==0u){return sign;}
 let raw=select(u32(e),0u,e==1i&&sig<0x800000u);
 return sign|(raw<<23u)|(sig&0x7fffffu);
}
fn ink_f32_add(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 var x=a;var y=b;if((x&0x7fffffffu)<(y&0x7fffffffu)){x=b;y=a;}
 let ax=x&0x7fffffffu;let ay=y&0x7fffffffu;let sign=x&0x80000000u;
 if(ax==0x7f800000u){if(ay==ax&&((x^y)&0x80000000u)!=0u){return 0x7fc00000u;}return x;}
 let rx=(x>>23u)&255u;let ry=(y>>23u)&255u;var e=i32(max(rx,1u));
 var sx=((x&0x7fffffu)|select(0u,0x800000u,rx!=0u))<<3u;
 let sy=ink_f32_jam(((y&0x7fffffu)|select(0u,0x800000u,ry!=0u))<<3u,u32(e)-max(ry,1u));
 if(((x^y)&0x80000000u)==0u){sx+=sy;if(sx>=0x8000000u){sx=ink_f32_jam(sx,1u);e++;}}
 else{sx-=sy;if(sx==0u){return 0u;}loop{if(sx>=0x4000000u||e<=1i){break;}sx<<=1u;e--;}}
 return ink_f32_round(sign,e,sx);
}
fn ink_f32_sub(a:u32,b:u32)->u32{return ink_f32_add(a,b^0x80000000u);}
fn ink_f32_mul(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(aa==0x7f800000u||bb==0x7f800000u){if(aa==0u||bb==0u){return 0x7fc00000u;}return sign|0x7f800000u;}
 if(aa==0u||bb==0u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u));var eb=i32(max(rb,1u));
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 let product=ink_u64_mul(InkU64(sa,0u),InkU64(sb,0u));let high=(product.hi&0x8000u)!=0u;
 let shift=select(20u,21u,high);let extended=(product.lo>>shift)|(product.hi<<(32u-shift))|select(0u,1u,(product.lo&((1u<<shift)-1u))!=0u);
 return ink_f32_round(sign,ea+eb-127i+select(0i,1i,high),extended);
}
// Exact sqrt and division use integer significands, independent of WGSL float
// approximation allowances and device flush-to-zero behavior.
fn ink_f32_sqrt(x:u32)->u32{
 let a=x&0x7fffffffu;if(a==0u){return x;}
 if(a>0x7f800000u||(x&0x80000000u)!=0u){return 0x7fc00000u;}
 if(a==0x7f800000u){return x;}
 let raw=(x>>23u)&255u;var m=(x&0x7fffffu)|select(0u,0x800000u,raw!=0u);var e=i32(max(raw,1u))-127i;
 loop{if(m>=0x800000u){break;}m<<=1u;e--;}
 let odd=e&1i;var half=(e-odd)/2i;let shift=23u+u32(odd);
 let n=InkU64(m<<shift,m>>(32u-shift));var lo=0u;var hi=0x1000000u;
 loop{if(lo+1u>=hi){break;}let mid=(lo+hi)>>1u;let sq=ink_u64_mul(InkU64(mid,0u),InkU64(mid,0u));if(!ink_u64_lt(n,sq)){lo=mid;}else{hi=mid;}}
 let sq=ink_u64_mul(InkU64(lo,0u),InkU64(lo,0u));let rem=ink_u64_sub(n,sq);
 if(ink_u64_lt(InkU64(lo,0u),rem)){lo++;}
 if(lo==0x1000000u){lo>>=1u;half++;}
 return (u32(half+127i)<<23u)|(lo&0x7fffffu);
}
fn ink_f32_div(a:u32,b:u32)->u32{
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(ink_f32_nan(a)||ink_f32_nan(b)||(aa==0u&&bb==0u)||(aa==0x7f800000u&&bb==aa)){return 0x7fc00000u;}
 if(aa==0x7f800000u||bb==0u){return sign|0x7f800000u;}
 if(aa==0u||bb==0x7f800000u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u))-127i;var eb=i32(max(rb,1u))-127i;
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 var e=ea-eb;if(sa<sb){sa<<=1u;e--;}
 let division=ink_u64_div(InkU64(sa<<26u,sa>>6u),InkU64(sb,0u));
 let extended=division.quotient.lo|select(0u,1u,!ink_u64_eq(division.remainder,InkU64(0u,0u)));
 return ink_f32_round(sign,e+127i,extended);
}
// mode: 0 trunc, 1 floor, 2 ceil, 3 ties-to-even.
fn ink_f32_integral(x:u32,mode:u32)->u32{
 let a=x&0x7fffffffu;let sign=x&0x80000000u;
 if(a>0x7f800000u){return 0x7fc00000u;}if(a>=0x4b000000u||a==0u){return x;}
 let e=i32((x>>23u)&255u)-127i;
 if(e<0i){var up=false;if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){up=a>0x3f000000u;}return sign|select(0u,0x3f800000u,up);}
 let shift=u32(23i-e);let mask=(1u<<shift)-1u;let fraction=a&mask;var rounded=a&~mask;var up=false;
 if(fraction!=0u){if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){let half=1u<<(shift-1u);up=fraction>half||(fraction==half&&((rounded>>shift)&1u)!=0u);}}
 if(up){rounded+=1u<<shift;}return sign|rounded;
}
fn ink_f32_from_u64(x:InkU64)->u32{
 if(ink_u64_eq(x,InkU64(0u,0u))){return 0u;}
 let leading=select(countLeadingZeros(x.lo)+32u,countLeadingZeros(x.hi),x.hi!=0u);let e=63u-leading;
 if(e<=23u){return ((e+127u)<<23u)|((x.lo<<(23u-e))&0x7fffffu);}
 let shift=e-23u;var sig=0u;var rem=InkU64(0u,0u);var half=InkU64(0u,0u);
 if(shift<32u){sig=(x.lo>>shift)|(x.hi<<(32u-shift));rem=InkU64(x.lo&((1u<<shift)-1u),0u);half=InkU64(1u<<(shift-1u),0u);}
 else if(shift==32u){sig=x.hi;rem=InkU64(x.lo,0u);half=InkU64(0x80000000u,0u);}
 else{sig=x.hi>>(shift-32u);rem=InkU64(x.lo,x.hi&((1u<<(shift-32u))-1u));half=InkU64(0u,1u<<(shift-33u));}
 if(ink_u64_lt(half,rem)||(ink_u64_eq(rem,half)&&(sig&1u)!=0u)){sig++;}
 var exponent=e+127u;if(sig==0x1000000u){sig>>=1u;exponent++;}
 return (exponent<<23u)|(sig&0x7fffffu);
}
fn ink_f32_from_i32(x:i32)->u32{let neg=x<0i;let magnitude=select(u32(x),0u-u32(x),neg);return ink_f32_from_u64(InkU64(magnitude,0u))|select(0u,0x80000000u,neg);}
struct InkBuffer_u32{data:array<u32,64>,length:u32,}
struct InkBuffer_InkU64{data:array<InkU64,64>,length:u32,}
struct InkBuffer_i32{data:array<i32,64>,length:u32,}
struct InkBuffer_bool{data:array<bool,64>,length:u32,}
struct R_Coefficients{ink_f_scale:u32,ink_f_bias:u32,}
@group(0) @binding(0) var<storage,read> a0:array<u32>;
@group(0) @binding(1) var<storage,read> a1:array<u32>;
@group(0) @binding(2) var<storage,read_write> output:array<u32>;
@compute @workgroup_size(1) fn main(@builtin(global_invocation_id) gid:vec3<u32>){
if(gid.x!=0u){return;}var t0:R_Coefficients=R_Coefficients(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t1:u32=a1[0u+(0u)*1u+0u];
var t2:R_Coefficients=t0;
var t3:u32=t1;
var t4:R_Coefficients=t2;
var t5:u32=t3;
var t6:R_Coefficients=t4;
var t7:u32=t5;
var t8:u32=t7;
var t9:u32=ink_f32_mul(t8,(t6).ink_f_scale);
var t10:u32=t9;
var t11:u32=ink_f32_add(t10,(t6).ink_f_bias);
var t12:u32=t11;
var t13:u32;
if (ink_f32_lt(0u,t12)) {
t13=t11;
} else {
t13=0u;
}
var t14:u32=t13;
var t15:u32=t14;
var t16:u32=ink_f32_mul(t15,(t6).ink_f_scale);
var t17:u32=t16;
var t18:u32=ink_f32_add(t17,(t6).ink_f_bias);
var t19:u32=t18;
var t20:u32=ink_f32_mul(t19,(t6).ink_f_scale);
var t21:u32=t20;
var t22:u32;
if (ink_f32_lt(0u,t21)) {
t22=t20;
} else {
t22=0u;
}
var t23:u32=t22;
var t24:u32=t23;
var t25:u32=ink_f32_add(t24,(t6).ink_f_bias);
var t26:u32=t25;
var t27:R_Coefficients=t4;
var t28:u32=t26;
var t29:u32=t28;
var t30:u32=ink_f32_mul(t29,(t27).ink_f_scale);
var t31:u32=t30;
var t32:u32=ink_f32_add(t31,(t27).ink_f_bias);
var t33:u32=t32;
var t34:u32;
if (ink_f32_lt(0u,t33)) {
t34=t32;
} else {
t34=0u;
}
var t35:u32=t34;
var t36:u32=t35;
var t37:u32=ink_f32_mul(t36,(t27).ink_f_scale);
var t38:u32=t37;
var t39:u32=ink_f32_add(t38,(t27).ink_f_bias);
var t40:u32=t39;
var t41:u32=ink_f32_mul(t40,(t27).ink_f_scale);
var t42:u32=t41;
var t43:u32;
if (ink_f32_lt(0u,t42)) {
t43=t41;
} else {
t43=0u;
}
var t44:u32=t43;
var t45:u32=t44;
var t46:u32=ink_f32_add(t45,(t27).ink_f_bias);
var t47:u32=t46;
var t48:R_Coefficients=t2;
var t49:u32=t47;
var t50:R_Coefficients=t48;
var t51:u32=t49;
var t52:u32=t51;
var t53:u32=ink_f32_mul(t52,(t50).ink_f_scale);
var t54:u32=t53;
var t55:u32=ink_f32_add(t54,(t50).ink_f_bias);
var t56:u32=t55;
var t57:u32;
if (ink_f32_lt(0u,t56)) {
t57=t55;
} else {
t57=0u;
}
var t58:u32=t57;
var t59:u32=t58;
var t60:u32=ink_f32_mul(t59,(t50).ink_f_scale);
var t61:u32=t60;
var t62:u32=ink_f32_add(t61,(t50).ink_f_bias);
var t63:u32=t62;
var t64:u32=ink_f32_mul(t63,(t50).ink_f_scale);
var t65:u32=t64;
var t66:u32;
if (ink_f32_lt(0u,t65)) {
t66=t64;
} else {
t66=0u;
}
var t67:u32=t66;
var t68:u32=t67;
var t69:u32=ink_f32_add(t68,(t50).ink_f_bias);
var t70:u32=t69;
var t71:R_Coefficients=t48;
var t72:u32=t70;
var t73:u32=t72;
var t74:u32=ink_f32_mul(t73,(t71).ink_f_scale);
var t75:u32=t74;
var t76:u32=ink_f32_add(t75,(t71).ink_f_bias);
var t77:u32=t76;
var t78:u32;
if (ink_f32_lt(0u,t77)) {
t78=t76;
} else {
t78=0u;
}
var t79:u32=t78;
var t80:u32=t79;
var t81:u32=ink_f32_mul(t80,(t71).ink_f_scale);
var t82:u32=t81;
var t83:u32=ink_f32_add(t82,(t71).ink_f_bias);
var t84:u32=t83;
var t85:u32=ink_f32_mul(t84,(t71).ink_f_scale);
var t86:u32=t85;
var t87:u32;
if (ink_f32_lt(0u,t86)) {
t87=t85;
} else {
t87=0u;
}
var t88:u32=t87;
var t89:u32=t88;
var t90:u32=ink_f32_add(t89,(t71).ink_f_bias);
var t91:u32=t90;
var t92:R_Coefficients=t0;
var t93:u32=t91;
var t94:R_Coefficients=t92;
var t95:u32=t93;
var t96:R_Coefficients=t94;
var t97:u32=t95;
var t98:u32=t97;
var t99:u32=ink_f32_mul(t98,(t96).ink_f_scale);
var t100:u32=t99;
var t101:u32=ink_f32_add(t100,(t96).ink_f_bias);
var t102:u32=t101;
var t103:u32;
if (ink_f32_lt(0u,t102)) {
t103=t101;
} else {
t103=0u;
}
var t104:u32=t103;
var t105:u32=t104;
var t106:u32=ink_f32_mul(t105,(t96).ink_f_scale);
var t107:u32=t106;
var t108:u32=ink_f32_add(t107,(t96).ink_f_bias);
var t109:u32=t108;
var t110:u32=ink_f32_mul(t109,(t96).ink_f_scale);
var t111:u32=t110;
var t112:u32;
if (ink_f32_lt(0u,t111)) {
t112=t110;
} else {
t112=0u;
}
var t113:u32=t112;
var t114:u32=t113;
var t115:u32=ink_f32_add(t114,(t96).ink_f_bias);
var t116:u32=t115;
var t117:R_Coefficients=t94;
var t118:u32=t116;
var t119:u32=t118;
var t120:u32=ink_f32_mul(t119,(t117).ink_f_scale);
var t121:u32=t120;
var t122:u32=ink_f32_add(t121,(t117).ink_f_bias);
var t123:u32=t122;
var t124:u32;
if (ink_f32_lt(0u,t123)) {
t124=t122;
} else {
t124=0u;
}
var t125:u32=t124;
var t126:u32=t125;
var t127:u32=ink_f32_mul(t126,(t117).ink_f_scale);
var t128:u32=t127;
var t129:u32=ink_f32_add(t128,(t117).ink_f_bias);
var t130:u32=t129;
var t131:u32=ink_f32_mul(t130,(t117).ink_f_scale);
var t132:u32=t131;
var t133:u32;
if (ink_f32_lt(0u,t132)) {
t133=t131;
} else {
t133=0u;
}
var t134:u32=t133;
var t135:u32=t134;
var t136:u32=ink_f32_add(t135,(t117).ink_f_bias);
var t137:u32=t136;
var t138:R_Coefficients=t92;
var t139:u32=t137;
var t140:R_Coefficients=t138;
var t141:u32=t139;
var t142:u32=t141;
var t143:u32=ink_f32_mul(t142,(t140).ink_f_scale);
var t144:u32=t143;
var t145:u32=ink_f32_add(t144,(t140).ink_f_bias);
var t146:u32=t145;
var t147:u32;
if (ink_f32_lt(0u,t146)) {
t147=t145;
} else {
t147=0u;
}
var t148:u32=t147;
var t149:u32=t148;
var t150:u32=ink_f32_mul(t149,(t140).ink_f_scale);
var t151:u32=t150;
var t152:u32=ink_f32_add(t151,(t140).ink_f_bias);
var t153:u32=t152;
var t154:u32=ink_f32_mul(t153,(t140).ink_f_scale);
var t155:u32=t154;
var t156:u32;
if (ink_f32_lt(0u,t155)) {
t156=t154;
} else {
t156=0u;
}
var t157:u32=t156;
var t158:u32=t157;
var t159:u32=ink_f32_add(t158,(t140).ink_f_bias);
var t160:u32=t159;
var t161:R_Coefficients=t138;
var t162:u32=t160;
var t163:u32=t162;
var t164:u32=ink_f32_mul(t163,(t161).ink_f_scale);
var t165:u32=t164;
var t166:u32=ink_f32_add(t165,(t161).ink_f_bias);
var t167:u32=t166;
var t168:u32;
if (ink_f32_lt(0u,t167)) {
t168=t166;
} else {
t168=0u;
}
var t169:u32=t168;
var t170:u32=t169;
var t171:u32=ink_f32_mul(t170,(t161).ink_f_scale);
var t172:u32=t171;
var t173:u32=ink_f32_add(t172,(t161).ink_f_bias);
var t174:u32=t173;
var t175:u32=ink_f32_mul(t174,(t161).ink_f_scale);
var t176:u32=t175;
var t177:u32;
if (ink_f32_lt(0u,t176)) {
t177=t175;
} else {
t177=0u;
}
var t178:u32=t177;
var t179:u32=t178;
var t180:u32=ink_f32_add(t179,(t161).ink_f_bias);
var t181:u32=t180;
var t182:R_Coefficients=R_Coefficients(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t183:u32=t181;
var t184:R_Coefficients=t182;
var t185:u32=t183;
var t186:R_Coefficients=t184;
var t187:u32=t185;
var t188:R_Coefficients=t186;
var t189:u32=t187;
var t190:u32=t189;
var t191:u32=ink_f32_mul(t190,(t188).ink_f_scale);
var t192:u32=t191;
var t193:u32=ink_f32_add(t192,(t188).ink_f_bias);
var t194:u32=t193;
var t195:u32;
if (ink_f32_lt(0u,t194)) {
t195=t193;
} else {
t195=0u;
}
var t196:u32=t195;
var t197:u32=t196;
var t198:u32=ink_f32_mul(t197,(t188).ink_f_scale);
var t199:u32=t198;
var t200:u32=ink_f32_add(t199,(t188).ink_f_bias);
var t201:u32=t200;
var t202:u32=ink_f32_mul(t201,(t188).ink_f_scale);
var t203:u32=t202;
var t204:u32;
if (ink_f32_lt(0u,t203)) {
t204=t202;
} else {
t204=0u;
}
var t205:u32=t204;
var t206:u32=t205;
var t207:u32=ink_f32_add(t206,(t188).ink_f_bias);
var t208:u32=t207;
var t209:R_Coefficients=t186;
var t210:u32=t208;
var t211:u32=t210;
var t212:u32=ink_f32_mul(t211,(t209).ink_f_scale);
var t213:u32=t212;
var t214:u32=ink_f32_add(t213,(t209).ink_f_bias);
var t215:u32=t214;
var t216:u32;
if (ink_f32_lt(0u,t215)) {
t216=t214;
} else {
t216=0u;
}
var t217:u32=t216;
var t218:u32=t217;
var t219:u32=ink_f32_mul(t218,(t209).ink_f_scale);
var t220:u32=t219;
var t221:u32=ink_f32_add(t220,(t209).ink_f_bias);
var t222:u32=t221;
var t223:u32=ink_f32_mul(t222,(t209).ink_f_scale);
var t224:u32=t223;
var t225:u32;
if (ink_f32_lt(0u,t224)) {
t225=t223;
} else {
t225=0u;
}
var t226:u32=t225;
var t227:u32=t226;
var t228:u32=ink_f32_add(t227,(t209).ink_f_bias);
var t229:u32=t228;
var t230:R_Coefficients=t184;
var t231:u32=t229;
var t232:R_Coefficients=t230;
var t233:u32=t231;
var t234:u32=t233;
var t235:u32=ink_f32_mul(t234,(t232).ink_f_scale);
var t236:u32=t235;
var t237:u32=ink_f32_add(t236,(t232).ink_f_bias);
var t238:u32=t237;
var t239:u32;
if (ink_f32_lt(0u,t238)) {
t239=t237;
} else {
t239=0u;
}
var t240:u32=t239;
var t241:u32=t240;
var t242:u32=ink_f32_mul(t241,(t232).ink_f_scale);
var t243:u32=t242;
var t244:u32=ink_f32_add(t243,(t232).ink_f_bias);
var t245:u32=t244;
var t246:u32=ink_f32_mul(t245,(t232).ink_f_scale);
var t247:u32=t246;
var t248:u32;
if (ink_f32_lt(0u,t247)) {
t248=t246;
} else {
t248=0u;
}
var t249:u32=t248;
var t250:u32=t249;
var t251:u32=ink_f32_add(t250,(t232).ink_f_bias);
var t252:u32=t251;
var t253:R_Coefficients=t230;
var t254:u32=t252;
var t255:u32=t254;
var t256:u32=ink_f32_mul(t255,(t253).ink_f_scale);
var t257:u32=t256;
var t258:u32=ink_f32_add(t257,(t253).ink_f_bias);
var t259:u32=t258;
var t260:u32;
if (ink_f32_lt(0u,t259)) {
t260=t258;
} else {
t260=0u;
}
var t261:u32=t260;
var t262:u32=t261;
var t263:u32=ink_f32_mul(t262,(t253).ink_f_scale);
var t264:u32=t263;
var t265:u32=ink_f32_add(t264,(t253).ink_f_bias);
var t266:u32=t265;
var t267:u32=ink_f32_mul(t266,(t253).ink_f_scale);
var t268:u32=t267;
var t269:u32;
if (ink_f32_lt(0u,t268)) {
t269=t267;
} else {
t269=0u;
}
var t270:u32=t269;
var t271:u32=t270;
var t272:u32=ink_f32_add(t271,(t253).ink_f_bias);
var t273:u32=t272;
var t274:R_Coefficients=t182;
var t275:u32=t273;
var t276:R_Coefficients=t274;
var t277:u32=t275;
var t278:R_Coefficients=t276;
var t279:u32=t277;
var t280:u32=t279;
var t281:u32=ink_f32_mul(t280,(t278).ink_f_scale);
var t282:u32=t281;
var t283:u32=ink_f32_add(t282,(t278).ink_f_bias);
var t284:u32=t283;
var t285:u32;
if (ink_f32_lt(0u,t284)) {
t285=t283;
} else {
t285=0u;
}
var t286:u32=t285;
var t287:u32=t286;
var t288:u32=ink_f32_mul(t287,(t278).ink_f_scale);
var t289:u32=t288;
var t290:u32=ink_f32_add(t289,(t278).ink_f_bias);
var t291:u32=t290;
var t292:u32=ink_f32_mul(t291,(t278).ink_f_scale);
var t293:u32=t292;
var t294:u32;
if (ink_f32_lt(0u,t293)) {
t294=t292;
} else {
t294=0u;
}
var t295:u32=t294;
var t296:u32=t295;
var t297:u32=ink_f32_add(t296,(t278).ink_f_bias);
var t298:u32=t297;
var t299:R_Coefficients=t276;
var t300:u32=t298;
var t301:u32=t300;
var t302:u32=ink_f32_mul(t301,(t299).ink_f_scale);
var t303:u32=t302;
var t304:u32=ink_f32_add(t303,(t299).ink_f_bias);
var t305:u32=t304;
var t306:u32;
if (ink_f32_lt(0u,t305)) {
t306=t304;
} else {
t306=0u;
}
var t307:u32=t306;
var t308:u32=t307;
var t309:u32=ink_f32_mul(t308,(t299).ink_f_scale);
var t310:u32=t309;
var t311:u32=ink_f32_add(t310,(t299).ink_f_bias);
var t312:u32=t311;
var t313:u32=ink_f32_mul(t312,(t299).ink_f_scale);
var t314:u32=t313;
var t315:u32;
if (ink_f32_lt(0u,t314)) {
t315=t313;
} else {
t315=0u;
}
var t316:u32=t315;
var t317:u32=t316;
var t318:u32=ink_f32_add(t317,(t299).ink_f_bias);
var t319:u32=t318;
var t320:R_Coefficients=t274;
var t321:u32=t319;
var t322:R_Coefficients=t320;
var t323:u32=t321;
var t324:u32=t323;
var t325:u32=ink_f32_mul(t324,(t322).ink_f_scale);
var t326:u32=t325;
var t327:u32=ink_f32_add(t326,(t322).ink_f_bias);
var t328:u32=t327;
var t329:u32;
if (ink_f32_lt(0u,t328)) {
t329=t327;
} else {
t329=0u;
}
var t330:u32=t329;
var t331:u32=t330;
var t332:u32=ink_f32_mul(t331,(t322).ink_f_scale);
var t333:u32=t332;
var t334:u32=ink_f32_add(t333,(t322).ink_f_bias);
var t335:u32=t334;
var t336:u32=ink_f32_mul(t335,(t322).ink_f_scale);
var t337:u32=t336;
var t338:u32;
if (ink_f32_lt(0u,t337)) {
t338=t336;
} else {
t338=0u;
}
var t339:u32=t338;
var t340:u32=t339;
var t341:u32=ink_f32_add(t340,(t322).ink_f_bias);
var t342:u32=t341;
var t343:R_Coefficients=t320;
var t344:u32=t342;
var t345:u32=t344;
var t346:u32=ink_f32_mul(t345,(t343).ink_f_scale);
var t347:u32=t346;
var t348:u32=ink_f32_add(t347,(t343).ink_f_bias);
var t349:u32=t348;
var t350:u32;
if (ink_f32_lt(0u,t349)) {
t350=t348;
} else {
t350=0u;
}
var t351:u32=t350;
var t352:u32=t351;
var t353:u32=ink_f32_mul(t352,(t343).ink_f_scale);
var t354:u32=t353;
var t355:u32=ink_f32_add(t354,(t343).ink_f_bias);
var t356:u32=t355;
var t357:u32=ink_f32_mul(t356,(t343).ink_f_scale);
var t358:u32=t357;
var t359:u32;
if (ink_f32_lt(0u,t358)) {
t359=t357;
} else {
t359=0u;
}
var t360:u32=t359;
var t361:u32=t360;
var t362:u32=ink_f32_add(t361,(t343).ink_f_bias);
var t363:u32=t362;
output[0u+0u]=bitcast<u32>(t363);


}