from pathlib import Path
import hashlib,json,time
from ink_knowledge import Store,canonical,identity,semantic_entry
from ink_knowledge.proposal_views import ProposalViews as Eager
from adaptive_views import ProposalViews as Adaptive
from producers.semantic_laws import value,var,word,binary,law
from producers.frozen_laws import index,load,closure
b=Path('build/v8-variable-power-cases/adaptive-transport');source=Store.publish(b/'source',[]);s=value('U32');x=var(s,'x');good=semantic_entry(law({'x':s},binary('+',x,word('U32',0)),x));gid=identity(good);noise={hashlib.sha256(('unused/'+str(i)).encode()).hexdigest():dict(dependencies=[])for i in range(2048)};data=Path('knowledge/producers/data/v8-integer-laws');root=load(data,next(r for r in index(data)if r['name']=='u32_rem_or_variable_power_guard'));rid=identity(semantic_entry(root));large={identity(semantic_entry(l)):semantic_entry(l)for _,l in closure(data,[('root',root)])};rows=[]
for label,objects,roots in [('small',{**noise,gid:good},[gid]),('large',large,[rid]),('large-global',{**noise,**large},[rid])]:
 outputs={}
 for name,cls in [('eager',Eager),('adaptive',Adaptive)]:
  start=time.monotonic();v=cls(source,objects,b/(label+'-'+name));constructed=time.monotonic()-start;start=time.monotonic();view=v.bundle(roots);seconds=time.monotonic()-start;raw=canonical(view);outputs[name]=raw;rows.append(dict(label=label,method=name,construction_seconds=str(constructed),bundle_seconds=str(seconds),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),tree_files=len(list((b/(label+'-'+name)).rglob('trees/*.json')))));print(json.dumps(rows[-1]),flush=True)
 if label!='small':assert outputs['eager']==outputs['adaptive']
 else:assert rows[-1]['tree_files']<rows[-2]['tree_files']
(b/'terminal.json').write_text(json.dumps(dict(schema=1,exit_status=0,rows=rows,scope='Exact transport/metadata only; unused dummy candidate bodies are never exported or admitted. Large real checked witness packets remain byte-identical to eager compact transport. No new production code or broad speed claim.'),indent=2))
