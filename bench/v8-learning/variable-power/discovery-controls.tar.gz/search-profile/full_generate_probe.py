from pathlib import Path
import cProfile,pstats,json,sqlite3,time
from ink_knowledge import Store
from ink_knowledge.proposals import generate
b=Path('build/v8-variable-power-cases/search-profile');root=b/'indexed-final-cli/knowledge'
with sqlite3.connect(root/'index.sqlite')as db:db.execute('CREATE INDEX IF NOT EXISTS entry_kind_lookup ON entries(kind,id)')
s=Store(root,root/'store/snapshots/14edbdd3dea8f2bea214b8badba800a004dfbeffc7c4feb02be8b9a1ad45e739.json');subject=json.loads((b/'subject.json').read_bytes());core=json.loads(Path('build/v8-variable-power-cases/corpus/inputs/44dc64a74456ff85189fc9d8969a5d23ca8b1fdfc43db8a28b18656980a840b3.core.json').read_bytes());profile=cProfile.Profile();start=time.monotonic();profile.enable();objects,receipts=generate(subject,core,s,compiler=Path('build/v8-proof-dependencies-final-cli/frozen/ink-integrated').resolve());profile.disable();print('seconds',time.monotonic()-start,'objects',len(objects),flush=True);pstats.Stats(profile).sort_stats('cumtime').print_stats(24);(b/'full-generate-terminal.json').write_text(json.dumps(dict(schema=1,exit_status=0,objects=len(objects),receipts=receipts)))
