module variable_remainder; fn reduce(xs:List<u32>,y:u32,fallback:u32)->u32{return foldl(xs,0,fn(x)=>fn(a)=>a+rem_or(x,y,fallback));}
pub fn score(xs:List<u32>,y:u32,fallback:u32,cohort:u32)->u32{return reduce(xs,y,fallback)+cohort;}
