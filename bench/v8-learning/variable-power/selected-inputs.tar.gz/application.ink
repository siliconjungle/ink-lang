module guarded_remainder; pub fn calculate(x:u32,y:u32,default:u32)->u32{return rem_or(x,y,default);}
