module power_remainder_author; fn identity(x:u32)->u32{return x;}
