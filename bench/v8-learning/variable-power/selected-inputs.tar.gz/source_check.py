from pathlib import Path
import json,subprocess,hashlib,tarfile
from ink_knowledge import Store,canonical
from ink_planner.semantic_search import positions,match
b=Path('build/v8-variable-power-cases');compiler=Path('build/v8-proof-dependencies-merged/frozen/ink-integrated').resolve();source=b/'application.ink';source.write_text('module guarded_remainder; pub fn calculate(x:u32,y:u32,default:u32)->u32{return rem_or(x,y,default);}\n')
def run(*args):return subprocess.run([str(compiler),*map(str,args)],capture_output=True,text=True,check=True,timeout=120)
run('emit-core',source,'-o',b/'application.core.json');run('emit-semantic',b/'application.core.json','--core','-o',b/'application.subject.json');subject=json.loads((b/'application.subject.json').read_bytes());law=json.loads((b/'law.json').read_bytes());terminal=json.loads((b/'terminal.json').read_bytes());store=Store(b/'candidate');applications=[]
for function,body in subject['functions'].items():
 for path,target in positions(body):
  arguments={}
  if match(law['from'],target,law['params'],arguments):applications.append(dict(function=function,path=list(path),law=terminal['entry'],arguments=arguments,premises=[]))
assert len(applications)==1
selection=dict(schema=1,semantics='ink-evidence-v1',input_core_sha256=subject['input_core_sha256'],knowledge=store.bundle([terminal['entry']]),applications=applications);raw=canonical(selection);(b/'application.selection.json').write_bytes(raw);r=run('check-selection',b/'application.core.json',b/'application.selection.json');(b/'application.check.stdout').write_text(r.stdout);(b/'application.check.stderr').write_text(r.stderr)
with tarfile.open('bench/v8-learning/proof-dependencies/selected-inputs.tar.gz')as a:plan=json.load(a.extractfile('program/baseline.plan.json'))
plan.update(input_core_sha256=subject['input_core_sha256'],steps=[dict(kind='rewrite',package=selection)]);(b/'application.plan.json').write_bytes(canonical(plan));r=run('check-plan',b/'application.core.json',b/'application.plan.json','--core');(b/'application.plan.stdout').write_text(r.stdout);(b/'application.plan.stderr').write_text(r.stderr)
result=dict(schema=1,exit_status=0,source=subject['input_core_sha256'],law=terminal['law'],entry=terminal['entry'],selection_bytes=len(raw),plan_bytes=(b/'application.plan.json').stat().st_size,compiler_sha256=hashlib.sha256(compiler.read_bytes()).hexdigest(),scope='Ordinary one-site source selection and complete plan replay under unchanged16MB input/catalogue budgets. No runtime, default exposure or profitability claim.');(b/'source-terminal.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
