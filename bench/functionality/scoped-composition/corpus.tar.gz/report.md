# Planning corpus report

Target `javascript`, effort `quick`, compiler `9834b846ce0e`, knowledge snapshot `14edbdd3dea8`.

| Measure | Value |
|---|---:|
| Programs compiled | 10 / 10 |
| With an admitted rewrite alternative | 1 |
| With any knowledge-backed alternative | 1 |
| Selecting an alternative under defaults | 0 |
| Stopped by the time budget | 10 |
| Median planning seconds | 47.234 |
| Laws admitted (in 2+ programs) | 1 (0) |
| Representations admitted | 0 |

## Programs

| Program | Seconds | Stop | Matched | Admitted | Rejected | Unchecked | Rewrite alts | Last gate |
|---|---:|---|---:|---:|---:|---:|---:|---|
| sequence-every | 52 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| ast-ancestor | 53 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| text-lines | 43 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| drawing-hit | 46 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| particle-step | 55 | time | 0 | 0 | 0 | 0 | 1 | measurement_evidence |
| spatial-collision | 38 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| index-membership | 35 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| incremental-distinct | 45 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| bulk-update | 49 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| compact-set | 49 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |

## Near misses

Checker rejection gates: none

| Failed premise shape | Rejections | Programs |
|---|---:|---|

| Failed premise as instantiated in the program | Rejections | Programs |
|---|---:|---|

## Where planning time went

| Recipe | Seconds | Share |
|---|---:|---:|
| maintained-folds | 12.11 | 42% |
| all-published-packages | 5.37 | 19% |
| database-source-algorithms | 5.12 | 18% |
| proved-observations | 2.58 | 9% |
| guarded-parameter-cache | 1.13 | 4% |
| scalar-observation-arguments | 0.8 | 3% |
| pure-routing | 0.61 | 2% |
| source-capabilities | 0.52 | 2% |
| whole-state-protocols | 0.48 | 2% |
| compact-observer | 0.0 | 0% |
| representation-products | 0.0 | 0% |
| first-order-choices | 0.0 | 0% |
| migration-bridges | 0.0 | 0% |
| residual-execution-carriers | 0.0 | 0% |
| graph-resources | 0.0 | 0% |

## Admitted knowledge by program

| Entry | Kind | Programs |
|---|---|---|
| 0ed2e74a78dff510 | law | particle-step |

Observed default planning on a fixed corpus; no proof, applicability or profitability authority.
