# Planning corpus report

Target `javascript`, effort `quick`, compiler `6399bf6717af`, knowledge snapshot `14edbdd3dea8`.

| Measure | Value |
|---|---:|
| Programs compiled | 1 / 1 |
| With an admitted rewrite alternative | 0 |
| With any knowledge-backed alternative | 0 |
| Selecting an alternative under defaults | 0 |
| Stopped by the time budget | 1 |
| Median planning seconds | 29.195 |
| Laws admitted (in 2+ programs) | 0 (0) |
| Representations admitted | 0 |

## Programs

| Program | Seconds | Stop | Matched | Admitted | Rejected | Unchecked | Rewrite alts | Last gate |
|---|---:|---|---:|---:|---:|---:|---:|---|
| sequence-every | 29 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |

## Near misses

Checker rejection gates: none

| Failed premise shape | Rejections | Programs |
|---|---:|---|

| Failed premise as instantiated in the program | Rejections | Programs |
|---|---:|---|

## Where planning time went

| Recipe | Seconds | Share |
|---|---:|---:|
| proved-observations | 2.08 | 46% |
| maintained-folds | 0.74 | 16% |
| pure-routing | 0.68 | 15% |
| all-published-packages | 0.26 | 6% |
| database-source-algorithms | 0.26 | 6% |
| guarded-parameter-cache | 0.14 | 3% |
| scalar-observation-arguments | 0.13 | 3% |
| source-capabilities | 0.12 | 3% |
| whole-state-protocols | 0.12 | 3% |
| compact-observer | 0.0 | 0% |
| representation-products | 0.0 | 0% |
| first-order-choices | 0.0 | 0% |
| migration-bridges | 0.0 | 0% |
| residual-execution-carriers | 0.0 | 0% |
| graph-resources | 0.0 | 0% |

## Admitted knowledge by program

| Entry | Kind | Programs |
|---|---|---|

Observed default planning on a fixed corpus; no proof, applicability or profitability authority.
