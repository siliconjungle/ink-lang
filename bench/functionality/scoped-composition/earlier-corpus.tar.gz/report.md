# Planning corpus report

Target `javascript`, effort `quick`, compiler `6399bf6717af`, knowledge snapshot `14edbdd3dea8`.

| Measure | Value |
|---|---:|
| Programs compiled | 10 / 10 |
| With an admitted rewrite alternative | 2 |
| With any knowledge-backed alternative | 2 |
| Selecting an alternative under defaults | 0 |
| Stopped by the time budget | 10 |
| Median planning seconds | 36.438 |
| Laws admitted (in 2+ programs) | 5 (0) |
| Representations admitted | 0 |

## Programs

| Program | Seconds | Stop | Matched | Admitted | Rejected | Unchecked | Rewrite alts | Last gate |
|---|---:|---|---:|---:|---:|---:|---:|---|
| sequence-every | 37 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| ast-ancestor | 36 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| text-lines | 34 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| drawing-hit | 37 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| particle-step | 44 | time | 1 | 1 | 0 | 0 | 1 | measurement_evidence |
| spatial-collision | 33 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| index-membership | 35 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| incremental-distinct | 29 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| bulk-update | 63 | time | 0 | 0 | 0 | 0 | 8 | measurement_evidence |
| compact-set | 42 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |

## Near misses

Checker rejection gates: none

| Failed premise shape | Rejections | Programs |
|---|---:|---|

| Failed premise as instantiated in the program | Rejections | Programs |
|---|---:|---|

## Where planning time went

| Recipe | Seconds | Share |
|---|---:|---:|
| proved-observations | 22.49 | 46% |
| maintained-folds | 9.47 | 20% |
| all-published-packages | 4.28 | 9% |
| database-source-algorithms | 4.19 | 9% |
| semantic-laws | 2.43 | 5% |
| pure-routing | 1.77 | 4% |
| source-capabilities | 1.22 | 2% |
| guarded-parameter-cache | 1.13 | 2% |
| scalar-observation-arguments | 0.75 | 2% |
| whole-state-protocols | 0.63 | 1% |
| compact-observer | 0.0 | 0% |
| representation-products | 0.0 | 0% |
| first-order-choices | 0.0 | 0% |
| migration-bridges | 0.0 | 0% |
| residual-execution-carriers | 0.0 | 0% |

## Admitted knowledge by program

| Entry | Kind | Programs |
|---|---|---|
| 0ed2e74a78dff510 | law | particle-step |
| 7069b2b125e492c9 | law | bulk-update |
| 8c2dc4e9d4ed881c | law | bulk-update |
| 8e2c50472eec5ace | law | bulk-update |
| f5a2171264a0873c | law | bulk-update |

Observed default planning on a fixed corpus; no proof, applicability or profitability authority.
