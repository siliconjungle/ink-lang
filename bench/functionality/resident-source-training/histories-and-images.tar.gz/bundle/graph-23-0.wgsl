// Exact wrapping u64 over two storage lanes. No floating point intermediates.
struct InkU64 {lo:u32,hi:u32,}
struct InkDiv64 {quotient:InkU64,remainder:InkU64,}
fn ink_u64_shl(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64(a.lo<<k,(a.hi<<k)|(a.lo>>(32u-k)));}return InkU64(0u,a.lo<<(k-32u));}
fn ink_u64_shr(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64((a.lo>>k)|(a.hi<<(32u-k)),a.hi>>k);}return InkU64(a.hi>>(k-32u),0u);}
fn ink_u64_rol(a:InkU64,count:u32)->InkU64{let k=count&63u;let l=ink_u64_shl(a,k);let r=ink_u64_shr(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_ror(a:InkU64,count:u32)->InkU64{let k=count&63u;let r=ink_u64_shr(a,k);let l=ink_u64_shl(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_eq(a:InkU64,b:InkU64)->bool{return a.lo==b.lo&&a.hi==b.hi;}
fn ink_u64_lt(a:InkU64,b:InkU64)->bool{return a.hi<b.hi||(a.hi==b.hi&&a.lo<b.lo);}
fn ink_u64_add(a:InkU64,b:InkU64)->InkU64{let lo=a.lo+b.lo;return InkU64(lo,a.hi+b.hi+select(0u,1u,lo<a.lo));}
fn ink_u64_sub(a:InkU64,b:InkU64)->InkU64{return InkU64(a.lo-b.lo,a.hi-b.hi-select(0u,1u,a.lo<b.lo));}
fn ink_u64_mul(a:InkU64,b:InkU64)->InkU64{let al=a.lo&65535u;let ah=a.lo>>16u;let bl=b.lo&65535u;let bh=b.lo>>16u;let p=al*bl;let x=ah*bl;let y=al*bh;let mid=(p>>16u)+(x&65535u)+(y&65535u);let high=ah*bh+(x>>16u)+(y>>16u)+(mid>>16u);return InkU64((mid<<16u)|(p&65535u),high+a.lo*b.hi+a.hi*b.lo);}
fn ink_u64_div(a:InkU64,b:InkU64)->InkDiv64{var q=InkU64(0u,0u);var r=InkU64(0u,0u);var cursor=64u;loop{if(cursor==0u){break;}cursor--;var bit=0u;if(cursor>=32u){bit=(a.hi>>(cursor-32u))&1u;}else{bit=(a.lo>>cursor)&1u;}let overflow=r.hi>>31u;r=InkU64((r.lo<<1u)|bit,(r.hi<<1u)|(r.lo>>31u));if(overflow!=0u||!ink_u64_lt(r,b)){r=ink_u64_sub(r,b);if(cursor>=32u){q.hi|=1u<<(cursor-32u);}else{q.lo|=1u<<cursor;}}}return InkDiv64(q,r);}
// Binary32 evaluated with integer lanes: round-to-nearest, ties-to-even,
// gradual underflow, signed zero and canonical arithmetic NaN.
fn ink_f32_nan(x:u32)->bool{return (x&0x7fffffffu)>0x7f800000u;}
fn ink_f32_eq(a:u32,b:u32)->bool{return !ink_f32_nan(a)&&!ink_f32_nan(b)&&(a==b||((a|b)&0x7fffffffu)==0u);}
fn ink_f32_lt(a:u32,b:u32)->bool{
 if(ink_f32_nan(a)||ink_f32_nan(b)||ink_f32_eq(a,b)){return false;}
 if((a^b)&0x80000000u)!=0u{return (a&0x80000000u)!=0u;}
 if((a&0x80000000u)!=0u){return a>b;}return a<b;
}
fn ink_f32_jam(x:u32,n:u32)->u32{if(n==0u){return x;}if(n>=32u){return select(0u,1u,x!=0u);}return (x>>n)|select(0u,1u,(x&((1u<<n)-1u))!=0u);}
fn ink_f32_round(sign:u32,exponent:i32,extended:u32)->u32{
 var e=exponent;var s=extended;
 if(e<1i){s=ink_f32_jam(s,u32(1i-e));e=1i;}
 let tail=s&7u;var sig=s>>3u;
 if(tail>4u||(tail==4u&&(sig&1u)!=0u)){sig++;}
 if(sig>=0x1000000u){sig>>=1u;e++;}
 if(e>=255i){return sign|0x7f800000u;}
 if(sig==0u){return sign;}
 let raw=select(u32(e),0u,e==1i&&sig<0x800000u);
 return sign|(raw<<23u)|(sig&0x7fffffu);
}
fn ink_f32_add(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 var x=a;var y=b;if((x&0x7fffffffu)<(y&0x7fffffffu)){x=b;y=a;}
 let ax=x&0x7fffffffu;let ay=y&0x7fffffffu;let sign=x&0x80000000u;
 if(ax==0x7f800000u){if(ay==ax&&((x^y)&0x80000000u)!=0u){return 0x7fc00000u;}return x;}
 let rx=(x>>23u)&255u;let ry=(y>>23u)&255u;var e=i32(max(rx,1u));
 var sx=((x&0x7fffffu)|select(0u,0x800000u,rx!=0u))<<3u;
 let sy=ink_f32_jam(((y&0x7fffffu)|select(0u,0x800000u,ry!=0u))<<3u,u32(e)-max(ry,1u));
 if(((x^y)&0x80000000u)==0u){sx+=sy;if(sx>=0x8000000u){sx=ink_f32_jam(sx,1u);e++;}}
 else{sx-=sy;if(sx==0u){return 0u;}loop{if(sx>=0x4000000u||e<=1i){break;}sx<<=1u;e--;}}
 return ink_f32_round(sign,e,sx);
}
fn ink_f32_sub(a:u32,b:u32)->u32{return ink_f32_add(a,b^0x80000000u);}
fn ink_f32_mul(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(aa==0x7f800000u||bb==0x7f800000u){if(aa==0u||bb==0u){return 0x7fc00000u;}return sign|0x7f800000u;}
 if(aa==0u||bb==0u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u));var eb=i32(max(rb,1u));
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 let product=ink_u64_mul(InkU64(sa,0u),InkU64(sb,0u));let high=(product.hi&0x8000u)!=0u;
 let shift=select(20u,21u,high);let extended=(product.lo>>shift)|(product.hi<<(32u-shift))|select(0u,1u,(product.lo&((1u<<shift)-1u))!=0u);
 return ink_f32_round(sign,ea+eb-127i+select(0i,1i,high),extended);
}
// Exact sqrt and division use integer significands, independent of WGSL float
// approximation allowances and device flush-to-zero behavior.
fn ink_f32_sqrt(x:u32)->u32{
 let a=x&0x7fffffffu;if(a==0u){return x;}
 if(a>0x7f800000u||(x&0x80000000u)!=0u){return 0x7fc00000u;}
 if(a==0x7f800000u){return x;}
 let raw=(x>>23u)&255u;var m=(x&0x7fffffu)|select(0u,0x800000u,raw!=0u);var e=i32(max(raw,1u))-127i;
 loop{if(m>=0x800000u){break;}m<<=1u;e--;}
 let odd=e&1i;var half=(e-odd)/2i;let shift=23u+u32(odd);
 let n=InkU64(m<<shift,m>>(32u-shift));var lo=0u;var hi=0x1000000u;
 loop{if(lo+1u>=hi){break;}let mid=(lo+hi)>>1u;let sq=ink_u64_mul(InkU64(mid,0u),InkU64(mid,0u));if(!ink_u64_lt(n,sq)){lo=mid;}else{hi=mid;}}
 let sq=ink_u64_mul(InkU64(lo,0u),InkU64(lo,0u));let rem=ink_u64_sub(n,sq);
 if(ink_u64_lt(InkU64(lo,0u),rem)){lo++;}
 if(lo==0x1000000u){lo>>=1u;half++;}
 return (u32(half+127i)<<23u)|(lo&0x7fffffu);
}
fn ink_f32_div(a:u32,b:u32)->u32{
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(ink_f32_nan(a)||ink_f32_nan(b)||(aa==0u&&bb==0u)||(aa==0x7f800000u&&bb==aa)){return 0x7fc00000u;}
 if(aa==0x7f800000u||bb==0u){return sign|0x7f800000u;}
 if(aa==0u||bb==0x7f800000u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u))-127i;var eb=i32(max(rb,1u))-127i;
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 var e=ea-eb;if(sa<sb){sa<<=1u;e--;}
 let division=ink_u64_div(InkU64(sa<<26u,sa>>6u),InkU64(sb,0u));
 let extended=division.quotient.lo|select(0u,1u,!ink_u64_eq(division.remainder,InkU64(0u,0u)));
 return ink_f32_round(sign,e+127i,extended);
}
// mode: 0 trunc, 1 floor, 2 ceil, 3 ties-to-even.
fn ink_f32_integral(x:u32,mode:u32)->u32{
 let a=x&0x7fffffffu;let sign=x&0x80000000u;
 if(a>0x7f800000u){return 0x7fc00000u;}if(a>=0x4b000000u||a==0u){return x;}
 let e=i32((x>>23u)&255u)-127i;
 if(e<0i){var up=false;if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){up=a>0x3f000000u;}return sign|select(0u,0x3f800000u,up);}
 let shift=u32(23i-e);let mask=(1u<<shift)-1u;let fraction=a&mask;var rounded=a&~mask;var up=false;
 if(fraction!=0u){if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){let half=1u<<(shift-1u);up=fraction>half||(fraction==half&&((rounded>>shift)&1u)!=0u);}}
 if(up){rounded+=1u<<shift;}return sign|rounded;
}
fn ink_f32_from_u64(x:InkU64)->u32{
 if(ink_u64_eq(x,InkU64(0u,0u))){return 0u;}
 let leading=select(countLeadingZeros(x.lo)+32u,countLeadingZeros(x.hi),x.hi!=0u);let e=63u-leading;
 if(e<=23u){return ((e+127u)<<23u)|((x.lo<<(23u-e))&0x7fffffu);}
 let shift=e-23u;var sig=0u;var rem=InkU64(0u,0u);var half=InkU64(0u,0u);
 if(shift<32u){sig=(x.lo>>shift)|(x.hi<<(32u-shift));rem=InkU64(x.lo&((1u<<shift)-1u),0u);half=InkU64(1u<<(shift-1u),0u);}
 else if(shift==32u){sig=x.hi;rem=InkU64(x.lo,0u);half=InkU64(0x80000000u,0u);}
 else{sig=x.hi>>(shift-32u);rem=InkU64(x.lo,x.hi&((1u<<(shift-32u))-1u));half=InkU64(0u,1u<<(shift-33u));}
 if(ink_u64_lt(half,rem)||(ink_u64_eq(rem,half)&&(sig&1u)!=0u)){sig++;}
 var exponent=e+127u;if(sig==0x1000000u){sig>>=1u;exponent++;}
 return (exponent<<23u)|(sig&0x7fffffu);
}
fn ink_f32_from_i32(x:i32)->u32{let neg=x<0i;let magnitude=select(u32(x),0u-u32(x),neg);return ink_f32_from_u64(InkU64(magnitude,0u))|select(0u,0x80000000u,neg);}
struct InkBuffer_u32{data:array<u32,64>,length:u32,}
struct InkBuffer_InkU64{data:array<InkU64,64>,length:u32,}
struct InkBuffer_i32{data:array<i32,64>,length:u32,}
struct InkBuffer_bool{data:array<bool,64>,length:u32,}
struct R_Config{ink_f_rate:u32,ink_f_first_decay:u32,ink_f_second_decay:u32,ink_f_epsilon:u32,}
struct R_Parameter{ink_f_value:u32,ink_f_first:u32,ink_f_second:u32,ink_f_first_power:u32,ink_f_second_power:u32,ink_f_steps:u32,}
struct R___ink_differential_0{ink_f_value:u32,ink_f_tangent:u32,}
struct R___ink_differential_3{ink_f_value:R___ink_differential_0,ink_f_first:R___ink_differential_0,ink_f_second:R___ink_differential_0,ink_f_first_power:R___ink_differential_0,ink_f_second_power:R___ink_differential_0,ink_f_steps:u32,}
@group(0) @binding(0) var<storage,read> a0:array<u32>;
@group(0) @binding(1) var<storage,read> a1:array<u32>;
@group(0) @binding(2) var<storage,read> a2:array<u32>;
@group(0) @binding(3) var<storage,read> a3:array<u32>;
@group(0) @binding(4) var<storage,read> a4:array<u32>;
@group(0) @binding(5) var<storage,read_write> output:array<u32>;
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) gid:vec3<u32>){
let size=6u;let i=gid.x;if(i==0u){output[0]=size;}if(i<size){
switch(i){
case 0u:{
var t0:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t1:u32=a1[0u+(0u)*1u+0u];
var t2:u32=a4[0u+(0u)*1u+0u];
var t3:u32=0u;
var t4:R___ink_differential_0=t0;
var t5:u32=t1;
var t6:u32=t3;
var t7:u32=(t6 + 10u);
var t8:u32=t5;
var t9:R___ink_differential_0;
if ((t8 == t7)) {
t9=t4;
} else {
var t10:u32=t7;
var t11:R___ink_differential_3;if(t10<a3[0u]){
t11=R___ink_differential_3(R___ink_differential_0(a3[1u+(t10)*11u+0u],a3[1u+(t10)*11u+1u]),R___ink_differential_0(a3[1u+(t10)*11u+2u],a3[1u+(t10)*11u+3u]),R___ink_differential_0(a3[1u+(t10)*11u+4u],a3[1u+(t10)*11u+5u]),R___ink_differential_0(a3[1u+(t10)*11u+6u],a3[1u+(t10)*11u+7u]),R___ink_differential_0(a3[1u+(t10)*11u+8u],a3[1u+(t10)*11u+9u]),a3[1u+(t10)*11u+10u]);}else{
var t12:u32=0u;
var t13:u32=0u;
var t14:R___ink_differential_0=R___ink_differential_0(t12,t13);
var t15:u32=0u;
var t16:u32=0u;
var t17:R___ink_differential_0=R___ink_differential_0(t15,t16);
var t18:u32=0u;
var t19:u32=0u;
var t20:R___ink_differential_0=R___ink_differential_0(t18,t19);
var t21:u32=1065353216u;
var t22:u32=0u;
var t23:R___ink_differential_0=R___ink_differential_0(t21,t22);
var t24:u32=1065353216u;
var t25:u32=0u;
var t26:R___ink_differential_0=R___ink_differential_0(t24,t25);
var t27:u32=0u;
t11=R___ink_differential_3(t14,t17,t20,t23,t26,t27);}
t9=(t11).ink_f_value;
}
var t28:R___ink_differential_0=t9;
var t29:R___ink_differential_0=t28;
for(var t30=0u;t30<10u;t30++){
var t31:R___ink_differential_0=t29;
var t32:R___ink_differential_0=t0;
var t33:u32=t1;
var t34:u32=t3;
var t35:u32=(t34 + t30);
var t36:u32=t33;
var t37:R___ink_differential_0;
if ((t36 == t35)) {
t37=t32;
} else {
var t38:u32=t35;
var t39:R___ink_differential_3;if(t38<a3[0u]){
t39=R___ink_differential_3(R___ink_differential_0(a3[1u+(t38)*11u+0u],a3[1u+(t38)*11u+1u]),R___ink_differential_0(a3[1u+(t38)*11u+2u],a3[1u+(t38)*11u+3u]),R___ink_differential_0(a3[1u+(t38)*11u+4u],a3[1u+(t38)*11u+5u]),R___ink_differential_0(a3[1u+(t38)*11u+6u],a3[1u+(t38)*11u+7u]),R___ink_differential_0(a3[1u+(t38)*11u+8u],a3[1u+(t38)*11u+9u]),a3[1u+(t38)*11u+10u]);}else{
var t40:u32=0u;
var t41:u32=0u;
var t42:R___ink_differential_0=R___ink_differential_0(t40,t41);
var t43:u32=0u;
var t44:u32=0u;
var t45:R___ink_differential_0=R___ink_differential_0(t43,t44);
var t46:u32=0u;
var t47:u32=0u;
var t48:R___ink_differential_0=R___ink_differential_0(t46,t47);
var t49:u32=1065353216u;
var t50:u32=0u;
var t51:R___ink_differential_0=R___ink_differential_0(t49,t50);
var t52:u32=1065353216u;
var t53:u32=0u;
var t54:R___ink_differential_0=R___ink_differential_0(t52,t53);
var t55:u32=0u;
t39=R___ink_differential_3(t42,t45,t48,t51,t54,t55);}
t37=(t39).ink_f_value;
}
var t56:R___ink_differential_0=t37;
var t57:u32=t2;
var t58:u32=(t57 * 10u);
var t59:u32=(t58 + t30);
var t60:R___ink_differential_0;if(t59<a2[0u]){
t60=R___ink_differential_0(a2[1u+(t59)*2u+0u],a2[1u+(t59)*2u+1u]);}else{
var t61:u32=0u;
var t62:u32=0u;
t60=R___ink_differential_0(t61,t62);}
var t63:R___ink_differential_0=t60;
var t64:u32=(t56).ink_f_value;
var t65:u32=ink_f32_mul(t64,(t63).ink_f_value);
var t66:u32=t65;
var t67:u32=(t56).ink_f_tangent;
var t68:u32=ink_f32_mul(t67,(t63).ink_f_value);
var t69:u32=(t56).ink_f_value;
var t70:u32=ink_f32_add(t68,ink_f32_mul(t69,(t63).ink_f_tangent));
var t71:R___ink_differential_0=R___ink_differential_0(t66,t70);
var t72:u32=(t31).ink_f_value;
var t73:u32=ink_f32_add(t72,(t71).ink_f_value);
var t74:u32=t73;
var t75:u32=(t31).ink_f_tangent;
var t76:u32=ink_f32_add(t75,(t71).ink_f_tangent);
t29=R___ink_differential_0(t74,t76);
}
var t77:R___ink_differential_0=t29;
var t78:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t79:u32=a1[0u+(0u)*1u+0u];
var t80:u32=a4[0u+(0u)*1u+0u];
var t81:u32=11u;
var t82:R___ink_differential_0=t78;
var t83:u32=t79;
var t84:u32=t81;
var t85:u32=(t84 + 10u);
var t86:u32=t83;
var t87:R___ink_differential_0;
if ((t86 == t85)) {
t87=t82;
} else {
var t88:u32=t85;
var t89:R___ink_differential_3;if(t88<a3[0u]){
t89=R___ink_differential_3(R___ink_differential_0(a3[1u+(t88)*11u+0u],a3[1u+(t88)*11u+1u]),R___ink_differential_0(a3[1u+(t88)*11u+2u],a3[1u+(t88)*11u+3u]),R___ink_differential_0(a3[1u+(t88)*11u+4u],a3[1u+(t88)*11u+5u]),R___ink_differential_0(a3[1u+(t88)*11u+6u],a3[1u+(t88)*11u+7u]),R___ink_differential_0(a3[1u+(t88)*11u+8u],a3[1u+(t88)*11u+9u]),a3[1u+(t88)*11u+10u]);}else{
var t90:u32=0u;
var t91:u32=0u;
var t92:R___ink_differential_0=R___ink_differential_0(t90,t91);
var t93:u32=0u;
var t94:u32=0u;
var t95:R___ink_differential_0=R___ink_differential_0(t93,t94);
var t96:u32=0u;
var t97:u32=0u;
var t98:R___ink_differential_0=R___ink_differential_0(t96,t97);
var t99:u32=1065353216u;
var t100:u32=0u;
var t101:R___ink_differential_0=R___ink_differential_0(t99,t100);
var t102:u32=1065353216u;
var t103:u32=0u;
var t104:R___ink_differential_0=R___ink_differential_0(t102,t103);
var t105:u32=0u;
t89=R___ink_differential_3(t92,t95,t98,t101,t104,t105);}
t87=(t89).ink_f_value;
}
var t106:R___ink_differential_0=t87;
var t107:R___ink_differential_0=t106;
for(var t108=0u;t108<10u;t108++){
var t109:R___ink_differential_0=t107;
var t110:R___ink_differential_0=t78;
var t111:u32=t79;
var t112:u32=t81;
var t113:u32=(t112 + t108);
var t114:u32=t111;
var t115:R___ink_differential_0;
if ((t114 == t113)) {
t115=t110;
} else {
var t116:u32=t113;
var t117:R___ink_differential_3;if(t116<a3[0u]){
t117=R___ink_differential_3(R___ink_differential_0(a3[1u+(t116)*11u+0u],a3[1u+(t116)*11u+1u]),R___ink_differential_0(a3[1u+(t116)*11u+2u],a3[1u+(t116)*11u+3u]),R___ink_differential_0(a3[1u+(t116)*11u+4u],a3[1u+(t116)*11u+5u]),R___ink_differential_0(a3[1u+(t116)*11u+6u],a3[1u+(t116)*11u+7u]),R___ink_differential_0(a3[1u+(t116)*11u+8u],a3[1u+(t116)*11u+9u]),a3[1u+(t116)*11u+10u]);}else{
var t118:u32=0u;
var t119:u32=0u;
var t120:R___ink_differential_0=R___ink_differential_0(t118,t119);
var t121:u32=0u;
var t122:u32=0u;
var t123:R___ink_differential_0=R___ink_differential_0(t121,t122);
var t124:u32=0u;
var t125:u32=0u;
var t126:R___ink_differential_0=R___ink_differential_0(t124,t125);
var t127:u32=1065353216u;
var t128:u32=0u;
var t129:R___ink_differential_0=R___ink_differential_0(t127,t128);
var t130:u32=1065353216u;
var t131:u32=0u;
var t132:R___ink_differential_0=R___ink_differential_0(t130,t131);
var t133:u32=0u;
t117=R___ink_differential_3(t120,t123,t126,t129,t132,t133);}
t115=(t117).ink_f_value;
}
var t134:R___ink_differential_0=t115;
var t135:u32=t80;
var t136:u32=(t135 * 10u);
var t137:u32=(t136 + t108);
var t138:R___ink_differential_0;if(t137<a2[0u]){
t138=R___ink_differential_0(a2[1u+(t137)*2u+0u],a2[1u+(t137)*2u+1u]);}else{
var t139:u32=0u;
var t140:u32=0u;
t138=R___ink_differential_0(t139,t140);}
var t141:R___ink_differential_0=t138;
var t142:u32=(t134).ink_f_value;
var t143:u32=ink_f32_mul(t142,(t141).ink_f_value);
var t144:u32=t143;
var t145:u32=(t134).ink_f_tangent;
var t146:u32=ink_f32_mul(t145,(t141).ink_f_value);
var t147:u32=(t134).ink_f_value;
var t148:u32=ink_f32_add(t146,ink_f32_mul(t147,(t141).ink_f_tangent));
var t149:R___ink_differential_0=R___ink_differential_0(t144,t148);
var t150:u32=(t109).ink_f_value;
var t151:u32=ink_f32_add(t150,(t149).ink_f_value);
var t152:u32=t151;
var t153:u32=(t109).ink_f_tangent;
var t154:u32=ink_f32_add(t153,(t149).ink_f_tangent);
t107=R___ink_differential_0(t152,t154);
}
var t155:R___ink_differential_0=t107;
var t156:u32=(t155).ink_f_value;
var t157:u32=0u;
var t158:u32=0u;
var t159:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t157,t158)).ink_f_value,t156)) {
var t160:R___ink_differential_0=t77;
var t161:R___ink_differential_0=t155;
var t162:u32=(t160).ink_f_value;
var t163:u32=ink_f32_mul(t162,(t161).ink_f_value);
var t164:u32=t163;
var t165:u32=(t160).ink_f_tangent;
var t166:u32=ink_f32_mul(t165,(t161).ink_f_value);
var t167:u32=(t160).ink_f_value;
var t168:u32=ink_f32_add(t166,ink_f32_mul(t167,(t161).ink_f_tangent));
t159=R___ink_differential_0(t164,t168);
} else {
var t169:u32=0u;
var t170:u32=0u;
t159=R___ink_differential_0(t169,t170);
}
var t171:R___ink_differential_0=t159;
output[1u+i*2u+0u]=bitcast<u32>((t171).ink_f_value);
output[1u+i*2u+1u]=bitcast<u32>((t171).ink_f_tangent);

}
case 1u:{
var t172:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t173:u32=a1[0u+(0u)*1u+0u];
var t174:u32=a4[0u+(0u)*1u+0u];
var t175:u32=22u;
var t176:R___ink_differential_0=t172;
var t177:u32=t173;
var t178:u32=t175;
var t179:u32=(t178 + 10u);
var t180:u32=t177;
var t181:R___ink_differential_0;
if ((t180 == t179)) {
t181=t176;
} else {
var t182:u32=t179;
var t183:R___ink_differential_3;if(t182<a3[0u]){
t183=R___ink_differential_3(R___ink_differential_0(a3[1u+(t182)*11u+0u],a3[1u+(t182)*11u+1u]),R___ink_differential_0(a3[1u+(t182)*11u+2u],a3[1u+(t182)*11u+3u]),R___ink_differential_0(a3[1u+(t182)*11u+4u],a3[1u+(t182)*11u+5u]),R___ink_differential_0(a3[1u+(t182)*11u+6u],a3[1u+(t182)*11u+7u]),R___ink_differential_0(a3[1u+(t182)*11u+8u],a3[1u+(t182)*11u+9u]),a3[1u+(t182)*11u+10u]);}else{
var t184:u32=0u;
var t185:u32=0u;
var t186:R___ink_differential_0=R___ink_differential_0(t184,t185);
var t187:u32=0u;
var t188:u32=0u;
var t189:R___ink_differential_0=R___ink_differential_0(t187,t188);
var t190:u32=0u;
var t191:u32=0u;
var t192:R___ink_differential_0=R___ink_differential_0(t190,t191);
var t193:u32=1065353216u;
var t194:u32=0u;
var t195:R___ink_differential_0=R___ink_differential_0(t193,t194);
var t196:u32=1065353216u;
var t197:u32=0u;
var t198:R___ink_differential_0=R___ink_differential_0(t196,t197);
var t199:u32=0u;
t183=R___ink_differential_3(t186,t189,t192,t195,t198,t199);}
t181=(t183).ink_f_value;
}
var t200:R___ink_differential_0=t181;
var t201:R___ink_differential_0=t200;
for(var t202=0u;t202<10u;t202++){
var t203:R___ink_differential_0=t201;
var t204:R___ink_differential_0=t172;
var t205:u32=t173;
var t206:u32=t175;
var t207:u32=(t206 + t202);
var t208:u32=t205;
var t209:R___ink_differential_0;
if ((t208 == t207)) {
t209=t204;
} else {
var t210:u32=t207;
var t211:R___ink_differential_3;if(t210<a3[0u]){
t211=R___ink_differential_3(R___ink_differential_0(a3[1u+(t210)*11u+0u],a3[1u+(t210)*11u+1u]),R___ink_differential_0(a3[1u+(t210)*11u+2u],a3[1u+(t210)*11u+3u]),R___ink_differential_0(a3[1u+(t210)*11u+4u],a3[1u+(t210)*11u+5u]),R___ink_differential_0(a3[1u+(t210)*11u+6u],a3[1u+(t210)*11u+7u]),R___ink_differential_0(a3[1u+(t210)*11u+8u],a3[1u+(t210)*11u+9u]),a3[1u+(t210)*11u+10u]);}else{
var t212:u32=0u;
var t213:u32=0u;
var t214:R___ink_differential_0=R___ink_differential_0(t212,t213);
var t215:u32=0u;
var t216:u32=0u;
var t217:R___ink_differential_0=R___ink_differential_0(t215,t216);
var t218:u32=0u;
var t219:u32=0u;
var t220:R___ink_differential_0=R___ink_differential_0(t218,t219);
var t221:u32=1065353216u;
var t222:u32=0u;
var t223:R___ink_differential_0=R___ink_differential_0(t221,t222);
var t224:u32=1065353216u;
var t225:u32=0u;
var t226:R___ink_differential_0=R___ink_differential_0(t224,t225);
var t227:u32=0u;
t211=R___ink_differential_3(t214,t217,t220,t223,t226,t227);}
t209=(t211).ink_f_value;
}
var t228:R___ink_differential_0=t209;
var t229:u32=t174;
var t230:u32=(t229 * 10u);
var t231:u32=(t230 + t202);
var t232:R___ink_differential_0;if(t231<a2[0u]){
t232=R___ink_differential_0(a2[1u+(t231)*2u+0u],a2[1u+(t231)*2u+1u]);}else{
var t233:u32=0u;
var t234:u32=0u;
t232=R___ink_differential_0(t233,t234);}
var t235:R___ink_differential_0=t232;
var t236:u32=(t228).ink_f_value;
var t237:u32=ink_f32_mul(t236,(t235).ink_f_value);
var t238:u32=t237;
var t239:u32=(t228).ink_f_tangent;
var t240:u32=ink_f32_mul(t239,(t235).ink_f_value);
var t241:u32=(t228).ink_f_value;
var t242:u32=ink_f32_add(t240,ink_f32_mul(t241,(t235).ink_f_tangent));
var t243:R___ink_differential_0=R___ink_differential_0(t238,t242);
var t244:u32=(t203).ink_f_value;
var t245:u32=ink_f32_add(t244,(t243).ink_f_value);
var t246:u32=t245;
var t247:u32=(t203).ink_f_tangent;
var t248:u32=ink_f32_add(t247,(t243).ink_f_tangent);
t201=R___ink_differential_0(t246,t248);
}
var t249:R___ink_differential_0=t201;
var t250:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t251:u32=a1[0u+(0u)*1u+0u];
var t252:u32=a4[0u+(0u)*1u+0u];
var t253:u32=33u;
var t254:R___ink_differential_0=t250;
var t255:u32=t251;
var t256:u32=t253;
var t257:u32=(t256 + 10u);
var t258:u32=t255;
var t259:R___ink_differential_0;
if ((t258 == t257)) {
t259=t254;
} else {
var t260:u32=t257;
var t261:R___ink_differential_3;if(t260<a3[0u]){
t261=R___ink_differential_3(R___ink_differential_0(a3[1u+(t260)*11u+0u],a3[1u+(t260)*11u+1u]),R___ink_differential_0(a3[1u+(t260)*11u+2u],a3[1u+(t260)*11u+3u]),R___ink_differential_0(a3[1u+(t260)*11u+4u],a3[1u+(t260)*11u+5u]),R___ink_differential_0(a3[1u+(t260)*11u+6u],a3[1u+(t260)*11u+7u]),R___ink_differential_0(a3[1u+(t260)*11u+8u],a3[1u+(t260)*11u+9u]),a3[1u+(t260)*11u+10u]);}else{
var t262:u32=0u;
var t263:u32=0u;
var t264:R___ink_differential_0=R___ink_differential_0(t262,t263);
var t265:u32=0u;
var t266:u32=0u;
var t267:R___ink_differential_0=R___ink_differential_0(t265,t266);
var t268:u32=0u;
var t269:u32=0u;
var t270:R___ink_differential_0=R___ink_differential_0(t268,t269);
var t271:u32=1065353216u;
var t272:u32=0u;
var t273:R___ink_differential_0=R___ink_differential_0(t271,t272);
var t274:u32=1065353216u;
var t275:u32=0u;
var t276:R___ink_differential_0=R___ink_differential_0(t274,t275);
var t277:u32=0u;
t261=R___ink_differential_3(t264,t267,t270,t273,t276,t277);}
t259=(t261).ink_f_value;
}
var t278:R___ink_differential_0=t259;
var t279:R___ink_differential_0=t278;
for(var t280=0u;t280<10u;t280++){
var t281:R___ink_differential_0=t279;
var t282:R___ink_differential_0=t250;
var t283:u32=t251;
var t284:u32=t253;
var t285:u32=(t284 + t280);
var t286:u32=t283;
var t287:R___ink_differential_0;
if ((t286 == t285)) {
t287=t282;
} else {
var t288:u32=t285;
var t289:R___ink_differential_3;if(t288<a3[0u]){
t289=R___ink_differential_3(R___ink_differential_0(a3[1u+(t288)*11u+0u],a3[1u+(t288)*11u+1u]),R___ink_differential_0(a3[1u+(t288)*11u+2u],a3[1u+(t288)*11u+3u]),R___ink_differential_0(a3[1u+(t288)*11u+4u],a3[1u+(t288)*11u+5u]),R___ink_differential_0(a3[1u+(t288)*11u+6u],a3[1u+(t288)*11u+7u]),R___ink_differential_0(a3[1u+(t288)*11u+8u],a3[1u+(t288)*11u+9u]),a3[1u+(t288)*11u+10u]);}else{
var t290:u32=0u;
var t291:u32=0u;
var t292:R___ink_differential_0=R___ink_differential_0(t290,t291);
var t293:u32=0u;
var t294:u32=0u;
var t295:R___ink_differential_0=R___ink_differential_0(t293,t294);
var t296:u32=0u;
var t297:u32=0u;
var t298:R___ink_differential_0=R___ink_differential_0(t296,t297);
var t299:u32=1065353216u;
var t300:u32=0u;
var t301:R___ink_differential_0=R___ink_differential_0(t299,t300);
var t302:u32=1065353216u;
var t303:u32=0u;
var t304:R___ink_differential_0=R___ink_differential_0(t302,t303);
var t305:u32=0u;
t289=R___ink_differential_3(t292,t295,t298,t301,t304,t305);}
t287=(t289).ink_f_value;
}
var t306:R___ink_differential_0=t287;
var t307:u32=t252;
var t308:u32=(t307 * 10u);
var t309:u32=(t308 + t280);
var t310:R___ink_differential_0;if(t309<a2[0u]){
t310=R___ink_differential_0(a2[1u+(t309)*2u+0u],a2[1u+(t309)*2u+1u]);}else{
var t311:u32=0u;
var t312:u32=0u;
t310=R___ink_differential_0(t311,t312);}
var t313:R___ink_differential_0=t310;
var t314:u32=(t306).ink_f_value;
var t315:u32=ink_f32_mul(t314,(t313).ink_f_value);
var t316:u32=t315;
var t317:u32=(t306).ink_f_tangent;
var t318:u32=ink_f32_mul(t317,(t313).ink_f_value);
var t319:u32=(t306).ink_f_value;
var t320:u32=ink_f32_add(t318,ink_f32_mul(t319,(t313).ink_f_tangent));
var t321:R___ink_differential_0=R___ink_differential_0(t316,t320);
var t322:u32=(t281).ink_f_value;
var t323:u32=ink_f32_add(t322,(t321).ink_f_value);
var t324:u32=t323;
var t325:u32=(t281).ink_f_tangent;
var t326:u32=ink_f32_add(t325,(t321).ink_f_tangent);
t279=R___ink_differential_0(t324,t326);
}
var t327:R___ink_differential_0=t279;
var t328:u32=(t327).ink_f_value;
var t329:u32=0u;
var t330:u32=0u;
var t331:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t329,t330)).ink_f_value,t328)) {
var t332:R___ink_differential_0=t249;
var t333:R___ink_differential_0=t327;
var t334:u32=(t332).ink_f_value;
var t335:u32=ink_f32_mul(t334,(t333).ink_f_value);
var t336:u32=t335;
var t337:u32=(t332).ink_f_tangent;
var t338:u32=ink_f32_mul(t337,(t333).ink_f_value);
var t339:u32=(t332).ink_f_value;
var t340:u32=ink_f32_add(t338,ink_f32_mul(t339,(t333).ink_f_tangent));
t331=R___ink_differential_0(t336,t340);
} else {
var t341:u32=0u;
var t342:u32=0u;
t331=R___ink_differential_0(t341,t342);
}
var t343:R___ink_differential_0=t331;
output[1u+i*2u+0u]=bitcast<u32>((t343).ink_f_value);
output[1u+i*2u+1u]=bitcast<u32>((t343).ink_f_tangent);

}
case 2u:{
var t344:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t345:u32=a1[0u+(0u)*1u+0u];
var t346:u32=a4[0u+(0u)*1u+0u];
var t347:u32=44u;
var t348:R___ink_differential_0=t344;
var t349:u32=t345;
var t350:u32=t347;
var t351:u32=(t350 + 10u);
var t352:u32=t349;
var t353:R___ink_differential_0;
if ((t352 == t351)) {
t353=t348;
} else {
var t354:u32=t351;
var t355:R___ink_differential_3;if(t354<a3[0u]){
t355=R___ink_differential_3(R___ink_differential_0(a3[1u+(t354)*11u+0u],a3[1u+(t354)*11u+1u]),R___ink_differential_0(a3[1u+(t354)*11u+2u],a3[1u+(t354)*11u+3u]),R___ink_differential_0(a3[1u+(t354)*11u+4u],a3[1u+(t354)*11u+5u]),R___ink_differential_0(a3[1u+(t354)*11u+6u],a3[1u+(t354)*11u+7u]),R___ink_differential_0(a3[1u+(t354)*11u+8u],a3[1u+(t354)*11u+9u]),a3[1u+(t354)*11u+10u]);}else{
var t356:u32=0u;
var t357:u32=0u;
var t358:R___ink_differential_0=R___ink_differential_0(t356,t357);
var t359:u32=0u;
var t360:u32=0u;
var t361:R___ink_differential_0=R___ink_differential_0(t359,t360);
var t362:u32=0u;
var t363:u32=0u;
var t364:R___ink_differential_0=R___ink_differential_0(t362,t363);
var t365:u32=1065353216u;
var t366:u32=0u;
var t367:R___ink_differential_0=R___ink_differential_0(t365,t366);
var t368:u32=1065353216u;
var t369:u32=0u;
var t370:R___ink_differential_0=R___ink_differential_0(t368,t369);
var t371:u32=0u;
t355=R___ink_differential_3(t358,t361,t364,t367,t370,t371);}
t353=(t355).ink_f_value;
}
var t372:R___ink_differential_0=t353;
var t373:R___ink_differential_0=t372;
for(var t374=0u;t374<10u;t374++){
var t375:R___ink_differential_0=t373;
var t376:R___ink_differential_0=t344;
var t377:u32=t345;
var t378:u32=t347;
var t379:u32=(t378 + t374);
var t380:u32=t377;
var t381:R___ink_differential_0;
if ((t380 == t379)) {
t381=t376;
} else {
var t382:u32=t379;
var t383:R___ink_differential_3;if(t382<a3[0u]){
t383=R___ink_differential_3(R___ink_differential_0(a3[1u+(t382)*11u+0u],a3[1u+(t382)*11u+1u]),R___ink_differential_0(a3[1u+(t382)*11u+2u],a3[1u+(t382)*11u+3u]),R___ink_differential_0(a3[1u+(t382)*11u+4u],a3[1u+(t382)*11u+5u]),R___ink_differential_0(a3[1u+(t382)*11u+6u],a3[1u+(t382)*11u+7u]),R___ink_differential_0(a3[1u+(t382)*11u+8u],a3[1u+(t382)*11u+9u]),a3[1u+(t382)*11u+10u]);}else{
var t384:u32=0u;
var t385:u32=0u;
var t386:R___ink_differential_0=R___ink_differential_0(t384,t385);
var t387:u32=0u;
var t388:u32=0u;
var t389:R___ink_differential_0=R___ink_differential_0(t387,t388);
var t390:u32=0u;
var t391:u32=0u;
var t392:R___ink_differential_0=R___ink_differential_0(t390,t391);
var t393:u32=1065353216u;
var t394:u32=0u;
var t395:R___ink_differential_0=R___ink_differential_0(t393,t394);
var t396:u32=1065353216u;
var t397:u32=0u;
var t398:R___ink_differential_0=R___ink_differential_0(t396,t397);
var t399:u32=0u;
t383=R___ink_differential_3(t386,t389,t392,t395,t398,t399);}
t381=(t383).ink_f_value;
}
var t400:R___ink_differential_0=t381;
var t401:u32=t346;
var t402:u32=(t401 * 10u);
var t403:u32=(t402 + t374);
var t404:R___ink_differential_0;if(t403<a2[0u]){
t404=R___ink_differential_0(a2[1u+(t403)*2u+0u],a2[1u+(t403)*2u+1u]);}else{
var t405:u32=0u;
var t406:u32=0u;
t404=R___ink_differential_0(t405,t406);}
var t407:R___ink_differential_0=t404;
var t408:u32=(t400).ink_f_value;
var t409:u32=ink_f32_mul(t408,(t407).ink_f_value);
var t410:u32=t409;
var t411:u32=(t400).ink_f_tangent;
var t412:u32=ink_f32_mul(t411,(t407).ink_f_value);
var t413:u32=(t400).ink_f_value;
var t414:u32=ink_f32_add(t412,ink_f32_mul(t413,(t407).ink_f_tangent));
var t415:R___ink_differential_0=R___ink_differential_0(t410,t414);
var t416:u32=(t375).ink_f_value;
var t417:u32=ink_f32_add(t416,(t415).ink_f_value);
var t418:u32=t417;
var t419:u32=(t375).ink_f_tangent;
var t420:u32=ink_f32_add(t419,(t415).ink_f_tangent);
t373=R___ink_differential_0(t418,t420);
}
var t421:R___ink_differential_0=t373;
var t422:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t423:u32=a1[0u+(0u)*1u+0u];
var t424:u32=a4[0u+(0u)*1u+0u];
var t425:u32=55u;
var t426:R___ink_differential_0=t422;
var t427:u32=t423;
var t428:u32=t425;
var t429:u32=(t428 + 10u);
var t430:u32=t427;
var t431:R___ink_differential_0;
if ((t430 == t429)) {
t431=t426;
} else {
var t432:u32=t429;
var t433:R___ink_differential_3;if(t432<a3[0u]){
t433=R___ink_differential_3(R___ink_differential_0(a3[1u+(t432)*11u+0u],a3[1u+(t432)*11u+1u]),R___ink_differential_0(a3[1u+(t432)*11u+2u],a3[1u+(t432)*11u+3u]),R___ink_differential_0(a3[1u+(t432)*11u+4u],a3[1u+(t432)*11u+5u]),R___ink_differential_0(a3[1u+(t432)*11u+6u],a3[1u+(t432)*11u+7u]),R___ink_differential_0(a3[1u+(t432)*11u+8u],a3[1u+(t432)*11u+9u]),a3[1u+(t432)*11u+10u]);}else{
var t434:u32=0u;
var t435:u32=0u;
var t436:R___ink_differential_0=R___ink_differential_0(t434,t435);
var t437:u32=0u;
var t438:u32=0u;
var t439:R___ink_differential_0=R___ink_differential_0(t437,t438);
var t440:u32=0u;
var t441:u32=0u;
var t442:R___ink_differential_0=R___ink_differential_0(t440,t441);
var t443:u32=1065353216u;
var t444:u32=0u;
var t445:R___ink_differential_0=R___ink_differential_0(t443,t444);
var t446:u32=1065353216u;
var t447:u32=0u;
var t448:R___ink_differential_0=R___ink_differential_0(t446,t447);
var t449:u32=0u;
t433=R___ink_differential_3(t436,t439,t442,t445,t448,t449);}
t431=(t433).ink_f_value;
}
var t450:R___ink_differential_0=t431;
var t451:R___ink_differential_0=t450;
for(var t452=0u;t452<10u;t452++){
var t453:R___ink_differential_0=t451;
var t454:R___ink_differential_0=t422;
var t455:u32=t423;
var t456:u32=t425;
var t457:u32=(t456 + t452);
var t458:u32=t455;
var t459:R___ink_differential_0;
if ((t458 == t457)) {
t459=t454;
} else {
var t460:u32=t457;
var t461:R___ink_differential_3;if(t460<a3[0u]){
t461=R___ink_differential_3(R___ink_differential_0(a3[1u+(t460)*11u+0u],a3[1u+(t460)*11u+1u]),R___ink_differential_0(a3[1u+(t460)*11u+2u],a3[1u+(t460)*11u+3u]),R___ink_differential_0(a3[1u+(t460)*11u+4u],a3[1u+(t460)*11u+5u]),R___ink_differential_0(a3[1u+(t460)*11u+6u],a3[1u+(t460)*11u+7u]),R___ink_differential_0(a3[1u+(t460)*11u+8u],a3[1u+(t460)*11u+9u]),a3[1u+(t460)*11u+10u]);}else{
var t462:u32=0u;
var t463:u32=0u;
var t464:R___ink_differential_0=R___ink_differential_0(t462,t463);
var t465:u32=0u;
var t466:u32=0u;
var t467:R___ink_differential_0=R___ink_differential_0(t465,t466);
var t468:u32=0u;
var t469:u32=0u;
var t470:R___ink_differential_0=R___ink_differential_0(t468,t469);
var t471:u32=1065353216u;
var t472:u32=0u;
var t473:R___ink_differential_0=R___ink_differential_0(t471,t472);
var t474:u32=1065353216u;
var t475:u32=0u;
var t476:R___ink_differential_0=R___ink_differential_0(t474,t475);
var t477:u32=0u;
t461=R___ink_differential_3(t464,t467,t470,t473,t476,t477);}
t459=(t461).ink_f_value;
}
var t478:R___ink_differential_0=t459;
var t479:u32=t424;
var t480:u32=(t479 * 10u);
var t481:u32=(t480 + t452);
var t482:R___ink_differential_0;if(t481<a2[0u]){
t482=R___ink_differential_0(a2[1u+(t481)*2u+0u],a2[1u+(t481)*2u+1u]);}else{
var t483:u32=0u;
var t484:u32=0u;
t482=R___ink_differential_0(t483,t484);}
var t485:R___ink_differential_0=t482;
var t486:u32=(t478).ink_f_value;
var t487:u32=ink_f32_mul(t486,(t485).ink_f_value);
var t488:u32=t487;
var t489:u32=(t478).ink_f_tangent;
var t490:u32=ink_f32_mul(t489,(t485).ink_f_value);
var t491:u32=(t478).ink_f_value;
var t492:u32=ink_f32_add(t490,ink_f32_mul(t491,(t485).ink_f_tangent));
var t493:R___ink_differential_0=R___ink_differential_0(t488,t492);
var t494:u32=(t453).ink_f_value;
var t495:u32=ink_f32_add(t494,(t493).ink_f_value);
var t496:u32=t495;
var t497:u32=(t453).ink_f_tangent;
var t498:u32=ink_f32_add(t497,(t493).ink_f_tangent);
t451=R___ink_differential_0(t496,t498);
}
var t499:R___ink_differential_0=t451;
var t500:u32=(t499).ink_f_value;
var t501:u32=0u;
var t502:u32=0u;
var t503:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t501,t502)).ink_f_value,t500)) {
var t504:R___ink_differential_0=t421;
var t505:R___ink_differential_0=t499;
var t506:u32=(t504).ink_f_value;
var t507:u32=ink_f32_mul(t506,(t505).ink_f_value);
var t508:u32=t507;
var t509:u32=(t504).ink_f_tangent;
var t510:u32=ink_f32_mul(t509,(t505).ink_f_value);
var t511:u32=(t504).ink_f_value;
var t512:u32=ink_f32_add(t510,ink_f32_mul(t511,(t505).ink_f_tangent));
t503=R___ink_differential_0(t508,t512);
} else {
var t513:u32=0u;
var t514:u32=0u;
t503=R___ink_differential_0(t513,t514);
}
var t515:R___ink_differential_0=t503;
output[1u+i*2u+0u]=bitcast<u32>((t515).ink_f_value);
output[1u+i*2u+1u]=bitcast<u32>((t515).ink_f_tangent);

}
case 3u:{
var t516:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t517:u32=a1[0u+(0u)*1u+0u];
var t518:u32=a4[0u+(0u)*1u+0u];
var t519:u32=66u;
var t520:R___ink_differential_0=t516;
var t521:u32=t517;
var t522:u32=t519;
var t523:u32=(t522 + 10u);
var t524:u32=t521;
var t525:R___ink_differential_0;
if ((t524 == t523)) {
t525=t520;
} else {
var t526:u32=t523;
var t527:R___ink_differential_3;if(t526<a3[0u]){
t527=R___ink_differential_3(R___ink_differential_0(a3[1u+(t526)*11u+0u],a3[1u+(t526)*11u+1u]),R___ink_differential_0(a3[1u+(t526)*11u+2u],a3[1u+(t526)*11u+3u]),R___ink_differential_0(a3[1u+(t526)*11u+4u],a3[1u+(t526)*11u+5u]),R___ink_differential_0(a3[1u+(t526)*11u+6u],a3[1u+(t526)*11u+7u]),R___ink_differential_0(a3[1u+(t526)*11u+8u],a3[1u+(t526)*11u+9u]),a3[1u+(t526)*11u+10u]);}else{
var t528:u32=0u;
var t529:u32=0u;
var t530:R___ink_differential_0=R___ink_differential_0(t528,t529);
var t531:u32=0u;
var t532:u32=0u;
var t533:R___ink_differential_0=R___ink_differential_0(t531,t532);
var t534:u32=0u;
var t535:u32=0u;
var t536:R___ink_differential_0=R___ink_differential_0(t534,t535);
var t537:u32=1065353216u;
var t538:u32=0u;
var t539:R___ink_differential_0=R___ink_differential_0(t537,t538);
var t540:u32=1065353216u;
var t541:u32=0u;
var t542:R___ink_differential_0=R___ink_differential_0(t540,t541);
var t543:u32=0u;
t527=R___ink_differential_3(t530,t533,t536,t539,t542,t543);}
t525=(t527).ink_f_value;
}
var t544:R___ink_differential_0=t525;
var t545:R___ink_differential_0=t544;
for(var t546=0u;t546<10u;t546++){
var t547:R___ink_differential_0=t545;
var t548:R___ink_differential_0=t516;
var t549:u32=t517;
var t550:u32=t519;
var t551:u32=(t550 + t546);
var t552:u32=t549;
var t553:R___ink_differential_0;
if ((t552 == t551)) {
t553=t548;
} else {
var t554:u32=t551;
var t555:R___ink_differential_3;if(t554<a3[0u]){
t555=R___ink_differential_3(R___ink_differential_0(a3[1u+(t554)*11u+0u],a3[1u+(t554)*11u+1u]),R___ink_differential_0(a3[1u+(t554)*11u+2u],a3[1u+(t554)*11u+3u]),R___ink_differential_0(a3[1u+(t554)*11u+4u],a3[1u+(t554)*11u+5u]),R___ink_differential_0(a3[1u+(t554)*11u+6u],a3[1u+(t554)*11u+7u]),R___ink_differential_0(a3[1u+(t554)*11u+8u],a3[1u+(t554)*11u+9u]),a3[1u+(t554)*11u+10u]);}else{
var t556:u32=0u;
var t557:u32=0u;
var t558:R___ink_differential_0=R___ink_differential_0(t556,t557);
var t559:u32=0u;
var t560:u32=0u;
var t561:R___ink_differential_0=R___ink_differential_0(t559,t560);
var t562:u32=0u;
var t563:u32=0u;
var t564:R___ink_differential_0=R___ink_differential_0(t562,t563);
var t565:u32=1065353216u;
var t566:u32=0u;
var t567:R___ink_differential_0=R___ink_differential_0(t565,t566);
var t568:u32=1065353216u;
var t569:u32=0u;
var t570:R___ink_differential_0=R___ink_differential_0(t568,t569);
var t571:u32=0u;
t555=R___ink_differential_3(t558,t561,t564,t567,t570,t571);}
t553=(t555).ink_f_value;
}
var t572:R___ink_differential_0=t553;
var t573:u32=t518;
var t574:u32=(t573 * 10u);
var t575:u32=(t574 + t546);
var t576:R___ink_differential_0;if(t575<a2[0u]){
t576=R___ink_differential_0(a2[1u+(t575)*2u+0u],a2[1u+(t575)*2u+1u]);}else{
var t577:u32=0u;
var t578:u32=0u;
t576=R___ink_differential_0(t577,t578);}
var t579:R___ink_differential_0=t576;
var t580:u32=(t572).ink_f_value;
var t581:u32=ink_f32_mul(t580,(t579).ink_f_value);
var t582:u32=t581;
var t583:u32=(t572).ink_f_tangent;
var t584:u32=ink_f32_mul(t583,(t579).ink_f_value);
var t585:u32=(t572).ink_f_value;
var t586:u32=ink_f32_add(t584,ink_f32_mul(t585,(t579).ink_f_tangent));
var t587:R___ink_differential_0=R___ink_differential_0(t582,t586);
var t588:u32=(t547).ink_f_value;
var t589:u32=ink_f32_add(t588,(t587).ink_f_value);
var t590:u32=t589;
var t591:u32=(t547).ink_f_tangent;
var t592:u32=ink_f32_add(t591,(t587).ink_f_tangent);
t545=R___ink_differential_0(t590,t592);
}
var t593:R___ink_differential_0=t545;
var t594:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t595:u32=a1[0u+(0u)*1u+0u];
var t596:u32=a4[0u+(0u)*1u+0u];
var t597:u32=77u;
var t598:R___ink_differential_0=t594;
var t599:u32=t595;
var t600:u32=t597;
var t601:u32=(t600 + 10u);
var t602:u32=t599;
var t603:R___ink_differential_0;
if ((t602 == t601)) {
t603=t598;
} else {
var t604:u32=t601;
var t605:R___ink_differential_3;if(t604<a3[0u]){
t605=R___ink_differential_3(R___ink_differential_0(a3[1u+(t604)*11u+0u],a3[1u+(t604)*11u+1u]),R___ink_differential_0(a3[1u+(t604)*11u+2u],a3[1u+(t604)*11u+3u]),R___ink_differential_0(a3[1u+(t604)*11u+4u],a3[1u+(t604)*11u+5u]),R___ink_differential_0(a3[1u+(t604)*11u+6u],a3[1u+(t604)*11u+7u]),R___ink_differential_0(a3[1u+(t604)*11u+8u],a3[1u+(t604)*11u+9u]),a3[1u+(t604)*11u+10u]);}else{
var t606:u32=0u;
var t607:u32=0u;
var t608:R___ink_differential_0=R___ink_differential_0(t606,t607);
var t609:u32=0u;
var t610:u32=0u;
var t611:R___ink_differential_0=R___ink_differential_0(t609,t610);
var t612:u32=0u;
var t613:u32=0u;
var t614:R___ink_differential_0=R___ink_differential_0(t612,t613);
var t615:u32=1065353216u;
var t616:u32=0u;
var t617:R___ink_differential_0=R___ink_differential_0(t615,t616);
var t618:u32=1065353216u;
var t619:u32=0u;
var t620:R___ink_differential_0=R___ink_differential_0(t618,t619);
var t621:u32=0u;
t605=R___ink_differential_3(t608,t611,t614,t617,t620,t621);}
t603=(t605).ink_f_value;
}
var t622:R___ink_differential_0=t603;
var t623:R___ink_differential_0=t622;
for(var t624=0u;t624<10u;t624++){
var t625:R___ink_differential_0=t623;
var t626:R___ink_differential_0=t594;
var t627:u32=t595;
var t628:u32=t597;
var t629:u32=(t628 + t624);
var t630:u32=t627;
var t631:R___ink_differential_0;
if ((t630 == t629)) {
t631=t626;
} else {
var t632:u32=t629;
var t633:R___ink_differential_3;if(t632<a3[0u]){
t633=R___ink_differential_3(R___ink_differential_0(a3[1u+(t632)*11u+0u],a3[1u+(t632)*11u+1u]),R___ink_differential_0(a3[1u+(t632)*11u+2u],a3[1u+(t632)*11u+3u]),R___ink_differential_0(a3[1u+(t632)*11u+4u],a3[1u+(t632)*11u+5u]),R___ink_differential_0(a3[1u+(t632)*11u+6u],a3[1u+(t632)*11u+7u]),R___ink_differential_0(a3[1u+(t632)*11u+8u],a3[1u+(t632)*11u+9u]),a3[1u+(t632)*11u+10u]);}else{
var t634:u32=0u;
var t635:u32=0u;
var t636:R___ink_differential_0=R___ink_differential_0(t634,t635);
var t637:u32=0u;
var t638:u32=0u;
var t639:R___ink_differential_0=R___ink_differential_0(t637,t638);
var t640:u32=0u;
var t641:u32=0u;
var t642:R___ink_differential_0=R___ink_differential_0(t640,t641);
var t643:u32=1065353216u;
var t644:u32=0u;
var t645:R___ink_differential_0=R___ink_differential_0(t643,t644);
var t646:u32=1065353216u;
var t647:u32=0u;
var t648:R___ink_differential_0=R___ink_differential_0(t646,t647);
var t649:u32=0u;
t633=R___ink_differential_3(t636,t639,t642,t645,t648,t649);}
t631=(t633).ink_f_value;
}
var t650:R___ink_differential_0=t631;
var t651:u32=t596;
var t652:u32=(t651 * 10u);
var t653:u32=(t652 + t624);
var t654:R___ink_differential_0;if(t653<a2[0u]){
t654=R___ink_differential_0(a2[1u+(t653)*2u+0u],a2[1u+(t653)*2u+1u]);}else{
var t655:u32=0u;
var t656:u32=0u;
t654=R___ink_differential_0(t655,t656);}
var t657:R___ink_differential_0=t654;
var t658:u32=(t650).ink_f_value;
var t659:u32=ink_f32_mul(t658,(t657).ink_f_value);
var t660:u32=t659;
var t661:u32=(t650).ink_f_tangent;
var t662:u32=ink_f32_mul(t661,(t657).ink_f_value);
var t663:u32=(t650).ink_f_value;
var t664:u32=ink_f32_add(t662,ink_f32_mul(t663,(t657).ink_f_tangent));
var t665:R___ink_differential_0=R___ink_differential_0(t660,t664);
var t666:u32=(t625).ink_f_value;
var t667:u32=ink_f32_add(t666,(t665).ink_f_value);
var t668:u32=t667;
var t669:u32=(t625).ink_f_tangent;
var t670:u32=ink_f32_add(t669,(t665).ink_f_tangent);
t623=R___ink_differential_0(t668,t670);
}
var t671:R___ink_differential_0=t623;
var t672:u32=(t671).ink_f_value;
var t673:u32=0u;
var t674:u32=0u;
var t675:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t673,t674)).ink_f_value,t672)) {
var t676:R___ink_differential_0=t593;
var t677:R___ink_differential_0=t671;
var t678:u32=(t676).ink_f_value;
var t679:u32=ink_f32_mul(t678,(t677).ink_f_value);
var t680:u32=t679;
var t681:u32=(t676).ink_f_tangent;
var t682:u32=ink_f32_mul(t681,(t677).ink_f_value);
var t683:u32=(t676).ink_f_value;
var t684:u32=ink_f32_add(t682,ink_f32_mul(t683,(t677).ink_f_tangent));
t675=R___ink_differential_0(t680,t684);
} else {
var t685:u32=0u;
var t686:u32=0u;
t675=R___ink_differential_0(t685,t686);
}
var t687:R___ink_differential_0=t675;
output[1u+i*2u+0u]=bitcast<u32>((t687).ink_f_value);
output[1u+i*2u+1u]=bitcast<u32>((t687).ink_f_tangent);

}
case 4u:{
var t688:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t689:u32=a1[0u+(0u)*1u+0u];
var t690:u32=a4[0u+(0u)*1u+0u];
var t691:u32=88u;
var t692:R___ink_differential_0=t688;
var t693:u32=t689;
var t694:u32=t691;
var t695:u32=(t694 + 10u);
var t696:u32=t693;
var t697:R___ink_differential_0;
if ((t696 == t695)) {
t697=t692;
} else {
var t698:u32=t695;
var t699:R___ink_differential_3;if(t698<a3[0u]){
t699=R___ink_differential_3(R___ink_differential_0(a3[1u+(t698)*11u+0u],a3[1u+(t698)*11u+1u]),R___ink_differential_0(a3[1u+(t698)*11u+2u],a3[1u+(t698)*11u+3u]),R___ink_differential_0(a3[1u+(t698)*11u+4u],a3[1u+(t698)*11u+5u]),R___ink_differential_0(a3[1u+(t698)*11u+6u],a3[1u+(t698)*11u+7u]),R___ink_differential_0(a3[1u+(t698)*11u+8u],a3[1u+(t698)*11u+9u]),a3[1u+(t698)*11u+10u]);}else{
var t700:u32=0u;
var t701:u32=0u;
var t702:R___ink_differential_0=R___ink_differential_0(t700,t701);
var t703:u32=0u;
var t704:u32=0u;
var t705:R___ink_differential_0=R___ink_differential_0(t703,t704);
var t706:u32=0u;
var t707:u32=0u;
var t708:R___ink_differential_0=R___ink_differential_0(t706,t707);
var t709:u32=1065353216u;
var t710:u32=0u;
var t711:R___ink_differential_0=R___ink_differential_0(t709,t710);
var t712:u32=1065353216u;
var t713:u32=0u;
var t714:R___ink_differential_0=R___ink_differential_0(t712,t713);
var t715:u32=0u;
t699=R___ink_differential_3(t702,t705,t708,t711,t714,t715);}
t697=(t699).ink_f_value;
}
var t716:R___ink_differential_0=t697;
var t717:R___ink_differential_0=t716;
for(var t718=0u;t718<10u;t718++){
var t719:R___ink_differential_0=t717;
var t720:R___ink_differential_0=t688;
var t721:u32=t689;
var t722:u32=t691;
var t723:u32=(t722 + t718);
var t724:u32=t721;
var t725:R___ink_differential_0;
if ((t724 == t723)) {
t725=t720;
} else {
var t726:u32=t723;
var t727:R___ink_differential_3;if(t726<a3[0u]){
t727=R___ink_differential_3(R___ink_differential_0(a3[1u+(t726)*11u+0u],a3[1u+(t726)*11u+1u]),R___ink_differential_0(a3[1u+(t726)*11u+2u],a3[1u+(t726)*11u+3u]),R___ink_differential_0(a3[1u+(t726)*11u+4u],a3[1u+(t726)*11u+5u]),R___ink_differential_0(a3[1u+(t726)*11u+6u],a3[1u+(t726)*11u+7u]),R___ink_differential_0(a3[1u+(t726)*11u+8u],a3[1u+(t726)*11u+9u]),a3[1u+(t726)*11u+10u]);}else{
var t728:u32=0u;
var t729:u32=0u;
var t730:R___ink_differential_0=R___ink_differential_0(t728,t729);
var t731:u32=0u;
var t732:u32=0u;
var t733:R___ink_differential_0=R___ink_differential_0(t731,t732);
var t734:u32=0u;
var t735:u32=0u;
var t736:R___ink_differential_0=R___ink_differential_0(t734,t735);
var t737:u32=1065353216u;
var t738:u32=0u;
var t739:R___ink_differential_0=R___ink_differential_0(t737,t738);
var t740:u32=1065353216u;
var t741:u32=0u;
var t742:R___ink_differential_0=R___ink_differential_0(t740,t741);
var t743:u32=0u;
t727=R___ink_differential_3(t730,t733,t736,t739,t742,t743);}
t725=(t727).ink_f_value;
}
var t744:R___ink_differential_0=t725;
var t745:u32=t690;
var t746:u32=(t745 * 10u);
var t747:u32=(t746 + t718);
var t748:R___ink_differential_0;if(t747<a2[0u]){
t748=R___ink_differential_0(a2[1u+(t747)*2u+0u],a2[1u+(t747)*2u+1u]);}else{
var t749:u32=0u;
var t750:u32=0u;
t748=R___ink_differential_0(t749,t750);}
var t751:R___ink_differential_0=t748;
var t752:u32=(t744).ink_f_value;
var t753:u32=ink_f32_mul(t752,(t751).ink_f_value);
var t754:u32=t753;
var t755:u32=(t744).ink_f_tangent;
var t756:u32=ink_f32_mul(t755,(t751).ink_f_value);
var t757:u32=(t744).ink_f_value;
var t758:u32=ink_f32_add(t756,ink_f32_mul(t757,(t751).ink_f_tangent));
var t759:R___ink_differential_0=R___ink_differential_0(t754,t758);
var t760:u32=(t719).ink_f_value;
var t761:u32=ink_f32_add(t760,(t759).ink_f_value);
var t762:u32=t761;
var t763:u32=(t719).ink_f_tangent;
var t764:u32=ink_f32_add(t763,(t759).ink_f_tangent);
t717=R___ink_differential_0(t762,t764);
}
var t765:R___ink_differential_0=t717;
var t766:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t767:u32=a1[0u+(0u)*1u+0u];
var t768:u32=a4[0u+(0u)*1u+0u];
var t769:u32=99u;
var t770:R___ink_differential_0=t766;
var t771:u32=t767;
var t772:u32=t769;
var t773:u32=(t772 + 10u);
var t774:u32=t771;
var t775:R___ink_differential_0;
if ((t774 == t773)) {
t775=t770;
} else {
var t776:u32=t773;
var t777:R___ink_differential_3;if(t776<a3[0u]){
t777=R___ink_differential_3(R___ink_differential_0(a3[1u+(t776)*11u+0u],a3[1u+(t776)*11u+1u]),R___ink_differential_0(a3[1u+(t776)*11u+2u],a3[1u+(t776)*11u+3u]),R___ink_differential_0(a3[1u+(t776)*11u+4u],a3[1u+(t776)*11u+5u]),R___ink_differential_0(a3[1u+(t776)*11u+6u],a3[1u+(t776)*11u+7u]),R___ink_differential_0(a3[1u+(t776)*11u+8u],a3[1u+(t776)*11u+9u]),a3[1u+(t776)*11u+10u]);}else{
var t778:u32=0u;
var t779:u32=0u;
var t780:R___ink_differential_0=R___ink_differential_0(t778,t779);
var t781:u32=0u;
var t782:u32=0u;
var t783:R___ink_differential_0=R___ink_differential_0(t781,t782);
var t784:u32=0u;
var t785:u32=0u;
var t786:R___ink_differential_0=R___ink_differential_0(t784,t785);
var t787:u32=1065353216u;
var t788:u32=0u;
var t789:R___ink_differential_0=R___ink_differential_0(t787,t788);
var t790:u32=1065353216u;
var t791:u32=0u;
var t792:R___ink_differential_0=R___ink_differential_0(t790,t791);
var t793:u32=0u;
t777=R___ink_differential_3(t780,t783,t786,t789,t792,t793);}
t775=(t777).ink_f_value;
}
var t794:R___ink_differential_0=t775;
var t795:R___ink_differential_0=t794;
for(var t796=0u;t796<10u;t796++){
var t797:R___ink_differential_0=t795;
var t798:R___ink_differential_0=t766;
var t799:u32=t767;
var t800:u32=t769;
var t801:u32=(t800 + t796);
var t802:u32=t799;
var t803:R___ink_differential_0;
if ((t802 == t801)) {
t803=t798;
} else {
var t804:u32=t801;
var t805:R___ink_differential_3;if(t804<a3[0u]){
t805=R___ink_differential_3(R___ink_differential_0(a3[1u+(t804)*11u+0u],a3[1u+(t804)*11u+1u]),R___ink_differential_0(a3[1u+(t804)*11u+2u],a3[1u+(t804)*11u+3u]),R___ink_differential_0(a3[1u+(t804)*11u+4u],a3[1u+(t804)*11u+5u]),R___ink_differential_0(a3[1u+(t804)*11u+6u],a3[1u+(t804)*11u+7u]),R___ink_differential_0(a3[1u+(t804)*11u+8u],a3[1u+(t804)*11u+9u]),a3[1u+(t804)*11u+10u]);}else{
var t806:u32=0u;
var t807:u32=0u;
var t808:R___ink_differential_0=R___ink_differential_0(t806,t807);
var t809:u32=0u;
var t810:u32=0u;
var t811:R___ink_differential_0=R___ink_differential_0(t809,t810);
var t812:u32=0u;
var t813:u32=0u;
var t814:R___ink_differential_0=R___ink_differential_0(t812,t813);
var t815:u32=1065353216u;
var t816:u32=0u;
var t817:R___ink_differential_0=R___ink_differential_0(t815,t816);
var t818:u32=1065353216u;
var t819:u32=0u;
var t820:R___ink_differential_0=R___ink_differential_0(t818,t819);
var t821:u32=0u;
t805=R___ink_differential_3(t808,t811,t814,t817,t820,t821);}
t803=(t805).ink_f_value;
}
var t822:R___ink_differential_0=t803;
var t823:u32=t768;
var t824:u32=(t823 * 10u);
var t825:u32=(t824 + t796);
var t826:R___ink_differential_0;if(t825<a2[0u]){
t826=R___ink_differential_0(a2[1u+(t825)*2u+0u],a2[1u+(t825)*2u+1u]);}else{
var t827:u32=0u;
var t828:u32=0u;
t826=R___ink_differential_0(t827,t828);}
var t829:R___ink_differential_0=t826;
var t830:u32=(t822).ink_f_value;
var t831:u32=ink_f32_mul(t830,(t829).ink_f_value);
var t832:u32=t831;
var t833:u32=(t822).ink_f_tangent;
var t834:u32=ink_f32_mul(t833,(t829).ink_f_value);
var t835:u32=(t822).ink_f_value;
var t836:u32=ink_f32_add(t834,ink_f32_mul(t835,(t829).ink_f_tangent));
var t837:R___ink_differential_0=R___ink_differential_0(t832,t836);
var t838:u32=(t797).ink_f_value;
var t839:u32=ink_f32_add(t838,(t837).ink_f_value);
var t840:u32=t839;
var t841:u32=(t797).ink_f_tangent;
var t842:u32=ink_f32_add(t841,(t837).ink_f_tangent);
t795=R___ink_differential_0(t840,t842);
}
var t843:R___ink_differential_0=t795;
var t844:u32=(t843).ink_f_value;
var t845:u32=0u;
var t846:u32=0u;
var t847:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t845,t846)).ink_f_value,t844)) {
var t848:R___ink_differential_0=t765;
var t849:R___ink_differential_0=t843;
var t850:u32=(t848).ink_f_value;
var t851:u32=ink_f32_mul(t850,(t849).ink_f_value);
var t852:u32=t851;
var t853:u32=(t848).ink_f_tangent;
var t854:u32=ink_f32_mul(t853,(t849).ink_f_value);
var t855:u32=(t848).ink_f_value;
var t856:u32=ink_f32_add(t854,ink_f32_mul(t855,(t849).ink_f_tangent));
t847=R___ink_differential_0(t852,t856);
} else {
var t857:u32=0u;
var t858:u32=0u;
t847=R___ink_differential_0(t857,t858);
}
var t859:R___ink_differential_0=t847;
output[1u+i*2u+0u]=bitcast<u32>((t859).ink_f_value);
output[1u+i*2u+1u]=bitcast<u32>((t859).ink_f_tangent);

}
case 5u:{
var t860:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t861:u32=a1[0u+(0u)*1u+0u];
var t862:u32=a4[0u+(0u)*1u+0u];
var t863:u32=110u;
var t864:R___ink_differential_0=t860;
var t865:u32=t861;
var t866:u32=t863;
var t867:u32=(t866 + 10u);
var t868:u32=t865;
var t869:R___ink_differential_0;
if ((t868 == t867)) {
t869=t864;
} else {
var t870:u32=t867;
var t871:R___ink_differential_3;if(t870<a3[0u]){
t871=R___ink_differential_3(R___ink_differential_0(a3[1u+(t870)*11u+0u],a3[1u+(t870)*11u+1u]),R___ink_differential_0(a3[1u+(t870)*11u+2u],a3[1u+(t870)*11u+3u]),R___ink_differential_0(a3[1u+(t870)*11u+4u],a3[1u+(t870)*11u+5u]),R___ink_differential_0(a3[1u+(t870)*11u+6u],a3[1u+(t870)*11u+7u]),R___ink_differential_0(a3[1u+(t870)*11u+8u],a3[1u+(t870)*11u+9u]),a3[1u+(t870)*11u+10u]);}else{
var t872:u32=0u;
var t873:u32=0u;
var t874:R___ink_differential_0=R___ink_differential_0(t872,t873);
var t875:u32=0u;
var t876:u32=0u;
var t877:R___ink_differential_0=R___ink_differential_0(t875,t876);
var t878:u32=0u;
var t879:u32=0u;
var t880:R___ink_differential_0=R___ink_differential_0(t878,t879);
var t881:u32=1065353216u;
var t882:u32=0u;
var t883:R___ink_differential_0=R___ink_differential_0(t881,t882);
var t884:u32=1065353216u;
var t885:u32=0u;
var t886:R___ink_differential_0=R___ink_differential_0(t884,t885);
var t887:u32=0u;
t871=R___ink_differential_3(t874,t877,t880,t883,t886,t887);}
t869=(t871).ink_f_value;
}
var t888:R___ink_differential_0=t869;
var t889:R___ink_differential_0=t888;
for(var t890=0u;t890<10u;t890++){
var t891:R___ink_differential_0=t889;
var t892:R___ink_differential_0=t860;
var t893:u32=t861;
var t894:u32=t863;
var t895:u32=(t894 + t890);
var t896:u32=t893;
var t897:R___ink_differential_0;
if ((t896 == t895)) {
t897=t892;
} else {
var t898:u32=t895;
var t899:R___ink_differential_3;if(t898<a3[0u]){
t899=R___ink_differential_3(R___ink_differential_0(a3[1u+(t898)*11u+0u],a3[1u+(t898)*11u+1u]),R___ink_differential_0(a3[1u+(t898)*11u+2u],a3[1u+(t898)*11u+3u]),R___ink_differential_0(a3[1u+(t898)*11u+4u],a3[1u+(t898)*11u+5u]),R___ink_differential_0(a3[1u+(t898)*11u+6u],a3[1u+(t898)*11u+7u]),R___ink_differential_0(a3[1u+(t898)*11u+8u],a3[1u+(t898)*11u+9u]),a3[1u+(t898)*11u+10u]);}else{
var t900:u32=0u;
var t901:u32=0u;
var t902:R___ink_differential_0=R___ink_differential_0(t900,t901);
var t903:u32=0u;
var t904:u32=0u;
var t905:R___ink_differential_0=R___ink_differential_0(t903,t904);
var t906:u32=0u;
var t907:u32=0u;
var t908:R___ink_differential_0=R___ink_differential_0(t906,t907);
var t909:u32=1065353216u;
var t910:u32=0u;
var t911:R___ink_differential_0=R___ink_differential_0(t909,t910);
var t912:u32=1065353216u;
var t913:u32=0u;
var t914:R___ink_differential_0=R___ink_differential_0(t912,t913);
var t915:u32=0u;
t899=R___ink_differential_3(t902,t905,t908,t911,t914,t915);}
t897=(t899).ink_f_value;
}
var t916:R___ink_differential_0=t897;
var t917:u32=t862;
var t918:u32=(t917 * 10u);
var t919:u32=(t918 + t890);
var t920:R___ink_differential_0;if(t919<a2[0u]){
t920=R___ink_differential_0(a2[1u+(t919)*2u+0u],a2[1u+(t919)*2u+1u]);}else{
var t921:u32=0u;
var t922:u32=0u;
t920=R___ink_differential_0(t921,t922);}
var t923:R___ink_differential_0=t920;
var t924:u32=(t916).ink_f_value;
var t925:u32=ink_f32_mul(t924,(t923).ink_f_value);
var t926:u32=t925;
var t927:u32=(t916).ink_f_tangent;
var t928:u32=ink_f32_mul(t927,(t923).ink_f_value);
var t929:u32=(t916).ink_f_value;
var t930:u32=ink_f32_add(t928,ink_f32_mul(t929,(t923).ink_f_tangent));
var t931:R___ink_differential_0=R___ink_differential_0(t926,t930);
var t932:u32=(t891).ink_f_value;
var t933:u32=ink_f32_add(t932,(t931).ink_f_value);
var t934:u32=t933;
var t935:u32=(t891).ink_f_tangent;
var t936:u32=ink_f32_add(t935,(t931).ink_f_tangent);
t889=R___ink_differential_0(t934,t936);
}
var t937:R___ink_differential_0=t889;
var t938:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t939:u32=a1[0u+(0u)*1u+0u];
var t940:u32=a4[0u+(0u)*1u+0u];
var t941:u32=121u;
var t942:R___ink_differential_0=t938;
var t943:u32=t939;
var t944:u32=t941;
var t945:u32=(t944 + 10u);
var t946:u32=t943;
var t947:R___ink_differential_0;
if ((t946 == t945)) {
t947=t942;
} else {
var t948:u32=t945;
var t949:R___ink_differential_3;if(t948<a3[0u]){
t949=R___ink_differential_3(R___ink_differential_0(a3[1u+(t948)*11u+0u],a3[1u+(t948)*11u+1u]),R___ink_differential_0(a3[1u+(t948)*11u+2u],a3[1u+(t948)*11u+3u]),R___ink_differential_0(a3[1u+(t948)*11u+4u],a3[1u+(t948)*11u+5u]),R___ink_differential_0(a3[1u+(t948)*11u+6u],a3[1u+(t948)*11u+7u]),R___ink_differential_0(a3[1u+(t948)*11u+8u],a3[1u+(t948)*11u+9u]),a3[1u+(t948)*11u+10u]);}else{
var t950:u32=0u;
var t951:u32=0u;
var t952:R___ink_differential_0=R___ink_differential_0(t950,t951);
var t953:u32=0u;
var t954:u32=0u;
var t955:R___ink_differential_0=R___ink_differential_0(t953,t954);
var t956:u32=0u;
var t957:u32=0u;
var t958:R___ink_differential_0=R___ink_differential_0(t956,t957);
var t959:u32=1065353216u;
var t960:u32=0u;
var t961:R___ink_differential_0=R___ink_differential_0(t959,t960);
var t962:u32=1065353216u;
var t963:u32=0u;
var t964:R___ink_differential_0=R___ink_differential_0(t962,t963);
var t965:u32=0u;
t949=R___ink_differential_3(t952,t955,t958,t961,t964,t965);}
t947=(t949).ink_f_value;
}
var t966:R___ink_differential_0=t947;
var t967:R___ink_differential_0=t966;
for(var t968=0u;t968<10u;t968++){
var t969:R___ink_differential_0=t967;
var t970:R___ink_differential_0=t938;
var t971:u32=t939;
var t972:u32=t941;
var t973:u32=(t972 + t968);
var t974:u32=t971;
var t975:R___ink_differential_0;
if ((t974 == t973)) {
t975=t970;
} else {
var t976:u32=t973;
var t977:R___ink_differential_3;if(t976<a3[0u]){
t977=R___ink_differential_3(R___ink_differential_0(a3[1u+(t976)*11u+0u],a3[1u+(t976)*11u+1u]),R___ink_differential_0(a3[1u+(t976)*11u+2u],a3[1u+(t976)*11u+3u]),R___ink_differential_0(a3[1u+(t976)*11u+4u],a3[1u+(t976)*11u+5u]),R___ink_differential_0(a3[1u+(t976)*11u+6u],a3[1u+(t976)*11u+7u]),R___ink_differential_0(a3[1u+(t976)*11u+8u],a3[1u+(t976)*11u+9u]),a3[1u+(t976)*11u+10u]);}else{
var t978:u32=0u;
var t979:u32=0u;
var t980:R___ink_differential_0=R___ink_differential_0(t978,t979);
var t981:u32=0u;
var t982:u32=0u;
var t983:R___ink_differential_0=R___ink_differential_0(t981,t982);
var t984:u32=0u;
var t985:u32=0u;
var t986:R___ink_differential_0=R___ink_differential_0(t984,t985);
var t987:u32=1065353216u;
var t988:u32=0u;
var t989:R___ink_differential_0=R___ink_differential_0(t987,t988);
var t990:u32=1065353216u;
var t991:u32=0u;
var t992:R___ink_differential_0=R___ink_differential_0(t990,t991);
var t993:u32=0u;
t977=R___ink_differential_3(t980,t983,t986,t989,t992,t993);}
t975=(t977).ink_f_value;
}
var t994:R___ink_differential_0=t975;
var t995:u32=t940;
var t996:u32=(t995 * 10u);
var t997:u32=(t996 + t968);
var t998:R___ink_differential_0;if(t997<a2[0u]){
t998=R___ink_differential_0(a2[1u+(t997)*2u+0u],a2[1u+(t997)*2u+1u]);}else{
var t999:u32=0u;
var t1000:u32=0u;
t998=R___ink_differential_0(t999,t1000);}
var t1001:R___ink_differential_0=t998;
var t1002:u32=(t994).ink_f_value;
var t1003:u32=ink_f32_mul(t1002,(t1001).ink_f_value);
var t1004:u32=t1003;
var t1005:u32=(t994).ink_f_tangent;
var t1006:u32=ink_f32_mul(t1005,(t1001).ink_f_value);
var t1007:u32=(t994).ink_f_value;
var t1008:u32=ink_f32_add(t1006,ink_f32_mul(t1007,(t1001).ink_f_tangent));
var t1009:R___ink_differential_0=R___ink_differential_0(t1004,t1008);
var t1010:u32=(t969).ink_f_value;
var t1011:u32=ink_f32_add(t1010,(t1009).ink_f_value);
var t1012:u32=t1011;
var t1013:u32=(t969).ink_f_tangent;
var t1014:u32=ink_f32_add(t1013,(t1009).ink_f_tangent);
t967=R___ink_differential_0(t1012,t1014);
}
var t1015:R___ink_differential_0=t967;
var t1016:u32=(t1015).ink_f_value;
var t1017:u32=0u;
var t1018:u32=0u;
var t1019:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t1017,t1018)).ink_f_value,t1016)) {
var t1020:R___ink_differential_0=t937;
var t1021:R___ink_differential_0=t1015;
var t1022:u32=(t1020).ink_f_value;
var t1023:u32=ink_f32_mul(t1022,(t1021).ink_f_value);
var t1024:u32=t1023;
var t1025:u32=(t1020).ink_f_tangent;
var t1026:u32=ink_f32_mul(t1025,(t1021).ink_f_value);
var t1027:u32=(t1020).ink_f_value;
var t1028:u32=ink_f32_add(t1026,ink_f32_mul(t1027,(t1021).ink_f_tangent));
t1019=R___ink_differential_0(t1024,t1028);
} else {
var t1029:u32=0u;
var t1030:u32=0u;
t1019=R___ink_differential_0(t1029,t1030);
}
var t1031:R___ink_differential_0=t1019;
output[1u+i*2u+0u]=bitcast<u32>((t1031).ink_f_value);
output[1u+i*2u+1u]=bitcast<u32>((t1031).ink_f_tangent);

}
default:{} }

}
}