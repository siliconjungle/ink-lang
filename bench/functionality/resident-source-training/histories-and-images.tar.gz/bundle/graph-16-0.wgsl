// Exact wrapping u64 over two storage lanes. No floating point intermediates.
struct InkU64 {lo:u32,hi:u32,}
struct InkDiv64 {quotient:InkU64,remainder:InkU64,}
fn ink_u64_shl(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64(a.lo<<k,(a.hi<<k)|(a.lo>>(32u-k)));}return InkU64(0u,a.lo<<(k-32u));}
fn ink_u64_shr(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64((a.lo>>k)|(a.hi<<(32u-k)),a.hi>>k);}return InkU64(a.hi>>(k-32u),0u);}
fn ink_u64_rol(a:InkU64,count:u32)->InkU64{let k=count&63u;let l=ink_u64_shl(a,k);let r=ink_u64_shr(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_ror(a:InkU64,count:u32)->InkU64{let k=count&63u;let r=ink_u64_shr(a,k);let l=ink_u64_shl(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_eq(a:InkU64,b:InkU64)->bool{return a.lo==b.lo&&a.hi==b.hi;}
fn ink_u64_lt(a:InkU64,b:InkU64)->bool{return a.hi<b.hi||(a.hi==b.hi&&a.lo<b.lo);}
fn ink_u64_add(a:InkU64,b:InkU64)->InkU64{let lo=a.lo+b.lo;return InkU64(lo,a.hi+b.hi+select(0u,1u,lo<a.lo));}
fn ink_u64_sub(a:InkU64,b:InkU64)->InkU64{return InkU64(a.lo-b.lo,a.hi-b.hi-select(0u,1u,a.lo<b.lo));}
fn ink_u64_mul(a:InkU64,b:InkU64)->InkU64{let al=a.lo&65535u;let ah=a.lo>>16u;let bl=b.lo&65535u;let bh=b.lo>>16u;let p=al*bl;let x=ah*bl;let y=al*bh;let mid=(p>>16u)+(x&65535u)+(y&65535u);let high=ah*bh+(x>>16u)+(y>>16u)+(mid>>16u);return InkU64((mid<<16u)|(p&65535u),high+a.lo*b.hi+a.hi*b.lo);}
fn ink_u64_div(a:InkU64,b:InkU64)->InkDiv64{var q=InkU64(0u,0u);var r=InkU64(0u,0u);var cursor=64u;loop{if(cursor==0u){break;}cursor--;var bit=0u;if(cursor>=32u){bit=(a.hi>>(cursor-32u))&1u;}else{bit=(a.lo>>cursor)&1u;}let overflow=r.hi>>31u;r=InkU64((r.lo<<1u)|bit,(r.hi<<1u)|(r.lo>>31u));if(overflow!=0u||!ink_u64_lt(r,b)){r=ink_u64_sub(r,b);if(cursor>=32u){q.hi|=1u<<(cursor-32u);}else{q.lo|=1u<<cursor;}}}return InkDiv64(q,r);}
// Binary32 evaluated with integer lanes: round-to-nearest, ties-to-even,
// gradual underflow, signed zero and canonical arithmetic NaN.
fn ink_f32_nan(x:u32)->bool{return (x&0x7fffffffu)>0x7f800000u;}
fn ink_f32_eq(a:u32,b:u32)->bool{return !ink_f32_nan(a)&&!ink_f32_nan(b)&&(a==b||((a|b)&0x7fffffffu)==0u);}
fn ink_f32_lt(a:u32,b:u32)->bool{
 if(ink_f32_nan(a)||ink_f32_nan(b)||ink_f32_eq(a,b)){return false;}
 if((a^b)&0x80000000u)!=0u{return (a&0x80000000u)!=0u;}
 if((a&0x80000000u)!=0u){return a>b;}return a<b;
}
fn ink_f32_jam(x:u32,n:u32)->u32{if(n==0u){return x;}if(n>=32u){return select(0u,1u,x!=0u);}return (x>>n)|select(0u,1u,(x&((1u<<n)-1u))!=0u);}
fn ink_f32_round(sign:u32,exponent:i32,extended:u32)->u32{
 var e=exponent;var s=extended;
 if(e<1i){s=ink_f32_jam(s,u32(1i-e));e=1i;}
 let tail=s&7u;var sig=s>>3u;
 if(tail>4u||(tail==4u&&(sig&1u)!=0u)){sig++;}
 if(sig>=0x1000000u){sig>>=1u;e++;}
 if(e>=255i){return sign|0x7f800000u;}
 if(sig==0u){return sign;}
 let raw=select(u32(e),0u,e==1i&&sig<0x800000u);
 return sign|(raw<<23u)|(sig&0x7fffffu);
}
fn ink_f32_add(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 var x=a;var y=b;if((x&0x7fffffffu)<(y&0x7fffffffu)){x=b;y=a;}
 let ax=x&0x7fffffffu;let ay=y&0x7fffffffu;let sign=x&0x80000000u;
 if(ax==0x7f800000u){if(ay==ax&&((x^y)&0x80000000u)!=0u){return 0x7fc00000u;}return x;}
 let rx=(x>>23u)&255u;let ry=(y>>23u)&255u;var e=i32(max(rx,1u));
 var sx=((x&0x7fffffu)|select(0u,0x800000u,rx!=0u))<<3u;
 let sy=ink_f32_jam(((y&0x7fffffu)|select(0u,0x800000u,ry!=0u))<<3u,u32(e)-max(ry,1u));
 if(((x^y)&0x80000000u)==0u){sx+=sy;if(sx>=0x8000000u){sx=ink_f32_jam(sx,1u);e++;}}
 else{sx-=sy;if(sx==0u){return 0u;}loop{if(sx>=0x4000000u||e<=1i){break;}sx<<=1u;e--;}}
 return ink_f32_round(sign,e,sx);
}
fn ink_f32_sub(a:u32,b:u32)->u32{return ink_f32_add(a,b^0x80000000u);}
fn ink_f32_mul(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(aa==0x7f800000u||bb==0x7f800000u){if(aa==0u||bb==0u){return 0x7fc00000u;}return sign|0x7f800000u;}
 if(aa==0u||bb==0u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u));var eb=i32(max(rb,1u));
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 let product=ink_u64_mul(InkU64(sa,0u),InkU64(sb,0u));let high=(product.hi&0x8000u)!=0u;
 let shift=select(20u,21u,high);let extended=(product.lo>>shift)|(product.hi<<(32u-shift))|select(0u,1u,(product.lo&((1u<<shift)-1u))!=0u);
 return ink_f32_round(sign,ea+eb-127i+select(0i,1i,high),extended);
}
// Exact sqrt and division use integer significands, independent of WGSL float
// approximation allowances and device flush-to-zero behavior.
fn ink_f32_sqrt(x:u32)->u32{
 let a=x&0x7fffffffu;if(a==0u){return x;}
 if(a>0x7f800000u||(x&0x80000000u)!=0u){return 0x7fc00000u;}
 if(a==0x7f800000u){return x;}
 let raw=(x>>23u)&255u;var m=(x&0x7fffffu)|select(0u,0x800000u,raw!=0u);var e=i32(max(raw,1u))-127i;
 loop{if(m>=0x800000u){break;}m<<=1u;e--;}
 let odd=e&1i;var half=(e-odd)/2i;let shift=23u+u32(odd);
 let n=InkU64(m<<shift,m>>(32u-shift));var lo=0u;var hi=0x1000000u;
 loop{if(lo+1u>=hi){break;}let mid=(lo+hi)>>1u;let sq=ink_u64_mul(InkU64(mid,0u),InkU64(mid,0u));if(!ink_u64_lt(n,sq)){lo=mid;}else{hi=mid;}}
 let sq=ink_u64_mul(InkU64(lo,0u),InkU64(lo,0u));let rem=ink_u64_sub(n,sq);
 if(ink_u64_lt(InkU64(lo,0u),rem)){lo++;}
 if(lo==0x1000000u){lo>>=1u;half++;}
 return (u32(half+127i)<<23u)|(lo&0x7fffffu);
}
fn ink_f32_div(a:u32,b:u32)->u32{
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(ink_f32_nan(a)||ink_f32_nan(b)||(aa==0u&&bb==0u)||(aa==0x7f800000u&&bb==aa)){return 0x7fc00000u;}
 if(aa==0x7f800000u||bb==0u){return sign|0x7f800000u;}
 if(aa==0u||bb==0x7f800000u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u))-127i;var eb=i32(max(rb,1u))-127i;
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 var e=ea-eb;if(sa<sb){sa<<=1u;e--;}
 let division=ink_u64_div(InkU64(sa<<26u,sa>>6u),InkU64(sb,0u));
 let extended=division.quotient.lo|select(0u,1u,!ink_u64_eq(division.remainder,InkU64(0u,0u)));
 return ink_f32_round(sign,e+127i,extended);
}
// mode: 0 trunc, 1 floor, 2 ceil, 3 ties-to-even.
fn ink_f32_integral(x:u32,mode:u32)->u32{
 let a=x&0x7fffffffu;let sign=x&0x80000000u;
 if(a>0x7f800000u){return 0x7fc00000u;}if(a>=0x4b000000u||a==0u){return x;}
 let e=i32((x>>23u)&255u)-127i;
 if(e<0i){var up=false;if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){up=a>0x3f000000u;}return sign|select(0u,0x3f800000u,up);}
 let shift=u32(23i-e);let mask=(1u<<shift)-1u;let fraction=a&mask;var rounded=a&~mask;var up=false;
 if(fraction!=0u){if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){let half=1u<<(shift-1u);up=fraction>half||(fraction==half&&((rounded>>shift)&1u)!=0u);}}
 if(up){rounded+=1u<<shift;}return sign|rounded;
}
fn ink_f32_from_u64(x:InkU64)->u32{
 if(ink_u64_eq(x,InkU64(0u,0u))){return 0u;}
 let leading=select(countLeadingZeros(x.lo)+32u,countLeadingZeros(x.hi),x.hi!=0u);let e=63u-leading;
 if(e<=23u){return ((e+127u)<<23u)|((x.lo<<(23u-e))&0x7fffffu);}
 let shift=e-23u;var sig=0u;var rem=InkU64(0u,0u);var half=InkU64(0u,0u);
 if(shift<32u){sig=(x.lo>>shift)|(x.hi<<(32u-shift));rem=InkU64(x.lo&((1u<<shift)-1u),0u);half=InkU64(1u<<(shift-1u),0u);}
 else if(shift==32u){sig=x.hi;rem=InkU64(x.lo,0u);half=InkU64(0x80000000u,0u);}
 else{sig=x.hi>>(shift-32u);rem=InkU64(x.lo,x.hi&((1u<<(shift-32u))-1u));half=InkU64(0u,1u<<(shift-33u));}
 if(ink_u64_lt(half,rem)||(ink_u64_eq(rem,half)&&(sig&1u)!=0u)){sig++;}
 var exponent=e+127u;if(sig==0x1000000u){sig>>=1u;exponent++;}
 return (exponent<<23u)|(sig&0x7fffffu);
}
fn ink_f32_from_i32(x:i32)->u32{let neg=x<0i;let magnitude=select(u32(x),0u-u32(x),neg);return ink_f32_from_u64(InkU64(magnitude,0u))|select(0u,0x80000000u,neg);}
struct InkBuffer_u32{data:array<u32,64>,length:u32,}
struct InkBuffer_InkU64{data:array<InkU64,64>,length:u32,}
struct InkBuffer_i32{data:array<i32,64>,length:u32,}
struct InkBuffer_bool{data:array<bool,64>,length:u32,}
struct R_Config{ink_f_rate:u32,ink_f_first_decay:u32,ink_f_second_decay:u32,ink_f_epsilon:u32,}
struct R_Parameter{ink_f_value:u32,ink_f_first:u32,ink_f_second:u32,ink_f_first_power:u32,ink_f_second_power:u32,ink_f_steps:u32,}
struct R___ink_differential_0{ink_f_value:u32,ink_f_tangent:u32,}
struct R___ink_differential_3{ink_f_value:R___ink_differential_0,ink_f_first:R___ink_differential_0,ink_f_second:R___ink_differential_0,ink_f_first_power:R___ink_differential_0,ink_f_second_power:R___ink_differential_0,ink_f_steps:u32,}
@group(0) @binding(0) var<storage,read> a0:array<u32>;
@group(0) @binding(1) var<storage,read> a1:array<u32>;
@group(0) @binding(2) var<storage,read> a2:array<u32>;
@group(0) @binding(3) var<storage,read> a3:array<u32>;
@group(0) @binding(4) var<storage,read_write> output:array<u32>;
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) gid:vec3<u32>){
let size=a1[0];let i=gid.x;if(i==0u){output[0]=size;}if(i<size){
var t0:u32=0u;
var t1:u32=4294967295u;
var t2:u32=a1[1u+(i)*1u+0u];
var t3:u32=t0;
var t4:u32=t1;
var t5:u32=t2;
var t6:u32=t3;
var t7:u32=t4;
var t8:u32=t5;
var t9:array<u32,6>;
var t10:u32=t6;
var t11:u32=t7;
var t12:u32=t8;
var t13:u32=0u;
var t14:u32=t10;
var t15:u32=t11;
var t16:u32=t13;
var t17:u32=(t16 + 10u);
var t18:u32=t15;
var t19:u32;
if ((t18 == t17)) {
t19=t14;
} else {
var t20:u32=t17;
var t21:R_Parameter;if(t20<a2[0u]){
t21=R_Parameter(a2[1u+(t20)*6u+0u],a2[1u+(t20)*6u+1u],a2[1u+(t20)*6u+2u],a2[1u+(t20)*6u+3u],a2[1u+(t20)*6u+4u],a2[1u+(t20)*6u+5u]);}else{
var t22:u32=0u;
var t23:u32=0u;
var t24:u32=0u;
var t25:u32=1065353216u;
var t26:u32=1065353216u;
var t27:u32=0u;
t21=R_Parameter(t22,t23,t24,t25,t26,t27);}
t19=(t21).ink_f_value;
}
var t28:u32=t19;
var t29:u32=t28;
for(var t30=0u;t30<10u;t30++){
var t31:u32=t29;
var t32:u32=t10;
var t33:u32=t11;
var t34:u32=t13;
var t35:u32=(t34 + t30);
var t36:u32=t33;
var t37:u32;
if ((t36 == t35)) {
t37=t32;
} else {
var t38:u32=t35;
var t39:R_Parameter;if(t38<a2[0u]){
t39=R_Parameter(a2[1u+(t38)*6u+0u],a2[1u+(t38)*6u+1u],a2[1u+(t38)*6u+2u],a2[1u+(t38)*6u+3u],a2[1u+(t38)*6u+4u],a2[1u+(t38)*6u+5u]);}else{
var t40:u32=0u;
var t41:u32=0u;
var t42:u32=0u;
var t43:u32=1065353216u;
var t44:u32=1065353216u;
var t45:u32=0u;
t39=R_Parameter(t40,t41,t42,t43,t44,t45);}
t37=(t39).ink_f_value;
}
var t46:u32=t37;
var t47:u32=t12;
var t48:u32=(t47 * 10u);
var t49:u32=(t48 + t30);
var t50:u32;if(t49<a0[0u]){
t50=a0[1u+(t49)*1u+0u];}else{
t50=0u;}
t29=ink_f32_add(t31,ink_f32_mul(t46,t50));
}
var t51:u32=t29;
var t52:u32=t6;
var t53:u32=t7;
var t54:u32=t8;
var t55:u32=11u;
var t56:u32=t52;
var t57:u32=t53;
var t58:u32=t55;
var t59:u32=(t58 + 10u);
var t60:u32=t57;
var t61:u32;
if ((t60 == t59)) {
t61=t56;
} else {
var t62:u32=t59;
var t63:R_Parameter;if(t62<a2[0u]){
t63=R_Parameter(a2[1u+(t62)*6u+0u],a2[1u+(t62)*6u+1u],a2[1u+(t62)*6u+2u],a2[1u+(t62)*6u+3u],a2[1u+(t62)*6u+4u],a2[1u+(t62)*6u+5u]);}else{
var t64:u32=0u;
var t65:u32=0u;
var t66:u32=0u;
var t67:u32=1065353216u;
var t68:u32=1065353216u;
var t69:u32=0u;
t63=R_Parameter(t64,t65,t66,t67,t68,t69);}
t61=(t63).ink_f_value;
}
var t70:u32=t61;
var t71:u32=t70;
for(var t72=0u;t72<10u;t72++){
var t73:u32=t71;
var t74:u32=t52;
var t75:u32=t53;
var t76:u32=t55;
var t77:u32=(t76 + t72);
var t78:u32=t75;
var t79:u32;
if ((t78 == t77)) {
t79=t74;
} else {
var t80:u32=t77;
var t81:R_Parameter;if(t80<a2[0u]){
t81=R_Parameter(a2[1u+(t80)*6u+0u],a2[1u+(t80)*6u+1u],a2[1u+(t80)*6u+2u],a2[1u+(t80)*6u+3u],a2[1u+(t80)*6u+4u],a2[1u+(t80)*6u+5u]);}else{
var t82:u32=0u;
var t83:u32=0u;
var t84:u32=0u;
var t85:u32=1065353216u;
var t86:u32=1065353216u;
var t87:u32=0u;
t81=R_Parameter(t82,t83,t84,t85,t86,t87);}
t79=(t81).ink_f_value;
}
var t88:u32=t79;
var t89:u32=t54;
var t90:u32=(t89 * 10u);
var t91:u32=(t90 + t72);
var t92:u32;if(t91<a0[0u]){
t92=a0[1u+(t91)*1u+0u];}else{
t92=0u;}
t71=ink_f32_add(t73,ink_f32_mul(t88,t92));
}
var t93:u32=t71;
var t94:u32=t93;
var t95:u32;
if (ink_f32_lt(0u,t94)) {
var t96:u32=t51;
t95=ink_f32_mul(t96,t93);
} else {
t95=0u;
}
t9[0u]=t95;
var t97:u32=t6;
var t98:u32=t7;
var t99:u32=t8;
var t100:u32=22u;
var t101:u32=t97;
var t102:u32=t98;
var t103:u32=t100;
var t104:u32=(t103 + 10u);
var t105:u32=t102;
var t106:u32;
if ((t105 == t104)) {
t106=t101;
} else {
var t107:u32=t104;
var t108:R_Parameter;if(t107<a2[0u]){
t108=R_Parameter(a2[1u+(t107)*6u+0u],a2[1u+(t107)*6u+1u],a2[1u+(t107)*6u+2u],a2[1u+(t107)*6u+3u],a2[1u+(t107)*6u+4u],a2[1u+(t107)*6u+5u]);}else{
var t109:u32=0u;
var t110:u32=0u;
var t111:u32=0u;
var t112:u32=1065353216u;
var t113:u32=1065353216u;
var t114:u32=0u;
t108=R_Parameter(t109,t110,t111,t112,t113,t114);}
t106=(t108).ink_f_value;
}
var t115:u32=t106;
var t116:u32=t115;
for(var t117=0u;t117<10u;t117++){
var t118:u32=t116;
var t119:u32=t97;
var t120:u32=t98;
var t121:u32=t100;
var t122:u32=(t121 + t117);
var t123:u32=t120;
var t124:u32;
if ((t123 == t122)) {
t124=t119;
} else {
var t125:u32=t122;
var t126:R_Parameter;if(t125<a2[0u]){
t126=R_Parameter(a2[1u+(t125)*6u+0u],a2[1u+(t125)*6u+1u],a2[1u+(t125)*6u+2u],a2[1u+(t125)*6u+3u],a2[1u+(t125)*6u+4u],a2[1u+(t125)*6u+5u]);}else{
var t127:u32=0u;
var t128:u32=0u;
var t129:u32=0u;
var t130:u32=1065353216u;
var t131:u32=1065353216u;
var t132:u32=0u;
t126=R_Parameter(t127,t128,t129,t130,t131,t132);}
t124=(t126).ink_f_value;
}
var t133:u32=t124;
var t134:u32=t99;
var t135:u32=(t134 * 10u);
var t136:u32=(t135 + t117);
var t137:u32;if(t136<a0[0u]){
t137=a0[1u+(t136)*1u+0u];}else{
t137=0u;}
t116=ink_f32_add(t118,ink_f32_mul(t133,t137));
}
var t138:u32=t116;
var t139:u32=t6;
var t140:u32=t7;
var t141:u32=t8;
var t142:u32=33u;
var t143:u32=t139;
var t144:u32=t140;
var t145:u32=t142;
var t146:u32=(t145 + 10u);
var t147:u32=t144;
var t148:u32;
if ((t147 == t146)) {
t148=t143;
} else {
var t149:u32=t146;
var t150:R_Parameter;if(t149<a2[0u]){
t150=R_Parameter(a2[1u+(t149)*6u+0u],a2[1u+(t149)*6u+1u],a2[1u+(t149)*6u+2u],a2[1u+(t149)*6u+3u],a2[1u+(t149)*6u+4u],a2[1u+(t149)*6u+5u]);}else{
var t151:u32=0u;
var t152:u32=0u;
var t153:u32=0u;
var t154:u32=1065353216u;
var t155:u32=1065353216u;
var t156:u32=0u;
t150=R_Parameter(t151,t152,t153,t154,t155,t156);}
t148=(t150).ink_f_value;
}
var t157:u32=t148;
var t158:u32=t157;
for(var t159=0u;t159<10u;t159++){
var t160:u32=t158;
var t161:u32=t139;
var t162:u32=t140;
var t163:u32=t142;
var t164:u32=(t163 + t159);
var t165:u32=t162;
var t166:u32;
if ((t165 == t164)) {
t166=t161;
} else {
var t167:u32=t164;
var t168:R_Parameter;if(t167<a2[0u]){
t168=R_Parameter(a2[1u+(t167)*6u+0u],a2[1u+(t167)*6u+1u],a2[1u+(t167)*6u+2u],a2[1u+(t167)*6u+3u],a2[1u+(t167)*6u+4u],a2[1u+(t167)*6u+5u]);}else{
var t169:u32=0u;
var t170:u32=0u;
var t171:u32=0u;
var t172:u32=1065353216u;
var t173:u32=1065353216u;
var t174:u32=0u;
t168=R_Parameter(t169,t170,t171,t172,t173,t174);}
t166=(t168).ink_f_value;
}
var t175:u32=t166;
var t176:u32=t141;
var t177:u32=(t176 * 10u);
var t178:u32=(t177 + t159);
var t179:u32;if(t178<a0[0u]){
t179=a0[1u+(t178)*1u+0u];}else{
t179=0u;}
t158=ink_f32_add(t160,ink_f32_mul(t175,t179));
}
var t180:u32=t158;
var t181:u32=t180;
var t182:u32;
if (ink_f32_lt(0u,t181)) {
var t183:u32=t138;
t182=ink_f32_mul(t183,t180);
} else {
t182=0u;
}
t9[1u]=t182;
var t184:u32=t6;
var t185:u32=t7;
var t186:u32=t8;
var t187:u32=44u;
var t188:u32=t184;
var t189:u32=t185;
var t190:u32=t187;
var t191:u32=(t190 + 10u);
var t192:u32=t189;
var t193:u32;
if ((t192 == t191)) {
t193=t188;
} else {
var t194:u32=t191;
var t195:R_Parameter;if(t194<a2[0u]){
t195=R_Parameter(a2[1u+(t194)*6u+0u],a2[1u+(t194)*6u+1u],a2[1u+(t194)*6u+2u],a2[1u+(t194)*6u+3u],a2[1u+(t194)*6u+4u],a2[1u+(t194)*6u+5u]);}else{
var t196:u32=0u;
var t197:u32=0u;
var t198:u32=0u;
var t199:u32=1065353216u;
var t200:u32=1065353216u;
var t201:u32=0u;
t195=R_Parameter(t196,t197,t198,t199,t200,t201);}
t193=(t195).ink_f_value;
}
var t202:u32=t193;
var t203:u32=t202;
for(var t204=0u;t204<10u;t204++){
var t205:u32=t203;
var t206:u32=t184;
var t207:u32=t185;
var t208:u32=t187;
var t209:u32=(t208 + t204);
var t210:u32=t207;
var t211:u32;
if ((t210 == t209)) {
t211=t206;
} else {
var t212:u32=t209;
var t213:R_Parameter;if(t212<a2[0u]){
t213=R_Parameter(a2[1u+(t212)*6u+0u],a2[1u+(t212)*6u+1u],a2[1u+(t212)*6u+2u],a2[1u+(t212)*6u+3u],a2[1u+(t212)*6u+4u],a2[1u+(t212)*6u+5u]);}else{
var t214:u32=0u;
var t215:u32=0u;
var t216:u32=0u;
var t217:u32=1065353216u;
var t218:u32=1065353216u;
var t219:u32=0u;
t213=R_Parameter(t214,t215,t216,t217,t218,t219);}
t211=(t213).ink_f_value;
}
var t220:u32=t211;
var t221:u32=t186;
var t222:u32=(t221 * 10u);
var t223:u32=(t222 + t204);
var t224:u32;if(t223<a0[0u]){
t224=a0[1u+(t223)*1u+0u];}else{
t224=0u;}
t203=ink_f32_add(t205,ink_f32_mul(t220,t224));
}
var t225:u32=t203;
var t226:u32=t6;
var t227:u32=t7;
var t228:u32=t8;
var t229:u32=55u;
var t230:u32=t226;
var t231:u32=t227;
var t232:u32=t229;
var t233:u32=(t232 + 10u);
var t234:u32=t231;
var t235:u32;
if ((t234 == t233)) {
t235=t230;
} else {
var t236:u32=t233;
var t237:R_Parameter;if(t236<a2[0u]){
t237=R_Parameter(a2[1u+(t236)*6u+0u],a2[1u+(t236)*6u+1u],a2[1u+(t236)*6u+2u],a2[1u+(t236)*6u+3u],a2[1u+(t236)*6u+4u],a2[1u+(t236)*6u+5u]);}else{
var t238:u32=0u;
var t239:u32=0u;
var t240:u32=0u;
var t241:u32=1065353216u;
var t242:u32=1065353216u;
var t243:u32=0u;
t237=R_Parameter(t238,t239,t240,t241,t242,t243);}
t235=(t237).ink_f_value;
}
var t244:u32=t235;
var t245:u32=t244;
for(var t246=0u;t246<10u;t246++){
var t247:u32=t245;
var t248:u32=t226;
var t249:u32=t227;
var t250:u32=t229;
var t251:u32=(t250 + t246);
var t252:u32=t249;
var t253:u32;
if ((t252 == t251)) {
t253=t248;
} else {
var t254:u32=t251;
var t255:R_Parameter;if(t254<a2[0u]){
t255=R_Parameter(a2[1u+(t254)*6u+0u],a2[1u+(t254)*6u+1u],a2[1u+(t254)*6u+2u],a2[1u+(t254)*6u+3u],a2[1u+(t254)*6u+4u],a2[1u+(t254)*6u+5u]);}else{
var t256:u32=0u;
var t257:u32=0u;
var t258:u32=0u;
var t259:u32=1065353216u;
var t260:u32=1065353216u;
var t261:u32=0u;
t255=R_Parameter(t256,t257,t258,t259,t260,t261);}
t253=(t255).ink_f_value;
}
var t262:u32=t253;
var t263:u32=t228;
var t264:u32=(t263 * 10u);
var t265:u32=(t264 + t246);
var t266:u32;if(t265<a0[0u]){
t266=a0[1u+(t265)*1u+0u];}else{
t266=0u;}
t245=ink_f32_add(t247,ink_f32_mul(t262,t266));
}
var t267:u32=t245;
var t268:u32=t267;
var t269:u32;
if (ink_f32_lt(0u,t268)) {
var t270:u32=t225;
t269=ink_f32_mul(t270,t267);
} else {
t269=0u;
}
t9[2u]=t269;
var t271:u32=t6;
var t272:u32=t7;
var t273:u32=t8;
var t274:u32=66u;
var t275:u32=t271;
var t276:u32=t272;
var t277:u32=t274;
var t278:u32=(t277 + 10u);
var t279:u32=t276;
var t280:u32;
if ((t279 == t278)) {
t280=t275;
} else {
var t281:u32=t278;
var t282:R_Parameter;if(t281<a2[0u]){
t282=R_Parameter(a2[1u+(t281)*6u+0u],a2[1u+(t281)*6u+1u],a2[1u+(t281)*6u+2u],a2[1u+(t281)*6u+3u],a2[1u+(t281)*6u+4u],a2[1u+(t281)*6u+5u]);}else{
var t283:u32=0u;
var t284:u32=0u;
var t285:u32=0u;
var t286:u32=1065353216u;
var t287:u32=1065353216u;
var t288:u32=0u;
t282=R_Parameter(t283,t284,t285,t286,t287,t288);}
t280=(t282).ink_f_value;
}
var t289:u32=t280;
var t290:u32=t289;
for(var t291=0u;t291<10u;t291++){
var t292:u32=t290;
var t293:u32=t271;
var t294:u32=t272;
var t295:u32=t274;
var t296:u32=(t295 + t291);
var t297:u32=t294;
var t298:u32;
if ((t297 == t296)) {
t298=t293;
} else {
var t299:u32=t296;
var t300:R_Parameter;if(t299<a2[0u]){
t300=R_Parameter(a2[1u+(t299)*6u+0u],a2[1u+(t299)*6u+1u],a2[1u+(t299)*6u+2u],a2[1u+(t299)*6u+3u],a2[1u+(t299)*6u+4u],a2[1u+(t299)*6u+5u]);}else{
var t301:u32=0u;
var t302:u32=0u;
var t303:u32=0u;
var t304:u32=1065353216u;
var t305:u32=1065353216u;
var t306:u32=0u;
t300=R_Parameter(t301,t302,t303,t304,t305,t306);}
t298=(t300).ink_f_value;
}
var t307:u32=t298;
var t308:u32=t273;
var t309:u32=(t308 * 10u);
var t310:u32=(t309 + t291);
var t311:u32;if(t310<a0[0u]){
t311=a0[1u+(t310)*1u+0u];}else{
t311=0u;}
t290=ink_f32_add(t292,ink_f32_mul(t307,t311));
}
var t312:u32=t290;
var t313:u32=t6;
var t314:u32=t7;
var t315:u32=t8;
var t316:u32=77u;
var t317:u32=t313;
var t318:u32=t314;
var t319:u32=t316;
var t320:u32=(t319 + 10u);
var t321:u32=t318;
var t322:u32;
if ((t321 == t320)) {
t322=t317;
} else {
var t323:u32=t320;
var t324:R_Parameter;if(t323<a2[0u]){
t324=R_Parameter(a2[1u+(t323)*6u+0u],a2[1u+(t323)*6u+1u],a2[1u+(t323)*6u+2u],a2[1u+(t323)*6u+3u],a2[1u+(t323)*6u+4u],a2[1u+(t323)*6u+5u]);}else{
var t325:u32=0u;
var t326:u32=0u;
var t327:u32=0u;
var t328:u32=1065353216u;
var t329:u32=1065353216u;
var t330:u32=0u;
t324=R_Parameter(t325,t326,t327,t328,t329,t330);}
t322=(t324).ink_f_value;
}
var t331:u32=t322;
var t332:u32=t331;
for(var t333=0u;t333<10u;t333++){
var t334:u32=t332;
var t335:u32=t313;
var t336:u32=t314;
var t337:u32=t316;
var t338:u32=(t337 + t333);
var t339:u32=t336;
var t340:u32;
if ((t339 == t338)) {
t340=t335;
} else {
var t341:u32=t338;
var t342:R_Parameter;if(t341<a2[0u]){
t342=R_Parameter(a2[1u+(t341)*6u+0u],a2[1u+(t341)*6u+1u],a2[1u+(t341)*6u+2u],a2[1u+(t341)*6u+3u],a2[1u+(t341)*6u+4u],a2[1u+(t341)*6u+5u]);}else{
var t343:u32=0u;
var t344:u32=0u;
var t345:u32=0u;
var t346:u32=1065353216u;
var t347:u32=1065353216u;
var t348:u32=0u;
t342=R_Parameter(t343,t344,t345,t346,t347,t348);}
t340=(t342).ink_f_value;
}
var t349:u32=t340;
var t350:u32=t315;
var t351:u32=(t350 * 10u);
var t352:u32=(t351 + t333);
var t353:u32;if(t352<a0[0u]){
t353=a0[1u+(t352)*1u+0u];}else{
t353=0u;}
t332=ink_f32_add(t334,ink_f32_mul(t349,t353));
}
var t354:u32=t332;
var t355:u32=t354;
var t356:u32;
if (ink_f32_lt(0u,t355)) {
var t357:u32=t312;
t356=ink_f32_mul(t357,t354);
} else {
t356=0u;
}
t9[3u]=t356;
var t358:u32=t6;
var t359:u32=t7;
var t360:u32=t8;
var t361:u32=88u;
var t362:u32=t358;
var t363:u32=t359;
var t364:u32=t361;
var t365:u32=(t364 + 10u);
var t366:u32=t363;
var t367:u32;
if ((t366 == t365)) {
t367=t362;
} else {
var t368:u32=t365;
var t369:R_Parameter;if(t368<a2[0u]){
t369=R_Parameter(a2[1u+(t368)*6u+0u],a2[1u+(t368)*6u+1u],a2[1u+(t368)*6u+2u],a2[1u+(t368)*6u+3u],a2[1u+(t368)*6u+4u],a2[1u+(t368)*6u+5u]);}else{
var t370:u32=0u;
var t371:u32=0u;
var t372:u32=0u;
var t373:u32=1065353216u;
var t374:u32=1065353216u;
var t375:u32=0u;
t369=R_Parameter(t370,t371,t372,t373,t374,t375);}
t367=(t369).ink_f_value;
}
var t376:u32=t367;
var t377:u32=t376;
for(var t378=0u;t378<10u;t378++){
var t379:u32=t377;
var t380:u32=t358;
var t381:u32=t359;
var t382:u32=t361;
var t383:u32=(t382 + t378);
var t384:u32=t381;
var t385:u32;
if ((t384 == t383)) {
t385=t380;
} else {
var t386:u32=t383;
var t387:R_Parameter;if(t386<a2[0u]){
t387=R_Parameter(a2[1u+(t386)*6u+0u],a2[1u+(t386)*6u+1u],a2[1u+(t386)*6u+2u],a2[1u+(t386)*6u+3u],a2[1u+(t386)*6u+4u],a2[1u+(t386)*6u+5u]);}else{
var t388:u32=0u;
var t389:u32=0u;
var t390:u32=0u;
var t391:u32=1065353216u;
var t392:u32=1065353216u;
var t393:u32=0u;
t387=R_Parameter(t388,t389,t390,t391,t392,t393);}
t385=(t387).ink_f_value;
}
var t394:u32=t385;
var t395:u32=t360;
var t396:u32=(t395 * 10u);
var t397:u32=(t396 + t378);
var t398:u32;if(t397<a0[0u]){
t398=a0[1u+(t397)*1u+0u];}else{
t398=0u;}
t377=ink_f32_add(t379,ink_f32_mul(t394,t398));
}
var t399:u32=t377;
var t400:u32=t6;
var t401:u32=t7;
var t402:u32=t8;
var t403:u32=99u;
var t404:u32=t400;
var t405:u32=t401;
var t406:u32=t403;
var t407:u32=(t406 + 10u);
var t408:u32=t405;
var t409:u32;
if ((t408 == t407)) {
t409=t404;
} else {
var t410:u32=t407;
var t411:R_Parameter;if(t410<a2[0u]){
t411=R_Parameter(a2[1u+(t410)*6u+0u],a2[1u+(t410)*6u+1u],a2[1u+(t410)*6u+2u],a2[1u+(t410)*6u+3u],a2[1u+(t410)*6u+4u],a2[1u+(t410)*6u+5u]);}else{
var t412:u32=0u;
var t413:u32=0u;
var t414:u32=0u;
var t415:u32=1065353216u;
var t416:u32=1065353216u;
var t417:u32=0u;
t411=R_Parameter(t412,t413,t414,t415,t416,t417);}
t409=(t411).ink_f_value;
}
var t418:u32=t409;
var t419:u32=t418;
for(var t420=0u;t420<10u;t420++){
var t421:u32=t419;
var t422:u32=t400;
var t423:u32=t401;
var t424:u32=t403;
var t425:u32=(t424 + t420);
var t426:u32=t423;
var t427:u32;
if ((t426 == t425)) {
t427=t422;
} else {
var t428:u32=t425;
var t429:R_Parameter;if(t428<a2[0u]){
t429=R_Parameter(a2[1u+(t428)*6u+0u],a2[1u+(t428)*6u+1u],a2[1u+(t428)*6u+2u],a2[1u+(t428)*6u+3u],a2[1u+(t428)*6u+4u],a2[1u+(t428)*6u+5u]);}else{
var t430:u32=0u;
var t431:u32=0u;
var t432:u32=0u;
var t433:u32=1065353216u;
var t434:u32=1065353216u;
var t435:u32=0u;
t429=R_Parameter(t430,t431,t432,t433,t434,t435);}
t427=(t429).ink_f_value;
}
var t436:u32=t427;
var t437:u32=t402;
var t438:u32=(t437 * 10u);
var t439:u32=(t438 + t420);
var t440:u32;if(t439<a0[0u]){
t440=a0[1u+(t439)*1u+0u];}else{
t440=0u;}
t419=ink_f32_add(t421,ink_f32_mul(t436,t440));
}
var t441:u32=t419;
var t442:u32=t441;
var t443:u32;
if (ink_f32_lt(0u,t442)) {
var t444:u32=t399;
t443=ink_f32_mul(t444,t441);
} else {
t443=0u;
}
t9[4u]=t443;
var t445:u32=t6;
var t446:u32=t7;
var t447:u32=t8;
var t448:u32=110u;
var t449:u32=t445;
var t450:u32=t446;
var t451:u32=t448;
var t452:u32=(t451 + 10u);
var t453:u32=t450;
var t454:u32;
if ((t453 == t452)) {
t454=t449;
} else {
var t455:u32=t452;
var t456:R_Parameter;if(t455<a2[0u]){
t456=R_Parameter(a2[1u+(t455)*6u+0u],a2[1u+(t455)*6u+1u],a2[1u+(t455)*6u+2u],a2[1u+(t455)*6u+3u],a2[1u+(t455)*6u+4u],a2[1u+(t455)*6u+5u]);}else{
var t457:u32=0u;
var t458:u32=0u;
var t459:u32=0u;
var t460:u32=1065353216u;
var t461:u32=1065353216u;
var t462:u32=0u;
t456=R_Parameter(t457,t458,t459,t460,t461,t462);}
t454=(t456).ink_f_value;
}
var t463:u32=t454;
var t464:u32=t463;
for(var t465=0u;t465<10u;t465++){
var t466:u32=t464;
var t467:u32=t445;
var t468:u32=t446;
var t469:u32=t448;
var t470:u32=(t469 + t465);
var t471:u32=t468;
var t472:u32;
if ((t471 == t470)) {
t472=t467;
} else {
var t473:u32=t470;
var t474:R_Parameter;if(t473<a2[0u]){
t474=R_Parameter(a2[1u+(t473)*6u+0u],a2[1u+(t473)*6u+1u],a2[1u+(t473)*6u+2u],a2[1u+(t473)*6u+3u],a2[1u+(t473)*6u+4u],a2[1u+(t473)*6u+5u]);}else{
var t475:u32=0u;
var t476:u32=0u;
var t477:u32=0u;
var t478:u32=1065353216u;
var t479:u32=1065353216u;
var t480:u32=0u;
t474=R_Parameter(t475,t476,t477,t478,t479,t480);}
t472=(t474).ink_f_value;
}
var t481:u32=t472;
var t482:u32=t447;
var t483:u32=(t482 * 10u);
var t484:u32=(t483 + t465);
var t485:u32;if(t484<a0[0u]){
t485=a0[1u+(t484)*1u+0u];}else{
t485=0u;}
t464=ink_f32_add(t466,ink_f32_mul(t481,t485));
}
var t486:u32=t464;
var t487:u32=t6;
var t488:u32=t7;
var t489:u32=t8;
var t490:u32=121u;
var t491:u32=t487;
var t492:u32=t488;
var t493:u32=t490;
var t494:u32=(t493 + 10u);
var t495:u32=t492;
var t496:u32;
if ((t495 == t494)) {
t496=t491;
} else {
var t497:u32=t494;
var t498:R_Parameter;if(t497<a2[0u]){
t498=R_Parameter(a2[1u+(t497)*6u+0u],a2[1u+(t497)*6u+1u],a2[1u+(t497)*6u+2u],a2[1u+(t497)*6u+3u],a2[1u+(t497)*6u+4u],a2[1u+(t497)*6u+5u]);}else{
var t499:u32=0u;
var t500:u32=0u;
var t501:u32=0u;
var t502:u32=1065353216u;
var t503:u32=1065353216u;
var t504:u32=0u;
t498=R_Parameter(t499,t500,t501,t502,t503,t504);}
t496=(t498).ink_f_value;
}
var t505:u32=t496;
var t506:u32=t505;
for(var t507=0u;t507<10u;t507++){
var t508:u32=t506;
var t509:u32=t487;
var t510:u32=t488;
var t511:u32=t490;
var t512:u32=(t511 + t507);
var t513:u32=t510;
var t514:u32;
if ((t513 == t512)) {
t514=t509;
} else {
var t515:u32=t512;
var t516:R_Parameter;if(t515<a2[0u]){
t516=R_Parameter(a2[1u+(t515)*6u+0u],a2[1u+(t515)*6u+1u],a2[1u+(t515)*6u+2u],a2[1u+(t515)*6u+3u],a2[1u+(t515)*6u+4u],a2[1u+(t515)*6u+5u]);}else{
var t517:u32=0u;
var t518:u32=0u;
var t519:u32=0u;
var t520:u32=1065353216u;
var t521:u32=1065353216u;
var t522:u32=0u;
t516=R_Parameter(t517,t518,t519,t520,t521,t522);}
t514=(t516).ink_f_value;
}
var t523:u32=t514;
var t524:u32=t489;
var t525:u32=(t524 * 10u);
var t526:u32=(t525 + t507);
var t527:u32;if(t526<a0[0u]){
t527=a0[1u+(t526)*1u+0u];}else{
t527=0u;}
t506=ink_f32_add(t508,ink_f32_mul(t523,t527));
}
var t528:u32=t506;
var t529:u32=t528;
var t530:u32;
if (ink_f32_lt(0u,t529)) {
var t531:u32=t486;
t530=ink_f32_mul(t531,t528);
} else {
t530=0u;
}
t9[5u]=t530;
var t532:u32=t3;
var t533:u32=t4;
var t534:array<u32,6>;
var t535:u32=t532;
var t536:u32=t533;
var t537:u32=132u;
var t538:u32=t535;
var t539:u32=t536;
var t540:u32=t537;
var t541:u32=(t540 + 6u);
var t542:u32=t539;
var t543:u32;
if ((t542 == t541)) {
t543=t538;
} else {
var t544:u32=t541;
var t545:R_Parameter;if(t544<a2[0u]){
t545=R_Parameter(a2[1u+(t544)*6u+0u],a2[1u+(t544)*6u+1u],a2[1u+(t544)*6u+2u],a2[1u+(t544)*6u+3u],a2[1u+(t544)*6u+4u],a2[1u+(t544)*6u+5u]);}else{
var t546:u32=0u;
var t547:u32=0u;
var t548:u32=0u;
var t549:u32=1065353216u;
var t550:u32=1065353216u;
var t551:u32=0u;
t545=R_Parameter(t546,t547,t548,t549,t550,t551);}
t543=(t545).ink_f_value;
}
var t552:u32=t543;
var t553:u32=t552;
for(var t554=0u;t554<6u;t554++){
var t555:u32=t553;
var t556:u32=t535;
var t557:u32=t536;
var t558:u32=t537;
var t559:u32=(t558 + t554);
var t560:u32=t557;
var t561:u32;
if ((t560 == t559)) {
t561=t556;
} else {
var t562:u32=t559;
var t563:R_Parameter;if(t562<a2[0u]){
t563=R_Parameter(a2[1u+(t562)*6u+0u],a2[1u+(t562)*6u+1u],a2[1u+(t562)*6u+2u],a2[1u+(t562)*6u+3u],a2[1u+(t562)*6u+4u],a2[1u+(t562)*6u+5u]);}else{
var t564:u32=0u;
var t565:u32=0u;
var t566:u32=0u;
var t567:u32=1065353216u;
var t568:u32=1065353216u;
var t569:u32=0u;
t563=R_Parameter(t564,t565,t566,t567,t568,t569);}
t561=(t563).ink_f_value;
}
var t570:u32=t561;
var t571:u32=t554;
var t572:u32;if(t571<6u){
t572=t9[t571];}else{
t572=0u;}
t553=ink_f32_add(t555,ink_f32_mul(t570,t572));
}
var t573:u32=t553;
var t574:u32=t532;
var t575:u32=t533;
var t576:u32=139u;
var t577:u32=t574;
var t578:u32=t575;
var t579:u32=t576;
var t580:u32=(t579 + 6u);
var t581:u32=t578;
var t582:u32;
if ((t581 == t580)) {
t582=t577;
} else {
var t583:u32=t580;
var t584:R_Parameter;if(t583<a2[0u]){
t584=R_Parameter(a2[1u+(t583)*6u+0u],a2[1u+(t583)*6u+1u],a2[1u+(t583)*6u+2u],a2[1u+(t583)*6u+3u],a2[1u+(t583)*6u+4u],a2[1u+(t583)*6u+5u]);}else{
var t585:u32=0u;
var t586:u32=0u;
var t587:u32=0u;
var t588:u32=1065353216u;
var t589:u32=1065353216u;
var t590:u32=0u;
t584=R_Parameter(t585,t586,t587,t588,t589,t590);}
t582=(t584).ink_f_value;
}
var t591:u32=t582;
var t592:u32=t591;
for(var t593=0u;t593<6u;t593++){
var t594:u32=t592;
var t595:u32=t574;
var t596:u32=t575;
var t597:u32=t576;
var t598:u32=(t597 + t593);
var t599:u32=t596;
var t600:u32;
if ((t599 == t598)) {
t600=t595;
} else {
var t601:u32=t598;
var t602:R_Parameter;if(t601<a2[0u]){
t602=R_Parameter(a2[1u+(t601)*6u+0u],a2[1u+(t601)*6u+1u],a2[1u+(t601)*6u+2u],a2[1u+(t601)*6u+3u],a2[1u+(t601)*6u+4u],a2[1u+(t601)*6u+5u]);}else{
var t603:u32=0u;
var t604:u32=0u;
var t605:u32=0u;
var t606:u32=1065353216u;
var t607:u32=1065353216u;
var t608:u32=0u;
t602=R_Parameter(t603,t604,t605,t606,t607,t608);}
t600=(t602).ink_f_value;
}
var t609:u32=t600;
var t610:u32=t593;
var t611:u32;if(t610<6u){
t611=t9[t610];}else{
t611=0u;}
t592=ink_f32_add(t594,ink_f32_mul(t609,t611));
}
var t612:u32=t592;
var t613:u32=t612;
var t614:u32;
if (ink_f32_lt(0u,t613)) {
var t615:u32=t573;
t614=ink_f32_mul(t615,t612);
} else {
t614=0u;
}
t534[0u]=t614;
var t616:u32=t532;
var t617:u32=t533;
var t618:u32=146u;
var t619:u32=t616;
var t620:u32=t617;
var t621:u32=t618;
var t622:u32=(t621 + 6u);
var t623:u32=t620;
var t624:u32;
if ((t623 == t622)) {
t624=t619;
} else {
var t625:u32=t622;
var t626:R_Parameter;if(t625<a2[0u]){
t626=R_Parameter(a2[1u+(t625)*6u+0u],a2[1u+(t625)*6u+1u],a2[1u+(t625)*6u+2u],a2[1u+(t625)*6u+3u],a2[1u+(t625)*6u+4u],a2[1u+(t625)*6u+5u]);}else{
var t627:u32=0u;
var t628:u32=0u;
var t629:u32=0u;
var t630:u32=1065353216u;
var t631:u32=1065353216u;
var t632:u32=0u;
t626=R_Parameter(t627,t628,t629,t630,t631,t632);}
t624=(t626).ink_f_value;
}
var t633:u32=t624;
var t634:u32=t633;
for(var t635=0u;t635<6u;t635++){
var t636:u32=t634;
var t637:u32=t616;
var t638:u32=t617;
var t639:u32=t618;
var t640:u32=(t639 + t635);
var t641:u32=t638;
var t642:u32;
if ((t641 == t640)) {
t642=t637;
} else {
var t643:u32=t640;
var t644:R_Parameter;if(t643<a2[0u]){
t644=R_Parameter(a2[1u+(t643)*6u+0u],a2[1u+(t643)*6u+1u],a2[1u+(t643)*6u+2u],a2[1u+(t643)*6u+3u],a2[1u+(t643)*6u+4u],a2[1u+(t643)*6u+5u]);}else{
var t645:u32=0u;
var t646:u32=0u;
var t647:u32=0u;
var t648:u32=1065353216u;
var t649:u32=1065353216u;
var t650:u32=0u;
t644=R_Parameter(t645,t646,t647,t648,t649,t650);}
t642=(t644).ink_f_value;
}
var t651:u32=t642;
var t652:u32=t635;
var t653:u32;if(t652<6u){
t653=t9[t652];}else{
t653=0u;}
t634=ink_f32_add(t636,ink_f32_mul(t651,t653));
}
var t654:u32=t634;
var t655:u32=t532;
var t656:u32=t533;
var t657:u32=153u;
var t658:u32=t655;
var t659:u32=t656;
var t660:u32=t657;
var t661:u32=(t660 + 6u);
var t662:u32=t659;
var t663:u32;
if ((t662 == t661)) {
t663=t658;
} else {
var t664:u32=t661;
var t665:R_Parameter;if(t664<a2[0u]){
t665=R_Parameter(a2[1u+(t664)*6u+0u],a2[1u+(t664)*6u+1u],a2[1u+(t664)*6u+2u],a2[1u+(t664)*6u+3u],a2[1u+(t664)*6u+4u],a2[1u+(t664)*6u+5u]);}else{
var t666:u32=0u;
var t667:u32=0u;
var t668:u32=0u;
var t669:u32=1065353216u;
var t670:u32=1065353216u;
var t671:u32=0u;
t665=R_Parameter(t666,t667,t668,t669,t670,t671);}
t663=(t665).ink_f_value;
}
var t672:u32=t663;
var t673:u32=t672;
for(var t674=0u;t674<6u;t674++){
var t675:u32=t673;
var t676:u32=t655;
var t677:u32=t656;
var t678:u32=t657;
var t679:u32=(t678 + t674);
var t680:u32=t677;
var t681:u32;
if ((t680 == t679)) {
t681=t676;
} else {
var t682:u32=t679;
var t683:R_Parameter;if(t682<a2[0u]){
t683=R_Parameter(a2[1u+(t682)*6u+0u],a2[1u+(t682)*6u+1u],a2[1u+(t682)*6u+2u],a2[1u+(t682)*6u+3u],a2[1u+(t682)*6u+4u],a2[1u+(t682)*6u+5u]);}else{
var t684:u32=0u;
var t685:u32=0u;
var t686:u32=0u;
var t687:u32=1065353216u;
var t688:u32=1065353216u;
var t689:u32=0u;
t683=R_Parameter(t684,t685,t686,t687,t688,t689);}
t681=(t683).ink_f_value;
}
var t690:u32=t681;
var t691:u32=t674;
var t692:u32;if(t691<6u){
t692=t9[t691];}else{
t692=0u;}
t673=ink_f32_add(t675,ink_f32_mul(t690,t692));
}
var t693:u32=t673;
var t694:u32=t693;
var t695:u32;
if (ink_f32_lt(0u,t694)) {
var t696:u32=t654;
t695=ink_f32_mul(t696,t693);
} else {
t695=0u;
}
t534[1u]=t695;
var t697:u32=t532;
var t698:u32=t533;
var t699:u32=160u;
var t700:u32=t697;
var t701:u32=t698;
var t702:u32=t699;
var t703:u32=(t702 + 6u);
var t704:u32=t701;
var t705:u32;
if ((t704 == t703)) {
t705=t700;
} else {
var t706:u32=t703;
var t707:R_Parameter;if(t706<a2[0u]){
t707=R_Parameter(a2[1u+(t706)*6u+0u],a2[1u+(t706)*6u+1u],a2[1u+(t706)*6u+2u],a2[1u+(t706)*6u+3u],a2[1u+(t706)*6u+4u],a2[1u+(t706)*6u+5u]);}else{
var t708:u32=0u;
var t709:u32=0u;
var t710:u32=0u;
var t711:u32=1065353216u;
var t712:u32=1065353216u;
var t713:u32=0u;
t707=R_Parameter(t708,t709,t710,t711,t712,t713);}
t705=(t707).ink_f_value;
}
var t714:u32=t705;
var t715:u32=t714;
for(var t716=0u;t716<6u;t716++){
var t717:u32=t715;
var t718:u32=t697;
var t719:u32=t698;
var t720:u32=t699;
var t721:u32=(t720 + t716);
var t722:u32=t719;
var t723:u32;
if ((t722 == t721)) {
t723=t718;
} else {
var t724:u32=t721;
var t725:R_Parameter;if(t724<a2[0u]){
t725=R_Parameter(a2[1u+(t724)*6u+0u],a2[1u+(t724)*6u+1u],a2[1u+(t724)*6u+2u],a2[1u+(t724)*6u+3u],a2[1u+(t724)*6u+4u],a2[1u+(t724)*6u+5u]);}else{
var t726:u32=0u;
var t727:u32=0u;
var t728:u32=0u;
var t729:u32=1065353216u;
var t730:u32=1065353216u;
var t731:u32=0u;
t725=R_Parameter(t726,t727,t728,t729,t730,t731);}
t723=(t725).ink_f_value;
}
var t732:u32=t723;
var t733:u32=t716;
var t734:u32;if(t733<6u){
t734=t9[t733];}else{
t734=0u;}
t715=ink_f32_add(t717,ink_f32_mul(t732,t734));
}
var t735:u32=t715;
var t736:u32=t532;
var t737:u32=t533;
var t738:u32=167u;
var t739:u32=t736;
var t740:u32=t737;
var t741:u32=t738;
var t742:u32=(t741 + 6u);
var t743:u32=t740;
var t744:u32;
if ((t743 == t742)) {
t744=t739;
} else {
var t745:u32=t742;
var t746:R_Parameter;if(t745<a2[0u]){
t746=R_Parameter(a2[1u+(t745)*6u+0u],a2[1u+(t745)*6u+1u],a2[1u+(t745)*6u+2u],a2[1u+(t745)*6u+3u],a2[1u+(t745)*6u+4u],a2[1u+(t745)*6u+5u]);}else{
var t747:u32=0u;
var t748:u32=0u;
var t749:u32=0u;
var t750:u32=1065353216u;
var t751:u32=1065353216u;
var t752:u32=0u;
t746=R_Parameter(t747,t748,t749,t750,t751,t752);}
t744=(t746).ink_f_value;
}
var t753:u32=t744;
var t754:u32=t753;
for(var t755=0u;t755<6u;t755++){
var t756:u32=t754;
var t757:u32=t736;
var t758:u32=t737;
var t759:u32=t738;
var t760:u32=(t759 + t755);
var t761:u32=t758;
var t762:u32;
if ((t761 == t760)) {
t762=t757;
} else {
var t763:u32=t760;
var t764:R_Parameter;if(t763<a2[0u]){
t764=R_Parameter(a2[1u+(t763)*6u+0u],a2[1u+(t763)*6u+1u],a2[1u+(t763)*6u+2u],a2[1u+(t763)*6u+3u],a2[1u+(t763)*6u+4u],a2[1u+(t763)*6u+5u]);}else{
var t765:u32=0u;
var t766:u32=0u;
var t767:u32=0u;
var t768:u32=1065353216u;
var t769:u32=1065353216u;
var t770:u32=0u;
t764=R_Parameter(t765,t766,t767,t768,t769,t770);}
t762=(t764).ink_f_value;
}
var t771:u32=t762;
var t772:u32=t755;
var t773:u32;if(t772<6u){
t773=t9[t772];}else{
t773=0u;}
t754=ink_f32_add(t756,ink_f32_mul(t771,t773));
}
var t774:u32=t754;
var t775:u32=t774;
var t776:u32;
if (ink_f32_lt(0u,t775)) {
var t777:u32=t735;
t776=ink_f32_mul(t777,t774);
} else {
t776=0u;
}
t534[2u]=t776;
var t778:u32=t532;
var t779:u32=t533;
var t780:u32=174u;
var t781:u32=t778;
var t782:u32=t779;
var t783:u32=t780;
var t784:u32=(t783 + 6u);
var t785:u32=t782;
var t786:u32;
if ((t785 == t784)) {
t786=t781;
} else {
var t787:u32=t784;
var t788:R_Parameter;if(t787<a2[0u]){
t788=R_Parameter(a2[1u+(t787)*6u+0u],a2[1u+(t787)*6u+1u],a2[1u+(t787)*6u+2u],a2[1u+(t787)*6u+3u],a2[1u+(t787)*6u+4u],a2[1u+(t787)*6u+5u]);}else{
var t789:u32=0u;
var t790:u32=0u;
var t791:u32=0u;
var t792:u32=1065353216u;
var t793:u32=1065353216u;
var t794:u32=0u;
t788=R_Parameter(t789,t790,t791,t792,t793,t794);}
t786=(t788).ink_f_value;
}
var t795:u32=t786;
var t796:u32=t795;
for(var t797=0u;t797<6u;t797++){
var t798:u32=t796;
var t799:u32=t778;
var t800:u32=t779;
var t801:u32=t780;
var t802:u32=(t801 + t797);
var t803:u32=t800;
var t804:u32;
if ((t803 == t802)) {
t804=t799;
} else {
var t805:u32=t802;
var t806:R_Parameter;if(t805<a2[0u]){
t806=R_Parameter(a2[1u+(t805)*6u+0u],a2[1u+(t805)*6u+1u],a2[1u+(t805)*6u+2u],a2[1u+(t805)*6u+3u],a2[1u+(t805)*6u+4u],a2[1u+(t805)*6u+5u]);}else{
var t807:u32=0u;
var t808:u32=0u;
var t809:u32=0u;
var t810:u32=1065353216u;
var t811:u32=1065353216u;
var t812:u32=0u;
t806=R_Parameter(t807,t808,t809,t810,t811,t812);}
t804=(t806).ink_f_value;
}
var t813:u32=t804;
var t814:u32=t797;
var t815:u32;if(t814<6u){
t815=t9[t814];}else{
t815=0u;}
t796=ink_f32_add(t798,ink_f32_mul(t813,t815));
}
var t816:u32=t796;
var t817:u32=t532;
var t818:u32=t533;
var t819:u32=181u;
var t820:u32=t817;
var t821:u32=t818;
var t822:u32=t819;
var t823:u32=(t822 + 6u);
var t824:u32=t821;
var t825:u32;
if ((t824 == t823)) {
t825=t820;
} else {
var t826:u32=t823;
var t827:R_Parameter;if(t826<a2[0u]){
t827=R_Parameter(a2[1u+(t826)*6u+0u],a2[1u+(t826)*6u+1u],a2[1u+(t826)*6u+2u],a2[1u+(t826)*6u+3u],a2[1u+(t826)*6u+4u],a2[1u+(t826)*6u+5u]);}else{
var t828:u32=0u;
var t829:u32=0u;
var t830:u32=0u;
var t831:u32=1065353216u;
var t832:u32=1065353216u;
var t833:u32=0u;
t827=R_Parameter(t828,t829,t830,t831,t832,t833);}
t825=(t827).ink_f_value;
}
var t834:u32=t825;
var t835:u32=t834;
for(var t836=0u;t836<6u;t836++){
var t837:u32=t835;
var t838:u32=t817;
var t839:u32=t818;
var t840:u32=t819;
var t841:u32=(t840 + t836);
var t842:u32=t839;
var t843:u32;
if ((t842 == t841)) {
t843=t838;
} else {
var t844:u32=t841;
var t845:R_Parameter;if(t844<a2[0u]){
t845=R_Parameter(a2[1u+(t844)*6u+0u],a2[1u+(t844)*6u+1u],a2[1u+(t844)*6u+2u],a2[1u+(t844)*6u+3u],a2[1u+(t844)*6u+4u],a2[1u+(t844)*6u+5u]);}else{
var t846:u32=0u;
var t847:u32=0u;
var t848:u32=0u;
var t849:u32=1065353216u;
var t850:u32=1065353216u;
var t851:u32=0u;
t845=R_Parameter(t846,t847,t848,t849,t850,t851);}
t843=(t845).ink_f_value;
}
var t852:u32=t843;
var t853:u32=t836;
var t854:u32;if(t853<6u){
t854=t9[t853];}else{
t854=0u;}
t835=ink_f32_add(t837,ink_f32_mul(t852,t854));
}
var t855:u32=t835;
var t856:u32=t855;
var t857:u32;
if (ink_f32_lt(0u,t856)) {
var t858:u32=t816;
t857=ink_f32_mul(t858,t855);
} else {
t857=0u;
}
t534[3u]=t857;
var t859:u32=t532;
var t860:u32=t533;
var t861:u32=188u;
var t862:u32=t859;
var t863:u32=t860;
var t864:u32=t861;
var t865:u32=(t864 + 6u);
var t866:u32=t863;
var t867:u32;
if ((t866 == t865)) {
t867=t862;
} else {
var t868:u32=t865;
var t869:R_Parameter;if(t868<a2[0u]){
t869=R_Parameter(a2[1u+(t868)*6u+0u],a2[1u+(t868)*6u+1u],a2[1u+(t868)*6u+2u],a2[1u+(t868)*6u+3u],a2[1u+(t868)*6u+4u],a2[1u+(t868)*6u+5u]);}else{
var t870:u32=0u;
var t871:u32=0u;
var t872:u32=0u;
var t873:u32=1065353216u;
var t874:u32=1065353216u;
var t875:u32=0u;
t869=R_Parameter(t870,t871,t872,t873,t874,t875);}
t867=(t869).ink_f_value;
}
var t876:u32=t867;
var t877:u32=t876;
for(var t878=0u;t878<6u;t878++){
var t879:u32=t877;
var t880:u32=t859;
var t881:u32=t860;
var t882:u32=t861;
var t883:u32=(t882 + t878);
var t884:u32=t881;
var t885:u32;
if ((t884 == t883)) {
t885=t880;
} else {
var t886:u32=t883;
var t887:R_Parameter;if(t886<a2[0u]){
t887=R_Parameter(a2[1u+(t886)*6u+0u],a2[1u+(t886)*6u+1u],a2[1u+(t886)*6u+2u],a2[1u+(t886)*6u+3u],a2[1u+(t886)*6u+4u],a2[1u+(t886)*6u+5u]);}else{
var t888:u32=0u;
var t889:u32=0u;
var t890:u32=0u;
var t891:u32=1065353216u;
var t892:u32=1065353216u;
var t893:u32=0u;
t887=R_Parameter(t888,t889,t890,t891,t892,t893);}
t885=(t887).ink_f_value;
}
var t894:u32=t885;
var t895:u32=t878;
var t896:u32;if(t895<6u){
t896=t9[t895];}else{
t896=0u;}
t877=ink_f32_add(t879,ink_f32_mul(t894,t896));
}
var t897:u32=t877;
var t898:u32=t532;
var t899:u32=t533;
var t900:u32=195u;
var t901:u32=t898;
var t902:u32=t899;
var t903:u32=t900;
var t904:u32=(t903 + 6u);
var t905:u32=t902;
var t906:u32;
if ((t905 == t904)) {
t906=t901;
} else {
var t907:u32=t904;
var t908:R_Parameter;if(t907<a2[0u]){
t908=R_Parameter(a2[1u+(t907)*6u+0u],a2[1u+(t907)*6u+1u],a2[1u+(t907)*6u+2u],a2[1u+(t907)*6u+3u],a2[1u+(t907)*6u+4u],a2[1u+(t907)*6u+5u]);}else{
var t909:u32=0u;
var t910:u32=0u;
var t911:u32=0u;
var t912:u32=1065353216u;
var t913:u32=1065353216u;
var t914:u32=0u;
t908=R_Parameter(t909,t910,t911,t912,t913,t914);}
t906=(t908).ink_f_value;
}
var t915:u32=t906;
var t916:u32=t915;
for(var t917=0u;t917<6u;t917++){
var t918:u32=t916;
var t919:u32=t898;
var t920:u32=t899;
var t921:u32=t900;
var t922:u32=(t921 + t917);
var t923:u32=t920;
var t924:u32;
if ((t923 == t922)) {
t924=t919;
} else {
var t925:u32=t922;
var t926:R_Parameter;if(t925<a2[0u]){
t926=R_Parameter(a2[1u+(t925)*6u+0u],a2[1u+(t925)*6u+1u],a2[1u+(t925)*6u+2u],a2[1u+(t925)*6u+3u],a2[1u+(t925)*6u+4u],a2[1u+(t925)*6u+5u]);}else{
var t927:u32=0u;
var t928:u32=0u;
var t929:u32=0u;
var t930:u32=1065353216u;
var t931:u32=1065353216u;
var t932:u32=0u;
t926=R_Parameter(t927,t928,t929,t930,t931,t932);}
t924=(t926).ink_f_value;
}
var t933:u32=t924;
var t934:u32=t917;
var t935:u32;if(t934<6u){
t935=t9[t934];}else{
t935=0u;}
t916=ink_f32_add(t918,ink_f32_mul(t933,t935));
}
var t936:u32=t916;
var t937:u32=t936;
var t938:u32;
if (ink_f32_lt(0u,t937)) {
var t939:u32=t897;
t938=ink_f32_mul(t939,t936);
} else {
t938=0u;
}
t534[4u]=t938;
var t940:u32=t532;
var t941:u32=t533;
var t942:u32=202u;
var t943:u32=t940;
var t944:u32=t941;
var t945:u32=t942;
var t946:u32=(t945 + 6u);
var t947:u32=t944;
var t948:u32;
if ((t947 == t946)) {
t948=t943;
} else {
var t949:u32=t946;
var t950:R_Parameter;if(t949<a2[0u]){
t950=R_Parameter(a2[1u+(t949)*6u+0u],a2[1u+(t949)*6u+1u],a2[1u+(t949)*6u+2u],a2[1u+(t949)*6u+3u],a2[1u+(t949)*6u+4u],a2[1u+(t949)*6u+5u]);}else{
var t951:u32=0u;
var t952:u32=0u;
var t953:u32=0u;
var t954:u32=1065353216u;
var t955:u32=1065353216u;
var t956:u32=0u;
t950=R_Parameter(t951,t952,t953,t954,t955,t956);}
t948=(t950).ink_f_value;
}
var t957:u32=t948;
var t958:u32=t957;
for(var t959=0u;t959<6u;t959++){
var t960:u32=t958;
var t961:u32=t940;
var t962:u32=t941;
var t963:u32=t942;
var t964:u32=(t963 + t959);
var t965:u32=t962;
var t966:u32;
if ((t965 == t964)) {
t966=t961;
} else {
var t967:u32=t964;
var t968:R_Parameter;if(t967<a2[0u]){
t968=R_Parameter(a2[1u+(t967)*6u+0u],a2[1u+(t967)*6u+1u],a2[1u+(t967)*6u+2u],a2[1u+(t967)*6u+3u],a2[1u+(t967)*6u+4u],a2[1u+(t967)*6u+5u]);}else{
var t969:u32=0u;
var t970:u32=0u;
var t971:u32=0u;
var t972:u32=1065353216u;
var t973:u32=1065353216u;
var t974:u32=0u;
t968=R_Parameter(t969,t970,t971,t972,t973,t974);}
t966=(t968).ink_f_value;
}
var t975:u32=t966;
var t976:u32=t959;
var t977:u32;if(t976<6u){
t977=t9[t976];}else{
t977=0u;}
t958=ink_f32_add(t960,ink_f32_mul(t975,t977));
}
var t978:u32=t958;
var t979:u32=t532;
var t980:u32=t533;
var t981:u32=209u;
var t982:u32=t979;
var t983:u32=t980;
var t984:u32=t981;
var t985:u32=(t984 + 6u);
var t986:u32=t983;
var t987:u32;
if ((t986 == t985)) {
t987=t982;
} else {
var t988:u32=t985;
var t989:R_Parameter;if(t988<a2[0u]){
t989=R_Parameter(a2[1u+(t988)*6u+0u],a2[1u+(t988)*6u+1u],a2[1u+(t988)*6u+2u],a2[1u+(t988)*6u+3u],a2[1u+(t988)*6u+4u],a2[1u+(t988)*6u+5u]);}else{
var t990:u32=0u;
var t991:u32=0u;
var t992:u32=0u;
var t993:u32=1065353216u;
var t994:u32=1065353216u;
var t995:u32=0u;
t989=R_Parameter(t990,t991,t992,t993,t994,t995);}
t987=(t989).ink_f_value;
}
var t996:u32=t987;
var t997:u32=t996;
for(var t998=0u;t998<6u;t998++){
var t999:u32=t997;
var t1000:u32=t979;
var t1001:u32=t980;
var t1002:u32=t981;
var t1003:u32=(t1002 + t998);
var t1004:u32=t1001;
var t1005:u32;
if ((t1004 == t1003)) {
t1005=t1000;
} else {
var t1006:u32=t1003;
var t1007:R_Parameter;if(t1006<a2[0u]){
t1007=R_Parameter(a2[1u+(t1006)*6u+0u],a2[1u+(t1006)*6u+1u],a2[1u+(t1006)*6u+2u],a2[1u+(t1006)*6u+3u],a2[1u+(t1006)*6u+4u],a2[1u+(t1006)*6u+5u]);}else{
var t1008:u32=0u;
var t1009:u32=0u;
var t1010:u32=0u;
var t1011:u32=1065353216u;
var t1012:u32=1065353216u;
var t1013:u32=0u;
t1007=R_Parameter(t1008,t1009,t1010,t1011,t1012,t1013);}
t1005=(t1007).ink_f_value;
}
var t1014:u32=t1005;
var t1015:u32=t998;
var t1016:u32;if(t1015<6u){
t1016=t9[t1015];}else{
t1016=0u;}
t997=ink_f32_add(t999,ink_f32_mul(t1014,t1016));
}
var t1017:u32=t997;
var t1018:u32=t1017;
var t1019:u32;
if (ink_f32_lt(0u,t1018)) {
var t1020:u32=t978;
t1019=ink_f32_mul(t1020,t1017);
} else {
t1019=0u;
}
t534[5u]=t1019;
var t1021:array<u32,4>;
var t1022:u32=t3;
var t1023:u32=t4;
var t1024:u32=216u;
var t1025:u32=t1022;
var t1026:u32=t1023;
var t1027:u32=t1024;
var t1028:u32=(t1027 + 6u);
var t1029:u32=t1026;
var t1030:u32;
if ((t1029 == t1028)) {
t1030=t1025;
} else {
var t1031:u32=t1028;
var t1032:R_Parameter;if(t1031<a2[0u]){
t1032=R_Parameter(a2[1u+(t1031)*6u+0u],a2[1u+(t1031)*6u+1u],a2[1u+(t1031)*6u+2u],a2[1u+(t1031)*6u+3u],a2[1u+(t1031)*6u+4u],a2[1u+(t1031)*6u+5u]);}else{
var t1033:u32=0u;
var t1034:u32=0u;
var t1035:u32=0u;
var t1036:u32=1065353216u;
var t1037:u32=1065353216u;
var t1038:u32=0u;
t1032=R_Parameter(t1033,t1034,t1035,t1036,t1037,t1038);}
t1030=(t1032).ink_f_value;
}
var t1039:u32=t1030;
var t1040:u32=t1039;
for(var t1041=0u;t1041<6u;t1041++){
var t1042:u32=t1040;
var t1043:u32=t1022;
var t1044:u32=t1023;
var t1045:u32=t1024;
var t1046:u32=(t1045 + t1041);
var t1047:u32=t1044;
var t1048:u32;
if ((t1047 == t1046)) {
t1048=t1043;
} else {
var t1049:u32=t1046;
var t1050:R_Parameter;if(t1049<a2[0u]){
t1050=R_Parameter(a2[1u+(t1049)*6u+0u],a2[1u+(t1049)*6u+1u],a2[1u+(t1049)*6u+2u],a2[1u+(t1049)*6u+3u],a2[1u+(t1049)*6u+4u],a2[1u+(t1049)*6u+5u]);}else{
var t1051:u32=0u;
var t1052:u32=0u;
var t1053:u32=0u;
var t1054:u32=1065353216u;
var t1055:u32=1065353216u;
var t1056:u32=0u;
t1050=R_Parameter(t1051,t1052,t1053,t1054,t1055,t1056);}
t1048=(t1050).ink_f_value;
}
var t1057:u32=t1048;
var t1058:u32=t1041;
var t1059:u32;if(t1058<6u){
t1059=t534[t1058];}else{
t1059=0u;}
t1040=ink_f32_add(t1042,ink_f32_mul(t1057,t1059));
}
t1021[0u]=t1040;
var t1060:u32=t3;
var t1061:u32=t4;
var t1062:u32=223u;
var t1063:u32=t1060;
var t1064:u32=t1061;
var t1065:u32=t1062;
var t1066:u32=(t1065 + 6u);
var t1067:u32=t1064;
var t1068:u32;
if ((t1067 == t1066)) {
t1068=t1063;
} else {
var t1069:u32=t1066;
var t1070:R_Parameter;if(t1069<a2[0u]){
t1070=R_Parameter(a2[1u+(t1069)*6u+0u],a2[1u+(t1069)*6u+1u],a2[1u+(t1069)*6u+2u],a2[1u+(t1069)*6u+3u],a2[1u+(t1069)*6u+4u],a2[1u+(t1069)*6u+5u]);}else{
var t1071:u32=0u;
var t1072:u32=0u;
var t1073:u32=0u;
var t1074:u32=1065353216u;
var t1075:u32=1065353216u;
var t1076:u32=0u;
t1070=R_Parameter(t1071,t1072,t1073,t1074,t1075,t1076);}
t1068=(t1070).ink_f_value;
}
var t1077:u32=t1068;
var t1078:u32=t1077;
for(var t1079=0u;t1079<6u;t1079++){
var t1080:u32=t1078;
var t1081:u32=t1060;
var t1082:u32=t1061;
var t1083:u32=t1062;
var t1084:u32=(t1083 + t1079);
var t1085:u32=t1082;
var t1086:u32;
if ((t1085 == t1084)) {
t1086=t1081;
} else {
var t1087:u32=t1084;
var t1088:R_Parameter;if(t1087<a2[0u]){
t1088=R_Parameter(a2[1u+(t1087)*6u+0u],a2[1u+(t1087)*6u+1u],a2[1u+(t1087)*6u+2u],a2[1u+(t1087)*6u+3u],a2[1u+(t1087)*6u+4u],a2[1u+(t1087)*6u+5u]);}else{
var t1089:u32=0u;
var t1090:u32=0u;
var t1091:u32=0u;
var t1092:u32=1065353216u;
var t1093:u32=1065353216u;
var t1094:u32=0u;
t1088=R_Parameter(t1089,t1090,t1091,t1092,t1093,t1094);}
t1086=(t1088).ink_f_value;
}
var t1095:u32=t1086;
var t1096:u32=t1079;
var t1097:u32;if(t1096<6u){
t1097=t534[t1096];}else{
t1097=0u;}
t1078=ink_f32_add(t1080,ink_f32_mul(t1095,t1097));
}
t1021[1u]=t1078;
var t1098:u32=t3;
var t1099:u32=t4;
var t1100:u32=230u;
var t1101:u32=t1098;
var t1102:u32=t1099;
var t1103:u32=t1100;
var t1104:u32=(t1103 + 6u);
var t1105:u32=t1102;
var t1106:u32;
if ((t1105 == t1104)) {
t1106=t1101;
} else {
var t1107:u32=t1104;
var t1108:R_Parameter;if(t1107<a2[0u]){
t1108=R_Parameter(a2[1u+(t1107)*6u+0u],a2[1u+(t1107)*6u+1u],a2[1u+(t1107)*6u+2u],a2[1u+(t1107)*6u+3u],a2[1u+(t1107)*6u+4u],a2[1u+(t1107)*6u+5u]);}else{
var t1109:u32=0u;
var t1110:u32=0u;
var t1111:u32=0u;
var t1112:u32=1065353216u;
var t1113:u32=1065353216u;
var t1114:u32=0u;
t1108=R_Parameter(t1109,t1110,t1111,t1112,t1113,t1114);}
t1106=(t1108).ink_f_value;
}
var t1115:u32=t1106;
var t1116:u32=t1115;
for(var t1117=0u;t1117<6u;t1117++){
var t1118:u32=t1116;
var t1119:u32=t1098;
var t1120:u32=t1099;
var t1121:u32=t1100;
var t1122:u32=(t1121 + t1117);
var t1123:u32=t1120;
var t1124:u32;
if ((t1123 == t1122)) {
t1124=t1119;
} else {
var t1125:u32=t1122;
var t1126:R_Parameter;if(t1125<a2[0u]){
t1126=R_Parameter(a2[1u+(t1125)*6u+0u],a2[1u+(t1125)*6u+1u],a2[1u+(t1125)*6u+2u],a2[1u+(t1125)*6u+3u],a2[1u+(t1125)*6u+4u],a2[1u+(t1125)*6u+5u]);}else{
var t1127:u32=0u;
var t1128:u32=0u;
var t1129:u32=0u;
var t1130:u32=1065353216u;
var t1131:u32=1065353216u;
var t1132:u32=0u;
t1126=R_Parameter(t1127,t1128,t1129,t1130,t1131,t1132);}
t1124=(t1126).ink_f_value;
}
var t1133:u32=t1124;
var t1134:u32=t1117;
var t1135:u32;if(t1134<6u){
t1135=t534[t1134];}else{
t1135=0u;}
t1116=ink_f32_add(t1118,ink_f32_mul(t1133,t1135));
}
t1021[2u]=t1116;
var t1136:u32=t3;
var t1137:u32=t4;
var t1138:u32=237u;
var t1139:u32=t1136;
var t1140:u32=t1137;
var t1141:u32=t1138;
var t1142:u32=(t1141 + 6u);
var t1143:u32=t1140;
var t1144:u32;
if ((t1143 == t1142)) {
t1144=t1139;
} else {
var t1145:u32=t1142;
var t1146:R_Parameter;if(t1145<a2[0u]){
t1146=R_Parameter(a2[1u+(t1145)*6u+0u],a2[1u+(t1145)*6u+1u],a2[1u+(t1145)*6u+2u],a2[1u+(t1145)*6u+3u],a2[1u+(t1145)*6u+4u],a2[1u+(t1145)*6u+5u]);}else{
var t1147:u32=0u;
var t1148:u32=0u;
var t1149:u32=0u;
var t1150:u32=1065353216u;
var t1151:u32=1065353216u;
var t1152:u32=0u;
t1146=R_Parameter(t1147,t1148,t1149,t1150,t1151,t1152);}
t1144=(t1146).ink_f_value;
}
var t1153:u32=t1144;
var t1154:u32=t1153;
for(var t1155=0u;t1155<6u;t1155++){
var t1156:u32=t1154;
var t1157:u32=t1136;
var t1158:u32=t1137;
var t1159:u32=t1138;
var t1160:u32=(t1159 + t1155);
var t1161:u32=t1158;
var t1162:u32;
if ((t1161 == t1160)) {
t1162=t1157;
} else {
var t1163:u32=t1160;
var t1164:R_Parameter;if(t1163<a2[0u]){
t1164=R_Parameter(a2[1u+(t1163)*6u+0u],a2[1u+(t1163)*6u+1u],a2[1u+(t1163)*6u+2u],a2[1u+(t1163)*6u+3u],a2[1u+(t1163)*6u+4u],a2[1u+(t1163)*6u+5u]);}else{
var t1165:u32=0u;
var t1166:u32=0u;
var t1167:u32=0u;
var t1168:u32=1065353216u;
var t1169:u32=1065353216u;
var t1170:u32=0u;
t1164=R_Parameter(t1165,t1166,t1167,t1168,t1169,t1170);}
t1162=(t1164).ink_f_value;
}
var t1171:u32=t1162;
var t1172:u32=t1155;
var t1173:u32;if(t1172<6u){
t1173=t534[t1172];}else{
t1173=0u;}
t1154=ink_f32_add(t1156,ink_f32_mul(t1171,t1173));
}
t1021[3u]=t1154;
var t1174:u32=0u;
for(var t1175=0u;t1175<4u;t1175++){
var t1176:u32=t1174;
var t1177:u32=t1175;
var t1178:u32;if(t1177<4u){
t1178=t1021[t1177];}else{
t1178=0u;}
var t1179:u32=t1178;
var t1180:u32=t2;
var t1181:u32=(t1180 * 4u);
var t1182:u32=(t1181 + t1175);
var t1183:u32;if(t1182<a3[0u]){
t1183=a3[1u+(t1182)*1u+0u];}else{
t1183=0u;}
var t1184:u32=t1183;
var t1185:u32=t1179;
var t1186:u32=ink_f32_sub(t1185,t1184);
var t1187:u32=t1186;
t1174=ink_f32_add(t1176,ink_f32_mul(t1187,t1186));
}
var t1188:u32=t1174;
var t1189:u32=ink_f32_div(t1188,1082130432u);
output[1u+i*1u+0u]=bitcast<u32>(t1189);


}
}