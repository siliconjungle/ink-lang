// Exact wrapping u64 over two storage lanes. No floating point intermediates.
struct InkU64 {lo:u32,hi:u32,}
struct InkDiv64 {quotient:InkU64,remainder:InkU64,}
fn ink_u64_shl(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64(a.lo<<k,(a.hi<<k)|(a.lo>>(32u-k)));}return InkU64(0u,a.lo<<(k-32u));}
fn ink_u64_shr(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64((a.lo>>k)|(a.hi<<(32u-k)),a.hi>>k);}return InkU64(a.hi>>(k-32u),0u);}
fn ink_u64_rol(a:InkU64,count:u32)->InkU64{let k=count&63u;let l=ink_u64_shl(a,k);let r=ink_u64_shr(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_ror(a:InkU64,count:u32)->InkU64{let k=count&63u;let r=ink_u64_shr(a,k);let l=ink_u64_shl(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_eq(a:InkU64,b:InkU64)->bool{return a.lo==b.lo&&a.hi==b.hi;}
fn ink_u64_lt(a:InkU64,b:InkU64)->bool{return a.hi<b.hi||(a.hi==b.hi&&a.lo<b.lo);}
fn ink_u64_add(a:InkU64,b:InkU64)->InkU64{let lo=a.lo+b.lo;return InkU64(lo,a.hi+b.hi+select(0u,1u,lo<a.lo));}
fn ink_u64_sub(a:InkU64,b:InkU64)->InkU64{return InkU64(a.lo-b.lo,a.hi-b.hi-select(0u,1u,a.lo<b.lo));}
fn ink_u64_mul(a:InkU64,b:InkU64)->InkU64{let al=a.lo&65535u;let ah=a.lo>>16u;let bl=b.lo&65535u;let bh=b.lo>>16u;let p=al*bl;let x=ah*bl;let y=al*bh;let mid=(p>>16u)+(x&65535u)+(y&65535u);let high=ah*bh+(x>>16u)+(y>>16u)+(mid>>16u);return InkU64((mid<<16u)|(p&65535u),high+a.lo*b.hi+a.hi*b.lo);}
fn ink_u64_div(a:InkU64,b:InkU64)->InkDiv64{var q=InkU64(0u,0u);var r=InkU64(0u,0u);var cursor=64u;loop{if(cursor==0u){break;}cursor--;var bit=0u;if(cursor>=32u){bit=(a.hi>>(cursor-32u))&1u;}else{bit=(a.lo>>cursor)&1u;}let overflow=r.hi>>31u;r=InkU64((r.lo<<1u)|bit,(r.hi<<1u)|(r.lo>>31u));if(overflow!=0u||!ink_u64_lt(r,b)){r=ink_u64_sub(r,b);if(cursor>=32u){q.hi|=1u<<(cursor-32u);}else{q.lo|=1u<<cursor;}}}return InkDiv64(q,r);}
// Binary32 evaluated with integer lanes: round-to-nearest, ties-to-even,
// gradual underflow, signed zero and canonical arithmetic NaN.
fn ink_f32_nan(x:u32)->bool{return (x&0x7fffffffu)>0x7f800000u;}
fn ink_f32_eq(a:u32,b:u32)->bool{return !ink_f32_nan(a)&&!ink_f32_nan(b)&&(a==b||((a|b)&0x7fffffffu)==0u);}
fn ink_f32_lt(a:u32,b:u32)->bool{
 if(ink_f32_nan(a)||ink_f32_nan(b)||ink_f32_eq(a,b)){return false;}
 if((a^b)&0x80000000u)!=0u{return (a&0x80000000u)!=0u;}
 if((a&0x80000000u)!=0u){return a>b;}return a<b;
}
fn ink_f32_jam(x:u32,n:u32)->u32{if(n==0u){return x;}if(n>=32u){return select(0u,1u,x!=0u);}return (x>>n)|select(0u,1u,(x&((1u<<n)-1u))!=0u);}
fn ink_f32_round(sign:u32,exponent:i32,extended:u32)->u32{
 var e=exponent;var s=extended;
 if(e<1i){s=ink_f32_jam(s,u32(1i-e));e=1i;}
 let tail=s&7u;var sig=s>>3u;
 if(tail>4u||(tail==4u&&(sig&1u)!=0u)){sig++;}
 if(sig>=0x1000000u){sig>>=1u;e++;}
 if(e>=255i){return sign|0x7f800000u;}
 if(sig==0u){return sign;}
 let raw=select(u32(e),0u,e==1i&&sig<0x800000u);
 return sign|(raw<<23u)|(sig&0x7fffffu);
}
fn ink_f32_add(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 var x=a;var y=b;if((x&0x7fffffffu)<(y&0x7fffffffu)){x=b;y=a;}
 let ax=x&0x7fffffffu;let ay=y&0x7fffffffu;let sign=x&0x80000000u;
 if(ax==0x7f800000u){if(ay==ax&&((x^y)&0x80000000u)!=0u){return 0x7fc00000u;}return x;}
 let rx=(x>>23u)&255u;let ry=(y>>23u)&255u;var e=i32(max(rx,1u));
 var sx=((x&0x7fffffu)|select(0u,0x800000u,rx!=0u))<<3u;
 let sy=ink_f32_jam(((y&0x7fffffu)|select(0u,0x800000u,ry!=0u))<<3u,u32(e)-max(ry,1u));
 if(((x^y)&0x80000000u)==0u){sx+=sy;if(sx>=0x8000000u){sx=ink_f32_jam(sx,1u);e++;}}
 else{sx-=sy;if(sx==0u){return 0u;}loop{if(sx>=0x4000000u||e<=1i){break;}sx<<=1u;e--;}}
 return ink_f32_round(sign,e,sx);
}
fn ink_f32_sub(a:u32,b:u32)->u32{return ink_f32_add(a,b^0x80000000u);}
fn ink_f32_mul(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(aa==0x7f800000u||bb==0x7f800000u){if(aa==0u||bb==0u){return 0x7fc00000u;}return sign|0x7f800000u;}
 if(aa==0u||bb==0u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u));var eb=i32(max(rb,1u));
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 let product=ink_u64_mul(InkU64(sa,0u),InkU64(sb,0u));let high=(product.hi&0x8000u)!=0u;
 let shift=select(20u,21u,high);let extended=(product.lo>>shift)|(product.hi<<(32u-shift))|select(0u,1u,(product.lo&((1u<<shift)-1u))!=0u);
 return ink_f32_round(sign,ea+eb-127i+select(0i,1i,high),extended);
}
// Exact sqrt and division use integer significands, independent of WGSL float
// approximation allowances and device flush-to-zero behavior.
fn ink_f32_sqrt(x:u32)->u32{
 let a=x&0x7fffffffu;if(a==0u){return x;}
 if(a>0x7f800000u||(x&0x80000000u)!=0u){return 0x7fc00000u;}
 if(a==0x7f800000u){return x;}
 let raw=(x>>23u)&255u;var m=(x&0x7fffffu)|select(0u,0x800000u,raw!=0u);var e=i32(max(raw,1u))-127i;
 loop{if(m>=0x800000u){break;}m<<=1u;e--;}
 let odd=e&1i;var half=(e-odd)/2i;let shift=23u+u32(odd);
 let n=InkU64(m<<shift,m>>(32u-shift));var lo=0u;var hi=0x1000000u;
 loop{if(lo+1u>=hi){break;}let mid=(lo+hi)>>1u;let sq=ink_u64_mul(InkU64(mid,0u),InkU64(mid,0u));if(!ink_u64_lt(n,sq)){lo=mid;}else{hi=mid;}}
 let sq=ink_u64_mul(InkU64(lo,0u),InkU64(lo,0u));let rem=ink_u64_sub(n,sq);
 if(ink_u64_lt(InkU64(lo,0u),rem)){lo++;}
 if(lo==0x1000000u){lo>>=1u;half++;}
 return (u32(half+127i)<<23u)|(lo&0x7fffffu);
}
fn ink_f32_div(a:u32,b:u32)->u32{
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(ink_f32_nan(a)||ink_f32_nan(b)||(aa==0u&&bb==0u)||(aa==0x7f800000u&&bb==aa)){return 0x7fc00000u;}
 if(aa==0x7f800000u||bb==0u){return sign|0x7f800000u;}
 if(aa==0u||bb==0x7f800000u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u))-127i;var eb=i32(max(rb,1u))-127i;
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 var e=ea-eb;if(sa<sb){sa<<=1u;e--;}
 let division=ink_u64_div(InkU64(sa<<26u,sa>>6u),InkU64(sb,0u));
 let extended=division.quotient.lo|select(0u,1u,!ink_u64_eq(division.remainder,InkU64(0u,0u)));
 return ink_f32_round(sign,e+127i,extended);
}
// mode: 0 trunc, 1 floor, 2 ceil, 3 ties-to-even.
fn ink_f32_integral(x:u32,mode:u32)->u32{
 let a=x&0x7fffffffu;let sign=x&0x80000000u;
 if(a>0x7f800000u){return 0x7fc00000u;}if(a>=0x4b000000u||a==0u){return x;}
 let e=i32((x>>23u)&255u)-127i;
 if(e<0i){var up=false;if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){up=a>0x3f000000u;}return sign|select(0u,0x3f800000u,up);}
 let shift=u32(23i-e);let mask=(1u<<shift)-1u;let fraction=a&mask;var rounded=a&~mask;var up=false;
 if(fraction!=0u){if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){let half=1u<<(shift-1u);up=fraction>half||(fraction==half&&((rounded>>shift)&1u)!=0u);}}
 if(up){rounded+=1u<<shift;}return sign|rounded;
}
fn ink_f32_from_u64(x:InkU64)->u32{
 if(ink_u64_eq(x,InkU64(0u,0u))){return 0u;}
 let leading=select(countLeadingZeros(x.lo)+32u,countLeadingZeros(x.hi),x.hi!=0u);let e=63u-leading;
 if(e<=23u){return ((e+127u)<<23u)|((x.lo<<(23u-e))&0x7fffffu);}
 let shift=e-23u;var sig=0u;var rem=InkU64(0u,0u);var half=InkU64(0u,0u);
 if(shift<32u){sig=(x.lo>>shift)|(x.hi<<(32u-shift));rem=InkU64(x.lo&((1u<<shift)-1u),0u);half=InkU64(1u<<(shift-1u),0u);}
 else if(shift==32u){sig=x.hi;rem=InkU64(x.lo,0u);half=InkU64(0x80000000u,0u);}
 else{sig=x.hi>>(shift-32u);rem=InkU64(x.lo,x.hi&((1u<<(shift-32u))-1u));half=InkU64(0u,1u<<(shift-33u));}
 if(ink_u64_lt(half,rem)||(ink_u64_eq(rem,half)&&(sig&1u)!=0u)){sig++;}
 var exponent=e+127u;if(sig==0x1000000u){sig>>=1u;exponent++;}
 return (exponent<<23u)|(sig&0x7fffffu);
}
fn ink_f32_from_i32(x:i32)->u32{let neg=x<0i;let magnitude=select(u32(x),0u-u32(x),neg);return ink_f32_from_u64(InkU64(magnitude,0u))|select(0u,0x80000000u,neg);}
struct InkBuffer_u32{data:array<u32,64>,length:u32,}
struct InkBuffer_InkU64{data:array<InkU64,64>,length:u32,}
struct InkBuffer_i32{data:array<i32,64>,length:u32,}
struct InkBuffer_bool{data:array<bool,64>,length:u32,}
struct R_Config{ink_f_rate:u32,ink_f_first_decay:u32,ink_f_second_decay:u32,ink_f_epsilon:u32,}
struct R_Parameter{ink_f_value:u32,ink_f_first:u32,ink_f_second:u32,ink_f_first_power:u32,ink_f_second_power:u32,ink_f_steps:u32,}
struct R___ink_differential_0{ink_f_value:u32,ink_f_tangent:u32,}
struct R___ink_differential_3{ink_f_value:R___ink_differential_0,ink_f_first:R___ink_differential_0,ink_f_second:R___ink_differential_0,ink_f_first_power:R___ink_differential_0,ink_f_second_power:R___ink_differential_0,ink_f_steps:u32,}
@group(0) @binding(0) var<storage,read> a0:array<u32>;
@group(0) @binding(1) var<storage,read> a1:array<u32>;
@group(0) @binding(2) var<storage,read> a2:array<u32>;
@group(0) @binding(3) var<storage,read> a3:array<u32>;
@group(0) @binding(4) var<storage,read_write> output:array<u32>;
@group(0) @binding(5) var<storage,read> ink_meta:array<u32>;
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=ink_meta[4]){return;}
var t0:bool=(a2[0u+(0u)*1u+0u]!=0u);
var t1:bool=(t0 == false);
var t2:bool=t1;
if (!t2) {
var t3:R_Config=R_Config(a3[0u+(0u)*4u+0u],a3[0u+(0u)*4u+1u],a3[0u+(0u)*4u+2u],a3[0u+(0u)*4u+3u]);
var t4:bool=(((t3).ink_f_rate)&0x7fffffffu)<0x7f800000u;
var t5:bool=t4;
if (t5) {
var t6:u32=(t3).ink_f_rate;
t5=ink_f32_lt(0u,t6);
}
var t7:bool=t5;
var t8:bool=t7;
if (t8) {
var t9:u32=(t3).ink_f_first_decay;
t8=(ink_f32_lt(0u,t9)||ink_f32_eq(t9,0u));
}
var t10:bool=t8;
var t11:bool=t10;
if (t11) {
var t12:u32=(t3).ink_f_first_decay;
t11=ink_f32_lt(t12,1065353216u);
}
var t13:bool=t11;
var t14:bool=t13;
if (t14) {
var t15:u32=(t3).ink_f_second_decay;
t14=(ink_f32_lt(0u,t15)||ink_f32_eq(t15,0u));
}
var t16:bool=t14;
var t17:bool=t16;
if (t17) {
var t18:u32=(t3).ink_f_second_decay;
t17=ink_f32_lt(t18,1065353216u);
}
var t19:bool=t17;
var t20:bool=t19;
if (t20) {
t20=(((t3).ink_f_epsilon)&0x7fffffffu)<0x7f800000u;
}
var t21:bool=t20;
var t22:bool=t21;
if (t22) {
var t23:u32=(t3).ink_f_epsilon;
t22=ink_f32_lt(0u,t23);
}
var t24:bool=t22;
t2=(t24 == false);
}
var t25:bool=t2;
var t26:bool=t25;
if (!t26) {
var t27:u32=a1[0u];
t26=(t27 != a0[0u]);
}
var t28:bool=t26;
var t29:bool=t28;
if (!t29) {
var t30:bool=true;
for(var t31=0u;t31<a0[0u];t31++){
var t32:R_Parameter=R_Parameter(a0[1u+(t31)*6u+0u],a0[1u+(t31)*6u+1u],a0[1u+(t31)*6u+2u],a0[1u+(t31)*6u+3u],a0[1u+(t31)*6u+4u],a0[1u+(t31)*6u+5u]);
var t33:bool=t30;
var t34:bool=t33;
var t35:bool=t34;
if (t35) {
var t36:R_Parameter=t32;
var t37:bool=(((t36).ink_f_value)&0x7fffffffu)<0x7f800000u;
var t38:bool=t37;
if (t38) {
t38=(((t36).ink_f_first)&0x7fffffffu)<0x7f800000u;
}
var t39:bool=t38;
var t40:bool=t39;
if (t40) {
t40=(((t36).ink_f_second)&0x7fffffffu)<0x7f800000u;
}
var t41:bool=t40;
var t42:bool=t41;
if (t42) {
var t43:u32=(t36).ink_f_second;
t42=(ink_f32_lt(0u,t43)||ink_f32_eq(t43,0u));
}
var t44:bool=t42;
var t45:bool=t44;
if (t45) {
var t46:u32=(t36).ink_f_first_power;
t45=(ink_f32_lt(0u,t46)||ink_f32_eq(t46,0u));
}
var t47:bool=t45;
var t48:bool=t47;
if (t48) {
var t49:u32=(t36).ink_f_first_power;
t48=(ink_f32_lt(t49,1065353216u)||ink_f32_eq(t49,1065353216u));
}
var t50:bool=t48;
var t51:bool=t50;
if (t51) {
var t52:u32=(t36).ink_f_second_power;
t51=(ink_f32_lt(0u,t52)||ink_f32_eq(t52,0u));
}
var t53:bool=t51;
var t54:bool=t53;
if (t54) {
var t55:u32=(t36).ink_f_second_power;
t54=(ink_f32_lt(t55,1065353216u)||ink_f32_eq(t55,1065353216u));
}
var t56:bool=t54;
var t57:bool=t56;
if (t57) {
var t58:u32=(t36).ink_f_steps;
t57=(t58 < 4294967295u);
}
t35=t57;
}
t30=t35;}
var t59:bool=t30;
t29=(t59 == false);
}
var t60:u32;if(t29){
t60=a0[0u];}else{
var t61:bool=true;
for(var t62=0u;t62<a0[0u];t62++){
var t63:u32=t62;
var t64:R_Parameter=R_Parameter(a0[1u+(t62)*6u+0u],a0[1u+(t62)*6u+1u],a0[1u+(t62)*6u+2u],a0[1u+(t62)*6u+3u],a0[1u+(t62)*6u+4u],a0[1u+(t62)*6u+5u]);
var t65:R_Parameter=t64;
var t66:u32=t63;
var t67:u32;if(t66<a1[0u]){
t67=a1[1u+(t66)*1u+0u];}else{
t67=0u;}
var t68:u32=t67;
var t69:R_Config=R_Config(a3[0u+(0u)*4u+0u],a3[0u+(0u)*4u+1u],a3[0u+(0u)*4u+2u],a3[0u+(0u)*4u+3u]);
var t70:u32=(t65).ink_f_first_power;
var t71:u32=ink_f32_mul(t70,(t69).ink_f_first_decay);
var t72:u32=(t65).ink_f_second_power;
var t73:u32=ink_f32_mul(t72,(t69).ink_f_second_decay);
var t74:u32=(t69).ink_f_first_decay;
var t75:u32=ink_f32_mul(t74,(t65).ink_f_first);
var t76:u32=1065353216u;
var t77:u32=ink_f32_sub(t76,(t69).ink_f_first_decay);
var t78:u32=ink_f32_add(t75,ink_f32_mul(t77,t68));
var t79:u32=(t69).ink_f_second_decay;
var t80:u32=ink_f32_mul(t79,(t65).ink_f_second);
var t81:u32=1065353216u;
var t82:u32=ink_f32_sub(t81,(t69).ink_f_second_decay);
var t83:u32=ink_f32_mul(t82,t68);
var t84:u32=ink_f32_add(t80,ink_f32_mul(t83,t68));
var t85:u32=(t65).ink_f_value;
var t86:u32=(t69).ink_f_rate;
var t87:u32=1065353216u;
var t88:u32=1065353216u;
var t89:u32=ink_f32_sqrt(ink_f32_div(t84,ink_f32_sub(t88,t73)));
var t90:u32=ink_f32_sub(t85,ink_f32_div(ink_f32_mul(t86,ink_f32_div(t78,ink_f32_sub(t87,t71))),ink_f32_add(t89,(t69).ink_f_epsilon)));
var t91:u32=t90;
var t92:u32=t78;
var t93:u32=t84;
var t94:u32=t71;
var t95:u32=t73;
var t96:u32=(t65).ink_f_steps;
var t97:u32=(t96 + 1u);
var t98:R_Parameter=R_Parameter(t91,t92,t93,t94,t95,t97);
var t99:bool=t61;
var t100:bool=t99;
var t101:bool=t100;
if (t101) {
var t102:R_Parameter=t98;
var t103:bool=(((t102).ink_f_value)&0x7fffffffu)<0x7f800000u;
var t104:bool=t103;
if (t104) {
t104=(((t102).ink_f_first)&0x7fffffffu)<0x7f800000u;
}
var t105:bool=t104;
var t106:bool=t105;
if (t106) {
t106=(((t102).ink_f_second)&0x7fffffffu)<0x7f800000u;
}
var t107:bool=t106;
var t108:bool=t107;
if (t108) {
var t109:u32=(t102).ink_f_second;
t108=(ink_f32_lt(0u,t109)||ink_f32_eq(t109,0u));
}
var t110:bool=t108;
var t111:bool=t110;
if (t111) {
var t112:u32=(t102).ink_f_first_power;
t111=(ink_f32_lt(0u,t112)||ink_f32_eq(t112,0u));
}
var t113:bool=t111;
var t114:bool=t113;
if (t114) {
var t115:u32=(t102).ink_f_first_power;
t114=(ink_f32_lt(t115,1065353216u)||ink_f32_eq(t115,1065353216u));
}
var t116:bool=t114;
var t117:bool=t116;
if (t117) {
var t118:u32=(t102).ink_f_second_power;
t117=(ink_f32_lt(0u,t118)||ink_f32_eq(t118,0u));
}
var t119:bool=t117;
var t120:bool=t119;
if (t120) {
var t121:u32=(t102).ink_f_second_power;
t120=(ink_f32_lt(t121,1065353216u)||ink_f32_eq(t121,1065353216u));
}
var t122:bool=t120;
var t123:bool=t122;
if (t123) {
var t124:u32=(t102).ink_f_steps;
t123=(t124 < 4294967295u);
}
t101=t123;
}
t61=t101;}
var t125:u32;if(t61){
t125=a0[0u];}else{
t125=a0[0u];}
t60=t125;}
if(i==0u){output[0u]=t60;}if(i>=t60){return;}
var t126:bool=(a2[0u+(0u)*1u+0u]!=0u);
var t127:bool=(t126 == false);
var t128:bool=t127;
if (!t128) {
var t129:R_Config=R_Config(a3[0u+(0u)*4u+0u],a3[0u+(0u)*4u+1u],a3[0u+(0u)*4u+2u],a3[0u+(0u)*4u+3u]);
var t130:bool=(((t129).ink_f_rate)&0x7fffffffu)<0x7f800000u;
var t131:bool=t130;
if (t131) {
var t132:u32=(t129).ink_f_rate;
t131=ink_f32_lt(0u,t132);
}
var t133:bool=t131;
var t134:bool=t133;
if (t134) {
var t135:u32=(t129).ink_f_first_decay;
t134=(ink_f32_lt(0u,t135)||ink_f32_eq(t135,0u));
}
var t136:bool=t134;
var t137:bool=t136;
if (t137) {
var t138:u32=(t129).ink_f_first_decay;
t137=ink_f32_lt(t138,1065353216u);
}
var t139:bool=t137;
var t140:bool=t139;
if (t140) {
var t141:u32=(t129).ink_f_second_decay;
t140=(ink_f32_lt(0u,t141)||ink_f32_eq(t141,0u));
}
var t142:bool=t140;
var t143:bool=t142;
if (t143) {
var t144:u32=(t129).ink_f_second_decay;
t143=ink_f32_lt(t144,1065353216u);
}
var t145:bool=t143;
var t146:bool=t145;
if (t146) {
t146=(((t129).ink_f_epsilon)&0x7fffffffu)<0x7f800000u;
}
var t147:bool=t146;
var t148:bool=t147;
if (t148) {
var t149:u32=(t129).ink_f_epsilon;
t148=ink_f32_lt(0u,t149);
}
var t150:bool=t148;
t128=(t150 == false);
}
var t151:bool=t128;
var t152:bool=t151;
if (!t152) {
var t153:u32=a1[0u];
t152=(t153 != a0[0u]);
}
var t154:bool=t152;
var t155:bool=t154;
if (!t155) {
var t156:bool=true;
for(var t157=0u;t157<a0[0u];t157++){
var t158:R_Parameter=R_Parameter(a0[1u+(t157)*6u+0u],a0[1u+(t157)*6u+1u],a0[1u+(t157)*6u+2u],a0[1u+(t157)*6u+3u],a0[1u+(t157)*6u+4u],a0[1u+(t157)*6u+5u]);
var t159:bool=t156;
var t160:bool=t159;
var t161:bool=t160;
if (t161) {
var t162:R_Parameter=t158;
var t163:bool=(((t162).ink_f_value)&0x7fffffffu)<0x7f800000u;
var t164:bool=t163;
if (t164) {
t164=(((t162).ink_f_first)&0x7fffffffu)<0x7f800000u;
}
var t165:bool=t164;
var t166:bool=t165;
if (t166) {
t166=(((t162).ink_f_second)&0x7fffffffu)<0x7f800000u;
}
var t167:bool=t166;
var t168:bool=t167;
if (t168) {
var t169:u32=(t162).ink_f_second;
t168=(ink_f32_lt(0u,t169)||ink_f32_eq(t169,0u));
}
var t170:bool=t168;
var t171:bool=t170;
if (t171) {
var t172:u32=(t162).ink_f_first_power;
t171=(ink_f32_lt(0u,t172)||ink_f32_eq(t172,0u));
}
var t173:bool=t171;
var t174:bool=t173;
if (t174) {
var t175:u32=(t162).ink_f_first_power;
t174=(ink_f32_lt(t175,1065353216u)||ink_f32_eq(t175,1065353216u));
}
var t176:bool=t174;
var t177:bool=t176;
if (t177) {
var t178:u32=(t162).ink_f_second_power;
t177=(ink_f32_lt(0u,t178)||ink_f32_eq(t178,0u));
}
var t179:bool=t177;
var t180:bool=t179;
if (t180) {
var t181:u32=(t162).ink_f_second_power;
t180=(ink_f32_lt(t181,1065353216u)||ink_f32_eq(t181,1065353216u));
}
var t182:bool=t180;
var t183:bool=t182;
if (t183) {
var t184:u32=(t162).ink_f_steps;
t183=(t184 < 4294967295u);
}
t161=t183;
}
t156=t161;}
var t185:bool=t156;
t155=(t185 == false);
}
var t186:R_Parameter;if(t155){
t186=R_Parameter(a0[1u+(i)*6u+0u],a0[1u+(i)*6u+1u],a0[1u+(i)*6u+2u],a0[1u+(i)*6u+3u],a0[1u+(i)*6u+4u],a0[1u+(i)*6u+5u]);}else{
var t187:bool=true;
for(var t188=0u;t188<a0[0u];t188++){
var t189:u32=t188;
var t190:R_Parameter=R_Parameter(a0[1u+(t188)*6u+0u],a0[1u+(t188)*6u+1u],a0[1u+(t188)*6u+2u],a0[1u+(t188)*6u+3u],a0[1u+(t188)*6u+4u],a0[1u+(t188)*6u+5u]);
var t191:R_Parameter=t190;
var t192:u32=t189;
var t193:u32;if(t192<a1[0u]){
t193=a1[1u+(t192)*1u+0u];}else{
t193=0u;}
var t194:u32=t193;
var t195:R_Config=R_Config(a3[0u+(0u)*4u+0u],a3[0u+(0u)*4u+1u],a3[0u+(0u)*4u+2u],a3[0u+(0u)*4u+3u]);
var t196:u32=(t191).ink_f_first_power;
var t197:u32=ink_f32_mul(t196,(t195).ink_f_first_decay);
var t198:u32=(t191).ink_f_second_power;
var t199:u32=ink_f32_mul(t198,(t195).ink_f_second_decay);
var t200:u32=(t195).ink_f_first_decay;
var t201:u32=ink_f32_mul(t200,(t191).ink_f_first);
var t202:u32=1065353216u;
var t203:u32=ink_f32_sub(t202,(t195).ink_f_first_decay);
var t204:u32=ink_f32_add(t201,ink_f32_mul(t203,t194));
var t205:u32=(t195).ink_f_second_decay;
var t206:u32=ink_f32_mul(t205,(t191).ink_f_second);
var t207:u32=1065353216u;
var t208:u32=ink_f32_sub(t207,(t195).ink_f_second_decay);
var t209:u32=ink_f32_mul(t208,t194);
var t210:u32=ink_f32_add(t206,ink_f32_mul(t209,t194));
var t211:u32=(t191).ink_f_value;
var t212:u32=(t195).ink_f_rate;
var t213:u32=1065353216u;
var t214:u32=1065353216u;
var t215:u32=ink_f32_sqrt(ink_f32_div(t210,ink_f32_sub(t214,t199)));
var t216:u32=ink_f32_sub(t211,ink_f32_div(ink_f32_mul(t212,ink_f32_div(t204,ink_f32_sub(t213,t197))),ink_f32_add(t215,(t195).ink_f_epsilon)));
var t217:u32=t216;
var t218:u32=t204;
var t219:u32=t210;
var t220:u32=t197;
var t221:u32=t199;
var t222:u32=(t191).ink_f_steps;
var t223:u32=(t222 + 1u);
var t224:R_Parameter=R_Parameter(t217,t218,t219,t220,t221,t223);
var t225:bool=t187;
var t226:bool=t225;
var t227:bool=t226;
if (t227) {
var t228:R_Parameter=t224;
var t229:bool=(((t228).ink_f_value)&0x7fffffffu)<0x7f800000u;
var t230:bool=t229;
if (t230) {
t230=(((t228).ink_f_first)&0x7fffffffu)<0x7f800000u;
}
var t231:bool=t230;
var t232:bool=t231;
if (t232) {
t232=(((t228).ink_f_second)&0x7fffffffu)<0x7f800000u;
}
var t233:bool=t232;
var t234:bool=t233;
if (t234) {
var t235:u32=(t228).ink_f_second;
t234=(ink_f32_lt(0u,t235)||ink_f32_eq(t235,0u));
}
var t236:bool=t234;
var t237:bool=t236;
if (t237) {
var t238:u32=(t228).ink_f_first_power;
t237=(ink_f32_lt(0u,t238)||ink_f32_eq(t238,0u));
}
var t239:bool=t237;
var t240:bool=t239;
if (t240) {
var t241:u32=(t228).ink_f_first_power;
t240=(ink_f32_lt(t241,1065353216u)||ink_f32_eq(t241,1065353216u));
}
var t242:bool=t240;
var t243:bool=t242;
if (t243) {
var t244:u32=(t228).ink_f_second_power;
t243=(ink_f32_lt(0u,t244)||ink_f32_eq(t244,0u));
}
var t245:bool=t243;
var t246:bool=t245;
if (t246) {
var t247:u32=(t228).ink_f_second_power;
t246=(ink_f32_lt(t247,1065353216u)||ink_f32_eq(t247,1065353216u));
}
var t248:bool=t246;
var t249:bool=t248;
if (t249) {
var t250:u32=(t228).ink_f_steps;
t249=(t250 < 4294967295u);
}
t227=t249;
}
t187=t227;}
var t251:R_Parameter;if(t187){
var t252:u32=i;
var t253:R_Parameter=R_Parameter(a0[1u+(i)*6u+0u],a0[1u+(i)*6u+1u],a0[1u+(i)*6u+2u],a0[1u+(i)*6u+3u],a0[1u+(i)*6u+4u],a0[1u+(i)*6u+5u]);
var t254:R_Parameter=t253;
var t255:u32=t252;
var t256:u32;if(t255<a1[0u]){
t256=a1[1u+(t255)*1u+0u];}else{
t256=0u;}
var t257:u32=t256;
var t258:R_Config=R_Config(a3[0u+(0u)*4u+0u],a3[0u+(0u)*4u+1u],a3[0u+(0u)*4u+2u],a3[0u+(0u)*4u+3u]);
var t259:u32=(t254).ink_f_first_power;
var t260:u32=ink_f32_mul(t259,(t258).ink_f_first_decay);
var t261:u32=(t254).ink_f_second_power;
var t262:u32=ink_f32_mul(t261,(t258).ink_f_second_decay);
var t263:u32=(t258).ink_f_first_decay;
var t264:u32=ink_f32_mul(t263,(t254).ink_f_first);
var t265:u32=1065353216u;
var t266:u32=ink_f32_sub(t265,(t258).ink_f_first_decay);
var t267:u32=ink_f32_add(t264,ink_f32_mul(t266,t257));
var t268:u32=(t258).ink_f_second_decay;
var t269:u32=ink_f32_mul(t268,(t254).ink_f_second);
var t270:u32=1065353216u;
var t271:u32=ink_f32_sub(t270,(t258).ink_f_second_decay);
var t272:u32=ink_f32_mul(t271,t257);
var t273:u32=ink_f32_add(t269,ink_f32_mul(t272,t257));
var t274:u32=(t254).ink_f_value;
var t275:u32=(t258).ink_f_rate;
var t276:u32=1065353216u;
var t277:u32=1065353216u;
var t278:u32=ink_f32_sqrt(ink_f32_div(t273,ink_f32_sub(t277,t262)));
var t279:u32=ink_f32_sub(t274,ink_f32_div(ink_f32_mul(t275,ink_f32_div(t267,ink_f32_sub(t276,t260))),ink_f32_add(t278,(t258).ink_f_epsilon)));
var t280:u32=t279;
var t281:u32=t267;
var t282:u32=t273;
var t283:u32=t260;
var t284:u32=t262;
var t285:u32=(t254).ink_f_steps;
var t286:u32=(t285 + 1u);
t251=R_Parameter(t280,t281,t282,t283,t284,t286);}else{
t251=R_Parameter(a0[1u+(i)*6u+0u],a0[1u+(i)*6u+1u],a0[1u+(i)*6u+2u],a0[1u+(i)*6u+3u],a0[1u+(i)*6u+4u],a0[1u+(i)*6u+5u]);}
t186=t251;}
var t287:R_Parameter=t186;
output[1u+i*6u+0u]=bitcast<u32>((t287).ink_f_value);
output[1u+i*6u+1u]=bitcast<u32>((t287).ink_f_first);
output[1u+i*6u+2u]=bitcast<u32>((t287).ink_f_second);
output[1u+i*6u+3u]=bitcast<u32>((t287).ink_f_first_power);
output[1u+i*6u+4u]=bitcast<u32>((t287).ink_f_second_power);
output[1u+i*6u+5u]=(t287).ink_f_steps;


}