const __recordElisions=new Set([]);
const __nativeF32=true;
// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
// Binary64 uses native Numbers for finite arithmetic and immutable private
// tags only where a NaN's exact payload must survive non-arithmetic operations.
const __doubleView=new DataView(new ArrayBuffer(8));
const __double=bits=>{__doubleView.setBigUint64(0,bits,true);return __doubleView.getFloat64(0,true);};
const __doubleBits=number=>{if(Number.isNaN(number))return 0x7ff8000000000000n;__doubleView.setFloat64(0,number,true);return __doubleView.getBigUint64(0,true);};
const __dfNumber=value=>typeof value==='number'?value:__double(BigInt(value.F64Bits));
const __dfBits=value=>typeof value==='number'?__doubleBits(value):BigInt(value.F64Bits);
const __dfFromBits=bits=>(bits&0x7fffffffffffffffn)>0x7ff0000000000000n?Object.freeze({F64Bits:bits.toString()}):__double(bits);
const __dfInput=value=>typeof value==='number'?value:__dfFromBits(BigInt(value.F64Bits));
const __dfNeg=value=>typeof value==='number'&&!Number.isNaN(value)?-value:__dfFromBits(__dfBits(value)^0x8000000000000000n);
const __dfOutput=value=>{const n=__dfNumber(value);return Number.isFinite(n)?n:{F64Bits:__dfBits(value).toString()};};
const __dfCapture=value=>{
 if(typeof value==='number'&&Number.isFinite(value))return value;
 if(!value||typeof value!=='object'||Object.keys(value).length!==1||!Object.hasOwn(value,'F64Bits'))throw Error('invalid f64');const text=value.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid f64');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');return __dfFromBits(bits);
};
// Native binary32 lane for pure modules. Explicit NaN payloads remain tagged;
// arithmetic canonicalizes NaNs just as __bits does in the exact-bit lane.
// Host tags are captured once at a typed read. Only private immutable tags
// may pass through normalization without consulting a host property again.
const __nfTagged = new WeakSet();
const __nfValue = value => typeof value === 'number' ? Math.fround(value) : __nfTagged.has(value) ? value : __nfFromBits(value.F32Bits);
// Number operands have already been normalised at their typed read or producer.
const __nfNumber = value => typeof value === 'number' ? value : __float(value.F32Bits);
const __nfBits = value => typeof value === 'number' ? __bits(value) : value.F32Bits;
const __nfFromBits = bits => {
  if((bits & 0x7fffffff)<=0x7f800000)return __float(bits);
  const value=Object.freeze({F32Bits:bits});__nfTagged.add(value);return value;
};
const __nfNeg = value => typeof value === 'number' && !Number.isNaN(value) ? -value : __nfFromBits((__nfBits(value) ^ 0x80000000) >>> 0);
const __nfOutput = value => {const n=typeof value==='number'?Math.fround(value):__float(value.F32Bits);return Number.isFinite(n)?n:{F32Bits:__nfBits(value)};};
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output, capture=false) {
  const convert=__representationRaw(type,output,capture);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':capture?'capture:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output, capture) {
  switch (type.kind) {
    case 'ref': {
      let resolved;
      return (value,context)=>(resolved??=__representation(__namedTypes[type.name],output,capture))(value,context);
    }
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output,capture);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output,capture),err=__representation(type.error,output,capture);
      const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);
      if(flat)return output?(value,context)=>{const v=__sumView(key,value);return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};}:(v,context)=>Object.hasOwn(v,'Ok')?__sumMake(key,true,ok(v.Ok,context)):__sumMake(key,false,err(v.Err,context));
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f64':return output?__dfOutput:__dfInput;
    case 'f32': if(typeof __nativeF32!=='undefined'&&__nativeF32)return output?__nfOutput:capture?__nfValue:__identity;
      return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output,capture);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){
        if(!type.fields.length)return ()=>undefined; // lexically unconsumed projected input
        const field=type.fields[0],child=__representation(field.type,output,capture);
        return output?(value,context)=>({[field.name]:child(value,context)}):(value,context)=>child(value[field.name],context);
      }
      const fields = type.fields.map(field => [field.name, __representation(field.type, output,capture)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
// Fixed primitives; no cross-invocation host caches.
function __ink_round_even(x){if(!Number.isFinite(x)||Math.abs(x)>=8388608)return x;const a=Math.abs(x),i=Math.floor(a),r=a-i;const y=i+Number(r>0.5||(r===0.5&&i%2===1));return x<0||Object.is(x,-0)?-y:y;}
function __ink_round_even_f64(x){if(!Number.isFinite(x)||Math.abs(x)>=4503599627370496)return x;const a=Math.abs(x),i=Math.floor(a),r=a-i;const y=i+Number(r>0.5||(r===0.5&&i%2===1));return x<0||Object.is(x,-0)?-y:y;}
// Direct BigInt -> binary32 avoids double rounding through binary64.
function __ink_big_float(x){if(x===0n)return 0;const neg=x<0n;if(neg)x=-x;let e=x.toString(2).length-1;if(e<=23)return Number(neg?-x:x);const shift=BigInt(e-23),mask=(1n<<shift)-1n;let q=x>>shift;const rem=x&mask,half=1n<<(shift-1n);if(rem>half||(rem===half&&(q&1n)!==0n))q++;if(q===16777216n){q>>=1n;e++;}if(e>127)return neg?-Infinity:Infinity;return (neg?-1:1)*Number(q)*2**(e-23);}
function __ink_from_float(x,t){x=Math.trunc(x);if(!Number.isFinite(x))return {None:null};const valid=t==='i32'?x>=-2147483648&&x<2147483648:x>=0&&x<(t==='u32'?4294967296:18446744073709551616);return valid?{Some:t==='u64'?BigInt(x):x===0?0:x}:{None:null};}
function __ink_count(x,n,width){if(width===64){x=BigInt.asUintN(64,x);if(n==='popcount'){let count=0;while(x){x&=x-1n;count++;}return count;}if(x===0n)return 64;if(n==='leading_zeros')return 64-x.toString(2).length;let count=0;while((x&1n)===0n){x>>=1n;count++;}return count;}x>>>=0;if(n==='leading_zeros')return Math.clz32(x);if(n==='trailing_zeros')return x===0?32:31-Math.clz32((x&-x)>>>0);x=x-((x>>>1)&0x55555555);x=(x&0x33333333)+((x>>>2)&0x33333333);return Math.imul((x+(x>>>4))&0x0f0f0f0f,0x01010101)>>>24;}
const __ink_encoder=new TextEncoder(),__ink_decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const __ink_bytes=s=>__ink_encoder.encode(s);
// Count UTF-8 bytes directly; valid Ink strings contain Unicode scalar values.
// Preserve TextEncoder's replacement width for a lone surrogate at trusted hosts.
function __ink_byte_len(s,start=0,end=s.length){let n=0;for(let i=start;i<end;i++){const c=s.charCodeAt(i);if(c<128)n++;else if(c<2048)n+=2;else if(c>=0xd800&&c<=0xdbff&&i+1<end&&s.charCodeAt(i+1)>=0xdc00&&s.charCodeAt(i+1)<=0xdfff){n+=4;i++;}else n+=3;}return n;}
const __ink_boundary=(b,i)=>i<=b.length&&(i===b.length||(b[i]&0xc0)!==0x80);
function __ink_byte_at(s,i){const b=__ink_bytes(s);return i<b.length?{Some:b[i]}:{None:null};}
function __ink_slice(s,a,z){const b=__ink_bytes(s);return a<=z&&__ink_boundary(b,a)&&__ink_boundary(b,z)?{Some:__ink_decoder.decode(b.subarray(a,z))}:{None:null};}
function __ink_concat(a,b){const s=a+b;if(__ink_byte_len(s)>4294967295)throw Error('String exceeds U32 byte length');return s;}
function __ink_find(s,needle,from){let unit=0,bytes=0;while(bytes<from&&unit<s.length){const c=s.charCodeAt(unit++);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff&&unit<s.length&&s.charCodeAt(unit)>=0xdc00&&s.charCodeAt(unit)<=0xdfff){bytes+=4;unit++;}else bytes+=3;}if(bytes!==from)return {None:null};const at=s.indexOf(needle,unit);return at<0?{None:null}:{Some:bytes+__ink_byte_len(s,unit,at)};}

function __ink_int_from_float(x){return Number.isFinite(x)?{Some:BigInt(Math.trunc(x))}:{None:null};}
function __fn0(){
const v0=0.0;
const v1=0.0;
const v2=0.0;
const v3=1.0;
const v4=1.0;
const v5=0;
return ({["value"]:v0,["first"]:v1,["second"]:v2,["first_power"]:v3,["second_power"]:v4,["steps"]:v5});}
function __fn1(v6,v7,v8,v9){
v6=__nfValue(v6);
let v10;if((v7===v9)){
v10=v6;}else{
let v11;if(v9<v8.length){v11=v8[v9];}else{
v11=__fn0();}
const v12=v11;
v10=__nfValue(v12["value"]);}
return v10;}
function __fn2(v13,v14){
v13=__nfValue(v13);
v14=__nfValue(v14);
const v15=0.0;
let v16;if(((__nfNumber(v14)) > (__nfNumber(v15)))){
v16=Math.fround(__nfNumber(v13) * __nfNumber(v14));}else{
v16=0.0;}
return v16;}
function __fn3(v17,v18,v19,v20,v21,v22){
v17=__nfValue(v17);
const v23=10;
const v24=(((v22) + (v23)) >>> 0);
const v25=__fn1(v17,v18,v19,v24);
let v26=v25;
for(let v27=0;v27<10;v27++){
const v28=(v27>>>0);
const v29=v26;
const v30=(((v22) + (v28)) >>> 0);
const v31=__fn1(v17,v18,v19,v30);
const v32=10;
const v33=(Math.imul(v21,v32) >>> 0);
const v34=(((v33) + (v28)) >>> 0);
let v35;if(v34<v20.length){v35=v20[v34];}else{
v35=0.0;}
const v36=__nfValue(v35);
const v37=Math.fround(__nfNumber(v31) * __nfNumber(v36));
v26=Math.fround(__nfNumber(v29) + v37);}
return v26;}
function __fn4(v38,v39,v40,v41,v42){
v38=__nfValue(v38);
const v43=6;
const v44=(((v42) + (v43)) >>> 0);
const v45=__fn1(v38,v39,v40,v44);
let v46=v45;
for(let v47=0;v47<6;v47++){
const v48=(v47>>>0);
const v49=v46;
const v50=(((v42) + (v48)) >>> 0);
const v51=__fn1(v38,v39,v40,v50);
let v52;if(v48<v41.length){v52=v41[v48];}else{
v52=0.0;}
const v53=__nfValue(v52);
const v54=Math.fround(__nfNumber(v51) * __nfNumber(v53));
v46=Math.fround(__nfNumber(v49) + v54);}
return v46;}
function __fn5(v55,v56,v57,v58,v59){
v55=__nfValue(v55);
const v60=0;
const v61=__fn3(v55,v56,v57,v58,v59,v60);
const v62=11;
const v63=__fn3(v55,v56,v57,v58,v59,v62);
const v64=__fn2(v61,v63);
const v65=22;
const v66=__fn3(v55,v56,v57,v58,v59,v65);
const v67=33;
const v68=__fn3(v55,v56,v57,v58,v59,v67);
const v69=__fn2(v66,v68);
const v70=44;
const v71=__fn3(v55,v56,v57,v58,v59,v70);
const v72=55;
const v73=__fn3(v55,v56,v57,v58,v59,v72);
const v74=__fn2(v71,v73);
const v75=66;
const v76=__fn3(v55,v56,v57,v58,v59,v75);
const v77=77;
const v78=__fn3(v55,v56,v57,v58,v59,v77);
const v79=__fn2(v76,v78);
const v80=88;
const v81=__fn3(v55,v56,v57,v58,v59,v80);
const v82=99;
const v83=__fn3(v55,v56,v57,v58,v59,v82);
const v84=__fn2(v81,v83);
const v85=110;
const v86=__fn3(v55,v56,v57,v58,v59,v85);
const v87=121;
const v88=__fn3(v55,v56,v57,v58,v59,v87);
const v89=__fn2(v86,v88);
return [v64,v69,v74,v79,v84,v89];}
function __fn6(v90,v91,v92,v93){
v90=__nfValue(v90);
const v94=132;
const v95=__fn4(v90,v91,v92,v93,v94);
const v96=139;
const v97=__fn4(v90,v91,v92,v93,v96);
const v98=__fn2(v95,v97);
const v99=146;
const v100=__fn4(v90,v91,v92,v93,v99);
const v101=153;
const v102=__fn4(v90,v91,v92,v93,v101);
const v103=__fn2(v100,v102);
const v104=160;
const v105=__fn4(v90,v91,v92,v93,v104);
const v106=167;
const v107=__fn4(v90,v91,v92,v93,v106);
const v108=__fn2(v105,v107);
const v109=174;
const v110=__fn4(v90,v91,v92,v93,v109);
const v111=181;
const v112=__fn4(v90,v91,v92,v93,v111);
const v113=__fn2(v110,v112);
const v114=188;
const v115=__fn4(v90,v91,v92,v93,v114);
const v116=195;
const v117=__fn4(v90,v91,v92,v93,v116);
const v118=__fn2(v115,v117);
const v119=202;
const v120=__fn4(v90,v91,v92,v93,v119);
const v121=209;
const v122=__fn4(v90,v91,v92,v93,v121);
const v123=__fn2(v120,v122);
return [v98,v103,v108,v113,v118,v123];}
function __fn7(v124,v125,v126,v127,v128){
v124=__nfValue(v124);
const v129=__fn5(v124,v125,v126,v127,v128);
const v130=__fn6(v124,v125,v126,v129);
const v131=216;
const v132=__fn4(v124,v125,v126,v130,v131);
const v133=223;
const v134=__fn4(v124,v125,v126,v130,v133);
const v135=230;
const v136=__fn4(v124,v125,v126,v130,v135);
const v137=237;
const v138=__fn4(v124,v125,v126,v130,v137);
return [v132,v134,v136,v138];}
function __fn8(v139,v140){
v139=__nfValue(v139);
v140=__nfValue(v140);
const v141=Math.fround(__nfNumber(v139) - __nfNumber(v140));
return Math.fround(v141 * v141);}
function __fn9(v142,v143,v144,v145,v146,v147){
v142=__nfValue(v142);
const v148=__fn7(v142,v143,v144,v145,v147);
let v149=0.0;
for(let v150=0;v150<4;v150++){
const v151=(v150>>>0);
const v152=v149;
let v153;if(v151<v148.length){v153=v148[v151];}else{
v153=0.0;}
const v154=__nfValue(v153);
const v155=4;
const v156=(Math.imul(v147,v155) >>> 0);
const v157=(((v156) + (v151)) >>> 0);
let v158;if(v157<v146.length){v158=v146[v157];}else{
v158=0.0;}
const v159=__nfValue(v158);
const v160=__fn8(v154,v159);
v149=Math.fround(__nfNumber(v152) + __nfNumber(v160));}
const v161=v149;
return Math.fround((__nfNumber(v161))/(__nfNumber(4.0)));}
function __fn10(v162,v163,v164,v165){
const v166=(v165).length;
const v167=0;
let v168;if((v166===v167)){
const v169=v162.length;
const v170=new Array(v169);
for(let v171=0;v171<v169;v171++){
const v172=v162[v171];
v170[v171]=0.0;
}
v168=v170;}else{
const v173=v162.length;
const v174=new Array(v173);
for(let v175=0;v175<v173;v175++){
const v176=v162[v175];
const v177=(v175>>>0);
let v178=0.0;
for(let v179=0;v179<v165.length;v179++){
const v180=(v165[v179]>>>0);
const v181=v178;
const v182=__nfValue(v176["value"]);
const v183=__fn31(v182,v177,v162,v163,v164,v180);
v178=Math.fround(__nfNumber(v181) + __nfNumber(v183));
}
v174[v175]=Math.fround((__nfNumber(v178))/(__nfNumber(Math.fround((v165).length))));
}
v168=v174;}
return v168;}
function __fn11(v184,v185,v186){
v185=__nfValue(v185);
const v187=__nfValue(v184["first_power"]);
const v188=__nfValue(v186["first_decay"]);
const v189=Math.fround(__nfNumber(v187) * __nfNumber(v188));
const v190=__nfValue(v184["second_power"]);
const v191=__nfValue(v186["second_decay"]);
const v192=Math.fround(__nfNumber(v190) * __nfNumber(v191));
const v193=__nfValue(v186["first_decay"]);
const v194=__nfValue(v184["first"]);
const v195=Math.fround(__nfNumber(v193) * __nfNumber(v194));
const v196=1.0;
const v197=__nfValue(v186["first_decay"]);
const v198=Math.fround(v196 - __nfNumber(v197));
const v199=Math.fround(v198 * __nfNumber(v185));
const v200=Math.fround(v195 + v199);
const v201=__nfValue(v186["second_decay"]);
const v202=__nfValue(v184["second"]);
const v203=Math.fround(__nfNumber(v201) * __nfNumber(v202));
const v204=1.0;
const v205=__nfValue(v186["second_decay"]);
const v206=Math.fround(v204 - __nfNumber(v205));
const v207=Math.fround(v206 * __nfNumber(v185));
const v208=Math.fround(v207 * __nfNumber(v185));
const v209=Math.fround(v203 + v208);
const v210=__nfValue(v184["value"]);
const v211=__nfValue(v186["rate"]);
const v212=1.0;
const v213=Math.fround((__nfNumber(v200))/(__nfNumber(Math.fround(v212 - v189))));
const v214=1.0;
const v215=Math.fround(Math.sqrt(__nfNumber(Math.fround((__nfNumber(v209))/(__nfNumber(Math.fround(v214 - v192)))))));
const v216=__nfValue(v186["epsilon"]);
const v217=Math.fround((__nfNumber(Math.fround(__nfNumber(v211) * v213)))/(__nfNumber(Math.fround(v215 + __nfNumber(v216)))));
const v218=Math.fround(__nfNumber(v210) - v217);
const v219=v184["steps"];
const v220=1;
const v221=(((v219) + (v220)) >>> 0);
return ({["value"]:v218,["first"]:v200,["second"]:v209,["first_power"]:v189,["second_power"]:v192,["steps"]:v221});}
function __fn12(v222){
const v223=Number.isFinite(__nfNumber(__nfValue(v222["value"])));
let v224=v223;if(v224){
v224=Number.isFinite(__nfNumber(__nfValue(v222["first"])));}
const v225=v224;
let v226=v225;if(v226){
v226=Number.isFinite(__nfNumber(__nfValue(v222["second"])));}
const v227=v226;
let v228=v227;if(v228){
const v229=__nfValue(v222["second"]);
const v230=0.0;
v228=((__nfNumber(v229)) >= (__nfNumber(v230)));}
const v231=v228;
let v232=v231;if(v232){
const v233=__nfValue(v222["first_power"]);
const v234=0.0;
v232=((__nfNumber(v233)) >= (__nfNumber(v234)));}
const v235=v232;
let v236=v235;if(v236){
const v237=__nfValue(v222["first_power"]);
const v238=1.0;
v236=((__nfNumber(v237)) <= (__nfNumber(v238)));}
const v239=v236;
let v240=v239;if(v240){
const v241=__nfValue(v222["second_power"]);
const v242=0.0;
v240=((__nfNumber(v241)) >= (__nfNumber(v242)));}
const v243=v240;
let v244=v243;if(v244){
const v245=__nfValue(v222["second_power"]);
const v246=1.0;
v244=((__nfNumber(v245)) <= (__nfNumber(v246)));}
const v247=v244;
let v248=v247;if(v248){
const v249=v222["steps"];
const v250=4294967295;
v248=((v249) < (v250));}
return v248;}
function __fn13(v251){
const v252=Number.isFinite(__nfNumber(__nfValue(v251["rate"])));
let v253=v252;if(v253){
const v254=__nfValue(v251["rate"]);
const v255=0.0;
v253=((__nfNumber(v254)) > (__nfNumber(v255)));}
const v256=v253;
let v257=v256;if(v257){
const v258=__nfValue(v251["first_decay"]);
const v259=0.0;
v257=((__nfNumber(v258)) >= (__nfNumber(v259)));}
const v260=v257;
let v261=v260;if(v261){
const v262=__nfValue(v251["first_decay"]);
const v263=1.0;
v261=((__nfNumber(v262)) < (__nfNumber(v263)));}
const v264=v261;
let v265=v264;if(v265){
const v266=__nfValue(v251["second_decay"]);
const v267=0.0;
v265=((__nfNumber(v266)) >= (__nfNumber(v267)));}
const v268=v265;
let v269=v268;if(v269){
const v270=__nfValue(v251["second_decay"]);
const v271=1.0;
v269=((__nfNumber(v270)) < (__nfNumber(v271)));}
const v272=v269;
let v273=v272;if(v273){
v273=Number.isFinite(__nfNumber(__nfValue(v251["epsilon"])));}
const v274=v273;
let v275=v274;if(v275){
const v276=__nfValue(v251["epsilon"]);
const v277=0.0;
v275=((__nfNumber(v276)) > (__nfNumber(v277)));}
return v275;}
function __fn14(v278,v279,v280,v281){
const v282=(v278).length;
const v283=244;
const v284=(v282===v283);
let v285=v284;if(v285){
const v286=(v279).length;
const v287=(v281).length;
const v288=10;
const v289=(Math.imul(v287,v288) >>> 0);
v285=(v286===v289);}
const v290=v285;
let v291=v290;if(v291){
const v292=(v280).length;
const v293=(v281).length;
const v294=4;
const v295=(Math.imul(v293,v294) >>> 0);
v291=(v292===v295);}
const v296=v291;
let v297=v296;if(v297){
const v298=(v281).length;
const v299=0;
v297=((v298) > (v299));}
return v297;}
function __fn15(v300,v301,v302,v303){
const v304=false;
const v305=(v302===v304);
let v306=v305;if(!v306){
const v307=__fn13(v303);
const v308=false;
v306=(v307===v308);}
const v309=v306;
let v310=v309;if(!v310){
const v311=(v301).length;
const v312=(v300).length;
v310=!(v311===v312);}
const v313=v310;
let v314=v313;if(!v314){
let v315=true;
for(let v316=0;v316<v300.length;v316++){
const v317=v300[v316];
const v318=v315;
let v319=v318;if(v319){
v319=__fn12(v317);}
v315=v319;
}
const v320=v315;
const v321=false;
v314=(v320===v321);}
let v322;if(v314){
v322=v300;}else{
const v323=v300.length;
const v324=new Array(v323);
for(let v325=0;v325<v323;v325++){
const v326=v300[v325];
const v327=(v325>>>0);
let v328;if(v327<v301.length){v328=v301[v327];}else{
v328=0.0;}
const v329=__nfValue(v328);
v324[v325]=__fn11(v326,v329,v303);
}
let v330=true;
for(let v331=0;v331<v324.length;v331++){
const v332=v324[v331];
const v333=v330;
let v334=v333;if(v334){
v334=__fn12(v332);}
v330=v334;
}
let v335;if(v330){
v335=v324;}else{
v335=v300;}
v322=v335;}
return v322;}
function __fn16(v336,v337,v338,v339){
const v340=v339.length;
const v341=new Array(v340);
for(let v342=0;v342<v340;v342++){
const v343=(v339[v342]>>>0);
const v344=0.0;
const v345=4294967295;
v341[v342]=__fn9(v344,v345,v336,v337,v338,v343);
}
return v341;}
function __fn17(v346,v347){
const v348=__nfValue(v346["value"]);
const v349=__nfValue(v347["value"]);
const v350=Math.fround(__nfNumber(v348) * __nfNumber(v349));
const v351=__nfValue(v346["tangent"]);
const v352=__nfValue(v347["value"]);
const v353=Math.fround(__nfNumber(v351) * __nfNumber(v352));
const v354=__nfValue(v346["value"]);
const v355=__nfValue(v347["tangent"]);
const v356=Math.fround(__nfNumber(v354) * __nfNumber(v355));
const v357=Math.fround(v353 + v356);
return ({["value"]:v350,["tangent"]:v357});}
function __fn18(v358,v359){
const v360=__nfValue(v359["value"]);
const v361=0.0;
const v362=0.0;
const v363=({["value"]:v361,["tangent"]:v362});
const v364=__nfValue(v363["value"]);
let v365;if(((__nfNumber(v360)) > (__nfNumber(v364)))){
v365=__fn17(v358,v359);}else{
const v366=0.0;
const v367=0.0;
v365=({["value"]:v366,["tangent"]:v367});}
return v365;}
function __fn19(){
const v368=0.0;
const v369=0.0;
const v370=({["value"]:v368,["tangent"]:v369});
const v371=0.0;
const v372=0.0;
const v373=({["value"]:v371,["tangent"]:v372});
const v374=0.0;
const v375=0.0;
const v376=({["value"]:v374,["tangent"]:v375});
const v377=1.0;
const v378=0.0;
const v379=({["value"]:v377,["tangent"]:v378});
const v380=1.0;
const v381=0.0;
const v382=({["value"]:v380,["tangent"]:v381});
const v383=0;
return ({["value"]:v370,["first"]:v373,["second"]:v376,["first_power"]:v379,["second_power"]:v382,["steps"]:v383});}
function __fn20(v384,v385,v386,v387){
let v388;if((v385===v387)){
v388=v384;}else{
let v389;if(v387<v386.length){v389=v386[v387];}else{
v389=__fn19();}
const v390=v389;
v388=v390["value"];}
return v388;}
function __fn21(v391,v392){
const v393=__nfValue(v391["value"]);
const v394=__nfValue(v392["value"]);
const v395=Math.fround(__nfNumber(v393) + __nfNumber(v394));
const v396=__nfValue(v391["tangent"]);
const v397=__nfValue(v392["tangent"]);
const v398=Math.fround(__nfNumber(v396) + __nfNumber(v397));
return ({["value"]:v395,["tangent"]:v398});}
function __fn22(v399,v400,v401,v402,v403,v404){
const v405=10;
const v406=(((v404) + (v405)) >>> 0);
const v407=__fn20(v399,v400,v401,v406);
let v408=v407["value"];
let v409=v407["tangent"];
for(let v411=0;v411<10;v411++){
const v412=(v411>>>0);
const v414=(((v404) + (v412)) >>> 0);
const v415=__fn20(v399,v400,v401,v414);
const v416=10;
const v417=(Math.imul(v403,v416) >>> 0);
const v418=(((v417) + (v412)) >>> 0);
let v419;if(v418<v402.length){v419=v402[v418];}else{
const v420=0.0;
const v421=0.0;
v419=({["value"]:v420,["tangent"]:v421});}
const v422=v419;
const v423=__fn17(v415,v422);
const v424=__nfValue(v408);
const v425=__nfValue(v423["value"]);
const v426=Math.fround(__nfNumber(v424) + __nfNumber(v425));
const v427=__nfValue(v409);
const v428=__nfValue(v423["tangent"]);
const v429=Math.fround(__nfNumber(v427) + __nfNumber(v428));
v408=v426;
v409=v429;
}
return ({["value"]:v408,["tangent"]:v409});}
function __fn23(v430,v431,v432,v433,v434){
const v435=0;
const v436=__fn22(v430,v431,v432,v433,v434,v435);
const v437=11;
const v438=__fn22(v430,v431,v432,v433,v434,v437);
const v439=__fn18(v436,v438);
const v440=22;
const v441=__fn22(v430,v431,v432,v433,v434,v440);
const v442=33;
const v443=__fn22(v430,v431,v432,v433,v434,v442);
const v444=__fn18(v441,v443);
const v445=44;
const v446=__fn22(v430,v431,v432,v433,v434,v445);
const v447=55;
const v448=__fn22(v430,v431,v432,v433,v434,v447);
const v449=__fn18(v446,v448);
const v450=66;
const v451=__fn22(v430,v431,v432,v433,v434,v450);
const v452=77;
const v453=__fn22(v430,v431,v432,v433,v434,v452);
const v454=__fn18(v451,v453);
const v455=88;
const v456=__fn22(v430,v431,v432,v433,v434,v455);
const v457=99;
const v458=__fn22(v430,v431,v432,v433,v434,v457);
const v459=__fn18(v456,v458);
const v460=110;
const v461=__fn22(v430,v431,v432,v433,v434,v460);
const v462=121;
const v463=__fn22(v430,v431,v432,v433,v434,v462);
const v464=__fn18(v461,v463);
return [v439,v444,v449,v454,v459,v464];}
function __fn24(v465,v466,v467,v468,v469){
const v470=6;
const v471=(((v469) + (v470)) >>> 0);
const v472=__fn20(v465,v466,v467,v471);
let v473=v472["value"];
let v474=v472["tangent"];
for(let v476=0;v476<6;v476++){
const v477=(v476>>>0);
const v479=(((v469) + (v477)) >>> 0);
const v480=__fn20(v465,v466,v467,v479);
let v481;if(v477<v468.length){v481=v468[v477];}else{
const v482=0.0;
const v483=0.0;
v481=({["value"]:v482,["tangent"]:v483});}
const v484=v481;
const v485=__fn17(v480,v484);
const v486=__nfValue(v473);
const v487=__nfValue(v485["value"]);
const v488=Math.fround(__nfNumber(v486) + __nfNumber(v487));
const v489=__nfValue(v474);
const v490=__nfValue(v485["tangent"]);
const v491=Math.fround(__nfNumber(v489) + __nfNumber(v490));
v473=v488;
v474=v491;
}
return ({["value"]:v473,["tangent"]:v474});}
function __fn25(v492,v493,v494,v495){
const v496=132;
const v497=__fn24(v492,v493,v494,v495,v496);
const v498=139;
const v499=__fn24(v492,v493,v494,v495,v498);
const v500=__fn18(v497,v499);
const v501=146;
const v502=__fn24(v492,v493,v494,v495,v501);
const v503=153;
const v504=__fn24(v492,v493,v494,v495,v503);
const v505=__fn18(v502,v504);
const v506=160;
const v507=__fn24(v492,v493,v494,v495,v506);
const v508=167;
const v509=__fn24(v492,v493,v494,v495,v508);
const v510=__fn18(v507,v509);
const v511=174;
const v512=__fn24(v492,v493,v494,v495,v511);
const v513=181;
const v514=__fn24(v492,v493,v494,v495,v513);
const v515=__fn18(v512,v514);
const v516=188;
const v517=__fn24(v492,v493,v494,v495,v516);
const v518=195;
const v519=__fn24(v492,v493,v494,v495,v518);
const v520=__fn18(v517,v519);
const v521=202;
const v522=__fn24(v492,v493,v494,v495,v521);
const v523=209;
const v524=__fn24(v492,v493,v494,v495,v523);
const v525=__fn18(v522,v524);
return [v500,v505,v510,v515,v520,v525];}
function __fn26(v526,v527,v528,v529,v530){
const v531=__fn23(v526,v527,v528,v529,v530);
const v532=__fn25(v526,v527,v528,v531);
const v533=216;
const v534=__fn24(v526,v527,v528,v532,v533);
const v535=223;
const v536=__fn24(v526,v527,v528,v532,v535);
const v537=230;
const v538=__fn24(v526,v527,v528,v532,v537);
const v539=237;
const v540=__fn24(v526,v527,v528,v532,v539);
return [v534,v536,v538,v540];}
function __fn27(v541,v542){
const v543=__nfValue(v541["value"]);
const v544=__nfValue(v542["value"]);
const v545=Math.fround(__nfNumber(v543) - __nfNumber(v544));
const v546=__nfValue(v541["tangent"]);
const v547=__nfValue(v542["tangent"]);
const v548=Math.fround(__nfNumber(v546) - __nfNumber(v547));
return ({["value"]:v545,["tangent"]:v548});}
function __fn28(v549,v550){
const v551=__fn27(v549,v550);
return __fn17(v551,v551);}
function __fn29(v552,v553){
const v554=Math.fround((__nfNumber(__nfValue(v552["value"])))/(__nfNumber(__nfValue(v553["value"]))));
const v555=__nfValue(v552["tangent"]);
const v556=__nfValue(v553["value"]);
const v557=Math.fround(__nfNumber(v555) * __nfNumber(v556));
const v558=__nfValue(v552["value"]);
const v559=__nfValue(v553["tangent"]);
const v560=Math.fround(__nfNumber(v558) * __nfNumber(v559));
const v561=__nfValue(v553["value"]);
const v562=__nfValue(v553["value"]);
const v563=Math.fround((__nfNumber(Math.fround(v557 - v560)))/(__nfNumber(Math.fround(__nfNumber(v561) * __nfNumber(v562)))));
return ({["value"]:v554,["tangent"]:v563});}
function __fn30(v564,v565,v566,v567,v568,v569){
const v570=__fn26(v564,v565,v566,v567,v569);
const v571=0.0;
const v572=0.0;
let v573=v571;
let v574=v572;
for(let v576=0;v576<4;v576++){
const v577=(v576>>>0);
let v579;if(v577<v570.length){v579=v570[v577];}else{
const v580=0.0;
const v581=0.0;
v579=({["value"]:v580,["tangent"]:v581});}
const v582=v579;
const v583=4;
const v584=(Math.imul(v569,v583) >>> 0);
const v585=(((v584) + (v577)) >>> 0);
let v586;if(v585<v568.length){v586=v568[v585];}else{
const v587=0.0;
const v588=0.0;
v586=({["value"]:v587,["tangent"]:v588});}
const v589=v586;
const v590=__fn28(v582,v589);
const v591=__nfValue(v573);
const v592=__nfValue(v590["value"]);
const v593=Math.fround(__nfNumber(v591) + __nfNumber(v592));
const v594=__nfValue(v574);
const v595=__nfValue(v590["tangent"]);
const v596=Math.fround(__nfNumber(v594) + __nfNumber(v595));
v573=v593;
v574=v596;
}
const v599=4.0;
const v600=0.0;
const v602=Math.fround((__nfNumber(__nfValue(v573)))/(__nfNumber(v599)));
const v603=__nfValue(v574);
const v604=Math.fround(__nfNumber(v603) * v599);
const v605=__nfValue(v573);
const v606=Math.fround(__nfNumber(v605) * v600);
const v607=Math.fround((__nfNumber(Math.fround(v604 - v606)))/(__nfNumber(Math.fround(v599 * v599))));
return ({["value"]:v602,["tangent"]:v607});}
function __fn31(v608,v609,v610,v611,v612,v613){
v608=__nfValue(v608);
const v614=1.0;
const v616=v610.length;
const v617=new Array(v616);
for(let v618=0;v618<v616;v618++){
const v619=v610[v618];
const v620=__nfValue(v619["value"]);
const v621=0.0;
const v622=({["value"]:v620,["tangent"]:v621});
const v623=__nfValue(v619["first"]);
const v624=0.0;
const v625=({["value"]:v623,["tangent"]:v624});
const v626=__nfValue(v619["second"]);
const v627=0.0;
const v628=({["value"]:v626,["tangent"]:v627});
const v629=__nfValue(v619["first_power"]);
const v630=0.0;
const v631=({["value"]:v629,["tangent"]:v630});
const v632=__nfValue(v619["second_power"]);
const v633=0.0;
const v634=({["value"]:v632,["tangent"]:v633});
const v635=v619["steps"];
v617[v618]=({["value"]:v622,["first"]:v625,["second"]:v628,["first_power"]:v631,["second_power"]:v634,["steps"]:v635});
}
const v636=v611.length;
const v637=new Array(v636);
for(let v638=0;v638<v636;v638++){
const v639=v611[v638];
const v640=__nfValue(v639);
const v641=0.0;
v637[v638]=({["value"]:v640,["tangent"]:v641});
}
const v642=v612.length;
const v643=new Array(v642);
for(let v644=0;v644<v642;v644++){
const v645=v612[v644];
const v646=__nfValue(v645);
const v647=0.0;
v643[v644]=({["value"]:v646,["tangent"]:v647});
}
const v651=0;
const v652=({["value"]:v608,["tangent"]:v614});
const v653=10;
const v654=(((v651) + (v653)) >>> 0);
const v655=__fn20(v652,v609,v617,v654);
let v656=v655["value"];
let v657=v655["tangent"];
for(let v659=0;v659<10;v659++){
const v660=(v659>>>0);
const v661=({["value"]:v656,["tangent"]:v657});
const v662=({["value"]:v608,["tangent"]:v614});
const v663=(((v651) + (v660)) >>> 0);
const v664=__fn20(v662,v609,v617,v663);
const v665=10;
const v666=(Math.imul(v613,v665) >>> 0);
const v667=(((v666) + (v660)) >>> 0);
let v668;if(v667<v637.length){v668=v637[v667];}else{
const v669=0.0;
const v670=0.0;
v668=({["value"]:v669,["tangent"]:v670});}
const v671=v668;
const v672=__fn17(v664,v671);
const v673=__fn21(v661,v672);
v656=v673["value"];
v657=v673["tangent"];
}
const v676=11;
const v677=({["value"]:v608,["tangent"]:v614});
const v678=10;
const v679=(((v676) + (v678)) >>> 0);
const v680=__fn20(v677,v609,v617,v679);
let v681=v680["value"];
let v682=v680["tangent"];
for(let v684=0;v684<10;v684++){
const v685=(v684>>>0);
const v686=({["value"]:v681,["tangent"]:v682});
const v687=({["value"]:v608,["tangent"]:v614});
const v688=(((v676) + (v685)) >>> 0);
const v689=__fn20(v687,v609,v617,v688);
const v690=10;
const v691=(Math.imul(v613,v690) >>> 0);
const v692=(((v691) + (v685)) >>> 0);
let v693;if(v692<v637.length){v693=v637[v692];}else{
const v694=0.0;
const v695=0.0;
v693=({["value"]:v694,["tangent"]:v695});}
const v696=v693;
const v697=__fn17(v689,v696);
const v698=__fn21(v686,v697);
v681=v698["value"];
v682=v698["tangent"];
}
const v700=__nfValue(v681);
const v701=0.0;
const v702=0.0;
const v703=({["value"]:v701,["tangent"]:v702});
const v704=__nfValue(v703["value"]);
let v705;
let v706;
if(((__nfNumber(v700)) > (__nfNumber(v704)))){
const v707=({["value"]:v656,["tangent"]:v657});
const v708=({["value"]:v681,["tangent"]:v682});
const v709=__fn17(v707,v708);
v705=v709["value"];
v706=v709["tangent"];
}else{
const v710=0.0;
const v711=0.0;
v705=v710;
v706=v711;
}
const v712=({["value"]:v705,["tangent"]:v706});
const v714=22;
const v715=({["value"]:v608,["tangent"]:v614});
const v716=10;
const v717=(((v714) + (v716)) >>> 0);
const v718=__fn20(v715,v609,v617,v717);
let v719=v718["value"];
let v720=v718["tangent"];
for(let v722=0;v722<10;v722++){
const v723=(v722>>>0);
const v724=({["value"]:v719,["tangent"]:v720});
const v725=({["value"]:v608,["tangent"]:v614});
const v726=(((v714) + (v723)) >>> 0);
const v727=__fn20(v725,v609,v617,v726);
const v728=10;
const v729=(Math.imul(v613,v728) >>> 0);
const v730=(((v729) + (v723)) >>> 0);
let v731;if(v730<v637.length){v731=v637[v730];}else{
const v732=0.0;
const v733=0.0;
v731=({["value"]:v732,["tangent"]:v733});}
const v734=v731;
const v735=__fn17(v727,v734);
const v736=__fn21(v724,v735);
v719=v736["value"];
v720=v736["tangent"];
}
const v739=33;
const v740=({["value"]:v608,["tangent"]:v614});
const v741=10;
const v742=(((v739) + (v741)) >>> 0);
const v743=__fn20(v740,v609,v617,v742);
let v744=v743["value"];
let v745=v743["tangent"];
for(let v747=0;v747<10;v747++){
const v748=(v747>>>0);
const v749=({["value"]:v744,["tangent"]:v745});
const v750=({["value"]:v608,["tangent"]:v614});
const v751=(((v739) + (v748)) >>> 0);
const v752=__fn20(v750,v609,v617,v751);
const v753=10;
const v754=(Math.imul(v613,v753) >>> 0);
const v755=(((v754) + (v748)) >>> 0);
let v756;if(v755<v637.length){v756=v637[v755];}else{
const v757=0.0;
const v758=0.0;
v756=({["value"]:v757,["tangent"]:v758});}
const v759=v756;
const v760=__fn17(v752,v759);
const v761=__fn21(v749,v760);
v744=v761["value"];
v745=v761["tangent"];
}
const v763=__nfValue(v744);
const v764=0.0;
const v765=0.0;
const v766=({["value"]:v764,["tangent"]:v765});
const v767=__nfValue(v766["value"]);
let v768;
let v769;
if(((__nfNumber(v763)) > (__nfNumber(v767)))){
const v770=({["value"]:v719,["tangent"]:v720});
const v771=({["value"]:v744,["tangent"]:v745});
const v772=__fn17(v770,v771);
v768=v772["value"];
v769=v772["tangent"];
}else{
const v773=0.0;
const v774=0.0;
v768=v773;
v769=v774;
}
const v775=({["value"]:v768,["tangent"]:v769});
const v777=44;
const v778=({["value"]:v608,["tangent"]:v614});
const v779=10;
const v780=(((v777) + (v779)) >>> 0);
const v781=__fn20(v778,v609,v617,v780);
let v782=v781["value"];
let v783=v781["tangent"];
for(let v785=0;v785<10;v785++){
const v786=(v785>>>0);
const v787=({["value"]:v782,["tangent"]:v783});
const v788=({["value"]:v608,["tangent"]:v614});
const v789=(((v777) + (v786)) >>> 0);
const v790=__fn20(v788,v609,v617,v789);
const v791=10;
const v792=(Math.imul(v613,v791) >>> 0);
const v793=(((v792) + (v786)) >>> 0);
let v794;if(v793<v637.length){v794=v637[v793];}else{
const v795=0.0;
const v796=0.0;
v794=({["value"]:v795,["tangent"]:v796});}
const v797=v794;
const v798=__fn17(v790,v797);
const v799=__fn21(v787,v798);
v782=v799["value"];
v783=v799["tangent"];
}
const v802=55;
const v803=({["value"]:v608,["tangent"]:v614});
const v804=10;
const v805=(((v802) + (v804)) >>> 0);
const v806=__fn20(v803,v609,v617,v805);
let v807=v806["value"];
let v808=v806["tangent"];
for(let v810=0;v810<10;v810++){
const v811=(v810>>>0);
const v812=({["value"]:v807,["tangent"]:v808});
const v813=({["value"]:v608,["tangent"]:v614});
const v814=(((v802) + (v811)) >>> 0);
const v815=__fn20(v813,v609,v617,v814);
const v816=10;
const v817=(Math.imul(v613,v816) >>> 0);
const v818=(((v817) + (v811)) >>> 0);
let v819;if(v818<v637.length){v819=v637[v818];}else{
const v820=0.0;
const v821=0.0;
v819=({["value"]:v820,["tangent"]:v821});}
const v822=v819;
const v823=__fn17(v815,v822);
const v824=__fn21(v812,v823);
v807=v824["value"];
v808=v824["tangent"];
}
const v826=__nfValue(v807);
const v827=0.0;
const v828=0.0;
const v829=({["value"]:v827,["tangent"]:v828});
const v830=__nfValue(v829["value"]);
let v831;
let v832;
if(((__nfNumber(v826)) > (__nfNumber(v830)))){
const v833=({["value"]:v782,["tangent"]:v783});
const v834=({["value"]:v807,["tangent"]:v808});
const v835=__fn17(v833,v834);
v831=v835["value"];
v832=v835["tangent"];
}else{
const v836=0.0;
const v837=0.0;
v831=v836;
v832=v837;
}
const v838=({["value"]:v831,["tangent"]:v832});
const v840=66;
const v841=({["value"]:v608,["tangent"]:v614});
const v842=10;
const v843=(((v840) + (v842)) >>> 0);
const v844=__fn20(v841,v609,v617,v843);
let v845=v844["value"];
let v846=v844["tangent"];
for(let v848=0;v848<10;v848++){
const v849=(v848>>>0);
const v850=({["value"]:v845,["tangent"]:v846});
const v851=({["value"]:v608,["tangent"]:v614});
const v852=(((v840) + (v849)) >>> 0);
const v853=__fn20(v851,v609,v617,v852);
const v854=10;
const v855=(Math.imul(v613,v854) >>> 0);
const v856=(((v855) + (v849)) >>> 0);
let v857;if(v856<v637.length){v857=v637[v856];}else{
const v858=0.0;
const v859=0.0;
v857=({["value"]:v858,["tangent"]:v859});}
const v860=v857;
const v861=__fn17(v853,v860);
const v862=__fn21(v850,v861);
v845=v862["value"];
v846=v862["tangent"];
}
const v865=77;
const v866=({["value"]:v608,["tangent"]:v614});
const v867=10;
const v868=(((v865) + (v867)) >>> 0);
const v869=__fn20(v866,v609,v617,v868);
let v870=v869["value"];
let v871=v869["tangent"];
for(let v873=0;v873<10;v873++){
const v874=(v873>>>0);
const v875=({["value"]:v870,["tangent"]:v871});
const v876=({["value"]:v608,["tangent"]:v614});
const v877=(((v865) + (v874)) >>> 0);
const v878=__fn20(v876,v609,v617,v877);
const v879=10;
const v880=(Math.imul(v613,v879) >>> 0);
const v881=(((v880) + (v874)) >>> 0);
let v882;if(v881<v637.length){v882=v637[v881];}else{
const v883=0.0;
const v884=0.0;
v882=({["value"]:v883,["tangent"]:v884});}
const v885=v882;
const v886=__fn17(v878,v885);
const v887=__fn21(v875,v886);
v870=v887["value"];
v871=v887["tangent"];
}
const v889=__nfValue(v870);
const v890=0.0;
const v891=0.0;
const v892=({["value"]:v890,["tangent"]:v891});
const v893=__nfValue(v892["value"]);
let v894;
let v895;
if(((__nfNumber(v889)) > (__nfNumber(v893)))){
const v896=({["value"]:v845,["tangent"]:v846});
const v897=({["value"]:v870,["tangent"]:v871});
const v898=__fn17(v896,v897);
v894=v898["value"];
v895=v898["tangent"];
}else{
const v899=0.0;
const v900=0.0;
v894=v899;
v895=v900;
}
const v901=({["value"]:v894,["tangent"]:v895});
const v903=88;
const v904=({["value"]:v608,["tangent"]:v614});
const v905=10;
const v906=(((v903) + (v905)) >>> 0);
const v907=__fn20(v904,v609,v617,v906);
let v908=v907["value"];
let v909=v907["tangent"];
for(let v911=0;v911<10;v911++){
const v912=(v911>>>0);
const v913=({["value"]:v908,["tangent"]:v909});
const v914=({["value"]:v608,["tangent"]:v614});
const v915=(((v903) + (v912)) >>> 0);
const v916=__fn20(v914,v609,v617,v915);
const v917=10;
const v918=(Math.imul(v613,v917) >>> 0);
const v919=(((v918) + (v912)) >>> 0);
let v920;if(v919<v637.length){v920=v637[v919];}else{
const v921=0.0;
const v922=0.0;
v920=({["value"]:v921,["tangent"]:v922});}
const v923=v920;
const v924=__fn17(v916,v923);
const v925=__fn21(v913,v924);
v908=v925["value"];
v909=v925["tangent"];
}
const v928=99;
const v929=({["value"]:v608,["tangent"]:v614});
const v930=10;
const v931=(((v928) + (v930)) >>> 0);
const v932=__fn20(v929,v609,v617,v931);
let v933=v932["value"];
let v934=v932["tangent"];
for(let v936=0;v936<10;v936++){
const v937=(v936>>>0);
const v938=({["value"]:v933,["tangent"]:v934});
const v939=({["value"]:v608,["tangent"]:v614});
const v940=(((v928) + (v937)) >>> 0);
const v941=__fn20(v939,v609,v617,v940);
const v942=10;
const v943=(Math.imul(v613,v942) >>> 0);
const v944=(((v943) + (v937)) >>> 0);
let v945;if(v944<v637.length){v945=v637[v944];}else{
const v946=0.0;
const v947=0.0;
v945=({["value"]:v946,["tangent"]:v947});}
const v948=v945;
const v949=__fn17(v941,v948);
const v950=__fn21(v938,v949);
v933=v950["value"];
v934=v950["tangent"];
}
const v952=__nfValue(v933);
const v953=0.0;
const v954=0.0;
const v955=({["value"]:v953,["tangent"]:v954});
const v956=__nfValue(v955["value"]);
let v957;
let v958;
if(((__nfNumber(v952)) > (__nfNumber(v956)))){
const v959=({["value"]:v908,["tangent"]:v909});
const v960=({["value"]:v933,["tangent"]:v934});
const v961=__fn17(v959,v960);
v957=v961["value"];
v958=v961["tangent"];
}else{
const v962=0.0;
const v963=0.0;
v957=v962;
v958=v963;
}
const v964=({["value"]:v957,["tangent"]:v958});
const v966=110;
const v967=({["value"]:v608,["tangent"]:v614});
const v968=10;
const v969=(((v966) + (v968)) >>> 0);
const v970=__fn20(v967,v609,v617,v969);
let v971=v970["value"];
let v972=v970["tangent"];
for(let v974=0;v974<10;v974++){
const v975=(v974>>>0);
const v976=({["value"]:v971,["tangent"]:v972});
const v977=({["value"]:v608,["tangent"]:v614});
const v978=(((v966) + (v975)) >>> 0);
const v979=__fn20(v977,v609,v617,v978);
const v980=10;
const v981=(Math.imul(v613,v980) >>> 0);
const v982=(((v981) + (v975)) >>> 0);
let v983;if(v982<v637.length){v983=v637[v982];}else{
const v984=0.0;
const v985=0.0;
v983=({["value"]:v984,["tangent"]:v985});}
const v986=v983;
const v987=__fn17(v979,v986);
const v988=__fn21(v976,v987);
v971=v988["value"];
v972=v988["tangent"];
}
const v991=121;
const v992=({["value"]:v608,["tangent"]:v614});
const v993=10;
const v994=(((v991) + (v993)) >>> 0);
const v995=__fn20(v992,v609,v617,v994);
let v996=v995["value"];
let v997=v995["tangent"];
for(let v999=0;v999<10;v999++){
const v1000=(v999>>>0);
const v1001=({["value"]:v996,["tangent"]:v997});
const v1002=({["value"]:v608,["tangent"]:v614});
const v1003=(((v991) + (v1000)) >>> 0);
const v1004=__fn20(v1002,v609,v617,v1003);
const v1005=10;
const v1006=(Math.imul(v613,v1005) >>> 0);
const v1007=(((v1006) + (v1000)) >>> 0);
let v1008;if(v1007<v637.length){v1008=v637[v1007];}else{
const v1009=0.0;
const v1010=0.0;
v1008=({["value"]:v1009,["tangent"]:v1010});}
const v1011=v1008;
const v1012=__fn17(v1004,v1011);
const v1013=__fn21(v1001,v1012);
v996=v1013["value"];
v997=v1013["tangent"];
}
const v1015=__nfValue(v996);
const v1016=0.0;
const v1017=0.0;
const v1018=({["value"]:v1016,["tangent"]:v1017});
const v1019=__nfValue(v1018["value"]);
let v1020;
let v1021;
if(((__nfNumber(v1015)) > (__nfNumber(v1019)))){
const v1022=({["value"]:v971,["tangent"]:v972});
const v1023=({["value"]:v996,["tangent"]:v997});
const v1024=__fn17(v1022,v1023);
v1020=v1024["value"];
v1021=v1024["tangent"];
}else{
const v1025=0.0;
const v1026=0.0;
v1020=v1025;
v1021=v1026;
}
const v1027=({["value"]:v1020,["tangent"]:v1021});
const v1028=[v712,v775,v838,v901,v964,v1027];
const v1031=132;
const v1032=({["value"]:v608,["tangent"]:v614});
const v1033=6;
const v1034=(((v1031) + (v1033)) >>> 0);
const v1035=__fn20(v1032,v609,v617,v1034);
let v1036=v1035["value"];
let v1037=v1035["tangent"];
for(let v1039=0;v1039<6;v1039++){
const v1040=(v1039>>>0);
const v1041=({["value"]:v1036,["tangent"]:v1037});
const v1042=({["value"]:v608,["tangent"]:v614});
const v1043=(((v1031) + (v1040)) >>> 0);
const v1044=__fn20(v1042,v609,v617,v1043);
let v1045;if(v1040<v1028.length){v1045=v1028[v1040];}else{
const v1046=0.0;
const v1047=0.0;
v1045=({["value"]:v1046,["tangent"]:v1047});}
const v1048=v1045;
const v1049=__fn17(v1044,v1048);
const v1050=__fn21(v1041,v1049);
v1036=v1050["value"];
v1037=v1050["tangent"];
}
const v1053=139;
const v1054=({["value"]:v608,["tangent"]:v614});
const v1055=6;
const v1056=(((v1053) + (v1055)) >>> 0);
const v1057=__fn20(v1054,v609,v617,v1056);
let v1058=v1057["value"];
let v1059=v1057["tangent"];
for(let v1061=0;v1061<6;v1061++){
const v1062=(v1061>>>0);
const v1063=({["value"]:v1058,["tangent"]:v1059});
const v1064=({["value"]:v608,["tangent"]:v614});
const v1065=(((v1053) + (v1062)) >>> 0);
const v1066=__fn20(v1064,v609,v617,v1065);
let v1067;if(v1062<v1028.length){v1067=v1028[v1062];}else{
const v1068=0.0;
const v1069=0.0;
v1067=({["value"]:v1068,["tangent"]:v1069});}
const v1070=v1067;
const v1071=__fn17(v1066,v1070);
const v1072=__fn21(v1063,v1071);
v1058=v1072["value"];
v1059=v1072["tangent"];
}
const v1074=__nfValue(v1058);
const v1075=0.0;
const v1076=0.0;
const v1077=({["value"]:v1075,["tangent"]:v1076});
const v1078=__nfValue(v1077["value"]);
let v1079;
let v1080;
if(((__nfNumber(v1074)) > (__nfNumber(v1078)))){
const v1081=({["value"]:v1036,["tangent"]:v1037});
const v1082=({["value"]:v1058,["tangent"]:v1059});
const v1083=__fn17(v1081,v1082);
v1079=v1083["value"];
v1080=v1083["tangent"];
}else{
const v1084=0.0;
const v1085=0.0;
v1079=v1084;
v1080=v1085;
}
const v1086=({["value"]:v1079,["tangent"]:v1080});
const v1088=146;
const v1089=({["value"]:v608,["tangent"]:v614});
const v1090=6;
const v1091=(((v1088) + (v1090)) >>> 0);
const v1092=__fn20(v1089,v609,v617,v1091);
let v1093=v1092["value"];
let v1094=v1092["tangent"];
for(let v1096=0;v1096<6;v1096++){
const v1097=(v1096>>>0);
const v1098=({["value"]:v1093,["tangent"]:v1094});
const v1099=({["value"]:v608,["tangent"]:v614});
const v1100=(((v1088) + (v1097)) >>> 0);
const v1101=__fn20(v1099,v609,v617,v1100);
let v1102;if(v1097<v1028.length){v1102=v1028[v1097];}else{
const v1103=0.0;
const v1104=0.0;
v1102=({["value"]:v1103,["tangent"]:v1104});}
const v1105=v1102;
const v1106=__fn17(v1101,v1105);
const v1107=__fn21(v1098,v1106);
v1093=v1107["value"];
v1094=v1107["tangent"];
}
const v1110=153;
const v1111=({["value"]:v608,["tangent"]:v614});
const v1112=6;
const v1113=(((v1110) + (v1112)) >>> 0);
const v1114=__fn20(v1111,v609,v617,v1113);
let v1115=v1114["value"];
let v1116=v1114["tangent"];
for(let v1118=0;v1118<6;v1118++){
const v1119=(v1118>>>0);
const v1120=({["value"]:v1115,["tangent"]:v1116});
const v1121=({["value"]:v608,["tangent"]:v614});
const v1122=(((v1110) + (v1119)) >>> 0);
const v1123=__fn20(v1121,v609,v617,v1122);
let v1124;if(v1119<v1028.length){v1124=v1028[v1119];}else{
const v1125=0.0;
const v1126=0.0;
v1124=({["value"]:v1125,["tangent"]:v1126});}
const v1127=v1124;
const v1128=__fn17(v1123,v1127);
const v1129=__fn21(v1120,v1128);
v1115=v1129["value"];
v1116=v1129["tangent"];
}
const v1131=__nfValue(v1115);
const v1132=0.0;
const v1133=0.0;
const v1134=({["value"]:v1132,["tangent"]:v1133});
const v1135=__nfValue(v1134["value"]);
let v1136;
let v1137;
if(((__nfNumber(v1131)) > (__nfNumber(v1135)))){
const v1138=({["value"]:v1093,["tangent"]:v1094});
const v1139=({["value"]:v1115,["tangent"]:v1116});
const v1140=__fn17(v1138,v1139);
v1136=v1140["value"];
v1137=v1140["tangent"];
}else{
const v1141=0.0;
const v1142=0.0;
v1136=v1141;
v1137=v1142;
}
const v1143=({["value"]:v1136,["tangent"]:v1137});
const v1145=160;
const v1146=({["value"]:v608,["tangent"]:v614});
const v1147=6;
const v1148=(((v1145) + (v1147)) >>> 0);
const v1149=__fn20(v1146,v609,v617,v1148);
let v1150=v1149["value"];
let v1151=v1149["tangent"];
for(let v1153=0;v1153<6;v1153++){
const v1154=(v1153>>>0);
const v1155=({["value"]:v1150,["tangent"]:v1151});
const v1156=({["value"]:v608,["tangent"]:v614});
const v1157=(((v1145) + (v1154)) >>> 0);
const v1158=__fn20(v1156,v609,v617,v1157);
let v1159;if(v1154<v1028.length){v1159=v1028[v1154];}else{
const v1160=0.0;
const v1161=0.0;
v1159=({["value"]:v1160,["tangent"]:v1161});}
const v1162=v1159;
const v1163=__fn17(v1158,v1162);
const v1164=__fn21(v1155,v1163);
v1150=v1164["value"];
v1151=v1164["tangent"];
}
const v1167=167;
const v1168=({["value"]:v608,["tangent"]:v614});
const v1169=6;
const v1170=(((v1167) + (v1169)) >>> 0);
const v1171=__fn20(v1168,v609,v617,v1170);
let v1172=v1171["value"];
let v1173=v1171["tangent"];
for(let v1175=0;v1175<6;v1175++){
const v1176=(v1175>>>0);
const v1177=({["value"]:v1172,["tangent"]:v1173});
const v1178=({["value"]:v608,["tangent"]:v614});
const v1179=(((v1167) + (v1176)) >>> 0);
const v1180=__fn20(v1178,v609,v617,v1179);
let v1181;if(v1176<v1028.length){v1181=v1028[v1176];}else{
const v1182=0.0;
const v1183=0.0;
v1181=({["value"]:v1182,["tangent"]:v1183});}
const v1184=v1181;
const v1185=__fn17(v1180,v1184);
const v1186=__fn21(v1177,v1185);
v1172=v1186["value"];
v1173=v1186["tangent"];
}
const v1188=__nfValue(v1172);
const v1189=0.0;
const v1190=0.0;
const v1191=({["value"]:v1189,["tangent"]:v1190});
const v1192=__nfValue(v1191["value"]);
let v1193;
let v1194;
if(((__nfNumber(v1188)) > (__nfNumber(v1192)))){
const v1195=({["value"]:v1150,["tangent"]:v1151});
const v1196=({["value"]:v1172,["tangent"]:v1173});
const v1197=__fn17(v1195,v1196);
v1193=v1197["value"];
v1194=v1197["tangent"];
}else{
const v1198=0.0;
const v1199=0.0;
v1193=v1198;
v1194=v1199;
}
const v1200=({["value"]:v1193,["tangent"]:v1194});
const v1202=174;
const v1203=({["value"]:v608,["tangent"]:v614});
const v1204=6;
const v1205=(((v1202) + (v1204)) >>> 0);
const v1206=__fn20(v1203,v609,v617,v1205);
let v1207=v1206["value"];
let v1208=v1206["tangent"];
for(let v1210=0;v1210<6;v1210++){
const v1211=(v1210>>>0);
const v1212=({["value"]:v1207,["tangent"]:v1208});
const v1213=({["value"]:v608,["tangent"]:v614});
const v1214=(((v1202) + (v1211)) >>> 0);
const v1215=__fn20(v1213,v609,v617,v1214);
let v1216;if(v1211<v1028.length){v1216=v1028[v1211];}else{
const v1217=0.0;
const v1218=0.0;
v1216=({["value"]:v1217,["tangent"]:v1218});}
const v1219=v1216;
const v1220=__fn17(v1215,v1219);
const v1221=__fn21(v1212,v1220);
v1207=v1221["value"];
v1208=v1221["tangent"];
}
const v1224=181;
const v1225=({["value"]:v608,["tangent"]:v614});
const v1226=6;
const v1227=(((v1224) + (v1226)) >>> 0);
const v1228=__fn20(v1225,v609,v617,v1227);
let v1229=v1228["value"];
let v1230=v1228["tangent"];
for(let v1232=0;v1232<6;v1232++){
const v1233=(v1232>>>0);
const v1234=({["value"]:v1229,["tangent"]:v1230});
const v1235=({["value"]:v608,["tangent"]:v614});
const v1236=(((v1224) + (v1233)) >>> 0);
const v1237=__fn20(v1235,v609,v617,v1236);
let v1238;if(v1233<v1028.length){v1238=v1028[v1233];}else{
const v1239=0.0;
const v1240=0.0;
v1238=({["value"]:v1239,["tangent"]:v1240});}
const v1241=v1238;
const v1242=__fn17(v1237,v1241);
const v1243=__fn21(v1234,v1242);
v1229=v1243["value"];
v1230=v1243["tangent"];
}
const v1245=__nfValue(v1229);
const v1246=0.0;
const v1247=0.0;
const v1248=({["value"]:v1246,["tangent"]:v1247});
const v1249=__nfValue(v1248["value"]);
let v1250;
let v1251;
if(((__nfNumber(v1245)) > (__nfNumber(v1249)))){
const v1252=({["value"]:v1207,["tangent"]:v1208});
const v1253=({["value"]:v1229,["tangent"]:v1230});
const v1254=__fn17(v1252,v1253);
v1250=v1254["value"];
v1251=v1254["tangent"];
}else{
const v1255=0.0;
const v1256=0.0;
v1250=v1255;
v1251=v1256;
}
const v1257=({["value"]:v1250,["tangent"]:v1251});
const v1259=188;
const v1260=({["value"]:v608,["tangent"]:v614});
const v1261=6;
const v1262=(((v1259) + (v1261)) >>> 0);
const v1263=__fn20(v1260,v609,v617,v1262);
let v1264=v1263["value"];
let v1265=v1263["tangent"];
for(let v1267=0;v1267<6;v1267++){
const v1268=(v1267>>>0);
const v1269=({["value"]:v1264,["tangent"]:v1265});
const v1270=({["value"]:v608,["tangent"]:v614});
const v1271=(((v1259) + (v1268)) >>> 0);
const v1272=__fn20(v1270,v609,v617,v1271);
let v1273;if(v1268<v1028.length){v1273=v1028[v1268];}else{
const v1274=0.0;
const v1275=0.0;
v1273=({["value"]:v1274,["tangent"]:v1275});}
const v1276=v1273;
const v1277=__fn17(v1272,v1276);
const v1278=__fn21(v1269,v1277);
v1264=v1278["value"];
v1265=v1278["tangent"];
}
const v1281=195;
const v1282=({["value"]:v608,["tangent"]:v614});
const v1283=6;
const v1284=(((v1281) + (v1283)) >>> 0);
const v1285=__fn20(v1282,v609,v617,v1284);
let v1286=v1285["value"];
let v1287=v1285["tangent"];
for(let v1289=0;v1289<6;v1289++){
const v1290=(v1289>>>0);
const v1291=({["value"]:v1286,["tangent"]:v1287});
const v1292=({["value"]:v608,["tangent"]:v614});
const v1293=(((v1281) + (v1290)) >>> 0);
const v1294=__fn20(v1292,v609,v617,v1293);
let v1295;if(v1290<v1028.length){v1295=v1028[v1290];}else{
const v1296=0.0;
const v1297=0.0;
v1295=({["value"]:v1296,["tangent"]:v1297});}
const v1298=v1295;
const v1299=__fn17(v1294,v1298);
const v1300=__fn21(v1291,v1299);
v1286=v1300["value"];
v1287=v1300["tangent"];
}
const v1302=__nfValue(v1286);
const v1303=0.0;
const v1304=0.0;
const v1305=({["value"]:v1303,["tangent"]:v1304});
const v1306=__nfValue(v1305["value"]);
let v1307;
let v1308;
if(((__nfNumber(v1302)) > (__nfNumber(v1306)))){
const v1309=({["value"]:v1264,["tangent"]:v1265});
const v1310=({["value"]:v1286,["tangent"]:v1287});
const v1311=__fn17(v1309,v1310);
v1307=v1311["value"];
v1308=v1311["tangent"];
}else{
const v1312=0.0;
const v1313=0.0;
v1307=v1312;
v1308=v1313;
}
const v1314=({["value"]:v1307,["tangent"]:v1308});
const v1316=202;
const v1317=({["value"]:v608,["tangent"]:v614});
const v1318=6;
const v1319=(((v1316) + (v1318)) >>> 0);
const v1320=__fn20(v1317,v609,v617,v1319);
let v1321=v1320["value"];
let v1322=v1320["tangent"];
for(let v1324=0;v1324<6;v1324++){
const v1325=(v1324>>>0);
const v1326=({["value"]:v1321,["tangent"]:v1322});
const v1327=({["value"]:v608,["tangent"]:v614});
const v1328=(((v1316) + (v1325)) >>> 0);
const v1329=__fn20(v1327,v609,v617,v1328);
let v1330;if(v1325<v1028.length){v1330=v1028[v1325];}else{
const v1331=0.0;
const v1332=0.0;
v1330=({["value"]:v1331,["tangent"]:v1332});}
const v1333=v1330;
const v1334=__fn17(v1329,v1333);
const v1335=__fn21(v1326,v1334);
v1321=v1335["value"];
v1322=v1335["tangent"];
}
const v1338=209;
const v1339=({["value"]:v608,["tangent"]:v614});
const v1340=6;
const v1341=(((v1338) + (v1340)) >>> 0);
const v1342=__fn20(v1339,v609,v617,v1341);
let v1343=v1342["value"];
let v1344=v1342["tangent"];
for(let v1346=0;v1346<6;v1346++){
const v1347=(v1346>>>0);
const v1348=({["value"]:v1343,["tangent"]:v1344});
const v1349=({["value"]:v608,["tangent"]:v614});
const v1350=(((v1338) + (v1347)) >>> 0);
const v1351=__fn20(v1349,v609,v617,v1350);
let v1352;if(v1347<v1028.length){v1352=v1028[v1347];}else{
const v1353=0.0;
const v1354=0.0;
v1352=({["value"]:v1353,["tangent"]:v1354});}
const v1355=v1352;
const v1356=__fn17(v1351,v1355);
const v1357=__fn21(v1348,v1356);
v1343=v1357["value"];
v1344=v1357["tangent"];
}
const v1359=__nfValue(v1343);
const v1360=0.0;
const v1361=0.0;
const v1362=({["value"]:v1360,["tangent"]:v1361});
const v1363=__nfValue(v1362["value"]);
let v1364;
let v1365;
if(((__nfNumber(v1359)) > (__nfNumber(v1363)))){
const v1366=({["value"]:v1321,["tangent"]:v1322});
const v1367=({["value"]:v1343,["tangent"]:v1344});
const v1368=__fn17(v1366,v1367);
v1364=v1368["value"];
v1365=v1368["tangent"];
}else{
const v1369=0.0;
const v1370=0.0;
v1364=v1369;
v1365=v1370;
}
const v1371=({["value"]:v1364,["tangent"]:v1365});
const v1372=[v1086,v1143,v1200,v1257,v1314,v1371];
const v1374=216;
const v1376=6;
const v1377=(((v1374) + (v1376)) >>> 0);
let v1378;
let v1379;
if((v609===v1377)){
v1378=v608;
v1379=v614;
}else{
let v1380;if(v1377<v617.length){v1380=v617[v1377];}else{
v1380=__fn19();}
const v1381=v1380;
const v1382=v1381["value"];
v1378=v1382["value"];
v1379=v1382["tangent"];
}
let v1384=v1378;
let v1385=v1379;
for(let v1387=0;v1387<6;v1387++){
const v1388=(v1387>>>0);
const v1391=(((v1374) + (v1388)) >>> 0);
let v1392;
let v1393;
if((v609===v1391)){
v1392=v608;
v1393=v614;
}else{
let v1394;if(v1391<v617.length){v1394=v617[v1391];}else{
v1394=__fn19();}
const v1395=v1394;
const v1396=v1395["value"];
v1392=v1396["value"];
v1393=v1396["tangent"];
}
let v1398;if(v1388<v1372.length){v1398=v1372[v1388];}else{
const v1399=0.0;
const v1400=0.0;
v1398=({["value"]:v1399,["tangent"]:v1400});}
const v1401=v1398;
const v1402=__nfValue(v1392);
const v1403=__nfValue(v1401["value"]);
const v1404=Math.fround(__nfNumber(v1402) * __nfNumber(v1403));
const v1405=__nfValue(v1393);
const v1406=__nfValue(v1401["value"]);
const v1407=Math.fround(__nfNumber(v1405) * __nfNumber(v1406));
const v1408=__nfValue(v1392);
const v1409=__nfValue(v1401["tangent"]);
const v1410=Math.fround(__nfNumber(v1408) * __nfNumber(v1409));
const v1411=Math.fround(v1407 + v1410);
const v1413=__nfValue(v1384);
const v1414=Math.fround(__nfNumber(v1413) + v1404);
const v1415=__nfValue(v1385);
const v1416=Math.fround(__nfNumber(v1415) + v1411);
v1384=v1414;
v1385=v1416;
}
const v1417=({["value"]:v1384,["tangent"]:v1385});
const v1419=223;
const v1421=6;
const v1422=(((v1419) + (v1421)) >>> 0);
let v1423;
let v1424;
if((v609===v1422)){
v1423=v608;
v1424=v614;
}else{
let v1425;if(v1422<v617.length){v1425=v617[v1422];}else{
v1425=__fn19();}
const v1426=v1425;
const v1427=v1426["value"];
v1423=v1427["value"];
v1424=v1427["tangent"];
}
let v1429=v1423;
let v1430=v1424;
for(let v1432=0;v1432<6;v1432++){
const v1433=(v1432>>>0);
const v1436=(((v1419) + (v1433)) >>> 0);
let v1437;
let v1438;
if((v609===v1436)){
v1437=v608;
v1438=v614;
}else{
let v1439;if(v1436<v617.length){v1439=v617[v1436];}else{
v1439=__fn19();}
const v1440=v1439;
const v1441=v1440["value"];
v1437=v1441["value"];
v1438=v1441["tangent"];
}
let v1443;if(v1433<v1372.length){v1443=v1372[v1433];}else{
const v1444=0.0;
const v1445=0.0;
v1443=({["value"]:v1444,["tangent"]:v1445});}
const v1446=v1443;
const v1447=__nfValue(v1437);
const v1448=__nfValue(v1446["value"]);
const v1449=Math.fround(__nfNumber(v1447) * __nfNumber(v1448));
const v1450=__nfValue(v1438);
const v1451=__nfValue(v1446["value"]);
const v1452=Math.fround(__nfNumber(v1450) * __nfNumber(v1451));
const v1453=__nfValue(v1437);
const v1454=__nfValue(v1446["tangent"]);
const v1455=Math.fround(__nfNumber(v1453) * __nfNumber(v1454));
const v1456=Math.fround(v1452 + v1455);
const v1458=__nfValue(v1429);
const v1459=Math.fround(__nfNumber(v1458) + v1449);
const v1460=__nfValue(v1430);
const v1461=Math.fround(__nfNumber(v1460) + v1456);
v1429=v1459;
v1430=v1461;
}
const v1462=({["value"]:v1429,["tangent"]:v1430});
const v1464=230;
const v1466=6;
const v1467=(((v1464) + (v1466)) >>> 0);
let v1468;
let v1469;
if((v609===v1467)){
v1468=v608;
v1469=v614;
}else{
let v1470;if(v1467<v617.length){v1470=v617[v1467];}else{
v1470=__fn19();}
const v1471=v1470;
const v1472=v1471["value"];
v1468=v1472["value"];
v1469=v1472["tangent"];
}
let v1474=v1468;
let v1475=v1469;
for(let v1477=0;v1477<6;v1477++){
const v1478=(v1477>>>0);
const v1481=(((v1464) + (v1478)) >>> 0);
let v1482;
let v1483;
if((v609===v1481)){
v1482=v608;
v1483=v614;
}else{
let v1484;if(v1481<v617.length){v1484=v617[v1481];}else{
v1484=__fn19();}
const v1485=v1484;
const v1486=v1485["value"];
v1482=v1486["value"];
v1483=v1486["tangent"];
}
let v1488;if(v1478<v1372.length){v1488=v1372[v1478];}else{
const v1489=0.0;
const v1490=0.0;
v1488=({["value"]:v1489,["tangent"]:v1490});}
const v1491=v1488;
const v1492=__nfValue(v1482);
const v1493=__nfValue(v1491["value"]);
const v1494=Math.fround(__nfNumber(v1492) * __nfNumber(v1493));
const v1495=__nfValue(v1483);
const v1496=__nfValue(v1491["value"]);
const v1497=Math.fround(__nfNumber(v1495) * __nfNumber(v1496));
const v1498=__nfValue(v1482);
const v1499=__nfValue(v1491["tangent"]);
const v1500=Math.fround(__nfNumber(v1498) * __nfNumber(v1499));
const v1501=Math.fround(v1497 + v1500);
const v1503=__nfValue(v1474);
const v1504=Math.fround(__nfNumber(v1503) + v1494);
const v1505=__nfValue(v1475);
const v1506=Math.fround(__nfNumber(v1505) + v1501);
v1474=v1504;
v1475=v1506;
}
const v1507=({["value"]:v1474,["tangent"]:v1475});
const v1509=237;
const v1511=6;
const v1512=(((v1509) + (v1511)) >>> 0);
let v1513;
let v1514;
if((v609===v1512)){
v1513=v608;
v1514=v614;
}else{
let v1515;if(v1512<v617.length){v1515=v617[v1512];}else{
v1515=__fn19();}
const v1516=v1515;
const v1517=v1516["value"];
v1513=v1517["value"];
v1514=v1517["tangent"];
}
let v1519=v1513;
let v1520=v1514;
for(let v1522=0;v1522<6;v1522++){
const v1523=(v1522>>>0);
const v1526=(((v1509) + (v1523)) >>> 0);
let v1527;
let v1528;
if((v609===v1526)){
v1527=v608;
v1528=v614;
}else{
let v1529;if(v1526<v617.length){v1529=v617[v1526];}else{
v1529=__fn19();}
const v1530=v1529;
const v1531=v1530["value"];
v1527=v1531["value"];
v1528=v1531["tangent"];
}
let v1533;if(v1523<v1372.length){v1533=v1372[v1523];}else{
const v1534=0.0;
const v1535=0.0;
v1533=({["value"]:v1534,["tangent"]:v1535});}
const v1536=v1533;
const v1537=__nfValue(v1527);
const v1538=__nfValue(v1536["value"]);
const v1539=Math.fround(__nfNumber(v1537) * __nfNumber(v1538));
const v1540=__nfValue(v1528);
const v1541=__nfValue(v1536["value"]);
const v1542=Math.fround(__nfNumber(v1540) * __nfNumber(v1541));
const v1543=__nfValue(v1527);
const v1544=__nfValue(v1536["tangent"]);
const v1545=Math.fround(__nfNumber(v1543) * __nfNumber(v1544));
const v1546=Math.fround(v1542 + v1545);
const v1548=__nfValue(v1519);
const v1549=Math.fround(__nfNumber(v1548) + v1539);
const v1550=__nfValue(v1520);
const v1551=Math.fround(__nfNumber(v1550) + v1546);
v1519=v1549;
v1520=v1551;
}
const v1552=({["value"]:v1519,["tangent"]:v1520});
const v1553=[v1417,v1462,v1507,v1552];
const v1554=0.0;
const v1555=0.0;
let v1556=v1554;
let v1557=v1555;
for(let v1559=0;v1559<4;v1559++){
const v1560=(v1559>>>0);
let v1562;if(v1560<v1553.length){v1562=v1553[v1560];}else{
const v1563=0.0;
const v1564=0.0;
v1562=({["value"]:v1563,["tangent"]:v1564});}
const v1565=v1562;
const v1566=4;
const v1567=(Math.imul(v613,v1566) >>> 0);
const v1568=(((v1567) + (v1560)) >>> 0);
let v1569;if(v1568<v643.length){v1569=v643[v1568];}else{
const v1570=0.0;
const v1571=0.0;
v1569=({["value"]:v1570,["tangent"]:v1571});}
const v1572=v1569;
const v1573=__fn28(v1565,v1572);
const v1574=__nfValue(v1556);
const v1575=__nfValue(v1573["value"]);
const v1576=Math.fround(__nfNumber(v1574) + __nfNumber(v1575));
const v1577=__nfValue(v1557);
const v1578=__nfValue(v1573["tangent"]);
const v1579=Math.fround(__nfNumber(v1577) + __nfNumber(v1578));
v1556=v1576;
v1557=v1579;
}
const v1582=4.0;
const v1583=0.0;
const v1585=Math.fround((__nfNumber(__nfValue(v1556)))/(__nfNumber(v1582)));
const v1586=__nfValue(v1557);
const v1587=Math.fround(__nfNumber(v1586) * v1582);
const v1588=__nfValue(v1556);
const v1589=Math.fround(__nfNumber(v1588) * v1583);
const v1590=Math.fround((__nfNumber(Math.fround(v1587 - v1589)))/(__nfNumber(Math.fround(v1582 * v1582))));
return v1590;}
function __into5(v1592,v1593,v1594,v1595,v1596,v1597){
v1592=__nfValue(v1592);
const v1598=0;
const v1599=__fn3(v1592,v1593,v1594,v1595,v1596,v1598);
const v1600=11;
const v1601=__fn3(v1592,v1593,v1594,v1595,v1596,v1600);
const v1602=__fn2(v1599,v1601);
const v1603=22;
const v1604=__fn3(v1592,v1593,v1594,v1595,v1596,v1603);
const v1605=33;
const v1606=__fn3(v1592,v1593,v1594,v1595,v1596,v1605);
const v1607=__fn2(v1604,v1606);
const v1608=44;
const v1609=__fn3(v1592,v1593,v1594,v1595,v1596,v1608);
const v1610=55;
const v1611=__fn3(v1592,v1593,v1594,v1595,v1596,v1610);
const v1612=__fn2(v1609,v1611);
const v1613=66;
const v1614=__fn3(v1592,v1593,v1594,v1595,v1596,v1613);
const v1615=77;
const v1616=__fn3(v1592,v1593,v1594,v1595,v1596,v1615);
const v1617=__fn2(v1614,v1616);
const v1618=88;
const v1619=__fn3(v1592,v1593,v1594,v1595,v1596,v1618);
const v1620=99;
const v1621=__fn3(v1592,v1593,v1594,v1595,v1596,v1620);
const v1622=__fn2(v1619,v1621);
const v1623=110;
const v1624=__fn3(v1592,v1593,v1594,v1595,v1596,v1623);
const v1625=121;
const v1626=__fn3(v1592,v1593,v1594,v1595,v1596,v1625);
const v1627=__fn2(v1624,v1626);
const v1628=[v1602,v1607,v1612,v1617,v1622,v1627];
const v1629=v1628.length;
for(let v1630=0;v1630<v1629;v1630++){
v1597[v1630]=__intoOutput5(v1628[v1630]);
}
return v1629;}
function __into6(v1631,v1632,v1633,v1634,v1635){
v1631=__nfValue(v1631);
const v1636=132;
const v1637=__fn4(v1631,v1632,v1633,v1634,v1636);
const v1638=139;
const v1639=__fn4(v1631,v1632,v1633,v1634,v1638);
const v1640=__fn2(v1637,v1639);
const v1641=146;
const v1642=__fn4(v1631,v1632,v1633,v1634,v1641);
const v1643=153;
const v1644=__fn4(v1631,v1632,v1633,v1634,v1643);
const v1645=__fn2(v1642,v1644);
const v1646=160;
const v1647=__fn4(v1631,v1632,v1633,v1634,v1646);
const v1648=167;
const v1649=__fn4(v1631,v1632,v1633,v1634,v1648);
const v1650=__fn2(v1647,v1649);
const v1651=174;
const v1652=__fn4(v1631,v1632,v1633,v1634,v1651);
const v1653=181;
const v1654=__fn4(v1631,v1632,v1633,v1634,v1653);
const v1655=__fn2(v1652,v1654);
const v1656=188;
const v1657=__fn4(v1631,v1632,v1633,v1634,v1656);
const v1658=195;
const v1659=__fn4(v1631,v1632,v1633,v1634,v1658);
const v1660=__fn2(v1657,v1659);
const v1661=202;
const v1662=__fn4(v1631,v1632,v1633,v1634,v1661);
const v1663=209;
const v1664=__fn4(v1631,v1632,v1633,v1634,v1663);
const v1665=__fn2(v1662,v1664);
const v1666=[v1640,v1645,v1650,v1655,v1660,v1665];
const v1667=v1666.length;
for(let v1668=0;v1668<v1667;v1668++){
v1635[v1668]=__intoOutput6(v1666[v1668]);
}
return v1667;}
function __into7(v1669,v1670,v1671,v1672,v1673,v1674){
v1669=__nfValue(v1669);
const v1675=__fn5(v1669,v1670,v1671,v1672,v1673);
const v1676=__fn6(v1669,v1670,v1671,v1675);
const v1677=216;
const v1678=__fn4(v1669,v1670,v1671,v1676,v1677);
const v1679=223;
const v1680=__fn4(v1669,v1670,v1671,v1676,v1679);
const v1681=230;
const v1682=__fn4(v1669,v1670,v1671,v1676,v1681);
const v1683=237;
const v1684=__fn4(v1669,v1670,v1671,v1676,v1683);
const v1685=[v1678,v1680,v1682,v1684];
const v1686=v1685.length;
for(let v1687=0;v1687<v1686;v1687++){
v1674[v1687]=__intoOutput7(v1685[v1687]);
}
return v1686;}
function __into10(v1688,v1689,v1690,v1691,v1692){
const v1693=(v1691).length;
const v1694=0;
let v1695;if((v1693===v1694)){
const v1696=v1688.length;
for(let v1698=0;v1698<v1696;v1698++){
const v1699=v1688[v1698];
v1692[v1698]=__intoOutput10(0.0);
}
v1695=v1696;}else{
const v1700=v1688.length;
for(let v1702=0;v1702<v1700;v1702++){
const v1703=v1688[v1702];
const v1704=(v1702>>>0);
let v1705=0.0;
for(let v1706=0;v1706<v1691.length;v1706++){
const v1707=(v1691[v1706]>>>0);
const v1708=v1705;
const v1709=__nfValue(v1703["value"]);
const v1710=__fn31(v1709,v1704,v1688,v1689,v1690,v1707);
v1705=Math.fround(__nfNumber(v1708) + __nfNumber(v1710));
}
v1692[v1702]=__intoOutput10(Math.fround((__nfNumber(v1705))/(__nfNumber(Math.fround((v1691).length)))));
}
v1695=v1700;}
return v1695;}
function __into15(v1711,v1712,v1713,v1714,v1715){
const v1716=false;
const v1717=(v1713===v1716);
let v1718=v1717;if(!v1718){
const v1719=__fn13(v1714);
const v1720=false;
v1718=(v1719===v1720);}
const v1721=v1718;
let v1722=v1721;if(!v1722){
const v1723=(v1712).length;
const v1724=(v1711).length;
v1722=!(v1723===v1724);}
const v1725=v1722;
let v1726=v1725;if(!v1726){
let v1727=true;
for(let v1728=0;v1728<v1711.length;v1728++){
const v1729=v1711[v1728];
const v1730=v1727;
let v1731=v1730;if(v1731){
v1731=__fn12(v1729);}
v1727=v1731;
}
const v1732=v1727;
const v1733=false;
v1726=(v1732===v1733);}
let v1734;if(v1726){
const v1735=v1711.length;
for(let v1736=0;v1736<v1735;v1736++){
v1715[v1736]=__intoOutput15(v1711[v1736]);
}
v1734=v1735;}else{
const v1737=v1711.length;
const v1738=new Array(v1737);
for(let v1739=0;v1739<v1737;v1739++){
const v1740=v1711[v1739];
const v1741=(v1739>>>0);
let v1742;if(v1741<v1712.length){v1742=v1712[v1741];}else{
v1742=0.0;}
const v1743=__nfValue(v1742);
v1738[v1739]=__fn11(v1740,v1743,v1714);
}
let v1744=true;
for(let v1745=0;v1745<v1738.length;v1745++){
const v1746=v1738[v1745];
const v1747=v1744;
let v1748=v1747;if(v1748){
v1748=__fn12(v1746);}
v1744=v1748;
}
let v1749;if(v1744){
const v1750=v1738.length;
for(let v1751=0;v1751<v1750;v1751++){
v1715[v1751]=__intoOutput15(v1738[v1751]);
}
v1749=v1750;}else{
const v1752=v1711.length;
for(let v1753=0;v1753<v1752;v1753++){
v1715[v1753]=__intoOutput15(v1711[v1753]);
}
v1749=v1752;}
v1734=v1749;}
return v1734;}
function __into16(v1754,v1755,v1756,v1757,v1758){
const v1759=v1757.length;
for(let v1761=0;v1761<v1759;v1761++){
const v1762=(v1757[v1761]>>>0);
const v1763=0.0;
const v1764=4294967295;
v1758[v1761]=__intoOutput16(__fn9(v1763,v1764,v1754,v1755,v1756,v1762));
}
return v1759;}
function __into23(v1765,v1766,v1767,v1768,v1769,v1770){
const v1771=0;
const v1772=__fn22(v1765,v1766,v1767,v1768,v1769,v1771);
const v1773=11;
const v1774=__fn22(v1765,v1766,v1767,v1768,v1769,v1773);
const v1775=__fn18(v1772,v1774);
const v1776=22;
const v1777=__fn22(v1765,v1766,v1767,v1768,v1769,v1776);
const v1778=33;
const v1779=__fn22(v1765,v1766,v1767,v1768,v1769,v1778);
const v1780=__fn18(v1777,v1779);
const v1781=44;
const v1782=__fn22(v1765,v1766,v1767,v1768,v1769,v1781);
const v1783=55;
const v1784=__fn22(v1765,v1766,v1767,v1768,v1769,v1783);
const v1785=__fn18(v1782,v1784);
const v1786=66;
const v1787=__fn22(v1765,v1766,v1767,v1768,v1769,v1786);
const v1788=77;
const v1789=__fn22(v1765,v1766,v1767,v1768,v1769,v1788);
const v1790=__fn18(v1787,v1789);
const v1791=88;
const v1792=__fn22(v1765,v1766,v1767,v1768,v1769,v1791);
const v1793=99;
const v1794=__fn22(v1765,v1766,v1767,v1768,v1769,v1793);
const v1795=__fn18(v1792,v1794);
const v1796=110;
const v1797=__fn22(v1765,v1766,v1767,v1768,v1769,v1796);
const v1798=121;
const v1799=__fn22(v1765,v1766,v1767,v1768,v1769,v1798);
const v1800=__fn18(v1797,v1799);
const v1801=[v1775,v1780,v1785,v1790,v1795,v1800];
const v1802=v1801.length;
for(let v1803=0;v1803<v1802;v1803++){
v1770[v1803]=__intoOutput23(v1801[v1803]);
}
return v1802;}
function __into25(v1804,v1805,v1806,v1807,v1808){
const v1809=132;
const v1810=__fn24(v1804,v1805,v1806,v1807,v1809);
const v1811=139;
const v1812=__fn24(v1804,v1805,v1806,v1807,v1811);
const v1813=__fn18(v1810,v1812);
const v1814=146;
const v1815=__fn24(v1804,v1805,v1806,v1807,v1814);
const v1816=153;
const v1817=__fn24(v1804,v1805,v1806,v1807,v1816);
const v1818=__fn18(v1815,v1817);
const v1819=160;
const v1820=__fn24(v1804,v1805,v1806,v1807,v1819);
const v1821=167;
const v1822=__fn24(v1804,v1805,v1806,v1807,v1821);
const v1823=__fn18(v1820,v1822);
const v1824=174;
const v1825=__fn24(v1804,v1805,v1806,v1807,v1824);
const v1826=181;
const v1827=__fn24(v1804,v1805,v1806,v1807,v1826);
const v1828=__fn18(v1825,v1827);
const v1829=188;
const v1830=__fn24(v1804,v1805,v1806,v1807,v1829);
const v1831=195;
const v1832=__fn24(v1804,v1805,v1806,v1807,v1831);
const v1833=__fn18(v1830,v1832);
const v1834=202;
const v1835=__fn24(v1804,v1805,v1806,v1807,v1834);
const v1836=209;
const v1837=__fn24(v1804,v1805,v1806,v1807,v1836);
const v1838=__fn18(v1835,v1837);
const v1839=[v1813,v1818,v1823,v1828,v1833,v1838];
const v1840=v1839.length;
for(let v1841=0;v1841<v1840;v1841++){
v1808[v1841]=__intoOutput25(v1839[v1841]);
}
return v1840;}
function __into26(v1842,v1843,v1844,v1845,v1846,v1847){
const v1848=__fn23(v1842,v1843,v1844,v1845,v1846);
const v1849=__fn25(v1842,v1843,v1844,v1848);
const v1850=216;
const v1851=__fn24(v1842,v1843,v1844,v1849,v1850);
const v1852=223;
const v1853=__fn24(v1842,v1843,v1844,v1849,v1852);
const v1854=230;
const v1855=__fn24(v1842,v1843,v1844,v1849,v1854);
const v1856=237;
const v1857=__fn24(v1842,v1843,v1844,v1849,v1856);
const v1858=[v1851,v1853,v1855,v1857];
const v1859=v1858.length;
for(let v1860=0;v1860<v1859;v1860++){
v1847[v1860]=__intoOutput26(v1858[v1860]);
}
return v1859;}
const __namedTypes={"Config":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"},"Parameter":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"__ink_differential_0":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"__ink_differential_3":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v11","core_sha256":"111ae91c4b69dd59d50a48766a158cdc01ad0dee55818344b80906bb64f73e64","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"f32_storage":"native-number-with-exact-nonfinite-tags","functions":[{"destination":null,"index":0,"internal":false,"name":"empty_parameter","parallel":false,"params":[],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}},{"destination":null,"index":1,"internal":false,"name":"parameter","parallel":false,"params":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"index","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":2,"internal":false,"name":"reglu","parallel":false,"params":[{"name":"value","type":{"kind":"f32"}},{"name":"gate","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":3,"internal":false,"name":"dot10","parallel":false,"params":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}},{"name":"base","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":4,"internal":false,"name":"dot6","parallel":false,"params":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"inputs","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"base","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":5,"internal":false,"name":"first_layer","parallel":false,"params":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":6,"internal":false,"name":"second_layer","parallel":false,"params":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"inputs","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":7,"internal":false,"name":"outputs","parallel":false,"params":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":8,"internal":false,"name":"squared_error","parallel":false,"params":[{"name":"prediction","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":9,"internal":false,"name":"objective","parallel":false,"params":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":10,"internal":false,"name":"gradients","parallel":false,"params":[{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"rows","type":{"element":{"kind":"u32"},"kind":"list"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":11,"internal":false,"name":"candidate","parallel":false,"params":[{"name":"p","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}},{"name":"g","type":{"kind":"f32"}},{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}},{"destination":null,"index":12,"internal":false,"name":"valid","parallel":false,"params":[{"name":"p","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":null,"index":13,"internal":false,"name":"configuration","parallel":false,"params":[{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":null,"index":14,"internal":false,"name":"shape","parallel":false,"params":[{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"rows","type":{"element":{"kind":"u32"},"kind":"list"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":15,"internal":false,"name":"update","parallel":false,"params":[{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"admissible","type":{"kind":"bool"}},{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}}],"precondition":null,"result":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":16,"internal":false,"name":"losses","parallel":false,"params":[{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"rows","type":{"element":{"kind":"u32"},"kind":"list"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":17,"internal":false,"name":"__ink_differential_7","parallel":false,"params":[{"name":"__ink_differential_8","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_9","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":18,"internal":false,"name":"__ink_differential_6","parallel":false,"params":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"gate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":19,"internal":false,"name":"__ink_differential_13","parallel":false,"params":[],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"}},{"destination":null,"index":20,"internal":false,"name":"__ink_differential_12","parallel":false,"params":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"index","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":21,"internal":false,"name":"__ink_differential_14","parallel":false,"params":[{"name":"__ink_differential_15","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_16","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":22,"internal":false,"name":"__ink_differential_11","parallel":false,"params":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}},{"name":"base","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":23,"internal":false,"name":"__ink_differential_5","parallel":false,"params":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"destination":null,"index":24,"internal":false,"name":"__ink_differential_19","parallel":false,"params":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"inputs","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"base","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":25,"internal":false,"name":"__ink_differential_18","parallel":false,"params":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"inputs","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}}],"precondition":null,"result":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":26,"internal":false,"name":"__ink_differential_4","parallel":false,"params":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"destination":null,"index":27,"internal":false,"name":"__ink_differential_21","parallel":false,"params":[{"name":"__ink_differential_22","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_23","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":28,"internal":false,"name":"__ink_differential_20","parallel":false,"params":[{"name":"prediction","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":29,"internal":false,"name":"__ink_differential_25","parallel":false,"params":[{"name":"__ink_differential_26","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_27","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":30,"internal":false,"name":"__ink_differential_2","parallel":false,"params":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"targets","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":31,"internal":false,"name":"__ink_differential_1","parallel":false,"params":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"f32"}}],"named_types":{"Config":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"},"Parameter":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"__ink_differential_0":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"__ink_differential_3":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"}},"prepared_compiled":{"evaluation":"lazy source-order; successful bindings only","functions":[{"factory":false,"function":"empty_parameter","reason":"no reusable captured work"},{"factory":false,"function":"parameter","reason":"no reusable captured work"},{"factory":false,"function":"reglu","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"dot10","retained_bindings":1},{"delegated_calls":0,"factory":true,"function":"dot6","retained_bindings":1},{"delegated_calls":12,"factory":true,"function":"first_layer","retained_bindings":0},{"delegated_calls":12,"factory":true,"function":"second_layer","retained_bindings":0},{"delegated_calls":6,"factory":true,"function":"outputs","retained_bindings":2},{"factory":false,"function":"squared_error","reason":"no reusable captured work"},{"delegated_calls":1,"factory":true,"function":"objective","retained_bindings":1},{"factory":false,"function":"gradients","reason":"no reusable captured work"},{"factory":false,"function":"candidate","reason":"no reusable captured work"},{"factory":false,"function":"valid","reason":"no reusable captured work"},{"factory":false,"function":"configuration","reason":"no reusable captured work"},{"factory":false,"function":"shape","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"update","retained_bindings":3},{"delegated_calls":1,"factory":true,"function":"losses","retained_bindings":0},{"factory":false,"function":"__ink_differential_7","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_6","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_13","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_12","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_14","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"__ink_differential_11","retained_bindings":1},{"delegated_calls":12,"factory":true,"function":"__ink_differential_5","retained_bindings":0},{"delegated_calls":0,"factory":true,"function":"__ink_differential_19","retained_bindings":1},{"delegated_calls":12,"factory":true,"function":"__ink_differential_18","retained_bindings":0},{"delegated_calls":6,"factory":true,"function":"__ink_differential_4","retained_bindings":2},{"factory":false,"function":"__ink_differential_21","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_20","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_25","reason":"no reusable captured work"},{"delegated_calls":1,"factory":true,"function":"__ink_differential_2","retained_bindings":2},{"delegated_calls":1,"factory":true,"function":"__ink_differential_1","retained_bindings":1}],"lifetime":"prepared token","semantics":"sealed-value-residual-v1"},"private_record_elisions":[],"private_sum_spines":[],"schema":1,"state":null,"wire":{"format":"ink-value-wire-v1","functions":{"__ink_differential_1":{"arguments":{"format":"ink-value-wire-v1","identity":"22549eae89e0dc6316436e0086e5bf18d8959fd0c3fae94f619a6d27d0451f7f","named":{},"root":{"fields":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"__ink_differential_11":{"arguments":{"format":"ink-value-wire-v1","identity":"d6cab0f5cb7ee4bfb3440531dbaa56b0fdc4937073092e6dbbbd1cdd7c4aa382","named":{},"root":{"fields":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}},{"name":"base","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_12":{"arguments":{"format":"ink-value-wire-v1","identity":"1f550c24187c484474301a9e9a869fd2214630de75d7c1d53b22de3f9683ac3d","named":{},"root":{"fields":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_13":{"arguments":{"format":"ink-value-wire-v1","identity":"3720cf83cb9a672c0c70e7f80cfe0abe0bf9b7df73d40a9def0c7436234026b2","named":{},"root":{"fields":[],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"bb1fd39ad8ae6c174bdc7c93bf326cea4848e5d07efb08ff6da1bad448ba9329","named":{},"root":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"}}},"__ink_differential_14":{"arguments":{"format":"ink-value-wire-v1","identity":"3ba898a3cfaf4bc347ed15914a0766b4d76b969b40e2173c5351b46e94344461","named":{},"root":{"fields":[{"name":"__ink_differential_15","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_16","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_18":{"arguments":{"format":"ink-value-wire-v1","identity":"f768b881f418ca4aaa3928806d68fb02afa1bc64fa779cad824441037ae17641","named":{},"root":{"fields":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"inputs","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"cdde982e98b457eca63f0b1f56713939bdd8ddf70f5be35e930642c404861714","named":{},"root":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}}},"__ink_differential_19":{"arguments":{"format":"ink-value-wire-v1","identity":"6f1f9ac7741dd39eaf4ffa402ac9ae4ee58f36e37f9554fefbb185516bf18592","named":{},"root":{"fields":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"inputs","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"base","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_2":{"arguments":{"format":"ink-value-wire-v1","identity":"9d8ff03a45c20596c31cd938ac529b84f7f68fc613f25f8986fb0a25b611fba1","named":{},"root":{"fields":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"targets","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_20":{"arguments":{"format":"ink-value-wire-v1","identity":"9fab172cda7ff8145656b68899c181a5f43d946e6bb3deda6393f520a7ff7847","named":{},"root":{"fields":[{"name":"prediction","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_21":{"arguments":{"format":"ink-value-wire-v1","identity":"05ad0fe40601b6501e611c63f42a4841be5e43468e274dc39e5865c5171ac268","named":{},"root":{"fields":[{"name":"__ink_differential_22","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_23","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_25":{"arguments":{"format":"ink-value-wire-v1","identity":"e9791254e476381294f0219e6a0102c02981994d8e2edc2d559be81a98c49caa","named":{},"root":{"fields":[{"name":"__ink_differential_26","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_27","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_4":{"arguments":{"format":"ink-value-wire-v1","identity":"4091e45a7ea55260f67482329c9b6b85d96a301a6b8ae619bb8f6a5ad8cd26f9","named":{},"root":{"fields":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"cdde982e98b457eca63f0b1f56713939bdd8ddf70f5be35e930642c404861714","named":{},"root":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}}},"__ink_differential_5":{"arguments":{"format":"ink-value-wire-v1","identity":"4091e45a7ea55260f67482329c9b6b85d96a301a6b8ae619bb8f6a5ad8cd26f9","named":{},"root":{"fields":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"cdde982e98b457eca63f0b1f56713939bdd8ddf70f5be35e930642c404861714","named":{},"root":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}}},"__ink_differential_6":{"arguments":{"format":"ink-value-wire-v1","identity":"31592dc92aec2c480ff896f14b6def755843fa745eda7741873860057a2e9c0d","named":{},"root":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"gate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_7":{"arguments":{"format":"ink-value-wire-v1","identity":"1eee11e978b643d01feacaa43d96c81a89b8bcb7d8406e53ac85d2a94730a633","named":{},"root":{"fields":[{"name":"__ink_differential_8","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_9","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"candidate":{"arguments":{"format":"ink-value-wire-v1","identity":"ccc16ee8f5974f4f8e95049e37b2e3bd4fbe769f0192c9a1a33745a7c1a6ebfe","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}},{"name":"g","type":{"kind":"f32"}},{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"7cd0db7bd067c6137d0451073ecc71755d81ac9dbc8526c5cda3a6cf0de894c3","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}}},"configuration":{"arguments":{"format":"ink-value-wire-v1","identity":"a0c1fcff287124f49ca5e0fa774ca7390e0c8ea561b4c2d377dbd09ba79e6309","named":{},"root":{"fields":[{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"dot10":{"arguments":{"format":"ink-value-wire-v1","identity":"37e273723f3f82d49a92eb9306a0319a0f80297ddaf4548f114502ec0b6cf6a6","named":{},"root":{"fields":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}},{"name":"base","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"dot6":{"arguments":{"format":"ink-value-wire-v1","identity":"feb8924860204cd016023b0b40f7ae444ddc86740d3a32cd79ecd1232c68d2f5","named":{},"root":{"fields":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"inputs","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"base","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"empty_parameter":{"arguments":{"format":"ink-value-wire-v1","identity":"3720cf83cb9a672c0c70e7f80cfe0abe0bf9b7df73d40a9def0c7436234026b2","named":{},"root":{"fields":[],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"7cd0db7bd067c6137d0451073ecc71755d81ac9dbc8526c5cda3a6cf0de894c3","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}}},"first_layer":{"arguments":{"format":"ink-value-wire-v1","identity":"dd445f0589a3aa37b6d0fb5f263058865bb606fbf648bd847d6a1e16d6bb3658","named":{},"root":{"fields":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"gradients":{"arguments":{"format":"ink-value-wire-v1","identity":"4f2033b1c433af3e1d797ea676ba7f9862c85cd25823d51f04e6335071354ff5","named":{},"root":{"fields":[{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"rows","type":{"element":{"kind":"u32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"losses":{"arguments":{"format":"ink-value-wire-v1","identity":"4f2033b1c433af3e1d797ea676ba7f9862c85cd25823d51f04e6335071354ff5","named":{},"root":{"fields":[{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"rows","type":{"element":{"kind":"u32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"objective":{"arguments":{"format":"ink-value-wire-v1","identity":"22549eae89e0dc6316436e0086e5bf18d8959fd0c3fae94f619a6d27d0451f7f","named":{},"root":{"fields":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"outputs":{"arguments":{"format":"ink-value-wire-v1","identity":"dd445f0589a3aa37b6d0fb5f263058865bb606fbf648bd847d6a1e16d6bb3658","named":{},"root":{"fields":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"parameter":{"arguments":{"format":"ink-value-wire-v1","identity":"278c77c1195ee8c9d8b1f990134b6cbb5a9552b5520fcc68351753085dc4c2ed","named":{},"root":{"fields":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"reglu":{"arguments":{"format":"ink-value-wire-v1","identity":"1fecec1fcd8fb7dce915abd77b22d39ebc89b17fc857eb01fd5abbbb2593cbfe","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gate","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"second_layer":{"arguments":{"format":"ink-value-wire-v1","identity":"582f9d9827718e12d6d47d61704695df375964b86cd9573316bd558e8a1bf99a","named":{},"root":{"fields":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"inputs","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"shape":{"arguments":{"format":"ink-value-wire-v1","identity":"4f2033b1c433af3e1d797ea676ba7f9862c85cd25823d51f04e6335071354ff5","named":{},"root":{"fields":[{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"rows","type":{"element":{"kind":"u32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"squared_error":{"arguments":{"format":"ink-value-wire-v1","identity":"643d934f13c916ac9fbe2b60b256ecabdb3dd59f0991c057d7366ad268222129","named":{},"root":{"fields":[{"name":"prediction","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"update":{"arguments":{"format":"ink-value-wire-v1","identity":"047325bab4732f3d0e00788b69015b016a512e9ebe7b4a3ef5389eee5b84ef8b","named":{},"root":{"fields":[{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"admissible","type":{"kind":"bool"}},{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"7e4dba74ea4a212e87b655db607b4b675c6150a5e6af015142def3ed7d7aa96c","named":{},"root":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}}},"valid":{"arguments":{"format":"ink-value-wire-v1","identity":"a611151880c9e23a958765b0cefc48481684963d56a3d7a8d388c827f6396d40","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}}}}};
const __implementations=[__fn0,__fn1,__fn2,__fn3,__fn4,__fn5,__fn6,__fn7,__fn8,__fn9,__fn10,__fn11,__fn12,__fn13,__fn14,__fn15,__fn16,__fn17,__fn18,__fn19,__fn20,__fn21,__fn22,__fn23,__fn24,__fn25,__fn26,__fn27,__fn28,__fn29,__fn30,__fn31];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
const __inputTypes=[{"capture":[],"types":[]},{"capture":[true,true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"kind":"u32"}]},{"capture":[true,true],"types":[{"kind":"f32"},{"kind":"f32"}]},{"capture":[true,true,true,true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"kind":"u32"},{"kind":"u32"}]},{"capture":[true,true,true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"kind":"u32"}]},{"capture":[true,true,true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"kind":"u32"}]},{"capture":[true,true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[true,true,true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"kind":"u32"}]},{"capture":[true,true],"types":[{"kind":"f32"},{"kind":"f32"}]},{"capture":[true,true,true,true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"kind":"u32"}]},{"capture":[false,true,true,true],"types":[{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"u32"},"kind":"list"}]},{"capture":[false,true,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},{"kind":"f32"},{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}]},{"capture":[false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}]},{"capture":[false],"types":[{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}]},{"capture":[false,true,true,true],"types":[{"element":{"fields":[],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"u32"},"kind":"list"}]},{"capture":[true,true,true,false],"types":[{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"kind":"bool"},{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}]},{"capture":[true,true,true,true],"types":[{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"u32"},"kind":"list"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[],"types":[]},{"capture":[true,true,true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"},{"kind":"u32"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[true,true,true,true,true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"},{"kind":"u32"},{"kind":"u32"}]},{"capture":[true,true,true,true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"},{"kind":"u32"}]},{"capture":[true,true,true,true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"},{"kind":"u32"}]},{"capture":[true,true,true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}]},{"capture":[true,true,true,true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"},{"kind":"u32"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[true,true,true,true,true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"},{"kind":"u32"}]},{"capture":[true,true,false,true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"kind":"u32"}]}];

// Descriptor work occurs once at module initialisation, never per word-list call.
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=> {
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const output=__representation(f.result,true);
  const body=__implementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
  const needsInput=input.some(c=>c!==__identity);
  const entry=!needsInput && output===__identity ? implementation :
    (...args)=>{const context=new WeakMap();return output(implementation(...(needsInput ? args.map((v,i)=>input[i](v,context)) : args)),context);};
  return [f.name,entry];
})));
export function call(name,args) { return functions[name](...args); }
// Shared bounded binary codec; generated code supplies exact descriptors.
export const valueWireFormat='ink-value-wire-v1';
// A connection agrees on the complete value schema before using this format.
// Version byte + schema-directed fields; schema identity is out of band.
export const compactValueWireFormat='ink-value-session-v1';
const wireMagic=Uint8Array.of(73,78,75,86,65,76,0,1);
const wireEncoder=new TextEncoder(),wireDecoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const wireDefaults=Object.freeze({bytes:16777216,nodes:1000000,depth:128}),wireDefaultOptions=Object.freeze({});
const wireDecimal=s=>typeof s==='string'&&/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(s);
function wireLimits(options){if(options===wireDefaultOptions||options===wireDefaults)return wireDefaults;const l={...wireDefaults,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>wireDefaults[k])throw Error('wire hard resource limit');return l;}
const wireFloat=new DataView(new ArrayBuffer(4));
function wireDecodeText(bytes,start,end){
 if(end-start<=16){let text='';for(let i=start;i<end;i++){const byte=bytes[i];if(byte>=128)return wireDecoder.decode(bytes.subarray(start,end));text+=String.fromCharCode(byte);}return text;}
 return wireDecoder.decode(bytes.subarray(start,end));
}
function wireUtf8Length(text){let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const wireOwn=(v,k)=>v!==null&&typeof v==='object'&&Object.hasOwn(v,k);
const wireTagged=(v,k)=>wireOwn(v,k)&&Object.keys(v).length===1;
const wireDouble=new DataView(new ArrayBuffer(8));
function wireF64Bits(v){
 if(typeof v==='number'&&Number.isFinite(v)){wireDouble.setFloat64(0,v,true);return wireDouble.getBigUint64(0,true);}
 if(!wireTagged(v,'F64Bits'))wireInvalidValue();const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))wireInvalidValue();
 const bits=BigInt(text);if(bits>18446744073709551615n)wireInvalidValue();return bits;
}
const wireCanonical=v=>Array.isArray(v)?'['+v.map(wireCanonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort((a,b)=>{const x=Array.from(a,c=>c.codePointAt(0)),y=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]-y[i];return x.length-y.length;}).map(k=>JSON.stringify(k)+':'+wireCanonical(v[k])).join(',')+'}':JSON.stringify(v);
export async function createValueCodec(root,named={}){
 const used=new Set(),budget={nodes:100000};
 function check(t,d=0){
  if(d>64||--budget.nodes<0)throw Error('wire descriptor limit');
  const keys={u32:['kind'],u64:['kind'],i32:['kind'],f32:['kind'],f64:['kind'],bool:['kind'],unit:['kind'],string:['kind'],int:['kind'],id:['kind','name'],ref:['kind','name'],enum:['kind','name','variants'],record:['kind','name','fields'],list:['kind','element'],option:['kind','element'],vector:['kind','element','size'],result:['kind','ok','error']}[t?.kind];
  if(!keys||Object.keys(t).length!==keys.length||keys.some(k=>!Object.hasOwn(t,k)))throw Error('invalid wire descriptor');
  if(keys.includes('name')&&(typeof t.name!=='string'||!t.name.isWellFormed()))throw Error('invalid descriptor name');
  if(t.kind==='ref'){if(!used.has(t.name)){used.add(t.name);if(named[t.name]?.kind!=='record'||named[t.name].name!==t.name)throw Error('unresolved wire reference');check(named[t.name],d+1);}}
  if(t.kind==='record'){if(!Array.isArray(t.fields))throw Error('wire fields');const names=new Set();for(const f of t.fields){if(Object.keys(f).length!==2||typeof f.name!=='string'||!f.name.isWellFormed()||names.has(f.name))throw Error('duplicate wire field');names.add(f.name);check(f.type,d+1);}}
  if(t.kind==='enum'&&(!Array.isArray(t.variants)||!t.variants.length||t.variants.length>64||t.variants.some(v=>typeof v!=='string'||!v.isWellFormed())||new Set(t.variants).size!==t.variants.length))throw Error('wire enum');
  if(['list','vector','option'].includes(t.kind)){if(t.kind==='vector'&&(!Number.isInteger(t.size)||t.size<1||t.size>64))throw Error('wire vector');check(t.element,d+1);}
  if(t.kind==='result'){check(t.ok,d+1);check(t.error,d+1);}
 }
 check(root);const names=Object.fromEntries([...used].sort().map(k=>[k,named[k]]));
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',wireEncoder.encode(wireCanonical({format:valueWireFormat,root,named:names}))));
 return new ValueCodec({format:valueWireFormat,root,named:names,identity:Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('')});
}
// Resolve immutable descriptor edges once. Logical validation traverses the
// literal schema; single-child nodes use a loop rather than recursive closures.
function wireValuePlan(codec){
 const seen=new WeakMap();let remaining=100000;
 const build=type=>{
  const t=codec.resolve(type);if(seen.has(t))return seen.get(t);
  if(--remaining<0)throw Error('wire descriptor limit');const p={kind:t.kind,type:t,decode:null,decodeCompact:null};seen.set(t,p);
  if(t.kind==='record')p.fields=t.fields.map(f=>({name:f.name,plan:build(f.type)}));
  if(t.kind==='list'||t.kind==='vector'||t.kind==='option')p.element=build(t.element);
  if(t.kind==='result'){p.ok=build(t.ok);p.error=build(t.error);}
  return p;
 };return build(codec.descriptor.root);
}
function wireBindDecodePlan(root,compact=false){
 const seen=new Set(),pending=[root];let flags=0;
 while(pending.length){
  const p=pending.pop();if(seen.has(p))continue;seen.add(p);if(compact)p.decodeCompact=compactDecodeOperation(p);else p.decode=wireDecodeOperation(p);
  if(p.fields?.length>4)flags|=1;
  if(p.kind==='u32'||p.kind==='i32'||p.kind==='u64'||p.kind==='f32'||p.kind==='f64')flags|=2;
  if(p.fields)for(const f of p.fields)pending.push(f.plan);
  if(p.element)pending.push(p.element);
  if(p.ok){pending.push(p.ok);pending.push(p.error);}
 }
 return flags|4;
}
// Select literal descriptor operations once, without runtime source generation
// or eval. Recursive edges call the completed plan. The generic scanner remains
// the visitor/validation path and an independent materialisation implementation.
function wireReadOperation(p){
 const t=p.type;
 let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':read=(r,end)=>{r.size(end,4);const value={F32Bits:r.view.getUint32(r.cursor,true)};r.cursor=end;return value;};break;
  case 'f64':read=(r,end)=>{r.size(end,8);const value={F64Bits:r.view.getBigUint64(r.cursor,true).toString()};r.cursor=end;return value;};break;
  case 'u64':read=(r,end)=>{r.size(end,8);const value=r.view.getBigUint64(r.cursor,true);r.cursor=end;return value;};break;
  case 'string':read=(r,end)=>r.text(end);break;
  case 'int':read=(r,end)=>{const text=r.text(end);if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=(r,end)=>{const text=r.text(end);if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=(r,end)=>{const text=r.text(end);if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{
    if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;
    if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');
    const values=new Array(n);for(let i=0;i<n;i++)values[i]=element.decode(r,end,d+1);return values;
   };break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1)});break;
    case 2:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1)});break;
    case 3:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1)});break;
    case 4:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1),[fs[3].name]:fs[3].plan.decode(r,end,d+1)});break;
    default:read=(r,end,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decode(r,end,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,end,d)=>{const tag=r.tag(end);return tag?{Some:p.element.decode(r,end,d+1)}:{None:null};};break;
  case 'result':read=(r,end,d)=>r.tag(end)?{Err:p.error.decode(r,end,d+1)}:{Ok:p.ok.decode(r,end,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function wireDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=wireReadOperation(field.plan),name=field.name;
  return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),childEnd=r.enter(end,d+1),item=read(r,childEnd,d+1);if(r.cursor!==childEnd)throw Error('trailing wire frame bytes');const value={[name]:item};if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
 }
 const read=wireReadOperation(p);
 return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
}
class WireDecodeCursor{
 constructor(bytes,view,limits){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
// Bind literal validation and postorder visitation once for every descriptor.
// No logical carriers are allocated; projection still validates every child.
function wireScanPlan(root){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,scan:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.scan=wireScanOperation(p);return p;
 };
 return build(root);
}
function wireScanOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':case 'f64':case 'u64':{const size=p.kind==='f32'?4:8;read=(r,end)=>{r.size(end,size);r.cursor=end;};break;}
  case 'string':read=(r,end)=>{let i=r.cursor;while(i<end&&r.bytes[i]<128)i++;if(i<end)wireDecoder.decode(r.bytes.subarray(r.cursor,end));r.cursor=end;};break;
  case 'int':case 'id':case 'enum':read=(r,end)=>{const text=r.text(end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');for(let i=0;i<n;i++)element.scan(r,end,d+1);};break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>{};break;
    case 1:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);};break;
    case 2:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);};break;
    case 3:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);};break;
    case 4:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);fs[3].plan.scan(r,end,d+1);};break;
    default:read=(r,end,d)=>{for(const f of fs)f.plan.scan(r,end,d+1);};
   }break;
  }
  case 'option':read=(r,end,d)=>{if(r.tag(end))p.element.scan(r,end,d+1);};break;
  case 'result':read=(r,end,d)=>{(r.tag(end)?p.error:p.ok).scan(r,end,d+1);};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return (r,parentEnd,d)=>{
  const end=r.enter(parentEnd,d),start=r.cursor,value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');
  const visitor=r.visitor;if(visitor&&(!r.selected||r.selected.has(t.name))){if(r.spans)visitor(t,r.bytes,start,end,d);else visitor(t,r.bytes.subarray(start,end),d);}
  return value;
 };
}
// Separate methods keep decoding's cursor callsites monomorphic. Both cursors
// are checked against the independent generic scanner and malformed fixtures.
class WireScanCursor{
 constructor(bytes,view,limits,visitor,selected,spans){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.visitor=visitor;this.selected=selected;this.spans=spans;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
function compactReadOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=()=>null;break;
  case 'bool':read=r=>{r.require(1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':case 'i32':read=r=>{r.require(4);const n=p.kind==='u32'?r.view.getUint32(r.cursor,true):r.view.getInt32(r.cursor,true);r.cursor+=4;return n;};break;
  case 'f32':read=r=>{r.require(4);const n=r.view.getUint32(r.cursor,true);r.cursor+=4;return {F32Bits:n};};break;
  case 'f64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return {F64Bits:n.toString()};};break;
  case 'u64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return n;};break;
  case 'string':read=r=>r.text();break;
  case 'int':read=r=>{const text=r.text();if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=r=>{const text=r.text();if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=r=>{const text=r.text();if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':read=(r,d)=>{const n=r.count();if(n>r.remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');const values=new Array(n);for(let i=0;i<n;i++)values[i]=p.element.decodeCompact(r,d+1);return values;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1)});break;
    case 2:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1)});break;
    case 3:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1)});break;
    case 4:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1),[fs[3].name]:fs[3].plan.decodeCompact(r,d+1)});break;
    default:read=(r,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decodeCompact(r,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,d)=>r.tag()?{Some:p.element.decodeCompact(r,d+1)}:{None:null};break;
  case 'result':read=(r,d)=>r.tag()?{Err:p.error.decodeCompact(r,d+1)}:{Ok:p.ok.decodeCompact(r,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function compactDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=compactReadOperation(field.plan),name=field.name;
  return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');if(d+1>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return {[name]:read(r,d+1)};};
 }
 const read=compactReadOperation(p);
 return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return read(r,d);};
}
class CompactDecodeCursor{
 constructor(bytes,limits,flags){this.bytes=bytes;this.view=flags&2?new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength):null;this.cursor=1;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 require(n){if(n>this.bytes.length-this.cursor)throw Error('truncated compact value');}
 count(){
  if(this.cursor>=this.bytes.length)throw Error('truncated compact value');
  const first=this.bytes[this.cursor++];if(first<128)return first;
  let value=first&127,scale=128;
  for(let i=1;i<5;i++){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const byte=this.bytes[this.cursor++];if(i===4&&byte>15)throw Error('compact count overflow');value+=(byte&127)*scale;if(byte<128){if(byte===0)throw Error('noncanonical compact count');return value;}scale*=128;}throw Error('compact count overflow');
 }
 tag(){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const tag=this.bytes[this.cursor++];if(tag>1)throw Error('wire sum tag');return tag;}
 text(){const n=this.count();this.require(n);const start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
function wireInvalidValue(){throw Error('invalid value for wire schema');}
// Capture has the canonical logical meaning of decode(encode(value)), without
// allocating wire bytes. A separate plan leaves validation/decoder hot shapes
// unchanged and never retains host input containers between calls.
function wireCapturePlan(root,checked=true){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,capture:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({name:f.name,plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.capture=checked?wireCaptureOperation(p):wireCopyOperation(p);return p;
 };return build(root);
}
function wireCaptureOperation(p){
 const t=p.type;let copy;
 switch(p.kind){
  case 'unit':copy=v=>{if(v!==null)wireInvalidValue();return null;};break;
  case 'bool':copy=(v,r)=>{if(typeof v!=='boolean')wireInvalidValue();r.add(1);return v;};break;
  case 'u32':case 'i32':{
   const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
   copy=(v,r)=>{if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();r.add(4);return v===0?0:v;};break;
  }
  case 'u64':copy=(v,r)=>{const kind=typeof v;if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();r.add(8);return n;};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'int':case 'id':case 'enum':copy=(v,r)=>{const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;if(typeof text!=='string'||!text.isWellFormed()||text.length>r.limit)wireInvalidValue();if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();r.add(wireUtf8Length(text));return p.kind==='int'?{Int:text}:text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   copy=(v,r,d)=>{if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();const n=v.length;if(n>r.remaining||size!==null&&n!==size)wireInvalidValue();r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=element.capture(v[i],r,d+1);return out;};break;
  }
  case 'record':{
   const fs=p.fields;let fields;
   switch(fs.length){
    case 0:fields=()=>({});break;
    case 1:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:fields=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }
   copy=(v,r,d)=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();for(const f of fs)if(!wireOwn(v,f.name))wireInvalidValue();return fields(v,r,d);};break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'None')&&v.None===null)return {None:null};if(wireTagged(v,'Some'))return {Some:p.element.capture(v.Some,r,d+1)};wireInvalidValue();};break;
  case 'result':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'Ok'))return {Ok:p.ok.capture(v.Ok,r,d+1)};if(wireTagged(v,'Err'))return {Err:p.error.capture(v.Err,r,d+1)};wireInvalidValue();};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
class WireCaptureCursor{
 constructor(limits){this.remaining=limits.nodes;this.depth=limits.depth;this.limit=limits.bytes;this.bytes=40;this.add(0);}
 add(n){this.bytes+=n;if(this.bytes>this.limit)throw Error('wire byte limit');}
 enter(depth,bytes){if(depth>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.add(bytes);}
 text(value){if(value.length>this.limit)throw Error('wire byte limit');this.add(wireUtf8Length(value));}
}
// Literal lowerers share this fixed resource policy with logical capture.
export function createValueCaptureBudget(options=wireDefaultOptions){return new WireCaptureCursor(wireLimits(options));}
// The trusted-value API has the same canonical copy and ownership semantics.
// Its caller supplies a stable value accepted by validateValue. Shape/range
// checks remain at external capture boundaries; resource limits still apply.
function wireCopyOperation(p){
 let copy;
 switch(p.kind){
  case 'unit':copy=()=>null;break;
  case 'bool':copy=(v,r)=>{r.add(1);return v;};break;
  case 'u32':copy=(v,r)=>{r.add(4);return v>>>0;};break;
  case 'i32':copy=(v,r)=>{r.add(4);return v|0;};break;
  case 'u64':copy=(v,r)=>{r.add(8);return BigInt(v);};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'){wireFloat.setFloat32(0,v,true);bits=wireFloat.getUint32(0,true);}else bits=v.F32Bits;r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'id':case 'enum':copy=(v,r)=>{r.add(wireUtf8Length(v));return v;};break;
  case 'int':copy=(v,r)=>{const text=typeof v==='bigint'?v.toString():v.Int;r.add(wireUtf8Length(text));return {Int:text};};break;
  case 'list':case 'vector':copy=(v,r,d)=>{const n=v.length;if(n>r.remaining)throw Error('wire sequence size');r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=p.element.capture(v[i],r,d+1);return out;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:copy=()=>({});break;
    case 1:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:copy=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'None')&&v.None===null?{None:null}:{Some:p.element.capture(v.Some,r,d+1)};};break;
  case 'result':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'Ok')?{Ok:p.ok.capture(v.Ok,r,d+1)}:{Err:p.error.capture(v.Err,r,d+1)};};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
// Emit the cached literal schema with one forward writer. Each value is checked
// where it is consumed; byte bounds belong to the writer, not a second size walk.
function wireEncodeValue(root,value,l,w){
 let remaining=l.nodes;const depthLimit=l.depth;
 const node=(p,v,d)=>{
  if(d>depthLimit||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type,start=w.beginNode();
  switch(p.kind){
   case 'unit':if(v!==null)wireInvalidValue();break;
   case 'bool':if(typeof v!=='boolean')wireInvalidValue();w.byte(+v);break;
   case 'u32':case 'i32':{
    const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
    if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();w.word(v>>>0);break;
   }
   case 'u64':{
    const kind=typeof v;
    if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
    const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();w.wide(n);break;
   }
   case 'f64':w.wide(wireF64Bits(v));break;
   case 'f32':{
    let bits;
    if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}
    else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
    w.word(bits);break;
   }
   case 'string':case 'int':case 'id':case 'enum':{
    const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
    if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&(typeof text!=='string'||!/^[0-9a-f]{32}$/.test(text))||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
    w.text(text);break;
   }
   case 'list':case 'vector':{
    if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
    if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
    w.count(v.length);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);break;
   }
   case 'record':{
    const fs=p.fields;
    if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
    for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
    for(let i=0;i<fs.length;i++){const f=fs[i];node(f.plan,v[f.name],d+1);}break;
   }
   case 'option':{
    if(wireTagged(v,'None')&&v.None===null)w.byte(0);
    else if(wireTagged(v,'Some')){w.byte(1);node(p.element,v.Some,d+1);}else wireInvalidValue();break;
   }
   case 'result':{
    if(wireTagged(v,'Ok')){w.byte(0);node(p.ok,v.Ok,d+1);}
    else if(wireTagged(v,'Err')){w.byte(1);node(p.error,v.Err,d+1);}else wireInvalidValue();break;
   }
   default:throw Error('unsupported wire kind');
  }
  w.endNode(start);
 };
 node(root,value,0);
}
function wireCheckValue(root,value,l){
 let remaining=l.nodes,total=40;
 const add=n=>{total+=n;if(total>l.bytes)throw Error('wire byte limit');};
 const node=(p,v,d)=>{
  while(true){
   if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
   const t=p.type;
   switch(p.kind){
    case 'unit':if(v!==null)wireInvalidValue();add(4);return;
    case 'bool':if(typeof v!=='boolean')wireInvalidValue();add(5);return;
    case 'u32':case 'i32':{
     const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
     if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();add(8);return;
    }
    case 'u64':{
     const kind=typeof v;
     if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
     const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();add(12);return;
    }
    case 'f64':wireF64Bits(v);add(12);return;
    case 'f32':{
     if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();}
     else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();const bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
     add(8);return;
    }
    case 'string':case 'int':case 'id':case 'enum':{
     const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
     if(typeof text!=='string'||!text.isWellFormed()||text.length>l.bytes)wireInvalidValue();
     if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
     add(4+wireUtf8Length(text));return;
    }
    case 'list':case 'vector':{
     if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
     if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
     add(8);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);return;
    }
    case 'record':{
     const fs=p.fields;
     if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
     for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
     add(4);if(!fs.length)return;
     for(let i=0;i<fs.length-1;i++)node(fs[i].plan,v[fs[i].name],d+1);
     const f=fs[fs.length-1];p=f.plan;v=v[f.name];d++;continue;
    }
    case 'option':{
     if(wireTagged(v,'None')&&v.None===null){add(5);return;}
     if(!wireTagged(v,'Some'))wireInvalidValue();add(5);p=p.element;v=v.Some;d++;continue;
    }
    case 'result':{
     if(wireTagged(v,'Ok')){add(5);p=p.ok;v=v.Ok;}
     else if(wireTagged(v,'Err')){add(5);p=p.error;v=v.Err;}else wireInvalidValue();
     d++;continue;
    }
    default:throw Error('unsupported wire kind');
   }
  }
 };
 node(root,value,0);if(total>l.bytes)throw Error('wire byte limit');
}
// A single cursor replaces per-node child closures and {end,value} temporaries.
// Projection filters limit callback materialisation, never schema validation.
function wireScanValue(root,bytes,view,l,materialize,visitor,selected,spans){
 let cursor=40,remaining=l.nodes;
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,parentEnd,d)=>{
  if(d>l.depth||--remaining<0||cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const t=p.type,start=cursor+4,end=start+view.getUint32(cursor,true);if(end>parentEnd)throw Error('truncated wire frame');cursor=start;let value;
  switch(p.kind){
   case 'unit':if(end-start!==0)throw Error('malformed wire scalar');value=null;break;
   case 'bool':if(end-start!==1)throw Error('malformed wire scalar');if(bytes[start]>1)throw Error('invalid wire Bool');value=!!bytes[start];cursor=end;break;
   case 'u32':case 'i32':if(end-start!==4)throw Error('malformed wire scalar');value=p.kind==='u32'?view.getUint32(start,true):view.getInt32(start,true);cursor=end;break;
   case 'f32':if(end-start!==4)throw Error('malformed wire scalar');if(materialize)value={F32Bits:view.getUint32(start,true)};cursor=end;break;
   case 'f64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value={F64Bits:view.getBigUint64(start,true).toString()};cursor=end;break;
   case 'u64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value=view.getBigUint64(start,true);cursor=end;break;
   case 'string':case 'int':case 'id':case 'enum':{
    if(p.kind==='string'&&!materialize){let i=start;while(i<end&&bytes[i]<128)i++;if(i<end)wireDecoder.decode(bytes.subarray(start,end));}
    else{const text=wireDecodeText(bytes,start,end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    cursor=end;break;
   }
   case 'list':case 'vector':{
    if(start+4>end)throw Error('wire list count');const n=view.getUint32(start,true);cursor+=4;
    if(n>remaining||n>Math.floor((end-cursor)/4)||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,end,d+1);if(materialize)value.push(child);}break;
   }
   case 'record':{
    const fs=p.fields;
    // Computed literal keys create own data properties even for __proto__ or
    // prototype setters. Common small records need no descriptor allocations.
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:value={};break;case 1:value={[fs[0].name]:node(fs[0].plan,end,d+1)};break;case 2:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1)};break;case 3:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1)};break;case 4:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1),[fs[3].name]:node(fs[3].plan,end,d+1)};break;}
    }else{if(materialize)value={};for(const f of fs){const child=node(f.plan,end,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}}break;
   }
   case 'option':case 'result':{
    if(start===end||bytes[cursor]>1)throw Error('wire sum tag');const tag=bytes[cursor++];
    if(p.kind==='option'&&tag===0){if(materialize)value={None:null};}
    else{const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,end,d+1);if(materialize)value={[label]:child};}break;
   }
   default:throw Error('unsupported wire kind');
  }
  if(cursor!==end)throw Error('trailing wire frame bytes');
  if(visitor&&(!selected||selected.has(t.name))){if(spans)visitor(t,bytes,start,end,d);else visitor(t,bytes.subarray(start,end),d);}
  return value;
 };
 const result=node(root,bytes.length,0);if(cursor!==bytes.length)throw Error('trailing wire bytes');return result;
}
export class ValueCodec{
 #hash;
 #header;
 #headerWords;
 #descriptor;
 #valuePlan;
 #compactCodec;
 #encoder;
 #decodeBound=0;
 #scanPlan=null;
 #capturePlan=null;
 #copyPlan=null;
 get descriptor(){return this.#descriptor;}
 constructor(descriptor){
  // This synchronous path is for compiler-generated immutable metadata. For
  // untrusted descriptors use createValueCodec and compare the computed identity.
  if(descriptor?.format!==valueWireFormat||!/^[0-9a-f]{64}$/.test(descriptor.identity))throw Error('invalid wire schema');
  this.#descriptor=structuredClone(descriptor);this.#hash=Uint8Array.from(descriptor.identity.match(/../g),s=>parseInt(s,16));
  this.#header=new Uint8Array(40);this.#header.set(wireMagic);this.#header.set(this.#hash,8);
  const headerView=new DataView(this.#header.buffer);this.#headerWords=Array.from({length:10},(_,i)=>headerView.getUint32(i*4,true));
  const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}};freeze(this.descriptor);this.#valuePlan=wireValuePlan(this);
 }
 resolve(t){for(let i=0;i<64;i++){if(t.kind!=='ref')return t;t=this.descriptor.named[t.name];if(!t)throw Error('wire reference');}throw Error('wire reference cycle');}
 validateValue(value,options=wireDefaultOptions){wireCheckValue(this.#valuePlan,value,wireLimits(options));return true;}
 capture(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#capturePlan??=wireCapturePlan(this.#valuePlan);return this.#capturePlan.capture(value,new WireCaptureCursor(limits),0);}
 copy(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#copyPlan??=wireCapturePlan(this.#valuePlan,false);return this.#copyPlan.capture(value,new WireCaptureCursor(limits),0);}
 compact(){return this.#compactCodec??=new CompactValueCodec(this);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new WireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.bytes(this.#header);wireEncodeValue(this.#valuePlan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new WireEncoder(options);w.bytes(wireMagic);w.bytes(this.#hash);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 scan(bytes,options=wireDefaultOptions,materialize=false,visitor=null,names=null,spans=false){
  const l=wireLimits(options);if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<44||bytes.length>l.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==this.#headerWords[i])throw Error('wire format or schema mismatch');
  if(names!==null&&(!Array.isArray(names)||names.length>100000||names.some(n=>typeof n!=='string')))throw Error('wire visitor names');
  if(materialize&&!visitor){this.#decodeBound||=wireBindDecodePlan(this.#valuePlan);const cursor=new WireDecodeCursor(bytes,view,l);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#valuePlan.decode(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  if(!materialize){this.#scanPlan??=wireScanPlan(this.#valuePlan);const cursor=new WireScanCursor(bytes,view,l,visitor,names===null?null:new Set(names),spans),value=this.#scanPlan.scan(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  return wireScanValue(this.#valuePlan,bytes,view,l,materialize,visitor,names===null?null:new Set(names),spans);
 }
 visit(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names);}
 visitSpans(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names,true);}
 validate(bytes,options=wireDefaultOptions){this.scan(bytes,options,false);return true;}
 decode(bytes,options=wireDefaultOptions){return this.scan(bytes,options,true);}
}

// Bounded forward emission avoids building and repeatedly joining child buffers.
class WireEncoder{
 #data=new Uint8Array(256);#view=new DataView(this.#data.buffer);#at=0;#remaining;#depth=0;#byteLimit;#depthLimit;
 active=false;
 constructor(options){this.reset(options);}
 reset(options){const limits=wireLimits(options);this.#byteLimit=limits.bytes;this.#depthLimit=limits.depth;this.#remaining=limits.nodes;this.#depth=0;this.#at=0;this.active=true;}
 get capacity(){return this.#data.length;}
 get position(){return this.#at;}
 beginNode(){const at=this.#at;this.word(0);return at;}
 endNode(at){this.patchWord(at,this.#at-at-4);}
 count(n){this.word(n);}
 beginCount(){const at=this.position;this.count(0);return at;}
 endCount(at,n){this.patchWord(at,n);}
 #reserve(size){
  const end=this.#at+size;if(end>this.#byteLimit)throw Error('wire byte limit');
  if(end>this.#data.length){const next=new Uint8Array(Math.min(this.#byteLimit,Math.max(end,this.#data.length*2)));next.set(this.#data.subarray(0,this.#at));this.#data=next;this.#view=new DataView(next.buffer);}
  return end;
 }
 bytes(bytes){const end=this.#reserve(bytes.length);this.#data.set(bytes,this.#at);this.#at=end;}
 byte(n){if(!Number.isInteger(n)||n<0||n>255)throw Error('wire byte range');this.#reserve(1);this.#data[this.#at++]=n;}
 word(n){if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire word range');const end=this.#reserve(4);this.#view.setUint32(this.#at,n,true);this.#at=end;}
 wide(n){if(typeof n!=='bigint'||n<0n||n>18446744073709551615n)throw Error('wire wide range');const end=this.#reserve(8);this.#view.setBigUint64(this.#at,n,true);this.#at=end;}
 text(text,count=false){
  if(typeof text!=='string')throw Error('wire Unicode');
  if(text.length<=16){
   let ascii=true;for(let i=0;i<text.length;i++)if(text.charCodeAt(i)>=128){ascii=false;break;}
   if(ascii){if(count)this.count(text.length);const end=this.#reserve(text.length);for(let i=0;i<text.length;i++)this.#data[this.#at+i]=text.charCodeAt(i);this.#at=end;return;}
  }
  if(!text.isWellFormed())throw Error('wire Unicode');const size=wireUtf8Length(text);if(count)this.count(size);
  const end=this.#reserve(size),r=wireEncoder.encodeInto(text,this.#data.subarray(this.#at,end));if(r.read!==text.length||r.written!==size)throw Error('wire UTF-8 size');this.#at=end;
 }
 patchWord(at,n){if(!Number.isInteger(at)||at<0||at+4>this.#at||!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire patch offset');this.#view.setUint32(at,n,true);}
 patchByte(at,n){if(!Number.isInteger(at)||at<0||at>=this.#at||!Number.isInteger(n)||n<0||n>255)throw Error('wire patch offset');this.#data[at]=n;}
 replace(at,removed,bytes){
  if(!Number.isInteger(at)||!Number.isInteger(removed)||at<0||removed<0||at+removed>this.#at||!(bytes instanceof Uint8Array))throw Error('wire replacement range');
  const extra=bytes.length-removed,end=extra>0?this.#reserve(extra):this.#at+extra;
  this.#data.copyWithin(at+bytes.length,at+removed,this.#at);this.#data.set(bytes,at);this.#at=end;
 }
 // Literal generated writers use balanced frames without per-node callbacks.
 // An exception abandons this invocation; encodeWith never reuses its writer.
 openFrame(){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;return at;}
 closeFrame(at){if(this.#depth===0)throw Error('wire frame boundary');this.#depth--;this.endNode(at);}
 frame(emit){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;try{emit(this);}finally{this.#depth--;}this.endNode(at);}
 reorder(start,spans){
  const sorted=spans.slice().sort((a,b)=>a[0]-b[0]);let at=start;
  for(const [a,b] of sorted){if(!Number.isInteger(a)||!Number.isInteger(b)||a!==at||b<a)throw Error('wire span permutation');at=b;}
  if(start<0||start>this.#at||at!==this.#at)throw Error('wire span permutation');
  if(spans.every((s,i)=>s===sorted[i]))return;
  const copy=this.#data.slice(start,this.#at);at=start;for(const [a,b] of spans){this.#data.set(copy.subarray(a-start,b-start),at);at+=b-a;}
 }
 finish(){if(this.#depth!==0)throw Error('wire frame boundary');return this.#data.slice(0,this.#at);}
}

class CompactWireEncoder extends WireEncoder{
 beginNode(){return 0;}
 endNode(){}
 endCount(at,n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  if(n<128){this.patchByte(at,n);return;}
  const bytes=[];while(n>=128){bytes.push(n%128+128);n=Math.floor(n/128);}bytes.push(n);this.replace(at,1,Uint8Array.from(bytes));
 }
 count(n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  while(n>=128){this.byte(n%128+128);n=Math.floor(n/128);}this.byte(n);
 }
 text(text){super.text(text,true);}
}

function compactScanValue(root,bytes,l,materialize){
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let cursor=1,remaining=l.nodes;
 const require=n=>{if(n>bytes.length-cursor)throw Error('truncated compact value');};
 const count=()=>{
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   require(1);const byte=bytes[cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }throw Error('compact count overflow');
 };
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,d)=>{
  if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type;let value;
  switch(p.kind){
   case 'unit':return null;
   case 'bool':require(1);if(bytes[cursor]>1)throw Error('invalid wire Bool');return !!bytes[cursor++];
   case 'u32':case 'i32':require(4);value=p.kind==='u32'?view.getUint32(cursor,true):view.getInt32(cursor,true);cursor+=4;return value;
   case 'f32':require(4);if(materialize)value={F32Bits:view.getUint32(cursor,true)};cursor+=4;return value;
   case 'f64':require(8);if(materialize)value={F64Bits:view.getBigUint64(cursor,true).toString()};cursor+=8;return value;
   case 'u64':require(8);if(materialize)value=view.getBigUint64(cursor,true);cursor+=8;return value;
   case 'string':case 'int':case 'id':case 'enum':{
    const n=count();require(n);const start=cursor;cursor+=n;
    if(p.kind==='string'&&!materialize){let i=start;while(i<cursor&&bytes[i]<128)i++;if(i<cursor)wireDecoder.decode(bytes.subarray(start,cursor));}
    else{const text=wireDecodeText(bytes,start,cursor);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    return value;
   }
   case 'list':case 'vector':{
    const n=count();if(n>remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,d+1);if(materialize)value.push(child);}return value;
   }
   case 'record':{
    const fs=p.fields;
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:return {};case 1:return {[fs[0].name]:node(fs[0].plan,d+1)};case 2:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1)};case 3:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1)};case 4:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1),[fs[3].name]:node(fs[3].plan,d+1)};}
    }
    if(materialize)value={};for(const f of fs){const child=node(f.plan,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}return value;
   }
   case 'option':case 'result':{
    require(1);const tag=bytes[cursor++];if(tag>1)throw Error('wire sum tag');
    if(p.kind==='option'&&tag===0)return materialize?{None:null}:undefined;
    const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,d+1);
    return materialize?{[label]:child}:undefined;
   }
   default:throw Error('unsupported wire kind');
  }
 };
 const value=node(root,0);if(cursor!==bytes.length)throw Error('trailing compact bytes');return value;
}

// General transport codec, independent of source rewrites and checkpoints.
// The sender/receiver must negotiate this exact identity and format. There is
// deliberately no claim that the bytes themselves identify their schema.
export class CompactValueCodec{
 #source;#plan;#encoder;#decodeBound=0;
 get format(){return compactValueWireFormat;}
 get identity(){return this.#source.descriptor.identity;}
 constructor(valueCodec){if(!(valueCodec instanceof ValueCodec))throw Error('compact codec requires a checked value codec');this.#source=valueCodec;this.#plan=wireValuePlan(valueCodec);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new CompactWireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.byte(1);wireEncodeValue(this.#plan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new CompactWireEncoder(options);w.byte(1);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 #scan(bytes,options,materialize){
  const l=wireLimits(options);
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<1||bytes.length>l.bytes)throw Error('wire byte limit or header');
  if(bytes[0]!==1)throw Error('compact format mismatch');
  if(materialize){this.#decodeBound||=wireBindDecodePlan(this.#plan,true);const cursor=new CompactDecodeCursor(bytes,l,this.#decodeBound);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#plan.decodeCompact(cursor,0);if(cursor.cursor!==bytes.length)throw Error('trailing compact bytes');return value;}
  return compactScanValue(this.#plan,bytes,l,materialize);
 }
 decode(bytes,options=wireDefaultOptions){return this.#scan(bytes,options,true);}
 validate(bytes,options=wireDefaultOptions){this.#scan(bytes,options,false);return true;}
}

// Compiler materialisers consume already validated bytes synchronously. This
// factory is for trusted emitted code, not untrusted descriptor/callback data.
// The complete generic validator runs before any compiler reader is invoked.
class ValidatedValueReader{
 constructor(bytes,compact){this.bytes=bytes;this.view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);this.cursor=compact?1:40;this.compact=compact;}
 frame(){if(this.compact)return 0;const end=this.cursor+4+this.view.getUint32(this.cursor,true);this.cursor+=4;return end;}
 finish(end){if(!this.compact&&this.cursor!==end)throw Error('compiled reader frame mismatch');}
 byte(){return this.bytes[this.cursor++];}
 word(){const n=this.view.getUint32(this.cursor,true);this.cursor+=4;return n;}
 signed(){const n=this.view.getInt32(this.cursor,true);this.cursor+=4;return n;}
 wide(){const n=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return n;}
 count(){if(!this.compact)return this.word();let n=0,scale=1,byte;do{byte=this.byte();n+=(byte&127)*scale;scale*=128;}while(byte>=128);return n;}
 text(end){const n=this.compact?this.count():end-this.cursor,start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
class CompiledCompactValueCodec extends CompactValueCodec{
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,true),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
}
class CompiledValueCodec extends ValueCodec{
 #read;#compiledCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,false),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
 compact(){return this.#compiledCompact??=new CompiledCompactValueCodec(this,this.#read);}
}
export function createCompiledValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new CompiledValueCodec(descriptor,read);}

// Trusted literal materialisers may use this checked reader to validate and
// construct in one traversal. The emitter must use frame/finish at every source
// node, typed text reads and counted sequence reads; arbitrary callbacks do not
// establish a schema correspondence proof. The independent scanner remains the
// validation oracle and the original factory retains its pre-validation path.
function literalValueHeader(identity){
 const bytes=new Uint8Array(40);bytes.set(wireMagic);
 for(let i=0;i<32;i++)bytes[i+8]=parseInt(identity.slice(i*2,i*2+2),16);
 const view=new DataView(bytes.buffer),words=new Uint32Array(10);
 for(let i=0;i<10;i++)words[i]=view.getUint32(i*4,true);
 return words;
}
class CheckedLiteralValueReader {
 constructor(bytes,header,compact,limits){
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<(compact?1:44)||bytes.length>limits.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  if(compact){if(bytes[0]!==1)throw Error('compact format mismatch');}
  else for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==header[i])throw Error('wire format or schema mismatch');
  this.bytes=bytes;this.view=view;
  this.cursor=compact?1:40;this.compact=compact;this.remaining=limits.nodes;this.depth=limits.depth;this.ends=[];
 }
 require(n){if(this.cursor+n>(this.ends.at(-1)??this.bytes.length))throw Error('truncated wire frame');}
 frame(){
  if(this.ends.length>this.depth||--this.remaining<0)throw Error('wire node or depth limit');
  let end=this.bytes.length;
  if(!this.compact){this.require(4);end=this.cursor+4+this.view.getUint32(this.cursor,true);this.require(end-this.cursor);this.cursor+=4;}
  this.ends.push(end);return this.compact?0:end;
 }
 finish(end){
  if(!this.ends.length||!this.compact&&(this.ends.at(-1)!==end||this.cursor!==end))throw Error('compiled reader frame mismatch');
  this.ends.pop();
 }
 byte(){this.require(1);const value=this.bytes[this.cursor++];if(value>1)throw Error('wire sum tag or Bool');return value;}
 word(){this.require(4);const value=this.view.getUint32(this.cursor,true);this.cursor+=4;return value;}
 signed(){this.require(4);const value=this.view.getInt32(this.cursor,true);this.cursor+=4;return value;}
 wide(){this.require(8);const value=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return value;}
 rawCount(){
  if(!this.compact)return this.word();
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   this.require(1);const byte=this.bytes[this.cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }
  throw Error('compact count overflow');
 }
 count(size){
  const value=this.rawCount();
  if(value>this.remaining||size!==undefined&&value!==size)throw Error('wire sequence size');
  return value;
 }
 text(end,kind='string',variants){
  const size=this.compact?this.rawCount():end-this.cursor;
  this.require(size);const start=this.cursor;this.cursor+=size;
  const value=wireDecodeText(this.bytes,start,this.cursor);
  if(kind==='int'&&!wireDecimal(value)||kind==='id'&&!/^[0-9a-f]{32}$/.test(value)||kind==='enum'&&!variants.includes(value))throw Error('malformed wire text');
  return value;
 }
 complete(){if(this.ends.length||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
// Compact source nodes have no individual frame ends: retain the same checked
// depth/node order using a counter, with bounds against the complete buffer.
class CheckedCompactLiteralValueReader extends CheckedLiteralValueReader {
 constructor(bytes,limits){super(bytes,null,true,limits);this.level=0;}
 require(n){if(this.cursor+n>this.bytes.length)throw Error('truncated wire frame');}
 frame(){if(this.level>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.level++;return 0;}
 finish(_end){if(!this.level)throw Error('compiled reader frame mismatch');this.level--;}
 complete(){if(this.level||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
class FusedCompactValueCodec extends CompactValueCodec {
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedCompactLiteralValueReader(bytes,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
}
class FusedValueCodec extends ValueCodec {
 #read;#header;#fusedCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;this.#header=literalValueHeader(this.descriptor.identity);}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedLiteralValueReader(bytes,this.#header,false,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
 compact(){return this.#fusedCompact??=new FusedCompactValueCodec(this,this.#read);}
}
export function createFusedValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new FusedValueCodec(descriptor,read);}
// JSON text is a boundary adapter to an ordinary recursive Ink datatype.
// No JavaScript Number conversion occurs for JSON numeric tokens.
export function jsonNumberToken(s){return typeof s==='string'&&/^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/.test(s);}
// JSON numeric tokens have an ASCII grammar. Check validated UTF-8 spans
// directly, preserving exact lexemes without allocating a decoded String.
function jsonNumberSpan(bytes,lo,hi){
 let at=lo;if(bytes[at]===45)at++;
 if(at>=hi)return false;
 if(bytes[at]===48)at++;
 else{if(bytes[at]<49||bytes[at]>57)return false;do{at++;}while(at<hi&&bytes[at]>=48&&bytes[at]<=57);}
 if(at<hi&&bytes[at]===46){const start=++at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 if(at<hi&&(bytes[at]===69||bytes[at]===101)){at++;if(at<hi&&(bytes[at]===43||bytes[at]===45))at++;const start=at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 return at===hi;
}
const jsonWireEncoder=new TextEncoder();
// Scalar conversion completes before writer callbacks; no per-value byte array.
const jsonFloatScratch=new DataView(new ArrayBuffer(4));
function jsonUtf8Length(text){if(text.length>16&&!/[^\x00-\x7f]/.test(text))return text.length;let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const jsonLimits={bytes:16777216,nodes:1000000,depth:128};
const jsonQuoters=new WeakSet();
/** Explicit, bounded reuse of immutable JSON string quotes. Cache payload bytes
 * are UTF-16 storage estimates; entry caps bound separate Map/object overhead.
 * Logical output budgets are charged again on every use, including cache hits.
 */
export function createJsonQuoter({maxEntries=1024,maxBytes=131072}={}){
 if(!Number.isSafeInteger(maxEntries)||maxEntries<0||maxEntries>65536||!Number.isSafeInteger(maxBytes)||maxBytes<0||maxBytes>16777216)throw Error('JSON quote cache budget');
 const entries=new Map();let bytes=0,hits=0,misses=0;
 const token=value=>{
  const prior=entries.get(value);if(prior!==undefined){hits++;return prior;}
  if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid JSON String');
  misses++;const text=JSON.stringify(value),size=2*(value.length+text.length),quoted=Object.freeze({text,utf8Bytes:jsonUtf8Length(text)});
  if(maxEntries&&size<=maxBytes){
   while(entries.size&&(entries.size>=maxEntries||bytes+size>maxBytes)){const key=entries.keys().next().value;bytes-=2*(key.length+entries.get(key).text.length);entries.delete(key);}
   entries.set(value,quoted);bytes+=size;
  }
  return quoted;
 };
 const quoter=Object.freeze({
  token,
  quote(value){return token(value).text;},
  clear(){entries.clear();bytes=0;},
  stats(){return {entries:entries.size,payload_bytes:bytes,hits,misses};},
 });jsonQuoters.add(quoter);return quoter;
}
function checkedJsonLimits(options){const l={...jsonLimits,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>jsonLimits[k])throw Error('JSON hard resource limit');return l;}
function jsonVariant(index,item){let payload=index===0?{}:{item0:item};if(index<5)payload={Ok:payload};for(let i=0;i<index;i++)payload={Err:payload};return {payload};}
export function parseJson(text,options={}){return parseJsonValue(text,options,null);}
function parseJsonValue(text,options,boundary){
 const p=new JsonWireReader(text,options);
 const value=(d,wireDepth=0)=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){boundary?.node(0,wireDepth);p.at+=4;return jsonVariant(0,null);}if(c==='t'&&text.startsWith('true',p.at)){boundary?.node(1,wireDepth);p.at+=4;return jsonVariant(1,true);}if(c==='f'&&text.startsWith('false',p.at)){boundary?.node(1,wireDepth);p.at+=5;return jsonVariant(1,false);}
  if(c==='"'){boundary?.node(3,wireDepth);const item=p.string();boundary?.text(item);return jsonVariant(3,item);}
  if(c==='['){boundary?.node(4,wireDepth);p.at++;const xs=[];if(!p.eat(']'))while(true){xs.push(value(d+1,wireDepth+8));if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}return jsonVariant(4,xs);}
  if(c==='{'){boundary?.node(5,wireDepth);p.at++;const xs=[],seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary?.member(key,wireDepth);if(!p.eat(':'))throw Error('JSON object colon');xs.push({key,value:value(d+1,wireDepth+9)});if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}return jsonVariant(5,xs);}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();boundary?.node(2,wireDepth);boundary?.text(token);return jsonVariant(2,token);}
  throw Error('invalid JSON value');
 };
 const out=value(0);p.finish();return out;
}
export function stringifyJson(value,options={}){return stringifyJsonValue(value,options,null);}
function stringifyJsonValue(value,options,boundary){
 const l=checkedJsonLimits(options);let remaining=l.nodes,bytes=0,output='';
 const emit=s=>{bytes+=jsonUtf8Length(s);if(bytes>l.bytes)throw Error('JSON byte limit');output+=s;};
 const write=(v,d,wireDepth=0)=>{
  if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');if(!v||Object.keys(v).length!==1||!Object.hasOwn(v,'payload'))throw Error('invalid JSON record');let p=v.payload,index=0;
  while(index<5&&p&&Object.hasOwn(p,'Err')){if(Object.keys(p).length!==1||boundary&&Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Err;index++;}
  if(index<5){if(!p||Object.keys(p).length!==1||!Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Ok;}
  if(!p||Object.keys(p).length!==(index===0?0:1)||index>0&&!Object.hasOwn(p,'item0'))throw Error('invalid JSON payload');const item=p.item0;boundary?.node(index,wireDepth);
  switch(index){
   case 0:emit('null');break;
   case 1:if(typeof item!=='boolean')throw Error('invalid JSON Boolean');emit(item?'true':'false');break;
   case 2:if(!jsonNumberToken(item))throw Error('invalid JSON number');boundary?.text(item);emit(item);break;
   case 3:if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary?.text(item);emit(JSON.stringify(item));break;
   case 4:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Array');const count=item.length;let visited=0;emit('[');item.forEach((x,i)=>{visited++;if(i)emit(',');write(x,d+1,wireDepth+8);});if(visited!==count)throw Error('invalid JSON Array');emit(']');break;}
   case 5:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Object');const count=item.length,seen=new Set();let visited=0;emit('{');item.forEach((m,i)=>{visited++;if(!m||Object.keys(m).length!==2||typeof m.key!=='string'||!m.key.isWellFormed()||!Object.hasOwn(m,'value')||boundary&&!Object.hasOwn(m,'key'))throw Error('invalid JSON member');if(seen.has(m.key))throw Error('duplicate JSON object key');seen.add(m.key);boundary?.member(m.key,wireDepth);if(i)emit(',');emit(JSON.stringify(m.key));emit(':');write(m.value,d+1,wireDepth+9);});if(visited!==count)throw Error('invalid JSON Object');emit('}');break;}
  }
 };write(value,0);return output;
}
// The adapter's schema is the fixed recursive JSON library shape checked by
// JsonCodec. Charge its ordinary record/sum/list wire nodes while parsing or
// rendering, rather than interpreting and walking the completed tree again.
function jsonBoundaryBudget(options){
 const l=checkedJsonLimits(options);let remaining=l.nodes,total=40;
 const charge=(nodes,bytes,depth)=>{remaining-=nodes;total+=bytes;if(remaining<0||depth>l.depth)throw Error('wire node or depth limit');if(total>l.bytes)throw Error('wire byte limit');};
 return {
  node(index,depth){charge(index===0?3:index<4?index+4:8,index===0?13:index===1?23:index===2?27:index===3?32:41,depth+(index===0?2:index<4?index+3:7));},
  text(text){charge(0,jsonUtf8Length(text),0);},
  member(key,depth){charge(2,8+jsonUtf8Length(key),depth+9);},
 };
}
function jsonSameSchema(a,b){
 if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;
 const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>Object.hasOwn(b,k)&&jsonSameSchema(a[k],b[k]));
}
// Host-object conversion is opt-in and JavaScript-only. Inspect data properties
// rather than invoking getters/toJSON; reflection is not a sandbox for proxies.
function jsonJSKeys(value){
 if(!value||typeof value!=='object')throw Error('expected a plain JavaScript object');
 const prototype=Object.getPrototypeOf(value);
 if(prototype!==Object.prototype&&prototype!==null)throw Error('expected a plain JavaScript object');
 const keys=Reflect.ownKeys(value);
 if(keys.some(k=>typeof k!=='string'))throw Error('JavaScript symbol keys are unsupported');
 return keys;
}
function jsonJSData(value,key){
 const property=Object.getOwnPropertyDescriptor(value,key);
 if(!property||!property.enumerable||!Object.hasOwn(property,'value'))throw Error('expected an enumerable own data property');
 return property.value;
}
function jsonJSRecord(value,names){
 const keys=jsonJSKeys(value);
 if(keys.length!==names.length||keys.some(k=>!names.includes(k)))throw Error('invalid JSON record or variant');
}
function jsonJSArray(value,remaining){
 if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype)throw Error('expected a plain JavaScript array');
 const length=value.length;
 if(length>remaining)throw Error('JSON node limit');
 const keys=Reflect.ownKeys(value);
 if(keys.length!==length+1||keys.some(k=>typeof k!=='string'||k!=='length'&&(!/^(0|[1-9][0-9]*)$/.test(k)||Number(k)>=length)))throw Error('sparse or decorated JavaScript arrays are unsupported');
 return length;
}
function jsonFromJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),active=new WeakSet();let remaining=limits.nodes;
 const text=value=>{if(!value.isWellFormed())throw Error('invalid JSON Unicode');boundary.text(value);return value;};
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  if(value===null){boundary.node(0,wireDepth);return jsonVariant(0);}
  switch(typeof value){
   case 'boolean':boundary.node(1,wireDepth);return jsonVariant(1,value);
   case 'string':boundary.node(3,wireDepth);return jsonVariant(3,text(value));
   case 'number':
    if(!Number.isFinite(value))throw Error('non-finite JavaScript numbers are unsupported');
    boundary.node(2,wireDepth);return jsonVariant(2,text(Object.is(value,-0)?'-0':String(value)));
   case 'bigint':boundary.node(2,wireDepth);return jsonVariant(2,text(String(value)));
   case 'object':break;
   default:throw Error('unsupported JavaScript value');
  }
  if(active.has(value))throw Error('cyclic JavaScript value');
  active.add(value);
  try{
   if(Array.isArray(value)){
    boundary.node(4,wireDepth);const count=jsonJSArray(value,remaining),items=[];
    for(let i=0;i<count;i++)items.push(visit(jsonJSData(value,String(i)),depth+1,wireDepth+8));
    return jsonVariant(4,items);
   }
   boundary.node(5,wireDepth);const keys=jsonJSKeys(value),members=[];
   if(keys.length>remaining)throw Error('JSON node limit');
   for(const key of keys){
    if(!key.isWellFormed())throw Error('invalid JSON Unicode');
    boundary.member(key,wireDepth);
    members.push({key,value:visit(jsonJSData(value,key),depth+1,wireDepth+9)});
   }
   return jsonVariant(5,members);
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
function jsonDecimalKey(token){
 const [,sign,whole,fraction='',exponent='0']=/^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(token);
 const digits=(whole+fraction).replace(/^0+/,'');
 if(!digits)return '0';
 const trimmed=digits.replace(/0+$/,'');
 return sign+trimmed+'e'+(Number(exponent)-fraction.length+digits.length-trimmed.length);
}
function jsonToJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),mode=options?.numbers??'number',active=new WeakSet();let remaining=limits.nodes;
 if(!['number','bigint','string'].includes(mode))throw Error('unknown JavaScript number policy');
 const number=token=>{
  if(!jsonNumberToken(token))throw Error('invalid JSON number');
  boundary.text(token);
  if(mode==='string')return token;
  if(mode==='bigint')return BigInt(jsonInteger(token,4096));
  const result=Number(token);
  if(!Number.isFinite(result)||jsonDecimalKey(token)!==jsonDecimalKey(String(result)))throw Error('JSON number loses precision as JavaScript Number; choose numbers: bigint or string');
  return result;
 };
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  jsonJSRecord(value,['payload']);
  if(active.has(value))throw Error('cyclic JSON value');
  active.add(value);
  try{
   let payload=jsonJSData(value,'payload'),index=0;
   while(index<5&&Object.hasOwn(payload,'Err')){jsonJSRecord(payload,['Err']);payload=jsonJSData(payload,'Err');index++;}
   if(index<5){jsonJSRecord(payload,['Ok']);payload=jsonJSData(payload,'Ok');}
   jsonJSRecord(payload,index===0?[]:['item0']);boundary.node(index,wireDepth);
   const item=index===0?null:jsonJSData(payload,'item0');
   if(index===0)return null;
   if(index===1){if(typeof item!=='boolean')throw Error('invalid JSON Boolean');return item;}
   if(index===2)return number(item);
   if(index===3){if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary.text(item);return item;}
   const count=jsonJSArray(item,remaining);
   if(index===4){const out=[];for(let i=0;i<count;i++)out.push(visit(jsonJSData(item,String(i)),depth+1,wireDepth+8));return out;}
   const out={},seen=new Set();
   for(let i=0;i<count;i++){
    const member=jsonJSData(item,String(i));jsonJSRecord(member,['key','value']);const key=jsonJSData(member,'key');
    if(typeof key!=='string'||!key.isWellFormed())throw Error('invalid JSON member key');
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary.member(key,wireDepth);
    Object.defineProperty(out,key,{value:visit(jsonJSData(member,'value'),depth+1,wireDepth+9),enumerable:true,writable:true,configurable:true});
   }
   return out;
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
const jsonConstructionPaths=Object.freeze(Array.from({length:6},(_,index)=>Object.freeze([0,...Array(index).fill(1),...(index<5?[0]:[]),0])));
function parseJsonConstructed(text,options,builder){
 const p=new JsonWireReader(text,options);
 const paths=jsonConstructionPaths;
 const fused=typeof builder.openPath==='function';
 const begin=index=>{if(fused){builder.openPath(paths[index]);return;}for(const choice of paths[index])builder.open(choice);};
 const end=index=>{for(let i=0;i<(fused?1:index<5?index+3:7);i++)builder.close();};
 const leaf=(index,item)=>{if(typeof builder.scalarPath==='function'){builder.scalarPath(paths[index],item);return;}begin(index);builder.scalar(item);end(index);};
 const value=d=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){p.at+=4;if(typeof builder.emptyPath==='function')builder.emptyPath(paths[0]);else{begin(0);end(0);}return;}
  if(c==='t'&&text.startsWith('true',p.at)){p.at+=4;leaf(1,true);return;}
  if(c==='f'&&text.startsWith('false',p.at)){p.at+=5;leaf(1,false);return;}
  if(c==='"'){leaf(3,p.string());return;}
  if(c==='['){begin(4);builder.open(0);p.at++;if(!p.eat(']'))while(true){value(d+1);if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}builder.close();end(4);return;}
  if(c==='{'){begin(5);builder.open(0);p.at++;const seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');builder.open(0);builder.scalar(key);value(d+1);builder.close();if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}builder.close();end(5);return;}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();leaf(2,token);return;}
  throw Error('invalid JSON value');
 };
 value(0);p.finish();return builder.finish();
}
const jsonCompiledRenderers=new WeakMap();
function compiledJsonRenderer(json,codec,unwrap){
 if(typeof codec?.reducer!=='function')throw Error('compiled JSON reduction unavailable');
 const source=codec.resolve(codec.descriptor.root),root=json.values.descriptor.root;
 const selected=unwrap&&source.kind==='result'?codec.resolve(source.ok):source;
 if(!jsonSameSchema(root,selected)||unwrap&&source.kind!=='result')throw Error('compiled JSON schema mismatch');
 let variants=root.fields[0].type;const roles=new Map([[root.name,'root']]);
 let member;
 for(let index=0;index<6;index++){
  const branch=index<5?variants.ok:variants;roles.set(branch.name,index);
  if(index===5){member=branch.fields[0].type.element.name;roles.set(member,'member');}
  if(index<5)variants=variants.error;
 }
 const nodeRoles=new Map();
 return codec.reducer((node,index)=>{
  const role=roles.get(node.name);nodeRoles.set(index,role);
  if(node.kind==='record'){
   if(role==='root')return value=>value;
   if(role==='member')return (key,value,context)=>{
    const text=(context.quoter?context.quote(key,true):context.add(JSON.stringify(key)+':'))+value,seen=context.members;
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);return text;
   };
   if(role===0)return context=>context.add('null');
   if(role===1)return (value,context)=>context.add(value?'true':'false');
   if(role===2)return (token,context)=>{if(!jsonNumberToken(token))throw Error('invalid JSON number');return context.add(token);};
   if(role===3)return (value,context)=>context.quoter?context.quote(value,false):context.add(JSON.stringify(value));
   if(role===4)return (value,context)=>{context.add('[]');return '['+value+']';};
   if(role===5)return (value,context)=>{context.add('{}');return '{'+value+'}';};
   return ()=>null;
  }
  if(node.kind==='list'||node.kind==='vector'){
   const members=nodeRoles.get(node.children[0])==='member';
   return {
    start:(_length,context)=>{
     const out={text:'',parent:members?context.members:null};
     if(members)context.members=new Set();return out;
    },
    step:(out,value,index,context)=>{out.text+=(index?context.add(','):'')+value;return out;},
    finish:(out,context)=>{if(members)context.members=out.parent;return out.text;},
   };
  }
  if(node.kind==='result'){
   // A Result<Json,E> boundary is explicitly requested by the caller. Ordinary
   // JSON's own sums only propagate an already rendered branch.
   if(unwrap&&nodeRoles.get(node.children[0])==='root')return (tag,value)=>{if(tag)throw Error('JSON result is Err');return value;};
   return (_tag,value)=>value;
  }
  if(node.kind==='string')return value=>{if(!value.isWellFormed())throw Error('invalid JSON String');return value;};
  return value=>value;
 });
}
export class JsonCodec{
 constructor(valueCodec){
  const root=valueCodec.descriptor.root,fields=root.fields;if(root.kind!=='record'||!Array.isArray(fields)||fields.length!==1||fields[0].name!=='payload')throw Error('JSON schema payload');let sum=fields[0].type;
  for(let i=0;i<6;i++){
   if(i<5&&sum.kind!=='result')throw Error('JSON schema sum');const branch=i<5?sum.ok:sum,fs=branch.fields;
   if(branch.kind!=='record'||!Array.isArray(fs)||fs.length!==(i?1:0)||i&&fs[0].name!=='item0')throw Error('JSON schema branch');
   if(i){const t=fs[0].type;if(i===1&&t.kind!=='bool'||(i===2||i===3)&&t.kind!=='string'||i===4&&(t.kind!=='list'||t.element.kind!=='ref'||t.element.name!==root.name))throw Error('JSON schema variant');if(i===5){const mf=t.element?.fields;if(t.kind!=='list'||t.element?.kind!=='record'||!Array.isArray(mf)||mf.length!==2||mf[0].name!=='key'||mf[0].type.kind!=='string'||mf[1].name!=='value'||mf[1].type.kind!=='ref'||mf[1].type.name!==root.name)throw Error('JSON schema member');}}
   if(i===2)this.numberBranch=branch.name;if(i===5)this.objectBranch=branch.name;
   if(i<5)sum=sum.error;
  }if(!jsonSameSchema(root,valueCodec.resolve({kind:'ref',name:root.name})))throw Error('JSON recursive schema mismatch');this.values=valueCodec;
 }
 parse(text,options={}){return parseJsonValue(text,options,jsonBoundaryBudget(options));}
 parseCompiled(codec,text,options={}){
  if(codec?.identity!==this.values.descriptor.identity||typeof codec.builder!=='function')throw Error('compiled JSON schema mismatch');
  const builder=codec.builder(options);try{return parseJsonConstructed(text,options,builder);}catch(error){builder.abort();throw error;}
 }
 stringify(value,options={}){return stringifyJsonValue(value,options,jsonBoundaryBudget(options));}
 stringifyCompiled(codec,handle,options={}){
  const limits=checkedJsonLimits(options),unwrap=options.unwrapResult===true;
  const quoter=options.quoter;if(quoter!==undefined&&!jsonQuoters.has(quoter))throw Error('JSON quote cache owner mismatch');
  let codecs=jsonCompiledRenderers.get(this);if(!codecs)jsonCompiledRenderers.set(this,codecs=new WeakMap());
  let renderers=codecs.get(codec);if(!renderers)codecs.set(codec,renderers=new Map());
  let render=renderers.get(unwrap);if(!render)renderers.set(unwrap,render=compiledJsonRenderer(this,codec,unwrap));
  let bytes=0;const context={
   quoter,
   add(text){bytes+=jsonUtf8Length(text);if(bytes>limits.bytes)throw Error('JSON byte limit');return text;},
   quote(value,colon){
    if(!quoter)return this.add(JSON.stringify(value)+(colon?':':''));
    const token=quoter.token(value);bytes+=token.utf8Bytes+(colon?1:0);if(bytes>limits.bytes)throw Error('JSON byte limit');return token.text+(colon?':':'');
   },
  };
  const text=render(handle,context,limits);
  return text;
 }
 fromJS(value,options={}){return jsonFromJS(value,options);}
 toJS(value,options={}){return jsonToJS(value,options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,false);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,false,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,true);}
 validateBinary(bytes,options={}){
  const decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});let view;
  this.values.visitSpans(bytes,(type,data,start,end)=>{
   view??=new DataView(data.buffer,data.byteOffset,data.byteLength);
   if(type.name===this.numberBranch){const length=view.getUint32(start,true);if(!jsonNumberSpan(data,start+4,start+4+length))throw Error('invalid JSON number token');}
   if(type.name===this.objectBranch){const listEnd=start+4+view.getUint32(start,true),count=view.getUint32(start+4,true),seen=new Set();let at=start+8;for(let i=0;i<count;i++){const memberEnd=at+4+view.getUint32(at,true),keyStart=at+8,keyEnd=keyStart+view.getUint32(at+4,true),key=decoder.decode(data.subarray(keyStart,keyEnd));if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);at=memberEnd;}if(at!==listEnd)throw Error('invalid JSON object frame');}
  },options,[this.numberBranch,this.objectBranch]);return true;

 }
}
function jsonUnpack(value){let p=value.payload,i=0;while(i<5&&Object.hasOwn(p,'Err')){p=p.Err;i++;}return [i,(i<5?p.Ok:p).item0];}
function jsonInteger(token,limit){
 if(!jsonNumberToken(token))throw Error('invalid JSON number');const negative=token[0]==='-',raw=negative?token.slice(1):token,[mantissa,exp='0']=raw.split(/[eE]/);let digits=mantissa.replace('.','');if(/^0+$/.test(digits))return '0';const exponent=Number(exp),fraction=mantissa.includes('.')?mantissa.length-mantissa.indexOf('.')-1:0,shift=exponent-fraction;
 if(!Number.isSafeInteger(exponent)||!Number.isSafeInteger(shift))throw Error('JSON integer exponent limit');
 if(shift<0){const cut=-shift;if(cut>=digits.length||!/^[0]+$/.test(digits.slice(-cut)))throw Error('JSON number is not an integer');digits=digits.slice(0,-cut);}else{if(digits.length+shift>limit)throw Error('JSON integer magnitude limit');digits+='0'.repeat(shift);}
 digits=digits.replace(/^0+/,'');if(digits.length>limit)throw Error('JSON integer magnitude limit');return (negative?'-':'')+digits;
}
function jsonBinary64Value(v){
 if(typeof v==='number')return v;
 const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid F64Bits');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');
 const b=new DataView(new ArrayBuffer(8));b.setBigUint64(0,bits,true);return b.getFloat64(0,true);
}
export class TypedJsonCodec{
 constructor(valueCodec){this.values=valueCodec;}
 decode(document,options={}){
  // Validate JSON-specific invariants before interpreting any tagged/record
  // shape, including duplicated names and malformed numeric tokens.
  stringifyJson(document,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const read=(type,value,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type),[kind,item]=jsonUnpack(value);const fail=()=>{throw Error('JSON does not match '+t.kind);};
   switch(t.kind){
    case 'unit':if(kind!==0)fail();return null;
    case 'bool':if(kind!==1)fail();return item;
    case 'u32':case 'u64':case 'i32':case 'int':{if(kind!==2)fail();const text=jsonInteger(item,t.kind==='int'?4096:t.kind==='u64'?20:10);return t.kind==='int'?{Int:text}:t.kind==='u64'?BigInt(text):Number(text);}
    case 'f64':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(8));if(!Number.isFinite(n))throw Error('JSON f64 overflow');b.setFloat64(0,n,true);return {F64Bits:b.getBigUint64(0,true).toString()};}
    case 'f32':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(4));b.setFloat32(0,n,true);if(!Number.isFinite(b.getFloat32(0,true)))throw Error('JSON f32 overflow');return {F32Bits:b.getUint32(0,true)};}
    case 'string':case 'enum':case 'id':if(kind!==3)fail();return item;
    case 'list':case 'vector':if(kind!==4)fail();return item.map(x=>read(t.element,x,d+1));
    case 'record':{if(kind!==5||item.length!==t.fields.length)throw Error('unknown or missing JSON record field');const fields=new Map(item.map(m=>[m.key,m.value])),out={};for(const f of t.fields){if(!fields.has(f.name))throw Error('missing JSON record field');Object.defineProperty(out,f.name,{value:read(f.type,fields.get(f.name),d+1),writable:true,enumerable:true,configurable:true});}return out;}
    case 'option':case 'result':{if(kind!==5||item.length!==1)fail();const m=item[0];if(t.kind==='option'&&m.key==='None'&&jsonUnpack(m.value)[0]===0)return {None:null};const child=t.kind==='option'&&m.key==='Some'?t.element:t.kind==='result'&&m.key==='Ok'?t.ok:t.kind==='result'&&m.key==='Err'?t.error:null;if(!child)fail();return {[m.key]:read(child,m.value,d+1)};}
    default:fail();
   }
  };
  const out=read(this.values.descriptor.root,document,0);this.values.validateValue(out,options);return out;
 }
 encode(value,options={}){
  this.values.validateValue(value,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const write=(type,v,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type);
   switch(t.kind){
    case 'unit':return jsonVariant(0);
    case 'bool':return jsonVariant(1,v);
    case 'u32':case 'u64':case 'i32':return jsonVariant(2,String(v));
    case 'int':return jsonVariant(2,typeof v==='bigint'?String(v):v.Int);
    case 'f64':{const n=jsonBinary64Value(v);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'f32':{let n;if(typeof v==='number')n=Math.fround(v);else{const b=new DataView(new ArrayBuffer(4));b.setUint32(0,v.F32Bits,true);n=b.getFloat32(0,true);}if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'string':case 'id':case 'enum':return jsonVariant(3,v);
    case 'list':case 'vector':return jsonVariant(4,Array.from(v,x=>write(t.element,x,d+1)));
    case 'record':return jsonVariant(5,t.fields.map(f=>({key:f.name,value:write(f.type,v[f.name],d+1)})));
    case 'option':return jsonVariant(5,[Object.hasOwn(v,'Some')?{key:'Some',value:write(t.element,v.Some,d+1)}:{key:'None',value:jsonVariant(0)}]);
    case 'result':return jsonVariant(5,[Object.hasOwn(v,'Ok')?{key:'Ok',value:write(t.ok,v.Ok,d+1)}:{key:'Err',value:write(t.error,v.Err,d+1)}]);
    default:throw Error('unsupported typed JSON descriptor');
   }
  };return write(this.values.descriptor.root,value,0);
 }
 parse(text,options={}){return this.decode(parseJson(text,options),options);}
 stringify(value,options={}){return stringifyJson(this.encode(value,options),options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,true);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,true,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,false);}
}

// Token reader shared by schema-directed and arbitrary-JSON wire emission.
class JsonWireReader{
 constructor(text,options){this.l=checkedJsonLimits(options);if(typeof text!=='string'||!text.isWellFormed()||text.length>this.l.bytes||jsonUtf8Length(text)>this.l.bytes)throw Error('JSON byte or Unicode limit');this.text=text;this.at=0;this.remaining=this.l.nodes;}
 ws(){while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(c!==32&&c!==9&&c!==10&&c!==13)break;this.at++;}}
 peek(){this.ws();return this.text[this.at];}
 eat(c){this.ws();if(this.text[this.at]===c){this.at++;return true;}return false;}
 node(d){if(d>this.l.depth||--this.remaining<0)throw Error('JSON node or depth limit');}
 string(){
  this.ws();const start=this.at;if(this.text[start]!=='"')throw Error('expected JSON string');
  const end=this.text.indexOf('"',start+1);if(end<0)throw Error('unterminated JSON string');
  const raw=this.text.slice(start+1,end);
  if(!raw.includes('\\')&&!/[\x00-\x1f]/.test(raw)){this.at=end+1;return raw;}
  this.at=start+1;while(this.at<this.text.length){if(this.text[this.at]==='"'){this.at++;const v=JSON.parse(this.text.slice(start,this.at));if(!v.isWellFormed())throw Error('invalid JSON Unicode');return v;}if(this.text[this.at]==='\\')this.at+=2;else this.at++;}throw Error('unterminated JSON string');
 }
 number(){const start=this.at;while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(!(c>=48&&c<=57||c===45||c===43||c===46||c===101||c===69))break;this.at++;}const token=this.text.slice(start,this.at);if(!jsonNumberToken(token))throw Error('invalid JSON number');return token;}
 leaf(d){this.node(d);const c=this.peek();if(c==='n'&&this.text.startsWith('null',this.at)){this.at+=4;return null;}if(c==='t'&&this.text.startsWith('true',this.at)){this.at+=4;return true;}if(c==='f'&&this.text.startsWith('false',this.at)){this.at+=5;return false;}if(c==='"')return this.string();if(c==='-'||c>='0'&&c<='9')return this.number();throw Error('invalid JSON scalar');}
 finish(){this.ws();if(this.at!==this.text.length)throw Error('trailing JSON text');}
}
function streamJsonBinary(values,text,options,typed,compact=false){
 const p=new JsonWireReader(text,options),utf8=jsonWireEncoder;
 const list=(w,open,close,item)=>{if(!p.eat(open))throw Error('JSON container shape');const at=w.beginCount();let count=0;if(!p.eat(close))while(true){item(w);count++;if(p.eat(close))break;if(!p.eat(','))throw Error('JSON container separator');}w.endCount(at,count);};
 const variant=(w,index,level,emit)=>{if(level<index)w.frame(w=>{w.byte(1);variant(w,index,level+1,emit);});else if(index<5)w.frame(w=>{w.byte(0);w.frame(emit);});else w.frame(emit);};
 const json=(w,d)=>{
  const ch=p.peek(),index=ch==='n'?0:ch==='t'||ch==='f'?1:ch==='-'||ch>='0'&&ch<='9'?2:ch==='"'?3:ch==='['?4:ch==='{'?5:-1;if(index<0)throw Error('invalid JSON value');
  const leaf=index<4?p.leaf(d):null;if(index>=4)p.node(d);
  w.frame(w=>variant(w,index,0,w=>{
   if(index===0)return;if(index===1){w.frame(w=>w.byte(+leaf));return;}
   if(index===2||index===3){w.frame(w=>w.text(leaf));return;}
   w.frame(w=>{if(index===4)list(w,'[',']',w=>json(w,d+1));else{const seen=new Set();list(w,'{','}',w=>{const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');w.frame(w=>{w.frame(w=>w.text(key));json(w,d+1);});});}});
  }));
 };
 const read=(type,w,d)=>{
  const t=values.resolve(type);w.frame(w=>{
   if(t.kind==='list'||t.kind==='vector'){p.node(d);list(w,'[',']',w=>read(t.element,w,d+1));return;}
   if(t.kind==='record'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON record');const start=w.position,spans=new Array(t.fields.length).fill(null);
    if(!p.eat('}'))while(true){const key=p.string(),i=t.fields.findIndex(f=>f.name===key);if(i<0)throw Error('unknown JSON record field');if(spans[i])throw Error('duplicate JSON record field');if(!p.eat(':'))throw Error('JSON record colon');const at=w.position;read(t.fields[i].type,w,d+1);spans[i]=[at,w.position];if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON record separator');}
    if(spans.some(s=>s===null))throw Error('missing JSON record field');w.reorder(start,spans);return;
   }
   if(t.kind==='option'||t.kind==='result'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON tagged value');const key=p.string();if(!p.eat(':'))throw Error('JSON tag colon');
    if(t.kind==='option'&&key==='None'){if(p.leaf(d+1)!==null)throw Error('JSON None payload');w.byte(0);}
    else{const child=t.kind==='option'&&key==='Some'?t.element:t.kind==='result'&&key==='Ok'?t.ok:t.kind==='result'&&key==='Err'?t.error:null;if(!child)throw Error('invalid JSON tag');w.byte(key==='Ok'?0:1);read(child,w,d+1);}
    if(!p.eat('}'))throw Error('expected exactly one JSON tag');return;
   }
   const ch=p.peek(),v=p.leaf(d),bad=()=>{throw Error('JSON does not match '+t.kind);};
   if(t.kind==='unit'){if(v!==null)bad();return;}
   if(t.kind==='bool'){if(typeof v!=='boolean')bad();w.byte(+v);return;}
   if(['string','id','enum'].includes(t.kind)){if(ch!=='"')bad();w.text(v);return;}
   if(ch!=='-'&&!(ch>='0'&&ch<='9'))bad();
   if(t.kind==='int'){w.text(jsonInteger(v,4096));return;}
   if(t.kind==='f64'){const n=Number(v);if(!Number.isFinite(n))throw Error('JSON f64 overflow');const b=new DataView(new ArrayBuffer(8));b.setFloat64(0,n,true);w.wide(b.getBigUint64(0,true));}
   else if(t.kind==='f32'){jsonFloatScratch.setFloat32(0,Number(v),true);if(!Number.isFinite(jsonFloatScratch.getFloat32(0,true)))throw Error('JSON f32 overflow');w.word(jsonFloatScratch.getUint32(0,true));}
   else{const n=BigInt(jsonInteger(v,t.kind==='u64'?20:10));if(t.kind==='u64'){if(n<0n||n>18446744073709551615n)bad();w.wide(n);}else if(t.kind==='u32'){if(n<0n||n>4294967295n)bad();w.word(Number(n));}else if(t.kind==='i32'){if(n< -2147483648n||n>2147483647n)bad();w.word(Number(n)>>>0);}else bad();}
  });
 };
 return (compact?values.compact():values).encodeWith(w=>{if(typed)read(values.descriptor.root,w,0);else json(w,0);p.finish();},options);
}

// Render validated bytes in a single traversal; only the final text is owned.
function streamWireJsonText(values,bytes,options,library){
 values.validate(bytes,options);const l=checkedJsonLimits(options),parts=[];let size=0,remaining=l.nodes;const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 const emit=s=>{size+=jsonUtf8Length(s);if(size>l.bytes)throw Error('JSON byte limit');parts.push(s);};
 const string=s=>emit(JSON.stringify(s));const node=d=>{if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');};
 const frame=(type,at)=>{const t=values.resolve(type),start=at+4,end=start+dv.getUint32(at,true);return{t,start,end};};
 const json=(type,at,d)=>{
  node(d);let root=frame(type,at),sum=frame(root.t.fields[0].type,root.start),index=0;
  while(index<5){const err=bytes[sum.start];sum=frame(err?sum.t.error:sum.t.ok,sum.start+1);if(!err)break;index++;}
  if(index===0){emit('null');return root.end;}
  const item=frame(sum.t.fields[0].type,sum.start);
  if(index===1)emit(bytes[item.start]?'true':'false');
  else if(index===2){const token=decoder.decode(bytes.subarray(item.start,item.end));if(!jsonNumberToken(token))throw Error('invalid JSON number token');emit(token);}
  else if(index===3)string(decoder.decode(bytes.subarray(item.start,item.end)));
  else{const count=dv.getUint32(item.start,true);let p=item.start+4;emit(index===4?'[':'{');const seen=new Set();for(let i=0;i<count;i++){if(i)emit(',');if(index===4)p=json(item.t.element,p,d+1);else{const member=frame(item.t.element,p),key=frame(member.t.fields[0].type,member.start),name=decoder.decode(bytes.subarray(key.start,key.end));if(seen.has(name))throw Error('duplicate JSON object key');seen.add(name);string(name);emit(':');json(member.t.fields[1].type,key.end,d+1);p=member.end;}}emit(index===4?']':'}');}
  return root.end;
 };
 const typed=(type,at,d)=>{
  node(d);const f=frame(type,at),t=f.t;let p=f.start;
  switch(t.kind){
   case 'unit':emit('null');break;
   case 'bool':emit(bytes[p]?'true':'false');break;
   case 'u32':emit(String(dv.getUint32(p,true)));break;
   case 'u64':emit(String(dv.getBigUint64(p,true)));break;
   case 'i32':emit(String(dv.getInt32(p,true)));break;
   case 'f64':{const n=dv.getFloat64(p,true);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'f32':{const n=dv.getFloat32(p,true);if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'int':emit(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'string':case 'id':case 'enum':string(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'list':case 'vector':{const n=dv.getUint32(p,true);p+=4;emit('[');for(let i=0;i<n;i++){if(i)emit(',');p=typed(t.element,p,d+1);}emit(']');break;}
   case 'record':emit('{');for(let i=0;i<t.fields.length;i++){if(i)emit(',');const field=t.fields[i];string(field.name);emit(':');p=typed(field.type,p,d+1);}emit('}');break;
   case 'option':case 'result':{const tag=bytes[p++],key=t.kind==='option'?(tag?'Some':'None'):tag?'Err':'Ok';emit('{');string(key);emit(':');if(t.kind==='option'&&!tag){node(d+1);emit('null');}else typed(t.kind==='option'?t.element:tag?t.error:t.ok,p,d+1);emit('}');break;}
   default:throw Error('unsupported typed JSON descriptor');
  }return f.end;
 };
 if(library)json(values.descriptor.root,40,0);else typed(values.descriptor.root,40,0);return parts.join('');
}

/** Owned, optional read view of arbitrary JSON. Auxiliary indexes contain member
 * offsets only. Logical order, exact number tokens and missing/null remain intact.
 * This does not transparently replace any compiled Ink action or its state.
 */
export function createJsonLookup(text,{stepEntries=16,minReads=4,maxEntries=4096,maxObjects=64,maxIndexBytes=262144,...limits}={}){
 for(const [v,max]of [[stepEntries,4096],[minReads,1000000],[maxEntries,1000000],[maxObjects,256],[maxIndexBytes,16777216]])if(!Number.isSafeInteger(v)||v<0||v>max)throw Error('JSON index budget');
 let root=parseJson(text,limits),indexes=new Map(),entries=0,indexBytes=0;
 const stats={reads:0,writes:0,scanned_members:0,index_hits:0,built_entries:0,invalidations:0};
 function parts(path){
  if(!Array.isArray(path))throw Error('JSON lookup path');const n=path.length;if(n>128)throw Error('JSON lookup path');
  const owned=[];for(let i=0;i<n;i++){const d=Object.getOwnPropertyDescriptor(path,String(i));if(!d||!Object.hasOwn(d,'value'))throw Error('JSON lookup path');const p=d.value;if(!(typeof p==='string'&&p.isWellFormed()&&p.length<=4096)&&!(Number.isSafeInteger(p)&&p>=0))throw Error('JSON lookup path');owned.push(p);}return owned;
 }
 function variant(value){let p=value.payload,index=0;while(index<5&&Object.hasOwn(p,'Err')){p=p.Err;index++;}return {index,item:(index<5?p.Ok:p).item0};}
 function resolve(document,path,indexed){
  let value=document,budget=stepEntries;
  for(let depth=0;depth<path.length;depth++){
   const part=path[depth],v=variant(value);
   if(typeof part==='number'){
    if(v.index!==4)throw Error('expected JSON array');if(part>=v.item.length)return {found:false};value=v.item[part];continue;
   }
   if(v.index!==5)throw Error('expected JSON object');
   const prefix=path.slice(0,depth),key=JSON.stringify(prefix),overhead=128+prefix.reduce((n,p)=>n+(typeof p==='string'?16+p.length*2:8),0);let idx=indexed?indexes.get(key):null;
   if(indexed&&!idx&&indexes.size<maxObjects&&indexBytes+overhead<=maxIndexBytes){idx={path:prefix,reads:0,cursor:0,keys:new Map(),bytes:overhead};indexes.set(key,idx);indexBytes+=overhead;}
   if(idx){
    idx.reads++;
    if(idx.reads>=minReads)while(budget>0&&idx.cursor<v.item.length&&entries<maxEntries){
     const member=v.item[idx.cursor],bytes=64+member.key.length*2;
     if(indexBytes+bytes>maxIndexBytes)break;
     idx.keys.set(member.key,idx.cursor++);idx.bytes+=bytes;indexBytes+=bytes;entries++;stats.built_entries++;budget--;
    }
    if(idx.keys.has(part)){stats.index_hits++;value=v.item[idx.keys.get(part)].value;continue;}
   }
   let found=false;
   for(let i=idx?.cursor??0;i<v.item.length;i++){if(indexed)stats.scanned_members++;if(v.item[i].key===part){value=v.item[i].value;found=true;break;}}
   if(!found)return {found:false};
  }
  return {found:true,value};
 }
 return {
  lookup(path){stats.reads++;const r=resolve(root,parts(path),true);return r.found?{found:true,value:structuredClone(r.value)}:r;},
  set(path,key,text){
   path=parts(path);if(typeof key!=='string'||!key.isWellFormed())throw Error('JSON object key');
   const replacement=parseJson(text,limits),next=structuredClone(root),r=resolve(next,path,false);
   if(!r.found)throw Error('JSON update path missing');const object=variant(r.value);if(object.index!==5)throw Error('expected JSON object');
   const members=[{key,value:replacement},...object.item.filter(m=>m.key!==key)];
   // Validate the complete resulting document before publishing a write.
   let payload=r.value.payload;for(let i=0;i<5;i++)payload=payload.Err;payload.item0=members;
   stringifyJson(next,limits);root=next;stats.writes++;
   for(const [id,idx]of indexes)if(idx.path.length>=path.length&&path.every((p,i)=>p===idx.path[i])){entries-=idx.keys.size;indexBytes-=idx.bytes;indexes.delete(id);stats.invalidations++;}
  },
  replace(text){const next=parseJson(text,limits);root=next;stats.writes++;stats.invalidations+=indexes.size;indexes.clear();entries=0;indexBytes=0;},
  stringify(){return stringifyJson(root,limits);},
  stats(){return {...stats,index_entries:entries,index_objects:indexes.size,index_bytes:indexBytes};}
 };
}
function __ownedValue5(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue0(value[i],budget,depth+1);return out;}
function __ownedValue8(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue6(value[i],budget,depth+1);return out;}
function __ownedValue3(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue1(value[i],budget,depth+1);return out;}
function __ownedValue7(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue6(value["value"],budget,depth+1),["first"]:__ownedValue6(value["first"],budget,depth+1),["second"]:__ownedValue6(value["second"],budget,depth+1),["first_power"]:__ownedValue6(value["first_power"],budget,depth+1),["second_power"]:__ownedValue6(value["second_power"],budget,depth+1),["steps"]:__ownedValue2(value["steps"],budget,depth+1)};}
function __ownedValue0(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue1(value["value"],budget,depth+1),["first"]:__ownedValue1(value["first"],budget,depth+1),["second"]:__ownedValue1(value["second"],budget,depth+1),["first_power"]:__ownedValue1(value["first_power"],budget,depth+1),["second_power"]:__ownedValue1(value["second_power"],budget,depth+1),["steps"]:__ownedValue2(value["steps"],budget,depth+1)};}
function __ownedValue6(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue1(value["value"],budget,depth+1),["tangent"]:__ownedValue1(value["tangent"],budget,depth+1)};}
function __ownedValue4(value,budget,depth){budget.enter(depth,5);return value;}
function __ownedValue1(value,budget,depth){budget.enter(depth,8);const bits=typeof value==='number'?__bits(value):value.F32Bits;return {F32Bits:bits===0?0:bits};}
function __ownedValue2(value,budget,depth){budget.enter(depth,8);return value>>>0;}
const __ownedFunctions=Object.freeze(Object.fromEntries([["empty_parameter",__ownedValue0],["parameter",__ownedValue1],["reglu",__ownedValue1],["dot10",__ownedValue1],["dot6",__ownedValue1],["first_layer",__ownedValue3],["second_layer",__ownedValue3],["outputs",__ownedValue3],["squared_error",__ownedValue1],["objective",__ownedValue1],["gradients",__ownedValue3],["candidate",__ownedValue0],["valid",__ownedValue4],["configuration",__ownedValue4],["shape",__ownedValue4],["update",__ownedValue5],["losses",__ownedValue3],["__ink_differential_7",__ownedValue6],["__ink_differential_6",__ownedValue6],["__ink_differential_13",__ownedValue7],["__ink_differential_12",__ownedValue6],["__ink_differential_14",__ownedValue6],["__ink_differential_11",__ownedValue6],["__ink_differential_5",__ownedValue8],["__ink_differential_19",__ownedValue6],["__ink_differential_18",__ownedValue8],["__ink_differential_4",__ownedValue8],["__ink_differential_21",__ownedValue6],["__ink_differential_20",__ownedValue6],["__ink_differential_25",__ownedValue6],["__ink_differential_2",__ownedValue6],["__ink_differential_1",__ownedValue1]]));
function __wireValue8(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue9(reader);reader.finish(end);return value;}
function __wireValue3(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue4(reader);reader.finish(end);return value;}
function __wireValue10(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue7(reader);reader.finish(end);return value;}
function __wireValue5(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue1(reader);reader.finish(end);return value;}
function __wireValue31(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue2(reader);reader.finish(end);return value;}
function __wireValue12(reader){const end=reader.frame();const value={};reader.finish(end);return value;}
function __wireValue13(reader){const end=reader.frame();const value={["__ink_differential_15"]:__wireValue7(reader),["__ink_differential_16"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue18(reader){const end=reader.frame();const value={["__ink_differential_22"]:__wireValue7(reader),["__ink_differential_23"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue19(reader){const end=reader.frame();const value={["__ink_differential_26"]:__wireValue7(reader),["__ink_differential_27"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue22(reader){const end=reader.frame();const value={["__ink_differential_8"]:__wireValue7(reader),["__ink_differential_9"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue25(reader){const end=reader.frame();const value={["c"]:__wireValue24(reader)};reader.finish(end);return value;}
function __wireValue6(reader){const end=reader.frame();const value={["candidate"]:__wireValue7(reader),["coordinate"]:__wireValue2(reader),["parameters"]:__wireValue8(reader),["features"]:__wireValue10(reader),["row"]:__wireValue2(reader),["base"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue20(reader){const end=reader.frame();const value={["candidate"]:__wireValue7(reader),["coordinate"]:__wireValue2(reader),["parameters"]:__wireValue8(reader),["features"]:__wireValue10(reader),["row"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue16(reader){const end=reader.frame();const value={["candidate"]:__wireValue7(reader),["coordinate"]:__wireValue2(reader),["parameters"]:__wireValue8(reader),["features"]:__wireValue10(reader),["targets"]:__wireValue10(reader),["row"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue11(reader){const end=reader.frame();const value={["candidate"]:__wireValue7(reader),["coordinate"]:__wireValue2(reader),["parameters"]:__wireValue8(reader),["index"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue15(reader){const end=reader.frame();const value={["candidate"]:__wireValue7(reader),["coordinate"]:__wireValue2(reader),["parameters"]:__wireValue8(reader),["inputs"]:__wireValue10(reader),["base"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue14(reader){const end=reader.frame();const value={["candidate"]:__wireValue7(reader),["coordinate"]:__wireValue2(reader),["parameters"]:__wireValue8(reader),["inputs"]:__wireValue10(reader)};reader.finish(end);return value;}
function __wireValue27(reader){const end=reader.frame();const value={["candidate"]:__wireValue1(reader),["coordinate"]:__wireValue2(reader),["parameters"]:__wireValue3(reader),["features"]:__wireValue5(reader),["row"]:__wireValue2(reader),["base"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue29(reader){const end=reader.frame();const value={["candidate"]:__wireValue1(reader),["coordinate"]:__wireValue2(reader),["parameters"]:__wireValue3(reader),["features"]:__wireValue5(reader),["row"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue0(reader){const end=reader.frame();const value={["candidate"]:__wireValue1(reader),["coordinate"]:__wireValue2(reader),["parameters"]:__wireValue3(reader),["features"]:__wireValue5(reader),["targets"]:__wireValue5(reader),["row"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue32(reader){const end=reader.frame();const value={["candidate"]:__wireValue1(reader),["coordinate"]:__wireValue2(reader),["parameters"]:__wireValue3(reader),["index"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue28(reader){const end=reader.frame();const value={["candidate"]:__wireValue1(reader),["coordinate"]:__wireValue2(reader),["parameters"]:__wireValue3(reader),["inputs"]:__wireValue5(reader),["base"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue34(reader){const end=reader.frame();const value={["candidate"]:__wireValue1(reader),["coordinate"]:__wireValue2(reader),["parameters"]:__wireValue3(reader),["inputs"]:__wireValue5(reader)};reader.finish(end);return value;}
function __wireValue23(reader){const end=reader.frame();const value={["p"]:__wireValue4(reader),["g"]:__wireValue1(reader),["c"]:__wireValue24(reader)};reader.finish(end);return value;}
function __wireValue37(reader){const end=reader.frame();const value={["p"]:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue30(reader){const end=reader.frame();const value={["parameters"]:__wireValue3(reader),["features"]:__wireValue5(reader),["targets"]:__wireValue5(reader),["rows"]:__wireValue31(reader)};reader.finish(end);return value;}
function __wireValue36(reader){const end=reader.frame();const value={["parameters"]:__wireValue3(reader),["gradient"]:__wireValue5(reader),["admissible"]:__wireValue26(reader),["c"]:__wireValue24(reader)};reader.finish(end);return value;}
function __wireValue17(reader){const end=reader.frame();const value={["prediction"]:__wireValue7(reader),["target"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue35(reader){const end=reader.frame();const value={["prediction"]:__wireValue1(reader),["target"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue24(reader){const end=reader.frame();const value={["rate"]:__wireValue1(reader),["first_decay"]:__wireValue1(reader),["second_decay"]:__wireValue1(reader),["epsilon"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue9(reader){const end=reader.frame();const value={["value"]:__wireValue7(reader),["first"]:__wireValue7(reader),["second"]:__wireValue7(reader),["first_power"]:__wireValue7(reader),["second_power"]:__wireValue7(reader),["steps"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue21(reader){const end=reader.frame();const value={["value"]:__wireValue7(reader),["gate"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue4(reader){const end=reader.frame();const value={["value"]:__wireValue1(reader),["first"]:__wireValue1(reader),["second"]:__wireValue1(reader),["first_power"]:__wireValue1(reader),["second_power"]:__wireValue1(reader),["steps"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue33(reader){const end=reader.frame();const value={["value"]:__wireValue1(reader),["gate"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue7(reader){const end=reader.frame();const value={["value"]:__wireValue1(reader),["tangent"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue26(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __wireValue1(reader){const end=reader.frame();const value={F32Bits:reader.word()};reader.finish(end);return value;}
function __wireValue2(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
const __wireReaders=Object.freeze(Object.fromEntries([["__ink_differential_1",[__wireValue0,__wireValue1]],["__ink_differential_11",[__wireValue6,__wireValue7]],["__ink_differential_12",[__wireValue11,__wireValue7]],["__ink_differential_13",[__wireValue12,__wireValue9]],["__ink_differential_14",[__wireValue13,__wireValue7]],["__ink_differential_18",[__wireValue14,__wireValue10]],["__ink_differential_19",[__wireValue15,__wireValue7]],["__ink_differential_2",[__wireValue16,__wireValue7]],["__ink_differential_20",[__wireValue17,__wireValue7]],["__ink_differential_21",[__wireValue18,__wireValue7]],["__ink_differential_25",[__wireValue19,__wireValue7]],["__ink_differential_4",[__wireValue20,__wireValue10]],["__ink_differential_5",[__wireValue20,__wireValue10]],["__ink_differential_6",[__wireValue21,__wireValue7]],["__ink_differential_7",[__wireValue22,__wireValue7]],["candidate",[__wireValue23,__wireValue4]],["configuration",[__wireValue25,__wireValue26]],["dot10",[__wireValue27,__wireValue1]],["dot6",[__wireValue28,__wireValue1]],["empty_parameter",[__wireValue12,__wireValue4]],["first_layer",[__wireValue29,__wireValue5]],["gradients",[__wireValue30,__wireValue5]],["losses",[__wireValue30,__wireValue5]],["objective",[__wireValue0,__wireValue1]],["outputs",[__wireValue29,__wireValue5]],["parameter",[__wireValue32,__wireValue1]],["reglu",[__wireValue33,__wireValue1]],["second_layer",[__wireValue34,__wireValue5]],["shape",[__wireValue30,__wireValue26]],["squared_error",[__wireValue35,__wireValue1]],["update",[__wireValue36,__wireValue3]],["valid",[__wireValue37,__wireValue26]]]));

const __ownedImplementations=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>{
 const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
 const body=__implementations[f.index];
 const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
 return [f.name,input.every(c=>c===__identity)?implementation:(...args)=>{const context=new WeakMap();return implementation(...args.map((v,i)=>input[i](v,context)));}];
})));

export const valueCodecs=(()=>{const codecs={};for(const [name,s] of Object.entries(metadata.wire.functions)){if(s.unsupported)continue;let value;Object.defineProperty(codecs,name,{enumerable:true,get:()=>value??=(Object.freeze(Object.hasOwn(__wireReaders,name)?{arguments:createCompiledValueCodec(s.arguments,__wireReaders[name][0]),result:createCompiledValueCodec(s.result,__wireReaders[name][1])}:{arguments:new ValueCodec(s.arguments),result:new ValueCodec(s.result)}))});}return Object.freeze(codecs);})();
function __callEncoded(name,bytes,limits,compact){
 const f=metadata.functions.find(f=>f.name===name&&!f.internal),codecs=valueCodecs[name];
 if(!f||!codecs)throw Error('unsupported binary function');
 const input=compact?codecs.arguments.compact():codecs.arguments,output=compact?codecs.result.compact():codecs.result;
 const entry=__compiledEntries.get(name);
 if(entry){
  const slot=compact?1:0;
  entry.argumentCodecs[slot]??=(entry.boundaryReaders[slot]?createFusedValueCodec:createCompiledValueCodec)(metadata.wire.functions[name].arguments,entry.arguments);
  const decoder=entry.argumentCodecs[slot];
  const values=(compact?decoder.compact():decoder).decode(bytes,limits),args=f.params.map(p=>values[p.name]);
  if(entry.precondition!==null&&__implementations[entry.precondition](...args)!==true)throw Error('contract precondition failed');
  return __compiledEncodeResult(entry,__implementations[entry.index](...args),limits,compact);
 }
 const values=input.decode(bytes,limits);
 const result=call(name,f.params.map(p=>values[p.name]));
 return output.encode(result,limits);
}
export function callBinary(name,bytes,limits={}){return __callEncoded(name,bytes,limits,false);}
export function callCompact(name,bytes,limits={}){return __callEncoded(name,bytes,limits,true);}
// Same stable, well-typed caller inputs as call; the result owns every container.
// The checked source return type justifies trusted copying, not arbitrary input.
export function callOwned(name,args,limits={}){
 if(!Object.hasOwn(__ownedFunctions,name)||!Object.hasOwn(functions,name))throw Error('unsupported owned function');
 const result=__ownedImplementations[name](...args);return __ownedFunctions[name](result,createValueCaptureBudget(limits),0);
}
function __privateCapture10(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture9(value[i],budget,depth+1);return out;}
function __privateCapture3(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture0(value[i],budget,depth+1);return out;}
function __privateCapture11(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture8(value[i],budget,depth+1);return out;}
function __privateCapture4(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture1(value[i],budget,depth+1);return out;}
function __privateCapture5(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture2(value[i],budget,depth+1);return out;}
function __privateCapture6(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==4){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"rate")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"first_decay")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"second_decay")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"epsilon")){throw Error('invalid value for wire schema');}return {["rate"]:__privateCapture1(value["rate"],budget,depth+1),["first_decay"]:__privateCapture1(value["first_decay"],budget,depth+1),["second_decay"]:__privateCapture1(value["second_decay"],budget,depth+1),["epsilon"]:__privateCapture1(value["epsilon"],budget,depth+1)};}
function __privateCapture9(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"first")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"second")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"first_power")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"second_power")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"steps")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture8(value["value"],budget,depth+1),["first"]:__privateCapture8(value["first"],budget,depth+1),["second"]:__privateCapture8(value["second"],budget,depth+1),["first_power"]:__privateCapture8(value["first_power"],budget,depth+1),["second_power"]:__privateCapture8(value["second_power"],budget,depth+1),["steps"]:__privateCapture2(value["steps"],budget,depth+1)};}
function __privateCapture0(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"first")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"second")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"first_power")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"second_power")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"steps")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["first"]:__privateCapture1(value["first"],budget,depth+1),["second"]:__privateCapture1(value["second"],budget,depth+1),["first_power"]:__privateCapture1(value["first_power"],budget,depth+1),["second_power"]:__privateCapture1(value["second_power"],budget,depth+1),["steps"]:__privateCapture2(value["steps"],budget,depth+1)};}
function __privateCapture8(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["tangent"]:__privateCapture1(value["tangent"],budget,depth+1)};}
function __privateCapture7(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='boolean'){throw Error('invalid value for wire schema');}budget.add(1);return value;}
function __privateCapture1(value,budget,depth=0){budget.enter(depth,4);let bits;if(typeof value==='number'&&Number.isFinite(value)){bits=__bits(value);if(!Number.isFinite(__float(bits))){throw Error('invalid value for wire schema');}}else{if(!(value!==null&&typeof value==='object'&&Object.hasOwn(value,'F32Bits')&&Object.keys(value).length===1)){throw Error('invalid value for wire schema');}bits=value.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295){throw Error('invalid value for wire schema');}}budget.add(4);return __nfFromBits(bits);}
function __privateCapture2(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='number'||!Number.isInteger(value)||value<0||value>4294967295){throw Error('invalid value for wire schema');}budget.add(4);return value===0?0:value;}
function __privateWireValue26(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue25(reader);reader.finish(end);return value;}
function __privateWireValue4(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue0(reader);reader.finish(end);return value;}
function __privateWireValue29(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue22(reader);reader.finish(end);return value;}
function __privateWireValue7(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue1(reader);reader.finish(end);return value;}
function __privateWireValue14(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue2(reader);reader.finish(end);return value;}
function __privateWireValue3(reader){const end=reader.frame();const value={};reader.finish(end);return value;}
function __privateWireValue28(reader){const end=reader.frame();const value={["__ink_differential_15"]:__privateWireValue22(reader),["__ink_differential_16"]:__privateWireValue22(reader)};reader.finish(end);return value;}
function __privateWireValue34(reader){const end=reader.frame();const value={["__ink_differential_22"]:__privateWireValue22(reader),["__ink_differential_23"]:__privateWireValue22(reader)};reader.finish(end);return value;}
function __privateWireValue36(reader){const end=reader.frame();const value={["__ink_differential_26"]:__privateWireValue22(reader),["__ink_differential_27"]:__privateWireValue22(reader)};reader.finish(end);return value;}
function __privateWireValue23(reader){const end=reader.frame();const value={["__ink_differential_8"]:__privateWireValue22(reader),["__ink_differential_9"]:__privateWireValue22(reader)};reader.finish(end);return value;}
function __privateWireValue20(reader){const end=reader.frame();const value={["c"]:__privateWireValue16(reader)};reader.finish(end);return value;}
function __privateWireValue30(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue22(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue26(reader),["features"]:__privateWireValue29(reader),["row"]:__privateWireValue2(reader),["base"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue31(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue22(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue26(reader),["features"]:__privateWireValue29(reader),["row"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue37(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue22(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue26(reader),["features"]:__privateWireValue29(reader),["targets"]:__privateWireValue29(reader),["row"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue27(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue22(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue26(reader),["index"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue32(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue22(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue26(reader),["inputs"]:__privateWireValue29(reader),["base"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue33(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue22(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue26(reader),["inputs"]:__privateWireValue29(reader)};reader.finish(end);return value;}
function __privateWireValue8(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue1(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue4(reader),["features"]:__privateWireValue7(reader),["row"]:__privateWireValue2(reader),["base"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue10(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue1(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue4(reader),["features"]:__privateWireValue7(reader),["row"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue13(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue1(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue4(reader),["features"]:__privateWireValue7(reader),["targets"]:__privateWireValue7(reader),["row"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue5(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue1(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue4(reader),["index"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue9(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue1(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue4(reader),["inputs"]:__privateWireValue7(reader),["base"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue11(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue1(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue4(reader),["inputs"]:__privateWireValue7(reader)};reader.finish(end);return value;}
function __privateWireValue17(reader){const end=reader.frame();const value={["p"]:__privateWireValue0(reader),["g"]:__privateWireValue1(reader),["c"]:__privateWireValue16(reader)};reader.finish(end);return value;}
function __privateWireValue19(reader){const end=reader.frame();const value={["p"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue15(reader){const end=reader.frame();const value={["parameters"]:__privateWireValue4(reader),["features"]:__privateWireValue7(reader),["targets"]:__privateWireValue7(reader),["rows"]:__privateWireValue14(reader)};reader.finish(end);return value;}
function __privateWireValue21(reader){const end=reader.frame();const value={["parameters"]:__privateWireValue4(reader),["gradient"]:__privateWireValue7(reader),["admissible"]:__privateWireValue18(reader),["c"]:__privateWireValue16(reader)};reader.finish(end);return value;}
function __privateWireValue35(reader){const end=reader.frame();const value={["prediction"]:__privateWireValue22(reader),["target"]:__privateWireValue22(reader)};reader.finish(end);return value;}
function __privateWireValue12(reader){const end=reader.frame();const value={["prediction"]:__privateWireValue1(reader),["target"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue16(reader){const end=reader.frame();const value={["rate"]:__privateWireValue1(reader),["first_decay"]:__privateWireValue1(reader),["second_decay"]:__privateWireValue1(reader),["epsilon"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue25(reader){const end=reader.frame();const value={["value"]:__privateWireValue22(reader),["first"]:__privateWireValue22(reader),["second"]:__privateWireValue22(reader),["first_power"]:__privateWireValue22(reader),["second_power"]:__privateWireValue22(reader),["steps"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue24(reader){const end=reader.frame();const value={["value"]:__privateWireValue22(reader),["gate"]:__privateWireValue22(reader)};reader.finish(end);return value;}
function __privateWireValue0(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["first"]:__privateWireValue1(reader),["second"]:__privateWireValue1(reader),["first_power"]:__privateWireValue1(reader),["second_power"]:__privateWireValue1(reader),["steps"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue6(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["gate"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue22(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["tangent"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue18(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __privateWireValue1(reader){const end=reader.frame();const value=__nfFromBits(reader.word());reader.finish(end);return value;}
function __privateWireValue2(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __compiledOwnedValue10(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue9(value[i],budget,depth+1);return out;}
function __compiledOwnedValue3(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue0(value[i],budget,depth+1);return out;}
function __compiledOwnedValue11(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue8(value[i],budget,depth+1);return out;}
function __compiledOwnedValue4(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue1(value[i],budget,depth+1);return out;}
function __compiledOwnedValue5(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue2(value[i],budget,depth+1);return out;}
function __compiledOwnedValue6(value,budget,depth){budget.enter(depth,4);return {["rate"]:__compiledOwnedValue1(value["rate"],budget,depth+1),["first_decay"]:__compiledOwnedValue1(value["first_decay"],budget,depth+1),["second_decay"]:__compiledOwnedValue1(value["second_decay"],budget,depth+1),["epsilon"]:__compiledOwnedValue1(value["epsilon"],budget,depth+1)};}
function __compiledOwnedValue9(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue8(value["value"],budget,depth+1),["first"]:__compiledOwnedValue8(value["first"],budget,depth+1),["second"]:__compiledOwnedValue8(value["second"],budget,depth+1),["first_power"]:__compiledOwnedValue8(value["first_power"],budget,depth+1),["second_power"]:__compiledOwnedValue8(value["second_power"],budget,depth+1),["steps"]:__compiledOwnedValue2(value["steps"],budget,depth+1)};}
function __compiledOwnedValue0(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["first"]:__compiledOwnedValue1(value["first"],budget,depth+1),["second"]:__compiledOwnedValue1(value["second"],budget,depth+1),["first_power"]:__compiledOwnedValue1(value["first_power"],budget,depth+1),["second_power"]:__compiledOwnedValue1(value["second_power"],budget,depth+1),["steps"]:__compiledOwnedValue2(value["steps"],budget,depth+1)};}
function __compiledOwnedValue8(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["tangent"]:__compiledOwnedValue1(value["tangent"],budget,depth+1)};}
function __compiledOwnedValue7(value,budget,depth){budget.enter(depth,5);return value;}
function __compiledOwnedValue1(value,budget,depth){budget.enter(depth,8);const bits=typeof value==='number'?__bits(value):value.F32Bits;return {F32Bits:bits===0?0:bits};}
function __compiledOwnedValue2(value,budget,depth){budget.enter(depth,8);return value>>>0;}
function __privateWireWrite10(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite9(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite3(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite0(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite11(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite8(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite4(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite1(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite5(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite2(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite6(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["rate"],compact);__privateWireWrite1(writer,value["first_decay"],compact);__privateWireWrite1(writer,value["second_decay"],compact);__privateWireWrite1(writer,value["epsilon"],compact);writer.closeFrame(frame);}
function __privateWireWrite9(writer,value,compact){const frame=writer.openFrame();__privateWireWrite8(writer,value["value"],compact);__privateWireWrite8(writer,value["first"],compact);__privateWireWrite8(writer,value["second"],compact);__privateWireWrite8(writer,value["first_power"],compact);__privateWireWrite8(writer,value["second_power"],compact);__privateWireWrite2(writer,value["steps"],compact);writer.closeFrame(frame);}
function __privateWireWrite0(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite1(writer,value["first"],compact);__privateWireWrite1(writer,value["second"],compact);__privateWireWrite1(writer,value["first_power"],compact);__privateWireWrite1(writer,value["second_power"],compact);__privateWireWrite2(writer,value["steps"],compact);writer.closeFrame(frame);}
function __privateWireWrite8(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite1(writer,value["tangent"],compact);writer.closeFrame(frame);}
function __privateWireWrite7(writer,value,compact){const frame=writer.openFrame();writer.byte(value?1:0);writer.closeFrame(frame);}
function __privateWireWrite1(writer,value,compact){const frame=writer.openFrame();writer.word(__nfBits(value));writer.closeFrame(frame);}
function __privateWireWrite2(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
// Handles have no mutable private payload surface. Membership and type identity
// are checked by this module's closure; copied/foreign objects cannot forge them.
const __compiledHandles=new WeakMap();
const __compiledBindings=new WeakMap();
function __compiledHandle(identity,value,guaranteed=false){
 const handle=Object.freeze(Object.create(null));
 __compiledHandles.set(handle,{identity,value,guaranteed});return handle;
}
function __compiledEntry(handle,identity){
 const entry=__compiledHandles.get(handle);
 if(!entry||entry.identity!==identity)throw Error('compiled value type or owner mismatch');
 return entry;
}
function __compiledUnwrap(handle,identity){return __compiledEntry(handle,identity).value;}
// Emit the portable schema's framing/scalar events without creating a buffer
// or exposing private composite nodes. Only this wrapper receives callbacks
// from the literal writer; host visitors never receive those closures.
function __compiledValueEvents(sink,limits){
 const methods=['begin','end','byte','word','wide','text','count'];
 for(const name of methods)if(typeof sink?.[name]!=='function')throw Error('compiled value visitor method: '+name);
 const budget=createValueCaptureBudget(limits);let depth=0,closed=false;
 const active=()=>{if(closed)throw Error('compiled value visitor is closed');};
 const writer=Object.freeze({
  openFrame(){active();budget.enter(depth,4);depth++;sink.begin();return 0;}
  ,closeFrame(){active();if(depth===0)throw Error('wire frame boundary');try{sink.end();}finally{depth--;}}
  ,frame(emit){active();budget.enter(depth,4);depth++;sink.begin();try{emit();sink.end();}finally{depth--;}}
  ,byte(value){active();budget.add(1);sink.byte(value);}
  ,word(value){active();budget.add(4);sink.word(value);}
  ,wide(value){active();budget.add(8);sink.wide(value);}
  ,text(value){active();budget.text(value);sink.text(value);}
  ,count(value){active();budget.add(4);if(value>budget.remaining)throw Error('wire sequence size');sink.count(value);}
 });
 return {writer,close(){closed=true;}};
}
function __compiledReduction(factory,root,reduce,identity){
 if(typeof factory!=='function')throw Error('compiled reduction factory');
 const reducers=[],seen=new Set(),nodes=__reductionNodes();
 const prepare=index=>{
  if(seen.has(index))return;seen.add(index);
  const node=nodes[index];
  for(const child of node.children)prepare(child);
  const reducer=factory(node,index);
  if(node.kind==='list'||node.kind==='vector'){
   const start=reducer?.start,step=reducer?.step,finish=reducer?.finish;
   if(typeof start!=='function'||typeof step!=='function'||typeof finish!=='function')throw Error('compiled collection reduction');
   reducers[index]=Object.freeze({start,step,finish});
  }else{
   if(typeof reducer!=='function')throw Error('compiled value reduction');
   reducers[index]=reducer;
  }
 };
 prepare(root);Object.freeze(reducers);
 return Object.freeze(function(handle,context,limits={}){
  const value=__compiledUnwrap(handle,identity),budget=createValueCaptureBudget(limits);
  return reduce(value,reducers,budget,0,context);
 });
}
function __compiledCodec(schema,capture,read,write,copy,constructorRoot,reductionRoot,reduce,portableFused=false,compactFused=false){
 const privateCodec=createCompiledValueCodec(schema,read),publicCodec=privateCodec;
 let fusedCodec;const fused=()=>fusedCodec??=createFusedValueCodec(schema,read);
 const identity=schema.identity;
 const codec=Object.freeze({
  identity,
  descriptor:publicCodec.descriptor,
  resolve(type){return publicCodec.resolve(type);},
  capture(value,limits={}){
   return __compiledHandle(identity,capture(value,createValueCaptureBudget(limits),0));
  },
  decode(bytes,limits={}){return __compiledHandle(identity,(portableFused?fused():privateCodec).decode(bytes,limits));},
  decodeCompact(bytes,limits={}){return __compiledHandle(identity,(compactFused?fused():privateCodec).compact().decode(bytes,limits));},
  decodeFused(bytes,limits={}){return __compiledHandle(identity,fused().decode(bytes,limits));},
  decodeCompactFused(bytes,limits={}){return __compiledHandle(identity,fused().compact().decode(bytes,limits));},
  encode(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.encodeWith(writer=>write(writer,value,false),limits);},
  encodeCompact(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.compact().encodeWith(writer=>write(writer,value,true),limits);},
  materialize(handle,limits={}){return copy(__compiledUnwrap(handle,identity),createValueCaptureBudget(limits),0);},
  builder(limits={}){return __valueBuilder(__constructorNodes(),constructorRoot,identity,limits);},
  reducer(factory){return __compiledReduction(factory,reductionRoot,reduce,identity);},
  visit(handle,sink,limits={}){
   const value=__compiledUnwrap(handle,identity),events=__compiledValueEvents(sink,limits);
   try{write(events.writer,value,false);}finally{events.close();}
  },
 });
 __compiledBindings.set(codec,{publicCodec,write,capture});return codec;
}

function __compiledEncodeResult(entry,value,limits,compact){
 const {publicCodec,write}=__compiledBindings.get(entry.result());
 return (compact?publicCodec.compact():publicCodec).encodeWith(writer=>write(writer,value,compact),limits);
}
let __constructorNodesValue;function __constructorNodes(){return __constructorNodesValue??=[{kind:'record',fields:["value","first","second","first_power","second_power","steps"],patterns:[{bytes:4,label:"record",children:[1,1,1,1,1,2],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["first"]:values[1],["second"]:values[2],["first_power"]:values[3],["second_power"]:values[4],["steps"]:values[5]})}]},{kind:"f32",scalar:__privateCapture1},{kind:"u32",scalar:__privateCapture2},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[0],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[1],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[2],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["rate","first_decay","second_decay","epsilon"],patterns:[{bytes:4,label:"record",children:[1,1,1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["rate"]:values[0],["first_decay"]:values[1],["second_decay"]:values[2],["epsilon"]:values[3]})}]},{kind:"bool",scalar:__privateCapture7},{kind:'record',fields:["value","tangent"],patterns:[{bytes:4,label:"record",children:[1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["tangent"]:values[1]})}]},{kind:'record',fields:["value","first","second","first_power","second_power","steps"],patterns:[{bytes:4,label:"record",children:[8,8,8,8,8,2],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["first"]:values[1],["second"]:values[2],["first_power"]:values[3],["second_power"]:values[4],["steps"]:values[5]})}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[9],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[8],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]}];}
// Typed input construction only: plans contain literal constructor/capture
// functions emitted from source schemas. No source expression evaluator.
// All frames and private values remain in this closure; callers receive only
// an owned opaque handle after one complete, well-typed root is constructed.
const __constructorPaths=new WeakMap();
function __valueBuilder(nodes,root,identity,limits){
 const budget=createValueCaptureBudget(limits),frames=[];
 let result,targetNode,targetDepth,complete=false,closed=false,failed=false,busy=false;
 const fail=message=>{failed=true;frames.length=0;result=undefined;throw Error(message);};
 const active=()=>{if(failed||closed)throw Error('value builder is closed');};
 const expected=()=>{
  if(!frames.length){if(complete)fail('value builder root already complete');targetNode=root;targetDepth=0;return;}
  const frame=frames.at(-1),position=frame.values.length;
  if(!frame.pattern.sequence&&position>=frame.pattern.children.length)fail('value builder constructor is full');
  targetNode=frame.pattern.sequence?frame.pattern.children[0]:frame.pattern.children[position];targetDepth=frame.depth+frame.pattern.childDepth;
 };
 const accept=value=>{
  if(frames.length)frames.at(-1).values.push(value);
  else{result=value;complete=true;}
 };
 const execute=(operation,first,second)=>{
  active();if(busy)throw Error('value builder operation already active');busy=true;
  try{return operation(first,second);}catch(error){failed=true;frames.length=0;result=undefined;throw error;}finally{busy=false;}
 };
 // Compile and cache constructor paths independently of the session's values.
 const pathPlan=(choices,startNode,startDepth)=>{
   if(!Array.isArray(choices)||choices.length===0||choices.length>128)fail('invalid value builder path');
   let cache=__constructorPaths.get(nodes);if(!cache){cache=new WeakMap();__constructorPaths.set(nodes,cache);}
   let entries=cache.get(choices),saved=entries?.get(startNode);
   if(saved)return saved;
   const path=[],charges=[];let node=startNode,depth=startDepth;
   for(let i=0;i<choices.length;i++){
    const choice=choices[i],patterns=nodes[node].patterns;
    if(!Number.isSafeInteger(choice)||choice<0||!patterns||choice>=patterns.length)fail('invalid value builder constructor');
    const pattern=patterns[choice];charges.push([pattern,depth-startDepth]);path.push({pattern,node:nodes[node]});
    if(i+1<choices.length){if(pattern.sequence||pattern.children.length!==1)fail('value builder path is not unary');node=pattern.children[0];depth+=pattern.childDepth;}
   }
   const terminal=path.at(-1).pattern;
   // Compose literal constructor functions once per path, instead of
   // allocating and interpreting another recursive closure for every value.
   const compose=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=args=>args[0];
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=args=>p.make([inner(args)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?compose(last+1):args=>args[0]):compose(last);
     return args=>node.flat(index,payload(args));
    }
    const inner=at+1<path.length?compose(at+1):null;
    if(pattern.transparent)return inner??(args=>args[0]);
    return inner?args=>pattern.make([inner(args)]):pattern.make;
   };
   const make=compose(0);
   // Scalar paths use the same literal constructors, but pass the leaf
   // directly through erased records and flat sums. No temporary argument
   // array is needed at those edges. Ordinary constructors keep their array
   // calling convention; no private value reaches the public builder API.
   const composeScalar=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=value=>value;
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=value=>p.make([inner(value)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?composeScalar(last+1):value=>value):composeScalar(last);
     return value=>node.flat(index,payload(value));
    }
    const inner=at+1<path.length?composeScalar(at+1):null;
    if(pattern.transparent)return inner??(value=>value);
    return inner?value=>pattern.make([inner(value)]):value=>pattern.make([value]);
   };
   const scalar=composeScalar(0);
   const pattern={...terminal,make};
   // Only frozen arrays of ordinary data properties can key reusable plans.
   // Mutable arrays and frozen accessor arrays retain checked per-call paths.
   const fixed=charges.every(([p])=>Number.isSafeInteger(p.bytes)&&p.bytes>=4);
   const plan={pattern,scalar,charges,offset:depth-startDepth,bytes:fixed?charges.reduce((n,[p])=>n+p.bytes,0):null};
   let reusable=Object.isFrozen(choices);
   for(let i=0;reusable&&i<choices.length;i++){const field=Object.getOwnPropertyDescriptor(choices,String(i));reusable=!!field&&Object.hasOwn(field,'value');}
   if(reusable){
    if(!entries){entries=new Map();cache.set(choices,entries);}entries.set(startNode,plan);
   }
   return plan;
 };
 const chargePath=(plan,depth)=>{
  // Each emitted constructor consumes one node and a fixed frame/tag cost.
  // Only take the combined charge when every original check would succeed.
  // Replaying the original order retains the exact first failure otherwise.
  if(plan.bytes!==null&&depth+plan.offset<=budget.depth&&plan.charges.length<=budget.remaining&&budget.bytes+plan.bytes<=budget.limit){
   budget.remaining-=plan.charges.length;budget.bytes+=plan.bytes;return;
  }
  for(const [pattern,offset]of plan.charges)pattern.charge(budget,depth+offset);
 };
 // Operations are allocated once per session, and share expected-node
 // scratch only while the existing reentrancy guard is held.
 const openOperation=(choice)=>{
   expected();const node=nodes[targetNode];
   if(!Number.isSafeInteger(choice)||choice<0||!node.patterns||choice>=node.patterns.length)fail('invalid value builder constructor');
   const pattern=node.patterns[choice];pattern.charge(budget,targetDepth);
   frames.push({pattern,depth:targetDepth,values:[]});
 };
 const openPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth);
   chargePath(plan,targetDepth);
   frames.push({pattern:plan.pattern,depth:targetDepth+plan.offset,values:[]});
 };
 const scalarPathOperation=(choices,value)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==1)fail('value builder path has no scalar leaf');
   const capture=nodes[pattern.children[0]].scalar;
   if(typeof capture!=='function')fail('value builder path has no scalar leaf');
   chargePath(plan,targetDepth);
   const leaf=capture(value,budget,targetDepth+plan.offset+pattern.childDepth);
   accept(plan.scalar(leaf));
 };
 const emptyPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==0)fail('value builder path is not empty');
   chargePath(plan,targetDepth);accept(pattern.make([]));
 };
 const scalarOperation=(value)=>{
   expected();const capture=nodes[targetNode].scalar;
   if(typeof capture!=='function')fail('value builder expects a constructor');
   accept(capture(value,budget,targetDepth));
 };
 const closeOperation=()=>{
   if(!frames.length)fail('value builder has no open constructor');
   const frame=frames.at(-1),pattern=frame.pattern,count=frame.values.length;
   if(!pattern.sequence&&count!==pattern.children.length||pattern.size!==undefined&&count!==pattern.size)fail('value builder constructor arity');
   if(pattern.sequence&&count>budget.limit)fail('wire sequence size');
   const value=pattern.make(frame.values);
   frames.pop();accept(value);
 };
 const finishOperation=()=>{
   if(frames.length||!complete)fail('value builder root is incomplete');
   closed=true;const handle=__compiledHandle(identity,result);result=undefined;return handle;
 };
 const api=Object.freeze({
  open(choice){return execute(openOperation,choice);},
  // Charge every source constructor even when unary paths share one frame.
  openPath(choices){return execute(openPathOperation,choices);},
  // Complete the path and leaf without intermediate session frames.
  scalarPath(choices,value){return execute(scalarPathOperation,choices,value);},
  emptyPath(choices){return execute(emptyPathOperation,choices);},
  scalar(value){return execute(scalarOperation,value);},
  close(){return execute(closeOperation);},
  finish(){return execute(finishOperation);},
  abort(){if(busy)throw Error('value builder operation already active');failed=true;frames.length=0;result=undefined;},
 });
 return api;
}
function __reduceValue0(value,r,b,d,c){b.enter(d,4);return r[0](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue1(value["first"],r,b,d+1,c),__reduceValue1(value["second"],r,b,d+1,c),__reduceValue1(value["first_power"],r,b,d+1,c),__reduceValue1(value["second_power"],r,b,d+1,c),__reduceValue2(value["steps"],r,b,d+1,c),c);}
function __reduceValue1(value,r,b,d,c){b.enter(d,8);return r[1]({F32Bits:__nfBits(value)},c);}
function __reduceValue2(value,r,b,d,c){b.enter(d,8);return r[2](value,c);}
function __reduceValue3(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[3];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue0(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue4(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[4];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue1(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue5(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[5];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue2(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue6(value,r,b,d,c){b.enter(d,4);return r[6](__reduceValue1(value["rate"],r,b,d+1,c),__reduceValue1(value["first_decay"],r,b,d+1,c),__reduceValue1(value["second_decay"],r,b,d+1,c),__reduceValue1(value["epsilon"],r,b,d+1,c),c);}
function __reduceValue7(value,r,b,d,c){b.enter(d,5);return r[7](value,c);}
function __reduceValue8(value,r,b,d,c){b.enter(d,4);return r[8](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue1(value["tangent"],r,b,d+1,c),c);}
function __reduceValue9(value,r,b,d,c){b.enter(d,4);return r[9](__reduceValue8(value["value"],r,b,d+1,c),__reduceValue8(value["first"],r,b,d+1,c),__reduceValue8(value["second"],r,b,d+1,c),__reduceValue8(value["first_power"],r,b,d+1,c),__reduceValue8(value["second_power"],r,b,d+1,c),__reduceValue2(value["steps"],r,b,d+1,c),c);}
function __reduceValue10(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[10];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue9(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue11(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[11];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue8(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
let __reductionNodeCache;function __reductionNodes(){return __reductionNodeCache??=Object.freeze([Object.freeze({"children":Object.freeze([1,1,1,1,1,2]),"fields":Object.freeze(["value","first","second","first_power","second_power","steps"]),"kind":"record","name":"Parameter"}),Object.freeze({"children":Object.freeze([]),"kind":"f32"}),Object.freeze({"children":Object.freeze([]),"kind":"u32"}),Object.freeze({"children":Object.freeze([0]),"kind":"list"}),Object.freeze({"children":Object.freeze([1]),"kind":"list"}),Object.freeze({"children":Object.freeze([2]),"kind":"list"}),Object.freeze({"children":Object.freeze([1,1,1,1]),"fields":Object.freeze(["rate","first_decay","second_decay","epsilon"]),"kind":"record","name":"Config"}),Object.freeze({"children":Object.freeze([]),"kind":"bool"}),Object.freeze({"children":Object.freeze([1,1]),"fields":Object.freeze(["value","tangent"]),"kind":"record","name":"__ink_differential_0"}),Object.freeze({"children":Object.freeze([8,8,8,8,8,2]),"fields":Object.freeze(["value","first","second","first_power","second_power","steps"]),"kind":"record","name":"__ink_differential_3"}),Object.freeze({"children":Object.freeze([9]),"kind":"list"}),Object.freeze({"children":Object.freeze([8]),"kind":"list"})]);}
function __compiledNamed0(){return {};}
let __compiledCodec0Value;function __compiledCodec0(){return __compiledCodec0Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"7cd0db7bd067c6137d0451073ecc71755d81ac9dbc8526c5cda3a6cf0de894c3","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}},__privateCapture0,__privateWireValue0,__privateWireWrite0,__compiledOwnedValue0,0,0,__reduceValue0,false,false);}
let __compiledCodec1Value;function __compiledCodec1(){return __compiledCodec1Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":__compiledNamed0(),"root":{"kind":"f32"}},__privateCapture1,__privateWireValue1,__privateWireWrite1,__compiledOwnedValue1,1,1,__reduceValue1,false,false);}
let __compiledCodec2Value;function __compiledCodec2(){return __compiledCodec2Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff","named":__compiledNamed0(),"root":{"kind":"u32"}},__privateCapture2,__privateWireValue2,__privateWireWrite2,__compiledOwnedValue2,2,2,__reduceValue2,false,false);}
let __compiledCodec3Value;function __compiledCodec3(){return __compiledCodec3Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"7e4dba74ea4a212e87b655db607b4b675c6150a5e6af015142def3ed7d7aa96c","named":__compiledNamed0(),"root":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},__privateCapture3,__privateWireValue4,__privateWireWrite3,__compiledOwnedValue3,3,3,__reduceValue3,false,false);}
let __compiledCodec4Value;function __compiledCodec4(){return __compiledCodec4Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":__compiledNamed0(),"root":{"element":{"kind":"f32"},"kind":"list"}},__privateCapture4,__privateWireValue7,__privateWireWrite4,__compiledOwnedValue4,4,4,__reduceValue4,false,false);}
let __compiledCodec5Value;function __compiledCodec5(){return __compiledCodec5Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"69ebf947aa59a2546656d1976b0baa6e56e7182d989425379b31e3bff74168ca","named":__compiledNamed0(),"root":{"element":{"kind":"u32"},"kind":"list"}},__privateCapture5,__privateWireValue14,__privateWireWrite5,__compiledOwnedValue5,5,5,__reduceValue5,false,false);}
let __compiledCodec6Value;function __compiledCodec6(){return __compiledCodec6Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"5c8fe4541f6e6c7176cad3a2fe6f317eae7cccf5413e86bb30ef5fa039ae35ca","named":__compiledNamed0(),"root":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}},__privateCapture6,__privateWireValue16,__privateWireWrite6,__compiledOwnedValue6,6,6,__reduceValue6,false,false);}
let __compiledCodec7Value;function __compiledCodec7(){return __compiledCodec7Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":__compiledNamed0(),"root":{"kind":"bool"}},__privateCapture7,__privateWireValue18,__privateWireWrite7,__compiledOwnedValue7,7,7,__reduceValue7,false,false);}
let __compiledCodec8Value;function __compiledCodec8(){return __compiledCodec8Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},__privateCapture8,__privateWireValue22,__privateWireWrite8,__compiledOwnedValue8,8,8,__reduceValue8,false,false);}
let __compiledCodec9Value;function __compiledCodec9(){return __compiledCodec9Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"bb1fd39ad8ae6c174bdc7c93bf326cea4848e5d07efb08ff6da1bad448ba9329","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"}},__privateCapture9,__privateWireValue25,__privateWireWrite9,__compiledOwnedValue9,9,9,__reduceValue9,false,false);}
let __compiledCodec10Value;function __compiledCodec10(){return __compiledCodec10Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"c686b1c555370cd2072b8991eb3bd930522c291627d0145fea1087bcba45e9f3","named":__compiledNamed0(),"root":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},__privateCapture10,__privateWireValue26,__privateWireWrite10,__compiledOwnedValue10,10,10,__reduceValue10,false,false);}
let __compiledCodec11Value;function __compiledCodec11(){return __compiledCodec11Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"cdde982e98b457eca63f0b1f56713939bdd8ddf70f5be35e930642c404861714","named":__compiledNamed0(),"root":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},__privateCapture11,__privateWireValue29,__privateWireWrite11,__compiledOwnedValue11,11,11,__reduceValue11,false,false);}
const __compiledEntries=new Map([["empty_parameter",{index:0,params:[],result:__compiledCodec0,arguments:__privateWireValue3,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[],precondition:null}],["parameter",{index:1,params:[__compiledCodec1,__compiledCodec2,__compiledCodec3,__compiledCodec2],result:__compiledCodec1,arguments:__privateWireValue5,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["reglu",{index:2,params:[__compiledCodec1,__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue6,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["dot10",{index:3,params:[__compiledCodec1,__compiledCodec2,__compiledCodec3,__compiledCodec4,__compiledCodec2,__compiledCodec2],result:__compiledCodec1,arguments:__privateWireValue8,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false,false],precondition:null}],["dot6",{index:4,params:[__compiledCodec1,__compiledCodec2,__compiledCodec3,__compiledCodec4,__compiledCodec2],result:__compiledCodec1,arguments:__privateWireValue9,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false],precondition:null}],["first_layer",{index:5,params:[__compiledCodec1,__compiledCodec2,__compiledCodec3,__compiledCodec4,__compiledCodec2],result:__compiledCodec4,arguments:__privateWireValue10,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false],precondition:null}],["second_layer",{index:6,params:[__compiledCodec1,__compiledCodec2,__compiledCodec3,__compiledCodec4],result:__compiledCodec4,arguments:__privateWireValue11,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["outputs",{index:7,params:[__compiledCodec1,__compiledCodec2,__compiledCodec3,__compiledCodec4,__compiledCodec2],result:__compiledCodec4,arguments:__privateWireValue10,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false],precondition:null}],["squared_error",{index:8,params:[__compiledCodec1,__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue12,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["objective",{index:9,params:[__compiledCodec1,__compiledCodec2,__compiledCodec3,__compiledCodec4,__compiledCodec4,__compiledCodec2],result:__compiledCodec1,arguments:__privateWireValue13,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false,false],precondition:null}],["gradients",{index:10,params:[__compiledCodec3,__compiledCodec4,__compiledCodec4,__compiledCodec5],result:__compiledCodec4,arguments:__privateWireValue15,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["candidate",{index:11,params:[__compiledCodec0,__compiledCodec1,__compiledCodec6],result:__compiledCodec0,arguments:__privateWireValue17,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["valid",{index:12,params:[__compiledCodec0],result:__compiledCodec7,arguments:__privateWireValue19,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["configuration",{index:13,params:[__compiledCodec6],result:__compiledCodec7,arguments:__privateWireValue20,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["shape",{index:14,params:[__compiledCodec3,__compiledCodec4,__compiledCodec4,__compiledCodec5],result:__compiledCodec7,arguments:__privateWireValue15,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["update",{index:15,params:[__compiledCodec3,__compiledCodec4,__compiledCodec7,__compiledCodec6],result:__compiledCodec3,arguments:__privateWireValue21,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["losses",{index:16,params:[__compiledCodec3,__compiledCodec4,__compiledCodec4,__compiledCodec5],result:__compiledCodec4,arguments:__privateWireValue15,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["__ink_differential_7",{index:17,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,arguments:__privateWireValue23,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_6",{index:18,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,arguments:__privateWireValue24,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_13",{index:19,params:[],result:__compiledCodec9,arguments:__privateWireValue3,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[],precondition:null}],["__ink_differential_12",{index:20,params:[__compiledCodec8,__compiledCodec2,__compiledCodec10,__compiledCodec2],result:__compiledCodec8,arguments:__privateWireValue27,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["__ink_differential_14",{index:21,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,arguments:__privateWireValue28,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_11",{index:22,params:[__compiledCodec8,__compiledCodec2,__compiledCodec10,__compiledCodec11,__compiledCodec2,__compiledCodec2],result:__compiledCodec8,arguments:__privateWireValue30,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false,false],precondition:null}],["__ink_differential_5",{index:23,params:[__compiledCodec8,__compiledCodec2,__compiledCodec10,__compiledCodec11,__compiledCodec2],result:__compiledCodec11,arguments:__privateWireValue31,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false],precondition:null}],["__ink_differential_19",{index:24,params:[__compiledCodec8,__compiledCodec2,__compiledCodec10,__compiledCodec11,__compiledCodec2],result:__compiledCodec8,arguments:__privateWireValue32,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false],precondition:null}],["__ink_differential_18",{index:25,params:[__compiledCodec8,__compiledCodec2,__compiledCodec10,__compiledCodec11],result:__compiledCodec11,arguments:__privateWireValue33,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["__ink_differential_4",{index:26,params:[__compiledCodec8,__compiledCodec2,__compiledCodec10,__compiledCodec11,__compiledCodec2],result:__compiledCodec11,arguments:__privateWireValue31,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false],precondition:null}],["__ink_differential_21",{index:27,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,arguments:__privateWireValue34,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_20",{index:28,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,arguments:__privateWireValue35,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_25",{index:29,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,arguments:__privateWireValue36,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_2",{index:30,params:[__compiledCodec8,__compiledCodec2,__compiledCodec10,__compiledCodec11,__compiledCodec11,__compiledCodec2],result:__compiledCodec8,arguments:__privateWireValue37,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false,false],precondition:null}],["__ink_differential_1",{index:31,params:[__compiledCodec1,__compiledCodec2,__compiledCodec3,__compiledCodec4,__compiledCodec4,__compiledCodec2],result:__compiledCodec1,arguments:__privateWireValue13,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false,false],precondition:null}]]);

export const compiledValues=Object.freeze(Object.fromEntries([...__compiledEntries].map(([name,entry])=>[name,Object.freeze({get params(){return Object.freeze(entry.params.map(codec=>codec()));},get result(){return entry.result();}})])));
function __compiledValidate(entry,owned){
 const values=owned.map(v=>v.value);
 const established=entry.onlyTypeGuards&&entry.needsInvariants.every((needed,i)=>!needed||owned[i].guaranteed);
 if(entry.precondition!==null&&!established){
  if(__implementations[entry.precondition](...values)!==true)throw Error('contract precondition failed');
  for(let i=0;i<owned.length;i++)if(entry.needsInvariants[i])owned[i].guaranteed=true;
 }
 return values;
}
export function callCompiled(name,args){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(args)||args.length!==entry.params.length)throw Error('unsupported compiled call');
 const owned=entry.params.map((codec,i)=>__compiledEntry(args[i],codec().identity)),values=__compiledValidate(entry,owned);
 // Checked source outputs satisfy their declared value interfaces. Private
 // handles expose only detached copies and never retain mutable host inputs.
 return __compiledHandle(entry.result().identity,__implementations[entry.index](...values),true);
}

// Explicit sealed-value partial application. Each token owns a bounded set of
// lexical caches; no mutable host object, global memo table or error is retained.
const __preparedCompiled=new WeakMap();
export function prepareCompiled(name,bindings){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(bindings)||bindings.length>entry.params.length)throw Error('unsupported prepared compiled call');
 const captured=new Array(entry.params.length),fixed=new Array(entry.params.length).fill(false);
 for(const binding of bindings){
  if(!Array.isArray(binding)||binding.length!==2)throw Error('prepared compiled binding');
  const [index,handle]=binding;
  if(!Number.isInteger(index)||index<0||index>=fixed.length||fixed[index])throw Error('prepared compiled parameter');
  captured[index]=__compiledEntry(handle,entry.params[index]().identity);fixed[index]=true;
 }
 const remaining=fixed.flatMap((yes,i)=>yes?[]:[i]);
 const factory=__preparedFactories.get(entry.index);
 const run=factory?factory(fixed):__implementations[entry.index];
 const token=Object.freeze(Object.create(null));
 __preparedCompiled.set(token,{entry,captured,remaining,run});return token;
}
export function callPreparedCompiled(token,args){
 const prepared=__preparedCompiled.get(token);
 if(!prepared||!Array.isArray(args)||args.length!==prepared.remaining.length)throw Error('invalid prepared compiled call');
 const {entry,captured,remaining,run}=prepared,owned=captured.slice();
 for(let i=0;i<remaining.length;i++){const at=remaining[i];owned[at]=__compiledEntry(args[i],entry.params[at]().identity);}
 const values=__compiledValidate(entry,owned);
 return __compiledHandle(entry.result().identity,run(...values),true);
}
const __intoOutput5=__representation(metadata.functions[5].result.element,true);
const __intoOutput6=__representation(metadata.functions[6].result.element,true);
const __intoOutput7=__representation(metadata.functions[7].result.element,true);
const __intoOutput10=__representation(metadata.functions[10].result.element,true);
const __intoOutput15=__representation(metadata.functions[15].result.element,true);
const __intoOutput16=__representation(metadata.functions[16].result.element,true);
const __intoOutput23=__representation(metadata.functions[23].result.element,true);
const __intoOutput25=__representation(metadata.functions[25].result.element,true);
const __intoOutput26=__representation(metadata.functions[26].result.element,true);
const __intoImplementations=[null,null,null,null,null,__into5,__into6,__into7,null,null,__into10,null,null,null,null,__into15,__into16,null,null,null,null,null,null,__into23,null,__into25,__into26,null,null,null,null,null];

export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>{
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const body=__intoImplementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args.slice(0,f.params.length))!==true)throw Error('contract precondition failed');return body(...args);};
  const entry=input.every(c=>c===__identity)?implementation:(...values)=>{const context=new WeakMap();return implementation(...input.map((convert,i)=>convert(values[i],context)),values[f.params.length]);};
  return [f.name,entry];
})));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}

function __preparedPart(mask,path){
 for(const field of path){
  if(mask===true)return true;
  if(!mask || typeof mask!=="object")return false;
  mask=Object.hasOwn(mask.fields,field)?mask.fields[field]:false;
 }
 return mask;
}
function __preparedStable(mask,path){const part=__preparedPart(mask,path);return part===true || (!!part && part.all===true);}
function __prepareFn3(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[5],[]))))return __fn3;const v1876=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[5],[]);
let v1875=false,v1874;
return function(v1867,v1868,v1869,v1870,v1871,v1872){v1867=__nfValue(v1867);
let v1873;if(v1876&&v1875){v1873=v1874;}else{
const v1877=10;
const v1878=(((v1872) + (v1877)) >>> 0);
v1873=__fn1(v1867,v1868,v1869,v1878);if(v1876){v1874=v1873;v1875=true;}}
let v1879=__nfValue(v1873);
for(let v1880=0;v1880<10;v1880++){
const v1881=(v1880>>>0);
const v1882=v1879;
const v1883=(((v1872) + (v1881)) >>> 0);
const v1884=__fn1(v1867,v1868,v1869,v1883);
const v1885=10;
const v1886=(Math.imul(v1871,v1885) >>> 0);
const v1887=(((v1886) + (v1881)) >>> 0);
let v1888;if(v1887<v1870.length){v1888=v1870[v1887];}else{
v1888=0.0;}
const v1889=__nfValue(v1888);
const v1890=Math.fround(__nfNumber(v1884) * __nfNumber(v1889));
v1879=Math.fround(__nfNumber(v1882) + v1890);}
return v1879;};}
function __prepareFn4(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[4],[]))))return __fn4;const v1899=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[4],[]);
let v1898=false,v1897;
return function(v1891,v1892,v1893,v1894,v1895){v1891=__nfValue(v1891);
let v1896;if(v1899&&v1898){v1896=v1897;}else{
const v1900=6;
const v1901=(((v1895) + (v1900)) >>> 0);
v1896=__fn1(v1891,v1892,v1893,v1901);if(v1899){v1897=v1896;v1898=true;}}
let v1902=__nfValue(v1896);
for(let v1903=0;v1903<6;v1903++){
const v1904=(v1903>>>0);
const v1905=v1902;
const v1906=(((v1895) + (v1904)) >>> 0);
const v1907=__fn1(v1891,v1892,v1893,v1906);
let v1908;if(v1904<v1894.length){v1908=v1894[v1904];}else{
v1908=0.0;}
const v1909=__nfValue(v1908);
const v1910=Math.fround(__nfNumber(v1907) * __nfNumber(v1909));
v1902=Math.fround(__nfNumber(v1905) + v1910);}
return v1902;};}
function __prepareFn5(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn5;const v1919=depth<15&&__preparedFactories.has(3)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v1917;
let v1924;
let v1934;
let v1940;
let v1950;
let v1956;
let v1966;
let v1972;
let v1982;
let v1988;
let v1998;
let v2004;
return function(v1911,v1912,v1913,v1914,v1915){v1911=__nfValue(v1911);
const v1916=0;
let v1920;if(v1919){if(!v1917){const v1918=__preparedFactories.get(3);v1917=v1918([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1920=v1917(v1911,v1912,v1913,v1914,v1915,v1916);}else{v1920=__fn3(v1911,v1912,v1913,v1914,v1915,v1916);}
const v1921=v1920;
const v1923=11;
let v1926;if(v1919){if(!v1924){const v1925=__preparedFactories.get(3);v1924=v1925([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1926=v1924(v1911,v1912,v1913,v1914,v1915,v1923);}else{v1926=__fn3(v1911,v1912,v1913,v1914,v1915,v1923);}
const v1927=v1926;
const v1929=__nfValue(v1921);
const v1930=__nfValue(v1927);
const v1931=__fn2(v1929,v1930);
const v1933=22;
let v1936;if(v1919){if(!v1934){const v1935=__preparedFactories.get(3);v1934=v1935([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1936=v1934(v1911,v1912,v1913,v1914,v1915,v1933);}else{v1936=__fn3(v1911,v1912,v1913,v1914,v1915,v1933);}
const v1937=v1936;
const v1939=33;
let v1942;if(v1919){if(!v1940){const v1941=__preparedFactories.get(3);v1940=v1941([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1942=v1940(v1911,v1912,v1913,v1914,v1915,v1939);}else{v1942=__fn3(v1911,v1912,v1913,v1914,v1915,v1939);}
const v1943=v1942;
const v1945=__nfValue(v1937);
const v1946=__nfValue(v1943);
const v1947=__fn2(v1945,v1946);
const v1949=44;
let v1952;if(v1919){if(!v1950){const v1951=__preparedFactories.get(3);v1950=v1951([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1952=v1950(v1911,v1912,v1913,v1914,v1915,v1949);}else{v1952=__fn3(v1911,v1912,v1913,v1914,v1915,v1949);}
const v1953=v1952;
const v1955=55;
let v1958;if(v1919){if(!v1956){const v1957=__preparedFactories.get(3);v1956=v1957([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1958=v1956(v1911,v1912,v1913,v1914,v1915,v1955);}else{v1958=__fn3(v1911,v1912,v1913,v1914,v1915,v1955);}
const v1959=v1958;
const v1961=__nfValue(v1953);
const v1962=__nfValue(v1959);
const v1963=__fn2(v1961,v1962);
const v1965=66;
let v1968;if(v1919){if(!v1966){const v1967=__preparedFactories.get(3);v1966=v1967([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1968=v1966(v1911,v1912,v1913,v1914,v1915,v1965);}else{v1968=__fn3(v1911,v1912,v1913,v1914,v1915,v1965);}
const v1969=v1968;
const v1971=77;
let v1974;if(v1919){if(!v1972){const v1973=__preparedFactories.get(3);v1972=v1973([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1974=v1972(v1911,v1912,v1913,v1914,v1915,v1971);}else{v1974=__fn3(v1911,v1912,v1913,v1914,v1915,v1971);}
const v1975=v1974;
const v1977=__nfValue(v1969);
const v1978=__nfValue(v1975);
const v1979=__fn2(v1977,v1978);
const v1981=88;
let v1984;if(v1919){if(!v1982){const v1983=__preparedFactories.get(3);v1982=v1983([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1984=v1982(v1911,v1912,v1913,v1914,v1915,v1981);}else{v1984=__fn3(v1911,v1912,v1913,v1914,v1915,v1981);}
const v1985=v1984;
const v1987=99;
let v1990;if(v1919){if(!v1988){const v1989=__preparedFactories.get(3);v1988=v1989([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1990=v1988(v1911,v1912,v1913,v1914,v1915,v1987);}else{v1990=__fn3(v1911,v1912,v1913,v1914,v1915,v1987);}
const v1991=v1990;
const v1993=__nfValue(v1985);
const v1994=__nfValue(v1991);
const v1995=__fn2(v1993,v1994);
const v1997=110;
let v2000;if(v1919){if(!v1998){const v1999=__preparedFactories.get(3);v1998=v1999([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2000=v1998(v1911,v1912,v1913,v1914,v1915,v1997);}else{v2000=__fn3(v1911,v1912,v1913,v1914,v1915,v1997);}
const v2001=v2000;
const v2003=121;
let v2006;if(v1919){if(!v2004){const v2005=__preparedFactories.get(3);v2004=v2005([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2006=v2004(v1911,v1912,v1913,v1914,v1915,v2003);}else{v2006=__fn3(v1911,v1912,v1913,v1914,v1915,v2003);}
const v2007=v2006;
const v2009=__nfValue(v2001);
const v2010=__nfValue(v2007);
const v2011=__fn2(v2009,v2010);
return [v1931,v1947,v1963,v1979,v1995,v2011];};}
function __prepareFn6(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn6;const v2020=depth<15&&__preparedFactories.has(4)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2018;
let v2025;
let v2035;
let v2041;
let v2051;
let v2057;
let v2067;
let v2073;
let v2083;
let v2089;
let v2099;
let v2105;
return function(v2013,v2014,v2015,v2016){v2013=__nfValue(v2013);
const v2017=132;
let v2021;if(v2020){if(!v2018){const v2019=__preparedFactories.get(4);v2018=v2019([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2021=v2018(v2013,v2014,v2015,v2016,v2017);}else{v2021=__fn4(v2013,v2014,v2015,v2016,v2017);}
const v2022=v2021;
const v2024=139;
let v2027;if(v2020){if(!v2025){const v2026=__preparedFactories.get(4);v2025=v2026([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2027=v2025(v2013,v2014,v2015,v2016,v2024);}else{v2027=__fn4(v2013,v2014,v2015,v2016,v2024);}
const v2028=v2027;
const v2030=__nfValue(v2022);
const v2031=__nfValue(v2028);
const v2032=__fn2(v2030,v2031);
const v2034=146;
let v2037;if(v2020){if(!v2035){const v2036=__preparedFactories.get(4);v2035=v2036([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2037=v2035(v2013,v2014,v2015,v2016,v2034);}else{v2037=__fn4(v2013,v2014,v2015,v2016,v2034);}
const v2038=v2037;
const v2040=153;
let v2043;if(v2020){if(!v2041){const v2042=__preparedFactories.get(4);v2041=v2042([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2043=v2041(v2013,v2014,v2015,v2016,v2040);}else{v2043=__fn4(v2013,v2014,v2015,v2016,v2040);}
const v2044=v2043;
const v2046=__nfValue(v2038);
const v2047=__nfValue(v2044);
const v2048=__fn2(v2046,v2047);
const v2050=160;
let v2053;if(v2020){if(!v2051){const v2052=__preparedFactories.get(4);v2051=v2052([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2053=v2051(v2013,v2014,v2015,v2016,v2050);}else{v2053=__fn4(v2013,v2014,v2015,v2016,v2050);}
const v2054=v2053;
const v2056=167;
let v2059;if(v2020){if(!v2057){const v2058=__preparedFactories.get(4);v2057=v2058([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2059=v2057(v2013,v2014,v2015,v2016,v2056);}else{v2059=__fn4(v2013,v2014,v2015,v2016,v2056);}
const v2060=v2059;
const v2062=__nfValue(v2054);
const v2063=__nfValue(v2060);
const v2064=__fn2(v2062,v2063);
const v2066=174;
let v2069;if(v2020){if(!v2067){const v2068=__preparedFactories.get(4);v2067=v2068([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2069=v2067(v2013,v2014,v2015,v2016,v2066);}else{v2069=__fn4(v2013,v2014,v2015,v2016,v2066);}
const v2070=v2069;
const v2072=181;
let v2075;if(v2020){if(!v2073){const v2074=__preparedFactories.get(4);v2073=v2074([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2075=v2073(v2013,v2014,v2015,v2016,v2072);}else{v2075=__fn4(v2013,v2014,v2015,v2016,v2072);}
const v2076=v2075;
const v2078=__nfValue(v2070);
const v2079=__nfValue(v2076);
const v2080=__fn2(v2078,v2079);
const v2082=188;
let v2085;if(v2020){if(!v2083){const v2084=__preparedFactories.get(4);v2083=v2084([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2085=v2083(v2013,v2014,v2015,v2016,v2082);}else{v2085=__fn4(v2013,v2014,v2015,v2016,v2082);}
const v2086=v2085;
const v2088=195;
let v2091;if(v2020){if(!v2089){const v2090=__preparedFactories.get(4);v2089=v2090([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2091=v2089(v2013,v2014,v2015,v2016,v2088);}else{v2091=__fn4(v2013,v2014,v2015,v2016,v2088);}
const v2092=v2091;
const v2094=__nfValue(v2086);
const v2095=__nfValue(v2092);
const v2096=__fn2(v2094,v2095);
const v2098=202;
let v2101;if(v2020){if(!v2099){const v2100=__preparedFactories.get(4);v2099=v2100([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2101=v2099(v2013,v2014,v2015,v2016,v2098);}else{v2101=__fn4(v2013,v2014,v2015,v2016,v2098);}
const v2102=v2101;
const v2104=209;
let v2107;if(v2020){if(!v2105){const v2106=__preparedFactories.get(4);v2105=v2106([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2107=v2105(v2013,v2014,v2015,v2016,v2104);}else{v2107=__fn4(v2013,v2014,v2015,v2016,v2104);}
const v2108=v2107;
const v2110=__nfValue(v2102);
const v2111=__nfValue(v2108);
const v2112=__fn2(v2110,v2111);
return [v2032,v2048,v2064,v2080,v2096,v2112];};}
function __prepareFn7(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn7;const v2122=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[])&&__preparedStable(fixed[4],[]);
let v2121=false,v2120;
const v2125=depth<15&&__preparedFactories.has(5)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2123;
let v2129=false,v2128;
const v2133=depth<15&&__preparedFactories.has(6)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2131;
const v2139=depth<15&&__preparedFactories.has(4)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2137;
let v2145;
let v2152;
let v2159;
return function(v2114,v2115,v2116,v2117,v2118){v2114=__nfValue(v2114);
let v2119;if(v2122&&v2121){v2119=v2120;}else{
let v2126;if(v2125){if(!v2123){const v2124=__preparedFactories.get(5);v2123=v2124([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4]],depth+1);}v2126=v2123(v2114,v2115,v2116,v2117,v2118);}else{v2126=__fn5(v2114,v2115,v2116,v2117,v2118);}
v2119=v2126;if(v2122){v2120=v2119;v2121=true;}}
let v2127;if(v2122&&v2129){v2127=v2128;}else{
const v2130=v2119;
let v2134;if(v2133){if(!v2131){const v2132=__preparedFactories.get(6);v2131=v2132([fixed[0],fixed[1],fixed[2],v2122],depth+1);}v2134=v2131(v2114,v2115,v2116,v2130);}else{v2134=__fn6(v2114,v2115,v2116,v2130);}
v2127=v2134;if(v2122){v2128=v2127;v2129=true;}}
const v2135=v2127;
const v2136=216;
let v2140;if(v2139){if(!v2137){const v2138=__preparedFactories.get(4);v2137=v2138([fixed[0],fixed[1],fixed[2],v2122,true],depth+1);}v2140=v2137(v2114,v2115,v2116,v2135,v2136);}else{v2140=__fn4(v2114,v2115,v2116,v2135,v2136);}
const v2141=v2140;
const v2143=v2127;
const v2144=223;
let v2147;if(v2139){if(!v2145){const v2146=__preparedFactories.get(4);v2145=v2146([fixed[0],fixed[1],fixed[2],v2122,true],depth+1);}v2147=v2145(v2114,v2115,v2116,v2143,v2144);}else{v2147=__fn4(v2114,v2115,v2116,v2143,v2144);}
const v2148=v2147;
const v2150=v2127;
const v2151=230;
let v2154;if(v2139){if(!v2152){const v2153=__preparedFactories.get(4);v2152=v2153([fixed[0],fixed[1],fixed[2],v2122,true],depth+1);}v2154=v2152(v2114,v2115,v2116,v2150,v2151);}else{v2154=__fn4(v2114,v2115,v2116,v2150,v2151);}
const v2155=v2154;
const v2157=v2127;
const v2158=237;
let v2161;if(v2139){if(!v2159){const v2160=__preparedFactories.get(4);v2159=v2160([fixed[0],fixed[1],fixed[2],v2122,true],depth+1);}v2161=v2159(v2114,v2115,v2116,v2157,v2158);}else{v2161=__fn4(v2114,v2115,v2116,v2157,v2158);}
const v2162=v2161;
const v2164=__nfValue(v2141);
const v2165=__nfValue(v2148);
const v2166=__nfValue(v2155);
const v2167=__nfValue(v2162);
return [v2164,v2165,v2166,v2167];};}
function __prepareFn9(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn9;const v2179=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[])&&__preparedStable(fixed[5],[]);
let v2178=false,v2177;
const v2182=depth<15&&__preparedFactories.has(7)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2180;
return function(v2170,v2171,v2172,v2173,v2174,v2175){v2170=__nfValue(v2170);
let v2176;if(v2179&&v2178){v2176=v2177;}else{
let v2183;if(v2182){if(!v2180){const v2181=__preparedFactories.get(7);v2180=v2181([fixed[0],fixed[1],fixed[2],fixed[3],fixed[5]],depth+1);}v2183=v2180(v2170,v2171,v2172,v2173,v2175);}else{v2183=__fn7(v2170,v2171,v2172,v2173,v2175);}
v2176=v2183;if(v2179){v2177=v2176;v2178=true;}}
let v2185=0.0;
for(let v2186=0;v2186<4;v2186++){
const v2187=(v2186>>>0);
const v2188=v2185;
const v2189=v2176;
let v2190;if(v2187<v2189.length){v2190=v2189[v2187];}else{
v2190=0.0;}
const v2191=__nfValue(v2190);
const v2192=4;
const v2193=(Math.imul(v2175,v2192) >>> 0);
const v2194=(((v2193) + (v2187)) >>> 0);
let v2195;if(v2194<v2174.length){v2195=v2174[v2194];}else{
v2195=0.0;}
const v2196=__nfValue(v2195);
const v2197=__fn8(v2191,v2196);
v2185=Math.fround(__nfNumber(v2188) + __nfNumber(v2197));}
const v2184=v2185;
return Math.fround((__nfNumber(__nfValue(v2184)))/(__nfNumber(4.0)));};}
function __prepareFn15(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[3],[]))))return __fn15;const v2218=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[]);
let v2217=false,v2216;
const v2241=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[3],[]);
let v2240=false,v2239;
let v2250=false,v2249;
return function(v2211,v2212,v2213,v2214){let v2215;if(v2218&&v2217){v2215=v2216;}else{
const v2219=false;
const v2220=(v2213===v2219);
let v2221=v2220;if(!v2221){
const v2222=__fn13(v2214);
const v2223=false;
v2221=(v2222===v2223);}
const v2224=v2221;
let v2225=v2224;if(!v2225){
const v2226=(v2212).length;
const v2227=(v2211).length;
v2225=!(v2226===v2227);}
const v2228=v2225;
let v2229=v2228;if(!v2229){
let v2230=true;
for(let v2231=0;v2231<v2211.length;v2231++){
const v2232=v2211[v2231];
const v2233=v2230;
let v2234=v2233;if(v2234){
v2234=__fn12(v2232);}
v2230=v2234;
}
const v2235=v2230;
const v2236=false;
v2229=(v2235===v2236);}
v2215=v2229;if(v2218){v2216=v2215;v2217=true;}}
let v2237;if(v2215){
v2237=v2211;}else{
let v2238;if(v2241&&v2240){v2238=v2239;}else{
const v2242=[];for(let v2243=0;v2243<v2211.length;v2243++){
const v2244=v2211[v2243];
const v2245=(v2243>>>0);
let v2246;if(v2245<v2212.length){v2246=v2212[v2245];}else{
v2246=0.0;}
const v2247=__nfValue(v2246);
v2242.push(__fn11(v2244,v2247,v2214));}
v2238=v2242;if(v2241){v2239=v2238;v2240=true;}}
let v2248;if(v2241&&v2250){v2248=v2249;}else{
const v2251=v2238;
let v2252=true;
for(let v2253=0;v2253<v2251.length;v2253++){
const v2254=v2251[v2253];
const v2255=v2252;
let v2256=v2255;if(v2256){
v2256=__fn12(v2254);}
v2252=v2256;
}
v2248=v2252;if(v2241){v2249=v2248;v2250=true;}}
let v2257;if(v2248){
v2257=v2238;}else{
v2257=v2211;}
v2237=v2257;}
return v2237;};}
function __prepareFn16(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn16;const v2269=depth<15&&__preparedFactories.has(9)&&((__preparedStable(fixed[0],[])));
let v2267;
return function(v2258,v2259,v2260,v2261){const v2262=[];for(let v2263=0;v2263<v2261.length;v2263++){
const v2264=(v2261[v2263]>>>0);
const v2265=0.0;
const v2266=4294967295;
let v2270;if(v2269){if(!v2267){const v2268=__preparedFactories.get(9);v2267=v2268([true,true,fixed[0],fixed[1],fixed[2],false],depth+1);}v2270=v2267(v2265,v2266,v2258,v2259,v2260,v2264);}else{v2270=__fn9(v2265,v2266,v2258,v2259,v2260,v2264);}
v2262.push(v2270);}
return v2262;};}
function __prepareFn22(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[5],[]))))return __fn22;const v2290=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[5],[]);
let v2289=false,v2288;
return function(v2281,v2282,v2283,v2284,v2285,v2286){let v2287;if(v2290&&v2289){v2287=v2288;}else{
const v2291=10;
const v2292=(((v2286) + (v2291)) >>> 0);
v2287=__fn20(v2281,v2282,v2283,v2292);if(v2290){v2288=v2287;v2289=true;}}
const v2293=v2287;
let v2294=v2293["value"];
let v2295=v2293["tangent"];
for(let v2297=0;v2297<10;v2297++){
const v2298=(v2297>>>0);
const v2300=(((v2286) + (v2298)) >>> 0);
const v2301=__fn20(v2281,v2282,v2283,v2300);
const v2302=10;
const v2303=(Math.imul(v2285,v2302) >>> 0);
const v2304=(((v2303) + (v2298)) >>> 0);
let v2305;if(v2304<v2284.length){v2305=v2284[v2304];}else{
const v2306=0.0;
const v2307=0.0;
v2305=({["value"]:v2306,["tangent"]:v2307});}
const v2308=v2305;
const v2309=__fn17(v2301,v2308);
const v2310=__nfValue(v2294);
const v2311=__nfValue(v2309["value"]);
const v2312=Math.fround(__nfNumber(v2310) + __nfNumber(v2311));
const v2313=__nfValue(v2295);
const v2314=__nfValue(v2309["tangent"]);
const v2315=Math.fround(__nfNumber(v2313) + __nfNumber(v2314));
v2294=v2312;
v2295=v2315;
}
return ({["value"]:v2294,["tangent"]:v2295});};}
function __prepareFn23(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn23;const v2324=depth<15&&__preparedFactories.has(22)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2322;
let v2329;
let v2337;
let v2343;
let v2351;
let v2357;
let v2365;
let v2371;
let v2379;
let v2385;
let v2393;
let v2399;
return function(v2316,v2317,v2318,v2319,v2320){const v2321=0;
let v2325;if(v2324){if(!v2322){const v2323=__preparedFactories.get(22);v2322=v2323([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2325=v2322(v2316,v2317,v2318,v2319,v2320,v2321);}else{v2325=__fn22(v2316,v2317,v2318,v2319,v2320,v2321);}
const v2326=v2325;
const v2328=11;
let v2331;if(v2324){if(!v2329){const v2330=__preparedFactories.get(22);v2329=v2330([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2331=v2329(v2316,v2317,v2318,v2319,v2320,v2328);}else{v2331=__fn22(v2316,v2317,v2318,v2319,v2320,v2328);}
const v2332=v2331;
const v2334=__fn18(v2326,v2332);
const v2336=22;
let v2339;if(v2324){if(!v2337){const v2338=__preparedFactories.get(22);v2337=v2338([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2339=v2337(v2316,v2317,v2318,v2319,v2320,v2336);}else{v2339=__fn22(v2316,v2317,v2318,v2319,v2320,v2336);}
const v2340=v2339;
const v2342=33;
let v2345;if(v2324){if(!v2343){const v2344=__preparedFactories.get(22);v2343=v2344([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2345=v2343(v2316,v2317,v2318,v2319,v2320,v2342);}else{v2345=__fn22(v2316,v2317,v2318,v2319,v2320,v2342);}
const v2346=v2345;
const v2348=__fn18(v2340,v2346);
const v2350=44;
let v2353;if(v2324){if(!v2351){const v2352=__preparedFactories.get(22);v2351=v2352([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2353=v2351(v2316,v2317,v2318,v2319,v2320,v2350);}else{v2353=__fn22(v2316,v2317,v2318,v2319,v2320,v2350);}
const v2354=v2353;
const v2356=55;
let v2359;if(v2324){if(!v2357){const v2358=__preparedFactories.get(22);v2357=v2358([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2359=v2357(v2316,v2317,v2318,v2319,v2320,v2356);}else{v2359=__fn22(v2316,v2317,v2318,v2319,v2320,v2356);}
const v2360=v2359;
const v2362=__fn18(v2354,v2360);
const v2364=66;
let v2367;if(v2324){if(!v2365){const v2366=__preparedFactories.get(22);v2365=v2366([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2367=v2365(v2316,v2317,v2318,v2319,v2320,v2364);}else{v2367=__fn22(v2316,v2317,v2318,v2319,v2320,v2364);}
const v2368=v2367;
const v2370=77;
let v2373;if(v2324){if(!v2371){const v2372=__preparedFactories.get(22);v2371=v2372([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2373=v2371(v2316,v2317,v2318,v2319,v2320,v2370);}else{v2373=__fn22(v2316,v2317,v2318,v2319,v2320,v2370);}
const v2374=v2373;
const v2376=__fn18(v2368,v2374);
const v2378=88;
let v2381;if(v2324){if(!v2379){const v2380=__preparedFactories.get(22);v2379=v2380([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2381=v2379(v2316,v2317,v2318,v2319,v2320,v2378);}else{v2381=__fn22(v2316,v2317,v2318,v2319,v2320,v2378);}
const v2382=v2381;
const v2384=99;
let v2387;if(v2324){if(!v2385){const v2386=__preparedFactories.get(22);v2385=v2386([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2387=v2385(v2316,v2317,v2318,v2319,v2320,v2384);}else{v2387=__fn22(v2316,v2317,v2318,v2319,v2320,v2384);}
const v2388=v2387;
const v2390=__fn18(v2382,v2388);
const v2392=110;
let v2395;if(v2324){if(!v2393){const v2394=__preparedFactories.get(22);v2393=v2394([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2395=v2393(v2316,v2317,v2318,v2319,v2320,v2392);}else{v2395=__fn22(v2316,v2317,v2318,v2319,v2320,v2392);}
const v2396=v2395;
const v2398=121;
let v2401;if(v2324){if(!v2399){const v2400=__preparedFactories.get(22);v2399=v2400([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2401=v2399(v2316,v2317,v2318,v2319,v2320,v2398);}else{v2401=__fn22(v2316,v2317,v2318,v2319,v2320,v2398);}
const v2402=v2401;
const v2404=__fn18(v2396,v2402);
return [v2334,v2348,v2362,v2376,v2390,v2404];};}
function __prepareFn24(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[4],[]))))return __fn24;const v2414=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[4],[]);
let v2413=false,v2412;
return function(v2406,v2407,v2408,v2409,v2410){let v2411;if(v2414&&v2413){v2411=v2412;}else{
const v2415=6;
const v2416=(((v2410) + (v2415)) >>> 0);
v2411=__fn20(v2406,v2407,v2408,v2416);if(v2414){v2412=v2411;v2413=true;}}
const v2417=v2411;
let v2418=v2417["value"];
let v2419=v2417["tangent"];
for(let v2421=0;v2421<6;v2421++){
const v2422=(v2421>>>0);
const v2424=(((v2410) + (v2422)) >>> 0);
const v2425=__fn20(v2406,v2407,v2408,v2424);
let v2426;if(v2422<v2409.length){v2426=v2409[v2422];}else{
const v2427=0.0;
const v2428=0.0;
v2426=({["value"]:v2427,["tangent"]:v2428});}
const v2429=v2426;
const v2430=__fn17(v2425,v2429);
const v2431=__nfValue(v2418);
const v2432=__nfValue(v2430["value"]);
const v2433=Math.fround(__nfNumber(v2431) + __nfNumber(v2432));
const v2434=__nfValue(v2419);
const v2435=__nfValue(v2430["tangent"]);
const v2436=Math.fround(__nfNumber(v2434) + __nfNumber(v2435));
v2418=v2433;
v2419=v2436;
}
return ({["value"]:v2418,["tangent"]:v2419});};}
function __prepareFn25(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn25;const v2444=depth<15&&__preparedFactories.has(24)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2442;
let v2449;
let v2457;
let v2463;
let v2471;
let v2477;
let v2485;
let v2491;
let v2499;
let v2505;
let v2513;
let v2519;
return function(v2437,v2438,v2439,v2440){const v2441=132;
let v2445;if(v2444){if(!v2442){const v2443=__preparedFactories.get(24);v2442=v2443([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2445=v2442(v2437,v2438,v2439,v2440,v2441);}else{v2445=__fn24(v2437,v2438,v2439,v2440,v2441);}
const v2446=v2445;
const v2448=139;
let v2451;if(v2444){if(!v2449){const v2450=__preparedFactories.get(24);v2449=v2450([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2451=v2449(v2437,v2438,v2439,v2440,v2448);}else{v2451=__fn24(v2437,v2438,v2439,v2440,v2448);}
const v2452=v2451;
const v2454=__fn18(v2446,v2452);
const v2456=146;
let v2459;if(v2444){if(!v2457){const v2458=__preparedFactories.get(24);v2457=v2458([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2459=v2457(v2437,v2438,v2439,v2440,v2456);}else{v2459=__fn24(v2437,v2438,v2439,v2440,v2456);}
const v2460=v2459;
const v2462=153;
let v2465;if(v2444){if(!v2463){const v2464=__preparedFactories.get(24);v2463=v2464([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2465=v2463(v2437,v2438,v2439,v2440,v2462);}else{v2465=__fn24(v2437,v2438,v2439,v2440,v2462);}
const v2466=v2465;
const v2468=__fn18(v2460,v2466);
const v2470=160;
let v2473;if(v2444){if(!v2471){const v2472=__preparedFactories.get(24);v2471=v2472([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2473=v2471(v2437,v2438,v2439,v2440,v2470);}else{v2473=__fn24(v2437,v2438,v2439,v2440,v2470);}
const v2474=v2473;
const v2476=167;
let v2479;if(v2444){if(!v2477){const v2478=__preparedFactories.get(24);v2477=v2478([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2479=v2477(v2437,v2438,v2439,v2440,v2476);}else{v2479=__fn24(v2437,v2438,v2439,v2440,v2476);}
const v2480=v2479;
const v2482=__fn18(v2474,v2480);
const v2484=174;
let v2487;if(v2444){if(!v2485){const v2486=__preparedFactories.get(24);v2485=v2486([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2487=v2485(v2437,v2438,v2439,v2440,v2484);}else{v2487=__fn24(v2437,v2438,v2439,v2440,v2484);}
const v2488=v2487;
const v2490=181;
let v2493;if(v2444){if(!v2491){const v2492=__preparedFactories.get(24);v2491=v2492([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2493=v2491(v2437,v2438,v2439,v2440,v2490);}else{v2493=__fn24(v2437,v2438,v2439,v2440,v2490);}
const v2494=v2493;
const v2496=__fn18(v2488,v2494);
const v2498=188;
let v2501;if(v2444){if(!v2499){const v2500=__preparedFactories.get(24);v2499=v2500([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2501=v2499(v2437,v2438,v2439,v2440,v2498);}else{v2501=__fn24(v2437,v2438,v2439,v2440,v2498);}
const v2502=v2501;
const v2504=195;
let v2507;if(v2444){if(!v2505){const v2506=__preparedFactories.get(24);v2505=v2506([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2507=v2505(v2437,v2438,v2439,v2440,v2504);}else{v2507=__fn24(v2437,v2438,v2439,v2440,v2504);}
const v2508=v2507;
const v2510=__fn18(v2502,v2508);
const v2512=202;
let v2515;if(v2444){if(!v2513){const v2514=__preparedFactories.get(24);v2513=v2514([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2515=v2513(v2437,v2438,v2439,v2440,v2512);}else{v2515=__fn24(v2437,v2438,v2439,v2440,v2512);}
const v2516=v2515;
const v2518=209;
let v2521;if(v2444){if(!v2519){const v2520=__preparedFactories.get(24);v2519=v2520([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2521=v2519(v2437,v2438,v2439,v2440,v2518);}else{v2521=__fn24(v2437,v2438,v2439,v2440,v2518);}
const v2522=v2521;
const v2524=__fn18(v2516,v2522);
return [v2454,v2468,v2482,v2496,v2510,v2524];};}
function __prepareFn26(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn26;const v2534=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[])&&__preparedStable(fixed[4],[]);
let v2533=false,v2532;
const v2537=depth<15&&__preparedFactories.has(23)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2535;
let v2541=false,v2540;
const v2545=depth<15&&__preparedFactories.has(25)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2543;
const v2551=depth<15&&__preparedFactories.has(24)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2549;
let v2557;
let v2564;
let v2571;
return function(v2526,v2527,v2528,v2529,v2530){let v2531;if(v2534&&v2533){v2531=v2532;}else{
let v2538;if(v2537){if(!v2535){const v2536=__preparedFactories.get(23);v2535=v2536([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4]],depth+1);}v2538=v2535(v2526,v2527,v2528,v2529,v2530);}else{v2538=__fn23(v2526,v2527,v2528,v2529,v2530);}
v2531=v2538;if(v2534){v2532=v2531;v2533=true;}}
let v2539;if(v2534&&v2541){v2539=v2540;}else{
const v2542=v2531;
let v2546;if(v2545){if(!v2543){const v2544=__preparedFactories.get(25);v2543=v2544([fixed[0],fixed[1],fixed[2],v2534],depth+1);}v2546=v2543(v2526,v2527,v2528,v2542);}else{v2546=__fn25(v2526,v2527,v2528,v2542);}
v2539=v2546;if(v2534){v2540=v2539;v2541=true;}}
const v2547=v2539;
const v2548=216;
let v2552;if(v2551){if(!v2549){const v2550=__preparedFactories.get(24);v2549=v2550([fixed[0],fixed[1],fixed[2],v2534,true],depth+1);}v2552=v2549(v2526,v2527,v2528,v2547,v2548);}else{v2552=__fn24(v2526,v2527,v2528,v2547,v2548);}
const v2553=v2552;
const v2555=v2539;
const v2556=223;
let v2559;if(v2551){if(!v2557){const v2558=__preparedFactories.get(24);v2557=v2558([fixed[0],fixed[1],fixed[2],v2534,true],depth+1);}v2559=v2557(v2526,v2527,v2528,v2555,v2556);}else{v2559=__fn24(v2526,v2527,v2528,v2555,v2556);}
const v2560=v2559;
const v2562=v2539;
const v2563=230;
let v2566;if(v2551){if(!v2564){const v2565=__preparedFactories.get(24);v2564=v2565([fixed[0],fixed[1],fixed[2],v2534,true],depth+1);}v2566=v2564(v2526,v2527,v2528,v2562,v2563);}else{v2566=__fn24(v2526,v2527,v2528,v2562,v2563);}
const v2567=v2566;
const v2569=v2539;
const v2570=237;
let v2573;if(v2551){if(!v2571){const v2572=__preparedFactories.get(24);v2571=v2572([fixed[0],fixed[1],fixed[2],v2534,true],depth+1);}v2573=v2571(v2526,v2527,v2528,v2569,v2570);}else{v2573=__fn24(v2526,v2527,v2528,v2569,v2570);}
const v2574=v2573;
return [v2553,v2560,v2567,v2574];};}
function __prepareFn30(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn30;const v2591=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[])&&__preparedStable(fixed[5],[]);
let v2590=false,v2589;
const v2594=depth<15&&__preparedFactories.has(26)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2592;
const v2599=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[])&&__preparedStable(fixed[4],[])&&__preparedStable(fixed[5],[]);
let v2598=false,v2597;
return function(v2582,v2583,v2584,v2585,v2586,v2587){let v2588;if(v2591&&v2590){v2588=v2589;}else{
let v2595;if(v2594){if(!v2592){const v2593=__preparedFactories.get(26);v2592=v2593([fixed[0],fixed[1],fixed[2],fixed[3],fixed[5]],depth+1);}v2595=v2592(v2582,v2583,v2584,v2585,v2587);}else{v2595=__fn26(v2582,v2583,v2584,v2585,v2587);}
v2588=v2595;if(v2591){v2589=v2588;v2590=true;}}
let v2596;if(v2599&&v2598){v2596=v2597;}else{
const v2600=0.0;
const v2601=0.0;
let v2602=v2600;
let v2603=v2601;
for(let v2605=0;v2605<4;v2605++){
const v2606=(v2605>>>0);
const v2608=v2588;
let v2609;if(v2606<v2608.length){v2609=v2608[v2606];}else{
const v2610=0.0;
const v2611=0.0;
v2609=({["value"]:v2610,["tangent"]:v2611});}
const v2612=v2609;
const v2613=4;
const v2614=(Math.imul(v2587,v2613) >>> 0);
const v2615=(((v2614) + (v2606)) >>> 0);
let v2616;if(v2615<v2586.length){v2616=v2586[v2615];}else{
const v2617=0.0;
const v2618=0.0;
v2616=({["value"]:v2617,["tangent"]:v2618});}
const v2619=v2616;
const v2620=__fn28(v2612,v2619);
const v2621=__nfValue(v2602);
const v2622=__nfValue(v2620["value"]);
const v2623=Math.fround(__nfNumber(v2621) + __nfNumber(v2622));
const v2624=__nfValue(v2603);
const v2625=__nfValue(v2620["tangent"]);
const v2626=Math.fround(__nfNumber(v2624) + __nfNumber(v2625));
v2602=v2623;
v2603=v2626;
}
v2596=({["value"]:v2602,["tangent"]:v2603});if(v2599){v2597=v2596;v2598=true;}}
const v2627=v2596;
const v2628=4.0;
const v2629=0.0;
const v2631=Math.fround((__nfNumber(__nfValue(v2627["value"])))/(__nfNumber(v2628)));
const v2632=__nfValue(v2627["tangent"]);
const v2633=Math.fround(__nfNumber(v2632) * v2628);
const v2634=__nfValue(v2627["value"]);
const v2635=Math.fround(__nfNumber(v2634) * v2629);
const v2636=Math.fround((__nfNumber(Math.fround(v2633 - v2635)))/(__nfNumber(Math.fround(v2628 * v2628))));
return ({["value"]:v2631,["tangent"]:v2636});};}
function __prepareFn31(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn31;const v2646=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[])&&__preparedStable(fixed[4],[])&&__preparedStable(fixed[5],[]);
let v2645=false,v2644;
const v2649={all:__preparedStable(fixed[0],[]),fields:{["tangent"]:true,["value"]:fixed[0]}};
const v2670=__preparedStable(fixed[2],[]);
const v2677=__preparedStable(fixed[3],[]);
const v2684=__preparedStable(fixed[4],[]);
const v2687=depth<15&&__preparedFactories.has(30)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2685;
return function(v2637,v2638,v2639,v2640,v2641,v2642){v2637=__nfValue(v2637);
let v2643;if(v2646&&v2645){v2643=v2644;}else{
const v2647=1.0;
const v2648=({["value"]:v2637,["tangent"]:v2647});
const v2650=[];for(let v2651=0;v2651<v2639.length;v2651++){
const v2652=v2639[v2651];
const v2653=__nfValue(v2652["value"]);
const v2654=0.0;
const v2655=({["value"]:v2653,["tangent"]:v2654});
const v2656=__nfValue(v2652["first"]);
const v2657=0.0;
const v2658=({["value"]:v2656,["tangent"]:v2657});
const v2659=__nfValue(v2652["second"]);
const v2660=0.0;
const v2661=({["value"]:v2659,["tangent"]:v2660});
const v2662=__nfValue(v2652["first_power"]);
const v2663=0.0;
const v2664=({["value"]:v2662,["tangent"]:v2663});
const v2665=__nfValue(v2652["second_power"]);
const v2666=0.0;
const v2667=({["value"]:v2665,["tangent"]:v2666});
const v2668=v2652["steps"];
v2650.push(({["value"]:v2655,["first"]:v2658,["second"]:v2661,["first_power"]:v2664,["second_power"]:v2667,["steps"]:v2668}));}
const v2669=v2650;
const v2671=[];for(let v2672=0;v2672<v2640.length;v2672++){
const v2673=v2640[v2672];
const v2674=__nfValue(v2673);
const v2675=0.0;
v2671.push(({["value"]:v2674,["tangent"]:v2675}));}
const v2676=v2671;
const v2678=[];for(let v2679=0;v2679<v2641.length;v2679++){
const v2680=v2641[v2679];
const v2681=__nfValue(v2680);
const v2682=0.0;
v2678.push(({["value"]:v2681,["tangent"]:v2682}));}
const v2683=v2678;
let v2688;if(v2687){if(!v2685){const v2686=__preparedFactories.get(30);v2685=v2686([v2649,fixed[1],v2670,v2677,v2684,fixed[5]],depth+1);}v2688=v2685(v2648,v2638,v2669,v2676,v2683,v2642);}else{v2688=__fn30(v2648,v2638,v2669,v2676,v2683,v2642);}
v2643=v2688;if(v2646){v2644=v2643;v2645=true;}}
const v2689=v2643;
return __nfValue(v2689["tangent"]);};}
const __preparedFactories=new Map([[3,__prepareFn3],[4,__prepareFn4],[5,__prepareFn5],[6,__prepareFn6],[7,__prepareFn7],[9,__prepareFn9],[15,__prepareFn15],[16,__prepareFn16],[22,__prepareFn22],[23,__prepareFn23],[24,__prepareFn24],[25,__prepareFn25],[26,__prepareFn26],[30,__prepareFn30],[31,__prepareFn31]]);
