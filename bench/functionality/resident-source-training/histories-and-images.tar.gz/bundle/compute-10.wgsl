// Exact wrapping u64 over two storage lanes. No floating point intermediates.
struct InkU64 {lo:u32,hi:u32,}
struct InkDiv64 {quotient:InkU64,remainder:InkU64,}
fn ink_u64_shl(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64(a.lo<<k,(a.hi<<k)|(a.lo>>(32u-k)));}return InkU64(0u,a.lo<<(k-32u));}
fn ink_u64_shr(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64((a.lo>>k)|(a.hi<<(32u-k)),a.hi>>k);}return InkU64(a.hi>>(k-32u),0u);}
fn ink_u64_rol(a:InkU64,count:u32)->InkU64{let k=count&63u;let l=ink_u64_shl(a,k);let r=ink_u64_shr(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_ror(a:InkU64,count:u32)->InkU64{let k=count&63u;let r=ink_u64_shr(a,k);let l=ink_u64_shl(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_eq(a:InkU64,b:InkU64)->bool{return a.lo==b.lo&&a.hi==b.hi;}
fn ink_u64_lt(a:InkU64,b:InkU64)->bool{return a.hi<b.hi||(a.hi==b.hi&&a.lo<b.lo);}
fn ink_u64_add(a:InkU64,b:InkU64)->InkU64{let lo=a.lo+b.lo;return InkU64(lo,a.hi+b.hi+select(0u,1u,lo<a.lo));}
fn ink_u64_sub(a:InkU64,b:InkU64)->InkU64{return InkU64(a.lo-b.lo,a.hi-b.hi-select(0u,1u,a.lo<b.lo));}
fn ink_u64_mul(a:InkU64,b:InkU64)->InkU64{let al=a.lo&65535u;let ah=a.lo>>16u;let bl=b.lo&65535u;let bh=b.lo>>16u;let p=al*bl;let x=ah*bl;let y=al*bh;let mid=(p>>16u)+(x&65535u)+(y&65535u);let high=ah*bh+(x>>16u)+(y>>16u)+(mid>>16u);return InkU64((mid<<16u)|(p&65535u),high+a.lo*b.hi+a.hi*b.lo);}
fn ink_u64_div(a:InkU64,b:InkU64)->InkDiv64{var q=InkU64(0u,0u);var r=InkU64(0u,0u);var cursor=64u;loop{if(cursor==0u){break;}cursor--;var bit=0u;if(cursor>=32u){bit=(a.hi>>(cursor-32u))&1u;}else{bit=(a.lo>>cursor)&1u;}let overflow=r.hi>>31u;r=InkU64((r.lo<<1u)|bit,(r.hi<<1u)|(r.lo>>31u));if(overflow!=0u||!ink_u64_lt(r,b)){r=ink_u64_sub(r,b);if(cursor>=32u){q.hi|=1u<<(cursor-32u);}else{q.lo|=1u<<cursor;}}}return InkDiv64(q,r);}
// Binary32 evaluated with integer lanes: round-to-nearest, ties-to-even,
// gradual underflow, signed zero and canonical arithmetic NaN.
fn ink_f32_nan(x:u32)->bool{return (x&0x7fffffffu)>0x7f800000u;}
fn ink_f32_eq(a:u32,b:u32)->bool{return !ink_f32_nan(a)&&!ink_f32_nan(b)&&(a==b||((a|b)&0x7fffffffu)==0u);}
fn ink_f32_lt(a:u32,b:u32)->bool{
 if(ink_f32_nan(a)||ink_f32_nan(b)||ink_f32_eq(a,b)){return false;}
 if((a^b)&0x80000000u)!=0u{return (a&0x80000000u)!=0u;}
 if((a&0x80000000u)!=0u){return a>b;}return a<b;
}
fn ink_f32_jam(x:u32,n:u32)->u32{if(n==0u){return x;}if(n>=32u){return select(0u,1u,x!=0u);}return (x>>n)|select(0u,1u,(x&((1u<<n)-1u))!=0u);}
fn ink_f32_round(sign:u32,exponent:i32,extended:u32)->u32{
 var e=exponent;var s=extended;
 if(e<1i){s=ink_f32_jam(s,u32(1i-e));e=1i;}
 let tail=s&7u;var sig=s>>3u;
 if(tail>4u||(tail==4u&&(sig&1u)!=0u)){sig++;}
 if(sig>=0x1000000u){sig>>=1u;e++;}
 if(e>=255i){return sign|0x7f800000u;}
 if(sig==0u){return sign;}
 let raw=select(u32(e),0u,e==1i&&sig<0x800000u);
 return sign|(raw<<23u)|(sig&0x7fffffu);
}
fn ink_f32_add(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 var x=a;var y=b;if((x&0x7fffffffu)<(y&0x7fffffffu)){x=b;y=a;}
 let ax=x&0x7fffffffu;let ay=y&0x7fffffffu;let sign=x&0x80000000u;
 if(ax==0x7f800000u){if(ay==ax&&((x^y)&0x80000000u)!=0u){return 0x7fc00000u;}return x;}
 let rx=(x>>23u)&255u;let ry=(y>>23u)&255u;var e=i32(max(rx,1u));
 var sx=((x&0x7fffffu)|select(0u,0x800000u,rx!=0u))<<3u;
 let sy=ink_f32_jam(((y&0x7fffffu)|select(0u,0x800000u,ry!=0u))<<3u,u32(e)-max(ry,1u));
 if(((x^y)&0x80000000u)==0u){sx+=sy;if(sx>=0x8000000u){sx=ink_f32_jam(sx,1u);e++;}}
 else{sx-=sy;if(sx==0u){return 0u;}loop{if(sx>=0x4000000u||e<=1i){break;}sx<<=1u;e--;}}
 return ink_f32_round(sign,e,sx);
}
fn ink_f32_sub(a:u32,b:u32)->u32{return ink_f32_add(a,b^0x80000000u);}
fn ink_f32_mul(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(aa==0x7f800000u||bb==0x7f800000u){if(aa==0u||bb==0u){return 0x7fc00000u;}return sign|0x7f800000u;}
 if(aa==0u||bb==0u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u));var eb=i32(max(rb,1u));
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 let product=ink_u64_mul(InkU64(sa,0u),InkU64(sb,0u));let high=(product.hi&0x8000u)!=0u;
 let shift=select(20u,21u,high);let extended=(product.lo>>shift)|(product.hi<<(32u-shift))|select(0u,1u,(product.lo&((1u<<shift)-1u))!=0u);
 return ink_f32_round(sign,ea+eb-127i+select(0i,1i,high),extended);
}
// Exact sqrt and division use integer significands, independent of WGSL float
// approximation allowances and device flush-to-zero behavior.
fn ink_f32_sqrt(x:u32)->u32{
 let a=x&0x7fffffffu;if(a==0u){return x;}
 if(a>0x7f800000u||(x&0x80000000u)!=0u){return 0x7fc00000u;}
 if(a==0x7f800000u){return x;}
 let raw=(x>>23u)&255u;var m=(x&0x7fffffu)|select(0u,0x800000u,raw!=0u);var e=i32(max(raw,1u))-127i;
 loop{if(m>=0x800000u){break;}m<<=1u;e--;}
 let odd=e&1i;var half=(e-odd)/2i;let shift=23u+u32(odd);
 let n=InkU64(m<<shift,m>>(32u-shift));var lo=0u;var hi=0x1000000u;
 loop{if(lo+1u>=hi){break;}let mid=(lo+hi)>>1u;let sq=ink_u64_mul(InkU64(mid,0u),InkU64(mid,0u));if(!ink_u64_lt(n,sq)){lo=mid;}else{hi=mid;}}
 let sq=ink_u64_mul(InkU64(lo,0u),InkU64(lo,0u));let rem=ink_u64_sub(n,sq);
 if(ink_u64_lt(InkU64(lo,0u),rem)){lo++;}
 if(lo==0x1000000u){lo>>=1u;half++;}
 return (u32(half+127i)<<23u)|(lo&0x7fffffu);
}
fn ink_f32_div(a:u32,b:u32)->u32{
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(ink_f32_nan(a)||ink_f32_nan(b)||(aa==0u&&bb==0u)||(aa==0x7f800000u&&bb==aa)){return 0x7fc00000u;}
 if(aa==0x7f800000u||bb==0u){return sign|0x7f800000u;}
 if(aa==0u||bb==0x7f800000u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u))-127i;var eb=i32(max(rb,1u))-127i;
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 var e=ea-eb;if(sa<sb){sa<<=1u;e--;}
 let division=ink_u64_div(InkU64(sa<<26u,sa>>6u),InkU64(sb,0u));
 let extended=division.quotient.lo|select(0u,1u,!ink_u64_eq(division.remainder,InkU64(0u,0u)));
 return ink_f32_round(sign,e+127i,extended);
}
// mode: 0 trunc, 1 floor, 2 ceil, 3 ties-to-even.
fn ink_f32_integral(x:u32,mode:u32)->u32{
 let a=x&0x7fffffffu;let sign=x&0x80000000u;
 if(a>0x7f800000u){return 0x7fc00000u;}if(a>=0x4b000000u||a==0u){return x;}
 let e=i32((x>>23u)&255u)-127i;
 if(e<0i){var up=false;if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){up=a>0x3f000000u;}return sign|select(0u,0x3f800000u,up);}
 let shift=u32(23i-e);let mask=(1u<<shift)-1u;let fraction=a&mask;var rounded=a&~mask;var up=false;
 if(fraction!=0u){if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){let half=1u<<(shift-1u);up=fraction>half||(fraction==half&&((rounded>>shift)&1u)!=0u);}}
 if(up){rounded+=1u<<shift;}return sign|rounded;
}
fn ink_f32_from_u64(x:InkU64)->u32{
 if(ink_u64_eq(x,InkU64(0u,0u))){return 0u;}
 let leading=select(countLeadingZeros(x.lo)+32u,countLeadingZeros(x.hi),x.hi!=0u);let e=63u-leading;
 if(e<=23u){return ((e+127u)<<23u)|((x.lo<<(23u-e))&0x7fffffu);}
 let shift=e-23u;var sig=0u;var rem=InkU64(0u,0u);var half=InkU64(0u,0u);
 if(shift<32u){sig=(x.lo>>shift)|(x.hi<<(32u-shift));rem=InkU64(x.lo&((1u<<shift)-1u),0u);half=InkU64(1u<<(shift-1u),0u);}
 else if(shift==32u){sig=x.hi;rem=InkU64(x.lo,0u);half=InkU64(0x80000000u,0u);}
 else{sig=x.hi>>(shift-32u);rem=InkU64(x.lo,x.hi&((1u<<(shift-32u))-1u));half=InkU64(0u,1u<<(shift-33u));}
 if(ink_u64_lt(half,rem)||(ink_u64_eq(rem,half)&&(sig&1u)!=0u)){sig++;}
 var exponent=e+127u;if(sig==0x1000000u){sig>>=1u;exponent++;}
 return (exponent<<23u)|(sig&0x7fffffu);
}
fn ink_f32_from_i32(x:i32)->u32{let neg=x<0i;let magnitude=select(u32(x),0u-u32(x),neg);return ink_f32_from_u64(InkU64(magnitude,0u))|select(0u,0x80000000u,neg);}
struct InkBuffer_u32{data:array<u32,64>,length:u32,}
struct InkBuffer_InkU64{data:array<InkU64,64>,length:u32,}
struct InkBuffer_i32{data:array<i32,64>,length:u32,}
struct InkBuffer_bool{data:array<bool,64>,length:u32,}
struct R_Config{ink_f_rate:u32,ink_f_first_decay:u32,ink_f_second_decay:u32,ink_f_epsilon:u32,}
struct R_Parameter{ink_f_value:u32,ink_f_first:u32,ink_f_second:u32,ink_f_first_power:u32,ink_f_second_power:u32,ink_f_steps:u32,}
struct R___ink_differential_0{ink_f_value:u32,ink_f_tangent:u32,}
struct R___ink_differential_3{ink_f_value:R___ink_differential_0,ink_f_first:R___ink_differential_0,ink_f_second:R___ink_differential_0,ink_f_first_power:R___ink_differential_0,ink_f_second_power:R___ink_differential_0,ink_f_steps:u32,}
@group(0) @binding(0) var<storage,read> a0:array<u32>;
@group(0) @binding(1) var<storage,read> a1:array<u32>;
@group(0) @binding(2) var<storage,read> a2:array<u32>;
@group(0) @binding(3) var<storage,read> a3:array<u32>;
@group(0) @binding(4) var<storage,read_write> output:array<u32>;
@group(0) @binding(5) var<storage,read> ink_meta:array<u32>;
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=ink_meta[4]){return;}
var t0:u32=a3[0u];
var t1:u32;if((t0 == 0u)){
t1=a0[0u];}else{
t1=a0[0u];}
if(i==0u){output[0u]=t1;}if(i>=t1){return;}
var t2:u32=a3[0u];
var t3:u32;if((t2 == 0u)){
var t4:R_Parameter=R_Parameter(a0[1u+(i)*6u+0u],a0[1u+(i)*6u+1u],a0[1u+(i)*6u+2u],a0[1u+(i)*6u+3u],a0[1u+(i)*6u+4u],a0[1u+(i)*6u+5u]);
t3=0u;}else{
var t5:u32=i;
var t6:R_Parameter=R_Parameter(a0[1u+(i)*6u+0u],a0[1u+(i)*6u+1u],a0[1u+(i)*6u+2u],a0[1u+(i)*6u+3u],a0[1u+(i)*6u+4u],a0[1u+(i)*6u+5u]);
var t7:u32=0u;
for(var t8=0u;t8<a3[0u];t8++){
var t9:u32=a3[1u+(t8)*1u+0u];
var t10:u32=t7;
var t11:u32=t10;
var t12:u32=(t6).ink_f_value;
var t13:u32=t5;
var t14:u32=t9;
var t15:u32=t12;
var t16:u32=1065353216u;
var t17:R___ink_differential_0=R___ink_differential_0(t15,t16);
var t18:u32=t13;
var t19:u32=t14;
var t20:R___ink_differential_0=t17;
var t21:u32=t18;
var t22:u32=t19;
var t23:R___ink_differential_0=t20;
var t24:u32=t21;
var t25:u32=t22;
var t26:array<R___ink_differential_0,6>;
var t27:R___ink_differential_0=t23;
var t28:u32=t24;
var t29:u32=t25;
var t30:u32=0u;
var t31:R___ink_differential_0=t27;
var t32:u32=t28;
var t33:u32=t30;
var t34:u32=(t33 + 10u);
var t35:u32=t32;
var t36:R___ink_differential_0;
if ((t35 == t34)) {
t36=t31;
} else {
var t37:u32=t34;
var t38:R___ink_differential_3;if(t37<a0[0u]){
var t39:R_Parameter=R_Parameter(a0[1u+(t37)*6u+0u],a0[1u+(t37)*6u+1u],a0[1u+(t37)*6u+2u],a0[1u+(t37)*6u+3u],a0[1u+(t37)*6u+4u],a0[1u+(t37)*6u+5u]);
var t40:u32=(t39).ink_f_value;
var t41:u32=0u;
var t42:R___ink_differential_0=R___ink_differential_0(t40,t41);
var t43:u32=(t39).ink_f_first;
var t44:u32=0u;
var t45:R___ink_differential_0=R___ink_differential_0(t43,t44);
var t46:u32=(t39).ink_f_second;
var t47:u32=0u;
var t48:R___ink_differential_0=R___ink_differential_0(t46,t47);
var t49:u32=(t39).ink_f_first_power;
var t50:u32=0u;
var t51:R___ink_differential_0=R___ink_differential_0(t49,t50);
var t52:u32=(t39).ink_f_second_power;
var t53:u32=0u;
var t54:R___ink_differential_0=R___ink_differential_0(t52,t53);
var t55:u32=(t39).ink_f_steps;
t38=R___ink_differential_3(t42,t45,t48,t51,t54,t55);}else{
var t56:u32=0u;
var t57:u32=0u;
var t58:R___ink_differential_0=R___ink_differential_0(t56,t57);
var t59:u32=0u;
var t60:u32=0u;
var t61:R___ink_differential_0=R___ink_differential_0(t59,t60);
var t62:u32=0u;
var t63:u32=0u;
var t64:R___ink_differential_0=R___ink_differential_0(t62,t63);
var t65:u32=1065353216u;
var t66:u32=0u;
var t67:R___ink_differential_0=R___ink_differential_0(t65,t66);
var t68:u32=1065353216u;
var t69:u32=0u;
var t70:R___ink_differential_0=R___ink_differential_0(t68,t69);
var t71:u32=0u;
t38=R___ink_differential_3(t58,t61,t64,t67,t70,t71);}
t36=(t38).ink_f_value;
}
var t72:R___ink_differential_0=t36;
var t73:R___ink_differential_0=t72;
for(var t74=0u;t74<10u;t74++){
var t75:R___ink_differential_0=t73;
var t76:R___ink_differential_0=t27;
var t77:u32=t28;
var t78:u32=t30;
var t79:u32=(t78 + t74);
var t80:u32=t77;
var t81:R___ink_differential_0;
if ((t80 == t79)) {
t81=t76;
} else {
var t82:u32=t79;
var t83:R___ink_differential_3;if(t82<a0[0u]){
var t84:R_Parameter=R_Parameter(a0[1u+(t82)*6u+0u],a0[1u+(t82)*6u+1u],a0[1u+(t82)*6u+2u],a0[1u+(t82)*6u+3u],a0[1u+(t82)*6u+4u],a0[1u+(t82)*6u+5u]);
var t85:u32=(t84).ink_f_value;
var t86:u32=0u;
var t87:R___ink_differential_0=R___ink_differential_0(t85,t86);
var t88:u32=(t84).ink_f_first;
var t89:u32=0u;
var t90:R___ink_differential_0=R___ink_differential_0(t88,t89);
var t91:u32=(t84).ink_f_second;
var t92:u32=0u;
var t93:R___ink_differential_0=R___ink_differential_0(t91,t92);
var t94:u32=(t84).ink_f_first_power;
var t95:u32=0u;
var t96:R___ink_differential_0=R___ink_differential_0(t94,t95);
var t97:u32=(t84).ink_f_second_power;
var t98:u32=0u;
var t99:R___ink_differential_0=R___ink_differential_0(t97,t98);
var t100:u32=(t84).ink_f_steps;
t83=R___ink_differential_3(t87,t90,t93,t96,t99,t100);}else{
var t101:u32=0u;
var t102:u32=0u;
var t103:R___ink_differential_0=R___ink_differential_0(t101,t102);
var t104:u32=0u;
var t105:u32=0u;
var t106:R___ink_differential_0=R___ink_differential_0(t104,t105);
var t107:u32=0u;
var t108:u32=0u;
var t109:R___ink_differential_0=R___ink_differential_0(t107,t108);
var t110:u32=1065353216u;
var t111:u32=0u;
var t112:R___ink_differential_0=R___ink_differential_0(t110,t111);
var t113:u32=1065353216u;
var t114:u32=0u;
var t115:R___ink_differential_0=R___ink_differential_0(t113,t114);
var t116:u32=0u;
t83=R___ink_differential_3(t103,t106,t109,t112,t115,t116);}
t81=(t83).ink_f_value;
}
var t117:R___ink_differential_0=t81;
var t118:u32=t29;
var t119:u32=(t118 * 10u);
var t120:u32=(t119 + t74);
var t121:R___ink_differential_0;if(t120<a1[0u]){
var t122:u32=a1[1u+(t120)*1u+0u];
var t123:u32=t122;
var t124:u32=0u;
t121=R___ink_differential_0(t123,t124);}else{
var t125:u32=0u;
var t126:u32=0u;
t121=R___ink_differential_0(t125,t126);}
var t127:R___ink_differential_0=t121;
var t128:u32=(t117).ink_f_value;
var t129:u32=ink_f32_mul(t128,(t127).ink_f_value);
var t130:u32=t129;
var t131:u32=(t117).ink_f_tangent;
var t132:u32=ink_f32_mul(t131,(t127).ink_f_value);
var t133:u32=(t117).ink_f_value;
var t134:u32=ink_f32_add(t132,ink_f32_mul(t133,(t127).ink_f_tangent));
var t135:R___ink_differential_0=R___ink_differential_0(t130,t134);
var t136:u32=(t75).ink_f_value;
var t137:u32=ink_f32_add(t136,(t135).ink_f_value);
var t138:u32=t137;
var t139:u32=(t75).ink_f_tangent;
var t140:u32=ink_f32_add(t139,(t135).ink_f_tangent);
t73=R___ink_differential_0(t138,t140);
}
var t141:R___ink_differential_0=t73;
var t142:R___ink_differential_0=t23;
var t143:u32=t24;
var t144:u32=t25;
var t145:u32=11u;
var t146:R___ink_differential_0=t142;
var t147:u32=t143;
var t148:u32=t145;
var t149:u32=(t148 + 10u);
var t150:u32=t147;
var t151:R___ink_differential_0;
if ((t150 == t149)) {
t151=t146;
} else {
var t152:u32=t149;
var t153:R___ink_differential_3;if(t152<a0[0u]){
var t154:R_Parameter=R_Parameter(a0[1u+(t152)*6u+0u],a0[1u+(t152)*6u+1u],a0[1u+(t152)*6u+2u],a0[1u+(t152)*6u+3u],a0[1u+(t152)*6u+4u],a0[1u+(t152)*6u+5u]);
var t155:u32=(t154).ink_f_value;
var t156:u32=0u;
var t157:R___ink_differential_0=R___ink_differential_0(t155,t156);
var t158:u32=(t154).ink_f_first;
var t159:u32=0u;
var t160:R___ink_differential_0=R___ink_differential_0(t158,t159);
var t161:u32=(t154).ink_f_second;
var t162:u32=0u;
var t163:R___ink_differential_0=R___ink_differential_0(t161,t162);
var t164:u32=(t154).ink_f_first_power;
var t165:u32=0u;
var t166:R___ink_differential_0=R___ink_differential_0(t164,t165);
var t167:u32=(t154).ink_f_second_power;
var t168:u32=0u;
var t169:R___ink_differential_0=R___ink_differential_0(t167,t168);
var t170:u32=(t154).ink_f_steps;
t153=R___ink_differential_3(t157,t160,t163,t166,t169,t170);}else{
var t171:u32=0u;
var t172:u32=0u;
var t173:R___ink_differential_0=R___ink_differential_0(t171,t172);
var t174:u32=0u;
var t175:u32=0u;
var t176:R___ink_differential_0=R___ink_differential_0(t174,t175);
var t177:u32=0u;
var t178:u32=0u;
var t179:R___ink_differential_0=R___ink_differential_0(t177,t178);
var t180:u32=1065353216u;
var t181:u32=0u;
var t182:R___ink_differential_0=R___ink_differential_0(t180,t181);
var t183:u32=1065353216u;
var t184:u32=0u;
var t185:R___ink_differential_0=R___ink_differential_0(t183,t184);
var t186:u32=0u;
t153=R___ink_differential_3(t173,t176,t179,t182,t185,t186);}
t151=(t153).ink_f_value;
}
var t187:R___ink_differential_0=t151;
var t188:R___ink_differential_0=t187;
for(var t189=0u;t189<10u;t189++){
var t190:R___ink_differential_0=t188;
var t191:R___ink_differential_0=t142;
var t192:u32=t143;
var t193:u32=t145;
var t194:u32=(t193 + t189);
var t195:u32=t192;
var t196:R___ink_differential_0;
if ((t195 == t194)) {
t196=t191;
} else {
var t197:u32=t194;
var t198:R___ink_differential_3;if(t197<a0[0u]){
var t199:R_Parameter=R_Parameter(a0[1u+(t197)*6u+0u],a0[1u+(t197)*6u+1u],a0[1u+(t197)*6u+2u],a0[1u+(t197)*6u+3u],a0[1u+(t197)*6u+4u],a0[1u+(t197)*6u+5u]);
var t200:u32=(t199).ink_f_value;
var t201:u32=0u;
var t202:R___ink_differential_0=R___ink_differential_0(t200,t201);
var t203:u32=(t199).ink_f_first;
var t204:u32=0u;
var t205:R___ink_differential_0=R___ink_differential_0(t203,t204);
var t206:u32=(t199).ink_f_second;
var t207:u32=0u;
var t208:R___ink_differential_0=R___ink_differential_0(t206,t207);
var t209:u32=(t199).ink_f_first_power;
var t210:u32=0u;
var t211:R___ink_differential_0=R___ink_differential_0(t209,t210);
var t212:u32=(t199).ink_f_second_power;
var t213:u32=0u;
var t214:R___ink_differential_0=R___ink_differential_0(t212,t213);
var t215:u32=(t199).ink_f_steps;
t198=R___ink_differential_3(t202,t205,t208,t211,t214,t215);}else{
var t216:u32=0u;
var t217:u32=0u;
var t218:R___ink_differential_0=R___ink_differential_0(t216,t217);
var t219:u32=0u;
var t220:u32=0u;
var t221:R___ink_differential_0=R___ink_differential_0(t219,t220);
var t222:u32=0u;
var t223:u32=0u;
var t224:R___ink_differential_0=R___ink_differential_0(t222,t223);
var t225:u32=1065353216u;
var t226:u32=0u;
var t227:R___ink_differential_0=R___ink_differential_0(t225,t226);
var t228:u32=1065353216u;
var t229:u32=0u;
var t230:R___ink_differential_0=R___ink_differential_0(t228,t229);
var t231:u32=0u;
t198=R___ink_differential_3(t218,t221,t224,t227,t230,t231);}
t196=(t198).ink_f_value;
}
var t232:R___ink_differential_0=t196;
var t233:u32=t144;
var t234:u32=(t233 * 10u);
var t235:u32=(t234 + t189);
var t236:R___ink_differential_0;if(t235<a1[0u]){
var t237:u32=a1[1u+(t235)*1u+0u];
var t238:u32=t237;
var t239:u32=0u;
t236=R___ink_differential_0(t238,t239);}else{
var t240:u32=0u;
var t241:u32=0u;
t236=R___ink_differential_0(t240,t241);}
var t242:R___ink_differential_0=t236;
var t243:u32=(t232).ink_f_value;
var t244:u32=ink_f32_mul(t243,(t242).ink_f_value);
var t245:u32=t244;
var t246:u32=(t232).ink_f_tangent;
var t247:u32=ink_f32_mul(t246,(t242).ink_f_value);
var t248:u32=(t232).ink_f_value;
var t249:u32=ink_f32_add(t247,ink_f32_mul(t248,(t242).ink_f_tangent));
var t250:R___ink_differential_0=R___ink_differential_0(t245,t249);
var t251:u32=(t190).ink_f_value;
var t252:u32=ink_f32_add(t251,(t250).ink_f_value);
var t253:u32=t252;
var t254:u32=(t190).ink_f_tangent;
var t255:u32=ink_f32_add(t254,(t250).ink_f_tangent);
t188=R___ink_differential_0(t253,t255);
}
var t256:R___ink_differential_0=t188;
var t257:u32=(t256).ink_f_value;
var t258:u32=0u;
var t259:u32=0u;
var t260:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t258,t259)).ink_f_value,t257)) {
var t261:R___ink_differential_0=t141;
var t262:R___ink_differential_0=t256;
var t263:u32=(t261).ink_f_value;
var t264:u32=ink_f32_mul(t263,(t262).ink_f_value);
var t265:u32=t264;
var t266:u32=(t261).ink_f_tangent;
var t267:u32=ink_f32_mul(t266,(t262).ink_f_value);
var t268:u32=(t261).ink_f_value;
var t269:u32=ink_f32_add(t267,ink_f32_mul(t268,(t262).ink_f_tangent));
t260=R___ink_differential_0(t265,t269);
} else {
var t270:u32=0u;
var t271:u32=0u;
t260=R___ink_differential_0(t270,t271);
}
t26[0u]=t260;
var t272:R___ink_differential_0=t23;
var t273:u32=t24;
var t274:u32=t25;
var t275:u32=22u;
var t276:R___ink_differential_0=t272;
var t277:u32=t273;
var t278:u32=t275;
var t279:u32=(t278 + 10u);
var t280:u32=t277;
var t281:R___ink_differential_0;
if ((t280 == t279)) {
t281=t276;
} else {
var t282:u32=t279;
var t283:R___ink_differential_3;if(t282<a0[0u]){
var t284:R_Parameter=R_Parameter(a0[1u+(t282)*6u+0u],a0[1u+(t282)*6u+1u],a0[1u+(t282)*6u+2u],a0[1u+(t282)*6u+3u],a0[1u+(t282)*6u+4u],a0[1u+(t282)*6u+5u]);
var t285:u32=(t284).ink_f_value;
var t286:u32=0u;
var t287:R___ink_differential_0=R___ink_differential_0(t285,t286);
var t288:u32=(t284).ink_f_first;
var t289:u32=0u;
var t290:R___ink_differential_0=R___ink_differential_0(t288,t289);
var t291:u32=(t284).ink_f_second;
var t292:u32=0u;
var t293:R___ink_differential_0=R___ink_differential_0(t291,t292);
var t294:u32=(t284).ink_f_first_power;
var t295:u32=0u;
var t296:R___ink_differential_0=R___ink_differential_0(t294,t295);
var t297:u32=(t284).ink_f_second_power;
var t298:u32=0u;
var t299:R___ink_differential_0=R___ink_differential_0(t297,t298);
var t300:u32=(t284).ink_f_steps;
t283=R___ink_differential_3(t287,t290,t293,t296,t299,t300);}else{
var t301:u32=0u;
var t302:u32=0u;
var t303:R___ink_differential_0=R___ink_differential_0(t301,t302);
var t304:u32=0u;
var t305:u32=0u;
var t306:R___ink_differential_0=R___ink_differential_0(t304,t305);
var t307:u32=0u;
var t308:u32=0u;
var t309:R___ink_differential_0=R___ink_differential_0(t307,t308);
var t310:u32=1065353216u;
var t311:u32=0u;
var t312:R___ink_differential_0=R___ink_differential_0(t310,t311);
var t313:u32=1065353216u;
var t314:u32=0u;
var t315:R___ink_differential_0=R___ink_differential_0(t313,t314);
var t316:u32=0u;
t283=R___ink_differential_3(t303,t306,t309,t312,t315,t316);}
t281=(t283).ink_f_value;
}
var t317:R___ink_differential_0=t281;
var t318:R___ink_differential_0=t317;
for(var t319=0u;t319<10u;t319++){
var t320:R___ink_differential_0=t318;
var t321:R___ink_differential_0=t272;
var t322:u32=t273;
var t323:u32=t275;
var t324:u32=(t323 + t319);
var t325:u32=t322;
var t326:R___ink_differential_0;
if ((t325 == t324)) {
t326=t321;
} else {
var t327:u32=t324;
var t328:R___ink_differential_3;if(t327<a0[0u]){
var t329:R_Parameter=R_Parameter(a0[1u+(t327)*6u+0u],a0[1u+(t327)*6u+1u],a0[1u+(t327)*6u+2u],a0[1u+(t327)*6u+3u],a0[1u+(t327)*6u+4u],a0[1u+(t327)*6u+5u]);
var t330:u32=(t329).ink_f_value;
var t331:u32=0u;
var t332:R___ink_differential_0=R___ink_differential_0(t330,t331);
var t333:u32=(t329).ink_f_first;
var t334:u32=0u;
var t335:R___ink_differential_0=R___ink_differential_0(t333,t334);
var t336:u32=(t329).ink_f_second;
var t337:u32=0u;
var t338:R___ink_differential_0=R___ink_differential_0(t336,t337);
var t339:u32=(t329).ink_f_first_power;
var t340:u32=0u;
var t341:R___ink_differential_0=R___ink_differential_0(t339,t340);
var t342:u32=(t329).ink_f_second_power;
var t343:u32=0u;
var t344:R___ink_differential_0=R___ink_differential_0(t342,t343);
var t345:u32=(t329).ink_f_steps;
t328=R___ink_differential_3(t332,t335,t338,t341,t344,t345);}else{
var t346:u32=0u;
var t347:u32=0u;
var t348:R___ink_differential_0=R___ink_differential_0(t346,t347);
var t349:u32=0u;
var t350:u32=0u;
var t351:R___ink_differential_0=R___ink_differential_0(t349,t350);
var t352:u32=0u;
var t353:u32=0u;
var t354:R___ink_differential_0=R___ink_differential_0(t352,t353);
var t355:u32=1065353216u;
var t356:u32=0u;
var t357:R___ink_differential_0=R___ink_differential_0(t355,t356);
var t358:u32=1065353216u;
var t359:u32=0u;
var t360:R___ink_differential_0=R___ink_differential_0(t358,t359);
var t361:u32=0u;
t328=R___ink_differential_3(t348,t351,t354,t357,t360,t361);}
t326=(t328).ink_f_value;
}
var t362:R___ink_differential_0=t326;
var t363:u32=t274;
var t364:u32=(t363 * 10u);
var t365:u32=(t364 + t319);
var t366:R___ink_differential_0;if(t365<a1[0u]){
var t367:u32=a1[1u+(t365)*1u+0u];
var t368:u32=t367;
var t369:u32=0u;
t366=R___ink_differential_0(t368,t369);}else{
var t370:u32=0u;
var t371:u32=0u;
t366=R___ink_differential_0(t370,t371);}
var t372:R___ink_differential_0=t366;
var t373:u32=(t362).ink_f_value;
var t374:u32=ink_f32_mul(t373,(t372).ink_f_value);
var t375:u32=t374;
var t376:u32=(t362).ink_f_tangent;
var t377:u32=ink_f32_mul(t376,(t372).ink_f_value);
var t378:u32=(t362).ink_f_value;
var t379:u32=ink_f32_add(t377,ink_f32_mul(t378,(t372).ink_f_tangent));
var t380:R___ink_differential_0=R___ink_differential_0(t375,t379);
var t381:u32=(t320).ink_f_value;
var t382:u32=ink_f32_add(t381,(t380).ink_f_value);
var t383:u32=t382;
var t384:u32=(t320).ink_f_tangent;
var t385:u32=ink_f32_add(t384,(t380).ink_f_tangent);
t318=R___ink_differential_0(t383,t385);
}
var t386:R___ink_differential_0=t318;
var t387:R___ink_differential_0=t23;
var t388:u32=t24;
var t389:u32=t25;
var t390:u32=33u;
var t391:R___ink_differential_0=t387;
var t392:u32=t388;
var t393:u32=t390;
var t394:u32=(t393 + 10u);
var t395:u32=t392;
var t396:R___ink_differential_0;
if ((t395 == t394)) {
t396=t391;
} else {
var t397:u32=t394;
var t398:R___ink_differential_3;if(t397<a0[0u]){
var t399:R_Parameter=R_Parameter(a0[1u+(t397)*6u+0u],a0[1u+(t397)*6u+1u],a0[1u+(t397)*6u+2u],a0[1u+(t397)*6u+3u],a0[1u+(t397)*6u+4u],a0[1u+(t397)*6u+5u]);
var t400:u32=(t399).ink_f_value;
var t401:u32=0u;
var t402:R___ink_differential_0=R___ink_differential_0(t400,t401);
var t403:u32=(t399).ink_f_first;
var t404:u32=0u;
var t405:R___ink_differential_0=R___ink_differential_0(t403,t404);
var t406:u32=(t399).ink_f_second;
var t407:u32=0u;
var t408:R___ink_differential_0=R___ink_differential_0(t406,t407);
var t409:u32=(t399).ink_f_first_power;
var t410:u32=0u;
var t411:R___ink_differential_0=R___ink_differential_0(t409,t410);
var t412:u32=(t399).ink_f_second_power;
var t413:u32=0u;
var t414:R___ink_differential_0=R___ink_differential_0(t412,t413);
var t415:u32=(t399).ink_f_steps;
t398=R___ink_differential_3(t402,t405,t408,t411,t414,t415);}else{
var t416:u32=0u;
var t417:u32=0u;
var t418:R___ink_differential_0=R___ink_differential_0(t416,t417);
var t419:u32=0u;
var t420:u32=0u;
var t421:R___ink_differential_0=R___ink_differential_0(t419,t420);
var t422:u32=0u;
var t423:u32=0u;
var t424:R___ink_differential_0=R___ink_differential_0(t422,t423);
var t425:u32=1065353216u;
var t426:u32=0u;
var t427:R___ink_differential_0=R___ink_differential_0(t425,t426);
var t428:u32=1065353216u;
var t429:u32=0u;
var t430:R___ink_differential_0=R___ink_differential_0(t428,t429);
var t431:u32=0u;
t398=R___ink_differential_3(t418,t421,t424,t427,t430,t431);}
t396=(t398).ink_f_value;
}
var t432:R___ink_differential_0=t396;
var t433:R___ink_differential_0=t432;
for(var t434=0u;t434<10u;t434++){
var t435:R___ink_differential_0=t433;
var t436:R___ink_differential_0=t387;
var t437:u32=t388;
var t438:u32=t390;
var t439:u32=(t438 + t434);
var t440:u32=t437;
var t441:R___ink_differential_0;
if ((t440 == t439)) {
t441=t436;
} else {
var t442:u32=t439;
var t443:R___ink_differential_3;if(t442<a0[0u]){
var t444:R_Parameter=R_Parameter(a0[1u+(t442)*6u+0u],a0[1u+(t442)*6u+1u],a0[1u+(t442)*6u+2u],a0[1u+(t442)*6u+3u],a0[1u+(t442)*6u+4u],a0[1u+(t442)*6u+5u]);
var t445:u32=(t444).ink_f_value;
var t446:u32=0u;
var t447:R___ink_differential_0=R___ink_differential_0(t445,t446);
var t448:u32=(t444).ink_f_first;
var t449:u32=0u;
var t450:R___ink_differential_0=R___ink_differential_0(t448,t449);
var t451:u32=(t444).ink_f_second;
var t452:u32=0u;
var t453:R___ink_differential_0=R___ink_differential_0(t451,t452);
var t454:u32=(t444).ink_f_first_power;
var t455:u32=0u;
var t456:R___ink_differential_0=R___ink_differential_0(t454,t455);
var t457:u32=(t444).ink_f_second_power;
var t458:u32=0u;
var t459:R___ink_differential_0=R___ink_differential_0(t457,t458);
var t460:u32=(t444).ink_f_steps;
t443=R___ink_differential_3(t447,t450,t453,t456,t459,t460);}else{
var t461:u32=0u;
var t462:u32=0u;
var t463:R___ink_differential_0=R___ink_differential_0(t461,t462);
var t464:u32=0u;
var t465:u32=0u;
var t466:R___ink_differential_0=R___ink_differential_0(t464,t465);
var t467:u32=0u;
var t468:u32=0u;
var t469:R___ink_differential_0=R___ink_differential_0(t467,t468);
var t470:u32=1065353216u;
var t471:u32=0u;
var t472:R___ink_differential_0=R___ink_differential_0(t470,t471);
var t473:u32=1065353216u;
var t474:u32=0u;
var t475:R___ink_differential_0=R___ink_differential_0(t473,t474);
var t476:u32=0u;
t443=R___ink_differential_3(t463,t466,t469,t472,t475,t476);}
t441=(t443).ink_f_value;
}
var t477:R___ink_differential_0=t441;
var t478:u32=t389;
var t479:u32=(t478 * 10u);
var t480:u32=(t479 + t434);
var t481:R___ink_differential_0;if(t480<a1[0u]){
var t482:u32=a1[1u+(t480)*1u+0u];
var t483:u32=t482;
var t484:u32=0u;
t481=R___ink_differential_0(t483,t484);}else{
var t485:u32=0u;
var t486:u32=0u;
t481=R___ink_differential_0(t485,t486);}
var t487:R___ink_differential_0=t481;
var t488:u32=(t477).ink_f_value;
var t489:u32=ink_f32_mul(t488,(t487).ink_f_value);
var t490:u32=t489;
var t491:u32=(t477).ink_f_tangent;
var t492:u32=ink_f32_mul(t491,(t487).ink_f_value);
var t493:u32=(t477).ink_f_value;
var t494:u32=ink_f32_add(t492,ink_f32_mul(t493,(t487).ink_f_tangent));
var t495:R___ink_differential_0=R___ink_differential_0(t490,t494);
var t496:u32=(t435).ink_f_value;
var t497:u32=ink_f32_add(t496,(t495).ink_f_value);
var t498:u32=t497;
var t499:u32=(t435).ink_f_tangent;
var t500:u32=ink_f32_add(t499,(t495).ink_f_tangent);
t433=R___ink_differential_0(t498,t500);
}
var t501:R___ink_differential_0=t433;
var t502:u32=(t501).ink_f_value;
var t503:u32=0u;
var t504:u32=0u;
var t505:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t503,t504)).ink_f_value,t502)) {
var t506:R___ink_differential_0=t386;
var t507:R___ink_differential_0=t501;
var t508:u32=(t506).ink_f_value;
var t509:u32=ink_f32_mul(t508,(t507).ink_f_value);
var t510:u32=t509;
var t511:u32=(t506).ink_f_tangent;
var t512:u32=ink_f32_mul(t511,(t507).ink_f_value);
var t513:u32=(t506).ink_f_value;
var t514:u32=ink_f32_add(t512,ink_f32_mul(t513,(t507).ink_f_tangent));
t505=R___ink_differential_0(t510,t514);
} else {
var t515:u32=0u;
var t516:u32=0u;
t505=R___ink_differential_0(t515,t516);
}
t26[1u]=t505;
var t517:R___ink_differential_0=t23;
var t518:u32=t24;
var t519:u32=t25;
var t520:u32=44u;
var t521:R___ink_differential_0=t517;
var t522:u32=t518;
var t523:u32=t520;
var t524:u32=(t523 + 10u);
var t525:u32=t522;
var t526:R___ink_differential_0;
if ((t525 == t524)) {
t526=t521;
} else {
var t527:u32=t524;
var t528:R___ink_differential_3;if(t527<a0[0u]){
var t529:R_Parameter=R_Parameter(a0[1u+(t527)*6u+0u],a0[1u+(t527)*6u+1u],a0[1u+(t527)*6u+2u],a0[1u+(t527)*6u+3u],a0[1u+(t527)*6u+4u],a0[1u+(t527)*6u+5u]);
var t530:u32=(t529).ink_f_value;
var t531:u32=0u;
var t532:R___ink_differential_0=R___ink_differential_0(t530,t531);
var t533:u32=(t529).ink_f_first;
var t534:u32=0u;
var t535:R___ink_differential_0=R___ink_differential_0(t533,t534);
var t536:u32=(t529).ink_f_second;
var t537:u32=0u;
var t538:R___ink_differential_0=R___ink_differential_0(t536,t537);
var t539:u32=(t529).ink_f_first_power;
var t540:u32=0u;
var t541:R___ink_differential_0=R___ink_differential_0(t539,t540);
var t542:u32=(t529).ink_f_second_power;
var t543:u32=0u;
var t544:R___ink_differential_0=R___ink_differential_0(t542,t543);
var t545:u32=(t529).ink_f_steps;
t528=R___ink_differential_3(t532,t535,t538,t541,t544,t545);}else{
var t546:u32=0u;
var t547:u32=0u;
var t548:R___ink_differential_0=R___ink_differential_0(t546,t547);
var t549:u32=0u;
var t550:u32=0u;
var t551:R___ink_differential_0=R___ink_differential_0(t549,t550);
var t552:u32=0u;
var t553:u32=0u;
var t554:R___ink_differential_0=R___ink_differential_0(t552,t553);
var t555:u32=1065353216u;
var t556:u32=0u;
var t557:R___ink_differential_0=R___ink_differential_0(t555,t556);
var t558:u32=1065353216u;
var t559:u32=0u;
var t560:R___ink_differential_0=R___ink_differential_0(t558,t559);
var t561:u32=0u;
t528=R___ink_differential_3(t548,t551,t554,t557,t560,t561);}
t526=(t528).ink_f_value;
}
var t562:R___ink_differential_0=t526;
var t563:R___ink_differential_0=t562;
for(var t564=0u;t564<10u;t564++){
var t565:R___ink_differential_0=t563;
var t566:R___ink_differential_0=t517;
var t567:u32=t518;
var t568:u32=t520;
var t569:u32=(t568 + t564);
var t570:u32=t567;
var t571:R___ink_differential_0;
if ((t570 == t569)) {
t571=t566;
} else {
var t572:u32=t569;
var t573:R___ink_differential_3;if(t572<a0[0u]){
var t574:R_Parameter=R_Parameter(a0[1u+(t572)*6u+0u],a0[1u+(t572)*6u+1u],a0[1u+(t572)*6u+2u],a0[1u+(t572)*6u+3u],a0[1u+(t572)*6u+4u],a0[1u+(t572)*6u+5u]);
var t575:u32=(t574).ink_f_value;
var t576:u32=0u;
var t577:R___ink_differential_0=R___ink_differential_0(t575,t576);
var t578:u32=(t574).ink_f_first;
var t579:u32=0u;
var t580:R___ink_differential_0=R___ink_differential_0(t578,t579);
var t581:u32=(t574).ink_f_second;
var t582:u32=0u;
var t583:R___ink_differential_0=R___ink_differential_0(t581,t582);
var t584:u32=(t574).ink_f_first_power;
var t585:u32=0u;
var t586:R___ink_differential_0=R___ink_differential_0(t584,t585);
var t587:u32=(t574).ink_f_second_power;
var t588:u32=0u;
var t589:R___ink_differential_0=R___ink_differential_0(t587,t588);
var t590:u32=(t574).ink_f_steps;
t573=R___ink_differential_3(t577,t580,t583,t586,t589,t590);}else{
var t591:u32=0u;
var t592:u32=0u;
var t593:R___ink_differential_0=R___ink_differential_0(t591,t592);
var t594:u32=0u;
var t595:u32=0u;
var t596:R___ink_differential_0=R___ink_differential_0(t594,t595);
var t597:u32=0u;
var t598:u32=0u;
var t599:R___ink_differential_0=R___ink_differential_0(t597,t598);
var t600:u32=1065353216u;
var t601:u32=0u;
var t602:R___ink_differential_0=R___ink_differential_0(t600,t601);
var t603:u32=1065353216u;
var t604:u32=0u;
var t605:R___ink_differential_0=R___ink_differential_0(t603,t604);
var t606:u32=0u;
t573=R___ink_differential_3(t593,t596,t599,t602,t605,t606);}
t571=(t573).ink_f_value;
}
var t607:R___ink_differential_0=t571;
var t608:u32=t519;
var t609:u32=(t608 * 10u);
var t610:u32=(t609 + t564);
var t611:R___ink_differential_0;if(t610<a1[0u]){
var t612:u32=a1[1u+(t610)*1u+0u];
var t613:u32=t612;
var t614:u32=0u;
t611=R___ink_differential_0(t613,t614);}else{
var t615:u32=0u;
var t616:u32=0u;
t611=R___ink_differential_0(t615,t616);}
var t617:R___ink_differential_0=t611;
var t618:u32=(t607).ink_f_value;
var t619:u32=ink_f32_mul(t618,(t617).ink_f_value);
var t620:u32=t619;
var t621:u32=(t607).ink_f_tangent;
var t622:u32=ink_f32_mul(t621,(t617).ink_f_value);
var t623:u32=(t607).ink_f_value;
var t624:u32=ink_f32_add(t622,ink_f32_mul(t623,(t617).ink_f_tangent));
var t625:R___ink_differential_0=R___ink_differential_0(t620,t624);
var t626:u32=(t565).ink_f_value;
var t627:u32=ink_f32_add(t626,(t625).ink_f_value);
var t628:u32=t627;
var t629:u32=(t565).ink_f_tangent;
var t630:u32=ink_f32_add(t629,(t625).ink_f_tangent);
t563=R___ink_differential_0(t628,t630);
}
var t631:R___ink_differential_0=t563;
var t632:R___ink_differential_0=t23;
var t633:u32=t24;
var t634:u32=t25;
var t635:u32=55u;
var t636:R___ink_differential_0=t632;
var t637:u32=t633;
var t638:u32=t635;
var t639:u32=(t638 + 10u);
var t640:u32=t637;
var t641:R___ink_differential_0;
if ((t640 == t639)) {
t641=t636;
} else {
var t642:u32=t639;
var t643:R___ink_differential_3;if(t642<a0[0u]){
var t644:R_Parameter=R_Parameter(a0[1u+(t642)*6u+0u],a0[1u+(t642)*6u+1u],a0[1u+(t642)*6u+2u],a0[1u+(t642)*6u+3u],a0[1u+(t642)*6u+4u],a0[1u+(t642)*6u+5u]);
var t645:u32=(t644).ink_f_value;
var t646:u32=0u;
var t647:R___ink_differential_0=R___ink_differential_0(t645,t646);
var t648:u32=(t644).ink_f_first;
var t649:u32=0u;
var t650:R___ink_differential_0=R___ink_differential_0(t648,t649);
var t651:u32=(t644).ink_f_second;
var t652:u32=0u;
var t653:R___ink_differential_0=R___ink_differential_0(t651,t652);
var t654:u32=(t644).ink_f_first_power;
var t655:u32=0u;
var t656:R___ink_differential_0=R___ink_differential_0(t654,t655);
var t657:u32=(t644).ink_f_second_power;
var t658:u32=0u;
var t659:R___ink_differential_0=R___ink_differential_0(t657,t658);
var t660:u32=(t644).ink_f_steps;
t643=R___ink_differential_3(t647,t650,t653,t656,t659,t660);}else{
var t661:u32=0u;
var t662:u32=0u;
var t663:R___ink_differential_0=R___ink_differential_0(t661,t662);
var t664:u32=0u;
var t665:u32=0u;
var t666:R___ink_differential_0=R___ink_differential_0(t664,t665);
var t667:u32=0u;
var t668:u32=0u;
var t669:R___ink_differential_0=R___ink_differential_0(t667,t668);
var t670:u32=1065353216u;
var t671:u32=0u;
var t672:R___ink_differential_0=R___ink_differential_0(t670,t671);
var t673:u32=1065353216u;
var t674:u32=0u;
var t675:R___ink_differential_0=R___ink_differential_0(t673,t674);
var t676:u32=0u;
t643=R___ink_differential_3(t663,t666,t669,t672,t675,t676);}
t641=(t643).ink_f_value;
}
var t677:R___ink_differential_0=t641;
var t678:R___ink_differential_0=t677;
for(var t679=0u;t679<10u;t679++){
var t680:R___ink_differential_0=t678;
var t681:R___ink_differential_0=t632;
var t682:u32=t633;
var t683:u32=t635;
var t684:u32=(t683 + t679);
var t685:u32=t682;
var t686:R___ink_differential_0;
if ((t685 == t684)) {
t686=t681;
} else {
var t687:u32=t684;
var t688:R___ink_differential_3;if(t687<a0[0u]){
var t689:R_Parameter=R_Parameter(a0[1u+(t687)*6u+0u],a0[1u+(t687)*6u+1u],a0[1u+(t687)*6u+2u],a0[1u+(t687)*6u+3u],a0[1u+(t687)*6u+4u],a0[1u+(t687)*6u+5u]);
var t690:u32=(t689).ink_f_value;
var t691:u32=0u;
var t692:R___ink_differential_0=R___ink_differential_0(t690,t691);
var t693:u32=(t689).ink_f_first;
var t694:u32=0u;
var t695:R___ink_differential_0=R___ink_differential_0(t693,t694);
var t696:u32=(t689).ink_f_second;
var t697:u32=0u;
var t698:R___ink_differential_0=R___ink_differential_0(t696,t697);
var t699:u32=(t689).ink_f_first_power;
var t700:u32=0u;
var t701:R___ink_differential_0=R___ink_differential_0(t699,t700);
var t702:u32=(t689).ink_f_second_power;
var t703:u32=0u;
var t704:R___ink_differential_0=R___ink_differential_0(t702,t703);
var t705:u32=(t689).ink_f_steps;
t688=R___ink_differential_3(t692,t695,t698,t701,t704,t705);}else{
var t706:u32=0u;
var t707:u32=0u;
var t708:R___ink_differential_0=R___ink_differential_0(t706,t707);
var t709:u32=0u;
var t710:u32=0u;
var t711:R___ink_differential_0=R___ink_differential_0(t709,t710);
var t712:u32=0u;
var t713:u32=0u;
var t714:R___ink_differential_0=R___ink_differential_0(t712,t713);
var t715:u32=1065353216u;
var t716:u32=0u;
var t717:R___ink_differential_0=R___ink_differential_0(t715,t716);
var t718:u32=1065353216u;
var t719:u32=0u;
var t720:R___ink_differential_0=R___ink_differential_0(t718,t719);
var t721:u32=0u;
t688=R___ink_differential_3(t708,t711,t714,t717,t720,t721);}
t686=(t688).ink_f_value;
}
var t722:R___ink_differential_0=t686;
var t723:u32=t634;
var t724:u32=(t723 * 10u);
var t725:u32=(t724 + t679);
var t726:R___ink_differential_0;if(t725<a1[0u]){
var t727:u32=a1[1u+(t725)*1u+0u];
var t728:u32=t727;
var t729:u32=0u;
t726=R___ink_differential_0(t728,t729);}else{
var t730:u32=0u;
var t731:u32=0u;
t726=R___ink_differential_0(t730,t731);}
var t732:R___ink_differential_0=t726;
var t733:u32=(t722).ink_f_value;
var t734:u32=ink_f32_mul(t733,(t732).ink_f_value);
var t735:u32=t734;
var t736:u32=(t722).ink_f_tangent;
var t737:u32=ink_f32_mul(t736,(t732).ink_f_value);
var t738:u32=(t722).ink_f_value;
var t739:u32=ink_f32_add(t737,ink_f32_mul(t738,(t732).ink_f_tangent));
var t740:R___ink_differential_0=R___ink_differential_0(t735,t739);
var t741:u32=(t680).ink_f_value;
var t742:u32=ink_f32_add(t741,(t740).ink_f_value);
var t743:u32=t742;
var t744:u32=(t680).ink_f_tangent;
var t745:u32=ink_f32_add(t744,(t740).ink_f_tangent);
t678=R___ink_differential_0(t743,t745);
}
var t746:R___ink_differential_0=t678;
var t747:u32=(t746).ink_f_value;
var t748:u32=0u;
var t749:u32=0u;
var t750:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t748,t749)).ink_f_value,t747)) {
var t751:R___ink_differential_0=t631;
var t752:R___ink_differential_0=t746;
var t753:u32=(t751).ink_f_value;
var t754:u32=ink_f32_mul(t753,(t752).ink_f_value);
var t755:u32=t754;
var t756:u32=(t751).ink_f_tangent;
var t757:u32=ink_f32_mul(t756,(t752).ink_f_value);
var t758:u32=(t751).ink_f_value;
var t759:u32=ink_f32_add(t757,ink_f32_mul(t758,(t752).ink_f_tangent));
t750=R___ink_differential_0(t755,t759);
} else {
var t760:u32=0u;
var t761:u32=0u;
t750=R___ink_differential_0(t760,t761);
}
t26[2u]=t750;
var t762:R___ink_differential_0=t23;
var t763:u32=t24;
var t764:u32=t25;
var t765:u32=66u;
var t766:R___ink_differential_0=t762;
var t767:u32=t763;
var t768:u32=t765;
var t769:u32=(t768 + 10u);
var t770:u32=t767;
var t771:R___ink_differential_0;
if ((t770 == t769)) {
t771=t766;
} else {
var t772:u32=t769;
var t773:R___ink_differential_3;if(t772<a0[0u]){
var t774:R_Parameter=R_Parameter(a0[1u+(t772)*6u+0u],a0[1u+(t772)*6u+1u],a0[1u+(t772)*6u+2u],a0[1u+(t772)*6u+3u],a0[1u+(t772)*6u+4u],a0[1u+(t772)*6u+5u]);
var t775:u32=(t774).ink_f_value;
var t776:u32=0u;
var t777:R___ink_differential_0=R___ink_differential_0(t775,t776);
var t778:u32=(t774).ink_f_first;
var t779:u32=0u;
var t780:R___ink_differential_0=R___ink_differential_0(t778,t779);
var t781:u32=(t774).ink_f_second;
var t782:u32=0u;
var t783:R___ink_differential_0=R___ink_differential_0(t781,t782);
var t784:u32=(t774).ink_f_first_power;
var t785:u32=0u;
var t786:R___ink_differential_0=R___ink_differential_0(t784,t785);
var t787:u32=(t774).ink_f_second_power;
var t788:u32=0u;
var t789:R___ink_differential_0=R___ink_differential_0(t787,t788);
var t790:u32=(t774).ink_f_steps;
t773=R___ink_differential_3(t777,t780,t783,t786,t789,t790);}else{
var t791:u32=0u;
var t792:u32=0u;
var t793:R___ink_differential_0=R___ink_differential_0(t791,t792);
var t794:u32=0u;
var t795:u32=0u;
var t796:R___ink_differential_0=R___ink_differential_0(t794,t795);
var t797:u32=0u;
var t798:u32=0u;
var t799:R___ink_differential_0=R___ink_differential_0(t797,t798);
var t800:u32=1065353216u;
var t801:u32=0u;
var t802:R___ink_differential_0=R___ink_differential_0(t800,t801);
var t803:u32=1065353216u;
var t804:u32=0u;
var t805:R___ink_differential_0=R___ink_differential_0(t803,t804);
var t806:u32=0u;
t773=R___ink_differential_3(t793,t796,t799,t802,t805,t806);}
t771=(t773).ink_f_value;
}
var t807:R___ink_differential_0=t771;
var t808:R___ink_differential_0=t807;
for(var t809=0u;t809<10u;t809++){
var t810:R___ink_differential_0=t808;
var t811:R___ink_differential_0=t762;
var t812:u32=t763;
var t813:u32=t765;
var t814:u32=(t813 + t809);
var t815:u32=t812;
var t816:R___ink_differential_0;
if ((t815 == t814)) {
t816=t811;
} else {
var t817:u32=t814;
var t818:R___ink_differential_3;if(t817<a0[0u]){
var t819:R_Parameter=R_Parameter(a0[1u+(t817)*6u+0u],a0[1u+(t817)*6u+1u],a0[1u+(t817)*6u+2u],a0[1u+(t817)*6u+3u],a0[1u+(t817)*6u+4u],a0[1u+(t817)*6u+5u]);
var t820:u32=(t819).ink_f_value;
var t821:u32=0u;
var t822:R___ink_differential_0=R___ink_differential_0(t820,t821);
var t823:u32=(t819).ink_f_first;
var t824:u32=0u;
var t825:R___ink_differential_0=R___ink_differential_0(t823,t824);
var t826:u32=(t819).ink_f_second;
var t827:u32=0u;
var t828:R___ink_differential_0=R___ink_differential_0(t826,t827);
var t829:u32=(t819).ink_f_first_power;
var t830:u32=0u;
var t831:R___ink_differential_0=R___ink_differential_0(t829,t830);
var t832:u32=(t819).ink_f_second_power;
var t833:u32=0u;
var t834:R___ink_differential_0=R___ink_differential_0(t832,t833);
var t835:u32=(t819).ink_f_steps;
t818=R___ink_differential_3(t822,t825,t828,t831,t834,t835);}else{
var t836:u32=0u;
var t837:u32=0u;
var t838:R___ink_differential_0=R___ink_differential_0(t836,t837);
var t839:u32=0u;
var t840:u32=0u;
var t841:R___ink_differential_0=R___ink_differential_0(t839,t840);
var t842:u32=0u;
var t843:u32=0u;
var t844:R___ink_differential_0=R___ink_differential_0(t842,t843);
var t845:u32=1065353216u;
var t846:u32=0u;
var t847:R___ink_differential_0=R___ink_differential_0(t845,t846);
var t848:u32=1065353216u;
var t849:u32=0u;
var t850:R___ink_differential_0=R___ink_differential_0(t848,t849);
var t851:u32=0u;
t818=R___ink_differential_3(t838,t841,t844,t847,t850,t851);}
t816=(t818).ink_f_value;
}
var t852:R___ink_differential_0=t816;
var t853:u32=t764;
var t854:u32=(t853 * 10u);
var t855:u32=(t854 + t809);
var t856:R___ink_differential_0;if(t855<a1[0u]){
var t857:u32=a1[1u+(t855)*1u+0u];
var t858:u32=t857;
var t859:u32=0u;
t856=R___ink_differential_0(t858,t859);}else{
var t860:u32=0u;
var t861:u32=0u;
t856=R___ink_differential_0(t860,t861);}
var t862:R___ink_differential_0=t856;
var t863:u32=(t852).ink_f_value;
var t864:u32=ink_f32_mul(t863,(t862).ink_f_value);
var t865:u32=t864;
var t866:u32=(t852).ink_f_tangent;
var t867:u32=ink_f32_mul(t866,(t862).ink_f_value);
var t868:u32=(t852).ink_f_value;
var t869:u32=ink_f32_add(t867,ink_f32_mul(t868,(t862).ink_f_tangent));
var t870:R___ink_differential_0=R___ink_differential_0(t865,t869);
var t871:u32=(t810).ink_f_value;
var t872:u32=ink_f32_add(t871,(t870).ink_f_value);
var t873:u32=t872;
var t874:u32=(t810).ink_f_tangent;
var t875:u32=ink_f32_add(t874,(t870).ink_f_tangent);
t808=R___ink_differential_0(t873,t875);
}
var t876:R___ink_differential_0=t808;
var t877:R___ink_differential_0=t23;
var t878:u32=t24;
var t879:u32=t25;
var t880:u32=77u;
var t881:R___ink_differential_0=t877;
var t882:u32=t878;
var t883:u32=t880;
var t884:u32=(t883 + 10u);
var t885:u32=t882;
var t886:R___ink_differential_0;
if ((t885 == t884)) {
t886=t881;
} else {
var t887:u32=t884;
var t888:R___ink_differential_3;if(t887<a0[0u]){
var t889:R_Parameter=R_Parameter(a0[1u+(t887)*6u+0u],a0[1u+(t887)*6u+1u],a0[1u+(t887)*6u+2u],a0[1u+(t887)*6u+3u],a0[1u+(t887)*6u+4u],a0[1u+(t887)*6u+5u]);
var t890:u32=(t889).ink_f_value;
var t891:u32=0u;
var t892:R___ink_differential_0=R___ink_differential_0(t890,t891);
var t893:u32=(t889).ink_f_first;
var t894:u32=0u;
var t895:R___ink_differential_0=R___ink_differential_0(t893,t894);
var t896:u32=(t889).ink_f_second;
var t897:u32=0u;
var t898:R___ink_differential_0=R___ink_differential_0(t896,t897);
var t899:u32=(t889).ink_f_first_power;
var t900:u32=0u;
var t901:R___ink_differential_0=R___ink_differential_0(t899,t900);
var t902:u32=(t889).ink_f_second_power;
var t903:u32=0u;
var t904:R___ink_differential_0=R___ink_differential_0(t902,t903);
var t905:u32=(t889).ink_f_steps;
t888=R___ink_differential_3(t892,t895,t898,t901,t904,t905);}else{
var t906:u32=0u;
var t907:u32=0u;
var t908:R___ink_differential_0=R___ink_differential_0(t906,t907);
var t909:u32=0u;
var t910:u32=0u;
var t911:R___ink_differential_0=R___ink_differential_0(t909,t910);
var t912:u32=0u;
var t913:u32=0u;
var t914:R___ink_differential_0=R___ink_differential_0(t912,t913);
var t915:u32=1065353216u;
var t916:u32=0u;
var t917:R___ink_differential_0=R___ink_differential_0(t915,t916);
var t918:u32=1065353216u;
var t919:u32=0u;
var t920:R___ink_differential_0=R___ink_differential_0(t918,t919);
var t921:u32=0u;
t888=R___ink_differential_3(t908,t911,t914,t917,t920,t921);}
t886=(t888).ink_f_value;
}
var t922:R___ink_differential_0=t886;
var t923:R___ink_differential_0=t922;
for(var t924=0u;t924<10u;t924++){
var t925:R___ink_differential_0=t923;
var t926:R___ink_differential_0=t877;
var t927:u32=t878;
var t928:u32=t880;
var t929:u32=(t928 + t924);
var t930:u32=t927;
var t931:R___ink_differential_0;
if ((t930 == t929)) {
t931=t926;
} else {
var t932:u32=t929;
var t933:R___ink_differential_3;if(t932<a0[0u]){
var t934:R_Parameter=R_Parameter(a0[1u+(t932)*6u+0u],a0[1u+(t932)*6u+1u],a0[1u+(t932)*6u+2u],a0[1u+(t932)*6u+3u],a0[1u+(t932)*6u+4u],a0[1u+(t932)*6u+5u]);
var t935:u32=(t934).ink_f_value;
var t936:u32=0u;
var t937:R___ink_differential_0=R___ink_differential_0(t935,t936);
var t938:u32=(t934).ink_f_first;
var t939:u32=0u;
var t940:R___ink_differential_0=R___ink_differential_0(t938,t939);
var t941:u32=(t934).ink_f_second;
var t942:u32=0u;
var t943:R___ink_differential_0=R___ink_differential_0(t941,t942);
var t944:u32=(t934).ink_f_first_power;
var t945:u32=0u;
var t946:R___ink_differential_0=R___ink_differential_0(t944,t945);
var t947:u32=(t934).ink_f_second_power;
var t948:u32=0u;
var t949:R___ink_differential_0=R___ink_differential_0(t947,t948);
var t950:u32=(t934).ink_f_steps;
t933=R___ink_differential_3(t937,t940,t943,t946,t949,t950);}else{
var t951:u32=0u;
var t952:u32=0u;
var t953:R___ink_differential_0=R___ink_differential_0(t951,t952);
var t954:u32=0u;
var t955:u32=0u;
var t956:R___ink_differential_0=R___ink_differential_0(t954,t955);
var t957:u32=0u;
var t958:u32=0u;
var t959:R___ink_differential_0=R___ink_differential_0(t957,t958);
var t960:u32=1065353216u;
var t961:u32=0u;
var t962:R___ink_differential_0=R___ink_differential_0(t960,t961);
var t963:u32=1065353216u;
var t964:u32=0u;
var t965:R___ink_differential_0=R___ink_differential_0(t963,t964);
var t966:u32=0u;
t933=R___ink_differential_3(t953,t956,t959,t962,t965,t966);}
t931=(t933).ink_f_value;
}
var t967:R___ink_differential_0=t931;
var t968:u32=t879;
var t969:u32=(t968 * 10u);
var t970:u32=(t969 + t924);
var t971:R___ink_differential_0;if(t970<a1[0u]){
var t972:u32=a1[1u+(t970)*1u+0u];
var t973:u32=t972;
var t974:u32=0u;
t971=R___ink_differential_0(t973,t974);}else{
var t975:u32=0u;
var t976:u32=0u;
t971=R___ink_differential_0(t975,t976);}
var t977:R___ink_differential_0=t971;
var t978:u32=(t967).ink_f_value;
var t979:u32=ink_f32_mul(t978,(t977).ink_f_value);
var t980:u32=t979;
var t981:u32=(t967).ink_f_tangent;
var t982:u32=ink_f32_mul(t981,(t977).ink_f_value);
var t983:u32=(t967).ink_f_value;
var t984:u32=ink_f32_add(t982,ink_f32_mul(t983,(t977).ink_f_tangent));
var t985:R___ink_differential_0=R___ink_differential_0(t980,t984);
var t986:u32=(t925).ink_f_value;
var t987:u32=ink_f32_add(t986,(t985).ink_f_value);
var t988:u32=t987;
var t989:u32=(t925).ink_f_tangent;
var t990:u32=ink_f32_add(t989,(t985).ink_f_tangent);
t923=R___ink_differential_0(t988,t990);
}
var t991:R___ink_differential_0=t923;
var t992:u32=(t991).ink_f_value;
var t993:u32=0u;
var t994:u32=0u;
var t995:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t993,t994)).ink_f_value,t992)) {
var t996:R___ink_differential_0=t876;
var t997:R___ink_differential_0=t991;
var t998:u32=(t996).ink_f_value;
var t999:u32=ink_f32_mul(t998,(t997).ink_f_value);
var t1000:u32=t999;
var t1001:u32=(t996).ink_f_tangent;
var t1002:u32=ink_f32_mul(t1001,(t997).ink_f_value);
var t1003:u32=(t996).ink_f_value;
var t1004:u32=ink_f32_add(t1002,ink_f32_mul(t1003,(t997).ink_f_tangent));
t995=R___ink_differential_0(t1000,t1004);
} else {
var t1005:u32=0u;
var t1006:u32=0u;
t995=R___ink_differential_0(t1005,t1006);
}
t26[3u]=t995;
var t1007:R___ink_differential_0=t23;
var t1008:u32=t24;
var t1009:u32=t25;
var t1010:u32=88u;
var t1011:R___ink_differential_0=t1007;
var t1012:u32=t1008;
var t1013:u32=t1010;
var t1014:u32=(t1013 + 10u);
var t1015:u32=t1012;
var t1016:R___ink_differential_0;
if ((t1015 == t1014)) {
t1016=t1011;
} else {
var t1017:u32=t1014;
var t1018:R___ink_differential_3;if(t1017<a0[0u]){
var t1019:R_Parameter=R_Parameter(a0[1u+(t1017)*6u+0u],a0[1u+(t1017)*6u+1u],a0[1u+(t1017)*6u+2u],a0[1u+(t1017)*6u+3u],a0[1u+(t1017)*6u+4u],a0[1u+(t1017)*6u+5u]);
var t1020:u32=(t1019).ink_f_value;
var t1021:u32=0u;
var t1022:R___ink_differential_0=R___ink_differential_0(t1020,t1021);
var t1023:u32=(t1019).ink_f_first;
var t1024:u32=0u;
var t1025:R___ink_differential_0=R___ink_differential_0(t1023,t1024);
var t1026:u32=(t1019).ink_f_second;
var t1027:u32=0u;
var t1028:R___ink_differential_0=R___ink_differential_0(t1026,t1027);
var t1029:u32=(t1019).ink_f_first_power;
var t1030:u32=0u;
var t1031:R___ink_differential_0=R___ink_differential_0(t1029,t1030);
var t1032:u32=(t1019).ink_f_second_power;
var t1033:u32=0u;
var t1034:R___ink_differential_0=R___ink_differential_0(t1032,t1033);
var t1035:u32=(t1019).ink_f_steps;
t1018=R___ink_differential_3(t1022,t1025,t1028,t1031,t1034,t1035);}else{
var t1036:u32=0u;
var t1037:u32=0u;
var t1038:R___ink_differential_0=R___ink_differential_0(t1036,t1037);
var t1039:u32=0u;
var t1040:u32=0u;
var t1041:R___ink_differential_0=R___ink_differential_0(t1039,t1040);
var t1042:u32=0u;
var t1043:u32=0u;
var t1044:R___ink_differential_0=R___ink_differential_0(t1042,t1043);
var t1045:u32=1065353216u;
var t1046:u32=0u;
var t1047:R___ink_differential_0=R___ink_differential_0(t1045,t1046);
var t1048:u32=1065353216u;
var t1049:u32=0u;
var t1050:R___ink_differential_0=R___ink_differential_0(t1048,t1049);
var t1051:u32=0u;
t1018=R___ink_differential_3(t1038,t1041,t1044,t1047,t1050,t1051);}
t1016=(t1018).ink_f_value;
}
var t1052:R___ink_differential_0=t1016;
var t1053:R___ink_differential_0=t1052;
for(var t1054=0u;t1054<10u;t1054++){
var t1055:R___ink_differential_0=t1053;
var t1056:R___ink_differential_0=t1007;
var t1057:u32=t1008;
var t1058:u32=t1010;
var t1059:u32=(t1058 + t1054);
var t1060:u32=t1057;
var t1061:R___ink_differential_0;
if ((t1060 == t1059)) {
t1061=t1056;
} else {
var t1062:u32=t1059;
var t1063:R___ink_differential_3;if(t1062<a0[0u]){
var t1064:R_Parameter=R_Parameter(a0[1u+(t1062)*6u+0u],a0[1u+(t1062)*6u+1u],a0[1u+(t1062)*6u+2u],a0[1u+(t1062)*6u+3u],a0[1u+(t1062)*6u+4u],a0[1u+(t1062)*6u+5u]);
var t1065:u32=(t1064).ink_f_value;
var t1066:u32=0u;
var t1067:R___ink_differential_0=R___ink_differential_0(t1065,t1066);
var t1068:u32=(t1064).ink_f_first;
var t1069:u32=0u;
var t1070:R___ink_differential_0=R___ink_differential_0(t1068,t1069);
var t1071:u32=(t1064).ink_f_second;
var t1072:u32=0u;
var t1073:R___ink_differential_0=R___ink_differential_0(t1071,t1072);
var t1074:u32=(t1064).ink_f_first_power;
var t1075:u32=0u;
var t1076:R___ink_differential_0=R___ink_differential_0(t1074,t1075);
var t1077:u32=(t1064).ink_f_second_power;
var t1078:u32=0u;
var t1079:R___ink_differential_0=R___ink_differential_0(t1077,t1078);
var t1080:u32=(t1064).ink_f_steps;
t1063=R___ink_differential_3(t1067,t1070,t1073,t1076,t1079,t1080);}else{
var t1081:u32=0u;
var t1082:u32=0u;
var t1083:R___ink_differential_0=R___ink_differential_0(t1081,t1082);
var t1084:u32=0u;
var t1085:u32=0u;
var t1086:R___ink_differential_0=R___ink_differential_0(t1084,t1085);
var t1087:u32=0u;
var t1088:u32=0u;
var t1089:R___ink_differential_0=R___ink_differential_0(t1087,t1088);
var t1090:u32=1065353216u;
var t1091:u32=0u;
var t1092:R___ink_differential_0=R___ink_differential_0(t1090,t1091);
var t1093:u32=1065353216u;
var t1094:u32=0u;
var t1095:R___ink_differential_0=R___ink_differential_0(t1093,t1094);
var t1096:u32=0u;
t1063=R___ink_differential_3(t1083,t1086,t1089,t1092,t1095,t1096);}
t1061=(t1063).ink_f_value;
}
var t1097:R___ink_differential_0=t1061;
var t1098:u32=t1009;
var t1099:u32=(t1098 * 10u);
var t1100:u32=(t1099 + t1054);
var t1101:R___ink_differential_0;if(t1100<a1[0u]){
var t1102:u32=a1[1u+(t1100)*1u+0u];
var t1103:u32=t1102;
var t1104:u32=0u;
t1101=R___ink_differential_0(t1103,t1104);}else{
var t1105:u32=0u;
var t1106:u32=0u;
t1101=R___ink_differential_0(t1105,t1106);}
var t1107:R___ink_differential_0=t1101;
var t1108:u32=(t1097).ink_f_value;
var t1109:u32=ink_f32_mul(t1108,(t1107).ink_f_value);
var t1110:u32=t1109;
var t1111:u32=(t1097).ink_f_tangent;
var t1112:u32=ink_f32_mul(t1111,(t1107).ink_f_value);
var t1113:u32=(t1097).ink_f_value;
var t1114:u32=ink_f32_add(t1112,ink_f32_mul(t1113,(t1107).ink_f_tangent));
var t1115:R___ink_differential_0=R___ink_differential_0(t1110,t1114);
var t1116:u32=(t1055).ink_f_value;
var t1117:u32=ink_f32_add(t1116,(t1115).ink_f_value);
var t1118:u32=t1117;
var t1119:u32=(t1055).ink_f_tangent;
var t1120:u32=ink_f32_add(t1119,(t1115).ink_f_tangent);
t1053=R___ink_differential_0(t1118,t1120);
}
var t1121:R___ink_differential_0=t1053;
var t1122:R___ink_differential_0=t23;
var t1123:u32=t24;
var t1124:u32=t25;
var t1125:u32=99u;
var t1126:R___ink_differential_0=t1122;
var t1127:u32=t1123;
var t1128:u32=t1125;
var t1129:u32=(t1128 + 10u);
var t1130:u32=t1127;
var t1131:R___ink_differential_0;
if ((t1130 == t1129)) {
t1131=t1126;
} else {
var t1132:u32=t1129;
var t1133:R___ink_differential_3;if(t1132<a0[0u]){
var t1134:R_Parameter=R_Parameter(a0[1u+(t1132)*6u+0u],a0[1u+(t1132)*6u+1u],a0[1u+(t1132)*6u+2u],a0[1u+(t1132)*6u+3u],a0[1u+(t1132)*6u+4u],a0[1u+(t1132)*6u+5u]);
var t1135:u32=(t1134).ink_f_value;
var t1136:u32=0u;
var t1137:R___ink_differential_0=R___ink_differential_0(t1135,t1136);
var t1138:u32=(t1134).ink_f_first;
var t1139:u32=0u;
var t1140:R___ink_differential_0=R___ink_differential_0(t1138,t1139);
var t1141:u32=(t1134).ink_f_second;
var t1142:u32=0u;
var t1143:R___ink_differential_0=R___ink_differential_0(t1141,t1142);
var t1144:u32=(t1134).ink_f_first_power;
var t1145:u32=0u;
var t1146:R___ink_differential_0=R___ink_differential_0(t1144,t1145);
var t1147:u32=(t1134).ink_f_second_power;
var t1148:u32=0u;
var t1149:R___ink_differential_0=R___ink_differential_0(t1147,t1148);
var t1150:u32=(t1134).ink_f_steps;
t1133=R___ink_differential_3(t1137,t1140,t1143,t1146,t1149,t1150);}else{
var t1151:u32=0u;
var t1152:u32=0u;
var t1153:R___ink_differential_0=R___ink_differential_0(t1151,t1152);
var t1154:u32=0u;
var t1155:u32=0u;
var t1156:R___ink_differential_0=R___ink_differential_0(t1154,t1155);
var t1157:u32=0u;
var t1158:u32=0u;
var t1159:R___ink_differential_0=R___ink_differential_0(t1157,t1158);
var t1160:u32=1065353216u;
var t1161:u32=0u;
var t1162:R___ink_differential_0=R___ink_differential_0(t1160,t1161);
var t1163:u32=1065353216u;
var t1164:u32=0u;
var t1165:R___ink_differential_0=R___ink_differential_0(t1163,t1164);
var t1166:u32=0u;
t1133=R___ink_differential_3(t1153,t1156,t1159,t1162,t1165,t1166);}
t1131=(t1133).ink_f_value;
}
var t1167:R___ink_differential_0=t1131;
var t1168:R___ink_differential_0=t1167;
for(var t1169=0u;t1169<10u;t1169++){
var t1170:R___ink_differential_0=t1168;
var t1171:R___ink_differential_0=t1122;
var t1172:u32=t1123;
var t1173:u32=t1125;
var t1174:u32=(t1173 + t1169);
var t1175:u32=t1172;
var t1176:R___ink_differential_0;
if ((t1175 == t1174)) {
t1176=t1171;
} else {
var t1177:u32=t1174;
var t1178:R___ink_differential_3;if(t1177<a0[0u]){
var t1179:R_Parameter=R_Parameter(a0[1u+(t1177)*6u+0u],a0[1u+(t1177)*6u+1u],a0[1u+(t1177)*6u+2u],a0[1u+(t1177)*6u+3u],a0[1u+(t1177)*6u+4u],a0[1u+(t1177)*6u+5u]);
var t1180:u32=(t1179).ink_f_value;
var t1181:u32=0u;
var t1182:R___ink_differential_0=R___ink_differential_0(t1180,t1181);
var t1183:u32=(t1179).ink_f_first;
var t1184:u32=0u;
var t1185:R___ink_differential_0=R___ink_differential_0(t1183,t1184);
var t1186:u32=(t1179).ink_f_second;
var t1187:u32=0u;
var t1188:R___ink_differential_0=R___ink_differential_0(t1186,t1187);
var t1189:u32=(t1179).ink_f_first_power;
var t1190:u32=0u;
var t1191:R___ink_differential_0=R___ink_differential_0(t1189,t1190);
var t1192:u32=(t1179).ink_f_second_power;
var t1193:u32=0u;
var t1194:R___ink_differential_0=R___ink_differential_0(t1192,t1193);
var t1195:u32=(t1179).ink_f_steps;
t1178=R___ink_differential_3(t1182,t1185,t1188,t1191,t1194,t1195);}else{
var t1196:u32=0u;
var t1197:u32=0u;
var t1198:R___ink_differential_0=R___ink_differential_0(t1196,t1197);
var t1199:u32=0u;
var t1200:u32=0u;
var t1201:R___ink_differential_0=R___ink_differential_0(t1199,t1200);
var t1202:u32=0u;
var t1203:u32=0u;
var t1204:R___ink_differential_0=R___ink_differential_0(t1202,t1203);
var t1205:u32=1065353216u;
var t1206:u32=0u;
var t1207:R___ink_differential_0=R___ink_differential_0(t1205,t1206);
var t1208:u32=1065353216u;
var t1209:u32=0u;
var t1210:R___ink_differential_0=R___ink_differential_0(t1208,t1209);
var t1211:u32=0u;
t1178=R___ink_differential_3(t1198,t1201,t1204,t1207,t1210,t1211);}
t1176=(t1178).ink_f_value;
}
var t1212:R___ink_differential_0=t1176;
var t1213:u32=t1124;
var t1214:u32=(t1213 * 10u);
var t1215:u32=(t1214 + t1169);
var t1216:R___ink_differential_0;if(t1215<a1[0u]){
var t1217:u32=a1[1u+(t1215)*1u+0u];
var t1218:u32=t1217;
var t1219:u32=0u;
t1216=R___ink_differential_0(t1218,t1219);}else{
var t1220:u32=0u;
var t1221:u32=0u;
t1216=R___ink_differential_0(t1220,t1221);}
var t1222:R___ink_differential_0=t1216;
var t1223:u32=(t1212).ink_f_value;
var t1224:u32=ink_f32_mul(t1223,(t1222).ink_f_value);
var t1225:u32=t1224;
var t1226:u32=(t1212).ink_f_tangent;
var t1227:u32=ink_f32_mul(t1226,(t1222).ink_f_value);
var t1228:u32=(t1212).ink_f_value;
var t1229:u32=ink_f32_add(t1227,ink_f32_mul(t1228,(t1222).ink_f_tangent));
var t1230:R___ink_differential_0=R___ink_differential_0(t1225,t1229);
var t1231:u32=(t1170).ink_f_value;
var t1232:u32=ink_f32_add(t1231,(t1230).ink_f_value);
var t1233:u32=t1232;
var t1234:u32=(t1170).ink_f_tangent;
var t1235:u32=ink_f32_add(t1234,(t1230).ink_f_tangent);
t1168=R___ink_differential_0(t1233,t1235);
}
var t1236:R___ink_differential_0=t1168;
var t1237:u32=(t1236).ink_f_value;
var t1238:u32=0u;
var t1239:u32=0u;
var t1240:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t1238,t1239)).ink_f_value,t1237)) {
var t1241:R___ink_differential_0=t1121;
var t1242:R___ink_differential_0=t1236;
var t1243:u32=(t1241).ink_f_value;
var t1244:u32=ink_f32_mul(t1243,(t1242).ink_f_value);
var t1245:u32=t1244;
var t1246:u32=(t1241).ink_f_tangent;
var t1247:u32=ink_f32_mul(t1246,(t1242).ink_f_value);
var t1248:u32=(t1241).ink_f_value;
var t1249:u32=ink_f32_add(t1247,ink_f32_mul(t1248,(t1242).ink_f_tangent));
t1240=R___ink_differential_0(t1245,t1249);
} else {
var t1250:u32=0u;
var t1251:u32=0u;
t1240=R___ink_differential_0(t1250,t1251);
}
t26[4u]=t1240;
var t1252:R___ink_differential_0=t23;
var t1253:u32=t24;
var t1254:u32=t25;
var t1255:u32=110u;
var t1256:R___ink_differential_0=t1252;
var t1257:u32=t1253;
var t1258:u32=t1255;
var t1259:u32=(t1258 + 10u);
var t1260:u32=t1257;
var t1261:R___ink_differential_0;
if ((t1260 == t1259)) {
t1261=t1256;
} else {
var t1262:u32=t1259;
var t1263:R___ink_differential_3;if(t1262<a0[0u]){
var t1264:R_Parameter=R_Parameter(a0[1u+(t1262)*6u+0u],a0[1u+(t1262)*6u+1u],a0[1u+(t1262)*6u+2u],a0[1u+(t1262)*6u+3u],a0[1u+(t1262)*6u+4u],a0[1u+(t1262)*6u+5u]);
var t1265:u32=(t1264).ink_f_value;
var t1266:u32=0u;
var t1267:R___ink_differential_0=R___ink_differential_0(t1265,t1266);
var t1268:u32=(t1264).ink_f_first;
var t1269:u32=0u;
var t1270:R___ink_differential_0=R___ink_differential_0(t1268,t1269);
var t1271:u32=(t1264).ink_f_second;
var t1272:u32=0u;
var t1273:R___ink_differential_0=R___ink_differential_0(t1271,t1272);
var t1274:u32=(t1264).ink_f_first_power;
var t1275:u32=0u;
var t1276:R___ink_differential_0=R___ink_differential_0(t1274,t1275);
var t1277:u32=(t1264).ink_f_second_power;
var t1278:u32=0u;
var t1279:R___ink_differential_0=R___ink_differential_0(t1277,t1278);
var t1280:u32=(t1264).ink_f_steps;
t1263=R___ink_differential_3(t1267,t1270,t1273,t1276,t1279,t1280);}else{
var t1281:u32=0u;
var t1282:u32=0u;
var t1283:R___ink_differential_0=R___ink_differential_0(t1281,t1282);
var t1284:u32=0u;
var t1285:u32=0u;
var t1286:R___ink_differential_0=R___ink_differential_0(t1284,t1285);
var t1287:u32=0u;
var t1288:u32=0u;
var t1289:R___ink_differential_0=R___ink_differential_0(t1287,t1288);
var t1290:u32=1065353216u;
var t1291:u32=0u;
var t1292:R___ink_differential_0=R___ink_differential_0(t1290,t1291);
var t1293:u32=1065353216u;
var t1294:u32=0u;
var t1295:R___ink_differential_0=R___ink_differential_0(t1293,t1294);
var t1296:u32=0u;
t1263=R___ink_differential_3(t1283,t1286,t1289,t1292,t1295,t1296);}
t1261=(t1263).ink_f_value;
}
var t1297:R___ink_differential_0=t1261;
var t1298:R___ink_differential_0=t1297;
for(var t1299=0u;t1299<10u;t1299++){
var t1300:R___ink_differential_0=t1298;
var t1301:R___ink_differential_0=t1252;
var t1302:u32=t1253;
var t1303:u32=t1255;
var t1304:u32=(t1303 + t1299);
var t1305:u32=t1302;
var t1306:R___ink_differential_0;
if ((t1305 == t1304)) {
t1306=t1301;
} else {
var t1307:u32=t1304;
var t1308:R___ink_differential_3;if(t1307<a0[0u]){
var t1309:R_Parameter=R_Parameter(a0[1u+(t1307)*6u+0u],a0[1u+(t1307)*6u+1u],a0[1u+(t1307)*6u+2u],a0[1u+(t1307)*6u+3u],a0[1u+(t1307)*6u+4u],a0[1u+(t1307)*6u+5u]);
var t1310:u32=(t1309).ink_f_value;
var t1311:u32=0u;
var t1312:R___ink_differential_0=R___ink_differential_0(t1310,t1311);
var t1313:u32=(t1309).ink_f_first;
var t1314:u32=0u;
var t1315:R___ink_differential_0=R___ink_differential_0(t1313,t1314);
var t1316:u32=(t1309).ink_f_second;
var t1317:u32=0u;
var t1318:R___ink_differential_0=R___ink_differential_0(t1316,t1317);
var t1319:u32=(t1309).ink_f_first_power;
var t1320:u32=0u;
var t1321:R___ink_differential_0=R___ink_differential_0(t1319,t1320);
var t1322:u32=(t1309).ink_f_second_power;
var t1323:u32=0u;
var t1324:R___ink_differential_0=R___ink_differential_0(t1322,t1323);
var t1325:u32=(t1309).ink_f_steps;
t1308=R___ink_differential_3(t1312,t1315,t1318,t1321,t1324,t1325);}else{
var t1326:u32=0u;
var t1327:u32=0u;
var t1328:R___ink_differential_0=R___ink_differential_0(t1326,t1327);
var t1329:u32=0u;
var t1330:u32=0u;
var t1331:R___ink_differential_0=R___ink_differential_0(t1329,t1330);
var t1332:u32=0u;
var t1333:u32=0u;
var t1334:R___ink_differential_0=R___ink_differential_0(t1332,t1333);
var t1335:u32=1065353216u;
var t1336:u32=0u;
var t1337:R___ink_differential_0=R___ink_differential_0(t1335,t1336);
var t1338:u32=1065353216u;
var t1339:u32=0u;
var t1340:R___ink_differential_0=R___ink_differential_0(t1338,t1339);
var t1341:u32=0u;
t1308=R___ink_differential_3(t1328,t1331,t1334,t1337,t1340,t1341);}
t1306=(t1308).ink_f_value;
}
var t1342:R___ink_differential_0=t1306;
var t1343:u32=t1254;
var t1344:u32=(t1343 * 10u);
var t1345:u32=(t1344 + t1299);
var t1346:R___ink_differential_0;if(t1345<a1[0u]){
var t1347:u32=a1[1u+(t1345)*1u+0u];
var t1348:u32=t1347;
var t1349:u32=0u;
t1346=R___ink_differential_0(t1348,t1349);}else{
var t1350:u32=0u;
var t1351:u32=0u;
t1346=R___ink_differential_0(t1350,t1351);}
var t1352:R___ink_differential_0=t1346;
var t1353:u32=(t1342).ink_f_value;
var t1354:u32=ink_f32_mul(t1353,(t1352).ink_f_value);
var t1355:u32=t1354;
var t1356:u32=(t1342).ink_f_tangent;
var t1357:u32=ink_f32_mul(t1356,(t1352).ink_f_value);
var t1358:u32=(t1342).ink_f_value;
var t1359:u32=ink_f32_add(t1357,ink_f32_mul(t1358,(t1352).ink_f_tangent));
var t1360:R___ink_differential_0=R___ink_differential_0(t1355,t1359);
var t1361:u32=(t1300).ink_f_value;
var t1362:u32=ink_f32_add(t1361,(t1360).ink_f_value);
var t1363:u32=t1362;
var t1364:u32=(t1300).ink_f_tangent;
var t1365:u32=ink_f32_add(t1364,(t1360).ink_f_tangent);
t1298=R___ink_differential_0(t1363,t1365);
}
var t1366:R___ink_differential_0=t1298;
var t1367:R___ink_differential_0=t23;
var t1368:u32=t24;
var t1369:u32=t25;
var t1370:u32=121u;
var t1371:R___ink_differential_0=t1367;
var t1372:u32=t1368;
var t1373:u32=t1370;
var t1374:u32=(t1373 + 10u);
var t1375:u32=t1372;
var t1376:R___ink_differential_0;
if ((t1375 == t1374)) {
t1376=t1371;
} else {
var t1377:u32=t1374;
var t1378:R___ink_differential_3;if(t1377<a0[0u]){
var t1379:R_Parameter=R_Parameter(a0[1u+(t1377)*6u+0u],a0[1u+(t1377)*6u+1u],a0[1u+(t1377)*6u+2u],a0[1u+(t1377)*6u+3u],a0[1u+(t1377)*6u+4u],a0[1u+(t1377)*6u+5u]);
var t1380:u32=(t1379).ink_f_value;
var t1381:u32=0u;
var t1382:R___ink_differential_0=R___ink_differential_0(t1380,t1381);
var t1383:u32=(t1379).ink_f_first;
var t1384:u32=0u;
var t1385:R___ink_differential_0=R___ink_differential_0(t1383,t1384);
var t1386:u32=(t1379).ink_f_second;
var t1387:u32=0u;
var t1388:R___ink_differential_0=R___ink_differential_0(t1386,t1387);
var t1389:u32=(t1379).ink_f_first_power;
var t1390:u32=0u;
var t1391:R___ink_differential_0=R___ink_differential_0(t1389,t1390);
var t1392:u32=(t1379).ink_f_second_power;
var t1393:u32=0u;
var t1394:R___ink_differential_0=R___ink_differential_0(t1392,t1393);
var t1395:u32=(t1379).ink_f_steps;
t1378=R___ink_differential_3(t1382,t1385,t1388,t1391,t1394,t1395);}else{
var t1396:u32=0u;
var t1397:u32=0u;
var t1398:R___ink_differential_0=R___ink_differential_0(t1396,t1397);
var t1399:u32=0u;
var t1400:u32=0u;
var t1401:R___ink_differential_0=R___ink_differential_0(t1399,t1400);
var t1402:u32=0u;
var t1403:u32=0u;
var t1404:R___ink_differential_0=R___ink_differential_0(t1402,t1403);
var t1405:u32=1065353216u;
var t1406:u32=0u;
var t1407:R___ink_differential_0=R___ink_differential_0(t1405,t1406);
var t1408:u32=1065353216u;
var t1409:u32=0u;
var t1410:R___ink_differential_0=R___ink_differential_0(t1408,t1409);
var t1411:u32=0u;
t1378=R___ink_differential_3(t1398,t1401,t1404,t1407,t1410,t1411);}
t1376=(t1378).ink_f_value;
}
var t1412:R___ink_differential_0=t1376;
var t1413:R___ink_differential_0=t1412;
for(var t1414=0u;t1414<10u;t1414++){
var t1415:R___ink_differential_0=t1413;
var t1416:R___ink_differential_0=t1367;
var t1417:u32=t1368;
var t1418:u32=t1370;
var t1419:u32=(t1418 + t1414);
var t1420:u32=t1417;
var t1421:R___ink_differential_0;
if ((t1420 == t1419)) {
t1421=t1416;
} else {
var t1422:u32=t1419;
var t1423:R___ink_differential_3;if(t1422<a0[0u]){
var t1424:R_Parameter=R_Parameter(a0[1u+(t1422)*6u+0u],a0[1u+(t1422)*6u+1u],a0[1u+(t1422)*6u+2u],a0[1u+(t1422)*6u+3u],a0[1u+(t1422)*6u+4u],a0[1u+(t1422)*6u+5u]);
var t1425:u32=(t1424).ink_f_value;
var t1426:u32=0u;
var t1427:R___ink_differential_0=R___ink_differential_0(t1425,t1426);
var t1428:u32=(t1424).ink_f_first;
var t1429:u32=0u;
var t1430:R___ink_differential_0=R___ink_differential_0(t1428,t1429);
var t1431:u32=(t1424).ink_f_second;
var t1432:u32=0u;
var t1433:R___ink_differential_0=R___ink_differential_0(t1431,t1432);
var t1434:u32=(t1424).ink_f_first_power;
var t1435:u32=0u;
var t1436:R___ink_differential_0=R___ink_differential_0(t1434,t1435);
var t1437:u32=(t1424).ink_f_second_power;
var t1438:u32=0u;
var t1439:R___ink_differential_0=R___ink_differential_0(t1437,t1438);
var t1440:u32=(t1424).ink_f_steps;
t1423=R___ink_differential_3(t1427,t1430,t1433,t1436,t1439,t1440);}else{
var t1441:u32=0u;
var t1442:u32=0u;
var t1443:R___ink_differential_0=R___ink_differential_0(t1441,t1442);
var t1444:u32=0u;
var t1445:u32=0u;
var t1446:R___ink_differential_0=R___ink_differential_0(t1444,t1445);
var t1447:u32=0u;
var t1448:u32=0u;
var t1449:R___ink_differential_0=R___ink_differential_0(t1447,t1448);
var t1450:u32=1065353216u;
var t1451:u32=0u;
var t1452:R___ink_differential_0=R___ink_differential_0(t1450,t1451);
var t1453:u32=1065353216u;
var t1454:u32=0u;
var t1455:R___ink_differential_0=R___ink_differential_0(t1453,t1454);
var t1456:u32=0u;
t1423=R___ink_differential_3(t1443,t1446,t1449,t1452,t1455,t1456);}
t1421=(t1423).ink_f_value;
}
var t1457:R___ink_differential_0=t1421;
var t1458:u32=t1369;
var t1459:u32=(t1458 * 10u);
var t1460:u32=(t1459 + t1414);
var t1461:R___ink_differential_0;if(t1460<a1[0u]){
var t1462:u32=a1[1u+(t1460)*1u+0u];
var t1463:u32=t1462;
var t1464:u32=0u;
t1461=R___ink_differential_0(t1463,t1464);}else{
var t1465:u32=0u;
var t1466:u32=0u;
t1461=R___ink_differential_0(t1465,t1466);}
var t1467:R___ink_differential_0=t1461;
var t1468:u32=(t1457).ink_f_value;
var t1469:u32=ink_f32_mul(t1468,(t1467).ink_f_value);
var t1470:u32=t1469;
var t1471:u32=(t1457).ink_f_tangent;
var t1472:u32=ink_f32_mul(t1471,(t1467).ink_f_value);
var t1473:u32=(t1457).ink_f_value;
var t1474:u32=ink_f32_add(t1472,ink_f32_mul(t1473,(t1467).ink_f_tangent));
var t1475:R___ink_differential_0=R___ink_differential_0(t1470,t1474);
var t1476:u32=(t1415).ink_f_value;
var t1477:u32=ink_f32_add(t1476,(t1475).ink_f_value);
var t1478:u32=t1477;
var t1479:u32=(t1415).ink_f_tangent;
var t1480:u32=ink_f32_add(t1479,(t1475).ink_f_tangent);
t1413=R___ink_differential_0(t1478,t1480);
}
var t1481:R___ink_differential_0=t1413;
var t1482:u32=(t1481).ink_f_value;
var t1483:u32=0u;
var t1484:u32=0u;
var t1485:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t1483,t1484)).ink_f_value,t1482)) {
var t1486:R___ink_differential_0=t1366;
var t1487:R___ink_differential_0=t1481;
var t1488:u32=(t1486).ink_f_value;
var t1489:u32=ink_f32_mul(t1488,(t1487).ink_f_value);
var t1490:u32=t1489;
var t1491:u32=(t1486).ink_f_tangent;
var t1492:u32=ink_f32_mul(t1491,(t1487).ink_f_value);
var t1493:u32=(t1486).ink_f_value;
var t1494:u32=ink_f32_add(t1492,ink_f32_mul(t1493,(t1487).ink_f_tangent));
t1485=R___ink_differential_0(t1490,t1494);
} else {
var t1495:u32=0u;
var t1496:u32=0u;
t1485=R___ink_differential_0(t1495,t1496);
}
t26[5u]=t1485;
var t1497:R___ink_differential_0=t20;
var t1498:u32=t21;
var t1499:array<R___ink_differential_0,6>;
var t1500:R___ink_differential_0=t1497;
var t1501:u32=t1498;
var t1502:u32=132u;
var t1503:R___ink_differential_0=t1500;
var t1504:u32=t1501;
var t1505:u32=t1502;
var t1506:u32=(t1505 + 6u);
var t1507:u32=t1504;
var t1508:R___ink_differential_0;
if ((t1507 == t1506)) {
t1508=t1503;
} else {
var t1509:u32=t1506;
var t1510:R___ink_differential_3;if(t1509<a0[0u]){
var t1511:R_Parameter=R_Parameter(a0[1u+(t1509)*6u+0u],a0[1u+(t1509)*6u+1u],a0[1u+(t1509)*6u+2u],a0[1u+(t1509)*6u+3u],a0[1u+(t1509)*6u+4u],a0[1u+(t1509)*6u+5u]);
var t1512:u32=(t1511).ink_f_value;
var t1513:u32=0u;
var t1514:R___ink_differential_0=R___ink_differential_0(t1512,t1513);
var t1515:u32=(t1511).ink_f_first;
var t1516:u32=0u;
var t1517:R___ink_differential_0=R___ink_differential_0(t1515,t1516);
var t1518:u32=(t1511).ink_f_second;
var t1519:u32=0u;
var t1520:R___ink_differential_0=R___ink_differential_0(t1518,t1519);
var t1521:u32=(t1511).ink_f_first_power;
var t1522:u32=0u;
var t1523:R___ink_differential_0=R___ink_differential_0(t1521,t1522);
var t1524:u32=(t1511).ink_f_second_power;
var t1525:u32=0u;
var t1526:R___ink_differential_0=R___ink_differential_0(t1524,t1525);
var t1527:u32=(t1511).ink_f_steps;
t1510=R___ink_differential_3(t1514,t1517,t1520,t1523,t1526,t1527);}else{
var t1528:u32=0u;
var t1529:u32=0u;
var t1530:R___ink_differential_0=R___ink_differential_0(t1528,t1529);
var t1531:u32=0u;
var t1532:u32=0u;
var t1533:R___ink_differential_0=R___ink_differential_0(t1531,t1532);
var t1534:u32=0u;
var t1535:u32=0u;
var t1536:R___ink_differential_0=R___ink_differential_0(t1534,t1535);
var t1537:u32=1065353216u;
var t1538:u32=0u;
var t1539:R___ink_differential_0=R___ink_differential_0(t1537,t1538);
var t1540:u32=1065353216u;
var t1541:u32=0u;
var t1542:R___ink_differential_0=R___ink_differential_0(t1540,t1541);
var t1543:u32=0u;
t1510=R___ink_differential_3(t1530,t1533,t1536,t1539,t1542,t1543);}
t1508=(t1510).ink_f_value;
}
var t1544:R___ink_differential_0=t1508;
var t1545:R___ink_differential_0=t1544;
for(var t1546=0u;t1546<6u;t1546++){
var t1547:R___ink_differential_0=t1545;
var t1548:R___ink_differential_0=t1500;
var t1549:u32=t1501;
var t1550:u32=t1502;
var t1551:u32=(t1550 + t1546);
var t1552:u32=t1549;
var t1553:R___ink_differential_0;
if ((t1552 == t1551)) {
t1553=t1548;
} else {
var t1554:u32=t1551;
var t1555:R___ink_differential_3;if(t1554<a0[0u]){
var t1556:R_Parameter=R_Parameter(a0[1u+(t1554)*6u+0u],a0[1u+(t1554)*6u+1u],a0[1u+(t1554)*6u+2u],a0[1u+(t1554)*6u+3u],a0[1u+(t1554)*6u+4u],a0[1u+(t1554)*6u+5u]);
var t1557:u32=(t1556).ink_f_value;
var t1558:u32=0u;
var t1559:R___ink_differential_0=R___ink_differential_0(t1557,t1558);
var t1560:u32=(t1556).ink_f_first;
var t1561:u32=0u;
var t1562:R___ink_differential_0=R___ink_differential_0(t1560,t1561);
var t1563:u32=(t1556).ink_f_second;
var t1564:u32=0u;
var t1565:R___ink_differential_0=R___ink_differential_0(t1563,t1564);
var t1566:u32=(t1556).ink_f_first_power;
var t1567:u32=0u;
var t1568:R___ink_differential_0=R___ink_differential_0(t1566,t1567);
var t1569:u32=(t1556).ink_f_second_power;
var t1570:u32=0u;
var t1571:R___ink_differential_0=R___ink_differential_0(t1569,t1570);
var t1572:u32=(t1556).ink_f_steps;
t1555=R___ink_differential_3(t1559,t1562,t1565,t1568,t1571,t1572);}else{
var t1573:u32=0u;
var t1574:u32=0u;
var t1575:R___ink_differential_0=R___ink_differential_0(t1573,t1574);
var t1576:u32=0u;
var t1577:u32=0u;
var t1578:R___ink_differential_0=R___ink_differential_0(t1576,t1577);
var t1579:u32=0u;
var t1580:u32=0u;
var t1581:R___ink_differential_0=R___ink_differential_0(t1579,t1580);
var t1582:u32=1065353216u;
var t1583:u32=0u;
var t1584:R___ink_differential_0=R___ink_differential_0(t1582,t1583);
var t1585:u32=1065353216u;
var t1586:u32=0u;
var t1587:R___ink_differential_0=R___ink_differential_0(t1585,t1586);
var t1588:u32=0u;
t1555=R___ink_differential_3(t1575,t1578,t1581,t1584,t1587,t1588);}
t1553=(t1555).ink_f_value;
}
var t1589:R___ink_differential_0=t1553;
var t1590:u32=t1546;
var t1591:R___ink_differential_0;if(t1590<6u){
t1591=t26[t1590];}else{
var t1592:u32=0u;
var t1593:u32=0u;
t1591=R___ink_differential_0(t1592,t1593);}
var t1594:R___ink_differential_0=t1591;
var t1595:u32=(t1589).ink_f_value;
var t1596:u32=ink_f32_mul(t1595,(t1594).ink_f_value);
var t1597:u32=t1596;
var t1598:u32=(t1589).ink_f_tangent;
var t1599:u32=ink_f32_mul(t1598,(t1594).ink_f_value);
var t1600:u32=(t1589).ink_f_value;
var t1601:u32=ink_f32_add(t1599,ink_f32_mul(t1600,(t1594).ink_f_tangent));
var t1602:R___ink_differential_0=R___ink_differential_0(t1597,t1601);
var t1603:u32=(t1547).ink_f_value;
var t1604:u32=ink_f32_add(t1603,(t1602).ink_f_value);
var t1605:u32=t1604;
var t1606:u32=(t1547).ink_f_tangent;
var t1607:u32=ink_f32_add(t1606,(t1602).ink_f_tangent);
t1545=R___ink_differential_0(t1605,t1607);
}
var t1608:R___ink_differential_0=t1545;
var t1609:R___ink_differential_0=t1497;
var t1610:u32=t1498;
var t1611:u32=139u;
var t1612:R___ink_differential_0=t1609;
var t1613:u32=t1610;
var t1614:u32=t1611;
var t1615:u32=(t1614 + 6u);
var t1616:u32=t1613;
var t1617:R___ink_differential_0;
if ((t1616 == t1615)) {
t1617=t1612;
} else {
var t1618:u32=t1615;
var t1619:R___ink_differential_3;if(t1618<a0[0u]){
var t1620:R_Parameter=R_Parameter(a0[1u+(t1618)*6u+0u],a0[1u+(t1618)*6u+1u],a0[1u+(t1618)*6u+2u],a0[1u+(t1618)*6u+3u],a0[1u+(t1618)*6u+4u],a0[1u+(t1618)*6u+5u]);
var t1621:u32=(t1620).ink_f_value;
var t1622:u32=0u;
var t1623:R___ink_differential_0=R___ink_differential_0(t1621,t1622);
var t1624:u32=(t1620).ink_f_first;
var t1625:u32=0u;
var t1626:R___ink_differential_0=R___ink_differential_0(t1624,t1625);
var t1627:u32=(t1620).ink_f_second;
var t1628:u32=0u;
var t1629:R___ink_differential_0=R___ink_differential_0(t1627,t1628);
var t1630:u32=(t1620).ink_f_first_power;
var t1631:u32=0u;
var t1632:R___ink_differential_0=R___ink_differential_0(t1630,t1631);
var t1633:u32=(t1620).ink_f_second_power;
var t1634:u32=0u;
var t1635:R___ink_differential_0=R___ink_differential_0(t1633,t1634);
var t1636:u32=(t1620).ink_f_steps;
t1619=R___ink_differential_3(t1623,t1626,t1629,t1632,t1635,t1636);}else{
var t1637:u32=0u;
var t1638:u32=0u;
var t1639:R___ink_differential_0=R___ink_differential_0(t1637,t1638);
var t1640:u32=0u;
var t1641:u32=0u;
var t1642:R___ink_differential_0=R___ink_differential_0(t1640,t1641);
var t1643:u32=0u;
var t1644:u32=0u;
var t1645:R___ink_differential_0=R___ink_differential_0(t1643,t1644);
var t1646:u32=1065353216u;
var t1647:u32=0u;
var t1648:R___ink_differential_0=R___ink_differential_0(t1646,t1647);
var t1649:u32=1065353216u;
var t1650:u32=0u;
var t1651:R___ink_differential_0=R___ink_differential_0(t1649,t1650);
var t1652:u32=0u;
t1619=R___ink_differential_3(t1639,t1642,t1645,t1648,t1651,t1652);}
t1617=(t1619).ink_f_value;
}
var t1653:R___ink_differential_0=t1617;
var t1654:R___ink_differential_0=t1653;
for(var t1655=0u;t1655<6u;t1655++){
var t1656:R___ink_differential_0=t1654;
var t1657:R___ink_differential_0=t1609;
var t1658:u32=t1610;
var t1659:u32=t1611;
var t1660:u32=(t1659 + t1655);
var t1661:u32=t1658;
var t1662:R___ink_differential_0;
if ((t1661 == t1660)) {
t1662=t1657;
} else {
var t1663:u32=t1660;
var t1664:R___ink_differential_3;if(t1663<a0[0u]){
var t1665:R_Parameter=R_Parameter(a0[1u+(t1663)*6u+0u],a0[1u+(t1663)*6u+1u],a0[1u+(t1663)*6u+2u],a0[1u+(t1663)*6u+3u],a0[1u+(t1663)*6u+4u],a0[1u+(t1663)*6u+5u]);
var t1666:u32=(t1665).ink_f_value;
var t1667:u32=0u;
var t1668:R___ink_differential_0=R___ink_differential_0(t1666,t1667);
var t1669:u32=(t1665).ink_f_first;
var t1670:u32=0u;
var t1671:R___ink_differential_0=R___ink_differential_0(t1669,t1670);
var t1672:u32=(t1665).ink_f_second;
var t1673:u32=0u;
var t1674:R___ink_differential_0=R___ink_differential_0(t1672,t1673);
var t1675:u32=(t1665).ink_f_first_power;
var t1676:u32=0u;
var t1677:R___ink_differential_0=R___ink_differential_0(t1675,t1676);
var t1678:u32=(t1665).ink_f_second_power;
var t1679:u32=0u;
var t1680:R___ink_differential_0=R___ink_differential_0(t1678,t1679);
var t1681:u32=(t1665).ink_f_steps;
t1664=R___ink_differential_3(t1668,t1671,t1674,t1677,t1680,t1681);}else{
var t1682:u32=0u;
var t1683:u32=0u;
var t1684:R___ink_differential_0=R___ink_differential_0(t1682,t1683);
var t1685:u32=0u;
var t1686:u32=0u;
var t1687:R___ink_differential_0=R___ink_differential_0(t1685,t1686);
var t1688:u32=0u;
var t1689:u32=0u;
var t1690:R___ink_differential_0=R___ink_differential_0(t1688,t1689);
var t1691:u32=1065353216u;
var t1692:u32=0u;
var t1693:R___ink_differential_0=R___ink_differential_0(t1691,t1692);
var t1694:u32=1065353216u;
var t1695:u32=0u;
var t1696:R___ink_differential_0=R___ink_differential_0(t1694,t1695);
var t1697:u32=0u;
t1664=R___ink_differential_3(t1684,t1687,t1690,t1693,t1696,t1697);}
t1662=(t1664).ink_f_value;
}
var t1698:R___ink_differential_0=t1662;
var t1699:u32=t1655;
var t1700:R___ink_differential_0;if(t1699<6u){
t1700=t26[t1699];}else{
var t1701:u32=0u;
var t1702:u32=0u;
t1700=R___ink_differential_0(t1701,t1702);}
var t1703:R___ink_differential_0=t1700;
var t1704:u32=(t1698).ink_f_value;
var t1705:u32=ink_f32_mul(t1704,(t1703).ink_f_value);
var t1706:u32=t1705;
var t1707:u32=(t1698).ink_f_tangent;
var t1708:u32=ink_f32_mul(t1707,(t1703).ink_f_value);
var t1709:u32=(t1698).ink_f_value;
var t1710:u32=ink_f32_add(t1708,ink_f32_mul(t1709,(t1703).ink_f_tangent));
var t1711:R___ink_differential_0=R___ink_differential_0(t1706,t1710);
var t1712:u32=(t1656).ink_f_value;
var t1713:u32=ink_f32_add(t1712,(t1711).ink_f_value);
var t1714:u32=t1713;
var t1715:u32=(t1656).ink_f_tangent;
var t1716:u32=ink_f32_add(t1715,(t1711).ink_f_tangent);
t1654=R___ink_differential_0(t1714,t1716);
}
var t1717:R___ink_differential_0=t1654;
var t1718:u32=(t1717).ink_f_value;
var t1719:u32=0u;
var t1720:u32=0u;
var t1721:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t1719,t1720)).ink_f_value,t1718)) {
var t1722:R___ink_differential_0=t1608;
var t1723:R___ink_differential_0=t1717;
var t1724:u32=(t1722).ink_f_value;
var t1725:u32=ink_f32_mul(t1724,(t1723).ink_f_value);
var t1726:u32=t1725;
var t1727:u32=(t1722).ink_f_tangent;
var t1728:u32=ink_f32_mul(t1727,(t1723).ink_f_value);
var t1729:u32=(t1722).ink_f_value;
var t1730:u32=ink_f32_add(t1728,ink_f32_mul(t1729,(t1723).ink_f_tangent));
t1721=R___ink_differential_0(t1726,t1730);
} else {
var t1731:u32=0u;
var t1732:u32=0u;
t1721=R___ink_differential_0(t1731,t1732);
}
t1499[0u]=t1721;
var t1733:R___ink_differential_0=t1497;
var t1734:u32=t1498;
var t1735:u32=146u;
var t1736:R___ink_differential_0=t1733;
var t1737:u32=t1734;
var t1738:u32=t1735;
var t1739:u32=(t1738 + 6u);
var t1740:u32=t1737;
var t1741:R___ink_differential_0;
if ((t1740 == t1739)) {
t1741=t1736;
} else {
var t1742:u32=t1739;
var t1743:R___ink_differential_3;if(t1742<a0[0u]){
var t1744:R_Parameter=R_Parameter(a0[1u+(t1742)*6u+0u],a0[1u+(t1742)*6u+1u],a0[1u+(t1742)*6u+2u],a0[1u+(t1742)*6u+3u],a0[1u+(t1742)*6u+4u],a0[1u+(t1742)*6u+5u]);
var t1745:u32=(t1744).ink_f_value;
var t1746:u32=0u;
var t1747:R___ink_differential_0=R___ink_differential_0(t1745,t1746);
var t1748:u32=(t1744).ink_f_first;
var t1749:u32=0u;
var t1750:R___ink_differential_0=R___ink_differential_0(t1748,t1749);
var t1751:u32=(t1744).ink_f_second;
var t1752:u32=0u;
var t1753:R___ink_differential_0=R___ink_differential_0(t1751,t1752);
var t1754:u32=(t1744).ink_f_first_power;
var t1755:u32=0u;
var t1756:R___ink_differential_0=R___ink_differential_0(t1754,t1755);
var t1757:u32=(t1744).ink_f_second_power;
var t1758:u32=0u;
var t1759:R___ink_differential_0=R___ink_differential_0(t1757,t1758);
var t1760:u32=(t1744).ink_f_steps;
t1743=R___ink_differential_3(t1747,t1750,t1753,t1756,t1759,t1760);}else{
var t1761:u32=0u;
var t1762:u32=0u;
var t1763:R___ink_differential_0=R___ink_differential_0(t1761,t1762);
var t1764:u32=0u;
var t1765:u32=0u;
var t1766:R___ink_differential_0=R___ink_differential_0(t1764,t1765);
var t1767:u32=0u;
var t1768:u32=0u;
var t1769:R___ink_differential_0=R___ink_differential_0(t1767,t1768);
var t1770:u32=1065353216u;
var t1771:u32=0u;
var t1772:R___ink_differential_0=R___ink_differential_0(t1770,t1771);
var t1773:u32=1065353216u;
var t1774:u32=0u;
var t1775:R___ink_differential_0=R___ink_differential_0(t1773,t1774);
var t1776:u32=0u;
t1743=R___ink_differential_3(t1763,t1766,t1769,t1772,t1775,t1776);}
t1741=(t1743).ink_f_value;
}
var t1777:R___ink_differential_0=t1741;
var t1778:R___ink_differential_0=t1777;
for(var t1779=0u;t1779<6u;t1779++){
var t1780:R___ink_differential_0=t1778;
var t1781:R___ink_differential_0=t1733;
var t1782:u32=t1734;
var t1783:u32=t1735;
var t1784:u32=(t1783 + t1779);
var t1785:u32=t1782;
var t1786:R___ink_differential_0;
if ((t1785 == t1784)) {
t1786=t1781;
} else {
var t1787:u32=t1784;
var t1788:R___ink_differential_3;if(t1787<a0[0u]){
var t1789:R_Parameter=R_Parameter(a0[1u+(t1787)*6u+0u],a0[1u+(t1787)*6u+1u],a0[1u+(t1787)*6u+2u],a0[1u+(t1787)*6u+3u],a0[1u+(t1787)*6u+4u],a0[1u+(t1787)*6u+5u]);
var t1790:u32=(t1789).ink_f_value;
var t1791:u32=0u;
var t1792:R___ink_differential_0=R___ink_differential_0(t1790,t1791);
var t1793:u32=(t1789).ink_f_first;
var t1794:u32=0u;
var t1795:R___ink_differential_0=R___ink_differential_0(t1793,t1794);
var t1796:u32=(t1789).ink_f_second;
var t1797:u32=0u;
var t1798:R___ink_differential_0=R___ink_differential_0(t1796,t1797);
var t1799:u32=(t1789).ink_f_first_power;
var t1800:u32=0u;
var t1801:R___ink_differential_0=R___ink_differential_0(t1799,t1800);
var t1802:u32=(t1789).ink_f_second_power;
var t1803:u32=0u;
var t1804:R___ink_differential_0=R___ink_differential_0(t1802,t1803);
var t1805:u32=(t1789).ink_f_steps;
t1788=R___ink_differential_3(t1792,t1795,t1798,t1801,t1804,t1805);}else{
var t1806:u32=0u;
var t1807:u32=0u;
var t1808:R___ink_differential_0=R___ink_differential_0(t1806,t1807);
var t1809:u32=0u;
var t1810:u32=0u;
var t1811:R___ink_differential_0=R___ink_differential_0(t1809,t1810);
var t1812:u32=0u;
var t1813:u32=0u;
var t1814:R___ink_differential_0=R___ink_differential_0(t1812,t1813);
var t1815:u32=1065353216u;
var t1816:u32=0u;
var t1817:R___ink_differential_0=R___ink_differential_0(t1815,t1816);
var t1818:u32=1065353216u;
var t1819:u32=0u;
var t1820:R___ink_differential_0=R___ink_differential_0(t1818,t1819);
var t1821:u32=0u;
t1788=R___ink_differential_3(t1808,t1811,t1814,t1817,t1820,t1821);}
t1786=(t1788).ink_f_value;
}
var t1822:R___ink_differential_0=t1786;
var t1823:u32=t1779;
var t1824:R___ink_differential_0;if(t1823<6u){
t1824=t26[t1823];}else{
var t1825:u32=0u;
var t1826:u32=0u;
t1824=R___ink_differential_0(t1825,t1826);}
var t1827:R___ink_differential_0=t1824;
var t1828:u32=(t1822).ink_f_value;
var t1829:u32=ink_f32_mul(t1828,(t1827).ink_f_value);
var t1830:u32=t1829;
var t1831:u32=(t1822).ink_f_tangent;
var t1832:u32=ink_f32_mul(t1831,(t1827).ink_f_value);
var t1833:u32=(t1822).ink_f_value;
var t1834:u32=ink_f32_add(t1832,ink_f32_mul(t1833,(t1827).ink_f_tangent));
var t1835:R___ink_differential_0=R___ink_differential_0(t1830,t1834);
var t1836:u32=(t1780).ink_f_value;
var t1837:u32=ink_f32_add(t1836,(t1835).ink_f_value);
var t1838:u32=t1837;
var t1839:u32=(t1780).ink_f_tangent;
var t1840:u32=ink_f32_add(t1839,(t1835).ink_f_tangent);
t1778=R___ink_differential_0(t1838,t1840);
}
var t1841:R___ink_differential_0=t1778;
var t1842:R___ink_differential_0=t1497;
var t1843:u32=t1498;
var t1844:u32=153u;
var t1845:R___ink_differential_0=t1842;
var t1846:u32=t1843;
var t1847:u32=t1844;
var t1848:u32=(t1847 + 6u);
var t1849:u32=t1846;
var t1850:R___ink_differential_0;
if ((t1849 == t1848)) {
t1850=t1845;
} else {
var t1851:u32=t1848;
var t1852:R___ink_differential_3;if(t1851<a0[0u]){
var t1853:R_Parameter=R_Parameter(a0[1u+(t1851)*6u+0u],a0[1u+(t1851)*6u+1u],a0[1u+(t1851)*6u+2u],a0[1u+(t1851)*6u+3u],a0[1u+(t1851)*6u+4u],a0[1u+(t1851)*6u+5u]);
var t1854:u32=(t1853).ink_f_value;
var t1855:u32=0u;
var t1856:R___ink_differential_0=R___ink_differential_0(t1854,t1855);
var t1857:u32=(t1853).ink_f_first;
var t1858:u32=0u;
var t1859:R___ink_differential_0=R___ink_differential_0(t1857,t1858);
var t1860:u32=(t1853).ink_f_second;
var t1861:u32=0u;
var t1862:R___ink_differential_0=R___ink_differential_0(t1860,t1861);
var t1863:u32=(t1853).ink_f_first_power;
var t1864:u32=0u;
var t1865:R___ink_differential_0=R___ink_differential_0(t1863,t1864);
var t1866:u32=(t1853).ink_f_second_power;
var t1867:u32=0u;
var t1868:R___ink_differential_0=R___ink_differential_0(t1866,t1867);
var t1869:u32=(t1853).ink_f_steps;
t1852=R___ink_differential_3(t1856,t1859,t1862,t1865,t1868,t1869);}else{
var t1870:u32=0u;
var t1871:u32=0u;
var t1872:R___ink_differential_0=R___ink_differential_0(t1870,t1871);
var t1873:u32=0u;
var t1874:u32=0u;
var t1875:R___ink_differential_0=R___ink_differential_0(t1873,t1874);
var t1876:u32=0u;
var t1877:u32=0u;
var t1878:R___ink_differential_0=R___ink_differential_0(t1876,t1877);
var t1879:u32=1065353216u;
var t1880:u32=0u;
var t1881:R___ink_differential_0=R___ink_differential_0(t1879,t1880);
var t1882:u32=1065353216u;
var t1883:u32=0u;
var t1884:R___ink_differential_0=R___ink_differential_0(t1882,t1883);
var t1885:u32=0u;
t1852=R___ink_differential_3(t1872,t1875,t1878,t1881,t1884,t1885);}
t1850=(t1852).ink_f_value;
}
var t1886:R___ink_differential_0=t1850;
var t1887:R___ink_differential_0=t1886;
for(var t1888=0u;t1888<6u;t1888++){
var t1889:R___ink_differential_0=t1887;
var t1890:R___ink_differential_0=t1842;
var t1891:u32=t1843;
var t1892:u32=t1844;
var t1893:u32=(t1892 + t1888);
var t1894:u32=t1891;
var t1895:R___ink_differential_0;
if ((t1894 == t1893)) {
t1895=t1890;
} else {
var t1896:u32=t1893;
var t1897:R___ink_differential_3;if(t1896<a0[0u]){
var t1898:R_Parameter=R_Parameter(a0[1u+(t1896)*6u+0u],a0[1u+(t1896)*6u+1u],a0[1u+(t1896)*6u+2u],a0[1u+(t1896)*6u+3u],a0[1u+(t1896)*6u+4u],a0[1u+(t1896)*6u+5u]);
var t1899:u32=(t1898).ink_f_value;
var t1900:u32=0u;
var t1901:R___ink_differential_0=R___ink_differential_0(t1899,t1900);
var t1902:u32=(t1898).ink_f_first;
var t1903:u32=0u;
var t1904:R___ink_differential_0=R___ink_differential_0(t1902,t1903);
var t1905:u32=(t1898).ink_f_second;
var t1906:u32=0u;
var t1907:R___ink_differential_0=R___ink_differential_0(t1905,t1906);
var t1908:u32=(t1898).ink_f_first_power;
var t1909:u32=0u;
var t1910:R___ink_differential_0=R___ink_differential_0(t1908,t1909);
var t1911:u32=(t1898).ink_f_second_power;
var t1912:u32=0u;
var t1913:R___ink_differential_0=R___ink_differential_0(t1911,t1912);
var t1914:u32=(t1898).ink_f_steps;
t1897=R___ink_differential_3(t1901,t1904,t1907,t1910,t1913,t1914);}else{
var t1915:u32=0u;
var t1916:u32=0u;
var t1917:R___ink_differential_0=R___ink_differential_0(t1915,t1916);
var t1918:u32=0u;
var t1919:u32=0u;
var t1920:R___ink_differential_0=R___ink_differential_0(t1918,t1919);
var t1921:u32=0u;
var t1922:u32=0u;
var t1923:R___ink_differential_0=R___ink_differential_0(t1921,t1922);
var t1924:u32=1065353216u;
var t1925:u32=0u;
var t1926:R___ink_differential_0=R___ink_differential_0(t1924,t1925);
var t1927:u32=1065353216u;
var t1928:u32=0u;
var t1929:R___ink_differential_0=R___ink_differential_0(t1927,t1928);
var t1930:u32=0u;
t1897=R___ink_differential_3(t1917,t1920,t1923,t1926,t1929,t1930);}
t1895=(t1897).ink_f_value;
}
var t1931:R___ink_differential_0=t1895;
var t1932:u32=t1888;
var t1933:R___ink_differential_0;if(t1932<6u){
t1933=t26[t1932];}else{
var t1934:u32=0u;
var t1935:u32=0u;
t1933=R___ink_differential_0(t1934,t1935);}
var t1936:R___ink_differential_0=t1933;
var t1937:u32=(t1931).ink_f_value;
var t1938:u32=ink_f32_mul(t1937,(t1936).ink_f_value);
var t1939:u32=t1938;
var t1940:u32=(t1931).ink_f_tangent;
var t1941:u32=ink_f32_mul(t1940,(t1936).ink_f_value);
var t1942:u32=(t1931).ink_f_value;
var t1943:u32=ink_f32_add(t1941,ink_f32_mul(t1942,(t1936).ink_f_tangent));
var t1944:R___ink_differential_0=R___ink_differential_0(t1939,t1943);
var t1945:u32=(t1889).ink_f_value;
var t1946:u32=ink_f32_add(t1945,(t1944).ink_f_value);
var t1947:u32=t1946;
var t1948:u32=(t1889).ink_f_tangent;
var t1949:u32=ink_f32_add(t1948,(t1944).ink_f_tangent);
t1887=R___ink_differential_0(t1947,t1949);
}
var t1950:R___ink_differential_0=t1887;
var t1951:u32=(t1950).ink_f_value;
var t1952:u32=0u;
var t1953:u32=0u;
var t1954:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t1952,t1953)).ink_f_value,t1951)) {
var t1955:R___ink_differential_0=t1841;
var t1956:R___ink_differential_0=t1950;
var t1957:u32=(t1955).ink_f_value;
var t1958:u32=ink_f32_mul(t1957,(t1956).ink_f_value);
var t1959:u32=t1958;
var t1960:u32=(t1955).ink_f_tangent;
var t1961:u32=ink_f32_mul(t1960,(t1956).ink_f_value);
var t1962:u32=(t1955).ink_f_value;
var t1963:u32=ink_f32_add(t1961,ink_f32_mul(t1962,(t1956).ink_f_tangent));
t1954=R___ink_differential_0(t1959,t1963);
} else {
var t1964:u32=0u;
var t1965:u32=0u;
t1954=R___ink_differential_0(t1964,t1965);
}
t1499[1u]=t1954;
var t1966:R___ink_differential_0=t1497;
var t1967:u32=t1498;
var t1968:u32=160u;
var t1969:R___ink_differential_0=t1966;
var t1970:u32=t1967;
var t1971:u32=t1968;
var t1972:u32=(t1971 + 6u);
var t1973:u32=t1970;
var t1974:R___ink_differential_0;
if ((t1973 == t1972)) {
t1974=t1969;
} else {
var t1975:u32=t1972;
var t1976:R___ink_differential_3;if(t1975<a0[0u]){
var t1977:R_Parameter=R_Parameter(a0[1u+(t1975)*6u+0u],a0[1u+(t1975)*6u+1u],a0[1u+(t1975)*6u+2u],a0[1u+(t1975)*6u+3u],a0[1u+(t1975)*6u+4u],a0[1u+(t1975)*6u+5u]);
var t1978:u32=(t1977).ink_f_value;
var t1979:u32=0u;
var t1980:R___ink_differential_0=R___ink_differential_0(t1978,t1979);
var t1981:u32=(t1977).ink_f_first;
var t1982:u32=0u;
var t1983:R___ink_differential_0=R___ink_differential_0(t1981,t1982);
var t1984:u32=(t1977).ink_f_second;
var t1985:u32=0u;
var t1986:R___ink_differential_0=R___ink_differential_0(t1984,t1985);
var t1987:u32=(t1977).ink_f_first_power;
var t1988:u32=0u;
var t1989:R___ink_differential_0=R___ink_differential_0(t1987,t1988);
var t1990:u32=(t1977).ink_f_second_power;
var t1991:u32=0u;
var t1992:R___ink_differential_0=R___ink_differential_0(t1990,t1991);
var t1993:u32=(t1977).ink_f_steps;
t1976=R___ink_differential_3(t1980,t1983,t1986,t1989,t1992,t1993);}else{
var t1994:u32=0u;
var t1995:u32=0u;
var t1996:R___ink_differential_0=R___ink_differential_0(t1994,t1995);
var t1997:u32=0u;
var t1998:u32=0u;
var t1999:R___ink_differential_0=R___ink_differential_0(t1997,t1998);
var t2000:u32=0u;
var t2001:u32=0u;
var t2002:R___ink_differential_0=R___ink_differential_0(t2000,t2001);
var t2003:u32=1065353216u;
var t2004:u32=0u;
var t2005:R___ink_differential_0=R___ink_differential_0(t2003,t2004);
var t2006:u32=1065353216u;
var t2007:u32=0u;
var t2008:R___ink_differential_0=R___ink_differential_0(t2006,t2007);
var t2009:u32=0u;
t1976=R___ink_differential_3(t1996,t1999,t2002,t2005,t2008,t2009);}
t1974=(t1976).ink_f_value;
}
var t2010:R___ink_differential_0=t1974;
var t2011:R___ink_differential_0=t2010;
for(var t2012=0u;t2012<6u;t2012++){
var t2013:R___ink_differential_0=t2011;
var t2014:R___ink_differential_0=t1966;
var t2015:u32=t1967;
var t2016:u32=t1968;
var t2017:u32=(t2016 + t2012);
var t2018:u32=t2015;
var t2019:R___ink_differential_0;
if ((t2018 == t2017)) {
t2019=t2014;
} else {
var t2020:u32=t2017;
var t2021:R___ink_differential_3;if(t2020<a0[0u]){
var t2022:R_Parameter=R_Parameter(a0[1u+(t2020)*6u+0u],a0[1u+(t2020)*6u+1u],a0[1u+(t2020)*6u+2u],a0[1u+(t2020)*6u+3u],a0[1u+(t2020)*6u+4u],a0[1u+(t2020)*6u+5u]);
var t2023:u32=(t2022).ink_f_value;
var t2024:u32=0u;
var t2025:R___ink_differential_0=R___ink_differential_0(t2023,t2024);
var t2026:u32=(t2022).ink_f_first;
var t2027:u32=0u;
var t2028:R___ink_differential_0=R___ink_differential_0(t2026,t2027);
var t2029:u32=(t2022).ink_f_second;
var t2030:u32=0u;
var t2031:R___ink_differential_0=R___ink_differential_0(t2029,t2030);
var t2032:u32=(t2022).ink_f_first_power;
var t2033:u32=0u;
var t2034:R___ink_differential_0=R___ink_differential_0(t2032,t2033);
var t2035:u32=(t2022).ink_f_second_power;
var t2036:u32=0u;
var t2037:R___ink_differential_0=R___ink_differential_0(t2035,t2036);
var t2038:u32=(t2022).ink_f_steps;
t2021=R___ink_differential_3(t2025,t2028,t2031,t2034,t2037,t2038);}else{
var t2039:u32=0u;
var t2040:u32=0u;
var t2041:R___ink_differential_0=R___ink_differential_0(t2039,t2040);
var t2042:u32=0u;
var t2043:u32=0u;
var t2044:R___ink_differential_0=R___ink_differential_0(t2042,t2043);
var t2045:u32=0u;
var t2046:u32=0u;
var t2047:R___ink_differential_0=R___ink_differential_0(t2045,t2046);
var t2048:u32=1065353216u;
var t2049:u32=0u;
var t2050:R___ink_differential_0=R___ink_differential_0(t2048,t2049);
var t2051:u32=1065353216u;
var t2052:u32=0u;
var t2053:R___ink_differential_0=R___ink_differential_0(t2051,t2052);
var t2054:u32=0u;
t2021=R___ink_differential_3(t2041,t2044,t2047,t2050,t2053,t2054);}
t2019=(t2021).ink_f_value;
}
var t2055:R___ink_differential_0=t2019;
var t2056:u32=t2012;
var t2057:R___ink_differential_0;if(t2056<6u){
t2057=t26[t2056];}else{
var t2058:u32=0u;
var t2059:u32=0u;
t2057=R___ink_differential_0(t2058,t2059);}
var t2060:R___ink_differential_0=t2057;
var t2061:u32=(t2055).ink_f_value;
var t2062:u32=ink_f32_mul(t2061,(t2060).ink_f_value);
var t2063:u32=t2062;
var t2064:u32=(t2055).ink_f_tangent;
var t2065:u32=ink_f32_mul(t2064,(t2060).ink_f_value);
var t2066:u32=(t2055).ink_f_value;
var t2067:u32=ink_f32_add(t2065,ink_f32_mul(t2066,(t2060).ink_f_tangent));
var t2068:R___ink_differential_0=R___ink_differential_0(t2063,t2067);
var t2069:u32=(t2013).ink_f_value;
var t2070:u32=ink_f32_add(t2069,(t2068).ink_f_value);
var t2071:u32=t2070;
var t2072:u32=(t2013).ink_f_tangent;
var t2073:u32=ink_f32_add(t2072,(t2068).ink_f_tangent);
t2011=R___ink_differential_0(t2071,t2073);
}
var t2074:R___ink_differential_0=t2011;
var t2075:R___ink_differential_0=t1497;
var t2076:u32=t1498;
var t2077:u32=167u;
var t2078:R___ink_differential_0=t2075;
var t2079:u32=t2076;
var t2080:u32=t2077;
var t2081:u32=(t2080 + 6u);
var t2082:u32=t2079;
var t2083:R___ink_differential_0;
if ((t2082 == t2081)) {
t2083=t2078;
} else {
var t2084:u32=t2081;
var t2085:R___ink_differential_3;if(t2084<a0[0u]){
var t2086:R_Parameter=R_Parameter(a0[1u+(t2084)*6u+0u],a0[1u+(t2084)*6u+1u],a0[1u+(t2084)*6u+2u],a0[1u+(t2084)*6u+3u],a0[1u+(t2084)*6u+4u],a0[1u+(t2084)*6u+5u]);
var t2087:u32=(t2086).ink_f_value;
var t2088:u32=0u;
var t2089:R___ink_differential_0=R___ink_differential_0(t2087,t2088);
var t2090:u32=(t2086).ink_f_first;
var t2091:u32=0u;
var t2092:R___ink_differential_0=R___ink_differential_0(t2090,t2091);
var t2093:u32=(t2086).ink_f_second;
var t2094:u32=0u;
var t2095:R___ink_differential_0=R___ink_differential_0(t2093,t2094);
var t2096:u32=(t2086).ink_f_first_power;
var t2097:u32=0u;
var t2098:R___ink_differential_0=R___ink_differential_0(t2096,t2097);
var t2099:u32=(t2086).ink_f_second_power;
var t2100:u32=0u;
var t2101:R___ink_differential_0=R___ink_differential_0(t2099,t2100);
var t2102:u32=(t2086).ink_f_steps;
t2085=R___ink_differential_3(t2089,t2092,t2095,t2098,t2101,t2102);}else{
var t2103:u32=0u;
var t2104:u32=0u;
var t2105:R___ink_differential_0=R___ink_differential_0(t2103,t2104);
var t2106:u32=0u;
var t2107:u32=0u;
var t2108:R___ink_differential_0=R___ink_differential_0(t2106,t2107);
var t2109:u32=0u;
var t2110:u32=0u;
var t2111:R___ink_differential_0=R___ink_differential_0(t2109,t2110);
var t2112:u32=1065353216u;
var t2113:u32=0u;
var t2114:R___ink_differential_0=R___ink_differential_0(t2112,t2113);
var t2115:u32=1065353216u;
var t2116:u32=0u;
var t2117:R___ink_differential_0=R___ink_differential_0(t2115,t2116);
var t2118:u32=0u;
t2085=R___ink_differential_3(t2105,t2108,t2111,t2114,t2117,t2118);}
t2083=(t2085).ink_f_value;
}
var t2119:R___ink_differential_0=t2083;
var t2120:R___ink_differential_0=t2119;
for(var t2121=0u;t2121<6u;t2121++){
var t2122:R___ink_differential_0=t2120;
var t2123:R___ink_differential_0=t2075;
var t2124:u32=t2076;
var t2125:u32=t2077;
var t2126:u32=(t2125 + t2121);
var t2127:u32=t2124;
var t2128:R___ink_differential_0;
if ((t2127 == t2126)) {
t2128=t2123;
} else {
var t2129:u32=t2126;
var t2130:R___ink_differential_3;if(t2129<a0[0u]){
var t2131:R_Parameter=R_Parameter(a0[1u+(t2129)*6u+0u],a0[1u+(t2129)*6u+1u],a0[1u+(t2129)*6u+2u],a0[1u+(t2129)*6u+3u],a0[1u+(t2129)*6u+4u],a0[1u+(t2129)*6u+5u]);
var t2132:u32=(t2131).ink_f_value;
var t2133:u32=0u;
var t2134:R___ink_differential_0=R___ink_differential_0(t2132,t2133);
var t2135:u32=(t2131).ink_f_first;
var t2136:u32=0u;
var t2137:R___ink_differential_0=R___ink_differential_0(t2135,t2136);
var t2138:u32=(t2131).ink_f_second;
var t2139:u32=0u;
var t2140:R___ink_differential_0=R___ink_differential_0(t2138,t2139);
var t2141:u32=(t2131).ink_f_first_power;
var t2142:u32=0u;
var t2143:R___ink_differential_0=R___ink_differential_0(t2141,t2142);
var t2144:u32=(t2131).ink_f_second_power;
var t2145:u32=0u;
var t2146:R___ink_differential_0=R___ink_differential_0(t2144,t2145);
var t2147:u32=(t2131).ink_f_steps;
t2130=R___ink_differential_3(t2134,t2137,t2140,t2143,t2146,t2147);}else{
var t2148:u32=0u;
var t2149:u32=0u;
var t2150:R___ink_differential_0=R___ink_differential_0(t2148,t2149);
var t2151:u32=0u;
var t2152:u32=0u;
var t2153:R___ink_differential_0=R___ink_differential_0(t2151,t2152);
var t2154:u32=0u;
var t2155:u32=0u;
var t2156:R___ink_differential_0=R___ink_differential_0(t2154,t2155);
var t2157:u32=1065353216u;
var t2158:u32=0u;
var t2159:R___ink_differential_0=R___ink_differential_0(t2157,t2158);
var t2160:u32=1065353216u;
var t2161:u32=0u;
var t2162:R___ink_differential_0=R___ink_differential_0(t2160,t2161);
var t2163:u32=0u;
t2130=R___ink_differential_3(t2150,t2153,t2156,t2159,t2162,t2163);}
t2128=(t2130).ink_f_value;
}
var t2164:R___ink_differential_0=t2128;
var t2165:u32=t2121;
var t2166:R___ink_differential_0;if(t2165<6u){
t2166=t26[t2165];}else{
var t2167:u32=0u;
var t2168:u32=0u;
t2166=R___ink_differential_0(t2167,t2168);}
var t2169:R___ink_differential_0=t2166;
var t2170:u32=(t2164).ink_f_value;
var t2171:u32=ink_f32_mul(t2170,(t2169).ink_f_value);
var t2172:u32=t2171;
var t2173:u32=(t2164).ink_f_tangent;
var t2174:u32=ink_f32_mul(t2173,(t2169).ink_f_value);
var t2175:u32=(t2164).ink_f_value;
var t2176:u32=ink_f32_add(t2174,ink_f32_mul(t2175,(t2169).ink_f_tangent));
var t2177:R___ink_differential_0=R___ink_differential_0(t2172,t2176);
var t2178:u32=(t2122).ink_f_value;
var t2179:u32=ink_f32_add(t2178,(t2177).ink_f_value);
var t2180:u32=t2179;
var t2181:u32=(t2122).ink_f_tangent;
var t2182:u32=ink_f32_add(t2181,(t2177).ink_f_tangent);
t2120=R___ink_differential_0(t2180,t2182);
}
var t2183:R___ink_differential_0=t2120;
var t2184:u32=(t2183).ink_f_value;
var t2185:u32=0u;
var t2186:u32=0u;
var t2187:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t2185,t2186)).ink_f_value,t2184)) {
var t2188:R___ink_differential_0=t2074;
var t2189:R___ink_differential_0=t2183;
var t2190:u32=(t2188).ink_f_value;
var t2191:u32=ink_f32_mul(t2190,(t2189).ink_f_value);
var t2192:u32=t2191;
var t2193:u32=(t2188).ink_f_tangent;
var t2194:u32=ink_f32_mul(t2193,(t2189).ink_f_value);
var t2195:u32=(t2188).ink_f_value;
var t2196:u32=ink_f32_add(t2194,ink_f32_mul(t2195,(t2189).ink_f_tangent));
t2187=R___ink_differential_0(t2192,t2196);
} else {
var t2197:u32=0u;
var t2198:u32=0u;
t2187=R___ink_differential_0(t2197,t2198);
}
t1499[2u]=t2187;
var t2199:R___ink_differential_0=t1497;
var t2200:u32=t1498;
var t2201:u32=174u;
var t2202:R___ink_differential_0=t2199;
var t2203:u32=t2200;
var t2204:u32=t2201;
var t2205:u32=(t2204 + 6u);
var t2206:u32=t2203;
var t2207:R___ink_differential_0;
if ((t2206 == t2205)) {
t2207=t2202;
} else {
var t2208:u32=t2205;
var t2209:R___ink_differential_3;if(t2208<a0[0u]){
var t2210:R_Parameter=R_Parameter(a0[1u+(t2208)*6u+0u],a0[1u+(t2208)*6u+1u],a0[1u+(t2208)*6u+2u],a0[1u+(t2208)*6u+3u],a0[1u+(t2208)*6u+4u],a0[1u+(t2208)*6u+5u]);
var t2211:u32=(t2210).ink_f_value;
var t2212:u32=0u;
var t2213:R___ink_differential_0=R___ink_differential_0(t2211,t2212);
var t2214:u32=(t2210).ink_f_first;
var t2215:u32=0u;
var t2216:R___ink_differential_0=R___ink_differential_0(t2214,t2215);
var t2217:u32=(t2210).ink_f_second;
var t2218:u32=0u;
var t2219:R___ink_differential_0=R___ink_differential_0(t2217,t2218);
var t2220:u32=(t2210).ink_f_first_power;
var t2221:u32=0u;
var t2222:R___ink_differential_0=R___ink_differential_0(t2220,t2221);
var t2223:u32=(t2210).ink_f_second_power;
var t2224:u32=0u;
var t2225:R___ink_differential_0=R___ink_differential_0(t2223,t2224);
var t2226:u32=(t2210).ink_f_steps;
t2209=R___ink_differential_3(t2213,t2216,t2219,t2222,t2225,t2226);}else{
var t2227:u32=0u;
var t2228:u32=0u;
var t2229:R___ink_differential_0=R___ink_differential_0(t2227,t2228);
var t2230:u32=0u;
var t2231:u32=0u;
var t2232:R___ink_differential_0=R___ink_differential_0(t2230,t2231);
var t2233:u32=0u;
var t2234:u32=0u;
var t2235:R___ink_differential_0=R___ink_differential_0(t2233,t2234);
var t2236:u32=1065353216u;
var t2237:u32=0u;
var t2238:R___ink_differential_0=R___ink_differential_0(t2236,t2237);
var t2239:u32=1065353216u;
var t2240:u32=0u;
var t2241:R___ink_differential_0=R___ink_differential_0(t2239,t2240);
var t2242:u32=0u;
t2209=R___ink_differential_3(t2229,t2232,t2235,t2238,t2241,t2242);}
t2207=(t2209).ink_f_value;
}
var t2243:R___ink_differential_0=t2207;
var t2244:R___ink_differential_0=t2243;
for(var t2245=0u;t2245<6u;t2245++){
var t2246:R___ink_differential_0=t2244;
var t2247:R___ink_differential_0=t2199;
var t2248:u32=t2200;
var t2249:u32=t2201;
var t2250:u32=(t2249 + t2245);
var t2251:u32=t2248;
var t2252:R___ink_differential_0;
if ((t2251 == t2250)) {
t2252=t2247;
} else {
var t2253:u32=t2250;
var t2254:R___ink_differential_3;if(t2253<a0[0u]){
var t2255:R_Parameter=R_Parameter(a0[1u+(t2253)*6u+0u],a0[1u+(t2253)*6u+1u],a0[1u+(t2253)*6u+2u],a0[1u+(t2253)*6u+3u],a0[1u+(t2253)*6u+4u],a0[1u+(t2253)*6u+5u]);
var t2256:u32=(t2255).ink_f_value;
var t2257:u32=0u;
var t2258:R___ink_differential_0=R___ink_differential_0(t2256,t2257);
var t2259:u32=(t2255).ink_f_first;
var t2260:u32=0u;
var t2261:R___ink_differential_0=R___ink_differential_0(t2259,t2260);
var t2262:u32=(t2255).ink_f_second;
var t2263:u32=0u;
var t2264:R___ink_differential_0=R___ink_differential_0(t2262,t2263);
var t2265:u32=(t2255).ink_f_first_power;
var t2266:u32=0u;
var t2267:R___ink_differential_0=R___ink_differential_0(t2265,t2266);
var t2268:u32=(t2255).ink_f_second_power;
var t2269:u32=0u;
var t2270:R___ink_differential_0=R___ink_differential_0(t2268,t2269);
var t2271:u32=(t2255).ink_f_steps;
t2254=R___ink_differential_3(t2258,t2261,t2264,t2267,t2270,t2271);}else{
var t2272:u32=0u;
var t2273:u32=0u;
var t2274:R___ink_differential_0=R___ink_differential_0(t2272,t2273);
var t2275:u32=0u;
var t2276:u32=0u;
var t2277:R___ink_differential_0=R___ink_differential_0(t2275,t2276);
var t2278:u32=0u;
var t2279:u32=0u;
var t2280:R___ink_differential_0=R___ink_differential_0(t2278,t2279);
var t2281:u32=1065353216u;
var t2282:u32=0u;
var t2283:R___ink_differential_0=R___ink_differential_0(t2281,t2282);
var t2284:u32=1065353216u;
var t2285:u32=0u;
var t2286:R___ink_differential_0=R___ink_differential_0(t2284,t2285);
var t2287:u32=0u;
t2254=R___ink_differential_3(t2274,t2277,t2280,t2283,t2286,t2287);}
t2252=(t2254).ink_f_value;
}
var t2288:R___ink_differential_0=t2252;
var t2289:u32=t2245;
var t2290:R___ink_differential_0;if(t2289<6u){
t2290=t26[t2289];}else{
var t2291:u32=0u;
var t2292:u32=0u;
t2290=R___ink_differential_0(t2291,t2292);}
var t2293:R___ink_differential_0=t2290;
var t2294:u32=(t2288).ink_f_value;
var t2295:u32=ink_f32_mul(t2294,(t2293).ink_f_value);
var t2296:u32=t2295;
var t2297:u32=(t2288).ink_f_tangent;
var t2298:u32=ink_f32_mul(t2297,(t2293).ink_f_value);
var t2299:u32=(t2288).ink_f_value;
var t2300:u32=ink_f32_add(t2298,ink_f32_mul(t2299,(t2293).ink_f_tangent));
var t2301:R___ink_differential_0=R___ink_differential_0(t2296,t2300);
var t2302:u32=(t2246).ink_f_value;
var t2303:u32=ink_f32_add(t2302,(t2301).ink_f_value);
var t2304:u32=t2303;
var t2305:u32=(t2246).ink_f_tangent;
var t2306:u32=ink_f32_add(t2305,(t2301).ink_f_tangent);
t2244=R___ink_differential_0(t2304,t2306);
}
var t2307:R___ink_differential_0=t2244;
var t2308:R___ink_differential_0=t1497;
var t2309:u32=t1498;
var t2310:u32=181u;
var t2311:R___ink_differential_0=t2308;
var t2312:u32=t2309;
var t2313:u32=t2310;
var t2314:u32=(t2313 + 6u);
var t2315:u32=t2312;
var t2316:R___ink_differential_0;
if ((t2315 == t2314)) {
t2316=t2311;
} else {
var t2317:u32=t2314;
var t2318:R___ink_differential_3;if(t2317<a0[0u]){
var t2319:R_Parameter=R_Parameter(a0[1u+(t2317)*6u+0u],a0[1u+(t2317)*6u+1u],a0[1u+(t2317)*6u+2u],a0[1u+(t2317)*6u+3u],a0[1u+(t2317)*6u+4u],a0[1u+(t2317)*6u+5u]);
var t2320:u32=(t2319).ink_f_value;
var t2321:u32=0u;
var t2322:R___ink_differential_0=R___ink_differential_0(t2320,t2321);
var t2323:u32=(t2319).ink_f_first;
var t2324:u32=0u;
var t2325:R___ink_differential_0=R___ink_differential_0(t2323,t2324);
var t2326:u32=(t2319).ink_f_second;
var t2327:u32=0u;
var t2328:R___ink_differential_0=R___ink_differential_0(t2326,t2327);
var t2329:u32=(t2319).ink_f_first_power;
var t2330:u32=0u;
var t2331:R___ink_differential_0=R___ink_differential_0(t2329,t2330);
var t2332:u32=(t2319).ink_f_second_power;
var t2333:u32=0u;
var t2334:R___ink_differential_0=R___ink_differential_0(t2332,t2333);
var t2335:u32=(t2319).ink_f_steps;
t2318=R___ink_differential_3(t2322,t2325,t2328,t2331,t2334,t2335);}else{
var t2336:u32=0u;
var t2337:u32=0u;
var t2338:R___ink_differential_0=R___ink_differential_0(t2336,t2337);
var t2339:u32=0u;
var t2340:u32=0u;
var t2341:R___ink_differential_0=R___ink_differential_0(t2339,t2340);
var t2342:u32=0u;
var t2343:u32=0u;
var t2344:R___ink_differential_0=R___ink_differential_0(t2342,t2343);
var t2345:u32=1065353216u;
var t2346:u32=0u;
var t2347:R___ink_differential_0=R___ink_differential_0(t2345,t2346);
var t2348:u32=1065353216u;
var t2349:u32=0u;
var t2350:R___ink_differential_0=R___ink_differential_0(t2348,t2349);
var t2351:u32=0u;
t2318=R___ink_differential_3(t2338,t2341,t2344,t2347,t2350,t2351);}
t2316=(t2318).ink_f_value;
}
var t2352:R___ink_differential_0=t2316;
var t2353:R___ink_differential_0=t2352;
for(var t2354=0u;t2354<6u;t2354++){
var t2355:R___ink_differential_0=t2353;
var t2356:R___ink_differential_0=t2308;
var t2357:u32=t2309;
var t2358:u32=t2310;
var t2359:u32=(t2358 + t2354);
var t2360:u32=t2357;
var t2361:R___ink_differential_0;
if ((t2360 == t2359)) {
t2361=t2356;
} else {
var t2362:u32=t2359;
var t2363:R___ink_differential_3;if(t2362<a0[0u]){
var t2364:R_Parameter=R_Parameter(a0[1u+(t2362)*6u+0u],a0[1u+(t2362)*6u+1u],a0[1u+(t2362)*6u+2u],a0[1u+(t2362)*6u+3u],a0[1u+(t2362)*6u+4u],a0[1u+(t2362)*6u+5u]);
var t2365:u32=(t2364).ink_f_value;
var t2366:u32=0u;
var t2367:R___ink_differential_0=R___ink_differential_0(t2365,t2366);
var t2368:u32=(t2364).ink_f_first;
var t2369:u32=0u;
var t2370:R___ink_differential_0=R___ink_differential_0(t2368,t2369);
var t2371:u32=(t2364).ink_f_second;
var t2372:u32=0u;
var t2373:R___ink_differential_0=R___ink_differential_0(t2371,t2372);
var t2374:u32=(t2364).ink_f_first_power;
var t2375:u32=0u;
var t2376:R___ink_differential_0=R___ink_differential_0(t2374,t2375);
var t2377:u32=(t2364).ink_f_second_power;
var t2378:u32=0u;
var t2379:R___ink_differential_0=R___ink_differential_0(t2377,t2378);
var t2380:u32=(t2364).ink_f_steps;
t2363=R___ink_differential_3(t2367,t2370,t2373,t2376,t2379,t2380);}else{
var t2381:u32=0u;
var t2382:u32=0u;
var t2383:R___ink_differential_0=R___ink_differential_0(t2381,t2382);
var t2384:u32=0u;
var t2385:u32=0u;
var t2386:R___ink_differential_0=R___ink_differential_0(t2384,t2385);
var t2387:u32=0u;
var t2388:u32=0u;
var t2389:R___ink_differential_0=R___ink_differential_0(t2387,t2388);
var t2390:u32=1065353216u;
var t2391:u32=0u;
var t2392:R___ink_differential_0=R___ink_differential_0(t2390,t2391);
var t2393:u32=1065353216u;
var t2394:u32=0u;
var t2395:R___ink_differential_0=R___ink_differential_0(t2393,t2394);
var t2396:u32=0u;
t2363=R___ink_differential_3(t2383,t2386,t2389,t2392,t2395,t2396);}
t2361=(t2363).ink_f_value;
}
var t2397:R___ink_differential_0=t2361;
var t2398:u32=t2354;
var t2399:R___ink_differential_0;if(t2398<6u){
t2399=t26[t2398];}else{
var t2400:u32=0u;
var t2401:u32=0u;
t2399=R___ink_differential_0(t2400,t2401);}
var t2402:R___ink_differential_0=t2399;
var t2403:u32=(t2397).ink_f_value;
var t2404:u32=ink_f32_mul(t2403,(t2402).ink_f_value);
var t2405:u32=t2404;
var t2406:u32=(t2397).ink_f_tangent;
var t2407:u32=ink_f32_mul(t2406,(t2402).ink_f_value);
var t2408:u32=(t2397).ink_f_value;
var t2409:u32=ink_f32_add(t2407,ink_f32_mul(t2408,(t2402).ink_f_tangent));
var t2410:R___ink_differential_0=R___ink_differential_0(t2405,t2409);
var t2411:u32=(t2355).ink_f_value;
var t2412:u32=ink_f32_add(t2411,(t2410).ink_f_value);
var t2413:u32=t2412;
var t2414:u32=(t2355).ink_f_tangent;
var t2415:u32=ink_f32_add(t2414,(t2410).ink_f_tangent);
t2353=R___ink_differential_0(t2413,t2415);
}
var t2416:R___ink_differential_0=t2353;
var t2417:u32=(t2416).ink_f_value;
var t2418:u32=0u;
var t2419:u32=0u;
var t2420:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t2418,t2419)).ink_f_value,t2417)) {
var t2421:R___ink_differential_0=t2307;
var t2422:R___ink_differential_0=t2416;
var t2423:u32=(t2421).ink_f_value;
var t2424:u32=ink_f32_mul(t2423,(t2422).ink_f_value);
var t2425:u32=t2424;
var t2426:u32=(t2421).ink_f_tangent;
var t2427:u32=ink_f32_mul(t2426,(t2422).ink_f_value);
var t2428:u32=(t2421).ink_f_value;
var t2429:u32=ink_f32_add(t2427,ink_f32_mul(t2428,(t2422).ink_f_tangent));
t2420=R___ink_differential_0(t2425,t2429);
} else {
var t2430:u32=0u;
var t2431:u32=0u;
t2420=R___ink_differential_0(t2430,t2431);
}
t1499[3u]=t2420;
var t2432:R___ink_differential_0=t1497;
var t2433:u32=t1498;
var t2434:u32=188u;
var t2435:R___ink_differential_0=t2432;
var t2436:u32=t2433;
var t2437:u32=t2434;
var t2438:u32=(t2437 + 6u);
var t2439:u32=t2436;
var t2440:R___ink_differential_0;
if ((t2439 == t2438)) {
t2440=t2435;
} else {
var t2441:u32=t2438;
var t2442:R___ink_differential_3;if(t2441<a0[0u]){
var t2443:R_Parameter=R_Parameter(a0[1u+(t2441)*6u+0u],a0[1u+(t2441)*6u+1u],a0[1u+(t2441)*6u+2u],a0[1u+(t2441)*6u+3u],a0[1u+(t2441)*6u+4u],a0[1u+(t2441)*6u+5u]);
var t2444:u32=(t2443).ink_f_value;
var t2445:u32=0u;
var t2446:R___ink_differential_0=R___ink_differential_0(t2444,t2445);
var t2447:u32=(t2443).ink_f_first;
var t2448:u32=0u;
var t2449:R___ink_differential_0=R___ink_differential_0(t2447,t2448);
var t2450:u32=(t2443).ink_f_second;
var t2451:u32=0u;
var t2452:R___ink_differential_0=R___ink_differential_0(t2450,t2451);
var t2453:u32=(t2443).ink_f_first_power;
var t2454:u32=0u;
var t2455:R___ink_differential_0=R___ink_differential_0(t2453,t2454);
var t2456:u32=(t2443).ink_f_second_power;
var t2457:u32=0u;
var t2458:R___ink_differential_0=R___ink_differential_0(t2456,t2457);
var t2459:u32=(t2443).ink_f_steps;
t2442=R___ink_differential_3(t2446,t2449,t2452,t2455,t2458,t2459);}else{
var t2460:u32=0u;
var t2461:u32=0u;
var t2462:R___ink_differential_0=R___ink_differential_0(t2460,t2461);
var t2463:u32=0u;
var t2464:u32=0u;
var t2465:R___ink_differential_0=R___ink_differential_0(t2463,t2464);
var t2466:u32=0u;
var t2467:u32=0u;
var t2468:R___ink_differential_0=R___ink_differential_0(t2466,t2467);
var t2469:u32=1065353216u;
var t2470:u32=0u;
var t2471:R___ink_differential_0=R___ink_differential_0(t2469,t2470);
var t2472:u32=1065353216u;
var t2473:u32=0u;
var t2474:R___ink_differential_0=R___ink_differential_0(t2472,t2473);
var t2475:u32=0u;
t2442=R___ink_differential_3(t2462,t2465,t2468,t2471,t2474,t2475);}
t2440=(t2442).ink_f_value;
}
var t2476:R___ink_differential_0=t2440;
var t2477:R___ink_differential_0=t2476;
for(var t2478=0u;t2478<6u;t2478++){
var t2479:R___ink_differential_0=t2477;
var t2480:R___ink_differential_0=t2432;
var t2481:u32=t2433;
var t2482:u32=t2434;
var t2483:u32=(t2482 + t2478);
var t2484:u32=t2481;
var t2485:R___ink_differential_0;
if ((t2484 == t2483)) {
t2485=t2480;
} else {
var t2486:u32=t2483;
var t2487:R___ink_differential_3;if(t2486<a0[0u]){
var t2488:R_Parameter=R_Parameter(a0[1u+(t2486)*6u+0u],a0[1u+(t2486)*6u+1u],a0[1u+(t2486)*6u+2u],a0[1u+(t2486)*6u+3u],a0[1u+(t2486)*6u+4u],a0[1u+(t2486)*6u+5u]);
var t2489:u32=(t2488).ink_f_value;
var t2490:u32=0u;
var t2491:R___ink_differential_0=R___ink_differential_0(t2489,t2490);
var t2492:u32=(t2488).ink_f_first;
var t2493:u32=0u;
var t2494:R___ink_differential_0=R___ink_differential_0(t2492,t2493);
var t2495:u32=(t2488).ink_f_second;
var t2496:u32=0u;
var t2497:R___ink_differential_0=R___ink_differential_0(t2495,t2496);
var t2498:u32=(t2488).ink_f_first_power;
var t2499:u32=0u;
var t2500:R___ink_differential_0=R___ink_differential_0(t2498,t2499);
var t2501:u32=(t2488).ink_f_second_power;
var t2502:u32=0u;
var t2503:R___ink_differential_0=R___ink_differential_0(t2501,t2502);
var t2504:u32=(t2488).ink_f_steps;
t2487=R___ink_differential_3(t2491,t2494,t2497,t2500,t2503,t2504);}else{
var t2505:u32=0u;
var t2506:u32=0u;
var t2507:R___ink_differential_0=R___ink_differential_0(t2505,t2506);
var t2508:u32=0u;
var t2509:u32=0u;
var t2510:R___ink_differential_0=R___ink_differential_0(t2508,t2509);
var t2511:u32=0u;
var t2512:u32=0u;
var t2513:R___ink_differential_0=R___ink_differential_0(t2511,t2512);
var t2514:u32=1065353216u;
var t2515:u32=0u;
var t2516:R___ink_differential_0=R___ink_differential_0(t2514,t2515);
var t2517:u32=1065353216u;
var t2518:u32=0u;
var t2519:R___ink_differential_0=R___ink_differential_0(t2517,t2518);
var t2520:u32=0u;
t2487=R___ink_differential_3(t2507,t2510,t2513,t2516,t2519,t2520);}
t2485=(t2487).ink_f_value;
}
var t2521:R___ink_differential_0=t2485;
var t2522:u32=t2478;
var t2523:R___ink_differential_0;if(t2522<6u){
t2523=t26[t2522];}else{
var t2524:u32=0u;
var t2525:u32=0u;
t2523=R___ink_differential_0(t2524,t2525);}
var t2526:R___ink_differential_0=t2523;
var t2527:u32=(t2521).ink_f_value;
var t2528:u32=ink_f32_mul(t2527,(t2526).ink_f_value);
var t2529:u32=t2528;
var t2530:u32=(t2521).ink_f_tangent;
var t2531:u32=ink_f32_mul(t2530,(t2526).ink_f_value);
var t2532:u32=(t2521).ink_f_value;
var t2533:u32=ink_f32_add(t2531,ink_f32_mul(t2532,(t2526).ink_f_tangent));
var t2534:R___ink_differential_0=R___ink_differential_0(t2529,t2533);
var t2535:u32=(t2479).ink_f_value;
var t2536:u32=ink_f32_add(t2535,(t2534).ink_f_value);
var t2537:u32=t2536;
var t2538:u32=(t2479).ink_f_tangent;
var t2539:u32=ink_f32_add(t2538,(t2534).ink_f_tangent);
t2477=R___ink_differential_0(t2537,t2539);
}
var t2540:R___ink_differential_0=t2477;
var t2541:R___ink_differential_0=t1497;
var t2542:u32=t1498;
var t2543:u32=195u;
var t2544:R___ink_differential_0=t2541;
var t2545:u32=t2542;
var t2546:u32=t2543;
var t2547:u32=(t2546 + 6u);
var t2548:u32=t2545;
var t2549:R___ink_differential_0;
if ((t2548 == t2547)) {
t2549=t2544;
} else {
var t2550:u32=t2547;
var t2551:R___ink_differential_3;if(t2550<a0[0u]){
var t2552:R_Parameter=R_Parameter(a0[1u+(t2550)*6u+0u],a0[1u+(t2550)*6u+1u],a0[1u+(t2550)*6u+2u],a0[1u+(t2550)*6u+3u],a0[1u+(t2550)*6u+4u],a0[1u+(t2550)*6u+5u]);
var t2553:u32=(t2552).ink_f_value;
var t2554:u32=0u;
var t2555:R___ink_differential_0=R___ink_differential_0(t2553,t2554);
var t2556:u32=(t2552).ink_f_first;
var t2557:u32=0u;
var t2558:R___ink_differential_0=R___ink_differential_0(t2556,t2557);
var t2559:u32=(t2552).ink_f_second;
var t2560:u32=0u;
var t2561:R___ink_differential_0=R___ink_differential_0(t2559,t2560);
var t2562:u32=(t2552).ink_f_first_power;
var t2563:u32=0u;
var t2564:R___ink_differential_0=R___ink_differential_0(t2562,t2563);
var t2565:u32=(t2552).ink_f_second_power;
var t2566:u32=0u;
var t2567:R___ink_differential_0=R___ink_differential_0(t2565,t2566);
var t2568:u32=(t2552).ink_f_steps;
t2551=R___ink_differential_3(t2555,t2558,t2561,t2564,t2567,t2568);}else{
var t2569:u32=0u;
var t2570:u32=0u;
var t2571:R___ink_differential_0=R___ink_differential_0(t2569,t2570);
var t2572:u32=0u;
var t2573:u32=0u;
var t2574:R___ink_differential_0=R___ink_differential_0(t2572,t2573);
var t2575:u32=0u;
var t2576:u32=0u;
var t2577:R___ink_differential_0=R___ink_differential_0(t2575,t2576);
var t2578:u32=1065353216u;
var t2579:u32=0u;
var t2580:R___ink_differential_0=R___ink_differential_0(t2578,t2579);
var t2581:u32=1065353216u;
var t2582:u32=0u;
var t2583:R___ink_differential_0=R___ink_differential_0(t2581,t2582);
var t2584:u32=0u;
t2551=R___ink_differential_3(t2571,t2574,t2577,t2580,t2583,t2584);}
t2549=(t2551).ink_f_value;
}
var t2585:R___ink_differential_0=t2549;
var t2586:R___ink_differential_0=t2585;
for(var t2587=0u;t2587<6u;t2587++){
var t2588:R___ink_differential_0=t2586;
var t2589:R___ink_differential_0=t2541;
var t2590:u32=t2542;
var t2591:u32=t2543;
var t2592:u32=(t2591 + t2587);
var t2593:u32=t2590;
var t2594:R___ink_differential_0;
if ((t2593 == t2592)) {
t2594=t2589;
} else {
var t2595:u32=t2592;
var t2596:R___ink_differential_3;if(t2595<a0[0u]){
var t2597:R_Parameter=R_Parameter(a0[1u+(t2595)*6u+0u],a0[1u+(t2595)*6u+1u],a0[1u+(t2595)*6u+2u],a0[1u+(t2595)*6u+3u],a0[1u+(t2595)*6u+4u],a0[1u+(t2595)*6u+5u]);
var t2598:u32=(t2597).ink_f_value;
var t2599:u32=0u;
var t2600:R___ink_differential_0=R___ink_differential_0(t2598,t2599);
var t2601:u32=(t2597).ink_f_first;
var t2602:u32=0u;
var t2603:R___ink_differential_0=R___ink_differential_0(t2601,t2602);
var t2604:u32=(t2597).ink_f_second;
var t2605:u32=0u;
var t2606:R___ink_differential_0=R___ink_differential_0(t2604,t2605);
var t2607:u32=(t2597).ink_f_first_power;
var t2608:u32=0u;
var t2609:R___ink_differential_0=R___ink_differential_0(t2607,t2608);
var t2610:u32=(t2597).ink_f_second_power;
var t2611:u32=0u;
var t2612:R___ink_differential_0=R___ink_differential_0(t2610,t2611);
var t2613:u32=(t2597).ink_f_steps;
t2596=R___ink_differential_3(t2600,t2603,t2606,t2609,t2612,t2613);}else{
var t2614:u32=0u;
var t2615:u32=0u;
var t2616:R___ink_differential_0=R___ink_differential_0(t2614,t2615);
var t2617:u32=0u;
var t2618:u32=0u;
var t2619:R___ink_differential_0=R___ink_differential_0(t2617,t2618);
var t2620:u32=0u;
var t2621:u32=0u;
var t2622:R___ink_differential_0=R___ink_differential_0(t2620,t2621);
var t2623:u32=1065353216u;
var t2624:u32=0u;
var t2625:R___ink_differential_0=R___ink_differential_0(t2623,t2624);
var t2626:u32=1065353216u;
var t2627:u32=0u;
var t2628:R___ink_differential_0=R___ink_differential_0(t2626,t2627);
var t2629:u32=0u;
t2596=R___ink_differential_3(t2616,t2619,t2622,t2625,t2628,t2629);}
t2594=(t2596).ink_f_value;
}
var t2630:R___ink_differential_0=t2594;
var t2631:u32=t2587;
var t2632:R___ink_differential_0;if(t2631<6u){
t2632=t26[t2631];}else{
var t2633:u32=0u;
var t2634:u32=0u;
t2632=R___ink_differential_0(t2633,t2634);}
var t2635:R___ink_differential_0=t2632;
var t2636:u32=(t2630).ink_f_value;
var t2637:u32=ink_f32_mul(t2636,(t2635).ink_f_value);
var t2638:u32=t2637;
var t2639:u32=(t2630).ink_f_tangent;
var t2640:u32=ink_f32_mul(t2639,(t2635).ink_f_value);
var t2641:u32=(t2630).ink_f_value;
var t2642:u32=ink_f32_add(t2640,ink_f32_mul(t2641,(t2635).ink_f_tangent));
var t2643:R___ink_differential_0=R___ink_differential_0(t2638,t2642);
var t2644:u32=(t2588).ink_f_value;
var t2645:u32=ink_f32_add(t2644,(t2643).ink_f_value);
var t2646:u32=t2645;
var t2647:u32=(t2588).ink_f_tangent;
var t2648:u32=ink_f32_add(t2647,(t2643).ink_f_tangent);
t2586=R___ink_differential_0(t2646,t2648);
}
var t2649:R___ink_differential_0=t2586;
var t2650:u32=(t2649).ink_f_value;
var t2651:u32=0u;
var t2652:u32=0u;
var t2653:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t2651,t2652)).ink_f_value,t2650)) {
var t2654:R___ink_differential_0=t2540;
var t2655:R___ink_differential_0=t2649;
var t2656:u32=(t2654).ink_f_value;
var t2657:u32=ink_f32_mul(t2656,(t2655).ink_f_value);
var t2658:u32=t2657;
var t2659:u32=(t2654).ink_f_tangent;
var t2660:u32=ink_f32_mul(t2659,(t2655).ink_f_value);
var t2661:u32=(t2654).ink_f_value;
var t2662:u32=ink_f32_add(t2660,ink_f32_mul(t2661,(t2655).ink_f_tangent));
t2653=R___ink_differential_0(t2658,t2662);
} else {
var t2663:u32=0u;
var t2664:u32=0u;
t2653=R___ink_differential_0(t2663,t2664);
}
t1499[4u]=t2653;
var t2665:R___ink_differential_0=t1497;
var t2666:u32=t1498;
var t2667:u32=202u;
var t2668:R___ink_differential_0=t2665;
var t2669:u32=t2666;
var t2670:u32=t2667;
var t2671:u32=(t2670 + 6u);
var t2672:u32=t2669;
var t2673:R___ink_differential_0;
if ((t2672 == t2671)) {
t2673=t2668;
} else {
var t2674:u32=t2671;
var t2675:R___ink_differential_3;if(t2674<a0[0u]){
var t2676:R_Parameter=R_Parameter(a0[1u+(t2674)*6u+0u],a0[1u+(t2674)*6u+1u],a0[1u+(t2674)*6u+2u],a0[1u+(t2674)*6u+3u],a0[1u+(t2674)*6u+4u],a0[1u+(t2674)*6u+5u]);
var t2677:u32=(t2676).ink_f_value;
var t2678:u32=0u;
var t2679:R___ink_differential_0=R___ink_differential_0(t2677,t2678);
var t2680:u32=(t2676).ink_f_first;
var t2681:u32=0u;
var t2682:R___ink_differential_0=R___ink_differential_0(t2680,t2681);
var t2683:u32=(t2676).ink_f_second;
var t2684:u32=0u;
var t2685:R___ink_differential_0=R___ink_differential_0(t2683,t2684);
var t2686:u32=(t2676).ink_f_first_power;
var t2687:u32=0u;
var t2688:R___ink_differential_0=R___ink_differential_0(t2686,t2687);
var t2689:u32=(t2676).ink_f_second_power;
var t2690:u32=0u;
var t2691:R___ink_differential_0=R___ink_differential_0(t2689,t2690);
var t2692:u32=(t2676).ink_f_steps;
t2675=R___ink_differential_3(t2679,t2682,t2685,t2688,t2691,t2692);}else{
var t2693:u32=0u;
var t2694:u32=0u;
var t2695:R___ink_differential_0=R___ink_differential_0(t2693,t2694);
var t2696:u32=0u;
var t2697:u32=0u;
var t2698:R___ink_differential_0=R___ink_differential_0(t2696,t2697);
var t2699:u32=0u;
var t2700:u32=0u;
var t2701:R___ink_differential_0=R___ink_differential_0(t2699,t2700);
var t2702:u32=1065353216u;
var t2703:u32=0u;
var t2704:R___ink_differential_0=R___ink_differential_0(t2702,t2703);
var t2705:u32=1065353216u;
var t2706:u32=0u;
var t2707:R___ink_differential_0=R___ink_differential_0(t2705,t2706);
var t2708:u32=0u;
t2675=R___ink_differential_3(t2695,t2698,t2701,t2704,t2707,t2708);}
t2673=(t2675).ink_f_value;
}
var t2709:R___ink_differential_0=t2673;
var t2710:R___ink_differential_0=t2709;
for(var t2711=0u;t2711<6u;t2711++){
var t2712:R___ink_differential_0=t2710;
var t2713:R___ink_differential_0=t2665;
var t2714:u32=t2666;
var t2715:u32=t2667;
var t2716:u32=(t2715 + t2711);
var t2717:u32=t2714;
var t2718:R___ink_differential_0;
if ((t2717 == t2716)) {
t2718=t2713;
} else {
var t2719:u32=t2716;
var t2720:R___ink_differential_3;if(t2719<a0[0u]){
var t2721:R_Parameter=R_Parameter(a0[1u+(t2719)*6u+0u],a0[1u+(t2719)*6u+1u],a0[1u+(t2719)*6u+2u],a0[1u+(t2719)*6u+3u],a0[1u+(t2719)*6u+4u],a0[1u+(t2719)*6u+5u]);
var t2722:u32=(t2721).ink_f_value;
var t2723:u32=0u;
var t2724:R___ink_differential_0=R___ink_differential_0(t2722,t2723);
var t2725:u32=(t2721).ink_f_first;
var t2726:u32=0u;
var t2727:R___ink_differential_0=R___ink_differential_0(t2725,t2726);
var t2728:u32=(t2721).ink_f_second;
var t2729:u32=0u;
var t2730:R___ink_differential_0=R___ink_differential_0(t2728,t2729);
var t2731:u32=(t2721).ink_f_first_power;
var t2732:u32=0u;
var t2733:R___ink_differential_0=R___ink_differential_0(t2731,t2732);
var t2734:u32=(t2721).ink_f_second_power;
var t2735:u32=0u;
var t2736:R___ink_differential_0=R___ink_differential_0(t2734,t2735);
var t2737:u32=(t2721).ink_f_steps;
t2720=R___ink_differential_3(t2724,t2727,t2730,t2733,t2736,t2737);}else{
var t2738:u32=0u;
var t2739:u32=0u;
var t2740:R___ink_differential_0=R___ink_differential_0(t2738,t2739);
var t2741:u32=0u;
var t2742:u32=0u;
var t2743:R___ink_differential_0=R___ink_differential_0(t2741,t2742);
var t2744:u32=0u;
var t2745:u32=0u;
var t2746:R___ink_differential_0=R___ink_differential_0(t2744,t2745);
var t2747:u32=1065353216u;
var t2748:u32=0u;
var t2749:R___ink_differential_0=R___ink_differential_0(t2747,t2748);
var t2750:u32=1065353216u;
var t2751:u32=0u;
var t2752:R___ink_differential_0=R___ink_differential_0(t2750,t2751);
var t2753:u32=0u;
t2720=R___ink_differential_3(t2740,t2743,t2746,t2749,t2752,t2753);}
t2718=(t2720).ink_f_value;
}
var t2754:R___ink_differential_0=t2718;
var t2755:u32=t2711;
var t2756:R___ink_differential_0;if(t2755<6u){
t2756=t26[t2755];}else{
var t2757:u32=0u;
var t2758:u32=0u;
t2756=R___ink_differential_0(t2757,t2758);}
var t2759:R___ink_differential_0=t2756;
var t2760:u32=(t2754).ink_f_value;
var t2761:u32=ink_f32_mul(t2760,(t2759).ink_f_value);
var t2762:u32=t2761;
var t2763:u32=(t2754).ink_f_tangent;
var t2764:u32=ink_f32_mul(t2763,(t2759).ink_f_value);
var t2765:u32=(t2754).ink_f_value;
var t2766:u32=ink_f32_add(t2764,ink_f32_mul(t2765,(t2759).ink_f_tangent));
var t2767:R___ink_differential_0=R___ink_differential_0(t2762,t2766);
var t2768:u32=(t2712).ink_f_value;
var t2769:u32=ink_f32_add(t2768,(t2767).ink_f_value);
var t2770:u32=t2769;
var t2771:u32=(t2712).ink_f_tangent;
var t2772:u32=ink_f32_add(t2771,(t2767).ink_f_tangent);
t2710=R___ink_differential_0(t2770,t2772);
}
var t2773:R___ink_differential_0=t2710;
var t2774:R___ink_differential_0=t1497;
var t2775:u32=t1498;
var t2776:u32=209u;
var t2777:R___ink_differential_0=t2774;
var t2778:u32=t2775;
var t2779:u32=t2776;
var t2780:u32=(t2779 + 6u);
var t2781:u32=t2778;
var t2782:R___ink_differential_0;
if ((t2781 == t2780)) {
t2782=t2777;
} else {
var t2783:u32=t2780;
var t2784:R___ink_differential_3;if(t2783<a0[0u]){
var t2785:R_Parameter=R_Parameter(a0[1u+(t2783)*6u+0u],a0[1u+(t2783)*6u+1u],a0[1u+(t2783)*6u+2u],a0[1u+(t2783)*6u+3u],a0[1u+(t2783)*6u+4u],a0[1u+(t2783)*6u+5u]);
var t2786:u32=(t2785).ink_f_value;
var t2787:u32=0u;
var t2788:R___ink_differential_0=R___ink_differential_0(t2786,t2787);
var t2789:u32=(t2785).ink_f_first;
var t2790:u32=0u;
var t2791:R___ink_differential_0=R___ink_differential_0(t2789,t2790);
var t2792:u32=(t2785).ink_f_second;
var t2793:u32=0u;
var t2794:R___ink_differential_0=R___ink_differential_0(t2792,t2793);
var t2795:u32=(t2785).ink_f_first_power;
var t2796:u32=0u;
var t2797:R___ink_differential_0=R___ink_differential_0(t2795,t2796);
var t2798:u32=(t2785).ink_f_second_power;
var t2799:u32=0u;
var t2800:R___ink_differential_0=R___ink_differential_0(t2798,t2799);
var t2801:u32=(t2785).ink_f_steps;
t2784=R___ink_differential_3(t2788,t2791,t2794,t2797,t2800,t2801);}else{
var t2802:u32=0u;
var t2803:u32=0u;
var t2804:R___ink_differential_0=R___ink_differential_0(t2802,t2803);
var t2805:u32=0u;
var t2806:u32=0u;
var t2807:R___ink_differential_0=R___ink_differential_0(t2805,t2806);
var t2808:u32=0u;
var t2809:u32=0u;
var t2810:R___ink_differential_0=R___ink_differential_0(t2808,t2809);
var t2811:u32=1065353216u;
var t2812:u32=0u;
var t2813:R___ink_differential_0=R___ink_differential_0(t2811,t2812);
var t2814:u32=1065353216u;
var t2815:u32=0u;
var t2816:R___ink_differential_0=R___ink_differential_0(t2814,t2815);
var t2817:u32=0u;
t2784=R___ink_differential_3(t2804,t2807,t2810,t2813,t2816,t2817);}
t2782=(t2784).ink_f_value;
}
var t2818:R___ink_differential_0=t2782;
var t2819:R___ink_differential_0=t2818;
for(var t2820=0u;t2820<6u;t2820++){
var t2821:R___ink_differential_0=t2819;
var t2822:R___ink_differential_0=t2774;
var t2823:u32=t2775;
var t2824:u32=t2776;
var t2825:u32=(t2824 + t2820);
var t2826:u32=t2823;
var t2827:R___ink_differential_0;
if ((t2826 == t2825)) {
t2827=t2822;
} else {
var t2828:u32=t2825;
var t2829:R___ink_differential_3;if(t2828<a0[0u]){
var t2830:R_Parameter=R_Parameter(a0[1u+(t2828)*6u+0u],a0[1u+(t2828)*6u+1u],a0[1u+(t2828)*6u+2u],a0[1u+(t2828)*6u+3u],a0[1u+(t2828)*6u+4u],a0[1u+(t2828)*6u+5u]);
var t2831:u32=(t2830).ink_f_value;
var t2832:u32=0u;
var t2833:R___ink_differential_0=R___ink_differential_0(t2831,t2832);
var t2834:u32=(t2830).ink_f_first;
var t2835:u32=0u;
var t2836:R___ink_differential_0=R___ink_differential_0(t2834,t2835);
var t2837:u32=(t2830).ink_f_second;
var t2838:u32=0u;
var t2839:R___ink_differential_0=R___ink_differential_0(t2837,t2838);
var t2840:u32=(t2830).ink_f_first_power;
var t2841:u32=0u;
var t2842:R___ink_differential_0=R___ink_differential_0(t2840,t2841);
var t2843:u32=(t2830).ink_f_second_power;
var t2844:u32=0u;
var t2845:R___ink_differential_0=R___ink_differential_0(t2843,t2844);
var t2846:u32=(t2830).ink_f_steps;
t2829=R___ink_differential_3(t2833,t2836,t2839,t2842,t2845,t2846);}else{
var t2847:u32=0u;
var t2848:u32=0u;
var t2849:R___ink_differential_0=R___ink_differential_0(t2847,t2848);
var t2850:u32=0u;
var t2851:u32=0u;
var t2852:R___ink_differential_0=R___ink_differential_0(t2850,t2851);
var t2853:u32=0u;
var t2854:u32=0u;
var t2855:R___ink_differential_0=R___ink_differential_0(t2853,t2854);
var t2856:u32=1065353216u;
var t2857:u32=0u;
var t2858:R___ink_differential_0=R___ink_differential_0(t2856,t2857);
var t2859:u32=1065353216u;
var t2860:u32=0u;
var t2861:R___ink_differential_0=R___ink_differential_0(t2859,t2860);
var t2862:u32=0u;
t2829=R___ink_differential_3(t2849,t2852,t2855,t2858,t2861,t2862);}
t2827=(t2829).ink_f_value;
}
var t2863:R___ink_differential_0=t2827;
var t2864:u32=t2820;
var t2865:R___ink_differential_0;if(t2864<6u){
t2865=t26[t2864];}else{
var t2866:u32=0u;
var t2867:u32=0u;
t2865=R___ink_differential_0(t2866,t2867);}
var t2868:R___ink_differential_0=t2865;
var t2869:u32=(t2863).ink_f_value;
var t2870:u32=ink_f32_mul(t2869,(t2868).ink_f_value);
var t2871:u32=t2870;
var t2872:u32=(t2863).ink_f_tangent;
var t2873:u32=ink_f32_mul(t2872,(t2868).ink_f_value);
var t2874:u32=(t2863).ink_f_value;
var t2875:u32=ink_f32_add(t2873,ink_f32_mul(t2874,(t2868).ink_f_tangent));
var t2876:R___ink_differential_0=R___ink_differential_0(t2871,t2875);
var t2877:u32=(t2821).ink_f_value;
var t2878:u32=ink_f32_add(t2877,(t2876).ink_f_value);
var t2879:u32=t2878;
var t2880:u32=(t2821).ink_f_tangent;
var t2881:u32=ink_f32_add(t2880,(t2876).ink_f_tangent);
t2819=R___ink_differential_0(t2879,t2881);
}
var t2882:R___ink_differential_0=t2819;
var t2883:u32=(t2882).ink_f_value;
var t2884:u32=0u;
var t2885:u32=0u;
var t2886:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t2884,t2885)).ink_f_value,t2883)) {
var t2887:R___ink_differential_0=t2773;
var t2888:R___ink_differential_0=t2882;
var t2889:u32=(t2887).ink_f_value;
var t2890:u32=ink_f32_mul(t2889,(t2888).ink_f_value);
var t2891:u32=t2890;
var t2892:u32=(t2887).ink_f_tangent;
var t2893:u32=ink_f32_mul(t2892,(t2888).ink_f_value);
var t2894:u32=(t2887).ink_f_value;
var t2895:u32=ink_f32_add(t2893,ink_f32_mul(t2894,(t2888).ink_f_tangent));
t2886=R___ink_differential_0(t2891,t2895);
} else {
var t2896:u32=0u;
var t2897:u32=0u;
t2886=R___ink_differential_0(t2896,t2897);
}
t1499[5u]=t2886;
var t2898:array<R___ink_differential_0,4>;
var t2899:R___ink_differential_0=t20;
var t2900:u32=t21;
var t2901:u32=216u;
var t2902:R___ink_differential_0=t2899;
var t2903:u32=t2900;
var t2904:u32=t2901;
var t2905:u32=(t2904 + 6u);
var t2906:u32=t2903;
var t2907:R___ink_differential_0;
if ((t2906 == t2905)) {
t2907=t2902;
} else {
var t2908:u32=t2905;
var t2909:R___ink_differential_3;if(t2908<a0[0u]){
var t2910:R_Parameter=R_Parameter(a0[1u+(t2908)*6u+0u],a0[1u+(t2908)*6u+1u],a0[1u+(t2908)*6u+2u],a0[1u+(t2908)*6u+3u],a0[1u+(t2908)*6u+4u],a0[1u+(t2908)*6u+5u]);
var t2911:u32=(t2910).ink_f_value;
var t2912:u32=0u;
var t2913:R___ink_differential_0=R___ink_differential_0(t2911,t2912);
var t2914:u32=(t2910).ink_f_first;
var t2915:u32=0u;
var t2916:R___ink_differential_0=R___ink_differential_0(t2914,t2915);
var t2917:u32=(t2910).ink_f_second;
var t2918:u32=0u;
var t2919:R___ink_differential_0=R___ink_differential_0(t2917,t2918);
var t2920:u32=(t2910).ink_f_first_power;
var t2921:u32=0u;
var t2922:R___ink_differential_0=R___ink_differential_0(t2920,t2921);
var t2923:u32=(t2910).ink_f_second_power;
var t2924:u32=0u;
var t2925:R___ink_differential_0=R___ink_differential_0(t2923,t2924);
var t2926:u32=(t2910).ink_f_steps;
t2909=R___ink_differential_3(t2913,t2916,t2919,t2922,t2925,t2926);}else{
var t2927:u32=0u;
var t2928:u32=0u;
var t2929:R___ink_differential_0=R___ink_differential_0(t2927,t2928);
var t2930:u32=0u;
var t2931:u32=0u;
var t2932:R___ink_differential_0=R___ink_differential_0(t2930,t2931);
var t2933:u32=0u;
var t2934:u32=0u;
var t2935:R___ink_differential_0=R___ink_differential_0(t2933,t2934);
var t2936:u32=1065353216u;
var t2937:u32=0u;
var t2938:R___ink_differential_0=R___ink_differential_0(t2936,t2937);
var t2939:u32=1065353216u;
var t2940:u32=0u;
var t2941:R___ink_differential_0=R___ink_differential_0(t2939,t2940);
var t2942:u32=0u;
t2909=R___ink_differential_3(t2929,t2932,t2935,t2938,t2941,t2942);}
t2907=(t2909).ink_f_value;
}
var t2943:R___ink_differential_0=t2907;
var t2944:R___ink_differential_0=t2943;
for(var t2945=0u;t2945<6u;t2945++){
var t2946:R___ink_differential_0=t2944;
var t2947:R___ink_differential_0=t2899;
var t2948:u32=t2900;
var t2949:u32=t2901;
var t2950:u32=(t2949 + t2945);
var t2951:u32=t2948;
var t2952:R___ink_differential_0;
if ((t2951 == t2950)) {
t2952=t2947;
} else {
var t2953:u32=t2950;
var t2954:R___ink_differential_3;if(t2953<a0[0u]){
var t2955:R_Parameter=R_Parameter(a0[1u+(t2953)*6u+0u],a0[1u+(t2953)*6u+1u],a0[1u+(t2953)*6u+2u],a0[1u+(t2953)*6u+3u],a0[1u+(t2953)*6u+4u],a0[1u+(t2953)*6u+5u]);
var t2956:u32=(t2955).ink_f_value;
var t2957:u32=0u;
var t2958:R___ink_differential_0=R___ink_differential_0(t2956,t2957);
var t2959:u32=(t2955).ink_f_first;
var t2960:u32=0u;
var t2961:R___ink_differential_0=R___ink_differential_0(t2959,t2960);
var t2962:u32=(t2955).ink_f_second;
var t2963:u32=0u;
var t2964:R___ink_differential_0=R___ink_differential_0(t2962,t2963);
var t2965:u32=(t2955).ink_f_first_power;
var t2966:u32=0u;
var t2967:R___ink_differential_0=R___ink_differential_0(t2965,t2966);
var t2968:u32=(t2955).ink_f_second_power;
var t2969:u32=0u;
var t2970:R___ink_differential_0=R___ink_differential_0(t2968,t2969);
var t2971:u32=(t2955).ink_f_steps;
t2954=R___ink_differential_3(t2958,t2961,t2964,t2967,t2970,t2971);}else{
var t2972:u32=0u;
var t2973:u32=0u;
var t2974:R___ink_differential_0=R___ink_differential_0(t2972,t2973);
var t2975:u32=0u;
var t2976:u32=0u;
var t2977:R___ink_differential_0=R___ink_differential_0(t2975,t2976);
var t2978:u32=0u;
var t2979:u32=0u;
var t2980:R___ink_differential_0=R___ink_differential_0(t2978,t2979);
var t2981:u32=1065353216u;
var t2982:u32=0u;
var t2983:R___ink_differential_0=R___ink_differential_0(t2981,t2982);
var t2984:u32=1065353216u;
var t2985:u32=0u;
var t2986:R___ink_differential_0=R___ink_differential_0(t2984,t2985);
var t2987:u32=0u;
t2954=R___ink_differential_3(t2974,t2977,t2980,t2983,t2986,t2987);}
t2952=(t2954).ink_f_value;
}
var t2988:R___ink_differential_0=t2952;
var t2989:u32=t2945;
var t2990:R___ink_differential_0;if(t2989<6u){
t2990=t1499[t2989];}else{
var t2991:u32=0u;
var t2992:u32=0u;
t2990=R___ink_differential_0(t2991,t2992);}
var t2993:R___ink_differential_0=t2990;
var t2994:u32=(t2988).ink_f_value;
var t2995:u32=ink_f32_mul(t2994,(t2993).ink_f_value);
var t2996:u32=t2995;
var t2997:u32=(t2988).ink_f_tangent;
var t2998:u32=ink_f32_mul(t2997,(t2993).ink_f_value);
var t2999:u32=(t2988).ink_f_value;
var t3000:u32=ink_f32_add(t2998,ink_f32_mul(t2999,(t2993).ink_f_tangent));
var t3001:R___ink_differential_0=R___ink_differential_0(t2996,t3000);
var t3002:u32=(t2946).ink_f_value;
var t3003:u32=ink_f32_add(t3002,(t3001).ink_f_value);
var t3004:u32=t3003;
var t3005:u32=(t2946).ink_f_tangent;
var t3006:u32=ink_f32_add(t3005,(t3001).ink_f_tangent);
t2944=R___ink_differential_0(t3004,t3006);
}
t2898[0u]=t2944;
var t3007:R___ink_differential_0=t20;
var t3008:u32=t21;
var t3009:u32=223u;
var t3010:R___ink_differential_0=t3007;
var t3011:u32=t3008;
var t3012:u32=t3009;
var t3013:u32=(t3012 + 6u);
var t3014:u32=t3011;
var t3015:R___ink_differential_0;
if ((t3014 == t3013)) {
t3015=t3010;
} else {
var t3016:u32=t3013;
var t3017:R___ink_differential_3;if(t3016<a0[0u]){
var t3018:R_Parameter=R_Parameter(a0[1u+(t3016)*6u+0u],a0[1u+(t3016)*6u+1u],a0[1u+(t3016)*6u+2u],a0[1u+(t3016)*6u+3u],a0[1u+(t3016)*6u+4u],a0[1u+(t3016)*6u+5u]);
var t3019:u32=(t3018).ink_f_value;
var t3020:u32=0u;
var t3021:R___ink_differential_0=R___ink_differential_0(t3019,t3020);
var t3022:u32=(t3018).ink_f_first;
var t3023:u32=0u;
var t3024:R___ink_differential_0=R___ink_differential_0(t3022,t3023);
var t3025:u32=(t3018).ink_f_second;
var t3026:u32=0u;
var t3027:R___ink_differential_0=R___ink_differential_0(t3025,t3026);
var t3028:u32=(t3018).ink_f_first_power;
var t3029:u32=0u;
var t3030:R___ink_differential_0=R___ink_differential_0(t3028,t3029);
var t3031:u32=(t3018).ink_f_second_power;
var t3032:u32=0u;
var t3033:R___ink_differential_0=R___ink_differential_0(t3031,t3032);
var t3034:u32=(t3018).ink_f_steps;
t3017=R___ink_differential_3(t3021,t3024,t3027,t3030,t3033,t3034);}else{
var t3035:u32=0u;
var t3036:u32=0u;
var t3037:R___ink_differential_0=R___ink_differential_0(t3035,t3036);
var t3038:u32=0u;
var t3039:u32=0u;
var t3040:R___ink_differential_0=R___ink_differential_0(t3038,t3039);
var t3041:u32=0u;
var t3042:u32=0u;
var t3043:R___ink_differential_0=R___ink_differential_0(t3041,t3042);
var t3044:u32=1065353216u;
var t3045:u32=0u;
var t3046:R___ink_differential_0=R___ink_differential_0(t3044,t3045);
var t3047:u32=1065353216u;
var t3048:u32=0u;
var t3049:R___ink_differential_0=R___ink_differential_0(t3047,t3048);
var t3050:u32=0u;
t3017=R___ink_differential_3(t3037,t3040,t3043,t3046,t3049,t3050);}
t3015=(t3017).ink_f_value;
}
var t3051:R___ink_differential_0=t3015;
var t3052:R___ink_differential_0=t3051;
for(var t3053=0u;t3053<6u;t3053++){
var t3054:R___ink_differential_0=t3052;
var t3055:R___ink_differential_0=t3007;
var t3056:u32=t3008;
var t3057:u32=t3009;
var t3058:u32=(t3057 + t3053);
var t3059:u32=t3056;
var t3060:R___ink_differential_0;
if ((t3059 == t3058)) {
t3060=t3055;
} else {
var t3061:u32=t3058;
var t3062:R___ink_differential_3;if(t3061<a0[0u]){
var t3063:R_Parameter=R_Parameter(a0[1u+(t3061)*6u+0u],a0[1u+(t3061)*6u+1u],a0[1u+(t3061)*6u+2u],a0[1u+(t3061)*6u+3u],a0[1u+(t3061)*6u+4u],a0[1u+(t3061)*6u+5u]);
var t3064:u32=(t3063).ink_f_value;
var t3065:u32=0u;
var t3066:R___ink_differential_0=R___ink_differential_0(t3064,t3065);
var t3067:u32=(t3063).ink_f_first;
var t3068:u32=0u;
var t3069:R___ink_differential_0=R___ink_differential_0(t3067,t3068);
var t3070:u32=(t3063).ink_f_second;
var t3071:u32=0u;
var t3072:R___ink_differential_0=R___ink_differential_0(t3070,t3071);
var t3073:u32=(t3063).ink_f_first_power;
var t3074:u32=0u;
var t3075:R___ink_differential_0=R___ink_differential_0(t3073,t3074);
var t3076:u32=(t3063).ink_f_second_power;
var t3077:u32=0u;
var t3078:R___ink_differential_0=R___ink_differential_0(t3076,t3077);
var t3079:u32=(t3063).ink_f_steps;
t3062=R___ink_differential_3(t3066,t3069,t3072,t3075,t3078,t3079);}else{
var t3080:u32=0u;
var t3081:u32=0u;
var t3082:R___ink_differential_0=R___ink_differential_0(t3080,t3081);
var t3083:u32=0u;
var t3084:u32=0u;
var t3085:R___ink_differential_0=R___ink_differential_0(t3083,t3084);
var t3086:u32=0u;
var t3087:u32=0u;
var t3088:R___ink_differential_0=R___ink_differential_0(t3086,t3087);
var t3089:u32=1065353216u;
var t3090:u32=0u;
var t3091:R___ink_differential_0=R___ink_differential_0(t3089,t3090);
var t3092:u32=1065353216u;
var t3093:u32=0u;
var t3094:R___ink_differential_0=R___ink_differential_0(t3092,t3093);
var t3095:u32=0u;
t3062=R___ink_differential_3(t3082,t3085,t3088,t3091,t3094,t3095);}
t3060=(t3062).ink_f_value;
}
var t3096:R___ink_differential_0=t3060;
var t3097:u32=t3053;
var t3098:R___ink_differential_0;if(t3097<6u){
t3098=t1499[t3097];}else{
var t3099:u32=0u;
var t3100:u32=0u;
t3098=R___ink_differential_0(t3099,t3100);}
var t3101:R___ink_differential_0=t3098;
var t3102:u32=(t3096).ink_f_value;
var t3103:u32=ink_f32_mul(t3102,(t3101).ink_f_value);
var t3104:u32=t3103;
var t3105:u32=(t3096).ink_f_tangent;
var t3106:u32=ink_f32_mul(t3105,(t3101).ink_f_value);
var t3107:u32=(t3096).ink_f_value;
var t3108:u32=ink_f32_add(t3106,ink_f32_mul(t3107,(t3101).ink_f_tangent));
var t3109:R___ink_differential_0=R___ink_differential_0(t3104,t3108);
var t3110:u32=(t3054).ink_f_value;
var t3111:u32=ink_f32_add(t3110,(t3109).ink_f_value);
var t3112:u32=t3111;
var t3113:u32=(t3054).ink_f_tangent;
var t3114:u32=ink_f32_add(t3113,(t3109).ink_f_tangent);
t3052=R___ink_differential_0(t3112,t3114);
}
t2898[1u]=t3052;
var t3115:R___ink_differential_0=t20;
var t3116:u32=t21;
var t3117:u32=230u;
var t3118:R___ink_differential_0=t3115;
var t3119:u32=t3116;
var t3120:u32=t3117;
var t3121:u32=(t3120 + 6u);
var t3122:u32=t3119;
var t3123:R___ink_differential_0;
if ((t3122 == t3121)) {
t3123=t3118;
} else {
var t3124:u32=t3121;
var t3125:R___ink_differential_3;if(t3124<a0[0u]){
var t3126:R_Parameter=R_Parameter(a0[1u+(t3124)*6u+0u],a0[1u+(t3124)*6u+1u],a0[1u+(t3124)*6u+2u],a0[1u+(t3124)*6u+3u],a0[1u+(t3124)*6u+4u],a0[1u+(t3124)*6u+5u]);
var t3127:u32=(t3126).ink_f_value;
var t3128:u32=0u;
var t3129:R___ink_differential_0=R___ink_differential_0(t3127,t3128);
var t3130:u32=(t3126).ink_f_first;
var t3131:u32=0u;
var t3132:R___ink_differential_0=R___ink_differential_0(t3130,t3131);
var t3133:u32=(t3126).ink_f_second;
var t3134:u32=0u;
var t3135:R___ink_differential_0=R___ink_differential_0(t3133,t3134);
var t3136:u32=(t3126).ink_f_first_power;
var t3137:u32=0u;
var t3138:R___ink_differential_0=R___ink_differential_0(t3136,t3137);
var t3139:u32=(t3126).ink_f_second_power;
var t3140:u32=0u;
var t3141:R___ink_differential_0=R___ink_differential_0(t3139,t3140);
var t3142:u32=(t3126).ink_f_steps;
t3125=R___ink_differential_3(t3129,t3132,t3135,t3138,t3141,t3142);}else{
var t3143:u32=0u;
var t3144:u32=0u;
var t3145:R___ink_differential_0=R___ink_differential_0(t3143,t3144);
var t3146:u32=0u;
var t3147:u32=0u;
var t3148:R___ink_differential_0=R___ink_differential_0(t3146,t3147);
var t3149:u32=0u;
var t3150:u32=0u;
var t3151:R___ink_differential_0=R___ink_differential_0(t3149,t3150);
var t3152:u32=1065353216u;
var t3153:u32=0u;
var t3154:R___ink_differential_0=R___ink_differential_0(t3152,t3153);
var t3155:u32=1065353216u;
var t3156:u32=0u;
var t3157:R___ink_differential_0=R___ink_differential_0(t3155,t3156);
var t3158:u32=0u;
t3125=R___ink_differential_3(t3145,t3148,t3151,t3154,t3157,t3158);}
t3123=(t3125).ink_f_value;
}
var t3159:R___ink_differential_0=t3123;
var t3160:R___ink_differential_0=t3159;
for(var t3161=0u;t3161<6u;t3161++){
var t3162:R___ink_differential_0=t3160;
var t3163:R___ink_differential_0=t3115;
var t3164:u32=t3116;
var t3165:u32=t3117;
var t3166:u32=(t3165 + t3161);
var t3167:u32=t3164;
var t3168:R___ink_differential_0;
if ((t3167 == t3166)) {
t3168=t3163;
} else {
var t3169:u32=t3166;
var t3170:R___ink_differential_3;if(t3169<a0[0u]){
var t3171:R_Parameter=R_Parameter(a0[1u+(t3169)*6u+0u],a0[1u+(t3169)*6u+1u],a0[1u+(t3169)*6u+2u],a0[1u+(t3169)*6u+3u],a0[1u+(t3169)*6u+4u],a0[1u+(t3169)*6u+5u]);
var t3172:u32=(t3171).ink_f_value;
var t3173:u32=0u;
var t3174:R___ink_differential_0=R___ink_differential_0(t3172,t3173);
var t3175:u32=(t3171).ink_f_first;
var t3176:u32=0u;
var t3177:R___ink_differential_0=R___ink_differential_0(t3175,t3176);
var t3178:u32=(t3171).ink_f_second;
var t3179:u32=0u;
var t3180:R___ink_differential_0=R___ink_differential_0(t3178,t3179);
var t3181:u32=(t3171).ink_f_first_power;
var t3182:u32=0u;
var t3183:R___ink_differential_0=R___ink_differential_0(t3181,t3182);
var t3184:u32=(t3171).ink_f_second_power;
var t3185:u32=0u;
var t3186:R___ink_differential_0=R___ink_differential_0(t3184,t3185);
var t3187:u32=(t3171).ink_f_steps;
t3170=R___ink_differential_3(t3174,t3177,t3180,t3183,t3186,t3187);}else{
var t3188:u32=0u;
var t3189:u32=0u;
var t3190:R___ink_differential_0=R___ink_differential_0(t3188,t3189);
var t3191:u32=0u;
var t3192:u32=0u;
var t3193:R___ink_differential_0=R___ink_differential_0(t3191,t3192);
var t3194:u32=0u;
var t3195:u32=0u;
var t3196:R___ink_differential_0=R___ink_differential_0(t3194,t3195);
var t3197:u32=1065353216u;
var t3198:u32=0u;
var t3199:R___ink_differential_0=R___ink_differential_0(t3197,t3198);
var t3200:u32=1065353216u;
var t3201:u32=0u;
var t3202:R___ink_differential_0=R___ink_differential_0(t3200,t3201);
var t3203:u32=0u;
t3170=R___ink_differential_3(t3190,t3193,t3196,t3199,t3202,t3203);}
t3168=(t3170).ink_f_value;
}
var t3204:R___ink_differential_0=t3168;
var t3205:u32=t3161;
var t3206:R___ink_differential_0;if(t3205<6u){
t3206=t1499[t3205];}else{
var t3207:u32=0u;
var t3208:u32=0u;
t3206=R___ink_differential_0(t3207,t3208);}
var t3209:R___ink_differential_0=t3206;
var t3210:u32=(t3204).ink_f_value;
var t3211:u32=ink_f32_mul(t3210,(t3209).ink_f_value);
var t3212:u32=t3211;
var t3213:u32=(t3204).ink_f_tangent;
var t3214:u32=ink_f32_mul(t3213,(t3209).ink_f_value);
var t3215:u32=(t3204).ink_f_value;
var t3216:u32=ink_f32_add(t3214,ink_f32_mul(t3215,(t3209).ink_f_tangent));
var t3217:R___ink_differential_0=R___ink_differential_0(t3212,t3216);
var t3218:u32=(t3162).ink_f_value;
var t3219:u32=ink_f32_add(t3218,(t3217).ink_f_value);
var t3220:u32=t3219;
var t3221:u32=(t3162).ink_f_tangent;
var t3222:u32=ink_f32_add(t3221,(t3217).ink_f_tangent);
t3160=R___ink_differential_0(t3220,t3222);
}
t2898[2u]=t3160;
var t3223:R___ink_differential_0=t20;
var t3224:u32=t21;
var t3225:u32=237u;
var t3226:R___ink_differential_0=t3223;
var t3227:u32=t3224;
var t3228:u32=t3225;
var t3229:u32=(t3228 + 6u);
var t3230:u32=t3227;
var t3231:R___ink_differential_0;
if ((t3230 == t3229)) {
t3231=t3226;
} else {
var t3232:u32=t3229;
var t3233:R___ink_differential_3;if(t3232<a0[0u]){
var t3234:R_Parameter=R_Parameter(a0[1u+(t3232)*6u+0u],a0[1u+(t3232)*6u+1u],a0[1u+(t3232)*6u+2u],a0[1u+(t3232)*6u+3u],a0[1u+(t3232)*6u+4u],a0[1u+(t3232)*6u+5u]);
var t3235:u32=(t3234).ink_f_value;
var t3236:u32=0u;
var t3237:R___ink_differential_0=R___ink_differential_0(t3235,t3236);
var t3238:u32=(t3234).ink_f_first;
var t3239:u32=0u;
var t3240:R___ink_differential_0=R___ink_differential_0(t3238,t3239);
var t3241:u32=(t3234).ink_f_second;
var t3242:u32=0u;
var t3243:R___ink_differential_0=R___ink_differential_0(t3241,t3242);
var t3244:u32=(t3234).ink_f_first_power;
var t3245:u32=0u;
var t3246:R___ink_differential_0=R___ink_differential_0(t3244,t3245);
var t3247:u32=(t3234).ink_f_second_power;
var t3248:u32=0u;
var t3249:R___ink_differential_0=R___ink_differential_0(t3247,t3248);
var t3250:u32=(t3234).ink_f_steps;
t3233=R___ink_differential_3(t3237,t3240,t3243,t3246,t3249,t3250);}else{
var t3251:u32=0u;
var t3252:u32=0u;
var t3253:R___ink_differential_0=R___ink_differential_0(t3251,t3252);
var t3254:u32=0u;
var t3255:u32=0u;
var t3256:R___ink_differential_0=R___ink_differential_0(t3254,t3255);
var t3257:u32=0u;
var t3258:u32=0u;
var t3259:R___ink_differential_0=R___ink_differential_0(t3257,t3258);
var t3260:u32=1065353216u;
var t3261:u32=0u;
var t3262:R___ink_differential_0=R___ink_differential_0(t3260,t3261);
var t3263:u32=1065353216u;
var t3264:u32=0u;
var t3265:R___ink_differential_0=R___ink_differential_0(t3263,t3264);
var t3266:u32=0u;
t3233=R___ink_differential_3(t3253,t3256,t3259,t3262,t3265,t3266);}
t3231=(t3233).ink_f_value;
}
var t3267:R___ink_differential_0=t3231;
var t3268:R___ink_differential_0=t3267;
for(var t3269=0u;t3269<6u;t3269++){
var t3270:R___ink_differential_0=t3268;
var t3271:R___ink_differential_0=t3223;
var t3272:u32=t3224;
var t3273:u32=t3225;
var t3274:u32=(t3273 + t3269);
var t3275:u32=t3272;
var t3276:R___ink_differential_0;
if ((t3275 == t3274)) {
t3276=t3271;
} else {
var t3277:u32=t3274;
var t3278:R___ink_differential_3;if(t3277<a0[0u]){
var t3279:R_Parameter=R_Parameter(a0[1u+(t3277)*6u+0u],a0[1u+(t3277)*6u+1u],a0[1u+(t3277)*6u+2u],a0[1u+(t3277)*6u+3u],a0[1u+(t3277)*6u+4u],a0[1u+(t3277)*6u+5u]);
var t3280:u32=(t3279).ink_f_value;
var t3281:u32=0u;
var t3282:R___ink_differential_0=R___ink_differential_0(t3280,t3281);
var t3283:u32=(t3279).ink_f_first;
var t3284:u32=0u;
var t3285:R___ink_differential_0=R___ink_differential_0(t3283,t3284);
var t3286:u32=(t3279).ink_f_second;
var t3287:u32=0u;
var t3288:R___ink_differential_0=R___ink_differential_0(t3286,t3287);
var t3289:u32=(t3279).ink_f_first_power;
var t3290:u32=0u;
var t3291:R___ink_differential_0=R___ink_differential_0(t3289,t3290);
var t3292:u32=(t3279).ink_f_second_power;
var t3293:u32=0u;
var t3294:R___ink_differential_0=R___ink_differential_0(t3292,t3293);
var t3295:u32=(t3279).ink_f_steps;
t3278=R___ink_differential_3(t3282,t3285,t3288,t3291,t3294,t3295);}else{
var t3296:u32=0u;
var t3297:u32=0u;
var t3298:R___ink_differential_0=R___ink_differential_0(t3296,t3297);
var t3299:u32=0u;
var t3300:u32=0u;
var t3301:R___ink_differential_0=R___ink_differential_0(t3299,t3300);
var t3302:u32=0u;
var t3303:u32=0u;
var t3304:R___ink_differential_0=R___ink_differential_0(t3302,t3303);
var t3305:u32=1065353216u;
var t3306:u32=0u;
var t3307:R___ink_differential_0=R___ink_differential_0(t3305,t3306);
var t3308:u32=1065353216u;
var t3309:u32=0u;
var t3310:R___ink_differential_0=R___ink_differential_0(t3308,t3309);
var t3311:u32=0u;
t3278=R___ink_differential_3(t3298,t3301,t3304,t3307,t3310,t3311);}
t3276=(t3278).ink_f_value;
}
var t3312:R___ink_differential_0=t3276;
var t3313:u32=t3269;
var t3314:R___ink_differential_0;if(t3313<6u){
t3314=t1499[t3313];}else{
var t3315:u32=0u;
var t3316:u32=0u;
t3314=R___ink_differential_0(t3315,t3316);}
var t3317:R___ink_differential_0=t3314;
var t3318:u32=(t3312).ink_f_value;
var t3319:u32=ink_f32_mul(t3318,(t3317).ink_f_value);
var t3320:u32=t3319;
var t3321:u32=(t3312).ink_f_tangent;
var t3322:u32=ink_f32_mul(t3321,(t3317).ink_f_value);
var t3323:u32=(t3312).ink_f_value;
var t3324:u32=ink_f32_add(t3322,ink_f32_mul(t3323,(t3317).ink_f_tangent));
var t3325:R___ink_differential_0=R___ink_differential_0(t3320,t3324);
var t3326:u32=(t3270).ink_f_value;
var t3327:u32=ink_f32_add(t3326,(t3325).ink_f_value);
var t3328:u32=t3327;
var t3329:u32=(t3270).ink_f_tangent;
var t3330:u32=ink_f32_add(t3329,(t3325).ink_f_tangent);
t3268=R___ink_differential_0(t3328,t3330);
}
t2898[3u]=t3268;
var t3331:u32=0u;
var t3332:u32=0u;
var t3333:R___ink_differential_0=R___ink_differential_0(t3331,t3332);
for(var t3334=0u;t3334<4u;t3334++){
var t3335:R___ink_differential_0=t3333;
var t3336:u32=t3334;
var t3337:R___ink_differential_0;if(t3336<4u){
t3337=t2898[t3336];}else{
var t3338:u32=0u;
var t3339:u32=0u;
t3337=R___ink_differential_0(t3338,t3339);}
var t3340:R___ink_differential_0=t3337;
var t3341:u32=t19;
var t3342:u32=(t3341 * 4u);
var t3343:u32=(t3342 + t3334);
var t3344:R___ink_differential_0;if(t3343<a2[0u]){
var t3345:u32=a2[1u+(t3343)*1u+0u];
var t3346:u32=t3345;
var t3347:u32=0u;
t3344=R___ink_differential_0(t3346,t3347);}else{
var t3348:u32=0u;
var t3349:u32=0u;
t3344=R___ink_differential_0(t3348,t3349);}
var t3350:R___ink_differential_0=t3344;
var t3351:R___ink_differential_0=t3340;
var t3352:R___ink_differential_0=t3350;
var t3353:u32=(t3351).ink_f_value;
var t3354:u32=ink_f32_sub(t3353,(t3352).ink_f_value);
var t3355:u32=t3354;
var t3356:u32=(t3351).ink_f_tangent;
var t3357:u32=ink_f32_sub(t3356,(t3352).ink_f_tangent);
var t3358:R___ink_differential_0=R___ink_differential_0(t3355,t3357);
var t3359:R___ink_differential_0=t3358;
var t3360:R___ink_differential_0=t3358;
var t3361:u32=(t3359).ink_f_value;
var t3362:u32=ink_f32_mul(t3361,(t3360).ink_f_value);
var t3363:u32=t3362;
var t3364:u32=(t3359).ink_f_tangent;
var t3365:u32=ink_f32_mul(t3364,(t3360).ink_f_value);
var t3366:u32=(t3359).ink_f_value;
var t3367:u32=ink_f32_add(t3365,ink_f32_mul(t3366,(t3360).ink_f_tangent));
var t3368:R___ink_differential_0=R___ink_differential_0(t3363,t3367);
var t3369:u32=(t3335).ink_f_value;
var t3370:u32=ink_f32_add(t3369,(t3368).ink_f_value);
var t3371:u32=t3370;
var t3372:u32=(t3335).ink_f_tangent;
var t3373:u32=ink_f32_add(t3372,(t3368).ink_f_tangent);
t3333=R___ink_differential_0(t3371,t3373);
}
var t3374:R___ink_differential_0=t3333;
var t3375:R___ink_differential_0=t3374;
var t3376:u32=1082130432u;
var t3377:u32=0u;
var t3378:R___ink_differential_0=R___ink_differential_0(t3376,t3377);
var t3379:u32=ink_f32_div((t3375).ink_f_value,(t3378).ink_f_value);
var t3380:u32=t3379;
var t3381:u32=(t3375).ink_f_tangent;
var t3382:u32=ink_f32_mul(t3381,(t3378).ink_f_value);
var t3383:u32=(t3375).ink_f_value;
var t3384:u32=(t3378).ink_f_value;
var t3385:u32=ink_f32_div(ink_f32_sub(t3382,ink_f32_mul(t3383,(t3378).ink_f_tangent)),ink_f32_mul(t3384,(t3378).ink_f_value));
var t3386:R___ink_differential_0=R___ink_differential_0(t3380,t3385);
t7=ink_f32_add(t11,(t3386).ink_f_tangent);}
t3=ink_f32_div(t7,ink_f32_from_u64(InkU64(a3[0u],0u)));}
var t3387:u32=t3;
output[1u+i*1u+0u]=bitcast<u32>(t3387);


}