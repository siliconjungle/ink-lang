module StateFloat;
record Packet {x:f32,values:List<f32>,pair:Vec2<f32>,maybe:Option<f32>,outcome:Result<f32,Option<f32>>,wide:f64,}
state Rows:Table<u32,Packet>=Table.empty();
event saved:Packet;
event scalar:f32;
fn copy(p:Packet)->Packet{return p;}
fn arithmetic(x:f32,y:f32)->f32{let a=x*y;let b=a+x;return (b-a)*y;}
fn parallel(xs:List<f32>)->List<f32>{return parallel_map(xs,1,fn(i)=>fn(x)=>-x);}
fn device(xs:List<f32>)->List<f32>{return xs.map(fn(x)=>x*2.0+1.0);}
keep cached:List<Packet>=Rows.values().map(fn(p)=>copy(p));
query read()->List<Packet> reads(cached){return cached;}
query direct(x:f32)->f32{return x;}
query via(x:f32,y:f32)->f32{return arithmetic(x,y);}
query workers(xs:List<f32>)->List<f32>{return parallel(xs);}
change put(p:Packet,fail:Bool)->Result<Packet,String> reads(cached) writes(Rows) emits(saved){
 let value=copy(p);Rows.put(0,value);let seen=read();emit saved(copy(value));
 if fail{return Err("rollback");}return Ok(copy(value));
}
change remember(x:f32)->f32 emits(scalar){emit scalar(x);return arithmetic(x,1.0);}
