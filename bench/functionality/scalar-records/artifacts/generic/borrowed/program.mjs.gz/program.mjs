const __recordElisions=new Set([]);
const __nativeF32=true;
// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
// Binary64 uses native Numbers for finite arithmetic and immutable private
// tags only where a NaN's exact payload must survive non-arithmetic operations.
const __doubleView=new DataView(new ArrayBuffer(8));
const __double=bits=>{__doubleView.setBigUint64(0,bits,true);return __doubleView.getFloat64(0,true);};
const __doubleBits=number=>{if(Number.isNaN(number))return 0x7ff8000000000000n;__doubleView.setFloat64(0,number,true);return __doubleView.getBigUint64(0,true);};
const __dfNumber=value=>typeof value==='number'?value:__double(BigInt(value.F64Bits));
const __dfBits=value=>typeof value==='number'?__doubleBits(value):BigInt(value.F64Bits);
const __dfFromBits=bits=>(bits&0x7fffffffffffffffn)>0x7ff0000000000000n?Object.freeze({F64Bits:bits.toString()}):__double(bits);
const __dfInput=value=>typeof value==='number'?value:__dfFromBits(BigInt(value.F64Bits));
const __dfNeg=value=>typeof value==='number'&&!Number.isNaN(value)?-value:__dfFromBits(__dfBits(value)^0x8000000000000000n);
const __dfOutput=value=>{const n=__dfNumber(value);return Number.isFinite(n)?n:{F64Bits:__dfBits(value).toString()};};
const __dfCapture=value=>{
 if(typeof value==='number'&&Number.isFinite(value))return value;
 if(!value||typeof value!=='object'||Object.keys(value).length!==1||!Object.hasOwn(value,'F64Bits'))throw Error('invalid f64');const text=value.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid f64');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');return __dfFromBits(bits);
};
// Native binary32 lane for pure modules. Explicit NaN payloads remain tagged;
// arithmetic canonicalizes NaNs just as __bits does in the exact-bit lane.
// Host tags are captured once at a typed read. Only private immutable tags
// may pass through normalization without consulting a host property again.
const __nfTagged = new WeakSet();
const __nfValue = value => typeof value === 'number' ? Math.fround(value) : __nfTagged.has(value) ? value : __nfFromBits(value.F32Bits);
// Number operands have already been normalised at their typed read or producer.
const __nfNumber = value => typeof value === 'number' ? value : __float(value.F32Bits);
const __nfBits = value => typeof value === 'number' ? __bits(value) : value.F32Bits;
const __nfFromBits = bits => {
  if((bits & 0x7fffffff)<=0x7f800000)return __float(bits);
  const value=Object.freeze({F32Bits:bits});__nfTagged.add(value);return value;
};
const __nfNeg = value => typeof value === 'number' && !Number.isNaN(value) ? -value : __nfFromBits((__nfBits(value) ^ 0x80000000) >>> 0);
const __nfOutput = value => {const n=typeof value==='number'?Math.fround(value):__float(value.F32Bits);return Number.isFinite(n)?n:{F32Bits:__nfBits(value)};};
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output, capture=false) {
  const convert=__representationRaw(type,output,capture);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':capture?'capture:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output, capture) {
  switch (type.kind) {
    case 'ref': {
      let resolved;
      return (value,context)=>(resolved??=__representation(__namedTypes[type.name],output,capture))(value,context);
    }
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output,capture);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output,capture),err=__representation(type.error,output,capture);
      const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);
      if(flat)return output?(value,context)=>{const v=__sumView(key,value);return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};}:(v,context)=>Object.hasOwn(v,'Ok')?__sumMake(key,true,ok(v.Ok,context)):__sumMake(key,false,err(v.Err,context));
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f64':return output?__dfOutput:__dfInput;
    case 'f32': if(typeof __nativeF32!=='undefined'&&__nativeF32)return output?__nfOutput:capture?__nfValue:__identity;
      return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output,capture);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){
        if(!type.fields.length)return ()=>undefined; // lexically unconsumed projected input
        const field=type.fields[0],child=__representation(field.type,output,capture);
        return output?(value,context)=>({[field.name]:child(value,context)}):(value,context)=>child(value[field.name],context);
      }
      const fields = type.fields.map(field => [field.name, __representation(field.type, output,capture)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
function __fn0(v0,v1){
v1=__nfValue(v1);
const v2=__nfValue(v0["a"]);
const v3=Math.fround(__nfNumber(v2) - __nfNumber(v1));
const v4=__nfValue(v0["b"]);
const v5=Math.fround(__nfNumber(v4) + __nfNumber(v1));
const v6=Math.fround(v3 * v3);
const v7=Math.fround(v5 * v5);
return Math.fround(v6 + v7);}
function __fn1(v8,v9){
v9=__nfValue(v9);
const v10=v8["p"];
const v11=__nfValue(v10["a"]);
const v12=Math.fround(__nfNumber(v11) - __nfNumber(v9));
const v13=v8["p"];
const v14=__nfValue(v13["b"]);
const v15=Math.fround(__nfNumber(v14) + __nfNumber(v9));
const v16=v8["q"];
const v17=__nfValue(v16["a"]);
const v18=Math.fround(__nfNumber(v17) - __nfNumber(v9));
const v19=v8["q"];
const v20=__nfValue(v19["b"]);
const v21=Math.fround(__nfNumber(v20) + __nfNumber(v9));
const v22=v8["r"];
const v23=__nfValue(v22["a"]);
const v24=Math.fround(__nfNumber(v23) - __nfNumber(v9));
const v25=v8["r"];
const v26=__nfValue(v25["b"]);
const v27=Math.fround(__nfNumber(v26) + __nfNumber(v9));
const v28=v8["s"];
const v29=__nfValue(v28["a"]);
const v30=Math.fround(__nfNumber(v29) - __nfNumber(v9));
const v31=v8["s"];
const v32=__nfValue(v31["b"]);
const v33=Math.fround(__nfNumber(v32) + __nfNumber(v9));
const v34=v8["t"];
const v35=__nfValue(v34["a"]);
const v36=Math.fround(__nfNumber(v35) - __nfNumber(v9));
const v37=v8["t"];
const v38=__nfValue(v37["b"]);
const v39=Math.fround(__nfNumber(v38) + __nfNumber(v9));
const v40=v8["u"];
const v41=__nfValue(v40["a"]);
const v42=Math.fround(__nfNumber(v41) - __nfNumber(v9));
const v43=v8["u"];
const v44=__nfValue(v43["b"]);
const v45=Math.fround(__nfNumber(v44) + __nfNumber(v9));
const v46=Math.fround(v12 * v12);
const v47=Math.fround(v15 * v15);
const v48=Math.fround(v46 + v47);
const v49=Math.fround(v18 * v18);
const v50=Math.fround(v48 + v49);
const v51=Math.fround(v21 * v21);
const v52=Math.fround(v50 + v51);
const v53=Math.fround(v24 * v24);
const v54=Math.fround(v52 + v53);
const v55=Math.fround(v27 * v27);
const v56=Math.fround(v54 + v55);
const v57=Math.fround(v30 * v30);
const v58=Math.fround(v56 + v57);
const v59=Math.fround(v33 * v33);
const v60=Math.fround(v58 + v59);
const v61=Math.fround(v36 * v36);
const v62=Math.fround(v60 + v61);
const v63=Math.fround(v39 * v39);
const v64=Math.fround(v62 + v63);
const v65=Math.fround(v42 * v42);
const v66=Math.fround(v64 + v65);
const v67=Math.fround(v45 * v45);
return Math.fround(v66 + v67);}
function __fn2(v68,v69){
v69=__nfValue(v69);
return __fn12(v68,v69);}
function __fn3(v70,v71){
v71=__nfValue(v71);
return __fn17(v70,v70,v71);}
function __fn4(v72){
const v73=__nfValue(v72["a"]);
const v74=__nfValue(v72["a"]);
const v75=Math.fround(__nfNumber(v73) * __nfNumber(v74));
const v76=__nfValue(v72["a"]);
const v77=__nfValue(v72["a"]);
const v78=Math.fround(__nfNumber(v76) * __nfNumber(v77));
return Math.fround(v75 + v78);}
function __fn5(v79,v80){
let v81;if(v80){
const v82=__nfValue(v79["b"]);
const v83=__nfValue(v79["b"]);
const v84=Math.fround(__nfNumber(v82) * __nfNumber(v83));
const v85=__nfValue(v79["a"]);
const v86=__nfValue(v79["a"]);
const v87=Math.fround(__nfNumber(v85) * __nfNumber(v86));
v81=({["a"]:v84,["b"]:v87});}else{
const v88=__nfValue(v79["a"]);
const v89=__nfValue(v79["a"]);
const v90=Math.fround(__nfNumber(v88) * __nfNumber(v89));
const v91=__nfValue(v79["b"]);
const v92=__nfValue(v79["b"]);
const v93=Math.fround(__nfNumber(v91) * __nfNumber(v92));
v81=({["a"]:v90,["b"]:v93});}
return v81;}
function __fn6(v94,v95){
v94=__nfValue(v94);
const v96=__nfNeg(v94);
let v99;
let v100;
if(v95){
const v101=Math.fround(__nfNumber(v96) * __nfNumber(v96));
const v102=Math.fround(__nfNumber(v94) * __nfNumber(v94));
v99=v101;
v100=v102;
}else{
const v103=Math.fround(__nfNumber(v94) * __nfNumber(v94));
const v104=Math.fround(__nfNumber(v96) * __nfNumber(v96));
v99=v103;
v100=v104;
}
return ({["a"]:v99,["b"]:v100});}
function __fn7(v105){
v105=__nfValue(v105);
const v106=__nfNeg(v105);
let v107=v105;
let v108=v106;
for(let v110=0;v110<3;v110++){
const v111=(v110>>>0);
const v112=__nfValue(v108);
const v113=__nfValue(v107);
v107=v112;
v108=v113;
}
return ({["a"]:v107,["b"]:v108});}
function __fn8(v114){
const v115=__nfValue(v114["b"]);
const v116=__nfValue(v114["b"]);
const v117=Math.fround(__nfNumber(v115) * __nfNumber(v116));
return __nfValue(v114["a"]);}
function __fn9(v118,v119){
v118=__nfValue(v118);
v119=__nfValue(v119);
const v121=Math.fround(__nfNumber(v119) * __nfNumber(v119));
return v118;}
function __fn10(v122){
const v123=({None:null});
let v124=v122;
let v125=v123;
for(let v127=0;v127<3;v127++){
const v128=(v127>>>0);
const v129=v124;
const v130=1;
const v131=(((v129) + (v130)) >>> 0);
const v132=v124;
const v133=v125;
const v135=({Some:({["value"]:v132,["previous"]:v133})});
v124=v131;
v125=v135;
}
return ({["value"]:v124,["previous"]:v125});}
function __fn11(v136,v137){
const v138=v136["p"];
const v139=v138["a"];
const v140=__nfValue(v139["value"]);
const v141=__nfValue(v137["value"]);
const v142=Math.fround(__nfNumber(v140) - __nfNumber(v141));
const v143=__nfValue(v139["tangent_0"]);
const v144=__nfValue(v137["tangent_0"]);
const v145=Math.fround(__nfNumber(v143) - __nfNumber(v144));
const v146=__nfValue(v139["tangent_1"]);
const v147=__nfValue(v137["tangent_1"]);
const v148=Math.fround(__nfNumber(v146) - __nfNumber(v147));
const v149=__nfValue(v139["tangent_2"]);
const v150=__nfValue(v137["tangent_2"]);
const v151=Math.fround(__nfNumber(v149) - __nfNumber(v150));
const v152=__nfValue(v139["tangent_3"]);
const v153=__nfValue(v137["tangent_3"]);
const v154=Math.fround(__nfNumber(v152) - __nfNumber(v153));
const v155=__nfValue(v139["tangent_4"]);
const v156=__nfValue(v137["tangent_4"]);
const v157=Math.fround(__nfNumber(v155) - __nfNumber(v156));
const v158=__nfValue(v139["tangent_5"]);
const v159=__nfValue(v137["tangent_5"]);
const v160=Math.fround(__nfNumber(v158) - __nfNumber(v159));
const v161=__nfValue(v139["tangent_6"]);
const v162=__nfValue(v137["tangent_6"]);
const v163=Math.fround(__nfNumber(v161) - __nfNumber(v162));
const v164=__nfValue(v139["tangent_7"]);
const v165=__nfValue(v137["tangent_7"]);
const v166=Math.fround(__nfNumber(v164) - __nfNumber(v165));
const v167=__nfValue(v139["tangent_8"]);
const v168=__nfValue(v137["tangent_8"]);
const v169=Math.fround(__nfNumber(v167) - __nfNumber(v168));
const v170=__nfValue(v139["tangent_9"]);
const v171=__nfValue(v137["tangent_9"]);
const v172=Math.fround(__nfNumber(v170) - __nfNumber(v171));
const v173=__nfValue(v139["tangent_10"]);
const v174=__nfValue(v137["tangent_10"]);
const v175=Math.fround(__nfNumber(v173) - __nfNumber(v174));
const v176=__nfValue(v139["tangent_11"]);
const v177=__nfValue(v137["tangent_11"]);
const v178=Math.fround(__nfNumber(v176) - __nfNumber(v177));
const v180=v136["p"];
const v181=v180["b"];
const v182=__nfValue(v181["value"]);
const v183=__nfValue(v137["value"]);
const v184=Math.fround(__nfNumber(v182) + __nfNumber(v183));
const v185=__nfValue(v181["tangent_0"]);
const v186=__nfValue(v137["tangent_0"]);
const v187=Math.fround(__nfNumber(v185) + __nfNumber(v186));
const v188=__nfValue(v181["tangent_1"]);
const v189=__nfValue(v137["tangent_1"]);
const v190=Math.fround(__nfNumber(v188) + __nfNumber(v189));
const v191=__nfValue(v181["tangent_2"]);
const v192=__nfValue(v137["tangent_2"]);
const v193=Math.fround(__nfNumber(v191) + __nfNumber(v192));
const v194=__nfValue(v181["tangent_3"]);
const v195=__nfValue(v137["tangent_3"]);
const v196=Math.fround(__nfNumber(v194) + __nfNumber(v195));
const v197=__nfValue(v181["tangent_4"]);
const v198=__nfValue(v137["tangent_4"]);
const v199=Math.fround(__nfNumber(v197) + __nfNumber(v198));
const v200=__nfValue(v181["tangent_5"]);
const v201=__nfValue(v137["tangent_5"]);
const v202=Math.fround(__nfNumber(v200) + __nfNumber(v201));
const v203=__nfValue(v181["tangent_6"]);
const v204=__nfValue(v137["tangent_6"]);
const v205=Math.fround(__nfNumber(v203) + __nfNumber(v204));
const v206=__nfValue(v181["tangent_7"]);
const v207=__nfValue(v137["tangent_7"]);
const v208=Math.fround(__nfNumber(v206) + __nfNumber(v207));
const v209=__nfValue(v181["tangent_8"]);
const v210=__nfValue(v137["tangent_8"]);
const v211=Math.fround(__nfNumber(v209) + __nfNumber(v210));
const v212=__nfValue(v181["tangent_9"]);
const v213=__nfValue(v137["tangent_9"]);
const v214=Math.fround(__nfNumber(v212) + __nfNumber(v213));
const v215=__nfValue(v181["tangent_10"]);
const v216=__nfValue(v137["tangent_10"]);
const v217=Math.fround(__nfNumber(v215) + __nfNumber(v216));
const v218=__nfValue(v181["tangent_11"]);
const v219=__nfValue(v137["tangent_11"]);
const v220=Math.fround(__nfNumber(v218) + __nfNumber(v219));
const v222=v136["q"];
const v223=v222["a"];
const v224=__nfValue(v223["value"]);
const v225=__nfValue(v137["value"]);
const v226=Math.fround(__nfNumber(v224) - __nfNumber(v225));
const v227=__nfValue(v223["tangent_0"]);
const v228=__nfValue(v137["tangent_0"]);
const v229=Math.fround(__nfNumber(v227) - __nfNumber(v228));
const v230=__nfValue(v223["tangent_1"]);
const v231=__nfValue(v137["tangent_1"]);
const v232=Math.fround(__nfNumber(v230) - __nfNumber(v231));
const v233=__nfValue(v223["tangent_2"]);
const v234=__nfValue(v137["tangent_2"]);
const v235=Math.fround(__nfNumber(v233) - __nfNumber(v234));
const v236=__nfValue(v223["tangent_3"]);
const v237=__nfValue(v137["tangent_3"]);
const v238=Math.fround(__nfNumber(v236) - __nfNumber(v237));
const v239=__nfValue(v223["tangent_4"]);
const v240=__nfValue(v137["tangent_4"]);
const v241=Math.fround(__nfNumber(v239) - __nfNumber(v240));
const v242=__nfValue(v223["tangent_5"]);
const v243=__nfValue(v137["tangent_5"]);
const v244=Math.fround(__nfNumber(v242) - __nfNumber(v243));
const v245=__nfValue(v223["tangent_6"]);
const v246=__nfValue(v137["tangent_6"]);
const v247=Math.fround(__nfNumber(v245) - __nfNumber(v246));
const v248=__nfValue(v223["tangent_7"]);
const v249=__nfValue(v137["tangent_7"]);
const v250=Math.fround(__nfNumber(v248) - __nfNumber(v249));
const v251=__nfValue(v223["tangent_8"]);
const v252=__nfValue(v137["tangent_8"]);
const v253=Math.fround(__nfNumber(v251) - __nfNumber(v252));
const v254=__nfValue(v223["tangent_9"]);
const v255=__nfValue(v137["tangent_9"]);
const v256=Math.fround(__nfNumber(v254) - __nfNumber(v255));
const v257=__nfValue(v223["tangent_10"]);
const v258=__nfValue(v137["tangent_10"]);
const v259=Math.fround(__nfNumber(v257) - __nfNumber(v258));
const v260=__nfValue(v223["tangent_11"]);
const v261=__nfValue(v137["tangent_11"]);
const v262=Math.fround(__nfNumber(v260) - __nfNumber(v261));
const v264=v136["q"];
const v265=v264["b"];
const v266=__nfValue(v265["value"]);
const v267=__nfValue(v137["value"]);
const v268=Math.fround(__nfNumber(v266) + __nfNumber(v267));
const v269=__nfValue(v265["tangent_0"]);
const v270=__nfValue(v137["tangent_0"]);
const v271=Math.fround(__nfNumber(v269) + __nfNumber(v270));
const v272=__nfValue(v265["tangent_1"]);
const v273=__nfValue(v137["tangent_1"]);
const v274=Math.fround(__nfNumber(v272) + __nfNumber(v273));
const v275=__nfValue(v265["tangent_2"]);
const v276=__nfValue(v137["tangent_2"]);
const v277=Math.fround(__nfNumber(v275) + __nfNumber(v276));
const v278=__nfValue(v265["tangent_3"]);
const v279=__nfValue(v137["tangent_3"]);
const v280=Math.fround(__nfNumber(v278) + __nfNumber(v279));
const v281=__nfValue(v265["tangent_4"]);
const v282=__nfValue(v137["tangent_4"]);
const v283=Math.fround(__nfNumber(v281) + __nfNumber(v282));
const v284=__nfValue(v265["tangent_5"]);
const v285=__nfValue(v137["tangent_5"]);
const v286=Math.fround(__nfNumber(v284) + __nfNumber(v285));
const v287=__nfValue(v265["tangent_6"]);
const v288=__nfValue(v137["tangent_6"]);
const v289=Math.fround(__nfNumber(v287) + __nfNumber(v288));
const v290=__nfValue(v265["tangent_7"]);
const v291=__nfValue(v137["tangent_7"]);
const v292=Math.fround(__nfNumber(v290) + __nfNumber(v291));
const v293=__nfValue(v265["tangent_8"]);
const v294=__nfValue(v137["tangent_8"]);
const v295=Math.fround(__nfNumber(v293) + __nfNumber(v294));
const v296=__nfValue(v265["tangent_9"]);
const v297=__nfValue(v137["tangent_9"]);
const v298=Math.fround(__nfNumber(v296) + __nfNumber(v297));
const v299=__nfValue(v265["tangent_10"]);
const v300=__nfValue(v137["tangent_10"]);
const v301=Math.fround(__nfNumber(v299) + __nfNumber(v300));
const v302=__nfValue(v265["tangent_11"]);
const v303=__nfValue(v137["tangent_11"]);
const v304=Math.fround(__nfNumber(v302) + __nfNumber(v303));
const v306=v136["r"];
const v307=v306["a"];
const v308=__nfValue(v307["value"]);
const v309=__nfValue(v137["value"]);
const v310=Math.fround(__nfNumber(v308) - __nfNumber(v309));
const v311=__nfValue(v307["tangent_0"]);
const v312=__nfValue(v137["tangent_0"]);
const v313=Math.fround(__nfNumber(v311) - __nfNumber(v312));
const v314=__nfValue(v307["tangent_1"]);
const v315=__nfValue(v137["tangent_1"]);
const v316=Math.fround(__nfNumber(v314) - __nfNumber(v315));
const v317=__nfValue(v307["tangent_2"]);
const v318=__nfValue(v137["tangent_2"]);
const v319=Math.fround(__nfNumber(v317) - __nfNumber(v318));
const v320=__nfValue(v307["tangent_3"]);
const v321=__nfValue(v137["tangent_3"]);
const v322=Math.fround(__nfNumber(v320) - __nfNumber(v321));
const v323=__nfValue(v307["tangent_4"]);
const v324=__nfValue(v137["tangent_4"]);
const v325=Math.fround(__nfNumber(v323) - __nfNumber(v324));
const v326=__nfValue(v307["tangent_5"]);
const v327=__nfValue(v137["tangent_5"]);
const v328=Math.fround(__nfNumber(v326) - __nfNumber(v327));
const v329=__nfValue(v307["tangent_6"]);
const v330=__nfValue(v137["tangent_6"]);
const v331=Math.fround(__nfNumber(v329) - __nfNumber(v330));
const v332=__nfValue(v307["tangent_7"]);
const v333=__nfValue(v137["tangent_7"]);
const v334=Math.fround(__nfNumber(v332) - __nfNumber(v333));
const v335=__nfValue(v307["tangent_8"]);
const v336=__nfValue(v137["tangent_8"]);
const v337=Math.fround(__nfNumber(v335) - __nfNumber(v336));
const v338=__nfValue(v307["tangent_9"]);
const v339=__nfValue(v137["tangent_9"]);
const v340=Math.fround(__nfNumber(v338) - __nfNumber(v339));
const v341=__nfValue(v307["tangent_10"]);
const v342=__nfValue(v137["tangent_10"]);
const v343=Math.fround(__nfNumber(v341) - __nfNumber(v342));
const v344=__nfValue(v307["tangent_11"]);
const v345=__nfValue(v137["tangent_11"]);
const v346=Math.fround(__nfNumber(v344) - __nfNumber(v345));
const v348=v136["r"];
const v349=v348["b"];
const v350=__nfValue(v349["value"]);
const v351=__nfValue(v137["value"]);
const v352=Math.fround(__nfNumber(v350) + __nfNumber(v351));
const v353=__nfValue(v349["tangent_0"]);
const v354=__nfValue(v137["tangent_0"]);
const v355=Math.fround(__nfNumber(v353) + __nfNumber(v354));
const v356=__nfValue(v349["tangent_1"]);
const v357=__nfValue(v137["tangent_1"]);
const v358=Math.fround(__nfNumber(v356) + __nfNumber(v357));
const v359=__nfValue(v349["tangent_2"]);
const v360=__nfValue(v137["tangent_2"]);
const v361=Math.fround(__nfNumber(v359) + __nfNumber(v360));
const v362=__nfValue(v349["tangent_3"]);
const v363=__nfValue(v137["tangent_3"]);
const v364=Math.fround(__nfNumber(v362) + __nfNumber(v363));
const v365=__nfValue(v349["tangent_4"]);
const v366=__nfValue(v137["tangent_4"]);
const v367=Math.fround(__nfNumber(v365) + __nfNumber(v366));
const v368=__nfValue(v349["tangent_5"]);
const v369=__nfValue(v137["tangent_5"]);
const v370=Math.fround(__nfNumber(v368) + __nfNumber(v369));
const v371=__nfValue(v349["tangent_6"]);
const v372=__nfValue(v137["tangent_6"]);
const v373=Math.fround(__nfNumber(v371) + __nfNumber(v372));
const v374=__nfValue(v349["tangent_7"]);
const v375=__nfValue(v137["tangent_7"]);
const v376=Math.fround(__nfNumber(v374) + __nfNumber(v375));
const v377=__nfValue(v349["tangent_8"]);
const v378=__nfValue(v137["tangent_8"]);
const v379=Math.fround(__nfNumber(v377) + __nfNumber(v378));
const v380=__nfValue(v349["tangent_9"]);
const v381=__nfValue(v137["tangent_9"]);
const v382=Math.fround(__nfNumber(v380) + __nfNumber(v381));
const v383=__nfValue(v349["tangent_10"]);
const v384=__nfValue(v137["tangent_10"]);
const v385=Math.fround(__nfNumber(v383) + __nfNumber(v384));
const v386=__nfValue(v349["tangent_11"]);
const v387=__nfValue(v137["tangent_11"]);
const v388=Math.fround(__nfNumber(v386) + __nfNumber(v387));
const v390=v136["s"];
const v391=v390["a"];
const v392=__nfValue(v391["value"]);
const v393=__nfValue(v137["value"]);
const v394=Math.fround(__nfNumber(v392) - __nfNumber(v393));
const v395=__nfValue(v391["tangent_0"]);
const v396=__nfValue(v137["tangent_0"]);
const v397=Math.fround(__nfNumber(v395) - __nfNumber(v396));
const v398=__nfValue(v391["tangent_1"]);
const v399=__nfValue(v137["tangent_1"]);
const v400=Math.fround(__nfNumber(v398) - __nfNumber(v399));
const v401=__nfValue(v391["tangent_2"]);
const v402=__nfValue(v137["tangent_2"]);
const v403=Math.fround(__nfNumber(v401) - __nfNumber(v402));
const v404=__nfValue(v391["tangent_3"]);
const v405=__nfValue(v137["tangent_3"]);
const v406=Math.fround(__nfNumber(v404) - __nfNumber(v405));
const v407=__nfValue(v391["tangent_4"]);
const v408=__nfValue(v137["tangent_4"]);
const v409=Math.fround(__nfNumber(v407) - __nfNumber(v408));
const v410=__nfValue(v391["tangent_5"]);
const v411=__nfValue(v137["tangent_5"]);
const v412=Math.fround(__nfNumber(v410) - __nfNumber(v411));
const v413=__nfValue(v391["tangent_6"]);
const v414=__nfValue(v137["tangent_6"]);
const v415=Math.fround(__nfNumber(v413) - __nfNumber(v414));
const v416=__nfValue(v391["tangent_7"]);
const v417=__nfValue(v137["tangent_7"]);
const v418=Math.fround(__nfNumber(v416) - __nfNumber(v417));
const v419=__nfValue(v391["tangent_8"]);
const v420=__nfValue(v137["tangent_8"]);
const v421=Math.fround(__nfNumber(v419) - __nfNumber(v420));
const v422=__nfValue(v391["tangent_9"]);
const v423=__nfValue(v137["tangent_9"]);
const v424=Math.fround(__nfNumber(v422) - __nfNumber(v423));
const v425=__nfValue(v391["tangent_10"]);
const v426=__nfValue(v137["tangent_10"]);
const v427=Math.fround(__nfNumber(v425) - __nfNumber(v426));
const v428=__nfValue(v391["tangent_11"]);
const v429=__nfValue(v137["tangent_11"]);
const v430=Math.fround(__nfNumber(v428) - __nfNumber(v429));
const v432=v136["s"];
const v433=v432["b"];
const v434=__nfValue(v433["value"]);
const v435=__nfValue(v137["value"]);
const v436=Math.fround(__nfNumber(v434) + __nfNumber(v435));
const v437=__nfValue(v433["tangent_0"]);
const v438=__nfValue(v137["tangent_0"]);
const v439=Math.fround(__nfNumber(v437) + __nfNumber(v438));
const v440=__nfValue(v433["tangent_1"]);
const v441=__nfValue(v137["tangent_1"]);
const v442=Math.fround(__nfNumber(v440) + __nfNumber(v441));
const v443=__nfValue(v433["tangent_2"]);
const v444=__nfValue(v137["tangent_2"]);
const v445=Math.fround(__nfNumber(v443) + __nfNumber(v444));
const v446=__nfValue(v433["tangent_3"]);
const v447=__nfValue(v137["tangent_3"]);
const v448=Math.fround(__nfNumber(v446) + __nfNumber(v447));
const v449=__nfValue(v433["tangent_4"]);
const v450=__nfValue(v137["tangent_4"]);
const v451=Math.fround(__nfNumber(v449) + __nfNumber(v450));
const v452=__nfValue(v433["tangent_5"]);
const v453=__nfValue(v137["tangent_5"]);
const v454=Math.fround(__nfNumber(v452) + __nfNumber(v453));
const v455=__nfValue(v433["tangent_6"]);
const v456=__nfValue(v137["tangent_6"]);
const v457=Math.fround(__nfNumber(v455) + __nfNumber(v456));
const v458=__nfValue(v433["tangent_7"]);
const v459=__nfValue(v137["tangent_7"]);
const v460=Math.fround(__nfNumber(v458) + __nfNumber(v459));
const v461=__nfValue(v433["tangent_8"]);
const v462=__nfValue(v137["tangent_8"]);
const v463=Math.fround(__nfNumber(v461) + __nfNumber(v462));
const v464=__nfValue(v433["tangent_9"]);
const v465=__nfValue(v137["tangent_9"]);
const v466=Math.fround(__nfNumber(v464) + __nfNumber(v465));
const v467=__nfValue(v433["tangent_10"]);
const v468=__nfValue(v137["tangent_10"]);
const v469=Math.fround(__nfNumber(v467) + __nfNumber(v468));
const v470=__nfValue(v433["tangent_11"]);
const v471=__nfValue(v137["tangent_11"]);
const v472=Math.fround(__nfNumber(v470) + __nfNumber(v471));
const v474=v136["t"];
const v475=v474["a"];
const v476=__nfValue(v475["value"]);
const v477=__nfValue(v137["value"]);
const v478=Math.fround(__nfNumber(v476) - __nfNumber(v477));
const v479=__nfValue(v475["tangent_0"]);
const v480=__nfValue(v137["tangent_0"]);
const v481=Math.fround(__nfNumber(v479) - __nfNumber(v480));
const v482=__nfValue(v475["tangent_1"]);
const v483=__nfValue(v137["tangent_1"]);
const v484=Math.fround(__nfNumber(v482) - __nfNumber(v483));
const v485=__nfValue(v475["tangent_2"]);
const v486=__nfValue(v137["tangent_2"]);
const v487=Math.fround(__nfNumber(v485) - __nfNumber(v486));
const v488=__nfValue(v475["tangent_3"]);
const v489=__nfValue(v137["tangent_3"]);
const v490=Math.fround(__nfNumber(v488) - __nfNumber(v489));
const v491=__nfValue(v475["tangent_4"]);
const v492=__nfValue(v137["tangent_4"]);
const v493=Math.fround(__nfNumber(v491) - __nfNumber(v492));
const v494=__nfValue(v475["tangent_5"]);
const v495=__nfValue(v137["tangent_5"]);
const v496=Math.fround(__nfNumber(v494) - __nfNumber(v495));
const v497=__nfValue(v475["tangent_6"]);
const v498=__nfValue(v137["tangent_6"]);
const v499=Math.fround(__nfNumber(v497) - __nfNumber(v498));
const v500=__nfValue(v475["tangent_7"]);
const v501=__nfValue(v137["tangent_7"]);
const v502=Math.fround(__nfNumber(v500) - __nfNumber(v501));
const v503=__nfValue(v475["tangent_8"]);
const v504=__nfValue(v137["tangent_8"]);
const v505=Math.fround(__nfNumber(v503) - __nfNumber(v504));
const v506=__nfValue(v475["tangent_9"]);
const v507=__nfValue(v137["tangent_9"]);
const v508=Math.fround(__nfNumber(v506) - __nfNumber(v507));
const v509=__nfValue(v475["tangent_10"]);
const v510=__nfValue(v137["tangent_10"]);
const v511=Math.fround(__nfNumber(v509) - __nfNumber(v510));
const v512=__nfValue(v475["tangent_11"]);
const v513=__nfValue(v137["tangent_11"]);
const v514=Math.fround(__nfNumber(v512) - __nfNumber(v513));
const v516=v136["t"];
const v517=v516["b"];
const v518=__nfValue(v517["value"]);
const v519=__nfValue(v137["value"]);
const v520=Math.fround(__nfNumber(v518) + __nfNumber(v519));
const v521=__nfValue(v517["tangent_0"]);
const v522=__nfValue(v137["tangent_0"]);
const v523=Math.fround(__nfNumber(v521) + __nfNumber(v522));
const v524=__nfValue(v517["tangent_1"]);
const v525=__nfValue(v137["tangent_1"]);
const v526=Math.fround(__nfNumber(v524) + __nfNumber(v525));
const v527=__nfValue(v517["tangent_2"]);
const v528=__nfValue(v137["tangent_2"]);
const v529=Math.fround(__nfNumber(v527) + __nfNumber(v528));
const v530=__nfValue(v517["tangent_3"]);
const v531=__nfValue(v137["tangent_3"]);
const v532=Math.fround(__nfNumber(v530) + __nfNumber(v531));
const v533=__nfValue(v517["tangent_4"]);
const v534=__nfValue(v137["tangent_4"]);
const v535=Math.fround(__nfNumber(v533) + __nfNumber(v534));
const v536=__nfValue(v517["tangent_5"]);
const v537=__nfValue(v137["tangent_5"]);
const v538=Math.fround(__nfNumber(v536) + __nfNumber(v537));
const v539=__nfValue(v517["tangent_6"]);
const v540=__nfValue(v137["tangent_6"]);
const v541=Math.fround(__nfNumber(v539) + __nfNumber(v540));
const v542=__nfValue(v517["tangent_7"]);
const v543=__nfValue(v137["tangent_7"]);
const v544=Math.fround(__nfNumber(v542) + __nfNumber(v543));
const v545=__nfValue(v517["tangent_8"]);
const v546=__nfValue(v137["tangent_8"]);
const v547=Math.fround(__nfNumber(v545) + __nfNumber(v546));
const v548=__nfValue(v517["tangent_9"]);
const v549=__nfValue(v137["tangent_9"]);
const v550=Math.fround(__nfNumber(v548) + __nfNumber(v549));
const v551=__nfValue(v517["tangent_10"]);
const v552=__nfValue(v137["tangent_10"]);
const v553=Math.fround(__nfNumber(v551) + __nfNumber(v552));
const v554=__nfValue(v517["tangent_11"]);
const v555=__nfValue(v137["tangent_11"]);
const v556=Math.fround(__nfNumber(v554) + __nfNumber(v555));
const v558=v136["u"];
const v559=v558["a"];
const v560=__nfValue(v559["value"]);
const v561=__nfValue(v137["value"]);
const v562=Math.fround(__nfNumber(v560) - __nfNumber(v561));
const v563=__nfValue(v559["tangent_0"]);
const v564=__nfValue(v137["tangent_0"]);
const v565=Math.fround(__nfNumber(v563) - __nfNumber(v564));
const v566=__nfValue(v559["tangent_1"]);
const v567=__nfValue(v137["tangent_1"]);
const v568=Math.fround(__nfNumber(v566) - __nfNumber(v567));
const v569=__nfValue(v559["tangent_2"]);
const v570=__nfValue(v137["tangent_2"]);
const v571=Math.fround(__nfNumber(v569) - __nfNumber(v570));
const v572=__nfValue(v559["tangent_3"]);
const v573=__nfValue(v137["tangent_3"]);
const v574=Math.fround(__nfNumber(v572) - __nfNumber(v573));
const v575=__nfValue(v559["tangent_4"]);
const v576=__nfValue(v137["tangent_4"]);
const v577=Math.fround(__nfNumber(v575) - __nfNumber(v576));
const v578=__nfValue(v559["tangent_5"]);
const v579=__nfValue(v137["tangent_5"]);
const v580=Math.fround(__nfNumber(v578) - __nfNumber(v579));
const v581=__nfValue(v559["tangent_6"]);
const v582=__nfValue(v137["tangent_6"]);
const v583=Math.fround(__nfNumber(v581) - __nfNumber(v582));
const v584=__nfValue(v559["tangent_7"]);
const v585=__nfValue(v137["tangent_7"]);
const v586=Math.fround(__nfNumber(v584) - __nfNumber(v585));
const v587=__nfValue(v559["tangent_8"]);
const v588=__nfValue(v137["tangent_8"]);
const v589=Math.fround(__nfNumber(v587) - __nfNumber(v588));
const v590=__nfValue(v559["tangent_9"]);
const v591=__nfValue(v137["tangent_9"]);
const v592=Math.fround(__nfNumber(v590) - __nfNumber(v591));
const v593=__nfValue(v559["tangent_10"]);
const v594=__nfValue(v137["tangent_10"]);
const v595=Math.fround(__nfNumber(v593) - __nfNumber(v594));
const v596=__nfValue(v559["tangent_11"]);
const v597=__nfValue(v137["tangent_11"]);
const v598=Math.fround(__nfNumber(v596) - __nfNumber(v597));
const v600=v136["u"];
const v601=v600["b"];
const v602=__nfValue(v601["value"]);
const v603=__nfValue(v137["value"]);
const v604=Math.fround(__nfNumber(v602) + __nfNumber(v603));
const v605=__nfValue(v601["tangent_0"]);
const v606=__nfValue(v137["tangent_0"]);
const v607=Math.fround(__nfNumber(v605) + __nfNumber(v606));
const v608=__nfValue(v601["tangent_1"]);
const v609=__nfValue(v137["tangent_1"]);
const v610=Math.fround(__nfNumber(v608) + __nfNumber(v609));
const v611=__nfValue(v601["tangent_2"]);
const v612=__nfValue(v137["tangent_2"]);
const v613=Math.fround(__nfNumber(v611) + __nfNumber(v612));
const v614=__nfValue(v601["tangent_3"]);
const v615=__nfValue(v137["tangent_3"]);
const v616=Math.fround(__nfNumber(v614) + __nfNumber(v615));
const v617=__nfValue(v601["tangent_4"]);
const v618=__nfValue(v137["tangent_4"]);
const v619=Math.fround(__nfNumber(v617) + __nfNumber(v618));
const v620=__nfValue(v601["tangent_5"]);
const v621=__nfValue(v137["tangent_5"]);
const v622=Math.fround(__nfNumber(v620) + __nfNumber(v621));
const v623=__nfValue(v601["tangent_6"]);
const v624=__nfValue(v137["tangent_6"]);
const v625=Math.fround(__nfNumber(v623) + __nfNumber(v624));
const v626=__nfValue(v601["tangent_7"]);
const v627=__nfValue(v137["tangent_7"]);
const v628=Math.fround(__nfNumber(v626) + __nfNumber(v627));
const v629=__nfValue(v601["tangent_8"]);
const v630=__nfValue(v137["tangent_8"]);
const v631=Math.fround(__nfNumber(v629) + __nfNumber(v630));
const v632=__nfValue(v601["tangent_9"]);
const v633=__nfValue(v137["tangent_9"]);
const v634=Math.fround(__nfNumber(v632) + __nfNumber(v633));
const v635=__nfValue(v601["tangent_10"]);
const v636=__nfValue(v137["tangent_10"]);
const v637=Math.fround(__nfNumber(v635) + __nfNumber(v636));
const v638=__nfValue(v601["tangent_11"]);
const v639=__nfValue(v137["tangent_11"]);
const v640=Math.fround(__nfNumber(v638) + __nfNumber(v639));
const v642=Math.fround(v142 * v142);
const v643=Math.fround(v145 * v142);
const v644=Math.fround(v142 * v145);
const v645=Math.fround(v643 + v644);
const v646=Math.fround(v148 * v142);
const v647=Math.fround(v142 * v148);
const v648=Math.fround(v646 + v647);
const v649=Math.fround(v151 * v142);
const v650=Math.fround(v142 * v151);
const v651=Math.fround(v649 + v650);
const v652=Math.fround(v154 * v142);
const v653=Math.fround(v142 * v154);
const v654=Math.fround(v652 + v653);
const v655=Math.fround(v157 * v142);
const v656=Math.fround(v142 * v157);
const v657=Math.fround(v655 + v656);
const v658=Math.fround(v160 * v142);
const v659=Math.fround(v142 * v160);
const v660=Math.fround(v658 + v659);
const v661=Math.fround(v163 * v142);
const v662=Math.fround(v142 * v163);
const v663=Math.fround(v661 + v662);
const v664=Math.fround(v166 * v142);
const v665=Math.fround(v142 * v166);
const v666=Math.fround(v664 + v665);
const v667=Math.fround(v169 * v142);
const v668=Math.fround(v142 * v169);
const v669=Math.fround(v667 + v668);
const v670=Math.fround(v172 * v142);
const v671=Math.fround(v142 * v172);
const v672=Math.fround(v670 + v671);
const v673=Math.fround(v175 * v142);
const v674=Math.fround(v142 * v175);
const v675=Math.fround(v673 + v674);
const v676=Math.fround(v178 * v142);
const v677=Math.fround(v142 * v178);
const v678=Math.fround(v676 + v677);
const v680=Math.fround(v184 * v184);
const v681=Math.fround(v187 * v184);
const v682=Math.fround(v184 * v187);
const v683=Math.fround(v681 + v682);
const v684=Math.fround(v190 * v184);
const v685=Math.fround(v184 * v190);
const v686=Math.fround(v684 + v685);
const v687=Math.fround(v193 * v184);
const v688=Math.fround(v184 * v193);
const v689=Math.fround(v687 + v688);
const v690=Math.fround(v196 * v184);
const v691=Math.fround(v184 * v196);
const v692=Math.fround(v690 + v691);
const v693=Math.fround(v199 * v184);
const v694=Math.fround(v184 * v199);
const v695=Math.fround(v693 + v694);
const v696=Math.fround(v202 * v184);
const v697=Math.fround(v184 * v202);
const v698=Math.fround(v696 + v697);
const v699=Math.fround(v205 * v184);
const v700=Math.fround(v184 * v205);
const v701=Math.fround(v699 + v700);
const v702=Math.fround(v208 * v184);
const v703=Math.fround(v184 * v208);
const v704=Math.fround(v702 + v703);
const v705=Math.fround(v211 * v184);
const v706=Math.fround(v184 * v211);
const v707=Math.fround(v705 + v706);
const v708=Math.fround(v214 * v184);
const v709=Math.fround(v184 * v214);
const v710=Math.fround(v708 + v709);
const v711=Math.fround(v217 * v184);
const v712=Math.fround(v184 * v217);
const v713=Math.fround(v711 + v712);
const v714=Math.fround(v220 * v184);
const v715=Math.fround(v184 * v220);
const v716=Math.fround(v714 + v715);
const v718=Math.fround(v642 + v680);
const v719=Math.fround(v645 + v683);
const v720=Math.fround(v648 + v686);
const v721=Math.fround(v651 + v689);
const v722=Math.fround(v654 + v692);
const v723=Math.fround(v657 + v695);
const v724=Math.fround(v660 + v698);
const v725=Math.fround(v663 + v701);
const v726=Math.fround(v666 + v704);
const v727=Math.fround(v669 + v707);
const v728=Math.fround(v672 + v710);
const v729=Math.fround(v675 + v713);
const v730=Math.fround(v678 + v716);
const v732=Math.fround(v226 * v226);
const v733=Math.fround(v229 * v226);
const v734=Math.fround(v226 * v229);
const v735=Math.fround(v733 + v734);
const v736=Math.fround(v232 * v226);
const v737=Math.fround(v226 * v232);
const v738=Math.fround(v736 + v737);
const v739=Math.fround(v235 * v226);
const v740=Math.fround(v226 * v235);
const v741=Math.fround(v739 + v740);
const v742=Math.fround(v238 * v226);
const v743=Math.fround(v226 * v238);
const v744=Math.fround(v742 + v743);
const v745=Math.fround(v241 * v226);
const v746=Math.fround(v226 * v241);
const v747=Math.fround(v745 + v746);
const v748=Math.fround(v244 * v226);
const v749=Math.fround(v226 * v244);
const v750=Math.fround(v748 + v749);
const v751=Math.fround(v247 * v226);
const v752=Math.fround(v226 * v247);
const v753=Math.fround(v751 + v752);
const v754=Math.fround(v250 * v226);
const v755=Math.fround(v226 * v250);
const v756=Math.fround(v754 + v755);
const v757=Math.fround(v253 * v226);
const v758=Math.fround(v226 * v253);
const v759=Math.fround(v757 + v758);
const v760=Math.fround(v256 * v226);
const v761=Math.fround(v226 * v256);
const v762=Math.fround(v760 + v761);
const v763=Math.fround(v259 * v226);
const v764=Math.fround(v226 * v259);
const v765=Math.fround(v763 + v764);
const v766=Math.fround(v262 * v226);
const v767=Math.fround(v226 * v262);
const v768=Math.fround(v766 + v767);
const v770=Math.fround(v718 + v732);
const v771=Math.fround(v719 + v735);
const v772=Math.fround(v720 + v738);
const v773=Math.fround(v721 + v741);
const v774=Math.fround(v722 + v744);
const v775=Math.fround(v723 + v747);
const v776=Math.fround(v724 + v750);
const v777=Math.fround(v725 + v753);
const v778=Math.fround(v726 + v756);
const v779=Math.fround(v727 + v759);
const v780=Math.fround(v728 + v762);
const v781=Math.fround(v729 + v765);
const v782=Math.fround(v730 + v768);
const v784=Math.fround(v268 * v268);
const v785=Math.fround(v271 * v268);
const v786=Math.fround(v268 * v271);
const v787=Math.fround(v785 + v786);
const v788=Math.fround(v274 * v268);
const v789=Math.fround(v268 * v274);
const v790=Math.fround(v788 + v789);
const v791=Math.fround(v277 * v268);
const v792=Math.fround(v268 * v277);
const v793=Math.fround(v791 + v792);
const v794=Math.fround(v280 * v268);
const v795=Math.fround(v268 * v280);
const v796=Math.fround(v794 + v795);
const v797=Math.fround(v283 * v268);
const v798=Math.fround(v268 * v283);
const v799=Math.fround(v797 + v798);
const v800=Math.fround(v286 * v268);
const v801=Math.fround(v268 * v286);
const v802=Math.fround(v800 + v801);
const v803=Math.fround(v289 * v268);
const v804=Math.fround(v268 * v289);
const v805=Math.fround(v803 + v804);
const v806=Math.fround(v292 * v268);
const v807=Math.fround(v268 * v292);
const v808=Math.fround(v806 + v807);
const v809=Math.fround(v295 * v268);
const v810=Math.fround(v268 * v295);
const v811=Math.fround(v809 + v810);
const v812=Math.fround(v298 * v268);
const v813=Math.fround(v268 * v298);
const v814=Math.fround(v812 + v813);
const v815=Math.fround(v301 * v268);
const v816=Math.fround(v268 * v301);
const v817=Math.fround(v815 + v816);
const v818=Math.fround(v304 * v268);
const v819=Math.fround(v268 * v304);
const v820=Math.fround(v818 + v819);
const v822=Math.fround(v770 + v784);
const v823=Math.fround(v771 + v787);
const v824=Math.fround(v772 + v790);
const v825=Math.fround(v773 + v793);
const v826=Math.fround(v774 + v796);
const v827=Math.fround(v775 + v799);
const v828=Math.fround(v776 + v802);
const v829=Math.fround(v777 + v805);
const v830=Math.fround(v778 + v808);
const v831=Math.fround(v779 + v811);
const v832=Math.fround(v780 + v814);
const v833=Math.fround(v781 + v817);
const v834=Math.fround(v782 + v820);
const v836=Math.fround(v310 * v310);
const v837=Math.fround(v313 * v310);
const v838=Math.fround(v310 * v313);
const v839=Math.fround(v837 + v838);
const v840=Math.fround(v316 * v310);
const v841=Math.fround(v310 * v316);
const v842=Math.fround(v840 + v841);
const v843=Math.fround(v319 * v310);
const v844=Math.fround(v310 * v319);
const v845=Math.fround(v843 + v844);
const v846=Math.fround(v322 * v310);
const v847=Math.fround(v310 * v322);
const v848=Math.fround(v846 + v847);
const v849=Math.fround(v325 * v310);
const v850=Math.fround(v310 * v325);
const v851=Math.fround(v849 + v850);
const v852=Math.fround(v328 * v310);
const v853=Math.fround(v310 * v328);
const v854=Math.fround(v852 + v853);
const v855=Math.fround(v331 * v310);
const v856=Math.fround(v310 * v331);
const v857=Math.fround(v855 + v856);
const v858=Math.fround(v334 * v310);
const v859=Math.fround(v310 * v334);
const v860=Math.fround(v858 + v859);
const v861=Math.fround(v337 * v310);
const v862=Math.fround(v310 * v337);
const v863=Math.fround(v861 + v862);
const v864=Math.fround(v340 * v310);
const v865=Math.fround(v310 * v340);
const v866=Math.fround(v864 + v865);
const v867=Math.fround(v343 * v310);
const v868=Math.fround(v310 * v343);
const v869=Math.fround(v867 + v868);
const v870=Math.fround(v346 * v310);
const v871=Math.fround(v310 * v346);
const v872=Math.fround(v870 + v871);
const v874=Math.fround(v822 + v836);
const v875=Math.fround(v823 + v839);
const v876=Math.fround(v824 + v842);
const v877=Math.fround(v825 + v845);
const v878=Math.fround(v826 + v848);
const v879=Math.fround(v827 + v851);
const v880=Math.fround(v828 + v854);
const v881=Math.fround(v829 + v857);
const v882=Math.fround(v830 + v860);
const v883=Math.fround(v831 + v863);
const v884=Math.fround(v832 + v866);
const v885=Math.fround(v833 + v869);
const v886=Math.fround(v834 + v872);
const v888=Math.fround(v352 * v352);
const v889=Math.fround(v355 * v352);
const v890=Math.fround(v352 * v355);
const v891=Math.fround(v889 + v890);
const v892=Math.fround(v358 * v352);
const v893=Math.fround(v352 * v358);
const v894=Math.fround(v892 + v893);
const v895=Math.fround(v361 * v352);
const v896=Math.fround(v352 * v361);
const v897=Math.fround(v895 + v896);
const v898=Math.fround(v364 * v352);
const v899=Math.fround(v352 * v364);
const v900=Math.fround(v898 + v899);
const v901=Math.fround(v367 * v352);
const v902=Math.fround(v352 * v367);
const v903=Math.fround(v901 + v902);
const v904=Math.fround(v370 * v352);
const v905=Math.fround(v352 * v370);
const v906=Math.fround(v904 + v905);
const v907=Math.fround(v373 * v352);
const v908=Math.fround(v352 * v373);
const v909=Math.fround(v907 + v908);
const v910=Math.fround(v376 * v352);
const v911=Math.fround(v352 * v376);
const v912=Math.fround(v910 + v911);
const v913=Math.fround(v379 * v352);
const v914=Math.fround(v352 * v379);
const v915=Math.fround(v913 + v914);
const v916=Math.fround(v382 * v352);
const v917=Math.fround(v352 * v382);
const v918=Math.fround(v916 + v917);
const v919=Math.fround(v385 * v352);
const v920=Math.fround(v352 * v385);
const v921=Math.fround(v919 + v920);
const v922=Math.fround(v388 * v352);
const v923=Math.fround(v352 * v388);
const v924=Math.fround(v922 + v923);
const v926=Math.fround(v874 + v888);
const v927=Math.fround(v875 + v891);
const v928=Math.fround(v876 + v894);
const v929=Math.fround(v877 + v897);
const v930=Math.fround(v878 + v900);
const v931=Math.fround(v879 + v903);
const v932=Math.fround(v880 + v906);
const v933=Math.fround(v881 + v909);
const v934=Math.fround(v882 + v912);
const v935=Math.fround(v883 + v915);
const v936=Math.fround(v884 + v918);
const v937=Math.fround(v885 + v921);
const v938=Math.fround(v886 + v924);
const v940=Math.fround(v394 * v394);
const v941=Math.fround(v397 * v394);
const v942=Math.fround(v394 * v397);
const v943=Math.fround(v941 + v942);
const v944=Math.fround(v400 * v394);
const v945=Math.fround(v394 * v400);
const v946=Math.fround(v944 + v945);
const v947=Math.fround(v403 * v394);
const v948=Math.fround(v394 * v403);
const v949=Math.fround(v947 + v948);
const v950=Math.fround(v406 * v394);
const v951=Math.fround(v394 * v406);
const v952=Math.fround(v950 + v951);
const v953=Math.fround(v409 * v394);
const v954=Math.fround(v394 * v409);
const v955=Math.fround(v953 + v954);
const v956=Math.fround(v412 * v394);
const v957=Math.fround(v394 * v412);
const v958=Math.fround(v956 + v957);
const v959=Math.fround(v415 * v394);
const v960=Math.fround(v394 * v415);
const v961=Math.fround(v959 + v960);
const v962=Math.fround(v418 * v394);
const v963=Math.fround(v394 * v418);
const v964=Math.fround(v962 + v963);
const v965=Math.fround(v421 * v394);
const v966=Math.fround(v394 * v421);
const v967=Math.fround(v965 + v966);
const v968=Math.fround(v424 * v394);
const v969=Math.fround(v394 * v424);
const v970=Math.fround(v968 + v969);
const v971=Math.fround(v427 * v394);
const v972=Math.fround(v394 * v427);
const v973=Math.fround(v971 + v972);
const v974=Math.fround(v430 * v394);
const v975=Math.fround(v394 * v430);
const v976=Math.fround(v974 + v975);
const v978=Math.fround(v926 + v940);
const v979=Math.fround(v927 + v943);
const v980=Math.fround(v928 + v946);
const v981=Math.fround(v929 + v949);
const v982=Math.fround(v930 + v952);
const v983=Math.fround(v931 + v955);
const v984=Math.fround(v932 + v958);
const v985=Math.fround(v933 + v961);
const v986=Math.fround(v934 + v964);
const v987=Math.fround(v935 + v967);
const v988=Math.fround(v936 + v970);
const v989=Math.fround(v937 + v973);
const v990=Math.fround(v938 + v976);
const v992=Math.fround(v436 * v436);
const v993=Math.fround(v439 * v436);
const v994=Math.fround(v436 * v439);
const v995=Math.fround(v993 + v994);
const v996=Math.fround(v442 * v436);
const v997=Math.fround(v436 * v442);
const v998=Math.fround(v996 + v997);
const v999=Math.fround(v445 * v436);
const v1000=Math.fround(v436 * v445);
const v1001=Math.fround(v999 + v1000);
const v1002=Math.fround(v448 * v436);
const v1003=Math.fround(v436 * v448);
const v1004=Math.fround(v1002 + v1003);
const v1005=Math.fround(v451 * v436);
const v1006=Math.fround(v436 * v451);
const v1007=Math.fround(v1005 + v1006);
const v1008=Math.fround(v454 * v436);
const v1009=Math.fround(v436 * v454);
const v1010=Math.fround(v1008 + v1009);
const v1011=Math.fround(v457 * v436);
const v1012=Math.fround(v436 * v457);
const v1013=Math.fround(v1011 + v1012);
const v1014=Math.fround(v460 * v436);
const v1015=Math.fround(v436 * v460);
const v1016=Math.fround(v1014 + v1015);
const v1017=Math.fround(v463 * v436);
const v1018=Math.fround(v436 * v463);
const v1019=Math.fround(v1017 + v1018);
const v1020=Math.fround(v466 * v436);
const v1021=Math.fround(v436 * v466);
const v1022=Math.fround(v1020 + v1021);
const v1023=Math.fround(v469 * v436);
const v1024=Math.fround(v436 * v469);
const v1025=Math.fround(v1023 + v1024);
const v1026=Math.fround(v472 * v436);
const v1027=Math.fround(v436 * v472);
const v1028=Math.fround(v1026 + v1027);
const v1030=Math.fround(v978 + v992);
const v1031=Math.fround(v979 + v995);
const v1032=Math.fround(v980 + v998);
const v1033=Math.fround(v981 + v1001);
const v1034=Math.fround(v982 + v1004);
const v1035=Math.fround(v983 + v1007);
const v1036=Math.fround(v984 + v1010);
const v1037=Math.fround(v985 + v1013);
const v1038=Math.fround(v986 + v1016);
const v1039=Math.fround(v987 + v1019);
const v1040=Math.fround(v988 + v1022);
const v1041=Math.fround(v989 + v1025);
const v1042=Math.fround(v990 + v1028);
const v1044=Math.fround(v478 * v478);
const v1045=Math.fround(v481 * v478);
const v1046=Math.fround(v478 * v481);
const v1047=Math.fround(v1045 + v1046);
const v1048=Math.fround(v484 * v478);
const v1049=Math.fround(v478 * v484);
const v1050=Math.fround(v1048 + v1049);
const v1051=Math.fround(v487 * v478);
const v1052=Math.fround(v478 * v487);
const v1053=Math.fround(v1051 + v1052);
const v1054=Math.fround(v490 * v478);
const v1055=Math.fround(v478 * v490);
const v1056=Math.fround(v1054 + v1055);
const v1057=Math.fround(v493 * v478);
const v1058=Math.fround(v478 * v493);
const v1059=Math.fround(v1057 + v1058);
const v1060=Math.fround(v496 * v478);
const v1061=Math.fround(v478 * v496);
const v1062=Math.fround(v1060 + v1061);
const v1063=Math.fround(v499 * v478);
const v1064=Math.fround(v478 * v499);
const v1065=Math.fround(v1063 + v1064);
const v1066=Math.fround(v502 * v478);
const v1067=Math.fround(v478 * v502);
const v1068=Math.fround(v1066 + v1067);
const v1069=Math.fround(v505 * v478);
const v1070=Math.fround(v478 * v505);
const v1071=Math.fround(v1069 + v1070);
const v1072=Math.fround(v508 * v478);
const v1073=Math.fround(v478 * v508);
const v1074=Math.fround(v1072 + v1073);
const v1075=Math.fround(v511 * v478);
const v1076=Math.fround(v478 * v511);
const v1077=Math.fround(v1075 + v1076);
const v1078=Math.fround(v514 * v478);
const v1079=Math.fround(v478 * v514);
const v1080=Math.fround(v1078 + v1079);
const v1082=Math.fround(v1030 + v1044);
const v1083=Math.fround(v1031 + v1047);
const v1084=Math.fround(v1032 + v1050);
const v1085=Math.fround(v1033 + v1053);
const v1086=Math.fround(v1034 + v1056);
const v1087=Math.fround(v1035 + v1059);
const v1088=Math.fround(v1036 + v1062);
const v1089=Math.fround(v1037 + v1065);
const v1090=Math.fround(v1038 + v1068);
const v1091=Math.fround(v1039 + v1071);
const v1092=Math.fround(v1040 + v1074);
const v1093=Math.fround(v1041 + v1077);
const v1094=Math.fround(v1042 + v1080);
const v1096=Math.fround(v520 * v520);
const v1097=Math.fround(v523 * v520);
const v1098=Math.fround(v520 * v523);
const v1099=Math.fround(v1097 + v1098);
const v1100=Math.fround(v526 * v520);
const v1101=Math.fround(v520 * v526);
const v1102=Math.fround(v1100 + v1101);
const v1103=Math.fround(v529 * v520);
const v1104=Math.fround(v520 * v529);
const v1105=Math.fround(v1103 + v1104);
const v1106=Math.fround(v532 * v520);
const v1107=Math.fround(v520 * v532);
const v1108=Math.fround(v1106 + v1107);
const v1109=Math.fround(v535 * v520);
const v1110=Math.fround(v520 * v535);
const v1111=Math.fround(v1109 + v1110);
const v1112=Math.fround(v538 * v520);
const v1113=Math.fround(v520 * v538);
const v1114=Math.fround(v1112 + v1113);
const v1115=Math.fround(v541 * v520);
const v1116=Math.fround(v520 * v541);
const v1117=Math.fround(v1115 + v1116);
const v1118=Math.fround(v544 * v520);
const v1119=Math.fround(v520 * v544);
const v1120=Math.fround(v1118 + v1119);
const v1121=Math.fround(v547 * v520);
const v1122=Math.fround(v520 * v547);
const v1123=Math.fround(v1121 + v1122);
const v1124=Math.fround(v550 * v520);
const v1125=Math.fround(v520 * v550);
const v1126=Math.fround(v1124 + v1125);
const v1127=Math.fround(v553 * v520);
const v1128=Math.fround(v520 * v553);
const v1129=Math.fround(v1127 + v1128);
const v1130=Math.fround(v556 * v520);
const v1131=Math.fround(v520 * v556);
const v1132=Math.fround(v1130 + v1131);
const v1134=Math.fround(v1082 + v1096);
const v1135=Math.fround(v1083 + v1099);
const v1136=Math.fround(v1084 + v1102);
const v1137=Math.fround(v1085 + v1105);
const v1138=Math.fround(v1086 + v1108);
const v1139=Math.fround(v1087 + v1111);
const v1140=Math.fround(v1088 + v1114);
const v1141=Math.fround(v1089 + v1117);
const v1142=Math.fround(v1090 + v1120);
const v1143=Math.fround(v1091 + v1123);
const v1144=Math.fround(v1092 + v1126);
const v1145=Math.fround(v1093 + v1129);
const v1146=Math.fround(v1094 + v1132);
const v1148=Math.fround(v562 * v562);
const v1149=Math.fround(v565 * v562);
const v1150=Math.fround(v562 * v565);
const v1151=Math.fround(v1149 + v1150);
const v1152=Math.fround(v568 * v562);
const v1153=Math.fround(v562 * v568);
const v1154=Math.fround(v1152 + v1153);
const v1155=Math.fround(v571 * v562);
const v1156=Math.fround(v562 * v571);
const v1157=Math.fround(v1155 + v1156);
const v1158=Math.fround(v574 * v562);
const v1159=Math.fround(v562 * v574);
const v1160=Math.fround(v1158 + v1159);
const v1161=Math.fround(v577 * v562);
const v1162=Math.fround(v562 * v577);
const v1163=Math.fround(v1161 + v1162);
const v1164=Math.fround(v580 * v562);
const v1165=Math.fround(v562 * v580);
const v1166=Math.fround(v1164 + v1165);
const v1167=Math.fround(v583 * v562);
const v1168=Math.fround(v562 * v583);
const v1169=Math.fround(v1167 + v1168);
const v1170=Math.fround(v586 * v562);
const v1171=Math.fround(v562 * v586);
const v1172=Math.fround(v1170 + v1171);
const v1173=Math.fround(v589 * v562);
const v1174=Math.fround(v562 * v589);
const v1175=Math.fround(v1173 + v1174);
const v1176=Math.fround(v592 * v562);
const v1177=Math.fround(v562 * v592);
const v1178=Math.fround(v1176 + v1177);
const v1179=Math.fround(v595 * v562);
const v1180=Math.fround(v562 * v595);
const v1181=Math.fround(v1179 + v1180);
const v1182=Math.fround(v598 * v562);
const v1183=Math.fround(v562 * v598);
const v1184=Math.fround(v1182 + v1183);
const v1186=Math.fround(v1134 + v1148);
const v1187=Math.fround(v1135 + v1151);
const v1188=Math.fround(v1136 + v1154);
const v1189=Math.fround(v1137 + v1157);
const v1190=Math.fround(v1138 + v1160);
const v1191=Math.fround(v1139 + v1163);
const v1192=Math.fround(v1140 + v1166);
const v1193=Math.fround(v1141 + v1169);
const v1194=Math.fround(v1142 + v1172);
const v1195=Math.fround(v1143 + v1175);
const v1196=Math.fround(v1144 + v1178);
const v1197=Math.fround(v1145 + v1181);
const v1198=Math.fround(v1146 + v1184);
const v1200=Math.fround(v604 * v604);
const v1201=Math.fround(v607 * v604);
const v1202=Math.fround(v604 * v607);
const v1203=Math.fround(v1201 + v1202);
const v1204=Math.fround(v610 * v604);
const v1205=Math.fround(v604 * v610);
const v1206=Math.fround(v1204 + v1205);
const v1207=Math.fround(v613 * v604);
const v1208=Math.fround(v604 * v613);
const v1209=Math.fround(v1207 + v1208);
const v1210=Math.fround(v616 * v604);
const v1211=Math.fround(v604 * v616);
const v1212=Math.fround(v1210 + v1211);
const v1213=Math.fround(v619 * v604);
const v1214=Math.fround(v604 * v619);
const v1215=Math.fround(v1213 + v1214);
const v1216=Math.fround(v622 * v604);
const v1217=Math.fround(v604 * v622);
const v1218=Math.fround(v1216 + v1217);
const v1219=Math.fround(v625 * v604);
const v1220=Math.fround(v604 * v625);
const v1221=Math.fround(v1219 + v1220);
const v1222=Math.fround(v628 * v604);
const v1223=Math.fround(v604 * v628);
const v1224=Math.fround(v1222 + v1223);
const v1225=Math.fround(v631 * v604);
const v1226=Math.fround(v604 * v631);
const v1227=Math.fround(v1225 + v1226);
const v1228=Math.fround(v634 * v604);
const v1229=Math.fround(v604 * v634);
const v1230=Math.fround(v1228 + v1229);
const v1231=Math.fround(v637 * v604);
const v1232=Math.fround(v604 * v637);
const v1233=Math.fround(v1231 + v1232);
const v1234=Math.fround(v640 * v604);
const v1235=Math.fround(v604 * v640);
const v1236=Math.fround(v1234 + v1235);
const v1238=Math.fround(v1186 + v1200);
const v1239=Math.fround(v1187 + v1203);
const v1240=Math.fround(v1188 + v1206);
const v1241=Math.fround(v1189 + v1209);
const v1242=Math.fround(v1190 + v1212);
const v1243=Math.fround(v1191 + v1215);
const v1244=Math.fround(v1192 + v1218);
const v1245=Math.fround(v1193 + v1221);
const v1246=Math.fround(v1194 + v1224);
const v1247=Math.fround(v1195 + v1227);
const v1248=Math.fround(v1196 + v1230);
const v1249=Math.fround(v1197 + v1233);
const v1250=Math.fround(v1198 + v1236);
return ({["value"]:v1238,["tangent_0"]:v1239,["tangent_1"]:v1240,["tangent_2"]:v1241,["tangent_3"]:v1242,["tangent_4"]:v1243,["tangent_5"]:v1244,["tangent_6"]:v1245,["tangent_7"]:v1246,["tangent_8"]:v1247,["tangent_9"]:v1248,["tangent_10"]:v1249,["tangent_11"]:v1250});}
function __fn12(v1251,v1252){
v1252=__nfValue(v1252);
const v1253=v1251["p"];
const v1254=__nfValue(v1253["a"]);
const v1255=1.0;
const v1256=0.0;
const v1258=v1251["p"];
const v1259=__nfValue(v1258["b"]);
const v1262=v1251["q"];
const v1263=__nfValue(v1262["a"]);
const v1265=v1251["q"];
const v1266=__nfValue(v1265["b"]);
const v1269=v1251["r"];
const v1270=__nfValue(v1269["a"]);
const v1272=v1251["r"];
const v1273=__nfValue(v1272["b"]);
const v1276=v1251["s"];
const v1277=__nfValue(v1276["a"]);
const v1279=v1251["s"];
const v1280=__nfValue(v1279["b"]);
const v1283=v1251["t"];
const v1284=__nfValue(v1283["a"]);
const v1286=v1251["t"];
const v1287=__nfValue(v1286["b"]);
const v1290=v1251["u"];
const v1291=__nfValue(v1290["a"]);
const v1293=v1251["u"];
const v1294=__nfValue(v1293["b"]);
const v1299=__record0(v1254,v1259,v1263,v1266,v1270,v1273,v1277,v1280,v1284,v1287,v1291,v1294,v1252);
const v1300=__nfValue(v1299["tangent_0"]);
const v1301=__nfValue(v1299["tangent_1"]);
const v1303=__nfValue(v1299["tangent_2"]);
const v1304=__nfValue(v1299["tangent_3"]);
const v1306=__nfValue(v1299["tangent_4"]);
const v1307=__nfValue(v1299["tangent_5"]);
const v1309=__nfValue(v1299["tangent_6"]);
const v1310=__nfValue(v1299["tangent_7"]);
const v1312=__nfValue(v1299["tangent_8"]);
const v1313=__nfValue(v1299["tangent_9"]);
const v1315=__nfValue(v1299["tangent_10"]);
const v1316=__nfValue(v1299["tangent_11"]);
return ({["p"]:({["a"]:v1300,["b"]:v1301}),["q"]:({["a"]:v1303,["b"]:v1304}),["r"]:({["a"]:v1306,["b"]:v1307}),["s"]:({["a"]:v1309,["b"]:v1310}),["t"]:({["a"]:v1312,["b"]:v1313}),["u"]:({["a"]:v1315,["b"]:v1316})});}
function __fn13(v1318,v1319){
const v1320=__nfValue(v1318["value"]);
const v1321=__nfValue(v1319["value"]);
const v1322=Math.fround(__nfNumber(v1320) - __nfNumber(v1321));
const v1323=__nfValue(v1318["tangent"]);
const v1324=__nfValue(v1319["tangent"]);
const v1325=Math.fround(__nfNumber(v1323) - __nfNumber(v1324));
return ({["value"]:v1322,["tangent"]:v1325});}
function __fn14(v1326,v1327){
const v1328=__nfValue(v1326["value"]);
const v1329=__nfValue(v1327["value"]);
const v1330=Math.fround(__nfNumber(v1328) + __nfNumber(v1329));
const v1331=__nfValue(v1326["tangent"]);
const v1332=__nfValue(v1327["tangent"]);
const v1333=Math.fround(__nfNumber(v1331) + __nfNumber(v1332));
return ({["value"]:v1330,["tangent"]:v1333});}
function __fn15(v1334,v1335){
const v1336=__nfValue(v1334["value"]);
const v1337=__nfValue(v1335["value"]);
const v1338=Math.fround(__nfNumber(v1336) * __nfNumber(v1337));
const v1339=__nfValue(v1334["tangent"]);
const v1340=__nfValue(v1335["value"]);
const v1341=Math.fround(__nfNumber(v1339) * __nfNumber(v1340));
const v1342=__nfValue(v1334["value"]);
const v1343=__nfValue(v1335["tangent"]);
const v1344=Math.fround(__nfNumber(v1342) * __nfNumber(v1343));
const v1345=Math.fround(v1341 + v1344);
return ({["value"]:v1338,["tangent"]:v1345});}
function __fn16(v1346,v1347){
const v1348=v1346["p"];
const v1349=v1348["a"];
const v1350=__fn13(v1349,v1347);
const v1351=v1346["p"];
const v1352=v1351["b"];
const v1353=__fn14(v1352,v1347);
const v1354=v1346["q"];
const v1355=v1354["a"];
const v1356=__fn13(v1355,v1347);
const v1357=v1346["q"];
const v1358=v1357["b"];
const v1359=__fn14(v1358,v1347);
const v1360=v1346["r"];
const v1361=v1360["a"];
const v1362=__fn13(v1361,v1347);
const v1363=v1346["r"];
const v1364=v1363["b"];
const v1365=__fn14(v1364,v1347);
const v1366=v1346["s"];
const v1367=v1366["a"];
const v1368=__fn13(v1367,v1347);
const v1369=v1346["s"];
const v1370=v1369["b"];
const v1371=__fn14(v1370,v1347);
const v1372=v1346["t"];
const v1373=v1372["a"];
const v1374=__fn13(v1373,v1347);
const v1375=v1346["t"];
const v1376=v1375["b"];
const v1377=__fn14(v1376,v1347);
const v1378=v1346["u"];
const v1379=v1378["a"];
const v1380=__fn13(v1379,v1347);
const v1381=v1346["u"];
const v1382=v1381["b"];
const v1383=__fn14(v1382,v1347);
const v1384=__fn15(v1350,v1350);
const v1385=__fn15(v1353,v1353);
const v1386=__fn14(v1384,v1385);
const v1387=__fn15(v1356,v1356);
const v1388=__fn14(v1386,v1387);
const v1389=__fn15(v1359,v1359);
const v1390=__fn14(v1388,v1389);
const v1391=__fn15(v1362,v1362);
const v1392=__fn14(v1390,v1391);
const v1393=__fn15(v1365,v1365);
const v1394=__fn14(v1392,v1393);
const v1395=__fn15(v1368,v1368);
const v1396=__fn14(v1394,v1395);
const v1397=__fn15(v1371,v1371);
const v1398=__fn14(v1396,v1397);
const v1399=__fn15(v1374,v1374);
const v1400=__fn14(v1398,v1399);
const v1401=__fn15(v1377,v1377);
const v1402=__fn14(v1400,v1401);
const v1403=__fn15(v1380,v1380);
const v1404=__fn14(v1402,v1403);
const v1405=__fn15(v1383,v1383);
return __fn14(v1404,v1405);}
function __fn17(v1406,v1407,v1408){
v1408=__nfValue(v1408);
const v1409=v1406["p"];
const v1410=__nfValue(v1409["a"]);
const v1411=v1407["p"];
const v1412=__nfValue(v1411["a"]);
const v1414=v1406["p"];
const v1415=__nfValue(v1414["b"]);
const v1416=v1407["p"];
const v1417=__nfValue(v1416["b"]);
const v1420=v1406["q"];
const v1421=__nfValue(v1420["a"]);
const v1422=v1407["q"];
const v1423=__nfValue(v1422["a"]);
const v1425=v1406["q"];
const v1426=__nfValue(v1425["b"]);
const v1427=v1407["q"];
const v1428=__nfValue(v1427["b"]);
const v1431=v1406["r"];
const v1432=__nfValue(v1431["a"]);
const v1433=v1407["r"];
const v1434=__nfValue(v1433["a"]);
const v1436=v1406["r"];
const v1437=__nfValue(v1436["b"]);
const v1438=v1407["r"];
const v1439=__nfValue(v1438["b"]);
const v1442=v1406["s"];
const v1443=__nfValue(v1442["a"]);
const v1444=v1407["s"];
const v1445=__nfValue(v1444["a"]);
const v1447=v1406["s"];
const v1448=__nfValue(v1447["b"]);
const v1449=v1407["s"];
const v1450=__nfValue(v1449["b"]);
const v1453=v1406["t"];
const v1454=__nfValue(v1453["a"]);
const v1455=v1407["t"];
const v1456=__nfValue(v1455["a"]);
const v1458=v1406["t"];
const v1459=__nfValue(v1458["b"]);
const v1460=v1407["t"];
const v1461=__nfValue(v1460["b"]);
const v1464=v1406["u"];
const v1465=__nfValue(v1464["a"]);
const v1466=v1407["u"];
const v1467=__nfValue(v1466["a"]);
const v1469=v1406["u"];
const v1470=__nfValue(v1469["b"]);
const v1471=v1407["u"];
const v1472=__nfValue(v1471["b"]);
const v1476=0.0;
const v1480=Math.fround(__nfNumber(v1410) - __nfNumber(v1408));
const v1481=Math.fround(__nfNumber(v1412) - v1476);
const v1485=Math.fround(__nfNumber(v1415) + __nfNumber(v1408));
const v1486=Math.fround(__nfNumber(v1417) + v1476);
const v1490=Math.fround(__nfNumber(v1421) - __nfNumber(v1408));
const v1491=Math.fround(__nfNumber(v1423) - v1476);
const v1495=Math.fround(__nfNumber(v1426) + __nfNumber(v1408));
const v1496=Math.fround(__nfNumber(v1428) + v1476);
const v1500=Math.fround(__nfNumber(v1432) - __nfNumber(v1408));
const v1501=Math.fround(__nfNumber(v1434) - v1476);
const v1505=Math.fround(__nfNumber(v1437) + __nfNumber(v1408));
const v1506=Math.fround(__nfNumber(v1439) + v1476);
const v1510=Math.fround(__nfNumber(v1443) - __nfNumber(v1408));
const v1511=Math.fround(__nfNumber(v1445) - v1476);
const v1515=Math.fround(__nfNumber(v1448) + __nfNumber(v1408));
const v1516=Math.fround(__nfNumber(v1450) + v1476);
const v1520=Math.fround(__nfNumber(v1454) - __nfNumber(v1408));
const v1521=Math.fround(__nfNumber(v1456) - v1476);
const v1525=Math.fround(__nfNumber(v1459) + __nfNumber(v1408));
const v1526=Math.fround(__nfNumber(v1461) + v1476);
const v1530=Math.fround(__nfNumber(v1465) - __nfNumber(v1408));
const v1531=Math.fround(__nfNumber(v1467) - v1476);
const v1535=Math.fround(__nfNumber(v1470) + __nfNumber(v1408));
const v1536=Math.fround(__nfNumber(v1472) + v1476);
const v1540=__record1(v1480,v1481,v1480,v1481);
const v1543=__record1(v1485,v1486,v1485,v1486);
const v1544=__fn14(v1540,v1543);
const v1547=__record1(v1490,v1491,v1490,v1491);
const v1548=__fn14(v1544,v1547);
const v1551=__record1(v1495,v1496,v1495,v1496);
const v1552=__fn14(v1548,v1551);
const v1555=__record1(v1500,v1501,v1500,v1501);
const v1556=__fn14(v1552,v1555);
const v1559=Math.fround(v1505 * v1505);
const v1560=Math.fround(v1506 * v1505);
const v1561=Math.fround(v1505 * v1506);
const v1562=Math.fround(v1560 + v1561);
const v1564=__nfValue(v1556["value"]);
const v1565=Math.fround(__nfNumber(v1564) + v1559);
const v1566=__nfValue(v1556["tangent"]);
const v1567=Math.fround(__nfNumber(v1566) + v1562);
const v1571=Math.fround(v1510 * v1510);
const v1572=Math.fround(v1511 * v1510);
const v1573=Math.fround(v1510 * v1511);
const v1574=Math.fround(v1572 + v1573);
const v1576=Math.fround(v1565 + v1571);
const v1577=Math.fround(v1567 + v1574);
const v1581=Math.fround(v1515 * v1515);
const v1582=Math.fround(v1516 * v1515);
const v1583=Math.fround(v1515 * v1516);
const v1584=Math.fround(v1582 + v1583);
const v1586=Math.fround(v1576 + v1581);
const v1587=Math.fround(v1577 + v1584);
const v1591=Math.fround(v1520 * v1520);
const v1592=Math.fround(v1521 * v1520);
const v1593=Math.fround(v1520 * v1521);
const v1594=Math.fround(v1592 + v1593);
const v1596=Math.fround(v1586 + v1591);
const v1597=Math.fround(v1587 + v1594);
const v1601=Math.fround(v1525 * v1525);
const v1602=Math.fround(v1526 * v1525);
const v1603=Math.fround(v1525 * v1526);
const v1604=Math.fround(v1602 + v1603);
const v1606=Math.fround(v1596 + v1601);
const v1607=Math.fround(v1597 + v1604);
const v1611=Math.fround(v1530 * v1530);
const v1612=Math.fround(v1531 * v1530);
const v1613=Math.fround(v1530 * v1531);
const v1614=Math.fround(v1612 + v1613);
const v1616=Math.fround(v1606 + v1611);
const v1617=Math.fround(v1607 + v1614);
const v1621=Math.fround(v1535 * v1535);
const v1622=Math.fround(v1536 * v1535);
const v1623=Math.fround(v1535 * v1536);
const v1624=Math.fround(v1622 + v1623);
const v1626=Math.fround(v1616 + v1621);
const v1627=Math.fround(v1617 + v1624);
const v1628=({["value"]:v1626,["tangent"]:v1627});
return v1627;}
function __record0(v2981,v2982,v2983,v2984,v2985,v2986,v2987,v2988,v2989,v2990,v2991,v2992,v2993){
const v2994=1.0;
const v2995=0.0;
const v3017=Math.fround(__nfNumber(v2981) - __nfNumber(v2993));
const v3018=Math.fround(v2994 - v2995);
const v3019=Math.fround(v2995 - v2995);
const v3022=Math.fround(__nfNumber(v2982) + __nfNumber(v2993));
const v3023=Math.fround(v2995 + v2995);
const v3024=Math.fround(v2994 + v2995);
const v3027=Math.fround(__nfNumber(v2983) - __nfNumber(v2993));
const v3030=Math.fround(__nfNumber(v2984) + __nfNumber(v2993));
const v3033=Math.fround(__nfNumber(v2985) - __nfNumber(v2993));
const v3036=Math.fround(__nfNumber(v2986) + __nfNumber(v2993));
const v3039=Math.fround(__nfNumber(v2987) - __nfNumber(v2993));
const v3042=Math.fround(__nfNumber(v2988) + __nfNumber(v2993));
const v3045=Math.fround(__nfNumber(v2989) - __nfNumber(v2993));
const v3048=Math.fround(__nfNumber(v2990) + __nfNumber(v2993));
const v3051=Math.fround(__nfNumber(v2991) - __nfNumber(v2993));
const v3054=Math.fround(__nfNumber(v2992) + __nfNumber(v2993));
const v3056=Math.fround(v3017 * v3017);
const v3057=Math.fround(v3018 * v3017);
const v3058=Math.fround(v3017 * v3018);
const v3059=Math.fround(v3057 + v3058);
const v3060=Math.fround(v3019 * v3017);
const v3061=Math.fround(v3017 * v3019);
const v3062=Math.fround(v3060 + v3061);
const v3064=Math.fround(v3022 * v3022);
const v3065=Math.fround(v3023 * v3022);
const v3066=Math.fround(v3022 * v3023);
const v3067=Math.fround(v3065 + v3066);
const v3068=Math.fround(v3024 * v3022);
const v3069=Math.fround(v3022 * v3024);
const v3070=Math.fround(v3068 + v3069);
const v3072=Math.fround(v3056 + v3064);
const v3073=Math.fround(v3059 + v3067);
const v3074=Math.fround(v3062 + v3070);
const v3075=Math.fround(v3062 + v3067);
const v3077=Math.fround(v3027 * v3027);
const v3078=Math.fround(v3019 * v3027);
const v3079=Math.fround(v3027 * v3019);
const v3080=Math.fround(v3078 + v3079);
const v3081=Math.fround(v3018 * v3027);
const v3082=Math.fround(v3027 * v3018);
const v3083=Math.fround(v3081 + v3082);
const v3085=Math.fround(v3072 + v3077);
const v3086=Math.fround(v3073 + v3080);
const v3087=Math.fround(v3074 + v3080);
const v3088=Math.fround(v3075 + v3083);
const v3089=Math.fround(v3075 + v3080);
const v3091=Math.fround(v3030 * v3030);
const v3092=Math.fround(v3023 * v3030);
const v3093=Math.fround(v3030 * v3023);
const v3094=Math.fround(v3092 + v3093);
const v3095=Math.fround(v3024 * v3030);
const v3096=Math.fround(v3030 * v3024);
const v3097=Math.fround(v3095 + v3096);
const v3099=Math.fround(v3085 + v3091);
const v3100=Math.fround(v3086 + v3094);
const v3101=Math.fround(v3087 + v3094);
const v3102=Math.fround(v3088 + v3094);
const v3103=Math.fround(v3089 + v3097);
const v3104=Math.fround(v3089 + v3094);
const v3106=Math.fround(v3033 * v3033);
const v3107=Math.fround(v3019 * v3033);
const v3108=Math.fround(v3033 * v3019);
const v3109=Math.fround(v3107 + v3108);
const v3110=Math.fround(v3018 * v3033);
const v3111=Math.fround(v3033 * v3018);
const v3112=Math.fround(v3110 + v3111);
const v3114=Math.fround(v3099 + v3106);
const v3115=Math.fround(v3100 + v3109);
const v3116=Math.fround(v3101 + v3109);
const v3117=Math.fround(v3102 + v3109);
const v3118=Math.fround(v3103 + v3109);
const v3119=Math.fround(v3104 + v3112);
const v3120=Math.fround(v3104 + v3109);
const v3122=Math.fround(v3036 * v3036);
const v3123=Math.fround(v3023 * v3036);
const v3124=Math.fround(v3036 * v3023);
const v3125=Math.fround(v3123 + v3124);
const v3126=Math.fround(v3024 * v3036);
const v3127=Math.fround(v3036 * v3024);
const v3128=Math.fround(v3126 + v3127);
const v3130=Math.fround(v3114 + v3122);
const v3131=Math.fround(v3115 + v3125);
const v3132=Math.fround(v3116 + v3125);
const v3133=Math.fround(v3117 + v3125);
const v3134=Math.fround(v3118 + v3125);
const v3135=Math.fround(v3119 + v3125);
const v3136=Math.fround(v3120 + v3128);
const v3137=Math.fround(v3120 + v3125);
const v3139=Math.fround(v3039 * v3039);
const v3140=Math.fround(v3019 * v3039);
const v3141=Math.fround(v3039 * v3019);
const v3142=Math.fround(v3140 + v3141);
const v3143=Math.fround(v3018 * v3039);
const v3144=Math.fround(v3039 * v3018);
const v3145=Math.fround(v3143 + v3144);
const v3147=Math.fround(v3130 + v3139);
const v3148=Math.fround(v3131 + v3142);
const v3149=Math.fround(v3132 + v3142);
const v3150=Math.fround(v3133 + v3142);
const v3151=Math.fround(v3134 + v3142);
const v3152=Math.fround(v3135 + v3142);
const v3153=Math.fround(v3136 + v3142);
const v3154=Math.fround(v3137 + v3145);
const v3155=Math.fround(v3137 + v3142);
const v3157=Math.fround(v3042 * v3042);
const v3158=Math.fround(v3023 * v3042);
const v3159=Math.fround(v3042 * v3023);
const v3160=Math.fround(v3158 + v3159);
const v3161=Math.fround(v3024 * v3042);
const v3162=Math.fround(v3042 * v3024);
const v3163=Math.fround(v3161 + v3162);
const v3165=Math.fround(v3147 + v3157);
const v3166=Math.fround(v3148 + v3160);
const v3167=Math.fround(v3149 + v3160);
const v3168=Math.fround(v3150 + v3160);
const v3169=Math.fround(v3151 + v3160);
const v3170=Math.fround(v3152 + v3160);
const v3171=Math.fround(v3153 + v3160);
const v3172=Math.fround(v3154 + v3160);
const v3173=Math.fround(v3155 + v3163);
const v3174=Math.fround(v3155 + v3160);
const v3176=Math.fround(v3045 * v3045);
const v3177=Math.fround(v3019 * v3045);
const v3178=Math.fround(v3045 * v3019);
const v3179=Math.fround(v3177 + v3178);
const v3180=Math.fround(v3018 * v3045);
const v3181=Math.fround(v3045 * v3018);
const v3182=Math.fround(v3180 + v3181);
const v3184=Math.fround(v3165 + v3176);
const v3185=Math.fround(v3166 + v3179);
const v3186=Math.fround(v3167 + v3179);
const v3187=Math.fround(v3168 + v3179);
const v3188=Math.fround(v3169 + v3179);
const v3189=Math.fround(v3170 + v3179);
const v3190=Math.fround(v3171 + v3179);
const v3191=Math.fround(v3172 + v3179);
const v3192=Math.fround(v3173 + v3179);
const v3193=Math.fround(v3174 + v3182);
const v3194=Math.fround(v3174 + v3179);
const v3196=Math.fround(v3048 * v3048);
const v3197=Math.fround(v3023 * v3048);
const v3198=Math.fround(v3048 * v3023);
const v3199=Math.fround(v3197 + v3198);
const v3200=Math.fround(v3024 * v3048);
const v3201=Math.fround(v3048 * v3024);
const v3202=Math.fround(v3200 + v3201);
const v3204=Math.fround(v3184 + v3196);
const v3205=Math.fround(v3185 + v3199);
const v3206=Math.fround(v3186 + v3199);
const v3207=Math.fround(v3187 + v3199);
const v3208=Math.fround(v3188 + v3199);
const v3209=Math.fround(v3189 + v3199);
const v3210=Math.fround(v3190 + v3199);
const v3211=Math.fround(v3191 + v3199);
const v3212=Math.fround(v3192 + v3199);
const v3213=Math.fround(v3193 + v3199);
const v3214=Math.fround(v3194 + v3202);
const v3215=Math.fround(v3194 + v3199);
const v3217=Math.fround(v3051 * v3051);
const v3218=Math.fround(v3019 * v3051);
const v3219=Math.fround(v3051 * v3019);
const v3220=Math.fround(v3218 + v3219);
const v3221=Math.fround(v3018 * v3051);
const v3222=Math.fround(v3051 * v3018);
const v3223=Math.fround(v3221 + v3222);
const v3225=Math.fround(v3204 + v3217);
const v3226=Math.fround(v3205 + v3220);
const v3227=Math.fround(v3206 + v3220);
const v3228=Math.fround(v3207 + v3220);
const v3229=Math.fround(v3208 + v3220);
const v3230=Math.fround(v3209 + v3220);
const v3231=Math.fround(v3210 + v3220);
const v3232=Math.fround(v3211 + v3220);
const v3233=Math.fround(v3212 + v3220);
const v3234=Math.fround(v3213 + v3220);
const v3235=Math.fround(v3214 + v3220);
const v3236=Math.fround(v3215 + v3223);
const v3237=Math.fround(v3215 + v3220);
const v3239=Math.fround(v3054 * v3054);
const v3240=Math.fround(v3023 * v3054);
const v3241=Math.fround(v3054 * v3023);
const v3242=Math.fround(v3240 + v3241);
const v3243=Math.fround(v3024 * v3054);
const v3244=Math.fround(v3054 * v3024);
const v3245=Math.fround(v3243 + v3244);
const v3247=Math.fround(v3225 + v3239);
const v3248=Math.fround(v3226 + v3242);
const v3249=Math.fround(v3227 + v3242);
const v3250=Math.fround(v3228 + v3242);
const v3251=Math.fround(v3229 + v3242);
const v3252=Math.fround(v3230 + v3242);
const v3253=Math.fround(v3231 + v3242);
const v3254=Math.fround(v3232 + v3242);
const v3255=Math.fround(v3233 + v3242);
const v3256=Math.fround(v3234 + v3242);
const v3257=Math.fround(v3235 + v3242);
const v3258=Math.fround(v3236 + v3242);
const v3259=Math.fround(v3237 + v3245);
return ({["value"]:v3247,["tangent_0"]:v3248,["tangent_1"]:v3249,["tangent_2"]:v3250,["tangent_3"]:v3251,["tangent_4"]:v3252,["tangent_5"]:v3253,["tangent_6"]:v3254,["tangent_7"]:v3255,["tangent_8"]:v3256,["tangent_9"]:v3257,["tangent_10"]:v3258,["tangent_11"]:v3259});}
function __record1(v3260,v3261,v3262,v3263){
const v3266=Math.fround(v3260 * v3262);
const v3267=Math.fround(v3261 * v3262);
const v3268=Math.fround(v3260 * v3263);
const v3269=Math.fround(v3267 + v3268);
return ({["value"]:v3266,["tangent"]:v3269});}
const __namedTypes={"Bundle":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},"Node":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"},"Pair":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"},"__ink_differential_0":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"__ink_differential_2":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"},"__ink_differential_21":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"},"__ink_differential_22":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"},"__ink_differential_4":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"},"__ink_differential_5":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"cde8fee8c8582ecdf344d864c391c82db943921b45788731c852eccb1b6d2309","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"f32_computation":"native-number-with-exact-nonfinite-tags","f32_storage":"native-number-with-exact-nonfinite-tags","functions":[{"destination":null,"index":0,"internal":false,"name":"component","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":1,"internal":false,"name":"energy","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":2,"internal":false,"name":"derivatives","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"destination":null,"index":3,"internal":false,"name":"direction","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":4,"internal":false,"name":"twice","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":5,"internal":false,"name":"selected","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"c","type":{"kind":"bool"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"destination":null,"index":6,"internal":false,"name":"branches","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}},{"name":"c","type":{"kind":"bool"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"destination":null,"index":7,"internal":false,"name":"looping","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"destination":null,"index":8,"internal":false,"name":"strict_unused","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":9,"internal":false,"name":"strict","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":10,"internal":false,"name":"history","parallel":false,"params":[{"name":"x","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}},{"destination":null,"index":11,"internal":false,"name":"__ink_differential_3","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"}},{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"destination":null,"index":12,"internal":false,"name":"__ink_differential_1","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"destination":null,"index":13,"internal":false,"name":"__ink_differential_23","parallel":false,"params":[{"name":"__ink_differential_24","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_25","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":14,"internal":false,"name":"__ink_differential_27","parallel":false,"params":[{"name":"__ink_differential_28","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_29","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":15,"internal":false,"name":"__ink_differential_31","parallel":false,"params":[{"name":"__ink_differential_32","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_33","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":16,"internal":false,"name":"__ink_differential_20","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"}},{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":17,"internal":false,"name":"__ink_differential_19","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"__ink_differential_35","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}}],"named_types":{"Bundle":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},"Node":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"},"Pair":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"},"__ink_differential_0":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"__ink_differential_2":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"},"__ink_differential_21":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"},"__ink_differential_22":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"},"__ink_differential_4":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"},"__ink_differential_5":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},"prepared_compiled":{"evaluation":"lazy source-order; successful bindings only","functions":[{"factory":false,"function":"component","reason":"no reusable captured work"},{"factory":false,"function":"energy","reason":"no reusable captured work"},{"delegated_calls":1,"factory":true,"function":"derivatives","retained_bindings":0},{"factory":false,"function":"direction","reason":"no reusable captured work"},{"factory":false,"function":"twice","reason":"no reusable captured work"},{"factory":false,"function":"selected","reason":"no reusable captured work"},{"factory":false,"function":"branches","reason":"no reusable captured work"},{"factory":false,"function":"looping","reason":"no reusable captured work"},{"factory":false,"function":"strict_unused","reason":"no reusable captured work"},{"factory":false,"function":"strict","reason":"no reusable captured work"},{"factory":false,"function":"history","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_3","reason":"prepared residual binding budget"},{"delegated_calls":1,"factory":true,"function":"__ink_differential_1","retained_bindings":1},{"factory":false,"function":"__ink_differential_23","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_27","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_31","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_20","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_19","reason":"no reusable captured work"}],"lifetime":"prepared token","semantics":"sealed-value-residual-v1"},"private_record_elisions":[],"private_sum_spines":[],"schema":1,"state":null,"wire":{"format":"ink-value-wire-v1","functions":{"__ink_differential_1":{"arguments":{"format":"ink-value-wire-v1","identity":"0682599d89e5a0da92fd3bb3a63bdbef728533bcace07efac64cbc6207072abd","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"7882b66162c075a7679604fdc86c31922fb250d10394af5aa2d1354c654b72e5","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}}},"__ink_differential_19":{"arguments":{"format":"ink-value-wire-v1","identity":"4b9a4eccc6d2615eb92680d1626d236c77340ef306b699fe9722c753783a60da","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"__ink_differential_35","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"__ink_differential_20":{"arguments":{"format":"ink-value-wire-v1","identity":"009ea546acc19d5b810484974d68d3c4457e94cf4bde388fdf2151c2e57e2a8b","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"}},{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_23":{"arguments":{"format":"ink-value-wire-v1","identity":"14dad48e9c7540e15bc5834542aecb46075a5f6db75bdf730ed1ae3cea29fd65","named":{},"root":{"fields":[{"name":"__ink_differential_24","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_25","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_27":{"arguments":{"format":"ink-value-wire-v1","identity":"3ff642723860241049980d889d5b40bc6385dbe1d5565864a6f0cff2789d7d65","named":{},"root":{"fields":[{"name":"__ink_differential_28","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_29","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_3":{"arguments":{"format":"ink-value-wire-v1","identity":"1d368d11ae3fd3df968cc51472c46914649ff205acd33e8d0894f38dfbe17c52","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"}},{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"bb2b2f3efce5ad7f78fd263ef8cf59e1adcabaeb4e987b0d193c2a16c631b760","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}},"__ink_differential_31":{"arguments":{"format":"ink-value-wire-v1","identity":"b89078033f0e43e3b942a030299778636af73ee6bf52de60b442828bffa87a4a","named":{},"root":{"fields":[{"name":"__ink_differential_32","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_33","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"branches":{"arguments":{"format":"ink-value-wire-v1","identity":"7e470bcf24f723adb7da774fec6821c355982fbef8ce2c31b5fee833dcc69a2c","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"c","type":{"kind":"bool"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"5728eeaa0e138ea2f93b2c91d176edec672a97fdd0e45fa08b4dacd31d4beebf","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}},"component":{"arguments":{"format":"ink-value-wire-v1","identity":"9e9f426322cda6dcb4444ebcf8caf3792884cce27574c91c49d8c179e163ada6","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"derivatives":{"arguments":{"format":"ink-value-wire-v1","identity":"0682599d89e5a0da92fd3bb3a63bdbef728533bcace07efac64cbc6207072abd","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"7882b66162c075a7679604fdc86c31922fb250d10394af5aa2d1354c654b72e5","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}}},"direction":{"arguments":{"format":"ink-value-wire-v1","identity":"0682599d89e5a0da92fd3bb3a63bdbef728533bcace07efac64cbc6207072abd","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"energy":{"arguments":{"format":"ink-value-wire-v1","identity":"0682599d89e5a0da92fd3bb3a63bdbef728533bcace07efac64cbc6207072abd","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"history":{"arguments":{"format":"ink-value-wire-v1","identity":"cc08f1332c0bbd676577f3e81f06e85cc8ef81a32bcbe10b3177d811cc8e0ae2","named":{},"root":{"fields":[{"name":"x","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"06a5b110d3c213512730b89ea5797ec6a338f55b0c357c4c3894a84ac3cfa9e3","named":{"Node":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}},"root":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}}},"looping":{"arguments":{"format":"ink-value-wire-v1","identity":"3d9fa005996e654b10e4e749ab0e2c4a9988b4ba944f21f1019c2132cbcb62b2","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"5728eeaa0e138ea2f93b2c91d176edec672a97fdd0e45fa08b4dacd31d4beebf","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}},"selected":{"arguments":{"format":"ink-value-wire-v1","identity":"a8946948d6a1d8ee77f631669030cc4c45446359c5b73e5817d71710ec234e83","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"c","type":{"kind":"bool"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"5728eeaa0e138ea2f93b2c91d176edec672a97fdd0e45fa08b4dacd31d4beebf","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}},"strict":{"arguments":{"format":"ink-value-wire-v1","identity":"3a34365b0c77659a92326203e995cfb8b5864a51d9641ba81afbf209004e3844","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"strict_unused":{"arguments":{"format":"ink-value-wire-v1","identity":"84d59578f8c7aa53acd5daacd88e348b3c426255a392adda48076dcabfcaf9f1","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"twice":{"arguments":{"format":"ink-value-wire-v1","identity":"84d59578f8c7aa53acd5daacd88e348b3c426255a392adda48076dcabfcaf9f1","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}}}}};
const __implementations=[__fn0,__fn1,__fn2,__fn3,__fn4,__fn5,__fn6,__fn7,__fn8,__fn9,__fn10,__fn11,__fn12,__fn13,__fn14,__fn15,__fn16,__fn17];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
const __inputTypes=[{"capture":[false,true],"types":[{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"},{"kind":"f32"}]},{"capture":[false,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f32"}]},{"capture":[false,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f32"}]},{"capture":[false,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f32"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}]},{"capture":[false,true],"types":[{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"},{"kind":"bool"}]},{"capture":[true,true],"types":[{"kind":"f32"},{"kind":"bool"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}]},{"capture":[true,true],"types":[{"kind":"f32"},{"kind":"f32"}]},{"capture":[true],"types":[{"kind":"u32"}]},{"capture":[false,false],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}]},{"capture":[false,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f32"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[false,false],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[false,false,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f32"}]}];

// Descriptor work occurs once at module initialisation, never per word-list call.
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=> {
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const output=__representation(f.result,true);
  const body=__implementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
  const needsInput=input.some(c=>c!==__identity);
  const entry=!needsInput && output===__identity ? implementation :
    (...args)=>{const context=new WeakMap();return output(implementation(...(needsInput ? args.map((v,i)=>input[i](v,context)) : args)),context);};
  return [f.name,entry];
})));
export function call(name,args) { return functions[name](...args); }
// Shared bounded binary codec; generated code supplies exact descriptors.
export const valueWireFormat='ink-value-wire-v1';
// A connection agrees on the complete value schema before using this format.
// Version byte + schema-directed fields; schema identity is out of band.
export const compactValueWireFormat='ink-value-session-v1';
const wireMagic=Uint8Array.of(73,78,75,86,65,76,0,1);
const wireEncoder=new TextEncoder(),wireDecoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const wireDefaults=Object.freeze({bytes:16777216,nodes:1000000,depth:128}),wireDefaultOptions=Object.freeze({});
const wireDecimal=s=>typeof s==='string'&&/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(s);
function wireLimits(options){if(options===wireDefaultOptions||options===wireDefaults)return wireDefaults;const l={...wireDefaults,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>wireDefaults[k])throw Error('wire hard resource limit');return l;}
const wireFloat=new DataView(new ArrayBuffer(4));
function wireDecodeText(bytes,start,end){
 if(end-start<=16){let text='';for(let i=start;i<end;i++){const byte=bytes[i];if(byte>=128)return wireDecoder.decode(bytes.subarray(start,end));text+=String.fromCharCode(byte);}return text;}
 return wireDecoder.decode(bytes.subarray(start,end));
}
function wireUtf8Length(text){let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const wireOwn=(v,k)=>v!==null&&typeof v==='object'&&Object.hasOwn(v,k);
const wireTagged=(v,k)=>wireOwn(v,k)&&Object.keys(v).length===1;
const wireDouble=new DataView(new ArrayBuffer(8));
function wireF64Bits(v){
 if(typeof v==='number'&&Number.isFinite(v)){wireDouble.setFloat64(0,v,true);return wireDouble.getBigUint64(0,true);}
 if(!wireTagged(v,'F64Bits'))wireInvalidValue();const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))wireInvalidValue();
 const bits=BigInt(text);if(bits>18446744073709551615n)wireInvalidValue();return bits;
}
const wireCanonical=v=>Array.isArray(v)?'['+v.map(wireCanonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort((a,b)=>{const x=Array.from(a,c=>c.codePointAt(0)),y=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]-y[i];return x.length-y.length;}).map(k=>JSON.stringify(k)+':'+wireCanonical(v[k])).join(',')+'}':JSON.stringify(v);
export async function createValueCodec(root,named={}){
 const used=new Set(),budget={nodes:100000};
 function check(t,d=0){
  if(d>64||--budget.nodes<0)throw Error('wire descriptor limit');
  const keys={u32:['kind'],u64:['kind'],i32:['kind'],f32:['kind'],f64:['kind'],bool:['kind'],unit:['kind'],string:['kind'],int:['kind'],id:['kind','name'],ref:['kind','name'],enum:['kind','name','variants'],record:['kind','name','fields'],list:['kind','element'],option:['kind','element'],vector:['kind','element','size'],result:['kind','ok','error']}[t?.kind];
  if(!keys||Object.keys(t).length!==keys.length||keys.some(k=>!Object.hasOwn(t,k)))throw Error('invalid wire descriptor');
  if(keys.includes('name')&&(typeof t.name!=='string'||!t.name.isWellFormed()))throw Error('invalid descriptor name');
  if(t.kind==='ref'){if(!used.has(t.name)){used.add(t.name);if(named[t.name]?.kind!=='record'||named[t.name].name!==t.name)throw Error('unresolved wire reference');check(named[t.name],d+1);}}
  if(t.kind==='record'){if(!Array.isArray(t.fields))throw Error('wire fields');const names=new Set();for(const f of t.fields){if(Object.keys(f).length!==2||typeof f.name!=='string'||!f.name.isWellFormed()||names.has(f.name))throw Error('duplicate wire field');names.add(f.name);check(f.type,d+1);}}
  if(t.kind==='enum'&&(!Array.isArray(t.variants)||!t.variants.length||t.variants.length>64||t.variants.some(v=>typeof v!=='string'||!v.isWellFormed())||new Set(t.variants).size!==t.variants.length))throw Error('wire enum');
  if(['list','vector','option'].includes(t.kind)){if(t.kind==='vector'&&(!Number.isInteger(t.size)||t.size<1||t.size>64))throw Error('wire vector');check(t.element,d+1);}
  if(t.kind==='result'){check(t.ok,d+1);check(t.error,d+1);}
 }
 check(root);const names=Object.fromEntries([...used].sort().map(k=>[k,named[k]]));
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',wireEncoder.encode(wireCanonical({format:valueWireFormat,root,named:names}))));
 return new ValueCodec({format:valueWireFormat,root,named:names,identity:Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('')});
}
// Resolve immutable descriptor edges once. Logical validation traverses the
// literal schema; single-child nodes use a loop rather than recursive closures.
function wireValuePlan(codec){
 const seen=new WeakMap();let remaining=100000;
 const build=type=>{
  const t=codec.resolve(type);if(seen.has(t))return seen.get(t);
  if(--remaining<0)throw Error('wire descriptor limit');const p={kind:t.kind,type:t,decode:null,decodeCompact:null};seen.set(t,p);
  if(t.kind==='record')p.fields=t.fields.map(f=>({name:f.name,plan:build(f.type)}));
  if(t.kind==='list'||t.kind==='vector'||t.kind==='option')p.element=build(t.element);
  if(t.kind==='result'){p.ok=build(t.ok);p.error=build(t.error);}
  return p;
 };return build(codec.descriptor.root);
}
function wireBindDecodePlan(root,compact=false){
 const seen=new Set(),pending=[root];let flags=0;
 while(pending.length){
  const p=pending.pop();if(seen.has(p))continue;seen.add(p);if(compact)p.decodeCompact=compactDecodeOperation(p);else p.decode=wireDecodeOperation(p);
  if(p.fields?.length>4)flags|=1;
  if(p.kind==='u32'||p.kind==='i32'||p.kind==='u64'||p.kind==='f32'||p.kind==='f64')flags|=2;
  if(p.fields)for(const f of p.fields)pending.push(f.plan);
  if(p.element)pending.push(p.element);
  if(p.ok){pending.push(p.ok);pending.push(p.error);}
 }
 return flags|4;
}
// Select literal descriptor operations once, without runtime source generation
// or eval. Recursive edges call the completed plan. The generic scanner remains
// the visitor/validation path and an independent materialisation implementation.
function wireReadOperation(p){
 const t=p.type;
 let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':read=(r,end)=>{r.size(end,4);const value={F32Bits:r.view.getUint32(r.cursor,true)};r.cursor=end;return value;};break;
  case 'f64':read=(r,end)=>{r.size(end,8);const value={F64Bits:r.view.getBigUint64(r.cursor,true).toString()};r.cursor=end;return value;};break;
  case 'u64':read=(r,end)=>{r.size(end,8);const value=r.view.getBigUint64(r.cursor,true);r.cursor=end;return value;};break;
  case 'string':read=(r,end)=>r.text(end);break;
  case 'int':read=(r,end)=>{const text=r.text(end);if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=(r,end)=>{const text=r.text(end);if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=(r,end)=>{const text=r.text(end);if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{
    if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;
    if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');
    const values=new Array(n);for(let i=0;i<n;i++)values[i]=element.decode(r,end,d+1);return values;
   };break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1)});break;
    case 2:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1)});break;
    case 3:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1)});break;
    case 4:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1),[fs[3].name]:fs[3].plan.decode(r,end,d+1)});break;
    default:read=(r,end,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decode(r,end,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,end,d)=>{const tag=r.tag(end);return tag?{Some:p.element.decode(r,end,d+1)}:{None:null};};break;
  case 'result':read=(r,end,d)=>r.tag(end)?{Err:p.error.decode(r,end,d+1)}:{Ok:p.ok.decode(r,end,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function wireDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=wireReadOperation(field.plan),name=field.name;
  return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),childEnd=r.enter(end,d+1),item=read(r,childEnd,d+1);if(r.cursor!==childEnd)throw Error('trailing wire frame bytes');const value={[name]:item};if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
 }
 const read=wireReadOperation(p);
 return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
}
class WireDecodeCursor{
 constructor(bytes,view,limits){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
// Bind literal validation and postorder visitation once for every descriptor.
// No logical carriers are allocated; projection still validates every child.
function wireScanPlan(root){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,scan:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.scan=wireScanOperation(p);return p;
 };
 return build(root);
}
function wireScanOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':case 'f64':case 'u64':{const size=p.kind==='f32'?4:8;read=(r,end)=>{r.size(end,size);r.cursor=end;};break;}
  case 'string':read=(r,end)=>{let i=r.cursor;while(i<end&&r.bytes[i]<128)i++;if(i<end)wireDecoder.decode(r.bytes.subarray(r.cursor,end));r.cursor=end;};break;
  case 'int':case 'id':case 'enum':read=(r,end)=>{const text=r.text(end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');for(let i=0;i<n;i++)element.scan(r,end,d+1);};break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>{};break;
    case 1:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);};break;
    case 2:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);};break;
    case 3:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);};break;
    case 4:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);fs[3].plan.scan(r,end,d+1);};break;
    default:read=(r,end,d)=>{for(const f of fs)f.plan.scan(r,end,d+1);};
   }break;
  }
  case 'option':read=(r,end,d)=>{if(r.tag(end))p.element.scan(r,end,d+1);};break;
  case 'result':read=(r,end,d)=>{(r.tag(end)?p.error:p.ok).scan(r,end,d+1);};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return (r,parentEnd,d)=>{
  const end=r.enter(parentEnd,d),start=r.cursor,value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');
  const visitor=r.visitor;if(visitor&&(!r.selected||r.selected.has(t.name))){if(r.spans)visitor(t,r.bytes,start,end,d);else visitor(t,r.bytes.subarray(start,end),d);}
  return value;
 };
}
// Separate methods keep decoding's cursor callsites monomorphic. Both cursors
// are checked against the independent generic scanner and malformed fixtures.
class WireScanCursor{
 constructor(bytes,view,limits,visitor,selected,spans){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.visitor=visitor;this.selected=selected;this.spans=spans;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
function compactReadOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=()=>null;break;
  case 'bool':read=r=>{r.require(1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':case 'i32':read=r=>{r.require(4);const n=p.kind==='u32'?r.view.getUint32(r.cursor,true):r.view.getInt32(r.cursor,true);r.cursor+=4;return n;};break;
  case 'f32':read=r=>{r.require(4);const n=r.view.getUint32(r.cursor,true);r.cursor+=4;return {F32Bits:n};};break;
  case 'f64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return {F64Bits:n.toString()};};break;
  case 'u64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return n;};break;
  case 'string':read=r=>r.text();break;
  case 'int':read=r=>{const text=r.text();if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=r=>{const text=r.text();if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=r=>{const text=r.text();if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':read=(r,d)=>{const n=r.count();if(n>r.remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');const values=new Array(n);for(let i=0;i<n;i++)values[i]=p.element.decodeCompact(r,d+1);return values;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1)});break;
    case 2:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1)});break;
    case 3:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1)});break;
    case 4:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1),[fs[3].name]:fs[3].plan.decodeCompact(r,d+1)});break;
    default:read=(r,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decodeCompact(r,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,d)=>r.tag()?{Some:p.element.decodeCompact(r,d+1)}:{None:null};break;
  case 'result':read=(r,d)=>r.tag()?{Err:p.error.decodeCompact(r,d+1)}:{Ok:p.ok.decodeCompact(r,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function compactDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=compactReadOperation(field.plan),name=field.name;
  return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');if(d+1>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return {[name]:read(r,d+1)};};
 }
 const read=compactReadOperation(p);
 return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return read(r,d);};
}
class CompactDecodeCursor{
 constructor(bytes,limits,flags){this.bytes=bytes;this.view=flags&2?new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength):null;this.cursor=1;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 require(n){if(n>this.bytes.length-this.cursor)throw Error('truncated compact value');}
 count(){
  if(this.cursor>=this.bytes.length)throw Error('truncated compact value');
  const first=this.bytes[this.cursor++];if(first<128)return first;
  let value=first&127,scale=128;
  for(let i=1;i<5;i++){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const byte=this.bytes[this.cursor++];if(i===4&&byte>15)throw Error('compact count overflow');value+=(byte&127)*scale;if(byte<128){if(byte===0)throw Error('noncanonical compact count');return value;}scale*=128;}throw Error('compact count overflow');
 }
 tag(){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const tag=this.bytes[this.cursor++];if(tag>1)throw Error('wire sum tag');return tag;}
 text(){const n=this.count();this.require(n);const start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
function wireInvalidValue(){throw Error('invalid value for wire schema');}
// Capture has the canonical logical meaning of decode(encode(value)), without
// allocating wire bytes. A separate plan leaves validation/decoder hot shapes
// unchanged and never retains host input containers between calls.
function wireCapturePlan(root,checked=true){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,capture:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({name:f.name,plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.capture=checked?wireCaptureOperation(p):wireCopyOperation(p);return p;
 };return build(root);
}
function wireCaptureOperation(p){
 const t=p.type;let copy;
 switch(p.kind){
  case 'unit':copy=v=>{if(v!==null)wireInvalidValue();return null;};break;
  case 'bool':copy=(v,r)=>{if(typeof v!=='boolean')wireInvalidValue();r.add(1);return v;};break;
  case 'u32':case 'i32':{
   const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
   copy=(v,r)=>{if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();r.add(4);return v===0?0:v;};break;
  }
  case 'u64':copy=(v,r)=>{const kind=typeof v;if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();r.add(8);return n;};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'int':case 'id':case 'enum':copy=(v,r)=>{const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;if(typeof text!=='string'||!text.isWellFormed()||text.length>r.limit)wireInvalidValue();if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();r.add(wireUtf8Length(text));return p.kind==='int'?{Int:text}:text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   copy=(v,r,d)=>{if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();const n=v.length;if(n>r.remaining||size!==null&&n!==size)wireInvalidValue();r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=element.capture(v[i],r,d+1);return out;};break;
  }
  case 'record':{
   const fs=p.fields;let fields;
   switch(fs.length){
    case 0:fields=()=>({});break;
    case 1:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:fields=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }
   copy=(v,r,d)=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();for(const f of fs)if(!wireOwn(v,f.name))wireInvalidValue();return fields(v,r,d);};break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'None')&&v.None===null)return {None:null};if(wireTagged(v,'Some'))return {Some:p.element.capture(v.Some,r,d+1)};wireInvalidValue();};break;
  case 'result':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'Ok'))return {Ok:p.ok.capture(v.Ok,r,d+1)};if(wireTagged(v,'Err'))return {Err:p.error.capture(v.Err,r,d+1)};wireInvalidValue();};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
class WireCaptureCursor{
 constructor(limits){this.remaining=limits.nodes;this.depth=limits.depth;this.limit=limits.bytes;this.bytes=40;this.add(0);}
 add(n){this.bytes+=n;if(this.bytes>this.limit)throw Error('wire byte limit');}
 enter(depth,bytes){if(depth>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.add(bytes);}
 text(value){if(value.length>this.limit)throw Error('wire byte limit');this.add(wireUtf8Length(value));}
}
// Literal lowerers share this fixed resource policy with logical capture.
export function createValueCaptureBudget(options=wireDefaultOptions){return new WireCaptureCursor(wireLimits(options));}
// The trusted-value API has the same canonical copy and ownership semantics.
// Its caller supplies a stable value accepted by validateValue. Shape/range
// checks remain at external capture boundaries; resource limits still apply.
function wireCopyOperation(p){
 let copy;
 switch(p.kind){
  case 'unit':copy=()=>null;break;
  case 'bool':copy=(v,r)=>{r.add(1);return v;};break;
  case 'u32':copy=(v,r)=>{r.add(4);return v>>>0;};break;
  case 'i32':copy=(v,r)=>{r.add(4);return v|0;};break;
  case 'u64':copy=(v,r)=>{r.add(8);return BigInt(v);};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'){wireFloat.setFloat32(0,v,true);bits=wireFloat.getUint32(0,true);}else bits=v.F32Bits;r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'id':case 'enum':copy=(v,r)=>{r.add(wireUtf8Length(v));return v;};break;
  case 'int':copy=(v,r)=>{const text=typeof v==='bigint'?v.toString():v.Int;r.add(wireUtf8Length(text));return {Int:text};};break;
  case 'list':case 'vector':copy=(v,r,d)=>{const n=v.length;if(n>r.remaining)throw Error('wire sequence size');r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=p.element.capture(v[i],r,d+1);return out;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:copy=()=>({});break;
    case 1:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:copy=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'None')&&v.None===null?{None:null}:{Some:p.element.capture(v.Some,r,d+1)};};break;
  case 'result':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'Ok')?{Ok:p.ok.capture(v.Ok,r,d+1)}:{Err:p.error.capture(v.Err,r,d+1)};};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
// Emit the cached literal schema with one forward writer. Each value is checked
// where it is consumed; byte bounds belong to the writer, not a second size walk.
function wireEncodeValue(root,value,l,w){
 let remaining=l.nodes;const depthLimit=l.depth;
 const node=(p,v,d)=>{
  if(d>depthLimit||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type,start=w.beginNode();
  switch(p.kind){
   case 'unit':if(v!==null)wireInvalidValue();break;
   case 'bool':if(typeof v!=='boolean')wireInvalidValue();w.byte(+v);break;
   case 'u32':case 'i32':{
    const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
    if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();w.word(v>>>0);break;
   }
   case 'u64':{
    const kind=typeof v;
    if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
    const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();w.wide(n);break;
   }
   case 'f64':w.wide(wireF64Bits(v));break;
   case 'f32':{
    let bits;
    if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}
    else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
    w.word(bits);break;
   }
   case 'string':case 'int':case 'id':case 'enum':{
    const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
    if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&(typeof text!=='string'||!/^[0-9a-f]{32}$/.test(text))||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
    w.text(text);break;
   }
   case 'list':case 'vector':{
    if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
    if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
    w.count(v.length);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);break;
   }
   case 'record':{
    const fs=p.fields;
    if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
    for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
    for(let i=0;i<fs.length;i++){const f=fs[i];node(f.plan,v[f.name],d+1);}break;
   }
   case 'option':{
    if(wireTagged(v,'None')&&v.None===null)w.byte(0);
    else if(wireTagged(v,'Some')){w.byte(1);node(p.element,v.Some,d+1);}else wireInvalidValue();break;
   }
   case 'result':{
    if(wireTagged(v,'Ok')){w.byte(0);node(p.ok,v.Ok,d+1);}
    else if(wireTagged(v,'Err')){w.byte(1);node(p.error,v.Err,d+1);}else wireInvalidValue();break;
   }
   default:throw Error('unsupported wire kind');
  }
  w.endNode(start);
 };
 node(root,value,0);
}
function wireCheckValue(root,value,l){
 let remaining=l.nodes,total=40;
 const add=n=>{total+=n;if(total>l.bytes)throw Error('wire byte limit');};
 const node=(p,v,d)=>{
  while(true){
   if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
   const t=p.type;
   switch(p.kind){
    case 'unit':if(v!==null)wireInvalidValue();add(4);return;
    case 'bool':if(typeof v!=='boolean')wireInvalidValue();add(5);return;
    case 'u32':case 'i32':{
     const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
     if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();add(8);return;
    }
    case 'u64':{
     const kind=typeof v;
     if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
     const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();add(12);return;
    }
    case 'f64':wireF64Bits(v);add(12);return;
    case 'f32':{
     if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();}
     else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();const bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
     add(8);return;
    }
    case 'string':case 'int':case 'id':case 'enum':{
     const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
     if(typeof text!=='string'||!text.isWellFormed()||text.length>l.bytes)wireInvalidValue();
     if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
     add(4+wireUtf8Length(text));return;
    }
    case 'list':case 'vector':{
     if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
     if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
     add(8);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);return;
    }
    case 'record':{
     const fs=p.fields;
     if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
     for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
     add(4);if(!fs.length)return;
     for(let i=0;i<fs.length-1;i++)node(fs[i].plan,v[fs[i].name],d+1);
     const f=fs[fs.length-1];p=f.plan;v=v[f.name];d++;continue;
    }
    case 'option':{
     if(wireTagged(v,'None')&&v.None===null){add(5);return;}
     if(!wireTagged(v,'Some'))wireInvalidValue();add(5);p=p.element;v=v.Some;d++;continue;
    }
    case 'result':{
     if(wireTagged(v,'Ok')){add(5);p=p.ok;v=v.Ok;}
     else if(wireTagged(v,'Err')){add(5);p=p.error;v=v.Err;}else wireInvalidValue();
     d++;continue;
    }
    default:throw Error('unsupported wire kind');
   }
  }
 };
 node(root,value,0);if(total>l.bytes)throw Error('wire byte limit');
}
// A single cursor replaces per-node child closures and {end,value} temporaries.
// Projection filters limit callback materialisation, never schema validation.
function wireScanValue(root,bytes,view,l,materialize,visitor,selected,spans){
 let cursor=40,remaining=l.nodes;
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,parentEnd,d)=>{
  if(d>l.depth||--remaining<0||cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const t=p.type,start=cursor+4,end=start+view.getUint32(cursor,true);if(end>parentEnd)throw Error('truncated wire frame');cursor=start;let value;
  switch(p.kind){
   case 'unit':if(end-start!==0)throw Error('malformed wire scalar');value=null;break;
   case 'bool':if(end-start!==1)throw Error('malformed wire scalar');if(bytes[start]>1)throw Error('invalid wire Bool');value=!!bytes[start];cursor=end;break;
   case 'u32':case 'i32':if(end-start!==4)throw Error('malformed wire scalar');value=p.kind==='u32'?view.getUint32(start,true):view.getInt32(start,true);cursor=end;break;
   case 'f32':if(end-start!==4)throw Error('malformed wire scalar');if(materialize)value={F32Bits:view.getUint32(start,true)};cursor=end;break;
   case 'f64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value={F64Bits:view.getBigUint64(start,true).toString()};cursor=end;break;
   case 'u64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value=view.getBigUint64(start,true);cursor=end;break;
   case 'string':case 'int':case 'id':case 'enum':{
    if(p.kind==='string'&&!materialize){let i=start;while(i<end&&bytes[i]<128)i++;if(i<end)wireDecoder.decode(bytes.subarray(start,end));}
    else{const text=wireDecodeText(bytes,start,end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    cursor=end;break;
   }
   case 'list':case 'vector':{
    if(start+4>end)throw Error('wire list count');const n=view.getUint32(start,true);cursor+=4;
    if(n>remaining||n>Math.floor((end-cursor)/4)||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,end,d+1);if(materialize)value.push(child);}break;
   }
   case 'record':{
    const fs=p.fields;
    // Computed literal keys create own data properties even for __proto__ or
    // prototype setters. Common small records need no descriptor allocations.
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:value={};break;case 1:value={[fs[0].name]:node(fs[0].plan,end,d+1)};break;case 2:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1)};break;case 3:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1)};break;case 4:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1),[fs[3].name]:node(fs[3].plan,end,d+1)};break;}
    }else{if(materialize)value={};for(const f of fs){const child=node(f.plan,end,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}}break;
   }
   case 'option':case 'result':{
    if(start===end||bytes[cursor]>1)throw Error('wire sum tag');const tag=bytes[cursor++];
    if(p.kind==='option'&&tag===0){if(materialize)value={None:null};}
    else{const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,end,d+1);if(materialize)value={[label]:child};}break;
   }
   default:throw Error('unsupported wire kind');
  }
  if(cursor!==end)throw Error('trailing wire frame bytes');
  if(visitor&&(!selected||selected.has(t.name))){if(spans)visitor(t,bytes,start,end,d);else visitor(t,bytes.subarray(start,end),d);}
  return value;
 };
 const result=node(root,bytes.length,0);if(cursor!==bytes.length)throw Error('trailing wire bytes');return result;
}
export class ValueCodec{
 #hash;
 #header;
 #headerWords;
 #descriptor;
 #valuePlan;
 #compactCodec;
 #encoder;
 #decodeBound=0;
 #scanPlan=null;
 #capturePlan=null;
 #copyPlan=null;
 get descriptor(){return this.#descriptor;}
 constructor(descriptor){
  // This synchronous path is for compiler-generated immutable metadata. For
  // untrusted descriptors use createValueCodec and compare the computed identity.
  if(descriptor?.format!==valueWireFormat||!/^[0-9a-f]{64}$/.test(descriptor.identity))throw Error('invalid wire schema');
  this.#descriptor=structuredClone(descriptor);this.#hash=Uint8Array.from(descriptor.identity.match(/../g),s=>parseInt(s,16));
  this.#header=new Uint8Array(40);this.#header.set(wireMagic);this.#header.set(this.#hash,8);
  const headerView=new DataView(this.#header.buffer);this.#headerWords=Array.from({length:10},(_,i)=>headerView.getUint32(i*4,true));
  const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}};freeze(this.descriptor);this.#valuePlan=wireValuePlan(this);
 }
 resolve(t){for(let i=0;i<64;i++){if(t.kind!=='ref')return t;t=this.descriptor.named[t.name];if(!t)throw Error('wire reference');}throw Error('wire reference cycle');}
 validateValue(value,options=wireDefaultOptions){wireCheckValue(this.#valuePlan,value,wireLimits(options));return true;}
 capture(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#capturePlan??=wireCapturePlan(this.#valuePlan);return this.#capturePlan.capture(value,new WireCaptureCursor(limits),0);}
 copy(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#copyPlan??=wireCapturePlan(this.#valuePlan,false);return this.#copyPlan.capture(value,new WireCaptureCursor(limits),0);}
 compact(){return this.#compactCodec??=new CompactValueCodec(this);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new WireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.bytes(this.#header);wireEncodeValue(this.#valuePlan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new WireEncoder(options);w.bytes(wireMagic);w.bytes(this.#hash);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 scan(bytes,options=wireDefaultOptions,materialize=false,visitor=null,names=null,spans=false){
  const l=wireLimits(options);if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<44||bytes.length>l.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==this.#headerWords[i])throw Error('wire format or schema mismatch');
  if(names!==null&&(!Array.isArray(names)||names.length>100000||names.some(n=>typeof n!=='string')))throw Error('wire visitor names');
  if(materialize&&!visitor){this.#decodeBound||=wireBindDecodePlan(this.#valuePlan);const cursor=new WireDecodeCursor(bytes,view,l);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#valuePlan.decode(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  if(!materialize){this.#scanPlan??=wireScanPlan(this.#valuePlan);const cursor=new WireScanCursor(bytes,view,l,visitor,names===null?null:new Set(names),spans),value=this.#scanPlan.scan(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  return wireScanValue(this.#valuePlan,bytes,view,l,materialize,visitor,names===null?null:new Set(names),spans);
 }
 visit(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names);}
 visitSpans(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names,true);}
 validate(bytes,options=wireDefaultOptions){this.scan(bytes,options,false);return true;}
 decode(bytes,options=wireDefaultOptions){return this.scan(bytes,options,true);}
}

// Bounded forward emission avoids building and repeatedly joining child buffers.
class WireEncoder{
 #data=new Uint8Array(256);#view=new DataView(this.#data.buffer);#at=0;#remaining;#depth=0;#byteLimit;#depthLimit;
 active=false;
 constructor(options){this.reset(options);}
 reset(options){const limits=wireLimits(options);this.#byteLimit=limits.bytes;this.#depthLimit=limits.depth;this.#remaining=limits.nodes;this.#depth=0;this.#at=0;this.active=true;}
 get capacity(){return this.#data.length;}
 get position(){return this.#at;}
 beginNode(){const at=this.#at;this.word(0);return at;}
 endNode(at){this.patchWord(at,this.#at-at-4);}
 count(n){this.word(n);}
 beginCount(){const at=this.position;this.count(0);return at;}
 endCount(at,n){this.patchWord(at,n);}
 #reserve(size){
  const end=this.#at+size;if(end>this.#byteLimit)throw Error('wire byte limit');
  if(end>this.#data.length){const next=new Uint8Array(Math.min(this.#byteLimit,Math.max(end,this.#data.length*2)));next.set(this.#data.subarray(0,this.#at));this.#data=next;this.#view=new DataView(next.buffer);}
  return end;
 }
 bytes(bytes){const end=this.#reserve(bytes.length);this.#data.set(bytes,this.#at);this.#at=end;}
 byte(n){if(!Number.isInteger(n)||n<0||n>255)throw Error('wire byte range');this.#reserve(1);this.#data[this.#at++]=n;}
 word(n){if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire word range');const end=this.#reserve(4);this.#view.setUint32(this.#at,n,true);this.#at=end;}
 wide(n){if(typeof n!=='bigint'||n<0n||n>18446744073709551615n)throw Error('wire wide range');const end=this.#reserve(8);this.#view.setBigUint64(this.#at,n,true);this.#at=end;}
 text(text,count=false){
  if(typeof text!=='string')throw Error('wire Unicode');
  if(text.length<=16){
   let ascii=true;for(let i=0;i<text.length;i++)if(text.charCodeAt(i)>=128){ascii=false;break;}
   if(ascii){if(count)this.count(text.length);const end=this.#reserve(text.length);for(let i=0;i<text.length;i++)this.#data[this.#at+i]=text.charCodeAt(i);this.#at=end;return;}
  }
  if(!text.isWellFormed())throw Error('wire Unicode');const size=wireUtf8Length(text);if(count)this.count(size);
  const end=this.#reserve(size),r=wireEncoder.encodeInto(text,this.#data.subarray(this.#at,end));if(r.read!==text.length||r.written!==size)throw Error('wire UTF-8 size');this.#at=end;
 }
 patchWord(at,n){if(!Number.isInteger(at)||at<0||at+4>this.#at||!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire patch offset');this.#view.setUint32(at,n,true);}
 patchByte(at,n){if(!Number.isInteger(at)||at<0||at>=this.#at||!Number.isInteger(n)||n<0||n>255)throw Error('wire patch offset');this.#data[at]=n;}
 replace(at,removed,bytes){
  if(!Number.isInteger(at)||!Number.isInteger(removed)||at<0||removed<0||at+removed>this.#at||!(bytes instanceof Uint8Array))throw Error('wire replacement range');
  const extra=bytes.length-removed,end=extra>0?this.#reserve(extra):this.#at+extra;
  this.#data.copyWithin(at+bytes.length,at+removed,this.#at);this.#data.set(bytes,at);this.#at=end;
 }
 // Literal generated writers use balanced frames without per-node callbacks.
 // An exception abandons this invocation; encodeWith never reuses its writer.
 openFrame(){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;return at;}
 closeFrame(at){if(this.#depth===0)throw Error('wire frame boundary');this.#depth--;this.endNode(at);}
 frame(emit){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;try{emit(this);}finally{this.#depth--;}this.endNode(at);}
 reorder(start,spans){
  const sorted=spans.slice().sort((a,b)=>a[0]-b[0]);let at=start;
  for(const [a,b] of sorted){if(!Number.isInteger(a)||!Number.isInteger(b)||a!==at||b<a)throw Error('wire span permutation');at=b;}
  if(start<0||start>this.#at||at!==this.#at)throw Error('wire span permutation');
  if(spans.every((s,i)=>s===sorted[i]))return;
  const copy=this.#data.slice(start,this.#at);at=start;for(const [a,b] of spans){this.#data.set(copy.subarray(a-start,b-start),at);at+=b-a;}
 }
 finish(){if(this.#depth!==0)throw Error('wire frame boundary');return this.#data.slice(0,this.#at);}
}

class CompactWireEncoder extends WireEncoder{
 beginNode(){return 0;}
 endNode(){}
 endCount(at,n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  if(n<128){this.patchByte(at,n);return;}
  const bytes=[];while(n>=128){bytes.push(n%128+128);n=Math.floor(n/128);}bytes.push(n);this.replace(at,1,Uint8Array.from(bytes));
 }
 count(n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  while(n>=128){this.byte(n%128+128);n=Math.floor(n/128);}this.byte(n);
 }
 text(text){super.text(text,true);}
}

function compactScanValue(root,bytes,l,materialize){
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let cursor=1,remaining=l.nodes;
 const require=n=>{if(n>bytes.length-cursor)throw Error('truncated compact value');};
 const count=()=>{
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   require(1);const byte=bytes[cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }throw Error('compact count overflow');
 };
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,d)=>{
  if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type;let value;
  switch(p.kind){
   case 'unit':return null;
   case 'bool':require(1);if(bytes[cursor]>1)throw Error('invalid wire Bool');return !!bytes[cursor++];
   case 'u32':case 'i32':require(4);value=p.kind==='u32'?view.getUint32(cursor,true):view.getInt32(cursor,true);cursor+=4;return value;
   case 'f32':require(4);if(materialize)value={F32Bits:view.getUint32(cursor,true)};cursor+=4;return value;
   case 'f64':require(8);if(materialize)value={F64Bits:view.getBigUint64(cursor,true).toString()};cursor+=8;return value;
   case 'u64':require(8);if(materialize)value=view.getBigUint64(cursor,true);cursor+=8;return value;
   case 'string':case 'int':case 'id':case 'enum':{
    const n=count();require(n);const start=cursor;cursor+=n;
    if(p.kind==='string'&&!materialize){let i=start;while(i<cursor&&bytes[i]<128)i++;if(i<cursor)wireDecoder.decode(bytes.subarray(start,cursor));}
    else{const text=wireDecodeText(bytes,start,cursor);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    return value;
   }
   case 'list':case 'vector':{
    const n=count();if(n>remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,d+1);if(materialize)value.push(child);}return value;
   }
   case 'record':{
    const fs=p.fields;
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:return {};case 1:return {[fs[0].name]:node(fs[0].plan,d+1)};case 2:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1)};case 3:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1)};case 4:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1),[fs[3].name]:node(fs[3].plan,d+1)};}
    }
    if(materialize)value={};for(const f of fs){const child=node(f.plan,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}return value;
   }
   case 'option':case 'result':{
    require(1);const tag=bytes[cursor++];if(tag>1)throw Error('wire sum tag');
    if(p.kind==='option'&&tag===0)return materialize?{None:null}:undefined;
    const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,d+1);
    return materialize?{[label]:child}:undefined;
   }
   default:throw Error('unsupported wire kind');
  }
 };
 const value=node(root,0);if(cursor!==bytes.length)throw Error('trailing compact bytes');return value;
}

// General transport codec, independent of source rewrites and checkpoints.
// The sender/receiver must negotiate this exact identity and format. There is
// deliberately no claim that the bytes themselves identify their schema.
export class CompactValueCodec{
 #source;#plan;#encoder;#decodeBound=0;
 get format(){return compactValueWireFormat;}
 get identity(){return this.#source.descriptor.identity;}
 constructor(valueCodec){if(!(valueCodec instanceof ValueCodec))throw Error('compact codec requires a checked value codec');this.#source=valueCodec;this.#plan=wireValuePlan(valueCodec);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new CompactWireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.byte(1);wireEncodeValue(this.#plan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new CompactWireEncoder(options);w.byte(1);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 #scan(bytes,options,materialize){
  const l=wireLimits(options);
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<1||bytes.length>l.bytes)throw Error('wire byte limit or header');
  if(bytes[0]!==1)throw Error('compact format mismatch');
  if(materialize){this.#decodeBound||=wireBindDecodePlan(this.#plan,true);const cursor=new CompactDecodeCursor(bytes,l,this.#decodeBound);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#plan.decodeCompact(cursor,0);if(cursor.cursor!==bytes.length)throw Error('trailing compact bytes');return value;}
  return compactScanValue(this.#plan,bytes,l,materialize);
 }
 decode(bytes,options=wireDefaultOptions){return this.#scan(bytes,options,true);}
 validate(bytes,options=wireDefaultOptions){this.#scan(bytes,options,false);return true;}
}

// Compiler materialisers consume already validated bytes synchronously. This
// factory is for trusted emitted code, not untrusted descriptor/callback data.
// The complete generic validator runs before any compiler reader is invoked.
class ValidatedValueReader{
 constructor(bytes,compact){this.bytes=bytes;this.view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);this.cursor=compact?1:40;this.compact=compact;}
 frame(){if(this.compact)return 0;const end=this.cursor+4+this.view.getUint32(this.cursor,true);this.cursor+=4;return end;}
 finish(end){if(!this.compact&&this.cursor!==end)throw Error('compiled reader frame mismatch');}
 byte(){return this.bytes[this.cursor++];}
 word(){const n=this.view.getUint32(this.cursor,true);this.cursor+=4;return n;}
 signed(){const n=this.view.getInt32(this.cursor,true);this.cursor+=4;return n;}
 wide(){const n=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return n;}
 count(){if(!this.compact)return this.word();let n=0,scale=1,byte;do{byte=this.byte();n+=(byte&127)*scale;scale*=128;}while(byte>=128);return n;}
 text(end){const n=this.compact?this.count():end-this.cursor,start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
class CompiledCompactValueCodec extends CompactValueCodec{
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,true),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
}
class CompiledValueCodec extends ValueCodec{
 #read;#compiledCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,false),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
 compact(){return this.#compiledCompact??=new CompiledCompactValueCodec(this,this.#read);}
}
export function createCompiledValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new CompiledValueCodec(descriptor,read);}

// Trusted literal materialisers may use this checked reader to validate and
// construct in one traversal. The emitter must use frame/finish at every source
// node, typed text reads and counted sequence reads; arbitrary callbacks do not
// establish a schema correspondence proof. The independent scanner remains the
// validation oracle and the original factory retains its pre-validation path.
function literalValueHeader(identity){
 const bytes=new Uint8Array(40);bytes.set(wireMagic);
 for(let i=0;i<32;i++)bytes[i+8]=parseInt(identity.slice(i*2,i*2+2),16);
 const view=new DataView(bytes.buffer),words=new Uint32Array(10);
 for(let i=0;i<10;i++)words[i]=view.getUint32(i*4,true);
 return words;
}
class CheckedLiteralValueReader {
 constructor(bytes,header,compact,limits){
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<(compact?1:44)||bytes.length>limits.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  if(compact){if(bytes[0]!==1)throw Error('compact format mismatch');}
  else for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==header[i])throw Error('wire format or schema mismatch');
  this.bytes=bytes;this.view=view;
  this.cursor=compact?1:40;this.compact=compact;this.remaining=limits.nodes;this.depth=limits.depth;this.ends=[];
 }
 require(n){if(this.cursor+n>(this.ends.at(-1)??this.bytes.length))throw Error('truncated wire frame');}
 frame(){
  if(this.ends.length>this.depth||--this.remaining<0)throw Error('wire node or depth limit');
  let end=this.bytes.length;
  if(!this.compact){this.require(4);end=this.cursor+4+this.view.getUint32(this.cursor,true);this.require(end-this.cursor);this.cursor+=4;}
  this.ends.push(end);return this.compact?0:end;
 }
 finish(end){
  if(!this.ends.length||!this.compact&&(this.ends.at(-1)!==end||this.cursor!==end))throw Error('compiled reader frame mismatch');
  this.ends.pop();
 }
 byte(){this.require(1);const value=this.bytes[this.cursor++];if(value>1)throw Error('wire sum tag or Bool');return value;}
 word(){this.require(4);const value=this.view.getUint32(this.cursor,true);this.cursor+=4;return value;}
 signed(){this.require(4);const value=this.view.getInt32(this.cursor,true);this.cursor+=4;return value;}
 wide(){this.require(8);const value=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return value;}
 rawCount(){
  if(!this.compact)return this.word();
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   this.require(1);const byte=this.bytes[this.cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }
  throw Error('compact count overflow');
 }
 count(size){
  const value=this.rawCount();
  if(value>this.remaining||size!==undefined&&value!==size)throw Error('wire sequence size');
  return value;
 }
 text(end,kind='string',variants){
  const size=this.compact?this.rawCount():end-this.cursor;
  this.require(size);const start=this.cursor;this.cursor+=size;
  const value=wireDecodeText(this.bytes,start,this.cursor);
  if(kind==='int'&&!wireDecimal(value)||kind==='id'&&!/^[0-9a-f]{32}$/.test(value)||kind==='enum'&&!variants.includes(value))throw Error('malformed wire text');
  return value;
 }
 complete(){if(this.ends.length||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
// Compact source nodes have no individual frame ends: retain the same checked
// depth/node order using a counter, with bounds against the complete buffer.
class CheckedCompactLiteralValueReader extends CheckedLiteralValueReader {
 constructor(bytes,limits){super(bytes,null,true,limits);this.level=0;}
 require(n){if(this.cursor+n>this.bytes.length)throw Error('truncated wire frame');}
 frame(){if(this.level>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.level++;return 0;}
 finish(_end){if(!this.level)throw Error('compiled reader frame mismatch');this.level--;}
 complete(){if(this.level||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
class FusedCompactValueCodec extends CompactValueCodec {
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedCompactLiteralValueReader(bytes,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
}
class FusedValueCodec extends ValueCodec {
 #read;#header;#fusedCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;this.#header=literalValueHeader(this.descriptor.identity);}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedLiteralValueReader(bytes,this.#header,false,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
 compact(){return this.#fusedCompact??=new FusedCompactValueCodec(this,this.#read);}
}
export function createFusedValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new FusedValueCodec(descriptor,read);}
// JSON text is a boundary adapter to an ordinary recursive Ink datatype.
// No JavaScript Number conversion occurs for JSON numeric tokens.
export function jsonNumberToken(s){return typeof s==='string'&&/^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/.test(s);}
// JSON numeric tokens have an ASCII grammar. Check validated UTF-8 spans
// directly, preserving exact lexemes without allocating a decoded String.
function jsonNumberSpan(bytes,lo,hi){
 let at=lo;if(bytes[at]===45)at++;
 if(at>=hi)return false;
 if(bytes[at]===48)at++;
 else{if(bytes[at]<49||bytes[at]>57)return false;do{at++;}while(at<hi&&bytes[at]>=48&&bytes[at]<=57);}
 if(at<hi&&bytes[at]===46){const start=++at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 if(at<hi&&(bytes[at]===69||bytes[at]===101)){at++;if(at<hi&&(bytes[at]===43||bytes[at]===45))at++;const start=at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 return at===hi;
}
const jsonWireEncoder=new TextEncoder();
// Scalar conversion completes before writer callbacks; no per-value byte array.
const jsonFloatScratch=new DataView(new ArrayBuffer(4));
function jsonUtf8Length(text){if(text.length>16&&!/[^\x00-\x7f]/.test(text))return text.length;let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const jsonLimits={bytes:16777216,nodes:1000000,depth:128};
const jsonQuoters=new WeakSet();
/** Explicit, bounded reuse of immutable JSON string quotes. Cache payload bytes
 * are UTF-16 storage estimates; entry caps bound separate Map/object overhead.
 * Logical output budgets are charged again on every use, including cache hits.
 */
export function createJsonQuoter({maxEntries=1024,maxBytes=131072}={}){
 if(!Number.isSafeInteger(maxEntries)||maxEntries<0||maxEntries>65536||!Number.isSafeInteger(maxBytes)||maxBytes<0||maxBytes>16777216)throw Error('JSON quote cache budget');
 const entries=new Map();let bytes=0,hits=0,misses=0;
 const token=value=>{
  const prior=entries.get(value);if(prior!==undefined){hits++;return prior;}
  if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid JSON String');
  misses++;const text=JSON.stringify(value),size=2*(value.length+text.length),quoted=Object.freeze({text,utf8Bytes:jsonUtf8Length(text)});
  if(maxEntries&&size<=maxBytes){
   while(entries.size&&(entries.size>=maxEntries||bytes+size>maxBytes)){const key=entries.keys().next().value;bytes-=2*(key.length+entries.get(key).text.length);entries.delete(key);}
   entries.set(value,quoted);bytes+=size;
  }
  return quoted;
 };
 const quoter=Object.freeze({
  token,
  quote(value){return token(value).text;},
  clear(){entries.clear();bytes=0;},
  stats(){return {entries:entries.size,payload_bytes:bytes,hits,misses};},
 });jsonQuoters.add(quoter);return quoter;
}
function checkedJsonLimits(options){const l={...jsonLimits,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>jsonLimits[k])throw Error('JSON hard resource limit');return l;}
function jsonVariant(index,item){let payload=index===0?{}:{item0:item};if(index<5)payload={Ok:payload};for(let i=0;i<index;i++)payload={Err:payload};return {payload};}
export function parseJson(text,options={}){return parseJsonValue(text,options,null);}
function parseJsonValue(text,options,boundary){
 const p=new JsonWireReader(text,options);
 const value=(d,wireDepth=0)=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){boundary?.node(0,wireDepth);p.at+=4;return jsonVariant(0,null);}if(c==='t'&&text.startsWith('true',p.at)){boundary?.node(1,wireDepth);p.at+=4;return jsonVariant(1,true);}if(c==='f'&&text.startsWith('false',p.at)){boundary?.node(1,wireDepth);p.at+=5;return jsonVariant(1,false);}
  if(c==='"'){boundary?.node(3,wireDepth);const item=p.string();boundary?.text(item);return jsonVariant(3,item);}
  if(c==='['){boundary?.node(4,wireDepth);p.at++;const xs=[];if(!p.eat(']'))while(true){xs.push(value(d+1,wireDepth+8));if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}return jsonVariant(4,xs);}
  if(c==='{'){boundary?.node(5,wireDepth);p.at++;const xs=[],seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary?.member(key,wireDepth);if(!p.eat(':'))throw Error('JSON object colon');xs.push({key,value:value(d+1,wireDepth+9)});if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}return jsonVariant(5,xs);}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();boundary?.node(2,wireDepth);boundary?.text(token);return jsonVariant(2,token);}
  throw Error('invalid JSON value');
 };
 const out=value(0);p.finish();return out;
}
export function stringifyJson(value,options={}){return stringifyJsonValue(value,options,null);}
function stringifyJsonValue(value,options,boundary){
 const l=checkedJsonLimits(options);let remaining=l.nodes,bytes=0,output='';
 const emit=s=>{bytes+=jsonUtf8Length(s);if(bytes>l.bytes)throw Error('JSON byte limit');output+=s;};
 const write=(v,d,wireDepth=0)=>{
  if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');if(!v||Object.keys(v).length!==1||!Object.hasOwn(v,'payload'))throw Error('invalid JSON record');let p=v.payload,index=0;
  while(index<5&&p&&Object.hasOwn(p,'Err')){if(Object.keys(p).length!==1||boundary&&Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Err;index++;}
  if(index<5){if(!p||Object.keys(p).length!==1||!Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Ok;}
  if(!p||Object.keys(p).length!==(index===0?0:1)||index>0&&!Object.hasOwn(p,'item0'))throw Error('invalid JSON payload');const item=p.item0;boundary?.node(index,wireDepth);
  switch(index){
   case 0:emit('null');break;
   case 1:if(typeof item!=='boolean')throw Error('invalid JSON Boolean');emit(item?'true':'false');break;
   case 2:if(!jsonNumberToken(item))throw Error('invalid JSON number');boundary?.text(item);emit(item);break;
   case 3:if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary?.text(item);emit(JSON.stringify(item));break;
   case 4:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Array');const count=item.length;let visited=0;emit('[');item.forEach((x,i)=>{visited++;if(i)emit(',');write(x,d+1,wireDepth+8);});if(visited!==count)throw Error('invalid JSON Array');emit(']');break;}
   case 5:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Object');const count=item.length,seen=new Set();let visited=0;emit('{');item.forEach((m,i)=>{visited++;if(!m||Object.keys(m).length!==2||typeof m.key!=='string'||!m.key.isWellFormed()||!Object.hasOwn(m,'value')||boundary&&!Object.hasOwn(m,'key'))throw Error('invalid JSON member');if(seen.has(m.key))throw Error('duplicate JSON object key');seen.add(m.key);boundary?.member(m.key,wireDepth);if(i)emit(',');emit(JSON.stringify(m.key));emit(':');write(m.value,d+1,wireDepth+9);});if(visited!==count)throw Error('invalid JSON Object');emit('}');break;}
  }
 };write(value,0);return output;
}
// The adapter's schema is the fixed recursive JSON library shape checked by
// JsonCodec. Charge its ordinary record/sum/list wire nodes while parsing or
// rendering, rather than interpreting and walking the completed tree again.
function jsonBoundaryBudget(options){
 const l=checkedJsonLimits(options);let remaining=l.nodes,total=40;
 const charge=(nodes,bytes,depth)=>{remaining-=nodes;total+=bytes;if(remaining<0||depth>l.depth)throw Error('wire node or depth limit');if(total>l.bytes)throw Error('wire byte limit');};
 return {
  node(index,depth){charge(index===0?3:index<4?index+4:8,index===0?13:index===1?23:index===2?27:index===3?32:41,depth+(index===0?2:index<4?index+3:7));},
  text(text){charge(0,jsonUtf8Length(text),0);},
  member(key,depth){charge(2,8+jsonUtf8Length(key),depth+9);},
 };
}
function jsonSameSchema(a,b){
 if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;
 const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>Object.hasOwn(b,k)&&jsonSameSchema(a[k],b[k]));
}
// Host-object conversion is opt-in and JavaScript-only. Inspect data properties
// rather than invoking getters/toJSON; reflection is not a sandbox for proxies.
function jsonJSKeys(value){
 if(!value||typeof value!=='object')throw Error('expected a plain JavaScript object');
 const prototype=Object.getPrototypeOf(value);
 if(prototype!==Object.prototype&&prototype!==null)throw Error('expected a plain JavaScript object');
 const keys=Reflect.ownKeys(value);
 if(keys.some(k=>typeof k!=='string'))throw Error('JavaScript symbol keys are unsupported');
 return keys;
}
function jsonJSData(value,key){
 const property=Object.getOwnPropertyDescriptor(value,key);
 if(!property||!property.enumerable||!Object.hasOwn(property,'value'))throw Error('expected an enumerable own data property');
 return property.value;
}
function jsonJSRecord(value,names){
 const keys=jsonJSKeys(value);
 if(keys.length!==names.length||keys.some(k=>!names.includes(k)))throw Error('invalid JSON record or variant');
}
function jsonJSArray(value,remaining){
 if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype)throw Error('expected a plain JavaScript array');
 const length=value.length;
 if(length>remaining)throw Error('JSON node limit');
 const keys=Reflect.ownKeys(value);
 if(keys.length!==length+1||keys.some(k=>typeof k!=='string'||k!=='length'&&(!/^(0|[1-9][0-9]*)$/.test(k)||Number(k)>=length)))throw Error('sparse or decorated JavaScript arrays are unsupported');
 return length;
}
function jsonFromJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),active=new WeakSet();let remaining=limits.nodes;
 const text=value=>{if(!value.isWellFormed())throw Error('invalid JSON Unicode');boundary.text(value);return value;};
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  if(value===null){boundary.node(0,wireDepth);return jsonVariant(0);}
  switch(typeof value){
   case 'boolean':boundary.node(1,wireDepth);return jsonVariant(1,value);
   case 'string':boundary.node(3,wireDepth);return jsonVariant(3,text(value));
   case 'number':
    if(!Number.isFinite(value))throw Error('non-finite JavaScript numbers are unsupported');
    boundary.node(2,wireDepth);return jsonVariant(2,text(Object.is(value,-0)?'-0':String(value)));
   case 'bigint':boundary.node(2,wireDepth);return jsonVariant(2,text(String(value)));
   case 'object':break;
   default:throw Error('unsupported JavaScript value');
  }
  if(active.has(value))throw Error('cyclic JavaScript value');
  active.add(value);
  try{
   if(Array.isArray(value)){
    boundary.node(4,wireDepth);const count=jsonJSArray(value,remaining),items=[];
    for(let i=0;i<count;i++)items.push(visit(jsonJSData(value,String(i)),depth+1,wireDepth+8));
    return jsonVariant(4,items);
   }
   boundary.node(5,wireDepth);const keys=jsonJSKeys(value),members=[];
   if(keys.length>remaining)throw Error('JSON node limit');
   for(const key of keys){
    if(!key.isWellFormed())throw Error('invalid JSON Unicode');
    boundary.member(key,wireDepth);
    members.push({key,value:visit(jsonJSData(value,key),depth+1,wireDepth+9)});
   }
   return jsonVariant(5,members);
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
function jsonDecimalKey(token){
 const [,sign,whole,fraction='',exponent='0']=/^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(token);
 const digits=(whole+fraction).replace(/^0+/,'');
 if(!digits)return '0';
 const trimmed=digits.replace(/0+$/,'');
 return sign+trimmed+'e'+(Number(exponent)-fraction.length+digits.length-trimmed.length);
}
function jsonToJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),mode=options?.numbers??'number',active=new WeakSet();let remaining=limits.nodes;
 if(!['number','bigint','string'].includes(mode))throw Error('unknown JavaScript number policy');
 const number=token=>{
  if(!jsonNumberToken(token))throw Error('invalid JSON number');
  boundary.text(token);
  if(mode==='string')return token;
  if(mode==='bigint')return BigInt(jsonInteger(token,4096));
  const result=Number(token);
  if(!Number.isFinite(result)||jsonDecimalKey(token)!==jsonDecimalKey(String(result)))throw Error('JSON number loses precision as JavaScript Number; choose numbers: bigint or string');
  return result;
 };
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  jsonJSRecord(value,['payload']);
  if(active.has(value))throw Error('cyclic JSON value');
  active.add(value);
  try{
   let payload=jsonJSData(value,'payload'),index=0;
   while(index<5&&Object.hasOwn(payload,'Err')){jsonJSRecord(payload,['Err']);payload=jsonJSData(payload,'Err');index++;}
   if(index<5){jsonJSRecord(payload,['Ok']);payload=jsonJSData(payload,'Ok');}
   jsonJSRecord(payload,index===0?[]:['item0']);boundary.node(index,wireDepth);
   const item=index===0?null:jsonJSData(payload,'item0');
   if(index===0)return null;
   if(index===1){if(typeof item!=='boolean')throw Error('invalid JSON Boolean');return item;}
   if(index===2)return number(item);
   if(index===3){if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary.text(item);return item;}
   const count=jsonJSArray(item,remaining);
   if(index===4){const out=[];for(let i=0;i<count;i++)out.push(visit(jsonJSData(item,String(i)),depth+1,wireDepth+8));return out;}
   const out={},seen=new Set();
   for(let i=0;i<count;i++){
    const member=jsonJSData(item,String(i));jsonJSRecord(member,['key','value']);const key=jsonJSData(member,'key');
    if(typeof key!=='string'||!key.isWellFormed())throw Error('invalid JSON member key');
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary.member(key,wireDepth);
    Object.defineProperty(out,key,{value:visit(jsonJSData(member,'value'),depth+1,wireDepth+9),enumerable:true,writable:true,configurable:true});
   }
   return out;
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
const jsonConstructionPaths=Object.freeze(Array.from({length:6},(_,index)=>Object.freeze([0,...Array(index).fill(1),...(index<5?[0]:[]),0])));
function parseJsonConstructed(text,options,builder){
 const p=new JsonWireReader(text,options);
 const paths=jsonConstructionPaths;
 const fused=typeof builder.openPath==='function';
 const begin=index=>{if(fused){builder.openPath(paths[index]);return;}for(const choice of paths[index])builder.open(choice);};
 const end=index=>{for(let i=0;i<(fused?1:index<5?index+3:7);i++)builder.close();};
 const leaf=(index,item)=>{if(typeof builder.scalarPath==='function'){builder.scalarPath(paths[index],item);return;}begin(index);builder.scalar(item);end(index);};
 const value=d=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){p.at+=4;if(typeof builder.emptyPath==='function')builder.emptyPath(paths[0]);else{begin(0);end(0);}return;}
  if(c==='t'&&text.startsWith('true',p.at)){p.at+=4;leaf(1,true);return;}
  if(c==='f'&&text.startsWith('false',p.at)){p.at+=5;leaf(1,false);return;}
  if(c==='"'){leaf(3,p.string());return;}
  if(c==='['){begin(4);builder.open(0);p.at++;if(!p.eat(']'))while(true){value(d+1);if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}builder.close();end(4);return;}
  if(c==='{'){begin(5);builder.open(0);p.at++;const seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');builder.open(0);builder.scalar(key);value(d+1);builder.close();if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}builder.close();end(5);return;}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();leaf(2,token);return;}
  throw Error('invalid JSON value');
 };
 value(0);p.finish();return builder.finish();
}
const jsonCompiledRenderers=new WeakMap();
function compiledJsonRenderer(json,codec,unwrap){
 if(typeof codec?.reducer!=='function')throw Error('compiled JSON reduction unavailable');
 const source=codec.resolve(codec.descriptor.root),root=json.values.descriptor.root;
 const selected=unwrap&&source.kind==='result'?codec.resolve(source.ok):source;
 if(!jsonSameSchema(root,selected)||unwrap&&source.kind!=='result')throw Error('compiled JSON schema mismatch');
 let variants=root.fields[0].type;const roles=new Map([[root.name,'root']]);
 let member;
 for(let index=0;index<6;index++){
  const branch=index<5?variants.ok:variants;roles.set(branch.name,index);
  if(index===5){member=branch.fields[0].type.element.name;roles.set(member,'member');}
  if(index<5)variants=variants.error;
 }
 const nodeRoles=new Map();
 return codec.reducer((node,index)=>{
  const role=roles.get(node.name);nodeRoles.set(index,role);
  if(node.kind==='record'){
   if(role==='root')return value=>value;
   if(role==='member')return (key,value,context)=>{
    const text=(context.quoter?context.quote(key,true):context.add(JSON.stringify(key)+':'))+value,seen=context.members;
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);return text;
   };
   if(role===0)return context=>context.add('null');
   if(role===1)return (value,context)=>context.add(value?'true':'false');
   if(role===2)return (token,context)=>{if(!jsonNumberToken(token))throw Error('invalid JSON number');return context.add(token);};
   if(role===3)return (value,context)=>context.quoter?context.quote(value,false):context.add(JSON.stringify(value));
   if(role===4)return (value,context)=>{context.add('[]');return '['+value+']';};
   if(role===5)return (value,context)=>{context.add('{}');return '{'+value+'}';};
   return ()=>null;
  }
  if(node.kind==='list'||node.kind==='vector'){
   const members=nodeRoles.get(node.children[0])==='member';
   return {
    start:(_length,context)=>{
     const out={text:'',parent:members?context.members:null};
     if(members)context.members=new Set();return out;
    },
    step:(out,value,index,context)=>{out.text+=(index?context.add(','):'')+value;return out;},
    finish:(out,context)=>{if(members)context.members=out.parent;return out.text;},
   };
  }
  if(node.kind==='result'){
   // A Result<Json,E> boundary is explicitly requested by the caller. Ordinary
   // JSON's own sums only propagate an already rendered branch.
   if(unwrap&&nodeRoles.get(node.children[0])==='root')return (tag,value)=>{if(tag)throw Error('JSON result is Err');return value;};
   return (_tag,value)=>value;
  }
  if(node.kind==='string')return value=>{if(!value.isWellFormed())throw Error('invalid JSON String');return value;};
  return value=>value;
 });
}
export class JsonCodec{
 constructor(valueCodec){
  const root=valueCodec.descriptor.root,fields=root.fields;if(root.kind!=='record'||!Array.isArray(fields)||fields.length!==1||fields[0].name!=='payload')throw Error('JSON schema payload');let sum=fields[0].type;
  for(let i=0;i<6;i++){
   if(i<5&&sum.kind!=='result')throw Error('JSON schema sum');const branch=i<5?sum.ok:sum,fs=branch.fields;
   if(branch.kind!=='record'||!Array.isArray(fs)||fs.length!==(i?1:0)||i&&fs[0].name!=='item0')throw Error('JSON schema branch');
   if(i){const t=fs[0].type;if(i===1&&t.kind!=='bool'||(i===2||i===3)&&t.kind!=='string'||i===4&&(t.kind!=='list'||t.element.kind!=='ref'||t.element.name!==root.name))throw Error('JSON schema variant');if(i===5){const mf=t.element?.fields;if(t.kind!=='list'||t.element?.kind!=='record'||!Array.isArray(mf)||mf.length!==2||mf[0].name!=='key'||mf[0].type.kind!=='string'||mf[1].name!=='value'||mf[1].type.kind!=='ref'||mf[1].type.name!==root.name)throw Error('JSON schema member');}}
   if(i===2)this.numberBranch=branch.name;if(i===5)this.objectBranch=branch.name;
   if(i<5)sum=sum.error;
  }if(!jsonSameSchema(root,valueCodec.resolve({kind:'ref',name:root.name})))throw Error('JSON recursive schema mismatch');this.values=valueCodec;
 }
 parse(text,options={}){return parseJsonValue(text,options,jsonBoundaryBudget(options));}
 parseCompiled(codec,text,options={}){
  if(codec?.identity!==this.values.descriptor.identity||typeof codec.builder!=='function')throw Error('compiled JSON schema mismatch');
  const builder=codec.builder(options);try{return parseJsonConstructed(text,options,builder);}catch(error){builder.abort();throw error;}
 }
 stringify(value,options={}){return stringifyJsonValue(value,options,jsonBoundaryBudget(options));}
 stringifyCompiled(codec,handle,options={}){
  const limits=checkedJsonLimits(options),unwrap=options.unwrapResult===true;
  const quoter=options.quoter;if(quoter!==undefined&&!jsonQuoters.has(quoter))throw Error('JSON quote cache owner mismatch');
  let codecs=jsonCompiledRenderers.get(this);if(!codecs)jsonCompiledRenderers.set(this,codecs=new WeakMap());
  let renderers=codecs.get(codec);if(!renderers)codecs.set(codec,renderers=new Map());
  let render=renderers.get(unwrap);if(!render)renderers.set(unwrap,render=compiledJsonRenderer(this,codec,unwrap));
  let bytes=0;const context={
   quoter,
   add(text){bytes+=jsonUtf8Length(text);if(bytes>limits.bytes)throw Error('JSON byte limit');return text;},
   quote(value,colon){
    if(!quoter)return this.add(JSON.stringify(value)+(colon?':':''));
    const token=quoter.token(value);bytes+=token.utf8Bytes+(colon?1:0);if(bytes>limits.bytes)throw Error('JSON byte limit');return token.text+(colon?':':'');
   },
  };
  const text=render(handle,context,limits);
  return text;
 }
 fromJS(value,options={}){return jsonFromJS(value,options);}
 toJS(value,options={}){return jsonToJS(value,options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,false);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,false,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,true);}
 validateBinary(bytes,options={}){
  const decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});let view;
  this.values.visitSpans(bytes,(type,data,start,end)=>{
   view??=new DataView(data.buffer,data.byteOffset,data.byteLength);
   if(type.name===this.numberBranch){const length=view.getUint32(start,true);if(!jsonNumberSpan(data,start+4,start+4+length))throw Error('invalid JSON number token');}
   if(type.name===this.objectBranch){const listEnd=start+4+view.getUint32(start,true),count=view.getUint32(start+4,true),seen=new Set();let at=start+8;for(let i=0;i<count;i++){const memberEnd=at+4+view.getUint32(at,true),keyStart=at+8,keyEnd=keyStart+view.getUint32(at+4,true),key=decoder.decode(data.subarray(keyStart,keyEnd));if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);at=memberEnd;}if(at!==listEnd)throw Error('invalid JSON object frame');}
  },options,[this.numberBranch,this.objectBranch]);return true;

 }
}
function jsonUnpack(value){let p=value.payload,i=0;while(i<5&&Object.hasOwn(p,'Err')){p=p.Err;i++;}return [i,(i<5?p.Ok:p).item0];}
function jsonInteger(token,limit){
 if(!jsonNumberToken(token))throw Error('invalid JSON number');const negative=token[0]==='-',raw=negative?token.slice(1):token,[mantissa,exp='0']=raw.split(/[eE]/);let digits=mantissa.replace('.','');if(/^0+$/.test(digits))return '0';const exponent=Number(exp),fraction=mantissa.includes('.')?mantissa.length-mantissa.indexOf('.')-1:0,shift=exponent-fraction;
 if(!Number.isSafeInteger(exponent)||!Number.isSafeInteger(shift))throw Error('JSON integer exponent limit');
 if(shift<0){const cut=-shift;if(cut>=digits.length||!/^[0]+$/.test(digits.slice(-cut)))throw Error('JSON number is not an integer');digits=digits.slice(0,-cut);}else{if(digits.length+shift>limit)throw Error('JSON integer magnitude limit');digits+='0'.repeat(shift);}
 digits=digits.replace(/^0+/,'');if(digits.length>limit)throw Error('JSON integer magnitude limit');return (negative?'-':'')+digits;
}
function jsonBinary64Value(v){
 if(typeof v==='number')return v;
 const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid F64Bits');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');
 const b=new DataView(new ArrayBuffer(8));b.setBigUint64(0,bits,true);return b.getFloat64(0,true);
}
export class TypedJsonCodec{
 constructor(valueCodec){this.values=valueCodec;}
 decode(document,options={}){
  // Validate JSON-specific invariants before interpreting any tagged/record
  // shape, including duplicated names and malformed numeric tokens.
  stringifyJson(document,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const read=(type,value,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type),[kind,item]=jsonUnpack(value);const fail=()=>{throw Error('JSON does not match '+t.kind);};
   switch(t.kind){
    case 'unit':if(kind!==0)fail();return null;
    case 'bool':if(kind!==1)fail();return item;
    case 'u32':case 'u64':case 'i32':case 'int':{if(kind!==2)fail();const text=jsonInteger(item,t.kind==='int'?4096:t.kind==='u64'?20:10);return t.kind==='int'?{Int:text}:t.kind==='u64'?BigInt(text):Number(text);}
    case 'f64':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(8));if(!Number.isFinite(n))throw Error('JSON f64 overflow');b.setFloat64(0,n,true);return {F64Bits:b.getBigUint64(0,true).toString()};}
    case 'f32':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(4));b.setFloat32(0,n,true);if(!Number.isFinite(b.getFloat32(0,true)))throw Error('JSON f32 overflow');return {F32Bits:b.getUint32(0,true)};}
    case 'string':case 'enum':case 'id':if(kind!==3)fail();return item;
    case 'list':case 'vector':if(kind!==4)fail();return item.map(x=>read(t.element,x,d+1));
    case 'record':{if(kind!==5||item.length!==t.fields.length)throw Error('unknown or missing JSON record field');const fields=new Map(item.map(m=>[m.key,m.value])),out={};for(const f of t.fields){if(!fields.has(f.name))throw Error('missing JSON record field');Object.defineProperty(out,f.name,{value:read(f.type,fields.get(f.name),d+1),writable:true,enumerable:true,configurable:true});}return out;}
    case 'option':case 'result':{if(kind!==5||item.length!==1)fail();const m=item[0];if(t.kind==='option'&&m.key==='None'&&jsonUnpack(m.value)[0]===0)return {None:null};const child=t.kind==='option'&&m.key==='Some'?t.element:t.kind==='result'&&m.key==='Ok'?t.ok:t.kind==='result'&&m.key==='Err'?t.error:null;if(!child)fail();return {[m.key]:read(child,m.value,d+1)};}
    default:fail();
   }
  };
  const out=read(this.values.descriptor.root,document,0);this.values.validateValue(out,options);return out;
 }
 encode(value,options={}){
  this.values.validateValue(value,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const write=(type,v,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type);
   switch(t.kind){
    case 'unit':return jsonVariant(0);
    case 'bool':return jsonVariant(1,v);
    case 'u32':case 'u64':case 'i32':return jsonVariant(2,String(v));
    case 'int':return jsonVariant(2,typeof v==='bigint'?String(v):v.Int);
    case 'f64':{const n=jsonBinary64Value(v);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'f32':{let n;if(typeof v==='number')n=Math.fround(v);else{const b=new DataView(new ArrayBuffer(4));b.setUint32(0,v.F32Bits,true);n=b.getFloat32(0,true);}if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'string':case 'id':case 'enum':return jsonVariant(3,v);
    case 'list':case 'vector':return jsonVariant(4,Array.from(v,x=>write(t.element,x,d+1)));
    case 'record':return jsonVariant(5,t.fields.map(f=>({key:f.name,value:write(f.type,v[f.name],d+1)})));
    case 'option':return jsonVariant(5,[Object.hasOwn(v,'Some')?{key:'Some',value:write(t.element,v.Some,d+1)}:{key:'None',value:jsonVariant(0)}]);
    case 'result':return jsonVariant(5,[Object.hasOwn(v,'Ok')?{key:'Ok',value:write(t.ok,v.Ok,d+1)}:{key:'Err',value:write(t.error,v.Err,d+1)}]);
    default:throw Error('unsupported typed JSON descriptor');
   }
  };return write(this.values.descriptor.root,value,0);
 }
 parse(text,options={}){return this.decode(parseJson(text,options),options);}
 stringify(value,options={}){return stringifyJson(this.encode(value,options),options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,true);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,true,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,false);}
}

// Token reader shared by schema-directed and arbitrary-JSON wire emission.
class JsonWireReader{
 constructor(text,options){this.l=checkedJsonLimits(options);if(typeof text!=='string'||!text.isWellFormed()||text.length>this.l.bytes||jsonUtf8Length(text)>this.l.bytes)throw Error('JSON byte or Unicode limit');this.text=text;this.at=0;this.remaining=this.l.nodes;}
 ws(){while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(c!==32&&c!==9&&c!==10&&c!==13)break;this.at++;}}
 peek(){this.ws();return this.text[this.at];}
 eat(c){this.ws();if(this.text[this.at]===c){this.at++;return true;}return false;}
 node(d){if(d>this.l.depth||--this.remaining<0)throw Error('JSON node or depth limit');}
 string(){
  this.ws();const start=this.at;if(this.text[start]!=='"')throw Error('expected JSON string');
  const end=this.text.indexOf('"',start+1);if(end<0)throw Error('unterminated JSON string');
  const raw=this.text.slice(start+1,end);
  if(!raw.includes('\\')&&!/[\x00-\x1f]/.test(raw)){this.at=end+1;return raw;}
  this.at=start+1;while(this.at<this.text.length){if(this.text[this.at]==='"'){this.at++;const v=JSON.parse(this.text.slice(start,this.at));if(!v.isWellFormed())throw Error('invalid JSON Unicode');return v;}if(this.text[this.at]==='\\')this.at+=2;else this.at++;}throw Error('unterminated JSON string');
 }
 number(){const start=this.at;while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(!(c>=48&&c<=57||c===45||c===43||c===46||c===101||c===69))break;this.at++;}const token=this.text.slice(start,this.at);if(!jsonNumberToken(token))throw Error('invalid JSON number');return token;}
 leaf(d){this.node(d);const c=this.peek();if(c==='n'&&this.text.startsWith('null',this.at)){this.at+=4;return null;}if(c==='t'&&this.text.startsWith('true',this.at)){this.at+=4;return true;}if(c==='f'&&this.text.startsWith('false',this.at)){this.at+=5;return false;}if(c==='"')return this.string();if(c==='-'||c>='0'&&c<='9')return this.number();throw Error('invalid JSON scalar');}
 finish(){this.ws();if(this.at!==this.text.length)throw Error('trailing JSON text');}
}
function streamJsonBinary(values,text,options,typed,compact=false){
 const p=new JsonWireReader(text,options),utf8=jsonWireEncoder;
 const list=(w,open,close,item)=>{if(!p.eat(open))throw Error('JSON container shape');const at=w.beginCount();let count=0;if(!p.eat(close))while(true){item(w);count++;if(p.eat(close))break;if(!p.eat(','))throw Error('JSON container separator');}w.endCount(at,count);};
 const variant=(w,index,level,emit)=>{if(level<index)w.frame(w=>{w.byte(1);variant(w,index,level+1,emit);});else if(index<5)w.frame(w=>{w.byte(0);w.frame(emit);});else w.frame(emit);};
 const json=(w,d)=>{
  const ch=p.peek(),index=ch==='n'?0:ch==='t'||ch==='f'?1:ch==='-'||ch>='0'&&ch<='9'?2:ch==='"'?3:ch==='['?4:ch==='{'?5:-1;if(index<0)throw Error('invalid JSON value');
  const leaf=index<4?p.leaf(d):null;if(index>=4)p.node(d);
  w.frame(w=>variant(w,index,0,w=>{
   if(index===0)return;if(index===1){w.frame(w=>w.byte(+leaf));return;}
   if(index===2||index===3){w.frame(w=>w.text(leaf));return;}
   w.frame(w=>{if(index===4)list(w,'[',']',w=>json(w,d+1));else{const seen=new Set();list(w,'{','}',w=>{const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');w.frame(w=>{w.frame(w=>w.text(key));json(w,d+1);});});}});
  }));
 };
 const read=(type,w,d)=>{
  const t=values.resolve(type);w.frame(w=>{
   if(t.kind==='list'||t.kind==='vector'){p.node(d);list(w,'[',']',w=>read(t.element,w,d+1));return;}
   if(t.kind==='record'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON record');const start=w.position,spans=new Array(t.fields.length).fill(null);
    if(!p.eat('}'))while(true){const key=p.string(),i=t.fields.findIndex(f=>f.name===key);if(i<0)throw Error('unknown JSON record field');if(spans[i])throw Error('duplicate JSON record field');if(!p.eat(':'))throw Error('JSON record colon');const at=w.position;read(t.fields[i].type,w,d+1);spans[i]=[at,w.position];if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON record separator');}
    if(spans.some(s=>s===null))throw Error('missing JSON record field');w.reorder(start,spans);return;
   }
   if(t.kind==='option'||t.kind==='result'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON tagged value');const key=p.string();if(!p.eat(':'))throw Error('JSON tag colon');
    if(t.kind==='option'&&key==='None'){if(p.leaf(d+1)!==null)throw Error('JSON None payload');w.byte(0);}
    else{const child=t.kind==='option'&&key==='Some'?t.element:t.kind==='result'&&key==='Ok'?t.ok:t.kind==='result'&&key==='Err'?t.error:null;if(!child)throw Error('invalid JSON tag');w.byte(key==='Ok'?0:1);read(child,w,d+1);}
    if(!p.eat('}'))throw Error('expected exactly one JSON tag');return;
   }
   const ch=p.peek(),v=p.leaf(d),bad=()=>{throw Error('JSON does not match '+t.kind);};
   if(t.kind==='unit'){if(v!==null)bad();return;}
   if(t.kind==='bool'){if(typeof v!=='boolean')bad();w.byte(+v);return;}
   if(['string','id','enum'].includes(t.kind)){if(ch!=='"')bad();w.text(v);return;}
   if(ch!=='-'&&!(ch>='0'&&ch<='9'))bad();
   if(t.kind==='int'){w.text(jsonInteger(v,4096));return;}
   if(t.kind==='f64'){const n=Number(v);if(!Number.isFinite(n))throw Error('JSON f64 overflow');const b=new DataView(new ArrayBuffer(8));b.setFloat64(0,n,true);w.wide(b.getBigUint64(0,true));}
   else if(t.kind==='f32'){jsonFloatScratch.setFloat32(0,Number(v),true);if(!Number.isFinite(jsonFloatScratch.getFloat32(0,true)))throw Error('JSON f32 overflow');w.word(jsonFloatScratch.getUint32(0,true));}
   else{const n=BigInt(jsonInteger(v,t.kind==='u64'?20:10));if(t.kind==='u64'){if(n<0n||n>18446744073709551615n)bad();w.wide(n);}else if(t.kind==='u32'){if(n<0n||n>4294967295n)bad();w.word(Number(n));}else if(t.kind==='i32'){if(n< -2147483648n||n>2147483647n)bad();w.word(Number(n)>>>0);}else bad();}
  });
 };
 return (compact?values.compact():values).encodeWith(w=>{if(typed)read(values.descriptor.root,w,0);else json(w,0);p.finish();},options);
}

// Render validated bytes in a single traversal; only the final text is owned.
function streamWireJsonText(values,bytes,options,library){
 values.validate(bytes,options);const l=checkedJsonLimits(options),parts=[];let size=0,remaining=l.nodes;const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 const emit=s=>{size+=jsonUtf8Length(s);if(size>l.bytes)throw Error('JSON byte limit');parts.push(s);};
 const string=s=>emit(JSON.stringify(s));const node=d=>{if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');};
 const frame=(type,at)=>{const t=values.resolve(type),start=at+4,end=start+dv.getUint32(at,true);return{t,start,end};};
 const json=(type,at,d)=>{
  node(d);let root=frame(type,at),sum=frame(root.t.fields[0].type,root.start),index=0;
  while(index<5){const err=bytes[sum.start];sum=frame(err?sum.t.error:sum.t.ok,sum.start+1);if(!err)break;index++;}
  if(index===0){emit('null');return root.end;}
  const item=frame(sum.t.fields[0].type,sum.start);
  if(index===1)emit(bytes[item.start]?'true':'false');
  else if(index===2){const token=decoder.decode(bytes.subarray(item.start,item.end));if(!jsonNumberToken(token))throw Error('invalid JSON number token');emit(token);}
  else if(index===3)string(decoder.decode(bytes.subarray(item.start,item.end)));
  else{const count=dv.getUint32(item.start,true);let p=item.start+4;emit(index===4?'[':'{');const seen=new Set();for(let i=0;i<count;i++){if(i)emit(',');if(index===4)p=json(item.t.element,p,d+1);else{const member=frame(item.t.element,p),key=frame(member.t.fields[0].type,member.start),name=decoder.decode(bytes.subarray(key.start,key.end));if(seen.has(name))throw Error('duplicate JSON object key');seen.add(name);string(name);emit(':');json(member.t.fields[1].type,key.end,d+1);p=member.end;}}emit(index===4?']':'}');}
  return root.end;
 };
 const typed=(type,at,d)=>{
  node(d);const f=frame(type,at),t=f.t;let p=f.start;
  switch(t.kind){
   case 'unit':emit('null');break;
   case 'bool':emit(bytes[p]?'true':'false');break;
   case 'u32':emit(String(dv.getUint32(p,true)));break;
   case 'u64':emit(String(dv.getBigUint64(p,true)));break;
   case 'i32':emit(String(dv.getInt32(p,true)));break;
   case 'f64':{const n=dv.getFloat64(p,true);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'f32':{const n=dv.getFloat32(p,true);if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'int':emit(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'string':case 'id':case 'enum':string(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'list':case 'vector':{const n=dv.getUint32(p,true);p+=4;emit('[');for(let i=0;i<n;i++){if(i)emit(',');p=typed(t.element,p,d+1);}emit(']');break;}
   case 'record':emit('{');for(let i=0;i<t.fields.length;i++){if(i)emit(',');const field=t.fields[i];string(field.name);emit(':');p=typed(field.type,p,d+1);}emit('}');break;
   case 'option':case 'result':{const tag=bytes[p++],key=t.kind==='option'?(tag?'Some':'None'):tag?'Err':'Ok';emit('{');string(key);emit(':');if(t.kind==='option'&&!tag){node(d+1);emit('null');}else typed(t.kind==='option'?t.element:tag?t.error:t.ok,p,d+1);emit('}');break;}
   default:throw Error('unsupported typed JSON descriptor');
  }return f.end;
 };
 if(library)json(values.descriptor.root,40,0);else typed(values.descriptor.root,40,0);return parts.join('');
}

/** Owned, optional read view of arbitrary JSON. Auxiliary indexes contain member
 * offsets only. Logical order, exact number tokens and missing/null remain intact.
 * This does not transparently replace any compiled Ink action or its state.
 */
export function createJsonLookup(text,{stepEntries=16,minReads=4,maxEntries=4096,maxObjects=64,maxIndexBytes=262144,...limits}={}){
 for(const [v,max]of [[stepEntries,4096],[minReads,1000000],[maxEntries,1000000],[maxObjects,256],[maxIndexBytes,16777216]])if(!Number.isSafeInteger(v)||v<0||v>max)throw Error('JSON index budget');
 let root=parseJson(text,limits),indexes=new Map(),entries=0,indexBytes=0;
 const stats={reads:0,writes:0,scanned_members:0,index_hits:0,built_entries:0,invalidations:0};
 function parts(path){
  if(!Array.isArray(path))throw Error('JSON lookup path');const n=path.length;if(n>128)throw Error('JSON lookup path');
  const owned=[];for(let i=0;i<n;i++){const d=Object.getOwnPropertyDescriptor(path,String(i));if(!d||!Object.hasOwn(d,'value'))throw Error('JSON lookup path');const p=d.value;if(!(typeof p==='string'&&p.isWellFormed()&&p.length<=4096)&&!(Number.isSafeInteger(p)&&p>=0))throw Error('JSON lookup path');owned.push(p);}return owned;
 }
 function variant(value){let p=value.payload,index=0;while(index<5&&Object.hasOwn(p,'Err')){p=p.Err;index++;}return {index,item:(index<5?p.Ok:p).item0};}
 function resolve(document,path,indexed){
  let value=document,budget=stepEntries;
  for(let depth=0;depth<path.length;depth++){
   const part=path[depth],v=variant(value);
   if(typeof part==='number'){
    if(v.index!==4)throw Error('expected JSON array');if(part>=v.item.length)return {found:false};value=v.item[part];continue;
   }
   if(v.index!==5)throw Error('expected JSON object');
   const prefix=path.slice(0,depth),key=JSON.stringify(prefix),overhead=128+prefix.reduce((n,p)=>n+(typeof p==='string'?16+p.length*2:8),0);let idx=indexed?indexes.get(key):null;
   if(indexed&&!idx&&indexes.size<maxObjects&&indexBytes+overhead<=maxIndexBytes){idx={path:prefix,reads:0,cursor:0,keys:new Map(),bytes:overhead};indexes.set(key,idx);indexBytes+=overhead;}
   if(idx){
    idx.reads++;
    if(idx.reads>=minReads)while(budget>0&&idx.cursor<v.item.length&&entries<maxEntries){
     const member=v.item[idx.cursor],bytes=64+member.key.length*2;
     if(indexBytes+bytes>maxIndexBytes)break;
     idx.keys.set(member.key,idx.cursor++);idx.bytes+=bytes;indexBytes+=bytes;entries++;stats.built_entries++;budget--;
    }
    if(idx.keys.has(part)){stats.index_hits++;value=v.item[idx.keys.get(part)].value;continue;}
   }
   let found=false;
   for(let i=idx?.cursor??0;i<v.item.length;i++){if(indexed)stats.scanned_members++;if(v.item[i].key===part){value=v.item[i].value;found=true;break;}}
   if(!found)return {found:false};
  }
  return {found:true,value};
 }
 return {
  lookup(path){stats.reads++;const r=resolve(root,parts(path),true);return r.found?{found:true,value:structuredClone(r.value)}:r;},
  set(path,key,text){
   path=parts(path);if(typeof key!=='string'||!key.isWellFormed())throw Error('JSON object key');
   const replacement=parseJson(text,limits),next=structuredClone(root),r=resolve(next,path,false);
   if(!r.found)throw Error('JSON update path missing');const object=variant(r.value);if(object.index!==5)throw Error('expected JSON object');
   const members=[{key,value:replacement},...object.item.filter(m=>m.key!==key)];
   // Validate the complete resulting document before publishing a write.
   let payload=r.value.payload;for(let i=0;i<5;i++)payload=payload.Err;payload.item0=members;
   stringifyJson(next,limits);root=next;stats.writes++;
   for(const [id,idx]of indexes)if(idx.path.length>=path.length&&path.every((p,i)=>p===idx.path[i])){entries-=idx.keys.size;indexBytes-=idx.bytes;indexes.delete(id);stats.invalidations++;}
  },
  replace(text){const next=parseJson(text,limits);root=next;stats.writes++;stats.invalidations+=indexes.size;indexes.clear();entries=0;indexBytes=0;},
  stringify(){return stringifyJson(root,limits);},
  stats(){return {...stats,index_entries:entries,index_objects:indexes.size,index_bytes:indexBytes};}
 };
}
function __ownedValue5(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__ownedValue6(value.Some,budget,depth+1)};}
function __ownedValue2(value,budget,depth){budget.enter(depth,4);return {["a"]:__ownedValue0(value["a"],budget,depth+1),["b"]:__ownedValue0(value["b"],budget,depth+1)};}
function __ownedValue1(value,budget,depth){budget.enter(depth,4);return {["p"]:__ownedValue2(value["p"],budget,depth+1),["q"]:__ownedValue2(value["q"],budget,depth+1),["r"]:__ownedValue2(value["r"],budget,depth+1),["s"]:__ownedValue2(value["s"],budget,depth+1),["t"]:__ownedValue2(value["t"],budget,depth+1),["u"]:__ownedValue2(value["u"],budget,depth+1)};}
function __ownedValue8(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue0(value["value"],budget,depth+1),["tangent"]:__ownedValue0(value["tangent"],budget,depth+1)};}
function __ownedValue7(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue0(value["value"],budget,depth+1),["tangent_0"]:__ownedValue0(value["tangent_0"],budget,depth+1),["tangent_1"]:__ownedValue0(value["tangent_1"],budget,depth+1),["tangent_2"]:__ownedValue0(value["tangent_2"],budget,depth+1),["tangent_3"]:__ownedValue0(value["tangent_3"],budget,depth+1),["tangent_4"]:__ownedValue0(value["tangent_4"],budget,depth+1),["tangent_5"]:__ownedValue0(value["tangent_5"],budget,depth+1),["tangent_6"]:__ownedValue0(value["tangent_6"],budget,depth+1),["tangent_7"]:__ownedValue0(value["tangent_7"],budget,depth+1),["tangent_8"]:__ownedValue0(value["tangent_8"],budget,depth+1),["tangent_9"]:__ownedValue0(value["tangent_9"],budget,depth+1),["tangent_10"]:__ownedValue0(value["tangent_10"],budget,depth+1),["tangent_11"]:__ownedValue0(value["tangent_11"],budget,depth+1)};}
function __ownedValue3(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue4(value["value"],budget,depth+1),["previous"]:__ownedValue5(value["previous"],budget,depth+1)};}
function __ownedValue0(value,budget,depth){budget.enter(depth,8);const bits=typeof value==='number'?__bits(value):value.F32Bits;return {F32Bits:bits===0?0:bits};}
function __ownedValue6(value,budget,depth){return __ownedValue3(value,budget,depth);}
function __ownedValue4(value,budget,depth){budget.enter(depth,8);return value>>>0;}
const __ownedFunctions=Object.freeze(Object.fromEntries([["component",__ownedValue0],["energy",__ownedValue0],["derivatives",__ownedValue1],["direction",__ownedValue0],["twice",__ownedValue0],["selected",__ownedValue2],["branches",__ownedValue2],["looping",__ownedValue2],["strict_unused",__ownedValue0],["strict",__ownedValue0],["history",__ownedValue3],["__ink_differential_3",__ownedValue7],["__ink_differential_1",__ownedValue1],["__ink_differential_23",__ownedValue8],["__ink_differential_27",__ownedValue8],["__ink_differential_31",__ownedValue8],["__ink_differential_20",__ownedValue8],["__ink_differential_19",__ownedValue0]]));
function __wireValue22(reader){const end=reader.frame();const value=reader.byte()?{Some:__wireValue21(reader)}:{None:null};reader.finish(end);return value;}
function __wireValue9(reader){const end=reader.frame();const value={["__ink_differential_24"]:__wireValue8(reader),["__ink_differential_25"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue10(reader){const end=reader.frame();const value={["__ink_differential_28"]:__wireValue8(reader),["__ink_differential_29"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue15(reader){const end=reader.frame();const value={["__ink_differential_32"]:__wireValue8(reader),["__ink_differential_33"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue7(reader){const end=reader.frame();const value={["a"]:__wireValue8(reader),["b"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue13(reader){const end=reader.frame();const value={["a"]:__wireValue14(reader),["b"]:__wireValue14(reader)};reader.finish(end);return value;}
function __wireValue2(reader){const end=reader.frame();const value={["a"]:__wireValue3(reader),["b"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue6(reader){const end=reader.frame();const value={["p"]:__wireValue7(reader),["q"]:__wireValue7(reader),["r"]:__wireValue7(reader),["s"]:__wireValue7(reader),["t"]:__wireValue7(reader),["u"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue12(reader){const end=reader.frame();const value={["p"]:__wireValue13(reader),["q"]:__wireValue13(reader),["r"]:__wireValue13(reader),["s"]:__wireValue13(reader),["t"]:__wireValue13(reader),["u"]:__wireValue13(reader)};reader.finish(end);return value;}
function __wireValue1(reader){const end=reader.frame();const value={["p"]:__wireValue2(reader),["q"]:__wireValue2(reader),["r"]:__wireValue2(reader),["s"]:__wireValue2(reader),["t"]:__wireValue2(reader),["u"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue8(reader){const end=reader.frame();const value={["value"]:__wireValue3(reader),["tangent"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue14(reader){const end=reader.frame();const value={["value"]:__wireValue3(reader),["tangent_0"]:__wireValue3(reader),["tangent_1"]:__wireValue3(reader),["tangent_2"]:__wireValue3(reader),["tangent_3"]:__wireValue3(reader),["tangent_4"]:__wireValue3(reader),["tangent_5"]:__wireValue3(reader),["tangent_6"]:__wireValue3(reader),["tangent_7"]:__wireValue3(reader),["tangent_8"]:__wireValue3(reader),["tangent_9"]:__wireValue3(reader),["tangent_10"]:__wireValue3(reader),["tangent_11"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue21(reader){const end=reader.frame();const value={["value"]:__wireValue20(reader),["previous"]:__wireValue22(reader)};reader.finish(end);return value;}
function __wireValue24(reader){const end=reader.frame();const value={["w"]:__wireValue2(reader),["c"]:__wireValue17(reader)};reader.finish(end);return value;}
function __wireValue18(reader){const end=reader.frame();const value={["w"]:__wireValue2(reader),["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue26(reader){const end=reader.frame();const value={["w"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue5(reader){const end=reader.frame();const value={["w"]:__wireValue6(reader),["x"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue11(reader){const end=reader.frame();const value={["w"]:__wireValue12(reader),["x"]:__wireValue14(reader)};reader.finish(end);return value;}
function __wireValue4(reader){const end=reader.frame();const value={["w"]:__wireValue1(reader),["__ink_differential_35"]:__wireValue1(reader),["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue0(reader){const end=reader.frame();const value={["w"]:__wireValue1(reader),["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue16(reader){const end=reader.frame();const value={["x"]:__wireValue3(reader),["c"]:__wireValue17(reader)};reader.finish(end);return value;}
function __wireValue25(reader){const end=reader.frame();const value={["x"]:__wireValue3(reader),["y"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue23(reader){const end=reader.frame();const value={["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue19(reader){const end=reader.frame();const value={["x"]:__wireValue20(reader)};reader.finish(end);return value;}
function __wireValue17(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __wireValue3(reader){const end=reader.frame();const value={F32Bits:reader.word()};reader.finish(end);return value;}
function __wireValue20(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
const __wireReaders=Object.freeze(Object.fromEntries([["__ink_differential_1",[__wireValue0,__wireValue1]],["__ink_differential_19",[__wireValue4,__wireValue3]],["__ink_differential_20",[__wireValue5,__wireValue8]],["__ink_differential_23",[__wireValue9,__wireValue8]],["__ink_differential_27",[__wireValue10,__wireValue8]],["__ink_differential_3",[__wireValue11,__wireValue14]],["__ink_differential_31",[__wireValue15,__wireValue8]],["branches",[__wireValue16,__wireValue2]],["component",[__wireValue18,__wireValue3]],["derivatives",[__wireValue0,__wireValue1]],["direction",[__wireValue0,__wireValue3]],["energy",[__wireValue0,__wireValue3]],["history",[__wireValue19,__wireValue21]],["looping",[__wireValue23,__wireValue2]],["selected",[__wireValue24,__wireValue2]],["strict",[__wireValue25,__wireValue3]],["strict_unused",[__wireValue26,__wireValue3]],["twice",[__wireValue26,__wireValue3]]]));

const __ownedImplementations=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>{
 const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
 const body=__implementations[f.index];
 const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
 return [f.name,input.every(c=>c===__identity)?implementation:(...args)=>{const context=new WeakMap();return implementation(...args.map((v,i)=>input[i](v,context)));}];
})));

export const valueCodecs=(()=>{const codecs={};for(const [name,s] of Object.entries(metadata.wire.functions)){if(s.unsupported)continue;let value;Object.defineProperty(codecs,name,{enumerable:true,get:()=>value??=(Object.freeze(Object.hasOwn(__wireReaders,name)?{arguments:createCompiledValueCodec(s.arguments,__wireReaders[name][0]),result:createCompiledValueCodec(s.result,__wireReaders[name][1])}:{arguments:new ValueCodec(s.arguments),result:new ValueCodec(s.result)}))});}return Object.freeze(codecs);})();
function __callEncoded(name,bytes,limits,compact){
 const f=metadata.functions.find(f=>f.name===name&&!f.internal),codecs=valueCodecs[name];
 if(!f||!codecs)throw Error('unsupported binary function');
 const input=compact?codecs.arguments.compact():codecs.arguments,output=compact?codecs.result.compact():codecs.result;
 const entry=__compiledEntries.get(name);
 if(entry){
  const slot=compact?1:0;
  entry.argumentCodecs[slot]??=(entry.boundaryReaders[slot]?createFusedValueCodec:createCompiledValueCodec)(metadata.wire.functions[name].arguments,entry.arguments);
  const decoder=entry.argumentCodecs[slot];
  const values=(compact?decoder.compact():decoder).decode(bytes,limits),args=f.params.map(p=>values[p.name]);
  if(entry.precondition!==null&&__implementations[entry.precondition](...args)!==true)throw Error('contract precondition failed');
  return __compiledEncodeResult(entry,__implementations[entry.index](...args),limits,compact);
 }
 const values=input.decode(bytes,limits);
 const result=call(name,f.params.map(p=>values[p.name]));
 return output.encode(result,limits);
}
export function callBinary(name,bytes,limits={}){return __callEncoded(name,bytes,limits,false);}
export function callCompact(name,bytes,limits={}){return __callEncoded(name,bytes,limits,true);}
// Same stable, well-typed caller inputs as call; the result owns every container.
// The checked source return type justifies trusted copying, not arbitrary input.
export function callOwned(name,args,limits={}){
 if(!Object.hasOwn(__ownedFunctions,name)||!Object.hasOwn(functions,name))throw Error('unsupported owned function');
 const result=__ownedImplementations[name](...args);return __ownedFunctions[name](result,createValueCaptureBudget(limits),0);
}
function __privateCapture6(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if((value!==null&&typeof value==='object'&&Object.hasOwn(value,'None')&&Object.keys(value).length===1)&&value.None===null)return {None:null};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Some')&&Object.keys(value).length===1)return {Some:__privateCapture5(value.Some,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture12(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture10(value["a"],budget,depth+1),["b"]:__privateCapture10(value["b"],budget,depth+1)};}
function __privateCapture8(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture9(value["a"],budget,depth+1),["b"]:__privateCapture9(value["b"],budget,depth+1)};}
function __privateCapture0(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture1(value["a"],budget,depth+1),["b"]:__privateCapture1(value["b"],budget,depth+1)};}
function __privateCapture11(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"p")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"q")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"r")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"s")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"t")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"u")){throw Error('invalid value for wire schema');}return {["p"]:__privateCapture12(value["p"],budget,depth+1),["q"]:__privateCapture12(value["q"],budget,depth+1),["r"]:__privateCapture12(value["r"],budget,depth+1),["s"]:__privateCapture12(value["s"],budget,depth+1),["t"]:__privateCapture12(value["t"],budget,depth+1),["u"]:__privateCapture12(value["u"],budget,depth+1)};}
function __privateCapture7(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"p")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"q")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"r")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"s")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"t")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"u")){throw Error('invalid value for wire schema');}return {["p"]:__privateCapture8(value["p"],budget,depth+1),["q"]:__privateCapture8(value["q"],budget,depth+1),["r"]:__privateCapture8(value["r"],budget,depth+1),["s"]:__privateCapture8(value["s"],budget,depth+1),["t"]:__privateCapture8(value["t"],budget,depth+1),["u"]:__privateCapture8(value["u"],budget,depth+1)};}
function __privateCapture2(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"p")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"q")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"r")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"s")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"t")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"u")){throw Error('invalid value for wire schema');}return {["p"]:__privateCapture0(value["p"],budget,depth+1),["q"]:__privateCapture0(value["q"],budget,depth+1),["r"]:__privateCapture0(value["r"],budget,depth+1),["s"]:__privateCapture0(value["s"],budget,depth+1),["t"]:__privateCapture0(value["t"],budget,depth+1),["u"]:__privateCapture0(value["u"],budget,depth+1)};}
function __privateCapture10(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["tangent"]:__privateCapture1(value["tangent"],budget,depth+1)};}
function __privateCapture9(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==13){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_0")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_1")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_2")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_3")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_4")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_5")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_6")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_7")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_8")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_9")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_10")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_11")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["tangent_0"]:__privateCapture1(value["tangent_0"],budget,depth+1),["tangent_1"]:__privateCapture1(value["tangent_1"],budget,depth+1),["tangent_2"]:__privateCapture1(value["tangent_2"],budget,depth+1),["tangent_3"]:__privateCapture1(value["tangent_3"],budget,depth+1),["tangent_4"]:__privateCapture1(value["tangent_4"],budget,depth+1),["tangent_5"]:__privateCapture1(value["tangent_5"],budget,depth+1),["tangent_6"]:__privateCapture1(value["tangent_6"],budget,depth+1),["tangent_7"]:__privateCapture1(value["tangent_7"],budget,depth+1),["tangent_8"]:__privateCapture1(value["tangent_8"],budget,depth+1),["tangent_9"]:__privateCapture1(value["tangent_9"],budget,depth+1),["tangent_10"]:__privateCapture1(value["tangent_10"],budget,depth+1),["tangent_11"]:__privateCapture1(value["tangent_11"],budget,depth+1)};}
function __privateCapture5(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"previous")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture4(value["value"],budget,depth+1),["previous"]:__privateCapture6(value["previous"],budget,depth+1)};}
function __privateCapture3(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='boolean'){throw Error('invalid value for wire schema');}budget.add(1);return value;}
function __privateCapture1(value,budget,depth=0){budget.enter(depth,4);let bits;if(typeof value==='number'&&Number.isFinite(value)){bits=__bits(value);if(!Number.isFinite(__float(bits))){throw Error('invalid value for wire schema');}}else{if(!(value!==null&&typeof value==='object'&&Object.hasOwn(value,'F32Bits')&&Object.keys(value).length===1)){throw Error('invalid value for wire schema');}bits=value.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295){throw Error('invalid value for wire schema');}}budget.add(4);return __nfFromBits(bits);}
function __privateCapture4(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='number'||!Number.isInteger(value)||value<0||value>4294967295){throw Error('invalid value for wire schema');}budget.add(4);return value===0?0:value;}
function __privateWireValue13(reader){const end=reader.frame();const value=reader.byte()?{Some:__privateWireValue12(reader)}:{None:null};reader.finish(end);return value;}
function __privateWireValue20(reader){const end=reader.frame();const value={["__ink_differential_24"]:__privateWireValue19(reader),["__ink_differential_25"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue21(reader){const end=reader.frame();const value={["__ink_differential_28"]:__privateWireValue19(reader),["__ink_differential_29"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue22(reader){const end=reader.frame();const value={["__ink_differential_32"]:__privateWireValue19(reader),["__ink_differential_33"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue24(reader){const end=reader.frame();const value={["a"]:__privateWireValue19(reader),["b"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue16(reader){const end=reader.frame();const value={["a"]:__privateWireValue17(reader),["b"]:__privateWireValue17(reader)};reader.finish(end);return value;}
function __privateWireValue0(reader){const end=reader.frame();const value={["a"]:__privateWireValue1(reader),["b"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue23(reader){const end=reader.frame();const value={["p"]:__privateWireValue24(reader),["q"]:__privateWireValue24(reader),["r"]:__privateWireValue24(reader),["s"]:__privateWireValue24(reader),["t"]:__privateWireValue24(reader),["u"]:__privateWireValue24(reader)};reader.finish(end);return value;}
function __privateWireValue15(reader){const end=reader.frame();const value={["p"]:__privateWireValue16(reader),["q"]:__privateWireValue16(reader),["r"]:__privateWireValue16(reader),["s"]:__privateWireValue16(reader),["t"]:__privateWireValue16(reader),["u"]:__privateWireValue16(reader)};reader.finish(end);return value;}
function __privateWireValue3(reader){const end=reader.frame();const value={["p"]:__privateWireValue0(reader),["q"]:__privateWireValue0(reader),["r"]:__privateWireValue0(reader),["s"]:__privateWireValue0(reader),["t"]:__privateWireValue0(reader),["u"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue19(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["tangent"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue17(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["tangent_0"]:__privateWireValue1(reader),["tangent_1"]:__privateWireValue1(reader),["tangent_2"]:__privateWireValue1(reader),["tangent_3"]:__privateWireValue1(reader),["tangent_4"]:__privateWireValue1(reader),["tangent_5"]:__privateWireValue1(reader),["tangent_6"]:__privateWireValue1(reader),["tangent_7"]:__privateWireValue1(reader),["tangent_8"]:__privateWireValue1(reader),["tangent_9"]:__privateWireValue1(reader),["tangent_10"]:__privateWireValue1(reader),["tangent_11"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue12(reader){const end=reader.frame();const value={["value"]:__privateWireValue11(reader),["previous"]:__privateWireValue13(reader)};reader.finish(end);return value;}
function __privateWireValue7(reader){const end=reader.frame();const value={["w"]:__privateWireValue0(reader),["c"]:__privateWireValue6(reader)};reader.finish(end);return value;}
function __privateWireValue2(reader){const end=reader.frame();const value={["w"]:__privateWireValue0(reader),["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue5(reader){const end=reader.frame();const value={["w"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue25(reader){const end=reader.frame();const value={["w"]:__privateWireValue23(reader),["x"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue18(reader){const end=reader.frame();const value={["w"]:__privateWireValue15(reader),["x"]:__privateWireValue17(reader)};reader.finish(end);return value;}
function __privateWireValue26(reader){const end=reader.frame();const value={["w"]:__privateWireValue3(reader),["__ink_differential_35"]:__privateWireValue3(reader),["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue4(reader){const end=reader.frame();const value={["w"]:__privateWireValue3(reader),["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue8(reader){const end=reader.frame();const value={["x"]:__privateWireValue1(reader),["c"]:__privateWireValue6(reader)};reader.finish(end);return value;}
function __privateWireValue10(reader){const end=reader.frame();const value={["x"]:__privateWireValue1(reader),["y"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue9(reader){const end=reader.frame();const value={["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue14(reader){const end=reader.frame();const value={["x"]:__privateWireValue11(reader)};reader.finish(end);return value;}
function __privateWireValue6(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __privateWireValue1(reader){const end=reader.frame();const value=__nfFromBits(reader.word());reader.finish(end);return value;}
function __privateWireValue11(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __compiledOwnedValue6(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__compiledOwnedValue7(value.Some,budget,depth+1)};}
function __compiledOwnedValue13(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue11(value["a"],budget,depth+1),["b"]:__compiledOwnedValue11(value["b"],budget,depth+1)};}
function __compiledOwnedValue9(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue10(value["a"],budget,depth+1),["b"]:__compiledOwnedValue10(value["b"],budget,depth+1)};}
function __compiledOwnedValue0(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue1(value["a"],budget,depth+1),["b"]:__compiledOwnedValue1(value["b"],budget,depth+1)};}
function __compiledOwnedValue12(value,budget,depth){budget.enter(depth,4);return {["p"]:__compiledOwnedValue13(value["p"],budget,depth+1),["q"]:__compiledOwnedValue13(value["q"],budget,depth+1),["r"]:__compiledOwnedValue13(value["r"],budget,depth+1),["s"]:__compiledOwnedValue13(value["s"],budget,depth+1),["t"]:__compiledOwnedValue13(value["t"],budget,depth+1),["u"]:__compiledOwnedValue13(value["u"],budget,depth+1)};}
function __compiledOwnedValue8(value,budget,depth){budget.enter(depth,4);return {["p"]:__compiledOwnedValue9(value["p"],budget,depth+1),["q"]:__compiledOwnedValue9(value["q"],budget,depth+1),["r"]:__compiledOwnedValue9(value["r"],budget,depth+1),["s"]:__compiledOwnedValue9(value["s"],budget,depth+1),["t"]:__compiledOwnedValue9(value["t"],budget,depth+1),["u"]:__compiledOwnedValue9(value["u"],budget,depth+1)};}
function __compiledOwnedValue2(value,budget,depth){budget.enter(depth,4);return {["p"]:__compiledOwnedValue0(value["p"],budget,depth+1),["q"]:__compiledOwnedValue0(value["q"],budget,depth+1),["r"]:__compiledOwnedValue0(value["r"],budget,depth+1),["s"]:__compiledOwnedValue0(value["s"],budget,depth+1),["t"]:__compiledOwnedValue0(value["t"],budget,depth+1),["u"]:__compiledOwnedValue0(value["u"],budget,depth+1)};}
function __compiledOwnedValue11(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["tangent"]:__compiledOwnedValue1(value["tangent"],budget,depth+1)};}
function __compiledOwnedValue10(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["tangent_0"]:__compiledOwnedValue1(value["tangent_0"],budget,depth+1),["tangent_1"]:__compiledOwnedValue1(value["tangent_1"],budget,depth+1),["tangent_2"]:__compiledOwnedValue1(value["tangent_2"],budget,depth+1),["tangent_3"]:__compiledOwnedValue1(value["tangent_3"],budget,depth+1),["tangent_4"]:__compiledOwnedValue1(value["tangent_4"],budget,depth+1),["tangent_5"]:__compiledOwnedValue1(value["tangent_5"],budget,depth+1),["tangent_6"]:__compiledOwnedValue1(value["tangent_6"],budget,depth+1),["tangent_7"]:__compiledOwnedValue1(value["tangent_7"],budget,depth+1),["tangent_8"]:__compiledOwnedValue1(value["tangent_8"],budget,depth+1),["tangent_9"]:__compiledOwnedValue1(value["tangent_9"],budget,depth+1),["tangent_10"]:__compiledOwnedValue1(value["tangent_10"],budget,depth+1),["tangent_11"]:__compiledOwnedValue1(value["tangent_11"],budget,depth+1)};}
function __compiledOwnedValue5(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue4(value["value"],budget,depth+1),["previous"]:__compiledOwnedValue6(value["previous"],budget,depth+1)};}
function __compiledOwnedValue3(value,budget,depth){budget.enter(depth,5);return value;}
function __compiledOwnedValue1(value,budget,depth){budget.enter(depth,8);const bits=typeof value==='number'?__bits(value):value.F32Bits;return {F32Bits:bits===0?0:bits};}
function __compiledOwnedValue7(value,budget,depth){return __compiledOwnedValue5(value,budget,depth);}
function __compiledOwnedValue4(value,budget,depth){budget.enter(depth,8);return value>>>0;}
function __privateWireWrite6(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Some')){writer.byte(1);__privateWireWrite5(writer,value.Some,compact);}else{writer.byte(0);}writer.closeFrame(frame);}
function __privateWireWrite12(writer,value,compact){const frame=writer.openFrame();__privateWireWrite10(writer,value["a"],compact);__privateWireWrite10(writer,value["b"],compact);writer.closeFrame(frame);}
function __privateWireWrite8(writer,value,compact){const frame=writer.openFrame();__privateWireWrite9(writer,value["a"],compact);__privateWireWrite9(writer,value["b"],compact);writer.closeFrame(frame);}
function __privateWireWrite0(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["a"],compact);__privateWireWrite1(writer,value["b"],compact);writer.closeFrame(frame);}
function __privateWireWrite11(writer,value,compact){const frame=writer.openFrame();__privateWireWrite12(writer,value["p"],compact);__privateWireWrite12(writer,value["q"],compact);__privateWireWrite12(writer,value["r"],compact);__privateWireWrite12(writer,value["s"],compact);__privateWireWrite12(writer,value["t"],compact);__privateWireWrite12(writer,value["u"],compact);writer.closeFrame(frame);}
function __privateWireWrite7(writer,value,compact){const frame=writer.openFrame();__privateWireWrite8(writer,value["p"],compact);__privateWireWrite8(writer,value["q"],compact);__privateWireWrite8(writer,value["r"],compact);__privateWireWrite8(writer,value["s"],compact);__privateWireWrite8(writer,value["t"],compact);__privateWireWrite8(writer,value["u"],compact);writer.closeFrame(frame);}
function __privateWireWrite2(writer,value,compact){const frame=writer.openFrame();__privateWireWrite0(writer,value["p"],compact);__privateWireWrite0(writer,value["q"],compact);__privateWireWrite0(writer,value["r"],compact);__privateWireWrite0(writer,value["s"],compact);__privateWireWrite0(writer,value["t"],compact);__privateWireWrite0(writer,value["u"],compact);writer.closeFrame(frame);}
function __privateWireWrite10(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite1(writer,value["tangent"],compact);writer.closeFrame(frame);}
function __privateWireWrite9(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite1(writer,value["tangent_0"],compact);__privateWireWrite1(writer,value["tangent_1"],compact);__privateWireWrite1(writer,value["tangent_2"],compact);__privateWireWrite1(writer,value["tangent_3"],compact);__privateWireWrite1(writer,value["tangent_4"],compact);__privateWireWrite1(writer,value["tangent_5"],compact);__privateWireWrite1(writer,value["tangent_6"],compact);__privateWireWrite1(writer,value["tangent_7"],compact);__privateWireWrite1(writer,value["tangent_8"],compact);__privateWireWrite1(writer,value["tangent_9"],compact);__privateWireWrite1(writer,value["tangent_10"],compact);__privateWireWrite1(writer,value["tangent_11"],compact);writer.closeFrame(frame);}
function __privateWireWrite5(writer,value,compact){const frame=writer.openFrame();__privateWireWrite4(writer,value["value"],compact);__privateWireWrite6(writer,value["previous"],compact);writer.closeFrame(frame);}
function __privateWireWrite3(writer,value,compact){const frame=writer.openFrame();writer.byte(value?1:0);writer.closeFrame(frame);}
function __privateWireWrite1(writer,value,compact){const frame=writer.openFrame();writer.word(__nfBits(value));writer.closeFrame(frame);}
function __privateWireWrite4(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
// Handles have no mutable private payload surface. Membership and type identity
// are checked by this module's closure; copied/foreign objects cannot forge them.
const __compiledHandles=new WeakMap();
const __compiledBindings=new WeakMap();
function __compiledHandle(identity,value,guaranteed=false){
 const handle=Object.freeze(Object.create(null));
 __compiledHandles.set(handle,{identity,value,guaranteed});return handle;
}
function __compiledEntry(handle,identity){
 const entry=__compiledHandles.get(handle);
 if(!entry||entry.identity!==identity)throw Error('compiled value type or owner mismatch');
 return entry;
}
function __compiledUnwrap(handle,identity){return __compiledEntry(handle,identity).value;}
// Emit the portable schema's framing/scalar events without creating a buffer
// or exposing private composite nodes. Only this wrapper receives callbacks
// from the literal writer; host visitors never receive those closures.
function __compiledValueEvents(sink,limits){
 const methods=['begin','end','byte','word','wide','text','count'];
 for(const name of methods)if(typeof sink?.[name]!=='function')throw Error('compiled value visitor method: '+name);
 const budget=createValueCaptureBudget(limits);let depth=0,closed=false;
 const active=()=>{if(closed)throw Error('compiled value visitor is closed');};
 const writer=Object.freeze({
  openFrame(){active();budget.enter(depth,4);depth++;sink.begin();return 0;}
  ,closeFrame(){active();if(depth===0)throw Error('wire frame boundary');try{sink.end();}finally{depth--;}}
  ,frame(emit){active();budget.enter(depth,4);depth++;sink.begin();try{emit();sink.end();}finally{depth--;}}
  ,byte(value){active();budget.add(1);sink.byte(value);}
  ,word(value){active();budget.add(4);sink.word(value);}
  ,wide(value){active();budget.add(8);sink.wide(value);}
  ,text(value){active();budget.text(value);sink.text(value);}
  ,count(value){active();budget.add(4);if(value>budget.remaining)throw Error('wire sequence size');sink.count(value);}
 });
 return {writer,close(){closed=true;}};
}
function __compiledReduction(factory,root,reduce,identity){
 if(typeof factory!=='function')throw Error('compiled reduction factory');
 const reducers=[],seen=new Set(),nodes=__reductionNodes();
 const prepare=index=>{
  if(seen.has(index))return;seen.add(index);
  const node=nodes[index];
  for(const child of node.children)prepare(child);
  const reducer=factory(node,index);
  if(node.kind==='list'||node.kind==='vector'){
   const start=reducer?.start,step=reducer?.step,finish=reducer?.finish;
   if(typeof start!=='function'||typeof step!=='function'||typeof finish!=='function')throw Error('compiled collection reduction');
   reducers[index]=Object.freeze({start,step,finish});
  }else{
   if(typeof reducer!=='function')throw Error('compiled value reduction');
   reducers[index]=reducer;
  }
 };
 prepare(root);Object.freeze(reducers);
 return Object.freeze(function(handle,context,limits={}){
  const value=__compiledUnwrap(handle,identity),budget=createValueCaptureBudget(limits);
  return reduce(value,reducers,budget,0,context);
 });
}
function __compiledCodec(schema,capture,read,write,copy,constructorRoot,reductionRoot,reduce,portableFused=false,compactFused=false){
 const privateCodec=createCompiledValueCodec(schema,read),publicCodec=privateCodec;
 let fusedCodec;const fused=()=>fusedCodec??=createFusedValueCodec(schema,read);
 const identity=schema.identity;
 const codec=Object.freeze({
  identity,
  descriptor:publicCodec.descriptor,
  resolve(type){return publicCodec.resolve(type);},
  capture(value,limits={}){
   return __compiledHandle(identity,capture(value,createValueCaptureBudget(limits),0));
  },
  decode(bytes,limits={}){return __compiledHandle(identity,(portableFused?fused():privateCodec).decode(bytes,limits));},
  decodeCompact(bytes,limits={}){return __compiledHandle(identity,(compactFused?fused():privateCodec).compact().decode(bytes,limits));},
  decodeFused(bytes,limits={}){return __compiledHandle(identity,fused().decode(bytes,limits));},
  decodeCompactFused(bytes,limits={}){return __compiledHandle(identity,fused().compact().decode(bytes,limits));},
  encode(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.encodeWith(writer=>write(writer,value,false),limits);},
  encodeCompact(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.compact().encodeWith(writer=>write(writer,value,true),limits);},
  materialize(handle,limits={}){return copy(__compiledUnwrap(handle,identity),createValueCaptureBudget(limits),0);},
  builder(limits={}){return __valueBuilder(__constructorNodes(),constructorRoot,identity,limits);},
  reducer(factory){return __compiledReduction(factory,reductionRoot,reduce,identity);},
  visit(handle,sink,limits={}){
   const value=__compiledUnwrap(handle,identity),events=__compiledValueEvents(sink,limits);
   try{write(events.writer,value,false);}finally{events.close();}
  },
 });
 __compiledBindings.set(codec,{publicCodec,write,capture});return codec;
}

function __compiledEncodeResult(entry,value,limits,compact){
 const {publicCodec,write}=__compiledBindings.get(entry.result());
 return (compact?publicCodec.compact():publicCodec).encodeWith(writer=>write(writer,value,compact),limits);
}
let __constructorNodesValue;function __constructorNodes(){return __constructorNodesValue??=[{kind:'record',fields:["a","b"],patterns:[{bytes:4,label:"record",children:[1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1]})}]},{kind:"f32",scalar:__privateCapture1},{kind:'record',fields:["p","q","r","s","t","u"],patterns:[{bytes:4,label:"record",children:[0,0,0,0,0,0],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["p"]:values[0],["q"]:values[1],["r"]:values[2],["s"]:values[3],["t"]:values[4],["u"]:values[5]})}]},{kind:"bool",scalar:__privateCapture3},{kind:"u32",scalar:__privateCapture4},{kind:'record',fields:["value","previous"],patterns:[{bytes:4,label:"record",children:[4,6],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["previous"]:values[1]})}]},{kind:'option',patterns:[{bytes:5,label:"None",children:[],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({None:null})},{bytes:5,label:"Some",children:[5],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({Some:values[0]})}]},{kind:'record',fields:["p","q","r","s","t","u"],patterns:[{bytes:4,label:"record",children:[8,8,8,8,8,8],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["p"]:values[0],["q"]:values[1],["r"]:values[2],["s"]:values[3],["t"]:values[4],["u"]:values[5]})}]},{kind:'record',fields:["a","b"],patterns:[{bytes:4,label:"record",children:[9,9],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1]})}]},{kind:'record',fields:["value","tangent_0","tangent_1","tangent_2","tangent_3","tangent_4","tangent_5","tangent_6","tangent_7","tangent_8","tangent_9","tangent_10","tangent_11"],patterns:[{bytes:4,label:"record",children:[1,1,1,1,1,1,1,1,1,1,1,1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["tangent_0"]:values[1],["tangent_1"]:values[2],["tangent_2"]:values[3],["tangent_3"]:values[4],["tangent_4"]:values[5],["tangent_5"]:values[6],["tangent_6"]:values[7],["tangent_7"]:values[8],["tangent_8"]:values[9],["tangent_9"]:values[10],["tangent_10"]:values[11],["tangent_11"]:values[12]})}]},{kind:'record',fields:["value","tangent"],patterns:[{bytes:4,label:"record",children:[1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["tangent"]:values[1]})}]},{kind:'record',fields:["p","q","r","s","t","u"],patterns:[{bytes:4,label:"record",children:[12,12,12,12,12,12],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["p"]:values[0],["q"]:values[1],["r"]:values[2],["s"]:values[3],["t"]:values[4],["u"]:values[5]})}]},{kind:'record',fields:["a","b"],patterns:[{bytes:4,label:"record",children:[10,10],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1]})}]}];}
// Typed input construction only: plans contain literal constructor/capture
// functions emitted from source schemas. No source expression evaluator.
// All frames and private values remain in this closure; callers receive only
// an owned opaque handle after one complete, well-typed root is constructed.
const __constructorPaths=new WeakMap();
function __valueBuilder(nodes,root,identity,limits){
 const budget=createValueCaptureBudget(limits),frames=[];
 let result,targetNode,targetDepth,complete=false,closed=false,failed=false,busy=false;
 const fail=message=>{failed=true;frames.length=0;result=undefined;throw Error(message);};
 const active=()=>{if(failed||closed)throw Error('value builder is closed');};
 const expected=()=>{
  if(!frames.length){if(complete)fail('value builder root already complete');targetNode=root;targetDepth=0;return;}
  const frame=frames.at(-1),position=frame.values.length;
  if(!frame.pattern.sequence&&position>=frame.pattern.children.length)fail('value builder constructor is full');
  targetNode=frame.pattern.sequence?frame.pattern.children[0]:frame.pattern.children[position];targetDepth=frame.depth+frame.pattern.childDepth;
 };
 const accept=value=>{
  if(frames.length)frames.at(-1).values.push(value);
  else{result=value;complete=true;}
 };
 const execute=(operation,first,second)=>{
  active();if(busy)throw Error('value builder operation already active');busy=true;
  try{return operation(first,second);}catch(error){failed=true;frames.length=0;result=undefined;throw error;}finally{busy=false;}
 };
 // Compile and cache constructor paths independently of the session's values.
 const pathPlan=(choices,startNode,startDepth)=>{
   if(!Array.isArray(choices)||choices.length===0||choices.length>128)fail('invalid value builder path');
   let cache=__constructorPaths.get(nodes);if(!cache){cache=new WeakMap();__constructorPaths.set(nodes,cache);}
   let entries=cache.get(choices),saved=entries?.get(startNode);
   if(saved)return saved;
   const path=[],charges=[];let node=startNode,depth=startDepth;
   for(let i=0;i<choices.length;i++){
    const choice=choices[i],patterns=nodes[node].patterns;
    if(!Number.isSafeInteger(choice)||choice<0||!patterns||choice>=patterns.length)fail('invalid value builder constructor');
    const pattern=patterns[choice];charges.push([pattern,depth-startDepth]);path.push({pattern,node:nodes[node]});
    if(i+1<choices.length){if(pattern.sequence||pattern.children.length!==1)fail('value builder path is not unary');node=pattern.children[0];depth+=pattern.childDepth;}
   }
   const terminal=path.at(-1).pattern;
   // Compose literal constructor functions once per path, instead of
   // allocating and interpreting another recursive closure for every value.
   const compose=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=args=>args[0];
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=args=>p.make([inner(args)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?compose(last+1):args=>args[0]):compose(last);
     return args=>node.flat(index,payload(args));
    }
    const inner=at+1<path.length?compose(at+1):null;
    if(pattern.transparent)return inner??(args=>args[0]);
    return inner?args=>pattern.make([inner(args)]):pattern.make;
   };
   const make=compose(0);
   // Scalar paths use the same literal constructors, but pass the leaf
   // directly through erased records and flat sums. No temporary argument
   // array is needed at those edges. Ordinary constructors keep their array
   // calling convention; no private value reaches the public builder API.
   const composeScalar=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=value=>value;
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=value=>p.make([inner(value)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?composeScalar(last+1):value=>value):composeScalar(last);
     return value=>node.flat(index,payload(value));
    }
    const inner=at+1<path.length?composeScalar(at+1):null;
    if(pattern.transparent)return inner??(value=>value);
    return inner?value=>pattern.make([inner(value)]):value=>pattern.make([value]);
   };
   const scalar=composeScalar(0);
   const pattern={...terminal,make};
   // Only frozen arrays of ordinary data properties can key reusable plans.
   // Mutable arrays and frozen accessor arrays retain checked per-call paths.
   const fixed=charges.every(([p])=>Number.isSafeInteger(p.bytes)&&p.bytes>=4);
   const plan={pattern,scalar,charges,offset:depth-startDepth,bytes:fixed?charges.reduce((n,[p])=>n+p.bytes,0):null};
   let reusable=Object.isFrozen(choices);
   for(let i=0;reusable&&i<choices.length;i++){const field=Object.getOwnPropertyDescriptor(choices,String(i));reusable=!!field&&Object.hasOwn(field,'value');}
   if(reusable){
    if(!entries){entries=new Map();cache.set(choices,entries);}entries.set(startNode,plan);
   }
   return plan;
 };
 const chargePath=(plan,depth)=>{
  // Each emitted constructor consumes one node and a fixed frame/tag cost.
  // Only take the combined charge when every original check would succeed.
  // Replaying the original order retains the exact first failure otherwise.
  if(plan.bytes!==null&&depth+plan.offset<=budget.depth&&plan.charges.length<=budget.remaining&&budget.bytes+plan.bytes<=budget.limit){
   budget.remaining-=plan.charges.length;budget.bytes+=plan.bytes;return;
  }
  for(const [pattern,offset]of plan.charges)pattern.charge(budget,depth+offset);
 };
 // Operations are allocated once per session, and share expected-node
 // scratch only while the existing reentrancy guard is held.
 const openOperation=(choice)=>{
   expected();const node=nodes[targetNode];
   if(!Number.isSafeInteger(choice)||choice<0||!node.patterns||choice>=node.patterns.length)fail('invalid value builder constructor');
   const pattern=node.patterns[choice];pattern.charge(budget,targetDepth);
   frames.push({pattern,depth:targetDepth,values:[]});
 };
 const openPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth);
   chargePath(plan,targetDepth);
   frames.push({pattern:plan.pattern,depth:targetDepth+plan.offset,values:[]});
 };
 const scalarPathOperation=(choices,value)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==1)fail('value builder path has no scalar leaf');
   const capture=nodes[pattern.children[0]].scalar;
   if(typeof capture!=='function')fail('value builder path has no scalar leaf');
   chargePath(plan,targetDepth);
   const leaf=capture(value,budget,targetDepth+plan.offset+pattern.childDepth);
   accept(plan.scalar(leaf));
 };
 const emptyPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==0)fail('value builder path is not empty');
   chargePath(plan,targetDepth);accept(pattern.make([]));
 };
 const scalarOperation=(value)=>{
   expected();const capture=nodes[targetNode].scalar;
   if(typeof capture!=='function')fail('value builder expects a constructor');
   accept(capture(value,budget,targetDepth));
 };
 const closeOperation=()=>{
   if(!frames.length)fail('value builder has no open constructor');
   const frame=frames.at(-1),pattern=frame.pattern,count=frame.values.length;
   if(!pattern.sequence&&count!==pattern.children.length||pattern.size!==undefined&&count!==pattern.size)fail('value builder constructor arity');
   if(pattern.sequence&&count>budget.limit)fail('wire sequence size');
   const value=pattern.make(frame.values);
   frames.pop();accept(value);
 };
 const finishOperation=()=>{
   if(frames.length||!complete)fail('value builder root is incomplete');
   closed=true;const handle=__compiledHandle(identity,result);result=undefined;return handle;
 };
 const api=Object.freeze({
  open(choice){return execute(openOperation,choice);},
  // Charge every source constructor even when unary paths share one frame.
  openPath(choices){return execute(openPathOperation,choices);},
  // Complete the path and leaf without intermediate session frames.
  scalarPath(choices,value){return execute(scalarPathOperation,choices,value);},
  emptyPath(choices){return execute(emptyPathOperation,choices);},
  scalar(value){return execute(scalarOperation,value);},
  close(){return execute(closeOperation);},
  finish(){return execute(finishOperation);},
  abort(){if(busy)throw Error('value builder operation already active');failed=true;frames.length=0;result=undefined;},
 });
 return api;
}
function __reduceValue0(value,r,b,d,c){b.enter(d,4);return r[0](__reduceValue1(value["a"],r,b,d+1,c),__reduceValue1(value["b"],r,b,d+1,c),c);}
function __reduceValue1(value,r,b,d,c){b.enter(d,8);return r[1]({F32Bits:__nfBits(value)},c);}
function __reduceValue2(value,r,b,d,c){b.enter(d,4);return r[2](__reduceValue0(value["p"],r,b,d+1,c),__reduceValue0(value["q"],r,b,d+1,c),__reduceValue0(value["r"],r,b,d+1,c),__reduceValue0(value["s"],r,b,d+1,c),__reduceValue0(value["t"],r,b,d+1,c),__reduceValue0(value["u"],r,b,d+1,c),c);}
function __reduceValue3(value,r,b,d,c){b.enter(d,5);return r[3](value,c);}
function __reduceValue4(value,r,b,d,c){b.enter(d,8);return r[4](value,c);}
function __reduceValue5(value,r,b,d,c){b.enter(d,4);return r[5](__reduceValue4(value["value"],r,b,d+1,c),__reduceValue6(value["previous"],r,b,d+1,c),c);}
function __reduceValue6(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'None')&&value.None===null?r[6](0,null,c):r[6](1,__reduceValue5(value.Some,r,b,d+1,c),c);}
function __reduceValue7(value,r,b,d,c){b.enter(d,4);return r[7](__reduceValue8(value["p"],r,b,d+1,c),__reduceValue8(value["q"],r,b,d+1,c),__reduceValue8(value["r"],r,b,d+1,c),__reduceValue8(value["s"],r,b,d+1,c),__reduceValue8(value["t"],r,b,d+1,c),__reduceValue8(value["u"],r,b,d+1,c),c);}
function __reduceValue8(value,r,b,d,c){b.enter(d,4);return r[8](__reduceValue9(value["a"],r,b,d+1,c),__reduceValue9(value["b"],r,b,d+1,c),c);}
function __reduceValue9(value,r,b,d,c){b.enter(d,4);return r[9](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue1(value["tangent_0"],r,b,d+1,c),__reduceValue1(value["tangent_1"],r,b,d+1,c),__reduceValue1(value["tangent_2"],r,b,d+1,c),__reduceValue1(value["tangent_3"],r,b,d+1,c),__reduceValue1(value["tangent_4"],r,b,d+1,c),__reduceValue1(value["tangent_5"],r,b,d+1,c),__reduceValue1(value["tangent_6"],r,b,d+1,c),__reduceValue1(value["tangent_7"],r,b,d+1,c),__reduceValue1(value["tangent_8"],r,b,d+1,c),__reduceValue1(value["tangent_9"],r,b,d+1,c),__reduceValue1(value["tangent_10"],r,b,d+1,c),__reduceValue1(value["tangent_11"],r,b,d+1,c),c);}
function __reduceValue10(value,r,b,d,c){b.enter(d,4);return r[10](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue1(value["tangent"],r,b,d+1,c),c);}
function __reduceValue11(value,r,b,d,c){b.enter(d,4);return r[11](__reduceValue12(value["p"],r,b,d+1,c),__reduceValue12(value["q"],r,b,d+1,c),__reduceValue12(value["r"],r,b,d+1,c),__reduceValue12(value["s"],r,b,d+1,c),__reduceValue12(value["t"],r,b,d+1,c),__reduceValue12(value["u"],r,b,d+1,c),c);}
function __reduceValue12(value,r,b,d,c){b.enter(d,4);return r[12](__reduceValue10(value["a"],r,b,d+1,c),__reduceValue10(value["b"],r,b,d+1,c),c);}
let __reductionNodeCache;function __reductionNodes(){return __reductionNodeCache??=Object.freeze([Object.freeze({"children":Object.freeze([1,1]),"fields":Object.freeze(["a","b"]),"kind":"record","name":"Pair"}),Object.freeze({"children":Object.freeze([]),"kind":"f32"}),Object.freeze({"children":Object.freeze([0,0,0,0,0,0]),"fields":Object.freeze(["p","q","r","s","t","u"]),"kind":"record","name":"Bundle"}),Object.freeze({"children":Object.freeze([]),"kind":"bool"}),Object.freeze({"children":Object.freeze([]),"kind":"u32"}),Object.freeze({"children":Object.freeze([4,6]),"fields":Object.freeze(["value","previous"]),"kind":"record","name":"Node"}),Object.freeze({"children":Object.freeze([5]),"kind":"option"}),Object.freeze({"children":Object.freeze([8,8,8,8,8,8]),"fields":Object.freeze(["p","q","r","s","t","u"]),"kind":"record","name":"__ink_differential_4"}),Object.freeze({"children":Object.freeze([9,9]),"fields":Object.freeze(["a","b"]),"kind":"record","name":"__ink_differential_5"}),Object.freeze({"children":Object.freeze([1,1,1,1,1,1,1,1,1,1,1,1,1]),"fields":Object.freeze(["value","tangent_0","tangent_1","tangent_2","tangent_3","tangent_4","tangent_5","tangent_6","tangent_7","tangent_8","tangent_9","tangent_10","tangent_11"]),"kind":"record","name":"__ink_differential_2"}),Object.freeze({"children":Object.freeze([1,1]),"fields":Object.freeze(["value","tangent"]),"kind":"record","name":"__ink_differential_0"}),Object.freeze({"children":Object.freeze([12,12,12,12,12,12]),"fields":Object.freeze(["p","q","r","s","t","u"]),"kind":"record","name":"__ink_differential_21"}),Object.freeze({"children":Object.freeze([10,10]),"fields":Object.freeze(["a","b"]),"kind":"record","name":"__ink_differential_22"})]);}
function __compiledNamed1(){return {"Node":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}};}
function __compiledNamed0(){return {};}
let __compiledCodec0Value;function __compiledCodec0(){return __compiledCodec0Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"5728eeaa0e138ea2f93b2c91d176edec672a97fdd0e45fa08b4dacd31d4beebf","named":__compiledNamed0(),"root":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},__privateCapture0,__privateWireValue0,__privateWireWrite0,__compiledOwnedValue0,0,0,__reduceValue0,false,false);}
let __compiledCodec1Value;function __compiledCodec1(){return __compiledCodec1Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":__compiledNamed0(),"root":{"kind":"f32"}},__privateCapture1,__privateWireValue1,__privateWireWrite1,__compiledOwnedValue1,1,1,__reduceValue1,false,false);}
let __compiledCodec2Value;function __compiledCodec2(){return __compiledCodec2Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"7882b66162c075a7679604fdc86c31922fb250d10394af5aa2d1354c654b72e5","named":__compiledNamed0(),"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},__privateCapture2,__privateWireValue3,__privateWireWrite2,__compiledOwnedValue2,2,2,__reduceValue2,false,false);}
let __compiledCodec3Value;function __compiledCodec3(){return __compiledCodec3Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":__compiledNamed0(),"root":{"kind":"bool"}},__privateCapture3,__privateWireValue6,__privateWireWrite3,__compiledOwnedValue3,3,3,__reduceValue3,false,false);}
let __compiledCodec4Value;function __compiledCodec4(){return __compiledCodec4Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff","named":__compiledNamed0(),"root":{"kind":"u32"}},__privateCapture4,__privateWireValue11,__privateWireWrite4,__compiledOwnedValue4,4,4,__reduceValue4,false,false);}
let __compiledCodec5Value;function __compiledCodec5(){return __compiledCodec5Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"06a5b110d3c213512730b89ea5797ec6a338f55b0c357c4c3894a84ac3cfa9e3","named":__compiledNamed1(),"root":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}},__privateCapture5,__privateWireValue12,__privateWireWrite5,__compiledOwnedValue5,5,5,__reduceValue5,false,false);}
let __compiledCodec6Value;function __compiledCodec6(){return __compiledCodec6Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"1ed4df67eec523fb721f2ffb2ccd09b8aa81b446e7cf8b212dcb0624fdc7c7ae","named":__compiledNamed0(),"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"}},__privateCapture7,__privateWireValue15,__privateWireWrite7,__compiledOwnedValue8,7,7,__reduceValue7,false,false);}
let __compiledCodec7Value;function __compiledCodec7(){return __compiledCodec7Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"bb2b2f3efce5ad7f78fd263ef8cf59e1adcabaeb4e987b0d193c2a16c631b760","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},__privateCapture9,__privateWireValue17,__privateWireWrite9,__compiledOwnedValue10,9,9,__reduceValue9,false,false);}
let __compiledCodec8Value;function __compiledCodec8(){return __compiledCodec8Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},__privateCapture10,__privateWireValue19,__privateWireWrite10,__compiledOwnedValue11,10,10,__reduceValue10,false,false);}
let __compiledCodec9Value;function __compiledCodec9(){return __compiledCodec9Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"184b9a0f696a7df0c965d31530477d4a3b357365123b431716058e9a227b0ea0","named":__compiledNamed0(),"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"}},__privateCapture11,__privateWireValue23,__privateWireWrite11,__compiledOwnedValue12,11,11,__reduceValue11,false,false);}
const __compiledEntries=new Map([["component",{index:0,params:[__compiledCodec0,__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue2,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["energy",{index:1,params:[__compiledCodec2,__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["derivatives",{index:2,params:[__compiledCodec2,__compiledCodec1],result:__compiledCodec2,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["direction",{index:3,params:[__compiledCodec2,__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["twice",{index:4,params:[__compiledCodec0],result:__compiledCodec1,arguments:__privateWireValue5,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["selected",{index:5,params:[__compiledCodec0,__compiledCodec3],result:__compiledCodec0,arguments:__privateWireValue7,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["branches",{index:6,params:[__compiledCodec1,__compiledCodec3],result:__compiledCodec0,arguments:__privateWireValue8,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["looping",{index:7,params:[__compiledCodec1],result:__compiledCodec0,arguments:__privateWireValue9,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["strict_unused",{index:8,params:[__compiledCodec0],result:__compiledCodec1,arguments:__privateWireValue5,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["strict",{index:9,params:[__compiledCodec1,__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue10,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["history",{index:10,params:[__compiledCodec4],result:__compiledCodec5,arguments:__privateWireValue14,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["__ink_differential_3",{index:11,params:[__compiledCodec6,__compiledCodec7],result:__compiledCodec7,arguments:__privateWireValue18,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_1",{index:12,params:[__compiledCodec2,__compiledCodec1],result:__compiledCodec2,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_23",{index:13,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,arguments:__privateWireValue20,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_27",{index:14,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,arguments:__privateWireValue21,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_31",{index:15,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,arguments:__privateWireValue22,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_20",{index:16,params:[__compiledCodec9,__compiledCodec8],result:__compiledCodec8,arguments:__privateWireValue25,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_19",{index:17,params:[__compiledCodec2,__compiledCodec2,__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue26,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}]]);

export const compiledValues=Object.freeze(Object.fromEntries([...__compiledEntries].map(([name,entry])=>[name,Object.freeze({get params(){return Object.freeze(entry.params.map(codec=>codec()));},get result(){return entry.result();}})])));
function __compiledValidate(entry,owned){
 const values=owned.map(v=>v.value);
 const established=entry.onlyTypeGuards&&entry.needsInvariants.every((needed,i)=>!needed||owned[i].guaranteed);
 if(entry.precondition!==null&&!established){
  if(__implementations[entry.precondition](...values)!==true)throw Error('contract precondition failed');
  for(let i=0;i<owned.length;i++)if(entry.needsInvariants[i])owned[i].guaranteed=true;
 }
 return values;
}
export function callCompiled(name,args){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(args)||args.length!==entry.params.length)throw Error('unsupported compiled call');
 const owned=entry.params.map((codec,i)=>__compiledEntry(args[i],codec().identity)),values=__compiledValidate(entry,owned);
 // Checked source outputs satisfy their declared value interfaces. Private
 // handles expose only detached copies and never retain mutable host inputs.
 return __compiledHandle(entry.result().identity,__implementations[entry.index](...values),true);
}

// Explicit sealed-value partial application. Each token owns a bounded set of
// lexical caches; no mutable host object, global memo table or error is retained.
const __preparedCompiled=new WeakMap();
export function prepareCompiled(name,bindings){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(bindings)||bindings.length>entry.params.length)throw Error('unsupported prepared compiled call');
 const captured=new Array(entry.params.length),fixed=new Array(entry.params.length).fill(false);
 for(const binding of bindings){
  if(!Array.isArray(binding)||binding.length!==2)throw Error('prepared compiled binding');
  const [index,handle]=binding;
  if(!Number.isInteger(index)||index<0||index>=fixed.length||fixed[index])throw Error('prepared compiled parameter');
  captured[index]=__compiledEntry(handle,entry.params[index]().identity);fixed[index]=true;
 }
 const remaining=fixed.flatMap((yes,i)=>yes?[]:[i]);
 const factory=__preparedFactories.get(entry.index);
 const run=factory?factory(fixed):__implementations[entry.index];
 const token=Object.freeze(Object.create(null));
 __preparedCompiled.set(token,{entry,captured,remaining,run});return token;
}
export function callPreparedCompiled(token,args){
 const prepared=__preparedCompiled.get(token);
 if(!prepared||!Array.isArray(args)||args.length!==prepared.remaining.length)throw Error('invalid prepared compiled call');
 const {entry,captured,remaining,run}=prepared,owned=captured.slice();
 for(let i=0;i<remaining.length;i++){const at=remaining[i];owned[at]=__compiledEntry(args[i],entry.params[at]().identity);}
 const values=__compiledValidate(entry,owned);
 return __compiledHandle(entry.result().identity,run(...values),true);
}
const __intoImplementations=[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];

export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>{
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const body=__intoImplementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args.slice(0,f.params.length))!==true)throw Error('contract precondition failed');return body(...args);};
  const entry=input.every(c=>c===__identity)?implementation:(...values)=>{const context=new WeakMap();return implementation(...input.map((convert,i)=>convert(values[i],context)),values[f.params.length]);};
  return [f.name,entry];
})));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}

function __preparedPart(mask,path){
 for(const field of path){
  if(mask===true)return true;
  if(!mask || typeof mask!=="object")return false;
  mask=Object.hasOwn(mask.fields,field)?mask.fields[field]:false;
 }
 return mask;
}
function __preparedStable(mask,path){const part=__preparedPart(mask,path);return part===true || (!!part && part.all===true);}
function __prepareFn2(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[]))))return __fn2;const v1637=depth<15&&__preparedFactories.has(12)&&((__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[])));
let v1635;
return function(v1633,v1634){v1634=__nfValue(v1634);
let v1638;if(v1637){if(!v1635){const v1636=__preparedFactories.get(12);v1635=v1636([fixed[0],fixed[1]],depth+1);}v1638=v1635(v1633,v1634);}else{v1638=__fn12(v1633,v1634);}
return v1638;};}
function __prepareFn12(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[]))))return __fn12;const v2703=__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[]);
let v2702=false,v2701;
const v2891=__preparedPart(fixed[0],["p","a"]);
const v2892={all:__preparedStable(fixed[0],["p","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2891}};
const v2893=__preparedPart(fixed[0],["p","b"]);
const v2894={all:__preparedStable(fixed[0],["p","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2893}};
const v2895={all:__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"]),fields:{["a"]:v2892,["b"]:v2894}};
const v2896=__preparedPart(fixed[0],["q","a"]);
const v2897={all:__preparedStable(fixed[0],["q","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2896}};
const v2898=__preparedPart(fixed[0],["q","b"]);
const v2899={all:__preparedStable(fixed[0],["q","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2898}};
const v2900={all:__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"]),fields:{["a"]:v2897,["b"]:v2899}};
const v2901=__preparedPart(fixed[0],["r","a"]);
const v2902={all:__preparedStable(fixed[0],["r","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2901}};
const v2903=__preparedPart(fixed[0],["r","b"]);
const v2904={all:__preparedStable(fixed[0],["r","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2903}};
const v2905={all:__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"]),fields:{["a"]:v2902,["b"]:v2904}};
const v2906=__preparedPart(fixed[0],["s","a"]);
const v2907={all:__preparedStable(fixed[0],["s","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2906}};
const v2908=__preparedPart(fixed[0],["s","b"]);
const v2909={all:__preparedStable(fixed[0],["s","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2908}};
const v2910={all:__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"]),fields:{["a"]:v2907,["b"]:v2909}};
const v2911=__preparedPart(fixed[0],["t","a"]);
const v2912={all:__preparedStable(fixed[0],["t","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2911}};
const v2913=__preparedPart(fixed[0],["t","b"]);
const v2914={all:__preparedStable(fixed[0],["t","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2913}};
const v2915={all:__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"]),fields:{["a"]:v2912,["b"]:v2914}};
const v2916=__preparedPart(fixed[0],["u","a"]);
const v2917={all:__preparedStable(fixed[0],["u","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2916}};
const v2918=__preparedPart(fixed[0],["u","b"]);
const v2919={all:__preparedStable(fixed[0],["u","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2918}};
const v2920={all:__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"]),fields:{["a"]:v2917,["b"]:v2919}};
const v2921={all:__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"]),fields:{["p"]:v2895,["q"]:v2900,["r"]:v2905,["s"]:v2910,["t"]:v2915,["u"]:v2920}};
const v2935={all:__preparedStable(fixed[1],[]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:fixed[1]}};
const v2938=depth<15&&__preparedFactories.has(11)&&((__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[])));
let v2936;
return function(v2698,v2699){v2699=__nfValue(v2699);
let v2700;if(v2703&&v2702){v2700=v2701;}else{
const v2704=v2698["p"];
const v2705=__nfValue(v2704["a"]);
const v2706=1.0;
const v2707=0.0;
const v2708=0.0;
const v2709=0.0;
const v2710=0.0;
const v2711=0.0;
const v2712=0.0;
const v2713=0.0;
const v2714=0.0;
const v2715=0.0;
const v2716=0.0;
const v2717=0.0;
const v2719=v2698["p"];
const v2720=__nfValue(v2719["b"]);
const v2721=0.0;
const v2722=1.0;
const v2723=0.0;
const v2724=0.0;
const v2725=0.0;
const v2726=0.0;
const v2727=0.0;
const v2728=0.0;
const v2729=0.0;
const v2730=0.0;
const v2731=0.0;
const v2732=0.0;
const v2735=v2698["q"];
const v2736=__nfValue(v2735["a"]);
const v2737=0.0;
const v2738=0.0;
const v2739=1.0;
const v2740=0.0;
const v2741=0.0;
const v2742=0.0;
const v2743=0.0;
const v2744=0.0;
const v2745=0.0;
const v2746=0.0;
const v2747=0.0;
const v2748=0.0;
const v2750=v2698["q"];
const v2751=__nfValue(v2750["b"]);
const v2752=0.0;
const v2753=0.0;
const v2754=0.0;
const v2755=1.0;
const v2756=0.0;
const v2757=0.0;
const v2758=0.0;
const v2759=0.0;
const v2760=0.0;
const v2761=0.0;
const v2762=0.0;
const v2763=0.0;
const v2766=v2698["r"];
const v2767=__nfValue(v2766["a"]);
const v2768=0.0;
const v2769=0.0;
const v2770=0.0;
const v2771=0.0;
const v2772=1.0;
const v2773=0.0;
const v2774=0.0;
const v2775=0.0;
const v2776=0.0;
const v2777=0.0;
const v2778=0.0;
const v2779=0.0;
const v2781=v2698["r"];
const v2782=__nfValue(v2781["b"]);
const v2783=0.0;
const v2784=0.0;
const v2785=0.0;
const v2786=0.0;
const v2787=0.0;
const v2788=1.0;
const v2789=0.0;
const v2790=0.0;
const v2791=0.0;
const v2792=0.0;
const v2793=0.0;
const v2794=0.0;
const v2797=v2698["s"];
const v2798=__nfValue(v2797["a"]);
const v2799=0.0;
const v2800=0.0;
const v2801=0.0;
const v2802=0.0;
const v2803=0.0;
const v2804=0.0;
const v2805=1.0;
const v2806=0.0;
const v2807=0.0;
const v2808=0.0;
const v2809=0.0;
const v2810=0.0;
const v2812=v2698["s"];
const v2813=__nfValue(v2812["b"]);
const v2814=0.0;
const v2815=0.0;
const v2816=0.0;
const v2817=0.0;
const v2818=0.0;
const v2819=0.0;
const v2820=0.0;
const v2821=1.0;
const v2822=0.0;
const v2823=0.0;
const v2824=0.0;
const v2825=0.0;
const v2828=v2698["t"];
const v2829=__nfValue(v2828["a"]);
const v2830=0.0;
const v2831=0.0;
const v2832=0.0;
const v2833=0.0;
const v2834=0.0;
const v2835=0.0;
const v2836=0.0;
const v2837=0.0;
const v2838=1.0;
const v2839=0.0;
const v2840=0.0;
const v2841=0.0;
const v2843=v2698["t"];
const v2844=__nfValue(v2843["b"]);
const v2845=0.0;
const v2846=0.0;
const v2847=0.0;
const v2848=0.0;
const v2849=0.0;
const v2850=0.0;
const v2851=0.0;
const v2852=0.0;
const v2853=0.0;
const v2854=1.0;
const v2855=0.0;
const v2856=0.0;
const v2859=v2698["u"];
const v2860=__nfValue(v2859["a"]);
const v2861=0.0;
const v2862=0.0;
const v2863=0.0;
const v2864=0.0;
const v2865=0.0;
const v2866=0.0;
const v2867=0.0;
const v2868=0.0;
const v2869=0.0;
const v2870=0.0;
const v2871=1.0;
const v2872=0.0;
const v2874=v2698["u"];
const v2875=__nfValue(v2874["b"]);
const v2876=0.0;
const v2877=0.0;
const v2878=0.0;
const v2879=0.0;
const v2880=0.0;
const v2881=0.0;
const v2882=0.0;
const v2883=0.0;
const v2884=0.0;
const v2885=0.0;
const v2886=0.0;
const v2887=1.0;
const v2890=({["p"]:({["a"]:({["value"]:v2705,["tangent_0"]:v2706,["tangent_1"]:v2707,["tangent_2"]:v2708,["tangent_3"]:v2709,["tangent_4"]:v2710,["tangent_5"]:v2711,["tangent_6"]:v2712,["tangent_7"]:v2713,["tangent_8"]:v2714,["tangent_9"]:v2715,["tangent_10"]:v2716,["tangent_11"]:v2717}),["b"]:({["value"]:v2720,["tangent_0"]:v2721,["tangent_1"]:v2722,["tangent_2"]:v2723,["tangent_3"]:v2724,["tangent_4"]:v2725,["tangent_5"]:v2726,["tangent_6"]:v2727,["tangent_7"]:v2728,["tangent_8"]:v2729,["tangent_9"]:v2730,["tangent_10"]:v2731,["tangent_11"]:v2732})}),["q"]:({["a"]:({["value"]:v2736,["tangent_0"]:v2737,["tangent_1"]:v2738,["tangent_2"]:v2739,["tangent_3"]:v2740,["tangent_4"]:v2741,["tangent_5"]:v2742,["tangent_6"]:v2743,["tangent_7"]:v2744,["tangent_8"]:v2745,["tangent_9"]:v2746,["tangent_10"]:v2747,["tangent_11"]:v2748}),["b"]:({["value"]:v2751,["tangent_0"]:v2752,["tangent_1"]:v2753,["tangent_2"]:v2754,["tangent_3"]:v2755,["tangent_4"]:v2756,["tangent_5"]:v2757,["tangent_6"]:v2758,["tangent_7"]:v2759,["tangent_8"]:v2760,["tangent_9"]:v2761,["tangent_10"]:v2762,["tangent_11"]:v2763})}),["r"]:({["a"]:({["value"]:v2767,["tangent_0"]:v2768,["tangent_1"]:v2769,["tangent_2"]:v2770,["tangent_3"]:v2771,["tangent_4"]:v2772,["tangent_5"]:v2773,["tangent_6"]:v2774,["tangent_7"]:v2775,["tangent_8"]:v2776,["tangent_9"]:v2777,["tangent_10"]:v2778,["tangent_11"]:v2779}),["b"]:({["value"]:v2782,["tangent_0"]:v2783,["tangent_1"]:v2784,["tangent_2"]:v2785,["tangent_3"]:v2786,["tangent_4"]:v2787,["tangent_5"]:v2788,["tangent_6"]:v2789,["tangent_7"]:v2790,["tangent_8"]:v2791,["tangent_9"]:v2792,["tangent_10"]:v2793,["tangent_11"]:v2794})}),["s"]:({["a"]:({["value"]:v2798,["tangent_0"]:v2799,["tangent_1"]:v2800,["tangent_2"]:v2801,["tangent_3"]:v2802,["tangent_4"]:v2803,["tangent_5"]:v2804,["tangent_6"]:v2805,["tangent_7"]:v2806,["tangent_8"]:v2807,["tangent_9"]:v2808,["tangent_10"]:v2809,["tangent_11"]:v2810}),["b"]:({["value"]:v2813,["tangent_0"]:v2814,["tangent_1"]:v2815,["tangent_2"]:v2816,["tangent_3"]:v2817,["tangent_4"]:v2818,["tangent_5"]:v2819,["tangent_6"]:v2820,["tangent_7"]:v2821,["tangent_8"]:v2822,["tangent_9"]:v2823,["tangent_10"]:v2824,["tangent_11"]:v2825})}),["t"]:({["a"]:({["value"]:v2829,["tangent_0"]:v2830,["tangent_1"]:v2831,["tangent_2"]:v2832,["tangent_3"]:v2833,["tangent_4"]:v2834,["tangent_5"]:v2835,["tangent_6"]:v2836,["tangent_7"]:v2837,["tangent_8"]:v2838,["tangent_9"]:v2839,["tangent_10"]:v2840,["tangent_11"]:v2841}),["b"]:({["value"]:v2844,["tangent_0"]:v2845,["tangent_1"]:v2846,["tangent_2"]:v2847,["tangent_3"]:v2848,["tangent_4"]:v2849,["tangent_5"]:v2850,["tangent_6"]:v2851,["tangent_7"]:v2852,["tangent_8"]:v2853,["tangent_9"]:v2854,["tangent_10"]:v2855,["tangent_11"]:v2856})}),["u"]:({["a"]:({["value"]:v2860,["tangent_0"]:v2861,["tangent_1"]:v2862,["tangent_2"]:v2863,["tangent_3"]:v2864,["tangent_4"]:v2865,["tangent_5"]:v2866,["tangent_6"]:v2867,["tangent_7"]:v2868,["tangent_8"]:v2869,["tangent_9"]:v2870,["tangent_10"]:v2871,["tangent_11"]:v2872}),["b"]:({["value"]:v2875,["tangent_0"]:v2876,["tangent_1"]:v2877,["tangent_2"]:v2878,["tangent_3"]:v2879,["tangent_4"]:v2880,["tangent_5"]:v2881,["tangent_6"]:v2882,["tangent_7"]:v2883,["tangent_8"]:v2884,["tangent_9"]:v2885,["tangent_10"]:v2886,["tangent_11"]:v2887})})});
const v2922=0.0;
const v2923=0.0;
const v2924=0.0;
const v2925=0.0;
const v2926=0.0;
const v2927=0.0;
const v2928=0.0;
const v2929=0.0;
const v2930=0.0;
const v2931=0.0;
const v2932=0.0;
const v2933=0.0;
const v2934=({["value"]:v2699,["tangent_0"]:v2922,["tangent_1"]:v2923,["tangent_2"]:v2924,["tangent_3"]:v2925,["tangent_4"]:v2926,["tangent_5"]:v2927,["tangent_6"]:v2928,["tangent_7"]:v2929,["tangent_8"]:v2930,["tangent_9"]:v2931,["tangent_10"]:v2932,["tangent_11"]:v2933});
let v2939;if(v2938){if(!v2936){const v2937=__preparedFactories.get(11);v2936=v2937([v2921,v2935],depth+1);}v2939=v2936(v2890,v2934);}else{v2939=__fn11(v2890,v2934);}
v2700=v2939;if(v2703){v2701=v2700;v2702=true;}}
const v2940=v2700;
const v2941=__nfValue(v2940["tangent_0"]);
const v2942=v2700;
const v2943=__nfValue(v2942["tangent_1"]);
const v2945=v2700;
const v2946=__nfValue(v2945["tangent_2"]);
const v2947=v2700;
const v2948=__nfValue(v2947["tangent_3"]);
const v2950=v2700;
const v2951=__nfValue(v2950["tangent_4"]);
const v2952=v2700;
const v2953=__nfValue(v2952["tangent_5"]);
const v2955=v2700;
const v2956=__nfValue(v2955["tangent_6"]);
const v2957=v2700;
const v2958=__nfValue(v2957["tangent_7"]);
const v2960=v2700;
const v2961=__nfValue(v2960["tangent_8"]);
const v2962=v2700;
const v2963=__nfValue(v2962["tangent_9"]);
const v2965=v2700;
const v2966=__nfValue(v2965["tangent_10"]);
const v2967=v2700;
const v2968=__nfValue(v2967["tangent_11"]);
return ({["p"]:({["a"]:v2941,["b"]:v2943}),["q"]:({["a"]:v2946,["b"]:v2948}),["r"]:({["a"]:v2951,["b"]:v2953}),["s"]:({["a"]:v2956,["b"]:v2958}),["t"]:({["a"]:v2961,["b"]:v2963}),["u"]:({["a"]:v2966,["b"]:v2968})});};}
const __preparedFactories=new Map([[2,__prepareFn2],[12,__prepareFn12]]);
