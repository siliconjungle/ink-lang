#[path="../../gpu/f2/native/src/lib.rs"] mod part2;
#[path="../../gpu/f3/native/src/lib.rs"] mod part3;
#[path="../../gpu/f4/native/src/lib.rs"] mod part4;
#[path="../../gpu/f5/native/src/lib.rs"] mod part5;
#[path="../../gpu/f6/native/src/lib.rs"] mod part6;
#[path="../../gpu/f7/native/src/lib.rs"] mod part7;
#[path="../../gpu/f8/native/src/lib.rs"] mod part8;
#[path="../../gpu/f10/native/src/lib.rs"] mod part10;
#[path="../../gpu/f13/native/src/lib.rs"] mod part13;
#[path="../../gpu/f14/native/src/lib.rs"] mod part14;
#[path="../../gpu/f17/native/src/lib.rs"] mod part17;
#[path="../../gpu/f18/native/src/lib.rs"] mod part18;
#[path="../../gpu/f19/native/src/lib.rs"] mod part19;
#[path="../../gpu/f20/native/src/lib.rs"] mod part20;
#[path="../../gpu/f21/native/src/lib.rs"] mod part21;
#[path="../../gpu/f22/native/src/lib.rs"] mod part22;

struct GpuEngines{part2:part2::Engine,part3:part3::Engine,part4:part4::Engine,part5:part5::Engine,part6:part6::Engine,part7:part7::Engine,part8:part8::Engine,part10:part10::Engine,part13:part13::Engine,part14:part14::Engine,part17:part17::Engine,part18:part18::Engine,part19:part19::Engine,part20:part20::Engine,part21:part21::Engine,part22:part22::Engine,}impl GpuEngines{fn new()->Self{Self{part2:part2::Engine::new(),part3:part3::Engine::new(),part4:part4::Engine::new(),part5:part5::Engine::new(),part6:part6::Engine::new(),part7:part7::Engine::new(),part8:part8::Engine::new(),part10:part10::Engine::new(),part13:part13::Engine::new(),part14:part14::Engine::new(),part17:part17::Engine::new(),part18:part18::Engine::new(),part19:part19::Engine::new(),part20:part20::Engine::new(),part21:part21::Engine::new(),part22:part22::Engine::new(),}} fn call(&mut self,name:&str,args:&serde_json::Value,backend:&str,options:Option<&serde_json::Value>)->Result<serde_json::Value,String>{match name{"value"=>{if let Some(options)=options{self.part2.configure_selection(options.clone())?;}self.part2.call(name,args,part2::Backend::parse(backend)?) },
"evaluated"=>{if let Some(options)=options{self.part3.configure_selection(options.clone())?;}self.part3.call(name,args,part3::Backend::parse(backend)?) },
"lazy_total"=>{if let Some(options)=options{self.part4.configure_selection(options.clone())?;}self.part4.call(name,args,part4::Backend::parse(backend)?) },
"readout"=>{if let Some(options)=options{self.part5.configure_selection(options.clone())?;}self.part5.call(name,args,part5::Backend::parse(backend)?) },
"admissible"=>{if let Some(options)=options{self.part6.configure_selection(options.clone())?;}self.part6.call(name,args,part6::Backend::parse(backend)?) },
"valid"=>{if let Some(options)=options{self.part7.configure_selection(options.clone())?;}self.part7.call(name,args,part7::Backend::parse(backend)?) },
"square"=>{if let Some(options)=options{self.part8.configure_selection(options.clone())?;}self.part8.call(name,args,part8::Backend::parse(backend)?) },
"zero"=>{if let Some(options)=options{self.part10.configure_selection(options.clone())?;}self.part10.call(name,args,part10::Backend::parse(backend)?) },
"tape_observation"=>{if let Some(options)=options{self.part13.configure_selection(options.clone())?;}self.part13.call(name,args,part13::Backend::parse(backend)?) },
"mapped"=>{if let Some(options)=options{self.part14.configure_selection(options.clone())?;}self.part14.call(name,args,part14::Backend::parse(backend)?) },
"partitioned"=>{if let Some(options)=options{self.part17.configure_selection(options.clone())?;}self.part17.call(name,args,part17::Backend::parse(backend)?) },
"scanned"=>{if let Some(options)=options{self.part18.configure_selection(options.clone())?;}self.part18.call(name,args,part18::Backend::parse(backend)?) },
"scanned_wide"=>{if let Some(options)=options{self.part19.configure_selection(options.clone())?;}self.part19.call(name,args,part19::Backend::parse(backend)?) },
"selected_wide"=>{if let Some(options)=options{self.part20.configure_selection(options.clone())?;}self.part20.call(name,args,part20::Backend::parse(backend)?) },
"empty_owned"=>{if let Some(options)=options{self.part21.configure_selection(options.clone())?;}self.part21.call(name,args,part21::Backend::parse(backend)?) },
"__ink_reverse_0_constant"=>{if let Some(options)=options{self.part22.configure_selection(options.clone())?;}self.part22.call(name,args,part22::Backend::parse(backend)?) },
_=>Err("CPU-only function".into())}}}
include!("state-cli.rs");
fn run() -> Result<(), String> {
    let mut engines = GpuEngines::new();
    run_with_pure_initialized(compiled_state::initial_state,|state, step| {
        let name = step["pure"].as_str().ok_or("missing pure")?;
        let backend = step["backend"].as_str().unwrap_or("auto");
        if !["auto", "cpu", "gpu", "gpu-required"].contains(&backend) {
            return Err("invalid native backend".into());
        }
        if let Some(options)=step.get("selection") {
            ink_abi::selection::decide(options,&serde_json::json!({}),&["cpu".into()])?;
        }
        if backend == "cpu" {
            state
                .pure(name, &step["args"])
                .map(|v| serde_json::json!({"value":v,"backend":"cpu"}))
        } else {
            engines.call(name, &step["args"], backend, step.get("selection")).or_else(|e| {
                if backend=="gpu-required"{return Err(e);}
                state
                    .pure(name, &step["args"])
                    .map(|v| serde_json::json!({"value":v,"backend":"cpu","reason":e}))
            })
        }
    })
}
fn main() -> std::process::ExitCode {
    match run() {
        Ok(()) => std::process::ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("error: {e}");
            std::process::ExitCode::FAILURE
        }
    }
}
