// Exact wrapping u64 over two storage lanes. No floating point intermediates.
struct InkU64 {lo:u32,hi:u32,}
struct InkDiv64 {quotient:InkU64,remainder:InkU64,}
fn ink_u64_shl(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64(a.lo<<k,(a.hi<<k)|(a.lo>>(32u-k)));}return InkU64(0u,a.lo<<(k-32u));}
fn ink_u64_shr(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64((a.lo>>k)|(a.hi<<(32u-k)),a.hi>>k);}return InkU64(a.hi>>(k-32u),0u);}
fn ink_u64_rol(a:InkU64,count:u32)->InkU64{let k=count&63u;let l=ink_u64_shl(a,k);let r=ink_u64_shr(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_ror(a:InkU64,count:u32)->InkU64{let k=count&63u;let r=ink_u64_shr(a,k);let l=ink_u64_shl(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_eq(a:InkU64,b:InkU64)->bool{return a.lo==b.lo&&a.hi==b.hi;}
fn ink_u64_lt(a:InkU64,b:InkU64)->bool{return a.hi<b.hi||(a.hi==b.hi&&a.lo<b.lo);}
fn ink_u64_add(a:InkU64,b:InkU64)->InkU64{let lo=a.lo+b.lo;return InkU64(lo,a.hi+b.hi+select(0u,1u,lo<a.lo));}
fn ink_u64_sub(a:InkU64,b:InkU64)->InkU64{return InkU64(a.lo-b.lo,a.hi-b.hi-select(0u,1u,a.lo<b.lo));}
fn ink_u64_mul(a:InkU64,b:InkU64)->InkU64{let al=a.lo&65535u;let ah=a.lo>>16u;let bl=b.lo&65535u;let bh=b.lo>>16u;let p=al*bl;let x=ah*bl;let y=al*bh;let mid=(p>>16u)+(x&65535u)+(y&65535u);let high=ah*bh+(x>>16u)+(y>>16u)+(mid>>16u);return InkU64((mid<<16u)|(p&65535u),high+a.lo*b.hi+a.hi*b.lo);}
fn ink_u64_div(a:InkU64,b:InkU64)->InkDiv64{var q=InkU64(0u,0u);var r=InkU64(0u,0u);var cursor=64u;loop{if(cursor==0u){break;}cursor--;var bit=0u;if(cursor>=32u){bit=(a.hi>>(cursor-32u))&1u;}else{bit=(a.lo>>cursor)&1u;}let overflow=r.hi>>31u;r=InkU64((r.lo<<1u)|bit,(r.hi<<1u)|(r.lo>>31u));if(overflow!=0u||!ink_u64_lt(r,b)){r=ink_u64_sub(r,b);if(cursor>=32u){q.hi|=1u<<(cursor-32u);}else{q.lo|=1u<<cursor;}}}return InkDiv64(q,r);}
// Binary32 evaluated with integer lanes: round-to-nearest, ties-to-even,
// gradual underflow, signed zero and canonical arithmetic NaN.
fn ink_f32_nan(x:u32)->bool{return (x&0x7fffffffu)>0x7f800000u;}
fn ink_f32_eq(a:u32,b:u32)->bool{return !ink_f32_nan(a)&&!ink_f32_nan(b)&&(a==b||((a|b)&0x7fffffffu)==0u);}
fn ink_f32_lt(a:u32,b:u32)->bool{
 if(ink_f32_nan(a)||ink_f32_nan(b)||ink_f32_eq(a,b)){return false;}
 if((a^b)&0x80000000u)!=0u{return (a&0x80000000u)!=0u;}
 if((a&0x80000000u)!=0u){return a>b;}return a<b;
}
fn ink_f32_jam(x:u32,n:u32)->u32{if(n==0u){return x;}if(n>=32u){return select(0u,1u,x!=0u);}return (x>>n)|select(0u,1u,(x&((1u<<n)-1u))!=0u);}
fn ink_f32_round(sign:u32,exponent:i32,extended:u32)->u32{
 var e=exponent;var s=extended;
 if(e<1i){s=ink_f32_jam(s,u32(1i-e));e=1i;}
 let tail=s&7u;var sig=s>>3u;
 if(tail>4u||(tail==4u&&(sig&1u)!=0u)){sig++;}
 if(sig>=0x1000000u){sig>>=1u;e++;}
 if(e>=255i){return sign|0x7f800000u;}
 if(sig==0u){return sign;}
 let raw=select(u32(e),0u,e==1i&&sig<0x800000u);
 return sign|(raw<<23u)|(sig&0x7fffffu);
}
fn ink_f32_add(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 var x=a;var y=b;if((x&0x7fffffffu)<(y&0x7fffffffu)){x=b;y=a;}
 let ax=x&0x7fffffffu;let ay=y&0x7fffffffu;let sign=x&0x80000000u;
 if(ax==0x7f800000u){if(ay==ax&&((x^y)&0x80000000u)!=0u){return 0x7fc00000u;}return x;}
 let rx=(x>>23u)&255u;let ry=(y>>23u)&255u;var e=i32(max(rx,1u));
 var sx=((x&0x7fffffu)|select(0u,0x800000u,rx!=0u))<<3u;
 let sy=ink_f32_jam(((y&0x7fffffu)|select(0u,0x800000u,ry!=0u))<<3u,u32(e)-max(ry,1u));
 if(((x^y)&0x80000000u)==0u){sx+=sy;if(sx>=0x8000000u){sx=ink_f32_jam(sx,1u);e++;}}
 else{sx-=sy;if(sx==0u){return 0u;}loop{if(sx>=0x4000000u||e<=1i){break;}sx<<=1u;e--;}}
 return ink_f32_round(sign,e,sx);
}
fn ink_f32_sub(a:u32,b:u32)->u32{return ink_f32_add(a,b^0x80000000u);}
fn ink_f32_mul(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(aa==0x7f800000u||bb==0x7f800000u){if(aa==0u||bb==0u){return 0x7fc00000u;}return sign|0x7f800000u;}
 if(aa==0u||bb==0u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u));var eb=i32(max(rb,1u));
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 let product=ink_u64_mul(InkU64(sa,0u),InkU64(sb,0u));let high=(product.hi&0x8000u)!=0u;
 let shift=select(20u,21u,high);let extended=(product.lo>>shift)|(product.hi<<(32u-shift))|select(0u,1u,(product.lo&((1u<<shift)-1u))!=0u);
 return ink_f32_round(sign,ea+eb-127i+select(0i,1i,high),extended);
}
// Exact sqrt and division use integer significands, independent of WGSL float
// approximation allowances and device flush-to-zero behavior.
fn ink_f32_sqrt(x:u32)->u32{
 let a=x&0x7fffffffu;if(a==0u){return x;}
 if(a>0x7f800000u||(x&0x80000000u)!=0u){return 0x7fc00000u;}
 if(a==0x7f800000u){return x;}
 let raw=(x>>23u)&255u;var m=(x&0x7fffffu)|select(0u,0x800000u,raw!=0u);var e=i32(max(raw,1u))-127i;
 loop{if(m>=0x800000u){break;}m<<=1u;e--;}
 let odd=e&1i;var half=(e-odd)/2i;let shift=23u+u32(odd);
 let n=InkU64(m<<shift,m>>(32u-shift));var lo=0u;var hi=0x1000000u;
 loop{if(lo+1u>=hi){break;}let mid=(lo+hi)>>1u;let sq=ink_u64_mul(InkU64(mid,0u),InkU64(mid,0u));if(!ink_u64_lt(n,sq)){lo=mid;}else{hi=mid;}}
 let sq=ink_u64_mul(InkU64(lo,0u),InkU64(lo,0u));let rem=ink_u64_sub(n,sq);
 if(ink_u64_lt(InkU64(lo,0u),rem)){lo++;}
 if(lo==0x1000000u){lo>>=1u;half++;}
 return (u32(half+127i)<<23u)|(lo&0x7fffffu);
}
fn ink_f32_div(a:u32,b:u32)->u32{
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(ink_f32_nan(a)||ink_f32_nan(b)||(aa==0u&&bb==0u)||(aa==0x7f800000u&&bb==aa)){return 0x7fc00000u;}
 if(aa==0x7f800000u||bb==0u){return sign|0x7f800000u;}
 if(aa==0u||bb==0x7f800000u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u))-127i;var eb=i32(max(rb,1u))-127i;
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 var e=ea-eb;if(sa<sb){sa<<=1u;e--;}
 let division=ink_u64_div(InkU64(sa<<26u,sa>>6u),InkU64(sb,0u));
 let extended=division.quotient.lo|select(0u,1u,!ink_u64_eq(division.remainder,InkU64(0u,0u)));
 return ink_f32_round(sign,e+127i,extended);
}
// mode: 0 trunc, 1 floor, 2 ceil, 3 ties-to-even.
fn ink_f32_integral(x:u32,mode:u32)->u32{
 let a=x&0x7fffffffu;let sign=x&0x80000000u;
 if(a>0x7f800000u){return 0x7fc00000u;}if(a>=0x4b000000u||a==0u){return x;}
 let e=i32((x>>23u)&255u)-127i;
 if(e<0i){var up=false;if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){up=a>0x3f000000u;}return sign|select(0u,0x3f800000u,up);}
 let shift=u32(23i-e);let mask=(1u<<shift)-1u;let fraction=a&mask;var rounded=a&~mask;var up=false;
 if(fraction!=0u){if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){let half=1u<<(shift-1u);up=fraction>half||(fraction==half&&((rounded>>shift)&1u)!=0u);}}
 if(up){rounded+=1u<<shift;}return sign|rounded;
}
fn ink_f32_from_u64(x:InkU64)->u32{
 if(ink_u64_eq(x,InkU64(0u,0u))){return 0u;}
 let leading=select(countLeadingZeros(x.lo)+32u,countLeadingZeros(x.hi),x.hi!=0u);let e=63u-leading;
 if(e<=23u){return ((e+127u)<<23u)|((x.lo<<(23u-e))&0x7fffffu);}
 let shift=e-23u;var sig=0u;var rem=InkU64(0u,0u);var half=InkU64(0u,0u);
 if(shift<32u){sig=(x.lo>>shift)|(x.hi<<(32u-shift));rem=InkU64(x.lo&((1u<<shift)-1u),0u);half=InkU64(1u<<(shift-1u),0u);}
 else if(shift==32u){sig=x.hi;rem=InkU64(x.lo,0u);half=InkU64(0x80000000u,0u);}
 else{sig=x.hi>>(shift-32u);rem=InkU64(x.lo,x.hi&((1u<<(shift-32u))-1u));half=InkU64(0u,1u<<(shift-33u));}
 if(ink_u64_lt(half,rem)||(ink_u64_eq(rem,half)&&(sig&1u)!=0u)){sig++;}
 var exponent=e+127u;if(sig==0x1000000u){sig>>=1u;exponent++;}
 return (exponent<<23u)|(sig&0x7fffffu);
}
fn ink_f32_from_i32(x:i32)->u32{let neg=x<0i;let magnitude=select(u32(x),0u-u32(x),neg);return ink_f32_from_u64(InkU64(magnitude,0u))|select(0u,0x80000000u,neg);}
struct R_Node{ink_f_op:u32,ink_f_a:u32,ink_f_b:u32,ink_f_av:u32,ink_f_bv:u32,ink_f_value:u32,}
struct R_Observation{ink_f_first:R_Node,ink_f_second:R_Node,ink_f_third:R_Node,ink_f_fourth:R_Node,ink_f_adjoints:vec4<u32>,ink_f_steps:u32,ink_f_count:u32,}
struct R_Tape{ink_f_nodes:InkBuffer_R_Node,ink_f_adjoints:InkBuffer_u32,ink_f_steps:u32,}
struct InkBuffer_InkU64{data:array<InkU64,64>,length:u32,}
struct InkBuffer_R_Node{data:array<R_Node,64>,length:u32,}
struct InkBuffer_bool{data:array<bool,64>,length:u32,}
struct InkBuffer_i32{data:array<i32,64>,length:u32,}
struct InkBuffer_u32{data:array<u32,64>,length:u32,}
@group(0) @binding(0) var<storage,read> a0:array<u32>;
@group(0) @binding(1) var<storage,read> a1:array<u32>;
@group(0) @binding(2) var<storage,read_write> output:array<u32>;
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) gid:vec3<u32>){
let size=a0[0];let i=gid.x;if(i==0u){output[0]=size;}if(i<size){
var t0:u32=a0[1u+(i)*1u+0u];
var t1:bool=(a1[0u+(0u)*1u+0u]!=0u);
var t2:u32=t0;
var t3:u32=3u;
var t4:u32=0u;
var t5:u32=1u;
var t6:u32=t2;
var t7:u32=t2;
var t8:u32=t2;
var t9:u32=ink_f32_mul(t8,t2);
var t10:R_Node=R_Node(t3,t4,t5,t6,t7,t9);
var t11:R_Node=t10;
var t12:InkBuffer_R_Node;t12.length=4u;for(var t13=0u;t13<4u;t13++){t12.data[t13]=t11;}
var t14:InkBuffer_R_Node=t12;
var t15:u32=0u;
var t16:InkBuffer_u32;t16.length=4u;for(var t17=0u;t17<4u;t17++){t16.data[t17]=t15;}
var t18:InkBuffer_u32=t16;
var t19:u32=0u;
var t20:R_Tape=R_Tape(t14,t18,t19);
var t21:R_Tape=t20;
var t22:R_Tape=t21;
for(var t23=0u;t23<4u;t23++){
var t24:R_Tape=t22;
var t25:u32=t23;
var t26:bool=t1;
var t27:u32=t25;
var t28:R_Node;if(t27<(t24).ink_f_nodes.length){t28=(t24).ink_f_nodes.data[t27];}else{
var t29:u32=0u;
var t30:u32=0u;
var t31:u32=0u;
var t32:u32=0u;
var t33:u32=0u;
var t34:u32=((0u) ^ 0x80000000u);
t28=R_Node(t29,t30,t31,t32,t33,t34);}
var t35:R_Node=t28;
var t36:u32=t25;
var t37:u32;if(t36<(t24).ink_f_adjoints.length){t37=(t24).ink_f_adjoints.data[t36];}else{
t37=0u;}
var t38:u32=t37;
var t39:u32;
if (t26) {
var t40:u32=(t35).ink_f_av;
t39=((ink_f32_add(t40,(t35).ink_f_bv)) ^ 0x80000000u);
} else {
var t41:u32=(t35).ink_f_av;
t39=ink_f32_add(t41,(t35).ink_f_bv);
}
var t42:u32=t39;
var t43:u32=(t35).ink_f_op;
var t44:u32=(t43 + 1u);
var t45:u32=(t35).ink_f_value;
var t46:u32=ink_f32_add(t45,t38);
var t47:u32=t44;
var t48:u32=(t35).ink_f_a;
var t49:u32=(t35).ink_f_b;
var t50:u32=(t35).ink_f_av;
var t51:u32=(t35).ink_f_bv;
var t52:u32=t46;
var t53:R_Node=R_Node(t47,t48,t49,t50,t51,t52);
var t54:u32=t25;
if(t54<(t24).ink_f_nodes.length){(t24).ink_f_nodes.data[t54]=t53;}
var t55:InkBuffer_R_Node=(t24).ink_f_nodes;
var t56:u32=t25;
var t57:u32=t38;
if(t56<(t24).ink_f_adjoints.length){(t24).ink_f_adjoints.data[t56]=ink_f32_add(t57,t42);}
var t58:InkBuffer_u32=(t24).ink_f_adjoints;
var t59:u32=(t24).ink_f_steps;
var t60:u32=(t59 + 1u);
var t61:R_Tape=R_Tape(t55,t58,t60);
t22=t61;
}
var t62:R_Tape=t22;
var t63:u32=0u;
var t64:R_Node;if(t63<(t62).ink_f_nodes.length){t64=(t62).ink_f_nodes.data[t63];}else{
var t65:u32=0u;
var t66:u32=0u;
var t67:u32=0u;
var t68:u32=0u;
var t69:u32=0u;
var t70:u32=((0u) ^ 0x80000000u);
t64=R_Node(t65,t66,t67,t68,t69,t70);}
var t71:R_Node=t64;
var t72:u32=1u;
var t73:R_Node;if(t72<(t62).ink_f_nodes.length){t73=(t62).ink_f_nodes.data[t72];}else{
var t74:u32=0u;
var t75:u32=0u;
var t76:u32=0u;
var t77:u32=0u;
var t78:u32=0u;
var t79:u32=((0u) ^ 0x80000000u);
t73=R_Node(t74,t75,t76,t77,t78,t79);}
var t80:R_Node=t73;
var t81:u32=2u;
var t82:R_Node;if(t81<(t62).ink_f_nodes.length){t82=(t62).ink_f_nodes.data[t81];}else{
var t83:u32=0u;
var t84:u32=0u;
var t85:u32=0u;
var t86:u32=0u;
var t87:u32=0u;
var t88:u32=((0u) ^ 0x80000000u);
t82=R_Node(t83,t84,t85,t86,t87,t88);}
var t89:R_Node=t82;
var t90:u32=3u;
var t91:R_Node;if(t90<(t62).ink_f_nodes.length){t91=(t62).ink_f_nodes.data[t90];}else{
var t92:u32=0u;
var t93:u32=0u;
var t94:u32=0u;
var t95:u32=0u;
var t96:u32=0u;
var t97:u32=((0u) ^ 0x80000000u);
t91=R_Node(t92,t93,t94,t95,t96,t97);}
var t98:R_Node=t91;
var t99:u32=0u;
var t100:u32;if(t99<(t62).ink_f_adjoints.length){t100=(t62).ink_f_adjoints.data[t99];}else{
t100=0u;}
var t101:u32=t100;
var t102:u32=1u;
var t103:u32;if(t102<(t62).ink_f_adjoints.length){t103=(t62).ink_f_adjoints.data[t102];}else{
t103=0u;}
var t104:u32=t103;
var t105:u32=2u;
var t106:u32;if(t105<(t62).ink_f_adjoints.length){t106=(t62).ink_f_adjoints.data[t105];}else{
t106=0u;}
var t107:u32=t106;
var t108:u32=3u;
var t109:u32;if(t108<(t62).ink_f_adjoints.length){t109=(t62).ink_f_adjoints.data[t108];}else{
t109=0u;}
var t110:u32=t109;
var t111:vec4<u32>=vec4<u32>(t101,t104,t107,t110);
var t112:u32=(t62).ink_f_steps;
var t113:u32=(t62).ink_f_nodes.length;
var t114:R_Observation=R_Observation(t71,t80,t89,t98,t111,t112,t113);
output[1u+i*30u+0u]=((t114).ink_f_first).ink_f_op;
output[1u+i*30u+1u]=((t114).ink_f_first).ink_f_a;
output[1u+i*30u+2u]=((t114).ink_f_first).ink_f_b;
output[1u+i*30u+3u]=bitcast<u32>(((t114).ink_f_first).ink_f_av);
output[1u+i*30u+4u]=bitcast<u32>(((t114).ink_f_first).ink_f_bv);
output[1u+i*30u+5u]=bitcast<u32>(((t114).ink_f_first).ink_f_value);
output[1u+i*30u+6u]=((t114).ink_f_second).ink_f_op;
output[1u+i*30u+7u]=((t114).ink_f_second).ink_f_a;
output[1u+i*30u+8u]=((t114).ink_f_second).ink_f_b;
output[1u+i*30u+9u]=bitcast<u32>(((t114).ink_f_second).ink_f_av);
output[1u+i*30u+10u]=bitcast<u32>(((t114).ink_f_second).ink_f_bv);
output[1u+i*30u+11u]=bitcast<u32>(((t114).ink_f_second).ink_f_value);
output[1u+i*30u+12u]=((t114).ink_f_third).ink_f_op;
output[1u+i*30u+13u]=((t114).ink_f_third).ink_f_a;
output[1u+i*30u+14u]=((t114).ink_f_third).ink_f_b;
output[1u+i*30u+15u]=bitcast<u32>(((t114).ink_f_third).ink_f_av);
output[1u+i*30u+16u]=bitcast<u32>(((t114).ink_f_third).ink_f_bv);
output[1u+i*30u+17u]=bitcast<u32>(((t114).ink_f_third).ink_f_value);
output[1u+i*30u+18u]=((t114).ink_f_fourth).ink_f_op;
output[1u+i*30u+19u]=((t114).ink_f_fourth).ink_f_a;
output[1u+i*30u+20u]=((t114).ink_f_fourth).ink_f_b;
output[1u+i*30u+21u]=bitcast<u32>(((t114).ink_f_fourth).ink_f_av);
output[1u+i*30u+22u]=bitcast<u32>(((t114).ink_f_fourth).ink_f_bv);
output[1u+i*30u+23u]=bitcast<u32>(((t114).ink_f_fourth).ink_f_value);
output[1u+i*30u+24u]=bitcast<u32>(((t114).ink_f_adjoints).x);
output[1u+i*30u+25u]=bitcast<u32>(((t114).ink_f_adjoints).y);
output[1u+i*30u+26u]=bitcast<u32>(((t114).ink_f_adjoints).z);
output[1u+i*30u+27u]=bitcast<u32>(((t114).ink_f_adjoints).w);
output[1u+i*30u+28u]=(t114).ink_f_steps;
output[1u+i*30u+29u]=(t114).ink_f_count;


}
}