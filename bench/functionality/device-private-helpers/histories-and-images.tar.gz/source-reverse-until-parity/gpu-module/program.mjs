const __recordElisions=new Set([]);
const __nativeF32=false;
// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
// Binary64 uses native Numbers for finite arithmetic and immutable private
// tags only where a NaN's exact payload must survive non-arithmetic operations.
const __doubleView=new DataView(new ArrayBuffer(8));
const __double=bits=>{__doubleView.setBigUint64(0,bits,true);return __doubleView.getFloat64(0,true);};
const __doubleBits=number=>{if(Number.isNaN(number))return 0x7ff8000000000000n;__doubleView.setFloat64(0,number,true);return __doubleView.getBigUint64(0,true);};
const __dfNumber=value=>typeof value==='number'?value:__double(BigInt(value.F64Bits));
const __dfBits=value=>typeof value==='number'?__doubleBits(value):BigInt(value.F64Bits);
const __dfFromBits=bits=>(bits&0x7fffffffffffffffn)>0x7ff0000000000000n?Object.freeze({F64Bits:bits.toString()}):__double(bits);
const __dfInput=value=>typeof value==='number'?value:__dfFromBits(BigInt(value.F64Bits));
const __dfNeg=value=>typeof value==='number'&&!Number.isNaN(value)?-value:__dfFromBits(__dfBits(value)^0x8000000000000000n);
const __dfOutput=value=>{const n=__dfNumber(value);return Number.isFinite(n)?n:{F64Bits:__dfBits(value).toString()};};
const __dfCapture=value=>{
 if(typeof value==='number'&&Number.isFinite(value))return value;
 if(!value||typeof value!=='object'||Object.keys(value).length!==1||!Object.hasOwn(value,'F64Bits'))throw Error('invalid f64');const text=value.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid f64');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');return __dfFromBits(bits);
};
// Native binary32 lane for pure modules. Explicit NaN payloads remain tagged;
// arithmetic canonicalizes NaNs just as __bits does in the exact-bit lane.
// Host tags are captured once at a typed read. Only private immutable tags
// may pass through normalization without consulting a host property again.
const __nfTagged = new WeakSet();
const __nfValue = value => typeof value === 'number' ? Math.fround(value) : __nfTagged.has(value) ? value : __nfFromBits(value.F32Bits);
// Number operands have already been normalised at their typed read or producer.
const __nfNumber = value => typeof value === 'number' ? value : __float(value.F32Bits);
const __nfBits = value => typeof value === 'number' ? __bits(value) : value.F32Bits;
const __nfFromBits = bits => {
  if((bits & 0x7fffffff)<=0x7f800000)return __float(bits);
  const value=Object.freeze({F32Bits:bits});__nfTagged.add(value);return value;
};
const __nfNeg = value => typeof value === 'number' && !Number.isNaN(value) ? -value : __nfFromBits((__nfBits(value) ^ 0x80000000) >>> 0);
const __nfOutput = value => {const n=typeof value==='number'?Math.fround(value):__float(value.F32Bits);return Number.isFinite(n)?n:{F32Bits:__nfBits(value)};};
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output, capture=false) {
  const convert=__representationRaw(type,output,capture);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':capture?'capture:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output, capture) {
  switch (type.kind) {
    case 'ref': {
      let resolved;
      return (value,context)=>(resolved??=__representation(__namedTypes[type.name],output,capture))(value,context);
    }
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output,capture);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output,capture),err=__representation(type.error,output,capture);
      const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);
      if(flat)return output?(value,context)=>{const v=__sumView(key,value);return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};}:(v,context)=>Object.hasOwn(v,'Ok')?__sumMake(key,true,ok(v.Ok,context)):__sumMake(key,false,err(v.Err,context));
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f64':return output?__dfOutput:__dfInput;
    case 'f32': if(typeof __nativeF32!=='undefined'&&__nativeF32)return output?__nfOutput:capture?__nfValue:__identity;
      return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output,capture);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){
        if(!type.fields.length)return ()=>undefined; // lexically unconsumed projected input
        const field=type.fields[0],child=__representation(field.type,output,capture);
        return output?(value,context)=>({[field.name]:child(value,context)}):(value,context)=>child(value[field.name],context);
      }
      const fields = type.fields.map(field => [field.name, __representation(field.type, output,capture)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
function __stateWord(value){
 if(typeof value==='number'&&!Number.isSafeInteger(value))throw Error('u64 requires an exact integer');
 if(!['bigint','number','string'].includes(typeof value)||typeof value==='string'&&!/^(0|[1-9][0-9]*)$/.test(value))throw Error('invalid u64');
 const n=BigInt(value);if(n<0n||n>18446744073709551615n)throw Error('invalid u64');return n;
}
// Compile the capture traversal once. Each invocation still validates and owns
// every public container; no host value is retained between calls.
const __stateCaptures=new WeakMap();
function __stateCapture(type){
 const prior=__stateCaptures.get(type);if(prior)return prior;
 const capture=__compileStateCapture(type);__stateCaptures.set(type,capture);return capture;
}
function __compileStateCapture(type){
 const limited=copy=>(value,budget={cells:1000000},depth=0)=>{
  if(depth>64||--budget.cells<0)throw Error('state input resource limit');
  return copy(value,budget,depth);
 };
 const tagged=(value,tag)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
 switch(type.kind){
  case 'ref':{
   // Resolve lazily so recursive schemas compile to recursive validators rather
   // than reverting to descriptor interpretation at every referenced node.
   let resolved;
   return limited((value,budget,depth)=>(resolved??=__stateCapture(__namedTypes[type.name]))(value,budget,depth+1));
  }
  case 'u32':case 'i32':{
   const min=type.kind==='u32'?0:-2147483648,max=type.kind==='u32'?4294967295:2147483647;
   return limited(value=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;});
  }
  case 'u64':return limited(__stateWord);
  case 'f64':return limited(__dfCapture);
  case 'bool':return limited(value=>{if(typeof value!=='boolean')throw Error('invalid Bool');return value;});
  case 'unit':return limited(value=>{if(value!==null)throw Error('invalid Unit');return null;});
  case 'string':return limited(value=>{if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;});
  case 'enum':return limited(value=>{if(!type.variants.includes(value))throw Error('invalid enum');return value;});
  case 'id':return limited(value=>{if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();});
  case 'list':case 'vector':{
   const item=__stateCapture(type.element),size=type.kind==='vector'?type.size:null;
   return limited((value,budget,depth)=>{
    if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
    if(size!==null&&value.length!==size)throw Error('invalid vector length');
    const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=item(value[i],budget,depth+1);return out;
   });
  }
  case 'record':{
   const fields=type.fields.map(f=>[f.name,__stateCapture(f.type)]);
   if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name)))return limited((value,budget,depth)=>{const [name,copy]=fields[0];if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,name))throw Error('invalid record');return copy(value[name],budget,depth+1);});
   return limited((value,budget,depth)=>{
    if(!value||typeof value!=='object'||Array.isArray(value)||!fields.every(([name])=>Object.hasOwn(value,name)))throw Error('invalid record');
    const out={};for(const [name,copy]of fields){const field=copy(value[name],budget,depth+1);if(name==='__proto__')Object.defineProperty(out,name,{value:field,writable:true,enumerable:true,configurable:true});else out[name]=field;}return out;
   });
  }
  case 'option':{
   const item=__stateCapture(type.element);
   return limited((value,budget,depth)=>{if(tagged(value,'Some'))return {Some:item(value.Some,budget,depth+1)};if(tagged(value,'None')&&value.None===null)return {None:null};throw Error('invalid Option');});
  }
  case 'result':{
   const ok=__stateCapture(type.ok),err=__stateCapture(type.error);
   return limited((value,budget,depth)=>{if(tagged(value,'Ok'))return {Ok:ok(value.Ok,budget,depth+1)};if(tagged(value,'Err'))return {Err:err(value.Err,budget,depth+1)};throw Error('invalid Result');});
  }
  default:return (value,budget,depth)=>__stateInput(value,type,budget,depth);
 }
}
function __stateInput(value,type,budget={cells:1000000},depth=0,maxDepth=64){
  if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');
  const input=(v,t)=>__stateInput(v,t,budget,depth+1,maxDepth);
  const integer=(min,max)=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;};
  const tagged=tag=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
  switch(type.kind){
    case 'ref':return input(value,__namedTypes[type.name]);
    case 'u32':return integer(0,4294967295);
    case 'i32':return integer(-2147483648,2147483647);
    case 'u64':return __stateWord(value);
    case 'int':{
      if(typeof value==='bigint')return value;
      if(!tagged('Int')||typeof value.Int!=='string'||!/^(-?[0-9]+)$/.test(value.Int))throw Error('invalid Int');return BigInt(value.Int);
    }
    case 'f64':return __dfCapture(value);
    case 'f32':{
      if(typeof value==='number'&&Number.isFinite(value)){const bits=__bits(value);if((bits&0x7fffffff)===0x7f800000)throw Error('f32 overflow requires F32Bits');return bits;}
      if(!tagged('F32Bits')||!Number.isInteger(value.F32Bits)||value.F32Bits<0||value.F32Bits>4294967295)throw Error('invalid f32');return value.F32Bits;
    }
    case 'bool':if(typeof value!=='boolean')throw Error('invalid Bool');return value;
    case 'unit':if(value!==null)throw Error('invalid Unit');return null;
    case 'string':if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;
    case 'id':if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();
    case 'enum':if(!type.variants.includes(value))throw Error('invalid enum');return value;
    case 'list':case 'vector':{
      if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
      if(type.kind==='vector'&&value.length!==type.size)throw Error('invalid vector length');
      return Array.from(value,v=>input(v,type.element));
    }
    case 'record':if(!value||typeof value!=='object'||Array.isArray(value)||!type.fields.every(f=>Object.hasOwn(value,f.name)))throw Error('invalid record');if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){const f=type.fields[0];return input(value[f.name],f.type);}return Object.fromEntries(type.fields.map(f=>[f.name,input(value[f.name],f.type)]));
    case 'option':if(tagged('Some'))return {Some:input(value.Some,type.element)};if(tagged('None')&&value.None===null)return {None:null};throw Error('invalid Option');
    case 'result':{const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);if(tagged('Ok')){const child=input(value.Ok,type.ok);return flat?__sumMake(key,true,child):{Ok:child};}if(tagged('Err')){const child=input(value.Err,type.error);return flat?__sumMake(key,false,child):{Err:child};}throw Error('invalid Result');}
    default:throw Error('unsupported public value type');
  }
}
// Mutable host replies must not retain references into compiled state or its outbox.
// State results must own mutable containers. Compile the declared schema once:
// scalars need no structured clone, while nested records/lists remain detached.
function __ownershipSchema(type){
 // Nominal references and expanded declarations name the same checked sort.
 // Distinct source records retain distinct keys even if a layout erases them.
 if(type.kind==='ref'||type.kind==='record'&&type.name)return ['named',type.name];
 switch(type.kind){
  case 'list':case 'vector':return [type.kind,type.size??null,__ownershipSchema(type.element)];
  case 'option':return ['option',__ownershipSchema(type.element)];
  case 'result':return ['result',__ownershipSchema(type.ok),__ownershipSchema(type.error)];
  case 'record':return ['record',type.fields.map(f=>[f.name,__ownershipSchema(f.type)])];
  default:return type;
 }
}
function __ownedResult(copy,nested,type){
 const key='owned-state:'+JSON.stringify(__ownershipSchema(type));
 let schema=__conversionKeys.get(key);
 if(!schema){schema={};__conversionKeys.set(key,schema);}
 const owned=(value,context)=>{
  if(!context&&!nested)return copy(value,null);
  const memo=context||new WeakMap();
  if(value===null||typeof value!=='object')return copy(value,memo);
  let entries=memo.get(schema);if(!entries){entries=new WeakMap();memo.set(schema,entries);}
  if(entries.has(value))return entries.get(value);
  const result=copy(value,memo);entries.set(value,result);return result;
 };
 owned.container=true;return owned;
}
function __stateResult(type){
 switch(type.kind){
  case 'ref':{let resolved;const copy=(value,context)=>(resolved??=__stateResult(__namedTypes[type.name]))(value,context);copy.container=true;return copy;}
  case 'record':{if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){const f=type.fields[0],copy=__stateResult(f.type);return __ownedResult((value,context)=>({[f.name]:copy(value,context)}),copy.container,type);}const fields=type.fields.map(f=>[f.name,__stateResult(f.type)]);return __ownedResult((value,context)=>Object.fromEntries(fields.map(([name,copy])=>[name,copy(value[name],context)])),fields.some(([,copy])=>copy.container),type);}
  case 'list':case 'vector':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Array.from(value,item=>copy(item,context)),copy.container,type);}
  case 'option':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Object.hasOwn(value,'Some')?{Some:copy(value.Some,context)}:{None:null},copy.container,type);}
  case 'result':{const ok=__stateResult(type.ok),err=__stateResult(type.error),key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);return __ownedResult((value,context)=>{const v=flat?__sumView(key,value):value;return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};},ok.container||err.container,type);}
  default:return __representation(type,true);
 }
}
function __stateOutput(value,type){return __stateResult(type)(value);}
const __u64 = n => BigInt.asUintN(64, n);
function __div(a, b, fallback, signed, remainder) {
  if (b === 0 || b === 0n || (signed && a === -2147483648 && b === -1)) return fallback();
  return typeof a === 'bigint' ? (remainder ? a % b : a / b) :
    ((remainder ? a % b : Math.trunc(a / b)) + 0); // integer zero has no sign
}
function __at(xs, index, fallback) { return index < xs.length ? xs[index] : fallback(); }
// Ordinary arrays retain the declared result element type when input is typed.
function __map(xs, fn) {
  const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = fn(xs[i], i);
  return out;
}
function __filter(xs, fn) {
  const out = [];
  for (let i = 0; i < xs.length; i++) if (fn(xs[i])) out.push(xs[i]);
  return out;
}
function __concat(xs, ys) {
  const left = xs.length, right = ys.length, out = new Array(left + right);
  for (let i = 0; i < left; i++) out[i] = xs[i];
  for (let i = 0; i < right; i++) out[left + i] = ys[i];
  return out;
}
function __zip(xs, ys, fn) {
  const n = Math.min(xs.length, ys.length), out = new Array(n);
  for (let i = 0; i < n; i++) out[i] = fn(xs[i], ys[i]);
  return out;
}
function __repeat(n, initial, fn) { let value = initial; for (let i = 0; i < n; i++) value = fn(i, value); return value; }
function __foldr(xs, initial, fn) { let value = initial; for (let i = xs.length - 1; i >= 0; i--) value = fn(xs[i], value); return value; }
function __scan(xs, zero, add) {
  let value = zero; const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = value = add(value, xs[i]);
  return out;
}
const __sort = xs => Array.from(xs).sort((a,b) => a < b ? -1 : a > b ? 1 : 0);

function __wordSort(xs,Storage){
 const sorted=Storage.from(xs).sort(),out=new Array(sorted.length);
 for(let i=0;i<sorted.length;i++)out[i]=sorted[i];
 return out;
}
// Affine buffers expose bounded disjoint ranges over one allocation. Source
// ownership prevents retaining a parent; growth detaches shared ranges.
// Elements cannot own temporary storage: they are immutable logical values.
// Copy the slot array when acquiring ownership, never the reachable records.
class __InkBuffer {
 constructor(data,start=0,end=data.length,shared=false){this.data=data;this.start=start;this.end=end;this.shared=shared;}
 get length(){return this.end-this.start;}
 set length(n){this.end=this.start+Math.min(this.length,n);if(!this.shared&&this.start===0)this.data.length=this.end;}
 item(i){return this.data[this.start+i];}
 range(start,count){const begin=this.start+Math.min(start,this.length);return new __InkBuffer(this.data,begin,begin+Math.min(count,this.end-begin),true);}
 set(i,v){if(i<this.length)this.data[this.start+i]=v;return this;}
 swap(a,b){if(a<this.length&&b<this.length){const x=this.item(a);this.set(a,this.item(b));this.set(b,x);}return this;}
 fill_range(start,count,value){start=Math.min(start,this.length);count=Math.min(count,this.length-start);this.data.fill(value,this.start+start,this.start+start+count);return this;}
 copy_within(source,destination,count){source=Math.min(source,this.length);destination=Math.min(destination,this.length);count=Math.min(count,this.length-source,this.length-destination);this.data.copyWithin(this.start+destination,this.start+source,this.start+source+count);return this;}
 detach(){if(this.shared||this.start!==0||this.end!==this.data.length){this.data=this.data.slice(this.start,this.end);this.start=0;this.end=this.data.length;this.shared=false;}}
 push(v){if(this.length>=4294967295)throw Error('buffer length exhausted');this.detach();this.data.push(v);this.end++;return this;}
 pop(){this.length=Math.max(0,this.length-1);return this;}
 truncate(n){this.length=Math.min(this.length,n);return this;}
 slice(start=0,end=this.length){return this.data.slice(this.start+start,this.start+Math.min(end,this.length));}
 freeze(){return this.start===0&&this.end===this.data.length?this.data:this.data.slice(this.start,this.end);}
 *[Symbol.iterator](){for(let i=this.start;i<this.end;i++)yield this.data[i];}
}
function __bufferSplit(x,at){const cut=x.start+Math.min(at,x.length);x.shared=true;return [new __InkBuffer(x.data,x.start,cut,true),new __InkBuffer(x.data,cut,x.end,true)];}
function __bufferAppend(a,b){
 if(a.length+b.length>4294967295)throw Error('buffer length exhausted');
 if(a.data===b.data&&a.end===b.start)return new __InkBuffer(a.data,a.start,b.end,a.start!==0||b.end!==a.data.length);
 a.detach();for(const item of b)a.push(item);return a;
}

function __repeat_until(limit,acc,stop,step){for(let i=0;i<limit;i++){if(stop(acc))break;acc=step(i,acc);}return acc;}
function __bufferFill(n,v){return new __InkBuffer(new Array(n).fill(v));}
function __mapGet(m,k,f){return m.has(k)?m.get(k):f();}
function __mapEntries(m,keys){return [...m.entries()].sort(([a],[b])=>a<b?-1:a>b?1:0).map(([k,v])=>keys?k:v);}
function __tempSet(x,k,v,map){x.set(k,v);return x;}
function __bufferSwap(x,a,b){return x.swap(a,b);}
function __tempEdit(x,op,...args){if(op==='push'){x.push(args[0]);}else if(op==='pop')x.pop();else if(op==='truncate')x.truncate(args[0]);else if(op==='remove')x.delete(args[0]);return x;}
// Fixed word semantics, including arithmetic signed right shift. Shift and
// rotation counts wrap modulo width; no source-pattern optimisation lives here.
function __word(op,a,b,bits) {
  const width=BigInt(Math.abs(bits)), k=BigInt(b??0)%width;
  const x=BigInt(a), y=BigInt(b??0), unsigned=BigInt.asUintN(Number(width),x);
  let r;
  switch(op) {
    case 'word_widen_u32_to_u64':case 'word_narrow_u64_to_u32':r=x;break;
    case 'word_not':r=~x;break;
    case 'word_and':r=x&y;break;
    case 'word_or':r=x|y;break;
    case 'word_xor':r=x^y;break;
    case 'wrapping_shl':r=x<<k;break;
    case 'wrapping_shr':r=x>>k;break;
    case 'rotate_left':r=(unsigned<<k)|(unsigned>>(width-k));break;
    case 'rotate_right':r=(unsigned>>k)|(unsigned<<(width-k));break;
    default:throw new Error('unknown word operation');
  }
  r=bits<0?BigInt.asIntN(Number(width),r):BigInt.asUintN(Number(width),r);
  return bits===64?r:Number(r);
}
// Rotations evaluate each operand once. Counts wrap modulo the width.
function __rotl32(a,k){k&=31;return (a<<k)|(a>>>((32-k)&31));}
function __rotr32(a,k){k&=31;return (a>>>k)|(a<<((32-k)&31));}
function __rotl64(a,k){const n=BigInt(k&63);return BigInt.asUintN(64,(a<<n)|(a>>((64n-n)&63n)));}
function __rotr64(a,k){const n=BigInt(k&63);return BigInt.asUintN(64,(a>>n)|(a<<((64n-n)&63n)));}
function __fn0(v0){
const v1=v0["value"];
const v2=1073741824;
const v3=Math.fround(__float(v1) * __float(v2));
const v4=1065353216;
return __bits(v3 + __float(v4));}
function __fn1(v5){
const v6=10;
let v7=v5;
for(let v8=0;v8<v6;v8++){
const v9=v7;
const v10=1090519040;
if(((__float(v9)) >= (__float(v10)))){break;}
const v11=(v8>>>0);
const v12=v7;
const v13=1073741824;
v7=__bits(__float(v12) * __float(v13));}
return v7;}
function __fn2(v14){
const v15=1n;
const v16=2n;
const v17=3n;
const v18=4n;
const v19=[v15,v16,v17,v18];
let v20=v14;
for(let v21=0;v21<v19.length;v21++){
const v22=v19[v21];
const v23=v20;
const v24=1082130432;
const v25=((__float(v23)) >= (__float(v24)));
const v26=v20;
const v27=1073741824;
v20=__bits(__float(v26) * __float(v27));
if(v25)break;
}
return v20;}
function __fn3(v28){
const v29=128;
const v30=true;
const v31=__fn18(v28,v29,v30);
let v32;if(Object.hasOwn(v31,"Ok")){
const v33=v31["Ok"];
v32=v33["value"];}else{
const v34=v31["Err"];
const v35=1065353216;
v32=((v35 ^ 2147483648) >>> 0);}
return v32;}
function __fn4(v36){
const v37=128;
const v38=true;
const v39=__fn18(v36,v37,v38);
let v40;if(Object.hasOwn(v39,"Ok")){
const v41=v39["Ok"];
v40=v41["gradient"];}else{
const v42=v39["Err"];
const v43=1065353216;
v40=((v43 ^ 2147483648) >>> 0);}
return v40;}
function __fn5(v44){
const v45=128;
const v46=true;
const v47=__fn20(v44,v45,v46);
let v48;if(Object.hasOwn(v47,"Ok")){
const v49=v47["Ok"];
v48=v49["value"];}else{
const v50=v47["Err"];
const v51=1065353216;
v48=((v51 ^ 2147483648) >>> 0);}
return v48;}
function __fn6(v52){
const v53=128;
const v54=true;
const v55=__fn20(v52,v53,v54);
let v56;if(Object.hasOwn(v55,"Ok")){
const v57=v55["Ok"];
v56=v57["gradient"];}else{
const v58=v55["Err"];
const v59=1065353216;
v56=((v59 ^ 2147483648) >>> 0);}
return v56;}
function __fn7(v60){
const v61=v60.length;
const v62=new Array(v61);
for(let v63=0;v63<v61;v63++){
const v64=v60[v63];
const v66=1073741824;
const v67=Math.fround(__float(v64) * __float(v66));
const v68=1065353216;
v62[v63]=__bits(v67 + __float(v68));
}
return v62;}
function __fn8(v69){
const v70=4294967295;
return ({["value"]:v69,["id"]:v70});}
function __fn9(v71,v72,v73){
const v74=false;
const v75=(v73===v74);
let v76=v75;if(!v76){
v76=v71["failed"];}
let v77;if(v76){
const v78=v72["value"];
const v79=__fn8(v78);
v77=({["value"]:v79,["tape"]:v71});}else{
const v80=v71["nodes"];
const v81=(v80).length;
const v82=v71["maximum"];
let v83;if(((v81) >= (v82))){
const v84=v72["value"];
const v85=__fn8(v84);
const v86=true;
const v87=v71["nodes"];
const v88=v71["maximum"];
const v89=({["nodes"]:v87,["maximum"]:v88,["failed"]:v86});
v83=({["value"]:v85,["tape"]:v89});}else{
const v90=v72["value"];
const v91=({["value"]:v90,["id"]:v81});
const v92=v71["nodes"];
const v93=__tempEdit(v92,"push",v72);
const v94=v71["maximum"];
const v95=v71["failed"];
const v96=({["nodes"]:v93,["maximum"]:v94,["failed"]:v95});
v83=({["value"]:v91,["tape"]:v96});}
v77=v83;}
return v77;}
function __fn10(v97,v98){
const v99=0;
const v100=4294967295;
const v101=4294967295;
const v102=0;
const v103=0;
const v105=true;
const v106=false;
const v107=(v105===v106);
let v108=v107;if(!v108){
v108=v98["failed"];}
let v109;
let v110;
if(v108){
const v111=__fn8(v97);
v109=v111;
v110=v98;
}else{
const v112=v98["nodes"];
const v113=(v112).length;
const v114=v98["maximum"];
let v115;
let v116;
if(((v113) >= (v114))){
const v117=__fn8(v97);
const v118=true;
const v119=v98["nodes"];
const v120=v98["maximum"];
const v121=({["nodes"]:v119,["maximum"]:v120,["failed"]:v118});
v115=v117;
v116=v121;
}else{
const v122=({["value"]:v97,["id"]:v113});
const v123=v98["nodes"];
const v124=({["op"]:v99,["a"]:v100,["b"]:v101,["av"]:v102,["bv"]:v103,["value"]:v97});
const v125=__tempEdit(v123,"push",v124);
const v126=v98["maximum"];
const v127=v98["failed"];
const v128=({["nodes"]:v125,["maximum"]:v126,["failed"]:v127});
v115=v122;
v116=v128;
}
v109=v115;
v110=v116;
}
return ({["value"]:v109,["tape"]:v110});}
function __fn11(v129,v130,v131,v132){
const v133=1;
let v134;if((v129===v133)){
const v135=v131["value"];
const v136=v132["value"];
v134=__bits(__float(v135) + __float(v136));}else{
const v137=2;
let v138;if((v129===v137)){
const v139=v131["value"];
const v140=v132["value"];
v138=__bits(__float(v139) - __float(v140));}else{
const v141=3;
let v142;if((v129===v141)){
const v143=v131["value"];
const v144=v132["value"];
v142=__bits(__float(v143) * __float(v144));}else{
v142=__bits((__float(v131["value"]))/(__float(v132["value"])));}
v138=v142;}
v134=v138;}
const v145=v134;
const v146=v131["id"];
const v147=v132["id"];
const v148=v131["value"];
const v149=v132["value"];
const v151=v131["id"];
const v152=4294967295;
const v153=!(v151===v152);
let v154=v153;if(!v154){
const v155=v132["id"];
const v156=4294967295;
v154=!(v155===v156);}
const v157=v154;
const v158=false;
const v159=(v157===v158);
let v160=v159;if(!v160){
v160=v130["failed"];}
let v161;
let v162;
if(v160){
const v163=__fn8(v145);
v161=v163;
v162=v130;
}else{
const v164=v130["nodes"];
const v165=(v164).length;
const v166=v130["maximum"];
let v167;
let v168;
if(((v165) >= (v166))){
const v169=__fn8(v145);
const v170=true;
const v171=v130["nodes"];
const v172=v130["maximum"];
const v173=({["nodes"]:v171,["maximum"]:v172,["failed"]:v170});
v167=v169;
v168=v173;
}else{
const v174=({["value"]:v145,["id"]:v165});
const v175=v130["nodes"];
const v176=({["op"]:v129,["a"]:v146,["b"]:v147,["av"]:v148,["bv"]:v149,["value"]:v145});
const v177=__tempEdit(v175,"push",v176);
const v178=v130["maximum"];
const v179=v130["failed"];
const v180=({["nodes"]:v177,["maximum"]:v178,["failed"]:v179});
v167=v174;
v168=v180;
}
v161=v167;
v162=v168;
}
return ({["value"]:v161,["tape"]:v162});}
function __fn12(v181,v182,v183){
const v184=5;
let v185;if((v181===v184)){
const v186=v183["value"];
v185=((v186 ^ 2147483648) >>> 0);}else{
v185=__bits(Math.sqrt(__float(v183["value"])));}
const v187=v185;
const v188=v183["id"];
const v189=4294967295;
const v190=v183["value"];
const v191=0;
const v193=v183["id"];
const v194=4294967295;
const v195=!(v193===v194);
const v196=false;
const v197=(v195===v196);
let v198=v197;if(!v198){
v198=v182["failed"];}
let v199;
let v200;
if(v198){
const v201=__fn8(v187);
v199=v201;
v200=v182;
}else{
const v202=v182["nodes"];
const v203=(v202).length;
const v204=v182["maximum"];
let v205;
let v206;
if(((v203) >= (v204))){
const v207=__fn8(v187);
const v208=true;
const v209=v182["nodes"];
const v210=v182["maximum"];
const v211=({["nodes"]:v209,["maximum"]:v210,["failed"]:v208});
v205=v207;
v206=v211;
}else{
const v212=({["value"]:v187,["id"]:v203});
const v213=v182["nodes"];
const v214=({["op"]:v181,["a"]:v188,["b"]:v189,["av"]:v190,["bv"]:v191,["value"]:v187});
const v215=__tempEdit(v213,"push",v214);
const v216=v182["maximum"];
const v217=v182["failed"];
const v218=({["nodes"]:v215,["maximum"]:v216,["failed"]:v217});
v205=v212;
v206=v218;
}
v199=v205;
v200=v206;
}
return ({["value"]:v199,["tape"]:v200});}
function __fn13(v219,v220,v221){
const v222=4294967295;
let v223;if((v220===v222)){
v223=v219;}else{
let v224;if(v220<v219.length){v224=v219.item(v220);}else{
v224=0;}
const v225=v224;
v223=__tempSet(v219,v220,__bits(__float(v225) + __float(v221)),false);}
return v223;}
function __fn14(v226,v227,v228){
const v229=v226["op"];
const v230=1;
let v231;if((v229===v230)){
const v232=v226["a"];
const v233=4294967295;
let v234;if((v232===v233)){
v234=v228;}else{
let v235;if(v232<v228.length){v235=v228.item(v232);}else{
v235=0;}
const v236=v235;
v234=__tempSet(v228,v232,__bits(__float(v236) + __float(v227)),false);}
const v237=v234;
const v238=v226["b"];
const v239=4294967295;
let v240;if((v238===v239)){
v240=v237;}else{
let v241;if(v238<v237.length){v241=v237.item(v238);}else{
v241=0;}
const v242=v241;
v240=__tempSet(v237,v238,__bits(__float(v242) + __float(v227)),false);}
v231=v240;}else{
const v243=v226["op"];
const v244=2;
let v245;if((v243===v244)){
const v246=v226["a"];
const v247=4294967295;
let v248;if((v246===v247)){
v248=v228;}else{
let v249;if(v246<v228.length){v249=v228.item(v246);}else{
v249=0;}
const v250=v249;
v248=__tempSet(v228,v246,__bits(__float(v250) + __float(v227)),false);}
const v251=v248;
const v252=v226["b"];
const v253=((v227 ^ 2147483648) >>> 0);
const v254=4294967295;
let v255;if((v252===v254)){
v255=v251;}else{
let v256;if(v252<v251.length){v256=v251.item(v252);}else{
v256=0;}
const v257=v256;
v255=__tempSet(v251,v252,__bits(__float(v257) + __float(v253)),false);}
v245=v255;}else{
const v258=v226["op"];
const v259=3;
let v260;if((v258===v259)){
const v261=v226["a"];
const v262=v226["bv"];
const v263=__bits(__float(v227) * __float(v262));
const v264=4294967295;
let v265;if((v261===v264)){
v265=v228;}else{
let v266;if(v261<v228.length){v266=v228.item(v261);}else{
v266=0;}
const v267=v266;
v265=__tempSet(v228,v261,__bits(__float(v267) + __float(v263)),false);}
const v268=v265;
const v269=v226["b"];
const v270=v226["av"];
const v271=__bits(__float(v227) * __float(v270));
const v272=4294967295;
let v273;if((v269===v272)){
v273=v268;}else{
let v274;if(v269<v268.length){v274=v268.item(v269);}else{
v274=0;}
const v275=v274;
v273=__tempSet(v268,v269,__bits(__float(v275) + __float(v271)),false);}
v260=v273;}else{
const v276=v226["op"];
const v277=4;
let v278;if((v276===v277)){
const v279=v226["a"];
const v280=__bits((__float(v227))/(__float(v226["bv"])));
const v281=4294967295;
let v282;if((v279===v281)){
v282=v228;}else{
let v283;if(v279<v228.length){v283=v228.item(v279);}else{
v283=0;}
const v284=v283;
v282=__tempSet(v228,v279,__bits(__float(v284) + __float(v280)),false);}
const v285=v282;
const v286=v226["b"];
const v287=v226["av"];
const v288=v226["bv"];
const v289=v226["bv"];
const v290=__bits((__float(__bits(__float(v227) * __float(v287))))/(__float(__bits(__float(v288) * __float(v289)))));
const v291=((v290 ^ 2147483648) >>> 0);
const v292=4294967295;
let v293;if((v286===v292)){
v293=v285;}else{
let v294;if(v286<v285.length){v294=v285.item(v286);}else{
v294=0;}
const v295=v294;
v293=__tempSet(v285,v286,__bits(__float(v295) + __float(v291)),false);}
v278=v293;}else{
const v296=v226["op"];
const v297=5;
let v298;if((v296===v297)){
const v299=v226["a"];
const v300=((v227 ^ 2147483648) >>> 0);
const v301=4294967295;
let v302;if((v299===v301)){
v302=v228;}else{
let v303;if(v299<v228.length){v303=v228.item(v299);}else{
v303=0;}
const v304=v303;
v302=__tempSet(v228,v299,__bits(__float(v304) + __float(v300)),false);}
v298=v302;}else{
const v305=v226["op"];
const v306=6;
let v307;if((v305===v306)){
const v308=v226["a"];
const v309=1073741824;
const v310=v226["value"];
const v311=__bits((__float(v227))/(__float(__bits(__float(v309) * __float(v310)))));
const v312=4294967295;
let v313;if((v308===v312)){
v313=v228;}else{
let v314;if(v308<v228.length){v314=v228.item(v308);}else{
v314=0;}
const v315=v314;
v313=__tempSet(v228,v308,__bits(__float(v315) + __float(v311)),false);}
v307=v313;}else{
v307=v228;}
v298=v307;}
v278=v298;}
v260=v278;}
v245=v260;}
v231=v245;}
return v231;}
function __fn15(v316,v317,v318){
const v319=v317["index"];
const v320=1;
const v321=(((v319) - (v320)) >>> 0);
const v322=v317["gradient"];
let v323;if(v321<v322.length){v323=v322.item(v321);}else{
v323=0;}
const v324=v323;
let v325=v318;if(v325){
const v326=0;
v325=((__float(v324)) === (__float(v326)));}
let v327;if(v325){
v327=v317["gradient"];}else{
const v328=v317["gradient"];
const v329=v316["op"];
const v330=1;
let v331;if((v329===v330)){
const v332=v316["a"];
const v333=4294967295;
let v334;if((v332===v333)){
v334=v328;}else{
let v335;if(v332<v328.length){v335=v328.item(v332);}else{
v335=0;}
const v336=v335;
v334=__tempSet(v328,v332,__bits(__float(v336) + __float(v324)),false);}
const v337=v334;
const v338=v316["b"];
const v339=4294967295;
let v340;if((v338===v339)){
v340=v337;}else{
let v341;if(v338<v337.length){v341=v337.item(v338);}else{
v341=0;}
const v342=v341;
v340=__tempSet(v337,v338,__bits(__float(v342) + __float(v324)),false);}
v331=v340;}else{
const v343=v316["op"];
const v344=2;
let v345;if((v343===v344)){
const v346=v316["a"];
const v347=4294967295;
let v348;if((v346===v347)){
v348=v328;}else{
let v349;if(v346<v328.length){v349=v328.item(v346);}else{
v349=0;}
const v350=v349;
v348=__tempSet(v328,v346,__bits(__float(v350) + __float(v324)),false);}
const v351=v348;
const v352=v316["b"];
const v353=((v324 ^ 2147483648) >>> 0);
const v354=4294967295;
let v355;if((v352===v354)){
v355=v351;}else{
let v356;if(v352<v351.length){v356=v351.item(v352);}else{
v356=0;}
const v357=v356;
v355=__tempSet(v351,v352,__bits(__float(v357) + __float(v353)),false);}
v345=v355;}else{
const v358=v316["op"];
const v359=3;
let v360;if((v358===v359)){
const v361=v316["a"];
const v362=v316["bv"];
const v363=__bits(__float(v324) * __float(v362));
const v364=4294967295;
let v365;if((v361===v364)){
v365=v328;}else{
let v366;if(v361<v328.length){v366=v328.item(v361);}else{
v366=0;}
const v367=v366;
v365=__tempSet(v328,v361,__bits(__float(v367) + __float(v363)),false);}
const v368=v365;
const v369=v316["b"];
const v370=v316["av"];
const v371=__bits(__float(v324) * __float(v370));
const v372=4294967295;
let v373;if((v369===v372)){
v373=v368;}else{
let v374;if(v369<v368.length){v374=v368.item(v369);}else{
v374=0;}
const v375=v374;
v373=__tempSet(v368,v369,__bits(__float(v375) + __float(v371)),false);}
v360=v373;}else{
const v376=v316["op"];
const v377=4;
let v378;if((v376===v377)){
const v379=v316["a"];
const v380=__bits((__float(v324))/(__float(v316["bv"])));
const v381=4294967295;
let v382;if((v379===v381)){
v382=v328;}else{
let v383;if(v379<v328.length){v383=v328.item(v379);}else{
v383=0;}
const v384=v383;
v382=__tempSet(v328,v379,__bits(__float(v384) + __float(v380)),false);}
const v385=v382;
const v386=v316["b"];
const v387=v316["av"];
const v388=v316["bv"];
const v389=v316["bv"];
const v390=__bits((__float(__bits(__float(v324) * __float(v387))))/(__float(__bits(__float(v388) * __float(v389)))));
const v391=((v390 ^ 2147483648) >>> 0);
const v392=4294967295;
let v393;if((v386===v392)){
v393=v385;}else{
let v394;if(v386<v385.length){v394=v385.item(v386);}else{
v394=0;}
const v395=v394;
v393=__tempSet(v385,v386,__bits(__float(v395) + __float(v391)),false);}
v378=v393;}else{
const v396=v316["op"];
const v397=5;
let v398;if((v396===v397)){
const v399=v316["a"];
const v400=((v324 ^ 2147483648) >>> 0);
const v401=4294967295;
let v402;if((v399===v401)){
v402=v328;}else{
let v403;if(v399<v328.length){v403=v328.item(v399);}else{
v403=0;}
const v404=v403;
v402=__tempSet(v328,v399,__bits(__float(v404) + __float(v400)),false);}
v398=v402;}else{
const v405=v316["op"];
const v406=6;
let v407;if((v405===v406)){
const v408=v316["a"];
const v409=1073741824;
const v410=v316["value"];
const v411=__bits((__float(v324))/(__float(__bits(__float(v409) * __float(v410)))));
const v412=4294967295;
let v413;if((v408===v412)){
v413=v328;}else{
let v414;if(v408<v328.length){v414=v328.item(v408);}else{
v414=0;}
const v415=v414;
v413=__tempSet(v328,v408,__bits(__float(v415) + __float(v411)),false);}
v407=v413;}else{
v407=v328;}
v398=v407;}
v378=v398;}
v360=v378;}
v345=v360;}
v331=v345;}
v327=v331;}
const v416=v327;
return ({["index"]:v321,["gradient"]:v416});}
function __fn16(v417,v418,v419){
let v420=new __InkBuffer([]);
for(let v421=0;v421<v417.length;v421++){
const v422=v417[v421];
const v423=v420;
const v424=0;
v420=__tempEdit(v423,"push",v424);
}
const v425=v420;
const v426=v418["id"];
const v427=1065353216;
const v428=4294967295;
let v429;if((v426===v428)){
v429=v425;}else{
let v430;if(v426<v425.length){v430=v425.item(v426);}else{
v430=0;}
const v431=v430;
v429=__tempSet(v425,v426,__bits(__float(v431) + __float(v427)),false);}
const v432=v429;
const v433=(v417).length;
let v434=v432;
let v435=v433;
for(let v437=v417.length-1;v437>=0;v437--){
const v438=v417[v437];
const v440=v435;
const v441=1;
const v442=(((v440) - (v441)) >>> 0);
const v443=v434;
let v444;if(v442<v443.length){v444=v443.item(v442);}else{
v444=0;}
const v445=v444;
let v446=v419;if(v446){
const v447=0;
v446=((__float(v445)) === (__float(v447)));}
let v448;if(v446){
v448=v434;}else{
const v449=v434;
const v450=v438["op"];
const v451=1;
let v452;if((v450===v451)){
const v453=v438["a"];
const v454=4294967295;
let v455;if((v453===v454)){
v455=v449;}else{
let v456;if(v453<v449.length){v456=v449.item(v453);}else{
v456=0;}
const v457=v456;
v455=__tempSet(v449,v453,__bits(__float(v457) + __float(v445)),false);}
const v458=v455;
const v459=v438["b"];
const v460=4294967295;
let v461;if((v459===v460)){
v461=v458;}else{
let v462;if(v459<v458.length){v462=v458.item(v459);}else{
v462=0;}
const v463=v462;
v461=__tempSet(v458,v459,__bits(__float(v463) + __float(v445)),false);}
v452=v461;}else{
const v464=v438["op"];
const v465=2;
let v466;if((v464===v465)){
const v467=v438["a"];
const v468=4294967295;
let v469;if((v467===v468)){
v469=v449;}else{
let v470;if(v467<v449.length){v470=v449.item(v467);}else{
v470=0;}
const v471=v470;
v469=__tempSet(v449,v467,__bits(__float(v471) + __float(v445)),false);}
const v472=v469;
const v473=v438["b"];
const v474=((v445 ^ 2147483648) >>> 0);
const v475=4294967295;
let v476;if((v473===v475)){
v476=v472;}else{
let v477;if(v473<v472.length){v477=v472.item(v473);}else{
v477=0;}
const v478=v477;
v476=__tempSet(v472,v473,__bits(__float(v478) + __float(v474)),false);}
v466=v476;}else{
const v479=v438["op"];
const v480=3;
let v481;if((v479===v480)){
const v482=v438["a"];
const v483=v438["bv"];
const v484=__bits(__float(v445) * __float(v483));
const v485=4294967295;
let v486;if((v482===v485)){
v486=v449;}else{
let v487;if(v482<v449.length){v487=v449.item(v482);}else{
v487=0;}
const v488=v487;
v486=__tempSet(v449,v482,__bits(__float(v488) + __float(v484)),false);}
const v489=v486;
const v490=v438["b"];
const v491=v438["av"];
const v492=__bits(__float(v445) * __float(v491));
const v493=4294967295;
let v494;if((v490===v493)){
v494=v489;}else{
let v495;if(v490<v489.length){v495=v489.item(v490);}else{
v495=0;}
const v496=v495;
v494=__tempSet(v489,v490,__bits(__float(v496) + __float(v492)),false);}
v481=v494;}else{
const v497=v438["op"];
const v498=4;
let v499;if((v497===v498)){
const v500=v438["a"];
const v501=__bits((__float(v445))/(__float(v438["bv"])));
const v502=4294967295;
let v503;if((v500===v502)){
v503=v449;}else{
let v504;if(v500<v449.length){v504=v449.item(v500);}else{
v504=0;}
const v505=v504;
v503=__tempSet(v449,v500,__bits(__float(v505) + __float(v501)),false);}
const v506=v503;
const v507=v438["b"];
const v508=v438["av"];
const v509=v438["bv"];
const v510=v438["bv"];
const v511=__bits((__float(__bits(__float(v445) * __float(v508))))/(__float(__bits(__float(v509) * __float(v510)))));
const v512=((v511 ^ 2147483648) >>> 0);
const v513=4294967295;
let v514;if((v507===v513)){
v514=v506;}else{
let v515;if(v507<v506.length){v515=v506.item(v507);}else{
v515=0;}
const v516=v515;
v514=__tempSet(v506,v507,__bits(__float(v516) + __float(v512)),false);}
v499=v514;}else{
const v517=v438["op"];
const v518=5;
let v519;if((v517===v518)){
const v520=v438["a"];
const v521=((v445 ^ 2147483648) >>> 0);
const v522=4294967295;
let v523;if((v520===v522)){
v523=v449;}else{
let v524;if(v520<v449.length){v524=v449.item(v520);}else{
v524=0;}
const v525=v524;
v523=__tempSet(v449,v520,__bits(__float(v525) + __float(v521)),false);}
v519=v523;}else{
const v526=v438["op"];
const v527=6;
let v528;if((v526===v527)){
const v529=v438["a"];
const v530=1073741824;
const v531=v438["value"];
const v532=__bits((__float(v445))/(__float(__bits(__float(v530) * __float(v531)))));
const v533=4294967295;
let v534;if((v529===v533)){
v534=v449;}else{
let v535;if(v529<v449.length){v535=v449.item(v529);}else{
v535=0;}
const v536=v535;
v534=__tempSet(v449,v529,__bits(__float(v536) + __float(v532)),false);}
v528=v534;}else{
v528=v449;}
v519=v528;}
v499=v519;}
v481=v499;}
v466=v481;}
v452=v466;}
v448=v452;}
const v537=v448;
const v538=({["index"]:v442,["gradient"]:v537});
v434=v538["gradient"];
v435=v538["index"];
}
const v540=v434;
return v540.freeze();}
function __fn17(v541,v542){
const v543=10;
const v546=false;
let v547=v541;
let v548=v542;
let v549=v546;
for(let v551=0;v551<v543;v551++){
if(v549){break;}
const v552=(v551>>>0);
const v553=v547;
const v554=v548;
const v556=1090519040;
const v557=__fn8(v556);
const v559=v553["value"];
const v560=v557["value"];
const v561=((__float(v559)) >= (__float(v560)));
let v563;if(v561){
const v564=v547;
const v565=true;
v563=({["value"]:v564,["tape"]:v554,["stopped"]:v565});}else{
const v566=v547;
const v568=1073741824;
const v569=__fn8(v568);
const v571=3;
const v572=1;
let v573;if((v571===v572)){
const v574=v566["value"];
const v575=v569["value"];
v573=__bits(__float(v574) + __float(v575));}else{
const v576=2;
let v577;if((v571===v576)){
const v578=v566["value"];
const v579=v569["value"];
v577=__bits(__float(v578) - __float(v579));}else{
const v580=3;
let v581;if((v571===v580)){
const v582=v566["value"];
const v583=v569["value"];
v581=__bits(__float(v582) * __float(v583));}else{
v581=__bits((__float(v566["value"]))/(__float(v569["value"])));}
v577=v581;}
v573=v577;}
const v584=v573;
const v585=v566["id"];
const v586=v569["id"];
const v587=v566["value"];
const v588=v569["value"];
const v590=v566["id"];
const v591=4294967295;
const v592=!(v590===v591);
let v593=v592;if(!v593){
const v594=v569["id"];
const v595=4294967295;
v593=!(v594===v595);}
const v596=v593;
const v597=false;
const v598=(v596===v597);
let v599=v598;if(!v599){
v599=v554["failed"];}
let v600;
let v601;
if(v599){
const v602=__fn8(v584);
v600=v602;
v601=v554;
}else{
const v603=v554["nodes"];
const v604=(v603).length;
const v605=v554["maximum"];
let v606;
let v607;
if(((v604) >= (v605))){
const v608=__fn8(v584);
const v609=true;
const v610=v554["nodes"];
const v611=v554["maximum"];
const v612=({["nodes"]:v610,["maximum"]:v611,["failed"]:v609});
v606=v608;
v607=v612;
}else{
const v613=({["value"]:v584,["id"]:v604});
const v614=v554["nodes"];
const v615=({["op"]:v571,["a"]:v585,["b"]:v586,["av"]:v587,["bv"]:v588,["value"]:v584});
const v616=__tempEdit(v614,"push",v615);
const v617=v554["maximum"];
const v618=v554["failed"];
const v619=({["nodes"]:v616,["maximum"]:v617,["failed"]:v618});
v606=v613;
v607=v619;
}
v600=v606;
v601=v607;
}
const v621=v600;
const v622=v601;
const v623=false;
v563=({["value"]:v621,["tape"]:v622,["stopped"]:v623});}
const v624=v563;
v547=v624["value"];
v548=v624["tape"];
v549=v624["stopped"];
}
const v626=v547;
const v627=v548;
return ({["value"]:v626,["tape"]:v627});}
function __fn18(v628,v629,v630){
const v631=1000000;
let v632;if(((v629) > (v631))){
v632=({Err:"reverse differentiation capacity exceeds one million nodes"});}else{
const v633=new __InkBuffer([]);
const v634=false;
const v637=0;
const v638=4294967295;
const v639=4294967295;
const v640=0;
const v641=0;
const v643=true;
const v644=false;
const v645=(v643===v644);
let v646=v645;if(!v646){
v646=v634;}
let v647;
let v648;
if(v646){
const v649=__fn8(v628);
const v650=({["nodes"]:v633,["maximum"]:v629,["failed"]:v634});
v647=v649;
v648=v650;
}else{
const v651=(v633).length;
let v652;
let v653;
if(((v651) >= (v629))){
const v654=__fn8(v628);
const v655=true;
const v656=({["nodes"]:v633,["maximum"]:v629,["failed"]:v655});
v652=v654;
v653=v656;
}else{
const v657=({["value"]:v628,["id"]:v651});
const v658=({["op"]:v637,["a"]:v638,["b"]:v639,["av"]:v640,["bv"]:v641,["value"]:v628});
const v659=__tempEdit(v633,"push",v658);
const v660=({["nodes"]:v659,["maximum"]:v629,["failed"]:v634});
v652=v657;
v653=v660;
}
v647=v652;
v648=v653;
}
const v662=v647;
const v663=v648;
const v664=10;
const v667=false;
let v668=v662;
let v669=v663;
let v670=v667;
for(let v672=0;v672<v664;v672++){
if(v670){break;}
const v673=(v672>>>0);
const v674=v668;
const v675=v669;
const v677=1090519040;
const v678=__fn8(v677);
const v680=v674["value"];
const v681=v678["value"];
const v682=((__float(v680)) >= (__float(v681)));
let v684;
let v685;
let v686;
if(v682){
const v687=v668;
const v688=true;
v684=v687;
v685=v675;
v686=v688;
}else{
const v689=v668;
const v691=1073741824;
const v692=__fn8(v691);
const v694=3;
const v695=1;
let v696;if((v694===v695)){
const v697=v689["value"];
const v698=v692["value"];
v696=__bits(__float(v697) + __float(v698));}else{
const v699=2;
let v700;if((v694===v699)){
const v701=v689["value"];
const v702=v692["value"];
v700=__bits(__float(v701) - __float(v702));}else{
const v703=3;
let v704;if((v694===v703)){
const v705=v689["value"];
const v706=v692["value"];
v704=__bits(__float(v705) * __float(v706));}else{
v704=__bits((__float(v689["value"]))/(__float(v692["value"])));}
v700=v704;}
v696=v700;}
const v707=v696;
const v708=v689["id"];
const v709=v692["id"];
const v710=v689["value"];
const v711=v692["value"];
const v713=v689["id"];
const v714=4294967295;
const v715=!(v713===v714);
let v716=v715;if(!v716){
const v717=v692["id"];
const v718=4294967295;
v716=!(v717===v718);}
const v719=v716;
const v720=false;
const v721=(v719===v720);
let v722=v721;if(!v722){
v722=v675["failed"];}
let v723;
let v724;
if(v722){
const v725=__fn8(v707);
v723=v725;
v724=v675;
}else{
const v726=v675["nodes"];
const v727=(v726).length;
const v728=v675["maximum"];
let v729;
let v730;
if(((v727) >= (v728))){
const v731=__fn8(v707);
const v732=true;
const v733=v675["nodes"];
const v734=v675["maximum"];
const v735=({["nodes"]:v733,["maximum"]:v734,["failed"]:v732});
v729=v731;
v730=v735;
}else{
const v736=({["value"]:v707,["id"]:v727});
const v737=v675["nodes"];
const v738=({["op"]:v694,["a"]:v708,["b"]:v709,["av"]:v710,["bv"]:v711,["value"]:v707});
const v739=__tempEdit(v737,"push",v738);
const v740=v675["maximum"];
const v741=v675["failed"];
const v742=({["nodes"]:v739,["maximum"]:v740,["failed"]:v741});
v729=v736;
v730=v742;
}
v723=v729;
v724=v730;
}
const v744=v723;
const v745=v724;
const v746=false;
v684=v744;
v685=v745;
v686=v746;
}
v668=v684;
v669=v685;
v670=v686;
}
const v748=v668;
const v749=v669;
let v751;if(v749["failed"]){
v751=({Err:"reverse differentiation tape capacity exceeded"});}else{
const v752=v749["nodes"];
const v753=v752.freeze();
const v754=__fn16(v753,v748,v630);
const v755=v748["value"];
const v756=v647;
const v757=v756["id"];
let v758;if(v757<v754.length){v758=v754[v757];}else{
v758=0;}
const v759=v758;
v751=({Ok:({["value"]:v755,["gradient"]:v759})});}
v632=v751;}
return v632;}
function __fn19(v760,v761){
const v762=1n;
const v764=2n;
const v766=3n;
const v768=4n;
const v770=[v762,v764,v766,v768];
const v773=false;
let v774=v760;
let v775=v761;
let v776=v773;
for(let v778=0;v778<v770.length;v778++){
const v779=v770[v778];
const v780=v776;
let v781;if(v776){
v781=({["value"]:v774,["tape"]:v775,["stopped"]:v776});}else{
const v782=v774;
const v783=v775;
const v785=1082130432;
const v786=__fn8(v785);
const v788=v782["value"];
const v789=v786["value"];
const v790=((__float(v788)) >= (__float(v789)));
const v792=v774;
const v794=1073741824;
const v795=__fn8(v794);
const v797=3;
const v798=1;
let v799;if((v797===v798)){
const v800=v792["value"];
const v801=v795["value"];
v799=__bits(__float(v800) + __float(v801));}else{
const v802=2;
let v803;if((v797===v802)){
const v804=v792["value"];
const v805=v795["value"];
v803=__bits(__float(v804) - __float(v805));}else{
const v806=3;
let v807;if((v797===v806)){
const v808=v792["value"];
const v809=v795["value"];
v807=__bits(__float(v808) * __float(v809));}else{
v807=__bits((__float(v792["value"]))/(__float(v795["value"])));}
v803=v807;}
v799=v803;}
const v810=v799;
const v811=v792["id"];
const v812=v795["id"];
const v813=v792["value"];
const v814=v795["value"];
const v816=v792["id"];
const v817=4294967295;
const v818=!(v816===v817);
let v819=v818;if(!v819){
const v820=v795["id"];
const v821=4294967295;
v819=!(v820===v821);}
const v822=v819;
const v823=false;
const v824=(v822===v823);
let v825=v824;if(!v825){
v825=v783["failed"];}
let v826;
let v827;
if(v825){
const v828=__fn8(v810);
v826=v828;
v827=v783;
}else{
const v829=v783["nodes"];
const v830=(v829).length;
const v831=v783["maximum"];
let v832;
let v833;
if(((v830) >= (v831))){
const v834=__fn8(v810);
const v835=true;
const v836=v783["nodes"];
const v837=v783["maximum"];
const v838=({["nodes"]:v836,["maximum"]:v837,["failed"]:v835});
v832=v834;
v833=v838;
}else{
const v839=({["value"]:v810,["id"]:v830});
const v840=v783["nodes"];
const v841=({["op"]:v797,["a"]:v811,["b"]:v812,["av"]:v813,["bv"]:v814,["value"]:v810});
const v842=__tempEdit(v840,"push",v841);
const v843=v783["maximum"];
const v844=v783["failed"];
const v845=({["nodes"]:v842,["maximum"]:v843,["failed"]:v844});
v832=v839;
v833=v845;
}
v826=v832;
v827=v833;
}
const v847=v826;
const v848=v827;
v781=({["value"]:v847,["tape"]:v848,["stopped"]:v790});}
const v849=v781;
v774=v849["value"];
v775=v849["tape"];
v776=v849["stopped"];
if(v780)break;
}
const v851=v774;
const v852=v775;
return ({["value"]:v851,["tape"]:v852});}
function __fn20(v853,v854,v855){
const v856=1000000;
let v857;if(((v854) > (v856))){
v857=({Err:"reverse differentiation capacity exceeds one million nodes"});}else{
const v858=new __InkBuffer([]);
const v859=false;
const v862=0;
const v863=4294967295;
const v864=4294967295;
const v865=0;
const v866=0;
const v868=true;
const v869=false;
const v870=(v868===v869);
let v871=v870;if(!v871){
v871=v859;}
let v872;
let v873;
if(v871){
const v874=__fn8(v853);
const v875=({["nodes"]:v858,["maximum"]:v854,["failed"]:v859});
v872=v874;
v873=v875;
}else{
const v876=(v858).length;
let v877;
let v878;
if(((v876) >= (v854))){
const v879=__fn8(v853);
const v880=true;
const v881=({["nodes"]:v858,["maximum"]:v854,["failed"]:v880});
v877=v879;
v878=v881;
}else{
const v882=({["value"]:v853,["id"]:v876});
const v883=({["op"]:v862,["a"]:v863,["b"]:v864,["av"]:v865,["bv"]:v866,["value"]:v853});
const v884=__tempEdit(v858,"push",v883);
const v885=({["nodes"]:v884,["maximum"]:v854,["failed"]:v859});
v877=v882;
v878=v885;
}
v872=v877;
v873=v878;
}
const v887=v872;
const v888=v873;
const v889=1n;
const v891=2n;
const v893=3n;
const v895=4n;
const v897=[v889,v891,v893,v895];
const v900=false;
let v901=v887;
let v902=v888;
let v903=v900;
for(let v905=0;v905<v897.length;v905++){
const v906=v897[v905];
const v907=v903;
let v908;
let v909;
let v910;
if(v903){
v908=v901;
v909=v902;
v910=v903;
}else{
const v911=v901;
const v912=v902;
const v914=1082130432;
const v915=__fn8(v914);
const v917=v911["value"];
const v918=v915["value"];
const v919=((__float(v917)) >= (__float(v918)));
const v921=v901;
const v923=1073741824;
const v924=__fn8(v923);
const v926=3;
const v927=1;
let v928;if((v926===v927)){
const v929=v921["value"];
const v930=v924["value"];
v928=__bits(__float(v929) + __float(v930));}else{
const v931=2;
let v932;if((v926===v931)){
const v933=v921["value"];
const v934=v924["value"];
v932=__bits(__float(v933) - __float(v934));}else{
const v935=3;
let v936;if((v926===v935)){
const v937=v921["value"];
const v938=v924["value"];
v936=__bits(__float(v937) * __float(v938));}else{
v936=__bits((__float(v921["value"]))/(__float(v924["value"])));}
v932=v936;}
v928=v932;}
const v939=v928;
const v940=v921["id"];
const v941=v924["id"];
const v942=v921["value"];
const v943=v924["value"];
const v945=v921["id"];
const v946=4294967295;
const v947=!(v945===v946);
let v948=v947;if(!v948){
const v949=v924["id"];
const v950=4294967295;
v948=!(v949===v950);}
const v951=v948;
const v952=false;
const v953=(v951===v952);
let v954=v953;if(!v954){
v954=v912["failed"];}
let v955;
let v956;
if(v954){
const v957=__fn8(v939);
v955=v957;
v956=v912;
}else{
const v958=v912["nodes"];
const v959=(v958).length;
const v960=v912["maximum"];
let v961;
let v962;
if(((v959) >= (v960))){
const v963=__fn8(v939);
const v964=true;
const v965=v912["nodes"];
const v966=v912["maximum"];
const v967=({["nodes"]:v965,["maximum"]:v966,["failed"]:v964});
v961=v963;
v962=v967;
}else{
const v968=({["value"]:v939,["id"]:v959});
const v969=v912["nodes"];
const v970=({["op"]:v926,["a"]:v940,["b"]:v941,["av"]:v942,["bv"]:v943,["value"]:v939});
const v971=__tempEdit(v969,"push",v970);
const v972=v912["maximum"];
const v973=v912["failed"];
const v974=({["nodes"]:v971,["maximum"]:v972,["failed"]:v973});
v961=v968;
v962=v974;
}
v955=v961;
v956=v962;
}
const v976=v955;
const v977=v956;
v908=v976;
v909=v977;
v910=v919;
}
v901=v908;
v902=v909;
v903=v910;
if(v907)break;
}
const v979=v901;
const v980=v902;
let v982;if(v980["failed"]){
v982=({Err:"reverse differentiation tape capacity exceeded"});}else{
const v983=v980["nodes"];
const v984=v983.freeze();
const v985=__fn16(v984,v979,v855);
const v986=v979["value"];
const v987=v872;
const v988=v987["id"];
let v989;if(v988<v985.length){v989=v985[v988];}else{
v989=0;}
const v990=v989;
v982=({Ok:({["value"]:v986,["gradient"]:v990})});}
v857=v982;}
return v857;}
function __into7(v991,v992){
const v993=v991.length;
for(let v995=0;v995<v993;v995++){
const v996=v991[v995];
const v998=1073741824;
const v999=Math.fround(__float(v996) * __float(v998));
const v1000=1065353216;
v992[v995]=__intoOutput7(__bits(v999 + __float(v1000)));
}
return v993;}
function __into16(v1001,v1002,v1003,v1004){
let v1005=new __InkBuffer([]);
for(let v1006=0;v1006<v1001.length;v1006++){
const v1007=v1001[v1006];
const v1008=v1005;
const v1009=0;
v1005=__tempEdit(v1008,"push",v1009);
}
const v1010=v1005;
const v1011=v1002["id"];
const v1012=1065353216;
const v1013=4294967295;
let v1014;if((v1011===v1013)){
v1014=v1010;}else{
let v1015;if(v1011<v1010.length){v1015=v1010.item(v1011);}else{
v1015=0;}
const v1016=v1015;
v1014=__tempSet(v1010,v1011,__bits(__float(v1016) + __float(v1012)),false);}
const v1017=v1014;
const v1018=(v1001).length;
let v1019=v1017;
let v1020=v1018;
for(let v1022=v1001.length-1;v1022>=0;v1022--){
const v1023=v1001[v1022];
const v1025=v1020;
const v1026=1;
const v1027=(((v1025) - (v1026)) >>> 0);
const v1028=v1019;
let v1029;if(v1027<v1028.length){v1029=v1028.item(v1027);}else{
v1029=0;}
const v1030=v1029;
let v1031=v1003;if(v1031){
const v1032=0;
v1031=((__float(v1030)) === (__float(v1032)));}
let v1033;if(v1031){
v1033=v1019;}else{
const v1034=v1019;
const v1035=v1023["op"];
const v1036=1;
let v1037;if((v1035===v1036)){
const v1038=v1023["a"];
const v1039=4294967295;
let v1040;if((v1038===v1039)){
v1040=v1034;}else{
let v1041;if(v1038<v1034.length){v1041=v1034.item(v1038);}else{
v1041=0;}
const v1042=v1041;
v1040=__tempSet(v1034,v1038,__bits(__float(v1042) + __float(v1030)),false);}
const v1043=v1040;
const v1044=v1023["b"];
const v1045=4294967295;
let v1046;if((v1044===v1045)){
v1046=v1043;}else{
let v1047;if(v1044<v1043.length){v1047=v1043.item(v1044);}else{
v1047=0;}
const v1048=v1047;
v1046=__tempSet(v1043,v1044,__bits(__float(v1048) + __float(v1030)),false);}
v1037=v1046;}else{
const v1049=v1023["op"];
const v1050=2;
let v1051;if((v1049===v1050)){
const v1052=v1023["a"];
const v1053=4294967295;
let v1054;if((v1052===v1053)){
v1054=v1034;}else{
let v1055;if(v1052<v1034.length){v1055=v1034.item(v1052);}else{
v1055=0;}
const v1056=v1055;
v1054=__tempSet(v1034,v1052,__bits(__float(v1056) + __float(v1030)),false);}
const v1057=v1054;
const v1058=v1023["b"];
const v1059=((v1030 ^ 2147483648) >>> 0);
const v1060=4294967295;
let v1061;if((v1058===v1060)){
v1061=v1057;}else{
let v1062;if(v1058<v1057.length){v1062=v1057.item(v1058);}else{
v1062=0;}
const v1063=v1062;
v1061=__tempSet(v1057,v1058,__bits(__float(v1063) + __float(v1059)),false);}
v1051=v1061;}else{
const v1064=v1023["op"];
const v1065=3;
let v1066;if((v1064===v1065)){
const v1067=v1023["a"];
const v1068=v1023["bv"];
const v1069=__bits(__float(v1030) * __float(v1068));
const v1070=4294967295;
let v1071;if((v1067===v1070)){
v1071=v1034;}else{
let v1072;if(v1067<v1034.length){v1072=v1034.item(v1067);}else{
v1072=0;}
const v1073=v1072;
v1071=__tempSet(v1034,v1067,__bits(__float(v1073) + __float(v1069)),false);}
const v1074=v1071;
const v1075=v1023["b"];
const v1076=v1023["av"];
const v1077=__bits(__float(v1030) * __float(v1076));
const v1078=4294967295;
let v1079;if((v1075===v1078)){
v1079=v1074;}else{
let v1080;if(v1075<v1074.length){v1080=v1074.item(v1075);}else{
v1080=0;}
const v1081=v1080;
v1079=__tempSet(v1074,v1075,__bits(__float(v1081) + __float(v1077)),false);}
v1066=v1079;}else{
const v1082=v1023["op"];
const v1083=4;
let v1084;if((v1082===v1083)){
const v1085=v1023["a"];
const v1086=__bits((__float(v1030))/(__float(v1023["bv"])));
const v1087=4294967295;
let v1088;if((v1085===v1087)){
v1088=v1034;}else{
let v1089;if(v1085<v1034.length){v1089=v1034.item(v1085);}else{
v1089=0;}
const v1090=v1089;
v1088=__tempSet(v1034,v1085,__bits(__float(v1090) + __float(v1086)),false);}
const v1091=v1088;
const v1092=v1023["b"];
const v1093=v1023["av"];
const v1094=v1023["bv"];
const v1095=v1023["bv"];
const v1096=__bits((__float(__bits(__float(v1030) * __float(v1093))))/(__float(__bits(__float(v1094) * __float(v1095)))));
const v1097=((v1096 ^ 2147483648) >>> 0);
const v1098=4294967295;
let v1099;if((v1092===v1098)){
v1099=v1091;}else{
let v1100;if(v1092<v1091.length){v1100=v1091.item(v1092);}else{
v1100=0;}
const v1101=v1100;
v1099=__tempSet(v1091,v1092,__bits(__float(v1101) + __float(v1097)),false);}
v1084=v1099;}else{
const v1102=v1023["op"];
const v1103=5;
let v1104;if((v1102===v1103)){
const v1105=v1023["a"];
const v1106=((v1030 ^ 2147483648) >>> 0);
const v1107=4294967295;
let v1108;if((v1105===v1107)){
v1108=v1034;}else{
let v1109;if(v1105<v1034.length){v1109=v1034.item(v1105);}else{
v1109=0;}
const v1110=v1109;
v1108=__tempSet(v1034,v1105,__bits(__float(v1110) + __float(v1106)),false);}
v1104=v1108;}else{
const v1111=v1023["op"];
const v1112=6;
let v1113;if((v1111===v1112)){
const v1114=v1023["a"];
const v1115=1073741824;
const v1116=v1023["value"];
const v1117=__bits((__float(v1030))/(__float(__bits(__float(v1115) * __float(v1116)))));
const v1118=4294967295;
let v1119;if((v1114===v1118)){
v1119=v1034;}else{
let v1120;if(v1114<v1034.length){v1120=v1034.item(v1114);}else{
v1120=0;}
const v1121=v1120;
v1119=__tempSet(v1034,v1114,__bits(__float(v1121) + __float(v1117)),false);}
v1113=v1119;}else{
v1113=v1034;}
v1104=v1113;}
v1084=v1104;}
v1066=v1084;}
v1051=v1066;}
v1037=v1051;}
v1033=v1037;}
const v1122=v1033;
const v1123=({["index"]:v1027,["gradient"]:v1122});
v1019=v1123["gradient"];
v1020=v1123["index"];
}
const v1124=({["gradient"]:v1019,["index"]:v1020});
const v1125=v1124["gradient"];
const v1126=v1125.freeze();
const v1127=v1126.length;
for(let v1128=0;v1128<v1127;v1128++){
v1004[v1128]=__intoOutput16(v1126[v1128]);
}
return v1127;}
const __namedTypes={"Alias":{"fields":[{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Alias"},"DevicePoint":{"fields":[{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"DevicePoint"},"__ink_reverse_0_Flow":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"},"__ink_reverse_0_Node":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"__ink_reverse_0_Reverse":{"fields":[{"name":"gradient","type":{"kind":"temporary"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Reverse"},"__ink_reverse_0_Tape":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"},"__ink_reverse_0_Wire":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"__ink_reverse_14":{"fields":[{"name":"value","type":{"kind":"bool"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_14"},"__ink_reverse_25":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_25"},"__ink_reverse_28":{"fields":[{"name":"value","type":{"kind":"u64"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_28"},"__ink_reverse_3":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_3"},"__ink_reverse_33":{"fields":[{"name":"value","type":{"element":{"kind":"u64"},"kind":"list"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_33"},"__ink_reverse_36":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"stopped","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_36"},"__ink_reverse_54":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_54"},"__ink_reverse_6":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"stopped","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_6"}};
// Portable snapshot ABI shared with native/Wasm. Hashing uses Web Crypto.
function __snapshotLimits(limits={}){
 const result={bytes:64*1024*1024,values:1000000,depth:128,...limits};
 for(const k of ['bytes','values','depth'])if(!Number.isSafeInteger(result[k])||result[k]<0||result[k]>(k==='depth'?128:k==='values'?1000000:64*1024*1024))throw Error('invalid snapshot limits');
 return result;
}
const __hash=async bytes=>new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256',bytes));
function __snapshotWriter(limits){
 const out=[];let left=limits.values,maxDepth=0;
 function bytes(xs){if(xs.length>limits.bytes-out.length)throw Error('snapshot byte limit exceeded');for(const x of xs)out.push(x);}
 function integer(n,size){n=BigInt(n);for(let i=0;i<size;i++){bytes([Number(n&255n)]);n>>=8n;}}
 function raw(xs){integer(xs.length,8);bytes(xs);}
 function value(v,t,depth=0,bindings=[]){maxDepth=Math.max(maxDepth,depth);if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{value(v,t.body,depth+1,bindings);}finally{bindings.pop();}break;
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');value(v,bound[1],depth+1,bindings);break;}
  case 'unit':break;case 'bool':bytes([v?1:0]);break;
  case 'u32':case 'i32':case 'f32':integer(v,4);break;case 'u64':integer(v,8);break;
  case 'f64':integer(__dfBits(v),8);break;
  case 'vector':if(v.length!==t.size)throw Error('vector dimension mismatch');for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'int':{let n=v<0n?-v:v;const xs=[];while(n){if(xs.length>=4096)throw Error('snapshot Int exceeds size limit');xs.push(Number(n&255n));n>>=8n;}bytes([v===0n?0:v>0n?1:2]);raw(xs);break;}
  case 'string':raw(__encoder.encode(v));break;
  case 'id':integer(BigInt('0x'+v),16);break;
  case 'enum':integer(t.variants.indexOf(v),4);break;
  case 'record':for(const f of t.fields)value(t.elided?v:v[f.name],f.type,depth+1,bindings);break;
  case 'list':if(v.length>left)throw Error('snapshot value limit exceeded');integer(v.length,8);for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'option':if(Object.hasOwn(v,'Some')){bytes([1]);value(v.Some,t.element,depth+1,bindings);}else bytes([0]);break;
  case 'result':{const branch=t.sum_key?__sumView(t.sum_key,v):v;if(Object.hasOwn(branch,'Ok')){bytes([0]);value(branch.Ok,t.ok,depth+1,bindings);}else{bytes([1]);value(branch.Err,t.error,depth+1,bindings);}break;}
  default:throw Error('unsupported snapshot type');
 }}
 return {bytes,integer,raw,value,charge(cells,depth){left-=cells;if(left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');},get maxDepth(){return maxDepth;},get left(){return left;},finish:()=>new Uint8Array(out)};
}
async function __snapshotEncode(meta,state,options){
 const limits=__snapshotLimits(options),w=__snapshotWriter(limits);
 w.integer(state.version,8);
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const rows=[...state.tables[r.index].entries()].sort((a,b)=>__keyCompare(a[0],b[0],r.key));if(rows.length>Math.floor(w.left/2))throw Error('snapshot row limit exceeded');w.integer(rows.length,8);for(const [k,v]of rows){
  if(!meta.snapshotRows){w.value(k,r.snapshotKey??r.key);w.value(v,r.snapshotValue??r.value);continue;}
  const cache=state.snapshotRows[r.index];let packed=cache.get(k);
  if(!packed){const row=__snapshotWriter(limits);row.value(k,r.snapshotKey??r.key);row.value(v,r.snapshotValue??r.value);packed={bytes:row.finish(),cells:limits.values-row.left,depth:row.maxDepth};cache.set(k,packed);}
  w.charge(packed.cells,packed.depth);w.bytes(packed.bytes);
 }}
 w.integer(state.outbox.length,8);
 for(const e of state.outbox){const channel=meta.events.findIndex(t=>t.name===e.channel);w.integer(e.commit,8);w.integer(e.position,8);w.integer(channel,4);w.value(e.value,meta.events[channel].snapshotType??meta.events[channel].type);}
 const payload=w.finish(),header=__snapshotWriter(limits);header.bytes([86,76,83,84,65,84,69,0,1,0,1,0]);header.bytes(meta.snapshot.program);header.bytes(meta.snapshot.schema);header.integer(payload.length,8);header.bytes(payload);
 const bytes=header.finish();if(bytes.length+32>limits.bytes)throw Error('snapshot byte limit exceeded');const digest=await __hash(bytes);const result=new Uint8Array(bytes.length+32);result.set(bytes);result.set(digest,bytes.length);return result;
}
async function __snapshotDecode(meta,input,options){
 const limits=__snapshotLimits(options);
 if(!(input instanceof Uint8Array)&&!Array.isArray(input))throw Error('expected snapshot bytes');
 if(input.length>limits.bytes||input.length<116)throw Error('snapshot byte length invalid');
 if(Array.isArray(input)&&input.some(b=>!Number.isInteger(b)||b<0||b>255))throw Error('invalid snapshot bytes');
 const bytes=new Uint8Array(input); // capture before asynchronous integrity work
 function same(a,b){return a.length===b.length&&a.every((v,i)=>v===b[i]);}
 if(!same(bytes.subarray(0,12),[86,76,83,84,65,84,69,0,1,0,1,0]))throw Error('snapshot format or semantics version mismatch');
 if(!same(bytes.subarray(12,44),meta.snapshot.program)||!same(bytes.subarray(44,76),meta.snapshot.schema))throw Error('snapshot program or schema identity mismatch');
 const end=bytes.length-32,digest=await __hash(bytes.subarray(0,end));if(!same(digest,bytes.subarray(end)))throw Error('snapshot integrity check failed');
 let at=76,left=limits.values;
 function take(n){if(!Number.isSafeInteger(n)||n<0||n>end-at)throw Error('truncated snapshot');const x=bytes.subarray(at,at+n);at+=n;return x;}
 function integer(size){const xs=take(size);let n=0n;for(let i=size-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return n;}
 function length(){const n=integer(8);if(n>BigInt(Number.MAX_SAFE_INTEGER))throw Error('snapshot length not addressable');return Number(n);}
 function sequence(){const n=length();if(n>left)throw Error('snapshot value limit exceeded');return n;}
 function raw(){return take(length());}
 const n=length();if(n!==end-84)throw Error('snapshot payload length mismatch');
 function value(t,depth=0,bindings=[]){if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{return value(t.body,depth+1,bindings);}finally{bindings.pop();}
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');return value(bound[1],depth+1,bindings);}
  case 'unit':return null;case 'bool':{const b=take(1)[0];if(b>1)throw Error('invalid Bool tag');return b===1;}
  case 'u32':case 'f32':return Number(integer(4));case 'i32':return Number(BigInt.asIntN(32,integer(4)));case 'u64':return integer(8);
  case 'f64':return __dfFromBits(integer(8));
  case 'vector':{const xs=[];for(let i=0;i<t.size;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'int':{const sign=take(1)[0],xs=raw();if(xs.length>4096)throw Error('snapshot Int exceeds size limit');if(!((sign===0&&xs.length===0)||((sign===1||sign===2)&&xs.length>0&&xs[xs.length-1]!==0)))throw Error('noncanonical signed integer');let n=0n;for(let i=xs.length-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return sign===2?-n:n;}
  case 'string':return new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(raw());
  case 'id':return integer(16).toString(16).padStart(32,'0');
  case 'enum':{const i=Number(integer(4));if(i>=t.variants.length)throw Error('invalid enum tag');return t.variants[i];}
  case 'record':if(t.elided)return value(t.fields[0].type,depth+1,bindings);return Object.fromEntries(t.fields.map(f=>[f.name,value(f.type,depth+1,bindings)]));
  case 'list':{const n=sequence(),xs=[];for(let i=0;i<n;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'option':{const tag=take(1)[0];if(tag===0)return {None:null};if(tag===1)return {Some:value(t.element,depth+1,bindings)};throw Error('invalid Option tag');}
  case 'result':{const tag=take(1)[0];if(tag===0){const child=value(t.ok,depth+1,bindings);return t.sum_key?__sumMake(t.sum_key,true,child):{Ok:child};}if(tag===1){const child=value(t.error,depth+1,bindings);return t.sum_key?__sumMake(t.sum_key,false,child):{Err:child};}throw Error('invalid Result tag');}
  default:throw Error('unsupported snapshot type');
 }}
 const version=integer(8),tables=meta.roots.map(()=>new Map());
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const n=sequence();if(n>Math.floor(left/2))throw Error('snapshot row limit exceeded');let prior;for(let i=0;i<n;i++){const k=value(r.snapshotKey??r.key),v=value(r.snapshotValue??r.value);if(i&&__keyCompare(prior,k,r.key)>=0)throw Error('duplicate or unordered snapshot key');tables[r.index].set(k,v);prior=k;}}
 const count=sequence(),outbox=[];let prior;
 for(let i=0;i<count;i++){const commit=integer(8),position=integer(8),channel=Number(integer(4));if(!meta.events[channel])throw Error('unknown snapshot event channel');const v=value(meta.events[channel].snapshotType??meta.events[channel].type);if(commit===0n||commit>version||(prior&&(commit<prior.commit||(commit===prior.commit&&position<=prior.position))))throw Error('invalid snapshot event sequence');const e={commit,position,channel:meta.events[channel].name,value:v};outbox.push(e);prior=e;}
 if(at!==end)throw Error('trailing snapshot payload');return {version,tables,outbox};
}
// Fixed subscription lifecycle. Root/output edges derive from checked source;
// values and ownership codecs are compiled from each query's declared type.
function __createObservers(prepare){
 const subscriptions=new Map(),byRoot=new Map(),errors=[],directRoots=[],rootSchedules=[];
 let pending=[],spare=[];
 let next=0,held=0,flushing=false;
 function report(s,error,phase){errors.push({query:s?.query??null,error,phase});if(s?.onError)try{s.onError(error);}catch(e){errors.push({query:s.query,error:e,phase:'error-handler'});}}
 function flush(initialPasses=0){
  if(held||flushing||!pending.length)return;
  flushing=true;let passes=initialPasses;
  try{
   while(pending.length&&!held){
    if(++passes>1024){report(null,Error('subscription publication budget exhausted'),'publication');break;}
    const affected=pending;pending=spare;spare=affected;
    for(const s of affected)s.queued=false;
    // Snapshot every affected value before consumers run. Deliveries reside in
    // the stable subscription slots; no per-delivery tuple is allocated.
    for(const s of affected){if(!s.active)continue;s.deliver=false;
     try{if(s.pair){const a=s.pairState?s.pairState.keeps[s.keep0]:s.read0(),b=s.pairState?s.pairState.keeps[s.keep1]:s.read1();if(s.value0!==a||s.value1!==b){s.value0=a;s.value1=b;s.delivery0=a;s.delivery1=b;s.deliver=true;}}else{const value=s.capture(s.read());if(!s.equal(s.value,value)){s.value=value;s.delivery=value;s.deliver=true;}}}
     catch(e){report(s,e,'query');}
    }
    for(const s of affected){if(!s.active||!s.deliver)continue;const value=s.delivery;s.deliver=false;s.delivery=undefined;
     try{if(s.pair)s.callback(s.delivery0,s.delivery1);else s.callback(s.output(value));}catch(e){report(s,e,'listener');}
    }
    affected.length=0;
   }
  }finally{flushing=false;}
 }
 function install(query,q,callback,{immediate=true,onError}={}){
  if(typeof callback!=='function'||onError!==undefined&&typeof onError!=='function')throw TypeError('subscription callback');
  const s={...q,id:next++,query,callback,onError,active:true,queued:false,deliver:false,delivery:undefined};
  if(s.pair){s.value0=s.pairState?s.pairState.keeps[s.keep0]:s.read0();s.value1=s.pairState?s.pairState.keeps[s.keep1]:s.read1();}else{s.value=s.capture(s.read());}subscriptions.set(s.id,s);
  for(const root of s.roots){let ids=byRoot.get(root);if(!ids)byRoot.set(root,ids=[]);ids.push(s);schedule(root,ids);}
  const dispose=()=>{if(!subscriptions.delete(s.id))return;s.active=false;for(const root of s.roots){const ids=byRoot.get(root);ids.splice(ids.indexOf(s),1);schedule(root,ids);if(!ids.length)byRoot.delete(root);}};
  if(immediate)try{if(s.pair)callback(s.value0,s.value1);else callback(s.output(s.value));}catch(e){dispose();throw e;}
  return dispose;
 }
 // Bind the publication implementation when consumers change, instead of
 // rediscovering the one-consumer schedule on each source mutation.
 function schedule(root,ids){
  const s=directRoots[root]=ids.length===1&&ids[0].pairState?ids[0]:null;
  rootSchedules[root]=!ids.length?null:s?()=>publishPair(s):(outputs,epoch)=>{enqueueRoot(root,outputs,epoch);flush();};
 }
 function publishPair(s){
  const a=s.pairState.keeps[s.keep0],b=s.pairState.keeps[s.keep1];
  if(s.value0===a&&s.value1===b)return;
  if(!held&&!flushing&&!pending.length){
   s.value0=a;s.value1=b;flushing=true;
   try{s.callback(a,b);}catch(e){report(s,e,'listener');}finally{flushing=false;}
   flush(1);return;
  }
  if(!s.queued){s.queued=true;pending.push(s);}flush();
 }
 function enqueueRoot(root,outputs,epoch){
  const slots=byRoot.get(root);if(!slots)return;
  for(let i=0;i<slots.length;i++){
   const s=slots[i];if(s.queued)continue;
   if(outputs!==null&&s.outputs?.length){
    let changed=false;for(let j=0;j<s.outputs.length;j++)if(epoch?outputs[s.outputs[j]]===epoch:outputs.has(s.outputs[j])){changed=true;break;}
    if(!changed)continue;
   }
   s.queued=true;pending.push(s);
  }
 }
 return {
  directRoots,rootSchedules,
  get active(){return subscriptions.size!==0;},
  subscribe(query,args,callback,options){return install(query,prepare(query,args),callback,options);},
  subscribeGroup(queries,callback,options){
   if(!Array.isArray(queries)||!queries.length)throw TypeError('subscription group requires queries');
   const qs=queries.map(q=>typeof q==='string'?prepare(q,[]):prepare(q.query,q.args??[]));
   const roots=[...new Set(qs.flatMap(q=>q.roots))];
   // An unknown dependency forces ordinary root invalidation for the group.
   const outputs=qs.every(q=>q.outputs?.length)?[...new Set(qs.flatMap(q=>q.outputs))]:[];
   const scalar=qs.every(q=>q.scalar),direct=qs.every(q=>q.direct);
   return install(queries,{roots,outputs,read:direct?()=>qs.map(q=>q.direct()):()=>qs.map(q=>q.read()),capture:scalar?values=>values:values=>values.map((v,i)=>qs[i].capture(v)),output:scalar?values=>values.slice():values=>values.map((v,i)=>qs[i].output(v)),equal:scalar?(a,b)=>a.every((v,i)=>v===b[i]):(a,b)=>a.every((v,i)=>qs[i].equal(v,b[i]))},callback,options);
  },
  subscribeValues(queries,callback,options){
   if(!Array.isArray(queries)||!queries.length)throw TypeError('subscription group requires queries');
   if(typeof callback!=='function')throw TypeError('subscription callback');
   const qs=queries.map(q=>typeof q==='string'?prepare(q,[]):prepare(q.query,q.args??[]));
   if(qs.length===2&&qs.every(q=>q.scalar)){
    const roots=[...new Set(qs.flatMap(q=>q.roots))],outputs=qs.every(q=>q.outputs?.length)?[...new Set(qs.flatMap(q=>q.outputs))]:[];
    const pairState=qs[0].committed&&qs[1].committed&&qs[0].committed.state===qs[1].committed.state?qs[0].committed.state:null;
    return install(queries,{roots,outputs,pair:true,pairState,keep0:qs[0].committed?.keep,keep1:qs[1].committed?.keep,read0:qs[0].direct||qs[0].read,read1:qs[1].direct||qs[1].read},callback,options);
   }
   return this.subscribeGroup(queries,values=>callback(...values),options);
  },
  commit(roots,outputs=null){
   if(!subscriptions.size)return;
   for(const root of roots)enqueueRoot(root,outputs,false);
   flush();
  },
  // A checked single-root action supplies a reusable array of changed outputs.
  // No root carrier, Set, affected-ID array or Map lookup per delivery is needed.
  commitRoot(root,outputs=null,epoch=0){
   rootSchedules[root]?.(outputs,epoch);
  },
  hold(){held++;return pending.slice();},
  release(){if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  rollback(mark){for(const s of pending)s.queued=false;pending.length=0;for(const s of mark)if(s.active&&!s.queued){s.queued=true;pending.push(s);}if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  batch(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('batch callback must be synchronous');held++;
   try{const value=callback();if(value&&typeof value.then==='function')throw TypeError('state batch callback must be synchronous');return value;}
   finally{held--;flush();}
  },
  flush,takeErrors(){return errors.splice(0);}
 };
}
function __versionWord(v){return typeof v==='number'?BigInt(v):v;}
function __storedCommit(meta,v){return meta.compactCommits&&v<=9007199254740991n?Number(v):v;}
function __nextCommit(v){return typeof v==='number'&&v<9007199254740991?v+1:BigInt(v)+1n;}
// Private column event log. Public records and portable event ordering are unchanged.
// Private event storage. Public events and portable snapshots keep their ordinary
// ordered records. A selected contiguous run omits repeated commit metadata;
// gaps and duplicate commits materialise an exact literal column.
class __EventColumns {
 constructor(channels,compact=false,runs=false){this.channels=channels;this.compact=compact;this.runs=runs;this.commits=runs?null:[];this.base=undefined;this.values=[];this.positions=null;this.channelValues=channels.length===1?null:[];}
 get length(){return this.values.length;}
 set length(n){if(!Number.isSafeInteger(n)||n<0||n>this.length)throw Error('event log truncate');if(this.commits)this.commits.length=n;this.values.length=n;if(this.positions)this.positions.length=n;if(this.channelValues)this.channelValues.length=n;if(n===0){this.base=undefined;if(this.runs)this.commits=null;}}
 append(commit,position,channel,value){
  const i=this.values.length;
  if(this.commits)this.commits.push(commit);
  else if(!i)this.base=commit;
  else{
   const small=typeof this.base==='number'&&typeof commit==='number';
   const expected=small?this.base+i:__versionWord(this.base)+BigInt(i);
   if(expected!==commit){
    this.commits=[];
    for(let j=0;j<i;j++){const word=__versionWord(this.base)+BigInt(j);this.commits.push(this.compact&&word<=9007199254740991n?Number(word):word);}
    this.commits.push(commit);
   }
  }
  this.values.push(value);if(this.channelValues)this.channelValues.push(channel);if(position!==0n&&!this.positions)this.positions=new Array(i).fill(0n);if(this.positions)this.positions.push(position);
 }
 push(e){this.append(this.compact&&e.commit<=9007199254740991n?Number(e.commit):e.commit,e.position,e.channel,e.value);return this.length;}
 at(i){if(i<0)i+=this.length;if(i<0||i>=this.length)return undefined;return {commit:this.commits?__versionWord(this.commits[i]):__versionWord(this.base)+BigInt(i),position:this.positions?this.positions[i]:0n,channel:this.channelValues?this.channelValues[i]:this.channels[0],value:this.values[i]};}
 *[Symbol.iterator](){for(let i=0;i<this.length;i++)yield this.at(i);}
 map(f){const out=new Array(this.length);for(let i=0;i<this.length;i++)out[i]=f(this.at(i),i);return out;}
 filter(f){const out=new __EventColumns(this.channels,this.compact,this.runs);for(let i=0;i<this.length;i++){const e=this.at(i);if(f(e,i))out.push(e);}return out;}
}
function __eventLog(meta,events=[]){
 if(!meta.eventColumns)return meta.compactCommits?events.map(e=>({...e,commit:__storedCommit(meta,e.commit)})):events;
 const log=new __EventColumns(meta.events.map(e=>e.name),meta.compactCommits,meta.eventRuns);for(const e of events)log.append(__storedCommit(meta,e.commit),e.position,e.channel,e.value);return log;
}
// CALLER CONTRACT: arguments must match declared types; malformed data may throw or corrupt state.
// Fixed state primitives used by emitted action bodies, without an AST evaluator.
class __Abort {constructor(value){this.value=value;}}
function __preflightError(message){throw Error(message);}
function __try(value){if(Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value.Ok;}
function __nested(value,change){if(change && Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value;}
function __equal(a,b){if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object')return false;const ak=Object.keys(a),bk=Object.keys(b);return ak.length===bk.length&&ak.every(k=>Object.hasOwn(b,k)&&__equal(a[k],b[k]));}
function __checked(op,a,b,bits){const x=BigInt(a),y=BigInt(b),n=op==='checked_add'?x+y:op==='checked_sub'?x-y:x*y;const min=bits===-32?-2147483648n:0n,max=bits===-32?2147483648n:1n<<BigInt(bits);return n<min||n>=max?{Err:'ArithmeticError.Overflow'}:{Ok:Math.abs(bits)===32?Number(n):n};}
function __okOr(value,error){return Object.hasOwn(value,'Some')?{Ok:value.Some}:{Err:error};}
function __mapValue(value,kind,method,fn){
 if(kind==='list')return value[method](fn);
 if(kind==='option')return Object.hasOwn(value,'Some')?{Some:fn(value.Some)}:{None:null};
 const tag=method==='map_err'?'Err':'Ok';return Object.hasOwn(value,tag)?{[tag]:fn(value[tag])}:value;
}
const __encoder=new TextEncoder();
function __tick(ctx){if(--ctx.fuel<0)throw Error('Ink state execution budget exhausted');}
function __keyCompare(a,b,type){
 if(type.kind==='string'){let i=0,j=0;while(i<a.length&&j<b.length){const x=a.codePointAt(i),y=b.codePointAt(j);if(x!==y)return x-y;i+=x>65535?2:1;j+=y>65535?2:1;}return (i<a.length?1:0)-(j<b.length?1:0);}
 return a<b?-1:a>b?1:0;
}
// A table's ordered key view is reused until membership changes. Values are
// fetched at traversal time, so replacement never leaves stale row payloads.
const __tableOrder=new WeakMap();
function __keyPosition(keys,key,type){let low=0,high=keys.length;while(low<high){const middle=(low+high)>>>1;if(__keyCompare(keys[middle],key,type)<0)low=middle+1;else high=middle;}return low;}
function __tableMembership(rt,index,key,present){
 const view=__tableOrder.get(rt.tables[index]);if(!view)return;
 const at=__keyPosition(view.keys,key,rt.meta.roots[index].key);
 if((at<view.keys.length&&view.keys[at]===key)===present)view.pending.delete(key);
 else view.pending.set(key,present);
}
function __orderedKeys(rt,index){
 const table=rt.tables[index],type=rt.meta.roots[index].key;let view=__tableOrder.get(table);
 if(!view){view={keys:[...table.keys()].sort((a,b)=>__keyCompare(a,b,type)),pending:new Map()};__tableOrder.set(table,view);}
 if(view.pending.size){
  const changes=[...view.pending.keys()].sort((a,b)=>__keyCompare(a,b,type)),merged=[];let i=0,j=0;
  while(i<view.keys.length||j<changes.length){
   if(j===changes.length||(i<view.keys.length&&__keyCompare(view.keys[i],changes[j],type)<0))merged.push(view.keys[i++]);
   else{const key=changes[j++];if(i<view.keys.length&&view.keys[i]===key)i++;if(view.pending.get(key))merged.push(key);}
  }
  view.keys=merged;view.pending.clear();
 }
 const keys=view.keys;
 const cell=rt.cell;
 if(cell&&cell.index===index&&table.has(cell.key)!==(cell.next!==undefined)){
  if(cell.next===undefined)return keys.filter(k=>k!==cell.key);
  const at=__keyPosition(keys,cell.key,type);return [...keys.slice(0,at),cell.key,...keys.slice(at)];
 }
 return keys;
}
function __cellGet(rt,index,key){const cell=rt.cell;return cell&&cell.index===index&&cell.key===key?cell.next:rt.tables[index].get(key);}
function __readTable(rt,index){const cell=rt.cell;if(!cell||cell.index!==index)return rt.tables[index];const table=new Map(rt.tables[index]);if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);return table;}
// The first before-image of each cell suffices for whole-transaction rollback.
function __remember(rt,index,key,present,value){if(rt.cellMode)return;if(!rt.seen[index].has(key)){rt.seen[index].add(key);rt.undo.push([index,key,present,value]);}}
// Immutable keeps retain private values. Public results remain owned copies.
// Reverse edges come from checked source effects.
// Before-images preserve cached values across failed actions; host rollback and
// restore discard caches rather than serializing them into logical snapshots.
function __invalidateKeeps(rt,index){
 if(rt.observers?.active)rt.changedRoots.add(index);
 if(!rt.keeps||rt.cellMode)return;
 for(const keep of rt.meta.keepInvalidations[index]){
  if(!rt.keepDirty[keep]){rt.keepDirty[keep]=1;rt.keepUndoIndices[rt.keepUndoCount++]=keep;rt.keepBefore[keep]=rt.keeps[keep];}
  rt.keeps[keep]=undefined;
 }
}
function __restoreKeeps(rt){for(let i=rt.keepUndoCount-1;i>=0;i--){const keep=rt.keepUndoIndices[i];rt.keeps[keep]=rt.keepBefore[keep];}__refreshActiveViews(rt);}
function __clearKeepJournal(rt){for(let i=0;i<rt.keepUndoCount;i++){const keep=rt.keepUndoIndices[i];rt.keepDirty[keep]=0;rt.keepBefore[keep]=undefined;}rt.keepUndoCount=0;}
function __rebuildViews(rt){
 rt.activeViewRoots=new Uint8Array(rt.meta.roots.length);
 for(const view of rt.views){rt.keeps[view.keep]=undefined;if(!rt.meta.lazyMaintenance)__viewBase(rt,view);}
}
function __refreshActiveViews(rt){rt.activeViewRoots.fill(0);for(const view of rt.views)if(rt.keeps[view.keep]!==undefined)rt.activeViewRoots[view.root]=1;}
function __viewBase(rt,view){
 if(rt.keeps[view.keep]===undefined){let value=view.zero;for(const [key,row]of rt.tables[view.root])value=view.combine(value,view.contribution(key,row));rt.keeps[view.keep]=value;rt.activeViewRoots[view.root]=1;}
 return rt.keeps[view.keep];
}
function __viewValue(view,value,key,oldValue,newValue){
 if(oldValue===undefined)return view.insert?view.insert(value,key,newValue):view.combine(value,view.contribution(key,newValue));
 if(newValue===undefined)return view.remove?view.remove(value,key,oldValue):view.combine(value,view.inverse(view.contribution(key,oldValue)));
 return view.replace?view.replace(value,key,oldValue,newValue):view.combine(view.combine(value,view.inverse(view.contribution(key,oldValue))),view.contribution(key,newValue));
}
function __updateViews(rt,index,key,oldValue,newValue){
 if(!rt.activeViewRoots[index])return null;
 const updates=rt.viewNext;
 for(const view of rt.viewsByRoot[index])updates[view.keep]=rt.keeps[view.keep]===undefined?undefined:__viewValue(view,rt.keeps[view.keep],key,oldValue,newValue);
 return updates;
}
function __installViews(rt,updates,index){if(updates)for(const view of rt.viewsByRoot[index])rt.keeps[view.keep]=updates[view.keep];}
function __pendingView(rt,view){
 const keep=view.keep;
 if(rt.pendingValues[keep]===undefined){
  const cell=rt.cell;
  rt.pendingValues[keep]=__viewValue(view,__viewBase(rt,view),cell.key,cell.prior,cell.next);
  rt.pendingIndices.push(keep);
 }
 return rt.pendingValues[keep];
}
function __prepareCell(rt){if(rt.cell&&rt.activeViewRoots[rt.cell.index]){const prepare=rt.views.prepareRoots?.[rt.cell.index];if(prepare)prepare(rt,rt.cell);else for(const view of rt.viewsByRoot[rt.cell.index])if(rt.keeps[view.keep]!==undefined)__pendingView(rt,view);}}
function __invalidateSnapshotRow(rt,index,key){rt.snapshotRows?.[index].delete(key);}
function __writeCell(rt,index,key,next,prior){
 if(rt.cellMode){if(rt.cell)throw Error('checked single-cell bound exceeded');rt.cell={index,key,next,prior};}
 else{const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);if(rt.changeTracking)__recordChange(rt,index,key,prior,next);if((prior!==undefined)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);if(next===undefined)table.delete(key);else table.set(key,next);}
}
function __commitCell(rt){
 const cell=rt.cell;if(!cell)return;
 const table=rt.tables[cell.index];__invalidateSnapshotRow(rt,cell.index,cell.key);
 if(rt.changeTracking)__recordChange(rt,cell.index,cell.key,cell.prior,cell.next);
 if((cell.prior!==undefined)!==(cell.next!==undefined))__tableMembership(rt,cell.index,cell.key,cell.next!==undefined);
 if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);
 for(const keep of rt.meta.keepInvalidations[cell.index])rt.keeps[keep]=rt.pendingValues[keep];
 rt.cell=null;
}
// Preflight scratch has no logical state or rollback obligations. Definitions
// are the same admitted group operations used by ordinary cell maintenance.
function __prepareDirect(rt,index,key,prior,next){
 const prepare=rt.views.directRoots?.[index];
 if(prepare)prepare(rt,key,prior,next);
 else for(const view of rt.viewsByRoot[index])rt.viewNext[view.keep]=__viewValue(view,rt.keeps[view.keep],key,prior,next);
}
function __storeDirect(rt,index,key,prior,next,slot){
 const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);
 if((prior!==undefined)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);
 if(rt.changeTracking)__recordChange(rt,index,key,prior,next);
 if(slot===undefined){if(next===undefined)table.delete(key);else table.set(key,next);}
 else{
  // The checked preflight lookup retains the dense slot until this commit.
  // No callback or source write can intervene; sparse keys retain exact identity.
  if(slot<0){if(next===undefined)table.sparse.delete(key);else table.sparse.set(key,next);}else table.dense[slot]=next;
  if(prior===undefined&&next!==undefined)table.members.add(key);else if(prior!==undefined&&next===undefined)table.members.delete(key);
 }
}
function __commitDirect(rt,index,key,prior,next,slot){
 __storeDirect(rt,index,key,prior,next,slot);
 const publishOutputs=rt.meta.outputPublication&&!rt.observers.directRoots[index]&&rt.observers.active;
 if(publishOutputs&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}

 for(const keep of rt.meta.keepInvalidations[index]){
  const value=rt.viewByKeep[keep]?rt.viewNext[keep]:undefined;
  if(publishOutputs)rt.changedOutputs[keep]=rt.keeps[keep]!==value?rt.changedOutputEpoch:0;
  rt.keeps[keep]=value;
 }
}
function __emit(rt,channel,value){
 if(rt.eventCount++===0){rt.eventChannel=channel;rt.eventValue=value;}
 else rt.staged.push([channel,value]);
}
// Checked prefix capacities are at most 2^20. Number conversion is exact
// inside that prefix; rounding a wide word cannot move it into the prefix.
// Wide keys retain their original full-width value in the sparse fallback.
class __DenseTable{
 constructor(capacity){this.limit=capacity;this.dense=[];for(let i=0;i<capacity;i++)this.dense.push(undefined);this.sparse=new Map();this.members=new Set();}
 clear(){this.dense.fill(undefined);this.sparse.clear();this.members.clear();__tableOrder.delete(this);return this;}
 slot(key){const i=Number(key);return Number.isInteger(i)&&i>=0&&i<this.limit?i:-1;}
 get size(){return this.members.size;}
 get(key){const i=this.slot(key);return i<0?this.sparse.get(key):this.dense[i];}
 has(key){return this.get(key)!==undefined;}
 set(key,value){const i=this.slot(key),present=i<0?this.sparse.has(key):this.dense[i]!==undefined;if(i<0)this.sparse.set(key,value);else this.dense[i]=value;if(!present)this.members.add(key);return this;}
 delete(key){const i=this.slot(key);if(i<0)this.sparse.delete(key);else this.dense[i]=undefined;return this.members.delete(key);}
 keys(){return this.members.keys();}
 *values(){for(const key of this.members)yield this.get(key);}
 *entries(){for(const key of this.members)yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
class __ColumnTable {
 constructor(root){
  this.limit=root.columnPrefix.capacity;this.keyBig=root.key.kind==='u64';
  this.fields=root.value.fields;this.exactNumbers=root.columnPrefix.exactNumbers;
  this.present=new Uint8Array(this.limit);this.count=0;this.sparse=new Map();
  this.lanes=this.fields.map(f=>f.type.kind==='u64'?(this.exactNumbers?new Float64Array(this.limit):new BigUint64Array(this.limit)):f.type.kind==='i32'?new Int32Array(this.limit):f.type.kind==='bool'?new Uint8Array(this.limit):new Uint32Array(this.limit));
  this.wide=this.fields.map(f=>f.type.kind==='u64'&&this.exactNumbers?new Map():null);
 }
 slot(key){const i=Number(key);return Number.isInteger(i)&&i>=0&&i<this.limit?i:-1;}
 get size(){return this.count+this.sparse.size;}
 has(key){const i=this.slot(key);return i<0?this.sparse.has(key):this.present[i]!==0;}
 get(key){const i=this.slot(key);if(i<0)return this.sparse.get(key);if(!this.present[i])return undefined;const row=Object.create(null);for(let j=0;j<this.fields.length;j++){const f=this.fields[j],v=this.lanes[j][i];row[f.name]=f.type.kind==='bool'?v!==0:f.type.kind==='u64'&&this.exactNumbers?(this.wide[j].get(i)??BigInt(v)):v;}return row;}
 set(key,row){const i=this.slot(key);if(i<0){this.sparse.set(key,row);return this;}for(let j=0;j<this.fields.length;j++){const f=this.fields[j],v=row[f.name];if(f.type.kind==='u64'&&this.exactNumbers){if(v<=9007199254740991n){this.lanes[j][i]=Number(v);this.wide[j].delete(i);}else{this.lanes[j][i]=0;this.wide[j].set(i,v);}}else this.lanes[j][i]=f.type.kind==='bool'?Number(v):v;}if(!this.present[i]){this.present[i]=1;this.count++;}return this;}
 delete(key){const i=this.slot(key);if(i<0)return this.sparse.delete(key);if(!this.present[i])return false;this.present[i]=0;this.count--;for(const wide of this.wide)wide?.delete(i);return true;}
 *keys(){for(let i=0;i<this.limit;i++)if(this.present[i])yield this.keyBig?BigInt(i):i;yield* this.sparse.keys();}
 *values(){for(const key of this.keys())yield this.get(key);}
 *entries(){for(const key of this.keys())yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
function __newTables(meta,prefixes,old,spares){return meta.roots.map((root,i)=>{const prior=spares?.[i];const t=root.columnPrefix?new __ColumnTable(root):prefixes[i]?(prior instanceof __DenseTable&&prior.limit===prefixes[i]?prior.clear():new __DenseTable(prefixes[i])):new Map();if(old)for(const [k,v]of old[i])t.set(k,v);return t;});}
// Only inactive containers are reused. Consume the spare before preparation so
// a failed invariant/rebuild cannot expose its partially reconstructed contents.
// Rows remain immutable; the current logical state changes only at installation.
function __restoreTables(rt,prefixes,old){const spares=rt.restoreSpares;rt.restoreSpares=null;return __newTables(rt.meta,prefixes,old,spares);}
function __cachedKeep(ctx,rt,index,compute){
 if(rt.cell&&rt.meta.keepInvalidations[rt.cell.index].includes(index)){
  const view=rt.viewByKeep[index];
  if(view)return __pendingView(rt,view);
  if(rt.pendingValues[index]===undefined){rt.pendingValues[index]=compute(ctx,rt);rt.pendingIndices.push(index);}
  return rt.pendingValues[index];
 }
 const prior=rt.keeps[index];if(prior!==undefined)return prior;
 const view=rt.viewByKeep[index];if(view)return __viewBase(rt,view);
 const value=compute(ctx,rt);rt.keeps[index]=value;return value;
}
function __tableContains(rt,index,key){return __cellGet(rt,index,key)!==undefined;}
function __tableGet(rt,index,key){const value=__cellGet(rt,index,key);return value===undefined?{None:null}:{Some:value};}
function __tablePut(rt,index,key,next,mode=0){
 const prior=rt.tables[index].get(key),present=prior!==undefined;
 if(mode===1&&present)throw Error('insert key already present');
 if(mode===2&&!present)throw Error('replace key absent');
 if(present&&__stateRootEquals[index](prior,next))return null;
 const updates=rt.cellMode?null:__updateViews(rt,index,key,prior,next);
 __invalidateKeeps(rt,index);__remember(rt,index,key,present,prior);
 __writeCell(rt,index,key,next,prior);__installViews(rt,updates,index);return null;
}
function __tableRemove(rt,index,key){
 const value=rt.tables[index].get(key);
 if(value===undefined)return {None:null};
 const updates=rt.cellMode?null:__updateViews(rt,index,key,value,undefined);
 __invalidateKeeps(rt,index);__remember(rt,index,key,true,value);
 __writeCell(rt,index,key,undefined,value);__installViews(rt,updates,index);return {Some:value};
}
function __table(rt,index,method,args){
 const key=args[0];
 if(method==='get')return __tableGet(rt,index,key);
 if(method==='contains')return __tableContains(rt,index,key);
 const table=rt.tables[index];
 if(method==='values'||method==='keys'){const keys=__orderedKeys(rt,index);return method==='keys'?keys.slice():keys.map(k=>__cellGet(rt,index,k));}
 if(method==='intersect_table'){const current=__readTable(rt,index),other=__readTable(rt,args[0]),small=current.size<=other.size?current:other,large=small===current?other:current;const result=[];for(const k of small.keys())if(large.has(k))result.push(k);return result.sort((a,b)=>__keyCompare(a,b,rt.meta.roots[index].key));}
 if(method==='intersect_keys'){const requested=args[0],size=rt.tables[index].size;
  // Fewer requested keys than rows: look each one up instead of scanning.
  if(requested.length<size){const type=rt.meta.roots[index].key;return [...new Set(requested)].filter(k=>__cellGet(rt,index,k)!==undefined).sort((a,b)=>__keyCompare(a,b,type));}
  const selected=new Set(requested);return __orderedKeys(rt,index).filter(k=>selected.has(k));}
 if(method==='put_many'){const keys=args[0],values=args[1];if(keys.length!==values.length)return {Err:'table bulk length mismatch'};for(let i=0;i<keys.length;i++)__table(rt,index,'put',[keys[i],values[i]]);return {Ok:null};}
 if(method==='remove_many'){for(const k of args[0])__table(rt,index,'remove',[k]);return null;}
 if(method==='remove')return __tableRemove(rt,index,key);
 return __tablePut(rt,index,key,args[1],method==='insert'?1:method==='replace'?2:0);
}

function __rollback(rt,mark){for(let i=rt.undo.length-1;i>=mark;i--){const [index,key,present,value]=rt.undo[i];const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);if(table.has(key)!==present)__tableMembership(rt,index,key,present);if(present)table.set(key,value);else table.delete(key);}rt.undo.length=mark;}
function __recordChange(rt,index,key,prior,next){rt.changeLog.push([index,key,prior,next]);}
function __fixedTableBytes(root,table){
 const writer=__snapshotWriter(__snapshotLimits());
 const rows=[...table.entries()].sort((a,b)=>__keyCompare(a[0],b[0],root.key));
 writer.integer(rows.length,8);
 for(const [key,value]of rows){writer.value(key,root.snapshotKey??root.key);writer.value(value,root.snapshotValue??root.value);}
 return writer.finish();
}
function __createState(meta,implementations,captures=null,views=[],prefixes=[]){
 const rt={meta,tables:__newTables(meta,prefixes),version:meta.compactCommits?0:0n,outbox:__eventLog(meta),staged:[],busy:false,undo:[],seen:meta.roots.map(()=>new Set()),host:null,keeps:new Array(meta.keeps.length),keepDirty:meta.keeps.length?new Uint8Array(meta.keeps.length):null,keepUndoIndices:meta.keeps.length?new Uint32Array(meta.keeps.length):null,keepUndoCount:0};
 const fixed=typeof __stateFrozenFactories==='undefined'?[]:__stateFrozenFactories;
 const fixedBytes=[];
 for(let i=0;i<fixed.length;i++)if(fixed[i]){for(const [key,value]of fixed[i]())rt.tables[i].set(key,value);fixedBytes[i]=__fixedTableBytes(meta.roots[i],rt.tables[i]);}
 function checkFixed(tables){for(let i=0;i<fixedBytes.length;i++)if(fixedBytes[i]){const bytes=__fixedTableBytes(meta.roots[i],tables[i]);if(bytes.length!==fixedBytes[i].length||!bytes.every((v,n)=>v===fixedBytes[i][n]))throw Error('snapshot changes frozen state: '+meta.roots[i].name);}}
 rt.views=views;rt.viewsByRoot=meta.roots.map((_,root)=>views.filter(v=>v.root===root));__rebuildViews(rt);
 rt.viewByKeep=new Array(meta.keeps.length);for(const view of views)rt.viewByKeep[view.keep]=view;
 rt.pendingIndices=[];rt.pendingValues=new Array(meta.keeps.length);
 rt.eventCount=0;rt.eventChannel=null;rt.eventValue=null;
 rt.viewNext=new Array(meta.keeps.length);rt.cell=null;rt.cellMode=false;rt.ctx={fuel:100000000};
 rt.keepBefore=meta.keeps.length?new Array(meta.keeps.length):null;
 rt.changedRoots=new Set();rt.changedOutputs=new Array(meta.keeps.length).fill(0);rt.changedOutputEpoch=0;
 rt.snapshotRows=meta.snapshotRows?meta.roots.map(()=>new Map()):null;
 rt.restoreSpares=null;rt.changeTracking=false;rt.changeLog=[];rt.changeEpoch=0;rt.changeTokens=new Map();
 const actionMap=new Map(meta.actions.map(a=>[a.name,{...a,inputs:captures?captures[a.index]:a.params.map(p=>__stateCapture(p.type)),output:__stateResult(a.result)}]));
 const eventOutput=new Map(meta.events.map(e=>[e.name,__stateResult(e.type)]));
 rt.eventOutput=eventOutput;
 const prepared=new WeakMap();
 const observers=rt.observers=__createObservers((name,args)=>{
  const a=actionMap.get(name);if(!a||a.change)throw Error('subscription requires a readonly query');
  const captured=a.inputs.map((convert,i)=>convert(args[i]));
  const publicArgs=captured.map((v,i)=>__stateResult(a.params[i].type)(v));
  const scalar=['u64','u32','i32','bool','string','unit','enum','id'].includes(a.result.kind);
  return {scalar,committed:scalar&&a.directKeep!==null&&a.directKeep!==undefined?{state:rt,keep:a.directKeep}:null,direct:scalar&&a.directKeep!==null&&a.directKeep!==undefined?()=>rt.keeps[a.directKeep]:null,roots:a.roots,outputs:rt.meta.outputPublication&&a.directKeep!==null&&a.directKeep!==undefined?[a.directKeep]:[],read:!a.precondition&&a.params.length===0?readZero(a,true):()=>run(a,publicArgs,null,null,true),capture:scalar?v=>v:__stateCapture(a.result),output:scalar?v=>v:a.output,equal:__stateQueryEquals[a.index]};
 });
 function invoke(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);return run(a,args);}
 function readZero(a,resultOnly){
  const implementation=implementations[a.index],output=a.output,fresh=a.freshResult;
  if(resultOnly&&fresh&&__stateDirectReadFactories[a.index])return __stateDirectReadFactories[a.index](rt);
  if(a.directKeep!==null&&a.directKeep!==undefined)return ()=>{
   if(rt.busy)throw Error('state operation already in progress');
   const value=rt.keeps[a.directKeep],result=fresh?value:output(value);
   return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};
  };
  return ()=>{
   if(rt.busy)throw Error('state operation already in progress');rt.busy=true;rt.ctx.fuel=100000000;
   try{const value=implementation(rt.ctx,rt),result=fresh?value:output(value);return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};}
   finally{rt.busy=false;}
  };
 }
 function read(a,args,inputs,output,resultOnly,owned=false){
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  rt.busy=true;
  try{const value=implementations[a.index](ctx,rt,...captured),result=a.freshResult?value:(output||a.output)(value);return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};}
  finally{rt.busy=false;}
 }
 function begin(a){
  if(rt.busy)throw Error('state operation already in progress');
  rt.ctx.fuel=100000000;
  rt.actionMark=rt.undo.length;rt.actionVersion=rt.version;rt.actionOutbox=rt.outbox;rt.actionOutboxLength=rt.outbox.length;rt.actionChangeMark=rt.changeLog.length;
  rt.busy=true;rt.cellMode=a.singleCell&&!rt.host;rt.staged.length=0;rt.eventCount=0;rt.changedRoots.clear();rt.actionSuccessful=false;
 }
 function complete(a,value,output,resultOnly){
  const result=a.freshResult?value:(output||a.output)(value);
  const version=rt.actionVersion;
  if(a.fallible && (a.flatFailure?value.tag!==0:Object.hasOwn(value,'Err'))){rt.changeLog.length=rt.actionChangeMark;__rollback(rt,rt.actionMark);__restoreKeeps(rt);if(rt.host?.strict)rt.host.failure=Object.assign(Error('transaction action failed'),{action:a.name,result});return resultOnly?result:{result,committed:false,version:__versionWord(version),events:[]};}
  if(version===18446744073709551615n)throw Error('commit sequence exhausted');
  const next=rt.meta.compactCommits?__nextCommit(version):version+1n;
  const publicNext=resultOnly?null:__versionWord(next);
  __prepareCell(rt);
  const events=resultOnly?null:new Array(rt.eventCount);
  if(rt.eventCount){
   const channel=rt.eventChannel,value=rt.eventValue;
   rt.outbox.push({commit:next,position:0n,channel,value});
   if(events)events[0]={commit:publicNext,position:0n,channel,value:eventOutput.get(channel)(value)};
   for(let i=0;i<rt.staged.length;i++){
    const [channel,value]=rt.staged[i],position=BigInt(i+1);
    rt.outbox.push({commit:next,position,channel,value});
    if(events)events[i+1]={commit:publicNext,position,channel,value:eventOutput.get(channel)(value)};
   }
  }
  __commitCell(rt);rt.version=next;rt.actionSuccessful=true;
  return resultOnly?result:{result,committed:true,version:publicNext,events};
 }
 function abort(e){
  rt.changeLog.length=rt.actionChangeMark;__rollback(rt,rt.actionMark);__restoreKeeps(rt);rt.version=rt.actionVersion;rt.outbox=rt.actionOutbox;rt.outbox.length=rt.actionOutboxLength;if(rt.host?.strict)rt.host.failure=e;throw e;
 }
 function end(){
  const successful=rt.actionSuccessful,single=rt.cellMode;
  rt.cell=null;rt.cellMode=false;rt.staged.length=0;rt.eventCount=0;rt.eventChannel=null;rt.eventValue=null;
  for(const keep of rt.pendingIndices)rt.pendingValues[keep]=undefined;rt.pendingIndices.length=0;
  if(!single){__clearKeepJournal(rt);for(const seen of rt.seen)seen.clear();if(!rt.host)rt.undo.length=0;}
  rt.actionOutbox=null;rt.busy=false;
  if(successful)observers.commit(rt.changedRoots);
 }
 function run(a,args,inputs=null,output=null,resultOnly=false,owned=false){
  if(a.kernels&&!rt.host){
   if(rt.busy)throw Error('state operation already in progress');
   const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
   return a.kernels[resultOnly?1:0](...captured);
  }
  if(!a.change)return read(a,args,inputs,output,resultOnly,owned);
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  begin(a);
  try{return complete(a,implementations[a.index](ctx,rt,...captured),output,resultOnly);}
  catch(e){return abort(e);}
  finally{end();}
 }

 for(const a of actionMap.values())if(__statePreflightFactories[a.index]){
  // run() supplies module-owned captured values; bound native entries still capture composites.
  a.kernels=[false,true].map(only=>__statePreflightFactories[a.index](run,a,a.inputs,a.output,only,rt,begin,complete,abort,end,true));
 }
 return Object.freeze({
  subscribeValues(queries,callback,options){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribeValues(queries,callback,options);},
  subscribeGroup(queries,callback,options){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribeGroup(queries,callback,options);},
  subscribe(...args){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribe(...args);},
  batch:observers.batch,flushSubscriptions:observers.flush,takeSubscriptionErrors:observers.takeErrors,
  transaction(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('transaction callback must be synchronous');this.beginTransaction();rt.host.strict=true;
   try{const value=callback(this);if(value&&typeof value.then==='function')throw TypeError('state transaction callback must be synchronous');this.commitTransaction();return value;}catch(e){this.rollbackTransaction();throw e;}
  },
  invoke,invoke_json:invoke,
  prepare(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);const captured=a.inputs.map((convert,i)=>convert(args[i])),token=Object.freeze({});prepared.set(token,{action:a,args:captured});return token;},
  invokePrepared(token){const packet=prepared.get(token);if(!packet)throw Error('invalid prepared state call');return run(packet.action,packet.args,null,null,false,true);},
  // A prebound typed entrypoint: scalar arguments obey the native caller contract.
  // Composite arguments still capture owned input; events remain in the outbox.
  bind(name,{resultOnly=false}={}){
   const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);
   const inputs=a.params.map((p,i)=>['u32','i32','u64','bool','unit','string','f32','f64','id','enum','int'].includes(p.type.kind)?__representation(p.type,false):a.inputs[i]);
   if(!a.change&&!a.precondition&&inputs.length===0)return readZero(a,resultOnly);
   return (__statePreflightFactories[a.index]||__stateBoundFactories[a.index])(run,a,inputs,a.output,resultOnly,rt,begin,complete,abort,end);
  },
  beginTransaction(){if(rt.busy||rt.host||rt.undo.length)throw Error('transaction already in progress');rt.host={version:rt.version,outbox:rt.outbox,length:rt.outbox.length,keeps:rt.keeps.slice(),changeMark:rt.changeLog.length,notificationMark:observers.hold()};return true;},
  commitTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');if(rt.host.failure)throw rt.host.failure;rt.host=null;rt.undo.length=0;observers.release();},
  rollbackTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');__rollback(rt,0);rt.version=rt.host.version;rt.outbox=rt.host.outbox;rt.outbox.length=rt.host.length;rt.keeps=rt.host.keeps;__refreshActiveViews(rt);rt.changeLog.length=rt.host.changeMark;rt.changeEpoch++;const mark=rt.host.notificationMark;rt.host=null;observers.rollback(mark);},
  changeToken(){
   if(rt.busy||rt.host)throw Error('change token requires transaction boundary');
   const token=Object.freeze({});rt.changeTracking=true;rt.changeTokens.set(token,{epoch:rt.changeEpoch,index:rt.changeLog.length,version:__versionWord(rt.version)});return token;
  },
  releaseChangeToken(token){rt.changeTokens.delete(token);if(!rt.changeTokens.size){rt.changeTracking=false;rt.changeLog.length=0;}},
  changesSince(token){
   if(rt.busy||rt.host)throw Error('changes require transaction boundary');
   const mark=rt.changeTokens.get(token);if(!mark||mark.epoch!==rt.changeEpoch)throw Error('invalid change token lineage');
   const roots=new Map();
   for(let i=mark.index;i<rt.changeLog.length;i++){
    const [root,key,before,after]=rt.changeLog[i];let cells=roots.get(root);if(!cells)roots.set(root,cells=new Map());
    const prior=cells.get(key);if(prior)prior.after=after;else cells.set(key,{before,after});
   }
   const changes=[];
   const codecs=rt.changeOutputs??=meta.roots.map(schema=>({key:__stateResult(schema.key),row:__stateResult(schema.value)}));
   for(const [root,cells]of roots){const schema=meta.roots[root],keyOut=codecs[root].key,rowOut=codecs[root].row;
    for(const [key,{before,after}]of cells){if(before===undefined&&after===undefined||before!==undefined&&after!==undefined&&__stateRootEquals[root](before,after))continue;
     changes.push({table:schema.name,key:keyOut(key),before:before===undefined?{None:null}:{Some:rowOut(before)},after:after===undefined?{None:null}:{Some:rowOut(after)}});
    }
   }
   return {from:mark.version,to:__versionWord(rt.version),changes};
  },
  get version(){return __versionWord(rt.version);},
  get outbox(){return rt.outbox.map(e=>({...e,commit:__versionWord(e.commit),value:eventOutput.get(e.channel)(e.value)}));},
  acknowledgeThrough(commit,position){if(rt.busy)throw Error('state operation already in progress');commit=__stateWord(commit);position=__stateWord(position);const last=rt.outbox.at(-1);if(!last)return;const lastCommit=__versionWord(last.commit);if(lastCommit<commit||(lastCommit===commit&&last.position<=position)){if(rt.host)rt.outbox=__eventLog(meta);else rt.outbox.length=0;return;}rt.outbox=rt.outbox.filter(e=>{const c=__versionWord(e.commit);return c>commit||(c===commit&&e.position>position);});},
  async invokeAsync(name,args){
   if(typeof __parallelInvokeAsync!=='function')return invoke(name,args);
   if(rt.busy||rt.host)throw Error('parallel state call requires transaction boundary');const captured=structuredClone(args);rt.busy=true;observers.hold();let completed=false;
   try{const snapshot=await __snapshotEncode(meta,rt);const reply=await __parallelInvokeAsync(name,captured,snapshot);const s=await __snapshotDecode(meta,reply.snapshot);checkFixed(s.tables);const candidate={...rt,tables:__restoreTables(rt,prefixes,s.tables),keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);const previousTables=rt.tables;rt.tables=candidate.tables;rt.restoreSpares=previousTables.map(table=>table instanceof __DenseTable?table:null);rt.version=__storedCommit(meta,s.version);rt.outbox=__eventLog(meta,s.outbox);rt.keeps=candidate.keeps;rt.activeViewRoots=candidate.activeViewRoots;if(rt.snapshotRows)rt.snapshotRows=meta.roots.map(()=>new Map());rt.changeEpoch++;rt.changeLog.length=0;completed=true;return reply.value;}finally{rt.busy=false;if(completed)observers.commit(meta.roots.map((_,i)=>i));observers.release();}
  },
  checkpoint(limits){if(rt.busy)throw Error('checkpoint requires transaction boundary');return __snapshotEncode(meta,rt,limits);},
  async restore(bytes,limits){if(rt.host)throw Error('restore during transaction');if(rt.busy)throw Error('restore requires transaction boundary');rt.busy=true;rt.ctx.fuel=100000000;observers.hold();let restored=false;try{const s=await __snapshotDecode(meta,bytes,limits);checkFixed(s.tables);const candidate={...rt,tables:__restoreTables(rt,prefixes,s.tables),version:__storedCommit(meta,s.version),outbox:s.outbox,keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);for(const name of meta.invariantChecks||[]){const a=actionMap.get(name);if(implementations[a.index](rt.ctx,candidate)!==true)throw Error('snapshot violates state invariant');}const previousTables=rt.tables;rt.tables=candidate.tables;rt.restoreSpares=previousTables.map(table=>table instanceof __DenseTable?table:null);rt.version=__storedCommit(meta,s.version);rt.outbox=__eventLog(meta,s.outbox);rt.keeps=candidate.keeps;rt.activeViewRoots=candidate.activeViewRoots;if(rt.snapshotRows)rt.snapshotRows=meta.roots.map(()=>new Map());rt.changeEpoch++;rt.changeLog.length=0;restored=true;}finally{rt.busy=false;if(restored)observers.commit(meta.roots.map((_,i)=>i));observers.release();}},
 });
}
function __stateCommitRoot0(rt,key,prior,next,slot){__storeDirect(rt,0,key,prior,next,slot);const publish=rt.meta.outputPublication&&!rt.observers.directRoots[0]&&rt.observers.active;if(publish&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}}
const __stateDirectReadFactories=[];
const __stateFrozenFactories=[];
const __stateQueryEquals=[];
const __stateRootEquals=[(a,b)=>(a===b)];
const __stateBoundFactories=[];const __statePreflightFactories=[];
const __stateMetadata={"actions":[],"compactCommits":false,"eventColumns":false,"eventRuns":false,"events":[],"invariantChecks":[],"keepInvalidations":[[]],"keeps":[],"lazyMaintenance":true,"outputPublication":false,"roots":[{"key":{"kind":"u32"},"name":"Marker","snapshotKey":{"kind":"u32"},"snapshotValue":{"kind":"u32"},"value":{"kind":"u32"}}],"snapshot":{"program":[137,55,217,128,15,101,161,50,77,83,105,254,16,140,180,231,68,171,171,65,112,149,170,242,60,12,104,203,147,9,253,245],"schema":[196,247,80,84,87,17,213,56,238,178,201,57,97,234,20,236,122,223,66,56,116,100,23,158,186,91,87,145,246,71,151,250]},"snapshotRows":false};const __actions=[];const __stateInputCaptures=[];
export function createState(){return __createState(__stateMetadata,__actions,__stateInputCaptures);}
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v15","core_sha256":"3b30c5d3bdff97671d6baa8be005404cfcbd199e20339be260176ac4ce00e355","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"f32_storage":"exact-u32-bits","functions":[{"destination":null,"index":0,"internal":false,"name":"device_value","parallel":false,"params":[{"name":"Alias","type":{"fields":[{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"DevicePoint"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":1,"internal":false,"name":"exclusive","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":2,"internal":false,"name":"inclusive","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":3,"internal":false,"name":"exclusive_value","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":4,"internal":false,"name":"exclusive_gradient","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":5,"internal":false,"name":"inclusive_value","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":6,"internal":false,"name":"inclusive_gradient","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":7,"internal":false,"name":"device","parallel":false,"params":[{"name":"xs","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":8,"internal":false,"name":"__ink_reverse_0_constant","parallel":false,"params":[{"name":"value","type":{"kind":"f32"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"destination":null,"index":9,"internal":true,"name":"__ink_reverse_0_append","parallel":false,"params":[{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"node","type":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"}},{"name":"active","type":{"kind":"bool"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":10,"internal":true,"name":"__ink_reverse_0_seed","parallel":false,"params":[{"name":"value","type":{"kind":"f32"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":11,"internal":true,"name":"__ink_reverse_0_binary","parallel":false,"params":[{"name":"op","type":{"kind":"u32"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":12,"internal":true,"name":"__ink_reverse_0_unary","parallel":false,"params":[{"name":"op","type":{"kind":"u32"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":13,"internal":true,"name":"__ink_reverse_0_add","parallel":false,"params":[{"name":"g","type":{"kind":"temporary"}},{"name":"id","type":{"kind":"u32"}},{"name":"value","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"temporary"}},{"destination":null,"index":14,"internal":true,"name":"__ink_reverse_0_back_node","parallel":false,"params":[{"name":"node","type":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"}},{"name":"amount","type":{"kind":"f32"}},{"name":"g","type":{"kind":"temporary"}}],"precondition":null,"result":{"kind":"temporary"}},{"destination":null,"index":15,"internal":true,"name":"__ink_reverse_0_back_step","parallel":false,"params":[{"name":"node","type":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"}},{"name":"work","type":{"fields":[{"name":"gradient","type":{"kind":"temporary"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Reverse"}},{"name":"stopZero","type":{"kind":"bool"}}],"precondition":null,"result":{"fields":[{"name":"gradient","type":{"kind":"temporary"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Reverse"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":16,"internal":false,"name":"__ink_reverse_0_backward","parallel":false,"params":[{"name":"nodes","type":{"element":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"kind":"list"}},{"name":"output","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"stopZero","type":{"kind":"bool"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":17,"internal":true,"name":"__ink_reverse_1","parallel":false,"params":[{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"__ink_reverse_2","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":18,"internal":false,"name":"__ink_reverse_24","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}},{"name":"__ink_reverse_19","type":{"kind":"u32"}},{"name":"__ink_reverse_20","type":{"kind":"bool"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_25"}}},{"destination":null,"index":19,"internal":true,"name":"__ink_reverse_26","parallel":false,"params":[{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"__ink_reverse_27","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":20,"internal":false,"name":"__ink_reverse_53","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}},{"name":"__ink_reverse_48","type":{"kind":"u32"}},{"name":"__ink_reverse_49","type":{"kind":"bool"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_54"}}}],"named_types":{"Alias":{"fields":[{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"Alias"},"DevicePoint":{"fields":[{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"DevicePoint"},"__ink_reverse_0_Flow":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"},"__ink_reverse_0_Node":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"__ink_reverse_0_Reverse":{"fields":[{"name":"gradient","type":{"kind":"temporary"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Reverse"},"__ink_reverse_0_Tape":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"},"__ink_reverse_0_Wire":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"__ink_reverse_14":{"fields":[{"name":"value","type":{"kind":"bool"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_14"},"__ink_reverse_25":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_25"},"__ink_reverse_28":{"fields":[{"name":"value","type":{"kind":"u64"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_28"},"__ink_reverse_3":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_3"},"__ink_reverse_33":{"fields":[{"name":"value","type":{"element":{"kind":"u64"},"kind":"list"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_33"},"__ink_reverse_36":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"stopped","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_36"},"__ink_reverse_54":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_54"},"__ink_reverse_6":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"stopped","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_6"}},"prepared_compiled":{"evaluation":"lazy source-order; successful bindings only","functions":[{"factory":false,"function":"device_value","reason":"no reusable captured work"},{"factory":false,"function":"exclusive","reason":"no reusable captured work"},{"factory":false,"function":"inclusive","reason":"no reusable captured work"},{"delegated_calls":1,"factory":true,"function":"exclusive_value","retained_bindings":0},{"delegated_calls":1,"factory":true,"function":"exclusive_gradient","retained_bindings":0},{"delegated_calls":1,"factory":true,"function":"inclusive_value","retained_bindings":0},{"delegated_calls":1,"factory":true,"function":"inclusive_gradient","retained_bindings":0},{"factory":false,"function":"device","reason":"no reusable captured work"},{"factory":false,"function":"__ink_reverse_0_constant","reason":"no reusable captured work"},{"factory":false,"function":"__ink_reverse_0_append","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_seed","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_binary","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_unary","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_add","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_back_node","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_back_step","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_backward","reason":"no reusable lexical bindings"},{"factory":false,"function":"__ink_reverse_1","reason":"prepared residual requires a bounded pure value entry"},{"delegated_calls":1,"factory":true,"function":"__ink_reverse_24","retained_bindings":1},{"factory":false,"function":"__ink_reverse_26","reason":"prepared residual requires a bounded pure value entry"},{"delegated_calls":1,"factory":true,"function":"__ink_reverse_53","retained_bindings":1}],"lifetime":"prepared token","semantics":"sealed-value-residual-v1"},"private_record_elisions":[],"private_sum_spines":[],"schema":1,"state":{"actions":[],"compactCommits":false,"eventColumns":false,"eventRuns":false,"events":[],"invariantChecks":[],"keepInvalidations":[[]],"keeps":[],"lazyMaintenance":true,"outputPublication":false,"roots":[{"key":{"kind":"u32"},"name":"Marker","snapshotKey":{"kind":"u32"},"snapshotValue":{"kind":"u32"},"value":{"kind":"u32"}}],"snapshot":{"program":[137,55,217,128,15,101,161,50,77,83,105,254,16,140,180,231,68,171,171,65,112,149,170,242,60,12,104,203,147,9,253,245],"schema":[196,247,80,84,87,17,213,56,238,178,201,57,97,234,20,236,122,223,66,56,116,100,23,158,186,91,87,145,246,71,151,250]},"snapshotRows":false},"wire":{"format":"ink-value-wire-v1","functions":{"__ink_reverse_0_add":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_append":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_back_node":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_back_step":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_backward":{"arguments":{"format":"ink-value-wire-v1","identity":"369ca7294b9f7da184514c2d74f2fbffa34696c1fa5d3a2adaf1f053340d482d","named":{},"root":{"fields":[{"name":"nodes","type":{"element":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"kind":"list"}},{"name":"output","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"stopZero","type":{"kind":"bool"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"__ink_reverse_0_binary":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_constant":{"arguments":{"format":"ink-value-wire-v1","identity":"d4cb0361a7a8833933106ca6dd70006e19100c770fe048f31d961bc14fa899fc","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fabc4e63e940c6190680726874c8654deced79200b320c057b9389a135a08557","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}},"__ink_reverse_0_seed":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_unary":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_1":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_24":{"arguments":{"format":"ink-value-wire-v1","identity":"3681040aa3075ba704ae5053102ed658d033ee6f956d476f6080c4348aa2c9d0","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"__ink_reverse_19","type":{"kind":"u32"}},{"name":"__ink_reverse_20","type":{"kind":"bool"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"ec732bc838055717d1ad026324fcc804a640c3e33a5b298aa112a2bb73f4dcd2","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_25"}}}},"__ink_reverse_26":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_53":{"arguments":{"format":"ink-value-wire-v1","identity":"849aa9367ab33e206bcdb3630786f49a0fe9a1db170daaaf40db0d57d242cb3b","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"__ink_reverse_48","type":{"kind":"u32"}},{"name":"__ink_reverse_49","type":{"kind":"bool"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"4d31dbac47a4ec1e295bbe9599c1bb1b188420bba49432c1facff5adc778a3a9","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_54"}}}},"device":{"arguments":{"format":"ink-value-wire-v1","identity":"7d522496fa90814f2f1e12091142cca8648a00e9c787d158636f57940650d4e4","named":{},"root":{"fields":[{"name":"xs","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"device_value":{"arguments":{"format":"ink-value-wire-v1","identity":"d650a1c39284f28d458fd182c57b8202aac4a1002de0096615fb09c7a0b7ba79","named":{},"root":{"fields":[{"name":"Alias","type":{"fields":[{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"DevicePoint"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"exclusive":{"arguments":{"format":"ink-value-wire-v1","identity":"3d9fa005996e654b10e4e749ab0e2c4a9988b4ba944f21f1019c2132cbcb62b2","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"exclusive_gradient":{"arguments":{"format":"ink-value-wire-v1","identity":"3d9fa005996e654b10e4e749ab0e2c4a9988b4ba944f21f1019c2132cbcb62b2","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"exclusive_value":{"arguments":{"format":"ink-value-wire-v1","identity":"3d9fa005996e654b10e4e749ab0e2c4a9988b4ba944f21f1019c2132cbcb62b2","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"inclusive":{"arguments":{"format":"ink-value-wire-v1","identity":"3d9fa005996e654b10e4e749ab0e2c4a9988b4ba944f21f1019c2132cbcb62b2","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"inclusive_gradient":{"arguments":{"format":"ink-value-wire-v1","identity":"3d9fa005996e654b10e4e749ab0e2c4a9988b4ba944f21f1019c2132cbcb62b2","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"inclusive_value":{"arguments":{"format":"ink-value-wire-v1","identity":"3d9fa005996e654b10e4e749ab0e2c4a9988b4ba944f21f1019c2132cbcb62b2","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}}}}};
const __implementations=[__fn0,__fn1,__fn2,__fn3,__fn4,__fn5,__fn6,__fn7,__fn8,__fn9,__fn10,__fn11,__fn12,__fn13,__fn14,__fn15,__fn16,__fn17,__fn18,__fn19,__fn20];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
const __inputTypes=[{"capture":[false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"DevicePoint"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[true],"types":[{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[true,true,true],"types":[{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"},{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},{"kind":"bool"}]},{"capture":[true,true],"types":[{"kind":"f32"},{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}]},{"capture":[true,true,false,false],"types":[{"kind":"u32"},{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}]},{"capture":[true,true,false],"types":[{"kind":"u32"},{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}]},{"capture":[true,true,true],"types":[{"kind":"temporary"},{"kind":"u32"},{"kind":"f32"}]},{"capture":[false,true,true],"types":[{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},{"kind":"f32"},{"kind":"temporary"}]},{"capture":[false,false,true],"types":[{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},{"fields":[{"name":"gradient","type":{"kind":"temporary"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Reverse"},{"kind":"bool"}]},{"capture":[false,false,true],"types":[{"element":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"kind":"list"},{"fields":[{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},{"kind":"bool"}]},{"capture":[true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}]},{"capture":[true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"kind":"bool"}]},{"capture":[true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}]},{"capture":[true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"kind":"bool"}]}];

// Descriptor work occurs once at module initialisation, never per word-list call.
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=> {
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const output=__representation(f.result,true);
  const body=__implementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
  const needsInput=input.some(c=>c!==__identity);
  const entry=!needsInput && output===__identity ? implementation :
    (...args)=>{const context=new WeakMap();return output(implementation(...(needsInput ? args.map((v,i)=>input[i](v,context)) : args)),context);};
  return [f.name,entry];
})));
export function call(name,args) {switch(name){case "__ink_reverse_0_append":case "__ink_reverse_0_seed":case "__ink_reverse_0_binary":case "__ink_reverse_0_unary":case "__ink_reverse_0_add":case "__ink_reverse_0_back_node":case "__ink_reverse_0_back_step":case "__ink_reverse_1":case "__ink_reverse_26":throw new Error('temporary storage is internal to a pure invocation');}return functions[name](...args);}
// Shared bounded binary codec; generated code supplies exact descriptors.
export const valueWireFormat='ink-value-wire-v1';
// A connection agrees on the complete value schema before using this format.
// Version byte + schema-directed fields; schema identity is out of band.
export const compactValueWireFormat='ink-value-session-v1';
const wireMagic=Uint8Array.of(73,78,75,86,65,76,0,1);
const wireEncoder=new TextEncoder(),wireDecoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const wireDefaults=Object.freeze({bytes:16777216,nodes:1000000,depth:128}),wireDefaultOptions=Object.freeze({});
const wireDecimal=s=>typeof s==='string'&&/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(s);
function wireLimits(options){if(options===wireDefaultOptions||options===wireDefaults)return wireDefaults;const l={...wireDefaults,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>wireDefaults[k])throw Error('wire hard resource limit');return l;}
const wireFloat=new DataView(new ArrayBuffer(4));
function wireDecodeText(bytes,start,end){
 if(end-start<=16){let text='';for(let i=start;i<end;i++){const byte=bytes[i];if(byte>=128)return wireDecoder.decode(bytes.subarray(start,end));text+=String.fromCharCode(byte);}return text;}
 return wireDecoder.decode(bytes.subarray(start,end));
}
function wireUtf8Length(text){let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const wireOwn=(v,k)=>v!==null&&typeof v==='object'&&Object.hasOwn(v,k);
const wireTagged=(v,k)=>wireOwn(v,k)&&Object.keys(v).length===1;
const wireDouble=new DataView(new ArrayBuffer(8));
function wireF64Bits(v){
 if(typeof v==='number'&&Number.isFinite(v)){wireDouble.setFloat64(0,v,true);return wireDouble.getBigUint64(0,true);}
 if(!wireTagged(v,'F64Bits'))wireInvalidValue();const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))wireInvalidValue();
 const bits=BigInt(text);if(bits>18446744073709551615n)wireInvalidValue();return bits;
}
const wireCanonical=v=>Array.isArray(v)?'['+v.map(wireCanonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort((a,b)=>{const x=Array.from(a,c=>c.codePointAt(0)),y=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]-y[i];return x.length-y.length;}).map(k=>JSON.stringify(k)+':'+wireCanonical(v[k])).join(',')+'}':JSON.stringify(v);
export async function createValueCodec(root,named={}){
 const used=new Set(),budget={nodes:100000};
 function check(t,d=0){
  if(d>64||--budget.nodes<0)throw Error('wire descriptor limit');
  const keys={u32:['kind'],u64:['kind'],i32:['kind'],f32:['kind'],f64:['kind'],bool:['kind'],unit:['kind'],string:['kind'],int:['kind'],id:['kind','name'],ref:['kind','name'],enum:['kind','name','variants'],record:['kind','name','fields'],list:['kind','element'],option:['kind','element'],vector:['kind','element','size'],result:['kind','ok','error']}[t?.kind];
  if(!keys||Object.keys(t).length!==keys.length||keys.some(k=>!Object.hasOwn(t,k)))throw Error('invalid wire descriptor');
  if(keys.includes('name')&&(typeof t.name!=='string'||!t.name.isWellFormed()))throw Error('invalid descriptor name');
  if(t.kind==='ref'){if(!used.has(t.name)){used.add(t.name);if(named[t.name]?.kind!=='record'||named[t.name].name!==t.name)throw Error('unresolved wire reference');check(named[t.name],d+1);}}
  if(t.kind==='record'){if(!Array.isArray(t.fields))throw Error('wire fields');const names=new Set();for(const f of t.fields){if(Object.keys(f).length!==2||typeof f.name!=='string'||!f.name.isWellFormed()||names.has(f.name))throw Error('duplicate wire field');names.add(f.name);check(f.type,d+1);}}
  if(t.kind==='enum'&&(!Array.isArray(t.variants)||!t.variants.length||t.variants.length>64||t.variants.some(v=>typeof v!=='string'||!v.isWellFormed())||new Set(t.variants).size!==t.variants.length))throw Error('wire enum');
  if(['list','vector','option'].includes(t.kind)){if(t.kind==='vector'&&(!Number.isInteger(t.size)||t.size<1||t.size>64))throw Error('wire vector');check(t.element,d+1);}
  if(t.kind==='result'){check(t.ok,d+1);check(t.error,d+1);}
 }
 check(root);const names=Object.fromEntries([...used].sort().map(k=>[k,named[k]]));
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',wireEncoder.encode(wireCanonical({format:valueWireFormat,root,named:names}))));
 return new ValueCodec({format:valueWireFormat,root,named:names,identity:Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('')});
}
// Resolve immutable descriptor edges once. Logical validation traverses the
// literal schema; single-child nodes use a loop rather than recursive closures.
function wireValuePlan(codec){
 const seen=new WeakMap();let remaining=100000;
 const build=type=>{
  const t=codec.resolve(type);if(seen.has(t))return seen.get(t);
  if(--remaining<0)throw Error('wire descriptor limit');const p={kind:t.kind,type:t,decode:null,decodeCompact:null};seen.set(t,p);
  if(t.kind==='record')p.fields=t.fields.map(f=>({name:f.name,plan:build(f.type)}));
  if(t.kind==='list'||t.kind==='vector'||t.kind==='option')p.element=build(t.element);
  if(t.kind==='result'){p.ok=build(t.ok);p.error=build(t.error);}
  return p;
 };return build(codec.descriptor.root);
}
function wireBindDecodePlan(root,compact=false){
 const seen=new Set(),pending=[root];let flags=0;
 while(pending.length){
  const p=pending.pop();if(seen.has(p))continue;seen.add(p);if(compact)p.decodeCompact=compactDecodeOperation(p);else p.decode=wireDecodeOperation(p);
  if(p.fields?.length>4)flags|=1;
  if(p.kind==='u32'||p.kind==='i32'||p.kind==='u64'||p.kind==='f32'||p.kind==='f64')flags|=2;
  if(p.fields)for(const f of p.fields)pending.push(f.plan);
  if(p.element)pending.push(p.element);
  if(p.ok){pending.push(p.ok);pending.push(p.error);}
 }
 return flags|4;
}
// Select literal descriptor operations once, without runtime source generation
// or eval. Recursive edges call the completed plan. The generic scanner remains
// the visitor/validation path and an independent materialisation implementation.
function wireReadOperation(p){
 const t=p.type;
 let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':read=(r,end)=>{r.size(end,4);const value={F32Bits:r.view.getUint32(r.cursor,true)};r.cursor=end;return value;};break;
  case 'f64':read=(r,end)=>{r.size(end,8);const value={F64Bits:r.view.getBigUint64(r.cursor,true).toString()};r.cursor=end;return value;};break;
  case 'u64':read=(r,end)=>{r.size(end,8);const value=r.view.getBigUint64(r.cursor,true);r.cursor=end;return value;};break;
  case 'string':read=(r,end)=>r.text(end);break;
  case 'int':read=(r,end)=>{const text=r.text(end);if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=(r,end)=>{const text=r.text(end);if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=(r,end)=>{const text=r.text(end);if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{
    if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;
    if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');
    const values=new Array(n);for(let i=0;i<n;i++)values[i]=element.decode(r,end,d+1);return values;
   };break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1)});break;
    case 2:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1)});break;
    case 3:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1)});break;
    case 4:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1),[fs[3].name]:fs[3].plan.decode(r,end,d+1)});break;
    default:read=(r,end,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decode(r,end,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,end,d)=>{const tag=r.tag(end);return tag?{Some:p.element.decode(r,end,d+1)}:{None:null};};break;
  case 'result':read=(r,end,d)=>r.tag(end)?{Err:p.error.decode(r,end,d+1)}:{Ok:p.ok.decode(r,end,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function wireDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=wireReadOperation(field.plan),name=field.name;
  return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),childEnd=r.enter(end,d+1),item=read(r,childEnd,d+1);if(r.cursor!==childEnd)throw Error('trailing wire frame bytes');const value={[name]:item};if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
 }
 const read=wireReadOperation(p);
 return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
}
class WireDecodeCursor{
 constructor(bytes,view,limits){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
// Bind literal validation and postorder visitation once for every descriptor.
// No logical carriers are allocated; projection still validates every child.
function wireScanPlan(root){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,scan:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.scan=wireScanOperation(p);return p;
 };
 return build(root);
}
function wireScanOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':case 'f64':case 'u64':{const size=p.kind==='f32'?4:8;read=(r,end)=>{r.size(end,size);r.cursor=end;};break;}
  case 'string':read=(r,end)=>{let i=r.cursor;while(i<end&&r.bytes[i]<128)i++;if(i<end)wireDecoder.decode(r.bytes.subarray(r.cursor,end));r.cursor=end;};break;
  case 'int':case 'id':case 'enum':read=(r,end)=>{const text=r.text(end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');for(let i=0;i<n;i++)element.scan(r,end,d+1);};break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>{};break;
    case 1:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);};break;
    case 2:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);};break;
    case 3:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);};break;
    case 4:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);fs[3].plan.scan(r,end,d+1);};break;
    default:read=(r,end,d)=>{for(const f of fs)f.plan.scan(r,end,d+1);};
   }break;
  }
  case 'option':read=(r,end,d)=>{if(r.tag(end))p.element.scan(r,end,d+1);};break;
  case 'result':read=(r,end,d)=>{(r.tag(end)?p.error:p.ok).scan(r,end,d+1);};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return (r,parentEnd,d)=>{
  const end=r.enter(parentEnd,d),start=r.cursor,value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');
  const visitor=r.visitor;if(visitor&&(!r.selected||r.selected.has(t.name))){if(r.spans)visitor(t,r.bytes,start,end,d);else visitor(t,r.bytes.subarray(start,end),d);}
  return value;
 };
}
// Separate methods keep decoding's cursor callsites monomorphic. Both cursors
// are checked against the independent generic scanner and malformed fixtures.
class WireScanCursor{
 constructor(bytes,view,limits,visitor,selected,spans){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.visitor=visitor;this.selected=selected;this.spans=spans;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
function compactReadOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=()=>null;break;
  case 'bool':read=r=>{r.require(1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':case 'i32':read=r=>{r.require(4);const n=p.kind==='u32'?r.view.getUint32(r.cursor,true):r.view.getInt32(r.cursor,true);r.cursor+=4;return n;};break;
  case 'f32':read=r=>{r.require(4);const n=r.view.getUint32(r.cursor,true);r.cursor+=4;return {F32Bits:n};};break;
  case 'f64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return {F64Bits:n.toString()};};break;
  case 'u64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return n;};break;
  case 'string':read=r=>r.text();break;
  case 'int':read=r=>{const text=r.text();if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=r=>{const text=r.text();if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=r=>{const text=r.text();if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':read=(r,d)=>{const n=r.count();if(n>r.remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');const values=new Array(n);for(let i=0;i<n;i++)values[i]=p.element.decodeCompact(r,d+1);return values;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1)});break;
    case 2:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1)});break;
    case 3:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1)});break;
    case 4:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1),[fs[3].name]:fs[3].plan.decodeCompact(r,d+1)});break;
    default:read=(r,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decodeCompact(r,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,d)=>r.tag()?{Some:p.element.decodeCompact(r,d+1)}:{None:null};break;
  case 'result':read=(r,d)=>r.tag()?{Err:p.error.decodeCompact(r,d+1)}:{Ok:p.ok.decodeCompact(r,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function compactDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=compactReadOperation(field.plan),name=field.name;
  return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');if(d+1>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return {[name]:read(r,d+1)};};
 }
 const read=compactReadOperation(p);
 return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return read(r,d);};
}
class CompactDecodeCursor{
 constructor(bytes,limits,flags){this.bytes=bytes;this.view=flags&2?new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength):null;this.cursor=1;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 require(n){if(n>this.bytes.length-this.cursor)throw Error('truncated compact value');}
 count(){
  if(this.cursor>=this.bytes.length)throw Error('truncated compact value');
  const first=this.bytes[this.cursor++];if(first<128)return first;
  let value=first&127,scale=128;
  for(let i=1;i<5;i++){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const byte=this.bytes[this.cursor++];if(i===4&&byte>15)throw Error('compact count overflow');value+=(byte&127)*scale;if(byte<128){if(byte===0)throw Error('noncanonical compact count');return value;}scale*=128;}throw Error('compact count overflow');
 }
 tag(){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const tag=this.bytes[this.cursor++];if(tag>1)throw Error('wire sum tag');return tag;}
 text(){const n=this.count();this.require(n);const start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
function wireInvalidValue(){throw Error('invalid value for wire schema');}
// Capture has the canonical logical meaning of decode(encode(value)), without
// allocating wire bytes. A separate plan leaves validation/decoder hot shapes
// unchanged and never retains host input containers between calls.
function wireCapturePlan(root,checked=true){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,capture:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({name:f.name,plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.capture=checked?wireCaptureOperation(p):wireCopyOperation(p);return p;
 };return build(root);
}
function wireCaptureOperation(p){
 const t=p.type;let copy;
 switch(p.kind){
  case 'unit':copy=v=>{if(v!==null)wireInvalidValue();return null;};break;
  case 'bool':copy=(v,r)=>{if(typeof v!=='boolean')wireInvalidValue();r.add(1);return v;};break;
  case 'u32':case 'i32':{
   const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
   copy=(v,r)=>{if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();r.add(4);return v===0?0:v;};break;
  }
  case 'u64':copy=(v,r)=>{const kind=typeof v;if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();r.add(8);return n;};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'int':case 'id':case 'enum':copy=(v,r)=>{const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;if(typeof text!=='string'||!text.isWellFormed()||text.length>r.limit)wireInvalidValue();if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();r.add(wireUtf8Length(text));return p.kind==='int'?{Int:text}:text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   copy=(v,r,d)=>{if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();const n=v.length;if(n>r.remaining||size!==null&&n!==size)wireInvalidValue();r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=element.capture(v[i],r,d+1);return out;};break;
  }
  case 'record':{
   const fs=p.fields;let fields;
   switch(fs.length){
    case 0:fields=()=>({});break;
    case 1:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:fields=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }
   copy=(v,r,d)=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();for(const f of fs)if(!wireOwn(v,f.name))wireInvalidValue();return fields(v,r,d);};break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'None')&&v.None===null)return {None:null};if(wireTagged(v,'Some'))return {Some:p.element.capture(v.Some,r,d+1)};wireInvalidValue();};break;
  case 'result':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'Ok'))return {Ok:p.ok.capture(v.Ok,r,d+1)};if(wireTagged(v,'Err'))return {Err:p.error.capture(v.Err,r,d+1)};wireInvalidValue();};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
class WireCaptureCursor{
 constructor(limits){this.remaining=limits.nodes;this.depth=limits.depth;this.limit=limits.bytes;this.bytes=40;this.add(0);}
 add(n){this.bytes+=n;if(this.bytes>this.limit)throw Error('wire byte limit');}
 enter(depth,bytes){if(depth>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.add(bytes);}
 text(value){if(value.length>this.limit)throw Error('wire byte limit');this.add(wireUtf8Length(value));}
}
// Literal lowerers share this fixed resource policy with logical capture.
export function createValueCaptureBudget(options=wireDefaultOptions){return new WireCaptureCursor(wireLimits(options));}
// The trusted-value API has the same canonical copy and ownership semantics.
// Its caller supplies a stable value accepted by validateValue. Shape/range
// checks remain at external capture boundaries; resource limits still apply.
function wireCopyOperation(p){
 let copy;
 switch(p.kind){
  case 'unit':copy=()=>null;break;
  case 'bool':copy=(v,r)=>{r.add(1);return v;};break;
  case 'u32':copy=(v,r)=>{r.add(4);return v>>>0;};break;
  case 'i32':copy=(v,r)=>{r.add(4);return v|0;};break;
  case 'u64':copy=(v,r)=>{r.add(8);return BigInt(v);};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'){wireFloat.setFloat32(0,v,true);bits=wireFloat.getUint32(0,true);}else bits=v.F32Bits;r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'id':case 'enum':copy=(v,r)=>{r.add(wireUtf8Length(v));return v;};break;
  case 'int':copy=(v,r)=>{const text=typeof v==='bigint'?v.toString():v.Int;r.add(wireUtf8Length(text));return {Int:text};};break;
  case 'list':case 'vector':copy=(v,r,d)=>{const n=v.length;if(n>r.remaining)throw Error('wire sequence size');r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=p.element.capture(v[i],r,d+1);return out;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:copy=()=>({});break;
    case 1:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:copy=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'None')&&v.None===null?{None:null}:{Some:p.element.capture(v.Some,r,d+1)};};break;
  case 'result':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'Ok')?{Ok:p.ok.capture(v.Ok,r,d+1)}:{Err:p.error.capture(v.Err,r,d+1)};};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
// Emit the cached literal schema with one forward writer. Each value is checked
// where it is consumed; byte bounds belong to the writer, not a second size walk.
function wireEncodeValue(root,value,l,w){
 let remaining=l.nodes;const depthLimit=l.depth;
 const node=(p,v,d)=>{
  if(d>depthLimit||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type,start=w.beginNode();
  switch(p.kind){
   case 'unit':if(v!==null)wireInvalidValue();break;
   case 'bool':if(typeof v!=='boolean')wireInvalidValue();w.byte(+v);break;
   case 'u32':case 'i32':{
    const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
    if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();w.word(v>>>0);break;
   }
   case 'u64':{
    const kind=typeof v;
    if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
    const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();w.wide(n);break;
   }
   case 'f64':w.wide(wireF64Bits(v));break;
   case 'f32':{
    let bits;
    if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}
    else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
    w.word(bits);break;
   }
   case 'string':case 'int':case 'id':case 'enum':{
    const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
    if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&(typeof text!=='string'||!/^[0-9a-f]{32}$/.test(text))||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
    w.text(text);break;
   }
   case 'list':case 'vector':{
    if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
    if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
    w.count(v.length);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);break;
   }
   case 'record':{
    const fs=p.fields;
    if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
    for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
    for(let i=0;i<fs.length;i++){const f=fs[i];node(f.plan,v[f.name],d+1);}break;
   }
   case 'option':{
    if(wireTagged(v,'None')&&v.None===null)w.byte(0);
    else if(wireTagged(v,'Some')){w.byte(1);node(p.element,v.Some,d+1);}else wireInvalidValue();break;
   }
   case 'result':{
    if(wireTagged(v,'Ok')){w.byte(0);node(p.ok,v.Ok,d+1);}
    else if(wireTagged(v,'Err')){w.byte(1);node(p.error,v.Err,d+1);}else wireInvalidValue();break;
   }
   default:throw Error('unsupported wire kind');
  }
  w.endNode(start);
 };
 node(root,value,0);
}
function wireCheckValue(root,value,l){
 let remaining=l.nodes,total=40;
 const add=n=>{total+=n;if(total>l.bytes)throw Error('wire byte limit');};
 const node=(p,v,d)=>{
  while(true){
   if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
   const t=p.type;
   switch(p.kind){
    case 'unit':if(v!==null)wireInvalidValue();add(4);return;
    case 'bool':if(typeof v!=='boolean')wireInvalidValue();add(5);return;
    case 'u32':case 'i32':{
     const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
     if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();add(8);return;
    }
    case 'u64':{
     const kind=typeof v;
     if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
     const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();add(12);return;
    }
    case 'f64':wireF64Bits(v);add(12);return;
    case 'f32':{
     if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();}
     else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();const bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
     add(8);return;
    }
    case 'string':case 'int':case 'id':case 'enum':{
     const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
     if(typeof text!=='string'||!text.isWellFormed()||text.length>l.bytes)wireInvalidValue();
     if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
     add(4+wireUtf8Length(text));return;
    }
    case 'list':case 'vector':{
     if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
     if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
     add(8);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);return;
    }
    case 'record':{
     const fs=p.fields;
     if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
     for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
     add(4);if(!fs.length)return;
     for(let i=0;i<fs.length-1;i++)node(fs[i].plan,v[fs[i].name],d+1);
     const f=fs[fs.length-1];p=f.plan;v=v[f.name];d++;continue;
    }
    case 'option':{
     if(wireTagged(v,'None')&&v.None===null){add(5);return;}
     if(!wireTagged(v,'Some'))wireInvalidValue();add(5);p=p.element;v=v.Some;d++;continue;
    }
    case 'result':{
     if(wireTagged(v,'Ok')){add(5);p=p.ok;v=v.Ok;}
     else if(wireTagged(v,'Err')){add(5);p=p.error;v=v.Err;}else wireInvalidValue();
     d++;continue;
    }
    default:throw Error('unsupported wire kind');
   }
  }
 };
 node(root,value,0);if(total>l.bytes)throw Error('wire byte limit');
}
// A single cursor replaces per-node child closures and {end,value} temporaries.
// Projection filters limit callback materialisation, never schema validation.
function wireScanValue(root,bytes,view,l,materialize,visitor,selected,spans){
 let cursor=40,remaining=l.nodes;
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,parentEnd,d)=>{
  if(d>l.depth||--remaining<0||cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const t=p.type,start=cursor+4,end=start+view.getUint32(cursor,true);if(end>parentEnd)throw Error('truncated wire frame');cursor=start;let value;
  switch(p.kind){
   case 'unit':if(end-start!==0)throw Error('malformed wire scalar');value=null;break;
   case 'bool':if(end-start!==1)throw Error('malformed wire scalar');if(bytes[start]>1)throw Error('invalid wire Bool');value=!!bytes[start];cursor=end;break;
   case 'u32':case 'i32':if(end-start!==4)throw Error('malformed wire scalar');value=p.kind==='u32'?view.getUint32(start,true):view.getInt32(start,true);cursor=end;break;
   case 'f32':if(end-start!==4)throw Error('malformed wire scalar');if(materialize)value={F32Bits:view.getUint32(start,true)};cursor=end;break;
   case 'f64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value={F64Bits:view.getBigUint64(start,true).toString()};cursor=end;break;
   case 'u64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value=view.getBigUint64(start,true);cursor=end;break;
   case 'string':case 'int':case 'id':case 'enum':{
    if(p.kind==='string'&&!materialize){let i=start;while(i<end&&bytes[i]<128)i++;if(i<end)wireDecoder.decode(bytes.subarray(start,end));}
    else{const text=wireDecodeText(bytes,start,end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    cursor=end;break;
   }
   case 'list':case 'vector':{
    if(start+4>end)throw Error('wire list count');const n=view.getUint32(start,true);cursor+=4;
    if(n>remaining||n>Math.floor((end-cursor)/4)||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,end,d+1);if(materialize)value.push(child);}break;
   }
   case 'record':{
    const fs=p.fields;
    // Computed literal keys create own data properties even for __proto__ or
    // prototype setters. Common small records need no descriptor allocations.
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:value={};break;case 1:value={[fs[0].name]:node(fs[0].plan,end,d+1)};break;case 2:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1)};break;case 3:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1)};break;case 4:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1),[fs[3].name]:node(fs[3].plan,end,d+1)};break;}
    }else{if(materialize)value={};for(const f of fs){const child=node(f.plan,end,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}}break;
   }
   case 'option':case 'result':{
    if(start===end||bytes[cursor]>1)throw Error('wire sum tag');const tag=bytes[cursor++];
    if(p.kind==='option'&&tag===0){if(materialize)value={None:null};}
    else{const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,end,d+1);if(materialize)value={[label]:child};}break;
   }
   default:throw Error('unsupported wire kind');
  }
  if(cursor!==end)throw Error('trailing wire frame bytes');
  if(visitor&&(!selected||selected.has(t.name))){if(spans)visitor(t,bytes,start,end,d);else visitor(t,bytes.subarray(start,end),d);}
  return value;
 };
 const result=node(root,bytes.length,0);if(cursor!==bytes.length)throw Error('trailing wire bytes');return result;
}
export class ValueCodec{
 #hash;
 #header;
 #headerWords;
 #descriptor;
 #valuePlan;
 #compactCodec;
 #encoder;
 #decodeBound=0;
 #scanPlan=null;
 #capturePlan=null;
 #copyPlan=null;
 get descriptor(){return this.#descriptor;}
 constructor(descriptor){
  // This synchronous path is for compiler-generated immutable metadata. For
  // untrusted descriptors use createValueCodec and compare the computed identity.
  if(descriptor?.format!==valueWireFormat||!/^[0-9a-f]{64}$/.test(descriptor.identity))throw Error('invalid wire schema');
  this.#descriptor=structuredClone(descriptor);this.#hash=Uint8Array.from(descriptor.identity.match(/../g),s=>parseInt(s,16));
  this.#header=new Uint8Array(40);this.#header.set(wireMagic);this.#header.set(this.#hash,8);
  const headerView=new DataView(this.#header.buffer);this.#headerWords=Array.from({length:10},(_,i)=>headerView.getUint32(i*4,true));
  const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}};freeze(this.descriptor);this.#valuePlan=wireValuePlan(this);
 }
 resolve(t){for(let i=0;i<64;i++){if(t.kind!=='ref')return t;t=this.descriptor.named[t.name];if(!t)throw Error('wire reference');}throw Error('wire reference cycle');}
 validateValue(value,options=wireDefaultOptions){wireCheckValue(this.#valuePlan,value,wireLimits(options));return true;}
 capture(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#capturePlan??=wireCapturePlan(this.#valuePlan);return this.#capturePlan.capture(value,new WireCaptureCursor(limits),0);}
 copy(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#copyPlan??=wireCapturePlan(this.#valuePlan,false);return this.#copyPlan.capture(value,new WireCaptureCursor(limits),0);}
 compact(){return this.#compactCodec??=new CompactValueCodec(this);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new WireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.bytes(this.#header);wireEncodeValue(this.#valuePlan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new WireEncoder(options);w.bytes(wireMagic);w.bytes(this.#hash);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 scan(bytes,options=wireDefaultOptions,materialize=false,visitor=null,names=null,spans=false){
  const l=wireLimits(options);if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<44||bytes.length>l.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==this.#headerWords[i])throw Error('wire format or schema mismatch');
  if(names!==null&&(!Array.isArray(names)||names.length>100000||names.some(n=>typeof n!=='string')))throw Error('wire visitor names');
  if(materialize&&!visitor){this.#decodeBound||=wireBindDecodePlan(this.#valuePlan);const cursor=new WireDecodeCursor(bytes,view,l);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#valuePlan.decode(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  if(!materialize){this.#scanPlan??=wireScanPlan(this.#valuePlan);const cursor=new WireScanCursor(bytes,view,l,visitor,names===null?null:new Set(names),spans),value=this.#scanPlan.scan(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  return wireScanValue(this.#valuePlan,bytes,view,l,materialize,visitor,names===null?null:new Set(names),spans);
 }
 visit(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names);}
 visitSpans(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names,true);}
 validate(bytes,options=wireDefaultOptions){this.scan(bytes,options,false);return true;}
 decode(bytes,options=wireDefaultOptions){return this.scan(bytes,options,true);}
}

// Bounded forward emission avoids building and repeatedly joining child buffers.
class WireEncoder{
 #data=new Uint8Array(256);#view=new DataView(this.#data.buffer);#at=0;#remaining;#depth=0;#byteLimit;#depthLimit;
 active=false;
 constructor(options){this.reset(options);}
 reset(options){const limits=wireLimits(options);this.#byteLimit=limits.bytes;this.#depthLimit=limits.depth;this.#remaining=limits.nodes;this.#depth=0;this.#at=0;this.active=true;}
 get capacity(){return this.#data.length;}
 get position(){return this.#at;}
 beginNode(){const at=this.#at;this.word(0);return at;}
 endNode(at){this.patchWord(at,this.#at-at-4);}
 count(n){this.word(n);}
 beginCount(){const at=this.position;this.count(0);return at;}
 endCount(at,n){this.patchWord(at,n);}
 #reserve(size){
  const end=this.#at+size;if(end>this.#byteLimit)throw Error('wire byte limit');
  if(end>this.#data.length){const next=new Uint8Array(Math.min(this.#byteLimit,Math.max(end,this.#data.length*2)));next.set(this.#data.subarray(0,this.#at));this.#data=next;this.#view=new DataView(next.buffer);}
  return end;
 }
 bytes(bytes){const end=this.#reserve(bytes.length);this.#data.set(bytes,this.#at);this.#at=end;}
 byte(n){if(!Number.isInteger(n)||n<0||n>255)throw Error('wire byte range');this.#reserve(1);this.#data[this.#at++]=n;}
 word(n){if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire word range');const end=this.#reserve(4);this.#view.setUint32(this.#at,n,true);this.#at=end;}
 wide(n){if(typeof n!=='bigint'||n<0n||n>18446744073709551615n)throw Error('wire wide range');const end=this.#reserve(8);this.#view.setBigUint64(this.#at,n,true);this.#at=end;}
 text(text,count=false){
  if(typeof text!=='string')throw Error('wire Unicode');
  if(text.length<=16){
   let ascii=true;for(let i=0;i<text.length;i++)if(text.charCodeAt(i)>=128){ascii=false;break;}
   if(ascii){if(count)this.count(text.length);const end=this.#reserve(text.length);for(let i=0;i<text.length;i++)this.#data[this.#at+i]=text.charCodeAt(i);this.#at=end;return;}
  }
  if(!text.isWellFormed())throw Error('wire Unicode');const size=wireUtf8Length(text);if(count)this.count(size);
  const end=this.#reserve(size),r=wireEncoder.encodeInto(text,this.#data.subarray(this.#at,end));if(r.read!==text.length||r.written!==size)throw Error('wire UTF-8 size');this.#at=end;
 }
 patchWord(at,n){if(!Number.isInteger(at)||at<0||at+4>this.#at||!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire patch offset');this.#view.setUint32(at,n,true);}
 patchByte(at,n){if(!Number.isInteger(at)||at<0||at>=this.#at||!Number.isInteger(n)||n<0||n>255)throw Error('wire patch offset');this.#data[at]=n;}
 replace(at,removed,bytes){
  if(!Number.isInteger(at)||!Number.isInteger(removed)||at<0||removed<0||at+removed>this.#at||!(bytes instanceof Uint8Array))throw Error('wire replacement range');
  const extra=bytes.length-removed,end=extra>0?this.#reserve(extra):this.#at+extra;
  this.#data.copyWithin(at+bytes.length,at+removed,this.#at);this.#data.set(bytes,at);this.#at=end;
 }
 // Literal generated writers use balanced frames without per-node callbacks.
 // An exception abandons this invocation; encodeWith never reuses its writer.
 openFrame(){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;return at;}
 closeFrame(at){if(this.#depth===0)throw Error('wire frame boundary');this.#depth--;this.endNode(at);}
 frame(emit){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;try{emit(this);}finally{this.#depth--;}this.endNode(at);}
 reorder(start,spans){
  const sorted=spans.slice().sort((a,b)=>a[0]-b[0]);let at=start;
  for(const [a,b] of sorted){if(!Number.isInteger(a)||!Number.isInteger(b)||a!==at||b<a)throw Error('wire span permutation');at=b;}
  if(start<0||start>this.#at||at!==this.#at)throw Error('wire span permutation');
  if(spans.every((s,i)=>s===sorted[i]))return;
  const copy=this.#data.slice(start,this.#at);at=start;for(const [a,b] of spans){this.#data.set(copy.subarray(a-start,b-start),at);at+=b-a;}
 }
 finish(){if(this.#depth!==0)throw Error('wire frame boundary');return this.#data.slice(0,this.#at);}
}

class CompactWireEncoder extends WireEncoder{
 beginNode(){return 0;}
 endNode(){}
 endCount(at,n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  if(n<128){this.patchByte(at,n);return;}
  const bytes=[];while(n>=128){bytes.push(n%128+128);n=Math.floor(n/128);}bytes.push(n);this.replace(at,1,Uint8Array.from(bytes));
 }
 count(n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  while(n>=128){this.byte(n%128+128);n=Math.floor(n/128);}this.byte(n);
 }
 text(text){super.text(text,true);}
}

function compactScanValue(root,bytes,l,materialize){
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let cursor=1,remaining=l.nodes;
 const require=n=>{if(n>bytes.length-cursor)throw Error('truncated compact value');};
 const count=()=>{
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   require(1);const byte=bytes[cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }throw Error('compact count overflow');
 };
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,d)=>{
  if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type;let value;
  switch(p.kind){
   case 'unit':return null;
   case 'bool':require(1);if(bytes[cursor]>1)throw Error('invalid wire Bool');return !!bytes[cursor++];
   case 'u32':case 'i32':require(4);value=p.kind==='u32'?view.getUint32(cursor,true):view.getInt32(cursor,true);cursor+=4;return value;
   case 'f32':require(4);if(materialize)value={F32Bits:view.getUint32(cursor,true)};cursor+=4;return value;
   case 'f64':require(8);if(materialize)value={F64Bits:view.getBigUint64(cursor,true).toString()};cursor+=8;return value;
   case 'u64':require(8);if(materialize)value=view.getBigUint64(cursor,true);cursor+=8;return value;
   case 'string':case 'int':case 'id':case 'enum':{
    const n=count();require(n);const start=cursor;cursor+=n;
    if(p.kind==='string'&&!materialize){let i=start;while(i<cursor&&bytes[i]<128)i++;if(i<cursor)wireDecoder.decode(bytes.subarray(start,cursor));}
    else{const text=wireDecodeText(bytes,start,cursor);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    return value;
   }
   case 'list':case 'vector':{
    const n=count();if(n>remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,d+1);if(materialize)value.push(child);}return value;
   }
   case 'record':{
    const fs=p.fields;
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:return {};case 1:return {[fs[0].name]:node(fs[0].plan,d+1)};case 2:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1)};case 3:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1)};case 4:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1),[fs[3].name]:node(fs[3].plan,d+1)};}
    }
    if(materialize)value={};for(const f of fs){const child=node(f.plan,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}return value;
   }
   case 'option':case 'result':{
    require(1);const tag=bytes[cursor++];if(tag>1)throw Error('wire sum tag');
    if(p.kind==='option'&&tag===0)return materialize?{None:null}:undefined;
    const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,d+1);
    return materialize?{[label]:child}:undefined;
   }
   default:throw Error('unsupported wire kind');
  }
 };
 const value=node(root,0);if(cursor!==bytes.length)throw Error('trailing compact bytes');return value;
}

// General transport codec, independent of source rewrites and checkpoints.
// The sender/receiver must negotiate this exact identity and format. There is
// deliberately no claim that the bytes themselves identify their schema.
export class CompactValueCodec{
 #source;#plan;#encoder;#decodeBound=0;
 get format(){return compactValueWireFormat;}
 get identity(){return this.#source.descriptor.identity;}
 constructor(valueCodec){if(!(valueCodec instanceof ValueCodec))throw Error('compact codec requires a checked value codec');this.#source=valueCodec;this.#plan=wireValuePlan(valueCodec);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new CompactWireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.byte(1);wireEncodeValue(this.#plan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new CompactWireEncoder(options);w.byte(1);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 #scan(bytes,options,materialize){
  const l=wireLimits(options);
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<1||bytes.length>l.bytes)throw Error('wire byte limit or header');
  if(bytes[0]!==1)throw Error('compact format mismatch');
  if(materialize){this.#decodeBound||=wireBindDecodePlan(this.#plan,true);const cursor=new CompactDecodeCursor(bytes,l,this.#decodeBound);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#plan.decodeCompact(cursor,0);if(cursor.cursor!==bytes.length)throw Error('trailing compact bytes');return value;}
  return compactScanValue(this.#plan,bytes,l,materialize);
 }
 decode(bytes,options=wireDefaultOptions){return this.#scan(bytes,options,true);}
 validate(bytes,options=wireDefaultOptions){this.#scan(bytes,options,false);return true;}
}

// Compiler materialisers consume already validated bytes synchronously. This
// factory is for trusted emitted code, not untrusted descriptor/callback data.
// The complete generic validator runs before any compiler reader is invoked.
class ValidatedValueReader{
 constructor(bytes,compact){this.bytes=bytes;this.view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);this.cursor=compact?1:40;this.compact=compact;}
 frame(){if(this.compact)return 0;const end=this.cursor+4+this.view.getUint32(this.cursor,true);this.cursor+=4;return end;}
 finish(end){if(!this.compact&&this.cursor!==end)throw Error('compiled reader frame mismatch');}
 byte(){return this.bytes[this.cursor++];}
 word(){const n=this.view.getUint32(this.cursor,true);this.cursor+=4;return n;}
 signed(){const n=this.view.getInt32(this.cursor,true);this.cursor+=4;return n;}
 wide(){const n=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return n;}
 count(){if(!this.compact)return this.word();let n=0,scale=1,byte;do{byte=this.byte();n+=(byte&127)*scale;scale*=128;}while(byte>=128);return n;}
 text(end){const n=this.compact?this.count():end-this.cursor,start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
class CompiledCompactValueCodec extends CompactValueCodec{
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,true),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
}
class CompiledValueCodec extends ValueCodec{
 #read;#compiledCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,false),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
 compact(){return this.#compiledCompact??=new CompiledCompactValueCodec(this,this.#read);}
}
export function createCompiledValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new CompiledValueCodec(descriptor,read);}

// Trusted literal materialisers may use this checked reader to validate and
// construct in one traversal. The emitter must use frame/finish at every source
// node, typed text reads and counted sequence reads; arbitrary callbacks do not
// establish a schema correspondence proof. The independent scanner remains the
// validation oracle and the original factory retains its pre-validation path.
function literalValueHeader(identity){
 const bytes=new Uint8Array(40);bytes.set(wireMagic);
 for(let i=0;i<32;i++)bytes[i+8]=parseInt(identity.slice(i*2,i*2+2),16);
 const view=new DataView(bytes.buffer),words=new Uint32Array(10);
 for(let i=0;i<10;i++)words[i]=view.getUint32(i*4,true);
 return words;
}
class CheckedLiteralValueReader {
 constructor(bytes,header,compact,limits){
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<(compact?1:44)||bytes.length>limits.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  if(compact){if(bytes[0]!==1)throw Error('compact format mismatch');}
  else for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==header[i])throw Error('wire format or schema mismatch');
  this.bytes=bytes;this.view=view;
  this.cursor=compact?1:40;this.compact=compact;this.remaining=limits.nodes;this.depth=limits.depth;this.ends=[];
 }
 require(n){if(this.cursor+n>(this.ends.at(-1)??this.bytes.length))throw Error('truncated wire frame');}
 frame(){
  if(this.ends.length>this.depth||--this.remaining<0)throw Error('wire node or depth limit');
  let end=this.bytes.length;
  if(!this.compact){this.require(4);end=this.cursor+4+this.view.getUint32(this.cursor,true);this.require(end-this.cursor);this.cursor+=4;}
  this.ends.push(end);return this.compact?0:end;
 }
 finish(end){
  if(!this.ends.length||!this.compact&&(this.ends.at(-1)!==end||this.cursor!==end))throw Error('compiled reader frame mismatch');
  this.ends.pop();
 }
 byte(){this.require(1);const value=this.bytes[this.cursor++];if(value>1)throw Error('wire sum tag or Bool');return value;}
 word(){this.require(4);const value=this.view.getUint32(this.cursor,true);this.cursor+=4;return value;}
 signed(){this.require(4);const value=this.view.getInt32(this.cursor,true);this.cursor+=4;return value;}
 wide(){this.require(8);const value=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return value;}
 rawCount(){
  if(!this.compact)return this.word();
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   this.require(1);const byte=this.bytes[this.cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }
  throw Error('compact count overflow');
 }
 count(size){
  const value=this.rawCount();
  if(value>this.remaining||size!==undefined&&value!==size)throw Error('wire sequence size');
  return value;
 }
 text(end,kind='string',variants){
  const size=this.compact?this.rawCount():end-this.cursor;
  this.require(size);const start=this.cursor;this.cursor+=size;
  const value=wireDecodeText(this.bytes,start,this.cursor);
  if(kind==='int'&&!wireDecimal(value)||kind==='id'&&!/^[0-9a-f]{32}$/.test(value)||kind==='enum'&&!variants.includes(value))throw Error('malformed wire text');
  return value;
 }
 complete(){if(this.ends.length||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
// Compact source nodes have no individual frame ends: retain the same checked
// depth/node order using a counter, with bounds against the complete buffer.
class CheckedCompactLiteralValueReader extends CheckedLiteralValueReader {
 constructor(bytes,limits){super(bytes,null,true,limits);this.level=0;}
 require(n){if(this.cursor+n>this.bytes.length)throw Error('truncated wire frame');}
 frame(){if(this.level>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.level++;return 0;}
 finish(_end){if(!this.level)throw Error('compiled reader frame mismatch');this.level--;}
 complete(){if(this.level||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
class FusedCompactValueCodec extends CompactValueCodec {
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedCompactLiteralValueReader(bytes,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
}
class FusedValueCodec extends ValueCodec {
 #read;#header;#fusedCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;this.#header=literalValueHeader(this.descriptor.identity);}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedLiteralValueReader(bytes,this.#header,false,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
 compact(){return this.#fusedCompact??=new FusedCompactValueCodec(this,this.#read);}
}
export function createFusedValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new FusedValueCodec(descriptor,read);}
// JSON text is a boundary adapter to an ordinary recursive Ink datatype.
// No JavaScript Number conversion occurs for JSON numeric tokens.
export function jsonNumberToken(s){return typeof s==='string'&&/^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/.test(s);}
// JSON numeric tokens have an ASCII grammar. Check validated UTF-8 spans
// directly, preserving exact lexemes without allocating a decoded String.
function jsonNumberSpan(bytes,lo,hi){
 let at=lo;if(bytes[at]===45)at++;
 if(at>=hi)return false;
 if(bytes[at]===48)at++;
 else{if(bytes[at]<49||bytes[at]>57)return false;do{at++;}while(at<hi&&bytes[at]>=48&&bytes[at]<=57);}
 if(at<hi&&bytes[at]===46){const start=++at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 if(at<hi&&(bytes[at]===69||bytes[at]===101)){at++;if(at<hi&&(bytes[at]===43||bytes[at]===45))at++;const start=at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 return at===hi;
}
const jsonWireEncoder=new TextEncoder();
// Scalar conversion completes before writer callbacks; no per-value byte array.
const jsonFloatScratch=new DataView(new ArrayBuffer(4));
function jsonUtf8Length(text){if(text.length>16&&!/[^\x00-\x7f]/.test(text))return text.length;let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const jsonLimits={bytes:16777216,nodes:1000000,depth:128};
const jsonQuoters=new WeakSet();
/** Explicit, bounded reuse of immutable JSON string quotes. Cache payload bytes
 * are UTF-16 storage estimates; entry caps bound separate Map/object overhead.
 * Logical output budgets are charged again on every use, including cache hits.
 */
export function createJsonQuoter({maxEntries=1024,maxBytes=131072}={}){
 if(!Number.isSafeInteger(maxEntries)||maxEntries<0||maxEntries>65536||!Number.isSafeInteger(maxBytes)||maxBytes<0||maxBytes>16777216)throw Error('JSON quote cache budget');
 const entries=new Map();let bytes=0,hits=0,misses=0;
 const token=value=>{
  const prior=entries.get(value);if(prior!==undefined){hits++;return prior;}
  if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid JSON String');
  misses++;const text=JSON.stringify(value),size=2*(value.length+text.length),quoted=Object.freeze({text,utf8Bytes:jsonUtf8Length(text)});
  if(maxEntries&&size<=maxBytes){
   while(entries.size&&(entries.size>=maxEntries||bytes+size>maxBytes)){const key=entries.keys().next().value;bytes-=2*(key.length+entries.get(key).text.length);entries.delete(key);}
   entries.set(value,quoted);bytes+=size;
  }
  return quoted;
 };
 const quoter=Object.freeze({
  token,
  quote(value){return token(value).text;},
  clear(){entries.clear();bytes=0;},
  stats(){return {entries:entries.size,payload_bytes:bytes,hits,misses};},
 });jsonQuoters.add(quoter);return quoter;
}
function checkedJsonLimits(options){const l={...jsonLimits,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>jsonLimits[k])throw Error('JSON hard resource limit');return l;}
function jsonVariant(index,item){let payload=index===0?{}:{item0:item};if(index<5)payload={Ok:payload};for(let i=0;i<index;i++)payload={Err:payload};return {payload};}
export function parseJson(text,options={}){return parseJsonValue(text,options,null);}
function parseJsonValue(text,options,boundary){
 const p=new JsonWireReader(text,options);
 const value=(d,wireDepth=0)=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){boundary?.node(0,wireDepth);p.at+=4;return jsonVariant(0,null);}if(c==='t'&&text.startsWith('true',p.at)){boundary?.node(1,wireDepth);p.at+=4;return jsonVariant(1,true);}if(c==='f'&&text.startsWith('false',p.at)){boundary?.node(1,wireDepth);p.at+=5;return jsonVariant(1,false);}
  if(c==='"'){boundary?.node(3,wireDepth);const item=p.string();boundary?.text(item);return jsonVariant(3,item);}
  if(c==='['){boundary?.node(4,wireDepth);p.at++;const xs=[];if(!p.eat(']'))while(true){xs.push(value(d+1,wireDepth+8));if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}return jsonVariant(4,xs);}
  if(c==='{'){boundary?.node(5,wireDepth);p.at++;const xs=[],seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary?.member(key,wireDepth);if(!p.eat(':'))throw Error('JSON object colon');xs.push({key,value:value(d+1,wireDepth+9)});if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}return jsonVariant(5,xs);}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();boundary?.node(2,wireDepth);boundary?.text(token);return jsonVariant(2,token);}
  throw Error('invalid JSON value');
 };
 const out=value(0);p.finish();return out;
}
export function stringifyJson(value,options={}){return stringifyJsonValue(value,options,null);}
function stringifyJsonValue(value,options,boundary){
 const l=checkedJsonLimits(options);let remaining=l.nodes,bytes=0,output='';
 const emit=s=>{bytes+=jsonUtf8Length(s);if(bytes>l.bytes)throw Error('JSON byte limit');output+=s;};
 const write=(v,d,wireDepth=0)=>{
  if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');if(!v||Object.keys(v).length!==1||!Object.hasOwn(v,'payload'))throw Error('invalid JSON record');let p=v.payload,index=0;
  while(index<5&&p&&Object.hasOwn(p,'Err')){if(Object.keys(p).length!==1||boundary&&Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Err;index++;}
  if(index<5){if(!p||Object.keys(p).length!==1||!Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Ok;}
  if(!p||Object.keys(p).length!==(index===0?0:1)||index>0&&!Object.hasOwn(p,'item0'))throw Error('invalid JSON payload');const item=p.item0;boundary?.node(index,wireDepth);
  switch(index){
   case 0:emit('null');break;
   case 1:if(typeof item!=='boolean')throw Error('invalid JSON Boolean');emit(item?'true':'false');break;
   case 2:if(!jsonNumberToken(item))throw Error('invalid JSON number');boundary?.text(item);emit(item);break;
   case 3:if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary?.text(item);emit(JSON.stringify(item));break;
   case 4:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Array');const count=item.length;let visited=0;emit('[');item.forEach((x,i)=>{visited++;if(i)emit(',');write(x,d+1,wireDepth+8);});if(visited!==count)throw Error('invalid JSON Array');emit(']');break;}
   case 5:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Object');const count=item.length,seen=new Set();let visited=0;emit('{');item.forEach((m,i)=>{visited++;if(!m||Object.keys(m).length!==2||typeof m.key!=='string'||!m.key.isWellFormed()||!Object.hasOwn(m,'value')||boundary&&!Object.hasOwn(m,'key'))throw Error('invalid JSON member');if(seen.has(m.key))throw Error('duplicate JSON object key');seen.add(m.key);boundary?.member(m.key,wireDepth);if(i)emit(',');emit(JSON.stringify(m.key));emit(':');write(m.value,d+1,wireDepth+9);});if(visited!==count)throw Error('invalid JSON Object');emit('}');break;}
  }
 };write(value,0);return output;
}
// The adapter's schema is the fixed recursive JSON library shape checked by
// JsonCodec. Charge its ordinary record/sum/list wire nodes while parsing or
// rendering, rather than interpreting and walking the completed tree again.
function jsonBoundaryBudget(options){
 const l=checkedJsonLimits(options);let remaining=l.nodes,total=40;
 const charge=(nodes,bytes,depth)=>{remaining-=nodes;total+=bytes;if(remaining<0||depth>l.depth)throw Error('wire node or depth limit');if(total>l.bytes)throw Error('wire byte limit');};
 return {
  node(index,depth){charge(index===0?3:index<4?index+4:8,index===0?13:index===1?23:index===2?27:index===3?32:41,depth+(index===0?2:index<4?index+3:7));},
  text(text){charge(0,jsonUtf8Length(text),0);},
  member(key,depth){charge(2,8+jsonUtf8Length(key),depth+9);},
 };
}
function jsonSameSchema(a,b){
 if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;
 const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>Object.hasOwn(b,k)&&jsonSameSchema(a[k],b[k]));
}
// Host-object conversion is opt-in and JavaScript-only. Inspect data properties
// rather than invoking getters/toJSON; reflection is not a sandbox for proxies.
function jsonJSKeys(value){
 if(!value||typeof value!=='object')throw Error('expected a plain JavaScript object');
 const prototype=Object.getPrototypeOf(value);
 if(prototype!==Object.prototype&&prototype!==null)throw Error('expected a plain JavaScript object');
 const keys=Reflect.ownKeys(value);
 if(keys.some(k=>typeof k!=='string'))throw Error('JavaScript symbol keys are unsupported');
 return keys;
}
function jsonJSData(value,key){
 const property=Object.getOwnPropertyDescriptor(value,key);
 if(!property||!property.enumerable||!Object.hasOwn(property,'value'))throw Error('expected an enumerable own data property');
 return property.value;
}
function jsonJSRecord(value,names){
 const keys=jsonJSKeys(value);
 if(keys.length!==names.length||keys.some(k=>!names.includes(k)))throw Error('invalid JSON record or variant');
}
function jsonJSArray(value,remaining){
 if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype)throw Error('expected a plain JavaScript array');
 const length=value.length;
 if(length>remaining)throw Error('JSON node limit');
 const keys=Reflect.ownKeys(value);
 if(keys.length!==length+1||keys.some(k=>typeof k!=='string'||k!=='length'&&(!/^(0|[1-9][0-9]*)$/.test(k)||Number(k)>=length)))throw Error('sparse or decorated JavaScript arrays are unsupported');
 return length;
}
function jsonFromJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),active=new WeakSet();let remaining=limits.nodes;
 const text=value=>{if(!value.isWellFormed())throw Error('invalid JSON Unicode');boundary.text(value);return value;};
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  if(value===null){boundary.node(0,wireDepth);return jsonVariant(0);}
  switch(typeof value){
   case 'boolean':boundary.node(1,wireDepth);return jsonVariant(1,value);
   case 'string':boundary.node(3,wireDepth);return jsonVariant(3,text(value));
   case 'number':
    if(!Number.isFinite(value))throw Error('non-finite JavaScript numbers are unsupported');
    boundary.node(2,wireDepth);return jsonVariant(2,text(Object.is(value,-0)?'-0':String(value)));
   case 'bigint':boundary.node(2,wireDepth);return jsonVariant(2,text(String(value)));
   case 'object':break;
   default:throw Error('unsupported JavaScript value');
  }
  if(active.has(value))throw Error('cyclic JavaScript value');
  active.add(value);
  try{
   if(Array.isArray(value)){
    boundary.node(4,wireDepth);const count=jsonJSArray(value,remaining),items=[];
    for(let i=0;i<count;i++)items.push(visit(jsonJSData(value,String(i)),depth+1,wireDepth+8));
    return jsonVariant(4,items);
   }
   boundary.node(5,wireDepth);const keys=jsonJSKeys(value),members=[];
   if(keys.length>remaining)throw Error('JSON node limit');
   for(const key of keys){
    if(!key.isWellFormed())throw Error('invalid JSON Unicode');
    boundary.member(key,wireDepth);
    members.push({key,value:visit(jsonJSData(value,key),depth+1,wireDepth+9)});
   }
   return jsonVariant(5,members);
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
function jsonDecimalKey(token){
 const [,sign,whole,fraction='',exponent='0']=/^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(token);
 const digits=(whole+fraction).replace(/^0+/,'');
 if(!digits)return '0';
 const trimmed=digits.replace(/0+$/,'');
 return sign+trimmed+'e'+(Number(exponent)-fraction.length+digits.length-trimmed.length);
}
function jsonToJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),mode=options?.numbers??'number',active=new WeakSet();let remaining=limits.nodes;
 if(!['number','bigint','string'].includes(mode))throw Error('unknown JavaScript number policy');
 const number=token=>{
  if(!jsonNumberToken(token))throw Error('invalid JSON number');
  boundary.text(token);
  if(mode==='string')return token;
  if(mode==='bigint')return BigInt(jsonInteger(token,4096));
  const result=Number(token);
  if(!Number.isFinite(result)||jsonDecimalKey(token)!==jsonDecimalKey(String(result)))throw Error('JSON number loses precision as JavaScript Number; choose numbers: bigint or string');
  return result;
 };
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  jsonJSRecord(value,['payload']);
  if(active.has(value))throw Error('cyclic JSON value');
  active.add(value);
  try{
   let payload=jsonJSData(value,'payload'),index=0;
   while(index<5&&Object.hasOwn(payload,'Err')){jsonJSRecord(payload,['Err']);payload=jsonJSData(payload,'Err');index++;}
   if(index<5){jsonJSRecord(payload,['Ok']);payload=jsonJSData(payload,'Ok');}
   jsonJSRecord(payload,index===0?[]:['item0']);boundary.node(index,wireDepth);
   const item=index===0?null:jsonJSData(payload,'item0');
   if(index===0)return null;
   if(index===1){if(typeof item!=='boolean')throw Error('invalid JSON Boolean');return item;}
   if(index===2)return number(item);
   if(index===3){if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary.text(item);return item;}
   const count=jsonJSArray(item,remaining);
   if(index===4){const out=[];for(let i=0;i<count;i++)out.push(visit(jsonJSData(item,String(i)),depth+1,wireDepth+8));return out;}
   const out={},seen=new Set();
   for(let i=0;i<count;i++){
    const member=jsonJSData(item,String(i));jsonJSRecord(member,['key','value']);const key=jsonJSData(member,'key');
    if(typeof key!=='string'||!key.isWellFormed())throw Error('invalid JSON member key');
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary.member(key,wireDepth);
    Object.defineProperty(out,key,{value:visit(jsonJSData(member,'value'),depth+1,wireDepth+9),enumerable:true,writable:true,configurable:true});
   }
   return out;
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
const jsonConstructionPaths=Object.freeze(Array.from({length:6},(_,index)=>Object.freeze([0,...Array(index).fill(1),...(index<5?[0]:[]),0])));
function parseJsonConstructed(text,options,builder){
 const p=new JsonWireReader(text,options);
 const paths=jsonConstructionPaths;
 const fused=typeof builder.openPath==='function';
 const begin=index=>{if(fused){builder.openPath(paths[index]);return;}for(const choice of paths[index])builder.open(choice);};
 const end=index=>{for(let i=0;i<(fused?1:index<5?index+3:7);i++)builder.close();};
 const leaf=(index,item)=>{if(typeof builder.scalarPath==='function'){builder.scalarPath(paths[index],item);return;}begin(index);builder.scalar(item);end(index);};
 const value=d=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){p.at+=4;if(typeof builder.emptyPath==='function')builder.emptyPath(paths[0]);else{begin(0);end(0);}return;}
  if(c==='t'&&text.startsWith('true',p.at)){p.at+=4;leaf(1,true);return;}
  if(c==='f'&&text.startsWith('false',p.at)){p.at+=5;leaf(1,false);return;}
  if(c==='"'){leaf(3,p.string());return;}
  if(c==='['){begin(4);builder.open(0);p.at++;if(!p.eat(']'))while(true){value(d+1);if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}builder.close();end(4);return;}
  if(c==='{'){begin(5);builder.open(0);p.at++;const seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');builder.open(0);builder.scalar(key);value(d+1);builder.close();if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}builder.close();end(5);return;}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();leaf(2,token);return;}
  throw Error('invalid JSON value');
 };
 value(0);p.finish();return builder.finish();
}
const jsonCompiledRenderers=new WeakMap();
function compiledJsonRenderer(json,codec,unwrap){
 if(typeof codec?.reducer!=='function')throw Error('compiled JSON reduction unavailable');
 const source=codec.resolve(codec.descriptor.root),root=json.values.descriptor.root;
 const selected=unwrap&&source.kind==='result'?codec.resolve(source.ok):source;
 if(!jsonSameSchema(root,selected)||unwrap&&source.kind!=='result')throw Error('compiled JSON schema mismatch');
 let variants=root.fields[0].type;const roles=new Map([[root.name,'root']]);
 let member;
 for(let index=0;index<6;index++){
  const branch=index<5?variants.ok:variants;roles.set(branch.name,index);
  if(index===5){member=branch.fields[0].type.element.name;roles.set(member,'member');}
  if(index<5)variants=variants.error;
 }
 const nodeRoles=new Map();
 return codec.reducer((node,index)=>{
  const role=roles.get(node.name);nodeRoles.set(index,role);
  if(node.kind==='record'){
   if(role==='root')return value=>value;
   if(role==='member')return (key,value,context)=>{
    const text=(context.quoter?context.quote(key,true):context.add(JSON.stringify(key)+':'))+value,seen=context.members;
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);return text;
   };
   if(role===0)return context=>context.add('null');
   if(role===1)return (value,context)=>context.add(value?'true':'false');
   if(role===2)return (token,context)=>{if(!jsonNumberToken(token))throw Error('invalid JSON number');return context.add(token);};
   if(role===3)return (value,context)=>context.quoter?context.quote(value,false):context.add(JSON.stringify(value));
   if(role===4)return (value,context)=>{context.add('[]');return '['+value+']';};
   if(role===5)return (value,context)=>{context.add('{}');return '{'+value+'}';};
   return ()=>null;
  }
  if(node.kind==='list'||node.kind==='vector'){
   const members=nodeRoles.get(node.children[0])==='member';
   return {
    start:(_length,context)=>{
     const out={text:'',parent:members?context.members:null};
     if(members)context.members=new Set();return out;
    },
    step:(out,value,index,context)=>{out.text+=(index?context.add(','):'')+value;return out;},
    finish:(out,context)=>{if(members)context.members=out.parent;return out.text;},
   };
  }
  if(node.kind==='result'){
   // A Result<Json,E> boundary is explicitly requested by the caller. Ordinary
   // JSON's own sums only propagate an already rendered branch.
   if(unwrap&&nodeRoles.get(node.children[0])==='root')return (tag,value)=>{if(tag)throw Error('JSON result is Err');return value;};
   return (_tag,value)=>value;
  }
  if(node.kind==='string')return value=>{if(!value.isWellFormed())throw Error('invalid JSON String');return value;};
  return value=>value;
 });
}
export class JsonCodec{
 constructor(valueCodec){
  const root=valueCodec.descriptor.root,fields=root.fields;if(root.kind!=='record'||!Array.isArray(fields)||fields.length!==1||fields[0].name!=='payload')throw Error('JSON schema payload');let sum=fields[0].type;
  for(let i=0;i<6;i++){
   if(i<5&&sum.kind!=='result')throw Error('JSON schema sum');const branch=i<5?sum.ok:sum,fs=branch.fields;
   if(branch.kind!=='record'||!Array.isArray(fs)||fs.length!==(i?1:0)||i&&fs[0].name!=='item0')throw Error('JSON schema branch');
   if(i){const t=fs[0].type;if(i===1&&t.kind!=='bool'||(i===2||i===3)&&t.kind!=='string'||i===4&&(t.kind!=='list'||t.element.kind!=='ref'||t.element.name!==root.name))throw Error('JSON schema variant');if(i===5){const mf=t.element?.fields;if(t.kind!=='list'||t.element?.kind!=='record'||!Array.isArray(mf)||mf.length!==2||mf[0].name!=='key'||mf[0].type.kind!=='string'||mf[1].name!=='value'||mf[1].type.kind!=='ref'||mf[1].type.name!==root.name)throw Error('JSON schema member');}}
   if(i===2)this.numberBranch=branch.name;if(i===5)this.objectBranch=branch.name;
   if(i<5)sum=sum.error;
  }if(!jsonSameSchema(root,valueCodec.resolve({kind:'ref',name:root.name})))throw Error('JSON recursive schema mismatch');this.values=valueCodec;
 }
 parse(text,options={}){return parseJsonValue(text,options,jsonBoundaryBudget(options));}
 parseCompiled(codec,text,options={}){
  if(codec?.identity!==this.values.descriptor.identity||typeof codec.builder!=='function')throw Error('compiled JSON schema mismatch');
  const builder=codec.builder(options);try{return parseJsonConstructed(text,options,builder);}catch(error){builder.abort();throw error;}
 }
 stringify(value,options={}){return stringifyJsonValue(value,options,jsonBoundaryBudget(options));}
 stringifyCompiled(codec,handle,options={}){
  const limits=checkedJsonLimits(options),unwrap=options.unwrapResult===true;
  const quoter=options.quoter;if(quoter!==undefined&&!jsonQuoters.has(quoter))throw Error('JSON quote cache owner mismatch');
  let codecs=jsonCompiledRenderers.get(this);if(!codecs)jsonCompiledRenderers.set(this,codecs=new WeakMap());
  let renderers=codecs.get(codec);if(!renderers)codecs.set(codec,renderers=new Map());
  let render=renderers.get(unwrap);if(!render)renderers.set(unwrap,render=compiledJsonRenderer(this,codec,unwrap));
  let bytes=0;const context={
   quoter,
   add(text){bytes+=jsonUtf8Length(text);if(bytes>limits.bytes)throw Error('JSON byte limit');return text;},
   quote(value,colon){
    if(!quoter)return this.add(JSON.stringify(value)+(colon?':':''));
    const token=quoter.token(value);bytes+=token.utf8Bytes+(colon?1:0);if(bytes>limits.bytes)throw Error('JSON byte limit');return token.text+(colon?':':'');
   },
  };
  const text=render(handle,context,limits);
  return text;
 }
 fromJS(value,options={}){return jsonFromJS(value,options);}
 toJS(value,options={}){return jsonToJS(value,options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,false);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,false,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,true);}
 validateBinary(bytes,options={}){
  const decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});let view;
  this.values.visitSpans(bytes,(type,data,start,end)=>{
   view??=new DataView(data.buffer,data.byteOffset,data.byteLength);
   if(type.name===this.numberBranch){const length=view.getUint32(start,true);if(!jsonNumberSpan(data,start+4,start+4+length))throw Error('invalid JSON number token');}
   if(type.name===this.objectBranch){const listEnd=start+4+view.getUint32(start,true),count=view.getUint32(start+4,true),seen=new Set();let at=start+8;for(let i=0;i<count;i++){const memberEnd=at+4+view.getUint32(at,true),keyStart=at+8,keyEnd=keyStart+view.getUint32(at+4,true),key=decoder.decode(data.subarray(keyStart,keyEnd));if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);at=memberEnd;}if(at!==listEnd)throw Error('invalid JSON object frame');}
  },options,[this.numberBranch,this.objectBranch]);return true;

 }
}
function jsonUnpack(value){let p=value.payload,i=0;while(i<5&&Object.hasOwn(p,'Err')){p=p.Err;i++;}return [i,(i<5?p.Ok:p).item0];}
function jsonInteger(token,limit){
 if(!jsonNumberToken(token))throw Error('invalid JSON number');const negative=token[0]==='-',raw=negative?token.slice(1):token,[mantissa,exp='0']=raw.split(/[eE]/);let digits=mantissa.replace('.','');if(/^0+$/.test(digits))return '0';const exponent=Number(exp),fraction=mantissa.includes('.')?mantissa.length-mantissa.indexOf('.')-1:0,shift=exponent-fraction;
 if(!Number.isSafeInteger(exponent)||!Number.isSafeInteger(shift))throw Error('JSON integer exponent limit');
 if(shift<0){const cut=-shift;if(cut>=digits.length||!/^[0]+$/.test(digits.slice(-cut)))throw Error('JSON number is not an integer');digits=digits.slice(0,-cut);}else{if(digits.length+shift>limit)throw Error('JSON integer magnitude limit');digits+='0'.repeat(shift);}
 digits=digits.replace(/^0+/,'');if(digits.length>limit)throw Error('JSON integer magnitude limit');return (negative?'-':'')+digits;
}
function jsonBinary64Value(v){
 if(typeof v==='number')return v;
 const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid F64Bits');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');
 const b=new DataView(new ArrayBuffer(8));b.setBigUint64(0,bits,true);return b.getFloat64(0,true);
}
export class TypedJsonCodec{
 constructor(valueCodec){this.values=valueCodec;}
 decode(document,options={}){
  // Validate JSON-specific invariants before interpreting any tagged/record
  // shape, including duplicated names and malformed numeric tokens.
  stringifyJson(document,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const read=(type,value,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type),[kind,item]=jsonUnpack(value);const fail=()=>{throw Error('JSON does not match '+t.kind);};
   switch(t.kind){
    case 'unit':if(kind!==0)fail();return null;
    case 'bool':if(kind!==1)fail();return item;
    case 'u32':case 'u64':case 'i32':case 'int':{if(kind!==2)fail();const text=jsonInteger(item,t.kind==='int'?4096:t.kind==='u64'?20:10);return t.kind==='int'?{Int:text}:t.kind==='u64'?BigInt(text):Number(text);}
    case 'f64':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(8));if(!Number.isFinite(n))throw Error('JSON f64 overflow');b.setFloat64(0,n,true);return {F64Bits:b.getBigUint64(0,true).toString()};}
    case 'f32':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(4));b.setFloat32(0,n,true);if(!Number.isFinite(b.getFloat32(0,true)))throw Error('JSON f32 overflow');return {F32Bits:b.getUint32(0,true)};}
    case 'string':case 'enum':case 'id':if(kind!==3)fail();return item;
    case 'list':case 'vector':if(kind!==4)fail();return item.map(x=>read(t.element,x,d+1));
    case 'record':{if(kind!==5||item.length!==t.fields.length)throw Error('unknown or missing JSON record field');const fields=new Map(item.map(m=>[m.key,m.value])),out={};for(const f of t.fields){if(!fields.has(f.name))throw Error('missing JSON record field');Object.defineProperty(out,f.name,{value:read(f.type,fields.get(f.name),d+1),writable:true,enumerable:true,configurable:true});}return out;}
    case 'option':case 'result':{if(kind!==5||item.length!==1)fail();const m=item[0];if(t.kind==='option'&&m.key==='None'&&jsonUnpack(m.value)[0]===0)return {None:null};const child=t.kind==='option'&&m.key==='Some'?t.element:t.kind==='result'&&m.key==='Ok'?t.ok:t.kind==='result'&&m.key==='Err'?t.error:null;if(!child)fail();return {[m.key]:read(child,m.value,d+1)};}
    default:fail();
   }
  };
  const out=read(this.values.descriptor.root,document,0);this.values.validateValue(out,options);return out;
 }
 encode(value,options={}){
  this.values.validateValue(value,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const write=(type,v,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type);
   switch(t.kind){
    case 'unit':return jsonVariant(0);
    case 'bool':return jsonVariant(1,v);
    case 'u32':case 'u64':case 'i32':return jsonVariant(2,String(v));
    case 'int':return jsonVariant(2,typeof v==='bigint'?String(v):v.Int);
    case 'f64':{const n=jsonBinary64Value(v);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'f32':{let n;if(typeof v==='number')n=Math.fround(v);else{const b=new DataView(new ArrayBuffer(4));b.setUint32(0,v.F32Bits,true);n=b.getFloat32(0,true);}if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'string':case 'id':case 'enum':return jsonVariant(3,v);
    case 'list':case 'vector':return jsonVariant(4,Array.from(v,x=>write(t.element,x,d+1)));
    case 'record':return jsonVariant(5,t.fields.map(f=>({key:f.name,value:write(f.type,v[f.name],d+1)})));
    case 'option':return jsonVariant(5,[Object.hasOwn(v,'Some')?{key:'Some',value:write(t.element,v.Some,d+1)}:{key:'None',value:jsonVariant(0)}]);
    case 'result':return jsonVariant(5,[Object.hasOwn(v,'Ok')?{key:'Ok',value:write(t.ok,v.Ok,d+1)}:{key:'Err',value:write(t.error,v.Err,d+1)}]);
    default:throw Error('unsupported typed JSON descriptor');
   }
  };return write(this.values.descriptor.root,value,0);
 }
 parse(text,options={}){return this.decode(parseJson(text,options),options);}
 stringify(value,options={}){return stringifyJson(this.encode(value,options),options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,true);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,true,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,false);}
}

// Token reader shared by schema-directed and arbitrary-JSON wire emission.
class JsonWireReader{
 constructor(text,options){this.l=checkedJsonLimits(options);if(typeof text!=='string'||!text.isWellFormed()||text.length>this.l.bytes||jsonUtf8Length(text)>this.l.bytes)throw Error('JSON byte or Unicode limit');this.text=text;this.at=0;this.remaining=this.l.nodes;}
 ws(){while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(c!==32&&c!==9&&c!==10&&c!==13)break;this.at++;}}
 peek(){this.ws();return this.text[this.at];}
 eat(c){this.ws();if(this.text[this.at]===c){this.at++;return true;}return false;}
 node(d){if(d>this.l.depth||--this.remaining<0)throw Error('JSON node or depth limit');}
 string(){
  this.ws();const start=this.at;if(this.text[start]!=='"')throw Error('expected JSON string');
  const end=this.text.indexOf('"',start+1);if(end<0)throw Error('unterminated JSON string');
  const raw=this.text.slice(start+1,end);
  if(!raw.includes('\\')&&!/[\x00-\x1f]/.test(raw)){this.at=end+1;return raw;}
  this.at=start+1;while(this.at<this.text.length){if(this.text[this.at]==='"'){this.at++;const v=JSON.parse(this.text.slice(start,this.at));if(!v.isWellFormed())throw Error('invalid JSON Unicode');return v;}if(this.text[this.at]==='\\')this.at+=2;else this.at++;}throw Error('unterminated JSON string');
 }
 number(){const start=this.at;while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(!(c>=48&&c<=57||c===45||c===43||c===46||c===101||c===69))break;this.at++;}const token=this.text.slice(start,this.at);if(!jsonNumberToken(token))throw Error('invalid JSON number');return token;}
 leaf(d){this.node(d);const c=this.peek();if(c==='n'&&this.text.startsWith('null',this.at)){this.at+=4;return null;}if(c==='t'&&this.text.startsWith('true',this.at)){this.at+=4;return true;}if(c==='f'&&this.text.startsWith('false',this.at)){this.at+=5;return false;}if(c==='"')return this.string();if(c==='-'||c>='0'&&c<='9')return this.number();throw Error('invalid JSON scalar');}
 finish(){this.ws();if(this.at!==this.text.length)throw Error('trailing JSON text');}
}
function streamJsonBinary(values,text,options,typed,compact=false){
 const p=new JsonWireReader(text,options),utf8=jsonWireEncoder;
 const list=(w,open,close,item)=>{if(!p.eat(open))throw Error('JSON container shape');const at=w.beginCount();let count=0;if(!p.eat(close))while(true){item(w);count++;if(p.eat(close))break;if(!p.eat(','))throw Error('JSON container separator');}w.endCount(at,count);};
 const variant=(w,index,level,emit)=>{if(level<index)w.frame(w=>{w.byte(1);variant(w,index,level+1,emit);});else if(index<5)w.frame(w=>{w.byte(0);w.frame(emit);});else w.frame(emit);};
 const json=(w,d)=>{
  const ch=p.peek(),index=ch==='n'?0:ch==='t'||ch==='f'?1:ch==='-'||ch>='0'&&ch<='9'?2:ch==='"'?3:ch==='['?4:ch==='{'?5:-1;if(index<0)throw Error('invalid JSON value');
  const leaf=index<4?p.leaf(d):null;if(index>=4)p.node(d);
  w.frame(w=>variant(w,index,0,w=>{
   if(index===0)return;if(index===1){w.frame(w=>w.byte(+leaf));return;}
   if(index===2||index===3){w.frame(w=>w.text(leaf));return;}
   w.frame(w=>{if(index===4)list(w,'[',']',w=>json(w,d+1));else{const seen=new Set();list(w,'{','}',w=>{const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');w.frame(w=>{w.frame(w=>w.text(key));json(w,d+1);});});}});
  }));
 };
 const read=(type,w,d)=>{
  const t=values.resolve(type);w.frame(w=>{
   if(t.kind==='list'||t.kind==='vector'){p.node(d);list(w,'[',']',w=>read(t.element,w,d+1));return;}
   if(t.kind==='record'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON record');const start=w.position,spans=new Array(t.fields.length).fill(null);
    if(!p.eat('}'))while(true){const key=p.string(),i=t.fields.findIndex(f=>f.name===key);if(i<0)throw Error('unknown JSON record field');if(spans[i])throw Error('duplicate JSON record field');if(!p.eat(':'))throw Error('JSON record colon');const at=w.position;read(t.fields[i].type,w,d+1);spans[i]=[at,w.position];if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON record separator');}
    if(spans.some(s=>s===null))throw Error('missing JSON record field');w.reorder(start,spans);return;
   }
   if(t.kind==='option'||t.kind==='result'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON tagged value');const key=p.string();if(!p.eat(':'))throw Error('JSON tag colon');
    if(t.kind==='option'&&key==='None'){if(p.leaf(d+1)!==null)throw Error('JSON None payload');w.byte(0);}
    else{const child=t.kind==='option'&&key==='Some'?t.element:t.kind==='result'&&key==='Ok'?t.ok:t.kind==='result'&&key==='Err'?t.error:null;if(!child)throw Error('invalid JSON tag');w.byte(key==='Ok'?0:1);read(child,w,d+1);}
    if(!p.eat('}'))throw Error('expected exactly one JSON tag');return;
   }
   const ch=p.peek(),v=p.leaf(d),bad=()=>{throw Error('JSON does not match '+t.kind);};
   if(t.kind==='unit'){if(v!==null)bad();return;}
   if(t.kind==='bool'){if(typeof v!=='boolean')bad();w.byte(+v);return;}
   if(['string','id','enum'].includes(t.kind)){if(ch!=='"')bad();w.text(v);return;}
   if(ch!=='-'&&!(ch>='0'&&ch<='9'))bad();
   if(t.kind==='int'){w.text(jsonInteger(v,4096));return;}
   if(t.kind==='f64'){const n=Number(v);if(!Number.isFinite(n))throw Error('JSON f64 overflow');const b=new DataView(new ArrayBuffer(8));b.setFloat64(0,n,true);w.wide(b.getBigUint64(0,true));}
   else if(t.kind==='f32'){jsonFloatScratch.setFloat32(0,Number(v),true);if(!Number.isFinite(jsonFloatScratch.getFloat32(0,true)))throw Error('JSON f32 overflow');w.word(jsonFloatScratch.getUint32(0,true));}
   else{const n=BigInt(jsonInteger(v,t.kind==='u64'?20:10));if(t.kind==='u64'){if(n<0n||n>18446744073709551615n)bad();w.wide(n);}else if(t.kind==='u32'){if(n<0n||n>4294967295n)bad();w.word(Number(n));}else if(t.kind==='i32'){if(n< -2147483648n||n>2147483647n)bad();w.word(Number(n)>>>0);}else bad();}
  });
 };
 return (compact?values.compact():values).encodeWith(w=>{if(typed)read(values.descriptor.root,w,0);else json(w,0);p.finish();},options);
}

// Render validated bytes in a single traversal; only the final text is owned.
function streamWireJsonText(values,bytes,options,library){
 values.validate(bytes,options);const l=checkedJsonLimits(options),parts=[];let size=0,remaining=l.nodes;const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 const emit=s=>{size+=jsonUtf8Length(s);if(size>l.bytes)throw Error('JSON byte limit');parts.push(s);};
 const string=s=>emit(JSON.stringify(s));const node=d=>{if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');};
 const frame=(type,at)=>{const t=values.resolve(type),start=at+4,end=start+dv.getUint32(at,true);return{t,start,end};};
 const json=(type,at,d)=>{
  node(d);let root=frame(type,at),sum=frame(root.t.fields[0].type,root.start),index=0;
  while(index<5){const err=bytes[sum.start];sum=frame(err?sum.t.error:sum.t.ok,sum.start+1);if(!err)break;index++;}
  if(index===0){emit('null');return root.end;}
  const item=frame(sum.t.fields[0].type,sum.start);
  if(index===1)emit(bytes[item.start]?'true':'false');
  else if(index===2){const token=decoder.decode(bytes.subarray(item.start,item.end));if(!jsonNumberToken(token))throw Error('invalid JSON number token');emit(token);}
  else if(index===3)string(decoder.decode(bytes.subarray(item.start,item.end)));
  else{const count=dv.getUint32(item.start,true);let p=item.start+4;emit(index===4?'[':'{');const seen=new Set();for(let i=0;i<count;i++){if(i)emit(',');if(index===4)p=json(item.t.element,p,d+1);else{const member=frame(item.t.element,p),key=frame(member.t.fields[0].type,member.start),name=decoder.decode(bytes.subarray(key.start,key.end));if(seen.has(name))throw Error('duplicate JSON object key');seen.add(name);string(name);emit(':');json(member.t.fields[1].type,key.end,d+1);p=member.end;}}emit(index===4?']':'}');}
  return root.end;
 };
 const typed=(type,at,d)=>{
  node(d);const f=frame(type,at),t=f.t;let p=f.start;
  switch(t.kind){
   case 'unit':emit('null');break;
   case 'bool':emit(bytes[p]?'true':'false');break;
   case 'u32':emit(String(dv.getUint32(p,true)));break;
   case 'u64':emit(String(dv.getBigUint64(p,true)));break;
   case 'i32':emit(String(dv.getInt32(p,true)));break;
   case 'f64':{const n=dv.getFloat64(p,true);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'f32':{const n=dv.getFloat32(p,true);if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'int':emit(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'string':case 'id':case 'enum':string(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'list':case 'vector':{const n=dv.getUint32(p,true);p+=4;emit('[');for(let i=0;i<n;i++){if(i)emit(',');p=typed(t.element,p,d+1);}emit(']');break;}
   case 'record':emit('{');for(let i=0;i<t.fields.length;i++){if(i)emit(',');const field=t.fields[i];string(field.name);emit(':');p=typed(field.type,p,d+1);}emit('}');break;
   case 'option':case 'result':{const tag=bytes[p++],key=t.kind==='option'?(tag?'Some':'None'):tag?'Err':'Ok';emit('{');string(key);emit(':');if(t.kind==='option'&&!tag){node(d+1);emit('null');}else typed(t.kind==='option'?t.element:tag?t.error:t.ok,p,d+1);emit('}');break;}
   default:throw Error('unsupported typed JSON descriptor');
  }return f.end;
 };
 if(library)json(values.descriptor.root,40,0);else typed(values.descriptor.root,40,0);return parts.join('');
}

/** Owned, optional read view of arbitrary JSON. Auxiliary indexes contain member
 * offsets only. Logical order, exact number tokens and missing/null remain intact.
 * This does not transparently replace any compiled Ink action or its state.
 */
export function createJsonLookup(text,{stepEntries=16,minReads=4,maxEntries=4096,maxObjects=64,maxIndexBytes=262144,...limits}={}){
 for(const [v,max]of [[stepEntries,4096],[minReads,1000000],[maxEntries,1000000],[maxObjects,256],[maxIndexBytes,16777216]])if(!Number.isSafeInteger(v)||v<0||v>max)throw Error('JSON index budget');
 let root=parseJson(text,limits),indexes=new Map(),entries=0,indexBytes=0;
 const stats={reads:0,writes:0,scanned_members:0,index_hits:0,built_entries:0,invalidations:0};
 function parts(path){
  if(!Array.isArray(path))throw Error('JSON lookup path');const n=path.length;if(n>128)throw Error('JSON lookup path');
  const owned=[];for(let i=0;i<n;i++){const d=Object.getOwnPropertyDescriptor(path,String(i));if(!d||!Object.hasOwn(d,'value'))throw Error('JSON lookup path');const p=d.value;if(!(typeof p==='string'&&p.isWellFormed()&&p.length<=4096)&&!(Number.isSafeInteger(p)&&p>=0))throw Error('JSON lookup path');owned.push(p);}return owned;
 }
 function variant(value){let p=value.payload,index=0;while(index<5&&Object.hasOwn(p,'Err')){p=p.Err;index++;}return {index,item:(index<5?p.Ok:p).item0};}
 function resolve(document,path,indexed){
  let value=document,budget=stepEntries;
  for(let depth=0;depth<path.length;depth++){
   const part=path[depth],v=variant(value);
   if(typeof part==='number'){
    if(v.index!==4)throw Error('expected JSON array');if(part>=v.item.length)return {found:false};value=v.item[part];continue;
   }
   if(v.index!==5)throw Error('expected JSON object');
   const prefix=path.slice(0,depth),key=JSON.stringify(prefix),overhead=128+prefix.reduce((n,p)=>n+(typeof p==='string'?16+p.length*2:8),0);let idx=indexed?indexes.get(key):null;
   if(indexed&&!idx&&indexes.size<maxObjects&&indexBytes+overhead<=maxIndexBytes){idx={path:prefix,reads:0,cursor:0,keys:new Map(),bytes:overhead};indexes.set(key,idx);indexBytes+=overhead;}
   if(idx){
    idx.reads++;
    if(idx.reads>=minReads)while(budget>0&&idx.cursor<v.item.length&&entries<maxEntries){
     const member=v.item[idx.cursor],bytes=64+member.key.length*2;
     if(indexBytes+bytes>maxIndexBytes)break;
     idx.keys.set(member.key,idx.cursor++);idx.bytes+=bytes;indexBytes+=bytes;entries++;stats.built_entries++;budget--;
    }
    if(idx.keys.has(part)){stats.index_hits++;value=v.item[idx.keys.get(part)].value;continue;}
   }
   let found=false;
   for(let i=idx?.cursor??0;i<v.item.length;i++){if(indexed)stats.scanned_members++;if(v.item[i].key===part){value=v.item[i].value;found=true;break;}}
   if(!found)return {found:false};
  }
  return {found:true,value};
 }
 return {
  lookup(path){stats.reads++;const r=resolve(root,parts(path),true);return r.found?{found:true,value:structuredClone(r.value)}:r;},
  set(path,key,text){
   path=parts(path);if(typeof key!=='string'||!key.isWellFormed())throw Error('JSON object key');
   const replacement=parseJson(text,limits),next=structuredClone(root),r=resolve(next,path,false);
   if(!r.found)throw Error('JSON update path missing');const object=variant(r.value);if(object.index!==5)throw Error('expected JSON object');
   const members=[{key,value:replacement},...object.item.filter(m=>m.key!==key)];
   // Validate the complete resulting document before publishing a write.
   let payload=r.value.payload;for(let i=0;i<5;i++)payload=payload.Err;payload.item0=members;
   stringifyJson(next,limits);root=next;stats.writes++;
   for(const [id,idx]of indexes)if(idx.path.length>=path.length&&path.every((p,i)=>p===idx.path[i])){entries-=idx.keys.size;indexBytes-=idx.bytes;indexes.delete(id);stats.invalidations++;}
  },
  replace(text){const next=parseJson(text,limits);root=next;stats.writes++;stats.invalidations+=indexes.size;indexes.clear();entries=0;indexBytes=0;},
  stringify(){return stringifyJson(root,limits);},
  stats(){return {...stats,index_entries:entries,index_objects:indexes.size,index_bytes:indexBytes};}
 };
}
function __ownedValue1(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue0(value[i],budget,depth+1);return out;}
function __ownedValue4(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue5(value.Ok,budget,depth+1)}:{Err:__ownedValue6(value.Err,budget,depth+1)};}
function __ownedValue7(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue8(value.Ok,budget,depth+1)}:{Err:__ownedValue6(value.Err,budget,depth+1)};}
function __ownedValue5(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue0(value["value"],budget,depth+1),["gradient"]:__ownedValue0(value["gradient"],budget,depth+1)};}
function __ownedValue8(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue0(value["value"],budget,depth+1),["gradient"]:__ownedValue0(value["gradient"],budget,depth+1)};}
function __ownedValue2(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue0(value["value"],budget,depth+1),["id"]:__ownedValue3(value["id"],budget,depth+1)};}
function __ownedValue0(value,budget,depth){budget.enter(depth,8);return {F32Bits:value===0?0:value};}
function __ownedValue6(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __ownedValue3(value,budget,depth){budget.enter(depth,8);return value>>>0;}
const __ownedFunctions=Object.freeze(Object.fromEntries([["device_value",__ownedValue0],["exclusive",__ownedValue0],["inclusive",__ownedValue0],["exclusive_value",__ownedValue0],["exclusive_gradient",__ownedValue0],["inclusive_value",__ownedValue0],["inclusive_gradient",__ownedValue0],["device",__ownedValue1],["__ink_reverse_0_constant",__ownedValue2],["__ink_reverse_0_backward",__ownedValue1],["__ink_reverse_24",__ownedValue4],["__ink_reverse_53",__ownedValue7]]));
function __wireValue1(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue2(reader);reader.finish(end);return value;}
function __wireValue7(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue4(reader);reader.finish(end);return value;}
function __wireValue10(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue12(reader)}:{Ok:__wireValue11(reader)};reader.finish(end);return value;}
function __wireValue14(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue12(reader)}:{Ok:__wireValue15(reader)};reader.finish(end);return value;}
function __wireValue17(reader){const end=reader.frame();const value={["Alias"]:__wireValue18(reader)};reader.finish(end);return value;}
function __wireValue0(reader){const end=reader.frame();const value={["nodes"]:__wireValue1(reader),["output"]:__wireValue5(reader),["stopZero"]:__wireValue6(reader)};reader.finish(end);return value;}
function __wireValue2(reader){const end=reader.frame();const value={["op"]:__wireValue3(reader),["a"]:__wireValue3(reader),["b"]:__wireValue3(reader),["av"]:__wireValue4(reader),["bv"]:__wireValue4(reader),["value"]:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue11(reader){const end=reader.frame();const value={["value"]:__wireValue4(reader),["gradient"]:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue15(reader){const end=reader.frame();const value={["value"]:__wireValue4(reader),["gradient"]:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue5(reader){const end=reader.frame();const value={["value"]:__wireValue4(reader),["id"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue18(reader){const end=reader.frame();const value={["value"]:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue8(reader){const end=reader.frame();const value={["value"]:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue9(reader){const end=reader.frame();const value={["x"]:__wireValue4(reader),["__ink_reverse_19"]:__wireValue3(reader),["__ink_reverse_20"]:__wireValue6(reader)};reader.finish(end);return value;}
function __wireValue13(reader){const end=reader.frame();const value={["x"]:__wireValue4(reader),["__ink_reverse_48"]:__wireValue3(reader),["__ink_reverse_49"]:__wireValue6(reader)};reader.finish(end);return value;}
function __wireValue19(reader){const end=reader.frame();const value={["x"]:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue16(reader){const end=reader.frame();const value={["xs"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue6(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __wireValue4(reader){const end=reader.frame();const value={F32Bits:reader.word()};reader.finish(end);return value;}
function __wireValue12(reader){const end=reader.frame();const value=reader.text(end,"string");reader.finish(end);return value;}
function __wireValue3(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
const __wireReaders=Object.freeze(Object.fromEntries([["__ink_reverse_0_backward",[__wireValue0,__wireValue7]],["__ink_reverse_0_constant",[__wireValue8,__wireValue5]],["__ink_reverse_24",[__wireValue9,__wireValue10]],["__ink_reverse_53",[__wireValue13,__wireValue14]],["device",[__wireValue16,__wireValue7]],["device_value",[__wireValue17,__wireValue4]],["exclusive",[__wireValue19,__wireValue4]],["exclusive_gradient",[__wireValue19,__wireValue4]],["exclusive_value",[__wireValue19,__wireValue4]],["inclusive",[__wireValue19,__wireValue4]],["inclusive_gradient",[__wireValue19,__wireValue4]],["inclusive_value",[__wireValue19,__wireValue4]]]));

const __ownedImplementations=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>{
 const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
 const body=__implementations[f.index];
 const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
 return [f.name,input.every(c=>c===__identity)?implementation:(...args)=>{const context=new WeakMap();return implementation(...args.map((v,i)=>input[i](v,context)));}];
})));

export const valueCodecs=(()=>{const codecs={};for(const [name,s] of Object.entries(metadata.wire.functions)){if(s.unsupported)continue;let value;Object.defineProperty(codecs,name,{enumerable:true,get:()=>value??=(Object.freeze(Object.hasOwn(__wireReaders,name)?{arguments:createCompiledValueCodec(s.arguments,__wireReaders[name][0]),result:createCompiledValueCodec(s.result,__wireReaders[name][1])}:{arguments:new ValueCodec(s.arguments),result:new ValueCodec(s.result)}))});}return Object.freeze(codecs);})();
function __callEncoded(name,bytes,limits,compact){
 const f=metadata.functions.find(f=>f.name===name&&!f.internal),codecs=valueCodecs[name];
 if(!f||!codecs)throw Error('unsupported binary function');
 const input=compact?codecs.arguments.compact():codecs.arguments,output=compact?codecs.result.compact():codecs.result;
 const entry=__compiledEntries.get(name);
 if(entry){
  const slot=compact?1:0;
  entry.argumentCodecs[slot]??=(entry.boundaryReaders[slot]?createFusedValueCodec:createCompiledValueCodec)(metadata.wire.functions[name].arguments,entry.arguments);
  const decoder=entry.argumentCodecs[slot];
  const values=(compact?decoder.compact():decoder).decode(bytes,limits),args=f.params.map(p=>values[p.name]);
  if(entry.precondition!==null&&__implementations[entry.precondition](...args)!==true)throw Error('contract precondition failed');
  return __compiledEncodeResult(entry,__implementations[entry.index](...args),limits,compact);
 }
 const values=input.decode(bytes,limits);
 const result=call(name,f.params.map(p=>values[p.name]));
 return output.encode(result,limits);
}
export function callBinary(name,bytes,limits={}){return __callEncoded(name,bytes,limits,false);}
export function callCompact(name,bytes,limits={}){return __callEncoded(name,bytes,limits,true);}
// Same stable, well-typed caller inputs as call; the result owns every container.
// The checked source return type justifies trusted copying, not arbitrary input.
export function callOwned(name,args,limits={}){
 if(!Object.hasOwn(__ownedFunctions,name)||!Object.hasOwn(functions,name))throw Error('unsupported owned function');
 const result=__ownedImplementations[name](...args);return __ownedFunctions[name](result,createValueCaptureBudget(limits),0);
}
function __privateCapture5(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture6(value[i],budget,depth+1);return out;}
function __privateCapture2(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture1(value[i],budget,depth+1);return out;}
function __privateCapture8(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture9(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture10(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture11(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture12(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture10(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture6(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"op")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"av")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"bv")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}return {["op"]:__privateCapture4(value["op"],budget,depth+1),["a"]:__privateCapture4(value["a"],budget,depth+1),["b"]:__privateCapture4(value["b"],budget,depth+1),["av"]:__privateCapture1(value["av"],budget,depth+1),["bv"]:__privateCapture1(value["bv"],budget,depth+1),["value"]:__privateCapture1(value["value"],budget,depth+1)};}
function __privateCapture9(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"gradient")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["gradient"]:__privateCapture1(value["gradient"],budget,depth+1)};}
function __privateCapture12(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"gradient")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["gradient"]:__privateCapture1(value["gradient"],budget,depth+1)};}
function __privateCapture3(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"id")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["id"]:__privateCapture4(value["id"],budget,depth+1)};}
function __privateCapture0(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==1){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1)};}
function __privateCapture7(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='boolean'){throw Error('invalid value for wire schema');}budget.add(1);return value;}
function __privateCapture1(value,budget,depth=0){budget.enter(depth,4);let bits;if(typeof value==='number'&&Number.isFinite(value)){bits=__bits(value);if(!Number.isFinite(__float(bits))){throw Error('invalid value for wire schema');}}else{if(!(value!==null&&typeof value==='object'&&Object.hasOwn(value,'F32Bits')&&Object.keys(value).length===1)){throw Error('invalid value for wire schema');}bits=value.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295){throw Error('invalid value for wire schema');}}budget.add(4);return bits===0?0:bits;}
function __privateCapture10(value,budget,depth=0){budget.enter(depth,4);const text=value;if(typeof text!=='string'||!text.isWellFormed()||text.length>budget.limit){throw Error('invalid value for wire schema');}budget.text(text);return text;}
function __privateCapture4(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='number'||!Number.isInteger(value)||value<0||value>4294967295){throw Error('invalid value for wire schema');}budget.add(4);return value===0?0:value;}
function __privateWireValue9(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue10(reader);reader.finish(end);return value;}
function __privateWireValue4(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue1(reader);reader.finish(end);return value;}
function __privateWireValue13(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue15(reader)}:{Ok:__privateWireValue14(reader)};reader.finish(end);return value;}
function __privateWireValue17(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue15(reader)}:{Ok:__privateWireValue18(reader)};reader.finish(end);return value;}
function __privateWireValue2(reader){const end=reader.frame();const value={["Alias"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue12(reader){const end=reader.frame();const value={["nodes"]:__privateWireValue9(reader),["output"]:__privateWireValue6(reader),["stopZero"]:__privateWireValue11(reader)};reader.finish(end);return value;}
function __privateWireValue10(reader){const end=reader.frame();const value={["op"]:__privateWireValue7(reader),["a"]:__privateWireValue7(reader),["b"]:__privateWireValue7(reader),["av"]:__privateWireValue1(reader),["bv"]:__privateWireValue1(reader),["value"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue14(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["gradient"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue18(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["gradient"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue6(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["id"]:__privateWireValue7(reader)};reader.finish(end);return value;}
function __privateWireValue0(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue8(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue16(reader){const end=reader.frame();const value={["x"]:__privateWireValue1(reader),["__ink_reverse_19"]:__privateWireValue7(reader),["__ink_reverse_20"]:__privateWireValue11(reader)};reader.finish(end);return value;}
function __privateWireValue19(reader){const end=reader.frame();const value={["x"]:__privateWireValue1(reader),["__ink_reverse_48"]:__privateWireValue7(reader),["__ink_reverse_49"]:__privateWireValue11(reader)};reader.finish(end);return value;}
function __privateWireValue3(reader){const end=reader.frame();const value={["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue5(reader){const end=reader.frame();const value={["xs"]:__privateWireValue4(reader)};reader.finish(end);return value;}
function __privateWireValue11(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __privateWireValue1(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __privateWireValue15(reader){const end=reader.frame();const value=reader.text(end,"string");reader.finish(end);return value;}
function __privateWireValue7(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __compiledOwnedValue5(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue6(value[i],budget,depth+1);return out;}
function __compiledOwnedValue2(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue1(value[i],budget,depth+1);return out;}
function __compiledOwnedValue8(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue9(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue10(value.Err,budget,depth+1)};}
function __compiledOwnedValue11(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue12(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue10(value.Err,budget,depth+1)};}
function __compiledOwnedValue6(value,budget,depth){budget.enter(depth,4);return {["op"]:__compiledOwnedValue4(value["op"],budget,depth+1),["a"]:__compiledOwnedValue4(value["a"],budget,depth+1),["b"]:__compiledOwnedValue4(value["b"],budget,depth+1),["av"]:__compiledOwnedValue1(value["av"],budget,depth+1),["bv"]:__compiledOwnedValue1(value["bv"],budget,depth+1),["value"]:__compiledOwnedValue1(value["value"],budget,depth+1)};}
function __compiledOwnedValue9(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["gradient"]:__compiledOwnedValue1(value["gradient"],budget,depth+1)};}
function __compiledOwnedValue12(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["gradient"]:__compiledOwnedValue1(value["gradient"],budget,depth+1)};}
function __compiledOwnedValue3(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["id"]:__compiledOwnedValue4(value["id"],budget,depth+1)};}
function __compiledOwnedValue0(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1)};}
function __compiledOwnedValue7(value,budget,depth){budget.enter(depth,5);return value;}
function __compiledOwnedValue1(value,budget,depth){budget.enter(depth,8);return {F32Bits:value===0?0:value};}
function __compiledOwnedValue10(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __compiledOwnedValue4(value,budget,depth){budget.enter(depth,8);return value>>>0;}
function __privateWireWrite5(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite6(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite2(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite1(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite8(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite9(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite10(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite11(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite12(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite10(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite6(writer,value,compact){const frame=writer.openFrame();__privateWireWrite4(writer,value["op"],compact);__privateWireWrite4(writer,value["a"],compact);__privateWireWrite4(writer,value["b"],compact);__privateWireWrite1(writer,value["av"],compact);__privateWireWrite1(writer,value["bv"],compact);__privateWireWrite1(writer,value["value"],compact);writer.closeFrame(frame);}
function __privateWireWrite9(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite1(writer,value["gradient"],compact);writer.closeFrame(frame);}
function __privateWireWrite12(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite1(writer,value["gradient"],compact);writer.closeFrame(frame);}
function __privateWireWrite3(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite4(writer,value["id"],compact);writer.closeFrame(frame);}
function __privateWireWrite0(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);writer.closeFrame(frame);}
function __privateWireWrite7(writer,value,compact){const frame=writer.openFrame();writer.byte(value?1:0);writer.closeFrame(frame);}
function __privateWireWrite1(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
function __privateWireWrite10(writer,value,compact){const frame=writer.openFrame();writer.text(value,compact);writer.closeFrame(frame);}
function __privateWireWrite4(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
// Handles have no mutable private payload surface. Membership and type identity
// are checked by this module's closure; copied/foreign objects cannot forge them.
const __compiledHandles=new WeakMap();
const __compiledBindings=new WeakMap();
function __compiledHandle(identity,value,guaranteed=false){
 const handle=Object.freeze(Object.create(null));
 __compiledHandles.set(handle,{identity,value,guaranteed});return handle;
}
function __compiledEntry(handle,identity){
 const entry=__compiledHandles.get(handle);
 if(!entry||entry.identity!==identity)throw Error('compiled value type or owner mismatch');
 return entry;
}
function __compiledUnwrap(handle,identity){return __compiledEntry(handle,identity).value;}
// Emit the portable schema's framing/scalar events without creating a buffer
// or exposing private composite nodes. Only this wrapper receives callbacks
// from the literal writer; host visitors never receive those closures.
function __compiledValueEvents(sink,limits){
 const methods=['begin','end','byte','word','wide','text','count'];
 for(const name of methods)if(typeof sink?.[name]!=='function')throw Error('compiled value visitor method: '+name);
 const budget=createValueCaptureBudget(limits);let depth=0,closed=false;
 const active=()=>{if(closed)throw Error('compiled value visitor is closed');};
 const writer=Object.freeze({
  openFrame(){active();budget.enter(depth,4);depth++;sink.begin();return 0;}
  ,closeFrame(){active();if(depth===0)throw Error('wire frame boundary');try{sink.end();}finally{depth--;}}
  ,frame(emit){active();budget.enter(depth,4);depth++;sink.begin();try{emit();sink.end();}finally{depth--;}}
  ,byte(value){active();budget.add(1);sink.byte(value);}
  ,word(value){active();budget.add(4);sink.word(value);}
  ,wide(value){active();budget.add(8);sink.wide(value);}
  ,text(value){active();budget.text(value);sink.text(value);}
  ,count(value){active();budget.add(4);if(value>budget.remaining)throw Error('wire sequence size');sink.count(value);}
 });
 return {writer,close(){closed=true;}};
}
function __compiledReduction(factory,root,reduce,identity){
 if(typeof factory!=='function')throw Error('compiled reduction factory');
 const reducers=[],seen=new Set(),nodes=__reductionNodes();
 const prepare=index=>{
  if(seen.has(index))return;seen.add(index);
  const node=nodes[index];
  for(const child of node.children)prepare(child);
  const reducer=factory(node,index);
  if(node.kind==='list'||node.kind==='vector'){
   const start=reducer?.start,step=reducer?.step,finish=reducer?.finish;
   if(typeof start!=='function'||typeof step!=='function'||typeof finish!=='function')throw Error('compiled collection reduction');
   reducers[index]=Object.freeze({start,step,finish});
  }else{
   if(typeof reducer!=='function')throw Error('compiled value reduction');
   reducers[index]=reducer;
  }
 };
 prepare(root);Object.freeze(reducers);
 return Object.freeze(function(handle,context,limits={}){
  const value=__compiledUnwrap(handle,identity),budget=createValueCaptureBudget(limits);
  return reduce(value,reducers,budget,0,context);
 });
}
function __compiledCodec(schema,capture,read,write,copy,constructorRoot,reductionRoot,reduce,portableFused=false,compactFused=false){
 const privateCodec=createCompiledValueCodec(schema,read),publicCodec=privateCodec;
 let fusedCodec;const fused=()=>fusedCodec??=createFusedValueCodec(schema,read);
 const identity=schema.identity;
 const codec=Object.freeze({
  identity,
  descriptor:publicCodec.descriptor,
  resolve(type){return publicCodec.resolve(type);},
  capture(value,limits={}){
   return __compiledHandle(identity,capture(value,createValueCaptureBudget(limits),0));
  },
  decode(bytes,limits={}){return __compiledHandle(identity,(portableFused?fused():privateCodec).decode(bytes,limits));},
  decodeCompact(bytes,limits={}){return __compiledHandle(identity,(compactFused?fused():privateCodec).compact().decode(bytes,limits));},
  decodeFused(bytes,limits={}){return __compiledHandle(identity,fused().decode(bytes,limits));},
  decodeCompactFused(bytes,limits={}){return __compiledHandle(identity,fused().compact().decode(bytes,limits));},
  encode(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.encodeWith(writer=>write(writer,value,false),limits);},
  encodeCompact(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.compact().encodeWith(writer=>write(writer,value,true),limits);},
  materialize(handle,limits={}){return copy(__compiledUnwrap(handle,identity),createValueCaptureBudget(limits),0);},
  builder(limits={}){return __valueBuilder(__constructorNodes(),constructorRoot,identity,limits);},
  reducer(factory){return __compiledReduction(factory,reductionRoot,reduce,identity);},
  visit(handle,sink,limits={}){
   const value=__compiledUnwrap(handle,identity),events=__compiledValueEvents(sink,limits);
   try{write(events.writer,value,false);}finally{events.close();}
  },
 });
 __compiledBindings.set(codec,{publicCodec,write,capture});return codec;
}

function __compiledEncodeResult(entry,value,limits,compact){
 const {publicCodec,write}=__compiledBindings.get(entry.result());
 return (compact?publicCodec.compact():publicCodec).encodeWith(writer=>write(writer,value,compact),limits);
}
let __constructorNodesValue;function __constructorNodes(){return __constructorNodesValue??=[{kind:'record',fields:["value"],patterns:[{bytes:4,label:"record",children:[1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0]})}]},{kind:"f32",scalar:__privateCapture1},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[1],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["value","id"],patterns:[{bytes:4,label:"record",children:[1,4],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["id"]:values[1]})}]},{kind:"u32",scalar:__privateCapture4},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[6],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["op","a","b","av","bv","value"],patterns:[{bytes:4,label:"record",children:[4,4,4,1,1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["op"]:values[0],["a"]:values[1],["b"]:values[2],["av"]:values[3],["bv"]:values[4],["value"]:values[5]})}]},{kind:"bool",scalar:__privateCapture7},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[9],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[10],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'record',fields:["value","gradient"],patterns:[{bytes:4,label:"record",children:[1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["gradient"]:values[1]})}]},{kind:"string",scalar:__privateCapture10},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[12],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[10],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'record',fields:["value","gradient"],patterns:[{bytes:4,label:"record",children:[1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["gradient"]:values[1]})}]}];}
// Typed input construction only: plans contain literal constructor/capture
// functions emitted from source schemas. No source expression evaluator.
// All frames and private values remain in this closure; callers receive only
// an owned opaque handle after one complete, well-typed root is constructed.
const __constructorPaths=new WeakMap();
function __valueBuilder(nodes,root,identity,limits){
 const budget=createValueCaptureBudget(limits),frames=[];
 let result,targetNode,targetDepth,complete=false,closed=false,failed=false,busy=false;
 const fail=message=>{failed=true;frames.length=0;result=undefined;throw Error(message);};
 const active=()=>{if(failed||closed)throw Error('value builder is closed');};
 const expected=()=>{
  if(!frames.length){if(complete)fail('value builder root already complete');targetNode=root;targetDepth=0;return;}
  const frame=frames.at(-1),position=frame.values.length;
  if(!frame.pattern.sequence&&position>=frame.pattern.children.length)fail('value builder constructor is full');
  targetNode=frame.pattern.sequence?frame.pattern.children[0]:frame.pattern.children[position];targetDepth=frame.depth+frame.pattern.childDepth;
 };
 const accept=value=>{
  if(frames.length)frames.at(-1).values.push(value);
  else{result=value;complete=true;}
 };
 const execute=(operation,first,second)=>{
  active();if(busy)throw Error('value builder operation already active');busy=true;
  try{return operation(first,second);}catch(error){failed=true;frames.length=0;result=undefined;throw error;}finally{busy=false;}
 };
 // Compile and cache constructor paths independently of the session's values.
 const pathPlan=(choices,startNode,startDepth)=>{
   if(!Array.isArray(choices)||choices.length===0||choices.length>128)fail('invalid value builder path');
   let cache=__constructorPaths.get(nodes);if(!cache){cache=new WeakMap();__constructorPaths.set(nodes,cache);}
   let entries=cache.get(choices),saved=entries?.get(startNode);
   if(saved)return saved;
   const path=[],charges=[];let node=startNode,depth=startDepth;
   for(let i=0;i<choices.length;i++){
    const choice=choices[i],patterns=nodes[node].patterns;
    if(!Number.isSafeInteger(choice)||choice<0||!patterns||choice>=patterns.length)fail('invalid value builder constructor');
    const pattern=patterns[choice];charges.push([pattern,depth-startDepth]);path.push({pattern,node:nodes[node]});
    if(i+1<choices.length){if(pattern.sequence||pattern.children.length!==1)fail('value builder path is not unary');node=pattern.children[0];depth+=pattern.childDepth;}
   }
   const terminal=path.at(-1).pattern;
   // Compose literal constructor functions once per path, instead of
   // allocating and interpreting another recursive closure for every value.
   const compose=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=args=>args[0];
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=args=>p.make([inner(args)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?compose(last+1):args=>args[0]):compose(last);
     return args=>node.flat(index,payload(args));
    }
    const inner=at+1<path.length?compose(at+1):null;
    if(pattern.transparent)return inner??(args=>args[0]);
    return inner?args=>pattern.make([inner(args)]):pattern.make;
   };
   const make=compose(0);
   // Scalar paths use the same literal constructors, but pass the leaf
   // directly through erased records and flat sums. No temporary argument
   // array is needed at those edges. Ordinary constructors keep their array
   // calling convention; no private value reaches the public builder API.
   const composeScalar=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=value=>value;
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=value=>p.make([inner(value)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?composeScalar(last+1):value=>value):composeScalar(last);
     return value=>node.flat(index,payload(value));
    }
    const inner=at+1<path.length?composeScalar(at+1):null;
    if(pattern.transparent)return inner??(value=>value);
    return inner?value=>pattern.make([inner(value)]):value=>pattern.make([value]);
   };
   const scalar=composeScalar(0);
   const pattern={...terminal,make};
   // Only frozen arrays of ordinary data properties can key reusable plans.
   // Mutable arrays and frozen accessor arrays retain checked per-call paths.
   const fixed=charges.every(([p])=>Number.isSafeInteger(p.bytes)&&p.bytes>=4);
   const plan={pattern,scalar,charges,offset:depth-startDepth,bytes:fixed?charges.reduce((n,[p])=>n+p.bytes,0):null};
   let reusable=Object.isFrozen(choices);
   for(let i=0;reusable&&i<choices.length;i++){const field=Object.getOwnPropertyDescriptor(choices,String(i));reusable=!!field&&Object.hasOwn(field,'value');}
   if(reusable){
    if(!entries){entries=new Map();cache.set(choices,entries);}entries.set(startNode,plan);
   }
   return plan;
 };
 const chargePath=(plan,depth)=>{
  // Each emitted constructor consumes one node and a fixed frame/tag cost.
  // Only take the combined charge when every original check would succeed.
  // Replaying the original order retains the exact first failure otherwise.
  if(plan.bytes!==null&&depth+plan.offset<=budget.depth&&plan.charges.length<=budget.remaining&&budget.bytes+plan.bytes<=budget.limit){
   budget.remaining-=plan.charges.length;budget.bytes+=plan.bytes;return;
  }
  for(const [pattern,offset]of plan.charges)pattern.charge(budget,depth+offset);
 };
 // Operations are allocated once per session, and share expected-node
 // scratch only while the existing reentrancy guard is held.
 const openOperation=(choice)=>{
   expected();const node=nodes[targetNode];
   if(!Number.isSafeInteger(choice)||choice<0||!node.patterns||choice>=node.patterns.length)fail('invalid value builder constructor');
   const pattern=node.patterns[choice];pattern.charge(budget,targetDepth);
   frames.push({pattern,depth:targetDepth,values:[]});
 };
 const openPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth);
   chargePath(plan,targetDepth);
   frames.push({pattern:plan.pattern,depth:targetDepth+plan.offset,values:[]});
 };
 const scalarPathOperation=(choices,value)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==1)fail('value builder path has no scalar leaf');
   const capture=nodes[pattern.children[0]].scalar;
   if(typeof capture!=='function')fail('value builder path has no scalar leaf');
   chargePath(plan,targetDepth);
   const leaf=capture(value,budget,targetDepth+plan.offset+pattern.childDepth);
   accept(plan.scalar(leaf));
 };
 const emptyPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==0)fail('value builder path is not empty');
   chargePath(plan,targetDepth);accept(pattern.make([]));
 };
 const scalarOperation=(value)=>{
   expected();const capture=nodes[targetNode].scalar;
   if(typeof capture!=='function')fail('value builder expects a constructor');
   accept(capture(value,budget,targetDepth));
 };
 const closeOperation=()=>{
   if(!frames.length)fail('value builder has no open constructor');
   const frame=frames.at(-1),pattern=frame.pattern,count=frame.values.length;
   if(!pattern.sequence&&count!==pattern.children.length||pattern.size!==undefined&&count!==pattern.size)fail('value builder constructor arity');
   if(pattern.sequence&&count>budget.limit)fail('wire sequence size');
   const value=pattern.make(frame.values);
   frames.pop();accept(value);
 };
 const finishOperation=()=>{
   if(frames.length||!complete)fail('value builder root is incomplete');
   closed=true;const handle=__compiledHandle(identity,result);result=undefined;return handle;
 };
 const api=Object.freeze({
  open(choice){return execute(openOperation,choice);},
  // Charge every source constructor even when unary paths share one frame.
  openPath(choices){return execute(openPathOperation,choices);},
  // Complete the path and leaf without intermediate session frames.
  scalarPath(choices,value){return execute(scalarPathOperation,choices,value);},
  emptyPath(choices){return execute(emptyPathOperation,choices);},
  scalar(value){return execute(scalarOperation,value);},
  close(){return execute(closeOperation);},
  finish(){return execute(finishOperation);},
  abort(){if(busy)throw Error('value builder operation already active');failed=true;frames.length=0;result=undefined;},
 });
 return api;
}
function __reduceValue0(value,r,b,d,c){b.enter(d,4);return r[0](__reduceValue1(value["value"],r,b,d+1,c),c);}
function __reduceValue1(value,r,b,d,c){b.enter(d,8);return r[1]({F32Bits:value},c);}
function __reduceValue2(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[2];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue1(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue3(value,r,b,d,c){b.enter(d,4);return r[3](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue4(value["id"],r,b,d+1,c),c);}
function __reduceValue4(value,r,b,d,c){b.enter(d,8);return r[4](value,c);}
function __reduceValue5(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[5];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue6(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue6(value,r,b,d,c){b.enter(d,4);return r[6](__reduceValue4(value["op"],r,b,d+1,c),__reduceValue4(value["a"],r,b,d+1,c),__reduceValue4(value["b"],r,b,d+1,c),__reduceValue1(value["av"],r,b,d+1,c),__reduceValue1(value["bv"],r,b,d+1,c),__reduceValue1(value["value"],r,b,d+1,c),c);}
function __reduceValue7(value,r,b,d,c){b.enter(d,5);return r[7](value,c);}
function __reduceValue8(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[8](0,__reduceValue9(value.Ok,r,b,d+1,c),c):r[8](1,__reduceValue10(value.Err,r,b,d+1,c),c);}
function __reduceValue9(value,r,b,d,c){b.enter(d,4);return r[9](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue1(value["gradient"],r,b,d+1,c),c);}
function __reduceValue10(value,r,b,d,c){b.enter(d,4);b.text(value);return r[10](value,c);}
function __reduceValue11(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[11](0,__reduceValue12(value.Ok,r,b,d+1,c),c):r[11](1,__reduceValue10(value.Err,r,b,d+1,c),c);}
function __reduceValue12(value,r,b,d,c){b.enter(d,4);return r[12](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue1(value["gradient"],r,b,d+1,c),c);}
let __reductionNodeCache;function __reductionNodes(){return __reductionNodeCache??=Object.freeze([Object.freeze({"children":Object.freeze([1]),"fields":Object.freeze(["value"]),"kind":"record","name":"DevicePoint"}),Object.freeze({"children":Object.freeze([]),"kind":"f32"}),Object.freeze({"children":Object.freeze([1]),"kind":"list"}),Object.freeze({"children":Object.freeze([1,4]),"fields":Object.freeze(["value","id"]),"kind":"record","name":"__ink_reverse_0_Wire"}),Object.freeze({"children":Object.freeze([]),"kind":"u32"}),Object.freeze({"children":Object.freeze([6]),"kind":"list"}),Object.freeze({"children":Object.freeze([4,4,4,1,1,1]),"fields":Object.freeze(["op","a","b","av","bv","value"]),"kind":"record","name":"__ink_reverse_0_Node"}),Object.freeze({"children":Object.freeze([]),"kind":"bool"}),Object.freeze({"children":Object.freeze([9,10]),"kind":"result"}),Object.freeze({"children":Object.freeze([1,1]),"fields":Object.freeze(["value","gradient"]),"kind":"record","name":"__ink_reverse_25"}),Object.freeze({"children":Object.freeze([]),"kind":"string"}),Object.freeze({"children":Object.freeze([12,10]),"kind":"result"}),Object.freeze({"children":Object.freeze([1,1]),"fields":Object.freeze(["value","gradient"]),"kind":"record","name":"__ink_reverse_54"})]);}
function __compiledNamed0(){return {};}
let __compiledCodec0Value;function __compiledCodec0(){return __compiledCodec0Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fdca1da93419e3f6d16318b990d113ebb5af1bcd85945be363f1b74b09e11b38","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"DevicePoint"}},__privateCapture0,__privateWireValue0,__privateWireWrite0,__compiledOwnedValue0,0,0,__reduceValue0,false,false);}
let __compiledCodec1Value;function __compiledCodec1(){return __compiledCodec1Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":__compiledNamed0(),"root":{"kind":"f32"}},__privateCapture1,__privateWireValue1,__privateWireWrite1,__compiledOwnedValue1,1,1,__reduceValue1,false,false);}
let __compiledCodec2Value;function __compiledCodec2(){return __compiledCodec2Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":__compiledNamed0(),"root":{"element":{"kind":"f32"},"kind":"list"}},__privateCapture2,__privateWireValue4,__privateWireWrite2,__compiledOwnedValue2,2,2,__reduceValue2,false,false);}
let __compiledCodec3Value;function __compiledCodec3(){return __compiledCodec3Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fabc4e63e940c6190680726874c8654deced79200b320c057b9389a135a08557","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},__privateCapture3,__privateWireValue6,__privateWireWrite3,__compiledOwnedValue3,3,3,__reduceValue3,false,false);}
let __compiledCodec4Value;function __compiledCodec4(){return __compiledCodec4Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"8d20db2e18176975b811079510807748b5da77b30341fa86eaec165fb19262b0","named":__compiledNamed0(),"root":{"element":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"kind":"list"}},__privateCapture5,__privateWireValue9,__privateWireWrite5,__compiledOwnedValue5,5,5,__reduceValue5,false,false);}
let __compiledCodec5Value;function __compiledCodec5(){return __compiledCodec5Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":__compiledNamed0(),"root":{"kind":"bool"}},__privateCapture7,__privateWireValue11,__privateWireWrite7,__compiledOwnedValue7,7,7,__reduceValue7,false,false);}
let __compiledCodec6Value;function __compiledCodec6(){return __compiledCodec6Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff","named":__compiledNamed0(),"root":{"kind":"u32"}},__privateCapture4,__privateWireValue7,__privateWireWrite4,__compiledOwnedValue4,4,4,__reduceValue4,false,false);}
let __compiledCodec7Value;function __compiledCodec7(){return __compiledCodec7Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"ec732bc838055717d1ad026324fcc804a640c3e33a5b298aa112a2bb73f4dcd2","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_25"}}},__privateCapture8,__privateWireValue13,__privateWireWrite8,__compiledOwnedValue8,8,8,__reduceValue8,false,false);}
let __compiledCodec8Value;function __compiledCodec8(){return __compiledCodec8Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"4d31dbac47a4ec1e295bbe9599c1bb1b188420bba49432c1facff5adc778a3a9","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_54"}}},__privateCapture11,__privateWireValue17,__privateWireWrite11,__compiledOwnedValue11,11,11,__reduceValue11,false,false);}
const __compiledEntries=new Map([["device_value",{index:0,params:[__compiledCodec0],result:__compiledCodec1,arguments:__privateWireValue2,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["exclusive",{index:1,params:[__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue3,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["inclusive",{index:2,params:[__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue3,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["exclusive_value",{index:3,params:[__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue3,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["exclusive_gradient",{index:4,params:[__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue3,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["inclusive_value",{index:5,params:[__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue3,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["inclusive_gradient",{index:6,params:[__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue3,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["device",{index:7,params:[__compiledCodec2],result:__compiledCodec2,arguments:__privateWireValue5,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["__ink_reverse_0_constant",{index:8,params:[__compiledCodec1],result:__compiledCodec3,arguments:__privateWireValue8,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["__ink_reverse_0_backward",{index:16,params:[__compiledCodec4,__compiledCodec3,__compiledCodec5],result:__compiledCodec2,arguments:__privateWireValue12,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["__ink_reverse_24",{index:18,params:[__compiledCodec1,__compiledCodec6,__compiledCodec5],result:__compiledCodec7,arguments:__privateWireValue16,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["__ink_reverse_53",{index:20,params:[__compiledCodec1,__compiledCodec6,__compiledCodec5],result:__compiledCodec8,arguments:__privateWireValue19,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}]]);

export const compiledValues=Object.freeze(Object.fromEntries([...__compiledEntries].map(([name,entry])=>[name,Object.freeze({get params(){return Object.freeze(entry.params.map(codec=>codec()));},get result(){return entry.result();}})])));
function __compiledValidate(entry,owned){
 const values=owned.map(v=>v.value);
 const established=entry.onlyTypeGuards&&entry.needsInvariants.every((needed,i)=>!needed||owned[i].guaranteed);
 if(entry.precondition!==null&&!established){
  if(__implementations[entry.precondition](...values)!==true)throw Error('contract precondition failed');
  for(let i=0;i<owned.length;i++)if(entry.needsInvariants[i])owned[i].guaranteed=true;
 }
 return values;
}
export function callCompiled(name,args){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(args)||args.length!==entry.params.length)throw Error('unsupported compiled call');
 const owned=entry.params.map((codec,i)=>__compiledEntry(args[i],codec().identity)),values=__compiledValidate(entry,owned);
 // Checked source outputs satisfy their declared value interfaces. Private
 // handles expose only detached copies and never retain mutable host inputs.
 return __compiledHandle(entry.result().identity,__implementations[entry.index](...values),true);
}

// Explicit sealed-value partial application. Each token owns a bounded set of
// lexical caches; no mutable host object, global memo table or error is retained.
const __preparedCompiled=new WeakMap();
export function prepareCompiled(name,bindings){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(bindings)||bindings.length>entry.params.length)throw Error('unsupported prepared compiled call');
 const captured=new Array(entry.params.length),fixed=new Array(entry.params.length).fill(false);
 for(const binding of bindings){
  if(!Array.isArray(binding)||binding.length!==2)throw Error('prepared compiled binding');
  const [index,handle]=binding;
  if(!Number.isInteger(index)||index<0||index>=fixed.length||fixed[index])throw Error('prepared compiled parameter');
  captured[index]=__compiledEntry(handle,entry.params[index]().identity);fixed[index]=true;
 }
 const remaining=fixed.flatMap((yes,i)=>yes?[]:[i]);
 const factory=__preparedFactories.get(entry.index);
 const run=factory?factory(fixed):__implementations[entry.index];
 const token=Object.freeze(Object.create(null));
 __preparedCompiled.set(token,{entry,captured,remaining,run});return token;
}
export function callPreparedCompiled(token,args){
 const prepared=__preparedCompiled.get(token);
 if(!prepared||!Array.isArray(args)||args.length!==prepared.remaining.length)throw Error('invalid prepared compiled call');
 const {entry,captured,remaining,run}=prepared,owned=captured.slice();
 for(let i=0;i<remaining.length;i++){const at=remaining[i];owned[at]=__compiledEntry(args[i],entry.params[at]().identity);}
 const values=__compiledValidate(entry,owned);
 return __compiledHandle(entry.result().identity,run(...values),true);
}
const __intoOutput7=__representation(metadata.functions[7].result.element,true);
const __intoOutput16=__representation(metadata.functions[16].result.element,true);
const __intoImplementations=[null,null,null,null,null,null,null,__into7,null,null,null,null,null,null,null,null,__into16,null,null,null,null];

export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>{
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const body=__intoImplementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args.slice(0,f.params.length))!==true)throw Error('contract precondition failed');return body(...args);};
  const entry=input.every(c=>c===__identity)?implementation:(...values)=>{const context=new WeakMap();return implementation(...input.map((convert,i)=>convert(values[i],context)),values[f.params.length]);};
  return [f.name,entry];
})));
export function callInto(name,args,destination){switch(name){case "__ink_reverse_0_append":case "__ink_reverse_0_seed":case "__ink_reverse_0_binary":case "__ink_reverse_0_unary":case "__ink_reverse_0_add":case "__ink_reverse_0_back_node":case "__ink_reverse_0_back_step":case "__ink_reverse_1":case "__ink_reverse_26":throw new Error('temporary storage is internal to a pure invocation');}return functionsInto[name](...args,destination);}

function __preparedPart(mask,path){
 for(const field of path){
  if(mask===true)return true;
  if(!mask || typeof mask!=="object")return false;
  mask=Object.hasOwn(mask.fields,field)?mask.fields[field]:false;
 }
 return mask;
}
function __preparedStable(mask,path){const part=__preparedPart(mask,path);return part===true || (!!part && part.all===true);}
function __prepareFn3(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn3;const v1137=depth<15&&__preparedFactories.has(18)&&((__preparedStable(fixed[0],[])));
let v1135;
return function(v1132){const v1133=128;
const v1134=true;
let v1138;if(v1137){if(!v1135){const v1136=__preparedFactories.get(18);v1135=v1136([fixed[0],true,true],depth+1);}v1138=v1135(v1132,v1133,v1134);}else{v1138=__fn18(v1132,v1133,v1134);}
const v1139=v1138;
let v1140;if(Object.hasOwn(v1139,"Ok")){
const v1141=v1139["Ok"];
v1140=v1141["value"];}else{
const v1142=v1139["Err"];
const v1143=1065353216;
v1140=((v1143 ^ 2147483648) >>> 0);}
return v1140;};}
function __prepareFn4(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn4;const v1149=depth<15&&__preparedFactories.has(18)&&((__preparedStable(fixed[0],[])));
let v1147;
return function(v1144){const v1145=128;
const v1146=true;
let v1150;if(v1149){if(!v1147){const v1148=__preparedFactories.get(18);v1147=v1148([fixed[0],true,true],depth+1);}v1150=v1147(v1144,v1145,v1146);}else{v1150=__fn18(v1144,v1145,v1146);}
const v1151=v1150;
let v1152;if(Object.hasOwn(v1151,"Ok")){
const v1153=v1151["Ok"];
v1152=v1153["gradient"];}else{
const v1154=v1151["Err"];
const v1155=1065353216;
v1152=((v1155 ^ 2147483648) >>> 0);}
return v1152;};}
function __prepareFn5(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn5;const v1161=depth<15&&__preparedFactories.has(20)&&((__preparedStable(fixed[0],[])));
let v1159;
return function(v1156){const v1157=128;
const v1158=true;
let v1162;if(v1161){if(!v1159){const v1160=__preparedFactories.get(20);v1159=v1160([fixed[0],true,true],depth+1);}v1162=v1159(v1156,v1157,v1158);}else{v1162=__fn20(v1156,v1157,v1158);}
const v1163=v1162;
let v1164;if(Object.hasOwn(v1163,"Ok")){
const v1165=v1163["Ok"];
v1164=v1165["value"];}else{
const v1166=v1163["Err"];
const v1167=1065353216;
v1164=((v1167 ^ 2147483648) >>> 0);}
return v1164;};}
function __prepareFn6(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn6;const v1173=depth<15&&__preparedFactories.has(20)&&((__preparedStable(fixed[0],[])));
let v1171;
return function(v1168){const v1169=128;
const v1170=true;
let v1174;if(v1173){if(!v1171){const v1172=__preparedFactories.get(20);v1171=v1172([fixed[0],true,true],depth+1);}v1174=v1171(v1168,v1169,v1170);}else{v1174=__fn20(v1168,v1169,v1170);}
const v1175=v1174;
let v1176;if(Object.hasOwn(v1175,"Ok")){
const v1177=v1175["Ok"];
v1176=v1177["gradient"];}else{
const v1178=v1175["Err"];
const v1179=1065353216;
v1176=((v1179 ^ 2147483648) >>> 0);}
return v1176;};}
function __prepareFn18(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn18;const v1442=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v1441=false,v1440;
const v1447=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
const v1452=depth<15&&__preparedFactories.has(16)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])));
let v1450;
return function(v1309,v1310,v1311){const v1312=1000000;
const v1313=((v1310) > (v1312));
let v1314;if(v1313){
v1314=({Err:"reverse differentiation capacity exceeds one million nodes"});}else{
const v1316=new __InkBuffer([]);
const v1317=false;
const v1320=0;
const v1321=4294967295;
const v1322=4294967295;
const v1323=0;
const v1324=0;
const v1326=true;
const v1327=false;
const v1328=(v1326===v1327);
let v1329=v1328;if(!v1329){
v1329=v1317;}
let v1330;
let v1331;
if(v1329){
const v1332=__fn8(v1309);
const v1333=({["nodes"]:v1316,["maximum"]:v1310,["failed"]:v1317});
v1330=v1332;
v1331=v1333;
}else{
const v1334=(v1316).length;
let v1335;
let v1336;
if(((v1334) >= (v1310))){
const v1337=__fn8(v1309);
const v1338=true;
const v1339=({["nodes"]:v1316,["maximum"]:v1310,["failed"]:v1338});
v1335=v1337;
v1336=v1339;
}else{
const v1340=({["value"]:v1309,["id"]:v1334});
const v1341=({["op"]:v1320,["a"]:v1321,["b"]:v1322,["av"]:v1323,["bv"]:v1324,["value"]:v1309});
const v1342=__tempEdit(v1316,"push",v1341);
const v1343=({["nodes"]:v1342,["maximum"]:v1310,["failed"]:v1317});
v1335=v1340;
v1336=v1343;
}
v1330=v1335;
v1331=v1336;
}
const v1315=({["value"]:v1330,["tape"]:v1331});
const v1345=v1315;
const v1346=v1345["value"];
const v1347=v1315;
const v1348=v1347["tape"];
const v1349=10;
const v1352=false;
let v1353=v1346;
let v1354=v1348;
let v1355=v1352;
for(let v1357=0;v1357<v1349;v1357++){
if(v1355){break;}
const v1358=(v1357>>>0);
const v1359=v1353;
const v1360=v1354;
const v1362=1090519040;
const v1363=__fn8(v1362);
const v1365=v1359["value"];
const v1366=v1363["value"];
const v1367=((__float(v1365)) >= (__float(v1366)));
let v1369;
let v1370;
let v1371;
if(v1367){
const v1372=v1353;
const v1373=true;
v1369=v1372;
v1370=v1360;
v1371=v1373;
}else{
const v1374=v1353;
const v1376=1073741824;
const v1377=__fn8(v1376);
const v1379=3;
const v1380=1;
let v1381;if((v1379===v1380)){
const v1382=v1374["value"];
const v1383=v1377["value"];
v1381=__bits(__float(v1382) + __float(v1383));}else{
const v1384=2;
let v1385;if((v1379===v1384)){
const v1386=v1374["value"];
const v1387=v1377["value"];
v1385=__bits(__float(v1386) - __float(v1387));}else{
const v1388=3;
let v1389;if((v1379===v1388)){
const v1390=v1374["value"];
const v1391=v1377["value"];
v1389=__bits(__float(v1390) * __float(v1391));}else{
v1389=__bits((__float(v1374["value"]))/(__float(v1377["value"])));}
v1385=v1389;}
v1381=v1385;}
const v1392=v1381;
const v1393=v1374["id"];
const v1394=v1377["id"];
const v1395=v1374["value"];
const v1396=v1377["value"];
const v1398=v1374["id"];
const v1399=4294967295;
const v1400=!(v1398===v1399);
let v1401=v1400;if(!v1401){
const v1402=v1377["id"];
const v1403=4294967295;
v1401=!(v1402===v1403);}
const v1404=v1401;
const v1405=false;
const v1406=(v1404===v1405);
let v1407=v1406;if(!v1407){
v1407=v1360["failed"];}
let v1408;
let v1409;
if(v1407){
const v1410=__fn8(v1392);
v1408=v1410;
v1409=v1360;
}else{
const v1411=v1360["nodes"];
const v1412=(v1411).length;
const v1413=v1360["maximum"];
let v1414;
let v1415;
if(((v1412) >= (v1413))){
const v1416=__fn8(v1392);
const v1417=true;
const v1418=v1360["nodes"];
const v1419=v1360["maximum"];
const v1420=({["nodes"]:v1418,["maximum"]:v1419,["failed"]:v1417});
v1414=v1416;
v1415=v1420;
}else{
const v1421=({["value"]:v1392,["id"]:v1412});
const v1422=v1360["nodes"];
const v1423=({["op"]:v1379,["a"]:v1393,["b"]:v1394,["av"]:v1395,["bv"]:v1396,["value"]:v1392});
const v1424=__tempEdit(v1422,"push",v1423);
const v1425=v1360["maximum"];
const v1426=v1360["failed"];
const v1427=({["nodes"]:v1424,["maximum"]:v1425,["failed"]:v1426});
v1414=v1421;
v1415=v1427;
}
v1408=v1414;
v1409=v1415;
}
const v1429=v1408;
const v1430=v1409;
const v1431=false;
v1369=v1429;
v1370=v1430;
v1371=v1431;
}
v1353=v1369;
v1354=v1370;
v1355=v1371;
}
const v1433=v1353;
const v1434=v1354;
const v1344=({["value"]:v1433,["tape"]:v1434});
const v1435=v1344;
const v1436=v1435["tape"];
const v1437=v1436["failed"];
let v1438;if(v1437){
v1438=({Err:"reverse differentiation tape capacity exceeded"});}else{
let v1439;if(v1442&&v1441){v1439=v1440;}else{
const v1443=v1344;
const v1444=v1443["tape"];
const v1445=v1444["nodes"];
const v1446=v1445.freeze();
const v1448=v1344;
const v1449=v1448["value"];
let v1453;if(v1452){if(!v1450){const v1451=__preparedFactories.get(16);v1450=v1451([v1447,v1447,fixed[2]],depth+1);}v1453=v1450(v1446,v1449,v1311);}else{v1453=__fn16(v1446,v1449,v1311);}
v1439=v1453;if(v1442){v1440=v1439;v1441=true;}}
const v1454=v1344;
const v1455=v1454["value"];
const v1456=v1455["value"];
const v1457=v1439;
const v1458=v1315;
const v1459=v1458["value"];
const v1460=v1459["id"];
let v1461;if(v1460<v1457.length){v1461=v1457[v1460];}else{
v1461=0;}
const v1462=v1461;
v1438=({Ok:({["value"]:v1456,["gradient"]:v1462})});}
v1314=v1438;}
return v1314;};}
function __prepareFn20(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn20;const v1602=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]);
let v1601=false,v1600;
const v1607=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
const v1612=depth<15&&__preparedFactories.has(16)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])));
let v1610;
return function(v1463,v1464,v1465){const v1466=1000000;
const v1467=((v1464) > (v1466));
let v1468;if(v1467){
v1468=({Err:"reverse differentiation capacity exceeds one million nodes"});}else{
const v1470=new __InkBuffer([]);
const v1471=false;
const v1474=0;
const v1475=4294967295;
const v1476=4294967295;
const v1477=0;
const v1478=0;
const v1480=true;
const v1481=false;
const v1482=(v1480===v1481);
let v1483=v1482;if(!v1483){
v1483=v1471;}
let v1484;
let v1485;
if(v1483){
const v1486=__fn8(v1463);
const v1487=({["nodes"]:v1470,["maximum"]:v1464,["failed"]:v1471});
v1484=v1486;
v1485=v1487;
}else{
const v1488=(v1470).length;
let v1489;
let v1490;
if(((v1488) >= (v1464))){
const v1491=__fn8(v1463);
const v1492=true;
const v1493=({["nodes"]:v1470,["maximum"]:v1464,["failed"]:v1492});
v1489=v1491;
v1490=v1493;
}else{
const v1494=({["value"]:v1463,["id"]:v1488});
const v1495=({["op"]:v1474,["a"]:v1475,["b"]:v1476,["av"]:v1477,["bv"]:v1478,["value"]:v1463});
const v1496=__tempEdit(v1470,"push",v1495);
const v1497=({["nodes"]:v1496,["maximum"]:v1464,["failed"]:v1471});
v1489=v1494;
v1490=v1497;
}
v1484=v1489;
v1485=v1490;
}
const v1469=({["value"]:v1484,["tape"]:v1485});
const v1499=v1469;
const v1500=v1499["value"];
const v1501=v1469;
const v1502=v1501["tape"];
const v1503=1n;
const v1505=2n;
const v1507=3n;
const v1509=4n;
const v1511=[v1503,v1505,v1507,v1509];
const v1514=false;
let v1515=v1500;
let v1516=v1502;
let v1517=v1514;
for(let v1519=0;v1519<v1511.length;v1519++){
const v1520=v1511[v1519];
const v1521=v1517;
let v1522;
let v1523;
let v1524;
if(v1517){
v1522=v1515;
v1523=v1516;
v1524=v1517;
}else{
const v1525=v1515;
const v1526=v1516;
const v1528=1082130432;
const v1529=__fn8(v1528);
const v1531=v1525["value"];
const v1532=v1529["value"];
const v1533=((__float(v1531)) >= (__float(v1532)));
const v1535=v1515;
const v1537=1073741824;
const v1538=__fn8(v1537);
const v1540=3;
const v1541=1;
let v1542;if((v1540===v1541)){
const v1543=v1535["value"];
const v1544=v1538["value"];
v1542=__bits(__float(v1543) + __float(v1544));}else{
const v1545=2;
let v1546;if((v1540===v1545)){
const v1547=v1535["value"];
const v1548=v1538["value"];
v1546=__bits(__float(v1547) - __float(v1548));}else{
const v1549=3;
let v1550;if((v1540===v1549)){
const v1551=v1535["value"];
const v1552=v1538["value"];
v1550=__bits(__float(v1551) * __float(v1552));}else{
v1550=__bits((__float(v1535["value"]))/(__float(v1538["value"])));}
v1546=v1550;}
v1542=v1546;}
const v1553=v1542;
const v1554=v1535["id"];
const v1555=v1538["id"];
const v1556=v1535["value"];
const v1557=v1538["value"];
const v1559=v1535["id"];
const v1560=4294967295;
const v1561=!(v1559===v1560);
let v1562=v1561;if(!v1562){
const v1563=v1538["id"];
const v1564=4294967295;
v1562=!(v1563===v1564);}
const v1565=v1562;
const v1566=false;
const v1567=(v1565===v1566);
let v1568=v1567;if(!v1568){
v1568=v1526["failed"];}
let v1569;
let v1570;
if(v1568){
const v1571=__fn8(v1553);
v1569=v1571;
v1570=v1526;
}else{
const v1572=v1526["nodes"];
const v1573=(v1572).length;
const v1574=v1526["maximum"];
let v1575;
let v1576;
if(((v1573) >= (v1574))){
const v1577=__fn8(v1553);
const v1578=true;
const v1579=v1526["nodes"];
const v1580=v1526["maximum"];
const v1581=({["nodes"]:v1579,["maximum"]:v1580,["failed"]:v1578});
v1575=v1577;
v1576=v1581;
}else{
const v1582=({["value"]:v1553,["id"]:v1573});
const v1583=v1526["nodes"];
const v1584=({["op"]:v1540,["a"]:v1554,["b"]:v1555,["av"]:v1556,["bv"]:v1557,["value"]:v1553});
const v1585=__tempEdit(v1583,"push",v1584);
const v1586=v1526["maximum"];
const v1587=v1526["failed"];
const v1588=({["nodes"]:v1585,["maximum"]:v1586,["failed"]:v1587});
v1575=v1582;
v1576=v1588;
}
v1569=v1575;
v1570=v1576;
}
const v1590=v1569;
const v1591=v1570;
v1522=v1590;
v1523=v1591;
v1524=v1533;
}
v1515=v1522;
v1516=v1523;
v1517=v1524;
if(v1521)break;
}
const v1593=v1515;
const v1594=v1516;
const v1498=({["value"]:v1593,["tape"]:v1594});
const v1595=v1498;
const v1596=v1595["tape"];
const v1597=v1596["failed"];
let v1598;if(v1597){
v1598=({Err:"reverse differentiation tape capacity exceeded"});}else{
let v1599;if(v1602&&v1601){v1599=v1600;}else{
const v1603=v1498;
const v1604=v1603["tape"];
const v1605=v1604["nodes"];
const v1606=v1605.freeze();
const v1608=v1498;
const v1609=v1608["value"];
let v1613;if(v1612){if(!v1610){const v1611=__preparedFactories.get(16);v1610=v1611([v1607,v1607,fixed[2]],depth+1);}v1613=v1610(v1606,v1609,v1465);}else{v1613=__fn16(v1606,v1609,v1465);}
v1599=v1613;if(v1602){v1600=v1599;v1601=true;}}
const v1614=v1498;
const v1615=v1614["value"];
const v1616=v1615["value"];
const v1617=v1599;
const v1618=v1469;
const v1619=v1618["value"];
const v1620=v1619["id"];
let v1621;if(v1620<v1617.length){v1621=v1617[v1620];}else{
v1621=0;}
const v1622=v1621;
v1598=({Ok:({["value"]:v1616,["gradient"]:v1622})});}
v1468=v1598;}
return v1468;};}
const __preparedFactories=new Map([[3,__prepareFn3],[4,__prepareFn4],[5,__prepareFn5],[6,__prepareFn6],[18,__prepareFn18],[20,__prepareFn20]]);
