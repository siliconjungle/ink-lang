const __recordElisions=new Set([]);
const __nativeF32=false;
// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
// Binary64 uses native Numbers for finite arithmetic and immutable private
// tags only where a NaN's exact payload must survive non-arithmetic operations.
const __doubleView=new DataView(new ArrayBuffer(8));
const __double=bits=>{__doubleView.setBigUint64(0,bits,true);return __doubleView.getFloat64(0,true);};
const __doubleBits=number=>{if(Number.isNaN(number))return 0x7ff8000000000000n;__doubleView.setFloat64(0,number,true);return __doubleView.getBigUint64(0,true);};
const __dfNumber=value=>typeof value==='number'?value:__double(BigInt(value.F64Bits));
const __dfBits=value=>typeof value==='number'?__doubleBits(value):BigInt(value.F64Bits);
const __dfFromBits=bits=>(bits&0x7fffffffffffffffn)>0x7ff0000000000000n?Object.freeze({F64Bits:bits.toString()}):__double(bits);
const __dfInput=value=>typeof value==='number'?value:__dfFromBits(BigInt(value.F64Bits));
const __dfNeg=value=>typeof value==='number'&&!Number.isNaN(value)?-value:__dfFromBits(__dfBits(value)^0x8000000000000000n);
const __dfOutput=value=>{const n=__dfNumber(value);return Number.isFinite(n)?n:{F64Bits:__dfBits(value).toString()};};
const __dfCapture=value=>{
 if(typeof value==='number'&&Number.isFinite(value))return value;
 if(!value||typeof value!=='object'||Object.keys(value).length!==1||!Object.hasOwn(value,'F64Bits'))throw Error('invalid f64');const text=value.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid f64');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');return __dfFromBits(bits);
};
// Native binary32 lane for pure modules. Explicit NaN payloads remain tagged;
// arithmetic canonicalizes NaNs just as __bits does in the exact-bit lane.
// Host tags are captured once at a typed read. Only private immutable tags
// may pass through normalization without consulting a host property again.
const __nfTagged = new WeakSet();
const __nfValue = value => typeof value === 'number' ? Math.fround(value) : __nfTagged.has(value) ? value : __nfFromBits(value.F32Bits);
// Number operands have already been normalised at their typed read or producer.
const __nfNumber = value => typeof value === 'number' ? value : __float(value.F32Bits);
const __nfBits = value => typeof value === 'number' ? __bits(value) : value.F32Bits;
const __nfFromBits = bits => {
  if((bits & 0x7fffffff)<=0x7f800000)return __float(bits);
  const value=Object.freeze({F32Bits:bits});__nfTagged.add(value);return value;
};
const __nfNeg = value => typeof value === 'number' && !Number.isNaN(value) ? -value : __nfFromBits((__nfBits(value) ^ 0x80000000) >>> 0);
const __nfOutput = value => {const n=typeof value==='number'?Math.fround(value):__float(value.F32Bits);return Number.isFinite(n)?n:{F32Bits:__nfBits(value)};};
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output, capture=false) {
  const convert=__representationRaw(type,output,capture);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':capture?'capture:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output, capture) {
  switch (type.kind) {
    case 'ref': {
      let resolved;
      return (value,context)=>(resolved??=__representation(__namedTypes[type.name],output,capture))(value,context);
    }
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output,capture);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output,capture),err=__representation(type.error,output,capture);
      const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);
      if(flat)return output?(value,context)=>{const v=__sumView(key,value);return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};}:(v,context)=>Object.hasOwn(v,'Ok')?__sumMake(key,true,ok(v.Ok,context)):__sumMake(key,false,err(v.Err,context));
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f64':return output?__dfOutput:__dfInput;
    case 'f32': if(typeof __nativeF32!=='undefined'&&__nativeF32)return output?__nfOutput:capture?__nfValue:__identity;
      return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output,capture);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){
        if(!type.fields.length)return ()=>undefined; // lexically unconsumed projected input
        const field=type.fields[0],child=__representation(field.type,output,capture);
        return output?(value,context)=>({[field.name]:child(value,context)}):(value,context)=>child(value[field.name],context);
      }
      const fields = type.fields.map(field => [field.name, __representation(field.type, output,capture)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
function __stateWord(value){
 if(typeof value==='number'&&!Number.isSafeInteger(value))throw Error('u64 requires an exact integer');
 if(!['bigint','number','string'].includes(typeof value)||typeof value==='string'&&!/^(0|[1-9][0-9]*)$/.test(value))throw Error('invalid u64');
 const n=BigInt(value);if(n<0n||n>18446744073709551615n)throw Error('invalid u64');return n;
}
// Compile the capture traversal once. Each invocation still validates and owns
// every public container; no host value is retained between calls.
const __stateCaptures=new WeakMap();
function __stateCapture(type){
 const prior=__stateCaptures.get(type);if(prior)return prior;
 const capture=__compileStateCapture(type);__stateCaptures.set(type,capture);return capture;
}
function __compileStateCapture(type){
 const limited=copy=>(value,budget={cells:1000000},depth=0)=>{
  if(depth>64||--budget.cells<0)throw Error('state input resource limit');
  return copy(value,budget,depth);
 };
 const tagged=(value,tag)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
 switch(type.kind){
  case 'ref':{
   // Resolve lazily so recursive schemas compile to recursive validators rather
   // than reverting to descriptor interpretation at every referenced node.
   let resolved;
   return limited((value,budget,depth)=>(resolved??=__stateCapture(__namedTypes[type.name]))(value,budget,depth+1));
  }
  case 'u32':case 'i32':{
   const min=type.kind==='u32'?0:-2147483648,max=type.kind==='u32'?4294967295:2147483647;
   return limited(value=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;});
  }
  case 'u64':return limited(__stateWord);
  case 'f64':return limited(__dfCapture);
  case 'bool':return limited(value=>{if(typeof value!=='boolean')throw Error('invalid Bool');return value;});
  case 'unit':return limited(value=>{if(value!==null)throw Error('invalid Unit');return null;});
  case 'string':return limited(value=>{if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;});
  case 'enum':return limited(value=>{if(!type.variants.includes(value))throw Error('invalid enum');return value;});
  case 'id':return limited(value=>{if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();});
  case 'list':case 'vector':{
   const item=__stateCapture(type.element),size=type.kind==='vector'?type.size:null;
   return limited((value,budget,depth)=>{
    if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
    if(size!==null&&value.length!==size)throw Error('invalid vector length');
    const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=item(value[i],budget,depth+1);return out;
   });
  }
  case 'record':{
   const fields=type.fields.map(f=>[f.name,__stateCapture(f.type)]);
   if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name)))return limited((value,budget,depth)=>{const [name,copy]=fields[0];if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,name))throw Error('invalid record');return copy(value[name],budget,depth+1);});
   return limited((value,budget,depth)=>{
    if(!value||typeof value!=='object'||Array.isArray(value)||!fields.every(([name])=>Object.hasOwn(value,name)))throw Error('invalid record');
    const out={};for(const [name,copy]of fields){const field=copy(value[name],budget,depth+1);if(name==='__proto__')Object.defineProperty(out,name,{value:field,writable:true,enumerable:true,configurable:true});else out[name]=field;}return out;
   });
  }
  case 'option':{
   const item=__stateCapture(type.element);
   return limited((value,budget,depth)=>{if(tagged(value,'Some'))return {Some:item(value.Some,budget,depth+1)};if(tagged(value,'None')&&value.None===null)return {None:null};throw Error('invalid Option');});
  }
  case 'result':{
   const ok=__stateCapture(type.ok),err=__stateCapture(type.error);
   return limited((value,budget,depth)=>{if(tagged(value,'Ok'))return {Ok:ok(value.Ok,budget,depth+1)};if(tagged(value,'Err'))return {Err:err(value.Err,budget,depth+1)};throw Error('invalid Result');});
  }
  default:return (value,budget,depth)=>__stateInput(value,type,budget,depth);
 }
}
function __stateInput(value,type,budget={cells:1000000},depth=0,maxDepth=64){
  if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');
  const input=(v,t)=>__stateInput(v,t,budget,depth+1,maxDepth);
  const integer=(min,max)=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;};
  const tagged=tag=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
  switch(type.kind){
    case 'ref':return input(value,__namedTypes[type.name]);
    case 'u32':return integer(0,4294967295);
    case 'i32':return integer(-2147483648,2147483647);
    case 'u64':return __stateWord(value);
    case 'int':{
      if(typeof value==='bigint')return value;
      if(!tagged('Int')||typeof value.Int!=='string'||!/^(-?[0-9]+)$/.test(value.Int))throw Error('invalid Int');return BigInt(value.Int);
    }
    case 'f64':return __dfCapture(value);
    case 'f32':{
      if(typeof value==='number'&&Number.isFinite(value)){const bits=__bits(value);if((bits&0x7fffffff)===0x7f800000)throw Error('f32 overflow requires F32Bits');return bits;}
      if(!tagged('F32Bits')||!Number.isInteger(value.F32Bits)||value.F32Bits<0||value.F32Bits>4294967295)throw Error('invalid f32');return value.F32Bits;
    }
    case 'bool':if(typeof value!=='boolean')throw Error('invalid Bool');return value;
    case 'unit':if(value!==null)throw Error('invalid Unit');return null;
    case 'string':if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;
    case 'id':if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();
    case 'enum':if(!type.variants.includes(value))throw Error('invalid enum');return value;
    case 'list':case 'vector':{
      if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
      if(type.kind==='vector'&&value.length!==type.size)throw Error('invalid vector length');
      return Array.from(value,v=>input(v,type.element));
    }
    case 'record':if(!value||typeof value!=='object'||Array.isArray(value)||!type.fields.every(f=>Object.hasOwn(value,f.name)))throw Error('invalid record');if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){const f=type.fields[0];return input(value[f.name],f.type);}return Object.fromEntries(type.fields.map(f=>[f.name,input(value[f.name],f.type)]));
    case 'option':if(tagged('Some'))return {Some:input(value.Some,type.element)};if(tagged('None')&&value.None===null)return {None:null};throw Error('invalid Option');
    case 'result':{const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);if(tagged('Ok')){const child=input(value.Ok,type.ok);return flat?__sumMake(key,true,child):{Ok:child};}if(tagged('Err')){const child=input(value.Err,type.error);return flat?__sumMake(key,false,child):{Err:child};}throw Error('invalid Result');}
    default:throw Error('unsupported public value type');
  }
}
// Mutable host replies must not retain references into compiled state or its outbox.
// State results must own mutable containers. Compile the declared schema once:
// scalars need no structured clone, while nested records/lists remain detached.
function __ownershipSchema(type){
 // Nominal references and expanded declarations name the same checked sort.
 // Distinct source records retain distinct keys even if a layout erases them.
 if(type.kind==='ref'||type.kind==='record'&&type.name)return ['named',type.name];
 switch(type.kind){
  case 'list':case 'vector':return [type.kind,type.size??null,__ownershipSchema(type.element)];
  case 'option':return ['option',__ownershipSchema(type.element)];
  case 'result':return ['result',__ownershipSchema(type.ok),__ownershipSchema(type.error)];
  case 'record':return ['record',type.fields.map(f=>[f.name,__ownershipSchema(f.type)])];
  default:return type;
 }
}
function __ownedResult(copy,nested,type){
 const key='owned-state:'+JSON.stringify(__ownershipSchema(type));
 let schema=__conversionKeys.get(key);
 if(!schema){schema={};__conversionKeys.set(key,schema);}
 const owned=(value,context)=>{
  if(!context&&!nested)return copy(value,null);
  const memo=context||new WeakMap();
  if(value===null||typeof value!=='object')return copy(value,memo);
  let entries=memo.get(schema);if(!entries){entries=new WeakMap();memo.set(schema,entries);}
  if(entries.has(value))return entries.get(value);
  const result=copy(value,memo);entries.set(value,result);return result;
 };
 owned.container=true;return owned;
}
function __stateResult(type){
 switch(type.kind){
  case 'ref':{let resolved;const copy=(value,context)=>(resolved??=__stateResult(__namedTypes[type.name]))(value,context);copy.container=true;return copy;}
  case 'record':{if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){const f=type.fields[0],copy=__stateResult(f.type);return __ownedResult((value,context)=>({[f.name]:copy(value,context)}),copy.container,type);}const fields=type.fields.map(f=>[f.name,__stateResult(f.type)]);return __ownedResult((value,context)=>Object.fromEntries(fields.map(([name,copy])=>[name,copy(value[name],context)])),fields.some(([,copy])=>copy.container),type);}
  case 'list':case 'vector':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Array.from(value,item=>copy(item,context)),copy.container,type);}
  case 'option':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Object.hasOwn(value,'Some')?{Some:copy(value.Some,context)}:{None:null},copy.container,type);}
  case 'result':{const ok=__stateResult(type.ok),err=__stateResult(type.error),key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);return __ownedResult((value,context)=>{const v=flat?__sumView(key,value):value;return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};},ok.container||err.container,type);}
  default:return __representation(type,true);
 }
}
function __stateOutput(value,type){return __stateResult(type)(value);}
const __u64 = n => BigInt.asUintN(64, n);
function __div(a, b, fallback, signed, remainder) {
  if (b === 0 || b === 0n || (signed && a === -2147483648 && b === -1)) return fallback();
  return typeof a === 'bigint' ? (remainder ? a % b : a / b) :
    ((remainder ? a % b : Math.trunc(a / b)) + 0); // integer zero has no sign
}
function __at(xs, index, fallback) { return index < xs.length ? xs[index] : fallback(); }
// Ordinary arrays retain the declared result element type when input is typed.
function __map(xs, fn) {
  const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = fn(xs[i], i);
  return out;
}
function __filter(xs, fn) {
  const out = [];
  for (let i = 0; i < xs.length; i++) if (fn(xs[i])) out.push(xs[i]);
  return out;
}
function __concat(xs, ys) {
  const left = xs.length, right = ys.length, out = new Array(left + right);
  for (let i = 0; i < left; i++) out[i] = xs[i];
  for (let i = 0; i < right; i++) out[left + i] = ys[i];
  return out;
}
function __zip(xs, ys, fn) {
  const n = Math.min(xs.length, ys.length), out = new Array(n);
  for (let i = 0; i < n; i++) out[i] = fn(xs[i], ys[i]);
  return out;
}
function __repeat(n, initial, fn) { let value = initial; for (let i = 0; i < n; i++) value = fn(i, value); return value; }
function __foldr(xs, initial, fn) { let value = initial; for (let i = xs.length - 1; i >= 0; i--) value = fn(xs[i], value); return value; }
function __scan(xs, zero, add) {
  let value = zero; const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = value = add(value, xs[i]);
  return out;
}
const __sort = xs => Array.from(xs).sort((a,b) => a < b ? -1 : a > b ? 1 : 0);

function __wordSort(xs,Storage){
 const sorted=Storage.from(xs).sort(),out=new Array(sorted.length);
 for(let i=0;i<sorted.length;i++)out[i]=sorted[i];
 return out;
}
// Fixed primitives; no cross-invocation host caches.
function __ink_round_even(x){if(!Number.isFinite(x)||Math.abs(x)>=8388608)return x;const a=Math.abs(x),i=Math.floor(a),r=a-i;const y=i+Number(r>0.5||(r===0.5&&i%2===1));return x<0||Object.is(x,-0)?-y:y;}
function __ink_round_even_f64(x){if(!Number.isFinite(x)||Math.abs(x)>=4503599627370496)return x;const a=Math.abs(x),i=Math.floor(a),r=a-i;const y=i+Number(r>0.5||(r===0.5&&i%2===1));return x<0||Object.is(x,-0)?-y:y;}
// Direct BigInt -> binary32 avoids double rounding through binary64.
function __ink_big_float(x){if(x===0n)return 0;const neg=x<0n;if(neg)x=-x;let e=x.toString(2).length-1;if(e<=23)return Number(neg?-x:x);const shift=BigInt(e-23),mask=(1n<<shift)-1n;let q=x>>shift;const rem=x&mask,half=1n<<(shift-1n);if(rem>half||(rem===half&&(q&1n)!==0n))q++;if(q===16777216n){q>>=1n;e++;}if(e>127)return neg?-Infinity:Infinity;return (neg?-1:1)*Number(q)*2**(e-23);}
function __ink_from_float(x,t){x=Math.trunc(x);if(!Number.isFinite(x))return {None:null};const valid=t==='i32'?x>=-2147483648&&x<2147483648:x>=0&&x<(t==='u32'?4294967296:18446744073709551616);return valid?{Some:t==='u64'?BigInt(x):x===0?0:x}:{None:null};}
function __ink_count(x,n,width){if(width===64){x=BigInt.asUintN(64,x);if(n==='popcount'){let count=0;while(x){x&=x-1n;count++;}return count;}if(x===0n)return 64;if(n==='leading_zeros')return 64-x.toString(2).length;let count=0;while((x&1n)===0n){x>>=1n;count++;}return count;}x>>>=0;if(n==='leading_zeros')return Math.clz32(x);if(n==='trailing_zeros')return x===0?32:31-Math.clz32((x&-x)>>>0);x=x-((x>>>1)&0x55555555);x=(x&0x33333333)+((x>>>2)&0x33333333);return Math.imul((x+(x>>>4))&0x0f0f0f0f,0x01010101)>>>24;}
const __ink_encoder=new TextEncoder(),__ink_decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const __ink_bytes=s=>__ink_encoder.encode(s);
// Count UTF-8 bytes directly; valid Ink strings contain Unicode scalar values.
// Preserve TextEncoder's replacement width for a lone surrogate at trusted hosts.
function __ink_byte_len(s,start=0,end=s.length){let n=0;for(let i=start;i<end;i++){const c=s.charCodeAt(i);if(c<128)n++;else if(c<2048)n+=2;else if(c>=0xd800&&c<=0xdbff&&i+1<end&&s.charCodeAt(i+1)>=0xdc00&&s.charCodeAt(i+1)<=0xdfff){n+=4;i++;}else n+=3;}return n;}
const __ink_boundary=(b,i)=>i<=b.length&&(i===b.length||(b[i]&0xc0)!==0x80);
function __ink_byte_at(s,i){const b=__ink_bytes(s);return i<b.length?{Some:b[i]}:{None:null};}
function __ink_slice(s,a,z){const b=__ink_bytes(s);return a<=z&&__ink_boundary(b,a)&&__ink_boundary(b,z)?{Some:__ink_decoder.decode(b.subarray(a,z))}:{None:null};}
function __ink_concat(a,b){const s=a+b;if(__ink_byte_len(s)>4294967295)throw Error('String exceeds U32 byte length');return s;}
function __ink_find(s,needle,from){let unit=0,bytes=0;while(bytes<from&&unit<s.length){const c=s.charCodeAt(unit++);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff&&unit<s.length&&s.charCodeAt(unit)>=0xdc00&&s.charCodeAt(unit)<=0xdfff){bytes+=4;unit++;}else bytes+=3;}if(bytes!==from)return {None:null};const at=s.indexOf(needle,unit);return at<0?{None:null}:{Some:bytes+__ink_byte_len(s,unit,at)};}

function __ink_int_from_float(x){return Number.isFinite(x)?{Some:BigInt(Math.trunc(x))}:{None:null};}
// Affine buffers expose bounded disjoint ranges over one allocation. Source
// ownership prevents retaining a parent; growth detaches shared ranges.
// Elements cannot own temporary storage: they are immutable logical values.
// Copy the slot array when acquiring ownership, never the reachable records.
class __InkBuffer {
 constructor(data,start=0,end=data.length,shared=false){this.data=data;this.start=start;this.end=end;this.shared=shared;}
 get length(){return this.end-this.start;}
 set length(n){this.end=this.start+Math.min(this.length,n);if(!this.shared&&this.start===0)this.data.length=this.end;}
 item(i){return this.data[this.start+i];}
 range(start,count){const begin=this.start+Math.min(start,this.length);return new __InkBuffer(this.data,begin,begin+Math.min(count,this.end-begin),true);}
 set(i,v){if(i<this.length)this.data[this.start+i]=v;return this;}
 swap(a,b){if(a<this.length&&b<this.length){const x=this.item(a);this.set(a,this.item(b));this.set(b,x);}return this;}
 fill_range(start,count,value){start=Math.min(start,this.length);count=Math.min(count,this.length-start);this.data.fill(value,this.start+start,this.start+start+count);return this;}
 copy_within(source,destination,count){source=Math.min(source,this.length);destination=Math.min(destination,this.length);count=Math.min(count,this.length-source,this.length-destination);this.data.copyWithin(this.start+destination,this.start+source,this.start+source+count);return this;}
 detach(){if(this.shared||this.start!==0||this.end!==this.data.length){this.data=this.data.slice(this.start,this.end);this.start=0;this.end=this.data.length;this.shared=false;}}
 push(v){if(this.length>=4294967295)throw Error('buffer length exhausted');this.detach();this.data.push(v);this.end++;return this;}
 pop(){this.length=Math.max(0,this.length-1);return this;}
 truncate(n){this.length=Math.min(this.length,n);return this;}
 slice(start=0,end=this.length){return this.data.slice(this.start+start,this.start+Math.min(end,this.length));}
 freeze(){return this.start===0&&this.end===this.data.length?this.data:this.data.slice(this.start,this.end);}
 *[Symbol.iterator](){for(let i=this.start;i<this.end;i++)yield this.data[i];}
}
function __bufferSplit(x,at){const cut=x.start+Math.min(at,x.length);x.shared=true;return [new __InkBuffer(x.data,x.start,cut,true),new __InkBuffer(x.data,cut,x.end,true)];}
function __bufferAppend(a,b){
 if(a.length+b.length>4294967295)throw Error('buffer length exhausted');
 if(a.data===b.data&&a.end===b.start)return new __InkBuffer(a.data,a.start,b.end,a.start!==0||b.end!==a.data.length);
 a.detach();for(const item of b)a.push(item);return a;
}

function __repeat_until(limit,acc,stop,step){for(let i=0;i<limit;i++){if(stop(acc))break;acc=step(i,acc);}return acc;}
function __bufferFill(n,v){return new __InkBuffer(new Array(n).fill(v));}
function __mapGet(m,k,f){return m.has(k)?m.get(k):f();}
function __mapEntries(m,keys){return [...m.entries()].sort(([a],[b])=>a<b?-1:a>b?1:0).map(([k,v])=>keys?k:v);}
function __tempSet(x,k,v,map){x.set(k,v);return x;}
function __bufferSwap(x,a,b){return x.swap(a,b);}
function __tempEdit(x,op,...args){if(op==='push'){x.push(args[0]);}else if(op==='pop')x.pop();else if(op==='truncate')x.truncate(args[0]);else if(op==='remove')x.delete(args[0]);return x;}
// Fixed word semantics, including arithmetic signed right shift. Shift and
// rotation counts wrap modulo width; no source-pattern optimisation lives here.
function __word(op,a,b,bits) {
  const width=BigInt(Math.abs(bits)), k=BigInt(b??0)%width;
  const x=BigInt(a), y=BigInt(b??0), unsigned=BigInt.asUintN(Number(width),x);
  let r;
  switch(op) {
    case 'word_widen_u32_to_u64':case 'word_narrow_u64_to_u32':r=x;break;
    case 'word_not':r=~x;break;
    case 'word_and':r=x&y;break;
    case 'word_or':r=x|y;break;
    case 'word_xor':r=x^y;break;
    case 'wrapping_shl':r=x<<k;break;
    case 'wrapping_shr':r=x>>k;break;
    case 'rotate_left':r=(unsigned<<k)|(unsigned>>(width-k));break;
    case 'rotate_right':r=(unsigned>>k)|(unsigned<<(width-k));break;
    default:throw new Error('unknown word operation');
  }
  r=bits<0?BigInt.asIntN(Number(width),r):BigInt.asUintN(Number(width),r);
  return bits===64?r:Number(r);
}
// Rotations evaluate each operand once. Counts wrap modulo the width.
function __rotl32(a,k){k&=31;return (a<<k)|(a>>>((32-k)&31));}
function __rotr32(a,k){k&=31;return (a>>>k)|(a<<((32-k)&31));}
function __rotl64(a,k){const n=BigInt(k&63);return BigInt.asUintN(64,(a<<n)|(a>>((64n-n)&63n)));}
function __rotr64(a,k){const n=BigInt(k&63);return BigInt.asUintN(64,(a>>n)|(a<<((64n-n)&63n)));}
function __fn0(){
let v0=new __InkBuffer([]);
for(let v1=0;v1<64;v1++){
const v2=(v1>>>0);
const v3=v0;
const v4=0;
v0=__tempEdit(v3,"push",v4);}
const v5=v0;
return v5.freeze();}
function __fn1(v6,v7){
const v8=v7["features"];
const v9=Math.min(v6.length,v8.length);
const v10=new Array(v9);
for(let v11=0;v11<v9;v11++){
const v12=v6[v11];
const v13=v8[v11];
v10[v11]=__bits(__float(v12) * __float(v13));
}
let v14=0;for(let v15=0;v15<v10.length;v15++){
const v16=v10[v15];
v14=__bits(__float(v14) + __float(v16));}
return v14;}
function __fn2(v17,v18){
const v19=__fn1(v17,v18);
const v20=v18["target"];
const v21=Math.fround(__float(v19) - __float(v20));
return __bits(v21 * v21);}
function __fn3(v22,v23,v24){
const v25=true;
return __fn22(v22,v24,v25,v23);}
function __fn4(v26,v27,v28){
const v29=true;
const v30=__fn23(v26,v28,v29,v27);
let v31;if(Object.hasOwn(v30,"Ok")){
const v32=v30["Ok"];
v31=({Ok:v32["value"]});}else{v31=({Err:v30.Err});}
return v31;}
function __fn5(v33){
let v34=true;
for(let v35=0;v35<v33.length;v35++){
const v36=v33[v35];
const v37=v34;
let v38=v37;if(v38){
v38=Number.isFinite(__float(v36));}
const v39=v38;
let v40=v39;if(v40){
const v41=1098907648;
const v42=((v41 ^ 2147483648) >>> 0);
v40=((__float(v36)) >= (__float(v42)));}
const v43=v40;
let v44=v43;if(v44){
const v45=1098907648;
v44=((__float(v36)) <= (__float(v45)));}
v34=v44;
}
return v34;}
function __fn6(v46,v47,v48){
const v49=v46.length;
const v50=new Array(v49);
for(let v51=0;v51<v49;v51++){
const v52=v46[v51];
const v53=(v51>>>0);
let v54;if(v53<v47.length){v54=v47[v53];}else{
v54=0;}
const v55=v54;
const v56=Math.fround(__float(v48) * __float(v55));
v50[v51]=__bits(__float(v52) - v56);
}
return v50;}
function __fn7(v57){
const v58=(v57["features"]).length;
const v59=64;
const v60=(v58===v59);
let v61=v60;if(v61){
v61=Number.isFinite(__float(v57["target"]));}
return v61;}
function __fn8(v62){
const v63=1;
const v64=new __InkBuffer(Array.from([v63]));
let v65;if(Object.hasOwn(v62,"Some")){
const v66=v62["Some"];
v65=__tempEdit(v64,"push",v66);}else{
const v67=null;
const v68=9;
v65=__tempEdit(v64,"push",v68);}
const v69=v65;
return v69.freeze();}
function __fn9(v70){
const v71=1073741824;
const v72=Math.fround(__float(v70) * __float(v71));
const v73=1065353216;
return __bufferFill(4,__bits(v72 + __float(v73)));}
function __fn10(v74){
const v75=v74.length;
const v76=new Array(v75);
for(let v77=0;v77<v75;v77++){
const v78=v74[v77];
const v79=__fn9(v78);
const v80=0;
let v81;if(v80<v79.length){v81=v79.item(v80);}else{
const v82=0;
v81=((v82 ^ 2147483648) >>> 0);}
v76[v77]=v81;
}
return v76;}
function __fn11(v83){
const v84=4294967295;
return ({["value"]:v83,["id"]:v84});}
function __fn12(v85,v86,v87){
const v88=false;
const v89=(v87===v88);
let v90=v89;if(!v90){
v90=v85["failed"];}
let v91;if(v90){
const v92=v86["value"];
const v93=__fn11(v92);
v91=({["value"]:v93,["tape"]:v85});}else{
const v94=v85["nodes"];
const v95=(v94).length;
const v96=v85["maximum"];
let v97;if(((v95) >= (v96))){
const v98=v86["value"];
const v99=__fn11(v98);
const v100=true;
const v101=v85["nodes"];
const v102=v85["maximum"];
const v103=({["nodes"]:v101,["maximum"]:v102,["failed"]:v100});
v97=({["value"]:v99,["tape"]:v103});}else{
const v104=v86["value"];
const v105=({["value"]:v104,["id"]:v95});
const v106=v85["nodes"];
const v107=__tempEdit(v106,"push",v86);
const v108=v85["maximum"];
const v109=v85["failed"];
const v110=({["nodes"]:v107,["maximum"]:v108,["failed"]:v109});
v97=({["value"]:v105,["tape"]:v110});}
v91=v97;}
return v91;}
function __fn13(v111,v112){
const v113=0;
const v114=4294967295;
const v115=4294967295;
const v116=0;
const v117=0;
const v119=true;
const v120=false;
const v121=(v119===v120);
let v122=v121;if(!v122){
v122=v112["failed"];}
let v123;
let v124;
if(v122){
const v125=__fn11(v111);
v123=v125;
v124=v112;
}else{
const v126=v112["nodes"];
const v127=(v126).length;
const v128=v112["maximum"];
let v129;
let v130;
if(((v127) >= (v128))){
const v131=__fn11(v111);
const v132=true;
const v133=v112["nodes"];
const v134=v112["maximum"];
const v135=({["nodes"]:v133,["maximum"]:v134,["failed"]:v132});
v129=v131;
v130=v135;
}else{
const v136=({["value"]:v111,["id"]:v127});
const v137=v112["nodes"];
const v138=({["op"]:v113,["a"]:v114,["b"]:v115,["av"]:v116,["bv"]:v117,["value"]:v111});
const v139=__tempEdit(v137,"push",v138);
const v140=v112["maximum"];
const v141=v112["failed"];
const v142=({["nodes"]:v139,["maximum"]:v140,["failed"]:v141});
v129=v136;
v130=v142;
}
v123=v129;
v124=v130;
}
return ({["value"]:v123,["tape"]:v124});}
function __fn14(v143,v144,v145,v146){
const v147=1;
let v148;if((v143===v147)){
const v149=v145["value"];
const v150=v146["value"];
v148=__bits(__float(v149) + __float(v150));}else{
const v151=2;
let v152;if((v143===v151)){
const v153=v145["value"];
const v154=v146["value"];
v152=__bits(__float(v153) - __float(v154));}else{
const v155=3;
let v156;if((v143===v155)){
const v157=v145["value"];
const v158=v146["value"];
v156=__bits(__float(v157) * __float(v158));}else{
v156=__bits((__float(v145["value"]))/(__float(v146["value"])));}
v152=v156;}
v148=v152;}
const v159=v148;
const v160=v145["id"];
const v161=v146["id"];
const v162=v145["value"];
const v163=v146["value"];
const v165=v145["id"];
const v166=4294967295;
const v167=!(v165===v166);
let v168=v167;if(!v168){
const v169=v146["id"];
const v170=4294967295;
v168=!(v169===v170);}
const v171=v168;
const v172=false;
const v173=(v171===v172);
let v174=v173;if(!v174){
v174=v144["failed"];}
let v175;
let v176;
if(v174){
const v177=__fn11(v159);
v175=v177;
v176=v144;
}else{
const v178=v144["nodes"];
const v179=(v178).length;
const v180=v144["maximum"];
let v181;
let v182;
if(((v179) >= (v180))){
const v183=__fn11(v159);
const v184=true;
const v185=v144["nodes"];
const v186=v144["maximum"];
const v187=({["nodes"]:v185,["maximum"]:v186,["failed"]:v184});
v181=v183;
v182=v187;
}else{
const v188=({["value"]:v159,["id"]:v179});
const v189=v144["nodes"];
const v190=({["op"]:v143,["a"]:v160,["b"]:v161,["av"]:v162,["bv"]:v163,["value"]:v159});
const v191=__tempEdit(v189,"push",v190);
const v192=v144["maximum"];
const v193=v144["failed"];
const v194=({["nodes"]:v191,["maximum"]:v192,["failed"]:v193});
v181=v188;
v182=v194;
}
v175=v181;
v176=v182;
}
return ({["value"]:v175,["tape"]:v176});}
function __fn15(v195,v196,v197){
const v198=5;
let v199;if((v195===v198)){
const v200=v197["value"];
v199=((v200 ^ 2147483648) >>> 0);}else{
v199=__bits(Math.sqrt(__float(v197["value"])));}
const v201=v199;
const v202=v197["id"];
const v203=4294967295;
const v204=v197["value"];
const v205=0;
const v207=v197["id"];
const v208=4294967295;
const v209=!(v207===v208);
const v210=false;
const v211=(v209===v210);
let v212=v211;if(!v212){
v212=v196["failed"];}
let v213;
let v214;
if(v212){
const v215=__fn11(v201);
v213=v215;
v214=v196;
}else{
const v216=v196["nodes"];
const v217=(v216).length;
const v218=v196["maximum"];
let v219;
let v220;
if(((v217) >= (v218))){
const v221=__fn11(v201);
const v222=true;
const v223=v196["nodes"];
const v224=v196["maximum"];
const v225=({["nodes"]:v223,["maximum"]:v224,["failed"]:v222});
v219=v221;
v220=v225;
}else{
const v226=({["value"]:v201,["id"]:v217});
const v227=v196["nodes"];
const v228=({["op"]:v195,["a"]:v202,["b"]:v203,["av"]:v204,["bv"]:v205,["value"]:v201});
const v229=__tempEdit(v227,"push",v228);
const v230=v196["maximum"];
const v231=v196["failed"];
const v232=({["nodes"]:v229,["maximum"]:v230,["failed"]:v231});
v219=v226;
v220=v232;
}
v213=v219;
v214=v220;
}
return ({["value"]:v213,["tape"]:v214});}
function __fn16(v233,v234,v235){
const v236=4294967295;
let v237;if((v234===v236)){
v237=v233;}else{
let v238;if(v234<v233.length){v238=v233.item(v234);}else{
v238=0;}
const v239=v238;
v237=__tempSet(v233,v234,__bits(__float(v239) + __float(v235)),false);}
return v237;}
function __fn17(v240,v241,v242){
const v243=v240["op"];
const v244=1;
let v245;if((v243===v244)){
const v246=v240["a"];
const v247=4294967295;
let v248;if((v246===v247)){
v248=v242;}else{
let v249;if(v246<v242.length){v249=v242.item(v246);}else{
v249=0;}
const v250=v249;
v248=__tempSet(v242,v246,__bits(__float(v250) + __float(v241)),false);}
const v251=v248;
const v252=v240["b"];
const v253=4294967295;
let v254;if((v252===v253)){
v254=v251;}else{
let v255;if(v252<v251.length){v255=v251.item(v252);}else{
v255=0;}
const v256=v255;
v254=__tempSet(v251,v252,__bits(__float(v256) + __float(v241)),false);}
v245=v254;}else{
const v257=v240["op"];
const v258=2;
let v259;if((v257===v258)){
const v260=v240["a"];
const v261=4294967295;
let v262;if((v260===v261)){
v262=v242;}else{
let v263;if(v260<v242.length){v263=v242.item(v260);}else{
v263=0;}
const v264=v263;
v262=__tempSet(v242,v260,__bits(__float(v264) + __float(v241)),false);}
const v265=v262;
const v266=v240["b"];
const v267=((v241 ^ 2147483648) >>> 0);
const v268=4294967295;
let v269;if((v266===v268)){
v269=v265;}else{
let v270;if(v266<v265.length){v270=v265.item(v266);}else{
v270=0;}
const v271=v270;
v269=__tempSet(v265,v266,__bits(__float(v271) + __float(v267)),false);}
v259=v269;}else{
const v272=v240["op"];
const v273=3;
let v274;if((v272===v273)){
const v275=v240["a"];
const v276=v240["bv"];
const v277=__bits(__float(v241) * __float(v276));
const v278=4294967295;
let v279;if((v275===v278)){
v279=v242;}else{
let v280;if(v275<v242.length){v280=v242.item(v275);}else{
v280=0;}
const v281=v280;
v279=__tempSet(v242,v275,__bits(__float(v281) + __float(v277)),false);}
const v282=v279;
const v283=v240["b"];
const v284=v240["av"];
const v285=__bits(__float(v241) * __float(v284));
const v286=4294967295;
let v287;if((v283===v286)){
v287=v282;}else{
let v288;if(v283<v282.length){v288=v282.item(v283);}else{
v288=0;}
const v289=v288;
v287=__tempSet(v282,v283,__bits(__float(v289) + __float(v285)),false);}
v274=v287;}else{
const v290=v240["op"];
const v291=4;
let v292;if((v290===v291)){
const v293=v240["a"];
const v294=__bits((__float(v241))/(__float(v240["bv"])));
const v295=4294967295;
let v296;if((v293===v295)){
v296=v242;}else{
let v297;if(v293<v242.length){v297=v242.item(v293);}else{
v297=0;}
const v298=v297;
v296=__tempSet(v242,v293,__bits(__float(v298) + __float(v294)),false);}
const v299=v296;
const v300=v240["b"];
const v301=v240["av"];
const v302=v240["bv"];
const v303=v240["bv"];
const v304=__bits((__float(__bits(__float(v241) * __float(v301))))/(__float(__bits(__float(v302) * __float(v303)))));
const v305=((v304 ^ 2147483648) >>> 0);
const v306=4294967295;
let v307;if((v300===v306)){
v307=v299;}else{
let v308;if(v300<v299.length){v308=v299.item(v300);}else{
v308=0;}
const v309=v308;
v307=__tempSet(v299,v300,__bits(__float(v309) + __float(v305)),false);}
v292=v307;}else{
const v310=v240["op"];
const v311=5;
let v312;if((v310===v311)){
const v313=v240["a"];
const v314=((v241 ^ 2147483648) >>> 0);
const v315=4294967295;
let v316;if((v313===v315)){
v316=v242;}else{
let v317;if(v313<v242.length){v317=v242.item(v313);}else{
v317=0;}
const v318=v317;
v316=__tempSet(v242,v313,__bits(__float(v318) + __float(v314)),false);}
v312=v316;}else{
const v319=v240["op"];
const v320=6;
let v321;if((v319===v320)){
const v322=v240["a"];
const v323=1073741824;
const v324=v240["value"];
const v325=__bits((__float(v241))/(__float(__bits(__float(v323) * __float(v324)))));
const v326=4294967295;
let v327;if((v322===v326)){
v327=v242;}else{
let v328;if(v322<v242.length){v328=v242.item(v322);}else{
v328=0;}
const v329=v328;
v327=__tempSet(v242,v322,__bits(__float(v329) + __float(v325)),false);}
v321=v327;}else{
v321=v242;}
v312=v321;}
v292=v312;}
v274=v292;}
v259=v274;}
v245=v259;}
return v245;}
function __fn18(v330,v331,v332){
const v333=v331["index"];
const v334=1;
const v335=(((v333) - (v334)) >>> 0);
const v336=v331["gradient"];
let v337;if(v335<v336.length){v337=v336.item(v335);}else{
v337=0;}
const v338=v337;
let v339=v332;if(v339){
const v340=0;
v339=((__float(v338)) === (__float(v340)));}
let v341;if(v339){
v341=v331["gradient"];}else{
const v342=v331["gradient"];
const v343=v330["op"];
const v344=1;
let v345;if((v343===v344)){
const v346=v330["a"];
const v347=4294967295;
let v348;if((v346===v347)){
v348=v342;}else{
let v349;if(v346<v342.length){v349=v342.item(v346);}else{
v349=0;}
const v350=v349;
v348=__tempSet(v342,v346,__bits(__float(v350) + __float(v338)),false);}
const v351=v348;
const v352=v330["b"];
const v353=4294967295;
let v354;if((v352===v353)){
v354=v351;}else{
let v355;if(v352<v351.length){v355=v351.item(v352);}else{
v355=0;}
const v356=v355;
v354=__tempSet(v351,v352,__bits(__float(v356) + __float(v338)),false);}
v345=v354;}else{
const v357=v330["op"];
const v358=2;
let v359;if((v357===v358)){
const v360=v330["a"];
const v361=4294967295;
let v362;if((v360===v361)){
v362=v342;}else{
let v363;if(v360<v342.length){v363=v342.item(v360);}else{
v363=0;}
const v364=v363;
v362=__tempSet(v342,v360,__bits(__float(v364) + __float(v338)),false);}
const v365=v362;
const v366=v330["b"];
const v367=((v338 ^ 2147483648) >>> 0);
const v368=4294967295;
let v369;if((v366===v368)){
v369=v365;}else{
let v370;if(v366<v365.length){v370=v365.item(v366);}else{
v370=0;}
const v371=v370;
v369=__tempSet(v365,v366,__bits(__float(v371) + __float(v367)),false);}
v359=v369;}else{
const v372=v330["op"];
const v373=3;
let v374;if((v372===v373)){
const v375=v330["a"];
const v376=v330["bv"];
const v377=__bits(__float(v338) * __float(v376));
const v378=4294967295;
let v379;if((v375===v378)){
v379=v342;}else{
let v380;if(v375<v342.length){v380=v342.item(v375);}else{
v380=0;}
const v381=v380;
v379=__tempSet(v342,v375,__bits(__float(v381) + __float(v377)),false);}
const v382=v379;
const v383=v330["b"];
const v384=v330["av"];
const v385=__bits(__float(v338) * __float(v384));
const v386=4294967295;
let v387;if((v383===v386)){
v387=v382;}else{
let v388;if(v383<v382.length){v388=v382.item(v383);}else{
v388=0;}
const v389=v388;
v387=__tempSet(v382,v383,__bits(__float(v389) + __float(v385)),false);}
v374=v387;}else{
const v390=v330["op"];
const v391=4;
let v392;if((v390===v391)){
const v393=v330["a"];
const v394=__bits((__float(v338))/(__float(v330["bv"])));
const v395=4294967295;
let v396;if((v393===v395)){
v396=v342;}else{
let v397;if(v393<v342.length){v397=v342.item(v393);}else{
v397=0;}
const v398=v397;
v396=__tempSet(v342,v393,__bits(__float(v398) + __float(v394)),false);}
const v399=v396;
const v400=v330["b"];
const v401=v330["av"];
const v402=v330["bv"];
const v403=v330["bv"];
const v404=__bits((__float(__bits(__float(v338) * __float(v401))))/(__float(__bits(__float(v402) * __float(v403)))));
const v405=((v404 ^ 2147483648) >>> 0);
const v406=4294967295;
let v407;if((v400===v406)){
v407=v399;}else{
let v408;if(v400<v399.length){v408=v399.item(v400);}else{
v408=0;}
const v409=v408;
v407=__tempSet(v399,v400,__bits(__float(v409) + __float(v405)),false);}
v392=v407;}else{
const v410=v330["op"];
const v411=5;
let v412;if((v410===v411)){
const v413=v330["a"];
const v414=((v338 ^ 2147483648) >>> 0);
const v415=4294967295;
let v416;if((v413===v415)){
v416=v342;}else{
let v417;if(v413<v342.length){v417=v342.item(v413);}else{
v417=0;}
const v418=v417;
v416=__tempSet(v342,v413,__bits(__float(v418) + __float(v414)),false);}
v412=v416;}else{
const v419=v330["op"];
const v420=6;
let v421;if((v419===v420)){
const v422=v330["a"];
const v423=1073741824;
const v424=v330["value"];
const v425=__bits((__float(v338))/(__float(__bits(__float(v423) * __float(v424)))));
const v426=4294967295;
let v427;if((v422===v426)){
v427=v342;}else{
let v428;if(v422<v342.length){v428=v342.item(v422);}else{
v428=0;}
const v429=v428;
v427=__tempSet(v342,v422,__bits(__float(v429) + __float(v425)),false);}
v421=v427;}else{
v421=v342;}
v412=v421;}
v392=v412;}
v374=v392;}
v359=v374;}
v345=v359;}
v341=v345;}
const v430=v341;
return ({["index"]:v335,["gradient"]:v430});}
function __fn19(v431,v432,v433){
let v434=new __InkBuffer([]);
for(let v435=0;v435<v431.length;v435++){
const v436=v431[v435];
const v437=v434;
const v438=0;
v434=__tempEdit(v437,"push",v438);
}
const v439=v434;
const v440=v432["id"];
const v441=1065353216;
const v442=4294967295;
let v443;if((v440===v442)){
v443=v439;}else{
let v444;if(v440<v439.length){v444=v439.item(v440);}else{
v444=0;}
const v445=v444;
v443=__tempSet(v439,v440,__bits(__float(v445) + __float(v441)),false);}
const v446=v443;
const v447=(v431).length;
let v448=v446;
let v449=v447;
for(let v451=v431.length-1;v451>=0;v451--){
const v452=v431[v451];
const v454=v449;
const v455=1;
const v456=(((v454) - (v455)) >>> 0);
const v457=v448;
let v458;if(v456<v457.length){v458=v457.item(v456);}else{
v458=0;}
const v459=v458;
let v460=v433;if(v460){
const v461=0;
v460=((__float(v459)) === (__float(v461)));}
let v462;if(v460){
v462=v448;}else{
const v463=v448;
const v464=v452["op"];
const v465=1;
let v466;if((v464===v465)){
const v467=v452["a"];
const v468=4294967295;
let v469;if((v467===v468)){
v469=v463;}else{
let v470;if(v467<v463.length){v470=v463.item(v467);}else{
v470=0;}
const v471=v470;
v469=__tempSet(v463,v467,__bits(__float(v471) + __float(v459)),false);}
const v472=v469;
const v473=v452["b"];
const v474=4294967295;
let v475;if((v473===v474)){
v475=v472;}else{
let v476;if(v473<v472.length){v476=v472.item(v473);}else{
v476=0;}
const v477=v476;
v475=__tempSet(v472,v473,__bits(__float(v477) + __float(v459)),false);}
v466=v475;}else{
const v478=v452["op"];
const v479=2;
let v480;if((v478===v479)){
const v481=v452["a"];
const v482=4294967295;
let v483;if((v481===v482)){
v483=v463;}else{
let v484;if(v481<v463.length){v484=v463.item(v481);}else{
v484=0;}
const v485=v484;
v483=__tempSet(v463,v481,__bits(__float(v485) + __float(v459)),false);}
const v486=v483;
const v487=v452["b"];
const v488=((v459 ^ 2147483648) >>> 0);
const v489=4294967295;
let v490;if((v487===v489)){
v490=v486;}else{
let v491;if(v487<v486.length){v491=v486.item(v487);}else{
v491=0;}
const v492=v491;
v490=__tempSet(v486,v487,__bits(__float(v492) + __float(v488)),false);}
v480=v490;}else{
const v493=v452["op"];
const v494=3;
let v495;if((v493===v494)){
const v496=v452["a"];
const v497=v452["bv"];
const v498=__bits(__float(v459) * __float(v497));
const v499=4294967295;
let v500;if((v496===v499)){
v500=v463;}else{
let v501;if(v496<v463.length){v501=v463.item(v496);}else{
v501=0;}
const v502=v501;
v500=__tempSet(v463,v496,__bits(__float(v502) + __float(v498)),false);}
const v503=v500;
const v504=v452["b"];
const v505=v452["av"];
const v506=__bits(__float(v459) * __float(v505));
const v507=4294967295;
let v508;if((v504===v507)){
v508=v503;}else{
let v509;if(v504<v503.length){v509=v503.item(v504);}else{
v509=0;}
const v510=v509;
v508=__tempSet(v503,v504,__bits(__float(v510) + __float(v506)),false);}
v495=v508;}else{
const v511=v452["op"];
const v512=4;
let v513;if((v511===v512)){
const v514=v452["a"];
const v515=__bits((__float(v459))/(__float(v452["bv"])));
const v516=4294967295;
let v517;if((v514===v516)){
v517=v463;}else{
let v518;if(v514<v463.length){v518=v463.item(v514);}else{
v518=0;}
const v519=v518;
v517=__tempSet(v463,v514,__bits(__float(v519) + __float(v515)),false);}
const v520=v517;
const v521=v452["b"];
const v522=v452["av"];
const v523=v452["bv"];
const v524=v452["bv"];
const v525=__bits((__float(__bits(__float(v459) * __float(v522))))/(__float(__bits(__float(v523) * __float(v524)))));
const v526=((v525 ^ 2147483648) >>> 0);
const v527=4294967295;
let v528;if((v521===v527)){
v528=v520;}else{
let v529;if(v521<v520.length){v529=v520.item(v521);}else{
v529=0;}
const v530=v529;
v528=__tempSet(v520,v521,__bits(__float(v530) + __float(v526)),false);}
v513=v528;}else{
const v531=v452["op"];
const v532=5;
let v533;if((v531===v532)){
const v534=v452["a"];
const v535=((v459 ^ 2147483648) >>> 0);
const v536=4294967295;
let v537;if((v534===v536)){
v537=v463;}else{
let v538;if(v534<v463.length){v538=v463.item(v534);}else{
v538=0;}
const v539=v538;
v537=__tempSet(v463,v534,__bits(__float(v539) + __float(v535)),false);}
v533=v537;}else{
const v540=v452["op"];
const v541=6;
let v542;if((v540===v541)){
const v543=v452["a"];
const v544=1073741824;
const v545=v452["value"];
const v546=__bits((__float(v459))/(__float(__bits(__float(v544) * __float(v545)))));
const v547=4294967295;
let v548;if((v543===v547)){
v548=v463;}else{
let v549;if(v543<v463.length){v549=v463.item(v543);}else{
v549=0;}
const v550=v549;
v548=__tempSet(v463,v543,__bits(__float(v550) + __float(v546)),false);}
v542=v548;}else{
v542=v463;}
v533=v542;}
v513=v533;}
v495=v513;}
v480=v495;}
v466=v480;}
v462=v466;}
const v551=v462;
const v552=({["index"]:v456,["gradient"]:v551});
v448=v552["gradient"];
v449=v552["index"];
}
const v554=v448;
return v554.freeze();}
function __fn20(v555,v556,v557){
const v560=v556["features"];
const v562=Math.min(v555.length,v560.length);
const v563=new Array(v562);
for(let v564=0;v564<v562;v564++){
const v565=v555[v564];
const v566=v560[v564];
v563[v564]=({["left"]:v565,["right"]:v566});
}
const v567=new __InkBuffer([]);
const v568=0;
let v569=v567;
let v570=v557;
let v571=v568;
for(let v573=0;v573<v563.length;v573++){
const v574=v563[v573];
const v575=v574["left"];
const v576=v574["right"];
const v577=v570;
const v580=3;
const v581=1;
let v582;if((v580===v581)){
const v583=v575["value"];
const v584=v576["value"];
v582=__bits(__float(v583) + __float(v584));}else{
const v585=2;
let v586;if((v580===v585)){
const v587=v575["value"];
const v588=v576["value"];
v586=__bits(__float(v587) - __float(v588));}else{
const v589=3;
let v590;if((v580===v589)){
const v591=v575["value"];
const v592=v576["value"];
v590=__bits(__float(v591) * __float(v592));}else{
v590=__bits((__float(v575["value"]))/(__float(v576["value"])));}
v586=v590;}
v582=v586;}
const v593=v582;
const v594=v575["id"];
const v595=v576["id"];
const v596=v575["value"];
const v597=v576["value"];
const v599=v575["id"];
const v600=4294967295;
const v601=!(v599===v600);
let v602=v601;if(!v602){
const v603=v576["id"];
const v604=4294967295;
v602=!(v603===v604);}
const v605=v602;
const v606=false;
const v607=(v605===v606);
let v608=v607;if(!v608){
v608=v577["failed"];}
let v609;
let v610;
if(v608){
const v611=__fn11(v593);
v609=v611;
v610=v577;
}else{
const v612=v577["nodes"];
const v613=(v612).length;
const v614=v577["maximum"];
let v615;
let v616;
if(((v613) >= (v614))){
const v617=__fn11(v593);
const v618=true;
const v619=v577["nodes"];
const v620=v577["maximum"];
const v621=({["nodes"]:v619,["maximum"]:v620,["failed"]:v618});
v615=v617;
v616=v621;
}else{
const v622=({["value"]:v593,["id"]:v613});
const v623=v577["nodes"];
const v624=({["op"]:v580,["a"]:v594,["b"]:v595,["av"]:v596,["bv"]:v597,["value"]:v593});
const v625=__tempEdit(v623,"push",v624);
const v626=v577["maximum"];
const v627=v577["failed"];
const v628=({["nodes"]:v625,["maximum"]:v626,["failed"]:v627});
v615=v622;
v616=v628;
}
v609=v615;
v610=v616;
}
const v630=v569;
const v631=v609;
const v632=__tempEdit(v630,"push",v631);
const v633=v610;
const v634=v571;
const v635=1;
const v636=(((v634) + (v635)) >>> 0);
v569=v632;
v570=v633;
v571=v636;
}
const v638=v569;
const v639=v638.freeze();
const v640=v570;
const v642=0;
const v643=__fn11(v642);
let v644=v643;
let v645=v640;
for(let v647=0;v647<v639.length;v647++){
const v648=v639[v647];
const v649=1;
const v650=v645;
const v651=v644;
const v652=1;
let v653;if((v649===v652)){
const v654=v651["value"];
const v655=v648["value"];
v653=__bits(__float(v654) + __float(v655));}else{
const v656=2;
let v657;if((v649===v656)){
const v658=v651["value"];
const v659=v648["value"];
v657=__bits(__float(v658) - __float(v659));}else{
const v660=3;
let v661;if((v649===v660)){
const v662=v651["value"];
const v663=v648["value"];
v661=__bits(__float(v662) * __float(v663));}else{
v661=__bits((__float(v651["value"]))/(__float(v648["value"])));}
v657=v661;}
v653=v657;}
const v664=v653;
const v665=v651["id"];
const v666=v648["id"];
const v667=v651["value"];
const v668=v648["value"];
const v670=v651["id"];
const v671=4294967295;
const v672=!(v670===v671);
let v673=v672;if(!v673){
const v674=v648["id"];
const v675=4294967295;
v673=!(v674===v675);}
const v676=v673;
const v677=false;
const v678=(v676===v677);
let v679=v678;if(!v679){
v679=v650["failed"];}
let v680;
let v681;
if(v679){
const v682=__fn11(v664);
v680=v682;
v681=v650;
}else{
const v683=v650["nodes"];
const v684=(v683).length;
const v685=v650["maximum"];
let v686;
let v687;
if(((v684) >= (v685))){
const v688=__fn11(v664);
const v689=true;
const v690=v650["nodes"];
const v691=v650["maximum"];
const v692=({["nodes"]:v690,["maximum"]:v691,["failed"]:v689});
v686=v688;
v687=v692;
}else{
const v693=({["value"]:v664,["id"]:v684});
const v694=v650["nodes"];
const v695=({["op"]:v649,["a"]:v665,["b"]:v666,["av"]:v667,["bv"]:v668,["value"]:v664});
const v696=__tempEdit(v694,"push",v695);
const v697=v650["maximum"];
const v698=v650["failed"];
const v699=({["nodes"]:v696,["maximum"]:v697,["failed"]:v698});
v686=v693;
v687=v699;
}
v680=v686;
v681=v687;
}
v644=v680;
v645=v681;
}
return ({["value"]:v644,["tape"]:v645});}
function __fn21(v700,v701,v702){
const v707=v701["features"];
const v709=Math.min(v700.length,v707.length);
const v710=new Array(v709);
for(let v711=0;v711<v709;v711++){
const v712=v700[v711];
const v713=v707[v711];
v710[v711]=({["left"]:v712,["right"]:v713});
}
const v714=new __InkBuffer([]);
const v715=0;
let v716=v714;
let v717=v702;
let v718=v715;
for(let v720=0;v720<v710.length;v720++){
const v721=v710[v720];
const v722=v721["left"];
const v723=v721["right"];
const v724=v717;
const v727=3;
const v728=1;
let v729;if((v727===v728)){
const v730=v722["value"];
const v731=v723["value"];
v729=__bits(__float(v730) + __float(v731));}else{
const v732=2;
let v733;if((v727===v732)){
const v734=v722["value"];
const v735=v723["value"];
v733=__bits(__float(v734) - __float(v735));}else{
const v736=3;
let v737;if((v727===v736)){
const v738=v722["value"];
const v739=v723["value"];
v737=__bits(__float(v738) * __float(v739));}else{
v737=__bits((__float(v722["value"]))/(__float(v723["value"])));}
v733=v737;}
v729=v733;}
const v740=v729;
const v741=v722["id"];
const v742=v723["id"];
const v743=v722["value"];
const v744=v723["value"];
const v746=v722["id"];
const v747=4294967295;
const v748=!(v746===v747);
let v749=v748;if(!v749){
const v750=v723["id"];
const v751=4294967295;
v749=!(v750===v751);}
const v752=v749;
const v753=false;
const v754=(v752===v753);
let v755=v754;if(!v755){
v755=v724["failed"];}
let v756;
let v757;
if(v755){
const v758=__fn11(v740);
v756=v758;
v757=v724;
}else{
const v759=v724["nodes"];
const v760=(v759).length;
const v761=v724["maximum"];
let v762;
let v763;
if(((v760) >= (v761))){
const v764=__fn11(v740);
const v765=true;
const v766=v724["nodes"];
const v767=v724["maximum"];
const v768=({["nodes"]:v766,["maximum"]:v767,["failed"]:v765});
v762=v764;
v763=v768;
}else{
const v769=({["value"]:v740,["id"]:v760});
const v770=v724["nodes"];
const v771=({["op"]:v727,["a"]:v741,["b"]:v742,["av"]:v743,["bv"]:v744,["value"]:v740});
const v772=__tempEdit(v770,"push",v771);
const v773=v724["maximum"];
const v774=v724["failed"];
const v775=({["nodes"]:v772,["maximum"]:v773,["failed"]:v774});
v762=v769;
v763=v775;
}
v756=v762;
v757=v763;
}
const v777=v716;
const v778=v756;
const v779=__tempEdit(v777,"push",v778);
const v780=v757;
const v781=v718;
const v782=1;
const v783=(((v781) + (v782)) >>> 0);
v716=v779;
v717=v780;
v718=v783;
}
const v785=v716;
const v786=v785.freeze();
const v787=v717;
const v789=0;
const v790=__fn11(v789);
let v791=v790;
let v792=v787;
for(let v794=0;v794<v786.length;v794++){
const v795=v786[v794];
const v796=1;
const v797=v792;
const v798=v791;
const v799=1;
let v800;if((v796===v799)){
const v801=v798["value"];
const v802=v795["value"];
v800=__bits(__float(v801) + __float(v802));}else{
const v803=2;
let v804;if((v796===v803)){
const v805=v798["value"];
const v806=v795["value"];
v804=__bits(__float(v805) - __float(v806));}else{
const v807=3;
let v808;if((v796===v807)){
const v809=v798["value"];
const v810=v795["value"];
v808=__bits(__float(v809) * __float(v810));}else{
v808=__bits((__float(v798["value"]))/(__float(v795["value"])));}
v804=v808;}
v800=v804;}
const v811=v800;
const v812=v798["id"];
const v813=v795["id"];
const v814=v798["value"];
const v815=v795["value"];
const v817=v798["id"];
const v818=4294967295;
const v819=!(v817===v818);
let v820=v819;if(!v820){
const v821=v795["id"];
const v822=4294967295;
v820=!(v821===v822);}
const v823=v820;
const v824=false;
const v825=(v823===v824);
let v826=v825;if(!v826){
v826=v797["failed"];}
let v827;
let v828;
if(v826){
const v829=__fn11(v811);
v827=v829;
v828=v797;
}else{
const v830=v797["nodes"];
const v831=(v830).length;
const v832=v797["maximum"];
let v833;
let v834;
if(((v831) >= (v832))){
const v835=__fn11(v811);
const v836=true;
const v837=v797["nodes"];
const v838=v797["maximum"];
const v839=({["nodes"]:v837,["maximum"]:v838,["failed"]:v836});
v833=v835;
v834=v839;
}else{
const v840=({["value"]:v811,["id"]:v831});
const v841=v797["nodes"];
const v842=({["op"]:v796,["a"]:v812,["b"]:v813,["av"]:v814,["bv"]:v815,["value"]:v811});
const v843=__tempEdit(v841,"push",v842);
const v844=v797["maximum"];
const v845=v797["failed"];
const v846=({["nodes"]:v843,["maximum"]:v844,["failed"]:v845});
v833=v840;
v834=v846;
}
v827=v833;
v828=v834;
}
v791=v827;
v792=v828;
}
const v848=v792;
const v850=v701["target"];
const v852=2;
const v853=v791;
const v854=1;
let v855;if((v852===v854)){
const v856=v853["value"];
const v857=v850["value"];
v855=__bits(__float(v856) + __float(v857));}else{
const v858=2;
let v859;if((v852===v858)){
const v860=v853["value"];
const v861=v850["value"];
v859=__bits(__float(v860) - __float(v861));}else{
const v862=3;
let v863;if((v852===v862)){
const v864=v853["value"];
const v865=v850["value"];
v863=__bits(__float(v864) * __float(v865));}else{
v863=__bits((__float(v853["value"]))/(__float(v850["value"])));}
v859=v863;}
v855=v859;}
const v866=v855;
const v867=v853["id"];
const v868=v850["id"];
const v869=v853["value"];
const v870=v850["value"];
const v872=v853["id"];
const v873=4294967295;
const v874=!(v872===v873);
let v875=v874;if(!v875){
const v876=v850["id"];
const v877=4294967295;
v875=!(v876===v877);}
const v878=v875;
const v879=false;
const v880=(v878===v879);
let v881=v880;if(!v881){
v881=v848["failed"];}
let v882;
let v883;
if(v881){
const v884=__fn11(v866);
v882=v884;
v883=v848;
}else{
const v885=v848["nodes"];
const v886=(v885).length;
const v887=v848["maximum"];
let v888;
let v889;
if(((v886) >= (v887))){
const v890=__fn11(v866);
const v891=true;
const v892=v848["nodes"];
const v893=v848["maximum"];
const v894=({["nodes"]:v892,["maximum"]:v893,["failed"]:v891});
v888=v890;
v889=v894;
}else{
const v895=({["value"]:v866,["id"]:v886});
const v896=v848["nodes"];
const v897=({["op"]:v852,["a"]:v867,["b"]:v868,["av"]:v869,["bv"]:v870,["value"]:v866});
const v898=__tempEdit(v896,"push",v897);
const v899=v848["maximum"];
const v900=v848["failed"];
const v901=({["nodes"]:v898,["maximum"]:v899,["failed"]:v900});
v888=v895;
v889=v901;
}
v882=v888;
v883=v889;
}
const v903=v882;
const v904=v883;
const v907=3;
const v908=1;
let v909;if((v907===v908)){
const v910=v903["value"];
const v911=v903["value"];
v909=__bits(__float(v910) + __float(v911));}else{
const v912=2;
let v913;if((v907===v912)){
const v914=v903["value"];
const v915=v903["value"];
v913=__bits(__float(v914) - __float(v915));}else{
const v916=3;
let v917;if((v907===v916)){
const v918=v903["value"];
const v919=v903["value"];
v917=__bits(__float(v918) * __float(v919));}else{
v917=__bits((__float(v903["value"]))/(__float(v903["value"])));}
v913=v917;}
v909=v913;}
const v920=v909;
const v921=v903["id"];
const v922=v903["id"];
const v923=v903["value"];
const v924=v903["value"];
const v926=v903["id"];
const v927=4294967295;
const v928=!(v926===v927);
let v929=v928;if(!v929){
const v930=v903["id"];
const v931=4294967295;
v929=!(v930===v931);}
const v932=v929;
const v933=false;
const v934=(v932===v933);
let v935=v934;if(!v935){
v935=v904["failed"];}
let v936;
let v937;
if(v935){
const v938=__fn11(v920);
v936=v938;
v937=v904;
}else{
const v939=v904["nodes"];
const v940=(v939).length;
const v941=v904["maximum"];
let v942;
let v943;
if(((v940) >= (v941))){
const v944=__fn11(v920);
const v945=true;
const v946=v904["nodes"];
const v947=v904["maximum"];
const v948=({["nodes"]:v946,["maximum"]:v947,["failed"]:v945});
v942=v944;
v943=v948;
}else{
const v949=({["value"]:v920,["id"]:v940});
const v950=v904["nodes"];
const v951=({["op"]:v907,["a"]:v921,["b"]:v922,["av"]:v923,["bv"]:v924,["value"]:v920});
const v952=__tempEdit(v950,"push",v951);
const v953=v904["maximum"];
const v954=v904["failed"];
const v955=({["nodes"]:v952,["maximum"]:v953,["failed"]:v954});
v942=v949;
v943=v955;
}
v936=v942;
v937=v943;
}
return ({["value"]:v936,["tape"]:v937});}
function __fn22(v956,v957,v958,v959){
const v960=1000000;
let v961;if(((v957) > (v960))){
v961=({Err:"reverse differentiation capacity exceeds one million nodes"});}else{
const v962=new __InkBuffer([]);
const v963=new __InkBuffer([]);
const v964=false;
const v965=({["nodes"]:v963,["maximum"]:v957,["failed"]:v964});
const v966=0;
let v967=v962;
let v968=v965;
let v969=v966;
for(let v971=0;v971<v956.length;v971++){
const v972=v956[v971];
const v973=v968;
const v974=0;
const v975=4294967295;
const v976=4294967295;
const v977=0;
const v978=0;
const v980=true;
const v981=false;
const v982=(v980===v981);
let v983=v982;if(!v983){
v983=v973["failed"];}
let v984;
let v985;
if(v983){
const v986=__fn11(v972);
v984=v986;
v985=v973;
}else{
const v987=v973["nodes"];
const v988=(v987).length;
const v989=v973["maximum"];
let v990;
let v991;
if(((v988) >= (v989))){
const v992=__fn11(v972);
const v993=true;
const v994=v973["nodes"];
const v995=v973["maximum"];
const v996=({["nodes"]:v994,["maximum"]:v995,["failed"]:v993});
v990=v992;
v991=v996;
}else{
const v997=({["value"]:v972,["id"]:v988});
const v998=v973["nodes"];
const v999=({["op"]:v974,["a"]:v975,["b"]:v976,["av"]:v977,["bv"]:v978,["value"]:v972});
const v1000=__tempEdit(v998,"push",v999);
const v1001=v973["maximum"];
const v1002=v973["failed"];
const v1003=({["nodes"]:v1000,["maximum"]:v1001,["failed"]:v1002});
v990=v997;
v991=v1003;
}
v984=v990;
v985=v991;
}
const v1005=v967;
const v1006=v984;
const v1007=__tempEdit(v1005,"push",v1006);
const v1008=v985;
const v1009=v969;
const v1010=1;
const v1011=(((v1009) + (v1010)) >>> 0);
v967=v1007;
v968=v1008;
v969=v1011;
}
const v1013=v967;
const v1014=v1013.freeze();
const v1015=v968;
const v1017=v959["features"];
const v1018=v1017.length;
const v1019=new Array(v1018);
for(let v1020=0;v1020<v1018;v1020++){
const v1021=v1017[v1020];
v1019[v1020]=__fn11(v1021);
}
const v1022=v959["target"];
const v1023=__fn11(v1022);
const v1026=({["features"]:v1019,["target"]:v1023});
const v1030=v1026["features"];
const v1032=Math.min(v1014.length,v1030.length);
const v1033=new Array(v1032);
for(let v1034=0;v1034<v1032;v1034++){
const v1035=v1014[v1034];
const v1036=v1030[v1034];
v1033[v1034]=({["left"]:v1035,["right"]:v1036});
}
const v1037=new __InkBuffer([]);
const v1038=0;
let v1039=v1037;
let v1040=v1015;
let v1041=v1038;
for(let v1043=0;v1043<v1033.length;v1043++){
const v1044=v1033[v1043];
const v1045=v1044["left"];
const v1046=v1044["right"];
const v1047=v1040;
const v1050=3;
const v1051=1;
let v1052;if((v1050===v1051)){
const v1053=v1045["value"];
const v1054=v1046["value"];
v1052=__bits(__float(v1053) + __float(v1054));}else{
const v1055=2;
let v1056;if((v1050===v1055)){
const v1057=v1045["value"];
const v1058=v1046["value"];
v1056=__bits(__float(v1057) - __float(v1058));}else{
const v1059=3;
let v1060;if((v1050===v1059)){
const v1061=v1045["value"];
const v1062=v1046["value"];
v1060=__bits(__float(v1061) * __float(v1062));}else{
v1060=__bits((__float(v1045["value"]))/(__float(v1046["value"])));}
v1056=v1060;}
v1052=v1056;}
const v1063=v1052;
const v1064=v1045["id"];
const v1065=v1046["id"];
const v1066=v1045["value"];
const v1067=v1046["value"];
const v1068=({["op"]:v1050,["a"]:v1064,["b"]:v1065,["av"]:v1066,["bv"]:v1067,["value"]:v1063});
const v1069=v1045["id"];
const v1070=4294967295;
const v1071=!(v1069===v1070);
let v1072=v1071;if(!v1072){
const v1073=v1046["id"];
const v1074=4294967295;
v1072=!(v1073===v1074);}
const v1075=v1072;
const v1076=__fn12(v1047,v1068,v1075);
const v1077=v1039;
const v1078=v1076["value"];
const v1079=__tempEdit(v1077,"push",v1078);
const v1080=v1076["tape"];
const v1081=v1041;
const v1082=1;
const v1083=(((v1081) + (v1082)) >>> 0);
v1039=v1079;
v1040=v1080;
v1041=v1083;
}
const v1085=v1039;
const v1086=v1085.freeze();
const v1087=v1040;
const v1089=0;
const v1090=__fn11(v1089);
let v1091=v1090;
let v1092=v1087;
for(let v1094=0;v1094<v1086.length;v1094++){
const v1095=v1086[v1094];
const v1096=1;
const v1097=v1092;
const v1098=v1091;
const v1099=1;
let v1100;if((v1096===v1099)){
const v1101=v1098["value"];
const v1102=v1095["value"];
v1100=__bits(__float(v1101) + __float(v1102));}else{
const v1103=2;
let v1104;if((v1096===v1103)){
const v1105=v1098["value"];
const v1106=v1095["value"];
v1104=__bits(__float(v1105) - __float(v1106));}else{
const v1107=3;
let v1108;if((v1096===v1107)){
const v1109=v1098["value"];
const v1110=v1095["value"];
v1108=__bits(__float(v1109) * __float(v1110));}else{
v1108=__bits((__float(v1098["value"]))/(__float(v1095["value"])));}
v1104=v1108;}
v1100=v1104;}
const v1111=v1100;
const v1112=v1098["id"];
const v1113=v1095["id"];
const v1114=v1098["value"];
const v1115=v1095["value"];
const v1117=v1098["id"];
const v1118=4294967295;
const v1119=!(v1117===v1118);
let v1120=v1119;if(!v1120){
const v1121=v1095["id"];
const v1122=4294967295;
v1120=!(v1121===v1122);}
const v1123=v1120;
const v1124=false;
const v1125=(v1123===v1124);
let v1126=v1125;if(!v1126){
v1126=v1097["failed"];}
let v1127;
let v1128;
if(v1126){
const v1129=__fn11(v1111);
v1127=v1129;
v1128=v1097;
}else{
const v1130=v1097["nodes"];
const v1131=(v1130).length;
const v1132=v1097["maximum"];
let v1133;
let v1134;
if(((v1131) >= (v1132))){
const v1135=__fn11(v1111);
const v1136=true;
const v1137=v1097["nodes"];
const v1138=v1097["maximum"];
const v1139=({["nodes"]:v1137,["maximum"]:v1138,["failed"]:v1136});
v1133=v1135;
v1134=v1139;
}else{
const v1140=({["value"]:v1111,["id"]:v1131});
const v1141=v1097["nodes"];
const v1142=({["op"]:v1096,["a"]:v1112,["b"]:v1113,["av"]:v1114,["bv"]:v1115,["value"]:v1111});
const v1143=__tempEdit(v1141,"push",v1142);
const v1144=v1097["maximum"];
const v1145=v1097["failed"];
const v1146=({["nodes"]:v1143,["maximum"]:v1144,["failed"]:v1145});
v1133=v1140;
v1134=v1146;
}
v1127=v1133;
v1128=v1134;
}
v1091=v1127;
v1092=v1128;
}
const v1148=({["features"]:v1019,["target"]:v1023});
const v1149=v1092;
const v1151=v1148["target"];
const v1153=2;
const v1154=v1091;
const v1155=1;
let v1156;if((v1153===v1155)){
const v1157=v1154["value"];
const v1158=v1151["value"];
v1156=__bits(__float(v1157) + __float(v1158));}else{
const v1159=2;
let v1160;if((v1153===v1159)){
const v1161=v1154["value"];
const v1162=v1151["value"];
v1160=__bits(__float(v1161) - __float(v1162));}else{
const v1163=3;
let v1164;if((v1153===v1163)){
const v1165=v1154["value"];
const v1166=v1151["value"];
v1164=__bits(__float(v1165) * __float(v1166));}else{
v1164=__bits((__float(v1154["value"]))/(__float(v1151["value"])));}
v1160=v1164;}
v1156=v1160;}
const v1167=v1156;
const v1168=v1154["id"];
const v1169=v1151["id"];
const v1170=v1154["value"];
const v1171=v1151["value"];
const v1173=v1154["id"];
const v1174=4294967295;
const v1175=!(v1173===v1174);
let v1176=v1175;if(!v1176){
const v1177=v1151["id"];
const v1178=4294967295;
v1176=!(v1177===v1178);}
const v1179=v1176;
const v1180=false;
const v1181=(v1179===v1180);
let v1182=v1181;if(!v1182){
v1182=v1149["failed"];}
let v1183;
let v1184;
if(v1182){
const v1185=__fn11(v1167);
v1183=v1185;
v1184=v1149;
}else{
const v1186=v1149["nodes"];
const v1187=(v1186).length;
const v1188=v1149["maximum"];
let v1189;
let v1190;
if(((v1187) >= (v1188))){
const v1191=__fn11(v1167);
const v1192=true;
const v1193=v1149["nodes"];
const v1194=v1149["maximum"];
const v1195=({["nodes"]:v1193,["maximum"]:v1194,["failed"]:v1192});
v1189=v1191;
v1190=v1195;
}else{
const v1196=({["value"]:v1167,["id"]:v1187});
const v1197=v1149["nodes"];
const v1198=({["op"]:v1153,["a"]:v1168,["b"]:v1169,["av"]:v1170,["bv"]:v1171,["value"]:v1167});
const v1199=__tempEdit(v1197,"push",v1198);
const v1200=v1149["maximum"];
const v1201=v1149["failed"];
const v1202=({["nodes"]:v1199,["maximum"]:v1200,["failed"]:v1201});
v1189=v1196;
v1190=v1202;
}
v1183=v1189;
v1184=v1190;
}
const v1204=v1183;
const v1205=v1184;
const v1208=3;
const v1209=1;
let v1210;if((v1208===v1209)){
const v1211=v1204["value"];
const v1212=v1204["value"];
v1210=__bits(__float(v1211) + __float(v1212));}else{
const v1213=2;
let v1214;if((v1208===v1213)){
const v1215=v1204["value"];
const v1216=v1204["value"];
v1214=__bits(__float(v1215) - __float(v1216));}else{
const v1217=3;
let v1218;if((v1208===v1217)){
const v1219=v1204["value"];
const v1220=v1204["value"];
v1218=__bits(__float(v1219) * __float(v1220));}else{
v1218=__bits((__float(v1204["value"]))/(__float(v1204["value"])));}
v1214=v1218;}
v1210=v1214;}
const v1221=v1210;
const v1222=v1204["id"];
const v1223=v1204["id"];
const v1224=v1204["value"];
const v1225=v1204["value"];
const v1227=v1204["id"];
const v1228=4294967295;
const v1229=!(v1227===v1228);
let v1230=v1229;if(!v1230){
const v1231=v1204["id"];
const v1232=4294967295;
v1230=!(v1231===v1232);}
const v1233=v1230;
const v1234=false;
const v1235=(v1233===v1234);
let v1236=v1235;if(!v1236){
v1236=v1205["failed"];}
let v1237;
let v1238;
if(v1236){
const v1239=__fn11(v1221);
v1237=v1239;
v1238=v1205;
}else{
const v1240=v1205["nodes"];
const v1241=(v1240).length;
const v1242=v1205["maximum"];
let v1243;
let v1244;
if(((v1241) >= (v1242))){
const v1245=__fn11(v1221);
const v1246=true;
const v1247=v1205["nodes"];
const v1248=v1205["maximum"];
const v1249=({["nodes"]:v1247,["maximum"]:v1248,["failed"]:v1246});
v1243=v1245;
v1244=v1249;
}else{
const v1250=({["value"]:v1221,["id"]:v1241});
const v1251=v1205["nodes"];
const v1252=({["op"]:v1208,["a"]:v1222,["b"]:v1223,["av"]:v1224,["bv"]:v1225,["value"]:v1221});
const v1253=__tempEdit(v1251,"push",v1252);
const v1254=v1205["maximum"];
const v1255=v1205["failed"];
const v1256=({["nodes"]:v1253,["maximum"]:v1254,["failed"]:v1255});
v1243=v1250;
v1244=v1256;
}
v1237=v1243;
v1238=v1244;
}
const v1258=v1238;
let v1259;if(v1258["failed"]){
v1259=({Err:"reverse differentiation tape capacity exceeded"});}else{
const v1260=v1238;
const v1261=v1260["nodes"];
const v1262=v1261.freeze();
const v1263=v1237;
const v1264=__fn19(v1262,v1263,v958);
const v1265=v1014.length;
const v1266=new Array(v1265);
for(let v1267=0;v1267<v1265;v1267++){
const v1268=v1014[v1267];
const v1269=v1268["id"];
let v1270;if(v1269<v1264.length){v1270=v1264[v1269];}else{
v1270=0;}
v1266[v1267]=v1270;
}
v1259=({Ok:v1266});}
v961=v1259;}
return v961;}
function __fn23(v1271,v1272,v1273,v1274){
const v1275=1000000;
let v1276;if(((v1272) > (v1275))){
v1276=({Err:"reverse differentiation capacity exceeds one million nodes"});}else{
const v1277=new __InkBuffer([]);
const v1278=new __InkBuffer([]);
const v1279=false;
const v1280=({["nodes"]:v1278,["maximum"]:v1272,["failed"]:v1279});
const v1281=0;
let v1282=v1277;
let v1283=v1280;
let v1284=v1281;
for(let v1286=0;v1286<v1271.length;v1286++){
const v1287=v1271[v1286];
const v1288=v1283;
const v1289=0;
const v1290=4294967295;
const v1291=4294967295;
const v1292=0;
const v1293=0;
const v1295=true;
const v1296=false;
const v1297=(v1295===v1296);
let v1298=v1297;if(!v1298){
v1298=v1288["failed"];}
let v1299;
let v1300;
if(v1298){
const v1301=__fn11(v1287);
v1299=v1301;
v1300=v1288;
}else{
const v1302=v1288["nodes"];
const v1303=(v1302).length;
const v1304=v1288["maximum"];
let v1305;
let v1306;
if(((v1303) >= (v1304))){
const v1307=__fn11(v1287);
const v1308=true;
const v1309=v1288["nodes"];
const v1310=v1288["maximum"];
const v1311=({["nodes"]:v1309,["maximum"]:v1310,["failed"]:v1308});
v1305=v1307;
v1306=v1311;
}else{
const v1312=({["value"]:v1287,["id"]:v1303});
const v1313=v1288["nodes"];
const v1314=({["op"]:v1289,["a"]:v1290,["b"]:v1291,["av"]:v1292,["bv"]:v1293,["value"]:v1287});
const v1315=__tempEdit(v1313,"push",v1314);
const v1316=v1288["maximum"];
const v1317=v1288["failed"];
const v1318=({["nodes"]:v1315,["maximum"]:v1316,["failed"]:v1317});
v1305=v1312;
v1306=v1318;
}
v1299=v1305;
v1300=v1306;
}
const v1320=v1282;
const v1321=v1299;
const v1322=__tempEdit(v1320,"push",v1321);
const v1323=v1300;
const v1324=v1284;
const v1325=1;
const v1326=(((v1324) + (v1325)) >>> 0);
v1282=v1322;
v1283=v1323;
v1284=v1326;
}
const v1328=v1282;
const v1329=v1328.freeze();
const v1330=v1283;
const v1332=v1274["features"];
const v1333=v1332.length;
const v1334=new Array(v1333);
for(let v1335=0;v1335<v1333;v1335++){
const v1336=v1332[v1335];
v1334[v1335]=__fn11(v1336);
}
const v1337=v1274["target"];
const v1338=__fn11(v1337);
const v1341=({["features"]:v1334,["target"]:v1338});
const v1345=v1341["features"];
const v1347=Math.min(v1329.length,v1345.length);
const v1348=new Array(v1347);
for(let v1349=0;v1349<v1347;v1349++){
const v1350=v1329[v1349];
const v1351=v1345[v1349];
v1348[v1349]=({["left"]:v1350,["right"]:v1351});
}
const v1352=new __InkBuffer([]);
const v1353=0;
let v1354=v1352;
let v1355=v1330;
let v1356=v1353;
for(let v1358=0;v1358<v1348.length;v1358++){
const v1359=v1348[v1358];
const v1360=v1359["left"];
const v1361=v1359["right"];
const v1362=v1355;
const v1365=3;
const v1366=1;
let v1367;if((v1365===v1366)){
const v1368=v1360["value"];
const v1369=v1361["value"];
v1367=__bits(__float(v1368) + __float(v1369));}else{
const v1370=2;
let v1371;if((v1365===v1370)){
const v1372=v1360["value"];
const v1373=v1361["value"];
v1371=__bits(__float(v1372) - __float(v1373));}else{
const v1374=3;
let v1375;if((v1365===v1374)){
const v1376=v1360["value"];
const v1377=v1361["value"];
v1375=__bits(__float(v1376) * __float(v1377));}else{
v1375=__bits((__float(v1360["value"]))/(__float(v1361["value"])));}
v1371=v1375;}
v1367=v1371;}
const v1378=v1367;
const v1379=v1360["id"];
const v1380=v1361["id"];
const v1381=v1360["value"];
const v1382=v1361["value"];
const v1383=({["op"]:v1365,["a"]:v1379,["b"]:v1380,["av"]:v1381,["bv"]:v1382,["value"]:v1378});
const v1384=v1360["id"];
const v1385=4294967295;
const v1386=!(v1384===v1385);
let v1387=v1386;if(!v1387){
const v1388=v1361["id"];
const v1389=4294967295;
v1387=!(v1388===v1389);}
const v1390=v1387;
const v1391=__fn12(v1362,v1383,v1390);
const v1392=v1354;
const v1393=v1391["value"];
const v1394=__tempEdit(v1392,"push",v1393);
const v1395=v1391["tape"];
const v1396=v1356;
const v1397=1;
const v1398=(((v1396) + (v1397)) >>> 0);
v1354=v1394;
v1355=v1395;
v1356=v1398;
}
const v1400=v1354;
const v1401=v1400.freeze();
const v1402=v1355;
const v1404=0;
const v1405=__fn11(v1404);
let v1406=v1405;
let v1407=v1402;
for(let v1409=0;v1409<v1401.length;v1409++){
const v1410=v1401[v1409];
const v1411=1;
const v1412=v1407;
const v1413=v1406;
const v1414=1;
let v1415;if((v1411===v1414)){
const v1416=v1413["value"];
const v1417=v1410["value"];
v1415=__bits(__float(v1416) + __float(v1417));}else{
const v1418=2;
let v1419;if((v1411===v1418)){
const v1420=v1413["value"];
const v1421=v1410["value"];
v1419=__bits(__float(v1420) - __float(v1421));}else{
const v1422=3;
let v1423;if((v1411===v1422)){
const v1424=v1413["value"];
const v1425=v1410["value"];
v1423=__bits(__float(v1424) * __float(v1425));}else{
v1423=__bits((__float(v1413["value"]))/(__float(v1410["value"])));}
v1419=v1423;}
v1415=v1419;}
const v1426=v1415;
const v1427=v1413["id"];
const v1428=v1410["id"];
const v1429=v1413["value"];
const v1430=v1410["value"];
const v1432=v1413["id"];
const v1433=4294967295;
const v1434=!(v1432===v1433);
let v1435=v1434;if(!v1435){
const v1436=v1410["id"];
const v1437=4294967295;
v1435=!(v1436===v1437);}
const v1438=v1435;
const v1439=false;
const v1440=(v1438===v1439);
let v1441=v1440;if(!v1441){
v1441=v1412["failed"];}
let v1442;
let v1443;
if(v1441){
const v1444=__fn11(v1426);
v1442=v1444;
v1443=v1412;
}else{
const v1445=v1412["nodes"];
const v1446=(v1445).length;
const v1447=v1412["maximum"];
let v1448;
let v1449;
if(((v1446) >= (v1447))){
const v1450=__fn11(v1426);
const v1451=true;
const v1452=v1412["nodes"];
const v1453=v1412["maximum"];
const v1454=({["nodes"]:v1452,["maximum"]:v1453,["failed"]:v1451});
v1448=v1450;
v1449=v1454;
}else{
const v1455=({["value"]:v1426,["id"]:v1446});
const v1456=v1412["nodes"];
const v1457=({["op"]:v1411,["a"]:v1427,["b"]:v1428,["av"]:v1429,["bv"]:v1430,["value"]:v1426});
const v1458=__tempEdit(v1456,"push",v1457);
const v1459=v1412["maximum"];
const v1460=v1412["failed"];
const v1461=({["nodes"]:v1458,["maximum"]:v1459,["failed"]:v1460});
v1448=v1455;
v1449=v1461;
}
v1442=v1448;
v1443=v1449;
}
v1406=v1442;
v1407=v1443;
}
const v1463=({["features"]:v1334,["target"]:v1338});
const v1464=v1407;
const v1466=v1463["target"];
const v1468=2;
const v1469=v1406;
const v1470=1;
let v1471;if((v1468===v1470)){
const v1472=v1469["value"];
const v1473=v1466["value"];
v1471=__bits(__float(v1472) + __float(v1473));}else{
const v1474=2;
let v1475;if((v1468===v1474)){
const v1476=v1469["value"];
const v1477=v1466["value"];
v1475=__bits(__float(v1476) - __float(v1477));}else{
const v1478=3;
let v1479;if((v1468===v1478)){
const v1480=v1469["value"];
const v1481=v1466["value"];
v1479=__bits(__float(v1480) * __float(v1481));}else{
v1479=__bits((__float(v1469["value"]))/(__float(v1466["value"])));}
v1475=v1479;}
v1471=v1475;}
const v1482=v1471;
const v1483=v1469["id"];
const v1484=v1466["id"];
const v1485=v1469["value"];
const v1486=v1466["value"];
const v1488=v1469["id"];
const v1489=4294967295;
const v1490=!(v1488===v1489);
let v1491=v1490;if(!v1491){
const v1492=v1466["id"];
const v1493=4294967295;
v1491=!(v1492===v1493);}
const v1494=v1491;
const v1495=false;
const v1496=(v1494===v1495);
let v1497=v1496;if(!v1497){
v1497=v1464["failed"];}
let v1498;
let v1499;
if(v1497){
const v1500=__fn11(v1482);
v1498=v1500;
v1499=v1464;
}else{
const v1501=v1464["nodes"];
const v1502=(v1501).length;
const v1503=v1464["maximum"];
let v1504;
let v1505;
if(((v1502) >= (v1503))){
const v1506=__fn11(v1482);
const v1507=true;
const v1508=v1464["nodes"];
const v1509=v1464["maximum"];
const v1510=({["nodes"]:v1508,["maximum"]:v1509,["failed"]:v1507});
v1504=v1506;
v1505=v1510;
}else{
const v1511=({["value"]:v1482,["id"]:v1502});
const v1512=v1464["nodes"];
const v1513=({["op"]:v1468,["a"]:v1483,["b"]:v1484,["av"]:v1485,["bv"]:v1486,["value"]:v1482});
const v1514=__tempEdit(v1512,"push",v1513);
const v1515=v1464["maximum"];
const v1516=v1464["failed"];
const v1517=({["nodes"]:v1514,["maximum"]:v1515,["failed"]:v1516});
v1504=v1511;
v1505=v1517;
}
v1498=v1504;
v1499=v1505;
}
const v1519=v1498;
const v1520=v1499;
const v1523=3;
const v1524=1;
let v1525;if((v1523===v1524)){
const v1526=v1519["value"];
const v1527=v1519["value"];
v1525=__bits(__float(v1526) + __float(v1527));}else{
const v1528=2;
let v1529;if((v1523===v1528)){
const v1530=v1519["value"];
const v1531=v1519["value"];
v1529=__bits(__float(v1530) - __float(v1531));}else{
const v1532=3;
let v1533;if((v1523===v1532)){
const v1534=v1519["value"];
const v1535=v1519["value"];
v1533=__bits(__float(v1534) * __float(v1535));}else{
v1533=__bits((__float(v1519["value"]))/(__float(v1519["value"])));}
v1529=v1533;}
v1525=v1529;}
const v1536=v1525;
const v1537=v1519["id"];
const v1538=v1519["id"];
const v1539=v1519["value"];
const v1540=v1519["value"];
const v1542=v1519["id"];
const v1543=4294967295;
const v1544=!(v1542===v1543);
let v1545=v1544;if(!v1545){
const v1546=v1519["id"];
const v1547=4294967295;
v1545=!(v1546===v1547);}
const v1548=v1545;
const v1549=false;
const v1550=(v1548===v1549);
let v1551=v1550;if(!v1551){
v1551=v1520["failed"];}
let v1552;
let v1553;
if(v1551){
const v1554=__fn11(v1536);
v1552=v1554;
v1553=v1520;
}else{
const v1555=v1520["nodes"];
const v1556=(v1555).length;
const v1557=v1520["maximum"];
let v1558;
let v1559;
if(((v1556) >= (v1557))){
const v1560=__fn11(v1536);
const v1561=true;
const v1562=v1520["nodes"];
const v1563=v1520["maximum"];
const v1564=({["nodes"]:v1562,["maximum"]:v1563,["failed"]:v1561});
v1558=v1560;
v1559=v1564;
}else{
const v1565=({["value"]:v1536,["id"]:v1556});
const v1566=v1520["nodes"];
const v1567=({["op"]:v1523,["a"]:v1537,["b"]:v1538,["av"]:v1539,["bv"]:v1540,["value"]:v1536});
const v1568=__tempEdit(v1566,"push",v1567);
const v1569=v1520["maximum"];
const v1570=v1520["failed"];
const v1571=({["nodes"]:v1568,["maximum"]:v1569,["failed"]:v1570});
v1558=v1565;
v1559=v1571;
}
v1552=v1558;
v1553=v1559;
}
const v1573=v1553;
let v1574;if(v1573["failed"]){
v1574=({Err:"reverse differentiation tape capacity exceeded"});}else{
const v1575=v1553;
const v1576=v1575["nodes"];
const v1577=v1576.freeze();
const v1578=v1552;
const v1579=__fn19(v1577,v1578,v1273);
const v1580=v1552;
const v1581=v1580["value"];
const v1582=v1329.length;
const v1583=new Array(v1582);
for(let v1584=0;v1584<v1582;v1584++){
const v1585=v1329[v1584];
const v1586=v1585["id"];
let v1587;if(v1586<v1579.length){v1587=v1579[v1586];}else{
v1587=0;}
v1583[v1584]=v1587;
}
v1574=({Ok:({["value"]:v1581,["gradient"]:v1583})});}
v1276=v1574;}
return v1276;}
function __into0(v1588){
let v1589=new __InkBuffer([]);
for(let v1590=0;v1590<64;v1590++){
const v1591=(v1590>>>0);
const v1592=v1589;
const v1593=0;
v1589=__tempEdit(v1592,"push",v1593);}
const v1594=v1589;
const v1595=v1594.freeze();
const v1596=v1595.length;
for(let v1597=0;v1597<v1596;v1597++){
v1588[v1597]=__intoOutput0(v1595[v1597]);
}
return v1596;}
function __into6(v1598,v1599,v1600,v1601){
const v1602=v1598.length;
for(let v1604=0;v1604<v1602;v1604++){
const v1605=v1598[v1604];
const v1606=(v1604>>>0);
let v1607;if(v1606<v1599.length){v1607=v1599[v1606];}else{
v1607=0;}
const v1608=v1607;
const v1609=Math.fround(__float(v1600) * __float(v1608));
v1601[v1604]=__intoOutput6(__bits(__float(v1605) - v1609));
}
return v1602;}
function __into8(v1610,v1611){
const v1612=1;
const v1613=new __InkBuffer(Array.from([v1612]));
let v1614;if(Object.hasOwn(v1610,"Some")){
const v1615=v1610["Some"];
v1614=__tempEdit(v1613,"push",v1615);}else{
const v1616=null;
const v1617=9;
v1614=__tempEdit(v1613,"push",v1617);}
const v1618=v1614;
const v1619=v1618.freeze();
const v1620=v1619.length;
for(let v1621=0;v1621<v1620;v1621++){
v1611[v1621]=v1619[v1621];
}
return v1620;}
function __into10(v1622,v1623){
const v1624=v1622.length;
for(let v1626=0;v1626<v1624;v1626++){
const v1627=v1622[v1626];
const v1628=__fn9(v1627);
const v1629=0;
let v1630;if(v1629<v1628.length){v1630=v1628.item(v1629);}else{
const v1631=0;
v1630=((v1631 ^ 2147483648) >>> 0);}
v1623[v1626]=__intoOutput10(v1630);
}
return v1624;}
function __into19(v1632,v1633,v1634,v1635){
let v1636=new __InkBuffer([]);
for(let v1637=0;v1637<v1632.length;v1637++){
const v1638=v1632[v1637];
const v1639=v1636;
const v1640=0;
v1636=__tempEdit(v1639,"push",v1640);
}
const v1641=v1636;
const v1642=v1633["id"];
const v1643=1065353216;
const v1644=4294967295;
let v1645;if((v1642===v1644)){
v1645=v1641;}else{
let v1646;if(v1642<v1641.length){v1646=v1641.item(v1642);}else{
v1646=0;}
const v1647=v1646;
v1645=__tempSet(v1641,v1642,__bits(__float(v1647) + __float(v1643)),false);}
const v1648=v1645;
const v1649=(v1632).length;
let v1650=v1648;
let v1651=v1649;
for(let v1653=v1632.length-1;v1653>=0;v1653--){
const v1654=v1632[v1653];
const v1656=v1651;
const v1657=1;
const v1658=(((v1656) - (v1657)) >>> 0);
const v1659=v1650;
let v1660;if(v1658<v1659.length){v1660=v1659.item(v1658);}else{
v1660=0;}
const v1661=v1660;
let v1662=v1634;if(v1662){
const v1663=0;
v1662=((__float(v1661)) === (__float(v1663)));}
let v1664;if(v1662){
v1664=v1650;}else{
const v1665=v1650;
const v1666=v1654["op"];
const v1667=1;
let v1668;if((v1666===v1667)){
const v1669=v1654["a"];
const v1670=4294967295;
let v1671;if((v1669===v1670)){
v1671=v1665;}else{
let v1672;if(v1669<v1665.length){v1672=v1665.item(v1669);}else{
v1672=0;}
const v1673=v1672;
v1671=__tempSet(v1665,v1669,__bits(__float(v1673) + __float(v1661)),false);}
const v1674=v1671;
const v1675=v1654["b"];
const v1676=4294967295;
let v1677;if((v1675===v1676)){
v1677=v1674;}else{
let v1678;if(v1675<v1674.length){v1678=v1674.item(v1675);}else{
v1678=0;}
const v1679=v1678;
v1677=__tempSet(v1674,v1675,__bits(__float(v1679) + __float(v1661)),false);}
v1668=v1677;}else{
const v1680=v1654["op"];
const v1681=2;
let v1682;if((v1680===v1681)){
const v1683=v1654["a"];
const v1684=4294967295;
let v1685;if((v1683===v1684)){
v1685=v1665;}else{
let v1686;if(v1683<v1665.length){v1686=v1665.item(v1683);}else{
v1686=0;}
const v1687=v1686;
v1685=__tempSet(v1665,v1683,__bits(__float(v1687) + __float(v1661)),false);}
const v1688=v1685;
const v1689=v1654["b"];
const v1690=((v1661 ^ 2147483648) >>> 0);
const v1691=4294967295;
let v1692;if((v1689===v1691)){
v1692=v1688;}else{
let v1693;if(v1689<v1688.length){v1693=v1688.item(v1689);}else{
v1693=0;}
const v1694=v1693;
v1692=__tempSet(v1688,v1689,__bits(__float(v1694) + __float(v1690)),false);}
v1682=v1692;}else{
const v1695=v1654["op"];
const v1696=3;
let v1697;if((v1695===v1696)){
const v1698=v1654["a"];
const v1699=v1654["bv"];
const v1700=__bits(__float(v1661) * __float(v1699));
const v1701=4294967295;
let v1702;if((v1698===v1701)){
v1702=v1665;}else{
let v1703;if(v1698<v1665.length){v1703=v1665.item(v1698);}else{
v1703=0;}
const v1704=v1703;
v1702=__tempSet(v1665,v1698,__bits(__float(v1704) + __float(v1700)),false);}
const v1705=v1702;
const v1706=v1654["b"];
const v1707=v1654["av"];
const v1708=__bits(__float(v1661) * __float(v1707));
const v1709=4294967295;
let v1710;if((v1706===v1709)){
v1710=v1705;}else{
let v1711;if(v1706<v1705.length){v1711=v1705.item(v1706);}else{
v1711=0;}
const v1712=v1711;
v1710=__tempSet(v1705,v1706,__bits(__float(v1712) + __float(v1708)),false);}
v1697=v1710;}else{
const v1713=v1654["op"];
const v1714=4;
let v1715;if((v1713===v1714)){
const v1716=v1654["a"];
const v1717=__bits((__float(v1661))/(__float(v1654["bv"])));
const v1718=4294967295;
let v1719;if((v1716===v1718)){
v1719=v1665;}else{
let v1720;if(v1716<v1665.length){v1720=v1665.item(v1716);}else{
v1720=0;}
const v1721=v1720;
v1719=__tempSet(v1665,v1716,__bits(__float(v1721) + __float(v1717)),false);}
const v1722=v1719;
const v1723=v1654["b"];
const v1724=v1654["av"];
const v1725=v1654["bv"];
const v1726=v1654["bv"];
const v1727=__bits((__float(__bits(__float(v1661) * __float(v1724))))/(__float(__bits(__float(v1725) * __float(v1726)))));
const v1728=((v1727 ^ 2147483648) >>> 0);
const v1729=4294967295;
let v1730;if((v1723===v1729)){
v1730=v1722;}else{
let v1731;if(v1723<v1722.length){v1731=v1722.item(v1723);}else{
v1731=0;}
const v1732=v1731;
v1730=__tempSet(v1722,v1723,__bits(__float(v1732) + __float(v1728)),false);}
v1715=v1730;}else{
const v1733=v1654["op"];
const v1734=5;
let v1735;if((v1733===v1734)){
const v1736=v1654["a"];
const v1737=((v1661 ^ 2147483648) >>> 0);
const v1738=4294967295;
let v1739;if((v1736===v1738)){
v1739=v1665;}else{
let v1740;if(v1736<v1665.length){v1740=v1665.item(v1736);}else{
v1740=0;}
const v1741=v1740;
v1739=__tempSet(v1665,v1736,__bits(__float(v1741) + __float(v1737)),false);}
v1735=v1739;}else{
const v1742=v1654["op"];
const v1743=6;
let v1744;if((v1742===v1743)){
const v1745=v1654["a"];
const v1746=1073741824;
const v1747=v1654["value"];
const v1748=__bits((__float(v1661))/(__float(__bits(__float(v1746) * __float(v1747)))));
const v1749=4294967295;
let v1750;if((v1745===v1749)){
v1750=v1665;}else{
let v1751;if(v1745<v1665.length){v1751=v1665.item(v1745);}else{
v1751=0;}
const v1752=v1751;
v1750=__tempSet(v1665,v1745,__bits(__float(v1752) + __float(v1748)),false);}
v1744=v1750;}else{
v1744=v1665;}
v1735=v1744;}
v1715=v1735;}
v1697=v1715;}
v1682=v1697;}
v1668=v1682;}
v1664=v1668;}
const v1753=v1664;
const v1754=({["index"]:v1658,["gradient"]:v1753});
v1650=v1754["gradient"];
v1651=v1754["index"];
}
const v1755=({["gradient"]:v1650,["index"]:v1651});
const v1756=v1755["gradient"];
const v1757=v1756.freeze();
const v1758=v1757.length;
for(let v1759=0;v1759<v1758;v1759++){
v1635[v1759]=__intoOutput19(v1757[v1759]);
}
return v1758;}
const __namedTypes={"Context":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"},"__ink_reverse_0_Flow":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"},"__ink_reverse_0_Node":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"__ink_reverse_0_Reverse":{"fields":[{"name":"gradient","type":{"kind":"temporary"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Reverse"},"__ink_reverse_0_Tape":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"},"__ink_reverse_0_Wire":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"__ink_reverse_13":{"fields":[{"name":"left","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"right","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_13"},"__ink_reverse_18":{"fields":[{"name":"values","type":{"kind":"temporary"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_18"},"__ink_reverse_3":{"fields":[{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_3"},"__ink_reverse_42":{"fields":[{"name":"values","type":{"kind":"temporary"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_42"},"__ink_reverse_55":{"fields":[{"name":"values","type":{"kind":"temporary"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_55"},"__ink_reverse_58":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"__ink_reverse_58"},"__ink_reverse_6":{"fields":[{"name":"value","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_6"},"__ink_reverse_8":{"fields":[{"name":"value","type":{"fields":[{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_3"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_8"}};
// Portable snapshot ABI shared with native/Wasm. Hashing uses Web Crypto.
function __snapshotLimits(limits={}){
 const result={bytes:64*1024*1024,values:1000000,depth:128,...limits};
 for(const k of ['bytes','values','depth'])if(!Number.isSafeInteger(result[k])||result[k]<0||result[k]>(k==='depth'?128:k==='values'?1000000:64*1024*1024))throw Error('invalid snapshot limits');
 return result;
}
const __hash=async bytes=>new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256',bytes));
function __snapshotWriter(limits){
 const out=[];let left=limits.values,maxDepth=0;
 function bytes(xs){if(xs.length>limits.bytes-out.length)throw Error('snapshot byte limit exceeded');for(const x of xs)out.push(x);}
 function integer(n,size){n=BigInt(n);for(let i=0;i<size;i++){bytes([Number(n&255n)]);n>>=8n;}}
 function raw(xs){integer(xs.length,8);bytes(xs);}
 function value(v,t,depth=0,bindings=[]){maxDepth=Math.max(maxDepth,depth);if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{value(v,t.body,depth+1,bindings);}finally{bindings.pop();}break;
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');value(v,bound[1],depth+1,bindings);break;}
  case 'unit':break;case 'bool':bytes([v?1:0]);break;
  case 'u32':case 'i32':case 'f32':integer(v,4);break;case 'u64':integer(v,8);break;
  case 'f64':integer(__dfBits(v),8);break;
  case 'vector':if(v.length!==t.size)throw Error('vector dimension mismatch');for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'int':{let n=v<0n?-v:v;const xs=[];while(n){if(xs.length>=4096)throw Error('snapshot Int exceeds size limit');xs.push(Number(n&255n));n>>=8n;}bytes([v===0n?0:v>0n?1:2]);raw(xs);break;}
  case 'string':raw(__encoder.encode(v));break;
  case 'id':integer(BigInt('0x'+v),16);break;
  case 'enum':integer(t.variants.indexOf(v),4);break;
  case 'record':for(const f of t.fields)value(t.elided?v:v[f.name],f.type,depth+1,bindings);break;
  case 'list':if(v.length>left)throw Error('snapshot value limit exceeded');integer(v.length,8);for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'option':if(Object.hasOwn(v,'Some')){bytes([1]);value(v.Some,t.element,depth+1,bindings);}else bytes([0]);break;
  case 'result':{const branch=t.sum_key?__sumView(t.sum_key,v):v;if(Object.hasOwn(branch,'Ok')){bytes([0]);value(branch.Ok,t.ok,depth+1,bindings);}else{bytes([1]);value(branch.Err,t.error,depth+1,bindings);}break;}
  default:throw Error('unsupported snapshot type');
 }}
 return {bytes,integer,raw,value,charge(cells,depth){left-=cells;if(left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');},get maxDepth(){return maxDepth;},get left(){return left;},finish:()=>new Uint8Array(out)};
}
async function __snapshotEncode(meta,state,options){
 const limits=__snapshotLimits(options),w=__snapshotWriter(limits);
 w.integer(state.version,8);
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const rows=[...state.tables[r.index].entries()].sort((a,b)=>__keyCompare(a[0],b[0],r.key));if(rows.length>Math.floor(w.left/2))throw Error('snapshot row limit exceeded');w.integer(rows.length,8);for(const [k,v]of rows){
  if(!meta.snapshotRows){w.value(k,r.snapshotKey??r.key);w.value(v,r.snapshotValue??r.value);continue;}
  const cache=state.snapshotRows[r.index];let packed=cache.get(k);
  if(!packed){const row=__snapshotWriter(limits);row.value(k,r.snapshotKey??r.key);row.value(v,r.snapshotValue??r.value);packed={bytes:row.finish(),cells:limits.values-row.left,depth:row.maxDepth};cache.set(k,packed);}
  w.charge(packed.cells,packed.depth);w.bytes(packed.bytes);
 }}
 w.integer(state.outbox.length,8);
 for(const e of state.outbox){const channel=meta.events.findIndex(t=>t.name===e.channel);w.integer(e.commit,8);w.integer(e.position,8);w.integer(channel,4);w.value(e.value,meta.events[channel].snapshotType??meta.events[channel].type);}
 const payload=w.finish(),header=__snapshotWriter(limits);header.bytes([86,76,83,84,65,84,69,0,1,0,1,0]);header.bytes(meta.snapshot.program);header.bytes(meta.snapshot.schema);header.integer(payload.length,8);header.bytes(payload);
 const bytes=header.finish();if(bytes.length+32>limits.bytes)throw Error('snapshot byte limit exceeded');const digest=await __hash(bytes);const result=new Uint8Array(bytes.length+32);result.set(bytes);result.set(digest,bytes.length);return result;
}
async function __snapshotDecode(meta,input,options){
 const limits=__snapshotLimits(options);
 if(!(input instanceof Uint8Array)&&!Array.isArray(input))throw Error('expected snapshot bytes');
 if(input.length>limits.bytes||input.length<116)throw Error('snapshot byte length invalid');
 if(Array.isArray(input)&&input.some(b=>!Number.isInteger(b)||b<0||b>255))throw Error('invalid snapshot bytes');
 const bytes=new Uint8Array(input); // capture before asynchronous integrity work
 function same(a,b){return a.length===b.length&&a.every((v,i)=>v===b[i]);}
 if(!same(bytes.subarray(0,12),[86,76,83,84,65,84,69,0,1,0,1,0]))throw Error('snapshot format or semantics version mismatch');
 if(!same(bytes.subarray(12,44),meta.snapshot.program)||!same(bytes.subarray(44,76),meta.snapshot.schema))throw Error('snapshot program or schema identity mismatch');
 const end=bytes.length-32,digest=await __hash(bytes.subarray(0,end));if(!same(digest,bytes.subarray(end)))throw Error('snapshot integrity check failed');
 let at=76,left=limits.values;
 function take(n){if(!Number.isSafeInteger(n)||n<0||n>end-at)throw Error('truncated snapshot');const x=bytes.subarray(at,at+n);at+=n;return x;}
 function integer(size){const xs=take(size);let n=0n;for(let i=size-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return n;}
 function length(){const n=integer(8);if(n>BigInt(Number.MAX_SAFE_INTEGER))throw Error('snapshot length not addressable');return Number(n);}
 function sequence(){const n=length();if(n>left)throw Error('snapshot value limit exceeded');return n;}
 function raw(){return take(length());}
 const n=length();if(n!==end-84)throw Error('snapshot payload length mismatch');
 function value(t,depth=0,bindings=[]){if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{return value(t.body,depth+1,bindings);}finally{bindings.pop();}
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');return value(bound[1],depth+1,bindings);}
  case 'unit':return null;case 'bool':{const b=take(1)[0];if(b>1)throw Error('invalid Bool tag');return b===1;}
  case 'u32':case 'f32':return Number(integer(4));case 'i32':return Number(BigInt.asIntN(32,integer(4)));case 'u64':return integer(8);
  case 'f64':return __dfFromBits(integer(8));
  case 'vector':{const xs=[];for(let i=0;i<t.size;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'int':{const sign=take(1)[0],xs=raw();if(xs.length>4096)throw Error('snapshot Int exceeds size limit');if(!((sign===0&&xs.length===0)||((sign===1||sign===2)&&xs.length>0&&xs[xs.length-1]!==0)))throw Error('noncanonical signed integer');let n=0n;for(let i=xs.length-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return sign===2?-n:n;}
  case 'string':return new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(raw());
  case 'id':return integer(16).toString(16).padStart(32,'0');
  case 'enum':{const i=Number(integer(4));if(i>=t.variants.length)throw Error('invalid enum tag');return t.variants[i];}
  case 'record':if(t.elided)return value(t.fields[0].type,depth+1,bindings);return Object.fromEntries(t.fields.map(f=>[f.name,value(f.type,depth+1,bindings)]));
  case 'list':{const n=sequence(),xs=[];for(let i=0;i<n;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'option':{const tag=take(1)[0];if(tag===0)return {None:null};if(tag===1)return {Some:value(t.element,depth+1,bindings)};throw Error('invalid Option tag');}
  case 'result':{const tag=take(1)[0];if(tag===0){const child=value(t.ok,depth+1,bindings);return t.sum_key?__sumMake(t.sum_key,true,child):{Ok:child};}if(tag===1){const child=value(t.error,depth+1,bindings);return t.sum_key?__sumMake(t.sum_key,false,child):{Err:child};}throw Error('invalid Result tag');}
  default:throw Error('unsupported snapshot type');
 }}
 const version=integer(8),tables=meta.roots.map(()=>new Map());
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const n=sequence();if(n>Math.floor(left/2))throw Error('snapshot row limit exceeded');let prior;for(let i=0;i<n;i++){const k=value(r.snapshotKey??r.key),v=value(r.snapshotValue??r.value);if(i&&__keyCompare(prior,k,r.key)>=0)throw Error('duplicate or unordered snapshot key');tables[r.index].set(k,v);prior=k;}}
 const count=sequence(),outbox=[];let prior;
 for(let i=0;i<count;i++){const commit=integer(8),position=integer(8),channel=Number(integer(4));if(!meta.events[channel])throw Error('unknown snapshot event channel');const v=value(meta.events[channel].snapshotType??meta.events[channel].type);if(commit===0n||commit>version||(prior&&(commit<prior.commit||(commit===prior.commit&&position<=prior.position))))throw Error('invalid snapshot event sequence');const e={commit,position,channel:meta.events[channel].name,value:v};outbox.push(e);prior=e;}
 if(at!==end)throw Error('trailing snapshot payload');return {version,tables,outbox};
}
// Fixed subscription lifecycle. Root/output edges derive from checked source;
// values and ownership codecs are compiled from each query's declared type.
function __createObservers(prepare){
 const subscriptions=new Map(),byRoot=new Map(),errors=[],directRoots=[],rootSchedules=[];
 let pending=[],spare=[];
 let next=0,held=0,flushing=false;
 function report(s,error,phase){errors.push({query:s?.query??null,error,phase});if(s?.onError)try{s.onError(error);}catch(e){errors.push({query:s.query,error:e,phase:'error-handler'});}}
 function flush(initialPasses=0){
  if(held||flushing||!pending.length)return;
  flushing=true;let passes=initialPasses;
  try{
   while(pending.length&&!held){
    if(++passes>1024){report(null,Error('subscription publication budget exhausted'),'publication');break;}
    const affected=pending;pending=spare;spare=affected;
    for(const s of affected)s.queued=false;
    // Snapshot every affected value before consumers run. Deliveries reside in
    // the stable subscription slots; no per-delivery tuple is allocated.
    for(const s of affected){if(!s.active)continue;s.deliver=false;
     try{if(s.pair){const a=s.pairState?s.pairState.keeps[s.keep0]:s.read0(),b=s.pairState?s.pairState.keeps[s.keep1]:s.read1();if(s.value0!==a||s.value1!==b){s.value0=a;s.value1=b;s.delivery0=a;s.delivery1=b;s.deliver=true;}}else{const value=s.capture(s.read());if(!s.equal(s.value,value)){s.value=value;s.delivery=value;s.deliver=true;}}}
     catch(e){report(s,e,'query');}
    }
    for(const s of affected){if(!s.active||!s.deliver)continue;const value=s.delivery;s.deliver=false;s.delivery=undefined;
     try{if(s.pair)s.callback(s.delivery0,s.delivery1);else s.callback(s.output(value));}catch(e){report(s,e,'listener');}
    }
    affected.length=0;
   }
  }finally{flushing=false;}
 }
 function install(query,q,callback,{immediate=true,onError}={}){
  if(typeof callback!=='function'||onError!==undefined&&typeof onError!=='function')throw TypeError('subscription callback');
  const s={...q,id:next++,query,callback,onError,active:true,queued:false,deliver:false,delivery:undefined};
  if(s.pair){s.value0=s.pairState?s.pairState.keeps[s.keep0]:s.read0();s.value1=s.pairState?s.pairState.keeps[s.keep1]:s.read1();}else{s.value=s.capture(s.read());}subscriptions.set(s.id,s);
  for(const root of s.roots){let ids=byRoot.get(root);if(!ids)byRoot.set(root,ids=[]);ids.push(s);schedule(root,ids);}
  const dispose=()=>{if(!subscriptions.delete(s.id))return;s.active=false;for(const root of s.roots){const ids=byRoot.get(root);ids.splice(ids.indexOf(s),1);schedule(root,ids);if(!ids.length)byRoot.delete(root);}};
  if(immediate)try{if(s.pair)callback(s.value0,s.value1);else callback(s.output(s.value));}catch(e){dispose();throw e;}
  return dispose;
 }
 // Bind the publication implementation when consumers change, instead of
 // rediscovering the one-consumer schedule on each source mutation.
 function schedule(root,ids){
  const s=directRoots[root]=ids.length===1&&ids[0].pairState?ids[0]:null;
  rootSchedules[root]=!ids.length?null:s?()=>publishPair(s):(outputs,epoch)=>{enqueueRoot(root,outputs,epoch);flush();};
 }
 function publishPair(s){
  const a=s.pairState.keeps[s.keep0],b=s.pairState.keeps[s.keep1];
  if(s.value0===a&&s.value1===b)return;
  if(!held&&!flushing&&!pending.length){
   s.value0=a;s.value1=b;flushing=true;
   try{s.callback(a,b);}catch(e){report(s,e,'listener');}finally{flushing=false;}
   flush(1);return;
  }
  if(!s.queued){s.queued=true;pending.push(s);}flush();
 }
 function enqueueRoot(root,outputs,epoch){
  const slots=byRoot.get(root);if(!slots)return;
  for(let i=0;i<slots.length;i++){
   const s=slots[i];if(s.queued)continue;
   if(outputs!==null&&s.outputs?.length){
    let changed=false;for(let j=0;j<s.outputs.length;j++)if(epoch?outputs[s.outputs[j]]===epoch:outputs.has(s.outputs[j])){changed=true;break;}
    if(!changed)continue;
   }
   s.queued=true;pending.push(s);
  }
 }
 return {
  directRoots,rootSchedules,
  get active(){return subscriptions.size!==0;},
  subscribe(query,args,callback,options){return install(query,prepare(query,args),callback,options);},
  subscribeGroup(queries,callback,options){
   if(!Array.isArray(queries)||!queries.length)throw TypeError('subscription group requires queries');
   const qs=queries.map(q=>typeof q==='string'?prepare(q,[]):prepare(q.query,q.args??[]));
   const roots=[...new Set(qs.flatMap(q=>q.roots))];
   // An unknown dependency forces ordinary root invalidation for the group.
   const outputs=qs.every(q=>q.outputs?.length)?[...new Set(qs.flatMap(q=>q.outputs))]:[];
   const scalar=qs.every(q=>q.scalar),direct=qs.every(q=>q.direct);
   return install(queries,{roots,outputs,read:direct?()=>qs.map(q=>q.direct()):()=>qs.map(q=>q.read()),capture:scalar?values=>values:values=>values.map((v,i)=>qs[i].capture(v)),output:scalar?values=>values.slice():values=>values.map((v,i)=>qs[i].output(v)),equal:scalar?(a,b)=>a.every((v,i)=>v===b[i]):(a,b)=>a.every((v,i)=>qs[i].equal(v,b[i]))},callback,options);
  },
  subscribeValues(queries,callback,options){
   if(!Array.isArray(queries)||!queries.length)throw TypeError('subscription group requires queries');
   if(typeof callback!=='function')throw TypeError('subscription callback');
   const qs=queries.map(q=>typeof q==='string'?prepare(q,[]):prepare(q.query,q.args??[]));
   if(qs.length===2&&qs.every(q=>q.scalar)){
    const roots=[...new Set(qs.flatMap(q=>q.roots))],outputs=qs.every(q=>q.outputs?.length)?[...new Set(qs.flatMap(q=>q.outputs))]:[];
    const pairState=qs[0].committed&&qs[1].committed&&qs[0].committed.state===qs[1].committed.state?qs[0].committed.state:null;
    return install(queries,{roots,outputs,pair:true,pairState,keep0:qs[0].committed?.keep,keep1:qs[1].committed?.keep,read0:qs[0].direct||qs[0].read,read1:qs[1].direct||qs[1].read},callback,options);
   }
   return this.subscribeGroup(queries,values=>callback(...values),options);
  },
  commit(roots,outputs=null){
   if(!subscriptions.size)return;
   for(const root of roots)enqueueRoot(root,outputs,false);
   flush();
  },
  // A checked single-root action supplies a reusable array of changed outputs.
  // No root carrier, Set, affected-ID array or Map lookup per delivery is needed.
  commitRoot(root,outputs=null,epoch=0){
   rootSchedules[root]?.(outputs,epoch);
  },
  hold(){held++;return pending.slice();},
  release(){if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  rollback(mark){for(const s of pending)s.queued=false;pending.length=0;for(const s of mark)if(s.active&&!s.queued){s.queued=true;pending.push(s);}if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  batch(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('batch callback must be synchronous');held++;
   try{const value=callback();if(value&&typeof value.then==='function')throw TypeError('state batch callback must be synchronous');return value;}
   finally{held--;flush();}
  },
  flush,takeErrors(){return errors.splice(0);}
 };
}
function __versionWord(v){return typeof v==='number'?BigInt(v):v;}
function __storedCommit(meta,v){return meta.compactCommits&&v<=9007199254740991n?Number(v):v;}
function __nextCommit(v){return typeof v==='number'&&v<9007199254740991?v+1:BigInt(v)+1n;}
// Private column event log. Public records and portable event ordering are unchanged.
// Private event storage. Public events and portable snapshots keep their ordinary
// ordered records. A selected contiguous run omits repeated commit metadata;
// gaps and duplicate commits materialise an exact literal column.
class __EventColumns {
 constructor(channels,compact=false,runs=false){this.channels=channels;this.compact=compact;this.runs=runs;this.commits=runs?null:[];this.base=undefined;this.values=[];this.positions=null;this.channelValues=channels.length===1?null:[];}
 get length(){return this.values.length;}
 set length(n){if(!Number.isSafeInteger(n)||n<0||n>this.length)throw Error('event log truncate');if(this.commits)this.commits.length=n;this.values.length=n;if(this.positions)this.positions.length=n;if(this.channelValues)this.channelValues.length=n;if(n===0){this.base=undefined;if(this.runs)this.commits=null;}}
 append(commit,position,channel,value){
  const i=this.values.length;
  if(this.commits)this.commits.push(commit);
  else if(!i)this.base=commit;
  else{
   const small=typeof this.base==='number'&&typeof commit==='number';
   const expected=small?this.base+i:__versionWord(this.base)+BigInt(i);
   if(expected!==commit){
    this.commits=[];
    for(let j=0;j<i;j++){const word=__versionWord(this.base)+BigInt(j);this.commits.push(this.compact&&word<=9007199254740991n?Number(word):word);}
    this.commits.push(commit);
   }
  }
  this.values.push(value);if(this.channelValues)this.channelValues.push(channel);if(position!==0n&&!this.positions)this.positions=new Array(i).fill(0n);if(this.positions)this.positions.push(position);
 }
 push(e){this.append(this.compact&&e.commit<=9007199254740991n?Number(e.commit):e.commit,e.position,e.channel,e.value);return this.length;}
 at(i){if(i<0)i+=this.length;if(i<0||i>=this.length)return undefined;return {commit:this.commits?__versionWord(this.commits[i]):__versionWord(this.base)+BigInt(i),position:this.positions?this.positions[i]:0n,channel:this.channelValues?this.channelValues[i]:this.channels[0],value:this.values[i]};}
 *[Symbol.iterator](){for(let i=0;i<this.length;i++)yield this.at(i);}
 map(f){const out=new Array(this.length);for(let i=0;i<this.length;i++)out[i]=f(this.at(i),i);return out;}
 filter(f){const out=new __EventColumns(this.channels,this.compact,this.runs);for(let i=0;i<this.length;i++){const e=this.at(i);if(f(e,i))out.push(e);}return out;}
}
function __eventLog(meta,events=[]){
 if(!meta.eventColumns)return meta.compactCommits?events.map(e=>({...e,commit:__storedCommit(meta,e.commit)})):events;
 const log=new __EventColumns(meta.events.map(e=>e.name),meta.compactCommits,meta.eventRuns);for(const e of events)log.append(__storedCommit(meta,e.commit),e.position,e.channel,e.value);return log;
}
// CALLER CONTRACT: arguments must match declared types; malformed data may throw or corrupt state.
// Fixed state primitives used by emitted action bodies, without an AST evaluator.
class __Abort {constructor(value){this.value=value;}}
function __preflightError(message){throw Error(message);}
function __try(value){if(Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value.Ok;}
function __nested(value,change){if(change && Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value;}
function __equal(a,b){if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object')return false;const ak=Object.keys(a),bk=Object.keys(b);return ak.length===bk.length&&ak.every(k=>Object.hasOwn(b,k)&&__equal(a[k],b[k]));}
function __checked(op,a,b,bits){const x=BigInt(a),y=BigInt(b),n=op==='checked_add'?x+y:op==='checked_sub'?x-y:x*y;const min=bits===-32?-2147483648n:0n,max=bits===-32?2147483648n:1n<<BigInt(bits);return n<min||n>=max?{Err:'ArithmeticError.Overflow'}:{Ok:Math.abs(bits)===32?Number(n):n};}
function __okOr(value,error){return Object.hasOwn(value,'Some')?{Ok:value.Some}:{Err:error};}
function __mapValue(value,kind,method,fn){
 if(kind==='list')return value[method](fn);
 if(kind==='option')return Object.hasOwn(value,'Some')?{Some:fn(value.Some)}:{None:null};
 const tag=method==='map_err'?'Err':'Ok';return Object.hasOwn(value,tag)?{[tag]:fn(value[tag])}:value;
}
const __encoder=new TextEncoder();
function __tick(ctx){if(--ctx.fuel<0)throw Error('Ink state execution budget exhausted');}
function __keyCompare(a,b,type){
 if(type.kind==='string'){let i=0,j=0;while(i<a.length&&j<b.length){const x=a.codePointAt(i),y=b.codePointAt(j);if(x!==y)return x-y;i+=x>65535?2:1;j+=y>65535?2:1;}return (i<a.length?1:0)-(j<b.length?1:0);}
 return a<b?-1:a>b?1:0;
}
// A table's ordered key view is reused until membership changes. Values are
// fetched at traversal time, so replacement never leaves stale row payloads.
const __tableOrder=new WeakMap();
function __keyPosition(keys,key,type){let low=0,high=keys.length;while(low<high){const middle=(low+high)>>>1;if(__keyCompare(keys[middle],key,type)<0)low=middle+1;else high=middle;}return low;}
function __tableMembership(rt,index,key,present){
 const view=__tableOrder.get(rt.tables[index]);if(!view)return;
 const at=__keyPosition(view.keys,key,rt.meta.roots[index].key);
 if((at<view.keys.length&&view.keys[at]===key)===present)view.pending.delete(key);
 else view.pending.set(key,present);
}
function __orderedKeys(rt,index){
 const table=rt.tables[index],type=rt.meta.roots[index].key;let view=__tableOrder.get(table);
 if(!view){view={keys:[...table.keys()].sort((a,b)=>__keyCompare(a,b,type)),pending:new Map()};__tableOrder.set(table,view);}
 if(view.pending.size){
  const changes=[...view.pending.keys()].sort((a,b)=>__keyCompare(a,b,type)),merged=[];let i=0,j=0;
  while(i<view.keys.length||j<changes.length){
   if(j===changes.length||(i<view.keys.length&&__keyCompare(view.keys[i],changes[j],type)<0))merged.push(view.keys[i++]);
   else{const key=changes[j++];if(i<view.keys.length&&view.keys[i]===key)i++;if(view.pending.get(key))merged.push(key);}
  }
  view.keys=merged;view.pending.clear();
 }
 const keys=view.keys;
 const cell=rt.cell;
 if(cell&&cell.index===index&&table.has(cell.key)!==(cell.next!==undefined)){
  if(cell.next===undefined)return keys.filter(k=>k!==cell.key);
  const at=__keyPosition(keys,cell.key,type);return [...keys.slice(0,at),cell.key,...keys.slice(at)];
 }
 return keys;
}
function __cellGet(rt,index,key){const cell=rt.cell;return cell&&cell.index===index&&cell.key===key?cell.next:rt.tables[index].get(key);}
function __readTable(rt,index){const cell=rt.cell;if(!cell||cell.index!==index)return rt.tables[index];const table=new Map(rt.tables[index]);if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);return table;}
// The first before-image of each cell suffices for whole-transaction rollback.
function __remember(rt,index,key,present,value){if(rt.cellMode)return;if(!rt.seen[index].has(key)){rt.seen[index].add(key);rt.undo.push([index,key,present,value]);}}
// Immutable keeps retain private values. Public results remain owned copies.
// Reverse edges come from checked source effects.
// Before-images preserve cached values across failed actions; host rollback and
// restore discard caches rather than serializing them into logical snapshots.
function __invalidateKeeps(rt,index){
 if(rt.observers?.active)rt.changedRoots.add(index);
 if(!rt.keeps||rt.cellMode)return;
 for(const keep of rt.meta.keepInvalidations[index]){
  if(!rt.keepDirty[keep]){rt.keepDirty[keep]=1;rt.keepUndoIndices[rt.keepUndoCount++]=keep;rt.keepBefore[keep]=rt.keeps[keep];}
  rt.keeps[keep]=undefined;
 }
}
function __restoreKeeps(rt){for(let i=rt.keepUndoCount-1;i>=0;i--){const keep=rt.keepUndoIndices[i];rt.keeps[keep]=rt.keepBefore[keep];}__refreshActiveViews(rt);}
function __clearKeepJournal(rt){for(let i=0;i<rt.keepUndoCount;i++){const keep=rt.keepUndoIndices[i];rt.keepDirty[keep]=0;rt.keepBefore[keep]=undefined;}rt.keepUndoCount=0;}
function __rebuildViews(rt){
 rt.activeViewRoots=new Uint8Array(rt.meta.roots.length);
 for(const view of rt.views){rt.keeps[view.keep]=undefined;if(!rt.meta.lazyMaintenance)__viewBase(rt,view);}
}
function __refreshActiveViews(rt){rt.activeViewRoots.fill(0);for(const view of rt.views)if(rt.keeps[view.keep]!==undefined)rt.activeViewRoots[view.root]=1;}
function __viewBase(rt,view){
 if(rt.keeps[view.keep]===undefined){let value=view.zero;for(const [key,row]of rt.tables[view.root])value=view.combine(value,view.contribution(key,row));rt.keeps[view.keep]=value;rt.activeViewRoots[view.root]=1;}
 return rt.keeps[view.keep];
}
function __viewValue(view,value,key,oldValue,newValue){
 if(oldValue===undefined)return view.insert?view.insert(value,key,newValue):view.combine(value,view.contribution(key,newValue));
 if(newValue===undefined)return view.remove?view.remove(value,key,oldValue):view.combine(value,view.inverse(view.contribution(key,oldValue)));
 return view.replace?view.replace(value,key,oldValue,newValue):view.combine(view.combine(value,view.inverse(view.contribution(key,oldValue))),view.contribution(key,newValue));
}
function __updateViews(rt,index,key,oldValue,newValue){
 if(!rt.activeViewRoots[index])return null;
 const updates=rt.viewNext;
 for(const view of rt.viewsByRoot[index])updates[view.keep]=rt.keeps[view.keep]===undefined?undefined:__viewValue(view,rt.keeps[view.keep],key,oldValue,newValue);
 return updates;
}
function __installViews(rt,updates,index){if(updates)for(const view of rt.viewsByRoot[index])rt.keeps[view.keep]=updates[view.keep];}
function __pendingView(rt,view){
 const keep=view.keep;
 if(rt.pendingValues[keep]===undefined){
  const cell=rt.cell;
  rt.pendingValues[keep]=__viewValue(view,__viewBase(rt,view),cell.key,cell.prior,cell.next);
  rt.pendingIndices.push(keep);
 }
 return rt.pendingValues[keep];
}
function __prepareCell(rt){if(rt.cell&&rt.activeViewRoots[rt.cell.index]){const prepare=rt.views.prepareRoots?.[rt.cell.index];if(prepare)prepare(rt,rt.cell);else for(const view of rt.viewsByRoot[rt.cell.index])if(rt.keeps[view.keep]!==undefined)__pendingView(rt,view);}}
function __invalidateSnapshotRow(rt,index,key){rt.snapshotRows?.[index].delete(key);}
function __writeCell(rt,index,key,next,prior){
 if(rt.cellMode){if(rt.cell)throw Error('checked single-cell bound exceeded');rt.cell={index,key,next,prior};}
 else{const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);if(rt.changeTracking)__recordChange(rt,index,key,prior,next);if((prior!==undefined)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);if(next===undefined)table.delete(key);else table.set(key,next);}
}
function __commitCell(rt){
 const cell=rt.cell;if(!cell)return;
 const table=rt.tables[cell.index];__invalidateSnapshotRow(rt,cell.index,cell.key);
 if(rt.changeTracking)__recordChange(rt,cell.index,cell.key,cell.prior,cell.next);
 if((cell.prior!==undefined)!==(cell.next!==undefined))__tableMembership(rt,cell.index,cell.key,cell.next!==undefined);
 if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);
 for(const keep of rt.meta.keepInvalidations[cell.index])rt.keeps[keep]=rt.pendingValues[keep];
 rt.cell=null;
}
// Preflight scratch has no logical state or rollback obligations. Definitions
// are the same admitted group operations used by ordinary cell maintenance.
function __prepareDirect(rt,index,key,prior,next){
 const prepare=rt.views.directRoots?.[index];
 if(prepare)prepare(rt,key,prior,next);
 else for(const view of rt.viewsByRoot[index])rt.viewNext[view.keep]=__viewValue(view,rt.keeps[view.keep],key,prior,next);
}
function __storeDirect(rt,index,key,prior,next,slot){
 const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);
 if((prior!==undefined)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);
 if(rt.changeTracking)__recordChange(rt,index,key,prior,next);
 if(slot===undefined){if(next===undefined)table.delete(key);else table.set(key,next);}
 else{
  // The checked preflight lookup retains the dense slot until this commit.
  // No callback or source write can intervene; sparse keys retain exact identity.
  if(slot<0){if(next===undefined)table.sparse.delete(key);else table.sparse.set(key,next);}else table.dense[slot]=next;
  if(prior===undefined&&next!==undefined)table.members.add(key);else if(prior!==undefined&&next===undefined)table.members.delete(key);
 }
}
function __commitDirect(rt,index,key,prior,next,slot){
 __storeDirect(rt,index,key,prior,next,slot);
 const publishOutputs=rt.meta.outputPublication&&!rt.observers.directRoots[index]&&rt.observers.active;
 if(publishOutputs&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}

 for(const keep of rt.meta.keepInvalidations[index]){
  const value=rt.viewByKeep[keep]?rt.viewNext[keep]:undefined;
  if(publishOutputs)rt.changedOutputs[keep]=rt.keeps[keep]!==value?rt.changedOutputEpoch:0;
  rt.keeps[keep]=value;
 }
}
function __emit(rt,channel,value){
 if(rt.eventCount++===0){rt.eventChannel=channel;rt.eventValue=value;}
 else rt.staged.push([channel,value]);
}
// Checked prefix capacities are at most 2^20. Number conversion is exact
// inside that prefix; rounding a wide word cannot move it into the prefix.
// Wide keys retain their original full-width value in the sparse fallback.
class __DenseTable{
 constructor(capacity){this.limit=capacity;this.dense=[];for(let i=0;i<capacity;i++)this.dense.push(undefined);this.sparse=new Map();this.members=new Set();}
 clear(){this.dense.fill(undefined);this.sparse.clear();this.members.clear();__tableOrder.delete(this);return this;}
 slot(key){const i=Number(key);return Number.isInteger(i)&&i>=0&&i<this.limit?i:-1;}
 get size(){return this.members.size;}
 get(key){const i=this.slot(key);return i<0?this.sparse.get(key):this.dense[i];}
 has(key){return this.get(key)!==undefined;}
 set(key,value){const i=this.slot(key),present=i<0?this.sparse.has(key):this.dense[i]!==undefined;if(i<0)this.sparse.set(key,value);else this.dense[i]=value;if(!present)this.members.add(key);return this;}
 delete(key){const i=this.slot(key);if(i<0)this.sparse.delete(key);else this.dense[i]=undefined;return this.members.delete(key);}
 keys(){return this.members.keys();}
 *values(){for(const key of this.members)yield this.get(key);}
 *entries(){for(const key of this.members)yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
class __ColumnTable {
 constructor(root){
  this.limit=root.columnPrefix.capacity;this.keyBig=root.key.kind==='u64';
  this.fields=root.value.fields;this.exactNumbers=root.columnPrefix.exactNumbers;
  this.present=new Uint8Array(this.limit);this.count=0;this.sparse=new Map();
  this.lanes=this.fields.map(f=>f.type.kind==='u64'?(this.exactNumbers?new Float64Array(this.limit):new BigUint64Array(this.limit)):f.type.kind==='i32'?new Int32Array(this.limit):f.type.kind==='bool'?new Uint8Array(this.limit):new Uint32Array(this.limit));
  this.wide=this.fields.map(f=>f.type.kind==='u64'&&this.exactNumbers?new Map():null);
 }
 slot(key){const i=Number(key);return Number.isInteger(i)&&i>=0&&i<this.limit?i:-1;}
 get size(){return this.count+this.sparse.size;}
 has(key){const i=this.slot(key);return i<0?this.sparse.has(key):this.present[i]!==0;}
 get(key){const i=this.slot(key);if(i<0)return this.sparse.get(key);if(!this.present[i])return undefined;const row=Object.create(null);for(let j=0;j<this.fields.length;j++){const f=this.fields[j],v=this.lanes[j][i];row[f.name]=f.type.kind==='bool'?v!==0:f.type.kind==='u64'&&this.exactNumbers?(this.wide[j].get(i)??BigInt(v)):v;}return row;}
 set(key,row){const i=this.slot(key);if(i<0){this.sparse.set(key,row);return this;}for(let j=0;j<this.fields.length;j++){const f=this.fields[j],v=row[f.name];if(f.type.kind==='u64'&&this.exactNumbers){if(v<=9007199254740991n){this.lanes[j][i]=Number(v);this.wide[j].delete(i);}else{this.lanes[j][i]=0;this.wide[j].set(i,v);}}else this.lanes[j][i]=f.type.kind==='bool'?Number(v):v;}if(!this.present[i]){this.present[i]=1;this.count++;}return this;}
 delete(key){const i=this.slot(key);if(i<0)return this.sparse.delete(key);if(!this.present[i])return false;this.present[i]=0;this.count--;for(const wide of this.wide)wide?.delete(i);return true;}
 *keys(){for(let i=0;i<this.limit;i++)if(this.present[i])yield this.keyBig?BigInt(i):i;yield* this.sparse.keys();}
 *values(){for(const key of this.keys())yield this.get(key);}
 *entries(){for(const key of this.keys())yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
function __newTables(meta,prefixes,old,spares){return meta.roots.map((root,i)=>{const prior=spares?.[i];const t=root.columnPrefix?new __ColumnTable(root):prefixes[i]?(prior instanceof __DenseTable&&prior.limit===prefixes[i]?prior.clear():new __DenseTable(prefixes[i])):new Map();if(old)for(const [k,v]of old[i])t.set(k,v);return t;});}
// Only inactive containers are reused. Consume the spare before preparation so
// a failed invariant/rebuild cannot expose its partially reconstructed contents.
// Rows remain immutable; the current logical state changes only at installation.
function __restoreTables(rt,prefixes,old){const spares=rt.restoreSpares;rt.restoreSpares=null;return __newTables(rt.meta,prefixes,old,spares);}
function __cachedKeep(ctx,rt,index,compute){
 if(rt.cell&&rt.meta.keepInvalidations[rt.cell.index].includes(index)){
  const view=rt.viewByKeep[index];
  if(view)return __pendingView(rt,view);
  if(rt.pendingValues[index]===undefined){rt.pendingValues[index]=compute(ctx,rt);rt.pendingIndices.push(index);}
  return rt.pendingValues[index];
 }
 const prior=rt.keeps[index];if(prior!==undefined)return prior;
 const view=rt.viewByKeep[index];if(view)return __viewBase(rt,view);
 const value=compute(ctx,rt);rt.keeps[index]=value;return value;
}
function __tableContains(rt,index,key){return __cellGet(rt,index,key)!==undefined;}
function __tableGet(rt,index,key){const value=__cellGet(rt,index,key);return value===undefined?{None:null}:{Some:value};}
function __tablePut(rt,index,key,next,mode=0){
 const prior=rt.tables[index].get(key),present=prior!==undefined;
 if(mode===1&&present)throw Error('insert key already present');
 if(mode===2&&!present)throw Error('replace key absent');
 if(present&&__stateRootEquals[index](prior,next))return null;
 const updates=rt.cellMode?null:__updateViews(rt,index,key,prior,next);
 __invalidateKeeps(rt,index);__remember(rt,index,key,present,prior);
 __writeCell(rt,index,key,next,prior);__installViews(rt,updates,index);return null;
}
function __tableRemove(rt,index,key){
 const value=rt.tables[index].get(key);
 if(value===undefined)return {None:null};
 const updates=rt.cellMode?null:__updateViews(rt,index,key,value,undefined);
 __invalidateKeeps(rt,index);__remember(rt,index,key,true,value);
 __writeCell(rt,index,key,undefined,value);__installViews(rt,updates,index);return {Some:value};
}
function __table(rt,index,method,args){
 const key=args[0];
 if(method==='get')return __tableGet(rt,index,key);
 if(method==='contains')return __tableContains(rt,index,key);
 const table=rt.tables[index];
 if(method==='values'||method==='keys'){const keys=__orderedKeys(rt,index);return method==='keys'?keys.slice():keys.map(k=>__cellGet(rt,index,k));}
 if(method==='intersect_table'){const current=__readTable(rt,index),other=__readTable(rt,args[0]),small=current.size<=other.size?current:other,large=small===current?other:current;const result=[];for(const k of small.keys())if(large.has(k))result.push(k);return result.sort((a,b)=>__keyCompare(a,b,rt.meta.roots[index].key));}
 if(method==='intersect_keys'){const requested=args[0],size=rt.tables[index].size;
  // Fewer requested keys than rows: look each one up instead of scanning.
  if(requested.length<size){const type=rt.meta.roots[index].key;return [...new Set(requested)].filter(k=>__cellGet(rt,index,k)!==undefined).sort((a,b)=>__keyCompare(a,b,type));}
  const selected=new Set(requested);return __orderedKeys(rt,index).filter(k=>selected.has(k));}
 if(method==='put_many'){const keys=args[0],values=args[1];if(keys.length!==values.length)return {Err:'table bulk length mismatch'};for(let i=0;i<keys.length;i++)__table(rt,index,'put',[keys[i],values[i]]);return {Ok:null};}
 if(method==='remove_many'){for(const k of args[0])__table(rt,index,'remove',[k]);return null;}
 if(method==='remove')return __tableRemove(rt,index,key);
 return __tablePut(rt,index,key,args[1],method==='insert'?1:method==='replace'?2:0);
}

function __rollback(rt,mark){for(let i=rt.undo.length-1;i>=mark;i--){const [index,key,present,value]=rt.undo[i];const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);if(table.has(key)!==present)__tableMembership(rt,index,key,present);if(present)table.set(key,value);else table.delete(key);}rt.undo.length=mark;}
function __recordChange(rt,index,key,prior,next){rt.changeLog.push([index,key,prior,next]);}
function __fixedTableBytes(root,table){
 const writer=__snapshotWriter(__snapshotLimits());
 const rows=[...table.entries()].sort((a,b)=>__keyCompare(a[0],b[0],root.key));
 writer.integer(rows.length,8);
 for(const [key,value]of rows){writer.value(key,root.snapshotKey??root.key);writer.value(value,root.snapshotValue??root.value);}
 return writer.finish();
}
function __createState(meta,implementations,captures=null,views=[],prefixes=[]){
 const rt={meta,tables:__newTables(meta,prefixes),version:meta.compactCommits?0:0n,outbox:__eventLog(meta),staged:[],busy:false,undo:[],seen:meta.roots.map(()=>new Set()),host:null,keeps:new Array(meta.keeps.length),keepDirty:meta.keeps.length?new Uint8Array(meta.keeps.length):null,keepUndoIndices:meta.keeps.length?new Uint32Array(meta.keeps.length):null,keepUndoCount:0};
 const fixed=typeof __stateFrozenFactories==='undefined'?[]:__stateFrozenFactories;
 const fixedBytes=[];
 for(let i=0;i<fixed.length;i++)if(fixed[i]){for(const [key,value]of fixed[i]())rt.tables[i].set(key,value);fixedBytes[i]=__fixedTableBytes(meta.roots[i],rt.tables[i]);}
 function checkFixed(tables){for(let i=0;i<fixedBytes.length;i++)if(fixedBytes[i]){const bytes=__fixedTableBytes(meta.roots[i],tables[i]);if(bytes.length!==fixedBytes[i].length||!bytes.every((v,n)=>v===fixedBytes[i][n]))throw Error('snapshot changes frozen state: '+meta.roots[i].name);}}
 rt.views=views;rt.viewsByRoot=meta.roots.map((_,root)=>views.filter(v=>v.root===root));__rebuildViews(rt);
 rt.viewByKeep=new Array(meta.keeps.length);for(const view of views)rt.viewByKeep[view.keep]=view;
 rt.pendingIndices=[];rt.pendingValues=new Array(meta.keeps.length);
 rt.eventCount=0;rt.eventChannel=null;rt.eventValue=null;
 rt.viewNext=new Array(meta.keeps.length);rt.cell=null;rt.cellMode=false;rt.ctx={fuel:100000000};
 rt.keepBefore=meta.keeps.length?new Array(meta.keeps.length):null;
 rt.changedRoots=new Set();rt.changedOutputs=new Array(meta.keeps.length).fill(0);rt.changedOutputEpoch=0;
 rt.snapshotRows=meta.snapshotRows?meta.roots.map(()=>new Map()):null;
 rt.restoreSpares=null;rt.changeTracking=false;rt.changeLog=[];rt.changeEpoch=0;rt.changeTokens=new Map();
 const actionMap=new Map(meta.actions.map(a=>[a.name,{...a,inputs:captures?captures[a.index]:a.params.map(p=>__stateCapture(p.type)),output:__stateResult(a.result)}]));
 const eventOutput=new Map(meta.events.map(e=>[e.name,__stateResult(e.type)]));
 rt.eventOutput=eventOutput;
 const prepared=new WeakMap();
 const observers=rt.observers=__createObservers((name,args)=>{
  const a=actionMap.get(name);if(!a||a.change)throw Error('subscription requires a readonly query');
  const captured=a.inputs.map((convert,i)=>convert(args[i]));
  const publicArgs=captured.map((v,i)=>__stateResult(a.params[i].type)(v));
  const scalar=['u64','u32','i32','bool','string','unit','enum','id'].includes(a.result.kind);
  return {scalar,committed:scalar&&a.directKeep!==null&&a.directKeep!==undefined?{state:rt,keep:a.directKeep}:null,direct:scalar&&a.directKeep!==null&&a.directKeep!==undefined?()=>rt.keeps[a.directKeep]:null,roots:a.roots,outputs:rt.meta.outputPublication&&a.directKeep!==null&&a.directKeep!==undefined?[a.directKeep]:[],read:!a.precondition&&a.params.length===0?readZero(a,true):()=>run(a,publicArgs,null,null,true),capture:scalar?v=>v:__stateCapture(a.result),output:scalar?v=>v:a.output,equal:__stateQueryEquals[a.index]};
 });
 function invoke(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);return run(a,args);}
 function readZero(a,resultOnly){
  const implementation=implementations[a.index],output=a.output,fresh=a.freshResult;
  if(resultOnly&&fresh&&__stateDirectReadFactories[a.index])return __stateDirectReadFactories[a.index](rt);
  if(a.directKeep!==null&&a.directKeep!==undefined)return ()=>{
   if(rt.busy)throw Error('state operation already in progress');
   const value=rt.keeps[a.directKeep],result=fresh?value:output(value);
   return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};
  };
  return ()=>{
   if(rt.busy)throw Error('state operation already in progress');rt.busy=true;rt.ctx.fuel=100000000;
   try{const value=implementation(rt.ctx,rt),result=fresh?value:output(value);return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};}
   finally{rt.busy=false;}
  };
 }
 function read(a,args,inputs,output,resultOnly,owned=false){
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  rt.busy=true;
  try{const value=implementations[a.index](ctx,rt,...captured),result=a.freshResult?value:(output||a.output)(value);return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};}
  finally{rt.busy=false;}
 }
 function begin(a){
  if(rt.busy)throw Error('state operation already in progress');
  rt.ctx.fuel=100000000;
  rt.actionMark=rt.undo.length;rt.actionVersion=rt.version;rt.actionOutbox=rt.outbox;rt.actionOutboxLength=rt.outbox.length;rt.actionChangeMark=rt.changeLog.length;
  rt.busy=true;rt.cellMode=a.singleCell&&!rt.host;rt.staged.length=0;rt.eventCount=0;rt.changedRoots.clear();rt.actionSuccessful=false;
 }
 function complete(a,value,output,resultOnly){
  const result=a.freshResult?value:(output||a.output)(value);
  const version=rt.actionVersion;
  if(a.fallible && (a.flatFailure?value.tag!==0:Object.hasOwn(value,'Err'))){rt.changeLog.length=rt.actionChangeMark;__rollback(rt,rt.actionMark);__restoreKeeps(rt);if(rt.host?.strict)rt.host.failure=Object.assign(Error('transaction action failed'),{action:a.name,result});return resultOnly?result:{result,committed:false,version:__versionWord(version),events:[]};}
  if(version===18446744073709551615n)throw Error('commit sequence exhausted');
  const next=rt.meta.compactCommits?__nextCommit(version):version+1n;
  const publicNext=resultOnly?null:__versionWord(next);
  __prepareCell(rt);
  const events=resultOnly?null:new Array(rt.eventCount);
  if(rt.eventCount){
   const channel=rt.eventChannel,value=rt.eventValue;
   rt.outbox.push({commit:next,position:0n,channel,value});
   if(events)events[0]={commit:publicNext,position:0n,channel,value:eventOutput.get(channel)(value)};
   for(let i=0;i<rt.staged.length;i++){
    const [channel,value]=rt.staged[i],position=BigInt(i+1);
    rt.outbox.push({commit:next,position,channel,value});
    if(events)events[i+1]={commit:publicNext,position,channel,value:eventOutput.get(channel)(value)};
   }
  }
  __commitCell(rt);rt.version=next;rt.actionSuccessful=true;
  return resultOnly?result:{result,committed:true,version:publicNext,events};
 }
 function abort(e){
  rt.changeLog.length=rt.actionChangeMark;__rollback(rt,rt.actionMark);__restoreKeeps(rt);rt.version=rt.actionVersion;rt.outbox=rt.actionOutbox;rt.outbox.length=rt.actionOutboxLength;if(rt.host?.strict)rt.host.failure=e;throw e;
 }
 function end(){
  const successful=rt.actionSuccessful,single=rt.cellMode;
  rt.cell=null;rt.cellMode=false;rt.staged.length=0;rt.eventCount=0;rt.eventChannel=null;rt.eventValue=null;
  for(const keep of rt.pendingIndices)rt.pendingValues[keep]=undefined;rt.pendingIndices.length=0;
  if(!single){__clearKeepJournal(rt);for(const seen of rt.seen)seen.clear();if(!rt.host)rt.undo.length=0;}
  rt.actionOutbox=null;rt.busy=false;
  if(successful)observers.commit(rt.changedRoots);
 }
 function run(a,args,inputs=null,output=null,resultOnly=false,owned=false){
  if(a.kernels&&!rt.host){
   if(rt.busy)throw Error('state operation already in progress');
   const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
   return a.kernels[resultOnly?1:0](...captured);
  }
  if(!a.change)return read(a,args,inputs,output,resultOnly,owned);
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  begin(a);
  try{return complete(a,implementations[a.index](ctx,rt,...captured),output,resultOnly);}
  catch(e){return abort(e);}
  finally{end();}
 }

 for(const a of actionMap.values())if(__statePreflightFactories[a.index]){
  // run() supplies module-owned captured values; bound native entries still capture composites.
  a.kernels=[false,true].map(only=>__statePreflightFactories[a.index](run,a,a.inputs,a.output,only,rt,begin,complete,abort,end,true));
 }
 return Object.freeze({
  subscribeValues(queries,callback,options){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribeValues(queries,callback,options);},
  subscribeGroup(queries,callback,options){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribeGroup(queries,callback,options);},
  subscribe(...args){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribe(...args);},
  batch:observers.batch,flushSubscriptions:observers.flush,takeSubscriptionErrors:observers.takeErrors,
  transaction(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('transaction callback must be synchronous');this.beginTransaction();rt.host.strict=true;
   try{const value=callback(this);if(value&&typeof value.then==='function')throw TypeError('state transaction callback must be synchronous');this.commitTransaction();return value;}catch(e){this.rollbackTransaction();throw e;}
  },
  invoke,invoke_json:invoke,
  prepare(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);const captured=a.inputs.map((convert,i)=>convert(args[i])),token=Object.freeze({});prepared.set(token,{action:a,args:captured});return token;},
  invokePrepared(token){const packet=prepared.get(token);if(!packet)throw Error('invalid prepared state call');return run(packet.action,packet.args,null,null,false,true);},
  // A prebound typed entrypoint: scalar arguments obey the native caller contract.
  // Composite arguments still capture owned input; events remain in the outbox.
  bind(name,{resultOnly=false}={}){
   const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);
   const inputs=a.params.map((p,i)=>['u32','i32','u64','bool','unit','string','f32','f64','id','enum','int'].includes(p.type.kind)?__representation(p.type,false):a.inputs[i]);
   if(!a.change&&!a.precondition&&inputs.length===0)return readZero(a,resultOnly);
   return (__statePreflightFactories[a.index]||__stateBoundFactories[a.index])(run,a,inputs,a.output,resultOnly,rt,begin,complete,abort,end);
  },
  beginTransaction(){if(rt.busy||rt.host||rt.undo.length)throw Error('transaction already in progress');rt.host={version:rt.version,outbox:rt.outbox,length:rt.outbox.length,keeps:rt.keeps.slice(),changeMark:rt.changeLog.length,notificationMark:observers.hold()};return true;},
  commitTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');if(rt.host.failure)throw rt.host.failure;rt.host=null;rt.undo.length=0;observers.release();},
  rollbackTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');__rollback(rt,0);rt.version=rt.host.version;rt.outbox=rt.host.outbox;rt.outbox.length=rt.host.length;rt.keeps=rt.host.keeps;__refreshActiveViews(rt);rt.changeLog.length=rt.host.changeMark;rt.changeEpoch++;const mark=rt.host.notificationMark;rt.host=null;observers.rollback(mark);},
  changeToken(){
   if(rt.busy||rt.host)throw Error('change token requires transaction boundary');
   const token=Object.freeze({});rt.changeTracking=true;rt.changeTokens.set(token,{epoch:rt.changeEpoch,index:rt.changeLog.length,version:__versionWord(rt.version)});return token;
  },
  releaseChangeToken(token){rt.changeTokens.delete(token);if(!rt.changeTokens.size){rt.changeTracking=false;rt.changeLog.length=0;}},
  changesSince(token){
   if(rt.busy||rt.host)throw Error('changes require transaction boundary');
   const mark=rt.changeTokens.get(token);if(!mark||mark.epoch!==rt.changeEpoch)throw Error('invalid change token lineage');
   const roots=new Map();
   for(let i=mark.index;i<rt.changeLog.length;i++){
    const [root,key,before,after]=rt.changeLog[i];let cells=roots.get(root);if(!cells)roots.set(root,cells=new Map());
    const prior=cells.get(key);if(prior)prior.after=after;else cells.set(key,{before,after});
   }
   const changes=[];
   const codecs=rt.changeOutputs??=meta.roots.map(schema=>({key:__stateResult(schema.key),row:__stateResult(schema.value)}));
   for(const [root,cells]of roots){const schema=meta.roots[root],keyOut=codecs[root].key,rowOut=codecs[root].row;
    for(const [key,{before,after}]of cells){if(before===undefined&&after===undefined||before!==undefined&&after!==undefined&&__stateRootEquals[root](before,after))continue;
     changes.push({table:schema.name,key:keyOut(key),before:before===undefined?{None:null}:{Some:rowOut(before)},after:after===undefined?{None:null}:{Some:rowOut(after)}});
    }
   }
   return {from:mark.version,to:__versionWord(rt.version),changes};
  },
  get version(){return __versionWord(rt.version);},
  get outbox(){return rt.outbox.map(e=>({...e,commit:__versionWord(e.commit),value:eventOutput.get(e.channel)(e.value)}));},
  acknowledgeThrough(commit,position){if(rt.busy)throw Error('state operation already in progress');commit=__stateWord(commit);position=__stateWord(position);const last=rt.outbox.at(-1);if(!last)return;const lastCommit=__versionWord(last.commit);if(lastCommit<commit||(lastCommit===commit&&last.position<=position)){if(rt.host)rt.outbox=__eventLog(meta);else rt.outbox.length=0;return;}rt.outbox=rt.outbox.filter(e=>{const c=__versionWord(e.commit);return c>commit||(c===commit&&e.position>position);});},
  async invokeAsync(name,args){
   if(typeof __parallelInvokeAsync!=='function')return invoke(name,args);
   if(rt.busy||rt.host)throw Error('parallel state call requires transaction boundary');const captured=structuredClone(args);rt.busy=true;observers.hold();let completed=false;
   try{const snapshot=await __snapshotEncode(meta,rt);const reply=await __parallelInvokeAsync(name,captured,snapshot);const s=await __snapshotDecode(meta,reply.snapshot);checkFixed(s.tables);const candidate={...rt,tables:__restoreTables(rt,prefixes,s.tables),keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);const previousTables=rt.tables;rt.tables=candidate.tables;rt.restoreSpares=previousTables.map(table=>table instanceof __DenseTable?table:null);rt.version=__storedCommit(meta,s.version);rt.outbox=__eventLog(meta,s.outbox);rt.keeps=candidate.keeps;rt.activeViewRoots=candidate.activeViewRoots;if(rt.snapshotRows)rt.snapshotRows=meta.roots.map(()=>new Map());rt.changeEpoch++;rt.changeLog.length=0;completed=true;return reply.value;}finally{rt.busy=false;if(completed)observers.commit(meta.roots.map((_,i)=>i));observers.release();}
  },
  checkpoint(limits){if(rt.busy)throw Error('checkpoint requires transaction boundary');return __snapshotEncode(meta,rt,limits);},
  async restore(bytes,limits){if(rt.host)throw Error('restore during transaction');if(rt.busy)throw Error('restore requires transaction boundary');rt.busy=true;rt.ctx.fuel=100000000;observers.hold();let restored=false;try{const s=await __snapshotDecode(meta,bytes,limits);checkFixed(s.tables);const candidate={...rt,tables:__restoreTables(rt,prefixes,s.tables),version:__storedCommit(meta,s.version),outbox:s.outbox,keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);for(const name of meta.invariantChecks||[]){const a=actionMap.get(name);if(implementations[a.index](rt.ctx,candidate)!==true)throw Error('snapshot violates state invariant');}const previousTables=rt.tables;rt.tables=candidate.tables;rt.restoreSpares=previousTables.map(table=>table instanceof __DenseTable?table:null);rt.version=__storedCommit(meta,s.version);rt.outbox=__eventLog(meta,s.outbox);rt.keeps=candidate.keeps;rt.activeViewRoots=candidate.activeViewRoots;if(rt.snapshotRows)rt.snapshotRows=meta.roots.map(()=>new Map());rt.changeEpoch++;rt.changeLog.length=0;restored=true;}finally{rt.busy=false;if(restored)observers.commit(meta.roots.map((_,i)=>i));observers.release();}},
 });
}
function __action0(ctx,rt,s0){__tick(ctx);__tick(ctx);return __fn1(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),__fn0()),s0);}
function __action1(ctx,rt,s1){__tick(ctx);__tick(ctx);return __fn2(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),__fn0()),s1);}
function __action2(ctx,rt){__tick(ctx);__tick(ctx);return ((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),__fn0());}
function __action3(ctx,rt,s2,s3,s4){__tick(ctx);try{__tick(ctx);const s5=({Some:null});if(((s6)=>Object.hasOwn(s6,"Some")?((s7)=>(((((__fn7(s2)) && ((__float(s3) > __float(0))))) && ((__float(s3) <= __float(1048576000))))))(s6["Some"]):((s8)=>(((((__fn7(s2)) && ((__float(s3) > __float(0))))) && ((__float(s3) <= __float(1048576000))))))(null))(s5)){__tick(ctx);const s9=__try(__fn3(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),__fn0()),s2,s4));__tick(ctx);__tablePut(rt,0,0,__fn6(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),__fn0()),s9,s3),0);__tick(ctx);const s10=__fn2(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),__fn0()),s2);__tick(ctx);__emit(rt,"learned",s10);__tick(ctx);const s11=({Ok:s10});return ((()=>{const s12=({Some:null});return ((s13)=>Object.hasOwn(s13,"Some")?((s14)=>(__fn5(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),__fn0()))))(s13["Some"]):((s15)=>(__fn5(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),__fn0()))))(null))(s12);})()?s11:({Err:(()=>{const s16=({Some:null});return ((s17)=>Object.hasOwn(s17,"Some")?((s18)=>("weight domain"))(s17["Some"]):((s19)=>("weight domain"))(null))(s16);})()}));}else{__tick(ctx);return ({Err:(()=>{const s20=({Some:null});return ((s21)=>Object.hasOwn(s21,"Some")?((s22)=>("training domain"))(s21["Some"]):((s23)=>("training domain"))(null))(s20);})()});}}catch(e){if(e instanceof __Abort)return ({Err:e.value});throw e;}}
function __stateCommitRoot0(rt,key,prior,next,slot){__storeDirect(rt,0,key,prior,next,slot);const publish=rt.meta.outputPublication&&!rt.observers.directRoots[0]&&rt.observers.active;if(publish&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}}
const __stateDirectReadFactories=[null,null,null,null];
function __stateValueEqual0(a,b){if(a===b)return true;if(a.length!==b.length)return false;for(let i=0;i<a.length;i++)if(!((a[i]===b[i])))return false;return true;}
function __stateValueEqual1(a,b){if(a===b)return true;const xv=a,yv=b,x=Object.hasOwn(xv,'Ok');return x===Object.hasOwn(yv,'Ok')&&(x?(xv.Ok===yv.Ok):(xv.Err===yv.Err));}
function __ownedInput1(value,budget={cells:1000000},depth=0,maxDepth=64){if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=__ownedInput2(value[i],budget,depth+1,maxDepth);return out;}
function __ownedInput0(value,budget={cells:1000000},depth=0,maxDepth=64){if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,"features")||!Object.hasOwn(value,"target"))throw Error('invalid record');const field0=__ownedInput1(value["features"],budget,depth+1,maxDepth);const field1=__ownedInput2(value["target"],budget,depth+1,maxDepth);return {["features"]:field0,["target"]:field1};}
const __ownedType2={"kind":"f32"};
function __ownedInput2(value,budget={cells:1000000},depth=0,maxDepth=64){return __stateInput(value,__ownedType2,budget,depth,maxDepth);}
function __ownedInput3(value,budget={cells:1000000},depth=0,maxDepth=64){let scalar=value;if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(typeof scalar!=='number'||!Number.isInteger(scalar)||scalar<0||scalar>4294967295)throw Error('invalid u32');if(scalar===0)scalar=0;return scalar;}
const __stateFrozenFactories=[];
const __stateQueryEquals=[(a,b)=>(a===b),(a,b)=>(a===b),(a,b)=>__stateValueEqual0(a,b),(a,b)=>__stateValueEqual1(a,b)];
const __stateRootEquals=[(a,b)=>__stateValueEqual0(a,b)];
const __stateBoundFactories=[(run,a,inputs,output,only)=>(p0)=>run(a,[inputs[0](p0)],null,output,only,true),(run,a,inputs,output,only)=>(p0)=>run(a,[inputs[0](p0)],null,output,only,true),(run,a,inputs,output,only)=>()=>run(a,[],null,output,only,true),(run,a,inputs,output,only,rt,begin,complete,abort,end)=>a.precondition?(p0,p1,p2)=>run(a,[inputs[0](p0),inputs[1](p1),inputs[2](p2)],null,output,only,true):(p0,p1,p2)=>{const b0=inputs[0](p0);const b1=inputs[1](p1);const b2=inputs[2](p2);begin(a);try{return complete(a,__action3(rt.ctx,rt,b0,b1,b2),output,only);}catch(e){return abort(e);}finally{end();}}];const __statePreflightFactories=[null,null,null,null];
const __stateMetadata={"actions":[{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":0,"name":"prediction","params":[{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"kind":"f32"},"roots":[0],"singleCell":true},{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":1,"name":"loss","params":[{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"kind":"f32"},"roots":[0],"singleCell":true},{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":2,"name":"parameters","params":[],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"},"roots":[0],"singleCell":true},{"change":true,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":false,"index":3,"name":"observe","params":[{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}},{"name":"rate","type":{"kind":"f32"}},{"name":"maximum","type":{"kind":"u32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"f32"}},"roots":[0],"singleCell":true}],"compactCommits":false,"eventColumns":false,"eventRuns":false,"events":[{"name":"learned","snapshotType":{"kind":"f32"},"type":{"kind":"f32"}}],"invariantChecks":[],"keepInvalidations":[[]],"keeps":[],"lazyMaintenance":true,"outputPublication":false,"roots":[{"key":{"kind":"u32"},"name":"Weights","snapshotKey":{"kind":"u32"},"snapshotValue":{"element":{"kind":"f32"},"kind":"list"},"value":{"element":{"kind":"f32"},"kind":"list"}}],"snapshot":{"program":[130,22,144,82,49,204,120,233,72,29,225,207,56,130,22,106,32,219,222,191,170,19,8,86,187,172,147,173,28,131,10,84],"schema":[88,237,187,8,176,224,234,212,255,33,114,68,240,149,102,187,10,107,85,221,202,66,9,105,147,239,26,11,119,207,53,167]},"snapshotRows":false};const __actions=[__action0,__action1,__action2,__action3];const __stateInputCaptures=[[__ownedInput0],[__ownedInput0],[],[__ownedInput0,__ownedInput2,__ownedInput3]];
export function createState(){return __createState(__stateMetadata,__actions,__stateInputCaptures);}
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v11","core_sha256":"7efbcb15d455abac724ec88ae497f683999f81ad2a57b2adf15718a3f001ab1b","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"f32_storage":"exact-u32-bits","functions":[{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":0,"internal":false,"name":"initial","parallel":false,"params":[],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":1,"internal":false,"name":"model","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":2,"internal":false,"name":"objective","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":3,"internal":false,"name":"derivatives","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}},{"name":"maximum","type":{"kind":"u32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"destination":null,"index":4,"internal":false,"name":"linearized_value","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}},{"name":"maximum","type":{"kind":"u32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"f32"}}},{"destination":null,"index":5,"internal":false,"name":"valid","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":6,"internal":false,"name":"update","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"rate","type":{"kind":"f32"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":7,"internal":false,"name":"admissible","parallel":false,"params":[{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":8,"internal":false,"name":"branch_owned","parallel":false,"params":[{"name":"input","type":{"element":{"kind":"u32"},"kind":"option"}}],"precondition":null,"result":{"element":{"kind":"u32"},"kind":"list"}},{"destination":null,"index":9,"internal":true,"name":"device_work","parallel":false,"params":[{"name":"input","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"temporary"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":10,"internal":false,"name":"device","parallel":false,"params":[{"name":"inputs","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":11,"internal":false,"name":"__ink_reverse_0_constant","parallel":false,"params":[{"name":"value","type":{"kind":"f32"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"destination":null,"index":12,"internal":true,"name":"__ink_reverse_0_append","parallel":false,"params":[{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"node","type":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"}},{"name":"active","type":{"kind":"bool"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":13,"internal":true,"name":"__ink_reverse_0_seed","parallel":false,"params":[{"name":"value","type":{"kind":"f32"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":14,"internal":true,"name":"__ink_reverse_0_binary","parallel":false,"params":[{"name":"op","type":{"kind":"u32"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":15,"internal":true,"name":"__ink_reverse_0_unary","parallel":false,"params":[{"name":"op","type":{"kind":"u32"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":16,"internal":true,"name":"__ink_reverse_0_add","parallel":false,"params":[{"name":"g","type":{"kind":"temporary"}},{"name":"id","type":{"kind":"u32"}},{"name":"value","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"temporary"}},{"destination":null,"index":17,"internal":true,"name":"__ink_reverse_0_back_node","parallel":false,"params":[{"name":"node","type":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"}},{"name":"amount","type":{"kind":"f32"}},{"name":"g","type":{"kind":"temporary"}}],"precondition":null,"result":{"kind":"temporary"}},{"destination":null,"index":18,"internal":true,"name":"__ink_reverse_0_back_step","parallel":false,"params":[{"name":"node","type":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"}},{"name":"work","type":{"fields":[{"name":"gradient","type":{"kind":"temporary"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Reverse"}},{"name":"stopZero","type":{"kind":"bool"}}],"precondition":null,"result":{"fields":[{"name":"gradient","type":{"kind":"temporary"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Reverse"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":19,"internal":false,"name":"__ink_reverse_0_backward","parallel":false,"params":[{"name":"nodes","type":{"element":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"kind":"list"}},{"name":"output","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"stopZero","type":{"kind":"bool"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":20,"internal":true,"name":"__ink_reverse_4","parallel":false,"params":[{"name":"weights","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_3"}},{"name":"__ink_reverse_5","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":21,"internal":true,"name":"__ink_reverse_1","parallel":false,"params":[{"name":"weights","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_3"}},{"name":"__ink_reverse_2","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":22,"internal":false,"name":"__ink_reverse_37","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"__ink_reverse_32","type":{"kind":"u32"}},{"name":"__ink_reverse_33","type":{"kind":"bool"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"destination":null,"index":23,"internal":false,"name":"__ink_reverse_50","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"__ink_reverse_45","type":{"kind":"u32"}},{"name":"__ink_reverse_46","type":{"kind":"bool"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"__ink_reverse_58"}}}],"named_types":{"Context":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"},"__ink_reverse_0_Flow":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"},"__ink_reverse_0_Node":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"__ink_reverse_0_Reverse":{"fields":[{"name":"gradient","type":{"kind":"temporary"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Reverse"},"__ink_reverse_0_Tape":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"},"__ink_reverse_0_Wire":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"__ink_reverse_13":{"fields":[{"name":"left","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"right","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_13"},"__ink_reverse_18":{"fields":[{"name":"values","type":{"kind":"temporary"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_18"},"__ink_reverse_3":{"fields":[{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_3"},"__ink_reverse_42":{"fields":[{"name":"values","type":{"kind":"temporary"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_42"},"__ink_reverse_55":{"fields":[{"name":"values","type":{"kind":"temporary"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_55"},"__ink_reverse_58":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"__ink_reverse_58"},"__ink_reverse_6":{"fields":[{"name":"value","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_6"},"__ink_reverse_8":{"fields":[{"name":"value","type":{"fields":[{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_3"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_8"}},"prepared_compiled":{"evaluation":"lazy source-order; successful bindings only","functions":[{"factory":false,"function":"initial","reason":"no reusable captured work"},{"factory":false,"function":"model","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"objective","retained_bindings":1},{"delegated_calls":1,"factory":true,"function":"derivatives","retained_bindings":0},{"delegated_calls":1,"factory":true,"function":"linearized_value","retained_bindings":0},{"factory":false,"function":"valid","reason":"no reusable captured work"},{"factory":false,"function":"update","reason":"no reusable captured work"},{"factory":false,"function":"admissible","reason":"no reusable captured work"},{"factory":false,"function":"branch_owned","reason":"no reusable captured work"},{"factory":false,"function":"device_work","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"device","reason":"no reusable captured work"},{"factory":false,"function":"__ink_reverse_0_constant","reason":"no reusable captured work"},{"factory":false,"function":"__ink_reverse_0_append","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_seed","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_binary","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_unary","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_add","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_back_node","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_back_step","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_backward","reason":"no reusable lexical bindings"},{"factory":false,"function":"__ink_reverse_4","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_1","reason":"prepared residual requires a bounded pure value entry"},{"delegated_calls":1,"factory":true,"function":"__ink_reverse_37","retained_bindings":1},{"delegated_calls":1,"factory":true,"function":"__ink_reverse_50","retained_bindings":1}],"lifetime":"prepared token","semantics":"sealed-value-residual-v1"},"private_record_elisions":[],"private_sum_spines":[],"schema":1,"state":{"actions":[{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":0,"name":"prediction","params":[{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"kind":"f32"},"roots":[0],"singleCell":true},{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":1,"name":"loss","params":[{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"kind":"f32"},"roots":[0],"singleCell":true},{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":2,"name":"parameters","params":[],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"},"roots":[0],"singleCell":true},{"change":true,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":false,"index":3,"name":"observe","params":[{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}},{"name":"rate","type":{"kind":"f32"}},{"name":"maximum","type":{"kind":"u32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"f32"}},"roots":[0],"singleCell":true}],"compactCommits":false,"eventColumns":false,"eventRuns":false,"events":[{"name":"learned","snapshotType":{"kind":"f32"},"type":{"kind":"f32"}}],"invariantChecks":[],"keepInvalidations":[[]],"keeps":[],"lazyMaintenance":true,"outputPublication":false,"roots":[{"key":{"kind":"u32"},"name":"Weights","snapshotKey":{"kind":"u32"},"snapshotValue":{"element":{"kind":"f32"},"kind":"list"},"value":{"element":{"kind":"f32"},"kind":"list"}}],"snapshot":{"program":[130,22,144,82,49,204,120,233,72,29,225,207,56,130,22,106,32,219,222,191,170,19,8,86,187,172,147,173,28,131,10,84],"schema":[88,237,187,8,176,224,234,212,255,33,114,68,240,149,102,187,10,107,85,221,202,66,9,105,147,239,26,11,119,207,53,167]},"snapshotRows":false},"wire":{"format":"ink-value-wire-v1","functions":{"__ink_reverse_0_add":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_append":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_back_node":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_back_step":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_backward":{"arguments":{"format":"ink-value-wire-v1","identity":"369ca7294b9f7da184514c2d74f2fbffa34696c1fa5d3a2adaf1f053340d482d","named":{},"root":{"fields":[{"name":"nodes","type":{"element":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"kind":"list"}},{"name":"output","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"stopZero","type":{"kind":"bool"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"__ink_reverse_0_binary":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_constant":{"arguments":{"format":"ink-value-wire-v1","identity":"d4cb0361a7a8833933106ca6dd70006e19100c770fe048f31d961bc14fa899fc","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fabc4e63e940c6190680726874c8654deced79200b320c057b9389a135a08557","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}},"__ink_reverse_0_seed":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_unary":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_1":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_37":{"arguments":{"format":"ink-value-wire-v1","identity":"aa6ffaee463edc2bbb4595b3448a47ccf9f902019bdfa1698cab5a40095ebc3a","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"__ink_reverse_32","type":{"kind":"u32"}},{"name":"__ink_reverse_33","type":{"kind":"bool"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}}},"__ink_reverse_4":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_50":{"arguments":{"format":"ink-value-wire-v1","identity":"064915d4b19973c0396dcdd3a9a8b095ad4e22429872efaf1a375b4c54eac3aa","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"__ink_reverse_45","type":{"kind":"u32"}},{"name":"__ink_reverse_46","type":{"kind":"bool"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"f2d8a6a6c76daa0750e8dd172034ca17108eb15fc853843947bdb021fd452611","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"__ink_reverse_58"}}}},"admissible":{"arguments":{"format":"ink-value-wire-v1","identity":"a4c45ed22b0e345add1a53da55d4f9aa0442ed173ee8c7734a183b368c9d0031","named":{},"root":{"fields":[{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"branch_owned":{"arguments":{"format":"ink-value-wire-v1","identity":"6ea13b740766255e668bdce007ed0ea6f6091b69fe3a9d897ca135f5edeef7cd","named":{},"root":{"fields":[{"name":"input","type":{"element":{"kind":"u32"},"kind":"option"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"69ebf947aa59a2546656d1976b0baa6e56e7182d989425379b31e3bff74168ca","named":{},"root":{"element":{"kind":"u32"},"kind":"list"}}},"derivatives":{"arguments":{"format":"ink-value-wire-v1","identity":"d0fa6f5fad6d5ea49ecfccbf7a1a5bdf4d65384297c30db7f5989fa6013499be","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}},{"name":"maximum","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}}},"device":{"arguments":{"format":"ink-value-wire-v1","identity":"83b9b7354aba5e748ee768e3487afeb50ddd616def9b5be81dbc74b6305f501b","named":{},"root":{"fields":[{"name":"inputs","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"device_work":{"unsupported":"unsupported wire descriptor"},"initial":{"arguments":{"format":"ink-value-wire-v1","identity":"3720cf83cb9a672c0c70e7f80cfe0abe0bf9b7df73d40a9def0c7436234026b2","named":{},"root":{"fields":[],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"linearized_value":{"arguments":{"format":"ink-value-wire-v1","identity":"d0fa6f5fad6d5ea49ecfccbf7a1a5bdf4d65384297c30db7f5989fa6013499be","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}},{"name":"maximum","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"29bcdada2d2b5ecb6deae18e25401ad25c1f0dc80bcd50defebf64892403468d","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"f32"}}}},"model":{"arguments":{"format":"ink-value-wire-v1","identity":"97019f1af0dd8c1360f443304271bf6d17719aef581eca5c217e172f074ab50e","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"objective":{"arguments":{"format":"ink-value-wire-v1","identity":"97019f1af0dd8c1360f443304271bf6d17719aef581eca5c217e172f074ab50e","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"update":{"arguments":{"format":"ink-value-wire-v1","identity":"907283cc95c811b8b6e4d273283b1227f8a468df3df28f504ee2584d9d3791aa","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"rate","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"valid":{"arguments":{"format":"ink-value-wire-v1","identity":"fb0d53fcc5118c446d80e19c4ffd8b95f7979f94f7fb23149d3518375b621a75","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}}}}};
const __implementations=[__fn0,__fn1,__fn2,__fn3,__fn4,__fn5,__fn6,__fn7,__fn8,__fn9,__fn10,__fn11,__fn12,__fn13,__fn14,__fn15,__fn16,__fn17,__fn18,__fn19,__fn20,__fn21,__fn22,__fn23];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
const __inputTypes=[{"capture":[],"types":[]},{"capture":[true,false],"types":[{"element":{"kind":"f32"},"kind":"list"},{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"Context"}]},{"capture":[true,false],"types":[{"element":{"kind":"f32"},"kind":"list"},{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}]},{"capture":[true,false,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"},{"kind":"u32"}]},{"capture":[true,false,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"},{"kind":"u32"}]},{"capture":[true],"types":[{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[true,true,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"kind":"f32"}]},{"capture":[false],"types":[{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}]},{"capture":[true],"types":[{"element":{"kind":"u32"},"kind":"option"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[true],"types":[{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[true,true,true],"types":[{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"},{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},{"kind":"bool"}]},{"capture":[true,true],"types":[{"kind":"f32"},{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}]},{"capture":[true,true,false,false],"types":[{"kind":"u32"},{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}]},{"capture":[true,true,false],"types":[{"kind":"u32"},{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}]},{"capture":[true,true,true],"types":[{"kind":"temporary"},{"kind":"u32"},{"kind":"f32"}]},{"capture":[false,true,true],"types":[{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},{"kind":"f32"},{"kind":"temporary"}]},{"capture":[false,false,true],"types":[{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},{"fields":[{"name":"gradient","type":{"kind":"temporary"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Reverse"},{"kind":"bool"}]},{"capture":[false,false,true],"types":[{"element":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"kind":"list"},{"fields":[{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},{"kind":"bool"}]},{"capture":[true,true,true],"types":[{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"},{"fields":[{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_3"},{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}]},{"capture":[true,true,true],"types":[{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"},{"fields":[{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_3"},{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}]},{"capture":[true,true,true,false],"types":[{"element":{"kind":"f32"},"kind":"list"},{"kind":"u32"},{"kind":"bool"},{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}]},{"capture":[true,true,true,false],"types":[{"element":{"kind":"f32"},"kind":"list"},{"kind":"u32"},{"kind":"bool"},{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}]}];

// Descriptor work occurs once at module initialisation, never per word-list call.
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=> {
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const output=__representation(f.result,true);
  const body=__implementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
  const needsInput=input.some(c=>c!==__identity);
  const entry=!needsInput && output===__identity ? implementation :
    (...args)=>{const context=new WeakMap();return output(implementation(...(needsInput ? args.map((v,i)=>input[i](v,context)) : args)),context);};
  return [f.name,entry];
})));
export function call(name,args) {switch(name){case "device_work":case "__ink_reverse_0_append":case "__ink_reverse_0_seed":case "__ink_reverse_0_binary":case "__ink_reverse_0_unary":case "__ink_reverse_0_add":case "__ink_reverse_0_back_node":case "__ink_reverse_0_back_step":case "__ink_reverse_4":case "__ink_reverse_1":throw new Error('temporary storage is internal to a pure invocation');}return functions[name](...args);}
// Shared bounded binary codec; generated code supplies exact descriptors.
export const valueWireFormat='ink-value-wire-v1';
// A connection agrees on the complete value schema before using this format.
// Version byte + schema-directed fields; schema identity is out of band.
export const compactValueWireFormat='ink-value-session-v1';
const wireMagic=Uint8Array.of(73,78,75,86,65,76,0,1);
const wireEncoder=new TextEncoder(),wireDecoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const wireDefaults=Object.freeze({bytes:16777216,nodes:1000000,depth:128}),wireDefaultOptions=Object.freeze({});
const wireDecimal=s=>typeof s==='string'&&/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(s);
function wireLimits(options){if(options===wireDefaultOptions||options===wireDefaults)return wireDefaults;const l={...wireDefaults,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>wireDefaults[k])throw Error('wire hard resource limit');return l;}
const wireFloat=new DataView(new ArrayBuffer(4));
function wireDecodeText(bytes,start,end){
 if(end-start<=16){let text='';for(let i=start;i<end;i++){const byte=bytes[i];if(byte>=128)return wireDecoder.decode(bytes.subarray(start,end));text+=String.fromCharCode(byte);}return text;}
 return wireDecoder.decode(bytes.subarray(start,end));
}
function wireUtf8Length(text){let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const wireOwn=(v,k)=>v!==null&&typeof v==='object'&&Object.hasOwn(v,k);
const wireTagged=(v,k)=>wireOwn(v,k)&&Object.keys(v).length===1;
const wireDouble=new DataView(new ArrayBuffer(8));
function wireF64Bits(v){
 if(typeof v==='number'&&Number.isFinite(v)){wireDouble.setFloat64(0,v,true);return wireDouble.getBigUint64(0,true);}
 if(!wireTagged(v,'F64Bits'))wireInvalidValue();const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))wireInvalidValue();
 const bits=BigInt(text);if(bits>18446744073709551615n)wireInvalidValue();return bits;
}
const wireCanonical=v=>Array.isArray(v)?'['+v.map(wireCanonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort((a,b)=>{const x=Array.from(a,c=>c.codePointAt(0)),y=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]-y[i];return x.length-y.length;}).map(k=>JSON.stringify(k)+':'+wireCanonical(v[k])).join(',')+'}':JSON.stringify(v);
export async function createValueCodec(root,named={}){
 const used=new Set(),budget={nodes:100000};
 function check(t,d=0){
  if(d>64||--budget.nodes<0)throw Error('wire descriptor limit');
  const keys={u32:['kind'],u64:['kind'],i32:['kind'],f32:['kind'],f64:['kind'],bool:['kind'],unit:['kind'],string:['kind'],int:['kind'],id:['kind','name'],ref:['kind','name'],enum:['kind','name','variants'],record:['kind','name','fields'],list:['kind','element'],option:['kind','element'],vector:['kind','element','size'],result:['kind','ok','error']}[t?.kind];
  if(!keys||Object.keys(t).length!==keys.length||keys.some(k=>!Object.hasOwn(t,k)))throw Error('invalid wire descriptor');
  if(keys.includes('name')&&(typeof t.name!=='string'||!t.name.isWellFormed()))throw Error('invalid descriptor name');
  if(t.kind==='ref'){if(!used.has(t.name)){used.add(t.name);if(named[t.name]?.kind!=='record'||named[t.name].name!==t.name)throw Error('unresolved wire reference');check(named[t.name],d+1);}}
  if(t.kind==='record'){if(!Array.isArray(t.fields))throw Error('wire fields');const names=new Set();for(const f of t.fields){if(Object.keys(f).length!==2||typeof f.name!=='string'||!f.name.isWellFormed()||names.has(f.name))throw Error('duplicate wire field');names.add(f.name);check(f.type,d+1);}}
  if(t.kind==='enum'&&(!Array.isArray(t.variants)||!t.variants.length||t.variants.length>64||t.variants.some(v=>typeof v!=='string'||!v.isWellFormed())||new Set(t.variants).size!==t.variants.length))throw Error('wire enum');
  if(['list','vector','option'].includes(t.kind)){if(t.kind==='vector'&&(!Number.isInteger(t.size)||t.size<1||t.size>64))throw Error('wire vector');check(t.element,d+1);}
  if(t.kind==='result'){check(t.ok,d+1);check(t.error,d+1);}
 }
 check(root);const names=Object.fromEntries([...used].sort().map(k=>[k,named[k]]));
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',wireEncoder.encode(wireCanonical({format:valueWireFormat,root,named:names}))));
 return new ValueCodec({format:valueWireFormat,root,named:names,identity:Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('')});
}
// Resolve immutable descriptor edges once. Logical validation traverses the
// literal schema; single-child nodes use a loop rather than recursive closures.
function wireValuePlan(codec){
 const seen=new WeakMap();let remaining=100000;
 const build=type=>{
  const t=codec.resolve(type);if(seen.has(t))return seen.get(t);
  if(--remaining<0)throw Error('wire descriptor limit');const p={kind:t.kind,type:t,decode:null,decodeCompact:null};seen.set(t,p);
  if(t.kind==='record')p.fields=t.fields.map(f=>({name:f.name,plan:build(f.type)}));
  if(t.kind==='list'||t.kind==='vector'||t.kind==='option')p.element=build(t.element);
  if(t.kind==='result'){p.ok=build(t.ok);p.error=build(t.error);}
  return p;
 };return build(codec.descriptor.root);
}
function wireBindDecodePlan(root,compact=false){
 const seen=new Set(),pending=[root];let flags=0;
 while(pending.length){
  const p=pending.pop();if(seen.has(p))continue;seen.add(p);if(compact)p.decodeCompact=compactDecodeOperation(p);else p.decode=wireDecodeOperation(p);
  if(p.fields?.length>4)flags|=1;
  if(p.kind==='u32'||p.kind==='i32'||p.kind==='u64'||p.kind==='f32'||p.kind==='f64')flags|=2;
  if(p.fields)for(const f of p.fields)pending.push(f.plan);
  if(p.element)pending.push(p.element);
  if(p.ok){pending.push(p.ok);pending.push(p.error);}
 }
 return flags|4;
}
// Select literal descriptor operations once, without runtime source generation
// or eval. Recursive edges call the completed plan. The generic scanner remains
// the visitor/validation path and an independent materialisation implementation.
function wireReadOperation(p){
 const t=p.type;
 let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':read=(r,end)=>{r.size(end,4);const value={F32Bits:r.view.getUint32(r.cursor,true)};r.cursor=end;return value;};break;
  case 'f64':read=(r,end)=>{r.size(end,8);const value={F64Bits:r.view.getBigUint64(r.cursor,true).toString()};r.cursor=end;return value;};break;
  case 'u64':read=(r,end)=>{r.size(end,8);const value=r.view.getBigUint64(r.cursor,true);r.cursor=end;return value;};break;
  case 'string':read=(r,end)=>r.text(end);break;
  case 'int':read=(r,end)=>{const text=r.text(end);if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=(r,end)=>{const text=r.text(end);if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=(r,end)=>{const text=r.text(end);if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{
    if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;
    if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');
    const values=new Array(n);for(let i=0;i<n;i++)values[i]=element.decode(r,end,d+1);return values;
   };break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1)});break;
    case 2:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1)});break;
    case 3:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1)});break;
    case 4:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1),[fs[3].name]:fs[3].plan.decode(r,end,d+1)});break;
    default:read=(r,end,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decode(r,end,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,end,d)=>{const tag=r.tag(end);return tag?{Some:p.element.decode(r,end,d+1)}:{None:null};};break;
  case 'result':read=(r,end,d)=>r.tag(end)?{Err:p.error.decode(r,end,d+1)}:{Ok:p.ok.decode(r,end,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function wireDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=wireReadOperation(field.plan),name=field.name;
  return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),childEnd=r.enter(end,d+1),item=read(r,childEnd,d+1);if(r.cursor!==childEnd)throw Error('trailing wire frame bytes');const value={[name]:item};if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
 }
 const read=wireReadOperation(p);
 return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
}
class WireDecodeCursor{
 constructor(bytes,view,limits){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
// Bind literal validation and postorder visitation once for every descriptor.
// No logical carriers are allocated; projection still validates every child.
function wireScanPlan(root){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,scan:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.scan=wireScanOperation(p);return p;
 };
 return build(root);
}
function wireScanOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':case 'f64':case 'u64':{const size=p.kind==='f32'?4:8;read=(r,end)=>{r.size(end,size);r.cursor=end;};break;}
  case 'string':read=(r,end)=>{let i=r.cursor;while(i<end&&r.bytes[i]<128)i++;if(i<end)wireDecoder.decode(r.bytes.subarray(r.cursor,end));r.cursor=end;};break;
  case 'int':case 'id':case 'enum':read=(r,end)=>{const text=r.text(end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');for(let i=0;i<n;i++)element.scan(r,end,d+1);};break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>{};break;
    case 1:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);};break;
    case 2:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);};break;
    case 3:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);};break;
    case 4:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);fs[3].plan.scan(r,end,d+1);};break;
    default:read=(r,end,d)=>{for(const f of fs)f.plan.scan(r,end,d+1);};
   }break;
  }
  case 'option':read=(r,end,d)=>{if(r.tag(end))p.element.scan(r,end,d+1);};break;
  case 'result':read=(r,end,d)=>{(r.tag(end)?p.error:p.ok).scan(r,end,d+1);};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return (r,parentEnd,d)=>{
  const end=r.enter(parentEnd,d),start=r.cursor,value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');
  const visitor=r.visitor;if(visitor&&(!r.selected||r.selected.has(t.name))){if(r.spans)visitor(t,r.bytes,start,end,d);else visitor(t,r.bytes.subarray(start,end),d);}
  return value;
 };
}
// Separate methods keep decoding's cursor callsites monomorphic. Both cursors
// are checked against the independent generic scanner and malformed fixtures.
class WireScanCursor{
 constructor(bytes,view,limits,visitor,selected,spans){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.visitor=visitor;this.selected=selected;this.spans=spans;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
function compactReadOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=()=>null;break;
  case 'bool':read=r=>{r.require(1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':case 'i32':read=r=>{r.require(4);const n=p.kind==='u32'?r.view.getUint32(r.cursor,true):r.view.getInt32(r.cursor,true);r.cursor+=4;return n;};break;
  case 'f32':read=r=>{r.require(4);const n=r.view.getUint32(r.cursor,true);r.cursor+=4;return {F32Bits:n};};break;
  case 'f64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return {F64Bits:n.toString()};};break;
  case 'u64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return n;};break;
  case 'string':read=r=>r.text();break;
  case 'int':read=r=>{const text=r.text();if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=r=>{const text=r.text();if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=r=>{const text=r.text();if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':read=(r,d)=>{const n=r.count();if(n>r.remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');const values=new Array(n);for(let i=0;i<n;i++)values[i]=p.element.decodeCompact(r,d+1);return values;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1)});break;
    case 2:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1)});break;
    case 3:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1)});break;
    case 4:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1),[fs[3].name]:fs[3].plan.decodeCompact(r,d+1)});break;
    default:read=(r,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decodeCompact(r,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,d)=>r.tag()?{Some:p.element.decodeCompact(r,d+1)}:{None:null};break;
  case 'result':read=(r,d)=>r.tag()?{Err:p.error.decodeCompact(r,d+1)}:{Ok:p.ok.decodeCompact(r,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function compactDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=compactReadOperation(field.plan),name=field.name;
  return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');if(d+1>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return {[name]:read(r,d+1)};};
 }
 const read=compactReadOperation(p);
 return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return read(r,d);};
}
class CompactDecodeCursor{
 constructor(bytes,limits,flags){this.bytes=bytes;this.view=flags&2?new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength):null;this.cursor=1;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 require(n){if(n>this.bytes.length-this.cursor)throw Error('truncated compact value');}
 count(){
  if(this.cursor>=this.bytes.length)throw Error('truncated compact value');
  const first=this.bytes[this.cursor++];if(first<128)return first;
  let value=first&127,scale=128;
  for(let i=1;i<5;i++){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const byte=this.bytes[this.cursor++];if(i===4&&byte>15)throw Error('compact count overflow');value+=(byte&127)*scale;if(byte<128){if(byte===0)throw Error('noncanonical compact count');return value;}scale*=128;}throw Error('compact count overflow');
 }
 tag(){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const tag=this.bytes[this.cursor++];if(tag>1)throw Error('wire sum tag');return tag;}
 text(){const n=this.count();this.require(n);const start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
function wireInvalidValue(){throw Error('invalid value for wire schema');}
// Capture has the canonical logical meaning of decode(encode(value)), without
// allocating wire bytes. A separate plan leaves validation/decoder hot shapes
// unchanged and never retains host input containers between calls.
function wireCapturePlan(root,checked=true){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,capture:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({name:f.name,plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.capture=checked?wireCaptureOperation(p):wireCopyOperation(p);return p;
 };return build(root);
}
function wireCaptureOperation(p){
 const t=p.type;let copy;
 switch(p.kind){
  case 'unit':copy=v=>{if(v!==null)wireInvalidValue();return null;};break;
  case 'bool':copy=(v,r)=>{if(typeof v!=='boolean')wireInvalidValue();r.add(1);return v;};break;
  case 'u32':case 'i32':{
   const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
   copy=(v,r)=>{if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();r.add(4);return v===0?0:v;};break;
  }
  case 'u64':copy=(v,r)=>{const kind=typeof v;if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();r.add(8);return n;};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'int':case 'id':case 'enum':copy=(v,r)=>{const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;if(typeof text!=='string'||!text.isWellFormed()||text.length>r.limit)wireInvalidValue();if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();r.add(wireUtf8Length(text));return p.kind==='int'?{Int:text}:text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   copy=(v,r,d)=>{if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();const n=v.length;if(n>r.remaining||size!==null&&n!==size)wireInvalidValue();r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=element.capture(v[i],r,d+1);return out;};break;
  }
  case 'record':{
   const fs=p.fields;let fields;
   switch(fs.length){
    case 0:fields=()=>({});break;
    case 1:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:fields=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }
   copy=(v,r,d)=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();for(const f of fs)if(!wireOwn(v,f.name))wireInvalidValue();return fields(v,r,d);};break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'None')&&v.None===null)return {None:null};if(wireTagged(v,'Some'))return {Some:p.element.capture(v.Some,r,d+1)};wireInvalidValue();};break;
  case 'result':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'Ok'))return {Ok:p.ok.capture(v.Ok,r,d+1)};if(wireTagged(v,'Err'))return {Err:p.error.capture(v.Err,r,d+1)};wireInvalidValue();};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
class WireCaptureCursor{
 constructor(limits){this.remaining=limits.nodes;this.depth=limits.depth;this.limit=limits.bytes;this.bytes=40;this.add(0);}
 add(n){this.bytes+=n;if(this.bytes>this.limit)throw Error('wire byte limit');}
 enter(depth,bytes){if(depth>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.add(bytes);}
 text(value){if(value.length>this.limit)throw Error('wire byte limit');this.add(wireUtf8Length(value));}
}
// Literal lowerers share this fixed resource policy with logical capture.
export function createValueCaptureBudget(options=wireDefaultOptions){return new WireCaptureCursor(wireLimits(options));}
// The trusted-value API has the same canonical copy and ownership semantics.
// Its caller supplies a stable value accepted by validateValue. Shape/range
// checks remain at external capture boundaries; resource limits still apply.
function wireCopyOperation(p){
 let copy;
 switch(p.kind){
  case 'unit':copy=()=>null;break;
  case 'bool':copy=(v,r)=>{r.add(1);return v;};break;
  case 'u32':copy=(v,r)=>{r.add(4);return v>>>0;};break;
  case 'i32':copy=(v,r)=>{r.add(4);return v|0;};break;
  case 'u64':copy=(v,r)=>{r.add(8);return BigInt(v);};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'){wireFloat.setFloat32(0,v,true);bits=wireFloat.getUint32(0,true);}else bits=v.F32Bits;r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'id':case 'enum':copy=(v,r)=>{r.add(wireUtf8Length(v));return v;};break;
  case 'int':copy=(v,r)=>{const text=typeof v==='bigint'?v.toString():v.Int;r.add(wireUtf8Length(text));return {Int:text};};break;
  case 'list':case 'vector':copy=(v,r,d)=>{const n=v.length;if(n>r.remaining)throw Error('wire sequence size');r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=p.element.capture(v[i],r,d+1);return out;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:copy=()=>({});break;
    case 1:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:copy=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'None')&&v.None===null?{None:null}:{Some:p.element.capture(v.Some,r,d+1)};};break;
  case 'result':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'Ok')?{Ok:p.ok.capture(v.Ok,r,d+1)}:{Err:p.error.capture(v.Err,r,d+1)};};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
// Emit the cached literal schema with one forward writer. Each value is checked
// where it is consumed; byte bounds belong to the writer, not a second size walk.
function wireEncodeValue(root,value,l,w){
 let remaining=l.nodes;const depthLimit=l.depth;
 const node=(p,v,d)=>{
  if(d>depthLimit||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type,start=w.beginNode();
  switch(p.kind){
   case 'unit':if(v!==null)wireInvalidValue();break;
   case 'bool':if(typeof v!=='boolean')wireInvalidValue();w.byte(+v);break;
   case 'u32':case 'i32':{
    const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
    if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();w.word(v>>>0);break;
   }
   case 'u64':{
    const kind=typeof v;
    if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
    const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();w.wide(n);break;
   }
   case 'f64':w.wide(wireF64Bits(v));break;
   case 'f32':{
    let bits;
    if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}
    else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
    w.word(bits);break;
   }
   case 'string':case 'int':case 'id':case 'enum':{
    const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
    if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&(typeof text!=='string'||!/^[0-9a-f]{32}$/.test(text))||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
    w.text(text);break;
   }
   case 'list':case 'vector':{
    if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
    if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
    w.count(v.length);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);break;
   }
   case 'record':{
    const fs=p.fields;
    if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
    for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
    for(let i=0;i<fs.length;i++){const f=fs[i];node(f.plan,v[f.name],d+1);}break;
   }
   case 'option':{
    if(wireTagged(v,'None')&&v.None===null)w.byte(0);
    else if(wireTagged(v,'Some')){w.byte(1);node(p.element,v.Some,d+1);}else wireInvalidValue();break;
   }
   case 'result':{
    if(wireTagged(v,'Ok')){w.byte(0);node(p.ok,v.Ok,d+1);}
    else if(wireTagged(v,'Err')){w.byte(1);node(p.error,v.Err,d+1);}else wireInvalidValue();break;
   }
   default:throw Error('unsupported wire kind');
  }
  w.endNode(start);
 };
 node(root,value,0);
}
function wireCheckValue(root,value,l){
 let remaining=l.nodes,total=40;
 const add=n=>{total+=n;if(total>l.bytes)throw Error('wire byte limit');};
 const node=(p,v,d)=>{
  while(true){
   if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
   const t=p.type;
   switch(p.kind){
    case 'unit':if(v!==null)wireInvalidValue();add(4);return;
    case 'bool':if(typeof v!=='boolean')wireInvalidValue();add(5);return;
    case 'u32':case 'i32':{
     const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
     if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();add(8);return;
    }
    case 'u64':{
     const kind=typeof v;
     if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
     const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();add(12);return;
    }
    case 'f64':wireF64Bits(v);add(12);return;
    case 'f32':{
     if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();}
     else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();const bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
     add(8);return;
    }
    case 'string':case 'int':case 'id':case 'enum':{
     const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
     if(typeof text!=='string'||!text.isWellFormed()||text.length>l.bytes)wireInvalidValue();
     if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
     add(4+wireUtf8Length(text));return;
    }
    case 'list':case 'vector':{
     if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
     if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
     add(8);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);return;
    }
    case 'record':{
     const fs=p.fields;
     if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
     for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
     add(4);if(!fs.length)return;
     for(let i=0;i<fs.length-1;i++)node(fs[i].plan,v[fs[i].name],d+1);
     const f=fs[fs.length-1];p=f.plan;v=v[f.name];d++;continue;
    }
    case 'option':{
     if(wireTagged(v,'None')&&v.None===null){add(5);return;}
     if(!wireTagged(v,'Some'))wireInvalidValue();add(5);p=p.element;v=v.Some;d++;continue;
    }
    case 'result':{
     if(wireTagged(v,'Ok')){add(5);p=p.ok;v=v.Ok;}
     else if(wireTagged(v,'Err')){add(5);p=p.error;v=v.Err;}else wireInvalidValue();
     d++;continue;
    }
    default:throw Error('unsupported wire kind');
   }
  }
 };
 node(root,value,0);if(total>l.bytes)throw Error('wire byte limit');
}
// A single cursor replaces per-node child closures and {end,value} temporaries.
// Projection filters limit callback materialisation, never schema validation.
function wireScanValue(root,bytes,view,l,materialize,visitor,selected,spans){
 let cursor=40,remaining=l.nodes;
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,parentEnd,d)=>{
  if(d>l.depth||--remaining<0||cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const t=p.type,start=cursor+4,end=start+view.getUint32(cursor,true);if(end>parentEnd)throw Error('truncated wire frame');cursor=start;let value;
  switch(p.kind){
   case 'unit':if(end-start!==0)throw Error('malformed wire scalar');value=null;break;
   case 'bool':if(end-start!==1)throw Error('malformed wire scalar');if(bytes[start]>1)throw Error('invalid wire Bool');value=!!bytes[start];cursor=end;break;
   case 'u32':case 'i32':if(end-start!==4)throw Error('malformed wire scalar');value=p.kind==='u32'?view.getUint32(start,true):view.getInt32(start,true);cursor=end;break;
   case 'f32':if(end-start!==4)throw Error('malformed wire scalar');if(materialize)value={F32Bits:view.getUint32(start,true)};cursor=end;break;
   case 'f64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value={F64Bits:view.getBigUint64(start,true).toString()};cursor=end;break;
   case 'u64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value=view.getBigUint64(start,true);cursor=end;break;
   case 'string':case 'int':case 'id':case 'enum':{
    if(p.kind==='string'&&!materialize){let i=start;while(i<end&&bytes[i]<128)i++;if(i<end)wireDecoder.decode(bytes.subarray(start,end));}
    else{const text=wireDecodeText(bytes,start,end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    cursor=end;break;
   }
   case 'list':case 'vector':{
    if(start+4>end)throw Error('wire list count');const n=view.getUint32(start,true);cursor+=4;
    if(n>remaining||n>Math.floor((end-cursor)/4)||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,end,d+1);if(materialize)value.push(child);}break;
   }
   case 'record':{
    const fs=p.fields;
    // Computed literal keys create own data properties even for __proto__ or
    // prototype setters. Common small records need no descriptor allocations.
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:value={};break;case 1:value={[fs[0].name]:node(fs[0].plan,end,d+1)};break;case 2:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1)};break;case 3:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1)};break;case 4:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1),[fs[3].name]:node(fs[3].plan,end,d+1)};break;}
    }else{if(materialize)value={};for(const f of fs){const child=node(f.plan,end,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}}break;
   }
   case 'option':case 'result':{
    if(start===end||bytes[cursor]>1)throw Error('wire sum tag');const tag=bytes[cursor++];
    if(p.kind==='option'&&tag===0){if(materialize)value={None:null};}
    else{const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,end,d+1);if(materialize)value={[label]:child};}break;
   }
   default:throw Error('unsupported wire kind');
  }
  if(cursor!==end)throw Error('trailing wire frame bytes');
  if(visitor&&(!selected||selected.has(t.name))){if(spans)visitor(t,bytes,start,end,d);else visitor(t,bytes.subarray(start,end),d);}
  return value;
 };
 const result=node(root,bytes.length,0);if(cursor!==bytes.length)throw Error('trailing wire bytes');return result;
}
export class ValueCodec{
 #hash;
 #header;
 #headerWords;
 #descriptor;
 #valuePlan;
 #compactCodec;
 #encoder;
 #decodeBound=0;
 #scanPlan=null;
 #capturePlan=null;
 #copyPlan=null;
 get descriptor(){return this.#descriptor;}
 constructor(descriptor){
  // This synchronous path is for compiler-generated immutable metadata. For
  // untrusted descriptors use createValueCodec and compare the computed identity.
  if(descriptor?.format!==valueWireFormat||!/^[0-9a-f]{64}$/.test(descriptor.identity))throw Error('invalid wire schema');
  this.#descriptor=structuredClone(descriptor);this.#hash=Uint8Array.from(descriptor.identity.match(/../g),s=>parseInt(s,16));
  this.#header=new Uint8Array(40);this.#header.set(wireMagic);this.#header.set(this.#hash,8);
  const headerView=new DataView(this.#header.buffer);this.#headerWords=Array.from({length:10},(_,i)=>headerView.getUint32(i*4,true));
  const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}};freeze(this.descriptor);this.#valuePlan=wireValuePlan(this);
 }
 resolve(t){for(let i=0;i<64;i++){if(t.kind!=='ref')return t;t=this.descriptor.named[t.name];if(!t)throw Error('wire reference');}throw Error('wire reference cycle');}
 validateValue(value,options=wireDefaultOptions){wireCheckValue(this.#valuePlan,value,wireLimits(options));return true;}
 capture(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#capturePlan??=wireCapturePlan(this.#valuePlan);return this.#capturePlan.capture(value,new WireCaptureCursor(limits),0);}
 copy(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#copyPlan??=wireCapturePlan(this.#valuePlan,false);return this.#copyPlan.capture(value,new WireCaptureCursor(limits),0);}
 compact(){return this.#compactCodec??=new CompactValueCodec(this);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new WireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.bytes(this.#header);wireEncodeValue(this.#valuePlan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new WireEncoder(options);w.bytes(wireMagic);w.bytes(this.#hash);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 scan(bytes,options=wireDefaultOptions,materialize=false,visitor=null,names=null,spans=false){
  const l=wireLimits(options);if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<44||bytes.length>l.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==this.#headerWords[i])throw Error('wire format or schema mismatch');
  if(names!==null&&(!Array.isArray(names)||names.length>100000||names.some(n=>typeof n!=='string')))throw Error('wire visitor names');
  if(materialize&&!visitor){this.#decodeBound||=wireBindDecodePlan(this.#valuePlan);const cursor=new WireDecodeCursor(bytes,view,l);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#valuePlan.decode(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  if(!materialize){this.#scanPlan??=wireScanPlan(this.#valuePlan);const cursor=new WireScanCursor(bytes,view,l,visitor,names===null?null:new Set(names),spans),value=this.#scanPlan.scan(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  return wireScanValue(this.#valuePlan,bytes,view,l,materialize,visitor,names===null?null:new Set(names),spans);
 }
 visit(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names);}
 visitSpans(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names,true);}
 validate(bytes,options=wireDefaultOptions){this.scan(bytes,options,false);return true;}
 decode(bytes,options=wireDefaultOptions){return this.scan(bytes,options,true);}
}

// Bounded forward emission avoids building and repeatedly joining child buffers.
class WireEncoder{
 #data=new Uint8Array(256);#view=new DataView(this.#data.buffer);#at=0;#remaining;#depth=0;#byteLimit;#depthLimit;
 active=false;
 constructor(options){this.reset(options);}
 reset(options){const limits=wireLimits(options);this.#byteLimit=limits.bytes;this.#depthLimit=limits.depth;this.#remaining=limits.nodes;this.#depth=0;this.#at=0;this.active=true;}
 get capacity(){return this.#data.length;}
 get position(){return this.#at;}
 beginNode(){const at=this.#at;this.word(0);return at;}
 endNode(at){this.patchWord(at,this.#at-at-4);}
 count(n){this.word(n);}
 beginCount(){const at=this.position;this.count(0);return at;}
 endCount(at,n){this.patchWord(at,n);}
 #reserve(size){
  const end=this.#at+size;if(end>this.#byteLimit)throw Error('wire byte limit');
  if(end>this.#data.length){const next=new Uint8Array(Math.min(this.#byteLimit,Math.max(end,this.#data.length*2)));next.set(this.#data.subarray(0,this.#at));this.#data=next;this.#view=new DataView(next.buffer);}
  return end;
 }
 bytes(bytes){const end=this.#reserve(bytes.length);this.#data.set(bytes,this.#at);this.#at=end;}
 byte(n){if(!Number.isInteger(n)||n<0||n>255)throw Error('wire byte range');this.#reserve(1);this.#data[this.#at++]=n;}
 word(n){if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire word range');const end=this.#reserve(4);this.#view.setUint32(this.#at,n,true);this.#at=end;}
 wide(n){if(typeof n!=='bigint'||n<0n||n>18446744073709551615n)throw Error('wire wide range');const end=this.#reserve(8);this.#view.setBigUint64(this.#at,n,true);this.#at=end;}
 text(text,count=false){
  if(typeof text!=='string')throw Error('wire Unicode');
  if(text.length<=16){
   let ascii=true;for(let i=0;i<text.length;i++)if(text.charCodeAt(i)>=128){ascii=false;break;}
   if(ascii){if(count)this.count(text.length);const end=this.#reserve(text.length);for(let i=0;i<text.length;i++)this.#data[this.#at+i]=text.charCodeAt(i);this.#at=end;return;}
  }
  if(!text.isWellFormed())throw Error('wire Unicode');const size=wireUtf8Length(text);if(count)this.count(size);
  const end=this.#reserve(size),r=wireEncoder.encodeInto(text,this.#data.subarray(this.#at,end));if(r.read!==text.length||r.written!==size)throw Error('wire UTF-8 size');this.#at=end;
 }
 patchWord(at,n){if(!Number.isInteger(at)||at<0||at+4>this.#at||!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire patch offset');this.#view.setUint32(at,n,true);}
 patchByte(at,n){if(!Number.isInteger(at)||at<0||at>=this.#at||!Number.isInteger(n)||n<0||n>255)throw Error('wire patch offset');this.#data[at]=n;}
 replace(at,removed,bytes){
  if(!Number.isInteger(at)||!Number.isInteger(removed)||at<0||removed<0||at+removed>this.#at||!(bytes instanceof Uint8Array))throw Error('wire replacement range');
  const extra=bytes.length-removed,end=extra>0?this.#reserve(extra):this.#at+extra;
  this.#data.copyWithin(at+bytes.length,at+removed,this.#at);this.#data.set(bytes,at);this.#at=end;
 }
 // Literal generated writers use balanced frames without per-node callbacks.
 // An exception abandons this invocation; encodeWith never reuses its writer.
 openFrame(){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;return at;}
 closeFrame(at){if(this.#depth===0)throw Error('wire frame boundary');this.#depth--;this.endNode(at);}
 frame(emit){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;try{emit(this);}finally{this.#depth--;}this.endNode(at);}
 reorder(start,spans){
  const sorted=spans.slice().sort((a,b)=>a[0]-b[0]);let at=start;
  for(const [a,b] of sorted){if(!Number.isInteger(a)||!Number.isInteger(b)||a!==at||b<a)throw Error('wire span permutation');at=b;}
  if(start<0||start>this.#at||at!==this.#at)throw Error('wire span permutation');
  if(spans.every((s,i)=>s===sorted[i]))return;
  const copy=this.#data.slice(start,this.#at);at=start;for(const [a,b] of spans){this.#data.set(copy.subarray(a-start,b-start),at);at+=b-a;}
 }
 finish(){if(this.#depth!==0)throw Error('wire frame boundary');return this.#data.slice(0,this.#at);}
}

class CompactWireEncoder extends WireEncoder{
 beginNode(){return 0;}
 endNode(){}
 endCount(at,n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  if(n<128){this.patchByte(at,n);return;}
  const bytes=[];while(n>=128){bytes.push(n%128+128);n=Math.floor(n/128);}bytes.push(n);this.replace(at,1,Uint8Array.from(bytes));
 }
 count(n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  while(n>=128){this.byte(n%128+128);n=Math.floor(n/128);}this.byte(n);
 }
 text(text){super.text(text,true);}
}

function compactScanValue(root,bytes,l,materialize){
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let cursor=1,remaining=l.nodes;
 const require=n=>{if(n>bytes.length-cursor)throw Error('truncated compact value');};
 const count=()=>{
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   require(1);const byte=bytes[cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }throw Error('compact count overflow');
 };
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,d)=>{
  if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type;let value;
  switch(p.kind){
   case 'unit':return null;
   case 'bool':require(1);if(bytes[cursor]>1)throw Error('invalid wire Bool');return !!bytes[cursor++];
   case 'u32':case 'i32':require(4);value=p.kind==='u32'?view.getUint32(cursor,true):view.getInt32(cursor,true);cursor+=4;return value;
   case 'f32':require(4);if(materialize)value={F32Bits:view.getUint32(cursor,true)};cursor+=4;return value;
   case 'f64':require(8);if(materialize)value={F64Bits:view.getBigUint64(cursor,true).toString()};cursor+=8;return value;
   case 'u64':require(8);if(materialize)value=view.getBigUint64(cursor,true);cursor+=8;return value;
   case 'string':case 'int':case 'id':case 'enum':{
    const n=count();require(n);const start=cursor;cursor+=n;
    if(p.kind==='string'&&!materialize){let i=start;while(i<cursor&&bytes[i]<128)i++;if(i<cursor)wireDecoder.decode(bytes.subarray(start,cursor));}
    else{const text=wireDecodeText(bytes,start,cursor);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    return value;
   }
   case 'list':case 'vector':{
    const n=count();if(n>remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,d+1);if(materialize)value.push(child);}return value;
   }
   case 'record':{
    const fs=p.fields;
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:return {};case 1:return {[fs[0].name]:node(fs[0].plan,d+1)};case 2:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1)};case 3:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1)};case 4:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1),[fs[3].name]:node(fs[3].plan,d+1)};}
    }
    if(materialize)value={};for(const f of fs){const child=node(f.plan,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}return value;
   }
   case 'option':case 'result':{
    require(1);const tag=bytes[cursor++];if(tag>1)throw Error('wire sum tag');
    if(p.kind==='option'&&tag===0)return materialize?{None:null}:undefined;
    const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,d+1);
    return materialize?{[label]:child}:undefined;
   }
   default:throw Error('unsupported wire kind');
  }
 };
 const value=node(root,0);if(cursor!==bytes.length)throw Error('trailing compact bytes');return value;
}

// General transport codec, independent of source rewrites and checkpoints.
// The sender/receiver must negotiate this exact identity and format. There is
// deliberately no claim that the bytes themselves identify their schema.
export class CompactValueCodec{
 #source;#plan;#encoder;#decodeBound=0;
 get format(){return compactValueWireFormat;}
 get identity(){return this.#source.descriptor.identity;}
 constructor(valueCodec){if(!(valueCodec instanceof ValueCodec))throw Error('compact codec requires a checked value codec');this.#source=valueCodec;this.#plan=wireValuePlan(valueCodec);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new CompactWireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.byte(1);wireEncodeValue(this.#plan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new CompactWireEncoder(options);w.byte(1);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 #scan(bytes,options,materialize){
  const l=wireLimits(options);
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<1||bytes.length>l.bytes)throw Error('wire byte limit or header');
  if(bytes[0]!==1)throw Error('compact format mismatch');
  if(materialize){this.#decodeBound||=wireBindDecodePlan(this.#plan,true);const cursor=new CompactDecodeCursor(bytes,l,this.#decodeBound);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#plan.decodeCompact(cursor,0);if(cursor.cursor!==bytes.length)throw Error('trailing compact bytes');return value;}
  return compactScanValue(this.#plan,bytes,l,materialize);
 }
 decode(bytes,options=wireDefaultOptions){return this.#scan(bytes,options,true);}
 validate(bytes,options=wireDefaultOptions){this.#scan(bytes,options,false);return true;}
}

// Compiler materialisers consume already validated bytes synchronously. This
// factory is for trusted emitted code, not untrusted descriptor/callback data.
// The complete generic validator runs before any compiler reader is invoked.
class ValidatedValueReader{
 constructor(bytes,compact){this.bytes=bytes;this.view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);this.cursor=compact?1:40;this.compact=compact;}
 frame(){if(this.compact)return 0;const end=this.cursor+4+this.view.getUint32(this.cursor,true);this.cursor+=4;return end;}
 finish(end){if(!this.compact&&this.cursor!==end)throw Error('compiled reader frame mismatch');}
 byte(){return this.bytes[this.cursor++];}
 word(){const n=this.view.getUint32(this.cursor,true);this.cursor+=4;return n;}
 signed(){const n=this.view.getInt32(this.cursor,true);this.cursor+=4;return n;}
 wide(){const n=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return n;}
 count(){if(!this.compact)return this.word();let n=0,scale=1,byte;do{byte=this.byte();n+=(byte&127)*scale;scale*=128;}while(byte>=128);return n;}
 text(end){const n=this.compact?this.count():end-this.cursor,start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
class CompiledCompactValueCodec extends CompactValueCodec{
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,true),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
}
class CompiledValueCodec extends ValueCodec{
 #read;#compiledCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,false),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
 compact(){return this.#compiledCompact??=new CompiledCompactValueCodec(this,this.#read);}
}
export function createCompiledValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new CompiledValueCodec(descriptor,read);}

// Trusted literal materialisers may use this checked reader to validate and
// construct in one traversal. The emitter must use frame/finish at every source
// node, typed text reads and counted sequence reads; arbitrary callbacks do not
// establish a schema correspondence proof. The independent scanner remains the
// validation oracle and the original factory retains its pre-validation path.
function literalValueHeader(identity){
 const bytes=new Uint8Array(40);bytes.set(wireMagic);
 for(let i=0;i<32;i++)bytes[i+8]=parseInt(identity.slice(i*2,i*2+2),16);
 const view=new DataView(bytes.buffer),words=new Uint32Array(10);
 for(let i=0;i<10;i++)words[i]=view.getUint32(i*4,true);
 return words;
}
class CheckedLiteralValueReader {
 constructor(bytes,header,compact,limits){
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<(compact?1:44)||bytes.length>limits.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  if(compact){if(bytes[0]!==1)throw Error('compact format mismatch');}
  else for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==header[i])throw Error('wire format or schema mismatch');
  this.bytes=bytes;this.view=view;
  this.cursor=compact?1:40;this.compact=compact;this.remaining=limits.nodes;this.depth=limits.depth;this.ends=[];
 }
 require(n){if(this.cursor+n>(this.ends.at(-1)??this.bytes.length))throw Error('truncated wire frame');}
 frame(){
  if(this.ends.length>this.depth||--this.remaining<0)throw Error('wire node or depth limit');
  let end=this.bytes.length;
  if(!this.compact){this.require(4);end=this.cursor+4+this.view.getUint32(this.cursor,true);this.require(end-this.cursor);this.cursor+=4;}
  this.ends.push(end);return this.compact?0:end;
 }
 finish(end){
  if(!this.ends.length||!this.compact&&(this.ends.at(-1)!==end||this.cursor!==end))throw Error('compiled reader frame mismatch');
  this.ends.pop();
 }
 byte(){this.require(1);const value=this.bytes[this.cursor++];if(value>1)throw Error('wire sum tag or Bool');return value;}
 word(){this.require(4);const value=this.view.getUint32(this.cursor,true);this.cursor+=4;return value;}
 signed(){this.require(4);const value=this.view.getInt32(this.cursor,true);this.cursor+=4;return value;}
 wide(){this.require(8);const value=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return value;}
 rawCount(){
  if(!this.compact)return this.word();
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   this.require(1);const byte=this.bytes[this.cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }
  throw Error('compact count overflow');
 }
 count(size){
  const value=this.rawCount();
  if(value>this.remaining||size!==undefined&&value!==size)throw Error('wire sequence size');
  return value;
 }
 text(end,kind='string',variants){
  const size=this.compact?this.rawCount():end-this.cursor;
  this.require(size);const start=this.cursor;this.cursor+=size;
  const value=wireDecodeText(this.bytes,start,this.cursor);
  if(kind==='int'&&!wireDecimal(value)||kind==='id'&&!/^[0-9a-f]{32}$/.test(value)||kind==='enum'&&!variants.includes(value))throw Error('malformed wire text');
  return value;
 }
 complete(){if(this.ends.length||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
// Compact source nodes have no individual frame ends: retain the same checked
// depth/node order using a counter, with bounds against the complete buffer.
class CheckedCompactLiteralValueReader extends CheckedLiteralValueReader {
 constructor(bytes,limits){super(bytes,null,true,limits);this.level=0;}
 require(n){if(this.cursor+n>this.bytes.length)throw Error('truncated wire frame');}
 frame(){if(this.level>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.level++;return 0;}
 finish(_end){if(!this.level)throw Error('compiled reader frame mismatch');this.level--;}
 complete(){if(this.level||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
class FusedCompactValueCodec extends CompactValueCodec {
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedCompactLiteralValueReader(bytes,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
}
class FusedValueCodec extends ValueCodec {
 #read;#header;#fusedCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;this.#header=literalValueHeader(this.descriptor.identity);}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedLiteralValueReader(bytes,this.#header,false,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
 compact(){return this.#fusedCompact??=new FusedCompactValueCodec(this,this.#read);}
}
export function createFusedValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new FusedValueCodec(descriptor,read);}
// JSON text is a boundary adapter to an ordinary recursive Ink datatype.
// No JavaScript Number conversion occurs for JSON numeric tokens.
export function jsonNumberToken(s){return typeof s==='string'&&/^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/.test(s);}
// JSON numeric tokens have an ASCII grammar. Check validated UTF-8 spans
// directly, preserving exact lexemes without allocating a decoded String.
function jsonNumberSpan(bytes,lo,hi){
 let at=lo;if(bytes[at]===45)at++;
 if(at>=hi)return false;
 if(bytes[at]===48)at++;
 else{if(bytes[at]<49||bytes[at]>57)return false;do{at++;}while(at<hi&&bytes[at]>=48&&bytes[at]<=57);}
 if(at<hi&&bytes[at]===46){const start=++at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 if(at<hi&&(bytes[at]===69||bytes[at]===101)){at++;if(at<hi&&(bytes[at]===43||bytes[at]===45))at++;const start=at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 return at===hi;
}
const jsonWireEncoder=new TextEncoder();
// Scalar conversion completes before writer callbacks; no per-value byte array.
const jsonFloatScratch=new DataView(new ArrayBuffer(4));
function jsonUtf8Length(text){if(text.length>16&&!/[^\x00-\x7f]/.test(text))return text.length;let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const jsonLimits={bytes:16777216,nodes:1000000,depth:128};
const jsonQuoters=new WeakSet();
/** Explicit, bounded reuse of immutable JSON string quotes. Cache payload bytes
 * are UTF-16 storage estimates; entry caps bound separate Map/object overhead.
 * Logical output budgets are charged again on every use, including cache hits.
 */
export function createJsonQuoter({maxEntries=1024,maxBytes=131072}={}){
 if(!Number.isSafeInteger(maxEntries)||maxEntries<0||maxEntries>65536||!Number.isSafeInteger(maxBytes)||maxBytes<0||maxBytes>16777216)throw Error('JSON quote cache budget');
 const entries=new Map();let bytes=0,hits=0,misses=0;
 const token=value=>{
  const prior=entries.get(value);if(prior!==undefined){hits++;return prior;}
  if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid JSON String');
  misses++;const text=JSON.stringify(value),size=2*(value.length+text.length),quoted=Object.freeze({text,utf8Bytes:jsonUtf8Length(text)});
  if(maxEntries&&size<=maxBytes){
   while(entries.size&&(entries.size>=maxEntries||bytes+size>maxBytes)){const key=entries.keys().next().value;bytes-=2*(key.length+entries.get(key).text.length);entries.delete(key);}
   entries.set(value,quoted);bytes+=size;
  }
  return quoted;
 };
 const quoter=Object.freeze({
  token,
  quote(value){return token(value).text;},
  clear(){entries.clear();bytes=0;},
  stats(){return {entries:entries.size,payload_bytes:bytes,hits,misses};},
 });jsonQuoters.add(quoter);return quoter;
}
function checkedJsonLimits(options){const l={...jsonLimits,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>jsonLimits[k])throw Error('JSON hard resource limit');return l;}
function jsonVariant(index,item){let payload=index===0?{}:{item0:item};if(index<5)payload={Ok:payload};for(let i=0;i<index;i++)payload={Err:payload};return {payload};}
export function parseJson(text,options={}){return parseJsonValue(text,options,null);}
function parseJsonValue(text,options,boundary){
 const p=new JsonWireReader(text,options);
 const value=(d,wireDepth=0)=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){boundary?.node(0,wireDepth);p.at+=4;return jsonVariant(0,null);}if(c==='t'&&text.startsWith('true',p.at)){boundary?.node(1,wireDepth);p.at+=4;return jsonVariant(1,true);}if(c==='f'&&text.startsWith('false',p.at)){boundary?.node(1,wireDepth);p.at+=5;return jsonVariant(1,false);}
  if(c==='"'){boundary?.node(3,wireDepth);const item=p.string();boundary?.text(item);return jsonVariant(3,item);}
  if(c==='['){boundary?.node(4,wireDepth);p.at++;const xs=[];if(!p.eat(']'))while(true){xs.push(value(d+1,wireDepth+8));if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}return jsonVariant(4,xs);}
  if(c==='{'){boundary?.node(5,wireDepth);p.at++;const xs=[],seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary?.member(key,wireDepth);if(!p.eat(':'))throw Error('JSON object colon');xs.push({key,value:value(d+1,wireDepth+9)});if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}return jsonVariant(5,xs);}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();boundary?.node(2,wireDepth);boundary?.text(token);return jsonVariant(2,token);}
  throw Error('invalid JSON value');
 };
 const out=value(0);p.finish();return out;
}
export function stringifyJson(value,options={}){return stringifyJsonValue(value,options,null);}
function stringifyJsonValue(value,options,boundary){
 const l=checkedJsonLimits(options);let remaining=l.nodes,bytes=0,output='';
 const emit=s=>{bytes+=jsonUtf8Length(s);if(bytes>l.bytes)throw Error('JSON byte limit');output+=s;};
 const write=(v,d,wireDepth=0)=>{
  if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');if(!v||Object.keys(v).length!==1||!Object.hasOwn(v,'payload'))throw Error('invalid JSON record');let p=v.payload,index=0;
  while(index<5&&p&&Object.hasOwn(p,'Err')){if(Object.keys(p).length!==1||boundary&&Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Err;index++;}
  if(index<5){if(!p||Object.keys(p).length!==1||!Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Ok;}
  if(!p||Object.keys(p).length!==(index===0?0:1)||index>0&&!Object.hasOwn(p,'item0'))throw Error('invalid JSON payload');const item=p.item0;boundary?.node(index,wireDepth);
  switch(index){
   case 0:emit('null');break;
   case 1:if(typeof item!=='boolean')throw Error('invalid JSON Boolean');emit(item?'true':'false');break;
   case 2:if(!jsonNumberToken(item))throw Error('invalid JSON number');boundary?.text(item);emit(item);break;
   case 3:if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary?.text(item);emit(JSON.stringify(item));break;
   case 4:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Array');const count=item.length;let visited=0;emit('[');item.forEach((x,i)=>{visited++;if(i)emit(',');write(x,d+1,wireDepth+8);});if(visited!==count)throw Error('invalid JSON Array');emit(']');break;}
   case 5:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Object');const count=item.length,seen=new Set();let visited=0;emit('{');item.forEach((m,i)=>{visited++;if(!m||Object.keys(m).length!==2||typeof m.key!=='string'||!m.key.isWellFormed()||!Object.hasOwn(m,'value')||boundary&&!Object.hasOwn(m,'key'))throw Error('invalid JSON member');if(seen.has(m.key))throw Error('duplicate JSON object key');seen.add(m.key);boundary?.member(m.key,wireDepth);if(i)emit(',');emit(JSON.stringify(m.key));emit(':');write(m.value,d+1,wireDepth+9);});if(visited!==count)throw Error('invalid JSON Object');emit('}');break;}
  }
 };write(value,0);return output;
}
// The adapter's schema is the fixed recursive JSON library shape checked by
// JsonCodec. Charge its ordinary record/sum/list wire nodes while parsing or
// rendering, rather than interpreting and walking the completed tree again.
function jsonBoundaryBudget(options){
 const l=checkedJsonLimits(options);let remaining=l.nodes,total=40;
 const charge=(nodes,bytes,depth)=>{remaining-=nodes;total+=bytes;if(remaining<0||depth>l.depth)throw Error('wire node or depth limit');if(total>l.bytes)throw Error('wire byte limit');};
 return {
  node(index,depth){charge(index===0?3:index<4?index+4:8,index===0?13:index===1?23:index===2?27:index===3?32:41,depth+(index===0?2:index<4?index+3:7));},
  text(text){charge(0,jsonUtf8Length(text),0);},
  member(key,depth){charge(2,8+jsonUtf8Length(key),depth+9);},
 };
}
function jsonSameSchema(a,b){
 if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;
 const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>Object.hasOwn(b,k)&&jsonSameSchema(a[k],b[k]));
}
// Host-object conversion is opt-in and JavaScript-only. Inspect data properties
// rather than invoking getters/toJSON; reflection is not a sandbox for proxies.
function jsonJSKeys(value){
 if(!value||typeof value!=='object')throw Error('expected a plain JavaScript object');
 const prototype=Object.getPrototypeOf(value);
 if(prototype!==Object.prototype&&prototype!==null)throw Error('expected a plain JavaScript object');
 const keys=Reflect.ownKeys(value);
 if(keys.some(k=>typeof k!=='string'))throw Error('JavaScript symbol keys are unsupported');
 return keys;
}
function jsonJSData(value,key){
 const property=Object.getOwnPropertyDescriptor(value,key);
 if(!property||!property.enumerable||!Object.hasOwn(property,'value'))throw Error('expected an enumerable own data property');
 return property.value;
}
function jsonJSRecord(value,names){
 const keys=jsonJSKeys(value);
 if(keys.length!==names.length||keys.some(k=>!names.includes(k)))throw Error('invalid JSON record or variant');
}
function jsonJSArray(value,remaining){
 if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype)throw Error('expected a plain JavaScript array');
 const length=value.length;
 if(length>remaining)throw Error('JSON node limit');
 const keys=Reflect.ownKeys(value);
 if(keys.length!==length+1||keys.some(k=>typeof k!=='string'||k!=='length'&&(!/^(0|[1-9][0-9]*)$/.test(k)||Number(k)>=length)))throw Error('sparse or decorated JavaScript arrays are unsupported');
 return length;
}
function jsonFromJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),active=new WeakSet();let remaining=limits.nodes;
 const text=value=>{if(!value.isWellFormed())throw Error('invalid JSON Unicode');boundary.text(value);return value;};
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  if(value===null){boundary.node(0,wireDepth);return jsonVariant(0);}
  switch(typeof value){
   case 'boolean':boundary.node(1,wireDepth);return jsonVariant(1,value);
   case 'string':boundary.node(3,wireDepth);return jsonVariant(3,text(value));
   case 'number':
    if(!Number.isFinite(value))throw Error('non-finite JavaScript numbers are unsupported');
    boundary.node(2,wireDepth);return jsonVariant(2,text(Object.is(value,-0)?'-0':String(value)));
   case 'bigint':boundary.node(2,wireDepth);return jsonVariant(2,text(String(value)));
   case 'object':break;
   default:throw Error('unsupported JavaScript value');
  }
  if(active.has(value))throw Error('cyclic JavaScript value');
  active.add(value);
  try{
   if(Array.isArray(value)){
    boundary.node(4,wireDepth);const count=jsonJSArray(value,remaining),items=[];
    for(let i=0;i<count;i++)items.push(visit(jsonJSData(value,String(i)),depth+1,wireDepth+8));
    return jsonVariant(4,items);
   }
   boundary.node(5,wireDepth);const keys=jsonJSKeys(value),members=[];
   if(keys.length>remaining)throw Error('JSON node limit');
   for(const key of keys){
    if(!key.isWellFormed())throw Error('invalid JSON Unicode');
    boundary.member(key,wireDepth);
    members.push({key,value:visit(jsonJSData(value,key),depth+1,wireDepth+9)});
   }
   return jsonVariant(5,members);
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
function jsonDecimalKey(token){
 const [,sign,whole,fraction='',exponent='0']=/^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(token);
 const digits=(whole+fraction).replace(/^0+/,'');
 if(!digits)return '0';
 const trimmed=digits.replace(/0+$/,'');
 return sign+trimmed+'e'+(Number(exponent)-fraction.length+digits.length-trimmed.length);
}
function jsonToJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),mode=options?.numbers??'number',active=new WeakSet();let remaining=limits.nodes;
 if(!['number','bigint','string'].includes(mode))throw Error('unknown JavaScript number policy');
 const number=token=>{
  if(!jsonNumberToken(token))throw Error('invalid JSON number');
  boundary.text(token);
  if(mode==='string')return token;
  if(mode==='bigint')return BigInt(jsonInteger(token,4096));
  const result=Number(token);
  if(!Number.isFinite(result)||jsonDecimalKey(token)!==jsonDecimalKey(String(result)))throw Error('JSON number loses precision as JavaScript Number; choose numbers: bigint or string');
  return result;
 };
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  jsonJSRecord(value,['payload']);
  if(active.has(value))throw Error('cyclic JSON value');
  active.add(value);
  try{
   let payload=jsonJSData(value,'payload'),index=0;
   while(index<5&&Object.hasOwn(payload,'Err')){jsonJSRecord(payload,['Err']);payload=jsonJSData(payload,'Err');index++;}
   if(index<5){jsonJSRecord(payload,['Ok']);payload=jsonJSData(payload,'Ok');}
   jsonJSRecord(payload,index===0?[]:['item0']);boundary.node(index,wireDepth);
   const item=index===0?null:jsonJSData(payload,'item0');
   if(index===0)return null;
   if(index===1){if(typeof item!=='boolean')throw Error('invalid JSON Boolean');return item;}
   if(index===2)return number(item);
   if(index===3){if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary.text(item);return item;}
   const count=jsonJSArray(item,remaining);
   if(index===4){const out=[];for(let i=0;i<count;i++)out.push(visit(jsonJSData(item,String(i)),depth+1,wireDepth+8));return out;}
   const out={},seen=new Set();
   for(let i=0;i<count;i++){
    const member=jsonJSData(item,String(i));jsonJSRecord(member,['key','value']);const key=jsonJSData(member,'key');
    if(typeof key!=='string'||!key.isWellFormed())throw Error('invalid JSON member key');
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary.member(key,wireDepth);
    Object.defineProperty(out,key,{value:visit(jsonJSData(member,'value'),depth+1,wireDepth+9),enumerable:true,writable:true,configurable:true});
   }
   return out;
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
const jsonConstructionPaths=Object.freeze(Array.from({length:6},(_,index)=>Object.freeze([0,...Array(index).fill(1),...(index<5?[0]:[]),0])));
function parseJsonConstructed(text,options,builder){
 const p=new JsonWireReader(text,options);
 const paths=jsonConstructionPaths;
 const fused=typeof builder.openPath==='function';
 const begin=index=>{if(fused){builder.openPath(paths[index]);return;}for(const choice of paths[index])builder.open(choice);};
 const end=index=>{for(let i=0;i<(fused?1:index<5?index+3:7);i++)builder.close();};
 const leaf=(index,item)=>{if(typeof builder.scalarPath==='function'){builder.scalarPath(paths[index],item);return;}begin(index);builder.scalar(item);end(index);};
 const value=d=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){p.at+=4;if(typeof builder.emptyPath==='function')builder.emptyPath(paths[0]);else{begin(0);end(0);}return;}
  if(c==='t'&&text.startsWith('true',p.at)){p.at+=4;leaf(1,true);return;}
  if(c==='f'&&text.startsWith('false',p.at)){p.at+=5;leaf(1,false);return;}
  if(c==='"'){leaf(3,p.string());return;}
  if(c==='['){begin(4);builder.open(0);p.at++;if(!p.eat(']'))while(true){value(d+1);if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}builder.close();end(4);return;}
  if(c==='{'){begin(5);builder.open(0);p.at++;const seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');builder.open(0);builder.scalar(key);value(d+1);builder.close();if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}builder.close();end(5);return;}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();leaf(2,token);return;}
  throw Error('invalid JSON value');
 };
 value(0);p.finish();return builder.finish();
}
const jsonCompiledRenderers=new WeakMap();
function compiledJsonRenderer(json,codec,unwrap){
 if(typeof codec?.reducer!=='function')throw Error('compiled JSON reduction unavailable');
 const source=codec.resolve(codec.descriptor.root),root=json.values.descriptor.root;
 const selected=unwrap&&source.kind==='result'?codec.resolve(source.ok):source;
 if(!jsonSameSchema(root,selected)||unwrap&&source.kind!=='result')throw Error('compiled JSON schema mismatch');
 let variants=root.fields[0].type;const roles=new Map([[root.name,'root']]);
 let member;
 for(let index=0;index<6;index++){
  const branch=index<5?variants.ok:variants;roles.set(branch.name,index);
  if(index===5){member=branch.fields[0].type.element.name;roles.set(member,'member');}
  if(index<5)variants=variants.error;
 }
 const nodeRoles=new Map();
 return codec.reducer((node,index)=>{
  const role=roles.get(node.name);nodeRoles.set(index,role);
  if(node.kind==='record'){
   if(role==='root')return value=>value;
   if(role==='member')return (key,value,context)=>{
    const text=(context.quoter?context.quote(key,true):context.add(JSON.stringify(key)+':'))+value,seen=context.members;
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);return text;
   };
   if(role===0)return context=>context.add('null');
   if(role===1)return (value,context)=>context.add(value?'true':'false');
   if(role===2)return (token,context)=>{if(!jsonNumberToken(token))throw Error('invalid JSON number');return context.add(token);};
   if(role===3)return (value,context)=>context.quoter?context.quote(value,false):context.add(JSON.stringify(value));
   if(role===4)return (value,context)=>{context.add('[]');return '['+value+']';};
   if(role===5)return (value,context)=>{context.add('{}');return '{'+value+'}';};
   return ()=>null;
  }
  if(node.kind==='list'||node.kind==='vector'){
   const members=nodeRoles.get(node.children[0])==='member';
   return {
    start:(_length,context)=>{
     const out={text:'',parent:members?context.members:null};
     if(members)context.members=new Set();return out;
    },
    step:(out,value,index,context)=>{out.text+=(index?context.add(','):'')+value;return out;},
    finish:(out,context)=>{if(members)context.members=out.parent;return out.text;},
   };
  }
  if(node.kind==='result'){
   // A Result<Json,E> boundary is explicitly requested by the caller. Ordinary
   // JSON's own sums only propagate an already rendered branch.
   if(unwrap&&nodeRoles.get(node.children[0])==='root')return (tag,value)=>{if(tag)throw Error('JSON result is Err');return value;};
   return (_tag,value)=>value;
  }
  if(node.kind==='string')return value=>{if(!value.isWellFormed())throw Error('invalid JSON String');return value;};
  return value=>value;
 });
}
export class JsonCodec{
 constructor(valueCodec){
  const root=valueCodec.descriptor.root,fields=root.fields;if(root.kind!=='record'||!Array.isArray(fields)||fields.length!==1||fields[0].name!=='payload')throw Error('JSON schema payload');let sum=fields[0].type;
  for(let i=0;i<6;i++){
   if(i<5&&sum.kind!=='result')throw Error('JSON schema sum');const branch=i<5?sum.ok:sum,fs=branch.fields;
   if(branch.kind!=='record'||!Array.isArray(fs)||fs.length!==(i?1:0)||i&&fs[0].name!=='item0')throw Error('JSON schema branch');
   if(i){const t=fs[0].type;if(i===1&&t.kind!=='bool'||(i===2||i===3)&&t.kind!=='string'||i===4&&(t.kind!=='list'||t.element.kind!=='ref'||t.element.name!==root.name))throw Error('JSON schema variant');if(i===5){const mf=t.element?.fields;if(t.kind!=='list'||t.element?.kind!=='record'||!Array.isArray(mf)||mf.length!==2||mf[0].name!=='key'||mf[0].type.kind!=='string'||mf[1].name!=='value'||mf[1].type.kind!=='ref'||mf[1].type.name!==root.name)throw Error('JSON schema member');}}
   if(i===2)this.numberBranch=branch.name;if(i===5)this.objectBranch=branch.name;
   if(i<5)sum=sum.error;
  }if(!jsonSameSchema(root,valueCodec.resolve({kind:'ref',name:root.name})))throw Error('JSON recursive schema mismatch');this.values=valueCodec;
 }
 parse(text,options={}){return parseJsonValue(text,options,jsonBoundaryBudget(options));}
 parseCompiled(codec,text,options={}){
  if(codec?.identity!==this.values.descriptor.identity||typeof codec.builder!=='function')throw Error('compiled JSON schema mismatch');
  const builder=codec.builder(options);try{return parseJsonConstructed(text,options,builder);}catch(error){builder.abort();throw error;}
 }
 stringify(value,options={}){return stringifyJsonValue(value,options,jsonBoundaryBudget(options));}
 stringifyCompiled(codec,handle,options={}){
  const limits=checkedJsonLimits(options),unwrap=options.unwrapResult===true;
  const quoter=options.quoter;if(quoter!==undefined&&!jsonQuoters.has(quoter))throw Error('JSON quote cache owner mismatch');
  let codecs=jsonCompiledRenderers.get(this);if(!codecs)jsonCompiledRenderers.set(this,codecs=new WeakMap());
  let renderers=codecs.get(codec);if(!renderers)codecs.set(codec,renderers=new Map());
  let render=renderers.get(unwrap);if(!render)renderers.set(unwrap,render=compiledJsonRenderer(this,codec,unwrap));
  let bytes=0;const context={
   quoter,
   add(text){bytes+=jsonUtf8Length(text);if(bytes>limits.bytes)throw Error('JSON byte limit');return text;},
   quote(value,colon){
    if(!quoter)return this.add(JSON.stringify(value)+(colon?':':''));
    const token=quoter.token(value);bytes+=token.utf8Bytes+(colon?1:0);if(bytes>limits.bytes)throw Error('JSON byte limit');return token.text+(colon?':':'');
   },
  };
  const text=render(handle,context,limits);
  return text;
 }
 fromJS(value,options={}){return jsonFromJS(value,options);}
 toJS(value,options={}){return jsonToJS(value,options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,false);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,false,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,true);}
 validateBinary(bytes,options={}){
  const decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});let view;
  this.values.visitSpans(bytes,(type,data,start,end)=>{
   view??=new DataView(data.buffer,data.byteOffset,data.byteLength);
   if(type.name===this.numberBranch){const length=view.getUint32(start,true);if(!jsonNumberSpan(data,start+4,start+4+length))throw Error('invalid JSON number token');}
   if(type.name===this.objectBranch){const listEnd=start+4+view.getUint32(start,true),count=view.getUint32(start+4,true),seen=new Set();let at=start+8;for(let i=0;i<count;i++){const memberEnd=at+4+view.getUint32(at,true),keyStart=at+8,keyEnd=keyStart+view.getUint32(at+4,true),key=decoder.decode(data.subarray(keyStart,keyEnd));if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);at=memberEnd;}if(at!==listEnd)throw Error('invalid JSON object frame');}
  },options,[this.numberBranch,this.objectBranch]);return true;

 }
}
function jsonUnpack(value){let p=value.payload,i=0;while(i<5&&Object.hasOwn(p,'Err')){p=p.Err;i++;}return [i,(i<5?p.Ok:p).item0];}
function jsonInteger(token,limit){
 if(!jsonNumberToken(token))throw Error('invalid JSON number');const negative=token[0]==='-',raw=negative?token.slice(1):token,[mantissa,exp='0']=raw.split(/[eE]/);let digits=mantissa.replace('.','');if(/^0+$/.test(digits))return '0';const exponent=Number(exp),fraction=mantissa.includes('.')?mantissa.length-mantissa.indexOf('.')-1:0,shift=exponent-fraction;
 if(!Number.isSafeInteger(exponent)||!Number.isSafeInteger(shift))throw Error('JSON integer exponent limit');
 if(shift<0){const cut=-shift;if(cut>=digits.length||!/^[0]+$/.test(digits.slice(-cut)))throw Error('JSON number is not an integer');digits=digits.slice(0,-cut);}else{if(digits.length+shift>limit)throw Error('JSON integer magnitude limit');digits+='0'.repeat(shift);}
 digits=digits.replace(/^0+/,'');if(digits.length>limit)throw Error('JSON integer magnitude limit');return (negative?'-':'')+digits;
}
function jsonBinary64Value(v){
 if(typeof v==='number')return v;
 const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid F64Bits');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');
 const b=new DataView(new ArrayBuffer(8));b.setBigUint64(0,bits,true);return b.getFloat64(0,true);
}
export class TypedJsonCodec{
 constructor(valueCodec){this.values=valueCodec;}
 decode(document,options={}){
  // Validate JSON-specific invariants before interpreting any tagged/record
  // shape, including duplicated names and malformed numeric tokens.
  stringifyJson(document,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const read=(type,value,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type),[kind,item]=jsonUnpack(value);const fail=()=>{throw Error('JSON does not match '+t.kind);};
   switch(t.kind){
    case 'unit':if(kind!==0)fail();return null;
    case 'bool':if(kind!==1)fail();return item;
    case 'u32':case 'u64':case 'i32':case 'int':{if(kind!==2)fail();const text=jsonInteger(item,t.kind==='int'?4096:t.kind==='u64'?20:10);return t.kind==='int'?{Int:text}:t.kind==='u64'?BigInt(text):Number(text);}
    case 'f64':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(8));if(!Number.isFinite(n))throw Error('JSON f64 overflow');b.setFloat64(0,n,true);return {F64Bits:b.getBigUint64(0,true).toString()};}
    case 'f32':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(4));b.setFloat32(0,n,true);if(!Number.isFinite(b.getFloat32(0,true)))throw Error('JSON f32 overflow');return {F32Bits:b.getUint32(0,true)};}
    case 'string':case 'enum':case 'id':if(kind!==3)fail();return item;
    case 'list':case 'vector':if(kind!==4)fail();return item.map(x=>read(t.element,x,d+1));
    case 'record':{if(kind!==5||item.length!==t.fields.length)throw Error('unknown or missing JSON record field');const fields=new Map(item.map(m=>[m.key,m.value])),out={};for(const f of t.fields){if(!fields.has(f.name))throw Error('missing JSON record field');Object.defineProperty(out,f.name,{value:read(f.type,fields.get(f.name),d+1),writable:true,enumerable:true,configurable:true});}return out;}
    case 'option':case 'result':{if(kind!==5||item.length!==1)fail();const m=item[0];if(t.kind==='option'&&m.key==='None'&&jsonUnpack(m.value)[0]===0)return {None:null};const child=t.kind==='option'&&m.key==='Some'?t.element:t.kind==='result'&&m.key==='Ok'?t.ok:t.kind==='result'&&m.key==='Err'?t.error:null;if(!child)fail();return {[m.key]:read(child,m.value,d+1)};}
    default:fail();
   }
  };
  const out=read(this.values.descriptor.root,document,0);this.values.validateValue(out,options);return out;
 }
 encode(value,options={}){
  this.values.validateValue(value,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const write=(type,v,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type);
   switch(t.kind){
    case 'unit':return jsonVariant(0);
    case 'bool':return jsonVariant(1,v);
    case 'u32':case 'u64':case 'i32':return jsonVariant(2,String(v));
    case 'int':return jsonVariant(2,typeof v==='bigint'?String(v):v.Int);
    case 'f64':{const n=jsonBinary64Value(v);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'f32':{let n;if(typeof v==='number')n=Math.fround(v);else{const b=new DataView(new ArrayBuffer(4));b.setUint32(0,v.F32Bits,true);n=b.getFloat32(0,true);}if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'string':case 'id':case 'enum':return jsonVariant(3,v);
    case 'list':case 'vector':return jsonVariant(4,Array.from(v,x=>write(t.element,x,d+1)));
    case 'record':return jsonVariant(5,t.fields.map(f=>({key:f.name,value:write(f.type,v[f.name],d+1)})));
    case 'option':return jsonVariant(5,[Object.hasOwn(v,'Some')?{key:'Some',value:write(t.element,v.Some,d+1)}:{key:'None',value:jsonVariant(0)}]);
    case 'result':return jsonVariant(5,[Object.hasOwn(v,'Ok')?{key:'Ok',value:write(t.ok,v.Ok,d+1)}:{key:'Err',value:write(t.error,v.Err,d+1)}]);
    default:throw Error('unsupported typed JSON descriptor');
   }
  };return write(this.values.descriptor.root,value,0);
 }
 parse(text,options={}){return this.decode(parseJson(text,options),options);}
 stringify(value,options={}){return stringifyJson(this.encode(value,options),options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,true);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,true,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,false);}
}

// Token reader shared by schema-directed and arbitrary-JSON wire emission.
class JsonWireReader{
 constructor(text,options){this.l=checkedJsonLimits(options);if(typeof text!=='string'||!text.isWellFormed()||text.length>this.l.bytes||jsonUtf8Length(text)>this.l.bytes)throw Error('JSON byte or Unicode limit');this.text=text;this.at=0;this.remaining=this.l.nodes;}
 ws(){while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(c!==32&&c!==9&&c!==10&&c!==13)break;this.at++;}}
 peek(){this.ws();return this.text[this.at];}
 eat(c){this.ws();if(this.text[this.at]===c){this.at++;return true;}return false;}
 node(d){if(d>this.l.depth||--this.remaining<0)throw Error('JSON node or depth limit');}
 string(){
  this.ws();const start=this.at;if(this.text[start]!=='"')throw Error('expected JSON string');
  const end=this.text.indexOf('"',start+1);if(end<0)throw Error('unterminated JSON string');
  const raw=this.text.slice(start+1,end);
  if(!raw.includes('\\')&&!/[\x00-\x1f]/.test(raw)){this.at=end+1;return raw;}
  this.at=start+1;while(this.at<this.text.length){if(this.text[this.at]==='"'){this.at++;const v=JSON.parse(this.text.slice(start,this.at));if(!v.isWellFormed())throw Error('invalid JSON Unicode');return v;}if(this.text[this.at]==='\\')this.at+=2;else this.at++;}throw Error('unterminated JSON string');
 }
 number(){const start=this.at;while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(!(c>=48&&c<=57||c===45||c===43||c===46||c===101||c===69))break;this.at++;}const token=this.text.slice(start,this.at);if(!jsonNumberToken(token))throw Error('invalid JSON number');return token;}
 leaf(d){this.node(d);const c=this.peek();if(c==='n'&&this.text.startsWith('null',this.at)){this.at+=4;return null;}if(c==='t'&&this.text.startsWith('true',this.at)){this.at+=4;return true;}if(c==='f'&&this.text.startsWith('false',this.at)){this.at+=5;return false;}if(c==='"')return this.string();if(c==='-'||c>='0'&&c<='9')return this.number();throw Error('invalid JSON scalar');}
 finish(){this.ws();if(this.at!==this.text.length)throw Error('trailing JSON text');}
}
function streamJsonBinary(values,text,options,typed,compact=false){
 const p=new JsonWireReader(text,options),utf8=jsonWireEncoder;
 const list=(w,open,close,item)=>{if(!p.eat(open))throw Error('JSON container shape');const at=w.beginCount();let count=0;if(!p.eat(close))while(true){item(w);count++;if(p.eat(close))break;if(!p.eat(','))throw Error('JSON container separator');}w.endCount(at,count);};
 const variant=(w,index,level,emit)=>{if(level<index)w.frame(w=>{w.byte(1);variant(w,index,level+1,emit);});else if(index<5)w.frame(w=>{w.byte(0);w.frame(emit);});else w.frame(emit);};
 const json=(w,d)=>{
  const ch=p.peek(),index=ch==='n'?0:ch==='t'||ch==='f'?1:ch==='-'||ch>='0'&&ch<='9'?2:ch==='"'?3:ch==='['?4:ch==='{'?5:-1;if(index<0)throw Error('invalid JSON value');
  const leaf=index<4?p.leaf(d):null;if(index>=4)p.node(d);
  w.frame(w=>variant(w,index,0,w=>{
   if(index===0)return;if(index===1){w.frame(w=>w.byte(+leaf));return;}
   if(index===2||index===3){w.frame(w=>w.text(leaf));return;}
   w.frame(w=>{if(index===4)list(w,'[',']',w=>json(w,d+1));else{const seen=new Set();list(w,'{','}',w=>{const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');w.frame(w=>{w.frame(w=>w.text(key));json(w,d+1);});});}});
  }));
 };
 const read=(type,w,d)=>{
  const t=values.resolve(type);w.frame(w=>{
   if(t.kind==='list'||t.kind==='vector'){p.node(d);list(w,'[',']',w=>read(t.element,w,d+1));return;}
   if(t.kind==='record'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON record');const start=w.position,spans=new Array(t.fields.length).fill(null);
    if(!p.eat('}'))while(true){const key=p.string(),i=t.fields.findIndex(f=>f.name===key);if(i<0)throw Error('unknown JSON record field');if(spans[i])throw Error('duplicate JSON record field');if(!p.eat(':'))throw Error('JSON record colon');const at=w.position;read(t.fields[i].type,w,d+1);spans[i]=[at,w.position];if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON record separator');}
    if(spans.some(s=>s===null))throw Error('missing JSON record field');w.reorder(start,spans);return;
   }
   if(t.kind==='option'||t.kind==='result'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON tagged value');const key=p.string();if(!p.eat(':'))throw Error('JSON tag colon');
    if(t.kind==='option'&&key==='None'){if(p.leaf(d+1)!==null)throw Error('JSON None payload');w.byte(0);}
    else{const child=t.kind==='option'&&key==='Some'?t.element:t.kind==='result'&&key==='Ok'?t.ok:t.kind==='result'&&key==='Err'?t.error:null;if(!child)throw Error('invalid JSON tag');w.byte(key==='Ok'?0:1);read(child,w,d+1);}
    if(!p.eat('}'))throw Error('expected exactly one JSON tag');return;
   }
   const ch=p.peek(),v=p.leaf(d),bad=()=>{throw Error('JSON does not match '+t.kind);};
   if(t.kind==='unit'){if(v!==null)bad();return;}
   if(t.kind==='bool'){if(typeof v!=='boolean')bad();w.byte(+v);return;}
   if(['string','id','enum'].includes(t.kind)){if(ch!=='"')bad();w.text(v);return;}
   if(ch!=='-'&&!(ch>='0'&&ch<='9'))bad();
   if(t.kind==='int'){w.text(jsonInteger(v,4096));return;}
   if(t.kind==='f64'){const n=Number(v);if(!Number.isFinite(n))throw Error('JSON f64 overflow');const b=new DataView(new ArrayBuffer(8));b.setFloat64(0,n,true);w.wide(b.getBigUint64(0,true));}
   else if(t.kind==='f32'){jsonFloatScratch.setFloat32(0,Number(v),true);if(!Number.isFinite(jsonFloatScratch.getFloat32(0,true)))throw Error('JSON f32 overflow');w.word(jsonFloatScratch.getUint32(0,true));}
   else{const n=BigInt(jsonInteger(v,t.kind==='u64'?20:10));if(t.kind==='u64'){if(n<0n||n>18446744073709551615n)bad();w.wide(n);}else if(t.kind==='u32'){if(n<0n||n>4294967295n)bad();w.word(Number(n));}else if(t.kind==='i32'){if(n< -2147483648n||n>2147483647n)bad();w.word(Number(n)>>>0);}else bad();}
  });
 };
 return (compact?values.compact():values).encodeWith(w=>{if(typed)read(values.descriptor.root,w,0);else json(w,0);p.finish();},options);
}

// Render validated bytes in a single traversal; only the final text is owned.
function streamWireJsonText(values,bytes,options,library){
 values.validate(bytes,options);const l=checkedJsonLimits(options),parts=[];let size=0,remaining=l.nodes;const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 const emit=s=>{size+=jsonUtf8Length(s);if(size>l.bytes)throw Error('JSON byte limit');parts.push(s);};
 const string=s=>emit(JSON.stringify(s));const node=d=>{if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');};
 const frame=(type,at)=>{const t=values.resolve(type),start=at+4,end=start+dv.getUint32(at,true);return{t,start,end};};
 const json=(type,at,d)=>{
  node(d);let root=frame(type,at),sum=frame(root.t.fields[0].type,root.start),index=0;
  while(index<5){const err=bytes[sum.start];sum=frame(err?sum.t.error:sum.t.ok,sum.start+1);if(!err)break;index++;}
  if(index===0){emit('null');return root.end;}
  const item=frame(sum.t.fields[0].type,sum.start);
  if(index===1)emit(bytes[item.start]?'true':'false');
  else if(index===2){const token=decoder.decode(bytes.subarray(item.start,item.end));if(!jsonNumberToken(token))throw Error('invalid JSON number token');emit(token);}
  else if(index===3)string(decoder.decode(bytes.subarray(item.start,item.end)));
  else{const count=dv.getUint32(item.start,true);let p=item.start+4;emit(index===4?'[':'{');const seen=new Set();for(let i=0;i<count;i++){if(i)emit(',');if(index===4)p=json(item.t.element,p,d+1);else{const member=frame(item.t.element,p),key=frame(member.t.fields[0].type,member.start),name=decoder.decode(bytes.subarray(key.start,key.end));if(seen.has(name))throw Error('duplicate JSON object key');seen.add(name);string(name);emit(':');json(member.t.fields[1].type,key.end,d+1);p=member.end;}}emit(index===4?']':'}');}
  return root.end;
 };
 const typed=(type,at,d)=>{
  node(d);const f=frame(type,at),t=f.t;let p=f.start;
  switch(t.kind){
   case 'unit':emit('null');break;
   case 'bool':emit(bytes[p]?'true':'false');break;
   case 'u32':emit(String(dv.getUint32(p,true)));break;
   case 'u64':emit(String(dv.getBigUint64(p,true)));break;
   case 'i32':emit(String(dv.getInt32(p,true)));break;
   case 'f64':{const n=dv.getFloat64(p,true);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'f32':{const n=dv.getFloat32(p,true);if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'int':emit(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'string':case 'id':case 'enum':string(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'list':case 'vector':{const n=dv.getUint32(p,true);p+=4;emit('[');for(let i=0;i<n;i++){if(i)emit(',');p=typed(t.element,p,d+1);}emit(']');break;}
   case 'record':emit('{');for(let i=0;i<t.fields.length;i++){if(i)emit(',');const field=t.fields[i];string(field.name);emit(':');p=typed(field.type,p,d+1);}emit('}');break;
   case 'option':case 'result':{const tag=bytes[p++],key=t.kind==='option'?(tag?'Some':'None'):tag?'Err':'Ok';emit('{');string(key);emit(':');if(t.kind==='option'&&!tag){node(d+1);emit('null');}else typed(t.kind==='option'?t.element:tag?t.error:t.ok,p,d+1);emit('}');break;}
   default:throw Error('unsupported typed JSON descriptor');
  }return f.end;
 };
 if(library)json(values.descriptor.root,40,0);else typed(values.descriptor.root,40,0);return parts.join('');
}

/** Owned, optional read view of arbitrary JSON. Auxiliary indexes contain member
 * offsets only. Logical order, exact number tokens and missing/null remain intact.
 * This does not transparently replace any compiled Ink action or its state.
 */
export function createJsonLookup(text,{stepEntries=16,minReads=4,maxEntries=4096,maxObjects=64,maxIndexBytes=262144,...limits}={}){
 for(const [v,max]of [[stepEntries,4096],[minReads,1000000],[maxEntries,1000000],[maxObjects,256],[maxIndexBytes,16777216]])if(!Number.isSafeInteger(v)||v<0||v>max)throw Error('JSON index budget');
 let root=parseJson(text,limits),indexes=new Map(),entries=0,indexBytes=0;
 const stats={reads:0,writes:0,scanned_members:0,index_hits:0,built_entries:0,invalidations:0};
 function parts(path){
  if(!Array.isArray(path))throw Error('JSON lookup path');const n=path.length;if(n>128)throw Error('JSON lookup path');
  const owned=[];for(let i=0;i<n;i++){const d=Object.getOwnPropertyDescriptor(path,String(i));if(!d||!Object.hasOwn(d,'value'))throw Error('JSON lookup path');const p=d.value;if(!(typeof p==='string'&&p.isWellFormed()&&p.length<=4096)&&!(Number.isSafeInteger(p)&&p>=0))throw Error('JSON lookup path');owned.push(p);}return owned;
 }
 function variant(value){let p=value.payload,index=0;while(index<5&&Object.hasOwn(p,'Err')){p=p.Err;index++;}return {index,item:(index<5?p.Ok:p).item0};}
 function resolve(document,path,indexed){
  let value=document,budget=stepEntries;
  for(let depth=0;depth<path.length;depth++){
   const part=path[depth],v=variant(value);
   if(typeof part==='number'){
    if(v.index!==4)throw Error('expected JSON array');if(part>=v.item.length)return {found:false};value=v.item[part];continue;
   }
   if(v.index!==5)throw Error('expected JSON object');
   const prefix=path.slice(0,depth),key=JSON.stringify(prefix),overhead=128+prefix.reduce((n,p)=>n+(typeof p==='string'?16+p.length*2:8),0);let idx=indexed?indexes.get(key):null;
   if(indexed&&!idx&&indexes.size<maxObjects&&indexBytes+overhead<=maxIndexBytes){idx={path:prefix,reads:0,cursor:0,keys:new Map(),bytes:overhead};indexes.set(key,idx);indexBytes+=overhead;}
   if(idx){
    idx.reads++;
    if(idx.reads>=minReads)while(budget>0&&idx.cursor<v.item.length&&entries<maxEntries){
     const member=v.item[idx.cursor],bytes=64+member.key.length*2;
     if(indexBytes+bytes>maxIndexBytes)break;
     idx.keys.set(member.key,idx.cursor++);idx.bytes+=bytes;indexBytes+=bytes;entries++;stats.built_entries++;budget--;
    }
    if(idx.keys.has(part)){stats.index_hits++;value=v.item[idx.keys.get(part)].value;continue;}
   }
   let found=false;
   for(let i=idx?.cursor??0;i<v.item.length;i++){if(indexed)stats.scanned_members++;if(v.item[i].key===part){value=v.item[i].value;found=true;break;}}
   if(!found)return {found:false};
  }
  return {found:true,value};
 }
 return {
  lookup(path){stats.reads++;const r=resolve(root,parts(path),true);return r.found?{found:true,value:structuredClone(r.value)}:r;},
  set(path,key,text){
   path=parts(path);if(typeof key!=='string'||!key.isWellFormed())throw Error('JSON object key');
   const replacement=parseJson(text,limits),next=structuredClone(root),r=resolve(next,path,false);
   if(!r.found)throw Error('JSON update path missing');const object=variant(r.value);if(object.index!==5)throw Error('expected JSON object');
   const members=[{key,value:replacement},...object.item.filter(m=>m.key!==key)];
   // Validate the complete resulting document before publishing a write.
   let payload=r.value.payload;for(let i=0;i<5;i++)payload=payload.Err;payload.item0=members;
   stringifyJson(next,limits);root=next;stats.writes++;
   for(const [id,idx]of indexes)if(idx.path.length>=path.length&&path.every((p,i)=>p===idx.path[i])){entries-=idx.keys.size;indexBytes-=idx.bytes;indexes.delete(id);stats.invalidations++;}
  },
  replace(text){const next=parseJson(text,limits);root=next;stats.writes++;stats.invalidations+=indexes.size;indexes.clear();entries=0;indexBytes=0;},
  stringify(){return stringifyJson(root,limits);},
  stats(){return {...stats,index_entries:entries,index_objects:indexes.size,index_bytes:indexBytes};}
 };
}
function __ownedValue0(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue1(value[i],budget,depth+1);return out;}
function __ownedValue6(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue7(value[i],budget,depth+1);return out;}
function __ownedValue2(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue0(value.Ok,budget,depth+1)}:{Err:__ownedValue3(value.Err,budget,depth+1)};}
function __ownedValue9(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue10(value.Ok,budget,depth+1)}:{Err:__ownedValue3(value.Err,budget,depth+1)};}
function __ownedValue4(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue1(value.Ok,budget,depth+1)}:{Err:__ownedValue3(value.Err,budget,depth+1)};}
function __ownedValue10(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue1(value["value"],budget,depth+1),["gradient"]:__ownedValue0(value["gradient"],budget,depth+1)};}
function __ownedValue8(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue1(value["value"],budget,depth+1),["id"]:__ownedValue7(value["id"],budget,depth+1)};}
function __ownedValue5(value,budget,depth){budget.enter(depth,5);return value;}
function __ownedValue1(value,budget,depth){budget.enter(depth,8);return {F32Bits:value===0?0:value};}
function __ownedValue3(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __ownedValue7(value,budget,depth){budget.enter(depth,8);return value>>>0;}
const __ownedFunctions=Object.freeze(Object.fromEntries([["initial",__ownedValue0],["model",__ownedValue1],["objective",__ownedValue1],["derivatives",__ownedValue2],["linearized_value",__ownedValue4],["valid",__ownedValue5],["update",__ownedValue0],["admissible",__ownedValue5],["branch_owned",__ownedValue6],["device",__ownedValue0],["__ink_reverse_0_constant",__ownedValue8],["__ink_reverse_0_backward",__ownedValue0],["__ink_reverse_37",__ownedValue2],["__ink_reverse_50",__ownedValue9]]));
function __wireValue1(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue2(reader);reader.finish(end);return value;}
function __wireValue7(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue4(reader);reader.finish(end);return value;}
function __wireValue19(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue3(reader);reader.finish(end);return value;}
function __wireValue18(reader){const end=reader.frame();const value=reader.byte()?{Some:__wireValue3(reader)}:{None:null};reader.finish(end);return value;}
function __wireValue11(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue12(reader)}:{Ok:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue14(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue12(reader)}:{Ok:__wireValue15(reader)};reader.finish(end);return value;}
function __wireValue23(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue12(reader)}:{Ok:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue22(reader){const end=reader.frame();const value={};reader.finish(end);return value;}
function __wireValue16(reader){const end=reader.frame();const value={["context"]:__wireValue10(reader)};reader.finish(end);return value;}
function __wireValue10(reader){const end=reader.frame();const value={["features"]:__wireValue7(reader),["target"]:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue17(reader){const end=reader.frame();const value={["input"]:__wireValue18(reader)};reader.finish(end);return value;}
function __wireValue21(reader){const end=reader.frame();const value={["inputs"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue0(reader){const end=reader.frame();const value={["nodes"]:__wireValue1(reader),["output"]:__wireValue5(reader),["stopZero"]:__wireValue6(reader)};reader.finish(end);return value;}
function __wireValue2(reader){const end=reader.frame();const value={["op"]:__wireValue3(reader),["a"]:__wireValue3(reader),["b"]:__wireValue3(reader),["av"]:__wireValue4(reader),["bv"]:__wireValue4(reader),["value"]:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue15(reader){const end=reader.frame();const value={["value"]:__wireValue4(reader),["gradient"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue5(reader){const end=reader.frame();const value={["value"]:__wireValue4(reader),["id"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue8(reader){const end=reader.frame();const value={["value"]:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue9(reader){const end=reader.frame();const value={["weights"]:__wireValue7(reader),["__ink_reverse_32"]:__wireValue3(reader),["__ink_reverse_33"]:__wireValue6(reader),["context"]:__wireValue10(reader)};reader.finish(end);return value;}
function __wireValue13(reader){const end=reader.frame();const value={["weights"]:__wireValue7(reader),["__ink_reverse_45"]:__wireValue3(reader),["__ink_reverse_46"]:__wireValue6(reader),["context"]:__wireValue10(reader)};reader.finish(end);return value;}
function __wireValue20(reader){const end=reader.frame();const value={["weights"]:__wireValue7(reader),["context"]:__wireValue10(reader),["maximum"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue24(reader){const end=reader.frame();const value={["weights"]:__wireValue7(reader),["context"]:__wireValue10(reader)};reader.finish(end);return value;}
function __wireValue25(reader){const end=reader.frame();const value={["weights"]:__wireValue7(reader),["gradient"]:__wireValue7(reader),["rate"]:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue26(reader){const end=reader.frame();const value={["weights"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue6(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __wireValue4(reader){const end=reader.frame();const value={F32Bits:reader.word()};reader.finish(end);return value;}
function __wireValue12(reader){const end=reader.frame();const value=reader.text(end,"string");reader.finish(end);return value;}
function __wireValue3(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
const __wireReaders=Object.freeze(Object.fromEntries([["__ink_reverse_0_backward",[__wireValue0,__wireValue7]],["__ink_reverse_0_constant",[__wireValue8,__wireValue5]],["__ink_reverse_37",[__wireValue9,__wireValue11]],["__ink_reverse_50",[__wireValue13,__wireValue14]],["admissible",[__wireValue16,__wireValue6]],["branch_owned",[__wireValue17,__wireValue19]],["derivatives",[__wireValue20,__wireValue11]],["device",[__wireValue21,__wireValue7]],["initial",[__wireValue22,__wireValue7]],["linearized_value",[__wireValue20,__wireValue23]],["model",[__wireValue24,__wireValue4]],["objective",[__wireValue24,__wireValue4]],["update",[__wireValue25,__wireValue7]],["valid",[__wireValue26,__wireValue6]]]));

const __ownedImplementations=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>{
 const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
 const body=__implementations[f.index];
 const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
 return [f.name,input.every(c=>c===__identity)?implementation:(...args)=>{const context=new WeakMap();return implementation(...args.map((v,i)=>input[i](v,context)));}];
})));

export const valueCodecs=(()=>{const codecs={};for(const [name,s] of Object.entries(metadata.wire.functions)){if(s.unsupported)continue;let value;Object.defineProperty(codecs,name,{enumerable:true,get:()=>value??=(Object.freeze(Object.hasOwn(__wireReaders,name)?{arguments:createCompiledValueCodec(s.arguments,__wireReaders[name][0]),result:createCompiledValueCodec(s.result,__wireReaders[name][1])}:{arguments:new ValueCodec(s.arguments),result:new ValueCodec(s.result)}))});}return Object.freeze(codecs);})();
function __callEncoded(name,bytes,limits,compact){
 const f=metadata.functions.find(f=>f.name===name&&!f.internal),codecs=valueCodecs[name];
 if(!f||!codecs)throw Error('unsupported binary function');
 const input=compact?codecs.arguments.compact():codecs.arguments,output=compact?codecs.result.compact():codecs.result;
 const entry=__compiledEntries.get(name);
 if(entry){
  const slot=compact?1:0;
  entry.argumentCodecs[slot]??=(entry.boundaryReaders[slot]?createFusedValueCodec:createCompiledValueCodec)(metadata.wire.functions[name].arguments,entry.arguments);
  const decoder=entry.argumentCodecs[slot];
  const values=(compact?decoder.compact():decoder).decode(bytes,limits),args=f.params.map(p=>values[p.name]);
  if(entry.precondition!==null&&__implementations[entry.precondition](...args)!==true)throw Error('contract precondition failed');
  return __compiledEncodeResult(entry,__implementations[entry.index](...args),limits,compact);
 }
 const values=input.decode(bytes,limits);
 const result=call(name,f.params.map(p=>values[p.name]));
 return output.encode(result,limits);
}
export function callBinary(name,bytes,limits={}){return __callEncoded(name,bytes,limits,false);}
export function callCompact(name,bytes,limits={}){return __callEncoded(name,bytes,limits,true);}
// Same stable, well-typed caller inputs as call; the result owns every container.
// The checked source return type justifies trusted copying, not arbitrary input.
export function callOwned(name,args,limits={}){
 if(!Object.hasOwn(__ownedFunctions,name)||!Object.hasOwn(functions,name))throw Error('unsupported owned function');
 const result=__ownedImplementations[name](...args);return __ownedFunctions[name](result,createValueCaptureBudget(limits),0);
}
function __privateCapture11(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture12(value[i],budget,depth+1);return out;}
function __privateCapture0(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture1(value[i],budget,depth+1);return out;}
function __privateCapture9(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture3(value[i],budget,depth+1);return out;}
function __privateCapture8(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if((value!==null&&typeof value==='object'&&Object.hasOwn(value,'None')&&Object.keys(value).length===1)&&value.None===null)return {None:null};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Some')&&Object.keys(value).length===1)return {Some:__privateCapture3(value.Some,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture4(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture0(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture5(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture13(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture14(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture5(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture6(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture1(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture5(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture2(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"features")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"target")){throw Error('invalid value for wire schema');}return {["features"]:__privateCapture0(value["features"],budget,depth+1),["target"]:__privateCapture1(value["target"],budget,depth+1)};}
function __privateCapture12(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"op")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"av")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"bv")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}return {["op"]:__privateCapture3(value["op"],budget,depth+1),["a"]:__privateCapture3(value["a"],budget,depth+1),["b"]:__privateCapture3(value["b"],budget,depth+1),["av"]:__privateCapture1(value["av"],budget,depth+1),["bv"]:__privateCapture1(value["bv"],budget,depth+1),["value"]:__privateCapture1(value["value"],budget,depth+1)};}
function __privateCapture14(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"gradient")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["gradient"]:__privateCapture0(value["gradient"],budget,depth+1)};}
function __privateCapture10(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"id")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["id"]:__privateCapture3(value["id"],budget,depth+1)};}
function __privateCapture7(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='boolean'){throw Error('invalid value for wire schema');}budget.add(1);return value;}
function __privateCapture1(value,budget,depth=0){budget.enter(depth,4);let bits;if(typeof value==='number'&&Number.isFinite(value)){bits=__bits(value);if(!Number.isFinite(__float(bits))){throw Error('invalid value for wire schema');}}else{if(!(value!==null&&typeof value==='object'&&Object.hasOwn(value,'F32Bits')&&Object.keys(value).length===1)){throw Error('invalid value for wire schema');}bits=value.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295){throw Error('invalid value for wire schema');}}budget.add(4);return bits===0?0:bits;}
function __privateCapture5(value,budget,depth=0){budget.enter(depth,4);const text=value;if(typeof text!=='string'||!text.isWellFormed()||text.length>budget.limit){throw Error('invalid value for wire schema');}budget.text(text);return text;}
function __privateCapture3(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='number'||!Number.isInteger(value)||value<0||value>4294967295){throw Error('invalid value for wire schema');}budget.add(4);return value===0?0:value;}
function __privateWireValue20(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue21(reader);reader.finish(end);return value;}
function __privateWireValue0(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue1(reader);reader.finish(end);return value;}
function __privateWireValue15(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue5(reader);reader.finish(end);return value;}
function __privateWireValue14(reader){const end=reader.frame();const value=reader.byte()?{Some:__privateWireValue5(reader)}:{None:null};reader.finish(end);return value;}
function __privateWireValue6(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue7(reader)}:{Ok:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue24(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue7(reader)}:{Ok:__privateWireValue25(reader)};reader.finish(end);return value;}
function __privateWireValue9(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue7(reader)}:{Ok:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue2(reader){const end=reader.frame();const value={};reader.finish(end);return value;}
function __privateWireValue13(reader){const end=reader.frame();const value={["context"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue3(reader){const end=reader.frame();const value={["features"]:__privateWireValue0(reader),["target"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue16(reader){const end=reader.frame();const value={["input"]:__privateWireValue14(reader)};reader.finish(end);return value;}
function __privateWireValue17(reader){const end=reader.frame();const value={["inputs"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue22(reader){const end=reader.frame();const value={["nodes"]:__privateWireValue20(reader),["output"]:__privateWireValue18(reader),["stopZero"]:__privateWireValue10(reader)};reader.finish(end);return value;}
function __privateWireValue21(reader){const end=reader.frame();const value={["op"]:__privateWireValue5(reader),["a"]:__privateWireValue5(reader),["b"]:__privateWireValue5(reader),["av"]:__privateWireValue1(reader),["bv"]:__privateWireValue1(reader),["value"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue25(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["gradient"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue18(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["id"]:__privateWireValue5(reader)};reader.finish(end);return value;}
function __privateWireValue19(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue23(reader){const end=reader.frame();const value={["weights"]:__privateWireValue0(reader),["__ink_reverse_32"]:__privateWireValue5(reader),["__ink_reverse_33"]:__privateWireValue10(reader),["context"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue26(reader){const end=reader.frame();const value={["weights"]:__privateWireValue0(reader),["__ink_reverse_45"]:__privateWireValue5(reader),["__ink_reverse_46"]:__privateWireValue10(reader),["context"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue8(reader){const end=reader.frame();const value={["weights"]:__privateWireValue0(reader),["context"]:__privateWireValue3(reader),["maximum"]:__privateWireValue5(reader)};reader.finish(end);return value;}
function __privateWireValue4(reader){const end=reader.frame();const value={["weights"]:__privateWireValue0(reader),["context"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue12(reader){const end=reader.frame();const value={["weights"]:__privateWireValue0(reader),["gradient"]:__privateWireValue0(reader),["rate"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue11(reader){const end=reader.frame();const value={["weights"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue10(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __privateWireValue1(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __privateWireValue7(reader){const end=reader.frame();const value=reader.text(end,"string");reader.finish(end);return value;}
function __privateWireValue5(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __compiledOwnedValue11(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue12(value[i],budget,depth+1);return out;}
function __compiledOwnedValue0(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue1(value[i],budget,depth+1);return out;}
function __compiledOwnedValue9(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue3(value[i],budget,depth+1);return out;}
function __compiledOwnedValue8(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__compiledOwnedValue3(value.Some,budget,depth+1)};}
function __compiledOwnedValue4(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue0(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue5(value.Err,budget,depth+1)};}
function __compiledOwnedValue13(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue14(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue5(value.Err,budget,depth+1)};}
function __compiledOwnedValue6(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue1(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue5(value.Err,budget,depth+1)};}
function __compiledOwnedValue2(value,budget,depth){budget.enter(depth,4);return {["features"]:__compiledOwnedValue0(value["features"],budget,depth+1),["target"]:__compiledOwnedValue1(value["target"],budget,depth+1)};}
function __compiledOwnedValue12(value,budget,depth){budget.enter(depth,4);return {["op"]:__compiledOwnedValue3(value["op"],budget,depth+1),["a"]:__compiledOwnedValue3(value["a"],budget,depth+1),["b"]:__compiledOwnedValue3(value["b"],budget,depth+1),["av"]:__compiledOwnedValue1(value["av"],budget,depth+1),["bv"]:__compiledOwnedValue1(value["bv"],budget,depth+1),["value"]:__compiledOwnedValue1(value["value"],budget,depth+1)};}
function __compiledOwnedValue14(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["gradient"]:__compiledOwnedValue0(value["gradient"],budget,depth+1)};}
function __compiledOwnedValue10(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["id"]:__compiledOwnedValue3(value["id"],budget,depth+1)};}
function __compiledOwnedValue7(value,budget,depth){budget.enter(depth,5);return value;}
function __compiledOwnedValue1(value,budget,depth){budget.enter(depth,8);return {F32Bits:value===0?0:value};}
function __compiledOwnedValue5(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __compiledOwnedValue3(value,budget,depth){budget.enter(depth,8);return value>>>0;}
function __privateWireWrite11(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite12(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite0(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite1(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite9(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite3(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite8(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Some')){writer.byte(1);__privateWireWrite3(writer,value.Some,compact);}else{writer.byte(0);}writer.closeFrame(frame);}
function __privateWireWrite4(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite0(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite5(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite13(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite14(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite5(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite6(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite1(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite5(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite2(writer,value,compact){const frame=writer.openFrame();__privateWireWrite0(writer,value["features"],compact);__privateWireWrite1(writer,value["target"],compact);writer.closeFrame(frame);}
function __privateWireWrite12(writer,value,compact){const frame=writer.openFrame();__privateWireWrite3(writer,value["op"],compact);__privateWireWrite3(writer,value["a"],compact);__privateWireWrite3(writer,value["b"],compact);__privateWireWrite1(writer,value["av"],compact);__privateWireWrite1(writer,value["bv"],compact);__privateWireWrite1(writer,value["value"],compact);writer.closeFrame(frame);}
function __privateWireWrite14(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite0(writer,value["gradient"],compact);writer.closeFrame(frame);}
function __privateWireWrite10(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite3(writer,value["id"],compact);writer.closeFrame(frame);}
function __privateWireWrite7(writer,value,compact){const frame=writer.openFrame();writer.byte(value?1:0);writer.closeFrame(frame);}
function __privateWireWrite1(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
function __privateWireWrite5(writer,value,compact){const frame=writer.openFrame();writer.text(value,compact);writer.closeFrame(frame);}
function __privateWireWrite3(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
// Handles have no mutable private payload surface. Membership and type identity
// are checked by this module's closure; copied/foreign objects cannot forge them.
const __compiledHandles=new WeakMap();
const __compiledBindings=new WeakMap();
function __compiledHandle(identity,value,guaranteed=false){
 const handle=Object.freeze(Object.create(null));
 __compiledHandles.set(handle,{identity,value,guaranteed});return handle;
}
function __compiledEntry(handle,identity){
 const entry=__compiledHandles.get(handle);
 if(!entry||entry.identity!==identity)throw Error('compiled value type or owner mismatch');
 return entry;
}
function __compiledUnwrap(handle,identity){return __compiledEntry(handle,identity).value;}
// Emit the portable schema's framing/scalar events without creating a buffer
// or exposing private composite nodes. Only this wrapper receives callbacks
// from the literal writer; host visitors never receive those closures.
function __compiledValueEvents(sink,limits){
 const methods=['begin','end','byte','word','wide','text','count'];
 for(const name of methods)if(typeof sink?.[name]!=='function')throw Error('compiled value visitor method: '+name);
 const budget=createValueCaptureBudget(limits);let depth=0,closed=false;
 const active=()=>{if(closed)throw Error('compiled value visitor is closed');};
 const writer=Object.freeze({
  openFrame(){active();budget.enter(depth,4);depth++;sink.begin();return 0;}
  ,closeFrame(){active();if(depth===0)throw Error('wire frame boundary');try{sink.end();}finally{depth--;}}
  ,frame(emit){active();budget.enter(depth,4);depth++;sink.begin();try{emit();sink.end();}finally{depth--;}}
  ,byte(value){active();budget.add(1);sink.byte(value);}
  ,word(value){active();budget.add(4);sink.word(value);}
  ,wide(value){active();budget.add(8);sink.wide(value);}
  ,text(value){active();budget.text(value);sink.text(value);}
  ,count(value){active();budget.add(4);if(value>budget.remaining)throw Error('wire sequence size');sink.count(value);}
 });
 return {writer,close(){closed=true;}};
}
function __compiledReduction(factory,root,reduce,identity){
 if(typeof factory!=='function')throw Error('compiled reduction factory');
 const reducers=[],seen=new Set(),nodes=__reductionNodes();
 const prepare=index=>{
  if(seen.has(index))return;seen.add(index);
  const node=nodes[index];
  for(const child of node.children)prepare(child);
  const reducer=factory(node,index);
  if(node.kind==='list'||node.kind==='vector'){
   const start=reducer?.start,step=reducer?.step,finish=reducer?.finish;
   if(typeof start!=='function'||typeof step!=='function'||typeof finish!=='function')throw Error('compiled collection reduction');
   reducers[index]=Object.freeze({start,step,finish});
  }else{
   if(typeof reducer!=='function')throw Error('compiled value reduction');
   reducers[index]=reducer;
  }
 };
 prepare(root);Object.freeze(reducers);
 return Object.freeze(function(handle,context,limits={}){
  const value=__compiledUnwrap(handle,identity),budget=createValueCaptureBudget(limits);
  return reduce(value,reducers,budget,0,context);
 });
}
function __compiledCodec(schema,capture,read,write,copy,constructorRoot,reductionRoot,reduce,portableFused=false,compactFused=false){
 const privateCodec=createCompiledValueCodec(schema,read),publicCodec=privateCodec;
 let fusedCodec;const fused=()=>fusedCodec??=createFusedValueCodec(schema,read);
 const identity=schema.identity;
 const codec=Object.freeze({
  identity,
  descriptor:publicCodec.descriptor,
  resolve(type){return publicCodec.resolve(type);},
  capture(value,limits={}){
   return __compiledHandle(identity,capture(value,createValueCaptureBudget(limits),0));
  },
  decode(bytes,limits={}){return __compiledHandle(identity,(portableFused?fused():privateCodec).decode(bytes,limits));},
  decodeCompact(bytes,limits={}){return __compiledHandle(identity,(compactFused?fused():privateCodec).compact().decode(bytes,limits));},
  decodeFused(bytes,limits={}){return __compiledHandle(identity,fused().decode(bytes,limits));},
  decodeCompactFused(bytes,limits={}){return __compiledHandle(identity,fused().compact().decode(bytes,limits));},
  encode(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.encodeWith(writer=>write(writer,value,false),limits);},
  encodeCompact(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.compact().encodeWith(writer=>write(writer,value,true),limits);},
  materialize(handle,limits={}){return copy(__compiledUnwrap(handle,identity),createValueCaptureBudget(limits),0);},
  builder(limits={}){return __valueBuilder(__constructorNodes(),constructorRoot,identity,limits);},
  reducer(factory){return __compiledReduction(factory,reductionRoot,reduce,identity);},
  visit(handle,sink,limits={}){
   const value=__compiledUnwrap(handle,identity),events=__compiledValueEvents(sink,limits);
   try{write(events.writer,value,false);}finally{events.close();}
  },
 });
 __compiledBindings.set(codec,{publicCodec,write,capture});return codec;
}

function __compiledEncodeResult(entry,value,limits,compact){
 const {publicCodec,write}=__compiledBindings.get(entry.result());
 return (compact?publicCodec.compact():publicCodec).encodeWith(writer=>write(writer,value,compact),limits);
}
let __constructorNodesValue;function __constructorNodes(){return __constructorNodesValue??=[{kind:"list",patterns:[{bytes:8,label:"sequence",children:[1],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:"f32",scalar:__privateCapture1},{kind:'record',fields:["features","target"],patterns:[{bytes:4,label:"record",children:[0,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["features"]:values[0],["target"]:values[1]})}]},{kind:"u32",scalar:__privateCapture3},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[0],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[5],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:"string",scalar:__privateCapture5},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[1],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[5],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:"bool",scalar:__privateCapture7},{kind:'option',patterns:[{bytes:5,label:"None",children:[],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({None:null})},{bytes:5,label:"Some",children:[3],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({Some:values[0]})}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[3],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["value","id"],patterns:[{bytes:4,label:"record",children:[1,3],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["id"]:values[1]})}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[12],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["op","a","b","av","bv","value"],patterns:[{bytes:4,label:"record",children:[3,3,3,1,1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["op"]:values[0],["a"]:values[1],["b"]:values[2],["av"]:values[3],["bv"]:values[4],["value"]:values[5]})}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[14],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[5],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'record',fields:["value","gradient"],patterns:[{bytes:4,label:"record",children:[1,0],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["gradient"]:values[1]})}]}];}
// Typed input construction only: plans contain literal constructor/capture
// functions emitted from source schemas. No source expression evaluator.
// All frames and private values remain in this closure; callers receive only
// an owned opaque handle after one complete, well-typed root is constructed.
const __constructorPaths=new WeakMap();
function __valueBuilder(nodes,root,identity,limits){
 const budget=createValueCaptureBudget(limits),frames=[];
 let result,targetNode,targetDepth,complete=false,closed=false,failed=false,busy=false;
 const fail=message=>{failed=true;frames.length=0;result=undefined;throw Error(message);};
 const active=()=>{if(failed||closed)throw Error('value builder is closed');};
 const expected=()=>{
  if(!frames.length){if(complete)fail('value builder root already complete');targetNode=root;targetDepth=0;return;}
  const frame=frames.at(-1),position=frame.values.length;
  if(!frame.pattern.sequence&&position>=frame.pattern.children.length)fail('value builder constructor is full');
  targetNode=frame.pattern.sequence?frame.pattern.children[0]:frame.pattern.children[position];targetDepth=frame.depth+frame.pattern.childDepth;
 };
 const accept=value=>{
  if(frames.length)frames.at(-1).values.push(value);
  else{result=value;complete=true;}
 };
 const execute=(operation,first,second)=>{
  active();if(busy)throw Error('value builder operation already active');busy=true;
  try{return operation(first,second);}catch(error){failed=true;frames.length=0;result=undefined;throw error;}finally{busy=false;}
 };
 // Compile and cache constructor paths independently of the session's values.
 const pathPlan=(choices,startNode,startDepth)=>{
   if(!Array.isArray(choices)||choices.length===0||choices.length>128)fail('invalid value builder path');
   let cache=__constructorPaths.get(nodes);if(!cache){cache=new WeakMap();__constructorPaths.set(nodes,cache);}
   let entries=cache.get(choices),saved=entries?.get(startNode);
   if(saved)return saved;
   const path=[],charges=[];let node=startNode,depth=startDepth;
   for(let i=0;i<choices.length;i++){
    const choice=choices[i],patterns=nodes[node].patterns;
    if(!Number.isSafeInteger(choice)||choice<0||!patterns||choice>=patterns.length)fail('invalid value builder constructor');
    const pattern=patterns[choice];charges.push([pattern,depth-startDepth]);path.push({pattern,node:nodes[node]});
    if(i+1<choices.length){if(pattern.sequence||pattern.children.length!==1)fail('value builder path is not unary');node=pattern.children[0];depth+=pattern.childDepth;}
   }
   const terminal=path.at(-1).pattern;
   // Compose literal constructor functions once per path, instead of
   // allocating and interpreting another recursive closure for every value.
   const compose=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=args=>args[0];
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=args=>p.make([inner(args)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?compose(last+1):args=>args[0]):compose(last);
     return args=>node.flat(index,payload(args));
    }
    const inner=at+1<path.length?compose(at+1):null;
    if(pattern.transparent)return inner??(args=>args[0]);
    return inner?args=>pattern.make([inner(args)]):pattern.make;
   };
   const make=compose(0);
   // Scalar paths use the same literal constructors, but pass the leaf
   // directly through erased records and flat sums. No temporary argument
   // array is needed at those edges. Ordinary constructors keep their array
   // calling convention; no private value reaches the public builder API.
   const composeScalar=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=value=>value;
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=value=>p.make([inner(value)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?composeScalar(last+1):value=>value):composeScalar(last);
     return value=>node.flat(index,payload(value));
    }
    const inner=at+1<path.length?composeScalar(at+1):null;
    if(pattern.transparent)return inner??(value=>value);
    return inner?value=>pattern.make([inner(value)]):value=>pattern.make([value]);
   };
   const scalar=composeScalar(0);
   const pattern={...terminal,make};
   // Only frozen arrays of ordinary data properties can key reusable plans.
   // Mutable arrays and frozen accessor arrays retain checked per-call paths.
   const fixed=charges.every(([p])=>Number.isSafeInteger(p.bytes)&&p.bytes>=4);
   const plan={pattern,scalar,charges,offset:depth-startDepth,bytes:fixed?charges.reduce((n,[p])=>n+p.bytes,0):null};
   let reusable=Object.isFrozen(choices);
   for(let i=0;reusable&&i<choices.length;i++){const field=Object.getOwnPropertyDescriptor(choices,String(i));reusable=!!field&&Object.hasOwn(field,'value');}
   if(reusable){
    if(!entries){entries=new Map();cache.set(choices,entries);}entries.set(startNode,plan);
   }
   return plan;
 };
 const chargePath=(plan,depth)=>{
  // Each emitted constructor consumes one node and a fixed frame/tag cost.
  // Only take the combined charge when every original check would succeed.
  // Replaying the original order retains the exact first failure otherwise.
  if(plan.bytes!==null&&depth+plan.offset<=budget.depth&&plan.charges.length<=budget.remaining&&budget.bytes+plan.bytes<=budget.limit){
   budget.remaining-=plan.charges.length;budget.bytes+=plan.bytes;return;
  }
  for(const [pattern,offset]of plan.charges)pattern.charge(budget,depth+offset);
 };
 // Operations are allocated once per session, and share expected-node
 // scratch only while the existing reentrancy guard is held.
 const openOperation=(choice)=>{
   expected();const node=nodes[targetNode];
   if(!Number.isSafeInteger(choice)||choice<0||!node.patterns||choice>=node.patterns.length)fail('invalid value builder constructor');
   const pattern=node.patterns[choice];pattern.charge(budget,targetDepth);
   frames.push({pattern,depth:targetDepth,values:[]});
 };
 const openPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth);
   chargePath(plan,targetDepth);
   frames.push({pattern:plan.pattern,depth:targetDepth+plan.offset,values:[]});
 };
 const scalarPathOperation=(choices,value)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==1)fail('value builder path has no scalar leaf');
   const capture=nodes[pattern.children[0]].scalar;
   if(typeof capture!=='function')fail('value builder path has no scalar leaf');
   chargePath(plan,targetDepth);
   const leaf=capture(value,budget,targetDepth+plan.offset+pattern.childDepth);
   accept(plan.scalar(leaf));
 };
 const emptyPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==0)fail('value builder path is not empty');
   chargePath(plan,targetDepth);accept(pattern.make([]));
 };
 const scalarOperation=(value)=>{
   expected();const capture=nodes[targetNode].scalar;
   if(typeof capture!=='function')fail('value builder expects a constructor');
   accept(capture(value,budget,targetDepth));
 };
 const closeOperation=()=>{
   if(!frames.length)fail('value builder has no open constructor');
   const frame=frames.at(-1),pattern=frame.pattern,count=frame.values.length;
   if(!pattern.sequence&&count!==pattern.children.length||pattern.size!==undefined&&count!==pattern.size)fail('value builder constructor arity');
   if(pattern.sequence&&count>budget.limit)fail('wire sequence size');
   const value=pattern.make(frame.values);
   frames.pop();accept(value);
 };
 const finishOperation=()=>{
   if(frames.length||!complete)fail('value builder root is incomplete');
   closed=true;const handle=__compiledHandle(identity,result);result=undefined;return handle;
 };
 const api=Object.freeze({
  open(choice){return execute(openOperation,choice);},
  // Charge every source constructor even when unary paths share one frame.
  openPath(choices){return execute(openPathOperation,choices);},
  // Complete the path and leaf without intermediate session frames.
  scalarPath(choices,value){return execute(scalarPathOperation,choices,value);},
  emptyPath(choices){return execute(emptyPathOperation,choices);},
  scalar(value){return execute(scalarOperation,value);},
  close(){return execute(closeOperation);},
  finish(){return execute(finishOperation);},
  abort(){if(busy)throw Error('value builder operation already active');failed=true;frames.length=0;result=undefined;},
 });
 return api;
}
function __reduceValue0(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[0];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue1(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue1(value,r,b,d,c){b.enter(d,8);return r[1]({F32Bits:value},c);}
function __reduceValue2(value,r,b,d,c){b.enter(d,4);return r[2](__reduceValue0(value["features"],r,b,d+1,c),__reduceValue1(value["target"],r,b,d+1,c),c);}
function __reduceValue3(value,r,b,d,c){b.enter(d,8);return r[3](value,c);}
function __reduceValue4(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[4](0,__reduceValue0(value.Ok,r,b,d+1,c),c):r[4](1,__reduceValue5(value.Err,r,b,d+1,c),c);}
function __reduceValue5(value,r,b,d,c){b.enter(d,4);b.text(value);return r[5](value,c);}
function __reduceValue6(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[6](0,__reduceValue1(value.Ok,r,b,d+1,c),c):r[6](1,__reduceValue5(value.Err,r,b,d+1,c),c);}
function __reduceValue7(value,r,b,d,c){b.enter(d,5);return r[7](value,c);}
function __reduceValue8(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'None')&&value.None===null?r[8](0,null,c):r[8](1,__reduceValue3(value.Some,r,b,d+1,c),c);}
function __reduceValue9(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[9];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue3(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue10(value,r,b,d,c){b.enter(d,4);return r[10](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue3(value["id"],r,b,d+1,c),c);}
function __reduceValue11(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[11];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue12(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue12(value,r,b,d,c){b.enter(d,4);return r[12](__reduceValue3(value["op"],r,b,d+1,c),__reduceValue3(value["a"],r,b,d+1,c),__reduceValue3(value["b"],r,b,d+1,c),__reduceValue1(value["av"],r,b,d+1,c),__reduceValue1(value["bv"],r,b,d+1,c),__reduceValue1(value["value"],r,b,d+1,c),c);}
function __reduceValue13(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[13](0,__reduceValue14(value.Ok,r,b,d+1,c),c):r[13](1,__reduceValue5(value.Err,r,b,d+1,c),c);}
function __reduceValue14(value,r,b,d,c){b.enter(d,4);return r[14](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue0(value["gradient"],r,b,d+1,c),c);}
let __reductionNodeCache;function __reductionNodes(){return __reductionNodeCache??=Object.freeze([Object.freeze({"children":Object.freeze([1]),"kind":"list"}),Object.freeze({"children":Object.freeze([]),"kind":"f32"}),Object.freeze({"children":Object.freeze([0,1]),"fields":Object.freeze(["features","target"]),"kind":"record","name":"Context"}),Object.freeze({"children":Object.freeze([]),"kind":"u32"}),Object.freeze({"children":Object.freeze([0,5]),"kind":"result"}),Object.freeze({"children":Object.freeze([]),"kind":"string"}),Object.freeze({"children":Object.freeze([1,5]),"kind":"result"}),Object.freeze({"children":Object.freeze([]),"kind":"bool"}),Object.freeze({"children":Object.freeze([3]),"kind":"option"}),Object.freeze({"children":Object.freeze([3]),"kind":"list"}),Object.freeze({"children":Object.freeze([1,3]),"fields":Object.freeze(["value","id"]),"kind":"record","name":"__ink_reverse_0_Wire"}),Object.freeze({"children":Object.freeze([12]),"kind":"list"}),Object.freeze({"children":Object.freeze([3,3,3,1,1,1]),"fields":Object.freeze(["op","a","b","av","bv","value"]),"kind":"record","name":"__ink_reverse_0_Node"}),Object.freeze({"children":Object.freeze([14,5]),"kind":"result"}),Object.freeze({"children":Object.freeze([1,0]),"fields":Object.freeze(["value","gradient"]),"kind":"record","name":"__ink_reverse_58"})]);}
function __compiledNamed0(){return {};}
let __compiledCodec0Value;function __compiledCodec0(){return __compiledCodec0Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":__compiledNamed0(),"root":{"element":{"kind":"f32"},"kind":"list"}},__privateCapture0,__privateWireValue0,__privateWireWrite0,__compiledOwnedValue0,0,0,__reduceValue0,false,false);}
let __compiledCodec1Value;function __compiledCodec1(){return __compiledCodec1Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"80e41dc143c0deefa2b964386ffbcbf6c9b2a0241f99ce0592f21e733bbd835f","named":__compiledNamed0(),"root":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}},__privateCapture2,__privateWireValue3,__privateWireWrite2,__compiledOwnedValue2,2,2,__reduceValue2,false,false);}
let __compiledCodec2Value;function __compiledCodec2(){return __compiledCodec2Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":__compiledNamed0(),"root":{"kind":"f32"}},__privateCapture1,__privateWireValue1,__privateWireWrite1,__compiledOwnedValue1,1,1,__reduceValue1,false,false);}
let __compiledCodec3Value;function __compiledCodec3(){return __compiledCodec3Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff","named":__compiledNamed0(),"root":{"kind":"u32"}},__privateCapture3,__privateWireValue5,__privateWireWrite3,__compiledOwnedValue3,3,3,__reduceValue3,false,false);}
let __compiledCodec4Value;function __compiledCodec4(){return __compiledCodec4Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},__privateCapture4,__privateWireValue6,__privateWireWrite4,__compiledOwnedValue4,4,4,__reduceValue4,false,false);}
let __compiledCodec5Value;function __compiledCodec5(){return __compiledCodec5Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"29bcdada2d2b5ecb6deae18e25401ad25c1f0dc80bcd50defebf64892403468d","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"f32"}}},__privateCapture6,__privateWireValue9,__privateWireWrite6,__compiledOwnedValue6,6,6,__reduceValue6,false,false);}
let __compiledCodec6Value;function __compiledCodec6(){return __compiledCodec6Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":__compiledNamed0(),"root":{"kind":"bool"}},__privateCapture7,__privateWireValue10,__privateWireWrite7,__compiledOwnedValue7,7,7,__reduceValue7,false,false);}
let __compiledCodec7Value;function __compiledCodec7(){return __compiledCodec7Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"f4055357f369cc8f275f6cc1d5569678031edf449ad32c3c8d392d37fab5b1ed","named":__compiledNamed0(),"root":{"element":{"kind":"u32"},"kind":"option"}},__privateCapture8,__privateWireValue14,__privateWireWrite8,__compiledOwnedValue8,8,8,__reduceValue8,false,false);}
let __compiledCodec8Value;function __compiledCodec8(){return __compiledCodec8Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"69ebf947aa59a2546656d1976b0baa6e56e7182d989425379b31e3bff74168ca","named":__compiledNamed0(),"root":{"element":{"kind":"u32"},"kind":"list"}},__privateCapture9,__privateWireValue15,__privateWireWrite9,__compiledOwnedValue9,9,9,__reduceValue9,false,false);}
let __compiledCodec9Value;function __compiledCodec9(){return __compiledCodec9Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fabc4e63e940c6190680726874c8654deced79200b320c057b9389a135a08557","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},__privateCapture10,__privateWireValue18,__privateWireWrite10,__compiledOwnedValue10,10,10,__reduceValue10,false,false);}
let __compiledCodec10Value;function __compiledCodec10(){return __compiledCodec10Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"8d20db2e18176975b811079510807748b5da77b30341fa86eaec165fb19262b0","named":__compiledNamed0(),"root":{"element":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"kind":"list"}},__privateCapture11,__privateWireValue20,__privateWireWrite11,__compiledOwnedValue11,11,11,__reduceValue11,false,false);}
let __compiledCodec11Value;function __compiledCodec11(){return __compiledCodec11Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"f2d8a6a6c76daa0750e8dd172034ca17108eb15fc853843947bdb021fd452611","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"__ink_reverse_58"}}},__privateCapture13,__privateWireValue24,__privateWireWrite13,__compiledOwnedValue13,13,13,__reduceValue13,false,false);}
const __compiledEntries=new Map([["initial",{index:0,params:[],result:__compiledCodec0,arguments:__privateWireValue2,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[],precondition:null}],["model",{index:1,params:[__compiledCodec0,__compiledCodec1],result:__compiledCodec2,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["objective",{index:2,params:[__compiledCodec0,__compiledCodec1],result:__compiledCodec2,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["derivatives",{index:3,params:[__compiledCodec0,__compiledCodec1,__compiledCodec3],result:__compiledCodec4,arguments:__privateWireValue8,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["linearized_value",{index:4,params:[__compiledCodec0,__compiledCodec1,__compiledCodec3],result:__compiledCodec5,arguments:__privateWireValue8,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["valid",{index:5,params:[__compiledCodec0],result:__compiledCodec6,arguments:__privateWireValue11,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["update",{index:6,params:[__compiledCodec0,__compiledCodec0,__compiledCodec2],result:__compiledCodec0,arguments:__privateWireValue12,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["admissible",{index:7,params:[__compiledCodec1],result:__compiledCodec6,arguments:__privateWireValue13,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["branch_owned",{index:8,params:[__compiledCodec7],result:__compiledCodec8,arguments:__privateWireValue16,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["device",{index:10,params:[__compiledCodec0],result:__compiledCodec0,arguments:__privateWireValue17,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["__ink_reverse_0_constant",{index:11,params:[__compiledCodec2],result:__compiledCodec9,arguments:__privateWireValue19,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["__ink_reverse_0_backward",{index:19,params:[__compiledCodec10,__compiledCodec9,__compiledCodec6],result:__compiledCodec0,arguments:__privateWireValue22,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["__ink_reverse_37",{index:22,params:[__compiledCodec0,__compiledCodec3,__compiledCodec6,__compiledCodec1],result:__compiledCodec4,arguments:__privateWireValue23,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["__ink_reverse_50",{index:23,params:[__compiledCodec0,__compiledCodec3,__compiledCodec6,__compiledCodec1],result:__compiledCodec11,arguments:__privateWireValue26,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}]]);

export const compiledValues=Object.freeze(Object.fromEntries([...__compiledEntries].map(([name,entry])=>[name,Object.freeze({get params(){return Object.freeze(entry.params.map(codec=>codec()));},get result(){return entry.result();}})])));
function __compiledValidate(entry,owned){
 const values=owned.map(v=>v.value);
 const established=entry.onlyTypeGuards&&entry.needsInvariants.every((needed,i)=>!needed||owned[i].guaranteed);
 if(entry.precondition!==null&&!established){
  if(__implementations[entry.precondition](...values)!==true)throw Error('contract precondition failed');
  for(let i=0;i<owned.length;i++)if(entry.needsInvariants[i])owned[i].guaranteed=true;
 }
 return values;
}
export function callCompiled(name,args){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(args)||args.length!==entry.params.length)throw Error('unsupported compiled call');
 const owned=entry.params.map((codec,i)=>__compiledEntry(args[i],codec().identity)),values=__compiledValidate(entry,owned);
 // Checked source outputs satisfy their declared value interfaces. Private
 // handles expose only detached copies and never retain mutable host inputs.
 return __compiledHandle(entry.result().identity,__implementations[entry.index](...values),true);
}

// Explicit sealed-value partial application. Each token owns a bounded set of
// lexical caches; no mutable host object, global memo table or error is retained.
const __preparedCompiled=new WeakMap();
export function prepareCompiled(name,bindings){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(bindings)||bindings.length>entry.params.length)throw Error('unsupported prepared compiled call');
 const captured=new Array(entry.params.length),fixed=new Array(entry.params.length).fill(false);
 for(const binding of bindings){
  if(!Array.isArray(binding)||binding.length!==2)throw Error('prepared compiled binding');
  const [index,handle]=binding;
  if(!Number.isInteger(index)||index<0||index>=fixed.length||fixed[index])throw Error('prepared compiled parameter');
  captured[index]=__compiledEntry(handle,entry.params[index]().identity);fixed[index]=true;
 }
 const remaining=fixed.flatMap((yes,i)=>yes?[]:[i]);
 const factory=__preparedFactories.get(entry.index);
 const run=factory?factory(fixed):__implementations[entry.index];
 const token=Object.freeze(Object.create(null));
 __preparedCompiled.set(token,{entry,captured,remaining,run});return token;
}
export function callPreparedCompiled(token,args){
 const prepared=__preparedCompiled.get(token);
 if(!prepared||!Array.isArray(args)||args.length!==prepared.remaining.length)throw Error('invalid prepared compiled call');
 const {entry,captured,remaining,run}=prepared,owned=captured.slice();
 for(let i=0;i<remaining.length;i++){const at=remaining[i];owned[at]=__compiledEntry(args[i],entry.params[at]().identity);}
 const values=__compiledValidate(entry,owned);
 return __compiledHandle(entry.result().identity,run(...values),true);
}
const __intoOutput0=__representation(metadata.functions[0].result.element,true);
const __intoOutput6=__representation(metadata.functions[6].result.element,true);
const __intoOutput10=__representation(metadata.functions[10].result.element,true);
const __intoOutput19=__representation(metadata.functions[19].result.element,true);
const __intoImplementations=[__into0,null,null,null,null,null,__into6,null,__into8,null,__into10,null,null,null,null,null,null,null,null,__into19,null,null,null,null];

export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>{
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const body=__intoImplementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args.slice(0,f.params.length))!==true)throw Error('contract precondition failed');return body(...args);};
  const entry=input.every(c=>c===__identity)?implementation:(...values)=>{const context=new WeakMap();return implementation(...input.map((convert,i)=>convert(values[i],context)),values[f.params.length]);};
  return [f.name,entry];
})));
export function callInto(name,args,destination){switch(name){case "device_work":case "__ink_reverse_0_append":case "__ink_reverse_0_seed":case "__ink_reverse_0_binary":case "__ink_reverse_0_unary":case "__ink_reverse_0_add":case "__ink_reverse_0_back_node":case "__ink_reverse_0_back_step":case "__ink_reverse_4":case "__ink_reverse_1":throw new Error('temporary storage is internal to a pure invocation');}return functionsInto[name](...args,destination);}

function __preparedPart(mask,path){
 for(const field of path){
  if(mask===true)return true;
  if(!mask || typeof mask!=="object")return false;
  mask=Object.hasOwn(mask.fields,field)?mask.fields[field]:false;
 }
 return mask;
}
function __preparedStable(mask,path){const part=__preparedPart(mask,path);return part===true || (!!part && part.all===true);}
function __prepareFn2(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn2;const v1767=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
let v1766=false,v1765;
return function(v1762,v1763){let v1764;if(v1767&&v1766){v1764=v1765;}else{
const v1768=__fn1(v1762,v1763);
const v1769=v1763["target"];
v1764=__bits(__float(v1768) - __float(v1769));if(v1767){v1765=v1764;v1766=true;}}
const v1770=v1764;
const v1771=v1764;
return __bits(__float(v1770) * __float(v1771));};}
function __prepareFn3(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[]))))return __fn3;const v1778=depth<15&&__preparedFactories.has(22)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[])));
let v1776;
return function(v1772,v1773,v1774){const v1775=true;
let v1779;if(v1778){if(!v1776){const v1777=__preparedFactories.get(22);v1776=v1777([fixed[0],fixed[2],true,fixed[1]],depth+1);}v1779=v1776(v1772,v1774,v1775,v1773);}else{v1779=__fn22(v1772,v1774,v1775,v1773);}
return v1779;};}
function __prepareFn4(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[]))))return __fn4;const v1786=depth<15&&__preparedFactories.has(23)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[])));
let v1784;
return function(v1780,v1781,v1782){const v1783=true;
let v1787;if(v1786){if(!v1784){const v1785=__preparedFactories.get(23);v1784=v1785([fixed[0],fixed[2],true,fixed[1]],depth+1);}v1787=v1784(v1780,v1782,v1783,v1781);}else{v1787=__fn23(v1780,v1782,v1783,v1781);}
const v1788=v1787;
let v1789;if(Object.hasOwn(v1788,"Ok")){
const v1790=v1788["Ok"];
v1789=({Ok:v1790["value"]});}else{
v1789=({Err:v1788["Err"]});}
return v1789;};}
function __prepareFn22(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn22;const v2265=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],["features"])&&__preparedStable(fixed[3],["target"]);
let v2264=false,v2263;
const v2270=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[3],["features"])&&__preparedStable(fixed[3],["target"]);
const v2275=depth<15&&__preparedFactories.has(19)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[3],["features"])&&__preparedStable(fixed[3],["target"])));
let v2273;
return function(v1926,v1927,v1928,v1929){const v1930=1000000;
const v1931=((v1927) > (v1930));
let v1932;if(v1931){
v1932=({Err:"reverse differentiation capacity exceeds one million nodes"});}else{
const v1935=new __InkBuffer([]);
const v1936=new __InkBuffer([]);
const v1937=false;
const v1938=({["nodes"]:v1936,["maximum"]:v1927,["failed"]:v1937});
const v1939=0;
let v1940=v1935;
let v1941=v1938;
let v1942=v1939;
for(let v1944=0;v1944<v1926.length;v1944++){
const v1945=v1926[v1944];
const v1946=v1941;
const v1947=0;
const v1948=4294967295;
const v1949=4294967295;
const v1950=0;
const v1951=0;
const v1953=true;
const v1954=false;
const v1955=(v1953===v1954);
let v1956=v1955;if(!v1956){
v1956=v1946["failed"];}
let v1957;
let v1958;
if(v1956){
const v1959=__fn11(v1945);
v1957=v1959;
v1958=v1946;
}else{
const v1960=v1946["nodes"];
const v1961=(v1960).length;
const v1962=v1946["maximum"];
let v1963;
let v1964;
if(((v1961) >= (v1962))){
const v1965=__fn11(v1945);
const v1966=true;
const v1967=v1946["nodes"];
const v1968=v1946["maximum"];
const v1969=({["nodes"]:v1967,["maximum"]:v1968,["failed"]:v1966});
v1963=v1965;
v1964=v1969;
}else{
const v1970=({["value"]:v1945,["id"]:v1961});
const v1971=v1946["nodes"];
const v1972=({["op"]:v1947,["a"]:v1948,["b"]:v1949,["av"]:v1950,["bv"]:v1951,["value"]:v1945});
const v1973=__tempEdit(v1971,"push",v1972);
const v1974=v1946["maximum"];
const v1975=v1946["failed"];
const v1976=({["nodes"]:v1973,["maximum"]:v1974,["failed"]:v1975});
v1963=v1970;
v1964=v1976;
}
v1957=v1963;
v1958=v1964;
}
const v1978=v1940;
const v1979=v1957;
const v1980=__tempEdit(v1978,"push",v1979);
const v1981=v1958;
const v1982=v1942;
const v1983=1;
const v1984=(((v1982) + (v1983)) >>> 0);
v1940=v1980;
v1941=v1981;
v1942=v1984;
}
const v1934=({["values"]:v1940,["tape"]:v1941,["index"]:v1942});
const v1985=v1934;
const v1986=v1985["values"];
const v1987=v1986.freeze();
const v1988=v1934;
const v1989=v1988["tape"];
const v1933=({["value"]:v1987,["tape"]:v1989});
const v1991=v1933;
const v1992=v1991["value"];
const v1993=v1929["features"];
const v1994=v1993.length;
const v1995=new Array(v1994);
for(let v1996=0;v1996<v1994;v1996++){
const v1997=v1993[v1996];
v1995[v1996]=__fn11(v1997);
}
const v1998=v1929["target"];
const v1999=__fn11(v1998);
const v2001=v1933;
const v2002=v2001["tape"];
const v2004=({["features"]:v1995,["target"]:v1999});
const v2008=v2004["features"];
const v2010=Math.min(v1992.length,v2008.length);
const v2011=new Array(v2010);
for(let v2012=0;v2012<v2010;v2012++){
const v2013=v1992[v2012];
const v2014=v2008[v2012];
v2011[v2012]=({["left"]:v2013,["right"]:v2014});
}
const v2015=new __InkBuffer([]);
const v2016=0;
let v2017=v2015;
let v2018=v2002;
let v2019=v2016;
for(let v2021=0;v2021<v2011.length;v2021++){
const v2022=v2011[v2021];
const v2023=v2022["left"];
const v2024=v2022["right"];
const v2025=v2018;
const v2028=3;
const v2029=1;
let v2030;if((v2028===v2029)){
const v2031=v2023["value"];
const v2032=v2024["value"];
v2030=__bits(__float(v2031) + __float(v2032));}else{
const v2033=2;
let v2034;if((v2028===v2033)){
const v2035=v2023["value"];
const v2036=v2024["value"];
v2034=__bits(__float(v2035) - __float(v2036));}else{
const v2037=3;
let v2038;if((v2028===v2037)){
const v2039=v2023["value"];
const v2040=v2024["value"];
v2038=__bits(__float(v2039) * __float(v2040));}else{
v2038=__bits((__float(v2023["value"]))/(__float(v2024["value"])));}
v2034=v2038;}
v2030=v2034;}
const v2041=v2030;
const v2042=v2023["id"];
const v2043=v2024["id"];
const v2044=v2023["value"];
const v2045=v2024["value"];
const v2047=v2023["id"];
const v2048=4294967295;
const v2049=!(v2047===v2048);
let v2050=v2049;if(!v2050){
const v2051=v2024["id"];
const v2052=4294967295;
v2050=!(v2051===v2052);}
const v2053=v2050;
const v2054=false;
const v2055=(v2053===v2054);
let v2056=v2055;if(!v2056){
v2056=v2025["failed"];}
let v2057;
let v2058;
if(v2056){
const v2059=__fn11(v2041);
v2057=v2059;
v2058=v2025;
}else{
const v2060=v2025["nodes"];
const v2061=(v2060).length;
const v2062=v2025["maximum"];
let v2063;
let v2064;
if(((v2061) >= (v2062))){
const v2065=__fn11(v2041);
const v2066=true;
const v2067=v2025["nodes"];
const v2068=v2025["maximum"];
const v2069=({["nodes"]:v2067,["maximum"]:v2068,["failed"]:v2066});
v2063=v2065;
v2064=v2069;
}else{
const v2070=({["value"]:v2041,["id"]:v2061});
const v2071=v2025["nodes"];
const v2072=({["op"]:v2028,["a"]:v2042,["b"]:v2043,["av"]:v2044,["bv"]:v2045,["value"]:v2041});
const v2073=__tempEdit(v2071,"push",v2072);
const v2074=v2025["maximum"];
const v2075=v2025["failed"];
const v2076=({["nodes"]:v2073,["maximum"]:v2074,["failed"]:v2075});
v2063=v2070;
v2064=v2076;
}
v2057=v2063;
v2058=v2064;
}
const v2078=v2017;
const v2079=v2057;
const v2080=__tempEdit(v2078,"push",v2079);
const v2081=v2058;
const v2082=v2019;
const v2083=1;
const v2084=(((v2082) + (v2083)) >>> 0);
v2017=v2080;
v2018=v2081;
v2019=v2084;
}
const v2086=v2017;
const v2087=v2086.freeze();
const v2088=v2018;
const v2090=0;
const v2091=__fn11(v2090);
let v2092=v2091;
let v2093=v2088;
for(let v2095=0;v2095<v2087.length;v2095++){
const v2096=v2087[v2095];
const v2097=1;
const v2098=v2093;
const v2099=v2092;
const v2100=1;
let v2101;if((v2097===v2100)){
const v2102=v2099["value"];
const v2103=v2096["value"];
v2101=__bits(__float(v2102) + __float(v2103));}else{
const v2104=2;
let v2105;if((v2097===v2104)){
const v2106=v2099["value"];
const v2107=v2096["value"];
v2105=__bits(__float(v2106) - __float(v2107));}else{
const v2108=3;
let v2109;if((v2097===v2108)){
const v2110=v2099["value"];
const v2111=v2096["value"];
v2109=__bits(__float(v2110) * __float(v2111));}else{
v2109=__bits((__float(v2099["value"]))/(__float(v2096["value"])));}
v2105=v2109;}
v2101=v2105;}
const v2112=v2101;
const v2113=v2099["id"];
const v2114=v2096["id"];
const v2115=v2099["value"];
const v2116=v2096["value"];
const v2118=v2099["id"];
const v2119=4294967295;
const v2120=!(v2118===v2119);
let v2121=v2120;if(!v2121){
const v2122=v2096["id"];
const v2123=4294967295;
v2121=!(v2122===v2123);}
const v2124=v2121;
const v2125=false;
const v2126=(v2124===v2125);
let v2127=v2126;if(!v2127){
v2127=v2098["failed"];}
let v2128;
let v2129;
if(v2127){
const v2130=__fn11(v2112);
v2128=v2130;
v2129=v2098;
}else{
const v2131=v2098["nodes"];
const v2132=(v2131).length;
const v2133=v2098["maximum"];
let v2134;
let v2135;
if(((v2132) >= (v2133))){
const v2136=__fn11(v2112);
const v2137=true;
const v2138=v2098["nodes"];
const v2139=v2098["maximum"];
const v2140=({["nodes"]:v2138,["maximum"]:v2139,["failed"]:v2137});
v2134=v2136;
v2135=v2140;
}else{
const v2141=({["value"]:v2112,["id"]:v2132});
const v2142=v2098["nodes"];
const v2143=({["op"]:v2097,["a"]:v2113,["b"]:v2114,["av"]:v2115,["bv"]:v2116,["value"]:v2112});
const v2144=__tempEdit(v2142,"push",v2143);
const v2145=v2098["maximum"];
const v2146=v2098["failed"];
const v2147=({["nodes"]:v2144,["maximum"]:v2145,["failed"]:v2146});
v2134=v2141;
v2135=v2147;
}
v2128=v2134;
v2129=v2135;
}
v2092=v2128;
v2093=v2129;
}
const v2149=({["features"]:v1995,["target"]:v1999});
const v2150=v2093;
const v2152=v2149["target"];
const v2154=2;
const v2155=v2092;
const v2156=1;
let v2157;if((v2154===v2156)){
const v2158=v2155["value"];
const v2159=v2152["value"];
v2157=__bits(__float(v2158) + __float(v2159));}else{
const v2160=2;
let v2161;if((v2154===v2160)){
const v2162=v2155["value"];
const v2163=v2152["value"];
v2161=__bits(__float(v2162) - __float(v2163));}else{
const v2164=3;
let v2165;if((v2154===v2164)){
const v2166=v2155["value"];
const v2167=v2152["value"];
v2165=__bits(__float(v2166) * __float(v2167));}else{
v2165=__bits((__float(v2155["value"]))/(__float(v2152["value"])));}
v2161=v2165;}
v2157=v2161;}
const v2168=v2157;
const v2169=v2155["id"];
const v2170=v2152["id"];
const v2171=v2155["value"];
const v2172=v2152["value"];
const v2174=v2155["id"];
const v2175=4294967295;
const v2176=!(v2174===v2175);
let v2177=v2176;if(!v2177){
const v2178=v2152["id"];
const v2179=4294967295;
v2177=!(v2178===v2179);}
const v2180=v2177;
const v2181=false;
const v2182=(v2180===v2181);
let v2183=v2182;if(!v2183){
v2183=v2150["failed"];}
let v2184;
let v2185;
if(v2183){
const v2186=__fn11(v2168);
v2184=v2186;
v2185=v2150;
}else{
const v2187=v2150["nodes"];
const v2188=(v2187).length;
const v2189=v2150["maximum"];
let v2190;
let v2191;
if(((v2188) >= (v2189))){
const v2192=__fn11(v2168);
const v2193=true;
const v2194=v2150["nodes"];
const v2195=v2150["maximum"];
const v2196=({["nodes"]:v2194,["maximum"]:v2195,["failed"]:v2193});
v2190=v2192;
v2191=v2196;
}else{
const v2197=({["value"]:v2168,["id"]:v2188});
const v2198=v2150["nodes"];
const v2199=({["op"]:v2154,["a"]:v2169,["b"]:v2170,["av"]:v2171,["bv"]:v2172,["value"]:v2168});
const v2200=__tempEdit(v2198,"push",v2199);
const v2201=v2150["maximum"];
const v2202=v2150["failed"];
const v2203=({["nodes"]:v2200,["maximum"]:v2201,["failed"]:v2202});
v2190=v2197;
v2191=v2203;
}
v2184=v2190;
v2185=v2191;
}
const v2205=v2184;
const v2206=v2185;
const v2209=3;
const v2210=1;
let v2211;if((v2209===v2210)){
const v2212=v2205["value"];
const v2213=v2205["value"];
v2211=__bits(__float(v2212) + __float(v2213));}else{
const v2214=2;
let v2215;if((v2209===v2214)){
const v2216=v2205["value"];
const v2217=v2205["value"];
v2215=__bits(__float(v2216) - __float(v2217));}else{
const v2218=3;
let v2219;if((v2209===v2218)){
const v2220=v2205["value"];
const v2221=v2205["value"];
v2219=__bits(__float(v2220) * __float(v2221));}else{
v2219=__bits((__float(v2205["value"]))/(__float(v2205["value"])));}
v2215=v2219;}
v2211=v2215;}
const v2222=v2211;
const v2223=v2205["id"];
const v2224=v2205["id"];
const v2225=v2205["value"];
const v2226=v2205["value"];
const v2228=v2205["id"];
const v2229=4294967295;
const v2230=!(v2228===v2229);
let v2231=v2230;if(!v2231){
const v2232=v2205["id"];
const v2233=4294967295;
v2231=!(v2232===v2233);}
const v2234=v2231;
const v2235=false;
const v2236=(v2234===v2235);
let v2237=v2236;if(!v2237){
v2237=v2206["failed"];}
let v2238;
let v2239;
if(v2237){
const v2240=__fn11(v2222);
v2238=v2240;
v2239=v2206;
}else{
const v2241=v2206["nodes"];
const v2242=(v2241).length;
const v2243=v2206["maximum"];
let v2244;
let v2245;
if(((v2242) >= (v2243))){
const v2246=__fn11(v2222);
const v2247=true;
const v2248=v2206["nodes"];
const v2249=v2206["maximum"];
const v2250=({["nodes"]:v2248,["maximum"]:v2249,["failed"]:v2247});
v2244=v2246;
v2245=v2250;
}else{
const v2251=({["value"]:v2222,["id"]:v2242});
const v2252=v2206["nodes"];
const v2253=({["op"]:v2209,["a"]:v2223,["b"]:v2224,["av"]:v2225,["bv"]:v2226,["value"]:v2222});
const v2254=__tempEdit(v2252,"push",v2253);
const v2255=v2206["maximum"];
const v2256=v2206["failed"];
const v2257=({["nodes"]:v2254,["maximum"]:v2255,["failed"]:v2256});
v2244=v2251;
v2245=v2257;
}
v2238=v2244;
v2239=v2245;
}
const v1990=({["value"]:v2238,["tape"]:v2239});
const v2258=v1990;
const v2259=v2258["tape"];
const v2260=v2259["failed"];
let v2261;if(v2260){
v2261=({Err:"reverse differentiation tape capacity exceeded"});}else{
let v2262;if(v2265&&v2264){v2262=v2263;}else{
const v2266=v1990;
const v2267=v2266["tape"];
const v2268=v2267["nodes"];
const v2269=v2268.freeze();
const v2271=v1990;
const v2272=v2271["value"];
let v2276;if(v2275){if(!v2273){const v2274=__preparedFactories.get(19);v2273=v2274([v2270,v2270,fixed[2]],depth+1);}v2276=v2273(v2269,v2272,v1928);}else{v2276=__fn19(v2269,v2272,v1928);}
v2262=v2276;if(v2265){v2263=v2262;v2264=true;}}
const v2277=v1933;
const v2278=v2277["value"];
const v2279=v2278.length;
const v2280=new Array(v2279);
for(let v2281=0;v2281<v2279;v2281++){
const v2282=v2278[v2281];
const v2283=v2262;
const v2284=v2282["id"];
let v2285;if(v2284<v2283.length){v2285=v2283[v2284];}else{
v2285=0;}
v2280[v2281]=v2285;
}
v2261=({Ok:v2280});}
v1932=v2261;}
return v1932;};}
function __prepareFn23(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn23;const v2625=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],["features"])&&__preparedStable(fixed[3],["target"]);
let v2624=false,v2623;
const v2630=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[3],["features"])&&__preparedStable(fixed[3],["target"]);
const v2635=depth<15&&__preparedFactories.has(19)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[3],["features"])&&__preparedStable(fixed[3],["target"])));
let v2633;
return function(v2286,v2287,v2288,v2289){const v2290=1000000;
const v2291=((v2287) > (v2290));
let v2292;if(v2291){
v2292=({Err:"reverse differentiation capacity exceeds one million nodes"});}else{
const v2295=new __InkBuffer([]);
const v2296=new __InkBuffer([]);
const v2297=false;
const v2298=({["nodes"]:v2296,["maximum"]:v2287,["failed"]:v2297});
const v2299=0;
let v2300=v2295;
let v2301=v2298;
let v2302=v2299;
for(let v2304=0;v2304<v2286.length;v2304++){
const v2305=v2286[v2304];
const v2306=v2301;
const v2307=0;
const v2308=4294967295;
const v2309=4294967295;
const v2310=0;
const v2311=0;
const v2313=true;
const v2314=false;
const v2315=(v2313===v2314);
let v2316=v2315;if(!v2316){
v2316=v2306["failed"];}
let v2317;
let v2318;
if(v2316){
const v2319=__fn11(v2305);
v2317=v2319;
v2318=v2306;
}else{
const v2320=v2306["nodes"];
const v2321=(v2320).length;
const v2322=v2306["maximum"];
let v2323;
let v2324;
if(((v2321) >= (v2322))){
const v2325=__fn11(v2305);
const v2326=true;
const v2327=v2306["nodes"];
const v2328=v2306["maximum"];
const v2329=({["nodes"]:v2327,["maximum"]:v2328,["failed"]:v2326});
v2323=v2325;
v2324=v2329;
}else{
const v2330=({["value"]:v2305,["id"]:v2321});
const v2331=v2306["nodes"];
const v2332=({["op"]:v2307,["a"]:v2308,["b"]:v2309,["av"]:v2310,["bv"]:v2311,["value"]:v2305});
const v2333=__tempEdit(v2331,"push",v2332);
const v2334=v2306["maximum"];
const v2335=v2306["failed"];
const v2336=({["nodes"]:v2333,["maximum"]:v2334,["failed"]:v2335});
v2323=v2330;
v2324=v2336;
}
v2317=v2323;
v2318=v2324;
}
const v2338=v2300;
const v2339=v2317;
const v2340=__tempEdit(v2338,"push",v2339);
const v2341=v2318;
const v2342=v2302;
const v2343=1;
const v2344=(((v2342) + (v2343)) >>> 0);
v2300=v2340;
v2301=v2341;
v2302=v2344;
}
const v2294=({["values"]:v2300,["tape"]:v2301,["index"]:v2302});
const v2345=v2294;
const v2346=v2345["values"];
const v2347=v2346.freeze();
const v2348=v2294;
const v2349=v2348["tape"];
const v2293=({["value"]:v2347,["tape"]:v2349});
const v2351=v2293;
const v2352=v2351["value"];
const v2353=v2289["features"];
const v2354=v2353.length;
const v2355=new Array(v2354);
for(let v2356=0;v2356<v2354;v2356++){
const v2357=v2353[v2356];
v2355[v2356]=__fn11(v2357);
}
const v2358=v2289["target"];
const v2359=__fn11(v2358);
const v2361=v2293;
const v2362=v2361["tape"];
const v2364=({["features"]:v2355,["target"]:v2359});
const v2368=v2364["features"];
const v2370=Math.min(v2352.length,v2368.length);
const v2371=new Array(v2370);
for(let v2372=0;v2372<v2370;v2372++){
const v2373=v2352[v2372];
const v2374=v2368[v2372];
v2371[v2372]=({["left"]:v2373,["right"]:v2374});
}
const v2375=new __InkBuffer([]);
const v2376=0;
let v2377=v2375;
let v2378=v2362;
let v2379=v2376;
for(let v2381=0;v2381<v2371.length;v2381++){
const v2382=v2371[v2381];
const v2383=v2382["left"];
const v2384=v2382["right"];
const v2385=v2378;
const v2388=3;
const v2389=1;
let v2390;if((v2388===v2389)){
const v2391=v2383["value"];
const v2392=v2384["value"];
v2390=__bits(__float(v2391) + __float(v2392));}else{
const v2393=2;
let v2394;if((v2388===v2393)){
const v2395=v2383["value"];
const v2396=v2384["value"];
v2394=__bits(__float(v2395) - __float(v2396));}else{
const v2397=3;
let v2398;if((v2388===v2397)){
const v2399=v2383["value"];
const v2400=v2384["value"];
v2398=__bits(__float(v2399) * __float(v2400));}else{
v2398=__bits((__float(v2383["value"]))/(__float(v2384["value"])));}
v2394=v2398;}
v2390=v2394;}
const v2401=v2390;
const v2402=v2383["id"];
const v2403=v2384["id"];
const v2404=v2383["value"];
const v2405=v2384["value"];
const v2407=v2383["id"];
const v2408=4294967295;
const v2409=!(v2407===v2408);
let v2410=v2409;if(!v2410){
const v2411=v2384["id"];
const v2412=4294967295;
v2410=!(v2411===v2412);}
const v2413=v2410;
const v2414=false;
const v2415=(v2413===v2414);
let v2416=v2415;if(!v2416){
v2416=v2385["failed"];}
let v2417;
let v2418;
if(v2416){
const v2419=__fn11(v2401);
v2417=v2419;
v2418=v2385;
}else{
const v2420=v2385["nodes"];
const v2421=(v2420).length;
const v2422=v2385["maximum"];
let v2423;
let v2424;
if(((v2421) >= (v2422))){
const v2425=__fn11(v2401);
const v2426=true;
const v2427=v2385["nodes"];
const v2428=v2385["maximum"];
const v2429=({["nodes"]:v2427,["maximum"]:v2428,["failed"]:v2426});
v2423=v2425;
v2424=v2429;
}else{
const v2430=({["value"]:v2401,["id"]:v2421});
const v2431=v2385["nodes"];
const v2432=({["op"]:v2388,["a"]:v2402,["b"]:v2403,["av"]:v2404,["bv"]:v2405,["value"]:v2401});
const v2433=__tempEdit(v2431,"push",v2432);
const v2434=v2385["maximum"];
const v2435=v2385["failed"];
const v2436=({["nodes"]:v2433,["maximum"]:v2434,["failed"]:v2435});
v2423=v2430;
v2424=v2436;
}
v2417=v2423;
v2418=v2424;
}
const v2438=v2377;
const v2439=v2417;
const v2440=__tempEdit(v2438,"push",v2439);
const v2441=v2418;
const v2442=v2379;
const v2443=1;
const v2444=(((v2442) + (v2443)) >>> 0);
v2377=v2440;
v2378=v2441;
v2379=v2444;
}
const v2446=v2377;
const v2447=v2446.freeze();
const v2448=v2378;
const v2450=0;
const v2451=__fn11(v2450);
let v2452=v2451;
let v2453=v2448;
for(let v2455=0;v2455<v2447.length;v2455++){
const v2456=v2447[v2455];
const v2457=1;
const v2458=v2453;
const v2459=v2452;
const v2460=1;
let v2461;if((v2457===v2460)){
const v2462=v2459["value"];
const v2463=v2456["value"];
v2461=__bits(__float(v2462) + __float(v2463));}else{
const v2464=2;
let v2465;if((v2457===v2464)){
const v2466=v2459["value"];
const v2467=v2456["value"];
v2465=__bits(__float(v2466) - __float(v2467));}else{
const v2468=3;
let v2469;if((v2457===v2468)){
const v2470=v2459["value"];
const v2471=v2456["value"];
v2469=__bits(__float(v2470) * __float(v2471));}else{
v2469=__bits((__float(v2459["value"]))/(__float(v2456["value"])));}
v2465=v2469;}
v2461=v2465;}
const v2472=v2461;
const v2473=v2459["id"];
const v2474=v2456["id"];
const v2475=v2459["value"];
const v2476=v2456["value"];
const v2478=v2459["id"];
const v2479=4294967295;
const v2480=!(v2478===v2479);
let v2481=v2480;if(!v2481){
const v2482=v2456["id"];
const v2483=4294967295;
v2481=!(v2482===v2483);}
const v2484=v2481;
const v2485=false;
const v2486=(v2484===v2485);
let v2487=v2486;if(!v2487){
v2487=v2458["failed"];}
let v2488;
let v2489;
if(v2487){
const v2490=__fn11(v2472);
v2488=v2490;
v2489=v2458;
}else{
const v2491=v2458["nodes"];
const v2492=(v2491).length;
const v2493=v2458["maximum"];
let v2494;
let v2495;
if(((v2492) >= (v2493))){
const v2496=__fn11(v2472);
const v2497=true;
const v2498=v2458["nodes"];
const v2499=v2458["maximum"];
const v2500=({["nodes"]:v2498,["maximum"]:v2499,["failed"]:v2497});
v2494=v2496;
v2495=v2500;
}else{
const v2501=({["value"]:v2472,["id"]:v2492});
const v2502=v2458["nodes"];
const v2503=({["op"]:v2457,["a"]:v2473,["b"]:v2474,["av"]:v2475,["bv"]:v2476,["value"]:v2472});
const v2504=__tempEdit(v2502,"push",v2503);
const v2505=v2458["maximum"];
const v2506=v2458["failed"];
const v2507=({["nodes"]:v2504,["maximum"]:v2505,["failed"]:v2506});
v2494=v2501;
v2495=v2507;
}
v2488=v2494;
v2489=v2495;
}
v2452=v2488;
v2453=v2489;
}
const v2509=({["features"]:v2355,["target"]:v2359});
const v2510=v2453;
const v2512=v2509["target"];
const v2514=2;
const v2515=v2452;
const v2516=1;
let v2517;if((v2514===v2516)){
const v2518=v2515["value"];
const v2519=v2512["value"];
v2517=__bits(__float(v2518) + __float(v2519));}else{
const v2520=2;
let v2521;if((v2514===v2520)){
const v2522=v2515["value"];
const v2523=v2512["value"];
v2521=__bits(__float(v2522) - __float(v2523));}else{
const v2524=3;
let v2525;if((v2514===v2524)){
const v2526=v2515["value"];
const v2527=v2512["value"];
v2525=__bits(__float(v2526) * __float(v2527));}else{
v2525=__bits((__float(v2515["value"]))/(__float(v2512["value"])));}
v2521=v2525;}
v2517=v2521;}
const v2528=v2517;
const v2529=v2515["id"];
const v2530=v2512["id"];
const v2531=v2515["value"];
const v2532=v2512["value"];
const v2534=v2515["id"];
const v2535=4294967295;
const v2536=!(v2534===v2535);
let v2537=v2536;if(!v2537){
const v2538=v2512["id"];
const v2539=4294967295;
v2537=!(v2538===v2539);}
const v2540=v2537;
const v2541=false;
const v2542=(v2540===v2541);
let v2543=v2542;if(!v2543){
v2543=v2510["failed"];}
let v2544;
let v2545;
if(v2543){
const v2546=__fn11(v2528);
v2544=v2546;
v2545=v2510;
}else{
const v2547=v2510["nodes"];
const v2548=(v2547).length;
const v2549=v2510["maximum"];
let v2550;
let v2551;
if(((v2548) >= (v2549))){
const v2552=__fn11(v2528);
const v2553=true;
const v2554=v2510["nodes"];
const v2555=v2510["maximum"];
const v2556=({["nodes"]:v2554,["maximum"]:v2555,["failed"]:v2553});
v2550=v2552;
v2551=v2556;
}else{
const v2557=({["value"]:v2528,["id"]:v2548});
const v2558=v2510["nodes"];
const v2559=({["op"]:v2514,["a"]:v2529,["b"]:v2530,["av"]:v2531,["bv"]:v2532,["value"]:v2528});
const v2560=__tempEdit(v2558,"push",v2559);
const v2561=v2510["maximum"];
const v2562=v2510["failed"];
const v2563=({["nodes"]:v2560,["maximum"]:v2561,["failed"]:v2562});
v2550=v2557;
v2551=v2563;
}
v2544=v2550;
v2545=v2551;
}
const v2565=v2544;
const v2566=v2545;
const v2569=3;
const v2570=1;
let v2571;if((v2569===v2570)){
const v2572=v2565["value"];
const v2573=v2565["value"];
v2571=__bits(__float(v2572) + __float(v2573));}else{
const v2574=2;
let v2575;if((v2569===v2574)){
const v2576=v2565["value"];
const v2577=v2565["value"];
v2575=__bits(__float(v2576) - __float(v2577));}else{
const v2578=3;
let v2579;if((v2569===v2578)){
const v2580=v2565["value"];
const v2581=v2565["value"];
v2579=__bits(__float(v2580) * __float(v2581));}else{
v2579=__bits((__float(v2565["value"]))/(__float(v2565["value"])));}
v2575=v2579;}
v2571=v2575;}
const v2582=v2571;
const v2583=v2565["id"];
const v2584=v2565["id"];
const v2585=v2565["value"];
const v2586=v2565["value"];
const v2588=v2565["id"];
const v2589=4294967295;
const v2590=!(v2588===v2589);
let v2591=v2590;if(!v2591){
const v2592=v2565["id"];
const v2593=4294967295;
v2591=!(v2592===v2593);}
const v2594=v2591;
const v2595=false;
const v2596=(v2594===v2595);
let v2597=v2596;if(!v2597){
v2597=v2566["failed"];}
let v2598;
let v2599;
if(v2597){
const v2600=__fn11(v2582);
v2598=v2600;
v2599=v2566;
}else{
const v2601=v2566["nodes"];
const v2602=(v2601).length;
const v2603=v2566["maximum"];
let v2604;
let v2605;
if(((v2602) >= (v2603))){
const v2606=__fn11(v2582);
const v2607=true;
const v2608=v2566["nodes"];
const v2609=v2566["maximum"];
const v2610=({["nodes"]:v2608,["maximum"]:v2609,["failed"]:v2607});
v2604=v2606;
v2605=v2610;
}else{
const v2611=({["value"]:v2582,["id"]:v2602});
const v2612=v2566["nodes"];
const v2613=({["op"]:v2569,["a"]:v2583,["b"]:v2584,["av"]:v2585,["bv"]:v2586,["value"]:v2582});
const v2614=__tempEdit(v2612,"push",v2613);
const v2615=v2566["maximum"];
const v2616=v2566["failed"];
const v2617=({["nodes"]:v2614,["maximum"]:v2615,["failed"]:v2616});
v2604=v2611;
v2605=v2617;
}
v2598=v2604;
v2599=v2605;
}
const v2350=({["value"]:v2598,["tape"]:v2599});
const v2618=v2350;
const v2619=v2618["tape"];
const v2620=v2619["failed"];
let v2621;if(v2620){
v2621=({Err:"reverse differentiation tape capacity exceeded"});}else{
let v2622;if(v2625&&v2624){v2622=v2623;}else{
const v2626=v2350;
const v2627=v2626["tape"];
const v2628=v2627["nodes"];
const v2629=v2628.freeze();
const v2631=v2350;
const v2632=v2631["value"];
let v2636;if(v2635){if(!v2633){const v2634=__preparedFactories.get(19);v2633=v2634([v2630,v2630,fixed[2]],depth+1);}v2636=v2633(v2629,v2632,v2288);}else{v2636=__fn19(v2629,v2632,v2288);}
v2622=v2636;if(v2625){v2623=v2622;v2624=true;}}
const v2637=v2350;
const v2638=v2637["value"];
const v2639=v2638["value"];
const v2640=v2293;
const v2641=v2640["value"];
const v2642=v2641.length;
const v2643=new Array(v2642);
for(let v2644=0;v2644<v2642;v2644++){
const v2645=v2641[v2644];
const v2646=v2622;
const v2647=v2645["id"];
let v2648;if(v2647<v2646.length){v2648=v2646[v2647];}else{
v2648=0;}
v2643[v2644]=v2648;
}
v2621=({Ok:({["value"]:v2639,["gradient"]:v2643})});}
v2292=v2621;}
return v2292;};}
const __preparedFactories=new Map([[2,__prepareFn2],[3,__prepareFn3],[4,__prepareFn4],[22,__prepareFn22],[23,__prepareFn23]]);
