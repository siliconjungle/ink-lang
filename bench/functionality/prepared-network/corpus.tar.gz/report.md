# Planning corpus report

Target `javascript`, effort `quick`, compiler `540c226296b9`, knowledge snapshot `14edbdd3dea8`.

| Measure | Value |
|---|---:|
| Programs compiled | 10 / 10 |
| With an admitted rewrite alternative | 2 |
| With any knowledge-backed alternative | 2 |
| Selecting an alternative under defaults | 0 |
| Stopped by the time budget | 10 |
| Median planning seconds | 45.588499999999996 |
| Laws admitted (in 2+ programs) | 4 (0) |
| Representations admitted | 0 |

## Programs

| Program | Seconds | Stop | Matched | Admitted | Rejected | Unchecked | Rewrite alts | Last gate |
|---|---:|---|---:|---:|---:|---:|---:|---|
| sequence-every | 26 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| ast-ancestor | 27 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| text-lines | 51 | time | 0 | 0 | 0 | 0 | 8 | measurement_evidence |
| drawing-hit | 53 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| particle-step | 45 | time | 1 | 1 | 0 | 0 | 1 | measurement_evidence |
| spatial-collision | 36 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| index-membership | 50 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| incremental-distinct | 32 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| bulk-update | 46 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |
| compact-set | 50 | time | 0 | 0 | 0 | 0 | 0 | no_alternative |

## Near misses

Checker rejection gates: none

| Failed premise shape | Rejections | Programs |
|---|---:|---|

| Failed premise as instantiated in the program | Rejections | Programs |
|---|---:|---|

## Where planning time went

| Recipe | Seconds | Share |
|---|---:|---:|
| proved-observations | 11.86 | 34% |
| maintained-folds | 7.58 | 22% |
| all-published-packages | 3.88 | 11% |
| database-source-algorithms | 3.74 | 11% |
| semantic-laws | 2.99 | 8% |
| pure-routing | 1.62 | 5% |
| source-capabilities | 1.33 | 4% |
| scalar-observation-arguments | 0.85 | 2% |
| whole-state-protocols | 0.69 | 2% |
| guarded-parameter-cache | 0.56 | 2% |
| compact-observer | 0.0 | 0% |
| representation-products | 0.0 | 0% |
| first-order-choices | 0.0 | 0% |
| migration-bridges | 0.0 | 0% |
| residual-execution-carriers | 0.0 | 0% |

## Admitted knowledge by program

| Entry | Kind | Programs |
|---|---|---|
| 0ed2e74a78dff510 | law | particle-step |
| sets.indexed-construction.u32.word_equal_symmetric | law | text-lines |
| 7069b2b125e492c9 | law | text-lines |
| 8c2dc4e9d4ed881c | law | text-lines |

Observed default planning on a fixed corpus; no proof, applicability or profitability authority.
