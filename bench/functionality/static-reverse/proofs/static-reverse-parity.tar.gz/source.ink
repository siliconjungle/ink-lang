module WholeLearning;
record Block{w0:f32,w1:f32,w2:f32,w3:f32,w4:f32,w5:f32,w6:f32,w7:f32,}
record Weights{b0:Block,b1:Block,b2:Block,b3:Block,b4:Block,b5:Block,b6:Block,b7:Block,}
fn block(w:Block)->f32{return w.w0*w.w0+w.w1*w.w1+w.w2*w.w2+w.w3*w.w3+w.w4*w.w4+w.w5*w.w5+w.w6*w.w6+w.w7*w.w7;}
fn energy(w:Weights,target:f32)->f32{let error=block(w.b0)+block(w.b1)+block(w.b2)+block(w.b3)+block(w.b4)+block(w.b5)+block(w.b6)+block(w.b7)-target;return error*error;}
fn derivatives(w:Weights,target:f32,maximum:u32,stop:Bool)->Result<Weights,String>{return compiled_reverse_gradient(energy,w,maximum,stop,target);}
fn linearized(w:Weights,target:f32,maximum:u32,stop:Bool)->Result<f32,String>{return compiled_reverse_linearize(energy,w,maximum,stop,target).map(fn(r)=>r.value);}
fn update(w:Weights,g:Weights,rate:f32)->Weights{return Weights{b0:Block{w0:w.b0.w0-rate*g.b0.w0,w1:w.b0.w1-rate*g.b0.w1,w2:w.b0.w2-rate*g.b0.w2,w3:w.b0.w3-rate*g.b0.w3,w4:w.b0.w4-rate*g.b0.w4,w5:w.b0.w5-rate*g.b0.w5,w6:w.b0.w6-rate*g.b0.w6,w7:w.b0.w7-rate*g.b0.w7},b1:Block{w0:w.b1.w0-rate*g.b1.w0,w1:w.b1.w1-rate*g.b1.w1,w2:w.b1.w2-rate*g.b1.w2,w3:w.b1.w3-rate*g.b1.w3,w4:w.b1.w4-rate*g.b1.w4,w5:w.b1.w5-rate*g.b1.w5,w6:w.b1.w6-rate*g.b1.w6,w7:w.b1.w7-rate*g.b1.w7},b2:Block{w0:w.b2.w0-rate*g.b2.w0,w1:w.b2.w1-rate*g.b2.w1,w2:w.b2.w2-rate*g.b2.w2,w3:w.b2.w3-rate*g.b2.w3,w4:w.b2.w4-rate*g.b2.w4,w5:w.b2.w5-rate*g.b2.w5,w6:w.b2.w6-rate*g.b2.w6,w7:w.b2.w7-rate*g.b2.w7},b3:Block{w0:w.b3.w0-rate*g.b3.w0,w1:w.b3.w1-rate*g.b3.w1,w2:w.b3.w2-rate*g.b3.w2,w3:w.b3.w3-rate*g.b3.w3,w4:w.b3.w4-rate*g.b3.w4,w5:w.b3.w5-rate*g.b3.w5,w6:w.b3.w6-rate*g.b3.w6,w7:w.b3.w7-rate*g.b3.w7},b4:Block{w0:w.b4.w0-rate*g.b4.w0,w1:w.b4.w1-rate*g.b4.w1,w2:w.b4.w2-rate*g.b4.w2,w3:w.b4.w3-rate*g.b4.w3,w4:w.b4.w4-rate*g.b4.w4,w5:w.b4.w5-rate*g.b4.w5,w6:w.b4.w6-rate*g.b4.w6,w7:w.b4.w7-rate*g.b4.w7},b5:Block{w0:w.b5.w0-rate*g.b5.w0,w1:w.b5.w1-rate*g.b5.w1,w2:w.b5.w2-rate*g.b5.w2,w3:w.b5.w3-rate*g.b5.w3,w4:w.b5.w4-rate*g.b5.w4,w5:w.b5.w5-rate*g.b5.w5,w6:w.b5.w6-rate*g.b5.w6,w7:w.b5.w7-rate*g.b5.w7},b6:Block{w0:w.b6.w0-rate*g.b6.w0,w1:w.b6.w1-rate*g.b6.w1,w2:w.b6.w2-rate*g.b6.w2,w3:w.b6.w3-rate*g.b6.w3,w4:w.b6.w4-rate*g.b6.w4,w5:w.b6.w5-rate*g.b6.w5,w6:w.b6.w6-rate*g.b6.w6,w7:w.b6.w7-rate*g.b6.w7},b7:Block{w0:w.b7.w0-rate*g.b7.w0,w1:w.b7.w1-rate*g.b7.w1,w2:w.b7.w2-rate*g.b7.w2,w3:w.b7.w3-rate*g.b7.w3,w4:w.b7.w4-rate*g.b7.w4,w5:w.b7.w5-rate*g.b7.w5,w6:w.b7.w6-rate*g.b7.w6,w7:w.b7.w7-rate*g.b7.w7}};}
fn step(w:Weights,target:f32,rate:f32)->Weights{return derivatives(w,target,4096,true).fold(fn(g)=>update(w,g,rate),fn(e)=>w);}

fn initial()->Weights{return Weights{b0:Block{w0:0,w1:0.0078125,w2:0.015625,w3:0.0234375,w4:0.03125,w5:0.0390625,w6:0.046875,w7:0.0546875},b1:Block{w0:0.0625,w1:0.0703125,w2:0.078125,w3:0.0859375,w4:0.09375,w5:0.1015625,w6:0.109375,w7:0.1171875},b2:Block{w0:0.125,w1:0.1328125,w2:0.140625,w3:0.1484375,w4:0.15625,w5:0.1640625,w6:0.171875,w7:0.1796875},b3:Block{w0:0.1875,w1:0.1953125,w2:0.203125,w3:0.2109375,w4:0.21875,w5:0.2265625,w6:0.234375,w7:0.2421875},b4:Block{w0:0.25,w1:0.2578125,w2:0.265625,w3:0.2734375,w4:0.28125,w5:0.2890625,w6:0.296875,w7:0.3046875},b5:Block{w0:0.3125,w1:0.3203125,w2:0.328125,w3:0.3359375,w4:0.34375,w5:0.3515625,w6:0.359375,w7:0.3671875},b6:Block{w0:0.375,w1:0.3828125,w2:0.390625,w3:0.3984375,w4:0.40625,w5:0.4140625,w6:0.421875,w7:0.4296875},b7:Block{w0:0.4375,w1:0.4453125,w2:0.453125,w3:0.4609375,w4:0.46875,w5:0.4765625,w6:0.484375,w7:0.4921875}};}
fn valid_block(w:Block)->Bool{return is_finite(w.w0)&&is_finite(w.w1)&&is_finite(w.w2)&&is_finite(w.w3)&&is_finite(w.w4)&&is_finite(w.w5)&&is_finite(w.w6)&&is_finite(w.w7);}fn valid(w:Weights)->Bool{return valid_block(w.b0)&&valid_block(w.b1)&&valid_block(w.b2)&&valid_block(w.b3)&&valid_block(w.b4)&&valid_block(w.b5)&&valid_block(w.b6)&&valid_block(w.b7);}

trainable state Parameters:Weights=initial();
event learned:f32;
query parameters()->Weights reads(Parameters){return Parameters;}
query loss(target:f32)->f32 reads(Parameters){return energy(Parameters,target);}
learn change observe(target:f32,rate:f32,maximum:u32)->Result<f32,String>
 reads(Parameters) writes(Parameters) emits(learned)
 requires(is_finite(target)&&rate>0.0&&rate<=1.0,"training domain")
 ensures(result=>valid(Parameters),"finite weights") {
 let gradient=derivatives(Parameters,target,maximum,true)?;
 Parameters=update(Parameters,gradient,rate);
 let value=energy(Parameters,target);emit learned(value);return Ok(value);
}

fn device(xs:List<f32>)->List<f32>{return xs.map(fn(x)=>x*2.0+1.0);}
record Flat{v0:f32,v1:f32,v2:f32,v3:f32,v4:f32,v5:f32,v6:f32,v7:f32,v8:f32,v9:f32,v10:f32,v11:f32,v12:f32,v13:f32,v14:f32,v15:f32,v16:f32,v17:f32,v18:f32,v19:f32,v20:f32,v21:f32,v22:f32,v23:f32,v24:f32,v25:f32,v26:f32,v27:f32,v28:f32,v29:f32,v30:f32,v31:f32,v32:f32,v33:f32,v34:f32,v35:f32,v36:f32,v37:f32,v38:f32,v39:f32,v40:f32,v41:f32,v42:f32,v43:f32,v44:f32,v45:f32,v46:f32,v47:f32,v48:f32,v49:f32,v50:f32,v51:f32,v52:f32,v53:f32,v54:f32,v55:f32,v56:f32,v57:f32,v58:f32,v59:f32,v60:f32,v61:f32,v62:f32,v63:f32,}fn flat(value:Flat)->Flat{return value;}