#[path="../../gpu/f0/native/src/lib.rs"] mod part0;
#[path="../../gpu/f1/native/src/lib.rs"] mod part1;
#[path="../../gpu/f4/native/src/lib.rs"] mod part4;
#[path="../../gpu/f6/native/src/lib.rs"] mod part6;
#[path="../../gpu/f7/native/src/lib.rs"] mod part7;
#[path="../../gpu/f8/native/src/lib.rs"] mod part8;
#[path="../../gpu/f9/native/src/lib.rs"] mod part9;
#[path="../../gpu/f10/native/src/lib.rs"] mod part10;
#[path="../../gpu/f11/native/src/lib.rs"] mod part11;
#[path="../../gpu/f12/native/src/lib.rs"] mod part12;
#[path="../../gpu/f13/native/src/lib.rs"] mod part13;

struct GpuEngines{part0:part0::Engine,part1:part1::Engine,part4:part4::Engine,part6:part6::Engine,part7:part7::Engine,part8:part8::Engine,part9:part9::Engine,part10:part10::Engine,part11:part11::Engine,part12:part12::Engine,part13:part13::Engine,}impl GpuEngines{fn new()->Self{Self{part0:part0::Engine::new(),part1:part1::Engine::new(),part4:part4::Engine::new(),part6:part6::Engine::new(),part7:part7::Engine::new(),part8:part8::Engine::new(),part9:part9::Engine::new(),part10:part10::Engine::new(),part11:part11::Engine::new(),part12:part12::Engine::new(),part13:part13::Engine::new(),}} fn call(&mut self,name:&str,args:&serde_json::Value,backend:&str,options:Option<&serde_json::Value>)->Result<serde_json::Value,String>{match name{"block"=>{if let Some(options)=options{self.part0.configure_selection(options.clone())?;}self.part0.call(name,args,part0::Backend::parse(backend)?) },
"energy"=>{if let Some(options)=options{self.part1.configure_selection(options.clone())?;}self.part1.call(name,args,part1::Backend::parse(backend)?) },
"update"=>{if let Some(options)=options{self.part4.configure_selection(options.clone())?;}self.part4.call(name,args,part4::Backend::parse(backend)?) },
"initial"=>{if let Some(options)=options{self.part6.configure_selection(options.clone())?;}self.part6.call(name,args,part6::Backend::parse(backend)?) },
"valid_block"=>{if let Some(options)=options{self.part7.configure_selection(options.clone())?;}self.part7.call(name,args,part7::Backend::parse(backend)?) },
"valid"=>{if let Some(options)=options{self.part8.configure_selection(options.clone())?;}self.part8.call(name,args,part8::Backend::parse(backend)?) },
"device"=>{if let Some(options)=options{self.part9.configure_selection(options.clone())?;}self.part9.call(name,args,part9::Backend::parse(backend)?) },
"flat"=>{if let Some(options)=options{self.part10.configure_selection(options.clone())?;}self.part10.call(name,args,part10::Backend::parse(backend)?) },
"__ink_reverse_1"=>{if let Some(options)=options{self.part11.configure_selection(options.clone())?;}self.part11.call(name,args,part11::Backend::parse(backend)?) },
"__ink_reverse_2"=>{if let Some(options)=options{self.part12.configure_selection(options.clone())?;}self.part12.call(name,args,part12::Backend::parse(backend)?) },
"__ink_reverse_3"=>{if let Some(options)=options{self.part13.configure_selection(options.clone())?;}self.part13.call(name,args,part13::Backend::parse(backend)?) },
_=>Err("CPU-only function".into())}}}
include!("state-cli.rs");
fn run() -> Result<(), String> {
    let mut engines = GpuEngines::new();
    run_with_pure_initialized(compiled_state::initial_state,|state, step| {
        let name = step["pure"].as_str().ok_or("missing pure")?;
        let backend = step["backend"].as_str().unwrap_or("auto");
        if !["auto", "cpu", "gpu", "gpu-required"].contains(&backend) {
            return Err("invalid native backend".into());
        }
        if let Some(options)=step.get("selection") {
            ink_abi::selection::decide(options,&serde_json::json!({}),&["cpu".into()])?;
        }
        if backend == "cpu" {
            state
                .pure(name, &step["args"])
                .map(|v| serde_json::json!({"value":v,"backend":"cpu"}))
        } else {
            engines.call(name, &step["args"], backend, step.get("selection")).or_else(|e| {
                if backend=="gpu-required"{return Err(e);}
                state
                    .pure(name, &step["args"])
                    .map(|v| serde_json::json!({"value":v,"backend":"cpu","reason":e}))
            })
        }
    })
}
fn main() -> std::process::ExitCode {
    match run() {
        Ok(()) => std::process::ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("error: {e}");
            std::process::ExitCode::FAILURE
        }
    }
}
