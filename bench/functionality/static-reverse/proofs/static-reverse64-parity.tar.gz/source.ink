module WholeLearning;
record Block{w0:f64,w1:f64,w2:f64,w3:f64,w4:f64,w5:f64,w6:f64,w7:f64,}
record Weights{b0:Block,b1:Block,b2:Block,b3:Block,b4:Block,b5:Block,b6:Block,b7:Block,}
fn block(w:Block)->f64{return w.w0*w.w0+w.w1*w.w1+w.w2*w.w2+w.w3*w.w3+w.w4*w.w4+w.w5*w.w5+w.w6*w.w6+w.w7*w.w7;}
fn energy(w:Weights,target:f64)->f64{let error=block(w.b0)+block(w.b1)+block(w.b2)+block(w.b3)+block(w.b4)+block(w.b5)+block(w.b6)+block(w.b7)-target;return error*error;}
fn derivatives(w:Weights,target:f64,maximum:u32,stop:Bool)->Result<Weights,String>{return compiled_reverse_gradient(energy,w,maximum,stop,target);}
fn linearized(w:Weights,target:f64,maximum:u32,stop:Bool)->Result<f64,String>{return compiled_reverse_linearize(energy,w,maximum,stop,target).map(fn(r)=>r.value);}
fn update(w:Weights,g:Weights,rate:f64)->Weights{return Weights{b0:Block{w0:w.b0.w0-rate*g.b0.w0,w1:w.b0.w1-rate*g.b0.w1,w2:w.b0.w2-rate*g.b0.w2,w3:w.b0.w3-rate*g.b0.w3,w4:w.b0.w4-rate*g.b0.w4,w5:w.b0.w5-rate*g.b0.w5,w6:w.b0.w6-rate*g.b0.w6,w7:w.b0.w7-rate*g.b0.w7},b1:Block{w0:w.b1.w0-rate*g.b1.w0,w1:w.b1.w1-rate*g.b1.w1,w2:w.b1.w2-rate*g.b1.w2,w3:w.b1.w3-rate*g.b1.w3,w4:w.b1.w4-rate*g.b1.w4,w5:w.b1.w5-rate*g.b1.w5,w6:w.b1.w6-rate*g.b1.w6,w7:w.b1.w7-rate*g.b1.w7},b2:Block{w0:w.b2.w0-rate*g.b2.w0,w1:w.b2.w1-rate*g.b2.w1,w2:w.b2.w2-rate*g.b2.w2,w3:w.b2.w3-rate*g.b2.w3,w4:w.b2.w4-rate*g.b2.w4,w5:w.b2.w5-rate*g.b2.w5,w6:w.b2.w6-rate*g.b2.w6,w7:w.b2.w7-rate*g.b2.w7},b3:Block{w0:w.b3.w0-rate*g.b3.w0,w1:w.b3.w1-rate*g.b3.w1,w2:w.b3.w2-rate*g.b3.w2,w3:w.b3.w3-rate*g.b3.w3,w4:w.b3.w4-rate*g.b3.w4,w5:w.b3.w5-rate*g.b3.w5,w6:w.b3.w6-rate*g.b3.w6,w7:w.b3.w7-rate*g.b3.w7},b4:Block{w0:w.b4.w0-rate*g.b4.w0,w1:w.b4.w1-rate*g.b4.w1,w2:w.b4.w2-rate*g.b4.w2,w3:w.b4.w3-rate*g.b4.w3,w4:w.b4.w4-rate*g.b4.w4,w5:w.b4.w5-rate*g.b4.w5,w6:w.b4.w6-rate*g.b4.w6,w7:w.b4.w7-rate*g.b4.w7},b5:Block{w0:w.b5.w0-rate*g.b5.w0,w1:w.b5.w1-rate*g.b5.w1,w2:w.b5.w2-rate*g.b5.w2,w3:w.b5.w3-rate*g.b5.w3,w4:w.b5.w4-rate*g.b5.w4,w5:w.b5.w5-rate*g.b5.w5,w6:w.b5.w6-rate*g.b5.w6,w7:w.b5.w7-rate*g.b5.w7},b6:Block{w0:w.b6.w0-rate*g.b6.w0,w1:w.b6.w1-rate*g.b6.w1,w2:w.b6.w2-rate*g.b6.w2,w3:w.b6.w3-rate*g.b6.w3,w4:w.b6.w4-rate*g.b6.w4,w5:w.b6.w5-rate*g.b6.w5,w6:w.b6.w6-rate*g.b6.w6,w7:w.b6.w7-rate*g.b6.w7},b7:Block{w0:w.b7.w0-rate*g.b7.w0,w1:w.b7.w1-rate*g.b7.w1,w2:w.b7.w2-rate*g.b7.w2,w3:w.b7.w3-rate*g.b7.w3,w4:w.b7.w4-rate*g.b7.w4,w5:w.b7.w5-rate*g.b7.w5,w6:w.b7.w6-rate*g.b7.w6,w7:w.b7.w7-rate*g.b7.w7}};}
fn step(w:Weights,target:f64,rate:f64)->Weights{return derivatives(w,target,4096,true).fold(fn(g)=>update(w,g,rate),fn(e)=>w);}

fn initial()->Weights{return Weights{b0:Block{w0:0,w1:0.0078125f64,w2:0.015625f64,w3:0.0234375f64,w4:0.03125f64,w5:0.0390625f64,w6:0.046875f64,w7:0.0546875f64},b1:Block{w0:0.0625f64,w1:0.0703125f64,w2:0.078125f64,w3:0.0859375f64,w4:0.09375f64,w5:0.1015625f64,w6:0.109375f64,w7:0.1171875f64},b2:Block{w0:0.125f64,w1:0.1328125f64,w2:0.140625f64,w3:0.1484375f64,w4:0.15625f64,w5:0.1640625f64,w6:0.171875f64,w7:0.1796875f64},b3:Block{w0:0.1875f64,w1:0.1953125f64,w2:0.203125f64,w3:0.2109375f64,w4:0.21875f64,w5:0.2265625f64,w6:0.234375f64,w7:0.2421875f64},b4:Block{w0:0.25f64,w1:0.2578125f64,w2:0.265625f64,w3:0.2734375f64,w4:0.28125f64,w5:0.2890625f64,w6:0.296875f64,w7:0.3046875f64},b5:Block{w0:0.3125f64,w1:0.3203125f64,w2:0.328125f64,w3:0.3359375f64,w4:0.34375f64,w5:0.3515625f64,w6:0.359375f64,w7:0.3671875f64},b6:Block{w0:0.375f64,w1:0.3828125f64,w2:0.390625f64,w3:0.3984375f64,w4:0.40625f64,w5:0.4140625f64,w6:0.421875f64,w7:0.4296875f64},b7:Block{w0:0.4375f64,w1:0.4453125f64,w2:0.453125f64,w3:0.4609375f64,w4:0.46875f64,w5:0.4765625f64,w6:0.484375f64,w7:0.4921875f64}};}
fn valid_block(w:Block)->Bool{return is_finite(w.w0)&&is_finite(w.w1)&&is_finite(w.w2)&&is_finite(w.w3)&&is_finite(w.w4)&&is_finite(w.w5)&&is_finite(w.w6)&&is_finite(w.w7);}fn valid(w:Weights)->Bool{return valid_block(w.b0)&&valid_block(w.b1)&&valid_block(w.b2)&&valid_block(w.b3)&&valid_block(w.b4)&&valid_block(w.b5)&&valid_block(w.b6)&&valid_block(w.b7);}

trainable state Parameters:Weights=initial();
event learned:f64;
query parameters()->Weights reads(Parameters){return Parameters;}
query loss(target:f64)->f64 reads(Parameters){return energy(Parameters,target);}
learn change observe(target:f64,rate:f64,maximum:u32)->Result<f64,String>
 reads(Parameters) writes(Parameters) emits(learned)
 requires(is_finite(target)&&rate>0.0f64&&rate<=1.0f64,"training domain")
 ensures(result=>valid(Parameters),"finite weights") {
 let gradient=derivatives(Parameters,target,maximum,true)?;
 Parameters=update(Parameters,gradient,rate);
 let value=energy(Parameters,target);emit learned(value);return Ok(value);
}

fn device(xs:List<f32>)->List<f32>{return xs.map(fn(x)=>x*2.0+1.0);}
record Flat{v0:f64,v1:f64,v2:f64,v3:f64,v4:f64,v5:f64,v6:f64,v7:f64,v8:f64,v9:f64,v10:f64,v11:f64,v12:f64,v13:f64,v14:f64,v15:f64,v16:f64,v17:f64,v18:f64,v19:f64,v20:f64,v21:f64,v22:f64,v23:f64,v24:f64,v25:f64,v26:f64,v27:f64,v28:f64,v29:f64,v30:f64,v31:f64,v32:f64,v33:f64,v34:f64,v35:f64,v36:f64,v37:f64,v38:f64,v39:f64,v40:f64,v41:f64,v42:f64,v43:f64,v44:f64,v45:f64,v46:f64,v47:f64,v48:f64,v49:f64,v50:f64,v51:f64,v52:f64,v53:f64,v54:f64,v55:f64,v56:f64,v57:f64,v58:f64,v59:f64,v60:f64,v61:f64,v62:f64,v63:f64,}fn flat(value:Flat)->Flat{return value;}