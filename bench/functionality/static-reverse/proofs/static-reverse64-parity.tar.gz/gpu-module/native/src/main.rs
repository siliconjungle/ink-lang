#[path="../../gpu/f9/native/src/lib.rs"] mod part9;

struct GpuEngines{part9:part9::Engine,}impl GpuEngines{fn new()->Self{Self{part9:part9::Engine::new(),}} fn call(&mut self,name:&str,args:&serde_json::Value,backend:&str,options:Option<&serde_json::Value>)->Result<serde_json::Value,String>{match name{"device"=>{if let Some(options)=options{self.part9.configure_selection(options.clone())?;}self.part9.call(name,args,part9::Backend::parse(backend)?) },
_=>Err("CPU-only function".into())}}}
include!("state-cli.rs");
fn run() -> Result<(), String> {
    let mut engines = GpuEngines::new();
    run_with_pure_initialized(compiled_state::initial_state,|state, step| {
        let name = step["pure"].as_str().ok_or("missing pure")?;
        let backend = step["backend"].as_str().unwrap_or("auto");
        if !["auto", "cpu", "gpu", "gpu-required"].contains(&backend) {
            return Err("invalid native backend".into());
        }
        if let Some(options)=step.get("selection") {
            ink_abi::selection::decide(options,&serde_json::json!({}),&["cpu".into()])?;
        }
        if backend == "cpu" {
            state
                .pure(name, &step["args"])
                .map(|v| serde_json::json!({"value":v,"backend":"cpu"}))
        } else {
            engines.call(name, &step["args"], backend, step.get("selection")).or_else(|e| {
                if backend=="gpu-required"{return Err(e);}
                state
                    .pure(name, &step["args"])
                    .map(|v| serde_json::json!({"value":v,"backend":"cpu","reason":e}))
            })
        }
    })
}
fn main() -> std::process::ExitCode {
    match run() {
        Ok(()) => std::process::ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("error: {e}");
            std::process::ExitCode::FAILURE
        }
    }
}
