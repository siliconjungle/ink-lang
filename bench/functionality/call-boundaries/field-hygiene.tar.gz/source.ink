module field_hygiene;
record Row__ownedValueType{first__ownedValue:f32,second__ownedValue0:List<f32>,}
fn copy(xs:List<Row__ownedValueType>)->List<Row__ownedValueType>{return xs;}
