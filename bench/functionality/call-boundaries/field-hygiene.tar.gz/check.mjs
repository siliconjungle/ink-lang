import assert from 'node:assert/strict';import * as m from './program.mjs';
const input=[{first__ownedValue:{F32Bits:0x80000000},second__ownedValue0:[{F32Bits:0x7f812345}]}],c=m.compiledValues.copy,h=c.params[0].capture(input);
assert.deepEqual(c.result.materialize(m.callCompiled('copy',[h])),input);
const token=m.prepareCompiled('copy',[[0,h]]),out=[];
assert.equal(m.callPreparedCompiledInto(token,[],out),1);
assert.deepEqual(out,[{first__ownedValue:-0,second__ownedValue0:[{F32Bits:0x7f812345}]}]);
