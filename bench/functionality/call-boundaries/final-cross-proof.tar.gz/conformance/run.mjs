import assert from 'node:assert/strict';import fs from 'node:fs';import * as m from './program.mjs';
const history=JSON.parse(fs.readFileSync(new URL('history.json',import.meta.url)));
const normalize=v=>typeof v==='bigint'?String(v):typeof v==='number'&&Number.isInteger(v)?(Object.is(v,-0)?'negative zero':String(v)):Array.isArray(v)?v.map(normalize):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).map(([k,x])=>[k,normalize(x)])):v;
// Captured stateful-module pure entries normalize all float descendants before
// entering the helper. Borrowed pure-only entries keep their separate contract.
const input=structuredClone(history[0].args[0]);input.x=1+2**-25;input.values=[.1,-.1];input.pair=[2**24+1,-(2**-150)];
const output=m.functions.copy(input);assert.equal(output.x,Math.fround(input.x));assert.deepEqual(output.values,input.values.map(Math.fround));assert.deepEqual(output.pair,input.pair.map(Math.fround));
let reads=0;const tagged={get F32Bits(){reads++;return 0x7f812345;}};input.x=tagged;assert.deepEqual(m.functions.copy(input).x,{F32Bits:0x7f812345});assert.equal(reads,1);
assert.deepEqual(m.functions.device([-1,0,1]),[-1,1,3]);
for(const mode of ['invoke','prepared','bound']){
 const state=m.createState(),bindings=new Map();
 for(const step of history){
  if(!bindings.has(step.name))bindings.set(step.name,state.bind(step.name));
  const args=structuredClone(step.args);
  const reply=mode==='prepared'?state.invokePrepared(state.prepare(step.name,args)):mode==='bound'?bindings.get(step.name)(...args):state.invoke(step.name,args);
  assert.deepEqual(normalize(reply),normalize(step.reply),`${mode}:${step.name}`);
  assert.deepEqual(args,step.args);
  assert.deepEqual([...await state.checkpoint()],step.snapshot);
  if(step.name==='read'&&reply.result.length){reply.result[0].values[0]=123;reply.result[0].x=123;}
 }
 const before=await state.checkpoint();state.beginTransaction();bindings.get('remember')(-0);state.rollbackTransaction();assert.deepEqual(await state.checkpoint(),before);
 const restored=m.createState();await restored.restore(before);assert.deepEqual(await restored.checkpoint(),before);
 const step=history.at(-1);assert.deepEqual(normalize(await restored.invokeAsync(step.name,step.args)),normalize(step.reply));assert.deepEqual(await restored.checkpoint(),before);
 const events=state.outbox;events[0].value.values[0]=123;assert.deepEqual(await state.checkpoint(),before);
}
console.log(JSON.stringify({histories:3,steps:history.length,referenceSnapshots:true,prepared:true,bound:true,hostRollback:true,workerState:true,detached:true}));
