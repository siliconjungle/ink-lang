const __recordElisions=new Set([]);
const __nativeF32=false;
// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
// Binary64 uses native Numbers for finite arithmetic and immutable private
// tags only where a NaN's exact payload must survive non-arithmetic operations.
const __doubleView=new DataView(new ArrayBuffer(8));
const __double=bits=>{__doubleView.setBigUint64(0,bits,true);return __doubleView.getFloat64(0,true);};
const __doubleBits=number=>{if(Number.isNaN(number))return 0x7ff8000000000000n;__doubleView.setFloat64(0,number,true);return __doubleView.getBigUint64(0,true);};
const __dfNumber=value=>typeof value==='number'?value:__double(BigInt(value.F64Bits));
const __dfBits=value=>typeof value==='number'?__doubleBits(value):BigInt(value.F64Bits);
const __dfFromBits=bits=>(bits&0x7fffffffffffffffn)>0x7ff0000000000000n?Object.freeze({F64Bits:bits.toString()}):__double(bits);
const __dfInput=value=>typeof value==='number'?value:__dfFromBits(BigInt(value.F64Bits));
const __dfNeg=value=>typeof value==='number'&&!Number.isNaN(value)?-value:__dfFromBits(__dfBits(value)^0x8000000000000000n);
const __dfOutput=value=>{const n=__dfNumber(value);return Number.isFinite(n)?n:{F64Bits:__dfBits(value).toString()};};
const __dfCapture=value=>{
 if(typeof value==='number'&&Number.isFinite(value))return value;
 if(!value||typeof value!=='object'||Object.keys(value).length!==1||!Object.hasOwn(value,'F64Bits'))throw Error('invalid f64');const text=value.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid f64');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');return __dfFromBits(bits);
};
// Native binary32 lane for pure modules. Explicit NaN payloads remain tagged;
// arithmetic canonicalizes NaNs just as __bits does in the exact-bit lane.
// Host tags are captured once at a typed read. Only private immutable tags
// may pass through normalization without consulting a host property again.
const __nfTagged = new WeakSet();
const __nfValue = value => typeof value === 'number' ? Math.fround(value) : __nfTagged.has(value) ? value : __nfFromBits(value.F32Bits);
// Number operands have already been normalised at their typed read or producer.
const __nfNumber = value => typeof value === 'number' ? value : __float(value.F32Bits);
const __nfBits = value => typeof value === 'number' ? __bits(value) : value.F32Bits;
const __nfFromBits = bits => {
  if((bits & 0x7fffffff)<=0x7f800000)return __float(bits);
  const value=Object.freeze({F32Bits:bits});__nfTagged.add(value);return value;
};
const __nfNeg = value => typeof value === 'number' && !Number.isNaN(value) ? -value : __nfFromBits((__nfBits(value) ^ 0x80000000) >>> 0);
const __nfOutput = value => {const n=typeof value==='number'?Math.fround(value):__float(value.F32Bits);return Number.isFinite(n)?n:{F32Bits:__nfBits(value)};};
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output, capture=false) {
  const convert=__representationRaw(type,output,capture);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':capture?'capture:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output, capture) {
  switch (type.kind) {
    case 'ref': {
      let resolved;
      return (value,context)=>(resolved??=__representation(__namedTypes[type.name],output,capture))(value,context);
    }
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output,capture);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output,capture),err=__representation(type.error,output,capture);
      const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);
      if(flat)return output?(value,context)=>{const v=__sumView(key,value);return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};}:(v,context)=>Object.hasOwn(v,'Ok')?__sumMake(key,true,ok(v.Ok,context)):__sumMake(key,false,err(v.Err,context));
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f64':return output?__dfOutput:__dfInput;
    case 'f32': if(typeof __nativeF32!=='undefined'&&__nativeF32)return output?__nfOutput:capture?__nfValue:__identity;
      return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output,capture);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){
        if(!type.fields.length)return ()=>undefined; // lexically unconsumed projected input
        const field=type.fields[0],child=__representation(field.type,output,capture);
        return output?(value,context)=>({[field.name]:child(value,context)}):(value,context)=>child(value[field.name],context);
      }
      const fields = type.fields.map(field => [field.name, __representation(field.type, output,capture)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
function __stateWord(value){
 if(typeof value==='number'&&!Number.isSafeInteger(value))throw Error('u64 requires an exact integer');
 if(!['bigint','number','string'].includes(typeof value)||typeof value==='string'&&!/^(0|[1-9][0-9]*)$/.test(value))throw Error('invalid u64');
 const n=BigInt(value);if(n<0n||n>18446744073709551615n)throw Error('invalid u64');return n;
}
// Compile the capture traversal once. Each invocation still validates and owns
// every public container; no host value is retained between calls.
const __stateCaptures=new WeakMap();
function __stateCapture(type){
 const prior=__stateCaptures.get(type);if(prior)return prior;
 const capture=__compileStateCapture(type);__stateCaptures.set(type,capture);return capture;
}
function __compileStateCapture(type){
 const limited=copy=>(value,budget={cells:1000000},depth=0)=>{
  if(depth>64||--budget.cells<0)throw Error('state input resource limit');
  return copy(value,budget,depth);
 };
 const tagged=(value,tag)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
 switch(type.kind){
  case 'ref':{
   // Resolve lazily so recursive schemas compile to recursive validators rather
   // than reverting to descriptor interpretation at every referenced node.
   let resolved;
   return limited((value,budget,depth)=>(resolved??=__stateCapture(__namedTypes[type.name]))(value,budget,depth+1));
  }
  case 'u32':case 'i32':{
   const min=type.kind==='u32'?0:-2147483648,max=type.kind==='u32'?4294967295:2147483647;
   return limited(value=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;});
  }
  case 'u64':return limited(__stateWord);
  case 'f64':return limited(__dfCapture);
  case 'bool':return limited(value=>{if(typeof value!=='boolean')throw Error('invalid Bool');return value;});
  case 'unit':return limited(value=>{if(value!==null)throw Error('invalid Unit');return null;});
  case 'string':return limited(value=>{if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;});
  case 'enum':return limited(value=>{if(!type.variants.includes(value))throw Error('invalid enum');return value;});
  case 'id':return limited(value=>{if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();});
  case 'list':case 'vector':{
   const item=__stateCapture(type.element),size=type.kind==='vector'?type.size:null;
   return limited((value,budget,depth)=>{
    if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
    if(size!==null&&value.length!==size)throw Error('invalid vector length');
    const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=item(value[i],budget,depth+1);return out;
   });
  }
  case 'record':{
   const fields=type.fields.map(f=>[f.name,__stateCapture(f.type)]);
   if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name)))return limited((value,budget,depth)=>{const [name,copy]=fields[0];if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,name))throw Error('invalid record');return copy(value[name],budget,depth+1);});
   return limited((value,budget,depth)=>{
    if(!value||typeof value!=='object'||Array.isArray(value)||!fields.every(([name])=>Object.hasOwn(value,name)))throw Error('invalid record');
    const out={};for(const [name,copy]of fields){const field=copy(value[name],budget,depth+1);if(name==='__proto__')Object.defineProperty(out,name,{value:field,writable:true,enumerable:true,configurable:true});else out[name]=field;}return out;
   });
  }
  case 'option':{
   const item=__stateCapture(type.element);
   return limited((value,budget,depth)=>{if(tagged(value,'Some'))return {Some:item(value.Some,budget,depth+1)};if(tagged(value,'None')&&value.None===null)return {None:null};throw Error('invalid Option');});
  }
  case 'result':{
   const ok=__stateCapture(type.ok),err=__stateCapture(type.error);
   return limited((value,budget,depth)=>{if(tagged(value,'Ok'))return {Ok:ok(value.Ok,budget,depth+1)};if(tagged(value,'Err'))return {Err:err(value.Err,budget,depth+1)};throw Error('invalid Result');});
  }
  default:return (value,budget,depth)=>__stateInput(value,type,budget,depth);
 }
}
function __stateInput(value,type,budget={cells:1000000},depth=0,maxDepth=64){
  if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');
  const input=(v,t)=>__stateInput(v,t,budget,depth+1,maxDepth);
  const integer=(min,max)=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;};
  const tagged=tag=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
  switch(type.kind){
    case 'ref':return input(value,__namedTypes[type.name]);
    case 'u32':return integer(0,4294967295);
    case 'i32':return integer(-2147483648,2147483647);
    case 'u64':return __stateWord(value);
    case 'int':{
      if(typeof value==='bigint')return value;
      if(!tagged('Int')||typeof value.Int!=='string'||!/^(-?[0-9]+)$/.test(value.Int))throw Error('invalid Int');return BigInt(value.Int);
    }
    case 'f64':return __dfCapture(value);
    case 'f32':{
      if(typeof value==='number'&&Number.isFinite(value)){const bits=__bits(value);if((bits&0x7fffffff)===0x7f800000)throw Error('f32 overflow requires F32Bits');return bits;}
      if(!tagged('F32Bits')||!Number.isInteger(value.F32Bits)||value.F32Bits<0||value.F32Bits>4294967295)throw Error('invalid f32');return value.F32Bits;
    }
    case 'bool':if(typeof value!=='boolean')throw Error('invalid Bool');return value;
    case 'unit':if(value!==null)throw Error('invalid Unit');return null;
    case 'string':if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;
    case 'id':if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();
    case 'enum':if(!type.variants.includes(value))throw Error('invalid enum');return value;
    case 'list':case 'vector':{
      if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
      if(type.kind==='vector'&&value.length!==type.size)throw Error('invalid vector length');
      return Array.from(value,v=>input(v,type.element));
    }
    case 'record':if(!value||typeof value!=='object'||Array.isArray(value)||!type.fields.every(f=>Object.hasOwn(value,f.name)))throw Error('invalid record');if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){const f=type.fields[0];return input(value[f.name],f.type);}return Object.fromEntries(type.fields.map(f=>[f.name,input(value[f.name],f.type)]));
    case 'option':if(tagged('Some'))return {Some:input(value.Some,type.element)};if(tagged('None')&&value.None===null)return {None:null};throw Error('invalid Option');
    case 'result':{const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);if(tagged('Ok')){const child=input(value.Ok,type.ok);return flat?__sumMake(key,true,child):{Ok:child};}if(tagged('Err')){const child=input(value.Err,type.error);return flat?__sumMake(key,false,child):{Err:child};}throw Error('invalid Result');}
    default:throw Error('unsupported public value type');
  }
}
// Mutable host replies must not retain references into compiled state or its outbox.
// State results must own mutable containers. Compile the declared schema once:
// scalars need no structured clone, while nested records/lists remain detached.
function __ownershipSchema(type){
 // Nominal references and expanded declarations name the same checked sort.
 // Distinct source records retain distinct keys even if a layout erases them.
 if(type.kind==='ref'||type.kind==='record'&&type.name)return ['named',type.name];
 switch(type.kind){
  case 'list':case 'vector':return [type.kind,type.size??null,__ownershipSchema(type.element)];
  case 'option':return ['option',__ownershipSchema(type.element)];
  case 'result':return ['result',__ownershipSchema(type.ok),__ownershipSchema(type.error)];
  case 'record':return ['record',type.fields.map(f=>[f.name,__ownershipSchema(f.type)])];
  default:return type;
 }
}
function __ownedResult(copy,nested,type){
 const key='owned-state:'+JSON.stringify(__ownershipSchema(type));
 let schema=__conversionKeys.get(key);
 if(!schema){schema={};__conversionKeys.set(key,schema);}
 const owned=(value,context)=>{
  if(!context&&!nested)return copy(value,null);
  const memo=context||new WeakMap();
  if(value===null||typeof value!=='object')return copy(value,memo);
  let entries=memo.get(schema);if(!entries){entries=new WeakMap();memo.set(schema,entries);}
  if(entries.has(value))return entries.get(value);
  const result=copy(value,memo);entries.set(value,result);return result;
 };
 owned.container=true;return owned;
}
function __stateResult(type){
 switch(type.kind){
  // State storage is always exact bits, independently of pure helper carriers.
  case 'f32':return value=>{const number=__float(value);return Number.isFinite(number)?number:{F32Bits:value};};
  case 'ref':{let resolved;const copy=(value,context)=>(resolved??=__stateResult(__namedTypes[type.name]))(value,context);copy.container=true;return copy;}
  case 'record':{if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){const f=type.fields[0],copy=__stateResult(f.type);return __ownedResult((value,context)=>({[f.name]:copy(value,context)}),copy.container,type);}const fields=type.fields.map(f=>[f.name,__stateResult(f.type)]);return __ownedResult((value,context)=>Object.fromEntries(fields.map(([name,copy])=>[name,copy(value[name],context)])),fields.some(([,copy])=>copy.container),type);}
  case 'list':case 'vector':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Array.from(value,item=>copy(item,context)),copy.container,type);}
  case 'option':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Object.hasOwn(value,'Some')?{Some:copy(value.Some,context)}:{None:null},copy.container,type);}
  case 'result':{const ok=__stateResult(type.ok),err=__stateResult(type.error),key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);return __ownedResult((value,context)=>{const v=flat?__sumView(key,value):value;return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};},ok.container||err.container,type);}
  default:return __representation(type,true);
 }
}
function __stateOutput(value,type){return __stateResult(type)(value);}
const __u64 = n => BigInt.asUintN(64, n);
function __div(a, b, fallback, signed, remainder) {
  if (b === 0 || b === 0n || (signed && a === -2147483648 && b === -1)) return fallback();
  return typeof a === 'bigint' ? (remainder ? a % b : a / b) :
    ((remainder ? a % b : Math.trunc(a / b)) + 0); // integer zero has no sign
}
function __at(xs, index, fallback) { return index < xs.length ? xs[index] : fallback(); }
// Ordinary arrays retain the declared result element type when input is typed.
function __map(xs, fn) {
  const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = fn(xs[i], i);
  return out;
}
function __filter(xs, fn) {
  const out = [];
  for (let i = 0; i < xs.length; i++) if (fn(xs[i])) out.push(xs[i]);
  return out;
}
function __concat(xs, ys) {
  const left = xs.length, right = ys.length, out = new Array(left + right);
  for (let i = 0; i < left; i++) out[i] = xs[i];
  for (let i = 0; i < right; i++) out[left + i] = ys[i];
  return out;
}
function __zip(xs, ys, fn) {
  const n = Math.min(xs.length, ys.length), out = new Array(n);
  for (let i = 0; i < n; i++) out[i] = fn(xs[i], ys[i]);
  return out;
}
function __repeat(n, initial, fn) { let value = initial; for (let i = 0; i < n; i++) value = fn(i, value); return value; }
function __foldr(xs, initial, fn) { let value = initial; for (let i = xs.length - 1; i >= 0; i--) value = fn(xs[i], value); return value; }
function __scan(xs, zero, add) {
  let value = zero; const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = value = add(value, xs[i]);
  return out;
}
const __sort = xs => Array.from(xs).sort((a,b) => a < b ? -1 : a > b ? 1 : 0);

function __wordSort(xs,Storage){
 const sorted=Storage.from(xs).sort(),out=new Array(sorted.length);
 for(let i=0;i<sorted.length;i++)out[i]=sorted[i];
 return out;
}
// Fixed word semantics, including arithmetic signed right shift. Shift and
// rotation counts wrap modulo width; no source-pattern optimisation lives here.
function __word(op,a,b,bits) {
  const width=BigInt(Math.abs(bits)), k=BigInt(b??0)%width;
  const x=BigInt(a), y=BigInt(b??0), unsigned=BigInt.asUintN(Number(width),x);
  let r;
  switch(op) {
    case 'word_widen_u32_to_u64':case 'word_narrow_u64_to_u32':r=x;break;
    case 'word_not':r=~x;break;
    case 'word_and':r=x&y;break;
    case 'word_or':r=x|y;break;
    case 'word_xor':r=x^y;break;
    case 'wrapping_shl':r=x<<k;break;
    case 'wrapping_shr':r=x>>k;break;
    case 'rotate_left':r=(unsigned<<k)|(unsigned>>(width-k));break;
    case 'rotate_right':r=(unsigned>>k)|(unsigned<<(width-k));break;
    default:throw new Error('unknown word operation');
  }
  r=bits<0?BigInt.asIntN(Number(width),r):BigInt.asUintN(Number(width),r);
  return bits===64?r:Number(r);
}
// Rotations evaluate each operand once. Counts wrap modulo the width.
function __rotl32(a,k){k&=31;return (a<<k)|(a>>>((32-k)&31));}
function __rotr32(a,k){k&=31;return (a>>>k)|(a<<((32-k)&31));}
function __rotl64(a,k){const n=BigInt(k&63);return BigInt.asUintN(64,(a<<n)|(a>>((64n-n)&63n)));}
function __rotr64(a,k){const n=BigInt(k&63);return BigInt.asUintN(64,(a>>n)|(a<<((64n-n)&63n)));}
function __fn0(v0,v1){
const v2=v0["a"];
const v3=Math.fround(__float(v2) - __float(v1));
const v4=v0["b"];
const v5=Math.fround(__float(v4) + __float(v1));
const v6=Math.fround(v3 * v3);
const v7=Math.fround(v5 * v5);
return __bits(v6 + v7);}
function __fn1(v8,v9){
const v10=v8["p"];
const v11=v10["a"];
const v12=Math.fround(__float(v11) - __float(v9));
const v13=v8["p"];
const v14=v13["b"];
const v15=Math.fround(__float(v14) + __float(v9));
const v16=v8["q"];
const v17=v16["a"];
const v18=Math.fround(__float(v17) - __float(v9));
const v19=v8["q"];
const v20=v19["b"];
const v21=Math.fround(__float(v20) + __float(v9));
const v22=v8["r"];
const v23=v22["a"];
const v24=Math.fround(__float(v23) - __float(v9));
const v25=v8["r"];
const v26=v25["b"];
const v27=Math.fround(__float(v26) + __float(v9));
const v28=v8["s"];
const v29=v28["a"];
const v30=Math.fround(__float(v29) - __float(v9));
const v31=v8["s"];
const v32=v31["b"];
const v33=Math.fround(__float(v32) + __float(v9));
const v34=v8["t"];
const v35=v34["a"];
const v36=Math.fround(__float(v35) - __float(v9));
const v37=v8["t"];
const v38=v37["b"];
const v39=Math.fround(__float(v38) + __float(v9));
const v40=v8["u"];
const v41=v40["a"];
const v42=Math.fround(__float(v41) - __float(v9));
const v43=v8["u"];
const v44=v43["b"];
const v45=Math.fround(__float(v44) + __float(v9));
const v46=Math.fround(v12 * v12);
const v47=Math.fround(v15 * v15);
const v48=Math.fround(v46 + v47);
const v49=Math.fround(v18 * v18);
const v50=Math.fround(v48 + v49);
const v51=Math.fround(v21 * v21);
const v52=Math.fround(v50 + v51);
const v53=Math.fround(v24 * v24);
const v54=Math.fround(v52 + v53);
const v55=Math.fround(v27 * v27);
const v56=Math.fround(v54 + v55);
const v57=Math.fround(v30 * v30);
const v58=Math.fround(v56 + v57);
const v59=Math.fround(v33 * v33);
const v60=Math.fround(v58 + v59);
const v61=Math.fround(v36 * v36);
const v62=Math.fround(v60 + v61);
const v63=Math.fround(v39 * v39);
const v64=Math.fround(v62 + v63);
const v65=Math.fround(v42 * v42);
const v66=Math.fround(v64 + v65);
const v67=Math.fround(v45 * v45);
return __bits(v66 + v67);}
function __fn2(v68,v69){
return __fn13(v68,v69);}
function __fn3(v70,v71){
return __fn18(v70,v70,v71);}
function __fn4(v72){
const v73=v72["a"];
const v74=v72["a"];
const v75=Math.fround(__float(v73) * __float(v74));
const v76=v72["a"];
const v77=v72["a"];
const v78=Math.fround(__float(v76) * __float(v77));
return __bits(v75 + v78);}
function __fn5(v79,v80){
let v81;if(v80){
const v82=v79["b"];
const v83=v79["b"];
const v84=__bits(__float(v82) * __float(v83));
const v85=v79["a"];
const v86=v79["a"];
const v87=__bits(__float(v85) * __float(v86));
v81=({["a"]:v84,["b"]:v87});}else{
const v88=v79["a"];
const v89=v79["a"];
const v90=__bits(__float(v88) * __float(v89));
const v91=v79["b"];
const v92=v79["b"];
const v93=__bits(__float(v91) * __float(v92));
v81=({["a"]:v90,["b"]:v93});}
return v81;}
function __fn6(v94,v95){
const v96=((v94 ^ 2147483648) >>> 0);
let v99;
let v100;
if(v95){
const v101=__bits(__float(v96) * __float(v96));
const v102=__bits(__float(v94) * __float(v94));
v99=v101;
v100=v102;
}else{
const v103=__bits(__float(v94) * __float(v94));
const v104=__bits(__float(v96) * __float(v96));
v99=v103;
v100=v104;
}
return ({["a"]:v99,["b"]:v100});}
function __fn7(v105){
const v106=((v105 ^ 2147483648) >>> 0);
let v107=v105;
let v108=v106;
for(let v110=0;v110<3;v110++){
const v111=(v110>>>0);
const v112=v108;
const v113=v107;
v107=v112;
v108=v113;
}
return ({["a"]:v107,["b"]:v108});}
function __fn8(v114){
const v115=v114["b"];
const v116=v114["b"];
const v117=__bits(__float(v115) * __float(v116));
return v114["a"];}
function __fn9(v118,v119){
const v121=__bits(__float(v119) * __float(v119));
return v118;}
function __fn10(v122){
const v123=({None:null});
let v124=v122;
let v125=v123;
for(let v127=0;v127<3;v127++){
const v128=(v127>>>0);
const v129=v124;
const v130=1;
const v131=(((v129) + (v130)) >>> 0);
const v132=v124;
const v133=v125;
const v135=({Some:({["value"]:v132,["previous"]:v133})});
v124=v131;
v125=v135;
}
return ({["value"]:v124,["previous"]:v125});}
function __fn11(v136){
return v136;}
function __fn12(v137,v138){
const v139=v137["p"];
const v140=v139["a"];
const v141=v140["value"];
const v142=v138["value"];
const v143=__bits(__float(v141) - __float(v142));
const v144=v140["tangent_0"];
const v145=v138["tangent_0"];
const v146=__bits(__float(v144) - __float(v145));
const v147=v140["tangent_1"];
const v148=v138["tangent_1"];
const v149=__bits(__float(v147) - __float(v148));
const v150=v140["tangent_2"];
const v151=v138["tangent_2"];
const v152=__bits(__float(v150) - __float(v151));
const v153=v140["tangent_3"];
const v154=v138["tangent_3"];
const v155=__bits(__float(v153) - __float(v154));
const v156=v140["tangent_4"];
const v157=v138["tangent_4"];
const v158=__bits(__float(v156) - __float(v157));
const v159=v140["tangent_5"];
const v160=v138["tangent_5"];
const v161=__bits(__float(v159) - __float(v160));
const v162=v140["tangent_6"];
const v163=v138["tangent_6"];
const v164=__bits(__float(v162) - __float(v163));
const v165=v140["tangent_7"];
const v166=v138["tangent_7"];
const v167=__bits(__float(v165) - __float(v166));
const v168=v140["tangent_8"];
const v169=v138["tangent_8"];
const v170=__bits(__float(v168) - __float(v169));
const v171=v140["tangent_9"];
const v172=v138["tangent_9"];
const v173=__bits(__float(v171) - __float(v172));
const v174=v140["tangent_10"];
const v175=v138["tangent_10"];
const v176=__bits(__float(v174) - __float(v175));
const v177=v140["tangent_11"];
const v178=v138["tangent_11"];
const v179=__bits(__float(v177) - __float(v178));
const v181=v137["p"];
const v182=v181["b"];
const v183=v182["value"];
const v184=v138["value"];
const v185=__bits(__float(v183) + __float(v184));
const v186=v182["tangent_0"];
const v187=v138["tangent_0"];
const v188=__bits(__float(v186) + __float(v187));
const v189=v182["tangent_1"];
const v190=v138["tangent_1"];
const v191=__bits(__float(v189) + __float(v190));
const v192=v182["tangent_2"];
const v193=v138["tangent_2"];
const v194=__bits(__float(v192) + __float(v193));
const v195=v182["tangent_3"];
const v196=v138["tangent_3"];
const v197=__bits(__float(v195) + __float(v196));
const v198=v182["tangent_4"];
const v199=v138["tangent_4"];
const v200=__bits(__float(v198) + __float(v199));
const v201=v182["tangent_5"];
const v202=v138["tangent_5"];
const v203=__bits(__float(v201) + __float(v202));
const v204=v182["tangent_6"];
const v205=v138["tangent_6"];
const v206=__bits(__float(v204) + __float(v205));
const v207=v182["tangent_7"];
const v208=v138["tangent_7"];
const v209=__bits(__float(v207) + __float(v208));
const v210=v182["tangent_8"];
const v211=v138["tangent_8"];
const v212=__bits(__float(v210) + __float(v211));
const v213=v182["tangent_9"];
const v214=v138["tangent_9"];
const v215=__bits(__float(v213) + __float(v214));
const v216=v182["tangent_10"];
const v217=v138["tangent_10"];
const v218=__bits(__float(v216) + __float(v217));
const v219=v182["tangent_11"];
const v220=v138["tangent_11"];
const v221=__bits(__float(v219) + __float(v220));
const v223=v137["q"];
const v224=v223["a"];
const v225=v224["value"];
const v226=v138["value"];
const v227=__bits(__float(v225) - __float(v226));
const v228=v224["tangent_0"];
const v229=v138["tangent_0"];
const v230=__bits(__float(v228) - __float(v229));
const v231=v224["tangent_1"];
const v232=v138["tangent_1"];
const v233=__bits(__float(v231) - __float(v232));
const v234=v224["tangent_2"];
const v235=v138["tangent_2"];
const v236=__bits(__float(v234) - __float(v235));
const v237=v224["tangent_3"];
const v238=v138["tangent_3"];
const v239=__bits(__float(v237) - __float(v238));
const v240=v224["tangent_4"];
const v241=v138["tangent_4"];
const v242=__bits(__float(v240) - __float(v241));
const v243=v224["tangent_5"];
const v244=v138["tangent_5"];
const v245=__bits(__float(v243) - __float(v244));
const v246=v224["tangent_6"];
const v247=v138["tangent_6"];
const v248=__bits(__float(v246) - __float(v247));
const v249=v224["tangent_7"];
const v250=v138["tangent_7"];
const v251=__bits(__float(v249) - __float(v250));
const v252=v224["tangent_8"];
const v253=v138["tangent_8"];
const v254=__bits(__float(v252) - __float(v253));
const v255=v224["tangent_9"];
const v256=v138["tangent_9"];
const v257=__bits(__float(v255) - __float(v256));
const v258=v224["tangent_10"];
const v259=v138["tangent_10"];
const v260=__bits(__float(v258) - __float(v259));
const v261=v224["tangent_11"];
const v262=v138["tangent_11"];
const v263=__bits(__float(v261) - __float(v262));
const v265=v137["q"];
const v266=v265["b"];
const v267=v266["value"];
const v268=v138["value"];
const v269=__bits(__float(v267) + __float(v268));
const v270=v266["tangent_0"];
const v271=v138["tangent_0"];
const v272=__bits(__float(v270) + __float(v271));
const v273=v266["tangent_1"];
const v274=v138["tangent_1"];
const v275=__bits(__float(v273) + __float(v274));
const v276=v266["tangent_2"];
const v277=v138["tangent_2"];
const v278=__bits(__float(v276) + __float(v277));
const v279=v266["tangent_3"];
const v280=v138["tangent_3"];
const v281=__bits(__float(v279) + __float(v280));
const v282=v266["tangent_4"];
const v283=v138["tangent_4"];
const v284=__bits(__float(v282) + __float(v283));
const v285=v266["tangent_5"];
const v286=v138["tangent_5"];
const v287=__bits(__float(v285) + __float(v286));
const v288=v266["tangent_6"];
const v289=v138["tangent_6"];
const v290=__bits(__float(v288) + __float(v289));
const v291=v266["tangent_7"];
const v292=v138["tangent_7"];
const v293=__bits(__float(v291) + __float(v292));
const v294=v266["tangent_8"];
const v295=v138["tangent_8"];
const v296=__bits(__float(v294) + __float(v295));
const v297=v266["tangent_9"];
const v298=v138["tangent_9"];
const v299=__bits(__float(v297) + __float(v298));
const v300=v266["tangent_10"];
const v301=v138["tangent_10"];
const v302=__bits(__float(v300) + __float(v301));
const v303=v266["tangent_11"];
const v304=v138["tangent_11"];
const v305=__bits(__float(v303) + __float(v304));
const v307=v137["r"];
const v308=v307["a"];
const v309=v308["value"];
const v310=v138["value"];
const v311=__bits(__float(v309) - __float(v310));
const v312=v308["tangent_0"];
const v313=v138["tangent_0"];
const v314=__bits(__float(v312) - __float(v313));
const v315=v308["tangent_1"];
const v316=v138["tangent_1"];
const v317=__bits(__float(v315) - __float(v316));
const v318=v308["tangent_2"];
const v319=v138["tangent_2"];
const v320=__bits(__float(v318) - __float(v319));
const v321=v308["tangent_3"];
const v322=v138["tangent_3"];
const v323=__bits(__float(v321) - __float(v322));
const v324=v308["tangent_4"];
const v325=v138["tangent_4"];
const v326=__bits(__float(v324) - __float(v325));
const v327=v308["tangent_5"];
const v328=v138["tangent_5"];
const v329=__bits(__float(v327) - __float(v328));
const v330=v308["tangent_6"];
const v331=v138["tangent_6"];
const v332=__bits(__float(v330) - __float(v331));
const v333=v308["tangent_7"];
const v334=v138["tangent_7"];
const v335=__bits(__float(v333) - __float(v334));
const v336=v308["tangent_8"];
const v337=v138["tangent_8"];
const v338=__bits(__float(v336) - __float(v337));
const v339=v308["tangent_9"];
const v340=v138["tangent_9"];
const v341=__bits(__float(v339) - __float(v340));
const v342=v308["tangent_10"];
const v343=v138["tangent_10"];
const v344=__bits(__float(v342) - __float(v343));
const v345=v308["tangent_11"];
const v346=v138["tangent_11"];
const v347=__bits(__float(v345) - __float(v346));
const v349=v137["r"];
const v350=v349["b"];
const v351=v350["value"];
const v352=v138["value"];
const v353=__bits(__float(v351) + __float(v352));
const v354=v350["tangent_0"];
const v355=v138["tangent_0"];
const v356=__bits(__float(v354) + __float(v355));
const v357=v350["tangent_1"];
const v358=v138["tangent_1"];
const v359=__bits(__float(v357) + __float(v358));
const v360=v350["tangent_2"];
const v361=v138["tangent_2"];
const v362=__bits(__float(v360) + __float(v361));
const v363=v350["tangent_3"];
const v364=v138["tangent_3"];
const v365=__bits(__float(v363) + __float(v364));
const v366=v350["tangent_4"];
const v367=v138["tangent_4"];
const v368=__bits(__float(v366) + __float(v367));
const v369=v350["tangent_5"];
const v370=v138["tangent_5"];
const v371=__bits(__float(v369) + __float(v370));
const v372=v350["tangent_6"];
const v373=v138["tangent_6"];
const v374=__bits(__float(v372) + __float(v373));
const v375=v350["tangent_7"];
const v376=v138["tangent_7"];
const v377=__bits(__float(v375) + __float(v376));
const v378=v350["tangent_8"];
const v379=v138["tangent_8"];
const v380=__bits(__float(v378) + __float(v379));
const v381=v350["tangent_9"];
const v382=v138["tangent_9"];
const v383=__bits(__float(v381) + __float(v382));
const v384=v350["tangent_10"];
const v385=v138["tangent_10"];
const v386=__bits(__float(v384) + __float(v385));
const v387=v350["tangent_11"];
const v388=v138["tangent_11"];
const v389=__bits(__float(v387) + __float(v388));
const v391=v137["s"];
const v392=v391["a"];
const v393=v392["value"];
const v394=v138["value"];
const v395=__bits(__float(v393) - __float(v394));
const v396=v392["tangent_0"];
const v397=v138["tangent_0"];
const v398=__bits(__float(v396) - __float(v397));
const v399=v392["tangent_1"];
const v400=v138["tangent_1"];
const v401=__bits(__float(v399) - __float(v400));
const v402=v392["tangent_2"];
const v403=v138["tangent_2"];
const v404=__bits(__float(v402) - __float(v403));
const v405=v392["tangent_3"];
const v406=v138["tangent_3"];
const v407=__bits(__float(v405) - __float(v406));
const v408=v392["tangent_4"];
const v409=v138["tangent_4"];
const v410=__bits(__float(v408) - __float(v409));
const v411=v392["tangent_5"];
const v412=v138["tangent_5"];
const v413=__bits(__float(v411) - __float(v412));
const v414=v392["tangent_6"];
const v415=v138["tangent_6"];
const v416=__bits(__float(v414) - __float(v415));
const v417=v392["tangent_7"];
const v418=v138["tangent_7"];
const v419=__bits(__float(v417) - __float(v418));
const v420=v392["tangent_8"];
const v421=v138["tangent_8"];
const v422=__bits(__float(v420) - __float(v421));
const v423=v392["tangent_9"];
const v424=v138["tangent_9"];
const v425=__bits(__float(v423) - __float(v424));
const v426=v392["tangent_10"];
const v427=v138["tangent_10"];
const v428=__bits(__float(v426) - __float(v427));
const v429=v392["tangent_11"];
const v430=v138["tangent_11"];
const v431=__bits(__float(v429) - __float(v430));
const v433=v137["s"];
const v434=v433["b"];
const v435=v434["value"];
const v436=v138["value"];
const v437=__bits(__float(v435) + __float(v436));
const v438=v434["tangent_0"];
const v439=v138["tangent_0"];
const v440=__bits(__float(v438) + __float(v439));
const v441=v434["tangent_1"];
const v442=v138["tangent_1"];
const v443=__bits(__float(v441) + __float(v442));
const v444=v434["tangent_2"];
const v445=v138["tangent_2"];
const v446=__bits(__float(v444) + __float(v445));
const v447=v434["tangent_3"];
const v448=v138["tangent_3"];
const v449=__bits(__float(v447) + __float(v448));
const v450=v434["tangent_4"];
const v451=v138["tangent_4"];
const v452=__bits(__float(v450) + __float(v451));
const v453=v434["tangent_5"];
const v454=v138["tangent_5"];
const v455=__bits(__float(v453) + __float(v454));
const v456=v434["tangent_6"];
const v457=v138["tangent_6"];
const v458=__bits(__float(v456) + __float(v457));
const v459=v434["tangent_7"];
const v460=v138["tangent_7"];
const v461=__bits(__float(v459) + __float(v460));
const v462=v434["tangent_8"];
const v463=v138["tangent_8"];
const v464=__bits(__float(v462) + __float(v463));
const v465=v434["tangent_9"];
const v466=v138["tangent_9"];
const v467=__bits(__float(v465) + __float(v466));
const v468=v434["tangent_10"];
const v469=v138["tangent_10"];
const v470=__bits(__float(v468) + __float(v469));
const v471=v434["tangent_11"];
const v472=v138["tangent_11"];
const v473=__bits(__float(v471) + __float(v472));
const v475=v137["t"];
const v476=v475["a"];
const v477=v476["value"];
const v478=v138["value"];
const v479=__bits(__float(v477) - __float(v478));
const v480=v476["tangent_0"];
const v481=v138["tangent_0"];
const v482=__bits(__float(v480) - __float(v481));
const v483=v476["tangent_1"];
const v484=v138["tangent_1"];
const v485=__bits(__float(v483) - __float(v484));
const v486=v476["tangent_2"];
const v487=v138["tangent_2"];
const v488=__bits(__float(v486) - __float(v487));
const v489=v476["tangent_3"];
const v490=v138["tangent_3"];
const v491=__bits(__float(v489) - __float(v490));
const v492=v476["tangent_4"];
const v493=v138["tangent_4"];
const v494=__bits(__float(v492) - __float(v493));
const v495=v476["tangent_5"];
const v496=v138["tangent_5"];
const v497=__bits(__float(v495) - __float(v496));
const v498=v476["tangent_6"];
const v499=v138["tangent_6"];
const v500=__bits(__float(v498) - __float(v499));
const v501=v476["tangent_7"];
const v502=v138["tangent_7"];
const v503=__bits(__float(v501) - __float(v502));
const v504=v476["tangent_8"];
const v505=v138["tangent_8"];
const v506=__bits(__float(v504) - __float(v505));
const v507=v476["tangent_9"];
const v508=v138["tangent_9"];
const v509=__bits(__float(v507) - __float(v508));
const v510=v476["tangent_10"];
const v511=v138["tangent_10"];
const v512=__bits(__float(v510) - __float(v511));
const v513=v476["tangent_11"];
const v514=v138["tangent_11"];
const v515=__bits(__float(v513) - __float(v514));
const v517=v137["t"];
const v518=v517["b"];
const v519=v518["value"];
const v520=v138["value"];
const v521=__bits(__float(v519) + __float(v520));
const v522=v518["tangent_0"];
const v523=v138["tangent_0"];
const v524=__bits(__float(v522) + __float(v523));
const v525=v518["tangent_1"];
const v526=v138["tangent_1"];
const v527=__bits(__float(v525) + __float(v526));
const v528=v518["tangent_2"];
const v529=v138["tangent_2"];
const v530=__bits(__float(v528) + __float(v529));
const v531=v518["tangent_3"];
const v532=v138["tangent_3"];
const v533=__bits(__float(v531) + __float(v532));
const v534=v518["tangent_4"];
const v535=v138["tangent_4"];
const v536=__bits(__float(v534) + __float(v535));
const v537=v518["tangent_5"];
const v538=v138["tangent_5"];
const v539=__bits(__float(v537) + __float(v538));
const v540=v518["tangent_6"];
const v541=v138["tangent_6"];
const v542=__bits(__float(v540) + __float(v541));
const v543=v518["tangent_7"];
const v544=v138["tangent_7"];
const v545=__bits(__float(v543) + __float(v544));
const v546=v518["tangent_8"];
const v547=v138["tangent_8"];
const v548=__bits(__float(v546) + __float(v547));
const v549=v518["tangent_9"];
const v550=v138["tangent_9"];
const v551=__bits(__float(v549) + __float(v550));
const v552=v518["tangent_10"];
const v553=v138["tangent_10"];
const v554=__bits(__float(v552) + __float(v553));
const v555=v518["tangent_11"];
const v556=v138["tangent_11"];
const v557=__bits(__float(v555) + __float(v556));
const v559=v137["u"];
const v560=v559["a"];
const v561=v560["value"];
const v562=v138["value"];
const v563=__bits(__float(v561) - __float(v562));
const v564=v560["tangent_0"];
const v565=v138["tangent_0"];
const v566=__bits(__float(v564) - __float(v565));
const v567=v560["tangent_1"];
const v568=v138["tangent_1"];
const v569=__bits(__float(v567) - __float(v568));
const v570=v560["tangent_2"];
const v571=v138["tangent_2"];
const v572=__bits(__float(v570) - __float(v571));
const v573=v560["tangent_3"];
const v574=v138["tangent_3"];
const v575=__bits(__float(v573) - __float(v574));
const v576=v560["tangent_4"];
const v577=v138["tangent_4"];
const v578=__bits(__float(v576) - __float(v577));
const v579=v560["tangent_5"];
const v580=v138["tangent_5"];
const v581=__bits(__float(v579) - __float(v580));
const v582=v560["tangent_6"];
const v583=v138["tangent_6"];
const v584=__bits(__float(v582) - __float(v583));
const v585=v560["tangent_7"];
const v586=v138["tangent_7"];
const v587=__bits(__float(v585) - __float(v586));
const v588=v560["tangent_8"];
const v589=v138["tangent_8"];
const v590=__bits(__float(v588) - __float(v589));
const v591=v560["tangent_9"];
const v592=v138["tangent_9"];
const v593=__bits(__float(v591) - __float(v592));
const v594=v560["tangent_10"];
const v595=v138["tangent_10"];
const v596=__bits(__float(v594) - __float(v595));
const v597=v560["tangent_11"];
const v598=v138["tangent_11"];
const v599=__bits(__float(v597) - __float(v598));
const v601=v137["u"];
const v602=v601["b"];
const v603=v602["value"];
const v604=v138["value"];
const v605=__bits(__float(v603) + __float(v604));
const v606=v602["tangent_0"];
const v607=v138["tangent_0"];
const v608=__bits(__float(v606) + __float(v607));
const v609=v602["tangent_1"];
const v610=v138["tangent_1"];
const v611=__bits(__float(v609) + __float(v610));
const v612=v602["tangent_2"];
const v613=v138["tangent_2"];
const v614=__bits(__float(v612) + __float(v613));
const v615=v602["tangent_3"];
const v616=v138["tangent_3"];
const v617=__bits(__float(v615) + __float(v616));
const v618=v602["tangent_4"];
const v619=v138["tangent_4"];
const v620=__bits(__float(v618) + __float(v619));
const v621=v602["tangent_5"];
const v622=v138["tangent_5"];
const v623=__bits(__float(v621) + __float(v622));
const v624=v602["tangent_6"];
const v625=v138["tangent_6"];
const v626=__bits(__float(v624) + __float(v625));
const v627=v602["tangent_7"];
const v628=v138["tangent_7"];
const v629=__bits(__float(v627) + __float(v628));
const v630=v602["tangent_8"];
const v631=v138["tangent_8"];
const v632=__bits(__float(v630) + __float(v631));
const v633=v602["tangent_9"];
const v634=v138["tangent_9"];
const v635=__bits(__float(v633) + __float(v634));
const v636=v602["tangent_10"];
const v637=v138["tangent_10"];
const v638=__bits(__float(v636) + __float(v637));
const v639=v602["tangent_11"];
const v640=v138["tangent_11"];
const v641=__bits(__float(v639) + __float(v640));
const v643=__bits(__float(v143) * __float(v143));
const v644=Math.fround(__float(v146) * __float(v143));
const v645=Math.fround(__float(v143) * __float(v146));
const v646=__bits(v644 + v645);
const v647=Math.fround(__float(v149) * __float(v143));
const v648=Math.fround(__float(v143) * __float(v149));
const v649=__bits(v647 + v648);
const v650=Math.fround(__float(v152) * __float(v143));
const v651=Math.fround(__float(v143) * __float(v152));
const v652=__bits(v650 + v651);
const v653=Math.fround(__float(v155) * __float(v143));
const v654=Math.fround(__float(v143) * __float(v155));
const v655=__bits(v653 + v654);
const v656=Math.fround(__float(v158) * __float(v143));
const v657=Math.fround(__float(v143) * __float(v158));
const v658=__bits(v656 + v657);
const v659=Math.fround(__float(v161) * __float(v143));
const v660=Math.fround(__float(v143) * __float(v161));
const v661=__bits(v659 + v660);
const v662=Math.fround(__float(v164) * __float(v143));
const v663=Math.fround(__float(v143) * __float(v164));
const v664=__bits(v662 + v663);
const v665=Math.fround(__float(v167) * __float(v143));
const v666=Math.fround(__float(v143) * __float(v167));
const v667=__bits(v665 + v666);
const v668=Math.fround(__float(v170) * __float(v143));
const v669=Math.fround(__float(v143) * __float(v170));
const v670=__bits(v668 + v669);
const v671=Math.fround(__float(v173) * __float(v143));
const v672=Math.fround(__float(v143) * __float(v173));
const v673=__bits(v671 + v672);
const v674=Math.fround(__float(v176) * __float(v143));
const v675=Math.fround(__float(v143) * __float(v176));
const v676=__bits(v674 + v675);
const v677=Math.fround(__float(v179) * __float(v143));
const v678=Math.fround(__float(v143) * __float(v179));
const v679=__bits(v677 + v678);
const v681=__bits(__float(v185) * __float(v185));
const v682=Math.fround(__float(v188) * __float(v185));
const v683=Math.fround(__float(v185) * __float(v188));
const v684=__bits(v682 + v683);
const v685=Math.fround(__float(v191) * __float(v185));
const v686=Math.fround(__float(v185) * __float(v191));
const v687=__bits(v685 + v686);
const v688=Math.fround(__float(v194) * __float(v185));
const v689=Math.fround(__float(v185) * __float(v194));
const v690=__bits(v688 + v689);
const v691=Math.fround(__float(v197) * __float(v185));
const v692=Math.fround(__float(v185) * __float(v197));
const v693=__bits(v691 + v692);
const v694=Math.fround(__float(v200) * __float(v185));
const v695=Math.fround(__float(v185) * __float(v200));
const v696=__bits(v694 + v695);
const v697=Math.fround(__float(v203) * __float(v185));
const v698=Math.fround(__float(v185) * __float(v203));
const v699=__bits(v697 + v698);
const v700=Math.fround(__float(v206) * __float(v185));
const v701=Math.fround(__float(v185) * __float(v206));
const v702=__bits(v700 + v701);
const v703=Math.fround(__float(v209) * __float(v185));
const v704=Math.fround(__float(v185) * __float(v209));
const v705=__bits(v703 + v704);
const v706=Math.fround(__float(v212) * __float(v185));
const v707=Math.fround(__float(v185) * __float(v212));
const v708=__bits(v706 + v707);
const v709=Math.fround(__float(v215) * __float(v185));
const v710=Math.fround(__float(v185) * __float(v215));
const v711=__bits(v709 + v710);
const v712=Math.fround(__float(v218) * __float(v185));
const v713=Math.fround(__float(v185) * __float(v218));
const v714=__bits(v712 + v713);
const v715=Math.fround(__float(v221) * __float(v185));
const v716=Math.fround(__float(v185) * __float(v221));
const v717=__bits(v715 + v716);
const v719=__bits(__float(v643) + __float(v681));
const v720=__bits(__float(v646) + __float(v684));
const v721=__bits(__float(v649) + __float(v687));
const v722=__bits(__float(v652) + __float(v690));
const v723=__bits(__float(v655) + __float(v693));
const v724=__bits(__float(v658) + __float(v696));
const v725=__bits(__float(v661) + __float(v699));
const v726=__bits(__float(v664) + __float(v702));
const v727=__bits(__float(v667) + __float(v705));
const v728=__bits(__float(v670) + __float(v708));
const v729=__bits(__float(v673) + __float(v711));
const v730=__bits(__float(v676) + __float(v714));
const v731=__bits(__float(v679) + __float(v717));
const v733=__bits(__float(v227) * __float(v227));
const v734=Math.fround(__float(v230) * __float(v227));
const v735=Math.fround(__float(v227) * __float(v230));
const v736=__bits(v734 + v735);
const v737=Math.fround(__float(v233) * __float(v227));
const v738=Math.fround(__float(v227) * __float(v233));
const v739=__bits(v737 + v738);
const v740=Math.fround(__float(v236) * __float(v227));
const v741=Math.fround(__float(v227) * __float(v236));
const v742=__bits(v740 + v741);
const v743=Math.fround(__float(v239) * __float(v227));
const v744=Math.fround(__float(v227) * __float(v239));
const v745=__bits(v743 + v744);
const v746=Math.fround(__float(v242) * __float(v227));
const v747=Math.fround(__float(v227) * __float(v242));
const v748=__bits(v746 + v747);
const v749=Math.fround(__float(v245) * __float(v227));
const v750=Math.fround(__float(v227) * __float(v245));
const v751=__bits(v749 + v750);
const v752=Math.fround(__float(v248) * __float(v227));
const v753=Math.fround(__float(v227) * __float(v248));
const v754=__bits(v752 + v753);
const v755=Math.fround(__float(v251) * __float(v227));
const v756=Math.fround(__float(v227) * __float(v251));
const v757=__bits(v755 + v756);
const v758=Math.fround(__float(v254) * __float(v227));
const v759=Math.fround(__float(v227) * __float(v254));
const v760=__bits(v758 + v759);
const v761=Math.fround(__float(v257) * __float(v227));
const v762=Math.fround(__float(v227) * __float(v257));
const v763=__bits(v761 + v762);
const v764=Math.fround(__float(v260) * __float(v227));
const v765=Math.fround(__float(v227) * __float(v260));
const v766=__bits(v764 + v765);
const v767=Math.fround(__float(v263) * __float(v227));
const v768=Math.fround(__float(v227) * __float(v263));
const v769=__bits(v767 + v768);
const v771=__bits(__float(v719) + __float(v733));
const v772=__bits(__float(v720) + __float(v736));
const v773=__bits(__float(v721) + __float(v739));
const v774=__bits(__float(v722) + __float(v742));
const v775=__bits(__float(v723) + __float(v745));
const v776=__bits(__float(v724) + __float(v748));
const v777=__bits(__float(v725) + __float(v751));
const v778=__bits(__float(v726) + __float(v754));
const v779=__bits(__float(v727) + __float(v757));
const v780=__bits(__float(v728) + __float(v760));
const v781=__bits(__float(v729) + __float(v763));
const v782=__bits(__float(v730) + __float(v766));
const v783=__bits(__float(v731) + __float(v769));
const v785=__bits(__float(v269) * __float(v269));
const v786=Math.fround(__float(v272) * __float(v269));
const v787=Math.fround(__float(v269) * __float(v272));
const v788=__bits(v786 + v787);
const v789=Math.fround(__float(v275) * __float(v269));
const v790=Math.fround(__float(v269) * __float(v275));
const v791=__bits(v789 + v790);
const v792=Math.fround(__float(v278) * __float(v269));
const v793=Math.fround(__float(v269) * __float(v278));
const v794=__bits(v792 + v793);
const v795=Math.fround(__float(v281) * __float(v269));
const v796=Math.fround(__float(v269) * __float(v281));
const v797=__bits(v795 + v796);
const v798=Math.fround(__float(v284) * __float(v269));
const v799=Math.fround(__float(v269) * __float(v284));
const v800=__bits(v798 + v799);
const v801=Math.fround(__float(v287) * __float(v269));
const v802=Math.fround(__float(v269) * __float(v287));
const v803=__bits(v801 + v802);
const v804=Math.fround(__float(v290) * __float(v269));
const v805=Math.fround(__float(v269) * __float(v290));
const v806=__bits(v804 + v805);
const v807=Math.fround(__float(v293) * __float(v269));
const v808=Math.fround(__float(v269) * __float(v293));
const v809=__bits(v807 + v808);
const v810=Math.fround(__float(v296) * __float(v269));
const v811=Math.fround(__float(v269) * __float(v296));
const v812=__bits(v810 + v811);
const v813=Math.fround(__float(v299) * __float(v269));
const v814=Math.fround(__float(v269) * __float(v299));
const v815=__bits(v813 + v814);
const v816=Math.fround(__float(v302) * __float(v269));
const v817=Math.fround(__float(v269) * __float(v302));
const v818=__bits(v816 + v817);
const v819=Math.fround(__float(v305) * __float(v269));
const v820=Math.fround(__float(v269) * __float(v305));
const v821=__bits(v819 + v820);
const v823=__bits(__float(v771) + __float(v785));
const v824=__bits(__float(v772) + __float(v788));
const v825=__bits(__float(v773) + __float(v791));
const v826=__bits(__float(v774) + __float(v794));
const v827=__bits(__float(v775) + __float(v797));
const v828=__bits(__float(v776) + __float(v800));
const v829=__bits(__float(v777) + __float(v803));
const v830=__bits(__float(v778) + __float(v806));
const v831=__bits(__float(v779) + __float(v809));
const v832=__bits(__float(v780) + __float(v812));
const v833=__bits(__float(v781) + __float(v815));
const v834=__bits(__float(v782) + __float(v818));
const v835=__bits(__float(v783) + __float(v821));
const v837=__bits(__float(v311) * __float(v311));
const v838=Math.fround(__float(v314) * __float(v311));
const v839=Math.fround(__float(v311) * __float(v314));
const v840=__bits(v838 + v839);
const v841=Math.fround(__float(v317) * __float(v311));
const v842=Math.fround(__float(v311) * __float(v317));
const v843=__bits(v841 + v842);
const v844=Math.fround(__float(v320) * __float(v311));
const v845=Math.fround(__float(v311) * __float(v320));
const v846=__bits(v844 + v845);
const v847=Math.fround(__float(v323) * __float(v311));
const v848=Math.fround(__float(v311) * __float(v323));
const v849=__bits(v847 + v848);
const v850=Math.fround(__float(v326) * __float(v311));
const v851=Math.fround(__float(v311) * __float(v326));
const v852=__bits(v850 + v851);
const v853=Math.fround(__float(v329) * __float(v311));
const v854=Math.fround(__float(v311) * __float(v329));
const v855=__bits(v853 + v854);
const v856=Math.fround(__float(v332) * __float(v311));
const v857=Math.fround(__float(v311) * __float(v332));
const v858=__bits(v856 + v857);
const v859=Math.fround(__float(v335) * __float(v311));
const v860=Math.fround(__float(v311) * __float(v335));
const v861=__bits(v859 + v860);
const v862=Math.fround(__float(v338) * __float(v311));
const v863=Math.fround(__float(v311) * __float(v338));
const v864=__bits(v862 + v863);
const v865=Math.fround(__float(v341) * __float(v311));
const v866=Math.fround(__float(v311) * __float(v341));
const v867=__bits(v865 + v866);
const v868=Math.fround(__float(v344) * __float(v311));
const v869=Math.fround(__float(v311) * __float(v344));
const v870=__bits(v868 + v869);
const v871=Math.fround(__float(v347) * __float(v311));
const v872=Math.fround(__float(v311) * __float(v347));
const v873=__bits(v871 + v872);
const v875=__bits(__float(v823) + __float(v837));
const v876=__bits(__float(v824) + __float(v840));
const v877=__bits(__float(v825) + __float(v843));
const v878=__bits(__float(v826) + __float(v846));
const v879=__bits(__float(v827) + __float(v849));
const v880=__bits(__float(v828) + __float(v852));
const v881=__bits(__float(v829) + __float(v855));
const v882=__bits(__float(v830) + __float(v858));
const v883=__bits(__float(v831) + __float(v861));
const v884=__bits(__float(v832) + __float(v864));
const v885=__bits(__float(v833) + __float(v867));
const v886=__bits(__float(v834) + __float(v870));
const v887=__bits(__float(v835) + __float(v873));
const v889=__bits(__float(v353) * __float(v353));
const v890=Math.fround(__float(v356) * __float(v353));
const v891=Math.fround(__float(v353) * __float(v356));
const v892=__bits(v890 + v891);
const v893=Math.fround(__float(v359) * __float(v353));
const v894=Math.fround(__float(v353) * __float(v359));
const v895=__bits(v893 + v894);
const v896=Math.fround(__float(v362) * __float(v353));
const v897=Math.fround(__float(v353) * __float(v362));
const v898=__bits(v896 + v897);
const v899=Math.fround(__float(v365) * __float(v353));
const v900=Math.fround(__float(v353) * __float(v365));
const v901=__bits(v899 + v900);
const v902=Math.fround(__float(v368) * __float(v353));
const v903=Math.fround(__float(v353) * __float(v368));
const v904=__bits(v902 + v903);
const v905=Math.fround(__float(v371) * __float(v353));
const v906=Math.fround(__float(v353) * __float(v371));
const v907=__bits(v905 + v906);
const v908=Math.fround(__float(v374) * __float(v353));
const v909=Math.fround(__float(v353) * __float(v374));
const v910=__bits(v908 + v909);
const v911=Math.fround(__float(v377) * __float(v353));
const v912=Math.fround(__float(v353) * __float(v377));
const v913=__bits(v911 + v912);
const v914=Math.fround(__float(v380) * __float(v353));
const v915=Math.fround(__float(v353) * __float(v380));
const v916=__bits(v914 + v915);
const v917=Math.fround(__float(v383) * __float(v353));
const v918=Math.fround(__float(v353) * __float(v383));
const v919=__bits(v917 + v918);
const v920=Math.fround(__float(v386) * __float(v353));
const v921=Math.fround(__float(v353) * __float(v386));
const v922=__bits(v920 + v921);
const v923=Math.fround(__float(v389) * __float(v353));
const v924=Math.fround(__float(v353) * __float(v389));
const v925=__bits(v923 + v924);
const v927=__bits(__float(v875) + __float(v889));
const v928=__bits(__float(v876) + __float(v892));
const v929=__bits(__float(v877) + __float(v895));
const v930=__bits(__float(v878) + __float(v898));
const v931=__bits(__float(v879) + __float(v901));
const v932=__bits(__float(v880) + __float(v904));
const v933=__bits(__float(v881) + __float(v907));
const v934=__bits(__float(v882) + __float(v910));
const v935=__bits(__float(v883) + __float(v913));
const v936=__bits(__float(v884) + __float(v916));
const v937=__bits(__float(v885) + __float(v919));
const v938=__bits(__float(v886) + __float(v922));
const v939=__bits(__float(v887) + __float(v925));
const v941=__bits(__float(v395) * __float(v395));
const v942=Math.fround(__float(v398) * __float(v395));
const v943=Math.fround(__float(v395) * __float(v398));
const v944=__bits(v942 + v943);
const v945=Math.fround(__float(v401) * __float(v395));
const v946=Math.fround(__float(v395) * __float(v401));
const v947=__bits(v945 + v946);
const v948=Math.fround(__float(v404) * __float(v395));
const v949=Math.fround(__float(v395) * __float(v404));
const v950=__bits(v948 + v949);
const v951=Math.fround(__float(v407) * __float(v395));
const v952=Math.fround(__float(v395) * __float(v407));
const v953=__bits(v951 + v952);
const v954=Math.fround(__float(v410) * __float(v395));
const v955=Math.fround(__float(v395) * __float(v410));
const v956=__bits(v954 + v955);
const v957=Math.fround(__float(v413) * __float(v395));
const v958=Math.fround(__float(v395) * __float(v413));
const v959=__bits(v957 + v958);
const v960=Math.fround(__float(v416) * __float(v395));
const v961=Math.fround(__float(v395) * __float(v416));
const v962=__bits(v960 + v961);
const v963=Math.fround(__float(v419) * __float(v395));
const v964=Math.fround(__float(v395) * __float(v419));
const v965=__bits(v963 + v964);
const v966=Math.fround(__float(v422) * __float(v395));
const v967=Math.fround(__float(v395) * __float(v422));
const v968=__bits(v966 + v967);
const v969=Math.fround(__float(v425) * __float(v395));
const v970=Math.fround(__float(v395) * __float(v425));
const v971=__bits(v969 + v970);
const v972=Math.fround(__float(v428) * __float(v395));
const v973=Math.fround(__float(v395) * __float(v428));
const v974=__bits(v972 + v973);
const v975=Math.fround(__float(v431) * __float(v395));
const v976=Math.fround(__float(v395) * __float(v431));
const v977=__bits(v975 + v976);
const v979=__bits(__float(v927) + __float(v941));
const v980=__bits(__float(v928) + __float(v944));
const v981=__bits(__float(v929) + __float(v947));
const v982=__bits(__float(v930) + __float(v950));
const v983=__bits(__float(v931) + __float(v953));
const v984=__bits(__float(v932) + __float(v956));
const v985=__bits(__float(v933) + __float(v959));
const v986=__bits(__float(v934) + __float(v962));
const v987=__bits(__float(v935) + __float(v965));
const v988=__bits(__float(v936) + __float(v968));
const v989=__bits(__float(v937) + __float(v971));
const v990=__bits(__float(v938) + __float(v974));
const v991=__bits(__float(v939) + __float(v977));
const v993=__bits(__float(v437) * __float(v437));
const v994=Math.fround(__float(v440) * __float(v437));
const v995=Math.fround(__float(v437) * __float(v440));
const v996=__bits(v994 + v995);
const v997=Math.fround(__float(v443) * __float(v437));
const v998=Math.fround(__float(v437) * __float(v443));
const v999=__bits(v997 + v998);
const v1000=Math.fround(__float(v446) * __float(v437));
const v1001=Math.fround(__float(v437) * __float(v446));
const v1002=__bits(v1000 + v1001);
const v1003=Math.fround(__float(v449) * __float(v437));
const v1004=Math.fround(__float(v437) * __float(v449));
const v1005=__bits(v1003 + v1004);
const v1006=Math.fround(__float(v452) * __float(v437));
const v1007=Math.fround(__float(v437) * __float(v452));
const v1008=__bits(v1006 + v1007);
const v1009=Math.fround(__float(v455) * __float(v437));
const v1010=Math.fround(__float(v437) * __float(v455));
const v1011=__bits(v1009 + v1010);
const v1012=Math.fround(__float(v458) * __float(v437));
const v1013=Math.fround(__float(v437) * __float(v458));
const v1014=__bits(v1012 + v1013);
const v1015=Math.fround(__float(v461) * __float(v437));
const v1016=Math.fround(__float(v437) * __float(v461));
const v1017=__bits(v1015 + v1016);
const v1018=Math.fround(__float(v464) * __float(v437));
const v1019=Math.fround(__float(v437) * __float(v464));
const v1020=__bits(v1018 + v1019);
const v1021=Math.fround(__float(v467) * __float(v437));
const v1022=Math.fround(__float(v437) * __float(v467));
const v1023=__bits(v1021 + v1022);
const v1024=Math.fround(__float(v470) * __float(v437));
const v1025=Math.fround(__float(v437) * __float(v470));
const v1026=__bits(v1024 + v1025);
const v1027=Math.fround(__float(v473) * __float(v437));
const v1028=Math.fround(__float(v437) * __float(v473));
const v1029=__bits(v1027 + v1028);
const v1031=__bits(__float(v979) + __float(v993));
const v1032=__bits(__float(v980) + __float(v996));
const v1033=__bits(__float(v981) + __float(v999));
const v1034=__bits(__float(v982) + __float(v1002));
const v1035=__bits(__float(v983) + __float(v1005));
const v1036=__bits(__float(v984) + __float(v1008));
const v1037=__bits(__float(v985) + __float(v1011));
const v1038=__bits(__float(v986) + __float(v1014));
const v1039=__bits(__float(v987) + __float(v1017));
const v1040=__bits(__float(v988) + __float(v1020));
const v1041=__bits(__float(v989) + __float(v1023));
const v1042=__bits(__float(v990) + __float(v1026));
const v1043=__bits(__float(v991) + __float(v1029));
const v1045=__bits(__float(v479) * __float(v479));
const v1046=Math.fround(__float(v482) * __float(v479));
const v1047=Math.fround(__float(v479) * __float(v482));
const v1048=__bits(v1046 + v1047);
const v1049=Math.fround(__float(v485) * __float(v479));
const v1050=Math.fround(__float(v479) * __float(v485));
const v1051=__bits(v1049 + v1050);
const v1052=Math.fround(__float(v488) * __float(v479));
const v1053=Math.fround(__float(v479) * __float(v488));
const v1054=__bits(v1052 + v1053);
const v1055=Math.fround(__float(v491) * __float(v479));
const v1056=Math.fround(__float(v479) * __float(v491));
const v1057=__bits(v1055 + v1056);
const v1058=Math.fround(__float(v494) * __float(v479));
const v1059=Math.fround(__float(v479) * __float(v494));
const v1060=__bits(v1058 + v1059);
const v1061=Math.fround(__float(v497) * __float(v479));
const v1062=Math.fround(__float(v479) * __float(v497));
const v1063=__bits(v1061 + v1062);
const v1064=Math.fround(__float(v500) * __float(v479));
const v1065=Math.fround(__float(v479) * __float(v500));
const v1066=__bits(v1064 + v1065);
const v1067=Math.fround(__float(v503) * __float(v479));
const v1068=Math.fround(__float(v479) * __float(v503));
const v1069=__bits(v1067 + v1068);
const v1070=Math.fround(__float(v506) * __float(v479));
const v1071=Math.fround(__float(v479) * __float(v506));
const v1072=__bits(v1070 + v1071);
const v1073=Math.fround(__float(v509) * __float(v479));
const v1074=Math.fround(__float(v479) * __float(v509));
const v1075=__bits(v1073 + v1074);
const v1076=Math.fround(__float(v512) * __float(v479));
const v1077=Math.fround(__float(v479) * __float(v512));
const v1078=__bits(v1076 + v1077);
const v1079=Math.fround(__float(v515) * __float(v479));
const v1080=Math.fround(__float(v479) * __float(v515));
const v1081=__bits(v1079 + v1080);
const v1083=__bits(__float(v1031) + __float(v1045));
const v1084=__bits(__float(v1032) + __float(v1048));
const v1085=__bits(__float(v1033) + __float(v1051));
const v1086=__bits(__float(v1034) + __float(v1054));
const v1087=__bits(__float(v1035) + __float(v1057));
const v1088=__bits(__float(v1036) + __float(v1060));
const v1089=__bits(__float(v1037) + __float(v1063));
const v1090=__bits(__float(v1038) + __float(v1066));
const v1091=__bits(__float(v1039) + __float(v1069));
const v1092=__bits(__float(v1040) + __float(v1072));
const v1093=__bits(__float(v1041) + __float(v1075));
const v1094=__bits(__float(v1042) + __float(v1078));
const v1095=__bits(__float(v1043) + __float(v1081));
const v1097=__bits(__float(v521) * __float(v521));
const v1098=Math.fround(__float(v524) * __float(v521));
const v1099=Math.fround(__float(v521) * __float(v524));
const v1100=__bits(v1098 + v1099);
const v1101=Math.fround(__float(v527) * __float(v521));
const v1102=Math.fround(__float(v521) * __float(v527));
const v1103=__bits(v1101 + v1102);
const v1104=Math.fround(__float(v530) * __float(v521));
const v1105=Math.fround(__float(v521) * __float(v530));
const v1106=__bits(v1104 + v1105);
const v1107=Math.fround(__float(v533) * __float(v521));
const v1108=Math.fround(__float(v521) * __float(v533));
const v1109=__bits(v1107 + v1108);
const v1110=Math.fround(__float(v536) * __float(v521));
const v1111=Math.fround(__float(v521) * __float(v536));
const v1112=__bits(v1110 + v1111);
const v1113=Math.fround(__float(v539) * __float(v521));
const v1114=Math.fround(__float(v521) * __float(v539));
const v1115=__bits(v1113 + v1114);
const v1116=Math.fround(__float(v542) * __float(v521));
const v1117=Math.fround(__float(v521) * __float(v542));
const v1118=__bits(v1116 + v1117);
const v1119=Math.fround(__float(v545) * __float(v521));
const v1120=Math.fround(__float(v521) * __float(v545));
const v1121=__bits(v1119 + v1120);
const v1122=Math.fround(__float(v548) * __float(v521));
const v1123=Math.fround(__float(v521) * __float(v548));
const v1124=__bits(v1122 + v1123);
const v1125=Math.fround(__float(v551) * __float(v521));
const v1126=Math.fround(__float(v521) * __float(v551));
const v1127=__bits(v1125 + v1126);
const v1128=Math.fround(__float(v554) * __float(v521));
const v1129=Math.fround(__float(v521) * __float(v554));
const v1130=__bits(v1128 + v1129);
const v1131=Math.fround(__float(v557) * __float(v521));
const v1132=Math.fround(__float(v521) * __float(v557));
const v1133=__bits(v1131 + v1132);
const v1135=__bits(__float(v1083) + __float(v1097));
const v1136=__bits(__float(v1084) + __float(v1100));
const v1137=__bits(__float(v1085) + __float(v1103));
const v1138=__bits(__float(v1086) + __float(v1106));
const v1139=__bits(__float(v1087) + __float(v1109));
const v1140=__bits(__float(v1088) + __float(v1112));
const v1141=__bits(__float(v1089) + __float(v1115));
const v1142=__bits(__float(v1090) + __float(v1118));
const v1143=__bits(__float(v1091) + __float(v1121));
const v1144=__bits(__float(v1092) + __float(v1124));
const v1145=__bits(__float(v1093) + __float(v1127));
const v1146=__bits(__float(v1094) + __float(v1130));
const v1147=__bits(__float(v1095) + __float(v1133));
const v1149=__bits(__float(v563) * __float(v563));
const v1150=Math.fround(__float(v566) * __float(v563));
const v1151=Math.fround(__float(v563) * __float(v566));
const v1152=__bits(v1150 + v1151);
const v1153=Math.fround(__float(v569) * __float(v563));
const v1154=Math.fround(__float(v563) * __float(v569));
const v1155=__bits(v1153 + v1154);
const v1156=Math.fround(__float(v572) * __float(v563));
const v1157=Math.fround(__float(v563) * __float(v572));
const v1158=__bits(v1156 + v1157);
const v1159=Math.fround(__float(v575) * __float(v563));
const v1160=Math.fround(__float(v563) * __float(v575));
const v1161=__bits(v1159 + v1160);
const v1162=Math.fround(__float(v578) * __float(v563));
const v1163=Math.fround(__float(v563) * __float(v578));
const v1164=__bits(v1162 + v1163);
const v1165=Math.fround(__float(v581) * __float(v563));
const v1166=Math.fround(__float(v563) * __float(v581));
const v1167=__bits(v1165 + v1166);
const v1168=Math.fround(__float(v584) * __float(v563));
const v1169=Math.fround(__float(v563) * __float(v584));
const v1170=__bits(v1168 + v1169);
const v1171=Math.fround(__float(v587) * __float(v563));
const v1172=Math.fround(__float(v563) * __float(v587));
const v1173=__bits(v1171 + v1172);
const v1174=Math.fround(__float(v590) * __float(v563));
const v1175=Math.fround(__float(v563) * __float(v590));
const v1176=__bits(v1174 + v1175);
const v1177=Math.fround(__float(v593) * __float(v563));
const v1178=Math.fround(__float(v563) * __float(v593));
const v1179=__bits(v1177 + v1178);
const v1180=Math.fround(__float(v596) * __float(v563));
const v1181=Math.fround(__float(v563) * __float(v596));
const v1182=__bits(v1180 + v1181);
const v1183=Math.fround(__float(v599) * __float(v563));
const v1184=Math.fround(__float(v563) * __float(v599));
const v1185=__bits(v1183 + v1184);
const v1187=__bits(__float(v1135) + __float(v1149));
const v1188=__bits(__float(v1136) + __float(v1152));
const v1189=__bits(__float(v1137) + __float(v1155));
const v1190=__bits(__float(v1138) + __float(v1158));
const v1191=__bits(__float(v1139) + __float(v1161));
const v1192=__bits(__float(v1140) + __float(v1164));
const v1193=__bits(__float(v1141) + __float(v1167));
const v1194=__bits(__float(v1142) + __float(v1170));
const v1195=__bits(__float(v1143) + __float(v1173));
const v1196=__bits(__float(v1144) + __float(v1176));
const v1197=__bits(__float(v1145) + __float(v1179));
const v1198=__bits(__float(v1146) + __float(v1182));
const v1199=__bits(__float(v1147) + __float(v1185));
const v1201=__bits(__float(v605) * __float(v605));
const v1202=Math.fround(__float(v608) * __float(v605));
const v1203=Math.fround(__float(v605) * __float(v608));
const v1204=__bits(v1202 + v1203);
const v1205=Math.fround(__float(v611) * __float(v605));
const v1206=Math.fround(__float(v605) * __float(v611));
const v1207=__bits(v1205 + v1206);
const v1208=Math.fround(__float(v614) * __float(v605));
const v1209=Math.fround(__float(v605) * __float(v614));
const v1210=__bits(v1208 + v1209);
const v1211=Math.fround(__float(v617) * __float(v605));
const v1212=Math.fround(__float(v605) * __float(v617));
const v1213=__bits(v1211 + v1212);
const v1214=Math.fround(__float(v620) * __float(v605));
const v1215=Math.fround(__float(v605) * __float(v620));
const v1216=__bits(v1214 + v1215);
const v1217=Math.fround(__float(v623) * __float(v605));
const v1218=Math.fround(__float(v605) * __float(v623));
const v1219=__bits(v1217 + v1218);
const v1220=Math.fround(__float(v626) * __float(v605));
const v1221=Math.fround(__float(v605) * __float(v626));
const v1222=__bits(v1220 + v1221);
const v1223=Math.fround(__float(v629) * __float(v605));
const v1224=Math.fround(__float(v605) * __float(v629));
const v1225=__bits(v1223 + v1224);
const v1226=Math.fround(__float(v632) * __float(v605));
const v1227=Math.fround(__float(v605) * __float(v632));
const v1228=__bits(v1226 + v1227);
const v1229=Math.fround(__float(v635) * __float(v605));
const v1230=Math.fround(__float(v605) * __float(v635));
const v1231=__bits(v1229 + v1230);
const v1232=Math.fround(__float(v638) * __float(v605));
const v1233=Math.fround(__float(v605) * __float(v638));
const v1234=__bits(v1232 + v1233);
const v1235=Math.fround(__float(v641) * __float(v605));
const v1236=Math.fround(__float(v605) * __float(v641));
const v1237=__bits(v1235 + v1236);
const v1239=__bits(__float(v1187) + __float(v1201));
const v1240=__bits(__float(v1188) + __float(v1204));
const v1241=__bits(__float(v1189) + __float(v1207));
const v1242=__bits(__float(v1190) + __float(v1210));
const v1243=__bits(__float(v1191) + __float(v1213));
const v1244=__bits(__float(v1192) + __float(v1216));
const v1245=__bits(__float(v1193) + __float(v1219));
const v1246=__bits(__float(v1194) + __float(v1222));
const v1247=__bits(__float(v1195) + __float(v1225));
const v1248=__bits(__float(v1196) + __float(v1228));
const v1249=__bits(__float(v1197) + __float(v1231));
const v1250=__bits(__float(v1198) + __float(v1234));
const v1251=__bits(__float(v1199) + __float(v1237));
return ({["value"]:v1239,["tangent_0"]:v1240,["tangent_1"]:v1241,["tangent_2"]:v1242,["tangent_3"]:v1243,["tangent_4"]:v1244,["tangent_5"]:v1245,["tangent_6"]:v1246,["tangent_7"]:v1247,["tangent_8"]:v1248,["tangent_9"]:v1249,["tangent_10"]:v1250,["tangent_11"]:v1251});}
function __fn13(v1252,v1253){
const v1254=v1252["p"];
const v1255=v1254["a"];
const v1256=1065353216;
const v1257=0;
const v1259=v1252["p"];
const v1260=v1259["b"];
const v1263=v1252["q"];
const v1264=v1263["a"];
const v1266=v1252["q"];
const v1267=v1266["b"];
const v1270=v1252["r"];
const v1271=v1270["a"];
const v1273=v1252["r"];
const v1274=v1273["b"];
const v1277=v1252["s"];
const v1278=v1277["a"];
const v1280=v1252["s"];
const v1281=v1280["b"];
const v1284=v1252["t"];
const v1285=v1284["a"];
const v1287=v1252["t"];
const v1288=v1287["b"];
const v1291=v1252["u"];
const v1292=v1291["a"];
const v1294=v1252["u"];
const v1295=v1294["b"];
const v1300=__record0(v1255,v1260,v1264,v1267,v1271,v1274,v1278,v1281,v1285,v1288,v1292,v1295,v1253);
const v1301=v1300["tangent_0"];
const v1302=v1300["tangent_1"];
const v1304=v1300["tangent_2"];
const v1305=v1300["tangent_3"];
const v1307=v1300["tangent_4"];
const v1308=v1300["tangent_5"];
const v1310=v1300["tangent_6"];
const v1311=v1300["tangent_7"];
const v1313=v1300["tangent_8"];
const v1314=v1300["tangent_9"];
const v1316=v1300["tangent_10"];
const v1317=v1300["tangent_11"];
return ({["p"]:({["a"]:v1301,["b"]:v1302}),["q"]:({["a"]:v1304,["b"]:v1305}),["r"]:({["a"]:v1307,["b"]:v1308}),["s"]:({["a"]:v1310,["b"]:v1311}),["t"]:({["a"]:v1313,["b"]:v1314}),["u"]:({["a"]:v1316,["b"]:v1317})});}
function __fn14(v1319,v1320){
const v1321=v1319["value"];
const v1322=v1320["value"];
const v1323=__bits(__float(v1321) - __float(v1322));
const v1324=v1319["tangent"];
const v1325=v1320["tangent"];
const v1326=__bits(__float(v1324) - __float(v1325));
return ({["value"]:v1323,["tangent"]:v1326});}
function __fn15(v1327,v1328){
const v1329=v1327["value"];
const v1330=v1328["value"];
const v1331=__bits(__float(v1329) + __float(v1330));
const v1332=v1327["tangent"];
const v1333=v1328["tangent"];
const v1334=__bits(__float(v1332) + __float(v1333));
return ({["value"]:v1331,["tangent"]:v1334});}
function __fn16(v1335,v1336){
const v1337=v1335["value"];
const v1338=v1336["value"];
const v1339=__bits(__float(v1337) * __float(v1338));
const v1340=v1335["tangent"];
const v1341=v1336["value"];
const v1342=Math.fround(__float(v1340) * __float(v1341));
const v1343=v1335["value"];
const v1344=v1336["tangent"];
const v1345=Math.fround(__float(v1343) * __float(v1344));
const v1346=__bits(v1342 + v1345);
return ({["value"]:v1339,["tangent"]:v1346});}
function __fn17(v1347,v1348){
const v1349=v1347["p"];
const v1350=v1349["a"];
const v1351=__fn14(v1350,v1348);
const v1352=v1347["p"];
const v1353=v1352["b"];
const v1354=__fn15(v1353,v1348);
const v1355=v1347["q"];
const v1356=v1355["a"];
const v1357=__fn14(v1356,v1348);
const v1358=v1347["q"];
const v1359=v1358["b"];
const v1360=__fn15(v1359,v1348);
const v1361=v1347["r"];
const v1362=v1361["a"];
const v1363=__fn14(v1362,v1348);
const v1364=v1347["r"];
const v1365=v1364["b"];
const v1366=__fn15(v1365,v1348);
const v1367=v1347["s"];
const v1368=v1367["a"];
const v1369=__fn14(v1368,v1348);
const v1370=v1347["s"];
const v1371=v1370["b"];
const v1372=__fn15(v1371,v1348);
const v1373=v1347["t"];
const v1374=v1373["a"];
const v1375=__fn14(v1374,v1348);
const v1376=v1347["t"];
const v1377=v1376["b"];
const v1378=__fn15(v1377,v1348);
const v1379=v1347["u"];
const v1380=v1379["a"];
const v1381=__fn14(v1380,v1348);
const v1382=v1347["u"];
const v1383=v1382["b"];
const v1384=__fn15(v1383,v1348);
const v1385=__fn16(v1351,v1351);
const v1386=__fn16(v1354,v1354);
const v1387=__fn15(v1385,v1386);
const v1388=__fn16(v1357,v1357);
const v1389=__fn15(v1387,v1388);
const v1390=__fn16(v1360,v1360);
const v1391=__fn15(v1389,v1390);
const v1392=__fn16(v1363,v1363);
const v1393=__fn15(v1391,v1392);
const v1394=__fn16(v1366,v1366);
const v1395=__fn15(v1393,v1394);
const v1396=__fn16(v1369,v1369);
const v1397=__fn15(v1395,v1396);
const v1398=__fn16(v1372,v1372);
const v1399=__fn15(v1397,v1398);
const v1400=__fn16(v1375,v1375);
const v1401=__fn15(v1399,v1400);
const v1402=__fn16(v1378,v1378);
const v1403=__fn15(v1401,v1402);
const v1404=__fn16(v1381,v1381);
const v1405=__fn15(v1403,v1404);
const v1406=__fn16(v1384,v1384);
return __fn15(v1405,v1406);}
function __fn18(v1407,v1408,v1409){
const v1410=v1407["p"];
const v1411=v1410["a"];
const v1412=v1408["p"];
const v1413=v1412["a"];
const v1415=v1407["p"];
const v1416=v1415["b"];
const v1417=v1408["p"];
const v1418=v1417["b"];
const v1421=v1407["q"];
const v1422=v1421["a"];
const v1423=v1408["q"];
const v1424=v1423["a"];
const v1426=v1407["q"];
const v1427=v1426["b"];
const v1428=v1408["q"];
const v1429=v1428["b"];
const v1432=v1407["r"];
const v1433=v1432["a"];
const v1434=v1408["r"];
const v1435=v1434["a"];
const v1437=v1407["r"];
const v1438=v1437["b"];
const v1439=v1408["r"];
const v1440=v1439["b"];
const v1443=v1407["s"];
const v1444=v1443["a"];
const v1445=v1408["s"];
const v1446=v1445["a"];
const v1448=v1407["s"];
const v1449=v1448["b"];
const v1450=v1408["s"];
const v1451=v1450["b"];
const v1454=v1407["t"];
const v1455=v1454["a"];
const v1456=v1408["t"];
const v1457=v1456["a"];
const v1459=v1407["t"];
const v1460=v1459["b"];
const v1461=v1408["t"];
const v1462=v1461["b"];
const v1465=v1407["u"];
const v1466=v1465["a"];
const v1467=v1408["u"];
const v1468=v1467["a"];
const v1470=v1407["u"];
const v1471=v1470["b"];
const v1472=v1408["u"];
const v1473=v1472["b"];
const v1477=0;
const v1481=__bits(__float(v1411) - __float(v1409));
const v1482=__bits(__float(v1413) - __float(v1477));
const v1486=__bits(__float(v1416) + __float(v1409));
const v1487=__bits(__float(v1418) + __float(v1477));
const v1491=__bits(__float(v1422) - __float(v1409));
const v1492=__bits(__float(v1424) - __float(v1477));
const v1496=__bits(__float(v1427) + __float(v1409));
const v1497=__bits(__float(v1429) + __float(v1477));
const v1501=__bits(__float(v1433) - __float(v1409));
const v1502=__bits(__float(v1435) - __float(v1477));
const v1506=__bits(__float(v1438) + __float(v1409));
const v1507=__bits(__float(v1440) + __float(v1477));
const v1511=__bits(__float(v1444) - __float(v1409));
const v1512=__bits(__float(v1446) - __float(v1477));
const v1516=__bits(__float(v1449) + __float(v1409));
const v1517=__bits(__float(v1451) + __float(v1477));
const v1521=__bits(__float(v1455) - __float(v1409));
const v1522=__bits(__float(v1457) - __float(v1477));
const v1526=__bits(__float(v1460) + __float(v1409));
const v1527=__bits(__float(v1462) + __float(v1477));
const v1531=__bits(__float(v1466) - __float(v1409));
const v1532=__bits(__float(v1468) - __float(v1477));
const v1536=__bits(__float(v1471) + __float(v1409));
const v1537=__bits(__float(v1473) + __float(v1477));
const v1541=__record1(v1481,v1482,v1481,v1482);
const v1544=__record1(v1486,v1487,v1486,v1487);
const v1545=__fn15(v1541,v1544);
const v1548=__record1(v1491,v1492,v1491,v1492);
const v1549=__fn15(v1545,v1548);
const v1552=__record1(v1496,v1497,v1496,v1497);
const v1553=__fn15(v1549,v1552);
const v1556=__record1(v1501,v1502,v1501,v1502);
const v1557=__fn15(v1553,v1556);
const v1560=__bits(__float(v1506) * __float(v1506));
const v1561=Math.fround(__float(v1507) * __float(v1506));
const v1562=Math.fround(__float(v1506) * __float(v1507));
const v1563=__bits(v1561 + v1562);
const v1565=v1557["value"];
const v1566=__bits(__float(v1565) + __float(v1560));
const v1567=v1557["tangent"];
const v1568=__bits(__float(v1567) + __float(v1563));
const v1572=__bits(__float(v1511) * __float(v1511));
const v1573=Math.fround(__float(v1512) * __float(v1511));
const v1574=Math.fround(__float(v1511) * __float(v1512));
const v1575=__bits(v1573 + v1574);
const v1577=__bits(__float(v1566) + __float(v1572));
const v1578=__bits(__float(v1568) + __float(v1575));
const v1582=__bits(__float(v1516) * __float(v1516));
const v1583=Math.fround(__float(v1517) * __float(v1516));
const v1584=Math.fround(__float(v1516) * __float(v1517));
const v1585=__bits(v1583 + v1584);
const v1587=__bits(__float(v1577) + __float(v1582));
const v1588=__bits(__float(v1578) + __float(v1585));
const v1592=__bits(__float(v1521) * __float(v1521));
const v1593=Math.fround(__float(v1522) * __float(v1521));
const v1594=Math.fround(__float(v1521) * __float(v1522));
const v1595=__bits(v1593 + v1594);
const v1597=__bits(__float(v1587) + __float(v1592));
const v1598=__bits(__float(v1588) + __float(v1595));
const v1602=__bits(__float(v1526) * __float(v1526));
const v1603=Math.fround(__float(v1527) * __float(v1526));
const v1604=Math.fround(__float(v1526) * __float(v1527));
const v1605=__bits(v1603 + v1604);
const v1607=__bits(__float(v1597) + __float(v1602));
const v1608=__bits(__float(v1598) + __float(v1605));
const v1612=__bits(__float(v1531) * __float(v1531));
const v1613=Math.fround(__float(v1532) * __float(v1531));
const v1614=Math.fround(__float(v1531) * __float(v1532));
const v1615=__bits(v1613 + v1614);
const v1617=__bits(__float(v1607) + __float(v1612));
const v1618=__bits(__float(v1608) + __float(v1615));
const v1622=__bits(__float(v1536) * __float(v1536));
const v1623=Math.fround(__float(v1537) * __float(v1536));
const v1624=Math.fround(__float(v1536) * __float(v1537));
const v1625=__bits(v1623 + v1624);
const v1627=__bits(__float(v1617) + __float(v1622));
const v1628=__bits(__float(v1618) + __float(v1625));
const v1629=({["value"]:v1627,["tangent"]:v1628});
return v1628;}
function __record0(v2982,v2983,v2984,v2985,v2986,v2987,v2988,v2989,v2990,v2991,v2992,v2993,v2994){
const v2995=1065353216;
const v2996=0;
const v3018=__bits(__float(v2982) - __float(v2994));
const v3019=__bits(__float(v2995) - __float(v2996));
const v3020=__bits(__float(v2996) - __float(v2996));
const v3023=__bits(__float(v2983) + __float(v2994));
const v3024=__bits(__float(v2996) + __float(v2996));
const v3025=__bits(__float(v2995) + __float(v2996));
const v3028=__bits(__float(v2984) - __float(v2994));
const v3031=__bits(__float(v2985) + __float(v2994));
const v3034=__bits(__float(v2986) - __float(v2994));
const v3037=__bits(__float(v2987) + __float(v2994));
const v3040=__bits(__float(v2988) - __float(v2994));
const v3043=__bits(__float(v2989) + __float(v2994));
const v3046=__bits(__float(v2990) - __float(v2994));
const v3049=__bits(__float(v2991) + __float(v2994));
const v3052=__bits(__float(v2992) - __float(v2994));
const v3055=__bits(__float(v2993) + __float(v2994));
const v3057=__bits(__float(v3018) * __float(v3018));
const v3058=Math.fround(__float(v3019) * __float(v3018));
const v3059=Math.fround(__float(v3018) * __float(v3019));
const v3060=__bits(v3058 + v3059);
const v3061=Math.fround(__float(v3020) * __float(v3018));
const v3062=Math.fround(__float(v3018) * __float(v3020));
const v3063=__bits(v3061 + v3062);
const v3064=Math.fround(__float(v3020) * __float(v3018));
const v3065=Math.fround(__float(v3018) * __float(v3020));
const v3066=__bits(v3064 + v3065);
const v3067=Math.fround(__float(v3020) * __float(v3018));
const v3068=Math.fround(__float(v3018) * __float(v3020));
const v3069=__bits(v3067 + v3068);
const v3070=Math.fround(__float(v3020) * __float(v3018));
const v3071=Math.fround(__float(v3018) * __float(v3020));
const v3072=__bits(v3070 + v3071);
const v3073=Math.fround(__float(v3020) * __float(v3018));
const v3074=Math.fround(__float(v3018) * __float(v3020));
const v3075=__bits(v3073 + v3074);
const v3076=Math.fround(__float(v3020) * __float(v3018));
const v3077=Math.fround(__float(v3018) * __float(v3020));
const v3078=__bits(v3076 + v3077);
const v3079=Math.fround(__float(v3020) * __float(v3018));
const v3080=Math.fround(__float(v3018) * __float(v3020));
const v3081=__bits(v3079 + v3080);
const v3082=Math.fround(__float(v3020) * __float(v3018));
const v3083=Math.fround(__float(v3018) * __float(v3020));
const v3084=__bits(v3082 + v3083);
const v3085=Math.fround(__float(v3020) * __float(v3018));
const v3086=Math.fround(__float(v3018) * __float(v3020));
const v3087=__bits(v3085 + v3086);
const v3088=Math.fround(__float(v3020) * __float(v3018));
const v3089=Math.fround(__float(v3018) * __float(v3020));
const v3090=__bits(v3088 + v3089);
const v3091=Math.fround(__float(v3020) * __float(v3018));
const v3092=Math.fround(__float(v3018) * __float(v3020));
const v3093=__bits(v3091 + v3092);
const v3095=__bits(__float(v3023) * __float(v3023));
const v3096=Math.fround(__float(v3024) * __float(v3023));
const v3097=Math.fround(__float(v3023) * __float(v3024));
const v3098=__bits(v3096 + v3097);
const v3099=Math.fround(__float(v3025) * __float(v3023));
const v3100=Math.fround(__float(v3023) * __float(v3025));
const v3101=__bits(v3099 + v3100);
const v3102=Math.fround(__float(v3024) * __float(v3023));
const v3103=Math.fround(__float(v3023) * __float(v3024));
const v3104=__bits(v3102 + v3103);
const v3105=Math.fround(__float(v3024) * __float(v3023));
const v3106=Math.fround(__float(v3023) * __float(v3024));
const v3107=__bits(v3105 + v3106);
const v3108=Math.fround(__float(v3024) * __float(v3023));
const v3109=Math.fround(__float(v3023) * __float(v3024));
const v3110=__bits(v3108 + v3109);
const v3111=Math.fround(__float(v3024) * __float(v3023));
const v3112=Math.fround(__float(v3023) * __float(v3024));
const v3113=__bits(v3111 + v3112);
const v3114=Math.fround(__float(v3024) * __float(v3023));
const v3115=Math.fround(__float(v3023) * __float(v3024));
const v3116=__bits(v3114 + v3115);
const v3117=Math.fround(__float(v3024) * __float(v3023));
const v3118=Math.fround(__float(v3023) * __float(v3024));
const v3119=__bits(v3117 + v3118);
const v3120=Math.fround(__float(v3024) * __float(v3023));
const v3121=Math.fround(__float(v3023) * __float(v3024));
const v3122=__bits(v3120 + v3121);
const v3123=Math.fround(__float(v3024) * __float(v3023));
const v3124=Math.fround(__float(v3023) * __float(v3024));
const v3125=__bits(v3123 + v3124);
const v3126=Math.fround(__float(v3024) * __float(v3023));
const v3127=Math.fround(__float(v3023) * __float(v3024));
const v3128=__bits(v3126 + v3127);
const v3129=Math.fround(__float(v3024) * __float(v3023));
const v3130=Math.fround(__float(v3023) * __float(v3024));
const v3131=__bits(v3129 + v3130);
const v3133=__bits(__float(v3057) + __float(v3095));
const v3134=__bits(__float(v3060) + __float(v3098));
const v3135=__bits(__float(v3063) + __float(v3101));
const v3136=__bits(__float(v3066) + __float(v3104));
const v3137=__bits(__float(v3069) + __float(v3107));
const v3138=__bits(__float(v3072) + __float(v3110));
const v3139=__bits(__float(v3075) + __float(v3113));
const v3140=__bits(__float(v3078) + __float(v3116));
const v3141=__bits(__float(v3081) + __float(v3119));
const v3142=__bits(__float(v3084) + __float(v3122));
const v3143=__bits(__float(v3087) + __float(v3125));
const v3144=__bits(__float(v3090) + __float(v3128));
const v3145=__bits(__float(v3093) + __float(v3131));
const v3147=__bits(__float(v3028) * __float(v3028));
const v3148=Math.fround(__float(v3020) * __float(v3028));
const v3149=Math.fround(__float(v3028) * __float(v3020));
const v3150=__bits(v3148 + v3149);
const v3151=Math.fround(__float(v3020) * __float(v3028));
const v3152=Math.fround(__float(v3028) * __float(v3020));
const v3153=__bits(v3151 + v3152);
const v3154=Math.fround(__float(v3019) * __float(v3028));
const v3155=Math.fround(__float(v3028) * __float(v3019));
const v3156=__bits(v3154 + v3155);
const v3157=Math.fround(__float(v3020) * __float(v3028));
const v3158=Math.fround(__float(v3028) * __float(v3020));
const v3159=__bits(v3157 + v3158);
const v3160=Math.fround(__float(v3020) * __float(v3028));
const v3161=Math.fround(__float(v3028) * __float(v3020));
const v3162=__bits(v3160 + v3161);
const v3163=Math.fround(__float(v3020) * __float(v3028));
const v3164=Math.fround(__float(v3028) * __float(v3020));
const v3165=__bits(v3163 + v3164);
const v3166=Math.fround(__float(v3020) * __float(v3028));
const v3167=Math.fround(__float(v3028) * __float(v3020));
const v3168=__bits(v3166 + v3167);
const v3169=Math.fround(__float(v3020) * __float(v3028));
const v3170=Math.fround(__float(v3028) * __float(v3020));
const v3171=__bits(v3169 + v3170);
const v3172=Math.fround(__float(v3020) * __float(v3028));
const v3173=Math.fround(__float(v3028) * __float(v3020));
const v3174=__bits(v3172 + v3173);
const v3175=Math.fround(__float(v3020) * __float(v3028));
const v3176=Math.fround(__float(v3028) * __float(v3020));
const v3177=__bits(v3175 + v3176);
const v3178=Math.fround(__float(v3020) * __float(v3028));
const v3179=Math.fround(__float(v3028) * __float(v3020));
const v3180=__bits(v3178 + v3179);
const v3181=Math.fround(__float(v3020) * __float(v3028));
const v3182=Math.fround(__float(v3028) * __float(v3020));
const v3183=__bits(v3181 + v3182);
const v3185=__bits(__float(v3133) + __float(v3147));
const v3186=__bits(__float(v3134) + __float(v3150));
const v3187=__bits(__float(v3135) + __float(v3153));
const v3188=__bits(__float(v3136) + __float(v3156));
const v3189=__bits(__float(v3137) + __float(v3159));
const v3190=__bits(__float(v3138) + __float(v3162));
const v3191=__bits(__float(v3139) + __float(v3165));
const v3192=__bits(__float(v3140) + __float(v3168));
const v3193=__bits(__float(v3141) + __float(v3171));
const v3194=__bits(__float(v3142) + __float(v3174));
const v3195=__bits(__float(v3143) + __float(v3177));
const v3196=__bits(__float(v3144) + __float(v3180));
const v3197=__bits(__float(v3145) + __float(v3183));
const v3199=__bits(__float(v3031) * __float(v3031));
const v3200=Math.fround(__float(v3024) * __float(v3031));
const v3201=Math.fround(__float(v3031) * __float(v3024));
const v3202=__bits(v3200 + v3201);
const v3203=Math.fround(__float(v3024) * __float(v3031));
const v3204=Math.fround(__float(v3031) * __float(v3024));
const v3205=__bits(v3203 + v3204);
const v3206=Math.fround(__float(v3024) * __float(v3031));
const v3207=Math.fround(__float(v3031) * __float(v3024));
const v3208=__bits(v3206 + v3207);
const v3209=Math.fround(__float(v3025) * __float(v3031));
const v3210=Math.fround(__float(v3031) * __float(v3025));
const v3211=__bits(v3209 + v3210);
const v3212=Math.fround(__float(v3024) * __float(v3031));
const v3213=Math.fround(__float(v3031) * __float(v3024));
const v3214=__bits(v3212 + v3213);
const v3215=Math.fround(__float(v3024) * __float(v3031));
const v3216=Math.fround(__float(v3031) * __float(v3024));
const v3217=__bits(v3215 + v3216);
const v3218=Math.fround(__float(v3024) * __float(v3031));
const v3219=Math.fround(__float(v3031) * __float(v3024));
const v3220=__bits(v3218 + v3219);
const v3221=Math.fround(__float(v3024) * __float(v3031));
const v3222=Math.fround(__float(v3031) * __float(v3024));
const v3223=__bits(v3221 + v3222);
const v3224=Math.fround(__float(v3024) * __float(v3031));
const v3225=Math.fround(__float(v3031) * __float(v3024));
const v3226=__bits(v3224 + v3225);
const v3227=Math.fround(__float(v3024) * __float(v3031));
const v3228=Math.fround(__float(v3031) * __float(v3024));
const v3229=__bits(v3227 + v3228);
const v3230=Math.fround(__float(v3024) * __float(v3031));
const v3231=Math.fround(__float(v3031) * __float(v3024));
const v3232=__bits(v3230 + v3231);
const v3233=Math.fround(__float(v3024) * __float(v3031));
const v3234=Math.fround(__float(v3031) * __float(v3024));
const v3235=__bits(v3233 + v3234);
const v3237=__bits(__float(v3185) + __float(v3199));
const v3238=__bits(__float(v3186) + __float(v3202));
const v3239=__bits(__float(v3187) + __float(v3205));
const v3240=__bits(__float(v3188) + __float(v3208));
const v3241=__bits(__float(v3189) + __float(v3211));
const v3242=__bits(__float(v3190) + __float(v3214));
const v3243=__bits(__float(v3191) + __float(v3217));
const v3244=__bits(__float(v3192) + __float(v3220));
const v3245=__bits(__float(v3193) + __float(v3223));
const v3246=__bits(__float(v3194) + __float(v3226));
const v3247=__bits(__float(v3195) + __float(v3229));
const v3248=__bits(__float(v3196) + __float(v3232));
const v3249=__bits(__float(v3197) + __float(v3235));
const v3251=__bits(__float(v3034) * __float(v3034));
const v3252=Math.fround(__float(v3020) * __float(v3034));
const v3253=Math.fround(__float(v3034) * __float(v3020));
const v3254=__bits(v3252 + v3253);
const v3255=Math.fround(__float(v3020) * __float(v3034));
const v3256=Math.fround(__float(v3034) * __float(v3020));
const v3257=__bits(v3255 + v3256);
const v3258=Math.fround(__float(v3020) * __float(v3034));
const v3259=Math.fround(__float(v3034) * __float(v3020));
const v3260=__bits(v3258 + v3259);
const v3261=Math.fround(__float(v3020) * __float(v3034));
const v3262=Math.fround(__float(v3034) * __float(v3020));
const v3263=__bits(v3261 + v3262);
const v3264=Math.fround(__float(v3019) * __float(v3034));
const v3265=Math.fround(__float(v3034) * __float(v3019));
const v3266=__bits(v3264 + v3265);
const v3267=Math.fround(__float(v3020) * __float(v3034));
const v3268=Math.fround(__float(v3034) * __float(v3020));
const v3269=__bits(v3267 + v3268);
const v3270=Math.fround(__float(v3020) * __float(v3034));
const v3271=Math.fround(__float(v3034) * __float(v3020));
const v3272=__bits(v3270 + v3271);
const v3273=Math.fround(__float(v3020) * __float(v3034));
const v3274=Math.fround(__float(v3034) * __float(v3020));
const v3275=__bits(v3273 + v3274);
const v3276=Math.fround(__float(v3020) * __float(v3034));
const v3277=Math.fround(__float(v3034) * __float(v3020));
const v3278=__bits(v3276 + v3277);
const v3279=Math.fround(__float(v3020) * __float(v3034));
const v3280=Math.fround(__float(v3034) * __float(v3020));
const v3281=__bits(v3279 + v3280);
const v3282=Math.fround(__float(v3020) * __float(v3034));
const v3283=Math.fround(__float(v3034) * __float(v3020));
const v3284=__bits(v3282 + v3283);
const v3285=Math.fround(__float(v3020) * __float(v3034));
const v3286=Math.fround(__float(v3034) * __float(v3020));
const v3287=__bits(v3285 + v3286);
const v3289=__bits(__float(v3237) + __float(v3251));
const v3290=__bits(__float(v3238) + __float(v3254));
const v3291=__bits(__float(v3239) + __float(v3257));
const v3292=__bits(__float(v3240) + __float(v3260));
const v3293=__bits(__float(v3241) + __float(v3263));
const v3294=__bits(__float(v3242) + __float(v3266));
const v3295=__bits(__float(v3243) + __float(v3269));
const v3296=__bits(__float(v3244) + __float(v3272));
const v3297=__bits(__float(v3245) + __float(v3275));
const v3298=__bits(__float(v3246) + __float(v3278));
const v3299=__bits(__float(v3247) + __float(v3281));
const v3300=__bits(__float(v3248) + __float(v3284));
const v3301=__bits(__float(v3249) + __float(v3287));
const v3303=__bits(__float(v3037) * __float(v3037));
const v3304=Math.fround(__float(v3024) * __float(v3037));
const v3305=Math.fround(__float(v3037) * __float(v3024));
const v3306=__bits(v3304 + v3305);
const v3307=Math.fround(__float(v3024) * __float(v3037));
const v3308=Math.fround(__float(v3037) * __float(v3024));
const v3309=__bits(v3307 + v3308);
const v3310=Math.fround(__float(v3024) * __float(v3037));
const v3311=Math.fround(__float(v3037) * __float(v3024));
const v3312=__bits(v3310 + v3311);
const v3313=Math.fround(__float(v3024) * __float(v3037));
const v3314=Math.fround(__float(v3037) * __float(v3024));
const v3315=__bits(v3313 + v3314);
const v3316=Math.fround(__float(v3024) * __float(v3037));
const v3317=Math.fround(__float(v3037) * __float(v3024));
const v3318=__bits(v3316 + v3317);
const v3319=Math.fround(__float(v3025) * __float(v3037));
const v3320=Math.fround(__float(v3037) * __float(v3025));
const v3321=__bits(v3319 + v3320);
const v3322=Math.fround(__float(v3024) * __float(v3037));
const v3323=Math.fround(__float(v3037) * __float(v3024));
const v3324=__bits(v3322 + v3323);
const v3325=Math.fround(__float(v3024) * __float(v3037));
const v3326=Math.fround(__float(v3037) * __float(v3024));
const v3327=__bits(v3325 + v3326);
const v3328=Math.fround(__float(v3024) * __float(v3037));
const v3329=Math.fround(__float(v3037) * __float(v3024));
const v3330=__bits(v3328 + v3329);
const v3331=Math.fround(__float(v3024) * __float(v3037));
const v3332=Math.fround(__float(v3037) * __float(v3024));
const v3333=__bits(v3331 + v3332);
const v3334=Math.fround(__float(v3024) * __float(v3037));
const v3335=Math.fround(__float(v3037) * __float(v3024));
const v3336=__bits(v3334 + v3335);
const v3337=Math.fround(__float(v3024) * __float(v3037));
const v3338=Math.fround(__float(v3037) * __float(v3024));
const v3339=__bits(v3337 + v3338);
const v3341=__bits(__float(v3289) + __float(v3303));
const v3342=__bits(__float(v3290) + __float(v3306));
const v3343=__bits(__float(v3291) + __float(v3309));
const v3344=__bits(__float(v3292) + __float(v3312));
const v3345=__bits(__float(v3293) + __float(v3315));
const v3346=__bits(__float(v3294) + __float(v3318));
const v3347=__bits(__float(v3295) + __float(v3321));
const v3348=__bits(__float(v3296) + __float(v3324));
const v3349=__bits(__float(v3297) + __float(v3327));
const v3350=__bits(__float(v3298) + __float(v3330));
const v3351=__bits(__float(v3299) + __float(v3333));
const v3352=__bits(__float(v3300) + __float(v3336));
const v3353=__bits(__float(v3301) + __float(v3339));
const v3355=__bits(__float(v3040) * __float(v3040));
const v3356=Math.fround(__float(v3020) * __float(v3040));
const v3357=Math.fround(__float(v3040) * __float(v3020));
const v3358=__bits(v3356 + v3357);
const v3359=Math.fround(__float(v3020) * __float(v3040));
const v3360=Math.fround(__float(v3040) * __float(v3020));
const v3361=__bits(v3359 + v3360);
const v3362=Math.fround(__float(v3020) * __float(v3040));
const v3363=Math.fround(__float(v3040) * __float(v3020));
const v3364=__bits(v3362 + v3363);
const v3365=Math.fround(__float(v3020) * __float(v3040));
const v3366=Math.fround(__float(v3040) * __float(v3020));
const v3367=__bits(v3365 + v3366);
const v3368=Math.fround(__float(v3020) * __float(v3040));
const v3369=Math.fround(__float(v3040) * __float(v3020));
const v3370=__bits(v3368 + v3369);
const v3371=Math.fround(__float(v3020) * __float(v3040));
const v3372=Math.fround(__float(v3040) * __float(v3020));
const v3373=__bits(v3371 + v3372);
const v3374=Math.fround(__float(v3019) * __float(v3040));
const v3375=Math.fround(__float(v3040) * __float(v3019));
const v3376=__bits(v3374 + v3375);
const v3377=Math.fround(__float(v3020) * __float(v3040));
const v3378=Math.fround(__float(v3040) * __float(v3020));
const v3379=__bits(v3377 + v3378);
const v3380=Math.fround(__float(v3020) * __float(v3040));
const v3381=Math.fround(__float(v3040) * __float(v3020));
const v3382=__bits(v3380 + v3381);
const v3383=Math.fround(__float(v3020) * __float(v3040));
const v3384=Math.fround(__float(v3040) * __float(v3020));
const v3385=__bits(v3383 + v3384);
const v3386=Math.fround(__float(v3020) * __float(v3040));
const v3387=Math.fround(__float(v3040) * __float(v3020));
const v3388=__bits(v3386 + v3387);
const v3389=Math.fround(__float(v3020) * __float(v3040));
const v3390=Math.fround(__float(v3040) * __float(v3020));
const v3391=__bits(v3389 + v3390);
const v3393=__bits(__float(v3341) + __float(v3355));
const v3394=__bits(__float(v3342) + __float(v3358));
const v3395=__bits(__float(v3343) + __float(v3361));
const v3396=__bits(__float(v3344) + __float(v3364));
const v3397=__bits(__float(v3345) + __float(v3367));
const v3398=__bits(__float(v3346) + __float(v3370));
const v3399=__bits(__float(v3347) + __float(v3373));
const v3400=__bits(__float(v3348) + __float(v3376));
const v3401=__bits(__float(v3349) + __float(v3379));
const v3402=__bits(__float(v3350) + __float(v3382));
const v3403=__bits(__float(v3351) + __float(v3385));
const v3404=__bits(__float(v3352) + __float(v3388));
const v3405=__bits(__float(v3353) + __float(v3391));
const v3407=__bits(__float(v3043) * __float(v3043));
const v3408=Math.fround(__float(v3024) * __float(v3043));
const v3409=Math.fround(__float(v3043) * __float(v3024));
const v3410=__bits(v3408 + v3409);
const v3411=Math.fround(__float(v3024) * __float(v3043));
const v3412=Math.fround(__float(v3043) * __float(v3024));
const v3413=__bits(v3411 + v3412);
const v3414=Math.fround(__float(v3024) * __float(v3043));
const v3415=Math.fround(__float(v3043) * __float(v3024));
const v3416=__bits(v3414 + v3415);
const v3417=Math.fround(__float(v3024) * __float(v3043));
const v3418=Math.fround(__float(v3043) * __float(v3024));
const v3419=__bits(v3417 + v3418);
const v3420=Math.fround(__float(v3024) * __float(v3043));
const v3421=Math.fround(__float(v3043) * __float(v3024));
const v3422=__bits(v3420 + v3421);
const v3423=Math.fround(__float(v3024) * __float(v3043));
const v3424=Math.fround(__float(v3043) * __float(v3024));
const v3425=__bits(v3423 + v3424);
const v3426=Math.fround(__float(v3024) * __float(v3043));
const v3427=Math.fround(__float(v3043) * __float(v3024));
const v3428=__bits(v3426 + v3427);
const v3429=Math.fround(__float(v3025) * __float(v3043));
const v3430=Math.fround(__float(v3043) * __float(v3025));
const v3431=__bits(v3429 + v3430);
const v3432=Math.fround(__float(v3024) * __float(v3043));
const v3433=Math.fround(__float(v3043) * __float(v3024));
const v3434=__bits(v3432 + v3433);
const v3435=Math.fround(__float(v3024) * __float(v3043));
const v3436=Math.fround(__float(v3043) * __float(v3024));
const v3437=__bits(v3435 + v3436);
const v3438=Math.fround(__float(v3024) * __float(v3043));
const v3439=Math.fround(__float(v3043) * __float(v3024));
const v3440=__bits(v3438 + v3439);
const v3441=Math.fround(__float(v3024) * __float(v3043));
const v3442=Math.fround(__float(v3043) * __float(v3024));
const v3443=__bits(v3441 + v3442);
const v3445=__bits(__float(v3393) + __float(v3407));
const v3446=__bits(__float(v3394) + __float(v3410));
const v3447=__bits(__float(v3395) + __float(v3413));
const v3448=__bits(__float(v3396) + __float(v3416));
const v3449=__bits(__float(v3397) + __float(v3419));
const v3450=__bits(__float(v3398) + __float(v3422));
const v3451=__bits(__float(v3399) + __float(v3425));
const v3452=__bits(__float(v3400) + __float(v3428));
const v3453=__bits(__float(v3401) + __float(v3431));
const v3454=__bits(__float(v3402) + __float(v3434));
const v3455=__bits(__float(v3403) + __float(v3437));
const v3456=__bits(__float(v3404) + __float(v3440));
const v3457=__bits(__float(v3405) + __float(v3443));
const v3459=__bits(__float(v3046) * __float(v3046));
const v3460=Math.fround(__float(v3020) * __float(v3046));
const v3461=Math.fround(__float(v3046) * __float(v3020));
const v3462=__bits(v3460 + v3461);
const v3463=Math.fround(__float(v3020) * __float(v3046));
const v3464=Math.fround(__float(v3046) * __float(v3020));
const v3465=__bits(v3463 + v3464);
const v3466=Math.fround(__float(v3020) * __float(v3046));
const v3467=Math.fround(__float(v3046) * __float(v3020));
const v3468=__bits(v3466 + v3467);
const v3469=Math.fround(__float(v3020) * __float(v3046));
const v3470=Math.fround(__float(v3046) * __float(v3020));
const v3471=__bits(v3469 + v3470);
const v3472=Math.fround(__float(v3020) * __float(v3046));
const v3473=Math.fround(__float(v3046) * __float(v3020));
const v3474=__bits(v3472 + v3473);
const v3475=Math.fround(__float(v3020) * __float(v3046));
const v3476=Math.fround(__float(v3046) * __float(v3020));
const v3477=__bits(v3475 + v3476);
const v3478=Math.fround(__float(v3020) * __float(v3046));
const v3479=Math.fround(__float(v3046) * __float(v3020));
const v3480=__bits(v3478 + v3479);
const v3481=Math.fround(__float(v3020) * __float(v3046));
const v3482=Math.fround(__float(v3046) * __float(v3020));
const v3483=__bits(v3481 + v3482);
const v3484=Math.fround(__float(v3019) * __float(v3046));
const v3485=Math.fround(__float(v3046) * __float(v3019));
const v3486=__bits(v3484 + v3485);
const v3487=Math.fround(__float(v3020) * __float(v3046));
const v3488=Math.fround(__float(v3046) * __float(v3020));
const v3489=__bits(v3487 + v3488);
const v3490=Math.fround(__float(v3020) * __float(v3046));
const v3491=Math.fround(__float(v3046) * __float(v3020));
const v3492=__bits(v3490 + v3491);
const v3493=Math.fround(__float(v3020) * __float(v3046));
const v3494=Math.fround(__float(v3046) * __float(v3020));
const v3495=__bits(v3493 + v3494);
const v3497=__bits(__float(v3445) + __float(v3459));
const v3498=__bits(__float(v3446) + __float(v3462));
const v3499=__bits(__float(v3447) + __float(v3465));
const v3500=__bits(__float(v3448) + __float(v3468));
const v3501=__bits(__float(v3449) + __float(v3471));
const v3502=__bits(__float(v3450) + __float(v3474));
const v3503=__bits(__float(v3451) + __float(v3477));
const v3504=__bits(__float(v3452) + __float(v3480));
const v3505=__bits(__float(v3453) + __float(v3483));
const v3506=__bits(__float(v3454) + __float(v3486));
const v3507=__bits(__float(v3455) + __float(v3489));
const v3508=__bits(__float(v3456) + __float(v3492));
const v3509=__bits(__float(v3457) + __float(v3495));
const v3511=__bits(__float(v3049) * __float(v3049));
const v3512=Math.fround(__float(v3024) * __float(v3049));
const v3513=Math.fround(__float(v3049) * __float(v3024));
const v3514=__bits(v3512 + v3513);
const v3515=Math.fround(__float(v3024) * __float(v3049));
const v3516=Math.fround(__float(v3049) * __float(v3024));
const v3517=__bits(v3515 + v3516);
const v3518=Math.fround(__float(v3024) * __float(v3049));
const v3519=Math.fround(__float(v3049) * __float(v3024));
const v3520=__bits(v3518 + v3519);
const v3521=Math.fround(__float(v3024) * __float(v3049));
const v3522=Math.fround(__float(v3049) * __float(v3024));
const v3523=__bits(v3521 + v3522);
const v3524=Math.fround(__float(v3024) * __float(v3049));
const v3525=Math.fround(__float(v3049) * __float(v3024));
const v3526=__bits(v3524 + v3525);
const v3527=Math.fround(__float(v3024) * __float(v3049));
const v3528=Math.fround(__float(v3049) * __float(v3024));
const v3529=__bits(v3527 + v3528);
const v3530=Math.fround(__float(v3024) * __float(v3049));
const v3531=Math.fround(__float(v3049) * __float(v3024));
const v3532=__bits(v3530 + v3531);
const v3533=Math.fround(__float(v3024) * __float(v3049));
const v3534=Math.fround(__float(v3049) * __float(v3024));
const v3535=__bits(v3533 + v3534);
const v3536=Math.fround(__float(v3024) * __float(v3049));
const v3537=Math.fround(__float(v3049) * __float(v3024));
const v3538=__bits(v3536 + v3537);
const v3539=Math.fround(__float(v3025) * __float(v3049));
const v3540=Math.fround(__float(v3049) * __float(v3025));
const v3541=__bits(v3539 + v3540);
const v3542=Math.fround(__float(v3024) * __float(v3049));
const v3543=Math.fround(__float(v3049) * __float(v3024));
const v3544=__bits(v3542 + v3543);
const v3545=Math.fround(__float(v3024) * __float(v3049));
const v3546=Math.fround(__float(v3049) * __float(v3024));
const v3547=__bits(v3545 + v3546);
const v3549=__bits(__float(v3497) + __float(v3511));
const v3550=__bits(__float(v3498) + __float(v3514));
const v3551=__bits(__float(v3499) + __float(v3517));
const v3552=__bits(__float(v3500) + __float(v3520));
const v3553=__bits(__float(v3501) + __float(v3523));
const v3554=__bits(__float(v3502) + __float(v3526));
const v3555=__bits(__float(v3503) + __float(v3529));
const v3556=__bits(__float(v3504) + __float(v3532));
const v3557=__bits(__float(v3505) + __float(v3535));
const v3558=__bits(__float(v3506) + __float(v3538));
const v3559=__bits(__float(v3507) + __float(v3541));
const v3560=__bits(__float(v3508) + __float(v3544));
const v3561=__bits(__float(v3509) + __float(v3547));
const v3563=__bits(__float(v3052) * __float(v3052));
const v3564=Math.fround(__float(v3020) * __float(v3052));
const v3565=Math.fround(__float(v3052) * __float(v3020));
const v3566=__bits(v3564 + v3565);
const v3567=Math.fround(__float(v3020) * __float(v3052));
const v3568=Math.fround(__float(v3052) * __float(v3020));
const v3569=__bits(v3567 + v3568);
const v3570=Math.fround(__float(v3020) * __float(v3052));
const v3571=Math.fround(__float(v3052) * __float(v3020));
const v3572=__bits(v3570 + v3571);
const v3573=Math.fround(__float(v3020) * __float(v3052));
const v3574=Math.fround(__float(v3052) * __float(v3020));
const v3575=__bits(v3573 + v3574);
const v3576=Math.fround(__float(v3020) * __float(v3052));
const v3577=Math.fround(__float(v3052) * __float(v3020));
const v3578=__bits(v3576 + v3577);
const v3579=Math.fround(__float(v3020) * __float(v3052));
const v3580=Math.fround(__float(v3052) * __float(v3020));
const v3581=__bits(v3579 + v3580);
const v3582=Math.fround(__float(v3020) * __float(v3052));
const v3583=Math.fround(__float(v3052) * __float(v3020));
const v3584=__bits(v3582 + v3583);
const v3585=Math.fround(__float(v3020) * __float(v3052));
const v3586=Math.fround(__float(v3052) * __float(v3020));
const v3587=__bits(v3585 + v3586);
const v3588=Math.fround(__float(v3020) * __float(v3052));
const v3589=Math.fround(__float(v3052) * __float(v3020));
const v3590=__bits(v3588 + v3589);
const v3591=Math.fround(__float(v3020) * __float(v3052));
const v3592=Math.fround(__float(v3052) * __float(v3020));
const v3593=__bits(v3591 + v3592);
const v3594=Math.fround(__float(v3019) * __float(v3052));
const v3595=Math.fround(__float(v3052) * __float(v3019));
const v3596=__bits(v3594 + v3595);
const v3597=Math.fround(__float(v3020) * __float(v3052));
const v3598=Math.fround(__float(v3052) * __float(v3020));
const v3599=__bits(v3597 + v3598);
const v3601=__bits(__float(v3549) + __float(v3563));
const v3602=__bits(__float(v3550) + __float(v3566));
const v3603=__bits(__float(v3551) + __float(v3569));
const v3604=__bits(__float(v3552) + __float(v3572));
const v3605=__bits(__float(v3553) + __float(v3575));
const v3606=__bits(__float(v3554) + __float(v3578));
const v3607=__bits(__float(v3555) + __float(v3581));
const v3608=__bits(__float(v3556) + __float(v3584));
const v3609=__bits(__float(v3557) + __float(v3587));
const v3610=__bits(__float(v3558) + __float(v3590));
const v3611=__bits(__float(v3559) + __float(v3593));
const v3612=__bits(__float(v3560) + __float(v3596));
const v3613=__bits(__float(v3561) + __float(v3599));
const v3615=__bits(__float(v3055) * __float(v3055));
const v3616=Math.fround(__float(v3024) * __float(v3055));
const v3617=Math.fround(__float(v3055) * __float(v3024));
const v3618=__bits(v3616 + v3617);
const v3619=Math.fround(__float(v3024) * __float(v3055));
const v3620=Math.fround(__float(v3055) * __float(v3024));
const v3621=__bits(v3619 + v3620);
const v3622=Math.fround(__float(v3024) * __float(v3055));
const v3623=Math.fround(__float(v3055) * __float(v3024));
const v3624=__bits(v3622 + v3623);
const v3625=Math.fround(__float(v3024) * __float(v3055));
const v3626=Math.fround(__float(v3055) * __float(v3024));
const v3627=__bits(v3625 + v3626);
const v3628=Math.fround(__float(v3024) * __float(v3055));
const v3629=Math.fround(__float(v3055) * __float(v3024));
const v3630=__bits(v3628 + v3629);
const v3631=Math.fround(__float(v3024) * __float(v3055));
const v3632=Math.fround(__float(v3055) * __float(v3024));
const v3633=__bits(v3631 + v3632);
const v3634=Math.fround(__float(v3024) * __float(v3055));
const v3635=Math.fround(__float(v3055) * __float(v3024));
const v3636=__bits(v3634 + v3635);
const v3637=Math.fround(__float(v3024) * __float(v3055));
const v3638=Math.fround(__float(v3055) * __float(v3024));
const v3639=__bits(v3637 + v3638);
const v3640=Math.fround(__float(v3024) * __float(v3055));
const v3641=Math.fround(__float(v3055) * __float(v3024));
const v3642=__bits(v3640 + v3641);
const v3643=Math.fround(__float(v3024) * __float(v3055));
const v3644=Math.fround(__float(v3055) * __float(v3024));
const v3645=__bits(v3643 + v3644);
const v3646=Math.fround(__float(v3024) * __float(v3055));
const v3647=Math.fround(__float(v3055) * __float(v3024));
const v3648=__bits(v3646 + v3647);
const v3649=Math.fround(__float(v3025) * __float(v3055));
const v3650=Math.fround(__float(v3055) * __float(v3025));
const v3651=__bits(v3649 + v3650);
const v3653=__bits(__float(v3601) + __float(v3615));
const v3654=__bits(__float(v3602) + __float(v3618));
const v3655=__bits(__float(v3603) + __float(v3621));
const v3656=__bits(__float(v3604) + __float(v3624));
const v3657=__bits(__float(v3605) + __float(v3627));
const v3658=__bits(__float(v3606) + __float(v3630));
const v3659=__bits(__float(v3607) + __float(v3633));
const v3660=__bits(__float(v3608) + __float(v3636));
const v3661=__bits(__float(v3609) + __float(v3639));
const v3662=__bits(__float(v3610) + __float(v3642));
const v3663=__bits(__float(v3611) + __float(v3645));
const v3664=__bits(__float(v3612) + __float(v3648));
const v3665=__bits(__float(v3613) + __float(v3651));
return ({["value"]:v3653,["tangent_0"]:v3654,["tangent_1"]:v3655,["tangent_2"]:v3656,["tangent_3"]:v3657,["tangent_4"]:v3658,["tangent_5"]:v3659,["tangent_6"]:v3660,["tangent_7"]:v3661,["tangent_8"]:v3662,["tangent_9"]:v3663,["tangent_10"]:v3664,["tangent_11"]:v3665});}
function __record1(v3666,v3667,v3668,v3669){
const v3672=__bits(__float(v3666) * __float(v3668));
const v3673=Math.fround(__float(v3667) * __float(v3668));
const v3674=Math.fround(__float(v3666) * __float(v3669));
const v3675=__bits(v3673 + v3674);
return ({["value"]:v3672,["tangent"]:v3675});}
const __namedTypes={"Bundle":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},"Node":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"},"Pair":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"},"__ink_differential_0":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"__ink_differential_2":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"},"__ink_differential_21":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"},"__ink_differential_22":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"},"__ink_differential_4":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"},"__ink_differential_5":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}};
// Portable snapshot ABI shared with native/Wasm. Hashing uses Web Crypto.
function __snapshotLimits(limits={}){
 const result={bytes:64*1024*1024,values:1000000,depth:128,...limits};
 for(const k of ['bytes','values','depth'])if(!Number.isSafeInteger(result[k])||result[k]<0||result[k]>(k==='depth'?128:k==='values'?1000000:64*1024*1024))throw Error('invalid snapshot limits');
 return result;
}
const __hash=async bytes=>new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256',bytes));
function __snapshotWriter(limits){
 const out=[];let left=limits.values,maxDepth=0;
 function bytes(xs){if(xs.length>limits.bytes-out.length)throw Error('snapshot byte limit exceeded');for(const x of xs)out.push(x);}
 function integer(n,size){n=BigInt(n);for(let i=0;i<size;i++){bytes([Number(n&255n)]);n>>=8n;}}
 function raw(xs){integer(xs.length,8);bytes(xs);}
 function value(v,t,depth=0,bindings=[]){maxDepth=Math.max(maxDepth,depth);if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{value(v,t.body,depth+1,bindings);}finally{bindings.pop();}break;
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');value(v,bound[1],depth+1,bindings);break;}
  case 'unit':break;case 'bool':bytes([v?1:0]);break;
  case 'u32':case 'i32':case 'f32':integer(v,4);break;case 'u64':integer(v,8);break;
  case 'f64':integer(__dfBits(v),8);break;
  case 'vector':if(v.length!==t.size)throw Error('vector dimension mismatch');for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'int':{let n=v<0n?-v:v;const xs=[];while(n){if(xs.length>=4096)throw Error('snapshot Int exceeds size limit');xs.push(Number(n&255n));n>>=8n;}bytes([v===0n?0:v>0n?1:2]);raw(xs);break;}
  case 'string':raw(__encoder.encode(v));break;
  case 'id':integer(BigInt('0x'+v),16);break;
  case 'enum':integer(t.variants.indexOf(v),4);break;
  case 'record':for(const f of t.fields)value(t.elided?v:v[f.name],f.type,depth+1,bindings);break;
  case 'list':if(v.length>left)throw Error('snapshot value limit exceeded');integer(v.length,8);for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'option':if(Object.hasOwn(v,'Some')){bytes([1]);value(v.Some,t.element,depth+1,bindings);}else bytes([0]);break;
  case 'result':{const branch=t.sum_key?__sumView(t.sum_key,v):v;if(Object.hasOwn(branch,'Ok')){bytes([0]);value(branch.Ok,t.ok,depth+1,bindings);}else{bytes([1]);value(branch.Err,t.error,depth+1,bindings);}break;}
  default:throw Error('unsupported snapshot type');
 }}
 return {bytes,integer,raw,value,charge(cells,depth){left-=cells;if(left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');},get maxDepth(){return maxDepth;},get left(){return left;},finish:()=>new Uint8Array(out)};
}
async function __snapshotEncode(meta,state,options){
 const limits=__snapshotLimits(options),w=__snapshotWriter(limits);
 w.integer(state.version,8);
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const rows=[...state.tables[r.index].entries()].sort((a,b)=>__keyCompare(a[0],b[0],r.key));if(rows.length>Math.floor(w.left/2))throw Error('snapshot row limit exceeded');w.integer(rows.length,8);for(const [k,v]of rows){
  if(!meta.snapshotRows){w.value(k,r.snapshotKey??r.key);w.value(v,r.snapshotValue??r.value);continue;}
  const cache=state.snapshotRows[r.index];let packed=cache.get(k);
  if(!packed){const row=__snapshotWriter(limits);row.value(k,r.snapshotKey??r.key);row.value(v,r.snapshotValue??r.value);packed={bytes:row.finish(),cells:limits.values-row.left,depth:row.maxDepth};cache.set(k,packed);}
  w.charge(packed.cells,packed.depth);w.bytes(packed.bytes);
 }}
 w.integer(state.outbox.length,8);
 for(const e of state.outbox){const channel=meta.events.findIndex(t=>t.name===e.channel);w.integer(e.commit,8);w.integer(e.position,8);w.integer(channel,4);w.value(e.value,meta.events[channel].snapshotType??meta.events[channel].type);}
 const payload=w.finish(),header=__snapshotWriter(limits);header.bytes([86,76,83,84,65,84,69,0,1,0,1,0]);header.bytes(meta.snapshot.program);header.bytes(meta.snapshot.schema);header.integer(payload.length,8);header.bytes(payload);
 const bytes=header.finish();if(bytes.length+32>limits.bytes)throw Error('snapshot byte limit exceeded');const digest=await __hash(bytes);const result=new Uint8Array(bytes.length+32);result.set(bytes);result.set(digest,bytes.length);return result;
}
async function __snapshotDecode(meta,input,options){
 const limits=__snapshotLimits(options);
 if(!(input instanceof Uint8Array)&&!Array.isArray(input))throw Error('expected snapshot bytes');
 if(input.length>limits.bytes||input.length<116)throw Error('snapshot byte length invalid');
 if(Array.isArray(input)&&input.some(b=>!Number.isInteger(b)||b<0||b>255))throw Error('invalid snapshot bytes');
 const bytes=new Uint8Array(input); // capture before asynchronous integrity work
 function same(a,b){return a.length===b.length&&a.every((v,i)=>v===b[i]);}
 if(!same(bytes.subarray(0,12),[86,76,83,84,65,84,69,0,1,0,1,0]))throw Error('snapshot format or semantics version mismatch');
 if(!same(bytes.subarray(12,44),meta.snapshot.program)||!same(bytes.subarray(44,76),meta.snapshot.schema))throw Error('snapshot program or schema identity mismatch');
 const end=bytes.length-32,digest=await __hash(bytes.subarray(0,end));if(!same(digest,bytes.subarray(end)))throw Error('snapshot integrity check failed');
 let at=76,left=limits.values;
 function take(n){if(!Number.isSafeInteger(n)||n<0||n>end-at)throw Error('truncated snapshot');const x=bytes.subarray(at,at+n);at+=n;return x;}
 function integer(size){const xs=take(size);let n=0n;for(let i=size-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return n;}
 function length(){const n=integer(8);if(n>BigInt(Number.MAX_SAFE_INTEGER))throw Error('snapshot length not addressable');return Number(n);}
 function sequence(){const n=length();if(n>left)throw Error('snapshot value limit exceeded');return n;}
 function raw(){return take(length());}
 const n=length();if(n!==end-84)throw Error('snapshot payload length mismatch');
 function value(t,depth=0,bindings=[]){if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{return value(t.body,depth+1,bindings);}finally{bindings.pop();}
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');return value(bound[1],depth+1,bindings);}
  case 'unit':return null;case 'bool':{const b=take(1)[0];if(b>1)throw Error('invalid Bool tag');return b===1;}
  case 'u32':case 'f32':return Number(integer(4));case 'i32':return Number(BigInt.asIntN(32,integer(4)));case 'u64':return integer(8);
  case 'f64':return __dfFromBits(integer(8));
  case 'vector':{const xs=[];for(let i=0;i<t.size;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'int':{const sign=take(1)[0],xs=raw();if(xs.length>4096)throw Error('snapshot Int exceeds size limit');if(!((sign===0&&xs.length===0)||((sign===1||sign===2)&&xs.length>0&&xs[xs.length-1]!==0)))throw Error('noncanonical signed integer');let n=0n;for(let i=xs.length-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return sign===2?-n:n;}
  case 'string':return new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(raw());
  case 'id':return integer(16).toString(16).padStart(32,'0');
  case 'enum':{const i=Number(integer(4));if(i>=t.variants.length)throw Error('invalid enum tag');return t.variants[i];}
  case 'record':if(t.elided)return value(t.fields[0].type,depth+1,bindings);return Object.fromEntries(t.fields.map(f=>[f.name,value(f.type,depth+1,bindings)]));
  case 'list':{const n=sequence(),xs=[];for(let i=0;i<n;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'option':{const tag=take(1)[0];if(tag===0)return {None:null};if(tag===1)return {Some:value(t.element,depth+1,bindings)};throw Error('invalid Option tag');}
  case 'result':{const tag=take(1)[0];if(tag===0){const child=value(t.ok,depth+1,bindings);return t.sum_key?__sumMake(t.sum_key,true,child):{Ok:child};}if(tag===1){const child=value(t.error,depth+1,bindings);return t.sum_key?__sumMake(t.sum_key,false,child):{Err:child};}throw Error('invalid Result tag');}
  default:throw Error('unsupported snapshot type');
 }}
 const version=integer(8),tables=meta.roots.map(()=>new Map());
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const n=sequence();if(n>Math.floor(left/2))throw Error('snapshot row limit exceeded');let prior;for(let i=0;i<n;i++){const k=value(r.snapshotKey??r.key),v=value(r.snapshotValue??r.value);if(i&&__keyCompare(prior,k,r.key)>=0)throw Error('duplicate or unordered snapshot key');tables[r.index].set(k,v);prior=k;}}
 const count=sequence(),outbox=[];let prior;
 for(let i=0;i<count;i++){const commit=integer(8),position=integer(8),channel=Number(integer(4));if(!meta.events[channel])throw Error('unknown snapshot event channel');const v=value(meta.events[channel].snapshotType??meta.events[channel].type);if(commit===0n||commit>version||(prior&&(commit<prior.commit||(commit===prior.commit&&position<=prior.position))))throw Error('invalid snapshot event sequence');const e={commit,position,channel:meta.events[channel].name,value:v};outbox.push(e);prior=e;}
 if(at!==end)throw Error('trailing snapshot payload');return {version,tables,outbox};
}
// Fixed subscription lifecycle. Root/output edges derive from checked source;
// values and ownership codecs are compiled from each query's declared type.
function __createObservers(prepare){
 const subscriptions=new Map(),byRoot=new Map(),errors=[],directRoots=[],rootSchedules=[];
 let pending=[],spare=[];
 let next=0,held=0,flushing=false;
 function report(s,error,phase){errors.push({query:s?.query??null,error,phase});if(s?.onError)try{s.onError(error);}catch(e){errors.push({query:s.query,error:e,phase:'error-handler'});}}
 function flush(initialPasses=0){
  if(held||flushing||!pending.length)return;
  flushing=true;let passes=initialPasses;
  try{
   while(pending.length&&!held){
    if(++passes>1024){report(null,Error('subscription publication budget exhausted'),'publication');break;}
    const affected=pending;pending=spare;spare=affected;
    for(const s of affected)s.queued=false;
    // Snapshot every affected value before consumers run. Deliveries reside in
    // the stable subscription slots; no per-delivery tuple is allocated.
    for(const s of affected){if(!s.active)continue;s.deliver=false;
     try{if(s.pair){const a=s.pairState?s.pairState.keeps[s.keep0]:s.read0(),b=s.pairState?s.pairState.keeps[s.keep1]:s.read1();if(s.value0!==a||s.value1!==b){s.value0=a;s.value1=b;s.delivery0=a;s.delivery1=b;s.deliver=true;}}else{const value=s.capture(s.read());if(!s.equal(s.value,value)){s.value=value;s.delivery=value;s.deliver=true;}}}
     catch(e){report(s,e,'query');}
    }
    for(const s of affected){if(!s.active||!s.deliver)continue;const value=s.delivery;s.deliver=false;s.delivery=undefined;
     try{if(s.pair)s.callback(s.delivery0,s.delivery1);else s.callback(s.output(value));}catch(e){report(s,e,'listener');}
    }
    affected.length=0;
   }
  }finally{flushing=false;}
 }
 function install(query,q,callback,{immediate=true,onError}={}){
  if(typeof callback!=='function'||onError!==undefined&&typeof onError!=='function')throw TypeError('subscription callback');
  const s={...q,id:next++,query,callback,onError,active:true,queued:false,deliver:false,delivery:undefined};
  if(s.pair){s.value0=s.pairState?s.pairState.keeps[s.keep0]:s.read0();s.value1=s.pairState?s.pairState.keeps[s.keep1]:s.read1();}else{s.value=s.capture(s.read());}subscriptions.set(s.id,s);
  for(const root of s.roots){let ids=byRoot.get(root);if(!ids)byRoot.set(root,ids=[]);ids.push(s);schedule(root,ids);}
  const dispose=()=>{if(!subscriptions.delete(s.id))return;s.active=false;for(const root of s.roots){const ids=byRoot.get(root);ids.splice(ids.indexOf(s),1);schedule(root,ids);if(!ids.length)byRoot.delete(root);}};
  if(immediate)try{if(s.pair)callback(s.value0,s.value1);else callback(s.output(s.value));}catch(e){dispose();throw e;}
  return dispose;
 }
 // Bind the publication implementation when consumers change, instead of
 // rediscovering the one-consumer schedule on each source mutation.
 function schedule(root,ids){
  const s=directRoots[root]=ids.length===1&&ids[0].pairState?ids[0]:null;
  rootSchedules[root]=!ids.length?null:s?()=>publishPair(s):(outputs,epoch)=>{enqueueRoot(root,outputs,epoch);flush();};
 }
 function publishPair(s){
  const a=s.pairState.keeps[s.keep0],b=s.pairState.keeps[s.keep1];
  if(s.value0===a&&s.value1===b)return;
  if(!held&&!flushing&&!pending.length){
   s.value0=a;s.value1=b;flushing=true;
   try{s.callback(a,b);}catch(e){report(s,e,'listener');}finally{flushing=false;}
   flush(1);return;
  }
  if(!s.queued){s.queued=true;pending.push(s);}flush();
 }
 function enqueueRoot(root,outputs,epoch){
  const slots=byRoot.get(root);if(!slots)return;
  for(let i=0;i<slots.length;i++){
   const s=slots[i];if(s.queued)continue;
   if(outputs!==null&&s.outputs?.length){
    let changed=false;for(let j=0;j<s.outputs.length;j++)if(epoch?outputs[s.outputs[j]]===epoch:outputs.has(s.outputs[j])){changed=true;break;}
    if(!changed)continue;
   }
   s.queued=true;pending.push(s);
  }
 }
 return {
  directRoots,rootSchedules,
  get active(){return subscriptions.size!==0;},
  subscribe(query,args,callback,options){return install(query,prepare(query,args),callback,options);},
  subscribeGroup(queries,callback,options){
   if(!Array.isArray(queries)||!queries.length)throw TypeError('subscription group requires queries');
   const qs=queries.map(q=>typeof q==='string'?prepare(q,[]):prepare(q.query,q.args??[]));
   const roots=[...new Set(qs.flatMap(q=>q.roots))];
   // An unknown dependency forces ordinary root invalidation for the group.
   const outputs=qs.every(q=>q.outputs?.length)?[...new Set(qs.flatMap(q=>q.outputs))]:[];
   const scalar=qs.every(q=>q.scalar),direct=qs.every(q=>q.direct);
   return install(queries,{roots,outputs,read:direct?()=>qs.map(q=>q.direct()):()=>qs.map(q=>q.read()),capture:scalar?values=>values:values=>values.map((v,i)=>qs[i].capture(v)),output:scalar?values=>values.slice():values=>values.map((v,i)=>qs[i].output(v)),equal:scalar?(a,b)=>a.every((v,i)=>v===b[i]):(a,b)=>a.every((v,i)=>qs[i].equal(v,b[i]))},callback,options);
  },
  subscribeValues(queries,callback,options){
   if(!Array.isArray(queries)||!queries.length)throw TypeError('subscription group requires queries');
   if(typeof callback!=='function')throw TypeError('subscription callback');
   const qs=queries.map(q=>typeof q==='string'?prepare(q,[]):prepare(q.query,q.args??[]));
   if(qs.length===2&&qs.every(q=>q.scalar)){
    const roots=[...new Set(qs.flatMap(q=>q.roots))],outputs=qs.every(q=>q.outputs?.length)?[...new Set(qs.flatMap(q=>q.outputs))]:[];
    const pairState=qs[0].committed&&qs[1].committed&&qs[0].committed.state===qs[1].committed.state?qs[0].committed.state:null;
    return install(queries,{roots,outputs,pair:true,pairState,keep0:qs[0].committed?.keep,keep1:qs[1].committed?.keep,read0:qs[0].direct||qs[0].read,read1:qs[1].direct||qs[1].read},callback,options);
   }
   return this.subscribeGroup(queries,values=>callback(...values),options);
  },
  commit(roots,outputs=null){
   if(!subscriptions.size)return;
   for(const root of roots)enqueueRoot(root,outputs,false);
   flush();
  },
  // A checked single-root action supplies a reusable array of changed outputs.
  // No root carrier, Set, affected-ID array or Map lookup per delivery is needed.
  commitRoot(root,outputs=null,epoch=0){
   rootSchedules[root]?.(outputs,epoch);
  },
  hold(){held++;return pending.slice();},
  release(){if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  rollback(mark){for(const s of pending)s.queued=false;pending.length=0;for(const s of mark)if(s.active&&!s.queued){s.queued=true;pending.push(s);}if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  batch(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('batch callback must be synchronous');held++;
   try{const value=callback();if(value&&typeof value.then==='function')throw TypeError('state batch callback must be synchronous');return value;}
   finally{held--;flush();}
  },
  flush,takeErrors(){return errors.splice(0);}
 };
}
function __versionWord(v){return typeof v==='number'?BigInt(v):v;}
function __storedCommit(meta,v){return meta.compactCommits&&v<=9007199254740991n?Number(v):v;}
function __nextCommit(v){return typeof v==='number'&&v<9007199254740991?v+1:BigInt(v)+1n;}
// Private column event log. Public records and portable event ordering are unchanged.
// Private event storage. Public events and portable snapshots keep their ordinary
// ordered records. A selected contiguous run omits repeated commit metadata;
// gaps and duplicate commits materialise an exact literal column.
class __EventColumns {
 constructor(channels,compact=false,runs=false){this.channels=channels;this.compact=compact;this.runs=runs;this.commits=runs?null:[];this.base=undefined;this.values=[];this.positions=null;this.channelValues=channels.length===1?null:[];}
 get length(){return this.values.length;}
 set length(n){if(!Number.isSafeInteger(n)||n<0||n>this.length)throw Error('event log truncate');if(this.commits)this.commits.length=n;this.values.length=n;if(this.positions)this.positions.length=n;if(this.channelValues)this.channelValues.length=n;if(n===0){this.base=undefined;if(this.runs)this.commits=null;}}
 append(commit,position,channel,value){
  const i=this.values.length;
  if(this.commits)this.commits.push(commit);
  else if(!i)this.base=commit;
  else{
   const small=typeof this.base==='number'&&typeof commit==='number';
   const expected=small?this.base+i:__versionWord(this.base)+BigInt(i);
   if(expected!==commit){
    this.commits=[];
    for(let j=0;j<i;j++){const word=__versionWord(this.base)+BigInt(j);this.commits.push(this.compact&&word<=9007199254740991n?Number(word):word);}
    this.commits.push(commit);
   }
  }
  this.values.push(value);if(this.channelValues)this.channelValues.push(channel);if(position!==0n&&!this.positions)this.positions=new Array(i).fill(0n);if(this.positions)this.positions.push(position);
 }
 push(e){this.append(this.compact&&e.commit<=9007199254740991n?Number(e.commit):e.commit,e.position,e.channel,e.value);return this.length;}
 at(i){if(i<0)i+=this.length;if(i<0||i>=this.length)return undefined;return {commit:this.commits?__versionWord(this.commits[i]):__versionWord(this.base)+BigInt(i),position:this.positions?this.positions[i]:0n,channel:this.channelValues?this.channelValues[i]:this.channels[0],value:this.values[i]};}
 *[Symbol.iterator](){for(let i=0;i<this.length;i++)yield this.at(i);}
 map(f){const out=new Array(this.length);for(let i=0;i<this.length;i++)out[i]=f(this.at(i),i);return out;}
 filter(f){const out=new __EventColumns(this.channels,this.compact,this.runs);for(let i=0;i<this.length;i++){const e=this.at(i);if(f(e,i))out.push(e);}return out;}
}
function __eventLog(meta,events=[]){
 if(!meta.eventColumns)return meta.compactCommits?events.map(e=>({...e,commit:__storedCommit(meta,e.commit)})):events;
 const log=new __EventColumns(meta.events.map(e=>e.name),meta.compactCommits,meta.eventRuns);for(const e of events)log.append(__storedCommit(meta,e.commit),e.position,e.channel,e.value);return log;
}
// CALLER CONTRACT: arguments must match declared types; malformed data may throw or corrupt state.
// Fixed state primitives used by emitted action bodies, without an AST evaluator.
class __Abort {constructor(value){this.value=value;}}
function __preflightError(message){throw Error(message);}
function __try(value){if(Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value.Ok;}
function __nested(value,change){if(change && Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value;}
function __equal(a,b){if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object')return false;const ak=Object.keys(a),bk=Object.keys(b);return ak.length===bk.length&&ak.every(k=>Object.hasOwn(b,k)&&__equal(a[k],b[k]));}
function __checked(op,a,b,bits){const x=BigInt(a),y=BigInt(b),n=op==='checked_add'?x+y:op==='checked_sub'?x-y:x*y;const min=bits===-32?-2147483648n:0n,max=bits===-32?2147483648n:1n<<BigInt(bits);return n<min||n>=max?{Err:'ArithmeticError.Overflow'}:{Ok:Math.abs(bits)===32?Number(n):n};}
function __okOr(value,error){return Object.hasOwn(value,'Some')?{Ok:value.Some}:{Err:error};}
function __mapValue(value,kind,method,fn){
 if(kind==='list')return value[method](fn);
 if(kind==='option')return Object.hasOwn(value,'Some')?{Some:fn(value.Some)}:{None:null};
 const tag=method==='map_err'?'Err':'Ok';return Object.hasOwn(value,tag)?{[tag]:fn(value[tag])}:value;
}
const __encoder=new TextEncoder();
function __tick(ctx){if(--ctx.fuel<0)throw Error('Ink state execution budget exhausted');}
function __keyCompare(a,b,type){
 if(type.kind==='string'){let i=0,j=0;while(i<a.length&&j<b.length){const x=a.codePointAt(i),y=b.codePointAt(j);if(x!==y)return x-y;i+=x>65535?2:1;j+=y>65535?2:1;}return (i<a.length?1:0)-(j<b.length?1:0);}
 return a<b?-1:a>b?1:0;
}
// A table's ordered key view is reused until membership changes. Values are
// fetched at traversal time, so replacement never leaves stale row payloads.
const __tableOrder=new WeakMap();
function __keyPosition(keys,key,type){let low=0,high=keys.length;while(low<high){const middle=(low+high)>>>1;if(__keyCompare(keys[middle],key,type)<0)low=middle+1;else high=middle;}return low;}
function __tableMembership(rt,index,key,present){
 const view=__tableOrder.get(rt.tables[index]);if(!view)return;
 const at=__keyPosition(view.keys,key,rt.meta.roots[index].key);
 if((at<view.keys.length&&view.keys[at]===key)===present)view.pending.delete(key);
 else view.pending.set(key,present);
}
function __orderedKeys(rt,index){
 const table=rt.tables[index],type=rt.meta.roots[index].key;let view=__tableOrder.get(table);
 if(!view){view={keys:[...table.keys()].sort((a,b)=>__keyCompare(a,b,type)),pending:new Map()};__tableOrder.set(table,view);}
 if(view.pending.size){
  const changes=[...view.pending.keys()].sort((a,b)=>__keyCompare(a,b,type)),merged=[];let i=0,j=0;
  while(i<view.keys.length||j<changes.length){
   if(j===changes.length||(i<view.keys.length&&__keyCompare(view.keys[i],changes[j],type)<0))merged.push(view.keys[i++]);
   else{const key=changes[j++];if(i<view.keys.length&&view.keys[i]===key)i++;if(view.pending.get(key))merged.push(key);}
  }
  view.keys=merged;view.pending.clear();
 }
 const keys=view.keys;
 const cell=rt.cell;
 if(cell&&cell.index===index&&table.has(cell.key)!==(cell.next!==undefined)){
  if(cell.next===undefined)return keys.filter(k=>k!==cell.key);
  const at=__keyPosition(keys,cell.key,type);return [...keys.slice(0,at),cell.key,...keys.slice(at)];
 }
 return keys;
}
function __cellGet(rt,index,key){const cell=rt.cell;return cell&&cell.index===index&&cell.key===key?cell.next:rt.tables[index].get(key);}
function __readTable(rt,index){const cell=rt.cell;if(!cell||cell.index!==index)return rt.tables[index];const table=new Map(rt.tables[index]);if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);return table;}
// The first before-image of each cell suffices for whole-transaction rollback.
function __remember(rt,index,key,present,value){if(rt.cellMode)return;if(!rt.seen[index].has(key)){rt.seen[index].add(key);rt.undo.push([index,key,present,value]);}}
// Immutable keeps retain private values. Public results remain owned copies.
// Reverse edges come from checked source effects.
// Before-images preserve cached values across failed actions; host rollback and
// restore discard caches rather than serializing them into logical snapshots.
function __invalidateKeeps(rt,index){
 if(rt.observers?.active)rt.changedRoots.add(index);
 if(!rt.keeps||rt.cellMode)return;
 for(const keep of rt.meta.keepInvalidations[index]){
  if(!rt.keepDirty[keep]){rt.keepDirty[keep]=1;rt.keepUndoIndices[rt.keepUndoCount++]=keep;rt.keepBefore[keep]=rt.keeps[keep];}
  rt.keeps[keep]=undefined;
 }
}
function __restoreKeeps(rt){for(let i=rt.keepUndoCount-1;i>=0;i--){const keep=rt.keepUndoIndices[i];rt.keeps[keep]=rt.keepBefore[keep];}__refreshActiveViews(rt);}
function __clearKeepJournal(rt){for(let i=0;i<rt.keepUndoCount;i++){const keep=rt.keepUndoIndices[i];rt.keepDirty[keep]=0;rt.keepBefore[keep]=undefined;}rt.keepUndoCount=0;}
function __rebuildViews(rt){
 rt.activeViewRoots=new Uint8Array(rt.meta.roots.length);
 for(const view of rt.views){rt.keeps[view.keep]=undefined;if(!rt.meta.lazyMaintenance)__viewBase(rt,view);}
}
function __refreshActiveViews(rt){rt.activeViewRoots.fill(0);for(const view of rt.views)if(rt.keeps[view.keep]!==undefined)rt.activeViewRoots[view.root]=1;}
function __viewBase(rt,view){
 if(rt.keeps[view.keep]===undefined){let value=view.zero;for(const [key,row]of rt.tables[view.root])value=view.combine(value,view.contribution(key,row));rt.keeps[view.keep]=value;rt.activeViewRoots[view.root]=1;}
 return rt.keeps[view.keep];
}
function __viewValue(view,value,key,oldValue,newValue){
 if(oldValue===undefined)return view.insert?view.insert(value,key,newValue):view.combine(value,view.contribution(key,newValue));
 if(newValue===undefined)return view.remove?view.remove(value,key,oldValue):view.combine(value,view.inverse(view.contribution(key,oldValue)));
 return view.replace?view.replace(value,key,oldValue,newValue):view.combine(view.combine(value,view.inverse(view.contribution(key,oldValue))),view.contribution(key,newValue));
}
function __updateViews(rt,index,key,oldValue,newValue){
 if(!rt.activeViewRoots[index])return null;
 const updates=rt.viewNext;
 for(const view of rt.viewsByRoot[index])updates[view.keep]=rt.keeps[view.keep]===undefined?undefined:__viewValue(view,rt.keeps[view.keep],key,oldValue,newValue);
 return updates;
}
function __installViews(rt,updates,index){if(updates)for(const view of rt.viewsByRoot[index])rt.keeps[view.keep]=updates[view.keep];}
function __pendingView(rt,view){
 const keep=view.keep;
 if(rt.pendingValues[keep]===undefined){
  const cell=rt.cell;
  rt.pendingValues[keep]=__viewValue(view,__viewBase(rt,view),cell.key,cell.prior,cell.next);
  rt.pendingIndices.push(keep);
 }
 return rt.pendingValues[keep];
}
function __prepareCell(rt){if(rt.cell&&rt.activeViewRoots[rt.cell.index]){const prepare=rt.views.prepareRoots?.[rt.cell.index];if(prepare)prepare(rt,rt.cell);else for(const view of rt.viewsByRoot[rt.cell.index])if(rt.keeps[view.keep]!==undefined)__pendingView(rt,view);}}
function __invalidateSnapshotRow(rt,index,key){rt.snapshotRows?.[index].delete(key);}
function __writeCell(rt,index,key,next,prior){
 if(rt.cellMode){if(rt.cell)throw Error('checked single-cell bound exceeded');rt.cell={index,key,next,prior};}
 else{const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);if(rt.changeTracking)__recordChange(rt,index,key,prior,next);if((prior!==undefined)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);if(next===undefined)table.delete(key);else table.set(key,next);}
}
function __commitCell(rt){
 const cell=rt.cell;if(!cell)return;
 const table=rt.tables[cell.index];__invalidateSnapshotRow(rt,cell.index,cell.key);
 if(rt.changeTracking)__recordChange(rt,cell.index,cell.key,cell.prior,cell.next);
 if((cell.prior!==undefined)!==(cell.next!==undefined))__tableMembership(rt,cell.index,cell.key,cell.next!==undefined);
 if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);
 for(const keep of rt.meta.keepInvalidations[cell.index])rt.keeps[keep]=rt.pendingValues[keep];
 rt.cell=null;
}
// Preflight scratch has no logical state or rollback obligations. Definitions
// are the same admitted group operations used by ordinary cell maintenance.
function __prepareDirect(rt,index,key,prior,next){
 const prepare=rt.views.directRoots?.[index];
 if(prepare)prepare(rt,key,prior,next);
 else for(const view of rt.viewsByRoot[index])rt.viewNext[view.keep]=__viewValue(view,rt.keeps[view.keep],key,prior,next);
}
function __storeDirect(rt,index,key,prior,next,slot){
 const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);
 if((prior!==undefined)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);
 if(rt.changeTracking)__recordChange(rt,index,key,prior,next);
 if(slot===undefined){if(next===undefined)table.delete(key);else table.set(key,next);}
 else{
  // The checked preflight lookup retains the dense slot until this commit.
  // No callback or source write can intervene; sparse keys retain exact identity.
  if(slot<0){if(next===undefined)table.sparse.delete(key);else table.sparse.set(key,next);}else table.dense[slot]=next;
  if(prior===undefined&&next!==undefined)table.members.add(key);else if(prior!==undefined&&next===undefined)table.members.delete(key);
 }
}
function __commitDirect(rt,index,key,prior,next,slot){
 __storeDirect(rt,index,key,prior,next,slot);
 const publishOutputs=rt.meta.outputPublication&&!rt.observers.directRoots[index]&&rt.observers.active;
 if(publishOutputs&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}

 for(const keep of rt.meta.keepInvalidations[index]){
  const value=rt.viewByKeep[keep]?rt.viewNext[keep]:undefined;
  if(publishOutputs)rt.changedOutputs[keep]=rt.keeps[keep]!==value?rt.changedOutputEpoch:0;
  rt.keeps[keep]=value;
 }
}
function __emit(rt,channel,value){
 if(rt.eventCount++===0){rt.eventChannel=channel;rt.eventValue=value;}
 else rt.staged.push([channel,value]);
}
// Checked prefix capacities are at most 2^20. Number conversion is exact
// inside that prefix; rounding a wide word cannot move it into the prefix.
// Wide keys retain their original full-width value in the sparse fallback.
class __DenseTable{
 constructor(capacity){this.limit=capacity;this.dense=[];for(let i=0;i<capacity;i++)this.dense.push(undefined);this.sparse=new Map();this.members=new Set();}
 clear(){this.dense.fill(undefined);this.sparse.clear();this.members.clear();__tableOrder.delete(this);return this;}
 slot(key){const i=Number(key);return Number.isInteger(i)&&i>=0&&i<this.limit?i:-1;}
 get size(){return this.members.size;}
 get(key){const i=this.slot(key);return i<0?this.sparse.get(key):this.dense[i];}
 has(key){return this.get(key)!==undefined;}
 set(key,value){const i=this.slot(key),present=i<0?this.sparse.has(key):this.dense[i]!==undefined;if(i<0)this.sparse.set(key,value);else this.dense[i]=value;if(!present)this.members.add(key);return this;}
 delete(key){const i=this.slot(key);if(i<0)this.sparse.delete(key);else this.dense[i]=undefined;return this.members.delete(key);}
 keys(){return this.members.keys();}
 *values(){for(const key of this.members)yield this.get(key);}
 *entries(){for(const key of this.members)yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
class __ColumnTable {
 constructor(root){
  this.limit=root.columnPrefix.capacity;this.keyBig=root.key.kind==='u64';
  this.fields=root.value.fields;this.exactNumbers=root.columnPrefix.exactNumbers;
  this.present=new Uint8Array(this.limit);this.count=0;this.sparse=new Map();
  this.lanes=this.fields.map(f=>f.type.kind==='u64'?(this.exactNumbers?new Float64Array(this.limit):new BigUint64Array(this.limit)):f.type.kind==='i32'?new Int32Array(this.limit):f.type.kind==='bool'?new Uint8Array(this.limit):new Uint32Array(this.limit));
  this.wide=this.fields.map(f=>f.type.kind==='u64'&&this.exactNumbers?new Map():null);
 }
 slot(key){const i=Number(key);return Number.isInteger(i)&&i>=0&&i<this.limit?i:-1;}
 get size(){return this.count+this.sparse.size;}
 has(key){const i=this.slot(key);return i<0?this.sparse.has(key):this.present[i]!==0;}
 get(key){const i=this.slot(key);if(i<0)return this.sparse.get(key);if(!this.present[i])return undefined;const row=Object.create(null);for(let j=0;j<this.fields.length;j++){const f=this.fields[j],v=this.lanes[j][i];row[f.name]=f.type.kind==='bool'?v!==0:f.type.kind==='u64'&&this.exactNumbers?(this.wide[j].get(i)??BigInt(v)):v;}return row;}
 set(key,row){const i=this.slot(key);if(i<0){this.sparse.set(key,row);return this;}for(let j=0;j<this.fields.length;j++){const f=this.fields[j],v=row[f.name];if(f.type.kind==='u64'&&this.exactNumbers){if(v<=9007199254740991n){this.lanes[j][i]=Number(v);this.wide[j].delete(i);}else{this.lanes[j][i]=0;this.wide[j].set(i,v);}}else this.lanes[j][i]=f.type.kind==='bool'?Number(v):v;}if(!this.present[i]){this.present[i]=1;this.count++;}return this;}
 delete(key){const i=this.slot(key);if(i<0)return this.sparse.delete(key);if(!this.present[i])return false;this.present[i]=0;this.count--;for(const wide of this.wide)wide?.delete(i);return true;}
 *keys(){for(let i=0;i<this.limit;i++)if(this.present[i])yield this.keyBig?BigInt(i):i;yield* this.sparse.keys();}
 *values(){for(const key of this.keys())yield this.get(key);}
 *entries(){for(const key of this.keys())yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
function __newTables(meta,prefixes,old,spares){return meta.roots.map((root,i)=>{const prior=spares?.[i];const t=root.columnPrefix?new __ColumnTable(root):prefixes[i]?(prior instanceof __DenseTable&&prior.limit===prefixes[i]?prior.clear():new __DenseTable(prefixes[i])):new Map();if(old)for(const [k,v]of old[i])t.set(k,v);return t;});}
// Only inactive containers are reused. Consume the spare before preparation so
// a failed invariant/rebuild cannot expose its partially reconstructed contents.
// Rows remain immutable; the current logical state changes only at installation.
function __restoreTables(rt,prefixes,old){const spares=rt.restoreSpares;rt.restoreSpares=null;return __newTables(rt.meta,prefixes,old,spares);}
function __cachedKeep(ctx,rt,index,compute){
 if(rt.cell&&rt.meta.keepInvalidations[rt.cell.index].includes(index)){
  const view=rt.viewByKeep[index];
  if(view)return __pendingView(rt,view);
  if(rt.pendingValues[index]===undefined){rt.pendingValues[index]=compute(ctx,rt);rt.pendingIndices.push(index);}
  return rt.pendingValues[index];
 }
 const prior=rt.keeps[index];if(prior!==undefined)return prior;
 const view=rt.viewByKeep[index];if(view)return __viewBase(rt,view);
 const value=compute(ctx,rt);rt.keeps[index]=value;return value;
}
function __tableContains(rt,index,key){return __cellGet(rt,index,key)!==undefined;}
function __tableGet(rt,index,key){const value=__cellGet(rt,index,key);return value===undefined?{None:null}:{Some:value};}
function __tablePut(rt,index,key,next,mode=0){
 const prior=rt.tables[index].get(key),present=prior!==undefined;
 if(mode===1&&present)throw Error('insert key already present');
 if(mode===2&&!present)throw Error('replace key absent');
 if(present&&__stateRootEquals[index](prior,next))return null;
 const updates=rt.cellMode?null:__updateViews(rt,index,key,prior,next);
 __invalidateKeeps(rt,index);__remember(rt,index,key,present,prior);
 __writeCell(rt,index,key,next,prior);__installViews(rt,updates,index);return null;
}
function __tableRemove(rt,index,key){
 const value=rt.tables[index].get(key);
 if(value===undefined)return {None:null};
 const updates=rt.cellMode?null:__updateViews(rt,index,key,value,undefined);
 __invalidateKeeps(rt,index);__remember(rt,index,key,true,value);
 __writeCell(rt,index,key,undefined,value);__installViews(rt,updates,index);return {Some:value};
}
function __table(rt,index,method,args){
 const key=args[0];
 if(method==='get')return __tableGet(rt,index,key);
 if(method==='contains')return __tableContains(rt,index,key);
 const table=rt.tables[index];
 if(method==='values'||method==='keys'){const keys=__orderedKeys(rt,index);return method==='keys'?keys.slice():keys.map(k=>__cellGet(rt,index,k));}
 if(method==='intersect_table'){const current=__readTable(rt,index),other=__readTable(rt,args[0]),small=current.size<=other.size?current:other,large=small===current?other:current;const result=[];for(const k of small.keys())if(large.has(k))result.push(k);return result.sort((a,b)=>__keyCompare(a,b,rt.meta.roots[index].key));}
 if(method==='intersect_keys'){const requested=args[0],size=rt.tables[index].size;
  // Fewer requested keys than rows: look each one up instead of scanning.
  if(requested.length<size){const type=rt.meta.roots[index].key;return [...new Set(requested)].filter(k=>__cellGet(rt,index,k)!==undefined).sort((a,b)=>__keyCompare(a,b,type));}
  const selected=new Set(requested);return __orderedKeys(rt,index).filter(k=>selected.has(k));}
 if(method==='put_many'){const keys=args[0],values=args[1];if(keys.length!==values.length)return {Err:'table bulk length mismatch'};for(let i=0;i<keys.length;i++)__table(rt,index,'put',[keys[i],values[i]]);return {Ok:null};}
 if(method==='remove_many'){for(const k of args[0])__table(rt,index,'remove',[k]);return null;}
 if(method==='remove')return __tableRemove(rt,index,key);
 return __tablePut(rt,index,key,args[1],method==='insert'?1:method==='replace'?2:0);
}

function __rollback(rt,mark){for(let i=rt.undo.length-1;i>=mark;i--){const [index,key,present,value]=rt.undo[i];const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);if(table.has(key)!==present)__tableMembership(rt,index,key,present);if(present)table.set(key,value);else table.delete(key);}rt.undo.length=mark;}
function __recordChange(rt,index,key,prior,next){rt.changeLog.push([index,key,prior,next]);}
function __fixedTableBytes(root,table){
 const writer=__snapshotWriter(__snapshotLimits());
 const rows=[...table.entries()].sort((a,b)=>__keyCompare(a[0],b[0],root.key));
 writer.integer(rows.length,8);
 for(const [key,value]of rows){writer.value(key,root.snapshotKey??root.key);writer.value(value,root.snapshotValue??root.value);}
 return writer.finish();
}
function __createState(meta,implementations,captures=null,views=[],prefixes=[]){
 const rt={meta,tables:__newTables(meta,prefixes),version:meta.compactCommits?0:0n,outbox:__eventLog(meta),staged:[],busy:false,undo:[],seen:meta.roots.map(()=>new Set()),host:null,keeps:new Array(meta.keeps.length),keepDirty:meta.keeps.length?new Uint8Array(meta.keeps.length):null,keepUndoIndices:meta.keeps.length?new Uint32Array(meta.keeps.length):null,keepUndoCount:0};
 const fixed=typeof __stateFrozenFactories==='undefined'?[]:__stateFrozenFactories;
 const fixedBytes=[];
 for(let i=0;i<fixed.length;i++)if(fixed[i]){for(const [key,value]of fixed[i]())rt.tables[i].set(key,value);fixedBytes[i]=__fixedTableBytes(meta.roots[i],rt.tables[i]);}
 function checkFixed(tables){for(let i=0;i<fixedBytes.length;i++)if(fixedBytes[i]){const bytes=__fixedTableBytes(meta.roots[i],tables[i]);if(bytes.length!==fixedBytes[i].length||!bytes.every((v,n)=>v===fixedBytes[i][n]))throw Error('snapshot changes frozen state: '+meta.roots[i].name);}}
 rt.views=views;rt.viewsByRoot=meta.roots.map((_,root)=>views.filter(v=>v.root===root));__rebuildViews(rt);
 rt.viewByKeep=new Array(meta.keeps.length);for(const view of views)rt.viewByKeep[view.keep]=view;
 rt.pendingIndices=[];rt.pendingValues=new Array(meta.keeps.length);
 rt.eventCount=0;rt.eventChannel=null;rt.eventValue=null;
 rt.viewNext=new Array(meta.keeps.length);rt.cell=null;rt.cellMode=false;rt.ctx={fuel:100000000};
 rt.keepBefore=meta.keeps.length?new Array(meta.keeps.length):null;
 rt.changedRoots=new Set();rt.changedOutputs=new Array(meta.keeps.length).fill(0);rt.changedOutputEpoch=0;
 rt.snapshotRows=meta.snapshotRows?meta.roots.map(()=>new Map()):null;
 rt.restoreSpares=null;rt.changeTracking=false;rt.changeLog=[];rt.changeEpoch=0;rt.changeTokens=new Map();
 const actionMap=new Map(meta.actions.map(a=>[a.name,{...a,inputs:captures?captures[a.index]:a.params.map(p=>__stateCapture(p.type)),output:__stateResult(a.result)}]));
 const eventOutput=new Map(meta.events.map(e=>[e.name,__stateResult(e.type)]));
 rt.eventOutput=eventOutput;
 const prepared=new WeakMap();
 const observers=rt.observers=__createObservers((name,args)=>{
  const a=actionMap.get(name);if(!a||a.change)throw Error('subscription requires a readonly query');
  const captured=a.inputs.map((convert,i)=>convert(args[i]));
  const publicArgs=captured.map((v,i)=>__stateResult(a.params[i].type)(v));
  const scalar=['u64','u32','i32','bool','string','unit','enum','id'].includes(a.result.kind);
  return {scalar,committed:scalar&&a.directKeep!==null&&a.directKeep!==undefined?{state:rt,keep:a.directKeep}:null,direct:scalar&&a.directKeep!==null&&a.directKeep!==undefined?()=>rt.keeps[a.directKeep]:null,roots:a.roots,outputs:rt.meta.outputPublication&&a.directKeep!==null&&a.directKeep!==undefined?[a.directKeep]:[],read:!a.precondition&&a.params.length===0?readZero(a,true):()=>run(a,publicArgs,null,null,true),capture:scalar?v=>v:__stateCapture(a.result),output:scalar?v=>v:a.output,equal:__stateQueryEquals[a.index]};
 });
 function invoke(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);return run(a,args);}
 function readZero(a,resultOnly){
  const implementation=implementations[a.index],output=a.output,fresh=a.freshResult;
  if(resultOnly&&fresh&&__stateDirectReadFactories[a.index])return __stateDirectReadFactories[a.index](rt);
  if(a.directKeep!==null&&a.directKeep!==undefined)return ()=>{
   if(rt.busy)throw Error('state operation already in progress');
   const value=rt.keeps[a.directKeep],result=fresh?value:output(value);
   return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};
  };
  return ()=>{
   if(rt.busy)throw Error('state operation already in progress');rt.busy=true;rt.ctx.fuel=100000000;
   try{const value=implementation(rt.ctx,rt),result=fresh?value:output(value);return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};}
   finally{rt.busy=false;}
  };
 }
 function read(a,args,inputs,output,resultOnly,owned=false){
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  rt.busy=true;
  try{const value=implementations[a.index](ctx,rt,...captured),result=a.freshResult?value:(output||a.output)(value);return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};}
  finally{rt.busy=false;}
 }
 function begin(a){
  if(rt.busy)throw Error('state operation already in progress');
  rt.ctx.fuel=100000000;
  rt.actionMark=rt.undo.length;rt.actionVersion=rt.version;rt.actionOutbox=rt.outbox;rt.actionOutboxLength=rt.outbox.length;rt.actionChangeMark=rt.changeLog.length;
  rt.busy=true;rt.cellMode=a.singleCell&&!rt.host;rt.staged.length=0;rt.eventCount=0;rt.changedRoots.clear();rt.actionSuccessful=false;
 }
 function complete(a,value,output,resultOnly){
  const result=a.freshResult?value:(output||a.output)(value);
  const version=rt.actionVersion;
  if(a.fallible && (a.flatFailure?value.tag!==0:Object.hasOwn(value,'Err'))){rt.changeLog.length=rt.actionChangeMark;__rollback(rt,rt.actionMark);__restoreKeeps(rt);if(rt.host?.strict)rt.host.failure=Object.assign(Error('transaction action failed'),{action:a.name,result});return resultOnly?result:{result,committed:false,version:__versionWord(version),events:[]};}
  if(version===18446744073709551615n)throw Error('commit sequence exhausted');
  const next=rt.meta.compactCommits?__nextCommit(version):version+1n;
  const publicNext=resultOnly?null:__versionWord(next);
  __prepareCell(rt);
  const events=resultOnly?null:new Array(rt.eventCount);
  if(rt.eventCount){
   const channel=rt.eventChannel,value=rt.eventValue;
   rt.outbox.push({commit:next,position:0n,channel,value});
   if(events)events[0]={commit:publicNext,position:0n,channel,value:eventOutput.get(channel)(value)};
   for(let i=0;i<rt.staged.length;i++){
    const [channel,value]=rt.staged[i],position=BigInt(i+1);
    rt.outbox.push({commit:next,position,channel,value});
    if(events)events[i+1]={commit:publicNext,position,channel,value:eventOutput.get(channel)(value)};
   }
  }
  __commitCell(rt);rt.version=next;rt.actionSuccessful=true;
  return resultOnly?result:{result,committed:true,version:publicNext,events};
 }
 function abort(e){
  rt.changeLog.length=rt.actionChangeMark;__rollback(rt,rt.actionMark);__restoreKeeps(rt);rt.version=rt.actionVersion;rt.outbox=rt.actionOutbox;rt.outbox.length=rt.actionOutboxLength;if(rt.host?.strict)rt.host.failure=e;throw e;
 }
 function end(){
  const successful=rt.actionSuccessful,single=rt.cellMode;
  rt.cell=null;rt.cellMode=false;rt.staged.length=0;rt.eventCount=0;rt.eventChannel=null;rt.eventValue=null;
  for(const keep of rt.pendingIndices)rt.pendingValues[keep]=undefined;rt.pendingIndices.length=0;
  if(!single){__clearKeepJournal(rt);for(const seen of rt.seen)seen.clear();if(!rt.host)rt.undo.length=0;}
  rt.actionOutbox=null;rt.busy=false;
  if(successful)observers.commit(rt.changedRoots);
 }
 function run(a,args,inputs=null,output=null,resultOnly=false,owned=false){
  if(a.kernels&&!rt.host){
   if(rt.busy)throw Error('state operation already in progress');
   const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
   return a.kernels[resultOnly?1:0](...captured);
  }
  if(!a.change)return read(a,args,inputs,output,resultOnly,owned);
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  begin(a);
  try{return complete(a,implementations[a.index](ctx,rt,...captured),output,resultOnly);}
  catch(e){return abort(e);}
  finally{end();}
 }

 for(const a of actionMap.values())if(__statePreflightFactories[a.index]){
  // run() supplies module-owned captured values; bound native entries still capture composites.
  a.kernels=[false,true].map(only=>__statePreflightFactories[a.index](run,a,a.inputs,a.output,only,rt,begin,complete,abort,end,true));
 }
 return Object.freeze({
  subscribeValues(queries,callback,options){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribeValues(queries,callback,options);},
  subscribeGroup(queries,callback,options){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribeGroup(queries,callback,options);},
  subscribe(...args){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribe(...args);},
  batch:observers.batch,flushSubscriptions:observers.flush,takeSubscriptionErrors:observers.takeErrors,
  transaction(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('transaction callback must be synchronous');this.beginTransaction();rt.host.strict=true;
   try{const value=callback(this);if(value&&typeof value.then==='function')throw TypeError('state transaction callback must be synchronous');this.commitTransaction();return value;}catch(e){this.rollbackTransaction();throw e;}
  },
  invoke,invoke_json:invoke,
  prepare(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);const captured=a.inputs.map((convert,i)=>convert(args[i])),token=Object.freeze({});prepared.set(token,{action:a,args:captured});return token;},
  invokePrepared(token){const packet=prepared.get(token);if(!packet)throw Error('invalid prepared state call');return run(packet.action,packet.args,null,null,false,true);},
  // A prebound typed entrypoint: scalar arguments obey the native caller contract.
  // Composite arguments still capture owned input; events remain in the outbox.
  bind(name,{resultOnly=false}={}){
   const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);
   const inputs=a.params.map((p,i)=>p.type.kind==='f32'?(value=>typeof value==='number'?__bits(value):value.F32Bits):['u32','i32','u64','bool','unit','string','f64','id','enum','int'].includes(p.type.kind)?__representation(p.type,false):a.inputs[i]);
   if(!a.change&&!a.precondition&&inputs.length===0)return readZero(a,resultOnly);
   return (__statePreflightFactories[a.index]||__stateBoundFactories[a.index])(run,a,inputs,a.output,resultOnly,rt,begin,complete,abort,end);
  },
  beginTransaction(){if(rt.busy||rt.host||rt.undo.length)throw Error('transaction already in progress');rt.host={version:rt.version,outbox:rt.outbox,length:rt.outbox.length,keeps:rt.keeps.slice(),changeMark:rt.changeLog.length,notificationMark:observers.hold()};return true;},
  commitTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');if(rt.host.failure)throw rt.host.failure;rt.host=null;rt.undo.length=0;observers.release();},
  rollbackTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');__rollback(rt,0);rt.version=rt.host.version;rt.outbox=rt.host.outbox;rt.outbox.length=rt.host.length;rt.keeps=rt.host.keeps;__refreshActiveViews(rt);rt.changeLog.length=rt.host.changeMark;rt.changeEpoch++;const mark=rt.host.notificationMark;rt.host=null;observers.rollback(mark);},
  changeToken(){
   if(rt.busy||rt.host)throw Error('change token requires transaction boundary');
   const token=Object.freeze({});rt.changeTracking=true;rt.changeTokens.set(token,{epoch:rt.changeEpoch,index:rt.changeLog.length,version:__versionWord(rt.version)});return token;
  },
  releaseChangeToken(token){rt.changeTokens.delete(token);if(!rt.changeTokens.size){rt.changeTracking=false;rt.changeLog.length=0;}},
  changesSince(token){
   if(rt.busy||rt.host)throw Error('changes require transaction boundary');
   const mark=rt.changeTokens.get(token);if(!mark||mark.epoch!==rt.changeEpoch)throw Error('invalid change token lineage');
   const roots=new Map();
   for(let i=mark.index;i<rt.changeLog.length;i++){
    const [root,key,before,after]=rt.changeLog[i];let cells=roots.get(root);if(!cells)roots.set(root,cells=new Map());
    const prior=cells.get(key);if(prior)prior.after=after;else cells.set(key,{before,after});
   }
   const changes=[];
   const codecs=rt.changeOutputs??=meta.roots.map(schema=>({key:__stateResult(schema.key),row:__stateResult(schema.value)}));
   for(const [root,cells]of roots){const schema=meta.roots[root],keyOut=codecs[root].key,rowOut=codecs[root].row;
    for(const [key,{before,after}]of cells){if(before===undefined&&after===undefined||before!==undefined&&after!==undefined&&__stateRootEquals[root](before,after))continue;
     changes.push({table:schema.name,key:keyOut(key),before:before===undefined?{None:null}:{Some:rowOut(before)},after:after===undefined?{None:null}:{Some:rowOut(after)}});
    }
   }
   return {from:mark.version,to:__versionWord(rt.version),changes};
  },
  get version(){return __versionWord(rt.version);},
  get outbox(){return rt.outbox.map(e=>({...e,commit:__versionWord(e.commit),value:eventOutput.get(e.channel)(e.value)}));},
  acknowledgeThrough(commit,position){if(rt.busy)throw Error('state operation already in progress');commit=__stateWord(commit);position=__stateWord(position);const last=rt.outbox.at(-1);if(!last)return;const lastCommit=__versionWord(last.commit);if(lastCommit<commit||(lastCommit===commit&&last.position<=position)){if(rt.host)rt.outbox=__eventLog(meta);else rt.outbox.length=0;return;}rt.outbox=rt.outbox.filter(e=>{const c=__versionWord(e.commit);return c>commit||(c===commit&&e.position>position);});},
  async invokeAsync(name,args){
   if(typeof __parallelInvokeAsync!=='function')return invoke(name,args);
   if(rt.busy||rt.host)throw Error('parallel state call requires transaction boundary');const captured=structuredClone(args);rt.busy=true;observers.hold();let completed=false;
   try{const snapshot=await __snapshotEncode(meta,rt);const reply=await __parallelInvokeAsync(name,captured,snapshot);const s=await __snapshotDecode(meta,reply.snapshot);checkFixed(s.tables);const candidate={...rt,tables:__restoreTables(rt,prefixes,s.tables),keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);const previousTables=rt.tables;rt.tables=candidate.tables;rt.restoreSpares=previousTables.map(table=>table instanceof __DenseTable?table:null);rt.version=__storedCommit(meta,s.version);rt.outbox=__eventLog(meta,s.outbox);rt.keeps=candidate.keeps;rt.activeViewRoots=candidate.activeViewRoots;if(rt.snapshotRows)rt.snapshotRows=meta.roots.map(()=>new Map());rt.changeEpoch++;rt.changeLog.length=0;completed=true;return reply.value;}finally{rt.busy=false;if(completed)observers.commit(meta.roots.map((_,i)=>i));observers.release();}
  },
  checkpoint(limits){if(rt.busy)throw Error('checkpoint requires transaction boundary');return __snapshotEncode(meta,rt,limits);},
  async restore(bytes,limits){if(rt.host)throw Error('restore during transaction');if(rt.busy)throw Error('restore requires transaction boundary');rt.busy=true;rt.ctx.fuel=100000000;observers.hold();let restored=false;try{const s=await __snapshotDecode(meta,bytes,limits);checkFixed(s.tables);const candidate={...rt,tables:__restoreTables(rt,prefixes,s.tables),version:__storedCommit(meta,s.version),outbox:s.outbox,keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);for(const name of meta.invariantChecks||[]){const a=actionMap.get(name);if(implementations[a.index](rt.ctx,candidate)!==true)throw Error('snapshot violates state invariant');}const previousTables=rt.tables;rt.tables=candidate.tables;rt.restoreSpares=previousTables.map(table=>table instanceof __DenseTable?table:null);rt.version=__storedCommit(meta,s.version);rt.outbox=__eventLog(meta,s.outbox);rt.keeps=candidate.keeps;rt.activeViewRoots=candidate.activeViewRoots;if(rt.snapshotRows)rt.snapshotRows=meta.roots.map(()=>new Map());rt.changeEpoch++;rt.changeLog.length=0;restored=true;}finally{rt.busy=false;if(restored)observers.commit(meta.roots.map((_,i)=>i));observers.release();}},
 });
}
function __stateCommitRoot0(rt,key,prior,next,slot){__storeDirect(rt,0,key,prior,next,slot);const publish=rt.meta.outputPublication&&!rt.observers.directRoots[0]&&rt.observers.active;if(publish&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}}
const __stateDirectReadFactories=[];
const __stateFrozenFactories=[];
const __stateQueryEquals=[];
const __stateRootEquals=[(a,b)=>(a===b)];
const __stateBoundFactories=[];const __statePreflightFactories=[];
const __stateMetadata={"actions":[],"compactCommits":false,"eventColumns":false,"eventRuns":false,"events":[],"invariantChecks":[],"keepInvalidations":[[]],"keeps":[],"lazyMaintenance":true,"outputPublication":false,"roots":[{"key":{"kind":"u32"},"name":"Counter","snapshotKey":{"kind":"u32"},"snapshotValue":{"kind":"u32"},"value":{"kind":"u32"}}],"snapshot":{"program":[112,25,243,199,163,253,55,23,254,135,63,198,62,117,136,44,20,40,33,217,155,159,90,26,151,165,212,120,122,166,12,169],"schema":[78,116,32,200,30,17,164,209,84,242,145,99,104,60,11,144,181,111,135,33,24,37,47,123,243,81,245,13,38,7,160,171]},"snapshotRows":false};const __actions=[];const __stateInputCaptures=[];
export function createState(){return __createState(__stateMetadata,__actions,__stateInputCaptures);}
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"14c82a7b7cfb30a8f6921e856a1b5e2d94f42ed6d859d1d6a69920e1c926997f","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"f32_computation":"exact-u32-bits","f32_storage":"exact-u32-bits","functions":[{"destination":null,"index":0,"internal":false,"name":"component","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":1,"internal":false,"name":"energy","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":2,"internal":false,"name":"derivatives","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"destination":null,"index":3,"internal":false,"name":"direction","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":4,"internal":false,"name":"twice","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":5,"internal":false,"name":"selected","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"c","type":{"kind":"bool"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"destination":null,"index":6,"internal":false,"name":"branches","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}},{"name":"c","type":{"kind":"bool"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"destination":null,"index":7,"internal":false,"name":"looping","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"destination":null,"index":8,"internal":false,"name":"strict_unused","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":9,"internal":false,"name":"strict","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":10,"internal":false,"name":"history","parallel":false,"params":[{"name":"x","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}},{"destination":null,"index":11,"internal":true,"name":"owner","parallel":false,"params":[{"name":"value","type":{"kind":"temporary"}}],"precondition":null,"result":{"kind":"temporary"}},{"destination":null,"index":12,"internal":false,"name":"__ink_differential_3","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"}},{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"destination":null,"index":13,"internal":false,"name":"__ink_differential_1","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"destination":null,"index":14,"internal":false,"name":"__ink_differential_23","parallel":false,"params":[{"name":"__ink_differential_24","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_25","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":15,"internal":false,"name":"__ink_differential_27","parallel":false,"params":[{"name":"__ink_differential_28","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_29","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":16,"internal":false,"name":"__ink_differential_31","parallel":false,"params":[{"name":"__ink_differential_32","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_33","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":17,"internal":false,"name":"__ink_differential_20","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"}},{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":18,"internal":false,"name":"__ink_differential_19","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"__ink_differential_35","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}}],"named_types":{"Bundle":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},"Node":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"},"Pair":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"},"__ink_differential_0":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"__ink_differential_2":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"},"__ink_differential_21":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"},"__ink_differential_22":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"},"__ink_differential_4":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"},"__ink_differential_5":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},"prepared_compiled":{"destination":{"call":"callPreparedCompiledInto","capacity":"trusted","failure":"destination may be partially written","float_values":"trusted public representation","inputs":"sealed compiled values","ownership":"caller-owned","structured_elements":"detached","tail":"unwritten"},"evaluation":"lazy source-order; successful bindings only","functions":[{"factory":false,"function":"component","reason":"no reusable captured work"},{"factory":false,"function":"energy","reason":"no reusable captured work"},{"delegated_calls":1,"factory":true,"function":"derivatives","retained_bindings":0},{"factory":false,"function":"direction","reason":"no reusable captured work"},{"factory":false,"function":"twice","reason":"no reusable captured work"},{"factory":false,"function":"selected","reason":"no reusable captured work"},{"factory":false,"function":"branches","reason":"no reusable captured work"},{"factory":false,"function":"looping","reason":"no reusable captured work"},{"factory":false,"function":"strict_unused","reason":"no reusable captured work"},{"factory":false,"function":"strict","reason":"no reusable captured work"},{"factory":false,"function":"history","reason":"no reusable captured work"},{"factory":false,"function":"owner","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_differential_3","reason":"prepared residual binding budget"},{"delegated_calls":1,"factory":true,"function":"__ink_differential_1","retained_bindings":1},{"factory":false,"function":"__ink_differential_23","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_27","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_31","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_20","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_19","reason":"no reusable captured work"}],"lifetime":"prepared token","semantics":"sealed-value-residual-v1"},"private_record_elisions":[],"private_sum_spines":[],"schema":1,"state":{"actions":[],"compactCommits":false,"eventColumns":false,"eventRuns":false,"events":[],"invariantChecks":[],"keepInvalidations":[[]],"keeps":[],"lazyMaintenance":true,"outputPublication":false,"roots":[{"key":{"kind":"u32"},"name":"Counter","snapshotKey":{"kind":"u32"},"snapshotValue":{"kind":"u32"},"value":{"kind":"u32"}}],"snapshot":{"program":[112,25,243,199,163,253,55,23,254,135,63,198,62,117,136,44,20,40,33,217,155,159,90,26,151,165,212,120,122,166,12,169],"schema":[78,116,32,200,30,17,164,209,84,242,145,99,104,60,11,144,181,111,135,33,24,37,47,123,243,81,245,13,38,7,160,171]},"snapshotRows":false},"wire":{"format":"ink-value-wire-v1","functions":{"__ink_differential_1":{"arguments":{"format":"ink-value-wire-v1","identity":"0682599d89e5a0da92fd3bb3a63bdbef728533bcace07efac64cbc6207072abd","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"7882b66162c075a7679604fdc86c31922fb250d10394af5aa2d1354c654b72e5","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}}},"__ink_differential_19":{"arguments":{"format":"ink-value-wire-v1","identity":"4b9a4eccc6d2615eb92680d1626d236c77340ef306b699fe9722c753783a60da","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"__ink_differential_35","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"__ink_differential_20":{"arguments":{"format":"ink-value-wire-v1","identity":"009ea546acc19d5b810484974d68d3c4457e94cf4bde388fdf2151c2e57e2a8b","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"}},{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_23":{"arguments":{"format":"ink-value-wire-v1","identity":"14dad48e9c7540e15bc5834542aecb46075a5f6db75bdf730ed1ae3cea29fd65","named":{},"root":{"fields":[{"name":"__ink_differential_24","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_25","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_27":{"arguments":{"format":"ink-value-wire-v1","identity":"3ff642723860241049980d889d5b40bc6385dbe1d5565864a6f0cff2789d7d65","named":{},"root":{"fields":[{"name":"__ink_differential_28","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_29","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_3":{"arguments":{"format":"ink-value-wire-v1","identity":"1d368d11ae3fd3df968cc51472c46914649ff205acd33e8d0894f38dfbe17c52","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"}},{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"bb2b2f3efce5ad7f78fd263ef8cf59e1adcabaeb4e987b0d193c2a16c631b760","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}},"__ink_differential_31":{"arguments":{"format":"ink-value-wire-v1","identity":"b89078033f0e43e3b942a030299778636af73ee6bf52de60b442828bffa87a4a","named":{},"root":{"fields":[{"name":"__ink_differential_32","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_33","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"branches":{"arguments":{"format":"ink-value-wire-v1","identity":"7e470bcf24f723adb7da774fec6821c355982fbef8ce2c31b5fee833dcc69a2c","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"c","type":{"kind":"bool"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"5728eeaa0e138ea2f93b2c91d176edec672a97fdd0e45fa08b4dacd31d4beebf","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}},"component":{"arguments":{"format":"ink-value-wire-v1","identity":"9e9f426322cda6dcb4444ebcf8caf3792884cce27574c91c49d8c179e163ada6","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"derivatives":{"arguments":{"format":"ink-value-wire-v1","identity":"0682599d89e5a0da92fd3bb3a63bdbef728533bcace07efac64cbc6207072abd","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"7882b66162c075a7679604fdc86c31922fb250d10394af5aa2d1354c654b72e5","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}}},"direction":{"arguments":{"format":"ink-value-wire-v1","identity":"0682599d89e5a0da92fd3bb3a63bdbef728533bcace07efac64cbc6207072abd","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"energy":{"arguments":{"format":"ink-value-wire-v1","identity":"0682599d89e5a0da92fd3bb3a63bdbef728533bcace07efac64cbc6207072abd","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"history":{"arguments":{"format":"ink-value-wire-v1","identity":"cc08f1332c0bbd676577f3e81f06e85cc8ef81a32bcbe10b3177d811cc8e0ae2","named":{},"root":{"fields":[{"name":"x","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"06a5b110d3c213512730b89ea5797ec6a338f55b0c357c4c3894a84ac3cfa9e3","named":{"Node":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}},"root":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}}},"looping":{"arguments":{"format":"ink-value-wire-v1","identity":"3d9fa005996e654b10e4e749ab0e2c4a9988b4ba944f21f1019c2132cbcb62b2","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"5728eeaa0e138ea2f93b2c91d176edec672a97fdd0e45fa08b4dacd31d4beebf","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}},"owner":{"unsupported":"unsupported wire descriptor"},"selected":{"arguments":{"format":"ink-value-wire-v1","identity":"a8946948d6a1d8ee77f631669030cc4c45446359c5b73e5817d71710ec234e83","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"c","type":{"kind":"bool"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"5728eeaa0e138ea2f93b2c91d176edec672a97fdd0e45fa08b4dacd31d4beebf","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}},"strict":{"arguments":{"format":"ink-value-wire-v1","identity":"3a34365b0c77659a92326203e995cfb8b5864a51d9641ba81afbf209004e3844","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"strict_unused":{"arguments":{"format":"ink-value-wire-v1","identity":"84d59578f8c7aa53acd5daacd88e348b3c426255a392adda48076dcabfcaf9f1","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"twice":{"arguments":{"format":"ink-value-wire-v1","identity":"84d59578f8c7aa53acd5daacd88e348b3c426255a392adda48076dcabfcaf9f1","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}}}}};
const __implementations=[__fn0,__fn1,__fn2,__fn3,__fn4,__fn5,__fn6,__fn7,__fn8,__fn9,__fn10,__fn11,__fn12,__fn13,__fn14,__fn15,__fn16,__fn17,__fn18];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
const __inputTypes=[{"capture":[false,true],"types":[{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"},{"kind":"f32"}]},{"capture":[false,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f32"}]},{"capture":[false,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f32"}]},{"capture":[false,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f32"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}]},{"capture":[false,true],"types":[{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"},{"kind":"bool"}]},{"capture":[true,true],"types":[{"kind":"f32"},{"kind":"bool"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}]},{"capture":[true,true],"types":[{"kind":"f32"},{"kind":"f32"}]},{"capture":[true],"types":[{"kind":"u32"}]},{"capture":[true],"types":[{"kind":"temporary"}]},{"capture":[false,false],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}]},{"capture":[false,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f32"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[false,false],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[false,false,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f32"}]}];
export const functions=Object.freeze({...Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=> {
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const output=__representation(f.result,true);
  const body=__implementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
  const needsInput=input.some(c=>c!==__identity);
  const entry=!needsInput && output===__identity ? implementation :
    (...args)=>{const context=new WeakMap();return output(implementation(...(needsInput ? args.map((v,i)=>input[i](v,context)) : args)),context);};
  return [f.name,entry];
}))),...Object.freeze(Object.fromEntries([["component",(()=>{const c0=__representation(__inputTypes[0].types[0],false,__inputTypes[0].capture[0]);const c1=__representation(__inputTypes[0].types[1],false,__inputTypes[0].capture[1]);const output=__representation(metadata.functions[0].result,true);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity&&output===__identity)return __fn0;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn0(...values),context);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return output(__fn0(v0,v1),context);};})()],
["energy",(()=>{const c0=__representation(__inputTypes[1].types[0],false,__inputTypes[1].capture[0]);const c1=__representation(__inputTypes[1].types[1],false,__inputTypes[1].capture[1]);const output=__representation(metadata.functions[1].result,true);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity&&output===__identity)return __fn1;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn1(...values),context);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return output(__fn1(v0,v1),context);};})()],
["direction",(()=>{const c0=__representation(__inputTypes[3].types[0],false,__inputTypes[3].capture[0]);const c1=__representation(__inputTypes[3].types[1],false,__inputTypes[3].capture[1]);const output=__representation(metadata.functions[3].result,true);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity&&output===__identity)return __fn3;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn3(...values),context);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return output(__fn3(v0,v1),context);};})()],
["twice",(()=>{const c0=__representation(__inputTypes[4].types[0],false,__inputTypes[4].capture[0]);const output=__representation(metadata.functions[4].result,true);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&output===__identity)return __fn4;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn4(...values),context);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return output(__fn4(v0),context);};})()],
["strict_unused",(()=>{const c0=__representation(__inputTypes[8].types[0],false,__inputTypes[8].capture[0]);const output=__representation(metadata.functions[8].result,true);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&output===__identity)return __fn8;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn8(...values),context);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return output(__fn8(v0),context);};})()],
["strict",(()=>{const c0=__representation(__inputTypes[9].types[0],false,__inputTypes[9].capture[0]);const c1=__representation(__inputTypes[9].types[1],false,__inputTypes[9].capture[1]);const output=__representation(metadata.functions[9].result,true);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=false;if(c0===__identity&&c1===__identity&&output===__identity)return __fn9;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn9(...values),context);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return output(__fn9(v0,v1),context);};})()],
["__ink_differential_19",(()=>{const c0=__representation(__inputTypes[18].types[0],false,__inputTypes[18].capture[0]);const c1=__representation(__inputTypes[18].types[1],false,__inputTypes[18].capture[1]);const c2=__representation(__inputTypes[18].types[2],false,__inputTypes[18].capture[2]);const output=__representation(metadata.functions[18].result,true);const input=[c0,c1,c2],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity&&c2===__identity&&output===__identity)return __fn18;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn18(...values),context);};return function(a0,a1,a2){if(arguments.length!==3)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object')+Number(c2!==__identity&&a2!==null&&typeof a2==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);const v2=c2(a2,context);return output(__fn18(v0,v1,v2),context);};})()]]))});
export function call(name,args) {switch(name){case "owner":throw new Error('temporary storage is internal to a pure invocation');}return functions[name](...args);}
// Shared bounded binary codec; generated code supplies exact descriptors.
export const valueWireFormat='ink-value-wire-v1';
// A connection agrees on the complete value schema before using this format.
// Version byte + schema-directed fields; schema identity is out of band.
export const compactValueWireFormat='ink-value-session-v1';
const wireMagic=Uint8Array.of(73,78,75,86,65,76,0,1);
const wireEncoder=new TextEncoder(),wireDecoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const wireDefaults=Object.freeze({bytes:16777216,nodes:1000000,depth:128}),wireDefaultOptions=Object.freeze({});
const wireDecimal=s=>typeof s==='string'&&/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(s);
function wireLimits(options){if(options===wireDefaultOptions||options===wireDefaults)return wireDefaults;const l={...wireDefaults,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>wireDefaults[k])throw Error('wire hard resource limit');return l;}
const wireFloat=new DataView(new ArrayBuffer(4));
function wireDecodeText(bytes,start,end){
 if(end-start<=16){let text='';for(let i=start;i<end;i++){const byte=bytes[i];if(byte>=128)return wireDecoder.decode(bytes.subarray(start,end));text+=String.fromCharCode(byte);}return text;}
 return wireDecoder.decode(bytes.subarray(start,end));
}
function wireUtf8Length(text){let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const wireOwn=(v,k)=>v!==null&&typeof v==='object'&&Object.hasOwn(v,k);
const wireTagged=(v,k)=>wireOwn(v,k)&&Object.keys(v).length===1;
const wireDouble=new DataView(new ArrayBuffer(8));
function wireF64Bits(v){
 if(typeof v==='number'&&Number.isFinite(v)){wireDouble.setFloat64(0,v,true);return wireDouble.getBigUint64(0,true);}
 if(!wireTagged(v,'F64Bits'))wireInvalidValue();const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))wireInvalidValue();
 const bits=BigInt(text);if(bits>18446744073709551615n)wireInvalidValue();return bits;
}
const wireCanonical=v=>Array.isArray(v)?'['+v.map(wireCanonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort((a,b)=>{const x=Array.from(a,c=>c.codePointAt(0)),y=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]-y[i];return x.length-y.length;}).map(k=>JSON.stringify(k)+':'+wireCanonical(v[k])).join(',')+'}':JSON.stringify(v);
export async function createValueCodec(root,named={}){
 const used=new Set(),budget={nodes:100000};
 function check(t,d=0){
  if(d>64||--budget.nodes<0)throw Error('wire descriptor limit');
  const keys={u32:['kind'],u64:['kind'],i32:['kind'],f32:['kind'],f64:['kind'],bool:['kind'],unit:['kind'],string:['kind'],int:['kind'],id:['kind','name'],ref:['kind','name'],enum:['kind','name','variants'],record:['kind','name','fields'],list:['kind','element'],option:['kind','element'],vector:['kind','element','size'],result:['kind','ok','error']}[t?.kind];
  if(!keys||Object.keys(t).length!==keys.length||keys.some(k=>!Object.hasOwn(t,k)))throw Error('invalid wire descriptor');
  if(keys.includes('name')&&(typeof t.name!=='string'||!t.name.isWellFormed()))throw Error('invalid descriptor name');
  if(t.kind==='ref'){if(!used.has(t.name)){used.add(t.name);if(named[t.name]?.kind!=='record'||named[t.name].name!==t.name)throw Error('unresolved wire reference');check(named[t.name],d+1);}}
  if(t.kind==='record'){if(!Array.isArray(t.fields))throw Error('wire fields');const names=new Set();for(const f of t.fields){if(Object.keys(f).length!==2||typeof f.name!=='string'||!f.name.isWellFormed()||names.has(f.name))throw Error('duplicate wire field');names.add(f.name);check(f.type,d+1);}}
  if(t.kind==='enum'&&(!Array.isArray(t.variants)||!t.variants.length||t.variants.length>64||t.variants.some(v=>typeof v!=='string'||!v.isWellFormed())||new Set(t.variants).size!==t.variants.length))throw Error('wire enum');
  if(['list','vector','option'].includes(t.kind)){if(t.kind==='vector'&&(!Number.isInteger(t.size)||t.size<1||t.size>64))throw Error('wire vector');check(t.element,d+1);}
  if(t.kind==='result'){check(t.ok,d+1);check(t.error,d+1);}
 }
 check(root);const names=Object.fromEntries([...used].sort().map(k=>[k,named[k]]));
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',wireEncoder.encode(wireCanonical({format:valueWireFormat,root,named:names}))));
 return new ValueCodec({format:valueWireFormat,root,named:names,identity:Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('')});
}
// Resolve immutable descriptor edges once. Logical validation traverses the
// literal schema; single-child nodes use a loop rather than recursive closures.
function wireValuePlan(codec){
 const seen=new WeakMap();let remaining=100000;
 const build=type=>{
  const t=codec.resolve(type);if(seen.has(t))return seen.get(t);
  if(--remaining<0)throw Error('wire descriptor limit');const p={kind:t.kind,type:t,decode:null,decodeCompact:null};seen.set(t,p);
  if(t.kind==='record')p.fields=t.fields.map(f=>({name:f.name,plan:build(f.type)}));
  if(t.kind==='list'||t.kind==='vector'||t.kind==='option')p.element=build(t.element);
  if(t.kind==='result'){p.ok=build(t.ok);p.error=build(t.error);}
  return p;
 };return build(codec.descriptor.root);
}
function wireBindDecodePlan(root,compact=false){
 const seen=new Set(),pending=[root];let flags=0;
 while(pending.length){
  const p=pending.pop();if(seen.has(p))continue;seen.add(p);if(compact)p.decodeCompact=compactDecodeOperation(p);else p.decode=wireDecodeOperation(p);
  if(p.fields?.length>4)flags|=1;
  if(p.kind==='u32'||p.kind==='i32'||p.kind==='u64'||p.kind==='f32'||p.kind==='f64')flags|=2;
  if(p.fields)for(const f of p.fields)pending.push(f.plan);
  if(p.element)pending.push(p.element);
  if(p.ok){pending.push(p.ok);pending.push(p.error);}
 }
 return flags|4;
}
// Select literal descriptor operations once, without runtime source generation
// or eval. Recursive edges call the completed plan. The generic scanner remains
// the visitor/validation path and an independent materialisation implementation.
function wireReadOperation(p){
 const t=p.type;
 let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':read=(r,end)=>{r.size(end,4);const value={F32Bits:r.view.getUint32(r.cursor,true)};r.cursor=end;return value;};break;
  case 'f64':read=(r,end)=>{r.size(end,8);const value={F64Bits:r.view.getBigUint64(r.cursor,true).toString()};r.cursor=end;return value;};break;
  case 'u64':read=(r,end)=>{r.size(end,8);const value=r.view.getBigUint64(r.cursor,true);r.cursor=end;return value;};break;
  case 'string':read=(r,end)=>r.text(end);break;
  case 'int':read=(r,end)=>{const text=r.text(end);if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=(r,end)=>{const text=r.text(end);if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=(r,end)=>{const text=r.text(end);if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{
    if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;
    if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');
    const values=new Array(n);for(let i=0;i<n;i++)values[i]=element.decode(r,end,d+1);return values;
   };break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1)});break;
    case 2:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1)});break;
    case 3:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1)});break;
    case 4:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1),[fs[3].name]:fs[3].plan.decode(r,end,d+1)});break;
    default:read=(r,end,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decode(r,end,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,end,d)=>{const tag=r.tag(end);return tag?{Some:p.element.decode(r,end,d+1)}:{None:null};};break;
  case 'result':read=(r,end,d)=>r.tag(end)?{Err:p.error.decode(r,end,d+1)}:{Ok:p.ok.decode(r,end,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function wireDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=wireReadOperation(field.plan),name=field.name;
  return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),childEnd=r.enter(end,d+1),item=read(r,childEnd,d+1);if(r.cursor!==childEnd)throw Error('trailing wire frame bytes');const value={[name]:item};if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
 }
 const read=wireReadOperation(p);
 return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
}
class WireDecodeCursor{
 constructor(bytes,view,limits){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
// Bind literal validation and postorder visitation once for every descriptor.
// No logical carriers are allocated; projection still validates every child.
function wireScanPlan(root){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,scan:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.scan=wireScanOperation(p);return p;
 };
 return build(root);
}
function wireScanOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':case 'f64':case 'u64':{const size=p.kind==='f32'?4:8;read=(r,end)=>{r.size(end,size);r.cursor=end;};break;}
  case 'string':read=(r,end)=>{let i=r.cursor;while(i<end&&r.bytes[i]<128)i++;if(i<end)wireDecoder.decode(r.bytes.subarray(r.cursor,end));r.cursor=end;};break;
  case 'int':case 'id':case 'enum':read=(r,end)=>{const text=r.text(end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');for(let i=0;i<n;i++)element.scan(r,end,d+1);};break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>{};break;
    case 1:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);};break;
    case 2:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);};break;
    case 3:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);};break;
    case 4:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);fs[3].plan.scan(r,end,d+1);};break;
    default:read=(r,end,d)=>{for(const f of fs)f.plan.scan(r,end,d+1);};
   }break;
  }
  case 'option':read=(r,end,d)=>{if(r.tag(end))p.element.scan(r,end,d+1);};break;
  case 'result':read=(r,end,d)=>{(r.tag(end)?p.error:p.ok).scan(r,end,d+1);};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return (r,parentEnd,d)=>{
  const end=r.enter(parentEnd,d),start=r.cursor,value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');
  const visitor=r.visitor;if(visitor&&(!r.selected||r.selected.has(t.name))){if(r.spans)visitor(t,r.bytes,start,end,d);else visitor(t,r.bytes.subarray(start,end),d);}
  return value;
 };
}
// Separate methods keep decoding's cursor callsites monomorphic. Both cursors
// are checked against the independent generic scanner and malformed fixtures.
class WireScanCursor{
 constructor(bytes,view,limits,visitor,selected,spans){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.visitor=visitor;this.selected=selected;this.spans=spans;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
function compactReadOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=()=>null;break;
  case 'bool':read=r=>{r.require(1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':case 'i32':read=r=>{r.require(4);const n=p.kind==='u32'?r.view.getUint32(r.cursor,true):r.view.getInt32(r.cursor,true);r.cursor+=4;return n;};break;
  case 'f32':read=r=>{r.require(4);const n=r.view.getUint32(r.cursor,true);r.cursor+=4;return {F32Bits:n};};break;
  case 'f64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return {F64Bits:n.toString()};};break;
  case 'u64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return n;};break;
  case 'string':read=r=>r.text();break;
  case 'int':read=r=>{const text=r.text();if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=r=>{const text=r.text();if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=r=>{const text=r.text();if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':read=(r,d)=>{const n=r.count();if(n>r.remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');const values=new Array(n);for(let i=0;i<n;i++)values[i]=p.element.decodeCompact(r,d+1);return values;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1)});break;
    case 2:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1)});break;
    case 3:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1)});break;
    case 4:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1),[fs[3].name]:fs[3].plan.decodeCompact(r,d+1)});break;
    default:read=(r,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decodeCompact(r,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,d)=>r.tag()?{Some:p.element.decodeCompact(r,d+1)}:{None:null};break;
  case 'result':read=(r,d)=>r.tag()?{Err:p.error.decodeCompact(r,d+1)}:{Ok:p.ok.decodeCompact(r,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function compactDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=compactReadOperation(field.plan),name=field.name;
  return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');if(d+1>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return {[name]:read(r,d+1)};};
 }
 const read=compactReadOperation(p);
 return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return read(r,d);};
}
class CompactDecodeCursor{
 constructor(bytes,limits,flags){this.bytes=bytes;this.view=flags&2?new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength):null;this.cursor=1;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 require(n){if(n>this.bytes.length-this.cursor)throw Error('truncated compact value');}
 count(){
  if(this.cursor>=this.bytes.length)throw Error('truncated compact value');
  const first=this.bytes[this.cursor++];if(first<128)return first;
  let value=first&127,scale=128;
  for(let i=1;i<5;i++){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const byte=this.bytes[this.cursor++];if(i===4&&byte>15)throw Error('compact count overflow');value+=(byte&127)*scale;if(byte<128){if(byte===0)throw Error('noncanonical compact count');return value;}scale*=128;}throw Error('compact count overflow');
 }
 tag(){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const tag=this.bytes[this.cursor++];if(tag>1)throw Error('wire sum tag');return tag;}
 text(){const n=this.count();this.require(n);const start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
function wireInvalidValue(){throw Error('invalid value for wire schema');}
// Capture has the canonical logical meaning of decode(encode(value)), without
// allocating wire bytes. A separate plan leaves validation/decoder hot shapes
// unchanged and never retains host input containers between calls.
function wireCapturePlan(root,checked=true){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,capture:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({name:f.name,plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.capture=checked?wireCaptureOperation(p):wireCopyOperation(p);return p;
 };return build(root);
}
function wireCaptureOperation(p){
 const t=p.type;let copy;
 switch(p.kind){
  case 'unit':copy=v=>{if(v!==null)wireInvalidValue();return null;};break;
  case 'bool':copy=(v,r)=>{if(typeof v!=='boolean')wireInvalidValue();r.add(1);return v;};break;
  case 'u32':case 'i32':{
   const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
   copy=(v,r)=>{if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();r.add(4);return v===0?0:v;};break;
  }
  case 'u64':copy=(v,r)=>{const kind=typeof v;if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();r.add(8);return n;};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'int':case 'id':case 'enum':copy=(v,r)=>{const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;if(typeof text!=='string'||!text.isWellFormed()||text.length>r.limit)wireInvalidValue();if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();r.add(wireUtf8Length(text));return p.kind==='int'?{Int:text}:text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   copy=(v,r,d)=>{if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();const n=v.length;if(n>r.remaining||size!==null&&n!==size)wireInvalidValue();r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=element.capture(v[i],r,d+1);return out;};break;
  }
  case 'record':{
   const fs=p.fields;let fields;
   switch(fs.length){
    case 0:fields=()=>({});break;
    case 1:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:fields=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }
   copy=(v,r,d)=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();for(const f of fs)if(!wireOwn(v,f.name))wireInvalidValue();return fields(v,r,d);};break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'None')&&v.None===null)return {None:null};if(wireTagged(v,'Some'))return {Some:p.element.capture(v.Some,r,d+1)};wireInvalidValue();};break;
  case 'result':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'Ok'))return {Ok:p.ok.capture(v.Ok,r,d+1)};if(wireTagged(v,'Err'))return {Err:p.error.capture(v.Err,r,d+1)};wireInvalidValue();};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
class WireCaptureCursor{
 constructor(limits){this.remaining=limits.nodes;this.depth=limits.depth;this.limit=limits.bytes;this.bytes=40;this.add(0);}
 add(n){this.bytes+=n;if(this.bytes>this.limit)throw Error('wire byte limit');}
 enter(depth,bytes){if(depth>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.add(bytes);}
 text(value){if(value.length>this.limit)throw Error('wire byte limit');this.add(wireUtf8Length(value));}
}
// Literal lowerers share this fixed resource policy with logical capture.
export function createValueCaptureBudget(options=wireDefaultOptions){return new WireCaptureCursor(wireLimits(options));}
// The trusted-value API has the same canonical copy and ownership semantics.
// Its caller supplies a stable value accepted by validateValue. Shape/range
// checks remain at external capture boundaries; resource limits still apply.
function wireCopyOperation(p){
 let copy;
 switch(p.kind){
  case 'unit':copy=()=>null;break;
  case 'bool':copy=(v,r)=>{r.add(1);return v;};break;
  case 'u32':copy=(v,r)=>{r.add(4);return v>>>0;};break;
  case 'i32':copy=(v,r)=>{r.add(4);return v|0;};break;
  case 'u64':copy=(v,r)=>{r.add(8);return BigInt(v);};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'){wireFloat.setFloat32(0,v,true);bits=wireFloat.getUint32(0,true);}else bits=v.F32Bits;r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'id':case 'enum':copy=(v,r)=>{r.add(wireUtf8Length(v));return v;};break;
  case 'int':copy=(v,r)=>{const text=typeof v==='bigint'?v.toString():v.Int;r.add(wireUtf8Length(text));return {Int:text};};break;
  case 'list':case 'vector':copy=(v,r,d)=>{const n=v.length;if(n>r.remaining)throw Error('wire sequence size');r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=p.element.capture(v[i],r,d+1);return out;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:copy=()=>({});break;
    case 1:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:copy=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'None')&&v.None===null?{None:null}:{Some:p.element.capture(v.Some,r,d+1)};};break;
  case 'result':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'Ok')?{Ok:p.ok.capture(v.Ok,r,d+1)}:{Err:p.error.capture(v.Err,r,d+1)};};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
// Emit the cached literal schema with one forward writer. Each value is checked
// where it is consumed; byte bounds belong to the writer, not a second size walk.
function wireEncodeValue(root,value,l,w){
 let remaining=l.nodes;const depthLimit=l.depth;
 const node=(p,v,d)=>{
  if(d>depthLimit||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type,start=w.beginNode();
  switch(p.kind){
   case 'unit':if(v!==null)wireInvalidValue();break;
   case 'bool':if(typeof v!=='boolean')wireInvalidValue();w.byte(+v);break;
   case 'u32':case 'i32':{
    const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
    if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();w.word(v>>>0);break;
   }
   case 'u64':{
    const kind=typeof v;
    if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
    const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();w.wide(n);break;
   }
   case 'f64':w.wide(wireF64Bits(v));break;
   case 'f32':{
    let bits;
    if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}
    else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
    w.word(bits);break;
   }
   case 'string':case 'int':case 'id':case 'enum':{
    const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
    if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&(typeof text!=='string'||!/^[0-9a-f]{32}$/.test(text))||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
    w.text(text);break;
   }
   case 'list':case 'vector':{
    if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
    if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
    w.count(v.length);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);break;
   }
   case 'record':{
    const fs=p.fields;
    if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
    for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
    for(let i=0;i<fs.length;i++){const f=fs[i];node(f.plan,v[f.name],d+1);}break;
   }
   case 'option':{
    if(wireTagged(v,'None')&&v.None===null)w.byte(0);
    else if(wireTagged(v,'Some')){w.byte(1);node(p.element,v.Some,d+1);}else wireInvalidValue();break;
   }
   case 'result':{
    if(wireTagged(v,'Ok')){w.byte(0);node(p.ok,v.Ok,d+1);}
    else if(wireTagged(v,'Err')){w.byte(1);node(p.error,v.Err,d+1);}else wireInvalidValue();break;
   }
   default:throw Error('unsupported wire kind');
  }
  w.endNode(start);
 };
 node(root,value,0);
}
function wireCheckValue(root,value,l){
 let remaining=l.nodes,total=40;
 const add=n=>{total+=n;if(total>l.bytes)throw Error('wire byte limit');};
 const node=(p,v,d)=>{
  while(true){
   if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
   const t=p.type;
   switch(p.kind){
    case 'unit':if(v!==null)wireInvalidValue();add(4);return;
    case 'bool':if(typeof v!=='boolean')wireInvalidValue();add(5);return;
    case 'u32':case 'i32':{
     const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
     if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();add(8);return;
    }
    case 'u64':{
     const kind=typeof v;
     if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
     const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();add(12);return;
    }
    case 'f64':wireF64Bits(v);add(12);return;
    case 'f32':{
     if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();}
     else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();const bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
     add(8);return;
    }
    case 'string':case 'int':case 'id':case 'enum':{
     const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
     if(typeof text!=='string'||!text.isWellFormed()||text.length>l.bytes)wireInvalidValue();
     if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
     add(4+wireUtf8Length(text));return;
    }
    case 'list':case 'vector':{
     if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
     if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
     add(8);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);return;
    }
    case 'record':{
     const fs=p.fields;
     if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
     for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
     add(4);if(!fs.length)return;
     for(let i=0;i<fs.length-1;i++)node(fs[i].plan,v[fs[i].name],d+1);
     const f=fs[fs.length-1];p=f.plan;v=v[f.name];d++;continue;
    }
    case 'option':{
     if(wireTagged(v,'None')&&v.None===null){add(5);return;}
     if(!wireTagged(v,'Some'))wireInvalidValue();add(5);p=p.element;v=v.Some;d++;continue;
    }
    case 'result':{
     if(wireTagged(v,'Ok')){add(5);p=p.ok;v=v.Ok;}
     else if(wireTagged(v,'Err')){add(5);p=p.error;v=v.Err;}else wireInvalidValue();
     d++;continue;
    }
    default:throw Error('unsupported wire kind');
   }
  }
 };
 node(root,value,0);if(total>l.bytes)throw Error('wire byte limit');
}
// A single cursor replaces per-node child closures and {end,value} temporaries.
// Projection filters limit callback materialisation, never schema validation.
function wireScanValue(root,bytes,view,l,materialize,visitor,selected,spans){
 let cursor=40,remaining=l.nodes;
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,parentEnd,d)=>{
  if(d>l.depth||--remaining<0||cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const t=p.type,start=cursor+4,end=start+view.getUint32(cursor,true);if(end>parentEnd)throw Error('truncated wire frame');cursor=start;let value;
  switch(p.kind){
   case 'unit':if(end-start!==0)throw Error('malformed wire scalar');value=null;break;
   case 'bool':if(end-start!==1)throw Error('malformed wire scalar');if(bytes[start]>1)throw Error('invalid wire Bool');value=!!bytes[start];cursor=end;break;
   case 'u32':case 'i32':if(end-start!==4)throw Error('malformed wire scalar');value=p.kind==='u32'?view.getUint32(start,true):view.getInt32(start,true);cursor=end;break;
   case 'f32':if(end-start!==4)throw Error('malformed wire scalar');if(materialize)value={F32Bits:view.getUint32(start,true)};cursor=end;break;
   case 'f64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value={F64Bits:view.getBigUint64(start,true).toString()};cursor=end;break;
   case 'u64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value=view.getBigUint64(start,true);cursor=end;break;
   case 'string':case 'int':case 'id':case 'enum':{
    if(p.kind==='string'&&!materialize){let i=start;while(i<end&&bytes[i]<128)i++;if(i<end)wireDecoder.decode(bytes.subarray(start,end));}
    else{const text=wireDecodeText(bytes,start,end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    cursor=end;break;
   }
   case 'list':case 'vector':{
    if(start+4>end)throw Error('wire list count');const n=view.getUint32(start,true);cursor+=4;
    if(n>remaining||n>Math.floor((end-cursor)/4)||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,end,d+1);if(materialize)value.push(child);}break;
   }
   case 'record':{
    const fs=p.fields;
    // Computed literal keys create own data properties even for __proto__ or
    // prototype setters. Common small records need no descriptor allocations.
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:value={};break;case 1:value={[fs[0].name]:node(fs[0].plan,end,d+1)};break;case 2:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1)};break;case 3:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1)};break;case 4:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1),[fs[3].name]:node(fs[3].plan,end,d+1)};break;}
    }else{if(materialize)value={};for(const f of fs){const child=node(f.plan,end,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}}break;
   }
   case 'option':case 'result':{
    if(start===end||bytes[cursor]>1)throw Error('wire sum tag');const tag=bytes[cursor++];
    if(p.kind==='option'&&tag===0){if(materialize)value={None:null};}
    else{const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,end,d+1);if(materialize)value={[label]:child};}break;
   }
   default:throw Error('unsupported wire kind');
  }
  if(cursor!==end)throw Error('trailing wire frame bytes');
  if(visitor&&(!selected||selected.has(t.name))){if(spans)visitor(t,bytes,start,end,d);else visitor(t,bytes.subarray(start,end),d);}
  return value;
 };
 const result=node(root,bytes.length,0);if(cursor!==bytes.length)throw Error('trailing wire bytes');return result;
}
export class ValueCodec{
 #hash;
 #header;
 #headerWords;
 #descriptor;
 #valuePlan;
 #compactCodec;
 #encoder;
 #decodeBound=0;
 #scanPlan=null;
 #capturePlan=null;
 #copyPlan=null;
 get descriptor(){return this.#descriptor;}
 constructor(descriptor){
  // This synchronous path is for compiler-generated immutable metadata. For
  // untrusted descriptors use createValueCodec and compare the computed identity.
  if(descriptor?.format!==valueWireFormat||!/^[0-9a-f]{64}$/.test(descriptor.identity))throw Error('invalid wire schema');
  this.#descriptor=structuredClone(descriptor);this.#hash=Uint8Array.from(descriptor.identity.match(/../g),s=>parseInt(s,16));
  this.#header=new Uint8Array(40);this.#header.set(wireMagic);this.#header.set(this.#hash,8);
  const headerView=new DataView(this.#header.buffer);this.#headerWords=Array.from({length:10},(_,i)=>headerView.getUint32(i*4,true));
  const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}};freeze(this.descriptor);this.#valuePlan=wireValuePlan(this);
 }
 resolve(t){for(let i=0;i<64;i++){if(t.kind!=='ref')return t;t=this.descriptor.named[t.name];if(!t)throw Error('wire reference');}throw Error('wire reference cycle');}
 validateValue(value,options=wireDefaultOptions){wireCheckValue(this.#valuePlan,value,wireLimits(options));return true;}
 capture(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#capturePlan??=wireCapturePlan(this.#valuePlan);return this.#capturePlan.capture(value,new WireCaptureCursor(limits),0);}
 copy(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#copyPlan??=wireCapturePlan(this.#valuePlan,false);return this.#copyPlan.capture(value,new WireCaptureCursor(limits),0);}
 compact(){return this.#compactCodec??=new CompactValueCodec(this);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new WireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.bytes(this.#header);wireEncodeValue(this.#valuePlan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new WireEncoder(options);w.bytes(wireMagic);w.bytes(this.#hash);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 scan(bytes,options=wireDefaultOptions,materialize=false,visitor=null,names=null,spans=false){
  const l=wireLimits(options);if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<44||bytes.length>l.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==this.#headerWords[i])throw Error('wire format or schema mismatch');
  if(names!==null&&(!Array.isArray(names)||names.length>100000||names.some(n=>typeof n!=='string')))throw Error('wire visitor names');
  if(materialize&&!visitor){this.#decodeBound||=wireBindDecodePlan(this.#valuePlan);const cursor=new WireDecodeCursor(bytes,view,l);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#valuePlan.decode(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  if(!materialize){this.#scanPlan??=wireScanPlan(this.#valuePlan);const cursor=new WireScanCursor(bytes,view,l,visitor,names===null?null:new Set(names),spans),value=this.#scanPlan.scan(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  return wireScanValue(this.#valuePlan,bytes,view,l,materialize,visitor,names===null?null:new Set(names),spans);
 }
 visit(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names);}
 visitSpans(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names,true);}
 validate(bytes,options=wireDefaultOptions){this.scan(bytes,options,false);return true;}
 decode(bytes,options=wireDefaultOptions){return this.scan(bytes,options,true);}
}

// Bounded forward emission avoids building and repeatedly joining child buffers.
class WireEncoder{
 #data=new Uint8Array(256);#view=new DataView(this.#data.buffer);#at=0;#remaining;#depth=0;#byteLimit;#depthLimit;
 active=false;
 constructor(options){this.reset(options);}
 reset(options){const limits=wireLimits(options);this.#byteLimit=limits.bytes;this.#depthLimit=limits.depth;this.#remaining=limits.nodes;this.#depth=0;this.#at=0;this.active=true;}
 get capacity(){return this.#data.length;}
 get position(){return this.#at;}
 beginNode(){const at=this.#at;this.word(0);return at;}
 endNode(at){this.patchWord(at,this.#at-at-4);}
 count(n){this.word(n);}
 beginCount(){const at=this.position;this.count(0);return at;}
 endCount(at,n){this.patchWord(at,n);}
 #reserve(size){
  const end=this.#at+size;if(end>this.#byteLimit)throw Error('wire byte limit');
  if(end>this.#data.length){const next=new Uint8Array(Math.min(this.#byteLimit,Math.max(end,this.#data.length*2)));next.set(this.#data.subarray(0,this.#at));this.#data=next;this.#view=new DataView(next.buffer);}
  return end;
 }
 bytes(bytes){const end=this.#reserve(bytes.length);this.#data.set(bytes,this.#at);this.#at=end;}
 byte(n){if(!Number.isInteger(n)||n<0||n>255)throw Error('wire byte range');this.#reserve(1);this.#data[this.#at++]=n;}
 word(n){if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire word range');const end=this.#reserve(4);this.#view.setUint32(this.#at,n,true);this.#at=end;}
 wide(n){if(typeof n!=='bigint'||n<0n||n>18446744073709551615n)throw Error('wire wide range');const end=this.#reserve(8);this.#view.setBigUint64(this.#at,n,true);this.#at=end;}
 text(text,count=false){
  if(typeof text!=='string')throw Error('wire Unicode');
  if(text.length<=16){
   let ascii=true;for(let i=0;i<text.length;i++)if(text.charCodeAt(i)>=128){ascii=false;break;}
   if(ascii){if(count)this.count(text.length);const end=this.#reserve(text.length);for(let i=0;i<text.length;i++)this.#data[this.#at+i]=text.charCodeAt(i);this.#at=end;return;}
  }
  if(!text.isWellFormed())throw Error('wire Unicode');const size=wireUtf8Length(text);if(count)this.count(size);
  const end=this.#reserve(size),r=wireEncoder.encodeInto(text,this.#data.subarray(this.#at,end));if(r.read!==text.length||r.written!==size)throw Error('wire UTF-8 size');this.#at=end;
 }
 patchWord(at,n){if(!Number.isInteger(at)||at<0||at+4>this.#at||!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire patch offset');this.#view.setUint32(at,n,true);}
 patchByte(at,n){if(!Number.isInteger(at)||at<0||at>=this.#at||!Number.isInteger(n)||n<0||n>255)throw Error('wire patch offset');this.#data[at]=n;}
 replace(at,removed,bytes){
  if(!Number.isInteger(at)||!Number.isInteger(removed)||at<0||removed<0||at+removed>this.#at||!(bytes instanceof Uint8Array))throw Error('wire replacement range');
  const extra=bytes.length-removed,end=extra>0?this.#reserve(extra):this.#at+extra;
  this.#data.copyWithin(at+bytes.length,at+removed,this.#at);this.#data.set(bytes,at);this.#at=end;
 }
 // Literal generated writers use balanced frames without per-node callbacks.
 // An exception abandons this invocation; encodeWith never reuses its writer.
 openFrame(){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;return at;}
 closeFrame(at){if(this.#depth===0)throw Error('wire frame boundary');this.#depth--;this.endNode(at);}
 frame(emit){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;try{emit(this);}finally{this.#depth--;}this.endNode(at);}
 reorder(start,spans){
  const sorted=spans.slice().sort((a,b)=>a[0]-b[0]);let at=start;
  for(const [a,b] of sorted){if(!Number.isInteger(a)||!Number.isInteger(b)||a!==at||b<a)throw Error('wire span permutation');at=b;}
  if(start<0||start>this.#at||at!==this.#at)throw Error('wire span permutation');
  if(spans.every((s,i)=>s===sorted[i]))return;
  const copy=this.#data.slice(start,this.#at);at=start;for(const [a,b] of spans){this.#data.set(copy.subarray(a-start,b-start),at);at+=b-a;}
 }
 finish(){if(this.#depth!==0)throw Error('wire frame boundary');return this.#data.slice(0,this.#at);}
}

class CompactWireEncoder extends WireEncoder{
 beginNode(){return 0;}
 endNode(){}
 endCount(at,n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  if(n<128){this.patchByte(at,n);return;}
  const bytes=[];while(n>=128){bytes.push(n%128+128);n=Math.floor(n/128);}bytes.push(n);this.replace(at,1,Uint8Array.from(bytes));
 }
 count(n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  while(n>=128){this.byte(n%128+128);n=Math.floor(n/128);}this.byte(n);
 }
 text(text){super.text(text,true);}
}

function compactScanValue(root,bytes,l,materialize){
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let cursor=1,remaining=l.nodes;
 const require=n=>{if(n>bytes.length-cursor)throw Error('truncated compact value');};
 const count=()=>{
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   require(1);const byte=bytes[cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }throw Error('compact count overflow');
 };
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,d)=>{
  if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type;let value;
  switch(p.kind){
   case 'unit':return null;
   case 'bool':require(1);if(bytes[cursor]>1)throw Error('invalid wire Bool');return !!bytes[cursor++];
   case 'u32':case 'i32':require(4);value=p.kind==='u32'?view.getUint32(cursor,true):view.getInt32(cursor,true);cursor+=4;return value;
   case 'f32':require(4);if(materialize)value={F32Bits:view.getUint32(cursor,true)};cursor+=4;return value;
   case 'f64':require(8);if(materialize)value={F64Bits:view.getBigUint64(cursor,true).toString()};cursor+=8;return value;
   case 'u64':require(8);if(materialize)value=view.getBigUint64(cursor,true);cursor+=8;return value;
   case 'string':case 'int':case 'id':case 'enum':{
    const n=count();require(n);const start=cursor;cursor+=n;
    if(p.kind==='string'&&!materialize){let i=start;while(i<cursor&&bytes[i]<128)i++;if(i<cursor)wireDecoder.decode(bytes.subarray(start,cursor));}
    else{const text=wireDecodeText(bytes,start,cursor);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    return value;
   }
   case 'list':case 'vector':{
    const n=count();if(n>remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,d+1);if(materialize)value.push(child);}return value;
   }
   case 'record':{
    const fs=p.fields;
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:return {};case 1:return {[fs[0].name]:node(fs[0].plan,d+1)};case 2:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1)};case 3:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1)};case 4:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1),[fs[3].name]:node(fs[3].plan,d+1)};}
    }
    if(materialize)value={};for(const f of fs){const child=node(f.plan,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}return value;
   }
   case 'option':case 'result':{
    require(1);const tag=bytes[cursor++];if(tag>1)throw Error('wire sum tag');
    if(p.kind==='option'&&tag===0)return materialize?{None:null}:undefined;
    const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,d+1);
    return materialize?{[label]:child}:undefined;
   }
   default:throw Error('unsupported wire kind');
  }
 };
 const value=node(root,0);if(cursor!==bytes.length)throw Error('trailing compact bytes');return value;
}

// General transport codec, independent of source rewrites and checkpoints.
// The sender/receiver must negotiate this exact identity and format. There is
// deliberately no claim that the bytes themselves identify their schema.
export class CompactValueCodec{
 #source;#plan;#encoder;#decodeBound=0;
 get format(){return compactValueWireFormat;}
 get identity(){return this.#source.descriptor.identity;}
 constructor(valueCodec){if(!(valueCodec instanceof ValueCodec))throw Error('compact codec requires a checked value codec');this.#source=valueCodec;this.#plan=wireValuePlan(valueCodec);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new CompactWireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.byte(1);wireEncodeValue(this.#plan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new CompactWireEncoder(options);w.byte(1);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 #scan(bytes,options,materialize){
  const l=wireLimits(options);
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<1||bytes.length>l.bytes)throw Error('wire byte limit or header');
  if(bytes[0]!==1)throw Error('compact format mismatch');
  if(materialize){this.#decodeBound||=wireBindDecodePlan(this.#plan,true);const cursor=new CompactDecodeCursor(bytes,l,this.#decodeBound);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#plan.decodeCompact(cursor,0);if(cursor.cursor!==bytes.length)throw Error('trailing compact bytes');return value;}
  return compactScanValue(this.#plan,bytes,l,materialize);
 }
 decode(bytes,options=wireDefaultOptions){return this.#scan(bytes,options,true);}
 validate(bytes,options=wireDefaultOptions){this.#scan(bytes,options,false);return true;}
}

// Compiler materialisers consume already validated bytes synchronously. This
// factory is for trusted emitted code, not untrusted descriptor/callback data.
// The complete generic validator runs before any compiler reader is invoked.
class ValidatedValueReader{
 constructor(bytes,compact){this.bytes=bytes;this.view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);this.cursor=compact?1:40;this.compact=compact;}
 frame(){if(this.compact)return 0;const end=this.cursor+4+this.view.getUint32(this.cursor,true);this.cursor+=4;return end;}
 finish(end){if(!this.compact&&this.cursor!==end)throw Error('compiled reader frame mismatch');}
 byte(){return this.bytes[this.cursor++];}
 word(){const n=this.view.getUint32(this.cursor,true);this.cursor+=4;return n;}
 signed(){const n=this.view.getInt32(this.cursor,true);this.cursor+=4;return n;}
 wide(){const n=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return n;}
 count(){if(!this.compact)return this.word();let n=0,scale=1,byte;do{byte=this.byte();n+=(byte&127)*scale;scale*=128;}while(byte>=128);return n;}
 text(end){const n=this.compact?this.count():end-this.cursor,start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
class CompiledCompactValueCodec extends CompactValueCodec{
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,true),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
}
class CompiledValueCodec extends ValueCodec{
 #read;#compiledCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,false),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
 compact(){return this.#compiledCompact??=new CompiledCompactValueCodec(this,this.#read);}
}
export function createCompiledValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new CompiledValueCodec(descriptor,read);}

// Trusted literal materialisers may use this checked reader to validate and
// construct in one traversal. The emitter must use frame/finish at every source
// node, typed text reads and counted sequence reads; arbitrary callbacks do not
// establish a schema correspondence proof. The independent scanner remains the
// validation oracle and the original factory retains its pre-validation path.
function literalValueHeader(identity){
 const bytes=new Uint8Array(40);bytes.set(wireMagic);
 for(let i=0;i<32;i++)bytes[i+8]=parseInt(identity.slice(i*2,i*2+2),16);
 const view=new DataView(bytes.buffer),words=new Uint32Array(10);
 for(let i=0;i<10;i++)words[i]=view.getUint32(i*4,true);
 return words;
}
class CheckedLiteralValueReader {
 constructor(bytes,header,compact,limits){
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<(compact?1:44)||bytes.length>limits.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  if(compact){if(bytes[0]!==1)throw Error('compact format mismatch');}
  else for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==header[i])throw Error('wire format or schema mismatch');
  this.bytes=bytes;this.view=view;
  this.cursor=compact?1:40;this.compact=compact;this.remaining=limits.nodes;this.depth=limits.depth;this.ends=[];
 }
 require(n){if(this.cursor+n>(this.ends.at(-1)??this.bytes.length))throw Error('truncated wire frame');}
 frame(){
  if(this.ends.length>this.depth||--this.remaining<0)throw Error('wire node or depth limit');
  let end=this.bytes.length;
  if(!this.compact){this.require(4);end=this.cursor+4+this.view.getUint32(this.cursor,true);this.require(end-this.cursor);this.cursor+=4;}
  this.ends.push(end);return this.compact?0:end;
 }
 finish(end){
  if(!this.ends.length||!this.compact&&(this.ends.at(-1)!==end||this.cursor!==end))throw Error('compiled reader frame mismatch');
  this.ends.pop();
 }
 byte(){this.require(1);const value=this.bytes[this.cursor++];if(value>1)throw Error('wire sum tag or Bool');return value;}
 word(){this.require(4);const value=this.view.getUint32(this.cursor,true);this.cursor+=4;return value;}
 signed(){this.require(4);const value=this.view.getInt32(this.cursor,true);this.cursor+=4;return value;}
 wide(){this.require(8);const value=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return value;}
 rawCount(){
  if(!this.compact)return this.word();
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   this.require(1);const byte=this.bytes[this.cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }
  throw Error('compact count overflow');
 }
 count(size){
  const value=this.rawCount();
  if(value>this.remaining||size!==undefined&&value!==size)throw Error('wire sequence size');
  return value;
 }
 text(end,kind='string',variants){
  const size=this.compact?this.rawCount():end-this.cursor;
  this.require(size);const start=this.cursor;this.cursor+=size;
  const value=wireDecodeText(this.bytes,start,this.cursor);
  if(kind==='int'&&!wireDecimal(value)||kind==='id'&&!/^[0-9a-f]{32}$/.test(value)||kind==='enum'&&!variants.includes(value))throw Error('malformed wire text');
  return value;
 }
 complete(){if(this.ends.length||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
// Compact source nodes have no individual frame ends: retain the same checked
// depth/node order using a counter, with bounds against the complete buffer.
class CheckedCompactLiteralValueReader extends CheckedLiteralValueReader {
 constructor(bytes,limits){super(bytes,null,true,limits);this.level=0;}
 require(n){if(this.cursor+n>this.bytes.length)throw Error('truncated wire frame');}
 frame(){if(this.level>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.level++;return 0;}
 finish(_end){if(!this.level)throw Error('compiled reader frame mismatch');this.level--;}
 complete(){if(this.level||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
class FusedCompactValueCodec extends CompactValueCodec {
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedCompactLiteralValueReader(bytes,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
}
class FusedValueCodec extends ValueCodec {
 #read;#header;#fusedCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;this.#header=literalValueHeader(this.descriptor.identity);}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedLiteralValueReader(bytes,this.#header,false,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
 compact(){return this.#fusedCompact??=new FusedCompactValueCodec(this,this.#read);}
}
export function createFusedValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new FusedValueCodec(descriptor,read);}
// JSON text is a boundary adapter to an ordinary recursive Ink datatype.
// No JavaScript Number conversion occurs for JSON numeric tokens.
export function jsonNumberToken(s){return typeof s==='string'&&/^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/.test(s);}
// JSON numeric tokens have an ASCII grammar. Check validated UTF-8 spans
// directly, preserving exact lexemes without allocating a decoded String.
function jsonNumberSpan(bytes,lo,hi){
 let at=lo;if(bytes[at]===45)at++;
 if(at>=hi)return false;
 if(bytes[at]===48)at++;
 else{if(bytes[at]<49||bytes[at]>57)return false;do{at++;}while(at<hi&&bytes[at]>=48&&bytes[at]<=57);}
 if(at<hi&&bytes[at]===46){const start=++at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 if(at<hi&&(bytes[at]===69||bytes[at]===101)){at++;if(at<hi&&(bytes[at]===43||bytes[at]===45))at++;const start=at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 return at===hi;
}
const jsonWireEncoder=new TextEncoder();
// Scalar conversion completes before writer callbacks; no per-value byte array.
const jsonFloatScratch=new DataView(new ArrayBuffer(4));
function jsonUtf8Length(text){if(text.length>16&&!/[^\x00-\x7f]/.test(text))return text.length;let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const jsonLimits={bytes:16777216,nodes:1000000,depth:128};
const jsonQuoters=new WeakSet();
/** Explicit, bounded reuse of immutable JSON string quotes. Cache payload bytes
 * are UTF-16 storage estimates; entry caps bound separate Map/object overhead.
 * Logical output budgets are charged again on every use, including cache hits.
 */
export function createJsonQuoter({maxEntries=1024,maxBytes=131072}={}){
 if(!Number.isSafeInteger(maxEntries)||maxEntries<0||maxEntries>65536||!Number.isSafeInteger(maxBytes)||maxBytes<0||maxBytes>16777216)throw Error('JSON quote cache budget');
 const entries=new Map();let bytes=0,hits=0,misses=0;
 const token=value=>{
  const prior=entries.get(value);if(prior!==undefined){hits++;return prior;}
  if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid JSON String');
  misses++;const text=JSON.stringify(value),size=2*(value.length+text.length),quoted=Object.freeze({text,utf8Bytes:jsonUtf8Length(text)});
  if(maxEntries&&size<=maxBytes){
   while(entries.size&&(entries.size>=maxEntries||bytes+size>maxBytes)){const key=entries.keys().next().value;bytes-=2*(key.length+entries.get(key).text.length);entries.delete(key);}
   entries.set(value,quoted);bytes+=size;
  }
  return quoted;
 };
 const quoter=Object.freeze({
  token,
  quote(value){return token(value).text;},
  clear(){entries.clear();bytes=0;},
  stats(){return {entries:entries.size,payload_bytes:bytes,hits,misses};},
 });jsonQuoters.add(quoter);return quoter;
}
function checkedJsonLimits(options){const l={...jsonLimits,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>jsonLimits[k])throw Error('JSON hard resource limit');return l;}
function jsonVariant(index,item){let payload=index===0?{}:{item0:item};if(index<5)payload={Ok:payload};for(let i=0;i<index;i++)payload={Err:payload};return {payload};}
export function parseJson(text,options={}){return parseJsonValue(text,options,null);}
function parseJsonValue(text,options,boundary){
 const p=new JsonWireReader(text,options);
 const value=(d,wireDepth=0)=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){boundary?.node(0,wireDepth);p.at+=4;return jsonVariant(0,null);}if(c==='t'&&text.startsWith('true',p.at)){boundary?.node(1,wireDepth);p.at+=4;return jsonVariant(1,true);}if(c==='f'&&text.startsWith('false',p.at)){boundary?.node(1,wireDepth);p.at+=5;return jsonVariant(1,false);}
  if(c==='"'){boundary?.node(3,wireDepth);const item=p.string();boundary?.text(item);return jsonVariant(3,item);}
  if(c==='['){boundary?.node(4,wireDepth);p.at++;const xs=[];if(!p.eat(']'))while(true){xs.push(value(d+1,wireDepth+8));if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}return jsonVariant(4,xs);}
  if(c==='{'){boundary?.node(5,wireDepth);p.at++;const xs=[],seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary?.member(key,wireDepth);if(!p.eat(':'))throw Error('JSON object colon');xs.push({key,value:value(d+1,wireDepth+9)});if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}return jsonVariant(5,xs);}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();boundary?.node(2,wireDepth);boundary?.text(token);return jsonVariant(2,token);}
  throw Error('invalid JSON value');
 };
 const out=value(0);p.finish();return out;
}
export function stringifyJson(value,options={}){return stringifyJsonValue(value,options,null);}
function stringifyJsonValue(value,options,boundary){
 const l=checkedJsonLimits(options);let remaining=l.nodes,bytes=0,output='';
 const emit=s=>{bytes+=jsonUtf8Length(s);if(bytes>l.bytes)throw Error('JSON byte limit');output+=s;};
 const write=(v,d,wireDepth=0)=>{
  if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');if(!v||Object.keys(v).length!==1||!Object.hasOwn(v,'payload'))throw Error('invalid JSON record');let p=v.payload,index=0;
  while(index<5&&p&&Object.hasOwn(p,'Err')){if(Object.keys(p).length!==1||boundary&&Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Err;index++;}
  if(index<5){if(!p||Object.keys(p).length!==1||!Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Ok;}
  if(!p||Object.keys(p).length!==(index===0?0:1)||index>0&&!Object.hasOwn(p,'item0'))throw Error('invalid JSON payload');const item=p.item0;boundary?.node(index,wireDepth);
  switch(index){
   case 0:emit('null');break;
   case 1:if(typeof item!=='boolean')throw Error('invalid JSON Boolean');emit(item?'true':'false');break;
   case 2:if(!jsonNumberToken(item))throw Error('invalid JSON number');boundary?.text(item);emit(item);break;
   case 3:if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary?.text(item);emit(JSON.stringify(item));break;
   case 4:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Array');const count=item.length;let visited=0;emit('[');item.forEach((x,i)=>{visited++;if(i)emit(',');write(x,d+1,wireDepth+8);});if(visited!==count)throw Error('invalid JSON Array');emit(']');break;}
   case 5:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Object');const count=item.length,seen=new Set();let visited=0;emit('{');item.forEach((m,i)=>{visited++;if(!m||Object.keys(m).length!==2||typeof m.key!=='string'||!m.key.isWellFormed()||!Object.hasOwn(m,'value')||boundary&&!Object.hasOwn(m,'key'))throw Error('invalid JSON member');if(seen.has(m.key))throw Error('duplicate JSON object key');seen.add(m.key);boundary?.member(m.key,wireDepth);if(i)emit(',');emit(JSON.stringify(m.key));emit(':');write(m.value,d+1,wireDepth+9);});if(visited!==count)throw Error('invalid JSON Object');emit('}');break;}
  }
 };write(value,0);return output;
}
// The adapter's schema is the fixed recursive JSON library shape checked by
// JsonCodec. Charge its ordinary record/sum/list wire nodes while parsing or
// rendering, rather than interpreting and walking the completed tree again.
function jsonBoundaryBudget(options){
 const l=checkedJsonLimits(options);let remaining=l.nodes,total=40;
 const charge=(nodes,bytes,depth)=>{remaining-=nodes;total+=bytes;if(remaining<0||depth>l.depth)throw Error('wire node or depth limit');if(total>l.bytes)throw Error('wire byte limit');};
 return {
  node(index,depth){charge(index===0?3:index<4?index+4:8,index===0?13:index===1?23:index===2?27:index===3?32:41,depth+(index===0?2:index<4?index+3:7));},
  text(text){charge(0,jsonUtf8Length(text),0);},
  member(key,depth){charge(2,8+jsonUtf8Length(key),depth+9);},
 };
}
function jsonSameSchema(a,b){
 if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;
 const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>Object.hasOwn(b,k)&&jsonSameSchema(a[k],b[k]));
}
// Host-object conversion is opt-in and JavaScript-only. Inspect data properties
// rather than invoking getters/toJSON; reflection is not a sandbox for proxies.
function jsonJSKeys(value){
 if(!value||typeof value!=='object')throw Error('expected a plain JavaScript object');
 const prototype=Object.getPrototypeOf(value);
 if(prototype!==Object.prototype&&prototype!==null)throw Error('expected a plain JavaScript object');
 const keys=Reflect.ownKeys(value);
 if(keys.some(k=>typeof k!=='string'))throw Error('JavaScript symbol keys are unsupported');
 return keys;
}
function jsonJSData(value,key){
 const property=Object.getOwnPropertyDescriptor(value,key);
 if(!property||!property.enumerable||!Object.hasOwn(property,'value'))throw Error('expected an enumerable own data property');
 return property.value;
}
function jsonJSRecord(value,names){
 const keys=jsonJSKeys(value);
 if(keys.length!==names.length||keys.some(k=>!names.includes(k)))throw Error('invalid JSON record or variant');
}
function jsonJSArray(value,remaining){
 if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype)throw Error('expected a plain JavaScript array');
 const length=value.length;
 if(length>remaining)throw Error('JSON node limit');
 const keys=Reflect.ownKeys(value);
 if(keys.length!==length+1||keys.some(k=>typeof k!=='string'||k!=='length'&&(!/^(0|[1-9][0-9]*)$/.test(k)||Number(k)>=length)))throw Error('sparse or decorated JavaScript arrays are unsupported');
 return length;
}
function jsonFromJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),active=new WeakSet();let remaining=limits.nodes;
 const text=value=>{if(!value.isWellFormed())throw Error('invalid JSON Unicode');boundary.text(value);return value;};
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  if(value===null){boundary.node(0,wireDepth);return jsonVariant(0);}
  switch(typeof value){
   case 'boolean':boundary.node(1,wireDepth);return jsonVariant(1,value);
   case 'string':boundary.node(3,wireDepth);return jsonVariant(3,text(value));
   case 'number':
    if(!Number.isFinite(value))throw Error('non-finite JavaScript numbers are unsupported');
    boundary.node(2,wireDepth);return jsonVariant(2,text(Object.is(value,-0)?'-0':String(value)));
   case 'bigint':boundary.node(2,wireDepth);return jsonVariant(2,text(String(value)));
   case 'object':break;
   default:throw Error('unsupported JavaScript value');
  }
  if(active.has(value))throw Error('cyclic JavaScript value');
  active.add(value);
  try{
   if(Array.isArray(value)){
    boundary.node(4,wireDepth);const count=jsonJSArray(value,remaining),items=[];
    for(let i=0;i<count;i++)items.push(visit(jsonJSData(value,String(i)),depth+1,wireDepth+8));
    return jsonVariant(4,items);
   }
   boundary.node(5,wireDepth);const keys=jsonJSKeys(value),members=[];
   if(keys.length>remaining)throw Error('JSON node limit');
   for(const key of keys){
    if(!key.isWellFormed())throw Error('invalid JSON Unicode');
    boundary.member(key,wireDepth);
    members.push({key,value:visit(jsonJSData(value,key),depth+1,wireDepth+9)});
   }
   return jsonVariant(5,members);
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
function jsonDecimalKey(token){
 const [,sign,whole,fraction='',exponent='0']=/^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(token);
 const digits=(whole+fraction).replace(/^0+/,'');
 if(!digits)return '0';
 const trimmed=digits.replace(/0+$/,'');
 return sign+trimmed+'e'+(Number(exponent)-fraction.length+digits.length-trimmed.length);
}
function jsonToJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),mode=options?.numbers??'number',active=new WeakSet();let remaining=limits.nodes;
 if(!['number','bigint','string'].includes(mode))throw Error('unknown JavaScript number policy');
 const number=token=>{
  if(!jsonNumberToken(token))throw Error('invalid JSON number');
  boundary.text(token);
  if(mode==='string')return token;
  if(mode==='bigint')return BigInt(jsonInteger(token,4096));
  const result=Number(token);
  if(!Number.isFinite(result)||jsonDecimalKey(token)!==jsonDecimalKey(String(result)))throw Error('JSON number loses precision as JavaScript Number; choose numbers: bigint or string');
  return result;
 };
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  jsonJSRecord(value,['payload']);
  if(active.has(value))throw Error('cyclic JSON value');
  active.add(value);
  try{
   let payload=jsonJSData(value,'payload'),index=0;
   while(index<5&&Object.hasOwn(payload,'Err')){jsonJSRecord(payload,['Err']);payload=jsonJSData(payload,'Err');index++;}
   if(index<5){jsonJSRecord(payload,['Ok']);payload=jsonJSData(payload,'Ok');}
   jsonJSRecord(payload,index===0?[]:['item0']);boundary.node(index,wireDepth);
   const item=index===0?null:jsonJSData(payload,'item0');
   if(index===0)return null;
   if(index===1){if(typeof item!=='boolean')throw Error('invalid JSON Boolean');return item;}
   if(index===2)return number(item);
   if(index===3){if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary.text(item);return item;}
   const count=jsonJSArray(item,remaining);
   if(index===4){const out=[];for(let i=0;i<count;i++)out.push(visit(jsonJSData(item,String(i)),depth+1,wireDepth+8));return out;}
   const out={},seen=new Set();
   for(let i=0;i<count;i++){
    const member=jsonJSData(item,String(i));jsonJSRecord(member,['key','value']);const key=jsonJSData(member,'key');
    if(typeof key!=='string'||!key.isWellFormed())throw Error('invalid JSON member key');
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary.member(key,wireDepth);
    Object.defineProperty(out,key,{value:visit(jsonJSData(member,'value'),depth+1,wireDepth+9),enumerable:true,writable:true,configurable:true});
   }
   return out;
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
const jsonConstructionPaths=Object.freeze(Array.from({length:6},(_,index)=>Object.freeze([0,...Array(index).fill(1),...(index<5?[0]:[]),0])));
function parseJsonConstructed(text,options,builder){
 const p=new JsonWireReader(text,options);
 const paths=jsonConstructionPaths;
 const fused=typeof builder.openPath==='function';
 const begin=index=>{if(fused){builder.openPath(paths[index]);return;}for(const choice of paths[index])builder.open(choice);};
 const end=index=>{for(let i=0;i<(fused?1:index<5?index+3:7);i++)builder.close();};
 const leaf=(index,item)=>{if(typeof builder.scalarPath==='function'){builder.scalarPath(paths[index],item);return;}begin(index);builder.scalar(item);end(index);};
 const value=d=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){p.at+=4;if(typeof builder.emptyPath==='function')builder.emptyPath(paths[0]);else{begin(0);end(0);}return;}
  if(c==='t'&&text.startsWith('true',p.at)){p.at+=4;leaf(1,true);return;}
  if(c==='f'&&text.startsWith('false',p.at)){p.at+=5;leaf(1,false);return;}
  if(c==='"'){leaf(3,p.string());return;}
  if(c==='['){begin(4);builder.open(0);p.at++;if(!p.eat(']'))while(true){value(d+1);if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}builder.close();end(4);return;}
  if(c==='{'){begin(5);builder.open(0);p.at++;const seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');builder.open(0);builder.scalar(key);value(d+1);builder.close();if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}builder.close();end(5);return;}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();leaf(2,token);return;}
  throw Error('invalid JSON value');
 };
 value(0);p.finish();return builder.finish();
}
const jsonCompiledRenderers=new WeakMap();
function compiledJsonRenderer(json,codec,unwrap){
 if(typeof codec?.reducer!=='function')throw Error('compiled JSON reduction unavailable');
 const source=codec.resolve(codec.descriptor.root),root=json.values.descriptor.root;
 const selected=unwrap&&source.kind==='result'?codec.resolve(source.ok):source;
 if(!jsonSameSchema(root,selected)||unwrap&&source.kind!=='result')throw Error('compiled JSON schema mismatch');
 let variants=root.fields[0].type;const roles=new Map([[root.name,'root']]);
 let member;
 for(let index=0;index<6;index++){
  const branch=index<5?variants.ok:variants;roles.set(branch.name,index);
  if(index===5){member=branch.fields[0].type.element.name;roles.set(member,'member');}
  if(index<5)variants=variants.error;
 }
 const nodeRoles=new Map();
 return codec.reducer((node,index)=>{
  const role=roles.get(node.name);nodeRoles.set(index,role);
  if(node.kind==='record'){
   if(role==='root')return value=>value;
   if(role==='member')return (key,value,context)=>{
    const text=(context.quoter?context.quote(key,true):context.add(JSON.stringify(key)+':'))+value,seen=context.members;
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);return text;
   };
   if(role===0)return context=>context.add('null');
   if(role===1)return (value,context)=>context.add(value?'true':'false');
   if(role===2)return (token,context)=>{if(!jsonNumberToken(token))throw Error('invalid JSON number');return context.add(token);};
   if(role===3)return (value,context)=>context.quoter?context.quote(value,false):context.add(JSON.stringify(value));
   if(role===4)return (value,context)=>{context.add('[]');return '['+value+']';};
   if(role===5)return (value,context)=>{context.add('{}');return '{'+value+'}';};
   return ()=>null;
  }
  if(node.kind==='list'||node.kind==='vector'){
   const members=nodeRoles.get(node.children[0])==='member';
   return {
    start:(_length,context)=>{
     const out={text:'',parent:members?context.members:null};
     if(members)context.members=new Set();return out;
    },
    step:(out,value,index,context)=>{out.text+=(index?context.add(','):'')+value;return out;},
    finish:(out,context)=>{if(members)context.members=out.parent;return out.text;},
   };
  }
  if(node.kind==='result'){
   // A Result<Json,E> boundary is explicitly requested by the caller. Ordinary
   // JSON's own sums only propagate an already rendered branch.
   if(unwrap&&nodeRoles.get(node.children[0])==='root')return (tag,value)=>{if(tag)throw Error('JSON result is Err');return value;};
   return (_tag,value)=>value;
  }
  if(node.kind==='string')return value=>{if(!value.isWellFormed())throw Error('invalid JSON String');return value;};
  return value=>value;
 });
}
export class JsonCodec{
 constructor(valueCodec){
  const root=valueCodec.descriptor.root,fields=root.fields;if(root.kind!=='record'||!Array.isArray(fields)||fields.length!==1||fields[0].name!=='payload')throw Error('JSON schema payload');let sum=fields[0].type;
  for(let i=0;i<6;i++){
   if(i<5&&sum.kind!=='result')throw Error('JSON schema sum');const branch=i<5?sum.ok:sum,fs=branch.fields;
   if(branch.kind!=='record'||!Array.isArray(fs)||fs.length!==(i?1:0)||i&&fs[0].name!=='item0')throw Error('JSON schema branch');
   if(i){const t=fs[0].type;if(i===1&&t.kind!=='bool'||(i===2||i===3)&&t.kind!=='string'||i===4&&(t.kind!=='list'||t.element.kind!=='ref'||t.element.name!==root.name))throw Error('JSON schema variant');if(i===5){const mf=t.element?.fields;if(t.kind!=='list'||t.element?.kind!=='record'||!Array.isArray(mf)||mf.length!==2||mf[0].name!=='key'||mf[0].type.kind!=='string'||mf[1].name!=='value'||mf[1].type.kind!=='ref'||mf[1].type.name!==root.name)throw Error('JSON schema member');}}
   if(i===2)this.numberBranch=branch.name;if(i===5)this.objectBranch=branch.name;
   if(i<5)sum=sum.error;
  }if(!jsonSameSchema(root,valueCodec.resolve({kind:'ref',name:root.name})))throw Error('JSON recursive schema mismatch');this.values=valueCodec;
 }
 parse(text,options={}){return parseJsonValue(text,options,jsonBoundaryBudget(options));}
 parseCompiled(codec,text,options={}){
  if(codec?.identity!==this.values.descriptor.identity||typeof codec.builder!=='function')throw Error('compiled JSON schema mismatch');
  const builder=codec.builder(options);try{return parseJsonConstructed(text,options,builder);}catch(error){builder.abort();throw error;}
 }
 stringify(value,options={}){return stringifyJsonValue(value,options,jsonBoundaryBudget(options));}
 stringifyCompiled(codec,handle,options={}){
  const limits=checkedJsonLimits(options),unwrap=options.unwrapResult===true;
  const quoter=options.quoter;if(quoter!==undefined&&!jsonQuoters.has(quoter))throw Error('JSON quote cache owner mismatch');
  let codecs=jsonCompiledRenderers.get(this);if(!codecs)jsonCompiledRenderers.set(this,codecs=new WeakMap());
  let renderers=codecs.get(codec);if(!renderers)codecs.set(codec,renderers=new Map());
  let render=renderers.get(unwrap);if(!render)renderers.set(unwrap,render=compiledJsonRenderer(this,codec,unwrap));
  let bytes=0;const context={
   quoter,
   add(text){bytes+=jsonUtf8Length(text);if(bytes>limits.bytes)throw Error('JSON byte limit');return text;},
   quote(value,colon){
    if(!quoter)return this.add(JSON.stringify(value)+(colon?':':''));
    const token=quoter.token(value);bytes+=token.utf8Bytes+(colon?1:0);if(bytes>limits.bytes)throw Error('JSON byte limit');return token.text+(colon?':':'');
   },
  };
  const text=render(handle,context,limits);
  return text;
 }
 fromJS(value,options={}){return jsonFromJS(value,options);}
 toJS(value,options={}){return jsonToJS(value,options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,false);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,false,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,true);}
 validateBinary(bytes,options={}){
  const decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});let view;
  this.values.visitSpans(bytes,(type,data,start,end)=>{
   view??=new DataView(data.buffer,data.byteOffset,data.byteLength);
   if(type.name===this.numberBranch){const length=view.getUint32(start,true);if(!jsonNumberSpan(data,start+4,start+4+length))throw Error('invalid JSON number token');}
   if(type.name===this.objectBranch){const listEnd=start+4+view.getUint32(start,true),count=view.getUint32(start+4,true),seen=new Set();let at=start+8;for(let i=0;i<count;i++){const memberEnd=at+4+view.getUint32(at,true),keyStart=at+8,keyEnd=keyStart+view.getUint32(at+4,true),key=decoder.decode(data.subarray(keyStart,keyEnd));if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);at=memberEnd;}if(at!==listEnd)throw Error('invalid JSON object frame');}
  },options,[this.numberBranch,this.objectBranch]);return true;

 }
}
function jsonUnpack(value){let p=value.payload,i=0;while(i<5&&Object.hasOwn(p,'Err')){p=p.Err;i++;}return [i,(i<5?p.Ok:p).item0];}
function jsonInteger(token,limit){
 if(!jsonNumberToken(token))throw Error('invalid JSON number');const negative=token[0]==='-',raw=negative?token.slice(1):token,[mantissa,exp='0']=raw.split(/[eE]/);let digits=mantissa.replace('.','');if(/^0+$/.test(digits))return '0';const exponent=Number(exp),fraction=mantissa.includes('.')?mantissa.length-mantissa.indexOf('.')-1:0,shift=exponent-fraction;
 if(!Number.isSafeInteger(exponent)||!Number.isSafeInteger(shift))throw Error('JSON integer exponent limit');
 if(shift<0){const cut=-shift;if(cut>=digits.length||!/^[0]+$/.test(digits.slice(-cut)))throw Error('JSON number is not an integer');digits=digits.slice(0,-cut);}else{if(digits.length+shift>limit)throw Error('JSON integer magnitude limit');digits+='0'.repeat(shift);}
 digits=digits.replace(/^0+/,'');if(digits.length>limit)throw Error('JSON integer magnitude limit');return (negative?'-':'')+digits;
}
function jsonBinary64Value(v){
 if(typeof v==='number')return v;
 const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid F64Bits');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');
 const b=new DataView(new ArrayBuffer(8));b.setBigUint64(0,bits,true);return b.getFloat64(0,true);
}
export class TypedJsonCodec{
 constructor(valueCodec){this.values=valueCodec;}
 decode(document,options={}){
  // Validate JSON-specific invariants before interpreting any tagged/record
  // shape, including duplicated names and malformed numeric tokens.
  stringifyJson(document,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const read=(type,value,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type),[kind,item]=jsonUnpack(value);const fail=()=>{throw Error('JSON does not match '+t.kind);};
   switch(t.kind){
    case 'unit':if(kind!==0)fail();return null;
    case 'bool':if(kind!==1)fail();return item;
    case 'u32':case 'u64':case 'i32':case 'int':{if(kind!==2)fail();const text=jsonInteger(item,t.kind==='int'?4096:t.kind==='u64'?20:10);return t.kind==='int'?{Int:text}:t.kind==='u64'?BigInt(text):Number(text);}
    case 'f64':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(8));if(!Number.isFinite(n))throw Error('JSON f64 overflow');b.setFloat64(0,n,true);return {F64Bits:b.getBigUint64(0,true).toString()};}
    case 'f32':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(4));b.setFloat32(0,n,true);if(!Number.isFinite(b.getFloat32(0,true)))throw Error('JSON f32 overflow');return {F32Bits:b.getUint32(0,true)};}
    case 'string':case 'enum':case 'id':if(kind!==3)fail();return item;
    case 'list':case 'vector':if(kind!==4)fail();return item.map(x=>read(t.element,x,d+1));
    case 'record':{if(kind!==5||item.length!==t.fields.length)throw Error('unknown or missing JSON record field');const fields=new Map(item.map(m=>[m.key,m.value])),out={};for(const f of t.fields){if(!fields.has(f.name))throw Error('missing JSON record field');Object.defineProperty(out,f.name,{value:read(f.type,fields.get(f.name),d+1),writable:true,enumerable:true,configurable:true});}return out;}
    case 'option':case 'result':{if(kind!==5||item.length!==1)fail();const m=item[0];if(t.kind==='option'&&m.key==='None'&&jsonUnpack(m.value)[0]===0)return {None:null};const child=t.kind==='option'&&m.key==='Some'?t.element:t.kind==='result'&&m.key==='Ok'?t.ok:t.kind==='result'&&m.key==='Err'?t.error:null;if(!child)fail();return {[m.key]:read(child,m.value,d+1)};}
    default:fail();
   }
  };
  const out=read(this.values.descriptor.root,document,0);this.values.validateValue(out,options);return out;
 }
 encode(value,options={}){
  this.values.validateValue(value,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const write=(type,v,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type);
   switch(t.kind){
    case 'unit':return jsonVariant(0);
    case 'bool':return jsonVariant(1,v);
    case 'u32':case 'u64':case 'i32':return jsonVariant(2,String(v));
    case 'int':return jsonVariant(2,typeof v==='bigint'?String(v):v.Int);
    case 'f64':{const n=jsonBinary64Value(v);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'f32':{let n;if(typeof v==='number')n=Math.fround(v);else{const b=new DataView(new ArrayBuffer(4));b.setUint32(0,v.F32Bits,true);n=b.getFloat32(0,true);}if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'string':case 'id':case 'enum':return jsonVariant(3,v);
    case 'list':case 'vector':return jsonVariant(4,Array.from(v,x=>write(t.element,x,d+1)));
    case 'record':return jsonVariant(5,t.fields.map(f=>({key:f.name,value:write(f.type,v[f.name],d+1)})));
    case 'option':return jsonVariant(5,[Object.hasOwn(v,'Some')?{key:'Some',value:write(t.element,v.Some,d+1)}:{key:'None',value:jsonVariant(0)}]);
    case 'result':return jsonVariant(5,[Object.hasOwn(v,'Ok')?{key:'Ok',value:write(t.ok,v.Ok,d+1)}:{key:'Err',value:write(t.error,v.Err,d+1)}]);
    default:throw Error('unsupported typed JSON descriptor');
   }
  };return write(this.values.descriptor.root,value,0);
 }
 parse(text,options={}){return this.decode(parseJson(text,options),options);}
 stringify(value,options={}){return stringifyJson(this.encode(value,options),options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,true);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,true,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,false);}
}

// Token reader shared by schema-directed and arbitrary-JSON wire emission.
class JsonWireReader{
 constructor(text,options){this.l=checkedJsonLimits(options);if(typeof text!=='string'||!text.isWellFormed()||text.length>this.l.bytes||jsonUtf8Length(text)>this.l.bytes)throw Error('JSON byte or Unicode limit');this.text=text;this.at=0;this.remaining=this.l.nodes;}
 ws(){while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(c!==32&&c!==9&&c!==10&&c!==13)break;this.at++;}}
 peek(){this.ws();return this.text[this.at];}
 eat(c){this.ws();if(this.text[this.at]===c){this.at++;return true;}return false;}
 node(d){if(d>this.l.depth||--this.remaining<0)throw Error('JSON node or depth limit');}
 string(){
  this.ws();const start=this.at;if(this.text[start]!=='"')throw Error('expected JSON string');
  const end=this.text.indexOf('"',start+1);if(end<0)throw Error('unterminated JSON string');
  const raw=this.text.slice(start+1,end);
  if(!raw.includes('\\')&&!/[\x00-\x1f]/.test(raw)){this.at=end+1;return raw;}
  this.at=start+1;while(this.at<this.text.length){if(this.text[this.at]==='"'){this.at++;const v=JSON.parse(this.text.slice(start,this.at));if(!v.isWellFormed())throw Error('invalid JSON Unicode');return v;}if(this.text[this.at]==='\\')this.at+=2;else this.at++;}throw Error('unterminated JSON string');
 }
 number(){const start=this.at;while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(!(c>=48&&c<=57||c===45||c===43||c===46||c===101||c===69))break;this.at++;}const token=this.text.slice(start,this.at);if(!jsonNumberToken(token))throw Error('invalid JSON number');return token;}
 leaf(d){this.node(d);const c=this.peek();if(c==='n'&&this.text.startsWith('null',this.at)){this.at+=4;return null;}if(c==='t'&&this.text.startsWith('true',this.at)){this.at+=4;return true;}if(c==='f'&&this.text.startsWith('false',this.at)){this.at+=5;return false;}if(c==='"')return this.string();if(c==='-'||c>='0'&&c<='9')return this.number();throw Error('invalid JSON scalar');}
 finish(){this.ws();if(this.at!==this.text.length)throw Error('trailing JSON text');}
}
function streamJsonBinary(values,text,options,typed,compact=false){
 const p=new JsonWireReader(text,options),utf8=jsonWireEncoder;
 const list=(w,open,close,item)=>{if(!p.eat(open))throw Error('JSON container shape');const at=w.beginCount();let count=0;if(!p.eat(close))while(true){item(w);count++;if(p.eat(close))break;if(!p.eat(','))throw Error('JSON container separator');}w.endCount(at,count);};
 const variant=(w,index,level,emit)=>{if(level<index)w.frame(w=>{w.byte(1);variant(w,index,level+1,emit);});else if(index<5)w.frame(w=>{w.byte(0);w.frame(emit);});else w.frame(emit);};
 const json=(w,d)=>{
  const ch=p.peek(),index=ch==='n'?0:ch==='t'||ch==='f'?1:ch==='-'||ch>='0'&&ch<='9'?2:ch==='"'?3:ch==='['?4:ch==='{'?5:-1;if(index<0)throw Error('invalid JSON value');
  const leaf=index<4?p.leaf(d):null;if(index>=4)p.node(d);
  w.frame(w=>variant(w,index,0,w=>{
   if(index===0)return;if(index===1){w.frame(w=>w.byte(+leaf));return;}
   if(index===2||index===3){w.frame(w=>w.text(leaf));return;}
   w.frame(w=>{if(index===4)list(w,'[',']',w=>json(w,d+1));else{const seen=new Set();list(w,'{','}',w=>{const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');w.frame(w=>{w.frame(w=>w.text(key));json(w,d+1);});});}});
  }));
 };
 const read=(type,w,d)=>{
  const t=values.resolve(type);w.frame(w=>{
   if(t.kind==='list'||t.kind==='vector'){p.node(d);list(w,'[',']',w=>read(t.element,w,d+1));return;}
   if(t.kind==='record'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON record');const start=w.position,spans=new Array(t.fields.length).fill(null);
    if(!p.eat('}'))while(true){const key=p.string(),i=t.fields.findIndex(f=>f.name===key);if(i<0)throw Error('unknown JSON record field');if(spans[i])throw Error('duplicate JSON record field');if(!p.eat(':'))throw Error('JSON record colon');const at=w.position;read(t.fields[i].type,w,d+1);spans[i]=[at,w.position];if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON record separator');}
    if(spans.some(s=>s===null))throw Error('missing JSON record field');w.reorder(start,spans);return;
   }
   if(t.kind==='option'||t.kind==='result'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON tagged value');const key=p.string();if(!p.eat(':'))throw Error('JSON tag colon');
    if(t.kind==='option'&&key==='None'){if(p.leaf(d+1)!==null)throw Error('JSON None payload');w.byte(0);}
    else{const child=t.kind==='option'&&key==='Some'?t.element:t.kind==='result'&&key==='Ok'?t.ok:t.kind==='result'&&key==='Err'?t.error:null;if(!child)throw Error('invalid JSON tag');w.byte(key==='Ok'?0:1);read(child,w,d+1);}
    if(!p.eat('}'))throw Error('expected exactly one JSON tag');return;
   }
   const ch=p.peek(),v=p.leaf(d),bad=()=>{throw Error('JSON does not match '+t.kind);};
   if(t.kind==='unit'){if(v!==null)bad();return;}
   if(t.kind==='bool'){if(typeof v!=='boolean')bad();w.byte(+v);return;}
   if(['string','id','enum'].includes(t.kind)){if(ch!=='"')bad();w.text(v);return;}
   if(ch!=='-'&&!(ch>='0'&&ch<='9'))bad();
   if(t.kind==='int'){w.text(jsonInteger(v,4096));return;}
   if(t.kind==='f64'){const n=Number(v);if(!Number.isFinite(n))throw Error('JSON f64 overflow');const b=new DataView(new ArrayBuffer(8));b.setFloat64(0,n,true);w.wide(b.getBigUint64(0,true));}
   else if(t.kind==='f32'){jsonFloatScratch.setFloat32(0,Number(v),true);if(!Number.isFinite(jsonFloatScratch.getFloat32(0,true)))throw Error('JSON f32 overflow');w.word(jsonFloatScratch.getUint32(0,true));}
   else{const n=BigInt(jsonInteger(v,t.kind==='u64'?20:10));if(t.kind==='u64'){if(n<0n||n>18446744073709551615n)bad();w.wide(n);}else if(t.kind==='u32'){if(n<0n||n>4294967295n)bad();w.word(Number(n));}else if(t.kind==='i32'){if(n< -2147483648n||n>2147483647n)bad();w.word(Number(n)>>>0);}else bad();}
  });
 };
 return (compact?values.compact():values).encodeWith(w=>{if(typed)read(values.descriptor.root,w,0);else json(w,0);p.finish();},options);
}

// Render validated bytes in a single traversal; only the final text is owned.
function streamWireJsonText(values,bytes,options,library){
 values.validate(bytes,options);const l=checkedJsonLimits(options),parts=[];let size=0,remaining=l.nodes;const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 const emit=s=>{size+=jsonUtf8Length(s);if(size>l.bytes)throw Error('JSON byte limit');parts.push(s);};
 const string=s=>emit(JSON.stringify(s));const node=d=>{if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');};
 const frame=(type,at)=>{const t=values.resolve(type),start=at+4,end=start+dv.getUint32(at,true);return{t,start,end};};
 const json=(type,at,d)=>{
  node(d);let root=frame(type,at),sum=frame(root.t.fields[0].type,root.start),index=0;
  while(index<5){const err=bytes[sum.start];sum=frame(err?sum.t.error:sum.t.ok,sum.start+1);if(!err)break;index++;}
  if(index===0){emit('null');return root.end;}
  const item=frame(sum.t.fields[0].type,sum.start);
  if(index===1)emit(bytes[item.start]?'true':'false');
  else if(index===2){const token=decoder.decode(bytes.subarray(item.start,item.end));if(!jsonNumberToken(token))throw Error('invalid JSON number token');emit(token);}
  else if(index===3)string(decoder.decode(bytes.subarray(item.start,item.end)));
  else{const count=dv.getUint32(item.start,true);let p=item.start+4;emit(index===4?'[':'{');const seen=new Set();for(let i=0;i<count;i++){if(i)emit(',');if(index===4)p=json(item.t.element,p,d+1);else{const member=frame(item.t.element,p),key=frame(member.t.fields[0].type,member.start),name=decoder.decode(bytes.subarray(key.start,key.end));if(seen.has(name))throw Error('duplicate JSON object key');seen.add(name);string(name);emit(':');json(member.t.fields[1].type,key.end,d+1);p=member.end;}}emit(index===4?']':'}');}
  return root.end;
 };
 const typed=(type,at,d)=>{
  node(d);const f=frame(type,at),t=f.t;let p=f.start;
  switch(t.kind){
   case 'unit':emit('null');break;
   case 'bool':emit(bytes[p]?'true':'false');break;
   case 'u32':emit(String(dv.getUint32(p,true)));break;
   case 'u64':emit(String(dv.getBigUint64(p,true)));break;
   case 'i32':emit(String(dv.getInt32(p,true)));break;
   case 'f64':{const n=dv.getFloat64(p,true);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'f32':{const n=dv.getFloat32(p,true);if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'int':emit(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'string':case 'id':case 'enum':string(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'list':case 'vector':{const n=dv.getUint32(p,true);p+=4;emit('[');for(let i=0;i<n;i++){if(i)emit(',');p=typed(t.element,p,d+1);}emit(']');break;}
   case 'record':emit('{');for(let i=0;i<t.fields.length;i++){if(i)emit(',');const field=t.fields[i];string(field.name);emit(':');p=typed(field.type,p,d+1);}emit('}');break;
   case 'option':case 'result':{const tag=bytes[p++],key=t.kind==='option'?(tag?'Some':'None'):tag?'Err':'Ok';emit('{');string(key);emit(':');if(t.kind==='option'&&!tag){node(d+1);emit('null');}else typed(t.kind==='option'?t.element:tag?t.error:t.ok,p,d+1);emit('}');break;}
   default:throw Error('unsupported typed JSON descriptor');
  }return f.end;
 };
 if(library)json(values.descriptor.root,40,0);else typed(values.descriptor.root,40,0);return parts.join('');
}

/** Owned, optional read view of arbitrary JSON. Auxiliary indexes contain member
 * offsets only. Logical order, exact number tokens and missing/null remain intact.
 * This does not transparently replace any compiled Ink action or its state.
 */
export function createJsonLookup(text,{stepEntries=16,minReads=4,maxEntries=4096,maxObjects=64,maxIndexBytes=262144,...limits}={}){
 for(const [v,max]of [[stepEntries,4096],[minReads,1000000],[maxEntries,1000000],[maxObjects,256],[maxIndexBytes,16777216]])if(!Number.isSafeInteger(v)||v<0||v>max)throw Error('JSON index budget');
 let root=parseJson(text,limits),indexes=new Map(),entries=0,indexBytes=0;
 const stats={reads:0,writes:0,scanned_members:0,index_hits:0,built_entries:0,invalidations:0};
 function parts(path){
  if(!Array.isArray(path))throw Error('JSON lookup path');const n=path.length;if(n>128)throw Error('JSON lookup path');
  const owned=[];for(let i=0;i<n;i++){const d=Object.getOwnPropertyDescriptor(path,String(i));if(!d||!Object.hasOwn(d,'value'))throw Error('JSON lookup path');const p=d.value;if(!(typeof p==='string'&&p.isWellFormed()&&p.length<=4096)&&!(Number.isSafeInteger(p)&&p>=0))throw Error('JSON lookup path');owned.push(p);}return owned;
 }
 function variant(value){let p=value.payload,index=0;while(index<5&&Object.hasOwn(p,'Err')){p=p.Err;index++;}return {index,item:(index<5?p.Ok:p).item0};}
 function resolve(document,path,indexed){
  let value=document,budget=stepEntries;
  for(let depth=0;depth<path.length;depth++){
   const part=path[depth],v=variant(value);
   if(typeof part==='number'){
    if(v.index!==4)throw Error('expected JSON array');if(part>=v.item.length)return {found:false};value=v.item[part];continue;
   }
   if(v.index!==5)throw Error('expected JSON object');
   const prefix=path.slice(0,depth),key=JSON.stringify(prefix),overhead=128+prefix.reduce((n,p)=>n+(typeof p==='string'?16+p.length*2:8),0);let idx=indexed?indexes.get(key):null;
   if(indexed&&!idx&&indexes.size<maxObjects&&indexBytes+overhead<=maxIndexBytes){idx={path:prefix,reads:0,cursor:0,keys:new Map(),bytes:overhead};indexes.set(key,idx);indexBytes+=overhead;}
   if(idx){
    idx.reads++;
    if(idx.reads>=minReads)while(budget>0&&idx.cursor<v.item.length&&entries<maxEntries){
     const member=v.item[idx.cursor],bytes=64+member.key.length*2;
     if(indexBytes+bytes>maxIndexBytes)break;
     idx.keys.set(member.key,idx.cursor++);idx.bytes+=bytes;indexBytes+=bytes;entries++;stats.built_entries++;budget--;
    }
    if(idx.keys.has(part)){stats.index_hits++;value=v.item[idx.keys.get(part)].value;continue;}
   }
   let found=false;
   for(let i=idx?.cursor??0;i<v.item.length;i++){if(indexed)stats.scanned_members++;if(v.item[i].key===part){value=v.item[i].value;found=true;break;}}
   if(!found)return {found:false};
  }
  return {found:true,value};
 }
 return {
  lookup(path){stats.reads++;const r=resolve(root,parts(path),true);return r.found?{found:true,value:structuredClone(r.value)}:r;},
  set(path,key,text){
   path=parts(path);if(typeof key!=='string'||!key.isWellFormed())throw Error('JSON object key');
   const replacement=parseJson(text,limits),next=structuredClone(root),r=resolve(next,path,false);
   if(!r.found)throw Error('JSON update path missing');const object=variant(r.value);if(object.index!==5)throw Error('expected JSON object');
   const members=[{key,value:replacement},...object.item.filter(m=>m.key!==key)];
   // Validate the complete resulting document before publishing a write.
   let payload=r.value.payload;for(let i=0;i<5;i++)payload=payload.Err;payload.item0=members;
   stringifyJson(next,limits);root=next;stats.writes++;
   for(const [id,idx]of indexes)if(idx.path.length>=path.length&&path.every((p,i)=>p===idx.path[i])){entries-=idx.keys.size;indexBytes-=idx.bytes;indexes.delete(id);stats.invalidations++;}
  },
  replace(text){const next=parseJson(text,limits);root=next;stats.writes++;stats.invalidations+=indexes.size;indexes.clear();entries=0;indexBytes=0;},
  stringify(){return stringifyJson(root,limits);},
  stats(){return {...stats,index_entries:entries,index_objects:indexes.size,index_bytes:indexBytes};}
 };
}
function __ownedValue5(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__ownedValue6(value.Some,budget,depth+1)};}
function __ownedValue2(value,budget,depth){budget.enter(depth,4);return {["a"]:__ownedValue0(value["a"],budget,depth+1),["b"]:__ownedValue0(value["b"],budget,depth+1)};}
function __ownedValue1(value,budget,depth){budget.enter(depth,4);return {["p"]:__ownedValue2(value["p"],budget,depth+1),["q"]:__ownedValue2(value["q"],budget,depth+1),["r"]:__ownedValue2(value["r"],budget,depth+1),["s"]:__ownedValue2(value["s"],budget,depth+1),["t"]:__ownedValue2(value["t"],budget,depth+1),["u"]:__ownedValue2(value["u"],budget,depth+1)};}
function __ownedValue8(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue0(value["value"],budget,depth+1),["tangent"]:__ownedValue0(value["tangent"],budget,depth+1)};}
function __ownedValue7(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue0(value["value"],budget,depth+1),["tangent_0"]:__ownedValue0(value["tangent_0"],budget,depth+1),["tangent_1"]:__ownedValue0(value["tangent_1"],budget,depth+1),["tangent_2"]:__ownedValue0(value["tangent_2"],budget,depth+1),["tangent_3"]:__ownedValue0(value["tangent_3"],budget,depth+1),["tangent_4"]:__ownedValue0(value["tangent_4"],budget,depth+1),["tangent_5"]:__ownedValue0(value["tangent_5"],budget,depth+1),["tangent_6"]:__ownedValue0(value["tangent_6"],budget,depth+1),["tangent_7"]:__ownedValue0(value["tangent_7"],budget,depth+1),["tangent_8"]:__ownedValue0(value["tangent_8"],budget,depth+1),["tangent_9"]:__ownedValue0(value["tangent_9"],budget,depth+1),["tangent_10"]:__ownedValue0(value["tangent_10"],budget,depth+1),["tangent_11"]:__ownedValue0(value["tangent_11"],budget,depth+1)};}
function __ownedValue3(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue4(value["value"],budget,depth+1),["previous"]:__ownedValue5(value["previous"],budget,depth+1)};}
function __ownedValue0(value,budget,depth){budget.enter(depth,8);return {F32Bits:value===0?0:value};}
function __ownedValue6(value,budget,depth){return __ownedValue3(value,budget,depth);}
function __ownedValue4(value,budget,depth){budget.enter(depth,8);return value>>>0;}
const __ownedFunctions=Object.freeze(Object.fromEntries([["component",__ownedValue0],["energy",__ownedValue0],["derivatives",__ownedValue1],["direction",__ownedValue0],["twice",__ownedValue0],["selected",__ownedValue2],["branches",__ownedValue2],["looping",__ownedValue2],["strict_unused",__ownedValue0],["strict",__ownedValue0],["history",__ownedValue3],["__ink_differential_3",__ownedValue7],["__ink_differential_1",__ownedValue1],["__ink_differential_23",__ownedValue8],["__ink_differential_27",__ownedValue8],["__ink_differential_31",__ownedValue8],["__ink_differential_20",__ownedValue8],["__ink_differential_19",__ownedValue0]]));
function __wireValue22(reader){const end=reader.frame();const value=reader.byte()?{Some:__wireValue21(reader)}:{None:null};reader.finish(end);return value;}
function __wireValue9(reader){const end=reader.frame();const value={["__ink_differential_24"]:__wireValue8(reader),["__ink_differential_25"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue10(reader){const end=reader.frame();const value={["__ink_differential_28"]:__wireValue8(reader),["__ink_differential_29"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue15(reader){const end=reader.frame();const value={["__ink_differential_32"]:__wireValue8(reader),["__ink_differential_33"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue7(reader){const end=reader.frame();const value={["a"]:__wireValue8(reader),["b"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue13(reader){const end=reader.frame();const value={["a"]:__wireValue14(reader),["b"]:__wireValue14(reader)};reader.finish(end);return value;}
function __wireValue2(reader){const end=reader.frame();const value={["a"]:__wireValue3(reader),["b"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue6(reader){const end=reader.frame();const value={["p"]:__wireValue7(reader),["q"]:__wireValue7(reader),["r"]:__wireValue7(reader),["s"]:__wireValue7(reader),["t"]:__wireValue7(reader),["u"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue12(reader){const end=reader.frame();const value={["p"]:__wireValue13(reader),["q"]:__wireValue13(reader),["r"]:__wireValue13(reader),["s"]:__wireValue13(reader),["t"]:__wireValue13(reader),["u"]:__wireValue13(reader)};reader.finish(end);return value;}
function __wireValue1(reader){const end=reader.frame();const value={["p"]:__wireValue2(reader),["q"]:__wireValue2(reader),["r"]:__wireValue2(reader),["s"]:__wireValue2(reader),["t"]:__wireValue2(reader),["u"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue8(reader){const end=reader.frame();const value={["value"]:__wireValue3(reader),["tangent"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue14(reader){const end=reader.frame();const value={["value"]:__wireValue3(reader),["tangent_0"]:__wireValue3(reader),["tangent_1"]:__wireValue3(reader),["tangent_2"]:__wireValue3(reader),["tangent_3"]:__wireValue3(reader),["tangent_4"]:__wireValue3(reader),["tangent_5"]:__wireValue3(reader),["tangent_6"]:__wireValue3(reader),["tangent_7"]:__wireValue3(reader),["tangent_8"]:__wireValue3(reader),["tangent_9"]:__wireValue3(reader),["tangent_10"]:__wireValue3(reader),["tangent_11"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue21(reader){const end=reader.frame();const value={["value"]:__wireValue20(reader),["previous"]:__wireValue22(reader)};reader.finish(end);return value;}
function __wireValue24(reader){const end=reader.frame();const value={["w"]:__wireValue2(reader),["c"]:__wireValue17(reader)};reader.finish(end);return value;}
function __wireValue18(reader){const end=reader.frame();const value={["w"]:__wireValue2(reader),["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue26(reader){const end=reader.frame();const value={["w"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue5(reader){const end=reader.frame();const value={["w"]:__wireValue6(reader),["x"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue11(reader){const end=reader.frame();const value={["w"]:__wireValue12(reader),["x"]:__wireValue14(reader)};reader.finish(end);return value;}
function __wireValue4(reader){const end=reader.frame();const value={["w"]:__wireValue1(reader),["__ink_differential_35"]:__wireValue1(reader),["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue0(reader){const end=reader.frame();const value={["w"]:__wireValue1(reader),["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue16(reader){const end=reader.frame();const value={["x"]:__wireValue3(reader),["c"]:__wireValue17(reader)};reader.finish(end);return value;}
function __wireValue25(reader){const end=reader.frame();const value={["x"]:__wireValue3(reader),["y"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue23(reader){const end=reader.frame();const value={["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue19(reader){const end=reader.frame();const value={["x"]:__wireValue20(reader)};reader.finish(end);return value;}
function __wireValue17(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __wireValue3(reader){const end=reader.frame();const value={F32Bits:reader.word()};reader.finish(end);return value;}
function __wireValue20(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
const __wireReaders=Object.freeze(Object.fromEntries([["__ink_differential_1",[__wireValue0,__wireValue1]],["__ink_differential_19",[__wireValue4,__wireValue3]],["__ink_differential_20",[__wireValue5,__wireValue8]],["__ink_differential_23",[__wireValue9,__wireValue8]],["__ink_differential_27",[__wireValue10,__wireValue8]],["__ink_differential_3",[__wireValue11,__wireValue14]],["__ink_differential_31",[__wireValue15,__wireValue8]],["branches",[__wireValue16,__wireValue2]],["component",[__wireValue18,__wireValue3]],["derivatives",[__wireValue0,__wireValue1]],["direction",[__wireValue0,__wireValue3]],["energy",[__wireValue0,__wireValue3]],["history",[__wireValue19,__wireValue21]],["looping",[__wireValue23,__wireValue2]],["selected",[__wireValue24,__wireValue2]],["strict",[__wireValue25,__wireValue3]],["strict_unused",[__wireValue26,__wireValue3]],["twice",[__wireValue26,__wireValue3]]]));
const __ownedImplementations=Object.freeze(Object.fromEntries([["component",(()=>{const c0=__representation(__inputTypes[0].types[0],false,__inputTypes[0].capture[0]);const c1=__representation(__inputTypes[0].types[1],false,__inputTypes[0].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn0;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn0(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn0(v0,v1);};})()],
["energy",(()=>{const c0=__representation(__inputTypes[1].types[0],false,__inputTypes[1].capture[0]);const c1=__representation(__inputTypes[1].types[1],false,__inputTypes[1].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn1;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn1(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn1(v0,v1);};})()],
["derivatives",(()=>{const c0=__representation(__inputTypes[2].types[0],false,__inputTypes[2].capture[0]);const c1=__representation(__inputTypes[2].types[1],false,__inputTypes[2].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn2;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn2(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn2(v0,v1);};})()],
["direction",(()=>{const c0=__representation(__inputTypes[3].types[0],false,__inputTypes[3].capture[0]);const c1=__representation(__inputTypes[3].types[1],false,__inputTypes[3].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn3;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn3(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn3(v0,v1);};})()],
["twice",(()=>{const c0=__representation(__inputTypes[4].types[0],false,__inputTypes[4].capture[0]);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity)return __fn4;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn4(...values);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return __fn4(v0);};})()],
["selected",(()=>{const c0=__representation(__inputTypes[5].types[0],false,__inputTypes[5].capture[0]);const c1=__representation(__inputTypes[5].types[1],false,__inputTypes[5].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn5;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn5(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn5(v0,v1);};})()],
["branches",(()=>{const c0=__representation(__inputTypes[6].types[0],false,__inputTypes[6].capture[0]);const c1=__representation(__inputTypes[6].types[1],false,__inputTypes[6].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=false;if(c0===__identity&&c1===__identity)return __fn6;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn6(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn6(v0,v1);};})()],
["looping",(()=>{const c0=__representation(__inputTypes[7].types[0],false,__inputTypes[7].capture[0]);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=false;if(c0===__identity)return __fn7;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn7(...values);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return __fn7(v0);};})()],
["strict_unused",(()=>{const c0=__representation(__inputTypes[8].types[0],false,__inputTypes[8].capture[0]);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity)return __fn8;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn8(...values);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return __fn8(v0);};})()],
["strict",(()=>{const c0=__representation(__inputTypes[9].types[0],false,__inputTypes[9].capture[0]);const c1=__representation(__inputTypes[9].types[1],false,__inputTypes[9].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=false;if(c0===__identity&&c1===__identity)return __fn9;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn9(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn9(v0,v1);};})()],
["history",(()=>{const c0=__representation(__inputTypes[10].types[0],false,__inputTypes[10].capture[0]);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=false;if(c0===__identity)return __fn10;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn10(...values);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return __fn10(v0);};})()],
["__ink_differential_3",(()=>{const c0=__representation(__inputTypes[12].types[0],false,__inputTypes[12].capture[0]);const c1=__representation(__inputTypes[12].types[1],false,__inputTypes[12].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity)return __fn12;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn12(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn12(v0,v1);};})()],
["__ink_differential_1",(()=>{const c0=__representation(__inputTypes[13].types[0],false,__inputTypes[13].capture[0]);const c1=__representation(__inputTypes[13].types[1],false,__inputTypes[13].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn13;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn13(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn13(v0,v1);};})()],
["__ink_differential_23",(()=>{const c0=__representation(__inputTypes[14].types[0],false,__inputTypes[14].capture[0]);const c1=__representation(__inputTypes[14].types[1],false,__inputTypes[14].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity)return __fn14;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn14(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn14(v0,v1);};})()],
["__ink_differential_27",(()=>{const c0=__representation(__inputTypes[15].types[0],false,__inputTypes[15].capture[0]);const c1=__representation(__inputTypes[15].types[1],false,__inputTypes[15].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity)return __fn15;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn15(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn15(v0,v1);};})()],
["__ink_differential_31",(()=>{const c0=__representation(__inputTypes[16].types[0],false,__inputTypes[16].capture[0]);const c1=__representation(__inputTypes[16].types[1],false,__inputTypes[16].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity)return __fn16;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn16(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn16(v0,v1);};})()],
["__ink_differential_20",(()=>{const c0=__representation(__inputTypes[17].types[0],false,__inputTypes[17].capture[0]);const c1=__representation(__inputTypes[17].types[1],false,__inputTypes[17].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity)return __fn17;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn17(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn17(v0,v1);};})()],
["__ink_differential_19",(()=>{const c0=__representation(__inputTypes[18].types[0],false,__inputTypes[18].capture[0]);const c1=__representation(__inputTypes[18].types[1],false,__inputTypes[18].capture[1]);const c2=__representation(__inputTypes[18].types[2],false,__inputTypes[18].capture[2]);const input=[c0,c1,c2],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity&&c2===__identity)return __fn18;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn18(...values);};return function(a0,a1,a2){if(arguments.length!==3)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object')+Number(c2!==__identity&&a2!==null&&typeof a2==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);const v2=c2(a2,context);return __fn18(v0,v1,v2);};})()]]));

export const valueCodecs=(()=>{const codecs={};for(const [name,s] of Object.entries(metadata.wire.functions)){if(s.unsupported)continue;let value;Object.defineProperty(codecs,name,{enumerable:true,get:()=>value??=(Object.freeze(Object.hasOwn(__wireReaders,name)?{arguments:createCompiledValueCodec(s.arguments,__wireReaders[name][0]),result:createCompiledValueCodec(s.result,__wireReaders[name][1])}:{arguments:new ValueCodec(s.arguments),result:new ValueCodec(s.result)}))});}return Object.freeze(codecs);})();
function __callEncoded(name,bytes,limits,compact){
 const f=metadata.functions.find(f=>f.name===name&&!f.internal),codecs=valueCodecs[name];
 if(!f||!codecs)throw Error('unsupported binary function');
 const input=compact?codecs.arguments.compact():codecs.arguments,output=compact?codecs.result.compact():codecs.result;
 const entry=__compiledEntries.get(name);
 if(entry){
  const slot=compact?1:0;
  entry.argumentCodecs[slot]??=(entry.boundaryReaders[slot]?createFusedValueCodec:createCompiledValueCodec)(metadata.wire.functions[name].arguments,entry.arguments);
  const decoder=entry.argumentCodecs[slot];
  const values=(compact?decoder.compact():decoder).decode(bytes,limits),args=f.params.map(p=>values[p.name]);
  if(entry.precondition!==null&&__implementations[entry.precondition](...args)!==true)throw Error('contract precondition failed');
  return __compiledEncodeResult(entry,__implementations[entry.index](...args),limits,compact);
 }
 const values=input.decode(bytes,limits);
 const result=call(name,f.params.map(p=>values[p.name]));
 return output.encode(result,limits);
}
export function callBinary(name,bytes,limits={}){return __callEncoded(name,bytes,limits,false);}
export function callCompact(name,bytes,limits={}){return __callEncoded(name,bytes,limits,true);}
// Same stable, well-typed caller inputs as call; the result owns every container.
// The checked source return type justifies trusted copying, not arbitrary input.
export function callOwned(name,args,limits={}){
 if(!Object.hasOwn(__ownedFunctions,name)||!Object.hasOwn(functions,name))throw Error('unsupported owned function');
 const result=__ownedImplementations[name](...args);return __ownedFunctions[name](result,createValueCaptureBudget(limits),0);
}
function __privateCapture6(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if((value!==null&&typeof value==='object'&&Object.hasOwn(value,'None')&&Object.keys(value).length===1)&&value.None===null)return {None:null};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Some')&&Object.keys(value).length===1)return {Some:__privateCapture5(value.Some,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture12(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture10(value["a"],budget,depth+1),["b"]:__privateCapture10(value["b"],budget,depth+1)};}
function __privateCapture8(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture9(value["a"],budget,depth+1),["b"]:__privateCapture9(value["b"],budget,depth+1)};}
function __privateCapture0(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture1(value["a"],budget,depth+1),["b"]:__privateCapture1(value["b"],budget,depth+1)};}
function __privateCapture11(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"p")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"q")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"r")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"s")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"t")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"u")){throw Error('invalid value for wire schema');}return {["p"]:__privateCapture12(value["p"],budget,depth+1),["q"]:__privateCapture12(value["q"],budget,depth+1),["r"]:__privateCapture12(value["r"],budget,depth+1),["s"]:__privateCapture12(value["s"],budget,depth+1),["t"]:__privateCapture12(value["t"],budget,depth+1),["u"]:__privateCapture12(value["u"],budget,depth+1)};}
function __privateCapture7(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"p")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"q")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"r")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"s")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"t")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"u")){throw Error('invalid value for wire schema');}return {["p"]:__privateCapture8(value["p"],budget,depth+1),["q"]:__privateCapture8(value["q"],budget,depth+1),["r"]:__privateCapture8(value["r"],budget,depth+1),["s"]:__privateCapture8(value["s"],budget,depth+1),["t"]:__privateCapture8(value["t"],budget,depth+1),["u"]:__privateCapture8(value["u"],budget,depth+1)};}
function __privateCapture2(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"p")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"q")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"r")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"s")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"t")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"u")){throw Error('invalid value for wire schema');}return {["p"]:__privateCapture0(value["p"],budget,depth+1),["q"]:__privateCapture0(value["q"],budget,depth+1),["r"]:__privateCapture0(value["r"],budget,depth+1),["s"]:__privateCapture0(value["s"],budget,depth+1),["t"]:__privateCapture0(value["t"],budget,depth+1),["u"]:__privateCapture0(value["u"],budget,depth+1)};}
function __privateCapture10(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["tangent"]:__privateCapture1(value["tangent"],budget,depth+1)};}
function __privateCapture9(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==13){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_0")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_1")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_2")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_3")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_4")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_5")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_6")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_7")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_8")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_9")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_10")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_11")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["tangent_0"]:__privateCapture1(value["tangent_0"],budget,depth+1),["tangent_1"]:__privateCapture1(value["tangent_1"],budget,depth+1),["tangent_2"]:__privateCapture1(value["tangent_2"],budget,depth+1),["tangent_3"]:__privateCapture1(value["tangent_3"],budget,depth+1),["tangent_4"]:__privateCapture1(value["tangent_4"],budget,depth+1),["tangent_5"]:__privateCapture1(value["tangent_5"],budget,depth+1),["tangent_6"]:__privateCapture1(value["tangent_6"],budget,depth+1),["tangent_7"]:__privateCapture1(value["tangent_7"],budget,depth+1),["tangent_8"]:__privateCapture1(value["tangent_8"],budget,depth+1),["tangent_9"]:__privateCapture1(value["tangent_9"],budget,depth+1),["tangent_10"]:__privateCapture1(value["tangent_10"],budget,depth+1),["tangent_11"]:__privateCapture1(value["tangent_11"],budget,depth+1)};}
function __privateCapture5(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"previous")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture4(value["value"],budget,depth+1),["previous"]:__privateCapture6(value["previous"],budget,depth+1)};}
function __privateCapture3(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='boolean'){throw Error('invalid value for wire schema');}budget.add(1);return value;}
function __privateCapture1(value,budget,depth=0){budget.enter(depth,4);let bits;if(typeof value==='number'&&Number.isFinite(value)){bits=__bits(value);if(!Number.isFinite(__float(bits))){throw Error('invalid value for wire schema');}}else{if(!(value!==null&&typeof value==='object'&&Object.hasOwn(value,'F32Bits')&&Object.keys(value).length===1)){throw Error('invalid value for wire schema');}bits=value.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295){throw Error('invalid value for wire schema');}}budget.add(4);return bits===0?0:bits;}
function __privateCapture4(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='number'||!Number.isInteger(value)||value<0||value>4294967295){throw Error('invalid value for wire schema');}budget.add(4);return value===0?0:value;}
function __privateWireValue13(reader){const end=reader.frame();const value=reader.byte()?{Some:__privateWireValue12(reader)}:{None:null};reader.finish(end);return value;}
function __privateWireValue20(reader){const end=reader.frame();const value={["__ink_differential_24"]:__privateWireValue19(reader),["__ink_differential_25"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue21(reader){const end=reader.frame();const value={["__ink_differential_28"]:__privateWireValue19(reader),["__ink_differential_29"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue22(reader){const end=reader.frame();const value={["__ink_differential_32"]:__privateWireValue19(reader),["__ink_differential_33"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue24(reader){const end=reader.frame();const value={["a"]:__privateWireValue19(reader),["b"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue16(reader){const end=reader.frame();const value={["a"]:__privateWireValue17(reader),["b"]:__privateWireValue17(reader)};reader.finish(end);return value;}
function __privateWireValue0(reader){const end=reader.frame();const value={["a"]:__privateWireValue1(reader),["b"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue23(reader){const end=reader.frame();const value={["p"]:__privateWireValue24(reader),["q"]:__privateWireValue24(reader),["r"]:__privateWireValue24(reader),["s"]:__privateWireValue24(reader),["t"]:__privateWireValue24(reader),["u"]:__privateWireValue24(reader)};reader.finish(end);return value;}
function __privateWireValue15(reader){const end=reader.frame();const value={["p"]:__privateWireValue16(reader),["q"]:__privateWireValue16(reader),["r"]:__privateWireValue16(reader),["s"]:__privateWireValue16(reader),["t"]:__privateWireValue16(reader),["u"]:__privateWireValue16(reader)};reader.finish(end);return value;}
function __privateWireValue3(reader){const end=reader.frame();const value={["p"]:__privateWireValue0(reader),["q"]:__privateWireValue0(reader),["r"]:__privateWireValue0(reader),["s"]:__privateWireValue0(reader),["t"]:__privateWireValue0(reader),["u"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue19(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["tangent"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue17(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["tangent_0"]:__privateWireValue1(reader),["tangent_1"]:__privateWireValue1(reader),["tangent_2"]:__privateWireValue1(reader),["tangent_3"]:__privateWireValue1(reader),["tangent_4"]:__privateWireValue1(reader),["tangent_5"]:__privateWireValue1(reader),["tangent_6"]:__privateWireValue1(reader),["tangent_7"]:__privateWireValue1(reader),["tangent_8"]:__privateWireValue1(reader),["tangent_9"]:__privateWireValue1(reader),["tangent_10"]:__privateWireValue1(reader),["tangent_11"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue12(reader){const end=reader.frame();const value={["value"]:__privateWireValue11(reader),["previous"]:__privateWireValue13(reader)};reader.finish(end);return value;}
function __privateWireValue7(reader){const end=reader.frame();const value={["w"]:__privateWireValue0(reader),["c"]:__privateWireValue6(reader)};reader.finish(end);return value;}
function __privateWireValue2(reader){const end=reader.frame();const value={["w"]:__privateWireValue0(reader),["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue5(reader){const end=reader.frame();const value={["w"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue25(reader){const end=reader.frame();const value={["w"]:__privateWireValue23(reader),["x"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue18(reader){const end=reader.frame();const value={["w"]:__privateWireValue15(reader),["x"]:__privateWireValue17(reader)};reader.finish(end);return value;}
function __privateWireValue26(reader){const end=reader.frame();const value={["w"]:__privateWireValue3(reader),["__ink_differential_35"]:__privateWireValue3(reader),["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue4(reader){const end=reader.frame();const value={["w"]:__privateWireValue3(reader),["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue8(reader){const end=reader.frame();const value={["x"]:__privateWireValue1(reader),["c"]:__privateWireValue6(reader)};reader.finish(end);return value;}
function __privateWireValue10(reader){const end=reader.frame();const value={["x"]:__privateWireValue1(reader),["y"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue9(reader){const end=reader.frame();const value={["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue14(reader){const end=reader.frame();const value={["x"]:__privateWireValue11(reader)};reader.finish(end);return value;}
function __privateWireValue6(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __privateWireValue1(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __privateWireValue11(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __compiledOwnedValue6(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__compiledOwnedValue7(value.Some,budget,depth+1)};}
function __compiledOwnedValue13(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue11(value["a"],budget,depth+1),["b"]:__compiledOwnedValue11(value["b"],budget,depth+1)};}
function __compiledOwnedValue9(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue10(value["a"],budget,depth+1),["b"]:__compiledOwnedValue10(value["b"],budget,depth+1)};}
function __compiledOwnedValue0(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue1(value["a"],budget,depth+1),["b"]:__compiledOwnedValue1(value["b"],budget,depth+1)};}
function __compiledOwnedValue12(value,budget,depth){budget.enter(depth,4);return {["p"]:__compiledOwnedValue13(value["p"],budget,depth+1),["q"]:__compiledOwnedValue13(value["q"],budget,depth+1),["r"]:__compiledOwnedValue13(value["r"],budget,depth+1),["s"]:__compiledOwnedValue13(value["s"],budget,depth+1),["t"]:__compiledOwnedValue13(value["t"],budget,depth+1),["u"]:__compiledOwnedValue13(value["u"],budget,depth+1)};}
function __compiledOwnedValue8(value,budget,depth){budget.enter(depth,4);return {["p"]:__compiledOwnedValue9(value["p"],budget,depth+1),["q"]:__compiledOwnedValue9(value["q"],budget,depth+1),["r"]:__compiledOwnedValue9(value["r"],budget,depth+1),["s"]:__compiledOwnedValue9(value["s"],budget,depth+1),["t"]:__compiledOwnedValue9(value["t"],budget,depth+1),["u"]:__compiledOwnedValue9(value["u"],budget,depth+1)};}
function __compiledOwnedValue2(value,budget,depth){budget.enter(depth,4);return {["p"]:__compiledOwnedValue0(value["p"],budget,depth+1),["q"]:__compiledOwnedValue0(value["q"],budget,depth+1),["r"]:__compiledOwnedValue0(value["r"],budget,depth+1),["s"]:__compiledOwnedValue0(value["s"],budget,depth+1),["t"]:__compiledOwnedValue0(value["t"],budget,depth+1),["u"]:__compiledOwnedValue0(value["u"],budget,depth+1)};}
function __compiledOwnedValue11(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["tangent"]:__compiledOwnedValue1(value["tangent"],budget,depth+1)};}
function __compiledOwnedValue10(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["tangent_0"]:__compiledOwnedValue1(value["tangent_0"],budget,depth+1),["tangent_1"]:__compiledOwnedValue1(value["tangent_1"],budget,depth+1),["tangent_2"]:__compiledOwnedValue1(value["tangent_2"],budget,depth+1),["tangent_3"]:__compiledOwnedValue1(value["tangent_3"],budget,depth+1),["tangent_4"]:__compiledOwnedValue1(value["tangent_4"],budget,depth+1),["tangent_5"]:__compiledOwnedValue1(value["tangent_5"],budget,depth+1),["tangent_6"]:__compiledOwnedValue1(value["tangent_6"],budget,depth+1),["tangent_7"]:__compiledOwnedValue1(value["tangent_7"],budget,depth+1),["tangent_8"]:__compiledOwnedValue1(value["tangent_8"],budget,depth+1),["tangent_9"]:__compiledOwnedValue1(value["tangent_9"],budget,depth+1),["tangent_10"]:__compiledOwnedValue1(value["tangent_10"],budget,depth+1),["tangent_11"]:__compiledOwnedValue1(value["tangent_11"],budget,depth+1)};}
function __compiledOwnedValue5(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue4(value["value"],budget,depth+1),["previous"]:__compiledOwnedValue6(value["previous"],budget,depth+1)};}
function __compiledOwnedValue3(value,budget,depth){budget.enter(depth,5);return value;}
function __compiledOwnedValue1(value,budget,depth){budget.enter(depth,8);return {F32Bits:value===0?0:value};}
function __compiledOwnedValue7(value,budget,depth){return __compiledOwnedValue5(value,budget,depth);}
function __compiledOwnedValue4(value,budget,depth){budget.enter(depth,8);return value>>>0;}
function __privateWireWrite6(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Some')){writer.byte(1);__privateWireWrite5(writer,value.Some,compact);}else{writer.byte(0);}writer.closeFrame(frame);}
function __privateWireWrite12(writer,value,compact){const frame=writer.openFrame();__privateWireWrite10(writer,value["a"],compact);__privateWireWrite10(writer,value["b"],compact);writer.closeFrame(frame);}
function __privateWireWrite8(writer,value,compact){const frame=writer.openFrame();__privateWireWrite9(writer,value["a"],compact);__privateWireWrite9(writer,value["b"],compact);writer.closeFrame(frame);}
function __privateWireWrite0(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["a"],compact);__privateWireWrite1(writer,value["b"],compact);writer.closeFrame(frame);}
function __privateWireWrite11(writer,value,compact){const frame=writer.openFrame();__privateWireWrite12(writer,value["p"],compact);__privateWireWrite12(writer,value["q"],compact);__privateWireWrite12(writer,value["r"],compact);__privateWireWrite12(writer,value["s"],compact);__privateWireWrite12(writer,value["t"],compact);__privateWireWrite12(writer,value["u"],compact);writer.closeFrame(frame);}
function __privateWireWrite7(writer,value,compact){const frame=writer.openFrame();__privateWireWrite8(writer,value["p"],compact);__privateWireWrite8(writer,value["q"],compact);__privateWireWrite8(writer,value["r"],compact);__privateWireWrite8(writer,value["s"],compact);__privateWireWrite8(writer,value["t"],compact);__privateWireWrite8(writer,value["u"],compact);writer.closeFrame(frame);}
function __privateWireWrite2(writer,value,compact){const frame=writer.openFrame();__privateWireWrite0(writer,value["p"],compact);__privateWireWrite0(writer,value["q"],compact);__privateWireWrite0(writer,value["r"],compact);__privateWireWrite0(writer,value["s"],compact);__privateWireWrite0(writer,value["t"],compact);__privateWireWrite0(writer,value["u"],compact);writer.closeFrame(frame);}
function __privateWireWrite10(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite1(writer,value["tangent"],compact);writer.closeFrame(frame);}
function __privateWireWrite9(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite1(writer,value["tangent_0"],compact);__privateWireWrite1(writer,value["tangent_1"],compact);__privateWireWrite1(writer,value["tangent_2"],compact);__privateWireWrite1(writer,value["tangent_3"],compact);__privateWireWrite1(writer,value["tangent_4"],compact);__privateWireWrite1(writer,value["tangent_5"],compact);__privateWireWrite1(writer,value["tangent_6"],compact);__privateWireWrite1(writer,value["tangent_7"],compact);__privateWireWrite1(writer,value["tangent_8"],compact);__privateWireWrite1(writer,value["tangent_9"],compact);__privateWireWrite1(writer,value["tangent_10"],compact);__privateWireWrite1(writer,value["tangent_11"],compact);writer.closeFrame(frame);}
function __privateWireWrite5(writer,value,compact){const frame=writer.openFrame();__privateWireWrite4(writer,value["value"],compact);__privateWireWrite6(writer,value["previous"],compact);writer.closeFrame(frame);}
function __privateWireWrite3(writer,value,compact){const frame=writer.openFrame();writer.byte(value?1:0);writer.closeFrame(frame);}
function __privateWireWrite1(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
function __privateWireWrite4(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
// Handles have no mutable private payload surface. Membership and type identity
// are checked by this module's closure; copied/foreign objects cannot forge them.
const __compiledHandles=new WeakMap();
const __compiledBindings=new WeakMap();
function __compiledHandle(identity,value,guaranteed=false){
 const handle=Object.freeze(Object.create(null));
 __compiledHandles.set(handle,{identity,value,guaranteed});return handle;
}
function __compiledEntry(handle,identity){
 const entry=__compiledHandles.get(handle);
 if(!entry||entry.identity!==identity)throw Error('compiled value type or owner mismatch');
 return entry;
}
function __compiledUnwrap(handle,identity){return __compiledEntry(handle,identity).value;}
// Emit the portable schema's framing/scalar events without creating a buffer
// or exposing private composite nodes. Only this wrapper receives callbacks
// from the literal writer; host visitors never receive those closures.
function __compiledValueEvents(sink,limits){
 const methods=['begin','end','byte','word','wide','text','count'];
 for(const name of methods)if(typeof sink?.[name]!=='function')throw Error('compiled value visitor method: '+name);
 const budget=createValueCaptureBudget(limits);let depth=0,closed=false;
 const active=()=>{if(closed)throw Error('compiled value visitor is closed');};
 const writer=Object.freeze({
  openFrame(){active();budget.enter(depth,4);depth++;sink.begin();return 0;}
  ,closeFrame(){active();if(depth===0)throw Error('wire frame boundary');try{sink.end();}finally{depth--;}}
  ,frame(emit){active();budget.enter(depth,4);depth++;sink.begin();try{emit();sink.end();}finally{depth--;}}
  ,byte(value){active();budget.add(1);sink.byte(value);}
  ,word(value){active();budget.add(4);sink.word(value);}
  ,wide(value){active();budget.add(8);sink.wide(value);}
  ,text(value){active();budget.text(value);sink.text(value);}
  ,count(value){active();budget.add(4);if(value>budget.remaining)throw Error('wire sequence size');sink.count(value);}
 });
 return {writer,close(){closed=true;}};
}
function __compiledReduction(factory,root,reduce,identity){
 if(typeof factory!=='function')throw Error('compiled reduction factory');
 const reducers=[],seen=new Set(),nodes=__reductionNodes();
 const prepare=index=>{
  if(seen.has(index))return;seen.add(index);
  const node=nodes[index];
  for(const child of node.children)prepare(child);
  const reducer=factory(node,index);
  if(node.kind==='list'||node.kind==='vector'){
   const start=reducer?.start,step=reducer?.step,finish=reducer?.finish;
   if(typeof start!=='function'||typeof step!=='function'||typeof finish!=='function')throw Error('compiled collection reduction');
   reducers[index]=Object.freeze({start,step,finish});
  }else{
   if(typeof reducer!=='function')throw Error('compiled value reduction');
   reducers[index]=reducer;
  }
 };
 prepare(root);Object.freeze(reducers);
 return Object.freeze(function(handle,context,limits={}){
  const value=__compiledUnwrap(handle,identity),budget=createValueCaptureBudget(limits);
  return reduce(value,reducers,budget,0,context);
 });
}
function __compiledCodec(schema,capture,read,write,copy,constructorRoot,reductionRoot,reduce,portableFused=false,compactFused=false){
 const privateCodec=createCompiledValueCodec(schema,read),publicCodec=privateCodec;
 let fusedCodec;const fused=()=>fusedCodec??=createFusedValueCodec(schema,read);
 const identity=schema.identity;
 const codec=Object.freeze({
  identity,
  descriptor:publicCodec.descriptor,
  resolve(type){return publicCodec.resolve(type);},
  capture(value,limits={}){
   return __compiledHandle(identity,capture(value,createValueCaptureBudget(limits),0));
  },
  decode(bytes,limits={}){return __compiledHandle(identity,(portableFused?fused():privateCodec).decode(bytes,limits));},
  decodeCompact(bytes,limits={}){return __compiledHandle(identity,(compactFused?fused():privateCodec).compact().decode(bytes,limits));},
  decodeFused(bytes,limits={}){return __compiledHandle(identity,fused().decode(bytes,limits));},
  decodeCompactFused(bytes,limits={}){return __compiledHandle(identity,fused().compact().decode(bytes,limits));},
  encode(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.encodeWith(writer=>write(writer,value,false),limits);},
  encodeCompact(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.compact().encodeWith(writer=>write(writer,value,true),limits);},
  materialize(handle,limits={}){return copy(__compiledUnwrap(handle,identity),createValueCaptureBudget(limits),0);},
  builder(limits={}){return __valueBuilder(__constructorNodes(),constructorRoot,identity,limits);},
  reducer(factory){return __compiledReduction(factory,reductionRoot,reduce,identity);},
  visit(handle,sink,limits={}){
   const value=__compiledUnwrap(handle,identity),events=__compiledValueEvents(sink,limits);
   try{write(events.writer,value,false);}finally{events.close();}
  },
 });
 __compiledBindings.set(codec,{publicCodec,write,capture});return codec;
}

function __compiledEncodeResult(entry,value,limits,compact){
 const {publicCodec,write}=__compiledBindings.get(entry.result());
 return (compact?publicCodec.compact():publicCodec).encodeWith(writer=>write(writer,value,compact),limits);
}
let __constructorNodesValue;function __constructorNodes(){return __constructorNodesValue??=[{kind:'record',fields:["a","b"],patterns:[{bytes:4,label:"record",children:[1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1]})}]},{kind:"f32",scalar:__privateCapture1},{kind:'record',fields:["p","q","r","s","t","u"],patterns:[{bytes:4,label:"record",children:[0,0,0,0,0,0],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["p"]:values[0],["q"]:values[1],["r"]:values[2],["s"]:values[3],["t"]:values[4],["u"]:values[5]})}]},{kind:"bool",scalar:__privateCapture3},{kind:"u32",scalar:__privateCapture4},{kind:'record',fields:["value","previous"],patterns:[{bytes:4,label:"record",children:[4,6],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["previous"]:values[1]})}]},{kind:'option',patterns:[{bytes:5,label:"None",children:[],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({None:null})},{bytes:5,label:"Some",children:[5],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({Some:values[0]})}]},{kind:'record',fields:["p","q","r","s","t","u"],patterns:[{bytes:4,label:"record",children:[8,8,8,8,8,8],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["p"]:values[0],["q"]:values[1],["r"]:values[2],["s"]:values[3],["t"]:values[4],["u"]:values[5]})}]},{kind:'record',fields:["a","b"],patterns:[{bytes:4,label:"record",children:[9,9],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1]})}]},{kind:'record',fields:["value","tangent_0","tangent_1","tangent_2","tangent_3","tangent_4","tangent_5","tangent_6","tangent_7","tangent_8","tangent_9","tangent_10","tangent_11"],patterns:[{bytes:4,label:"record",children:[1,1,1,1,1,1,1,1,1,1,1,1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["tangent_0"]:values[1],["tangent_1"]:values[2],["tangent_2"]:values[3],["tangent_3"]:values[4],["tangent_4"]:values[5],["tangent_5"]:values[6],["tangent_6"]:values[7],["tangent_7"]:values[8],["tangent_8"]:values[9],["tangent_9"]:values[10],["tangent_10"]:values[11],["tangent_11"]:values[12]})}]},{kind:'record',fields:["value","tangent"],patterns:[{bytes:4,label:"record",children:[1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["tangent"]:values[1]})}]},{kind:'record',fields:["p","q","r","s","t","u"],patterns:[{bytes:4,label:"record",children:[12,12,12,12,12,12],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["p"]:values[0],["q"]:values[1],["r"]:values[2],["s"]:values[3],["t"]:values[4],["u"]:values[5]})}]},{kind:'record',fields:["a","b"],patterns:[{bytes:4,label:"record",children:[10,10],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1]})}]}];}
// Typed input construction only: plans contain literal constructor/capture
// functions emitted from source schemas. No source expression evaluator.
// All frames and private values remain in this closure; callers receive only
// an owned opaque handle after one complete, well-typed root is constructed.
const __constructorPaths=new WeakMap();
function __valueBuilder(nodes,root,identity,limits){
 const budget=createValueCaptureBudget(limits),frames=[];
 let result,targetNode,targetDepth,complete=false,closed=false,failed=false,busy=false;
 const fail=message=>{failed=true;frames.length=0;result=undefined;throw Error(message);};
 const active=()=>{if(failed||closed)throw Error('value builder is closed');};
 const expected=()=>{
  if(!frames.length){if(complete)fail('value builder root already complete');targetNode=root;targetDepth=0;return;}
  const frame=frames.at(-1),position=frame.values.length;
  if(!frame.pattern.sequence&&position>=frame.pattern.children.length)fail('value builder constructor is full');
  targetNode=frame.pattern.sequence?frame.pattern.children[0]:frame.pattern.children[position];targetDepth=frame.depth+frame.pattern.childDepth;
 };
 const accept=value=>{
  if(frames.length)frames.at(-1).values.push(value);
  else{result=value;complete=true;}
 };
 const execute=(operation,first,second)=>{
  active();if(busy)throw Error('value builder operation already active');busy=true;
  try{return operation(first,second);}catch(error){failed=true;frames.length=0;result=undefined;throw error;}finally{busy=false;}
 };
 // Compile and cache constructor paths independently of the session's values.
 const pathPlan=(choices,startNode,startDepth)=>{
   if(!Array.isArray(choices)||choices.length===0||choices.length>128)fail('invalid value builder path');
   let cache=__constructorPaths.get(nodes);if(!cache){cache=new WeakMap();__constructorPaths.set(nodes,cache);}
   let entries=cache.get(choices),saved=entries?.get(startNode);
   if(saved)return saved;
   const path=[],charges=[];let node=startNode,depth=startDepth;
   for(let i=0;i<choices.length;i++){
    const choice=choices[i],patterns=nodes[node].patterns;
    if(!Number.isSafeInteger(choice)||choice<0||!patterns||choice>=patterns.length)fail('invalid value builder constructor');
    const pattern=patterns[choice];charges.push([pattern,depth-startDepth]);path.push({pattern,node:nodes[node]});
    if(i+1<choices.length){if(pattern.sequence||pattern.children.length!==1)fail('value builder path is not unary');node=pattern.children[0];depth+=pattern.childDepth;}
   }
   const terminal=path.at(-1).pattern;
   // Compose literal constructor functions once per path, instead of
   // allocating and interpreting another recursive closure for every value.
   const compose=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=args=>args[0];
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=args=>p.make([inner(args)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?compose(last+1):args=>args[0]):compose(last);
     return args=>node.flat(index,payload(args));
    }
    const inner=at+1<path.length?compose(at+1):null;
    if(pattern.transparent)return inner??(args=>args[0]);
    return inner?args=>pattern.make([inner(args)]):pattern.make;
   };
   const make=compose(0);
   // Scalar paths use the same literal constructors, but pass the leaf
   // directly through erased records and flat sums. No temporary argument
   // array is needed at those edges. Ordinary constructors keep their array
   // calling convention; no private value reaches the public builder API.
   const composeScalar=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=value=>value;
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=value=>p.make([inner(value)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?composeScalar(last+1):value=>value):composeScalar(last);
     return value=>node.flat(index,payload(value));
    }
    const inner=at+1<path.length?composeScalar(at+1):null;
    if(pattern.transparent)return inner??(value=>value);
    return inner?value=>pattern.make([inner(value)]):value=>pattern.make([value]);
   };
   const scalar=composeScalar(0);
   const pattern={...terminal,make};
   // Only frozen arrays of ordinary data properties can key reusable plans.
   // Mutable arrays and frozen accessor arrays retain checked per-call paths.
   const fixed=charges.every(([p])=>Number.isSafeInteger(p.bytes)&&p.bytes>=4);
   const plan={pattern,scalar,charges,offset:depth-startDepth,bytes:fixed?charges.reduce((n,[p])=>n+p.bytes,0):null};
   let reusable=Object.isFrozen(choices);
   for(let i=0;reusable&&i<choices.length;i++){const field=Object.getOwnPropertyDescriptor(choices,String(i));reusable=!!field&&Object.hasOwn(field,'value');}
   if(reusable){
    if(!entries){entries=new Map();cache.set(choices,entries);}entries.set(startNode,plan);
   }
   return plan;
 };
 const chargePath=(plan,depth)=>{
  // Each emitted constructor consumes one node and a fixed frame/tag cost.
  // Only take the combined charge when every original check would succeed.
  // Replaying the original order retains the exact first failure otherwise.
  if(plan.bytes!==null&&depth+plan.offset<=budget.depth&&plan.charges.length<=budget.remaining&&budget.bytes+plan.bytes<=budget.limit){
   budget.remaining-=plan.charges.length;budget.bytes+=plan.bytes;return;
  }
  for(const [pattern,offset]of plan.charges)pattern.charge(budget,depth+offset);
 };
 // Operations are allocated once per session, and share expected-node
 // scratch only while the existing reentrancy guard is held.
 const openOperation=(choice)=>{
   expected();const node=nodes[targetNode];
   if(!Number.isSafeInteger(choice)||choice<0||!node.patterns||choice>=node.patterns.length)fail('invalid value builder constructor');
   const pattern=node.patterns[choice];pattern.charge(budget,targetDepth);
   frames.push({pattern,depth:targetDepth,values:[]});
 };
 const openPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth);
   chargePath(plan,targetDepth);
   frames.push({pattern:plan.pattern,depth:targetDepth+plan.offset,values:[]});
 };
 const scalarPathOperation=(choices,value)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==1)fail('value builder path has no scalar leaf');
   const capture=nodes[pattern.children[0]].scalar;
   if(typeof capture!=='function')fail('value builder path has no scalar leaf');
   chargePath(plan,targetDepth);
   const leaf=capture(value,budget,targetDepth+plan.offset+pattern.childDepth);
   accept(plan.scalar(leaf));
 };
 const emptyPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==0)fail('value builder path is not empty');
   chargePath(plan,targetDepth);accept(pattern.make([]));
 };
 const scalarOperation=(value)=>{
   expected();const capture=nodes[targetNode].scalar;
   if(typeof capture!=='function')fail('value builder expects a constructor');
   accept(capture(value,budget,targetDepth));
 };
 const closeOperation=()=>{
   if(!frames.length)fail('value builder has no open constructor');
   const frame=frames.at(-1),pattern=frame.pattern,count=frame.values.length;
   if(!pattern.sequence&&count!==pattern.children.length||pattern.size!==undefined&&count!==pattern.size)fail('value builder constructor arity');
   if(pattern.sequence&&count>budget.limit)fail('wire sequence size');
   const value=pattern.make(frame.values);
   frames.pop();accept(value);
 };
 const finishOperation=()=>{
   if(frames.length||!complete)fail('value builder root is incomplete');
   closed=true;const handle=__compiledHandle(identity,result);result=undefined;return handle;
 };
 const api=Object.freeze({
  open(choice){return execute(openOperation,choice);},
  // Charge every source constructor even when unary paths share one frame.
  openPath(choices){return execute(openPathOperation,choices);},
  // Complete the path and leaf without intermediate session frames.
  scalarPath(choices,value){return execute(scalarPathOperation,choices,value);},
  emptyPath(choices){return execute(emptyPathOperation,choices);},
  scalar(value){return execute(scalarOperation,value);},
  close(){return execute(closeOperation);},
  finish(){return execute(finishOperation);},
  abort(){if(busy)throw Error('value builder operation already active');failed=true;frames.length=0;result=undefined;},
 });
 return api;
}
function __reduceValue0(value,r,b,d,c){b.enter(d,4);return r[0](__reduceValue1(value["a"],r,b,d+1,c),__reduceValue1(value["b"],r,b,d+1,c),c);}
function __reduceValue1(value,r,b,d,c){b.enter(d,8);return r[1]({F32Bits:value},c);}
function __reduceValue2(value,r,b,d,c){b.enter(d,4);return r[2](__reduceValue0(value["p"],r,b,d+1,c),__reduceValue0(value["q"],r,b,d+1,c),__reduceValue0(value["r"],r,b,d+1,c),__reduceValue0(value["s"],r,b,d+1,c),__reduceValue0(value["t"],r,b,d+1,c),__reduceValue0(value["u"],r,b,d+1,c),c);}
function __reduceValue3(value,r,b,d,c){b.enter(d,5);return r[3](value,c);}
function __reduceValue4(value,r,b,d,c){b.enter(d,8);return r[4](value,c);}
function __reduceValue5(value,r,b,d,c){b.enter(d,4);return r[5](__reduceValue4(value["value"],r,b,d+1,c),__reduceValue6(value["previous"],r,b,d+1,c),c);}
function __reduceValue6(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'None')&&value.None===null?r[6](0,null,c):r[6](1,__reduceValue5(value.Some,r,b,d+1,c),c);}
function __reduceValue7(value,r,b,d,c){b.enter(d,4);return r[7](__reduceValue8(value["p"],r,b,d+1,c),__reduceValue8(value["q"],r,b,d+1,c),__reduceValue8(value["r"],r,b,d+1,c),__reduceValue8(value["s"],r,b,d+1,c),__reduceValue8(value["t"],r,b,d+1,c),__reduceValue8(value["u"],r,b,d+1,c),c);}
function __reduceValue8(value,r,b,d,c){b.enter(d,4);return r[8](__reduceValue9(value["a"],r,b,d+1,c),__reduceValue9(value["b"],r,b,d+1,c),c);}
function __reduceValue9(value,r,b,d,c){b.enter(d,4);return r[9](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue1(value["tangent_0"],r,b,d+1,c),__reduceValue1(value["tangent_1"],r,b,d+1,c),__reduceValue1(value["tangent_2"],r,b,d+1,c),__reduceValue1(value["tangent_3"],r,b,d+1,c),__reduceValue1(value["tangent_4"],r,b,d+1,c),__reduceValue1(value["tangent_5"],r,b,d+1,c),__reduceValue1(value["tangent_6"],r,b,d+1,c),__reduceValue1(value["tangent_7"],r,b,d+1,c),__reduceValue1(value["tangent_8"],r,b,d+1,c),__reduceValue1(value["tangent_9"],r,b,d+1,c),__reduceValue1(value["tangent_10"],r,b,d+1,c),__reduceValue1(value["tangent_11"],r,b,d+1,c),c);}
function __reduceValue10(value,r,b,d,c){b.enter(d,4);return r[10](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue1(value["tangent"],r,b,d+1,c),c);}
function __reduceValue11(value,r,b,d,c){b.enter(d,4);return r[11](__reduceValue12(value["p"],r,b,d+1,c),__reduceValue12(value["q"],r,b,d+1,c),__reduceValue12(value["r"],r,b,d+1,c),__reduceValue12(value["s"],r,b,d+1,c),__reduceValue12(value["t"],r,b,d+1,c),__reduceValue12(value["u"],r,b,d+1,c),c);}
function __reduceValue12(value,r,b,d,c){b.enter(d,4);return r[12](__reduceValue10(value["a"],r,b,d+1,c),__reduceValue10(value["b"],r,b,d+1,c),c);}
let __reductionNodeCache;function __reductionNodes(){return __reductionNodeCache??=Object.freeze([Object.freeze({"children":Object.freeze([1,1]),"fields":Object.freeze(["a","b"]),"kind":"record","name":"Pair"}),Object.freeze({"children":Object.freeze([]),"kind":"f32"}),Object.freeze({"children":Object.freeze([0,0,0,0,0,0]),"fields":Object.freeze(["p","q","r","s","t","u"]),"kind":"record","name":"Bundle"}),Object.freeze({"children":Object.freeze([]),"kind":"bool"}),Object.freeze({"children":Object.freeze([]),"kind":"u32"}),Object.freeze({"children":Object.freeze([4,6]),"fields":Object.freeze(["value","previous"]),"kind":"record","name":"Node"}),Object.freeze({"children":Object.freeze([5]),"kind":"option"}),Object.freeze({"children":Object.freeze([8,8,8,8,8,8]),"fields":Object.freeze(["p","q","r","s","t","u"]),"kind":"record","name":"__ink_differential_4"}),Object.freeze({"children":Object.freeze([9,9]),"fields":Object.freeze(["a","b"]),"kind":"record","name":"__ink_differential_5"}),Object.freeze({"children":Object.freeze([1,1,1,1,1,1,1,1,1,1,1,1,1]),"fields":Object.freeze(["value","tangent_0","tangent_1","tangent_2","tangent_3","tangent_4","tangent_5","tangent_6","tangent_7","tangent_8","tangent_9","tangent_10","tangent_11"]),"kind":"record","name":"__ink_differential_2"}),Object.freeze({"children":Object.freeze([1,1]),"fields":Object.freeze(["value","tangent"]),"kind":"record","name":"__ink_differential_0"}),Object.freeze({"children":Object.freeze([12,12,12,12,12,12]),"fields":Object.freeze(["p","q","r","s","t","u"]),"kind":"record","name":"__ink_differential_21"}),Object.freeze({"children":Object.freeze([10,10]),"fields":Object.freeze(["a","b"]),"kind":"record","name":"__ink_differential_22"})]);}
function __compiledNamed1(){return {"Node":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}};}
function __compiledNamed0(){return {};}
let __compiledCodec0Value;function __compiledCodec0(){return __compiledCodec0Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"5728eeaa0e138ea2f93b2c91d176edec672a97fdd0e45fa08b4dacd31d4beebf","named":__compiledNamed0(),"root":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},__privateCapture0,__privateWireValue0,__privateWireWrite0,__compiledOwnedValue0,0,0,__reduceValue0,false,false);}
let __compiledCodec1Value;function __compiledCodec1(){return __compiledCodec1Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":__compiledNamed0(),"root":{"kind":"f32"}},__privateCapture1,__privateWireValue1,__privateWireWrite1,__compiledOwnedValue1,1,1,__reduceValue1,false,false);}
let __compiledCodec2Value;function __compiledCodec2(){return __compiledCodec2Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"7882b66162c075a7679604fdc86c31922fb250d10394af5aa2d1354c654b72e5","named":__compiledNamed0(),"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},__privateCapture2,__privateWireValue3,__privateWireWrite2,__compiledOwnedValue2,2,2,__reduceValue2,false,false);}
let __compiledCodec3Value;function __compiledCodec3(){return __compiledCodec3Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":__compiledNamed0(),"root":{"kind":"bool"}},__privateCapture3,__privateWireValue6,__privateWireWrite3,__compiledOwnedValue3,3,3,__reduceValue3,false,false);}
let __compiledCodec4Value;function __compiledCodec4(){return __compiledCodec4Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff","named":__compiledNamed0(),"root":{"kind":"u32"}},__privateCapture4,__privateWireValue11,__privateWireWrite4,__compiledOwnedValue4,4,4,__reduceValue4,false,false);}
let __compiledCodec5Value;function __compiledCodec5(){return __compiledCodec5Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"06a5b110d3c213512730b89ea5797ec6a338f55b0c357c4c3894a84ac3cfa9e3","named":__compiledNamed1(),"root":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}},__privateCapture5,__privateWireValue12,__privateWireWrite5,__compiledOwnedValue5,5,5,__reduceValue5,false,false);}
let __compiledCodec6Value;function __compiledCodec6(){return __compiledCodec6Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"1ed4df67eec523fb721f2ffb2ccd09b8aa81b446e7cf8b212dcb0624fdc7c7ae","named":__compiledNamed0(),"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"}},__privateCapture7,__privateWireValue15,__privateWireWrite7,__compiledOwnedValue8,7,7,__reduceValue7,false,false);}
let __compiledCodec7Value;function __compiledCodec7(){return __compiledCodec7Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"bb2b2f3efce5ad7f78fd263ef8cf59e1adcabaeb4e987b0d193c2a16c631b760","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},__privateCapture9,__privateWireValue17,__privateWireWrite9,__compiledOwnedValue10,9,9,__reduceValue9,false,false);}
let __compiledCodec8Value;function __compiledCodec8(){return __compiledCodec8Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},__privateCapture10,__privateWireValue19,__privateWireWrite10,__compiledOwnedValue11,10,10,__reduceValue10,false,false);}
let __compiledCodec9Value;function __compiledCodec9(){return __compiledCodec9Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"184b9a0f696a7df0c965d31530477d4a3b357365123b431716058e9a227b0ea0","named":__compiledNamed0(),"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"}},__privateCapture11,__privateWireValue23,__privateWireWrite11,__compiledOwnedValue12,11,11,__reduceValue11,false,false);}
const __compiledEntries=new Map([["component",{index:0,params:[__compiledCodec0,__compiledCodec1],result:__compiledCodec1,destination:null,arguments:__privateWireValue2,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["energy",{index:1,params:[__compiledCodec2,__compiledCodec1],result:__compiledCodec1,destination:null,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["derivatives",{index:2,params:[__compiledCodec2,__compiledCodec1],result:__compiledCodec2,destination:null,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["direction",{index:3,params:[__compiledCodec2,__compiledCodec1],result:__compiledCodec1,destination:null,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["twice",{index:4,params:[__compiledCodec0],result:__compiledCodec1,destination:null,arguments:__privateWireValue5,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["selected",{index:5,params:[__compiledCodec0,__compiledCodec3],result:__compiledCodec0,destination:null,arguments:__privateWireValue7,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["branches",{index:6,params:[__compiledCodec1,__compiledCodec3],result:__compiledCodec0,destination:null,arguments:__privateWireValue8,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["looping",{index:7,params:[__compiledCodec1],result:__compiledCodec0,destination:null,arguments:__privateWireValue9,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["strict_unused",{index:8,params:[__compiledCodec0],result:__compiledCodec1,destination:null,arguments:__privateWireValue5,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["strict",{index:9,params:[__compiledCodec1,__compiledCodec1],result:__compiledCodec1,destination:null,arguments:__privateWireValue10,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["history",{index:10,params:[__compiledCodec4],result:__compiledCodec5,destination:null,arguments:__privateWireValue14,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["__ink_differential_3",{index:12,params:[__compiledCodec6,__compiledCodec7],result:__compiledCodec7,destination:null,arguments:__privateWireValue18,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_1",{index:13,params:[__compiledCodec2,__compiledCodec1],result:__compiledCodec2,destination:null,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_23",{index:14,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,destination:null,arguments:__privateWireValue20,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_27",{index:15,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,destination:null,arguments:__privateWireValue21,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_31",{index:16,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,destination:null,arguments:__privateWireValue22,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_20",{index:17,params:[__compiledCodec9,__compiledCodec8],result:__compiledCodec8,destination:null,arguments:__privateWireValue25,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_19",{index:18,params:[__compiledCodec2,__compiledCodec2,__compiledCodec1],result:__compiledCodec1,destination:null,arguments:__privateWireValue26,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}]]);

export const compiledValues=Object.freeze(Object.fromEntries([...__compiledEntries].map(([name,entry])=>[name,Object.freeze({get params(){return Object.freeze(entry.params.map(codec=>codec()));},get result(){return entry.result();}})])));
function __compiledValidate(entry,owned){
 const values=owned.map(v=>v.value);
 const established=entry.onlyTypeGuards&&entry.needsInvariants.every((needed,i)=>!needed||owned[i].guaranteed);
 if(entry.precondition!==null&&!established){
  if(__implementations[entry.precondition](...values)!==true)throw Error('contract precondition failed');
  for(let i=0;i<owned.length;i++)if(entry.needsInvariants[i])owned[i].guaranteed=true;
 }
 return values;
}
export function callCompiled(name,args){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(args)||args.length!==entry.params.length)throw Error('unsupported compiled call');
 const owned=entry.params.map((codec,i)=>__compiledEntry(args[i],codec().identity)),values=__compiledValidate(entry,owned);
 // Checked source outputs satisfy their declared value interfaces. Private
 // handles expose only detached copies and never retain mutable host inputs.
 return __compiledHandle(entry.result().identity,__implementations[entry.index](...values),true);
}

// Explicit sealed-value partial application. Each token owns a bounded set of
// lexical caches; no mutable host object, global memo table or error is retained.
const __preparedCompiled=new WeakMap();
export function prepareCompiled(name,bindings){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(bindings)||bindings.length>entry.params.length)throw Error('unsupported prepared compiled call');
 const captured=new Array(entry.params.length),fixed=new Array(entry.params.length).fill(false);
 for(const binding of bindings){
  if(!Array.isArray(binding)||binding.length!==2)throw Error('prepared compiled binding');
  const [index,handle]=binding;
  if(!Number.isInteger(index)||index<0||index>=fixed.length||fixed[index])throw Error('prepared compiled parameter');
  captured[index]=__compiledEntry(handle,entry.params[index]().identity);fixed[index]=true;
 }
 const remaining=fixed.flatMap((yes,i)=>yes?[]:[i]);
 const factory=__preparedFactories.get(entry.index);
 const run=factory?factory(fixed):__implementations[entry.index];
 const token=Object.freeze(Object.create(null));
 __preparedCompiled.set(token,{entry,captured,remaining,run});return token;
}
export function callPreparedCompiled(token,args){
 const prepared=__preparedCompiled.get(token);
 if(!prepared||!Array.isArray(args)||args.length!==prepared.remaining.length)throw Error('invalid prepared compiled call');
 const {entry,captured,remaining,run}=prepared,owned=captured.slice();
 for(let i=0;i<remaining.length;i++){const at=remaining[i];owned[at]=__compiledEntry(args[i],entry.params[at]().identity);}
 const values=__compiledValidate(entry,owned);
 return __compiledHandle(entry.result().identity,run(...values),true);
}
// The caller owns sufficiently large, disjoint destination storage. This is
// the trusted Into ABI, not a bounded wire/materialization operation. Private
// retained containers never escape: structured elements are deeply detached.
const __destinationBudget=Object.freeze({remaining:Infinity,enter(){},text(){}});
export function callPreparedCompiledInto(token,args,destination){
 const prepared=__preparedCompiled.get(token);
 if(!prepared||!prepared.entry.destination||!Array.isArray(args)||args.length!==prepared.remaining.length)throw Error('invalid prepared compiled destination call');
 const {entry,captured,remaining,run}=prepared,owned=captured.slice();
 for(let i=0;i<remaining.length;i++){const at=remaining[i];owned[at]=__compiledEntry(args[i],entry.params[at]().identity);}
 const values=__compiledValidate(entry,owned),into=entry.destination;
 // Ordinary scalar-list bodies can write the terminal stage directly. A
 // residual body keeps its lexical caches and copies only its final elements.
 if(into.direct&&run===__implementations[entry.index])return into.direct(...values,destination);
 const result=run(...values),n=result.length;
 for(let i=0;i<n;i++)destination[i]=into.copy(result[i],__destinationBudget,0);
 return n;
}
const __intoImplementations=[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
export const functionsInto=Object.freeze(Object.fromEntries([]));
export function callInto(name,args,destination){switch(name){case "owner":throw new Error('temporary storage is internal to a pure invocation');}return functionsInto[name](...args,destination);}

function __preparedPart(mask,path){
 for(const field of path){
  if(mask===true)return true;
  if(!mask || typeof mask!=="object")return false;
  mask=Object.hasOwn(mask.fields,field)?mask.fields[field]:false;
 }
 return mask;
}
function __preparedStable(mask,path){const part=__preparedPart(mask,path);return part===true || (!!part && part.all===true);}
function __prepareFn2(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[]))))return __fn2;const v1638=depth<15&&__preparedFactories.has(13)&&((__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[])));
let v1636;
return function(v1634,v1635){let v1639;if(v1638){if(!v1636){const v1637=__preparedFactories.get(13);v1636=v1637([fixed[0],fixed[1]],depth+1);}v1639=v1636(v1634,v1635);}else{v1639=__fn13(v1634,v1635);}
return v1639;};}
function __prepareFn13(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[]))))return __fn13;const v2704=__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[]);
let v2703=false,v2702;
const v2892=__preparedPart(fixed[0],["p","a"]);
const v2893={all:__preparedStable(fixed[0],["p","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2892}};
const v2894=__preparedPart(fixed[0],["p","b"]);
const v2895={all:__preparedStable(fixed[0],["p","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2894}};
const v2896={all:__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"]),fields:{["a"]:v2893,["b"]:v2895}};
const v2897=__preparedPart(fixed[0],["q","a"]);
const v2898={all:__preparedStable(fixed[0],["q","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2897}};
const v2899=__preparedPart(fixed[0],["q","b"]);
const v2900={all:__preparedStable(fixed[0],["q","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2899}};
const v2901={all:__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"]),fields:{["a"]:v2898,["b"]:v2900}};
const v2902=__preparedPart(fixed[0],["r","a"]);
const v2903={all:__preparedStable(fixed[0],["r","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2902}};
const v2904=__preparedPart(fixed[0],["r","b"]);
const v2905={all:__preparedStable(fixed[0],["r","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2904}};
const v2906={all:__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"]),fields:{["a"]:v2903,["b"]:v2905}};
const v2907=__preparedPart(fixed[0],["s","a"]);
const v2908={all:__preparedStable(fixed[0],["s","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2907}};
const v2909=__preparedPart(fixed[0],["s","b"]);
const v2910={all:__preparedStable(fixed[0],["s","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2909}};
const v2911={all:__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"]),fields:{["a"]:v2908,["b"]:v2910}};
const v2912=__preparedPart(fixed[0],["t","a"]);
const v2913={all:__preparedStable(fixed[0],["t","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2912}};
const v2914=__preparedPart(fixed[0],["t","b"]);
const v2915={all:__preparedStable(fixed[0],["t","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2914}};
const v2916={all:__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"]),fields:{["a"]:v2913,["b"]:v2915}};
const v2917=__preparedPart(fixed[0],["u","a"]);
const v2918={all:__preparedStable(fixed[0],["u","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2917}};
const v2919=__preparedPart(fixed[0],["u","b"]);
const v2920={all:__preparedStable(fixed[0],["u","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2919}};
const v2921={all:__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"]),fields:{["a"]:v2918,["b"]:v2920}};
const v2922={all:__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"]),fields:{["p"]:v2896,["q"]:v2901,["r"]:v2906,["s"]:v2911,["t"]:v2916,["u"]:v2921}};
const v2936={all:__preparedStable(fixed[1],[]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:fixed[1]}};
const v2939=depth<15&&__preparedFactories.has(12)&&((__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[])));
let v2937;
return function(v2699,v2700){let v2701;if(v2704&&v2703){v2701=v2702;}else{
const v2705=v2699["p"];
const v2706=v2705["a"];
const v2707=1065353216;
const v2708=0;
const v2709=0;
const v2710=0;
const v2711=0;
const v2712=0;
const v2713=0;
const v2714=0;
const v2715=0;
const v2716=0;
const v2717=0;
const v2718=0;
const v2720=v2699["p"];
const v2721=v2720["b"];
const v2722=0;
const v2723=1065353216;
const v2724=0;
const v2725=0;
const v2726=0;
const v2727=0;
const v2728=0;
const v2729=0;
const v2730=0;
const v2731=0;
const v2732=0;
const v2733=0;
const v2736=v2699["q"];
const v2737=v2736["a"];
const v2738=0;
const v2739=0;
const v2740=1065353216;
const v2741=0;
const v2742=0;
const v2743=0;
const v2744=0;
const v2745=0;
const v2746=0;
const v2747=0;
const v2748=0;
const v2749=0;
const v2751=v2699["q"];
const v2752=v2751["b"];
const v2753=0;
const v2754=0;
const v2755=0;
const v2756=1065353216;
const v2757=0;
const v2758=0;
const v2759=0;
const v2760=0;
const v2761=0;
const v2762=0;
const v2763=0;
const v2764=0;
const v2767=v2699["r"];
const v2768=v2767["a"];
const v2769=0;
const v2770=0;
const v2771=0;
const v2772=0;
const v2773=1065353216;
const v2774=0;
const v2775=0;
const v2776=0;
const v2777=0;
const v2778=0;
const v2779=0;
const v2780=0;
const v2782=v2699["r"];
const v2783=v2782["b"];
const v2784=0;
const v2785=0;
const v2786=0;
const v2787=0;
const v2788=0;
const v2789=1065353216;
const v2790=0;
const v2791=0;
const v2792=0;
const v2793=0;
const v2794=0;
const v2795=0;
const v2798=v2699["s"];
const v2799=v2798["a"];
const v2800=0;
const v2801=0;
const v2802=0;
const v2803=0;
const v2804=0;
const v2805=0;
const v2806=1065353216;
const v2807=0;
const v2808=0;
const v2809=0;
const v2810=0;
const v2811=0;
const v2813=v2699["s"];
const v2814=v2813["b"];
const v2815=0;
const v2816=0;
const v2817=0;
const v2818=0;
const v2819=0;
const v2820=0;
const v2821=0;
const v2822=1065353216;
const v2823=0;
const v2824=0;
const v2825=0;
const v2826=0;
const v2829=v2699["t"];
const v2830=v2829["a"];
const v2831=0;
const v2832=0;
const v2833=0;
const v2834=0;
const v2835=0;
const v2836=0;
const v2837=0;
const v2838=0;
const v2839=1065353216;
const v2840=0;
const v2841=0;
const v2842=0;
const v2844=v2699["t"];
const v2845=v2844["b"];
const v2846=0;
const v2847=0;
const v2848=0;
const v2849=0;
const v2850=0;
const v2851=0;
const v2852=0;
const v2853=0;
const v2854=0;
const v2855=1065353216;
const v2856=0;
const v2857=0;
const v2860=v2699["u"];
const v2861=v2860["a"];
const v2862=0;
const v2863=0;
const v2864=0;
const v2865=0;
const v2866=0;
const v2867=0;
const v2868=0;
const v2869=0;
const v2870=0;
const v2871=0;
const v2872=1065353216;
const v2873=0;
const v2875=v2699["u"];
const v2876=v2875["b"];
const v2877=0;
const v2878=0;
const v2879=0;
const v2880=0;
const v2881=0;
const v2882=0;
const v2883=0;
const v2884=0;
const v2885=0;
const v2886=0;
const v2887=0;
const v2888=1065353216;
const v2891=({["p"]:({["a"]:({["value"]:v2706,["tangent_0"]:v2707,["tangent_1"]:v2708,["tangent_2"]:v2709,["tangent_3"]:v2710,["tangent_4"]:v2711,["tangent_5"]:v2712,["tangent_6"]:v2713,["tangent_7"]:v2714,["tangent_8"]:v2715,["tangent_9"]:v2716,["tangent_10"]:v2717,["tangent_11"]:v2718}),["b"]:({["value"]:v2721,["tangent_0"]:v2722,["tangent_1"]:v2723,["tangent_2"]:v2724,["tangent_3"]:v2725,["tangent_4"]:v2726,["tangent_5"]:v2727,["tangent_6"]:v2728,["tangent_7"]:v2729,["tangent_8"]:v2730,["tangent_9"]:v2731,["tangent_10"]:v2732,["tangent_11"]:v2733})}),["q"]:({["a"]:({["value"]:v2737,["tangent_0"]:v2738,["tangent_1"]:v2739,["tangent_2"]:v2740,["tangent_3"]:v2741,["tangent_4"]:v2742,["tangent_5"]:v2743,["tangent_6"]:v2744,["tangent_7"]:v2745,["tangent_8"]:v2746,["tangent_9"]:v2747,["tangent_10"]:v2748,["tangent_11"]:v2749}),["b"]:({["value"]:v2752,["tangent_0"]:v2753,["tangent_1"]:v2754,["tangent_2"]:v2755,["tangent_3"]:v2756,["tangent_4"]:v2757,["tangent_5"]:v2758,["tangent_6"]:v2759,["tangent_7"]:v2760,["tangent_8"]:v2761,["tangent_9"]:v2762,["tangent_10"]:v2763,["tangent_11"]:v2764})}),["r"]:({["a"]:({["value"]:v2768,["tangent_0"]:v2769,["tangent_1"]:v2770,["tangent_2"]:v2771,["tangent_3"]:v2772,["tangent_4"]:v2773,["tangent_5"]:v2774,["tangent_6"]:v2775,["tangent_7"]:v2776,["tangent_8"]:v2777,["tangent_9"]:v2778,["tangent_10"]:v2779,["tangent_11"]:v2780}),["b"]:({["value"]:v2783,["tangent_0"]:v2784,["tangent_1"]:v2785,["tangent_2"]:v2786,["tangent_3"]:v2787,["tangent_4"]:v2788,["tangent_5"]:v2789,["tangent_6"]:v2790,["tangent_7"]:v2791,["tangent_8"]:v2792,["tangent_9"]:v2793,["tangent_10"]:v2794,["tangent_11"]:v2795})}),["s"]:({["a"]:({["value"]:v2799,["tangent_0"]:v2800,["tangent_1"]:v2801,["tangent_2"]:v2802,["tangent_3"]:v2803,["tangent_4"]:v2804,["tangent_5"]:v2805,["tangent_6"]:v2806,["tangent_7"]:v2807,["tangent_8"]:v2808,["tangent_9"]:v2809,["tangent_10"]:v2810,["tangent_11"]:v2811}),["b"]:({["value"]:v2814,["tangent_0"]:v2815,["tangent_1"]:v2816,["tangent_2"]:v2817,["tangent_3"]:v2818,["tangent_4"]:v2819,["tangent_5"]:v2820,["tangent_6"]:v2821,["tangent_7"]:v2822,["tangent_8"]:v2823,["tangent_9"]:v2824,["tangent_10"]:v2825,["tangent_11"]:v2826})}),["t"]:({["a"]:({["value"]:v2830,["tangent_0"]:v2831,["tangent_1"]:v2832,["tangent_2"]:v2833,["tangent_3"]:v2834,["tangent_4"]:v2835,["tangent_5"]:v2836,["tangent_6"]:v2837,["tangent_7"]:v2838,["tangent_8"]:v2839,["tangent_9"]:v2840,["tangent_10"]:v2841,["tangent_11"]:v2842}),["b"]:({["value"]:v2845,["tangent_0"]:v2846,["tangent_1"]:v2847,["tangent_2"]:v2848,["tangent_3"]:v2849,["tangent_4"]:v2850,["tangent_5"]:v2851,["tangent_6"]:v2852,["tangent_7"]:v2853,["tangent_8"]:v2854,["tangent_9"]:v2855,["tangent_10"]:v2856,["tangent_11"]:v2857})}),["u"]:({["a"]:({["value"]:v2861,["tangent_0"]:v2862,["tangent_1"]:v2863,["tangent_2"]:v2864,["tangent_3"]:v2865,["tangent_4"]:v2866,["tangent_5"]:v2867,["tangent_6"]:v2868,["tangent_7"]:v2869,["tangent_8"]:v2870,["tangent_9"]:v2871,["tangent_10"]:v2872,["tangent_11"]:v2873}),["b"]:({["value"]:v2876,["tangent_0"]:v2877,["tangent_1"]:v2878,["tangent_2"]:v2879,["tangent_3"]:v2880,["tangent_4"]:v2881,["tangent_5"]:v2882,["tangent_6"]:v2883,["tangent_7"]:v2884,["tangent_8"]:v2885,["tangent_9"]:v2886,["tangent_10"]:v2887,["tangent_11"]:v2888})})});
const v2923=0;
const v2924=0;
const v2925=0;
const v2926=0;
const v2927=0;
const v2928=0;
const v2929=0;
const v2930=0;
const v2931=0;
const v2932=0;
const v2933=0;
const v2934=0;
const v2935=({["value"]:v2700,["tangent_0"]:v2923,["tangent_1"]:v2924,["tangent_2"]:v2925,["tangent_3"]:v2926,["tangent_4"]:v2927,["tangent_5"]:v2928,["tangent_6"]:v2929,["tangent_7"]:v2930,["tangent_8"]:v2931,["tangent_9"]:v2932,["tangent_10"]:v2933,["tangent_11"]:v2934});
let v2940;if(v2939){if(!v2937){const v2938=__preparedFactories.get(12);v2937=v2938([v2922,v2936],depth+1);}v2940=v2937(v2891,v2935);}else{v2940=__fn12(v2891,v2935);}
v2701=v2940;if(v2704){v2702=v2701;v2703=true;}}
const v2941=v2701;
const v2942=v2941["tangent_0"];
const v2943=v2701;
const v2944=v2943["tangent_1"];
const v2946=v2701;
const v2947=v2946["tangent_2"];
const v2948=v2701;
const v2949=v2948["tangent_3"];
const v2951=v2701;
const v2952=v2951["tangent_4"];
const v2953=v2701;
const v2954=v2953["tangent_5"];
const v2956=v2701;
const v2957=v2956["tangent_6"];
const v2958=v2701;
const v2959=v2958["tangent_7"];
const v2961=v2701;
const v2962=v2961["tangent_8"];
const v2963=v2701;
const v2964=v2963["tangent_9"];
const v2966=v2701;
const v2967=v2966["tangent_10"];
const v2968=v2701;
const v2969=v2968["tangent_11"];
return ({["p"]:({["a"]:v2942,["b"]:v2944}),["q"]:({["a"]:v2947,["b"]:v2949}),["r"]:({["a"]:v2952,["b"]:v2954}),["s"]:({["a"]:v2957,["b"]:v2959}),["t"]:({["a"]:v2962,["b"]:v2964}),["u"]:({["a"]:v2967,["b"]:v2969})});};}
const __preparedFactories=new Map([[2,__prepareFn2],[13,__prepareFn13]]);
