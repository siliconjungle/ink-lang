const __recordElisions=new Set([]);
const __nativeF32=true;
// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
// Binary64 uses native Numbers for finite arithmetic and immutable private
// tags only where a NaN's exact payload must survive non-arithmetic operations.
const __doubleView=new DataView(new ArrayBuffer(8));
const __double=bits=>{__doubleView.setBigUint64(0,bits,true);return __doubleView.getFloat64(0,true);};
const __doubleBits=number=>{if(Number.isNaN(number))return 0x7ff8000000000000n;__doubleView.setFloat64(0,number,true);return __doubleView.getBigUint64(0,true);};
const __dfNumber=value=>typeof value==='number'?value:__double(BigInt(value.F64Bits));
const __dfBits=value=>typeof value==='number'?__doubleBits(value):BigInt(value.F64Bits);
const __dfFromBits=bits=>(bits&0x7fffffffffffffffn)>0x7ff0000000000000n?Object.freeze({F64Bits:bits.toString()}):__double(bits);
const __dfInput=value=>typeof value==='number'?value:__dfFromBits(BigInt(value.F64Bits));
const __dfNeg=value=>typeof value==='number'&&!Number.isNaN(value)?-value:__dfFromBits(__dfBits(value)^0x8000000000000000n);
const __dfOutput=value=>{const n=__dfNumber(value);return Number.isFinite(n)?n:{F64Bits:__dfBits(value).toString()};};
const __dfCapture=value=>{
 if(typeof value==='number'&&Number.isFinite(value))return value;
 if(!value||typeof value!=='object'||Object.keys(value).length!==1||!Object.hasOwn(value,'F64Bits'))throw Error('invalid f64');const text=value.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid f64');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');return __dfFromBits(bits);
};
// Native binary32 lane for pure modules. Explicit NaN payloads remain tagged;
// arithmetic canonicalizes NaNs just as __bits does in the exact-bit lane.
// Host tags are captured once at a typed read. Only private immutable tags
// may pass through normalization without consulting a host property again.
const __nfTagged = new WeakSet();
const __nfValue = value => typeof value === 'number' ? Math.fround(value) : __nfTagged.has(value) ? value : __nfFromBits(value.F32Bits);
// Number operands have already been normalised at their typed read or producer.
const __nfNumber = value => typeof value === 'number' ? value : __float(value.F32Bits);
const __nfBits = value => typeof value === 'number' ? __bits(value) : value.F32Bits;
const __nfFromBits = bits => {
  if((bits & 0x7fffffff)<=0x7f800000)return __float(bits);
  const value=Object.freeze({F32Bits:bits});__nfTagged.add(value);return value;
};
const __nfNeg = value => typeof value === 'number' && !Number.isNaN(value) ? -value : __nfFromBits((__nfBits(value) ^ 0x80000000) >>> 0);
const __nfOutput = value => {const n=typeof value==='number'?Math.fround(value):__float(value.F32Bits);return Number.isFinite(n)?n:{F32Bits:__nfBits(value)};};
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output, capture=false) {
  const convert=__representationRaw(type,output,capture);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':capture?'capture:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output, capture) {
  switch (type.kind) {
    case 'ref': {
      let resolved;
      return (value,context)=>(resolved??=__representation(__namedTypes[type.name],output,capture))(value,context);
    }
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output,capture);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output,capture),err=__representation(type.error,output,capture);
      const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);
      if(flat)return output?(value,context)=>{const v=__sumView(key,value);return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};}:(v,context)=>Object.hasOwn(v,'Ok')?__sumMake(key,true,ok(v.Ok,context)):__sumMake(key,false,err(v.Err,context));
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f64':return output?__dfOutput:__dfInput;
    case 'f32': if(typeof __nativeF32!=='undefined'&&__nativeF32)return output?__nfOutput:capture?__nfValue:__identity;
      return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output,capture);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){
        if(!type.fields.length)return ()=>undefined; // lexically unconsumed projected input
        const field=type.fields[0],child=__representation(field.type,output,capture);
        return output?(value,context)=>({[field.name]:child(value,context)}):(value,context)=>child(value[field.name],context);
      }
      const fields = type.fields.map(field => [field.name, __representation(field.type, output,capture)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
function __fn0(v0,v1){
const v2=v0["a"];
const v3=(__dfNumber(v2) - __dfNumber(v1));
const v4=v0["b"];
const v5=(__dfNumber(v4) + __dfNumber(v1));
const v6=(__dfNumber(v3) * __dfNumber(v3));
const v7=(__dfNumber(v5) * __dfNumber(v5));
return (__dfNumber(v6) + __dfNumber(v7));}
function __fn1(v8,v9){
const v10=v8["p"];
const v11=v10["a"];
const v12=(__dfNumber(v11) - __dfNumber(v9));
const v13=v8["p"];
const v14=v13["b"];
const v15=(__dfNumber(v14) + __dfNumber(v9));
const v16=v8["q"];
const v17=v16["a"];
const v18=(__dfNumber(v17) - __dfNumber(v9));
const v19=v8["q"];
const v20=v19["b"];
const v21=(__dfNumber(v20) + __dfNumber(v9));
const v22=v8["r"];
const v23=v22["a"];
const v24=(__dfNumber(v23) - __dfNumber(v9));
const v25=v8["r"];
const v26=v25["b"];
const v27=(__dfNumber(v26) + __dfNumber(v9));
const v28=v8["s"];
const v29=v28["a"];
const v30=(__dfNumber(v29) - __dfNumber(v9));
const v31=v8["s"];
const v32=v31["b"];
const v33=(__dfNumber(v32) + __dfNumber(v9));
const v34=v8["t"];
const v35=v34["a"];
const v36=(__dfNumber(v35) - __dfNumber(v9));
const v37=v8["t"];
const v38=v37["b"];
const v39=(__dfNumber(v38) + __dfNumber(v9));
const v40=v8["u"];
const v41=v40["a"];
const v42=(__dfNumber(v41) - __dfNumber(v9));
const v43=v8["u"];
const v44=v43["b"];
const v45=(__dfNumber(v44) + __dfNumber(v9));
const v46=(__dfNumber(v12) * __dfNumber(v12));
const v47=(__dfNumber(v15) * __dfNumber(v15));
const v48=(__dfNumber(v46) + __dfNumber(v47));
const v49=(__dfNumber(v18) * __dfNumber(v18));
const v50=(__dfNumber(v48) + __dfNumber(v49));
const v51=(__dfNumber(v21) * __dfNumber(v21));
const v52=(__dfNumber(v50) + __dfNumber(v51));
const v53=(__dfNumber(v24) * __dfNumber(v24));
const v54=(__dfNumber(v52) + __dfNumber(v53));
const v55=(__dfNumber(v27) * __dfNumber(v27));
const v56=(__dfNumber(v54) + __dfNumber(v55));
const v57=(__dfNumber(v30) * __dfNumber(v30));
const v58=(__dfNumber(v56) + __dfNumber(v57));
const v59=(__dfNumber(v33) * __dfNumber(v33));
const v60=(__dfNumber(v58) + __dfNumber(v59));
const v61=(__dfNumber(v36) * __dfNumber(v36));
const v62=(__dfNumber(v60) + __dfNumber(v61));
const v63=(__dfNumber(v39) * __dfNumber(v39));
const v64=(__dfNumber(v62) + __dfNumber(v63));
const v65=(__dfNumber(v42) * __dfNumber(v42));
const v66=(__dfNumber(v64) + __dfNumber(v65));
const v67=(__dfNumber(v45) * __dfNumber(v45));
return (__dfNumber(v66) + __dfNumber(v67));}
function __fn2(v68,v69){
return __fn12(v68,v69);}
function __fn3(v70,v71){
return __fn17(v70,v70,v71);}
function __fn4(v72){
const v73=v72["a"];
const v74=v72["a"];
const v75=(__dfNumber(v73) * __dfNumber(v74));
const v76=v72["a"];
const v77=v72["a"];
const v78=(__dfNumber(v76) * __dfNumber(v77));
return (__dfNumber(v75) + __dfNumber(v78));}
function __fn5(v79,v80){
let v81;if(v80){
const v82=v79["b"];
const v83=v79["b"];
const v84=(__dfNumber(v82) * __dfNumber(v83));
const v85=v79["a"];
const v86=v79["a"];
const v87=(__dfNumber(v85) * __dfNumber(v86));
v81=({["a"]:v84,["b"]:v87});}else{
const v88=v79["a"];
const v89=v79["a"];
const v90=(__dfNumber(v88) * __dfNumber(v89));
const v91=v79["b"];
const v92=v79["b"];
const v93=(__dfNumber(v91) * __dfNumber(v92));
v81=({["a"]:v90,["b"]:v93});}
return v81;}
function __fn6(v94,v95){
const v96=__dfNeg(v94);
let v99;
let v100;
if(v95){
const v101=(__dfNumber(v96) * __dfNumber(v96));
const v102=(__dfNumber(v94) * __dfNumber(v94));
v99=v101;
v100=v102;
}else{
const v103=(__dfNumber(v94) * __dfNumber(v94));
const v104=(__dfNumber(v96) * __dfNumber(v96));
v99=v103;
v100=v104;
}
return ({["a"]:v99,["b"]:v100});}
function __fn7(v105){
const v106=__dfNeg(v105);
let v107=v105;
let v108=v106;
for(let v110=0;v110<3;v110++){
const v111=(v110>>>0);
const v112=v108;
const v113=v107;
v107=v112;
v108=v113;
}
return ({["a"]:v107,["b"]:v108});}
function __fn8(v114){
const v115=v114["b"];
const v116=v114["b"];
const v117=(__dfNumber(v115) * __dfNumber(v116));
return v114["a"];}
function __fn9(v118,v119){
const v121=(__dfNumber(v119) * __dfNumber(v119));
return v118;}
function __fn10(v122){
const v123=({None:null});
let v124=v122;
let v125=v123;
for(let v127=0;v127<3;v127++){
const v128=(v127>>>0);
const v129=v124;
const v130=1;
const v131=(((v129) + (v130)) >>> 0);
const v132=v124;
const v133=v125;
const v135=({Some:({["value"]:v132,["previous"]:v133})});
v124=v131;
v125=v135;
}
return ({["value"]:v124,["previous"]:v125});}
function __fn11(v136,v137){
const v138=v136["p"];
const v139=v138["a"];
const v140=v139["value"];
const v141=v137["value"];
const v142=(__dfNumber(v140) - __dfNumber(v141));
const v143=v139["tangent_0"];
const v144=v137["tangent_0"];
const v145=(__dfNumber(v143) - __dfNumber(v144));
const v146=v139["tangent_1"];
const v147=v137["tangent_1"];
const v148=(__dfNumber(v146) - __dfNumber(v147));
const v149=v139["tangent_2"];
const v150=v137["tangent_2"];
const v151=(__dfNumber(v149) - __dfNumber(v150));
const v152=v139["tangent_3"];
const v153=v137["tangent_3"];
const v154=(__dfNumber(v152) - __dfNumber(v153));
const v155=v139["tangent_4"];
const v156=v137["tangent_4"];
const v157=(__dfNumber(v155) - __dfNumber(v156));
const v158=v139["tangent_5"];
const v159=v137["tangent_5"];
const v160=(__dfNumber(v158) - __dfNumber(v159));
const v161=v139["tangent_6"];
const v162=v137["tangent_6"];
const v163=(__dfNumber(v161) - __dfNumber(v162));
const v164=v139["tangent_7"];
const v165=v137["tangent_7"];
const v166=(__dfNumber(v164) - __dfNumber(v165));
const v167=v139["tangent_8"];
const v168=v137["tangent_8"];
const v169=(__dfNumber(v167) - __dfNumber(v168));
const v170=v139["tangent_9"];
const v171=v137["tangent_9"];
const v172=(__dfNumber(v170) - __dfNumber(v171));
const v173=v139["tangent_10"];
const v174=v137["tangent_10"];
const v175=(__dfNumber(v173) - __dfNumber(v174));
const v176=v139["tangent_11"];
const v177=v137["tangent_11"];
const v178=(__dfNumber(v176) - __dfNumber(v177));
const v180=v136["p"];
const v181=v180["b"];
const v182=v181["value"];
const v183=v137["value"];
const v184=(__dfNumber(v182) + __dfNumber(v183));
const v185=v181["tangent_0"];
const v186=v137["tangent_0"];
const v187=(__dfNumber(v185) + __dfNumber(v186));
const v188=v181["tangent_1"];
const v189=v137["tangent_1"];
const v190=(__dfNumber(v188) + __dfNumber(v189));
const v191=v181["tangent_2"];
const v192=v137["tangent_2"];
const v193=(__dfNumber(v191) + __dfNumber(v192));
const v194=v181["tangent_3"];
const v195=v137["tangent_3"];
const v196=(__dfNumber(v194) + __dfNumber(v195));
const v197=v181["tangent_4"];
const v198=v137["tangent_4"];
const v199=(__dfNumber(v197) + __dfNumber(v198));
const v200=v181["tangent_5"];
const v201=v137["tangent_5"];
const v202=(__dfNumber(v200) + __dfNumber(v201));
const v203=v181["tangent_6"];
const v204=v137["tangent_6"];
const v205=(__dfNumber(v203) + __dfNumber(v204));
const v206=v181["tangent_7"];
const v207=v137["tangent_7"];
const v208=(__dfNumber(v206) + __dfNumber(v207));
const v209=v181["tangent_8"];
const v210=v137["tangent_8"];
const v211=(__dfNumber(v209) + __dfNumber(v210));
const v212=v181["tangent_9"];
const v213=v137["tangent_9"];
const v214=(__dfNumber(v212) + __dfNumber(v213));
const v215=v181["tangent_10"];
const v216=v137["tangent_10"];
const v217=(__dfNumber(v215) + __dfNumber(v216));
const v218=v181["tangent_11"];
const v219=v137["tangent_11"];
const v220=(__dfNumber(v218) + __dfNumber(v219));
const v222=v136["q"];
const v223=v222["a"];
const v224=v223["value"];
const v225=v137["value"];
const v226=(__dfNumber(v224) - __dfNumber(v225));
const v227=v223["tangent_0"];
const v228=v137["tangent_0"];
const v229=(__dfNumber(v227) - __dfNumber(v228));
const v230=v223["tangent_1"];
const v231=v137["tangent_1"];
const v232=(__dfNumber(v230) - __dfNumber(v231));
const v233=v223["tangent_2"];
const v234=v137["tangent_2"];
const v235=(__dfNumber(v233) - __dfNumber(v234));
const v236=v223["tangent_3"];
const v237=v137["tangent_3"];
const v238=(__dfNumber(v236) - __dfNumber(v237));
const v239=v223["tangent_4"];
const v240=v137["tangent_4"];
const v241=(__dfNumber(v239) - __dfNumber(v240));
const v242=v223["tangent_5"];
const v243=v137["tangent_5"];
const v244=(__dfNumber(v242) - __dfNumber(v243));
const v245=v223["tangent_6"];
const v246=v137["tangent_6"];
const v247=(__dfNumber(v245) - __dfNumber(v246));
const v248=v223["tangent_7"];
const v249=v137["tangent_7"];
const v250=(__dfNumber(v248) - __dfNumber(v249));
const v251=v223["tangent_8"];
const v252=v137["tangent_8"];
const v253=(__dfNumber(v251) - __dfNumber(v252));
const v254=v223["tangent_9"];
const v255=v137["tangent_9"];
const v256=(__dfNumber(v254) - __dfNumber(v255));
const v257=v223["tangent_10"];
const v258=v137["tangent_10"];
const v259=(__dfNumber(v257) - __dfNumber(v258));
const v260=v223["tangent_11"];
const v261=v137["tangent_11"];
const v262=(__dfNumber(v260) - __dfNumber(v261));
const v264=v136["q"];
const v265=v264["b"];
const v266=v265["value"];
const v267=v137["value"];
const v268=(__dfNumber(v266) + __dfNumber(v267));
const v269=v265["tangent_0"];
const v270=v137["tangent_0"];
const v271=(__dfNumber(v269) + __dfNumber(v270));
const v272=v265["tangent_1"];
const v273=v137["tangent_1"];
const v274=(__dfNumber(v272) + __dfNumber(v273));
const v275=v265["tangent_2"];
const v276=v137["tangent_2"];
const v277=(__dfNumber(v275) + __dfNumber(v276));
const v278=v265["tangent_3"];
const v279=v137["tangent_3"];
const v280=(__dfNumber(v278) + __dfNumber(v279));
const v281=v265["tangent_4"];
const v282=v137["tangent_4"];
const v283=(__dfNumber(v281) + __dfNumber(v282));
const v284=v265["tangent_5"];
const v285=v137["tangent_5"];
const v286=(__dfNumber(v284) + __dfNumber(v285));
const v287=v265["tangent_6"];
const v288=v137["tangent_6"];
const v289=(__dfNumber(v287) + __dfNumber(v288));
const v290=v265["tangent_7"];
const v291=v137["tangent_7"];
const v292=(__dfNumber(v290) + __dfNumber(v291));
const v293=v265["tangent_8"];
const v294=v137["tangent_8"];
const v295=(__dfNumber(v293) + __dfNumber(v294));
const v296=v265["tangent_9"];
const v297=v137["tangent_9"];
const v298=(__dfNumber(v296) + __dfNumber(v297));
const v299=v265["tangent_10"];
const v300=v137["tangent_10"];
const v301=(__dfNumber(v299) + __dfNumber(v300));
const v302=v265["tangent_11"];
const v303=v137["tangent_11"];
const v304=(__dfNumber(v302) + __dfNumber(v303));
const v306=v136["r"];
const v307=v306["a"];
const v308=v307["value"];
const v309=v137["value"];
const v310=(__dfNumber(v308) - __dfNumber(v309));
const v311=v307["tangent_0"];
const v312=v137["tangent_0"];
const v313=(__dfNumber(v311) - __dfNumber(v312));
const v314=v307["tangent_1"];
const v315=v137["tangent_1"];
const v316=(__dfNumber(v314) - __dfNumber(v315));
const v317=v307["tangent_2"];
const v318=v137["tangent_2"];
const v319=(__dfNumber(v317) - __dfNumber(v318));
const v320=v307["tangent_3"];
const v321=v137["tangent_3"];
const v322=(__dfNumber(v320) - __dfNumber(v321));
const v323=v307["tangent_4"];
const v324=v137["tangent_4"];
const v325=(__dfNumber(v323) - __dfNumber(v324));
const v326=v307["tangent_5"];
const v327=v137["tangent_5"];
const v328=(__dfNumber(v326) - __dfNumber(v327));
const v329=v307["tangent_6"];
const v330=v137["tangent_6"];
const v331=(__dfNumber(v329) - __dfNumber(v330));
const v332=v307["tangent_7"];
const v333=v137["tangent_7"];
const v334=(__dfNumber(v332) - __dfNumber(v333));
const v335=v307["tangent_8"];
const v336=v137["tangent_8"];
const v337=(__dfNumber(v335) - __dfNumber(v336));
const v338=v307["tangent_9"];
const v339=v137["tangent_9"];
const v340=(__dfNumber(v338) - __dfNumber(v339));
const v341=v307["tangent_10"];
const v342=v137["tangent_10"];
const v343=(__dfNumber(v341) - __dfNumber(v342));
const v344=v307["tangent_11"];
const v345=v137["tangent_11"];
const v346=(__dfNumber(v344) - __dfNumber(v345));
const v348=v136["r"];
const v349=v348["b"];
const v350=v349["value"];
const v351=v137["value"];
const v352=(__dfNumber(v350) + __dfNumber(v351));
const v353=v349["tangent_0"];
const v354=v137["tangent_0"];
const v355=(__dfNumber(v353) + __dfNumber(v354));
const v356=v349["tangent_1"];
const v357=v137["tangent_1"];
const v358=(__dfNumber(v356) + __dfNumber(v357));
const v359=v349["tangent_2"];
const v360=v137["tangent_2"];
const v361=(__dfNumber(v359) + __dfNumber(v360));
const v362=v349["tangent_3"];
const v363=v137["tangent_3"];
const v364=(__dfNumber(v362) + __dfNumber(v363));
const v365=v349["tangent_4"];
const v366=v137["tangent_4"];
const v367=(__dfNumber(v365) + __dfNumber(v366));
const v368=v349["tangent_5"];
const v369=v137["tangent_5"];
const v370=(__dfNumber(v368) + __dfNumber(v369));
const v371=v349["tangent_6"];
const v372=v137["tangent_6"];
const v373=(__dfNumber(v371) + __dfNumber(v372));
const v374=v349["tangent_7"];
const v375=v137["tangent_7"];
const v376=(__dfNumber(v374) + __dfNumber(v375));
const v377=v349["tangent_8"];
const v378=v137["tangent_8"];
const v379=(__dfNumber(v377) + __dfNumber(v378));
const v380=v349["tangent_9"];
const v381=v137["tangent_9"];
const v382=(__dfNumber(v380) + __dfNumber(v381));
const v383=v349["tangent_10"];
const v384=v137["tangent_10"];
const v385=(__dfNumber(v383) + __dfNumber(v384));
const v386=v349["tangent_11"];
const v387=v137["tangent_11"];
const v388=(__dfNumber(v386) + __dfNumber(v387));
const v390=v136["s"];
const v391=v390["a"];
const v392=v391["value"];
const v393=v137["value"];
const v394=(__dfNumber(v392) - __dfNumber(v393));
const v395=v391["tangent_0"];
const v396=v137["tangent_0"];
const v397=(__dfNumber(v395) - __dfNumber(v396));
const v398=v391["tangent_1"];
const v399=v137["tangent_1"];
const v400=(__dfNumber(v398) - __dfNumber(v399));
const v401=v391["tangent_2"];
const v402=v137["tangent_2"];
const v403=(__dfNumber(v401) - __dfNumber(v402));
const v404=v391["tangent_3"];
const v405=v137["tangent_3"];
const v406=(__dfNumber(v404) - __dfNumber(v405));
const v407=v391["tangent_4"];
const v408=v137["tangent_4"];
const v409=(__dfNumber(v407) - __dfNumber(v408));
const v410=v391["tangent_5"];
const v411=v137["tangent_5"];
const v412=(__dfNumber(v410) - __dfNumber(v411));
const v413=v391["tangent_6"];
const v414=v137["tangent_6"];
const v415=(__dfNumber(v413) - __dfNumber(v414));
const v416=v391["tangent_7"];
const v417=v137["tangent_7"];
const v418=(__dfNumber(v416) - __dfNumber(v417));
const v419=v391["tangent_8"];
const v420=v137["tangent_8"];
const v421=(__dfNumber(v419) - __dfNumber(v420));
const v422=v391["tangent_9"];
const v423=v137["tangent_9"];
const v424=(__dfNumber(v422) - __dfNumber(v423));
const v425=v391["tangent_10"];
const v426=v137["tangent_10"];
const v427=(__dfNumber(v425) - __dfNumber(v426));
const v428=v391["tangent_11"];
const v429=v137["tangent_11"];
const v430=(__dfNumber(v428) - __dfNumber(v429));
const v432=v136["s"];
const v433=v432["b"];
const v434=v433["value"];
const v435=v137["value"];
const v436=(__dfNumber(v434) + __dfNumber(v435));
const v437=v433["tangent_0"];
const v438=v137["tangent_0"];
const v439=(__dfNumber(v437) + __dfNumber(v438));
const v440=v433["tangent_1"];
const v441=v137["tangent_1"];
const v442=(__dfNumber(v440) + __dfNumber(v441));
const v443=v433["tangent_2"];
const v444=v137["tangent_2"];
const v445=(__dfNumber(v443) + __dfNumber(v444));
const v446=v433["tangent_3"];
const v447=v137["tangent_3"];
const v448=(__dfNumber(v446) + __dfNumber(v447));
const v449=v433["tangent_4"];
const v450=v137["tangent_4"];
const v451=(__dfNumber(v449) + __dfNumber(v450));
const v452=v433["tangent_5"];
const v453=v137["tangent_5"];
const v454=(__dfNumber(v452) + __dfNumber(v453));
const v455=v433["tangent_6"];
const v456=v137["tangent_6"];
const v457=(__dfNumber(v455) + __dfNumber(v456));
const v458=v433["tangent_7"];
const v459=v137["tangent_7"];
const v460=(__dfNumber(v458) + __dfNumber(v459));
const v461=v433["tangent_8"];
const v462=v137["tangent_8"];
const v463=(__dfNumber(v461) + __dfNumber(v462));
const v464=v433["tangent_9"];
const v465=v137["tangent_9"];
const v466=(__dfNumber(v464) + __dfNumber(v465));
const v467=v433["tangent_10"];
const v468=v137["tangent_10"];
const v469=(__dfNumber(v467) + __dfNumber(v468));
const v470=v433["tangent_11"];
const v471=v137["tangent_11"];
const v472=(__dfNumber(v470) + __dfNumber(v471));
const v474=v136["t"];
const v475=v474["a"];
const v476=v475["value"];
const v477=v137["value"];
const v478=(__dfNumber(v476) - __dfNumber(v477));
const v479=v475["tangent_0"];
const v480=v137["tangent_0"];
const v481=(__dfNumber(v479) - __dfNumber(v480));
const v482=v475["tangent_1"];
const v483=v137["tangent_1"];
const v484=(__dfNumber(v482) - __dfNumber(v483));
const v485=v475["tangent_2"];
const v486=v137["tangent_2"];
const v487=(__dfNumber(v485) - __dfNumber(v486));
const v488=v475["tangent_3"];
const v489=v137["tangent_3"];
const v490=(__dfNumber(v488) - __dfNumber(v489));
const v491=v475["tangent_4"];
const v492=v137["tangent_4"];
const v493=(__dfNumber(v491) - __dfNumber(v492));
const v494=v475["tangent_5"];
const v495=v137["tangent_5"];
const v496=(__dfNumber(v494) - __dfNumber(v495));
const v497=v475["tangent_6"];
const v498=v137["tangent_6"];
const v499=(__dfNumber(v497) - __dfNumber(v498));
const v500=v475["tangent_7"];
const v501=v137["tangent_7"];
const v502=(__dfNumber(v500) - __dfNumber(v501));
const v503=v475["tangent_8"];
const v504=v137["tangent_8"];
const v505=(__dfNumber(v503) - __dfNumber(v504));
const v506=v475["tangent_9"];
const v507=v137["tangent_9"];
const v508=(__dfNumber(v506) - __dfNumber(v507));
const v509=v475["tangent_10"];
const v510=v137["tangent_10"];
const v511=(__dfNumber(v509) - __dfNumber(v510));
const v512=v475["tangent_11"];
const v513=v137["tangent_11"];
const v514=(__dfNumber(v512) - __dfNumber(v513));
const v516=v136["t"];
const v517=v516["b"];
const v518=v517["value"];
const v519=v137["value"];
const v520=(__dfNumber(v518) + __dfNumber(v519));
const v521=v517["tangent_0"];
const v522=v137["tangent_0"];
const v523=(__dfNumber(v521) + __dfNumber(v522));
const v524=v517["tangent_1"];
const v525=v137["tangent_1"];
const v526=(__dfNumber(v524) + __dfNumber(v525));
const v527=v517["tangent_2"];
const v528=v137["tangent_2"];
const v529=(__dfNumber(v527) + __dfNumber(v528));
const v530=v517["tangent_3"];
const v531=v137["tangent_3"];
const v532=(__dfNumber(v530) + __dfNumber(v531));
const v533=v517["tangent_4"];
const v534=v137["tangent_4"];
const v535=(__dfNumber(v533) + __dfNumber(v534));
const v536=v517["tangent_5"];
const v537=v137["tangent_5"];
const v538=(__dfNumber(v536) + __dfNumber(v537));
const v539=v517["tangent_6"];
const v540=v137["tangent_6"];
const v541=(__dfNumber(v539) + __dfNumber(v540));
const v542=v517["tangent_7"];
const v543=v137["tangent_7"];
const v544=(__dfNumber(v542) + __dfNumber(v543));
const v545=v517["tangent_8"];
const v546=v137["tangent_8"];
const v547=(__dfNumber(v545) + __dfNumber(v546));
const v548=v517["tangent_9"];
const v549=v137["tangent_9"];
const v550=(__dfNumber(v548) + __dfNumber(v549));
const v551=v517["tangent_10"];
const v552=v137["tangent_10"];
const v553=(__dfNumber(v551) + __dfNumber(v552));
const v554=v517["tangent_11"];
const v555=v137["tangent_11"];
const v556=(__dfNumber(v554) + __dfNumber(v555));
const v558=v136["u"];
const v559=v558["a"];
const v560=v559["value"];
const v561=v137["value"];
const v562=(__dfNumber(v560) - __dfNumber(v561));
const v563=v559["tangent_0"];
const v564=v137["tangent_0"];
const v565=(__dfNumber(v563) - __dfNumber(v564));
const v566=v559["tangent_1"];
const v567=v137["tangent_1"];
const v568=(__dfNumber(v566) - __dfNumber(v567));
const v569=v559["tangent_2"];
const v570=v137["tangent_2"];
const v571=(__dfNumber(v569) - __dfNumber(v570));
const v572=v559["tangent_3"];
const v573=v137["tangent_3"];
const v574=(__dfNumber(v572) - __dfNumber(v573));
const v575=v559["tangent_4"];
const v576=v137["tangent_4"];
const v577=(__dfNumber(v575) - __dfNumber(v576));
const v578=v559["tangent_5"];
const v579=v137["tangent_5"];
const v580=(__dfNumber(v578) - __dfNumber(v579));
const v581=v559["tangent_6"];
const v582=v137["tangent_6"];
const v583=(__dfNumber(v581) - __dfNumber(v582));
const v584=v559["tangent_7"];
const v585=v137["tangent_7"];
const v586=(__dfNumber(v584) - __dfNumber(v585));
const v587=v559["tangent_8"];
const v588=v137["tangent_8"];
const v589=(__dfNumber(v587) - __dfNumber(v588));
const v590=v559["tangent_9"];
const v591=v137["tangent_9"];
const v592=(__dfNumber(v590) - __dfNumber(v591));
const v593=v559["tangent_10"];
const v594=v137["tangent_10"];
const v595=(__dfNumber(v593) - __dfNumber(v594));
const v596=v559["tangent_11"];
const v597=v137["tangent_11"];
const v598=(__dfNumber(v596) - __dfNumber(v597));
const v600=v136["u"];
const v601=v600["b"];
const v602=v601["value"];
const v603=v137["value"];
const v604=(__dfNumber(v602) + __dfNumber(v603));
const v605=v601["tangent_0"];
const v606=v137["tangent_0"];
const v607=(__dfNumber(v605) + __dfNumber(v606));
const v608=v601["tangent_1"];
const v609=v137["tangent_1"];
const v610=(__dfNumber(v608) + __dfNumber(v609));
const v611=v601["tangent_2"];
const v612=v137["tangent_2"];
const v613=(__dfNumber(v611) + __dfNumber(v612));
const v614=v601["tangent_3"];
const v615=v137["tangent_3"];
const v616=(__dfNumber(v614) + __dfNumber(v615));
const v617=v601["tangent_4"];
const v618=v137["tangent_4"];
const v619=(__dfNumber(v617) + __dfNumber(v618));
const v620=v601["tangent_5"];
const v621=v137["tangent_5"];
const v622=(__dfNumber(v620) + __dfNumber(v621));
const v623=v601["tangent_6"];
const v624=v137["tangent_6"];
const v625=(__dfNumber(v623) + __dfNumber(v624));
const v626=v601["tangent_7"];
const v627=v137["tangent_7"];
const v628=(__dfNumber(v626) + __dfNumber(v627));
const v629=v601["tangent_8"];
const v630=v137["tangent_8"];
const v631=(__dfNumber(v629) + __dfNumber(v630));
const v632=v601["tangent_9"];
const v633=v137["tangent_9"];
const v634=(__dfNumber(v632) + __dfNumber(v633));
const v635=v601["tangent_10"];
const v636=v137["tangent_10"];
const v637=(__dfNumber(v635) + __dfNumber(v636));
const v638=v601["tangent_11"];
const v639=v137["tangent_11"];
const v640=(__dfNumber(v638) + __dfNumber(v639));
const v642=(__dfNumber(v142) * __dfNumber(v142));
const v643=(__dfNumber(v145) * __dfNumber(v142));
const v644=(__dfNumber(v142) * __dfNumber(v145));
const v645=(__dfNumber(v643) + __dfNumber(v644));
const v646=(__dfNumber(v148) * __dfNumber(v142));
const v647=(__dfNumber(v142) * __dfNumber(v148));
const v648=(__dfNumber(v646) + __dfNumber(v647));
const v649=(__dfNumber(v151) * __dfNumber(v142));
const v650=(__dfNumber(v142) * __dfNumber(v151));
const v651=(__dfNumber(v649) + __dfNumber(v650));
const v652=(__dfNumber(v154) * __dfNumber(v142));
const v653=(__dfNumber(v142) * __dfNumber(v154));
const v654=(__dfNumber(v652) + __dfNumber(v653));
const v655=(__dfNumber(v157) * __dfNumber(v142));
const v656=(__dfNumber(v142) * __dfNumber(v157));
const v657=(__dfNumber(v655) + __dfNumber(v656));
const v658=(__dfNumber(v160) * __dfNumber(v142));
const v659=(__dfNumber(v142) * __dfNumber(v160));
const v660=(__dfNumber(v658) + __dfNumber(v659));
const v661=(__dfNumber(v163) * __dfNumber(v142));
const v662=(__dfNumber(v142) * __dfNumber(v163));
const v663=(__dfNumber(v661) + __dfNumber(v662));
const v664=(__dfNumber(v166) * __dfNumber(v142));
const v665=(__dfNumber(v142) * __dfNumber(v166));
const v666=(__dfNumber(v664) + __dfNumber(v665));
const v667=(__dfNumber(v169) * __dfNumber(v142));
const v668=(__dfNumber(v142) * __dfNumber(v169));
const v669=(__dfNumber(v667) + __dfNumber(v668));
const v670=(__dfNumber(v172) * __dfNumber(v142));
const v671=(__dfNumber(v142) * __dfNumber(v172));
const v672=(__dfNumber(v670) + __dfNumber(v671));
const v673=(__dfNumber(v175) * __dfNumber(v142));
const v674=(__dfNumber(v142) * __dfNumber(v175));
const v675=(__dfNumber(v673) + __dfNumber(v674));
const v676=(__dfNumber(v178) * __dfNumber(v142));
const v677=(__dfNumber(v142) * __dfNumber(v178));
const v678=(__dfNumber(v676) + __dfNumber(v677));
const v680=(__dfNumber(v184) * __dfNumber(v184));
const v681=(__dfNumber(v187) * __dfNumber(v184));
const v682=(__dfNumber(v184) * __dfNumber(v187));
const v683=(__dfNumber(v681) + __dfNumber(v682));
const v684=(__dfNumber(v190) * __dfNumber(v184));
const v685=(__dfNumber(v184) * __dfNumber(v190));
const v686=(__dfNumber(v684) + __dfNumber(v685));
const v687=(__dfNumber(v193) * __dfNumber(v184));
const v688=(__dfNumber(v184) * __dfNumber(v193));
const v689=(__dfNumber(v687) + __dfNumber(v688));
const v690=(__dfNumber(v196) * __dfNumber(v184));
const v691=(__dfNumber(v184) * __dfNumber(v196));
const v692=(__dfNumber(v690) + __dfNumber(v691));
const v693=(__dfNumber(v199) * __dfNumber(v184));
const v694=(__dfNumber(v184) * __dfNumber(v199));
const v695=(__dfNumber(v693) + __dfNumber(v694));
const v696=(__dfNumber(v202) * __dfNumber(v184));
const v697=(__dfNumber(v184) * __dfNumber(v202));
const v698=(__dfNumber(v696) + __dfNumber(v697));
const v699=(__dfNumber(v205) * __dfNumber(v184));
const v700=(__dfNumber(v184) * __dfNumber(v205));
const v701=(__dfNumber(v699) + __dfNumber(v700));
const v702=(__dfNumber(v208) * __dfNumber(v184));
const v703=(__dfNumber(v184) * __dfNumber(v208));
const v704=(__dfNumber(v702) + __dfNumber(v703));
const v705=(__dfNumber(v211) * __dfNumber(v184));
const v706=(__dfNumber(v184) * __dfNumber(v211));
const v707=(__dfNumber(v705) + __dfNumber(v706));
const v708=(__dfNumber(v214) * __dfNumber(v184));
const v709=(__dfNumber(v184) * __dfNumber(v214));
const v710=(__dfNumber(v708) + __dfNumber(v709));
const v711=(__dfNumber(v217) * __dfNumber(v184));
const v712=(__dfNumber(v184) * __dfNumber(v217));
const v713=(__dfNumber(v711) + __dfNumber(v712));
const v714=(__dfNumber(v220) * __dfNumber(v184));
const v715=(__dfNumber(v184) * __dfNumber(v220));
const v716=(__dfNumber(v714) + __dfNumber(v715));
const v718=(__dfNumber(v642) + __dfNumber(v680));
const v719=(__dfNumber(v645) + __dfNumber(v683));
const v720=(__dfNumber(v648) + __dfNumber(v686));
const v721=(__dfNumber(v651) + __dfNumber(v689));
const v722=(__dfNumber(v654) + __dfNumber(v692));
const v723=(__dfNumber(v657) + __dfNumber(v695));
const v724=(__dfNumber(v660) + __dfNumber(v698));
const v725=(__dfNumber(v663) + __dfNumber(v701));
const v726=(__dfNumber(v666) + __dfNumber(v704));
const v727=(__dfNumber(v669) + __dfNumber(v707));
const v728=(__dfNumber(v672) + __dfNumber(v710));
const v729=(__dfNumber(v675) + __dfNumber(v713));
const v730=(__dfNumber(v678) + __dfNumber(v716));
const v732=(__dfNumber(v226) * __dfNumber(v226));
const v733=(__dfNumber(v229) * __dfNumber(v226));
const v734=(__dfNumber(v226) * __dfNumber(v229));
const v735=(__dfNumber(v733) + __dfNumber(v734));
const v736=(__dfNumber(v232) * __dfNumber(v226));
const v737=(__dfNumber(v226) * __dfNumber(v232));
const v738=(__dfNumber(v736) + __dfNumber(v737));
const v739=(__dfNumber(v235) * __dfNumber(v226));
const v740=(__dfNumber(v226) * __dfNumber(v235));
const v741=(__dfNumber(v739) + __dfNumber(v740));
const v742=(__dfNumber(v238) * __dfNumber(v226));
const v743=(__dfNumber(v226) * __dfNumber(v238));
const v744=(__dfNumber(v742) + __dfNumber(v743));
const v745=(__dfNumber(v241) * __dfNumber(v226));
const v746=(__dfNumber(v226) * __dfNumber(v241));
const v747=(__dfNumber(v745) + __dfNumber(v746));
const v748=(__dfNumber(v244) * __dfNumber(v226));
const v749=(__dfNumber(v226) * __dfNumber(v244));
const v750=(__dfNumber(v748) + __dfNumber(v749));
const v751=(__dfNumber(v247) * __dfNumber(v226));
const v752=(__dfNumber(v226) * __dfNumber(v247));
const v753=(__dfNumber(v751) + __dfNumber(v752));
const v754=(__dfNumber(v250) * __dfNumber(v226));
const v755=(__dfNumber(v226) * __dfNumber(v250));
const v756=(__dfNumber(v754) + __dfNumber(v755));
const v757=(__dfNumber(v253) * __dfNumber(v226));
const v758=(__dfNumber(v226) * __dfNumber(v253));
const v759=(__dfNumber(v757) + __dfNumber(v758));
const v760=(__dfNumber(v256) * __dfNumber(v226));
const v761=(__dfNumber(v226) * __dfNumber(v256));
const v762=(__dfNumber(v760) + __dfNumber(v761));
const v763=(__dfNumber(v259) * __dfNumber(v226));
const v764=(__dfNumber(v226) * __dfNumber(v259));
const v765=(__dfNumber(v763) + __dfNumber(v764));
const v766=(__dfNumber(v262) * __dfNumber(v226));
const v767=(__dfNumber(v226) * __dfNumber(v262));
const v768=(__dfNumber(v766) + __dfNumber(v767));
const v770=(__dfNumber(v718) + __dfNumber(v732));
const v771=(__dfNumber(v719) + __dfNumber(v735));
const v772=(__dfNumber(v720) + __dfNumber(v738));
const v773=(__dfNumber(v721) + __dfNumber(v741));
const v774=(__dfNumber(v722) + __dfNumber(v744));
const v775=(__dfNumber(v723) + __dfNumber(v747));
const v776=(__dfNumber(v724) + __dfNumber(v750));
const v777=(__dfNumber(v725) + __dfNumber(v753));
const v778=(__dfNumber(v726) + __dfNumber(v756));
const v779=(__dfNumber(v727) + __dfNumber(v759));
const v780=(__dfNumber(v728) + __dfNumber(v762));
const v781=(__dfNumber(v729) + __dfNumber(v765));
const v782=(__dfNumber(v730) + __dfNumber(v768));
const v784=(__dfNumber(v268) * __dfNumber(v268));
const v785=(__dfNumber(v271) * __dfNumber(v268));
const v786=(__dfNumber(v268) * __dfNumber(v271));
const v787=(__dfNumber(v785) + __dfNumber(v786));
const v788=(__dfNumber(v274) * __dfNumber(v268));
const v789=(__dfNumber(v268) * __dfNumber(v274));
const v790=(__dfNumber(v788) + __dfNumber(v789));
const v791=(__dfNumber(v277) * __dfNumber(v268));
const v792=(__dfNumber(v268) * __dfNumber(v277));
const v793=(__dfNumber(v791) + __dfNumber(v792));
const v794=(__dfNumber(v280) * __dfNumber(v268));
const v795=(__dfNumber(v268) * __dfNumber(v280));
const v796=(__dfNumber(v794) + __dfNumber(v795));
const v797=(__dfNumber(v283) * __dfNumber(v268));
const v798=(__dfNumber(v268) * __dfNumber(v283));
const v799=(__dfNumber(v797) + __dfNumber(v798));
const v800=(__dfNumber(v286) * __dfNumber(v268));
const v801=(__dfNumber(v268) * __dfNumber(v286));
const v802=(__dfNumber(v800) + __dfNumber(v801));
const v803=(__dfNumber(v289) * __dfNumber(v268));
const v804=(__dfNumber(v268) * __dfNumber(v289));
const v805=(__dfNumber(v803) + __dfNumber(v804));
const v806=(__dfNumber(v292) * __dfNumber(v268));
const v807=(__dfNumber(v268) * __dfNumber(v292));
const v808=(__dfNumber(v806) + __dfNumber(v807));
const v809=(__dfNumber(v295) * __dfNumber(v268));
const v810=(__dfNumber(v268) * __dfNumber(v295));
const v811=(__dfNumber(v809) + __dfNumber(v810));
const v812=(__dfNumber(v298) * __dfNumber(v268));
const v813=(__dfNumber(v268) * __dfNumber(v298));
const v814=(__dfNumber(v812) + __dfNumber(v813));
const v815=(__dfNumber(v301) * __dfNumber(v268));
const v816=(__dfNumber(v268) * __dfNumber(v301));
const v817=(__dfNumber(v815) + __dfNumber(v816));
const v818=(__dfNumber(v304) * __dfNumber(v268));
const v819=(__dfNumber(v268) * __dfNumber(v304));
const v820=(__dfNumber(v818) + __dfNumber(v819));
const v822=(__dfNumber(v770) + __dfNumber(v784));
const v823=(__dfNumber(v771) + __dfNumber(v787));
const v824=(__dfNumber(v772) + __dfNumber(v790));
const v825=(__dfNumber(v773) + __dfNumber(v793));
const v826=(__dfNumber(v774) + __dfNumber(v796));
const v827=(__dfNumber(v775) + __dfNumber(v799));
const v828=(__dfNumber(v776) + __dfNumber(v802));
const v829=(__dfNumber(v777) + __dfNumber(v805));
const v830=(__dfNumber(v778) + __dfNumber(v808));
const v831=(__dfNumber(v779) + __dfNumber(v811));
const v832=(__dfNumber(v780) + __dfNumber(v814));
const v833=(__dfNumber(v781) + __dfNumber(v817));
const v834=(__dfNumber(v782) + __dfNumber(v820));
const v836=(__dfNumber(v310) * __dfNumber(v310));
const v837=(__dfNumber(v313) * __dfNumber(v310));
const v838=(__dfNumber(v310) * __dfNumber(v313));
const v839=(__dfNumber(v837) + __dfNumber(v838));
const v840=(__dfNumber(v316) * __dfNumber(v310));
const v841=(__dfNumber(v310) * __dfNumber(v316));
const v842=(__dfNumber(v840) + __dfNumber(v841));
const v843=(__dfNumber(v319) * __dfNumber(v310));
const v844=(__dfNumber(v310) * __dfNumber(v319));
const v845=(__dfNumber(v843) + __dfNumber(v844));
const v846=(__dfNumber(v322) * __dfNumber(v310));
const v847=(__dfNumber(v310) * __dfNumber(v322));
const v848=(__dfNumber(v846) + __dfNumber(v847));
const v849=(__dfNumber(v325) * __dfNumber(v310));
const v850=(__dfNumber(v310) * __dfNumber(v325));
const v851=(__dfNumber(v849) + __dfNumber(v850));
const v852=(__dfNumber(v328) * __dfNumber(v310));
const v853=(__dfNumber(v310) * __dfNumber(v328));
const v854=(__dfNumber(v852) + __dfNumber(v853));
const v855=(__dfNumber(v331) * __dfNumber(v310));
const v856=(__dfNumber(v310) * __dfNumber(v331));
const v857=(__dfNumber(v855) + __dfNumber(v856));
const v858=(__dfNumber(v334) * __dfNumber(v310));
const v859=(__dfNumber(v310) * __dfNumber(v334));
const v860=(__dfNumber(v858) + __dfNumber(v859));
const v861=(__dfNumber(v337) * __dfNumber(v310));
const v862=(__dfNumber(v310) * __dfNumber(v337));
const v863=(__dfNumber(v861) + __dfNumber(v862));
const v864=(__dfNumber(v340) * __dfNumber(v310));
const v865=(__dfNumber(v310) * __dfNumber(v340));
const v866=(__dfNumber(v864) + __dfNumber(v865));
const v867=(__dfNumber(v343) * __dfNumber(v310));
const v868=(__dfNumber(v310) * __dfNumber(v343));
const v869=(__dfNumber(v867) + __dfNumber(v868));
const v870=(__dfNumber(v346) * __dfNumber(v310));
const v871=(__dfNumber(v310) * __dfNumber(v346));
const v872=(__dfNumber(v870) + __dfNumber(v871));
const v874=(__dfNumber(v822) + __dfNumber(v836));
const v875=(__dfNumber(v823) + __dfNumber(v839));
const v876=(__dfNumber(v824) + __dfNumber(v842));
const v877=(__dfNumber(v825) + __dfNumber(v845));
const v878=(__dfNumber(v826) + __dfNumber(v848));
const v879=(__dfNumber(v827) + __dfNumber(v851));
const v880=(__dfNumber(v828) + __dfNumber(v854));
const v881=(__dfNumber(v829) + __dfNumber(v857));
const v882=(__dfNumber(v830) + __dfNumber(v860));
const v883=(__dfNumber(v831) + __dfNumber(v863));
const v884=(__dfNumber(v832) + __dfNumber(v866));
const v885=(__dfNumber(v833) + __dfNumber(v869));
const v886=(__dfNumber(v834) + __dfNumber(v872));
const v888=(__dfNumber(v352) * __dfNumber(v352));
const v889=(__dfNumber(v355) * __dfNumber(v352));
const v890=(__dfNumber(v352) * __dfNumber(v355));
const v891=(__dfNumber(v889) + __dfNumber(v890));
const v892=(__dfNumber(v358) * __dfNumber(v352));
const v893=(__dfNumber(v352) * __dfNumber(v358));
const v894=(__dfNumber(v892) + __dfNumber(v893));
const v895=(__dfNumber(v361) * __dfNumber(v352));
const v896=(__dfNumber(v352) * __dfNumber(v361));
const v897=(__dfNumber(v895) + __dfNumber(v896));
const v898=(__dfNumber(v364) * __dfNumber(v352));
const v899=(__dfNumber(v352) * __dfNumber(v364));
const v900=(__dfNumber(v898) + __dfNumber(v899));
const v901=(__dfNumber(v367) * __dfNumber(v352));
const v902=(__dfNumber(v352) * __dfNumber(v367));
const v903=(__dfNumber(v901) + __dfNumber(v902));
const v904=(__dfNumber(v370) * __dfNumber(v352));
const v905=(__dfNumber(v352) * __dfNumber(v370));
const v906=(__dfNumber(v904) + __dfNumber(v905));
const v907=(__dfNumber(v373) * __dfNumber(v352));
const v908=(__dfNumber(v352) * __dfNumber(v373));
const v909=(__dfNumber(v907) + __dfNumber(v908));
const v910=(__dfNumber(v376) * __dfNumber(v352));
const v911=(__dfNumber(v352) * __dfNumber(v376));
const v912=(__dfNumber(v910) + __dfNumber(v911));
const v913=(__dfNumber(v379) * __dfNumber(v352));
const v914=(__dfNumber(v352) * __dfNumber(v379));
const v915=(__dfNumber(v913) + __dfNumber(v914));
const v916=(__dfNumber(v382) * __dfNumber(v352));
const v917=(__dfNumber(v352) * __dfNumber(v382));
const v918=(__dfNumber(v916) + __dfNumber(v917));
const v919=(__dfNumber(v385) * __dfNumber(v352));
const v920=(__dfNumber(v352) * __dfNumber(v385));
const v921=(__dfNumber(v919) + __dfNumber(v920));
const v922=(__dfNumber(v388) * __dfNumber(v352));
const v923=(__dfNumber(v352) * __dfNumber(v388));
const v924=(__dfNumber(v922) + __dfNumber(v923));
const v926=(__dfNumber(v874) + __dfNumber(v888));
const v927=(__dfNumber(v875) + __dfNumber(v891));
const v928=(__dfNumber(v876) + __dfNumber(v894));
const v929=(__dfNumber(v877) + __dfNumber(v897));
const v930=(__dfNumber(v878) + __dfNumber(v900));
const v931=(__dfNumber(v879) + __dfNumber(v903));
const v932=(__dfNumber(v880) + __dfNumber(v906));
const v933=(__dfNumber(v881) + __dfNumber(v909));
const v934=(__dfNumber(v882) + __dfNumber(v912));
const v935=(__dfNumber(v883) + __dfNumber(v915));
const v936=(__dfNumber(v884) + __dfNumber(v918));
const v937=(__dfNumber(v885) + __dfNumber(v921));
const v938=(__dfNumber(v886) + __dfNumber(v924));
const v940=(__dfNumber(v394) * __dfNumber(v394));
const v941=(__dfNumber(v397) * __dfNumber(v394));
const v942=(__dfNumber(v394) * __dfNumber(v397));
const v943=(__dfNumber(v941) + __dfNumber(v942));
const v944=(__dfNumber(v400) * __dfNumber(v394));
const v945=(__dfNumber(v394) * __dfNumber(v400));
const v946=(__dfNumber(v944) + __dfNumber(v945));
const v947=(__dfNumber(v403) * __dfNumber(v394));
const v948=(__dfNumber(v394) * __dfNumber(v403));
const v949=(__dfNumber(v947) + __dfNumber(v948));
const v950=(__dfNumber(v406) * __dfNumber(v394));
const v951=(__dfNumber(v394) * __dfNumber(v406));
const v952=(__dfNumber(v950) + __dfNumber(v951));
const v953=(__dfNumber(v409) * __dfNumber(v394));
const v954=(__dfNumber(v394) * __dfNumber(v409));
const v955=(__dfNumber(v953) + __dfNumber(v954));
const v956=(__dfNumber(v412) * __dfNumber(v394));
const v957=(__dfNumber(v394) * __dfNumber(v412));
const v958=(__dfNumber(v956) + __dfNumber(v957));
const v959=(__dfNumber(v415) * __dfNumber(v394));
const v960=(__dfNumber(v394) * __dfNumber(v415));
const v961=(__dfNumber(v959) + __dfNumber(v960));
const v962=(__dfNumber(v418) * __dfNumber(v394));
const v963=(__dfNumber(v394) * __dfNumber(v418));
const v964=(__dfNumber(v962) + __dfNumber(v963));
const v965=(__dfNumber(v421) * __dfNumber(v394));
const v966=(__dfNumber(v394) * __dfNumber(v421));
const v967=(__dfNumber(v965) + __dfNumber(v966));
const v968=(__dfNumber(v424) * __dfNumber(v394));
const v969=(__dfNumber(v394) * __dfNumber(v424));
const v970=(__dfNumber(v968) + __dfNumber(v969));
const v971=(__dfNumber(v427) * __dfNumber(v394));
const v972=(__dfNumber(v394) * __dfNumber(v427));
const v973=(__dfNumber(v971) + __dfNumber(v972));
const v974=(__dfNumber(v430) * __dfNumber(v394));
const v975=(__dfNumber(v394) * __dfNumber(v430));
const v976=(__dfNumber(v974) + __dfNumber(v975));
const v978=(__dfNumber(v926) + __dfNumber(v940));
const v979=(__dfNumber(v927) + __dfNumber(v943));
const v980=(__dfNumber(v928) + __dfNumber(v946));
const v981=(__dfNumber(v929) + __dfNumber(v949));
const v982=(__dfNumber(v930) + __dfNumber(v952));
const v983=(__dfNumber(v931) + __dfNumber(v955));
const v984=(__dfNumber(v932) + __dfNumber(v958));
const v985=(__dfNumber(v933) + __dfNumber(v961));
const v986=(__dfNumber(v934) + __dfNumber(v964));
const v987=(__dfNumber(v935) + __dfNumber(v967));
const v988=(__dfNumber(v936) + __dfNumber(v970));
const v989=(__dfNumber(v937) + __dfNumber(v973));
const v990=(__dfNumber(v938) + __dfNumber(v976));
const v992=(__dfNumber(v436) * __dfNumber(v436));
const v993=(__dfNumber(v439) * __dfNumber(v436));
const v994=(__dfNumber(v436) * __dfNumber(v439));
const v995=(__dfNumber(v993) + __dfNumber(v994));
const v996=(__dfNumber(v442) * __dfNumber(v436));
const v997=(__dfNumber(v436) * __dfNumber(v442));
const v998=(__dfNumber(v996) + __dfNumber(v997));
const v999=(__dfNumber(v445) * __dfNumber(v436));
const v1000=(__dfNumber(v436) * __dfNumber(v445));
const v1001=(__dfNumber(v999) + __dfNumber(v1000));
const v1002=(__dfNumber(v448) * __dfNumber(v436));
const v1003=(__dfNumber(v436) * __dfNumber(v448));
const v1004=(__dfNumber(v1002) + __dfNumber(v1003));
const v1005=(__dfNumber(v451) * __dfNumber(v436));
const v1006=(__dfNumber(v436) * __dfNumber(v451));
const v1007=(__dfNumber(v1005) + __dfNumber(v1006));
const v1008=(__dfNumber(v454) * __dfNumber(v436));
const v1009=(__dfNumber(v436) * __dfNumber(v454));
const v1010=(__dfNumber(v1008) + __dfNumber(v1009));
const v1011=(__dfNumber(v457) * __dfNumber(v436));
const v1012=(__dfNumber(v436) * __dfNumber(v457));
const v1013=(__dfNumber(v1011) + __dfNumber(v1012));
const v1014=(__dfNumber(v460) * __dfNumber(v436));
const v1015=(__dfNumber(v436) * __dfNumber(v460));
const v1016=(__dfNumber(v1014) + __dfNumber(v1015));
const v1017=(__dfNumber(v463) * __dfNumber(v436));
const v1018=(__dfNumber(v436) * __dfNumber(v463));
const v1019=(__dfNumber(v1017) + __dfNumber(v1018));
const v1020=(__dfNumber(v466) * __dfNumber(v436));
const v1021=(__dfNumber(v436) * __dfNumber(v466));
const v1022=(__dfNumber(v1020) + __dfNumber(v1021));
const v1023=(__dfNumber(v469) * __dfNumber(v436));
const v1024=(__dfNumber(v436) * __dfNumber(v469));
const v1025=(__dfNumber(v1023) + __dfNumber(v1024));
const v1026=(__dfNumber(v472) * __dfNumber(v436));
const v1027=(__dfNumber(v436) * __dfNumber(v472));
const v1028=(__dfNumber(v1026) + __dfNumber(v1027));
const v1030=(__dfNumber(v978) + __dfNumber(v992));
const v1031=(__dfNumber(v979) + __dfNumber(v995));
const v1032=(__dfNumber(v980) + __dfNumber(v998));
const v1033=(__dfNumber(v981) + __dfNumber(v1001));
const v1034=(__dfNumber(v982) + __dfNumber(v1004));
const v1035=(__dfNumber(v983) + __dfNumber(v1007));
const v1036=(__dfNumber(v984) + __dfNumber(v1010));
const v1037=(__dfNumber(v985) + __dfNumber(v1013));
const v1038=(__dfNumber(v986) + __dfNumber(v1016));
const v1039=(__dfNumber(v987) + __dfNumber(v1019));
const v1040=(__dfNumber(v988) + __dfNumber(v1022));
const v1041=(__dfNumber(v989) + __dfNumber(v1025));
const v1042=(__dfNumber(v990) + __dfNumber(v1028));
const v1044=(__dfNumber(v478) * __dfNumber(v478));
const v1045=(__dfNumber(v481) * __dfNumber(v478));
const v1046=(__dfNumber(v478) * __dfNumber(v481));
const v1047=(__dfNumber(v1045) + __dfNumber(v1046));
const v1048=(__dfNumber(v484) * __dfNumber(v478));
const v1049=(__dfNumber(v478) * __dfNumber(v484));
const v1050=(__dfNumber(v1048) + __dfNumber(v1049));
const v1051=(__dfNumber(v487) * __dfNumber(v478));
const v1052=(__dfNumber(v478) * __dfNumber(v487));
const v1053=(__dfNumber(v1051) + __dfNumber(v1052));
const v1054=(__dfNumber(v490) * __dfNumber(v478));
const v1055=(__dfNumber(v478) * __dfNumber(v490));
const v1056=(__dfNumber(v1054) + __dfNumber(v1055));
const v1057=(__dfNumber(v493) * __dfNumber(v478));
const v1058=(__dfNumber(v478) * __dfNumber(v493));
const v1059=(__dfNumber(v1057) + __dfNumber(v1058));
const v1060=(__dfNumber(v496) * __dfNumber(v478));
const v1061=(__dfNumber(v478) * __dfNumber(v496));
const v1062=(__dfNumber(v1060) + __dfNumber(v1061));
const v1063=(__dfNumber(v499) * __dfNumber(v478));
const v1064=(__dfNumber(v478) * __dfNumber(v499));
const v1065=(__dfNumber(v1063) + __dfNumber(v1064));
const v1066=(__dfNumber(v502) * __dfNumber(v478));
const v1067=(__dfNumber(v478) * __dfNumber(v502));
const v1068=(__dfNumber(v1066) + __dfNumber(v1067));
const v1069=(__dfNumber(v505) * __dfNumber(v478));
const v1070=(__dfNumber(v478) * __dfNumber(v505));
const v1071=(__dfNumber(v1069) + __dfNumber(v1070));
const v1072=(__dfNumber(v508) * __dfNumber(v478));
const v1073=(__dfNumber(v478) * __dfNumber(v508));
const v1074=(__dfNumber(v1072) + __dfNumber(v1073));
const v1075=(__dfNumber(v511) * __dfNumber(v478));
const v1076=(__dfNumber(v478) * __dfNumber(v511));
const v1077=(__dfNumber(v1075) + __dfNumber(v1076));
const v1078=(__dfNumber(v514) * __dfNumber(v478));
const v1079=(__dfNumber(v478) * __dfNumber(v514));
const v1080=(__dfNumber(v1078) + __dfNumber(v1079));
const v1082=(__dfNumber(v1030) + __dfNumber(v1044));
const v1083=(__dfNumber(v1031) + __dfNumber(v1047));
const v1084=(__dfNumber(v1032) + __dfNumber(v1050));
const v1085=(__dfNumber(v1033) + __dfNumber(v1053));
const v1086=(__dfNumber(v1034) + __dfNumber(v1056));
const v1087=(__dfNumber(v1035) + __dfNumber(v1059));
const v1088=(__dfNumber(v1036) + __dfNumber(v1062));
const v1089=(__dfNumber(v1037) + __dfNumber(v1065));
const v1090=(__dfNumber(v1038) + __dfNumber(v1068));
const v1091=(__dfNumber(v1039) + __dfNumber(v1071));
const v1092=(__dfNumber(v1040) + __dfNumber(v1074));
const v1093=(__dfNumber(v1041) + __dfNumber(v1077));
const v1094=(__dfNumber(v1042) + __dfNumber(v1080));
const v1096=(__dfNumber(v520) * __dfNumber(v520));
const v1097=(__dfNumber(v523) * __dfNumber(v520));
const v1098=(__dfNumber(v520) * __dfNumber(v523));
const v1099=(__dfNumber(v1097) + __dfNumber(v1098));
const v1100=(__dfNumber(v526) * __dfNumber(v520));
const v1101=(__dfNumber(v520) * __dfNumber(v526));
const v1102=(__dfNumber(v1100) + __dfNumber(v1101));
const v1103=(__dfNumber(v529) * __dfNumber(v520));
const v1104=(__dfNumber(v520) * __dfNumber(v529));
const v1105=(__dfNumber(v1103) + __dfNumber(v1104));
const v1106=(__dfNumber(v532) * __dfNumber(v520));
const v1107=(__dfNumber(v520) * __dfNumber(v532));
const v1108=(__dfNumber(v1106) + __dfNumber(v1107));
const v1109=(__dfNumber(v535) * __dfNumber(v520));
const v1110=(__dfNumber(v520) * __dfNumber(v535));
const v1111=(__dfNumber(v1109) + __dfNumber(v1110));
const v1112=(__dfNumber(v538) * __dfNumber(v520));
const v1113=(__dfNumber(v520) * __dfNumber(v538));
const v1114=(__dfNumber(v1112) + __dfNumber(v1113));
const v1115=(__dfNumber(v541) * __dfNumber(v520));
const v1116=(__dfNumber(v520) * __dfNumber(v541));
const v1117=(__dfNumber(v1115) + __dfNumber(v1116));
const v1118=(__dfNumber(v544) * __dfNumber(v520));
const v1119=(__dfNumber(v520) * __dfNumber(v544));
const v1120=(__dfNumber(v1118) + __dfNumber(v1119));
const v1121=(__dfNumber(v547) * __dfNumber(v520));
const v1122=(__dfNumber(v520) * __dfNumber(v547));
const v1123=(__dfNumber(v1121) + __dfNumber(v1122));
const v1124=(__dfNumber(v550) * __dfNumber(v520));
const v1125=(__dfNumber(v520) * __dfNumber(v550));
const v1126=(__dfNumber(v1124) + __dfNumber(v1125));
const v1127=(__dfNumber(v553) * __dfNumber(v520));
const v1128=(__dfNumber(v520) * __dfNumber(v553));
const v1129=(__dfNumber(v1127) + __dfNumber(v1128));
const v1130=(__dfNumber(v556) * __dfNumber(v520));
const v1131=(__dfNumber(v520) * __dfNumber(v556));
const v1132=(__dfNumber(v1130) + __dfNumber(v1131));
const v1134=(__dfNumber(v1082) + __dfNumber(v1096));
const v1135=(__dfNumber(v1083) + __dfNumber(v1099));
const v1136=(__dfNumber(v1084) + __dfNumber(v1102));
const v1137=(__dfNumber(v1085) + __dfNumber(v1105));
const v1138=(__dfNumber(v1086) + __dfNumber(v1108));
const v1139=(__dfNumber(v1087) + __dfNumber(v1111));
const v1140=(__dfNumber(v1088) + __dfNumber(v1114));
const v1141=(__dfNumber(v1089) + __dfNumber(v1117));
const v1142=(__dfNumber(v1090) + __dfNumber(v1120));
const v1143=(__dfNumber(v1091) + __dfNumber(v1123));
const v1144=(__dfNumber(v1092) + __dfNumber(v1126));
const v1145=(__dfNumber(v1093) + __dfNumber(v1129));
const v1146=(__dfNumber(v1094) + __dfNumber(v1132));
const v1148=(__dfNumber(v562) * __dfNumber(v562));
const v1149=(__dfNumber(v565) * __dfNumber(v562));
const v1150=(__dfNumber(v562) * __dfNumber(v565));
const v1151=(__dfNumber(v1149) + __dfNumber(v1150));
const v1152=(__dfNumber(v568) * __dfNumber(v562));
const v1153=(__dfNumber(v562) * __dfNumber(v568));
const v1154=(__dfNumber(v1152) + __dfNumber(v1153));
const v1155=(__dfNumber(v571) * __dfNumber(v562));
const v1156=(__dfNumber(v562) * __dfNumber(v571));
const v1157=(__dfNumber(v1155) + __dfNumber(v1156));
const v1158=(__dfNumber(v574) * __dfNumber(v562));
const v1159=(__dfNumber(v562) * __dfNumber(v574));
const v1160=(__dfNumber(v1158) + __dfNumber(v1159));
const v1161=(__dfNumber(v577) * __dfNumber(v562));
const v1162=(__dfNumber(v562) * __dfNumber(v577));
const v1163=(__dfNumber(v1161) + __dfNumber(v1162));
const v1164=(__dfNumber(v580) * __dfNumber(v562));
const v1165=(__dfNumber(v562) * __dfNumber(v580));
const v1166=(__dfNumber(v1164) + __dfNumber(v1165));
const v1167=(__dfNumber(v583) * __dfNumber(v562));
const v1168=(__dfNumber(v562) * __dfNumber(v583));
const v1169=(__dfNumber(v1167) + __dfNumber(v1168));
const v1170=(__dfNumber(v586) * __dfNumber(v562));
const v1171=(__dfNumber(v562) * __dfNumber(v586));
const v1172=(__dfNumber(v1170) + __dfNumber(v1171));
const v1173=(__dfNumber(v589) * __dfNumber(v562));
const v1174=(__dfNumber(v562) * __dfNumber(v589));
const v1175=(__dfNumber(v1173) + __dfNumber(v1174));
const v1176=(__dfNumber(v592) * __dfNumber(v562));
const v1177=(__dfNumber(v562) * __dfNumber(v592));
const v1178=(__dfNumber(v1176) + __dfNumber(v1177));
const v1179=(__dfNumber(v595) * __dfNumber(v562));
const v1180=(__dfNumber(v562) * __dfNumber(v595));
const v1181=(__dfNumber(v1179) + __dfNumber(v1180));
const v1182=(__dfNumber(v598) * __dfNumber(v562));
const v1183=(__dfNumber(v562) * __dfNumber(v598));
const v1184=(__dfNumber(v1182) + __dfNumber(v1183));
const v1186=(__dfNumber(v1134) + __dfNumber(v1148));
const v1187=(__dfNumber(v1135) + __dfNumber(v1151));
const v1188=(__dfNumber(v1136) + __dfNumber(v1154));
const v1189=(__dfNumber(v1137) + __dfNumber(v1157));
const v1190=(__dfNumber(v1138) + __dfNumber(v1160));
const v1191=(__dfNumber(v1139) + __dfNumber(v1163));
const v1192=(__dfNumber(v1140) + __dfNumber(v1166));
const v1193=(__dfNumber(v1141) + __dfNumber(v1169));
const v1194=(__dfNumber(v1142) + __dfNumber(v1172));
const v1195=(__dfNumber(v1143) + __dfNumber(v1175));
const v1196=(__dfNumber(v1144) + __dfNumber(v1178));
const v1197=(__dfNumber(v1145) + __dfNumber(v1181));
const v1198=(__dfNumber(v1146) + __dfNumber(v1184));
const v1200=(__dfNumber(v604) * __dfNumber(v604));
const v1201=(__dfNumber(v607) * __dfNumber(v604));
const v1202=(__dfNumber(v604) * __dfNumber(v607));
const v1203=(__dfNumber(v1201) + __dfNumber(v1202));
const v1204=(__dfNumber(v610) * __dfNumber(v604));
const v1205=(__dfNumber(v604) * __dfNumber(v610));
const v1206=(__dfNumber(v1204) + __dfNumber(v1205));
const v1207=(__dfNumber(v613) * __dfNumber(v604));
const v1208=(__dfNumber(v604) * __dfNumber(v613));
const v1209=(__dfNumber(v1207) + __dfNumber(v1208));
const v1210=(__dfNumber(v616) * __dfNumber(v604));
const v1211=(__dfNumber(v604) * __dfNumber(v616));
const v1212=(__dfNumber(v1210) + __dfNumber(v1211));
const v1213=(__dfNumber(v619) * __dfNumber(v604));
const v1214=(__dfNumber(v604) * __dfNumber(v619));
const v1215=(__dfNumber(v1213) + __dfNumber(v1214));
const v1216=(__dfNumber(v622) * __dfNumber(v604));
const v1217=(__dfNumber(v604) * __dfNumber(v622));
const v1218=(__dfNumber(v1216) + __dfNumber(v1217));
const v1219=(__dfNumber(v625) * __dfNumber(v604));
const v1220=(__dfNumber(v604) * __dfNumber(v625));
const v1221=(__dfNumber(v1219) + __dfNumber(v1220));
const v1222=(__dfNumber(v628) * __dfNumber(v604));
const v1223=(__dfNumber(v604) * __dfNumber(v628));
const v1224=(__dfNumber(v1222) + __dfNumber(v1223));
const v1225=(__dfNumber(v631) * __dfNumber(v604));
const v1226=(__dfNumber(v604) * __dfNumber(v631));
const v1227=(__dfNumber(v1225) + __dfNumber(v1226));
const v1228=(__dfNumber(v634) * __dfNumber(v604));
const v1229=(__dfNumber(v604) * __dfNumber(v634));
const v1230=(__dfNumber(v1228) + __dfNumber(v1229));
const v1231=(__dfNumber(v637) * __dfNumber(v604));
const v1232=(__dfNumber(v604) * __dfNumber(v637));
const v1233=(__dfNumber(v1231) + __dfNumber(v1232));
const v1234=(__dfNumber(v640) * __dfNumber(v604));
const v1235=(__dfNumber(v604) * __dfNumber(v640));
const v1236=(__dfNumber(v1234) + __dfNumber(v1235));
const v1238=(__dfNumber(v1186) + __dfNumber(v1200));
const v1239=(__dfNumber(v1187) + __dfNumber(v1203));
const v1240=(__dfNumber(v1188) + __dfNumber(v1206));
const v1241=(__dfNumber(v1189) + __dfNumber(v1209));
const v1242=(__dfNumber(v1190) + __dfNumber(v1212));
const v1243=(__dfNumber(v1191) + __dfNumber(v1215));
const v1244=(__dfNumber(v1192) + __dfNumber(v1218));
const v1245=(__dfNumber(v1193) + __dfNumber(v1221));
const v1246=(__dfNumber(v1194) + __dfNumber(v1224));
const v1247=(__dfNumber(v1195) + __dfNumber(v1227));
const v1248=(__dfNumber(v1196) + __dfNumber(v1230));
const v1249=(__dfNumber(v1197) + __dfNumber(v1233));
const v1250=(__dfNumber(v1198) + __dfNumber(v1236));
return ({["value"]:v1238,["tangent_0"]:v1239,["tangent_1"]:v1240,["tangent_2"]:v1241,["tangent_3"]:v1242,["tangent_4"]:v1243,["tangent_5"]:v1244,["tangent_6"]:v1245,["tangent_7"]:v1246,["tangent_8"]:v1247,["tangent_9"]:v1248,["tangent_10"]:v1249,["tangent_11"]:v1250});}
function __fn12(v1251,v1252){
const v1253=v1251["p"];
const v1254=v1253["a"];
const v1255=1.0;
const v1256=0.0;
const v1258=v1251["p"];
const v1259=v1258["b"];
const v1262=v1251["q"];
const v1263=v1262["a"];
const v1265=v1251["q"];
const v1266=v1265["b"];
const v1269=v1251["r"];
const v1270=v1269["a"];
const v1272=v1251["r"];
const v1273=v1272["b"];
const v1276=v1251["s"];
const v1277=v1276["a"];
const v1279=v1251["s"];
const v1280=v1279["b"];
const v1283=v1251["t"];
const v1284=v1283["a"];
const v1286=v1251["t"];
const v1287=v1286["b"];
const v1290=v1251["u"];
const v1291=v1290["a"];
const v1293=v1251["u"];
const v1294=v1293["b"];
const v1299=__record0(v1254,v1259,v1263,v1266,v1270,v1273,v1277,v1280,v1284,v1287,v1291,v1294,v1252);
const v1300=v1299["tangent_0"];
const v1301=v1299["tangent_1"];
const v1303=v1299["tangent_2"];
const v1304=v1299["tangent_3"];
const v1306=v1299["tangent_4"];
const v1307=v1299["tangent_5"];
const v1309=v1299["tangent_6"];
const v1310=v1299["tangent_7"];
const v1312=v1299["tangent_8"];
const v1313=v1299["tangent_9"];
const v1315=v1299["tangent_10"];
const v1316=v1299["tangent_11"];
return ({["p"]:({["a"]:v1300,["b"]:v1301}),["q"]:({["a"]:v1303,["b"]:v1304}),["r"]:({["a"]:v1306,["b"]:v1307}),["s"]:({["a"]:v1309,["b"]:v1310}),["t"]:({["a"]:v1312,["b"]:v1313}),["u"]:({["a"]:v1315,["b"]:v1316})});}
function __fn13(v1318,v1319){
const v1320=v1318["value"];
const v1321=v1319["value"];
const v1322=(__dfNumber(v1320) - __dfNumber(v1321));
const v1323=v1318["tangent"];
const v1324=v1319["tangent"];
const v1325=(__dfNumber(v1323) - __dfNumber(v1324));
return ({["value"]:v1322,["tangent"]:v1325});}
function __fn14(v1326,v1327){
const v1328=v1326["value"];
const v1329=v1327["value"];
const v1330=(__dfNumber(v1328) + __dfNumber(v1329));
const v1331=v1326["tangent"];
const v1332=v1327["tangent"];
const v1333=(__dfNumber(v1331) + __dfNumber(v1332));
return ({["value"]:v1330,["tangent"]:v1333});}
function __fn15(v1334,v1335){
const v1336=v1334["value"];
const v1337=v1335["value"];
const v1338=(__dfNumber(v1336) * __dfNumber(v1337));
const v1339=v1334["tangent"];
const v1340=v1335["value"];
const v1341=(__dfNumber(v1339) * __dfNumber(v1340));
const v1342=v1334["value"];
const v1343=v1335["tangent"];
const v1344=(__dfNumber(v1342) * __dfNumber(v1343));
const v1345=(__dfNumber(v1341) + __dfNumber(v1344));
return ({["value"]:v1338,["tangent"]:v1345});}
function __fn16(v1346,v1347){
const v1348=v1346["p"];
const v1349=v1348["a"];
const v1350=__fn13(v1349,v1347);
const v1351=v1346["p"];
const v1352=v1351["b"];
const v1353=__fn14(v1352,v1347);
const v1354=v1346["q"];
const v1355=v1354["a"];
const v1356=__fn13(v1355,v1347);
const v1357=v1346["q"];
const v1358=v1357["b"];
const v1359=__fn14(v1358,v1347);
const v1360=v1346["r"];
const v1361=v1360["a"];
const v1362=__fn13(v1361,v1347);
const v1363=v1346["r"];
const v1364=v1363["b"];
const v1365=__fn14(v1364,v1347);
const v1366=v1346["s"];
const v1367=v1366["a"];
const v1368=__fn13(v1367,v1347);
const v1369=v1346["s"];
const v1370=v1369["b"];
const v1371=__fn14(v1370,v1347);
const v1372=v1346["t"];
const v1373=v1372["a"];
const v1374=__fn13(v1373,v1347);
const v1375=v1346["t"];
const v1376=v1375["b"];
const v1377=__fn14(v1376,v1347);
const v1378=v1346["u"];
const v1379=v1378["a"];
const v1380=__fn13(v1379,v1347);
const v1381=v1346["u"];
const v1382=v1381["b"];
const v1383=__fn14(v1382,v1347);
const v1384=__fn15(v1350,v1350);
const v1385=__fn15(v1353,v1353);
const v1386=__fn14(v1384,v1385);
const v1387=__fn15(v1356,v1356);
const v1388=__fn14(v1386,v1387);
const v1389=__fn15(v1359,v1359);
const v1390=__fn14(v1388,v1389);
const v1391=__fn15(v1362,v1362);
const v1392=__fn14(v1390,v1391);
const v1393=__fn15(v1365,v1365);
const v1394=__fn14(v1392,v1393);
const v1395=__fn15(v1368,v1368);
const v1396=__fn14(v1394,v1395);
const v1397=__fn15(v1371,v1371);
const v1398=__fn14(v1396,v1397);
const v1399=__fn15(v1374,v1374);
const v1400=__fn14(v1398,v1399);
const v1401=__fn15(v1377,v1377);
const v1402=__fn14(v1400,v1401);
const v1403=__fn15(v1380,v1380);
const v1404=__fn14(v1402,v1403);
const v1405=__fn15(v1383,v1383);
return __fn14(v1404,v1405);}
function __fn17(v1406,v1407,v1408){
const v1409=v1406["p"];
const v1410=v1409["a"];
const v1411=v1407["p"];
const v1412=v1411["a"];
const v1414=v1406["p"];
const v1415=v1414["b"];
const v1416=v1407["p"];
const v1417=v1416["b"];
const v1420=v1406["q"];
const v1421=v1420["a"];
const v1422=v1407["q"];
const v1423=v1422["a"];
const v1425=v1406["q"];
const v1426=v1425["b"];
const v1427=v1407["q"];
const v1428=v1427["b"];
const v1431=v1406["r"];
const v1432=v1431["a"];
const v1433=v1407["r"];
const v1434=v1433["a"];
const v1436=v1406["r"];
const v1437=v1436["b"];
const v1438=v1407["r"];
const v1439=v1438["b"];
const v1442=v1406["s"];
const v1443=v1442["a"];
const v1444=v1407["s"];
const v1445=v1444["a"];
const v1447=v1406["s"];
const v1448=v1447["b"];
const v1449=v1407["s"];
const v1450=v1449["b"];
const v1453=v1406["t"];
const v1454=v1453["a"];
const v1455=v1407["t"];
const v1456=v1455["a"];
const v1458=v1406["t"];
const v1459=v1458["b"];
const v1460=v1407["t"];
const v1461=v1460["b"];
const v1464=v1406["u"];
const v1465=v1464["a"];
const v1466=v1407["u"];
const v1467=v1466["a"];
const v1469=v1406["u"];
const v1470=v1469["b"];
const v1471=v1407["u"];
const v1472=v1471["b"];
const v1476=0.0;
const v1480=(__dfNumber(v1410) - __dfNumber(v1408));
const v1481=(__dfNumber(v1412) - __dfNumber(v1476));
const v1485=(__dfNumber(v1415) + __dfNumber(v1408));
const v1486=(__dfNumber(v1417) + __dfNumber(v1476));
const v1490=(__dfNumber(v1421) - __dfNumber(v1408));
const v1491=(__dfNumber(v1423) - __dfNumber(v1476));
const v1495=(__dfNumber(v1426) + __dfNumber(v1408));
const v1496=(__dfNumber(v1428) + __dfNumber(v1476));
const v1500=(__dfNumber(v1432) - __dfNumber(v1408));
const v1501=(__dfNumber(v1434) - __dfNumber(v1476));
const v1505=(__dfNumber(v1437) + __dfNumber(v1408));
const v1506=(__dfNumber(v1439) + __dfNumber(v1476));
const v1510=(__dfNumber(v1443) - __dfNumber(v1408));
const v1511=(__dfNumber(v1445) - __dfNumber(v1476));
const v1515=(__dfNumber(v1448) + __dfNumber(v1408));
const v1516=(__dfNumber(v1450) + __dfNumber(v1476));
const v1520=(__dfNumber(v1454) - __dfNumber(v1408));
const v1521=(__dfNumber(v1456) - __dfNumber(v1476));
const v1525=(__dfNumber(v1459) + __dfNumber(v1408));
const v1526=(__dfNumber(v1461) + __dfNumber(v1476));
const v1530=(__dfNumber(v1465) - __dfNumber(v1408));
const v1531=(__dfNumber(v1467) - __dfNumber(v1476));
const v1535=(__dfNumber(v1470) + __dfNumber(v1408));
const v1536=(__dfNumber(v1472) + __dfNumber(v1476));
const v1540=__record1(v1480,v1481,v1480,v1481);
const v1543=__record1(v1485,v1486,v1485,v1486);
const v1544=__fn14(v1540,v1543);
const v1547=__record1(v1490,v1491,v1490,v1491);
const v1548=__fn14(v1544,v1547);
const v1551=__record1(v1495,v1496,v1495,v1496);
const v1552=__fn14(v1548,v1551);
const v1555=__record1(v1500,v1501,v1500,v1501);
const v1556=__fn14(v1552,v1555);
const v1559=(__dfNumber(v1505) * __dfNumber(v1505));
const v1560=(__dfNumber(v1506) * __dfNumber(v1505));
const v1561=(__dfNumber(v1505) * __dfNumber(v1506));
const v1562=(__dfNumber(v1560) + __dfNumber(v1561));
const v1564=v1556["value"];
const v1565=(__dfNumber(v1564) + __dfNumber(v1559));
const v1566=v1556["tangent"];
const v1567=(__dfNumber(v1566) + __dfNumber(v1562));
const v1571=(__dfNumber(v1510) * __dfNumber(v1510));
const v1572=(__dfNumber(v1511) * __dfNumber(v1510));
const v1573=(__dfNumber(v1510) * __dfNumber(v1511));
const v1574=(__dfNumber(v1572) + __dfNumber(v1573));
const v1576=(__dfNumber(v1565) + __dfNumber(v1571));
const v1577=(__dfNumber(v1567) + __dfNumber(v1574));
const v1581=(__dfNumber(v1515) * __dfNumber(v1515));
const v1582=(__dfNumber(v1516) * __dfNumber(v1515));
const v1583=(__dfNumber(v1515) * __dfNumber(v1516));
const v1584=(__dfNumber(v1582) + __dfNumber(v1583));
const v1586=(__dfNumber(v1576) + __dfNumber(v1581));
const v1587=(__dfNumber(v1577) + __dfNumber(v1584));
const v1591=(__dfNumber(v1520) * __dfNumber(v1520));
const v1592=(__dfNumber(v1521) * __dfNumber(v1520));
const v1593=(__dfNumber(v1520) * __dfNumber(v1521));
const v1594=(__dfNumber(v1592) + __dfNumber(v1593));
const v1596=(__dfNumber(v1586) + __dfNumber(v1591));
const v1597=(__dfNumber(v1587) + __dfNumber(v1594));
const v1601=(__dfNumber(v1525) * __dfNumber(v1525));
const v1602=(__dfNumber(v1526) * __dfNumber(v1525));
const v1603=(__dfNumber(v1525) * __dfNumber(v1526));
const v1604=(__dfNumber(v1602) + __dfNumber(v1603));
const v1606=(__dfNumber(v1596) + __dfNumber(v1601));
const v1607=(__dfNumber(v1597) + __dfNumber(v1604));
const v1611=(__dfNumber(v1530) * __dfNumber(v1530));
const v1612=(__dfNumber(v1531) * __dfNumber(v1530));
const v1613=(__dfNumber(v1530) * __dfNumber(v1531));
const v1614=(__dfNumber(v1612) + __dfNumber(v1613));
const v1616=(__dfNumber(v1606) + __dfNumber(v1611));
const v1617=(__dfNumber(v1607) + __dfNumber(v1614));
const v1621=(__dfNumber(v1535) * __dfNumber(v1535));
const v1622=(__dfNumber(v1536) * __dfNumber(v1535));
const v1623=(__dfNumber(v1535) * __dfNumber(v1536));
const v1624=(__dfNumber(v1622) + __dfNumber(v1623));
const v1626=(__dfNumber(v1616) + __dfNumber(v1621));
const v1627=(__dfNumber(v1617) + __dfNumber(v1624));
const v1628=({["value"]:v1626,["tangent"]:v1627});
return v1627;}
function __record0(v2981,v2982,v2983,v2984,v2985,v2986,v2987,v2988,v2989,v2990,v2991,v2992,v2993){
const v2994=1.0;
const v2995=0.0;
const v3017=(__dfNumber(v2981) - __dfNumber(v2993));
const v3018=(__dfNumber(v2994) - __dfNumber(v2995));
const v3019=(__dfNumber(v2995) - __dfNumber(v2995));
const v3022=(__dfNumber(v2982) + __dfNumber(v2993));
const v3023=(__dfNumber(v2995) + __dfNumber(v2995));
const v3024=(__dfNumber(v2994) + __dfNumber(v2995));
const v3027=(__dfNumber(v2983) - __dfNumber(v2993));
const v3030=(__dfNumber(v2984) + __dfNumber(v2993));
const v3033=(__dfNumber(v2985) - __dfNumber(v2993));
const v3036=(__dfNumber(v2986) + __dfNumber(v2993));
const v3039=(__dfNumber(v2987) - __dfNumber(v2993));
const v3042=(__dfNumber(v2988) + __dfNumber(v2993));
const v3045=(__dfNumber(v2989) - __dfNumber(v2993));
const v3048=(__dfNumber(v2990) + __dfNumber(v2993));
const v3051=(__dfNumber(v2991) - __dfNumber(v2993));
const v3054=(__dfNumber(v2992) + __dfNumber(v2993));
const v3056=(__dfNumber(v3017) * __dfNumber(v3017));
const v3057=(__dfNumber(v3018) * __dfNumber(v3017));
const v3058=(__dfNumber(v3017) * __dfNumber(v3018));
const v3059=(__dfNumber(v3057) + __dfNumber(v3058));
const v3060=(__dfNumber(v3019) * __dfNumber(v3017));
const v3061=(__dfNumber(v3017) * __dfNumber(v3019));
const v3062=(__dfNumber(v3060) + __dfNumber(v3061));
const v3064=(__dfNumber(v3022) * __dfNumber(v3022));
const v3065=(__dfNumber(v3023) * __dfNumber(v3022));
const v3066=(__dfNumber(v3022) * __dfNumber(v3023));
const v3067=(__dfNumber(v3065) + __dfNumber(v3066));
const v3068=(__dfNumber(v3024) * __dfNumber(v3022));
const v3069=(__dfNumber(v3022) * __dfNumber(v3024));
const v3070=(__dfNumber(v3068) + __dfNumber(v3069));
const v3072=(__dfNumber(v3056) + __dfNumber(v3064));
const v3073=(__dfNumber(v3059) + __dfNumber(v3067));
const v3074=(__dfNumber(v3062) + __dfNumber(v3070));
const v3075=(__dfNumber(v3062) + __dfNumber(v3067));
const v3077=(__dfNumber(v3027) * __dfNumber(v3027));
const v3078=(__dfNumber(v3019) * __dfNumber(v3027));
const v3079=(__dfNumber(v3027) * __dfNumber(v3019));
const v3080=(__dfNumber(v3078) + __dfNumber(v3079));
const v3081=(__dfNumber(v3018) * __dfNumber(v3027));
const v3082=(__dfNumber(v3027) * __dfNumber(v3018));
const v3083=(__dfNumber(v3081) + __dfNumber(v3082));
const v3085=(__dfNumber(v3072) + __dfNumber(v3077));
const v3086=(__dfNumber(v3073) + __dfNumber(v3080));
const v3087=(__dfNumber(v3074) + __dfNumber(v3080));
const v3088=(__dfNumber(v3075) + __dfNumber(v3083));
const v3089=(__dfNumber(v3075) + __dfNumber(v3080));
const v3091=(__dfNumber(v3030) * __dfNumber(v3030));
const v3092=(__dfNumber(v3023) * __dfNumber(v3030));
const v3093=(__dfNumber(v3030) * __dfNumber(v3023));
const v3094=(__dfNumber(v3092) + __dfNumber(v3093));
const v3095=(__dfNumber(v3024) * __dfNumber(v3030));
const v3096=(__dfNumber(v3030) * __dfNumber(v3024));
const v3097=(__dfNumber(v3095) + __dfNumber(v3096));
const v3099=(__dfNumber(v3085) + __dfNumber(v3091));
const v3100=(__dfNumber(v3086) + __dfNumber(v3094));
const v3101=(__dfNumber(v3087) + __dfNumber(v3094));
const v3102=(__dfNumber(v3088) + __dfNumber(v3094));
const v3103=(__dfNumber(v3089) + __dfNumber(v3097));
const v3104=(__dfNumber(v3089) + __dfNumber(v3094));
const v3106=(__dfNumber(v3033) * __dfNumber(v3033));
const v3107=(__dfNumber(v3019) * __dfNumber(v3033));
const v3108=(__dfNumber(v3033) * __dfNumber(v3019));
const v3109=(__dfNumber(v3107) + __dfNumber(v3108));
const v3110=(__dfNumber(v3018) * __dfNumber(v3033));
const v3111=(__dfNumber(v3033) * __dfNumber(v3018));
const v3112=(__dfNumber(v3110) + __dfNumber(v3111));
const v3114=(__dfNumber(v3099) + __dfNumber(v3106));
const v3115=(__dfNumber(v3100) + __dfNumber(v3109));
const v3116=(__dfNumber(v3101) + __dfNumber(v3109));
const v3117=(__dfNumber(v3102) + __dfNumber(v3109));
const v3118=(__dfNumber(v3103) + __dfNumber(v3109));
const v3119=(__dfNumber(v3104) + __dfNumber(v3112));
const v3120=(__dfNumber(v3104) + __dfNumber(v3109));
const v3122=(__dfNumber(v3036) * __dfNumber(v3036));
const v3123=(__dfNumber(v3023) * __dfNumber(v3036));
const v3124=(__dfNumber(v3036) * __dfNumber(v3023));
const v3125=(__dfNumber(v3123) + __dfNumber(v3124));
const v3126=(__dfNumber(v3024) * __dfNumber(v3036));
const v3127=(__dfNumber(v3036) * __dfNumber(v3024));
const v3128=(__dfNumber(v3126) + __dfNumber(v3127));
const v3130=(__dfNumber(v3114) + __dfNumber(v3122));
const v3131=(__dfNumber(v3115) + __dfNumber(v3125));
const v3132=(__dfNumber(v3116) + __dfNumber(v3125));
const v3133=(__dfNumber(v3117) + __dfNumber(v3125));
const v3134=(__dfNumber(v3118) + __dfNumber(v3125));
const v3135=(__dfNumber(v3119) + __dfNumber(v3125));
const v3136=(__dfNumber(v3120) + __dfNumber(v3128));
const v3137=(__dfNumber(v3120) + __dfNumber(v3125));
const v3139=(__dfNumber(v3039) * __dfNumber(v3039));
const v3140=(__dfNumber(v3019) * __dfNumber(v3039));
const v3141=(__dfNumber(v3039) * __dfNumber(v3019));
const v3142=(__dfNumber(v3140) + __dfNumber(v3141));
const v3143=(__dfNumber(v3018) * __dfNumber(v3039));
const v3144=(__dfNumber(v3039) * __dfNumber(v3018));
const v3145=(__dfNumber(v3143) + __dfNumber(v3144));
const v3147=(__dfNumber(v3130) + __dfNumber(v3139));
const v3148=(__dfNumber(v3131) + __dfNumber(v3142));
const v3149=(__dfNumber(v3132) + __dfNumber(v3142));
const v3150=(__dfNumber(v3133) + __dfNumber(v3142));
const v3151=(__dfNumber(v3134) + __dfNumber(v3142));
const v3152=(__dfNumber(v3135) + __dfNumber(v3142));
const v3153=(__dfNumber(v3136) + __dfNumber(v3142));
const v3154=(__dfNumber(v3137) + __dfNumber(v3145));
const v3155=(__dfNumber(v3137) + __dfNumber(v3142));
const v3157=(__dfNumber(v3042) * __dfNumber(v3042));
const v3158=(__dfNumber(v3023) * __dfNumber(v3042));
const v3159=(__dfNumber(v3042) * __dfNumber(v3023));
const v3160=(__dfNumber(v3158) + __dfNumber(v3159));
const v3161=(__dfNumber(v3024) * __dfNumber(v3042));
const v3162=(__dfNumber(v3042) * __dfNumber(v3024));
const v3163=(__dfNumber(v3161) + __dfNumber(v3162));
const v3165=(__dfNumber(v3147) + __dfNumber(v3157));
const v3166=(__dfNumber(v3148) + __dfNumber(v3160));
const v3167=(__dfNumber(v3149) + __dfNumber(v3160));
const v3168=(__dfNumber(v3150) + __dfNumber(v3160));
const v3169=(__dfNumber(v3151) + __dfNumber(v3160));
const v3170=(__dfNumber(v3152) + __dfNumber(v3160));
const v3171=(__dfNumber(v3153) + __dfNumber(v3160));
const v3172=(__dfNumber(v3154) + __dfNumber(v3160));
const v3173=(__dfNumber(v3155) + __dfNumber(v3163));
const v3174=(__dfNumber(v3155) + __dfNumber(v3160));
const v3176=(__dfNumber(v3045) * __dfNumber(v3045));
const v3177=(__dfNumber(v3019) * __dfNumber(v3045));
const v3178=(__dfNumber(v3045) * __dfNumber(v3019));
const v3179=(__dfNumber(v3177) + __dfNumber(v3178));
const v3180=(__dfNumber(v3018) * __dfNumber(v3045));
const v3181=(__dfNumber(v3045) * __dfNumber(v3018));
const v3182=(__dfNumber(v3180) + __dfNumber(v3181));
const v3184=(__dfNumber(v3165) + __dfNumber(v3176));
const v3185=(__dfNumber(v3166) + __dfNumber(v3179));
const v3186=(__dfNumber(v3167) + __dfNumber(v3179));
const v3187=(__dfNumber(v3168) + __dfNumber(v3179));
const v3188=(__dfNumber(v3169) + __dfNumber(v3179));
const v3189=(__dfNumber(v3170) + __dfNumber(v3179));
const v3190=(__dfNumber(v3171) + __dfNumber(v3179));
const v3191=(__dfNumber(v3172) + __dfNumber(v3179));
const v3192=(__dfNumber(v3173) + __dfNumber(v3179));
const v3193=(__dfNumber(v3174) + __dfNumber(v3182));
const v3194=(__dfNumber(v3174) + __dfNumber(v3179));
const v3196=(__dfNumber(v3048) * __dfNumber(v3048));
const v3197=(__dfNumber(v3023) * __dfNumber(v3048));
const v3198=(__dfNumber(v3048) * __dfNumber(v3023));
const v3199=(__dfNumber(v3197) + __dfNumber(v3198));
const v3200=(__dfNumber(v3024) * __dfNumber(v3048));
const v3201=(__dfNumber(v3048) * __dfNumber(v3024));
const v3202=(__dfNumber(v3200) + __dfNumber(v3201));
const v3204=(__dfNumber(v3184) + __dfNumber(v3196));
const v3205=(__dfNumber(v3185) + __dfNumber(v3199));
const v3206=(__dfNumber(v3186) + __dfNumber(v3199));
const v3207=(__dfNumber(v3187) + __dfNumber(v3199));
const v3208=(__dfNumber(v3188) + __dfNumber(v3199));
const v3209=(__dfNumber(v3189) + __dfNumber(v3199));
const v3210=(__dfNumber(v3190) + __dfNumber(v3199));
const v3211=(__dfNumber(v3191) + __dfNumber(v3199));
const v3212=(__dfNumber(v3192) + __dfNumber(v3199));
const v3213=(__dfNumber(v3193) + __dfNumber(v3199));
const v3214=(__dfNumber(v3194) + __dfNumber(v3202));
const v3215=(__dfNumber(v3194) + __dfNumber(v3199));
const v3217=(__dfNumber(v3051) * __dfNumber(v3051));
const v3218=(__dfNumber(v3019) * __dfNumber(v3051));
const v3219=(__dfNumber(v3051) * __dfNumber(v3019));
const v3220=(__dfNumber(v3218) + __dfNumber(v3219));
const v3221=(__dfNumber(v3018) * __dfNumber(v3051));
const v3222=(__dfNumber(v3051) * __dfNumber(v3018));
const v3223=(__dfNumber(v3221) + __dfNumber(v3222));
const v3225=(__dfNumber(v3204) + __dfNumber(v3217));
const v3226=(__dfNumber(v3205) + __dfNumber(v3220));
const v3227=(__dfNumber(v3206) + __dfNumber(v3220));
const v3228=(__dfNumber(v3207) + __dfNumber(v3220));
const v3229=(__dfNumber(v3208) + __dfNumber(v3220));
const v3230=(__dfNumber(v3209) + __dfNumber(v3220));
const v3231=(__dfNumber(v3210) + __dfNumber(v3220));
const v3232=(__dfNumber(v3211) + __dfNumber(v3220));
const v3233=(__dfNumber(v3212) + __dfNumber(v3220));
const v3234=(__dfNumber(v3213) + __dfNumber(v3220));
const v3235=(__dfNumber(v3214) + __dfNumber(v3220));
const v3236=(__dfNumber(v3215) + __dfNumber(v3223));
const v3237=(__dfNumber(v3215) + __dfNumber(v3220));
const v3239=(__dfNumber(v3054) * __dfNumber(v3054));
const v3240=(__dfNumber(v3023) * __dfNumber(v3054));
const v3241=(__dfNumber(v3054) * __dfNumber(v3023));
const v3242=(__dfNumber(v3240) + __dfNumber(v3241));
const v3243=(__dfNumber(v3024) * __dfNumber(v3054));
const v3244=(__dfNumber(v3054) * __dfNumber(v3024));
const v3245=(__dfNumber(v3243) + __dfNumber(v3244));
const v3247=(__dfNumber(v3225) + __dfNumber(v3239));
const v3248=(__dfNumber(v3226) + __dfNumber(v3242));
const v3249=(__dfNumber(v3227) + __dfNumber(v3242));
const v3250=(__dfNumber(v3228) + __dfNumber(v3242));
const v3251=(__dfNumber(v3229) + __dfNumber(v3242));
const v3252=(__dfNumber(v3230) + __dfNumber(v3242));
const v3253=(__dfNumber(v3231) + __dfNumber(v3242));
const v3254=(__dfNumber(v3232) + __dfNumber(v3242));
const v3255=(__dfNumber(v3233) + __dfNumber(v3242));
const v3256=(__dfNumber(v3234) + __dfNumber(v3242));
const v3257=(__dfNumber(v3235) + __dfNumber(v3242));
const v3258=(__dfNumber(v3236) + __dfNumber(v3242));
const v3259=(__dfNumber(v3237) + __dfNumber(v3245));
return ({["value"]:v3247,["tangent_0"]:v3248,["tangent_1"]:v3249,["tangent_2"]:v3250,["tangent_3"]:v3251,["tangent_4"]:v3252,["tangent_5"]:v3253,["tangent_6"]:v3254,["tangent_7"]:v3255,["tangent_8"]:v3256,["tangent_9"]:v3257,["tangent_10"]:v3258,["tangent_11"]:v3259});}
function __record1(v3260,v3261,v3262,v3263){
const v3266=(__dfNumber(v3260) * __dfNumber(v3262));
const v3267=(__dfNumber(v3261) * __dfNumber(v3262));
const v3268=(__dfNumber(v3260) * __dfNumber(v3263));
const v3269=(__dfNumber(v3267) + __dfNumber(v3268));
return ({["value"]:v3266,["tangent"]:v3269});}
const __namedTypes={"Bundle":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},"Node":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"},"Pair":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"},"__ink_differential64_0":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"},"__ink_differential64_2":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"},"__ink_differential64_21":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}}],"kind":"record","name":"__ink_differential64_21"},"__ink_differential64_22":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"},"__ink_differential64_4":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}}],"kind":"record","name":"__ink_differential64_4"},"__ink_differential64_5":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v15","core_sha256":"07adccc3403a91728cc634a665acc70e63e101cd162ad7d496e1fa3737fbc748","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"f32_computation":"native-number-with-exact-nonfinite-tags","f32_storage":"native-number-with-exact-nonfinite-tags","functions":[{"destination":null,"index":0,"internal":false,"name":"component","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"x","type":{"kind":"f64"}}],"precondition":null,"result":{"kind":"f64"}},{"destination":null,"index":1,"internal":false,"name":"energy","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f64"}}],"precondition":null,"result":{"kind":"f64"}},{"destination":null,"index":2,"internal":false,"name":"derivatives","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f64"}}],"precondition":null,"result":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"destination":null,"index":3,"internal":false,"name":"direction","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f64"}}],"precondition":null,"result":{"kind":"f64"}},{"destination":null,"index":4,"internal":false,"name":"twice","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"precondition":null,"result":{"kind":"f64"}},{"destination":null,"index":5,"internal":false,"name":"selected","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"c","type":{"kind":"bool"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"destination":null,"index":6,"internal":false,"name":"branches","parallel":false,"params":[{"name":"x","type":{"kind":"f64"}},{"name":"c","type":{"kind":"bool"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"destination":null,"index":7,"internal":false,"name":"looping","parallel":false,"params":[{"name":"x","type":{"kind":"f64"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"destination":null,"index":8,"internal":false,"name":"strict_unused","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"precondition":null,"result":{"kind":"f64"}},{"destination":null,"index":9,"internal":false,"name":"strict","parallel":false,"params":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}}],"precondition":null,"result":{"kind":"f64"}},{"destination":null,"index":10,"internal":false,"name":"history","parallel":false,"params":[{"name":"x","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}},{"destination":null,"index":11,"internal":false,"name":"__ink_differential64_3","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}}],"kind":"record","name":"__ink_differential64_4"}},{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"destination":null,"index":12,"internal":false,"name":"__ink_differential64_1","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f64"}}],"precondition":null,"result":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"destination":null,"index":13,"internal":false,"name":"__ink_differential64_23","parallel":false,"params":[{"name":"__ink_differential64_24","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"__ink_differential64_25","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"destination":null,"index":14,"internal":false,"name":"__ink_differential64_27","parallel":false,"params":[{"name":"__ink_differential64_28","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"__ink_differential64_29","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"destination":null,"index":15,"internal":false,"name":"__ink_differential64_31","parallel":false,"params":[{"name":"__ink_differential64_32","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"__ink_differential64_33","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"destination":null,"index":16,"internal":false,"name":"__ink_differential64_20","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}}],"kind":"record","name":"__ink_differential64_21"}},{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"destination":null,"index":17,"internal":false,"name":"__ink_differential64_19","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"__ink_differential64_35","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f64"}}],"precondition":null,"result":{"kind":"f64"}}],"named_types":{"Bundle":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},"Node":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"},"Pair":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"},"__ink_differential64_0":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"},"__ink_differential64_2":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"},"__ink_differential64_21":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}}],"kind":"record","name":"__ink_differential64_21"},"__ink_differential64_22":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"},"__ink_differential64_4":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}}],"kind":"record","name":"__ink_differential64_4"},"__ink_differential64_5":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},"prepared_compiled":{"destination":{"call":"callPreparedCompiledInto","capacity":"trusted","failure":"destination may be partially written","float_values":"trusted public representation","inputs":"sealed compiled values","ownership":"caller-owned","structured_elements":"detached","tail":"unwritten"},"evaluation":"lazy source-order; successful bindings only","functions":[{"factory":false,"function":"component","reason":"no reusable captured work"},{"factory":false,"function":"energy","reason":"no reusable captured work"},{"delegated_calls":1,"factory":true,"function":"derivatives","retained_bindings":0},{"factory":false,"function":"direction","reason":"no reusable captured work"},{"factory":false,"function":"twice","reason":"no reusable captured work"},{"factory":false,"function":"selected","reason":"no reusable captured work"},{"factory":false,"function":"branches","reason":"no reusable captured work"},{"factory":false,"function":"looping","reason":"no reusable captured work"},{"factory":false,"function":"strict_unused","reason":"no reusable captured work"},{"factory":false,"function":"strict","reason":"no reusable captured work"},{"factory":false,"function":"history","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential64_3","reason":"prepared residual binding budget"},{"delegated_calls":1,"factory":true,"function":"__ink_differential64_1","retained_bindings":1},{"factory":false,"function":"__ink_differential64_23","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential64_27","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential64_31","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential64_20","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential64_19","reason":"no reusable captured work"}],"lifetime":"prepared token","semantics":"sealed-value-residual-v1"},"private_record_elisions":[],"private_sum_spines":[],"schema":1,"state":null,"wire":{"format":"ink-value-wire-v1","functions":{"__ink_differential64_1":{"arguments":{"format":"ink-value-wire-v1","identity":"2c76121ced7b085b02e336ea48ad9b53d80a9767cf8c69074ce35120139cc29e","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"6e167f69f172d2f471a5d6ccb78ce304160f062f8f680efcdb1be1838e9f1380","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}}},"__ink_differential64_19":{"arguments":{"format":"ink-value-wire-v1","identity":"18b8627db3a9a6035da96f8211bad8c99850947764f0a827ce17c678e1e08ff5","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"__ink_differential64_35","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":{},"root":{"kind":"f64"}}},"__ink_differential64_20":{"arguments":{"format":"ink-value-wire-v1","identity":"332e82f8a3053b49651169405b046eb44dacf193e86b95533115b7d738374f5a","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}}],"kind":"record","name":"__ink_differential64_21"}},{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0e35873fe4e2836a793d1cccc5c47875def75fd4336b47c5bfa790354746fbe1","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}},"__ink_differential64_23":{"arguments":{"format":"ink-value-wire-v1","identity":"a437f52cb185e9e78e7b1b5057983e8221ffb98e23d54746a66075541bb79f00","named":{},"root":{"fields":[{"name":"__ink_differential64_24","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"__ink_differential64_25","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0e35873fe4e2836a793d1cccc5c47875def75fd4336b47c5bfa790354746fbe1","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}},"__ink_differential64_27":{"arguments":{"format":"ink-value-wire-v1","identity":"a27613d85400039dceca2f4033874f765ea9179420616d4beeaea09ae031c72c","named":{},"root":{"fields":[{"name":"__ink_differential64_28","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"__ink_differential64_29","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0e35873fe4e2836a793d1cccc5c47875def75fd4336b47c5bfa790354746fbe1","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}},"__ink_differential64_3":{"arguments":{"format":"ink-value-wire-v1","identity":"652be3d77ca28823eb07446224f12c4d85f629636c877f36110ed8887425f2ab","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}}],"kind":"record","name":"__ink_differential64_4"}},{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"48296b791ad4dd37c119c1bf7df4bcef9199640bff85b3a36cc024468a1de719","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}},"__ink_differential64_31":{"arguments":{"format":"ink-value-wire-v1","identity":"ffce138aeeccd353f98c9c362797003281e9cd192769d56673baed53352b6af2","named":{},"root":{"fields":[{"name":"__ink_differential64_32","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"__ink_differential64_33","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0e35873fe4e2836a793d1cccc5c47875def75fd4336b47c5bfa790354746fbe1","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}},"branches":{"arguments":{"format":"ink-value-wire-v1","identity":"64ba789e90b3644dd541d312165cb0f92bb781c84864277948ed42c85c1075fe","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f64"}},{"name":"c","type":{"kind":"bool"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"2c0b82b8cbdb96c5430627da6020de8a76d66d9c2adce83f72fd5e0a194f4e8f","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}},"component":{"arguments":{"format":"ink-value-wire-v1","identity":"bf4c0abcf2174f96bd72d7d22ded5633bdc69ec37b04200ede0a6030aa34009f","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"x","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":{},"root":{"kind":"f64"}}},"derivatives":{"arguments":{"format":"ink-value-wire-v1","identity":"2c76121ced7b085b02e336ea48ad9b53d80a9767cf8c69074ce35120139cc29e","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"6e167f69f172d2f471a5d6ccb78ce304160f062f8f680efcdb1be1838e9f1380","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}}},"direction":{"arguments":{"format":"ink-value-wire-v1","identity":"2c76121ced7b085b02e336ea48ad9b53d80a9767cf8c69074ce35120139cc29e","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":{},"root":{"kind":"f64"}}},"energy":{"arguments":{"format":"ink-value-wire-v1","identity":"2c76121ced7b085b02e336ea48ad9b53d80a9767cf8c69074ce35120139cc29e","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":{},"root":{"kind":"f64"}}},"history":{"arguments":{"format":"ink-value-wire-v1","identity":"cc08f1332c0bbd676577f3e81f06e85cc8ef81a32bcbe10b3177d811cc8e0ae2","named":{},"root":{"fields":[{"name":"x","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"06a5b110d3c213512730b89ea5797ec6a338f55b0c357c4c3894a84ac3cfa9e3","named":{"Node":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}},"root":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}}},"looping":{"arguments":{"format":"ink-value-wire-v1","identity":"472d19f2127f1316b16f49e96065b408f4e7270c1da4072dd74ece88bf21dcd6","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"2c0b82b8cbdb96c5430627da6020de8a76d66d9c2adce83f72fd5e0a194f4e8f","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}},"selected":{"arguments":{"format":"ink-value-wire-v1","identity":"acea5fcf7434f64913a3eeaa522b5b97d3a79b273a1724c95319d93c50548e48","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"c","type":{"kind":"bool"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"2c0b82b8cbdb96c5430627da6020de8a76d66d9c2adce83f72fd5e0a194f4e8f","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}},"strict":{"arguments":{"format":"ink-value-wire-v1","identity":"de2b22f0352ab5f6d42d231525c8380dac663c3e347813bb8e02bbed567d9bd6","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f64"}},{"name":"y","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":{},"root":{"kind":"f64"}}},"strict_unused":{"arguments":{"format":"ink-value-wire-v1","identity":"33af5cf88591892180b88bd810c62f689caf303f2d0a3c6da0e7e5503f2957f8","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":{},"root":{"kind":"f64"}}},"twice":{"arguments":{"format":"ink-value-wire-v1","identity":"33af5cf88591892180b88bd810c62f689caf303f2d0a3c6da0e7e5503f2957f8","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":{},"root":{"kind":"f64"}}}}}};
const __implementations=[__fn0,__fn1,__fn2,__fn3,__fn4,__fn5,__fn6,__fn7,__fn8,__fn9,__fn10,__fn11,__fn12,__fn13,__fn14,__fn15,__fn16,__fn17];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
const __inputTypes=[{"capture":[false,true],"types":[{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"},{"kind":"f64"}]},{"capture":[false,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f64"}]},{"capture":[false,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f64"}]},{"capture":[false,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f64"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}]},{"capture":[false,true],"types":[{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"},{"kind":"bool"}]},{"capture":[true,true],"types":[{"kind":"f64"},{"kind":"bool"}]},{"capture":[true],"types":[{"kind":"f64"}]},{"capture":[false],"types":[{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}]},{"capture":[true,true],"types":[{"kind":"f64"},{"kind":"f64"}]},{"capture":[true],"types":[{"kind":"u32"}]},{"capture":[false,false],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}}],"kind":"record","name":"__ink_differential64_4"},{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}]},{"capture":[false,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f64"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"},{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"},{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"},{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}]},{"capture":[false,false],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}}],"kind":"record","name":"__ink_differential64_21"},{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}]},{"capture":[false,false,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f64"}]}];
export const functions=Object.freeze({...Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=> {
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const output=__representation(f.result,true);
  const body=__implementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
  const needsInput=input.some(c=>c!==__identity);
  const entry=!needsInput && output===__identity ? implementation :
    (...args)=>{const context=new WeakMap();return output(implementation(...(needsInput ? args.map((v,i)=>input[i](v,context)) : args)),context);};
  return [f.name,entry];
}))),...Object.freeze(Object.fromEntries([["component",(()=>{const c0=__representation(__inputTypes[0].types[0],false,__inputTypes[0].capture[0]);const c1=__representation(__inputTypes[0].types[1],false,__inputTypes[0].capture[1]);const output=__representation(metadata.functions[0].result,true);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity&&output===__identity)return __fn0;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn0(...values),context);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return output(__fn0(v0,v1),context);};})()],
["energy",(()=>{const c0=__representation(__inputTypes[1].types[0],false,__inputTypes[1].capture[0]);const c1=__representation(__inputTypes[1].types[1],false,__inputTypes[1].capture[1]);const output=__representation(metadata.functions[1].result,true);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity&&output===__identity)return __fn1;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn1(...values),context);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return output(__fn1(v0,v1),context);};})()],
["direction",(()=>{const c0=__representation(__inputTypes[3].types[0],false,__inputTypes[3].capture[0]);const c1=__representation(__inputTypes[3].types[1],false,__inputTypes[3].capture[1]);const output=__representation(metadata.functions[3].result,true);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity&&output===__identity)return __fn3;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn3(...values),context);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return output(__fn3(v0,v1),context);};})()],
["twice",(()=>{const c0=__representation(__inputTypes[4].types[0],false,__inputTypes[4].capture[0]);const output=__representation(metadata.functions[4].result,true);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&output===__identity)return __fn4;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn4(...values),context);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return output(__fn4(v0),context);};})()],
["strict_unused",(()=>{const c0=__representation(__inputTypes[8].types[0],false,__inputTypes[8].capture[0]);const output=__representation(metadata.functions[8].result,true);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&output===__identity)return __fn8;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn8(...values),context);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return output(__fn8(v0),context);};})()],
["strict",(()=>{const c0=__representation(__inputTypes[9].types[0],false,__inputTypes[9].capture[0]);const c1=__representation(__inputTypes[9].types[1],false,__inputTypes[9].capture[1]);const output=__representation(metadata.functions[9].result,true);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=false;if(c0===__identity&&c1===__identity&&output===__identity)return __fn9;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn9(...values),context);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return output(__fn9(v0,v1),context);};})()],
["__ink_differential64_19",(()=>{const c0=__representation(__inputTypes[17].types[0],false,__inputTypes[17].capture[0]);const c1=__representation(__inputTypes[17].types[1],false,__inputTypes[17].capture[1]);const c2=__representation(__inputTypes[17].types[2],false,__inputTypes[17].capture[2]);const output=__representation(metadata.functions[17].result,true);const input=[c0,c1,c2],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity&&c2===__identity&&output===__identity)return __fn17;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn17(...values),context);};return function(a0,a1,a2){if(arguments.length!==3)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object')+Number(c2!==__identity&&a2!==null&&typeof a2==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);const v2=c2(a2,context);return output(__fn17(v0,v1,v2),context);};})()]]))});
export function call(name,args) { return functions[name](...args); }
// Shared bounded binary codec; generated code supplies exact descriptors.
export const valueWireFormat='ink-value-wire-v1';
// A connection agrees on the complete value schema before using this format.
// Version byte + schema-directed fields; schema identity is out of band.
export const compactValueWireFormat='ink-value-session-v1';
const wireMagic=Uint8Array.of(73,78,75,86,65,76,0,1);
const wireEncoder=new TextEncoder(),wireDecoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const wireDefaults=Object.freeze({bytes:16777216,nodes:1000000,depth:128}),wireDefaultOptions=Object.freeze({});
const wireDecimal=s=>typeof s==='string'&&/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(s);
function wireLimits(options){if(options===wireDefaultOptions||options===wireDefaults)return wireDefaults;const l={...wireDefaults,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>wireDefaults[k])throw Error('wire hard resource limit');return l;}
const wireFloat=new DataView(new ArrayBuffer(4));
function wireDecodeText(bytes,start,end){
 if(end-start<=16){let text='';for(let i=start;i<end;i++){const byte=bytes[i];if(byte>=128)return wireDecoder.decode(bytes.subarray(start,end));text+=String.fromCharCode(byte);}return text;}
 return wireDecoder.decode(bytes.subarray(start,end));
}
function wireUtf8Length(text){let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const wireOwn=(v,k)=>v!==null&&typeof v==='object'&&Object.hasOwn(v,k);
const wireTagged=(v,k)=>wireOwn(v,k)&&Object.keys(v).length===1;
const wireDouble=new DataView(new ArrayBuffer(8));
function wireF64Bits(v){
 if(typeof v==='number'&&Number.isFinite(v)){wireDouble.setFloat64(0,v,true);return wireDouble.getBigUint64(0,true);}
 if(!wireTagged(v,'F64Bits'))wireInvalidValue();const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))wireInvalidValue();
 const bits=BigInt(text);if(bits>18446744073709551615n)wireInvalidValue();return bits;
}
const wireCanonical=v=>Array.isArray(v)?'['+v.map(wireCanonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort((a,b)=>{const x=Array.from(a,c=>c.codePointAt(0)),y=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]-y[i];return x.length-y.length;}).map(k=>JSON.stringify(k)+':'+wireCanonical(v[k])).join(',')+'}':JSON.stringify(v);
export async function createValueCodec(root,named={}){
 const used=new Set(),budget={nodes:100000};
 function check(t,d=0){
  if(d>64||--budget.nodes<0)throw Error('wire descriptor limit');
  const keys={u32:['kind'],u64:['kind'],i32:['kind'],f32:['kind'],f64:['kind'],bool:['kind'],unit:['kind'],string:['kind'],int:['kind'],id:['kind','name'],ref:['kind','name'],enum:['kind','name','variants'],record:['kind','name','fields'],list:['kind','element'],option:['kind','element'],vector:['kind','element','size'],result:['kind','ok','error']}[t?.kind];
  if(!keys||Object.keys(t).length!==keys.length||keys.some(k=>!Object.hasOwn(t,k)))throw Error('invalid wire descriptor');
  if(keys.includes('name')&&(typeof t.name!=='string'||!t.name.isWellFormed()))throw Error('invalid descriptor name');
  if(t.kind==='ref'){if(!used.has(t.name)){used.add(t.name);if(named[t.name]?.kind!=='record'||named[t.name].name!==t.name)throw Error('unresolved wire reference');check(named[t.name],d+1);}}
  if(t.kind==='record'){if(!Array.isArray(t.fields))throw Error('wire fields');const names=new Set();for(const f of t.fields){if(Object.keys(f).length!==2||typeof f.name!=='string'||!f.name.isWellFormed()||names.has(f.name))throw Error('duplicate wire field');names.add(f.name);check(f.type,d+1);}}
  if(t.kind==='enum'&&(!Array.isArray(t.variants)||!t.variants.length||t.variants.length>64||t.variants.some(v=>typeof v!=='string'||!v.isWellFormed())||new Set(t.variants).size!==t.variants.length))throw Error('wire enum');
  if(['list','vector','option'].includes(t.kind)){if(t.kind==='vector'&&(!Number.isInteger(t.size)||t.size<1||t.size>64))throw Error('wire vector');check(t.element,d+1);}
  if(t.kind==='result'){check(t.ok,d+1);check(t.error,d+1);}
 }
 check(root);const names=Object.fromEntries([...used].sort().map(k=>[k,named[k]]));
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',wireEncoder.encode(wireCanonical({format:valueWireFormat,root,named:names}))));
 return new ValueCodec({format:valueWireFormat,root,named:names,identity:Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('')});
}
// Resolve immutable descriptor edges once. Logical validation traverses the
// literal schema; single-child nodes use a loop rather than recursive closures.
function wireValuePlan(codec){
 const seen=new WeakMap();let remaining=100000;
 const build=type=>{
  const t=codec.resolve(type);if(seen.has(t))return seen.get(t);
  if(--remaining<0)throw Error('wire descriptor limit');const p={kind:t.kind,type:t,decode:null,decodeCompact:null};seen.set(t,p);
  if(t.kind==='record')p.fields=t.fields.map(f=>({name:f.name,plan:build(f.type)}));
  if(t.kind==='list'||t.kind==='vector'||t.kind==='option')p.element=build(t.element);
  if(t.kind==='result'){p.ok=build(t.ok);p.error=build(t.error);}
  return p;
 };return build(codec.descriptor.root);
}
function wireBindDecodePlan(root,compact=false){
 const seen=new Set(),pending=[root];let flags=0;
 while(pending.length){
  const p=pending.pop();if(seen.has(p))continue;seen.add(p);if(compact)p.decodeCompact=compactDecodeOperation(p);else p.decode=wireDecodeOperation(p);
  if(p.fields?.length>4)flags|=1;
  if(p.kind==='u32'||p.kind==='i32'||p.kind==='u64'||p.kind==='f32'||p.kind==='f64')flags|=2;
  if(p.fields)for(const f of p.fields)pending.push(f.plan);
  if(p.element)pending.push(p.element);
  if(p.ok){pending.push(p.ok);pending.push(p.error);}
 }
 return flags|4;
}
// Select literal descriptor operations once, without runtime source generation
// or eval. Recursive edges call the completed plan. The generic scanner remains
// the visitor/validation path and an independent materialisation implementation.
function wireReadOperation(p){
 const t=p.type;
 let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':read=(r,end)=>{r.size(end,4);const value={F32Bits:r.view.getUint32(r.cursor,true)};r.cursor=end;return value;};break;
  case 'f64':read=(r,end)=>{r.size(end,8);const value={F64Bits:r.view.getBigUint64(r.cursor,true).toString()};r.cursor=end;return value;};break;
  case 'u64':read=(r,end)=>{r.size(end,8);const value=r.view.getBigUint64(r.cursor,true);r.cursor=end;return value;};break;
  case 'string':read=(r,end)=>r.text(end);break;
  case 'int':read=(r,end)=>{const text=r.text(end);if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=(r,end)=>{const text=r.text(end);if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=(r,end)=>{const text=r.text(end);if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{
    if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;
    if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');
    const values=new Array(n);for(let i=0;i<n;i++)values[i]=element.decode(r,end,d+1);return values;
   };break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1)});break;
    case 2:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1)});break;
    case 3:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1)});break;
    case 4:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1),[fs[3].name]:fs[3].plan.decode(r,end,d+1)});break;
    default:read=(r,end,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decode(r,end,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,end,d)=>{const tag=r.tag(end);return tag?{Some:p.element.decode(r,end,d+1)}:{None:null};};break;
  case 'result':read=(r,end,d)=>r.tag(end)?{Err:p.error.decode(r,end,d+1)}:{Ok:p.ok.decode(r,end,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function wireDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=wireReadOperation(field.plan),name=field.name;
  return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),childEnd=r.enter(end,d+1),item=read(r,childEnd,d+1);if(r.cursor!==childEnd)throw Error('trailing wire frame bytes');const value={[name]:item};if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
 }
 const read=wireReadOperation(p);
 return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
}
class WireDecodeCursor{
 constructor(bytes,view,limits){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
// Bind literal validation and postorder visitation once for every descriptor.
// No logical carriers are allocated; projection still validates every child.
function wireScanPlan(root){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,scan:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.scan=wireScanOperation(p);return p;
 };
 return build(root);
}
function wireScanOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':case 'f64':case 'u64':{const size=p.kind==='f32'?4:8;read=(r,end)=>{r.size(end,size);r.cursor=end;};break;}
  case 'string':read=(r,end)=>{let i=r.cursor;while(i<end&&r.bytes[i]<128)i++;if(i<end)wireDecoder.decode(r.bytes.subarray(r.cursor,end));r.cursor=end;};break;
  case 'int':case 'id':case 'enum':read=(r,end)=>{const text=r.text(end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');for(let i=0;i<n;i++)element.scan(r,end,d+1);};break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>{};break;
    case 1:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);};break;
    case 2:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);};break;
    case 3:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);};break;
    case 4:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);fs[3].plan.scan(r,end,d+1);};break;
    default:read=(r,end,d)=>{for(const f of fs)f.plan.scan(r,end,d+1);};
   }break;
  }
  case 'option':read=(r,end,d)=>{if(r.tag(end))p.element.scan(r,end,d+1);};break;
  case 'result':read=(r,end,d)=>{(r.tag(end)?p.error:p.ok).scan(r,end,d+1);};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return (r,parentEnd,d)=>{
  const end=r.enter(parentEnd,d),start=r.cursor,value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');
  const visitor=r.visitor;if(visitor&&(!r.selected||r.selected.has(t.name))){if(r.spans)visitor(t,r.bytes,start,end,d);else visitor(t,r.bytes.subarray(start,end),d);}
  return value;
 };
}
// Separate methods keep decoding's cursor callsites monomorphic. Both cursors
// are checked against the independent generic scanner and malformed fixtures.
class WireScanCursor{
 constructor(bytes,view,limits,visitor,selected,spans){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.visitor=visitor;this.selected=selected;this.spans=spans;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
function compactReadOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=()=>null;break;
  case 'bool':read=r=>{r.require(1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':case 'i32':read=r=>{r.require(4);const n=p.kind==='u32'?r.view.getUint32(r.cursor,true):r.view.getInt32(r.cursor,true);r.cursor+=4;return n;};break;
  case 'f32':read=r=>{r.require(4);const n=r.view.getUint32(r.cursor,true);r.cursor+=4;return {F32Bits:n};};break;
  case 'f64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return {F64Bits:n.toString()};};break;
  case 'u64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return n;};break;
  case 'string':read=r=>r.text();break;
  case 'int':read=r=>{const text=r.text();if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=r=>{const text=r.text();if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=r=>{const text=r.text();if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':read=(r,d)=>{const n=r.count();if(n>r.remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');const values=new Array(n);for(let i=0;i<n;i++)values[i]=p.element.decodeCompact(r,d+1);return values;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1)});break;
    case 2:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1)});break;
    case 3:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1)});break;
    case 4:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1),[fs[3].name]:fs[3].plan.decodeCompact(r,d+1)});break;
    default:read=(r,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decodeCompact(r,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,d)=>r.tag()?{Some:p.element.decodeCompact(r,d+1)}:{None:null};break;
  case 'result':read=(r,d)=>r.tag()?{Err:p.error.decodeCompact(r,d+1)}:{Ok:p.ok.decodeCompact(r,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function compactDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=compactReadOperation(field.plan),name=field.name;
  return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');if(d+1>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return {[name]:read(r,d+1)};};
 }
 const read=compactReadOperation(p);
 return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return read(r,d);};
}
class CompactDecodeCursor{
 constructor(bytes,limits,flags){this.bytes=bytes;this.view=flags&2?new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength):null;this.cursor=1;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 require(n){if(n>this.bytes.length-this.cursor)throw Error('truncated compact value');}
 count(){
  if(this.cursor>=this.bytes.length)throw Error('truncated compact value');
  const first=this.bytes[this.cursor++];if(first<128)return first;
  let value=first&127,scale=128;
  for(let i=1;i<5;i++){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const byte=this.bytes[this.cursor++];if(i===4&&byte>15)throw Error('compact count overflow');value+=(byte&127)*scale;if(byte<128){if(byte===0)throw Error('noncanonical compact count');return value;}scale*=128;}throw Error('compact count overflow');
 }
 tag(){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const tag=this.bytes[this.cursor++];if(tag>1)throw Error('wire sum tag');return tag;}
 text(){const n=this.count();this.require(n);const start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
function wireInvalidValue(){throw Error('invalid value for wire schema');}
// Capture has the canonical logical meaning of decode(encode(value)), without
// allocating wire bytes. A separate plan leaves validation/decoder hot shapes
// unchanged and never retains host input containers between calls.
function wireCapturePlan(root,checked=true){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,capture:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({name:f.name,plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.capture=checked?wireCaptureOperation(p):wireCopyOperation(p);return p;
 };return build(root);
}
function wireCaptureOperation(p){
 const t=p.type;let copy;
 switch(p.kind){
  case 'unit':copy=v=>{if(v!==null)wireInvalidValue();return null;};break;
  case 'bool':copy=(v,r)=>{if(typeof v!=='boolean')wireInvalidValue();r.add(1);return v;};break;
  case 'u32':case 'i32':{
   const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
   copy=(v,r)=>{if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();r.add(4);return v===0?0:v;};break;
  }
  case 'u64':copy=(v,r)=>{const kind=typeof v;if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();r.add(8);return n;};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'int':case 'id':case 'enum':copy=(v,r)=>{const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;if(typeof text!=='string'||!text.isWellFormed()||text.length>r.limit)wireInvalidValue();if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();r.add(wireUtf8Length(text));return p.kind==='int'?{Int:text}:text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   copy=(v,r,d)=>{if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();const n=v.length;if(n>r.remaining||size!==null&&n!==size)wireInvalidValue();r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=element.capture(v[i],r,d+1);return out;};break;
  }
  case 'record':{
   const fs=p.fields;let fields;
   switch(fs.length){
    case 0:fields=()=>({});break;
    case 1:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:fields=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }
   copy=(v,r,d)=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();for(const f of fs)if(!wireOwn(v,f.name))wireInvalidValue();return fields(v,r,d);};break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'None')&&v.None===null)return {None:null};if(wireTagged(v,'Some'))return {Some:p.element.capture(v.Some,r,d+1)};wireInvalidValue();};break;
  case 'result':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'Ok'))return {Ok:p.ok.capture(v.Ok,r,d+1)};if(wireTagged(v,'Err'))return {Err:p.error.capture(v.Err,r,d+1)};wireInvalidValue();};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
class WireCaptureCursor{
 constructor(limits){this.remaining=limits.nodes;this.depth=limits.depth;this.limit=limits.bytes;this.bytes=40;this.add(0);}
 add(n){this.bytes+=n;if(this.bytes>this.limit)throw Error('wire byte limit');}
 enter(depth,bytes){if(depth>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.add(bytes);}
 text(value){if(value.length>this.limit)throw Error('wire byte limit');this.add(wireUtf8Length(value));}
}
// Literal lowerers share this fixed resource policy with logical capture.
export function createValueCaptureBudget(options=wireDefaultOptions){return new WireCaptureCursor(wireLimits(options));}
// The trusted-value API has the same canonical copy and ownership semantics.
// Its caller supplies a stable value accepted by validateValue. Shape/range
// checks remain at external capture boundaries; resource limits still apply.
function wireCopyOperation(p){
 let copy;
 switch(p.kind){
  case 'unit':copy=()=>null;break;
  case 'bool':copy=(v,r)=>{r.add(1);return v;};break;
  case 'u32':copy=(v,r)=>{r.add(4);return v>>>0;};break;
  case 'i32':copy=(v,r)=>{r.add(4);return v|0;};break;
  case 'u64':copy=(v,r)=>{r.add(8);return BigInt(v);};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'){wireFloat.setFloat32(0,v,true);bits=wireFloat.getUint32(0,true);}else bits=v.F32Bits;r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'id':case 'enum':copy=(v,r)=>{r.add(wireUtf8Length(v));return v;};break;
  case 'int':copy=(v,r)=>{const text=typeof v==='bigint'?v.toString():v.Int;r.add(wireUtf8Length(text));return {Int:text};};break;
  case 'list':case 'vector':copy=(v,r,d)=>{const n=v.length;if(n>r.remaining)throw Error('wire sequence size');r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=p.element.capture(v[i],r,d+1);return out;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:copy=()=>({});break;
    case 1:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:copy=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'None')&&v.None===null?{None:null}:{Some:p.element.capture(v.Some,r,d+1)};};break;
  case 'result':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'Ok')?{Ok:p.ok.capture(v.Ok,r,d+1)}:{Err:p.error.capture(v.Err,r,d+1)};};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
// Emit the cached literal schema with one forward writer. Each value is checked
// where it is consumed; byte bounds belong to the writer, not a second size walk.
function wireEncodeValue(root,value,l,w){
 let remaining=l.nodes;const depthLimit=l.depth;
 const node=(p,v,d)=>{
  if(d>depthLimit||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type,start=w.beginNode();
  switch(p.kind){
   case 'unit':if(v!==null)wireInvalidValue();break;
   case 'bool':if(typeof v!=='boolean')wireInvalidValue();w.byte(+v);break;
   case 'u32':case 'i32':{
    const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
    if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();w.word(v>>>0);break;
   }
   case 'u64':{
    const kind=typeof v;
    if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
    const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();w.wide(n);break;
   }
   case 'f64':w.wide(wireF64Bits(v));break;
   case 'f32':{
    let bits;
    if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}
    else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
    w.word(bits);break;
   }
   case 'string':case 'int':case 'id':case 'enum':{
    const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
    if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&(typeof text!=='string'||!/^[0-9a-f]{32}$/.test(text))||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
    w.text(text);break;
   }
   case 'list':case 'vector':{
    if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
    if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
    w.count(v.length);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);break;
   }
   case 'record':{
    const fs=p.fields;
    if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
    for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
    for(let i=0;i<fs.length;i++){const f=fs[i];node(f.plan,v[f.name],d+1);}break;
   }
   case 'option':{
    if(wireTagged(v,'None')&&v.None===null)w.byte(0);
    else if(wireTagged(v,'Some')){w.byte(1);node(p.element,v.Some,d+1);}else wireInvalidValue();break;
   }
   case 'result':{
    if(wireTagged(v,'Ok')){w.byte(0);node(p.ok,v.Ok,d+1);}
    else if(wireTagged(v,'Err')){w.byte(1);node(p.error,v.Err,d+1);}else wireInvalidValue();break;
   }
   default:throw Error('unsupported wire kind');
  }
  w.endNode(start);
 };
 node(root,value,0);
}
function wireCheckValue(root,value,l){
 let remaining=l.nodes,total=40;
 const add=n=>{total+=n;if(total>l.bytes)throw Error('wire byte limit');};
 const node=(p,v,d)=>{
  while(true){
   if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
   const t=p.type;
   switch(p.kind){
    case 'unit':if(v!==null)wireInvalidValue();add(4);return;
    case 'bool':if(typeof v!=='boolean')wireInvalidValue();add(5);return;
    case 'u32':case 'i32':{
     const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
     if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();add(8);return;
    }
    case 'u64':{
     const kind=typeof v;
     if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
     const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();add(12);return;
    }
    case 'f64':wireF64Bits(v);add(12);return;
    case 'f32':{
     if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();}
     else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();const bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
     add(8);return;
    }
    case 'string':case 'int':case 'id':case 'enum':{
     const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
     if(typeof text!=='string'||!text.isWellFormed()||text.length>l.bytes)wireInvalidValue();
     if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
     add(4+wireUtf8Length(text));return;
    }
    case 'list':case 'vector':{
     if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
     if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
     add(8);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);return;
    }
    case 'record':{
     const fs=p.fields;
     if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
     for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
     add(4);if(!fs.length)return;
     for(let i=0;i<fs.length-1;i++)node(fs[i].plan,v[fs[i].name],d+1);
     const f=fs[fs.length-1];p=f.plan;v=v[f.name];d++;continue;
    }
    case 'option':{
     if(wireTagged(v,'None')&&v.None===null){add(5);return;}
     if(!wireTagged(v,'Some'))wireInvalidValue();add(5);p=p.element;v=v.Some;d++;continue;
    }
    case 'result':{
     if(wireTagged(v,'Ok')){add(5);p=p.ok;v=v.Ok;}
     else if(wireTagged(v,'Err')){add(5);p=p.error;v=v.Err;}else wireInvalidValue();
     d++;continue;
    }
    default:throw Error('unsupported wire kind');
   }
  }
 };
 node(root,value,0);if(total>l.bytes)throw Error('wire byte limit');
}
// A single cursor replaces per-node child closures and {end,value} temporaries.
// Projection filters limit callback materialisation, never schema validation.
function wireScanValue(root,bytes,view,l,materialize,visitor,selected,spans){
 let cursor=40,remaining=l.nodes;
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,parentEnd,d)=>{
  if(d>l.depth||--remaining<0||cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const t=p.type,start=cursor+4,end=start+view.getUint32(cursor,true);if(end>parentEnd)throw Error('truncated wire frame');cursor=start;let value;
  switch(p.kind){
   case 'unit':if(end-start!==0)throw Error('malformed wire scalar');value=null;break;
   case 'bool':if(end-start!==1)throw Error('malformed wire scalar');if(bytes[start]>1)throw Error('invalid wire Bool');value=!!bytes[start];cursor=end;break;
   case 'u32':case 'i32':if(end-start!==4)throw Error('malformed wire scalar');value=p.kind==='u32'?view.getUint32(start,true):view.getInt32(start,true);cursor=end;break;
   case 'f32':if(end-start!==4)throw Error('malformed wire scalar');if(materialize)value={F32Bits:view.getUint32(start,true)};cursor=end;break;
   case 'f64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value={F64Bits:view.getBigUint64(start,true).toString()};cursor=end;break;
   case 'u64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value=view.getBigUint64(start,true);cursor=end;break;
   case 'string':case 'int':case 'id':case 'enum':{
    if(p.kind==='string'&&!materialize){let i=start;while(i<end&&bytes[i]<128)i++;if(i<end)wireDecoder.decode(bytes.subarray(start,end));}
    else{const text=wireDecodeText(bytes,start,end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    cursor=end;break;
   }
   case 'list':case 'vector':{
    if(start+4>end)throw Error('wire list count');const n=view.getUint32(start,true);cursor+=4;
    if(n>remaining||n>Math.floor((end-cursor)/4)||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,end,d+1);if(materialize)value.push(child);}break;
   }
   case 'record':{
    const fs=p.fields;
    // Computed literal keys create own data properties even for __proto__ or
    // prototype setters. Common small records need no descriptor allocations.
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:value={};break;case 1:value={[fs[0].name]:node(fs[0].plan,end,d+1)};break;case 2:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1)};break;case 3:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1)};break;case 4:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1),[fs[3].name]:node(fs[3].plan,end,d+1)};break;}
    }else{if(materialize)value={};for(const f of fs){const child=node(f.plan,end,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}}break;
   }
   case 'option':case 'result':{
    if(start===end||bytes[cursor]>1)throw Error('wire sum tag');const tag=bytes[cursor++];
    if(p.kind==='option'&&tag===0){if(materialize)value={None:null};}
    else{const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,end,d+1);if(materialize)value={[label]:child};}break;
   }
   default:throw Error('unsupported wire kind');
  }
  if(cursor!==end)throw Error('trailing wire frame bytes');
  if(visitor&&(!selected||selected.has(t.name))){if(spans)visitor(t,bytes,start,end,d);else visitor(t,bytes.subarray(start,end),d);}
  return value;
 };
 const result=node(root,bytes.length,0);if(cursor!==bytes.length)throw Error('trailing wire bytes');return result;
}
export class ValueCodec{
 #hash;
 #header;
 #headerWords;
 #descriptor;
 #valuePlan;
 #compactCodec;
 #encoder;
 #decodeBound=0;
 #scanPlan=null;
 #capturePlan=null;
 #copyPlan=null;
 get descriptor(){return this.#descriptor;}
 constructor(descriptor){
  // This synchronous path is for compiler-generated immutable metadata. For
  // untrusted descriptors use createValueCodec and compare the computed identity.
  if(descriptor?.format!==valueWireFormat||!/^[0-9a-f]{64}$/.test(descriptor.identity))throw Error('invalid wire schema');
  this.#descriptor=structuredClone(descriptor);this.#hash=Uint8Array.from(descriptor.identity.match(/../g),s=>parseInt(s,16));
  this.#header=new Uint8Array(40);this.#header.set(wireMagic);this.#header.set(this.#hash,8);
  const headerView=new DataView(this.#header.buffer);this.#headerWords=Array.from({length:10},(_,i)=>headerView.getUint32(i*4,true));
  const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}};freeze(this.descriptor);this.#valuePlan=wireValuePlan(this);
 }
 resolve(t){for(let i=0;i<64;i++){if(t.kind!=='ref')return t;t=this.descriptor.named[t.name];if(!t)throw Error('wire reference');}throw Error('wire reference cycle');}
 validateValue(value,options=wireDefaultOptions){wireCheckValue(this.#valuePlan,value,wireLimits(options));return true;}
 capture(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#capturePlan??=wireCapturePlan(this.#valuePlan);return this.#capturePlan.capture(value,new WireCaptureCursor(limits),0);}
 copy(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#copyPlan??=wireCapturePlan(this.#valuePlan,false);return this.#copyPlan.capture(value,new WireCaptureCursor(limits),0);}
 compact(){return this.#compactCodec??=new CompactValueCodec(this);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new WireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.bytes(this.#header);wireEncodeValue(this.#valuePlan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new WireEncoder(options);w.bytes(wireMagic);w.bytes(this.#hash);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 scan(bytes,options=wireDefaultOptions,materialize=false,visitor=null,names=null,spans=false){
  const l=wireLimits(options);if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<44||bytes.length>l.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==this.#headerWords[i])throw Error('wire format or schema mismatch');
  if(names!==null&&(!Array.isArray(names)||names.length>100000||names.some(n=>typeof n!=='string')))throw Error('wire visitor names');
  if(materialize&&!visitor){this.#decodeBound||=wireBindDecodePlan(this.#valuePlan);const cursor=new WireDecodeCursor(bytes,view,l);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#valuePlan.decode(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  if(!materialize){this.#scanPlan??=wireScanPlan(this.#valuePlan);const cursor=new WireScanCursor(bytes,view,l,visitor,names===null?null:new Set(names),spans),value=this.#scanPlan.scan(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  return wireScanValue(this.#valuePlan,bytes,view,l,materialize,visitor,names===null?null:new Set(names),spans);
 }
 visit(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names);}
 visitSpans(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names,true);}
 validate(bytes,options=wireDefaultOptions){this.scan(bytes,options,false);return true;}
 decode(bytes,options=wireDefaultOptions){return this.scan(bytes,options,true);}
}

// Bounded forward emission avoids building and repeatedly joining child buffers.
class WireEncoder{
 #data=new Uint8Array(256);#view=new DataView(this.#data.buffer);#at=0;#remaining;#depth=0;#byteLimit;#depthLimit;
 active=false;
 constructor(options){this.reset(options);}
 reset(options){const limits=wireLimits(options);this.#byteLimit=limits.bytes;this.#depthLimit=limits.depth;this.#remaining=limits.nodes;this.#depth=0;this.#at=0;this.active=true;}
 get capacity(){return this.#data.length;}
 get position(){return this.#at;}
 beginNode(){const at=this.#at;this.word(0);return at;}
 endNode(at){this.patchWord(at,this.#at-at-4);}
 count(n){this.word(n);}
 beginCount(){const at=this.position;this.count(0);return at;}
 endCount(at,n){this.patchWord(at,n);}
 #reserve(size){
  const end=this.#at+size;if(end>this.#byteLimit)throw Error('wire byte limit');
  if(end>this.#data.length){const next=new Uint8Array(Math.min(this.#byteLimit,Math.max(end,this.#data.length*2)));next.set(this.#data.subarray(0,this.#at));this.#data=next;this.#view=new DataView(next.buffer);}
  return end;
 }
 bytes(bytes){const end=this.#reserve(bytes.length);this.#data.set(bytes,this.#at);this.#at=end;}
 byte(n){if(!Number.isInteger(n)||n<0||n>255)throw Error('wire byte range');this.#reserve(1);this.#data[this.#at++]=n;}
 word(n){if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire word range');const end=this.#reserve(4);this.#view.setUint32(this.#at,n,true);this.#at=end;}
 wide(n){if(typeof n!=='bigint'||n<0n||n>18446744073709551615n)throw Error('wire wide range');const end=this.#reserve(8);this.#view.setBigUint64(this.#at,n,true);this.#at=end;}
 text(text,count=false){
  if(typeof text!=='string')throw Error('wire Unicode');
  if(text.length<=16){
   let ascii=true;for(let i=0;i<text.length;i++)if(text.charCodeAt(i)>=128){ascii=false;break;}
   if(ascii){if(count)this.count(text.length);const end=this.#reserve(text.length);for(let i=0;i<text.length;i++)this.#data[this.#at+i]=text.charCodeAt(i);this.#at=end;return;}
  }
  if(!text.isWellFormed())throw Error('wire Unicode');const size=wireUtf8Length(text);if(count)this.count(size);
  const end=this.#reserve(size),r=wireEncoder.encodeInto(text,this.#data.subarray(this.#at,end));if(r.read!==text.length||r.written!==size)throw Error('wire UTF-8 size');this.#at=end;
 }
 patchWord(at,n){if(!Number.isInteger(at)||at<0||at+4>this.#at||!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire patch offset');this.#view.setUint32(at,n,true);}
 patchByte(at,n){if(!Number.isInteger(at)||at<0||at>=this.#at||!Number.isInteger(n)||n<0||n>255)throw Error('wire patch offset');this.#data[at]=n;}
 replace(at,removed,bytes){
  if(!Number.isInteger(at)||!Number.isInteger(removed)||at<0||removed<0||at+removed>this.#at||!(bytes instanceof Uint8Array))throw Error('wire replacement range');
  const extra=bytes.length-removed,end=extra>0?this.#reserve(extra):this.#at+extra;
  this.#data.copyWithin(at+bytes.length,at+removed,this.#at);this.#data.set(bytes,at);this.#at=end;
 }
 // Literal generated writers use balanced frames without per-node callbacks.
 // An exception abandons this invocation; encodeWith never reuses its writer.
 openFrame(){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;return at;}
 closeFrame(at){if(this.#depth===0)throw Error('wire frame boundary');this.#depth--;this.endNode(at);}
 frame(emit){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;try{emit(this);}finally{this.#depth--;}this.endNode(at);}
 reorder(start,spans){
  const sorted=spans.slice().sort((a,b)=>a[0]-b[0]);let at=start;
  for(const [a,b] of sorted){if(!Number.isInteger(a)||!Number.isInteger(b)||a!==at||b<a)throw Error('wire span permutation');at=b;}
  if(start<0||start>this.#at||at!==this.#at)throw Error('wire span permutation');
  if(spans.every((s,i)=>s===sorted[i]))return;
  const copy=this.#data.slice(start,this.#at);at=start;for(const [a,b] of spans){this.#data.set(copy.subarray(a-start,b-start),at);at+=b-a;}
 }
 finish(){if(this.#depth!==0)throw Error('wire frame boundary');return this.#data.slice(0,this.#at);}
}

class CompactWireEncoder extends WireEncoder{
 beginNode(){return 0;}
 endNode(){}
 endCount(at,n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  if(n<128){this.patchByte(at,n);return;}
  const bytes=[];while(n>=128){bytes.push(n%128+128);n=Math.floor(n/128);}bytes.push(n);this.replace(at,1,Uint8Array.from(bytes));
 }
 count(n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  while(n>=128){this.byte(n%128+128);n=Math.floor(n/128);}this.byte(n);
 }
 text(text){super.text(text,true);}
}

function compactScanValue(root,bytes,l,materialize){
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let cursor=1,remaining=l.nodes;
 const require=n=>{if(n>bytes.length-cursor)throw Error('truncated compact value');};
 const count=()=>{
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   require(1);const byte=bytes[cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }throw Error('compact count overflow');
 };
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,d)=>{
  if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type;let value;
  switch(p.kind){
   case 'unit':return null;
   case 'bool':require(1);if(bytes[cursor]>1)throw Error('invalid wire Bool');return !!bytes[cursor++];
   case 'u32':case 'i32':require(4);value=p.kind==='u32'?view.getUint32(cursor,true):view.getInt32(cursor,true);cursor+=4;return value;
   case 'f32':require(4);if(materialize)value={F32Bits:view.getUint32(cursor,true)};cursor+=4;return value;
   case 'f64':require(8);if(materialize)value={F64Bits:view.getBigUint64(cursor,true).toString()};cursor+=8;return value;
   case 'u64':require(8);if(materialize)value=view.getBigUint64(cursor,true);cursor+=8;return value;
   case 'string':case 'int':case 'id':case 'enum':{
    const n=count();require(n);const start=cursor;cursor+=n;
    if(p.kind==='string'&&!materialize){let i=start;while(i<cursor&&bytes[i]<128)i++;if(i<cursor)wireDecoder.decode(bytes.subarray(start,cursor));}
    else{const text=wireDecodeText(bytes,start,cursor);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    return value;
   }
   case 'list':case 'vector':{
    const n=count();if(n>remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,d+1);if(materialize)value.push(child);}return value;
   }
   case 'record':{
    const fs=p.fields;
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:return {};case 1:return {[fs[0].name]:node(fs[0].plan,d+1)};case 2:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1)};case 3:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1)};case 4:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1),[fs[3].name]:node(fs[3].plan,d+1)};}
    }
    if(materialize)value={};for(const f of fs){const child=node(f.plan,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}return value;
   }
   case 'option':case 'result':{
    require(1);const tag=bytes[cursor++];if(tag>1)throw Error('wire sum tag');
    if(p.kind==='option'&&tag===0)return materialize?{None:null}:undefined;
    const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,d+1);
    return materialize?{[label]:child}:undefined;
   }
   default:throw Error('unsupported wire kind');
  }
 };
 const value=node(root,0);if(cursor!==bytes.length)throw Error('trailing compact bytes');return value;
}

// General transport codec, independent of source rewrites and checkpoints.
// The sender/receiver must negotiate this exact identity and format. There is
// deliberately no claim that the bytes themselves identify their schema.
export class CompactValueCodec{
 #source;#plan;#encoder;#decodeBound=0;
 get format(){return compactValueWireFormat;}
 get identity(){return this.#source.descriptor.identity;}
 constructor(valueCodec){if(!(valueCodec instanceof ValueCodec))throw Error('compact codec requires a checked value codec');this.#source=valueCodec;this.#plan=wireValuePlan(valueCodec);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new CompactWireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.byte(1);wireEncodeValue(this.#plan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new CompactWireEncoder(options);w.byte(1);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 #scan(bytes,options,materialize){
  const l=wireLimits(options);
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<1||bytes.length>l.bytes)throw Error('wire byte limit or header');
  if(bytes[0]!==1)throw Error('compact format mismatch');
  if(materialize){this.#decodeBound||=wireBindDecodePlan(this.#plan,true);const cursor=new CompactDecodeCursor(bytes,l,this.#decodeBound);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#plan.decodeCompact(cursor,0);if(cursor.cursor!==bytes.length)throw Error('trailing compact bytes');return value;}
  return compactScanValue(this.#plan,bytes,l,materialize);
 }
 decode(bytes,options=wireDefaultOptions){return this.#scan(bytes,options,true);}
 validate(bytes,options=wireDefaultOptions){this.#scan(bytes,options,false);return true;}
}

// Compiler materialisers consume already validated bytes synchronously. This
// factory is for trusted emitted code, not untrusted descriptor/callback data.
// The complete generic validator runs before any compiler reader is invoked.
class ValidatedValueReader{
 constructor(bytes,compact){this.bytes=bytes;this.view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);this.cursor=compact?1:40;this.compact=compact;}
 frame(){if(this.compact)return 0;const end=this.cursor+4+this.view.getUint32(this.cursor,true);this.cursor+=4;return end;}
 finish(end){if(!this.compact&&this.cursor!==end)throw Error('compiled reader frame mismatch');}
 byte(){return this.bytes[this.cursor++];}
 word(){const n=this.view.getUint32(this.cursor,true);this.cursor+=4;return n;}
 signed(){const n=this.view.getInt32(this.cursor,true);this.cursor+=4;return n;}
 wide(){const n=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return n;}
 count(){if(!this.compact)return this.word();let n=0,scale=1,byte;do{byte=this.byte();n+=(byte&127)*scale;scale*=128;}while(byte>=128);return n;}
 text(end){const n=this.compact?this.count():end-this.cursor,start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
class CompiledCompactValueCodec extends CompactValueCodec{
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,true),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
}
class CompiledValueCodec extends ValueCodec{
 #read;#compiledCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,false),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
 compact(){return this.#compiledCompact??=new CompiledCompactValueCodec(this,this.#read);}
}
export function createCompiledValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new CompiledValueCodec(descriptor,read);}

// Trusted literal materialisers may use this checked reader to validate and
// construct in one traversal. The emitter must use frame/finish at every source
// node, typed text reads and counted sequence reads; arbitrary callbacks do not
// establish a schema correspondence proof. The independent scanner remains the
// validation oracle and the original factory retains its pre-validation path.
function literalValueHeader(identity){
 const bytes=new Uint8Array(40);bytes.set(wireMagic);
 for(let i=0;i<32;i++)bytes[i+8]=parseInt(identity.slice(i*2,i*2+2),16);
 const view=new DataView(bytes.buffer),words=new Uint32Array(10);
 for(let i=0;i<10;i++)words[i]=view.getUint32(i*4,true);
 return words;
}
class CheckedLiteralValueReader {
 constructor(bytes,header,compact,limits){
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<(compact?1:44)||bytes.length>limits.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  if(compact){if(bytes[0]!==1)throw Error('compact format mismatch');}
  else for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==header[i])throw Error('wire format or schema mismatch');
  this.bytes=bytes;this.view=view;
  this.cursor=compact?1:40;this.compact=compact;this.remaining=limits.nodes;this.depth=limits.depth;this.ends=[];
 }
 require(n){if(this.cursor+n>(this.ends.at(-1)??this.bytes.length))throw Error('truncated wire frame');}
 frame(){
  if(this.ends.length>this.depth||--this.remaining<0)throw Error('wire node or depth limit');
  let end=this.bytes.length;
  if(!this.compact){this.require(4);end=this.cursor+4+this.view.getUint32(this.cursor,true);this.require(end-this.cursor);this.cursor+=4;}
  this.ends.push(end);return this.compact?0:end;
 }
 finish(end){
  if(!this.ends.length||!this.compact&&(this.ends.at(-1)!==end||this.cursor!==end))throw Error('compiled reader frame mismatch');
  this.ends.pop();
 }
 byte(){this.require(1);const value=this.bytes[this.cursor++];if(value>1)throw Error('wire sum tag or Bool');return value;}
 word(){this.require(4);const value=this.view.getUint32(this.cursor,true);this.cursor+=4;return value;}
 signed(){this.require(4);const value=this.view.getInt32(this.cursor,true);this.cursor+=4;return value;}
 wide(){this.require(8);const value=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return value;}
 rawCount(){
  if(!this.compact)return this.word();
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   this.require(1);const byte=this.bytes[this.cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }
  throw Error('compact count overflow');
 }
 count(size){
  const value=this.rawCount();
  if(value>this.remaining||size!==undefined&&value!==size)throw Error('wire sequence size');
  return value;
 }
 text(end,kind='string',variants){
  const size=this.compact?this.rawCount():end-this.cursor;
  this.require(size);const start=this.cursor;this.cursor+=size;
  const value=wireDecodeText(this.bytes,start,this.cursor);
  if(kind==='int'&&!wireDecimal(value)||kind==='id'&&!/^[0-9a-f]{32}$/.test(value)||kind==='enum'&&!variants.includes(value))throw Error('malformed wire text');
  return value;
 }
 complete(){if(this.ends.length||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
// Compact source nodes have no individual frame ends: retain the same checked
// depth/node order using a counter, with bounds against the complete buffer.
class CheckedCompactLiteralValueReader extends CheckedLiteralValueReader {
 constructor(bytes,limits){super(bytes,null,true,limits);this.level=0;}
 require(n){if(this.cursor+n>this.bytes.length)throw Error('truncated wire frame');}
 frame(){if(this.level>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.level++;return 0;}
 finish(_end){if(!this.level)throw Error('compiled reader frame mismatch');this.level--;}
 complete(){if(this.level||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
class FusedCompactValueCodec extends CompactValueCodec {
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedCompactLiteralValueReader(bytes,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
}
class FusedValueCodec extends ValueCodec {
 #read;#header;#fusedCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;this.#header=literalValueHeader(this.descriptor.identity);}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedLiteralValueReader(bytes,this.#header,false,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
 compact(){return this.#fusedCompact??=new FusedCompactValueCodec(this,this.#read);}
}
export function createFusedValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new FusedValueCodec(descriptor,read);}
// JSON text is a boundary adapter to an ordinary recursive Ink datatype.
// No JavaScript Number conversion occurs for JSON numeric tokens.
export function jsonNumberToken(s){return typeof s==='string'&&/^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/.test(s);}
// JSON numeric tokens have an ASCII grammar. Check validated UTF-8 spans
// directly, preserving exact lexemes without allocating a decoded String.
function jsonNumberSpan(bytes,lo,hi){
 let at=lo;if(bytes[at]===45)at++;
 if(at>=hi)return false;
 if(bytes[at]===48)at++;
 else{if(bytes[at]<49||bytes[at]>57)return false;do{at++;}while(at<hi&&bytes[at]>=48&&bytes[at]<=57);}
 if(at<hi&&bytes[at]===46){const start=++at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 if(at<hi&&(bytes[at]===69||bytes[at]===101)){at++;if(at<hi&&(bytes[at]===43||bytes[at]===45))at++;const start=at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 return at===hi;
}
const jsonWireEncoder=new TextEncoder();
// Scalar conversion completes before writer callbacks; no per-value byte array.
const jsonFloatScratch=new DataView(new ArrayBuffer(4));
function jsonUtf8Length(text){if(text.length>16&&!/[^\x00-\x7f]/.test(text))return text.length;let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const jsonLimits={bytes:16777216,nodes:1000000,depth:128};
const jsonQuoters=new WeakSet();
/** Explicit, bounded reuse of immutable JSON string quotes. Cache payload bytes
 * are UTF-16 storage estimates; entry caps bound separate Map/object overhead.
 * Logical output budgets are charged again on every use, including cache hits.
 */
export function createJsonQuoter({maxEntries=1024,maxBytes=131072}={}){
 if(!Number.isSafeInteger(maxEntries)||maxEntries<0||maxEntries>65536||!Number.isSafeInteger(maxBytes)||maxBytes<0||maxBytes>16777216)throw Error('JSON quote cache budget');
 const entries=new Map();let bytes=0,hits=0,misses=0;
 const token=value=>{
  const prior=entries.get(value);if(prior!==undefined){hits++;return prior;}
  if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid JSON String');
  misses++;const text=JSON.stringify(value),size=2*(value.length+text.length),quoted=Object.freeze({text,utf8Bytes:jsonUtf8Length(text)});
  if(maxEntries&&size<=maxBytes){
   while(entries.size&&(entries.size>=maxEntries||bytes+size>maxBytes)){const key=entries.keys().next().value;bytes-=2*(key.length+entries.get(key).text.length);entries.delete(key);}
   entries.set(value,quoted);bytes+=size;
  }
  return quoted;
 };
 const quoter=Object.freeze({
  token,
  quote(value){return token(value).text;},
  clear(){entries.clear();bytes=0;},
  stats(){return {entries:entries.size,payload_bytes:bytes,hits,misses};},
 });jsonQuoters.add(quoter);return quoter;
}
function checkedJsonLimits(options){const l={...jsonLimits,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>jsonLimits[k])throw Error('JSON hard resource limit');return l;}
function jsonVariant(index,item){let payload=index===0?{}:{item0:item};if(index<5)payload={Ok:payload};for(let i=0;i<index;i++)payload={Err:payload};return {payload};}
export function parseJson(text,options={}){return parseJsonValue(text,options,null);}
function parseJsonValue(text,options,boundary){
 const p=new JsonWireReader(text,options);
 const value=(d,wireDepth=0)=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){boundary?.node(0,wireDepth);p.at+=4;return jsonVariant(0,null);}if(c==='t'&&text.startsWith('true',p.at)){boundary?.node(1,wireDepth);p.at+=4;return jsonVariant(1,true);}if(c==='f'&&text.startsWith('false',p.at)){boundary?.node(1,wireDepth);p.at+=5;return jsonVariant(1,false);}
  if(c==='"'){boundary?.node(3,wireDepth);const item=p.string();boundary?.text(item);return jsonVariant(3,item);}
  if(c==='['){boundary?.node(4,wireDepth);p.at++;const xs=[];if(!p.eat(']'))while(true){xs.push(value(d+1,wireDepth+8));if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}return jsonVariant(4,xs);}
  if(c==='{'){boundary?.node(5,wireDepth);p.at++;const xs=[],seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary?.member(key,wireDepth);if(!p.eat(':'))throw Error('JSON object colon');xs.push({key,value:value(d+1,wireDepth+9)});if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}return jsonVariant(5,xs);}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();boundary?.node(2,wireDepth);boundary?.text(token);return jsonVariant(2,token);}
  throw Error('invalid JSON value');
 };
 const out=value(0);p.finish();return out;
}
export function stringifyJson(value,options={}){return stringifyJsonValue(value,options,null);}
function stringifyJsonValue(value,options,boundary){
 const l=checkedJsonLimits(options);let remaining=l.nodes,bytes=0,output='';
 const emit=s=>{bytes+=jsonUtf8Length(s);if(bytes>l.bytes)throw Error('JSON byte limit');output+=s;};
 const write=(v,d,wireDepth=0)=>{
  if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');if(!v||Object.keys(v).length!==1||!Object.hasOwn(v,'payload'))throw Error('invalid JSON record');let p=v.payload,index=0;
  while(index<5&&p&&Object.hasOwn(p,'Err')){if(Object.keys(p).length!==1||boundary&&Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Err;index++;}
  if(index<5){if(!p||Object.keys(p).length!==1||!Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Ok;}
  if(!p||Object.keys(p).length!==(index===0?0:1)||index>0&&!Object.hasOwn(p,'item0'))throw Error('invalid JSON payload');const item=p.item0;boundary?.node(index,wireDepth);
  switch(index){
   case 0:emit('null');break;
   case 1:if(typeof item!=='boolean')throw Error('invalid JSON Boolean');emit(item?'true':'false');break;
   case 2:if(!jsonNumberToken(item))throw Error('invalid JSON number');boundary?.text(item);emit(item);break;
   case 3:if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary?.text(item);emit(JSON.stringify(item));break;
   case 4:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Array');const count=item.length;let visited=0;emit('[');item.forEach((x,i)=>{visited++;if(i)emit(',');write(x,d+1,wireDepth+8);});if(visited!==count)throw Error('invalid JSON Array');emit(']');break;}
   case 5:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Object');const count=item.length,seen=new Set();let visited=0;emit('{');item.forEach((m,i)=>{visited++;if(!m||Object.keys(m).length!==2||typeof m.key!=='string'||!m.key.isWellFormed()||!Object.hasOwn(m,'value')||boundary&&!Object.hasOwn(m,'key'))throw Error('invalid JSON member');if(seen.has(m.key))throw Error('duplicate JSON object key');seen.add(m.key);boundary?.member(m.key,wireDepth);if(i)emit(',');emit(JSON.stringify(m.key));emit(':');write(m.value,d+1,wireDepth+9);});if(visited!==count)throw Error('invalid JSON Object');emit('}');break;}
  }
 };write(value,0);return output;
}
// The adapter's schema is the fixed recursive JSON library shape checked by
// JsonCodec. Charge its ordinary record/sum/list wire nodes while parsing or
// rendering, rather than interpreting and walking the completed tree again.
function jsonBoundaryBudget(options){
 const l=checkedJsonLimits(options);let remaining=l.nodes,total=40;
 const charge=(nodes,bytes,depth)=>{remaining-=nodes;total+=bytes;if(remaining<0||depth>l.depth)throw Error('wire node or depth limit');if(total>l.bytes)throw Error('wire byte limit');};
 return {
  node(index,depth){charge(index===0?3:index<4?index+4:8,index===0?13:index===1?23:index===2?27:index===3?32:41,depth+(index===0?2:index<4?index+3:7));},
  text(text){charge(0,jsonUtf8Length(text),0);},
  member(key,depth){charge(2,8+jsonUtf8Length(key),depth+9);},
 };
}
function jsonSameSchema(a,b){
 if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;
 const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>Object.hasOwn(b,k)&&jsonSameSchema(a[k],b[k]));
}
// Host-object conversion is opt-in and JavaScript-only. Inspect data properties
// rather than invoking getters/toJSON; reflection is not a sandbox for proxies.
function jsonJSKeys(value){
 if(!value||typeof value!=='object')throw Error('expected a plain JavaScript object');
 const prototype=Object.getPrototypeOf(value);
 if(prototype!==Object.prototype&&prototype!==null)throw Error('expected a plain JavaScript object');
 const keys=Reflect.ownKeys(value);
 if(keys.some(k=>typeof k!=='string'))throw Error('JavaScript symbol keys are unsupported');
 return keys;
}
function jsonJSData(value,key){
 const property=Object.getOwnPropertyDescriptor(value,key);
 if(!property||!property.enumerable||!Object.hasOwn(property,'value'))throw Error('expected an enumerable own data property');
 return property.value;
}
function jsonJSRecord(value,names){
 const keys=jsonJSKeys(value);
 if(keys.length!==names.length||keys.some(k=>!names.includes(k)))throw Error('invalid JSON record or variant');
}
function jsonJSArray(value,remaining){
 if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype)throw Error('expected a plain JavaScript array');
 const length=value.length;
 if(length>remaining)throw Error('JSON node limit');
 const keys=Reflect.ownKeys(value);
 if(keys.length!==length+1||keys.some(k=>typeof k!=='string'||k!=='length'&&(!/^(0|[1-9][0-9]*)$/.test(k)||Number(k)>=length)))throw Error('sparse or decorated JavaScript arrays are unsupported');
 return length;
}
function jsonFromJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),active=new WeakSet();let remaining=limits.nodes;
 const text=value=>{if(!value.isWellFormed())throw Error('invalid JSON Unicode');boundary.text(value);return value;};
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  if(value===null){boundary.node(0,wireDepth);return jsonVariant(0);}
  switch(typeof value){
   case 'boolean':boundary.node(1,wireDepth);return jsonVariant(1,value);
   case 'string':boundary.node(3,wireDepth);return jsonVariant(3,text(value));
   case 'number':
    if(!Number.isFinite(value))throw Error('non-finite JavaScript numbers are unsupported');
    boundary.node(2,wireDepth);return jsonVariant(2,text(Object.is(value,-0)?'-0':String(value)));
   case 'bigint':boundary.node(2,wireDepth);return jsonVariant(2,text(String(value)));
   case 'object':break;
   default:throw Error('unsupported JavaScript value');
  }
  if(active.has(value))throw Error('cyclic JavaScript value');
  active.add(value);
  try{
   if(Array.isArray(value)){
    boundary.node(4,wireDepth);const count=jsonJSArray(value,remaining),items=[];
    for(let i=0;i<count;i++)items.push(visit(jsonJSData(value,String(i)),depth+1,wireDepth+8));
    return jsonVariant(4,items);
   }
   boundary.node(5,wireDepth);const keys=jsonJSKeys(value),members=[];
   if(keys.length>remaining)throw Error('JSON node limit');
   for(const key of keys){
    if(!key.isWellFormed())throw Error('invalid JSON Unicode');
    boundary.member(key,wireDepth);
    members.push({key,value:visit(jsonJSData(value,key),depth+1,wireDepth+9)});
   }
   return jsonVariant(5,members);
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
function jsonDecimalKey(token){
 const [,sign,whole,fraction='',exponent='0']=/^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(token);
 const digits=(whole+fraction).replace(/^0+/,'');
 if(!digits)return '0';
 const trimmed=digits.replace(/0+$/,'');
 return sign+trimmed+'e'+(Number(exponent)-fraction.length+digits.length-trimmed.length);
}
function jsonToJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),mode=options?.numbers??'number',active=new WeakSet();let remaining=limits.nodes;
 if(!['number','bigint','string'].includes(mode))throw Error('unknown JavaScript number policy');
 const number=token=>{
  if(!jsonNumberToken(token))throw Error('invalid JSON number');
  boundary.text(token);
  if(mode==='string')return token;
  if(mode==='bigint')return BigInt(jsonInteger(token,4096));
  const result=Number(token);
  if(!Number.isFinite(result)||jsonDecimalKey(token)!==jsonDecimalKey(String(result)))throw Error('JSON number loses precision as JavaScript Number; choose numbers: bigint or string');
  return result;
 };
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  jsonJSRecord(value,['payload']);
  if(active.has(value))throw Error('cyclic JSON value');
  active.add(value);
  try{
   let payload=jsonJSData(value,'payload'),index=0;
   while(index<5&&Object.hasOwn(payload,'Err')){jsonJSRecord(payload,['Err']);payload=jsonJSData(payload,'Err');index++;}
   if(index<5){jsonJSRecord(payload,['Ok']);payload=jsonJSData(payload,'Ok');}
   jsonJSRecord(payload,index===0?[]:['item0']);boundary.node(index,wireDepth);
   const item=index===0?null:jsonJSData(payload,'item0');
   if(index===0)return null;
   if(index===1){if(typeof item!=='boolean')throw Error('invalid JSON Boolean');return item;}
   if(index===2)return number(item);
   if(index===3){if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary.text(item);return item;}
   const count=jsonJSArray(item,remaining);
   if(index===4){const out=[];for(let i=0;i<count;i++)out.push(visit(jsonJSData(item,String(i)),depth+1,wireDepth+8));return out;}
   const out={},seen=new Set();
   for(let i=0;i<count;i++){
    const member=jsonJSData(item,String(i));jsonJSRecord(member,['key','value']);const key=jsonJSData(member,'key');
    if(typeof key!=='string'||!key.isWellFormed())throw Error('invalid JSON member key');
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary.member(key,wireDepth);
    Object.defineProperty(out,key,{value:visit(jsonJSData(member,'value'),depth+1,wireDepth+9),enumerable:true,writable:true,configurable:true});
   }
   return out;
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
const jsonConstructionPaths=Object.freeze(Array.from({length:6},(_,index)=>Object.freeze([0,...Array(index).fill(1),...(index<5?[0]:[]),0])));
function parseJsonConstructed(text,options,builder){
 const p=new JsonWireReader(text,options);
 const paths=jsonConstructionPaths;
 const fused=typeof builder.openPath==='function';
 const begin=index=>{if(fused){builder.openPath(paths[index]);return;}for(const choice of paths[index])builder.open(choice);};
 const end=index=>{for(let i=0;i<(fused?1:index<5?index+3:7);i++)builder.close();};
 const leaf=(index,item)=>{if(typeof builder.scalarPath==='function'){builder.scalarPath(paths[index],item);return;}begin(index);builder.scalar(item);end(index);};
 const value=d=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){p.at+=4;if(typeof builder.emptyPath==='function')builder.emptyPath(paths[0]);else{begin(0);end(0);}return;}
  if(c==='t'&&text.startsWith('true',p.at)){p.at+=4;leaf(1,true);return;}
  if(c==='f'&&text.startsWith('false',p.at)){p.at+=5;leaf(1,false);return;}
  if(c==='"'){leaf(3,p.string());return;}
  if(c==='['){begin(4);builder.open(0);p.at++;if(!p.eat(']'))while(true){value(d+1);if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}builder.close();end(4);return;}
  if(c==='{'){begin(5);builder.open(0);p.at++;const seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');builder.open(0);builder.scalar(key);value(d+1);builder.close();if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}builder.close();end(5);return;}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();leaf(2,token);return;}
  throw Error('invalid JSON value');
 };
 value(0);p.finish();return builder.finish();
}
const jsonCompiledRenderers=new WeakMap();
function compiledJsonRenderer(json,codec,unwrap){
 if(typeof codec?.reducer!=='function')throw Error('compiled JSON reduction unavailable');
 const source=codec.resolve(codec.descriptor.root),root=json.values.descriptor.root;
 const selected=unwrap&&source.kind==='result'?codec.resolve(source.ok):source;
 if(!jsonSameSchema(root,selected)||unwrap&&source.kind!=='result')throw Error('compiled JSON schema mismatch');
 let variants=root.fields[0].type;const roles=new Map([[root.name,'root']]);
 let member;
 for(let index=0;index<6;index++){
  const branch=index<5?variants.ok:variants;roles.set(branch.name,index);
  if(index===5){member=branch.fields[0].type.element.name;roles.set(member,'member');}
  if(index<5)variants=variants.error;
 }
 const nodeRoles=new Map();
 return codec.reducer((node,index)=>{
  const role=roles.get(node.name);nodeRoles.set(index,role);
  if(node.kind==='record'){
   if(role==='root')return value=>value;
   if(role==='member')return (key,value,context)=>{
    const text=(context.quoter?context.quote(key,true):context.add(JSON.stringify(key)+':'))+value,seen=context.members;
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);return text;
   };
   if(role===0)return context=>context.add('null');
   if(role===1)return (value,context)=>context.add(value?'true':'false');
   if(role===2)return (token,context)=>{if(!jsonNumberToken(token))throw Error('invalid JSON number');return context.add(token);};
   if(role===3)return (value,context)=>context.quoter?context.quote(value,false):context.add(JSON.stringify(value));
   if(role===4)return (value,context)=>{context.add('[]');return '['+value+']';};
   if(role===5)return (value,context)=>{context.add('{}');return '{'+value+'}';};
   return ()=>null;
  }
  if(node.kind==='list'||node.kind==='vector'){
   const members=nodeRoles.get(node.children[0])==='member';
   return {
    start:(_length,context)=>{
     const out={text:'',parent:members?context.members:null};
     if(members)context.members=new Set();return out;
    },
    step:(out,value,index,context)=>{out.text+=(index?context.add(','):'')+value;return out;},
    finish:(out,context)=>{if(members)context.members=out.parent;return out.text;},
   };
  }
  if(node.kind==='result'){
   // A Result<Json,E> boundary is explicitly requested by the caller. Ordinary
   // JSON's own sums only propagate an already rendered branch.
   if(unwrap&&nodeRoles.get(node.children[0])==='root')return (tag,value)=>{if(tag)throw Error('JSON result is Err');return value;};
   return (_tag,value)=>value;
  }
  if(node.kind==='string')return value=>{if(!value.isWellFormed())throw Error('invalid JSON String');return value;};
  return value=>value;
 });
}
export class JsonCodec{
 constructor(valueCodec){
  const root=valueCodec.descriptor.root,fields=root.fields;if(root.kind!=='record'||!Array.isArray(fields)||fields.length!==1||fields[0].name!=='payload')throw Error('JSON schema payload');let sum=fields[0].type;
  for(let i=0;i<6;i++){
   if(i<5&&sum.kind!=='result')throw Error('JSON schema sum');const branch=i<5?sum.ok:sum,fs=branch.fields;
   if(branch.kind!=='record'||!Array.isArray(fs)||fs.length!==(i?1:0)||i&&fs[0].name!=='item0')throw Error('JSON schema branch');
   if(i){const t=fs[0].type;if(i===1&&t.kind!=='bool'||(i===2||i===3)&&t.kind!=='string'||i===4&&(t.kind!=='list'||t.element.kind!=='ref'||t.element.name!==root.name))throw Error('JSON schema variant');if(i===5){const mf=t.element?.fields;if(t.kind!=='list'||t.element?.kind!=='record'||!Array.isArray(mf)||mf.length!==2||mf[0].name!=='key'||mf[0].type.kind!=='string'||mf[1].name!=='value'||mf[1].type.kind!=='ref'||mf[1].type.name!==root.name)throw Error('JSON schema member');}}
   if(i===2)this.numberBranch=branch.name;if(i===5)this.objectBranch=branch.name;
   if(i<5)sum=sum.error;
  }if(!jsonSameSchema(root,valueCodec.resolve({kind:'ref',name:root.name})))throw Error('JSON recursive schema mismatch');this.values=valueCodec;
 }
 parse(text,options={}){return parseJsonValue(text,options,jsonBoundaryBudget(options));}
 parseCompiled(codec,text,options={}){
  if(codec?.identity!==this.values.descriptor.identity||typeof codec.builder!=='function')throw Error('compiled JSON schema mismatch');
  const builder=codec.builder(options);try{return parseJsonConstructed(text,options,builder);}catch(error){builder.abort();throw error;}
 }
 stringify(value,options={}){return stringifyJsonValue(value,options,jsonBoundaryBudget(options));}
 stringifyCompiled(codec,handle,options={}){
  const limits=checkedJsonLimits(options),unwrap=options.unwrapResult===true;
  const quoter=options.quoter;if(quoter!==undefined&&!jsonQuoters.has(quoter))throw Error('JSON quote cache owner mismatch');
  let codecs=jsonCompiledRenderers.get(this);if(!codecs)jsonCompiledRenderers.set(this,codecs=new WeakMap());
  let renderers=codecs.get(codec);if(!renderers)codecs.set(codec,renderers=new Map());
  let render=renderers.get(unwrap);if(!render)renderers.set(unwrap,render=compiledJsonRenderer(this,codec,unwrap));
  let bytes=0;const context={
   quoter,
   add(text){bytes+=jsonUtf8Length(text);if(bytes>limits.bytes)throw Error('JSON byte limit');return text;},
   quote(value,colon){
    if(!quoter)return this.add(JSON.stringify(value)+(colon?':':''));
    const token=quoter.token(value);bytes+=token.utf8Bytes+(colon?1:0);if(bytes>limits.bytes)throw Error('JSON byte limit');return token.text+(colon?':':'');
   },
  };
  const text=render(handle,context,limits);
  return text;
 }
 fromJS(value,options={}){return jsonFromJS(value,options);}
 toJS(value,options={}){return jsonToJS(value,options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,false);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,false,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,true);}
 validateBinary(bytes,options={}){
  const decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});let view;
  this.values.visitSpans(bytes,(type,data,start,end)=>{
   view??=new DataView(data.buffer,data.byteOffset,data.byteLength);
   if(type.name===this.numberBranch){const length=view.getUint32(start,true);if(!jsonNumberSpan(data,start+4,start+4+length))throw Error('invalid JSON number token');}
   if(type.name===this.objectBranch){const listEnd=start+4+view.getUint32(start,true),count=view.getUint32(start+4,true),seen=new Set();let at=start+8;for(let i=0;i<count;i++){const memberEnd=at+4+view.getUint32(at,true),keyStart=at+8,keyEnd=keyStart+view.getUint32(at+4,true),key=decoder.decode(data.subarray(keyStart,keyEnd));if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);at=memberEnd;}if(at!==listEnd)throw Error('invalid JSON object frame');}
  },options,[this.numberBranch,this.objectBranch]);return true;

 }
}
function jsonUnpack(value){let p=value.payload,i=0;while(i<5&&Object.hasOwn(p,'Err')){p=p.Err;i++;}return [i,(i<5?p.Ok:p).item0];}
function jsonInteger(token,limit){
 if(!jsonNumberToken(token))throw Error('invalid JSON number');const negative=token[0]==='-',raw=negative?token.slice(1):token,[mantissa,exp='0']=raw.split(/[eE]/);let digits=mantissa.replace('.','');if(/^0+$/.test(digits))return '0';const exponent=Number(exp),fraction=mantissa.includes('.')?mantissa.length-mantissa.indexOf('.')-1:0,shift=exponent-fraction;
 if(!Number.isSafeInteger(exponent)||!Number.isSafeInteger(shift))throw Error('JSON integer exponent limit');
 if(shift<0){const cut=-shift;if(cut>=digits.length||!/^[0]+$/.test(digits.slice(-cut)))throw Error('JSON number is not an integer');digits=digits.slice(0,-cut);}else{if(digits.length+shift>limit)throw Error('JSON integer magnitude limit');digits+='0'.repeat(shift);}
 digits=digits.replace(/^0+/,'');if(digits.length>limit)throw Error('JSON integer magnitude limit');return (negative?'-':'')+digits;
}
function jsonBinary64Value(v){
 if(typeof v==='number')return v;
 const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid F64Bits');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');
 const b=new DataView(new ArrayBuffer(8));b.setBigUint64(0,bits,true);return b.getFloat64(0,true);
}
export class TypedJsonCodec{
 constructor(valueCodec){this.values=valueCodec;}
 decode(document,options={}){
  // Validate JSON-specific invariants before interpreting any tagged/record
  // shape, including duplicated names and malformed numeric tokens.
  stringifyJson(document,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const read=(type,value,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type),[kind,item]=jsonUnpack(value);const fail=()=>{throw Error('JSON does not match '+t.kind);};
   switch(t.kind){
    case 'unit':if(kind!==0)fail();return null;
    case 'bool':if(kind!==1)fail();return item;
    case 'u32':case 'u64':case 'i32':case 'int':{if(kind!==2)fail();const text=jsonInteger(item,t.kind==='int'?4096:t.kind==='u64'?20:10);return t.kind==='int'?{Int:text}:t.kind==='u64'?BigInt(text):Number(text);}
    case 'f64':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(8));if(!Number.isFinite(n))throw Error('JSON f64 overflow');b.setFloat64(0,n,true);return {F64Bits:b.getBigUint64(0,true).toString()};}
    case 'f32':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(4));b.setFloat32(0,n,true);if(!Number.isFinite(b.getFloat32(0,true)))throw Error('JSON f32 overflow');return {F32Bits:b.getUint32(0,true)};}
    case 'string':case 'enum':case 'id':if(kind!==3)fail();return item;
    case 'list':case 'vector':if(kind!==4)fail();return item.map(x=>read(t.element,x,d+1));
    case 'record':{if(kind!==5||item.length!==t.fields.length)throw Error('unknown or missing JSON record field');const fields=new Map(item.map(m=>[m.key,m.value])),out={};for(const f of t.fields){if(!fields.has(f.name))throw Error('missing JSON record field');Object.defineProperty(out,f.name,{value:read(f.type,fields.get(f.name),d+1),writable:true,enumerable:true,configurable:true});}return out;}
    case 'option':case 'result':{if(kind!==5||item.length!==1)fail();const m=item[0];if(t.kind==='option'&&m.key==='None'&&jsonUnpack(m.value)[0]===0)return {None:null};const child=t.kind==='option'&&m.key==='Some'?t.element:t.kind==='result'&&m.key==='Ok'?t.ok:t.kind==='result'&&m.key==='Err'?t.error:null;if(!child)fail();return {[m.key]:read(child,m.value,d+1)};}
    default:fail();
   }
  };
  const out=read(this.values.descriptor.root,document,0);this.values.validateValue(out,options);return out;
 }
 encode(value,options={}){
  this.values.validateValue(value,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const write=(type,v,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type);
   switch(t.kind){
    case 'unit':return jsonVariant(0);
    case 'bool':return jsonVariant(1,v);
    case 'u32':case 'u64':case 'i32':return jsonVariant(2,String(v));
    case 'int':return jsonVariant(2,typeof v==='bigint'?String(v):v.Int);
    case 'f64':{const n=jsonBinary64Value(v);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'f32':{let n;if(typeof v==='number')n=Math.fround(v);else{const b=new DataView(new ArrayBuffer(4));b.setUint32(0,v.F32Bits,true);n=b.getFloat32(0,true);}if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'string':case 'id':case 'enum':return jsonVariant(3,v);
    case 'list':case 'vector':return jsonVariant(4,Array.from(v,x=>write(t.element,x,d+1)));
    case 'record':return jsonVariant(5,t.fields.map(f=>({key:f.name,value:write(f.type,v[f.name],d+1)})));
    case 'option':return jsonVariant(5,[Object.hasOwn(v,'Some')?{key:'Some',value:write(t.element,v.Some,d+1)}:{key:'None',value:jsonVariant(0)}]);
    case 'result':return jsonVariant(5,[Object.hasOwn(v,'Ok')?{key:'Ok',value:write(t.ok,v.Ok,d+1)}:{key:'Err',value:write(t.error,v.Err,d+1)}]);
    default:throw Error('unsupported typed JSON descriptor');
   }
  };return write(this.values.descriptor.root,value,0);
 }
 parse(text,options={}){return this.decode(parseJson(text,options),options);}
 stringify(value,options={}){return stringifyJson(this.encode(value,options),options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,true);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,true,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,false);}
}

// Token reader shared by schema-directed and arbitrary-JSON wire emission.
class JsonWireReader{
 constructor(text,options){this.l=checkedJsonLimits(options);if(typeof text!=='string'||!text.isWellFormed()||text.length>this.l.bytes||jsonUtf8Length(text)>this.l.bytes)throw Error('JSON byte or Unicode limit');this.text=text;this.at=0;this.remaining=this.l.nodes;}
 ws(){while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(c!==32&&c!==9&&c!==10&&c!==13)break;this.at++;}}
 peek(){this.ws();return this.text[this.at];}
 eat(c){this.ws();if(this.text[this.at]===c){this.at++;return true;}return false;}
 node(d){if(d>this.l.depth||--this.remaining<0)throw Error('JSON node or depth limit');}
 string(){
  this.ws();const start=this.at;if(this.text[start]!=='"')throw Error('expected JSON string');
  const end=this.text.indexOf('"',start+1);if(end<0)throw Error('unterminated JSON string');
  const raw=this.text.slice(start+1,end);
  if(!raw.includes('\\')&&!/[\x00-\x1f]/.test(raw)){this.at=end+1;return raw;}
  this.at=start+1;while(this.at<this.text.length){if(this.text[this.at]==='"'){this.at++;const v=JSON.parse(this.text.slice(start,this.at));if(!v.isWellFormed())throw Error('invalid JSON Unicode');return v;}if(this.text[this.at]==='\\')this.at+=2;else this.at++;}throw Error('unterminated JSON string');
 }
 number(){const start=this.at;while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(!(c>=48&&c<=57||c===45||c===43||c===46||c===101||c===69))break;this.at++;}const token=this.text.slice(start,this.at);if(!jsonNumberToken(token))throw Error('invalid JSON number');return token;}
 leaf(d){this.node(d);const c=this.peek();if(c==='n'&&this.text.startsWith('null',this.at)){this.at+=4;return null;}if(c==='t'&&this.text.startsWith('true',this.at)){this.at+=4;return true;}if(c==='f'&&this.text.startsWith('false',this.at)){this.at+=5;return false;}if(c==='"')return this.string();if(c==='-'||c>='0'&&c<='9')return this.number();throw Error('invalid JSON scalar');}
 finish(){this.ws();if(this.at!==this.text.length)throw Error('trailing JSON text');}
}
function streamJsonBinary(values,text,options,typed,compact=false){
 const p=new JsonWireReader(text,options),utf8=jsonWireEncoder;
 const list=(w,open,close,item)=>{if(!p.eat(open))throw Error('JSON container shape');const at=w.beginCount();let count=0;if(!p.eat(close))while(true){item(w);count++;if(p.eat(close))break;if(!p.eat(','))throw Error('JSON container separator');}w.endCount(at,count);};
 const variant=(w,index,level,emit)=>{if(level<index)w.frame(w=>{w.byte(1);variant(w,index,level+1,emit);});else if(index<5)w.frame(w=>{w.byte(0);w.frame(emit);});else w.frame(emit);};
 const json=(w,d)=>{
  const ch=p.peek(),index=ch==='n'?0:ch==='t'||ch==='f'?1:ch==='-'||ch>='0'&&ch<='9'?2:ch==='"'?3:ch==='['?4:ch==='{'?5:-1;if(index<0)throw Error('invalid JSON value');
  const leaf=index<4?p.leaf(d):null;if(index>=4)p.node(d);
  w.frame(w=>variant(w,index,0,w=>{
   if(index===0)return;if(index===1){w.frame(w=>w.byte(+leaf));return;}
   if(index===2||index===3){w.frame(w=>w.text(leaf));return;}
   w.frame(w=>{if(index===4)list(w,'[',']',w=>json(w,d+1));else{const seen=new Set();list(w,'{','}',w=>{const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');w.frame(w=>{w.frame(w=>w.text(key));json(w,d+1);});});}});
  }));
 };
 const read=(type,w,d)=>{
  const t=values.resolve(type);w.frame(w=>{
   if(t.kind==='list'||t.kind==='vector'){p.node(d);list(w,'[',']',w=>read(t.element,w,d+1));return;}
   if(t.kind==='record'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON record');const start=w.position,spans=new Array(t.fields.length).fill(null);
    if(!p.eat('}'))while(true){const key=p.string(),i=t.fields.findIndex(f=>f.name===key);if(i<0)throw Error('unknown JSON record field');if(spans[i])throw Error('duplicate JSON record field');if(!p.eat(':'))throw Error('JSON record colon');const at=w.position;read(t.fields[i].type,w,d+1);spans[i]=[at,w.position];if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON record separator');}
    if(spans.some(s=>s===null))throw Error('missing JSON record field');w.reorder(start,spans);return;
   }
   if(t.kind==='option'||t.kind==='result'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON tagged value');const key=p.string();if(!p.eat(':'))throw Error('JSON tag colon');
    if(t.kind==='option'&&key==='None'){if(p.leaf(d+1)!==null)throw Error('JSON None payload');w.byte(0);}
    else{const child=t.kind==='option'&&key==='Some'?t.element:t.kind==='result'&&key==='Ok'?t.ok:t.kind==='result'&&key==='Err'?t.error:null;if(!child)throw Error('invalid JSON tag');w.byte(key==='Ok'?0:1);read(child,w,d+1);}
    if(!p.eat('}'))throw Error('expected exactly one JSON tag');return;
   }
   const ch=p.peek(),v=p.leaf(d),bad=()=>{throw Error('JSON does not match '+t.kind);};
   if(t.kind==='unit'){if(v!==null)bad();return;}
   if(t.kind==='bool'){if(typeof v!=='boolean')bad();w.byte(+v);return;}
   if(['string','id','enum'].includes(t.kind)){if(ch!=='"')bad();w.text(v);return;}
   if(ch!=='-'&&!(ch>='0'&&ch<='9'))bad();
   if(t.kind==='int'){w.text(jsonInteger(v,4096));return;}
   if(t.kind==='f64'){const n=Number(v);if(!Number.isFinite(n))throw Error('JSON f64 overflow');const b=new DataView(new ArrayBuffer(8));b.setFloat64(0,n,true);w.wide(b.getBigUint64(0,true));}
   else if(t.kind==='f32'){jsonFloatScratch.setFloat32(0,Number(v),true);if(!Number.isFinite(jsonFloatScratch.getFloat32(0,true)))throw Error('JSON f32 overflow');w.word(jsonFloatScratch.getUint32(0,true));}
   else{const n=BigInt(jsonInteger(v,t.kind==='u64'?20:10));if(t.kind==='u64'){if(n<0n||n>18446744073709551615n)bad();w.wide(n);}else if(t.kind==='u32'){if(n<0n||n>4294967295n)bad();w.word(Number(n));}else if(t.kind==='i32'){if(n< -2147483648n||n>2147483647n)bad();w.word(Number(n)>>>0);}else bad();}
  });
 };
 return (compact?values.compact():values).encodeWith(w=>{if(typed)read(values.descriptor.root,w,0);else json(w,0);p.finish();},options);
}

// Render validated bytes in a single traversal; only the final text is owned.
function streamWireJsonText(values,bytes,options,library){
 values.validate(bytes,options);const l=checkedJsonLimits(options),parts=[];let size=0,remaining=l.nodes;const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 const emit=s=>{size+=jsonUtf8Length(s);if(size>l.bytes)throw Error('JSON byte limit');parts.push(s);};
 const string=s=>emit(JSON.stringify(s));const node=d=>{if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');};
 const frame=(type,at)=>{const t=values.resolve(type),start=at+4,end=start+dv.getUint32(at,true);return{t,start,end};};
 const json=(type,at,d)=>{
  node(d);let root=frame(type,at),sum=frame(root.t.fields[0].type,root.start),index=0;
  while(index<5){const err=bytes[sum.start];sum=frame(err?sum.t.error:sum.t.ok,sum.start+1);if(!err)break;index++;}
  if(index===0){emit('null');return root.end;}
  const item=frame(sum.t.fields[0].type,sum.start);
  if(index===1)emit(bytes[item.start]?'true':'false');
  else if(index===2){const token=decoder.decode(bytes.subarray(item.start,item.end));if(!jsonNumberToken(token))throw Error('invalid JSON number token');emit(token);}
  else if(index===3)string(decoder.decode(bytes.subarray(item.start,item.end)));
  else{const count=dv.getUint32(item.start,true);let p=item.start+4;emit(index===4?'[':'{');const seen=new Set();for(let i=0;i<count;i++){if(i)emit(',');if(index===4)p=json(item.t.element,p,d+1);else{const member=frame(item.t.element,p),key=frame(member.t.fields[0].type,member.start),name=decoder.decode(bytes.subarray(key.start,key.end));if(seen.has(name))throw Error('duplicate JSON object key');seen.add(name);string(name);emit(':');json(member.t.fields[1].type,key.end,d+1);p=member.end;}}emit(index===4?']':'}');}
  return root.end;
 };
 const typed=(type,at,d)=>{
  node(d);const f=frame(type,at),t=f.t;let p=f.start;
  switch(t.kind){
   case 'unit':emit('null');break;
   case 'bool':emit(bytes[p]?'true':'false');break;
   case 'u32':emit(String(dv.getUint32(p,true)));break;
   case 'u64':emit(String(dv.getBigUint64(p,true)));break;
   case 'i32':emit(String(dv.getInt32(p,true)));break;
   case 'f64':{const n=dv.getFloat64(p,true);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'f32':{const n=dv.getFloat32(p,true);if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'int':emit(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'string':case 'id':case 'enum':string(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'list':case 'vector':{const n=dv.getUint32(p,true);p+=4;emit('[');for(let i=0;i<n;i++){if(i)emit(',');p=typed(t.element,p,d+1);}emit(']');break;}
   case 'record':emit('{');for(let i=0;i<t.fields.length;i++){if(i)emit(',');const field=t.fields[i];string(field.name);emit(':');p=typed(field.type,p,d+1);}emit('}');break;
   case 'option':case 'result':{const tag=bytes[p++],key=t.kind==='option'?(tag?'Some':'None'):tag?'Err':'Ok';emit('{');string(key);emit(':');if(t.kind==='option'&&!tag){node(d+1);emit('null');}else typed(t.kind==='option'?t.element:tag?t.error:t.ok,p,d+1);emit('}');break;}
   default:throw Error('unsupported typed JSON descriptor');
  }return f.end;
 };
 if(library)json(values.descriptor.root,40,0);else typed(values.descriptor.root,40,0);return parts.join('');
}

/** Owned, optional read view of arbitrary JSON. Auxiliary indexes contain member
 * offsets only. Logical order, exact number tokens and missing/null remain intact.
 * This does not transparently replace any compiled Ink action or its state.
 */
export function createJsonLookup(text,{stepEntries=16,minReads=4,maxEntries=4096,maxObjects=64,maxIndexBytes=262144,...limits}={}){
 for(const [v,max]of [[stepEntries,4096],[minReads,1000000],[maxEntries,1000000],[maxObjects,256],[maxIndexBytes,16777216]])if(!Number.isSafeInteger(v)||v<0||v>max)throw Error('JSON index budget');
 let root=parseJson(text,limits),indexes=new Map(),entries=0,indexBytes=0;
 const stats={reads:0,writes:0,scanned_members:0,index_hits:0,built_entries:0,invalidations:0};
 function parts(path){
  if(!Array.isArray(path))throw Error('JSON lookup path');const n=path.length;if(n>128)throw Error('JSON lookup path');
  const owned=[];for(let i=0;i<n;i++){const d=Object.getOwnPropertyDescriptor(path,String(i));if(!d||!Object.hasOwn(d,'value'))throw Error('JSON lookup path');const p=d.value;if(!(typeof p==='string'&&p.isWellFormed()&&p.length<=4096)&&!(Number.isSafeInteger(p)&&p>=0))throw Error('JSON lookup path');owned.push(p);}return owned;
 }
 function variant(value){let p=value.payload,index=0;while(index<5&&Object.hasOwn(p,'Err')){p=p.Err;index++;}return {index,item:(index<5?p.Ok:p).item0};}
 function resolve(document,path,indexed){
  let value=document,budget=stepEntries;
  for(let depth=0;depth<path.length;depth++){
   const part=path[depth],v=variant(value);
   if(typeof part==='number'){
    if(v.index!==4)throw Error('expected JSON array');if(part>=v.item.length)return {found:false};value=v.item[part];continue;
   }
   if(v.index!==5)throw Error('expected JSON object');
   const prefix=path.slice(0,depth),key=JSON.stringify(prefix),overhead=128+prefix.reduce((n,p)=>n+(typeof p==='string'?16+p.length*2:8),0);let idx=indexed?indexes.get(key):null;
   if(indexed&&!idx&&indexes.size<maxObjects&&indexBytes+overhead<=maxIndexBytes){idx={path:prefix,reads:0,cursor:0,keys:new Map(),bytes:overhead};indexes.set(key,idx);indexBytes+=overhead;}
   if(idx){
    idx.reads++;
    if(idx.reads>=minReads)while(budget>0&&idx.cursor<v.item.length&&entries<maxEntries){
     const member=v.item[idx.cursor],bytes=64+member.key.length*2;
     if(indexBytes+bytes>maxIndexBytes)break;
     idx.keys.set(member.key,idx.cursor++);idx.bytes+=bytes;indexBytes+=bytes;entries++;stats.built_entries++;budget--;
    }
    if(idx.keys.has(part)){stats.index_hits++;value=v.item[idx.keys.get(part)].value;continue;}
   }
   let found=false;
   for(let i=idx?.cursor??0;i<v.item.length;i++){if(indexed)stats.scanned_members++;if(v.item[i].key===part){value=v.item[i].value;found=true;break;}}
   if(!found)return {found:false};
  }
  return {found:true,value};
 }
 return {
  lookup(path){stats.reads++;const r=resolve(root,parts(path),true);return r.found?{found:true,value:structuredClone(r.value)}:r;},
  set(path,key,text){
   path=parts(path);if(typeof key!=='string'||!key.isWellFormed())throw Error('JSON object key');
   const replacement=parseJson(text,limits),next=structuredClone(root),r=resolve(next,path,false);
   if(!r.found)throw Error('JSON update path missing');const object=variant(r.value);if(object.index!==5)throw Error('expected JSON object');
   const members=[{key,value:replacement},...object.item.filter(m=>m.key!==key)];
   // Validate the complete resulting document before publishing a write.
   let payload=r.value.payload;for(let i=0;i<5;i++)payload=payload.Err;payload.item0=members;
   stringifyJson(next,limits);root=next;stats.writes++;
   for(const [id,idx]of indexes)if(idx.path.length>=path.length&&path.every((p,i)=>p===idx.path[i])){entries-=idx.keys.size;indexBytes-=idx.bytes;indexes.delete(id);stats.invalidations++;}
  },
  replace(text){const next=parseJson(text,limits);root=next;stats.writes++;stats.invalidations+=indexes.size;indexes.clear();entries=0;indexBytes=0;},
  stringify(){return stringifyJson(root,limits);},
  stats(){return {...stats,index_entries:entries,index_objects:indexes.size,index_bytes:indexBytes};}
 };
}
function __ownedValue5(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__ownedValue6(value.Some,budget,depth+1)};}
function __ownedValue2(value,budget,depth){budget.enter(depth,4);return {["a"]:__ownedValue0(value["a"],budget,depth+1),["b"]:__ownedValue0(value["b"],budget,depth+1)};}
function __ownedValue1(value,budget,depth){budget.enter(depth,4);return {["p"]:__ownedValue2(value["p"],budget,depth+1),["q"]:__ownedValue2(value["q"],budget,depth+1),["r"]:__ownedValue2(value["r"],budget,depth+1),["s"]:__ownedValue2(value["s"],budget,depth+1),["t"]:__ownedValue2(value["t"],budget,depth+1),["u"]:__ownedValue2(value["u"],budget,depth+1)};}
function __ownedValue8(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue0(value["value"],budget,depth+1),["tangent"]:__ownedValue0(value["tangent"],budget,depth+1)};}
function __ownedValue7(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue0(value["value"],budget,depth+1),["tangent_0"]:__ownedValue0(value["tangent_0"],budget,depth+1),["tangent_1"]:__ownedValue0(value["tangent_1"],budget,depth+1),["tangent_2"]:__ownedValue0(value["tangent_2"],budget,depth+1),["tangent_3"]:__ownedValue0(value["tangent_3"],budget,depth+1),["tangent_4"]:__ownedValue0(value["tangent_4"],budget,depth+1),["tangent_5"]:__ownedValue0(value["tangent_5"],budget,depth+1),["tangent_6"]:__ownedValue0(value["tangent_6"],budget,depth+1),["tangent_7"]:__ownedValue0(value["tangent_7"],budget,depth+1),["tangent_8"]:__ownedValue0(value["tangent_8"],budget,depth+1),["tangent_9"]:__ownedValue0(value["tangent_9"],budget,depth+1),["tangent_10"]:__ownedValue0(value["tangent_10"],budget,depth+1),["tangent_11"]:__ownedValue0(value["tangent_11"],budget,depth+1)};}
function __ownedValue3(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue4(value["value"],budget,depth+1),["previous"]:__ownedValue5(value["previous"],budget,depth+1)};}
function __ownedValue0(value,budget,depth){budget.enter(depth,12);return {F64Bits:__dfBits(value).toString()};}
function __ownedValue6(value,budget,depth){return __ownedValue3(value,budget,depth);}
function __ownedValue4(value,budget,depth){budget.enter(depth,8);return value>>>0;}
const __ownedFunctions=Object.freeze(Object.fromEntries([["component",__ownedValue0],["energy",__ownedValue0],["derivatives",__ownedValue1],["direction",__ownedValue0],["twice",__ownedValue0],["selected",__ownedValue2],["branches",__ownedValue2],["looping",__ownedValue2],["strict_unused",__ownedValue0],["strict",__ownedValue0],["history",__ownedValue3],["__ink_differential64_3",__ownedValue7],["__ink_differential64_1",__ownedValue1],["__ink_differential64_23",__ownedValue8],["__ink_differential64_27",__ownedValue8],["__ink_differential64_31",__ownedValue8],["__ink_differential64_20",__ownedValue8],["__ink_differential64_19",__ownedValue0]]));
function __wireValue22(reader){const end=reader.frame();const value=reader.byte()?{Some:__wireValue21(reader)}:{None:null};reader.finish(end);return value;}
function __wireValue9(reader){const end=reader.frame();const value={["__ink_differential64_24"]:__wireValue8(reader),["__ink_differential64_25"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue10(reader){const end=reader.frame();const value={["__ink_differential64_28"]:__wireValue8(reader),["__ink_differential64_29"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue15(reader){const end=reader.frame();const value={["__ink_differential64_32"]:__wireValue8(reader),["__ink_differential64_33"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue7(reader){const end=reader.frame();const value={["a"]:__wireValue8(reader),["b"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue13(reader){const end=reader.frame();const value={["a"]:__wireValue14(reader),["b"]:__wireValue14(reader)};reader.finish(end);return value;}
function __wireValue2(reader){const end=reader.frame();const value={["a"]:__wireValue3(reader),["b"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue6(reader){const end=reader.frame();const value={["p"]:__wireValue7(reader),["q"]:__wireValue7(reader),["r"]:__wireValue7(reader),["s"]:__wireValue7(reader),["t"]:__wireValue7(reader),["u"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue12(reader){const end=reader.frame();const value={["p"]:__wireValue13(reader),["q"]:__wireValue13(reader),["r"]:__wireValue13(reader),["s"]:__wireValue13(reader),["t"]:__wireValue13(reader),["u"]:__wireValue13(reader)};reader.finish(end);return value;}
function __wireValue1(reader){const end=reader.frame();const value={["p"]:__wireValue2(reader),["q"]:__wireValue2(reader),["r"]:__wireValue2(reader),["s"]:__wireValue2(reader),["t"]:__wireValue2(reader),["u"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue8(reader){const end=reader.frame();const value={["value"]:__wireValue3(reader),["tangent"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue14(reader){const end=reader.frame();const value={["value"]:__wireValue3(reader),["tangent_0"]:__wireValue3(reader),["tangent_1"]:__wireValue3(reader),["tangent_2"]:__wireValue3(reader),["tangent_3"]:__wireValue3(reader),["tangent_4"]:__wireValue3(reader),["tangent_5"]:__wireValue3(reader),["tangent_6"]:__wireValue3(reader),["tangent_7"]:__wireValue3(reader),["tangent_8"]:__wireValue3(reader),["tangent_9"]:__wireValue3(reader),["tangent_10"]:__wireValue3(reader),["tangent_11"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue21(reader){const end=reader.frame();const value={["value"]:__wireValue20(reader),["previous"]:__wireValue22(reader)};reader.finish(end);return value;}
function __wireValue24(reader){const end=reader.frame();const value={["w"]:__wireValue2(reader),["c"]:__wireValue17(reader)};reader.finish(end);return value;}
function __wireValue18(reader){const end=reader.frame();const value={["w"]:__wireValue2(reader),["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue26(reader){const end=reader.frame();const value={["w"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue5(reader){const end=reader.frame();const value={["w"]:__wireValue6(reader),["x"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue11(reader){const end=reader.frame();const value={["w"]:__wireValue12(reader),["x"]:__wireValue14(reader)};reader.finish(end);return value;}
function __wireValue4(reader){const end=reader.frame();const value={["w"]:__wireValue1(reader),["__ink_differential64_35"]:__wireValue1(reader),["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue0(reader){const end=reader.frame();const value={["w"]:__wireValue1(reader),["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue16(reader){const end=reader.frame();const value={["x"]:__wireValue3(reader),["c"]:__wireValue17(reader)};reader.finish(end);return value;}
function __wireValue25(reader){const end=reader.frame();const value={["x"]:__wireValue3(reader),["y"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue23(reader){const end=reader.frame();const value={["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue19(reader){const end=reader.frame();const value={["x"]:__wireValue20(reader)};reader.finish(end);return value;}
function __wireValue17(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __wireValue3(reader){const end=reader.frame();const value={F64Bits:reader.wide().toString()};reader.finish(end);return value;}
function __wireValue20(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
const __wireReaders=Object.freeze(Object.fromEntries([["__ink_differential64_1",[__wireValue0,__wireValue1]],["__ink_differential64_19",[__wireValue4,__wireValue3]],["__ink_differential64_20",[__wireValue5,__wireValue8]],["__ink_differential64_23",[__wireValue9,__wireValue8]],["__ink_differential64_27",[__wireValue10,__wireValue8]],["__ink_differential64_3",[__wireValue11,__wireValue14]],["__ink_differential64_31",[__wireValue15,__wireValue8]],["branches",[__wireValue16,__wireValue2]],["component",[__wireValue18,__wireValue3]],["derivatives",[__wireValue0,__wireValue1]],["direction",[__wireValue0,__wireValue3]],["energy",[__wireValue0,__wireValue3]],["history",[__wireValue19,__wireValue21]],["looping",[__wireValue23,__wireValue2]],["selected",[__wireValue24,__wireValue2]],["strict",[__wireValue25,__wireValue3]],["strict_unused",[__wireValue26,__wireValue3]],["twice",[__wireValue26,__wireValue3]]]));
const __ownedImplementations=Object.freeze(Object.fromEntries([["component",(()=>{const c0=__representation(__inputTypes[0].types[0],false,__inputTypes[0].capture[0]);const c1=__representation(__inputTypes[0].types[1],false,__inputTypes[0].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn0;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn0(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn0(v0,v1);};})()],
["energy",(()=>{const c0=__representation(__inputTypes[1].types[0],false,__inputTypes[1].capture[0]);const c1=__representation(__inputTypes[1].types[1],false,__inputTypes[1].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn1;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn1(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn1(v0,v1);};})()],
["derivatives",(()=>{const c0=__representation(__inputTypes[2].types[0],false,__inputTypes[2].capture[0]);const c1=__representation(__inputTypes[2].types[1],false,__inputTypes[2].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn2;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn2(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn2(v0,v1);};})()],
["direction",(()=>{const c0=__representation(__inputTypes[3].types[0],false,__inputTypes[3].capture[0]);const c1=__representation(__inputTypes[3].types[1],false,__inputTypes[3].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn3;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn3(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn3(v0,v1);};})()],
["twice",(()=>{const c0=__representation(__inputTypes[4].types[0],false,__inputTypes[4].capture[0]);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity)return __fn4;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn4(...values);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return __fn4(v0);};})()],
["selected",(()=>{const c0=__representation(__inputTypes[5].types[0],false,__inputTypes[5].capture[0]);const c1=__representation(__inputTypes[5].types[1],false,__inputTypes[5].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn5;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn5(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn5(v0,v1);};})()],
["branches",(()=>{const c0=__representation(__inputTypes[6].types[0],false,__inputTypes[6].capture[0]);const c1=__representation(__inputTypes[6].types[1],false,__inputTypes[6].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=false;if(c0===__identity&&c1===__identity)return __fn6;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn6(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn6(v0,v1);};})()],
["looping",(()=>{const c0=__representation(__inputTypes[7].types[0],false,__inputTypes[7].capture[0]);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=false;if(c0===__identity)return __fn7;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn7(...values);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return __fn7(v0);};})()],
["strict_unused",(()=>{const c0=__representation(__inputTypes[8].types[0],false,__inputTypes[8].capture[0]);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity)return __fn8;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn8(...values);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return __fn8(v0);};})()],
["strict",(()=>{const c0=__representation(__inputTypes[9].types[0],false,__inputTypes[9].capture[0]);const c1=__representation(__inputTypes[9].types[1],false,__inputTypes[9].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=false;if(c0===__identity&&c1===__identity)return __fn9;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn9(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn9(v0,v1);};})()],
["history",(()=>{const c0=__representation(__inputTypes[10].types[0],false,__inputTypes[10].capture[0]);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=false;if(c0===__identity)return __fn10;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn10(...values);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return __fn10(v0);};})()],
["__ink_differential64_3",(()=>{const c0=__representation(__inputTypes[11].types[0],false,__inputTypes[11].capture[0]);const c1=__representation(__inputTypes[11].types[1],false,__inputTypes[11].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity)return __fn11;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn11(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn11(v0,v1);};})()],
["__ink_differential64_1",(()=>{const c0=__representation(__inputTypes[12].types[0],false,__inputTypes[12].capture[0]);const c1=__representation(__inputTypes[12].types[1],false,__inputTypes[12].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn12;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn12(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn12(v0,v1);};})()],
["__ink_differential64_23",(()=>{const c0=__representation(__inputTypes[13].types[0],false,__inputTypes[13].capture[0]);const c1=__representation(__inputTypes[13].types[1],false,__inputTypes[13].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity)return __fn13;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn13(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn13(v0,v1);};})()],
["__ink_differential64_27",(()=>{const c0=__representation(__inputTypes[14].types[0],false,__inputTypes[14].capture[0]);const c1=__representation(__inputTypes[14].types[1],false,__inputTypes[14].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity)return __fn14;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn14(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn14(v0,v1);};})()],
["__ink_differential64_31",(()=>{const c0=__representation(__inputTypes[15].types[0],false,__inputTypes[15].capture[0]);const c1=__representation(__inputTypes[15].types[1],false,__inputTypes[15].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity)return __fn15;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn15(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn15(v0,v1);};})()],
["__ink_differential64_20",(()=>{const c0=__representation(__inputTypes[16].types[0],false,__inputTypes[16].capture[0]);const c1=__representation(__inputTypes[16].types[1],false,__inputTypes[16].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity)return __fn16;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn16(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn16(v0,v1);};})()],
["__ink_differential64_19",(()=>{const c0=__representation(__inputTypes[17].types[0],false,__inputTypes[17].capture[0]);const c1=__representation(__inputTypes[17].types[1],false,__inputTypes[17].capture[1]);const c2=__representation(__inputTypes[17].types[2],false,__inputTypes[17].capture[2]);const input=[c0,c1,c2],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity&&c2===__identity)return __fn17;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn17(...values);};return function(a0,a1,a2){if(arguments.length!==3)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object')+Number(c2!==__identity&&a2!==null&&typeof a2==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);const v2=c2(a2,context);return __fn17(v0,v1,v2);};})()]]));

export const valueCodecs=(()=>{const codecs={};for(const [name,s] of Object.entries(metadata.wire.functions)){if(s.unsupported)continue;let value;Object.defineProperty(codecs,name,{enumerable:true,get:()=>value??=(Object.freeze(Object.hasOwn(__wireReaders,name)?{arguments:createCompiledValueCodec(s.arguments,__wireReaders[name][0]),result:createCompiledValueCodec(s.result,__wireReaders[name][1])}:{arguments:new ValueCodec(s.arguments),result:new ValueCodec(s.result)}))});}return Object.freeze(codecs);})();
function __callEncoded(name,bytes,limits,compact){
 const f=metadata.functions.find(f=>f.name===name&&!f.internal),codecs=valueCodecs[name];
 if(!f||!codecs)throw Error('unsupported binary function');
 const input=compact?codecs.arguments.compact():codecs.arguments,output=compact?codecs.result.compact():codecs.result;
 const entry=__compiledEntries.get(name);
 if(entry){
  const slot=compact?1:0;
  entry.argumentCodecs[slot]??=(entry.boundaryReaders[slot]?createFusedValueCodec:createCompiledValueCodec)(metadata.wire.functions[name].arguments,entry.arguments);
  const decoder=entry.argumentCodecs[slot];
  const values=(compact?decoder.compact():decoder).decode(bytes,limits),args=f.params.map(p=>values[p.name]);
  if(entry.precondition!==null&&__implementations[entry.precondition](...args)!==true)throw Error('contract precondition failed');
  return __compiledEncodeResult(entry,__implementations[entry.index](...args),limits,compact);
 }
 const values=input.decode(bytes,limits);
 const result=call(name,f.params.map(p=>values[p.name]));
 return output.encode(result,limits);
}
export function callBinary(name,bytes,limits={}){return __callEncoded(name,bytes,limits,false);}
export function callCompact(name,bytes,limits={}){return __callEncoded(name,bytes,limits,true);}
// Same stable, well-typed caller inputs as call; the result owns every container.
// The checked source return type justifies trusted copying, not arbitrary input.
export function callOwned(name,args,limits={}){
 if(!Object.hasOwn(__ownedFunctions,name)||!Object.hasOwn(functions,name))throw Error('unsupported owned function');
 const result=__ownedImplementations[name](...args);return __ownedFunctions[name](result,createValueCaptureBudget(limits),0);
}
function __privateCapture6(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if((value!==null&&typeof value==='object'&&Object.hasOwn(value,'None')&&Object.keys(value).length===1)&&value.None===null)return {None:null};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Some')&&Object.keys(value).length===1)return {Some:__privateCapture5(value.Some,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture12(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture10(value["a"],budget,depth+1),["b"]:__privateCapture10(value["b"],budget,depth+1)};}
function __privateCapture8(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture9(value["a"],budget,depth+1),["b"]:__privateCapture9(value["b"],budget,depth+1)};}
function __privateCapture0(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture1(value["a"],budget,depth+1),["b"]:__privateCapture1(value["b"],budget,depth+1)};}
function __privateCapture11(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"p")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"q")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"r")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"s")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"t")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"u")){throw Error('invalid value for wire schema');}return {["p"]:__privateCapture12(value["p"],budget,depth+1),["q"]:__privateCapture12(value["q"],budget,depth+1),["r"]:__privateCapture12(value["r"],budget,depth+1),["s"]:__privateCapture12(value["s"],budget,depth+1),["t"]:__privateCapture12(value["t"],budget,depth+1),["u"]:__privateCapture12(value["u"],budget,depth+1)};}
function __privateCapture7(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"p")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"q")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"r")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"s")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"t")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"u")){throw Error('invalid value for wire schema');}return {["p"]:__privateCapture8(value["p"],budget,depth+1),["q"]:__privateCapture8(value["q"],budget,depth+1),["r"]:__privateCapture8(value["r"],budget,depth+1),["s"]:__privateCapture8(value["s"],budget,depth+1),["t"]:__privateCapture8(value["t"],budget,depth+1),["u"]:__privateCapture8(value["u"],budget,depth+1)};}
function __privateCapture2(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"p")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"q")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"r")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"s")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"t")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"u")){throw Error('invalid value for wire schema');}return {["p"]:__privateCapture0(value["p"],budget,depth+1),["q"]:__privateCapture0(value["q"],budget,depth+1),["r"]:__privateCapture0(value["r"],budget,depth+1),["s"]:__privateCapture0(value["s"],budget,depth+1),["t"]:__privateCapture0(value["t"],budget,depth+1),["u"]:__privateCapture0(value["u"],budget,depth+1)};}
function __privateCapture10(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["tangent"]:__privateCapture1(value["tangent"],budget,depth+1)};}
function __privateCapture9(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==13){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_0")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_1")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_2")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_3")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_4")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_5")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_6")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_7")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_8")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_9")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_10")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_11")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["tangent_0"]:__privateCapture1(value["tangent_0"],budget,depth+1),["tangent_1"]:__privateCapture1(value["tangent_1"],budget,depth+1),["tangent_2"]:__privateCapture1(value["tangent_2"],budget,depth+1),["tangent_3"]:__privateCapture1(value["tangent_3"],budget,depth+1),["tangent_4"]:__privateCapture1(value["tangent_4"],budget,depth+1),["tangent_5"]:__privateCapture1(value["tangent_5"],budget,depth+1),["tangent_6"]:__privateCapture1(value["tangent_6"],budget,depth+1),["tangent_7"]:__privateCapture1(value["tangent_7"],budget,depth+1),["tangent_8"]:__privateCapture1(value["tangent_8"],budget,depth+1),["tangent_9"]:__privateCapture1(value["tangent_9"],budget,depth+1),["tangent_10"]:__privateCapture1(value["tangent_10"],budget,depth+1),["tangent_11"]:__privateCapture1(value["tangent_11"],budget,depth+1)};}
function __privateCapture5(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"previous")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture4(value["value"],budget,depth+1),["previous"]:__privateCapture6(value["previous"],budget,depth+1)};}
function __privateCapture3(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='boolean'){throw Error('invalid value for wire schema');}budget.add(1);return value;}
function __privateCapture1(value,budget,depth=0){budget.enter(depth,4);const result=__dfCapture(value);budget.add(8);return result;}
function __privateCapture4(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='number'||!Number.isInteger(value)||value<0||value>4294967295){throw Error('invalid value for wire schema');}budget.add(4);return value===0?0:value;}
function __privateWireValue13(reader){const end=reader.frame();const value=reader.byte()?{Some:__privateWireValue12(reader)}:{None:null};reader.finish(end);return value;}
function __privateWireValue20(reader){const end=reader.frame();const value={["__ink_differential64_24"]:__privateWireValue19(reader),["__ink_differential64_25"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue21(reader){const end=reader.frame();const value={["__ink_differential64_28"]:__privateWireValue19(reader),["__ink_differential64_29"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue22(reader){const end=reader.frame();const value={["__ink_differential64_32"]:__privateWireValue19(reader),["__ink_differential64_33"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue24(reader){const end=reader.frame();const value={["a"]:__privateWireValue19(reader),["b"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue16(reader){const end=reader.frame();const value={["a"]:__privateWireValue17(reader),["b"]:__privateWireValue17(reader)};reader.finish(end);return value;}
function __privateWireValue0(reader){const end=reader.frame();const value={["a"]:__privateWireValue1(reader),["b"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue23(reader){const end=reader.frame();const value={["p"]:__privateWireValue24(reader),["q"]:__privateWireValue24(reader),["r"]:__privateWireValue24(reader),["s"]:__privateWireValue24(reader),["t"]:__privateWireValue24(reader),["u"]:__privateWireValue24(reader)};reader.finish(end);return value;}
function __privateWireValue15(reader){const end=reader.frame();const value={["p"]:__privateWireValue16(reader),["q"]:__privateWireValue16(reader),["r"]:__privateWireValue16(reader),["s"]:__privateWireValue16(reader),["t"]:__privateWireValue16(reader),["u"]:__privateWireValue16(reader)};reader.finish(end);return value;}
function __privateWireValue3(reader){const end=reader.frame();const value={["p"]:__privateWireValue0(reader),["q"]:__privateWireValue0(reader),["r"]:__privateWireValue0(reader),["s"]:__privateWireValue0(reader),["t"]:__privateWireValue0(reader),["u"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue19(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["tangent"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue17(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["tangent_0"]:__privateWireValue1(reader),["tangent_1"]:__privateWireValue1(reader),["tangent_2"]:__privateWireValue1(reader),["tangent_3"]:__privateWireValue1(reader),["tangent_4"]:__privateWireValue1(reader),["tangent_5"]:__privateWireValue1(reader),["tangent_6"]:__privateWireValue1(reader),["tangent_7"]:__privateWireValue1(reader),["tangent_8"]:__privateWireValue1(reader),["tangent_9"]:__privateWireValue1(reader),["tangent_10"]:__privateWireValue1(reader),["tangent_11"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue12(reader){const end=reader.frame();const value={["value"]:__privateWireValue11(reader),["previous"]:__privateWireValue13(reader)};reader.finish(end);return value;}
function __privateWireValue7(reader){const end=reader.frame();const value={["w"]:__privateWireValue0(reader),["c"]:__privateWireValue6(reader)};reader.finish(end);return value;}
function __privateWireValue2(reader){const end=reader.frame();const value={["w"]:__privateWireValue0(reader),["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue5(reader){const end=reader.frame();const value={["w"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue25(reader){const end=reader.frame();const value={["w"]:__privateWireValue23(reader),["x"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue18(reader){const end=reader.frame();const value={["w"]:__privateWireValue15(reader),["x"]:__privateWireValue17(reader)};reader.finish(end);return value;}
function __privateWireValue26(reader){const end=reader.frame();const value={["w"]:__privateWireValue3(reader),["__ink_differential64_35"]:__privateWireValue3(reader),["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue4(reader){const end=reader.frame();const value={["w"]:__privateWireValue3(reader),["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue8(reader){const end=reader.frame();const value={["x"]:__privateWireValue1(reader),["c"]:__privateWireValue6(reader)};reader.finish(end);return value;}
function __privateWireValue10(reader){const end=reader.frame();const value={["x"]:__privateWireValue1(reader),["y"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue9(reader){const end=reader.frame();const value={["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue14(reader){const end=reader.frame();const value={["x"]:__privateWireValue11(reader)};reader.finish(end);return value;}
function __privateWireValue6(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __privateWireValue1(reader){const end=reader.frame();const value=__dfFromBits(reader.wide());reader.finish(end);return value;}
function __privateWireValue11(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __compiledOwnedValue6(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__compiledOwnedValue7(value.Some,budget,depth+1)};}
function __compiledOwnedValue13(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue11(value["a"],budget,depth+1),["b"]:__compiledOwnedValue11(value["b"],budget,depth+1)};}
function __compiledOwnedValue9(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue10(value["a"],budget,depth+1),["b"]:__compiledOwnedValue10(value["b"],budget,depth+1)};}
function __compiledOwnedValue0(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue1(value["a"],budget,depth+1),["b"]:__compiledOwnedValue1(value["b"],budget,depth+1)};}
function __compiledOwnedValue12(value,budget,depth){budget.enter(depth,4);return {["p"]:__compiledOwnedValue13(value["p"],budget,depth+1),["q"]:__compiledOwnedValue13(value["q"],budget,depth+1),["r"]:__compiledOwnedValue13(value["r"],budget,depth+1),["s"]:__compiledOwnedValue13(value["s"],budget,depth+1),["t"]:__compiledOwnedValue13(value["t"],budget,depth+1),["u"]:__compiledOwnedValue13(value["u"],budget,depth+1)};}
function __compiledOwnedValue8(value,budget,depth){budget.enter(depth,4);return {["p"]:__compiledOwnedValue9(value["p"],budget,depth+1),["q"]:__compiledOwnedValue9(value["q"],budget,depth+1),["r"]:__compiledOwnedValue9(value["r"],budget,depth+1),["s"]:__compiledOwnedValue9(value["s"],budget,depth+1),["t"]:__compiledOwnedValue9(value["t"],budget,depth+1),["u"]:__compiledOwnedValue9(value["u"],budget,depth+1)};}
function __compiledOwnedValue2(value,budget,depth){budget.enter(depth,4);return {["p"]:__compiledOwnedValue0(value["p"],budget,depth+1),["q"]:__compiledOwnedValue0(value["q"],budget,depth+1),["r"]:__compiledOwnedValue0(value["r"],budget,depth+1),["s"]:__compiledOwnedValue0(value["s"],budget,depth+1),["t"]:__compiledOwnedValue0(value["t"],budget,depth+1),["u"]:__compiledOwnedValue0(value["u"],budget,depth+1)};}
function __compiledOwnedValue11(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["tangent"]:__compiledOwnedValue1(value["tangent"],budget,depth+1)};}
function __compiledOwnedValue10(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["tangent_0"]:__compiledOwnedValue1(value["tangent_0"],budget,depth+1),["tangent_1"]:__compiledOwnedValue1(value["tangent_1"],budget,depth+1),["tangent_2"]:__compiledOwnedValue1(value["tangent_2"],budget,depth+1),["tangent_3"]:__compiledOwnedValue1(value["tangent_3"],budget,depth+1),["tangent_4"]:__compiledOwnedValue1(value["tangent_4"],budget,depth+1),["tangent_5"]:__compiledOwnedValue1(value["tangent_5"],budget,depth+1),["tangent_6"]:__compiledOwnedValue1(value["tangent_6"],budget,depth+1),["tangent_7"]:__compiledOwnedValue1(value["tangent_7"],budget,depth+1),["tangent_8"]:__compiledOwnedValue1(value["tangent_8"],budget,depth+1),["tangent_9"]:__compiledOwnedValue1(value["tangent_9"],budget,depth+1),["tangent_10"]:__compiledOwnedValue1(value["tangent_10"],budget,depth+1),["tangent_11"]:__compiledOwnedValue1(value["tangent_11"],budget,depth+1)};}
function __compiledOwnedValue5(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue4(value["value"],budget,depth+1),["previous"]:__compiledOwnedValue6(value["previous"],budget,depth+1)};}
function __compiledOwnedValue3(value,budget,depth){budget.enter(depth,5);return value;}
function __compiledOwnedValue1(value,budget,depth){budget.enter(depth,12);return {F64Bits:__dfBits(value).toString()};}
function __compiledOwnedValue7(value,budget,depth){return __compiledOwnedValue5(value,budget,depth);}
function __compiledOwnedValue4(value,budget,depth){budget.enter(depth,8);return value>>>0;}
function __privateWireWrite6(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Some')){writer.byte(1);__privateWireWrite5(writer,value.Some,compact);}else{writer.byte(0);}writer.closeFrame(frame);}
function __privateWireWrite12(writer,value,compact){const frame=writer.openFrame();__privateWireWrite10(writer,value["a"],compact);__privateWireWrite10(writer,value["b"],compact);writer.closeFrame(frame);}
function __privateWireWrite8(writer,value,compact){const frame=writer.openFrame();__privateWireWrite9(writer,value["a"],compact);__privateWireWrite9(writer,value["b"],compact);writer.closeFrame(frame);}
function __privateWireWrite0(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["a"],compact);__privateWireWrite1(writer,value["b"],compact);writer.closeFrame(frame);}
function __privateWireWrite11(writer,value,compact){const frame=writer.openFrame();__privateWireWrite12(writer,value["p"],compact);__privateWireWrite12(writer,value["q"],compact);__privateWireWrite12(writer,value["r"],compact);__privateWireWrite12(writer,value["s"],compact);__privateWireWrite12(writer,value["t"],compact);__privateWireWrite12(writer,value["u"],compact);writer.closeFrame(frame);}
function __privateWireWrite7(writer,value,compact){const frame=writer.openFrame();__privateWireWrite8(writer,value["p"],compact);__privateWireWrite8(writer,value["q"],compact);__privateWireWrite8(writer,value["r"],compact);__privateWireWrite8(writer,value["s"],compact);__privateWireWrite8(writer,value["t"],compact);__privateWireWrite8(writer,value["u"],compact);writer.closeFrame(frame);}
function __privateWireWrite2(writer,value,compact){const frame=writer.openFrame();__privateWireWrite0(writer,value["p"],compact);__privateWireWrite0(writer,value["q"],compact);__privateWireWrite0(writer,value["r"],compact);__privateWireWrite0(writer,value["s"],compact);__privateWireWrite0(writer,value["t"],compact);__privateWireWrite0(writer,value["u"],compact);writer.closeFrame(frame);}
function __privateWireWrite10(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite1(writer,value["tangent"],compact);writer.closeFrame(frame);}
function __privateWireWrite9(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite1(writer,value["tangent_0"],compact);__privateWireWrite1(writer,value["tangent_1"],compact);__privateWireWrite1(writer,value["tangent_2"],compact);__privateWireWrite1(writer,value["tangent_3"],compact);__privateWireWrite1(writer,value["tangent_4"],compact);__privateWireWrite1(writer,value["tangent_5"],compact);__privateWireWrite1(writer,value["tangent_6"],compact);__privateWireWrite1(writer,value["tangent_7"],compact);__privateWireWrite1(writer,value["tangent_8"],compact);__privateWireWrite1(writer,value["tangent_9"],compact);__privateWireWrite1(writer,value["tangent_10"],compact);__privateWireWrite1(writer,value["tangent_11"],compact);writer.closeFrame(frame);}
function __privateWireWrite5(writer,value,compact){const frame=writer.openFrame();__privateWireWrite4(writer,value["value"],compact);__privateWireWrite6(writer,value["previous"],compact);writer.closeFrame(frame);}
function __privateWireWrite3(writer,value,compact){const frame=writer.openFrame();writer.byte(value?1:0);writer.closeFrame(frame);}
function __privateWireWrite1(writer,value,compact){const frame=writer.openFrame();writer.wide(__dfBits(value));writer.closeFrame(frame);}
function __privateWireWrite4(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
// Handles have no mutable private payload surface. Membership and type identity
// are checked by this module's closure; copied/foreign objects cannot forge them.
const __compiledHandles=new WeakMap();
const __compiledBindings=new WeakMap();
function __compiledHandle(identity,value,guaranteed=false){
 const handle=Object.freeze(Object.create(null));
 __compiledHandles.set(handle,{identity,value,guaranteed});return handle;
}
function __compiledEntry(handle,identity){
 const entry=__compiledHandles.get(handle);
 if(!entry||entry.identity!==identity)throw Error('compiled value type or owner mismatch');
 return entry;
}
function __compiledUnwrap(handle,identity){return __compiledEntry(handle,identity).value;}
// Emit the portable schema's framing/scalar events without creating a buffer
// or exposing private composite nodes. Only this wrapper receives callbacks
// from the literal writer; host visitors never receive those closures.
function __compiledValueEvents(sink,limits){
 const methods=['begin','end','byte','word','wide','text','count'];
 for(const name of methods)if(typeof sink?.[name]!=='function')throw Error('compiled value visitor method: '+name);
 const budget=createValueCaptureBudget(limits);let depth=0,closed=false;
 const active=()=>{if(closed)throw Error('compiled value visitor is closed');};
 const writer=Object.freeze({
  openFrame(){active();budget.enter(depth,4);depth++;sink.begin();return 0;}
  ,closeFrame(){active();if(depth===0)throw Error('wire frame boundary');try{sink.end();}finally{depth--;}}
  ,frame(emit){active();budget.enter(depth,4);depth++;sink.begin();try{emit();sink.end();}finally{depth--;}}
  ,byte(value){active();budget.add(1);sink.byte(value);}
  ,word(value){active();budget.add(4);sink.word(value);}
  ,wide(value){active();budget.add(8);sink.wide(value);}
  ,text(value){active();budget.text(value);sink.text(value);}
  ,count(value){active();budget.add(4);if(value>budget.remaining)throw Error('wire sequence size');sink.count(value);}
 });
 return {writer,close(){closed=true;}};
}
function __compiledReduction(factory,root,reduce,identity){
 if(typeof factory!=='function')throw Error('compiled reduction factory');
 const reducers=[],seen=new Set(),nodes=__reductionNodes();
 const prepare=index=>{
  if(seen.has(index))return;seen.add(index);
  const node=nodes[index];
  for(const child of node.children)prepare(child);
  const reducer=factory(node,index);
  if(node.kind==='list'||node.kind==='vector'){
   const start=reducer?.start,step=reducer?.step,finish=reducer?.finish;
   if(typeof start!=='function'||typeof step!=='function'||typeof finish!=='function')throw Error('compiled collection reduction');
   reducers[index]=Object.freeze({start,step,finish});
  }else{
   if(typeof reducer!=='function')throw Error('compiled value reduction');
   reducers[index]=reducer;
  }
 };
 prepare(root);Object.freeze(reducers);
 return Object.freeze(function(handle,context,limits={}){
  const value=__compiledUnwrap(handle,identity),budget=createValueCaptureBudget(limits);
  return reduce(value,reducers,budget,0,context);
 });
}
function __compiledCodec(schema,capture,read,write,copy,constructorRoot,reductionRoot,reduce,portableFused=false,compactFused=false){
 const privateCodec=createCompiledValueCodec(schema,read),publicCodec=privateCodec;
 let fusedCodec;const fused=()=>fusedCodec??=createFusedValueCodec(schema,read);
 const identity=schema.identity;
 const codec=Object.freeze({
  identity,
  descriptor:publicCodec.descriptor,
  resolve(type){return publicCodec.resolve(type);},
  capture(value,limits={}){
   return __compiledHandle(identity,capture(value,createValueCaptureBudget(limits),0));
  },
  decode(bytes,limits={}){return __compiledHandle(identity,(portableFused?fused():privateCodec).decode(bytes,limits));},
  decodeCompact(bytes,limits={}){return __compiledHandle(identity,(compactFused?fused():privateCodec).compact().decode(bytes,limits));},
  decodeFused(bytes,limits={}){return __compiledHandle(identity,fused().decode(bytes,limits));},
  decodeCompactFused(bytes,limits={}){return __compiledHandle(identity,fused().compact().decode(bytes,limits));},
  encode(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.encodeWith(writer=>write(writer,value,false),limits);},
  encodeCompact(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.compact().encodeWith(writer=>write(writer,value,true),limits);},
  materialize(handle,limits={}){return copy(__compiledUnwrap(handle,identity),createValueCaptureBudget(limits),0);},
  builder(limits={}){return __valueBuilder(__constructorNodes(),constructorRoot,identity,limits);},
  reducer(factory){return __compiledReduction(factory,reductionRoot,reduce,identity);},
  visit(handle,sink,limits={}){
   const value=__compiledUnwrap(handle,identity),events=__compiledValueEvents(sink,limits);
   try{write(events.writer,value,false);}finally{events.close();}
  },
 });
 __compiledBindings.set(codec,{publicCodec,write,capture});return codec;
}

function __compiledEncodeResult(entry,value,limits,compact){
 const {publicCodec,write}=__compiledBindings.get(entry.result());
 return (compact?publicCodec.compact():publicCodec).encodeWith(writer=>write(writer,value,compact),limits);
}
let __constructorNodesValue;function __constructorNodes(){return __constructorNodesValue??=[{kind:'record',fields:["a","b"],patterns:[{bytes:4,label:"record",children:[1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1]})}]},{kind:"f64",scalar:__privateCapture1},{kind:'record',fields:["p","q","r","s","t","u"],patterns:[{bytes:4,label:"record",children:[0,0,0,0,0,0],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["p"]:values[0],["q"]:values[1],["r"]:values[2],["s"]:values[3],["t"]:values[4],["u"]:values[5]})}]},{kind:"bool",scalar:__privateCapture3},{kind:"u32",scalar:__privateCapture4},{kind:'record',fields:["value","previous"],patterns:[{bytes:4,label:"record",children:[4,6],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["previous"]:values[1]})}]},{kind:'option',patterns:[{bytes:5,label:"None",children:[],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({None:null})},{bytes:5,label:"Some",children:[5],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({Some:values[0]})}]},{kind:'record',fields:["p","q","r","s","t","u"],patterns:[{bytes:4,label:"record",children:[8,8,8,8,8,8],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["p"]:values[0],["q"]:values[1],["r"]:values[2],["s"]:values[3],["t"]:values[4],["u"]:values[5]})}]},{kind:'record',fields:["a","b"],patterns:[{bytes:4,label:"record",children:[9,9],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1]})}]},{kind:'record',fields:["value","tangent_0","tangent_1","tangent_2","tangent_3","tangent_4","tangent_5","tangent_6","tangent_7","tangent_8","tangent_9","tangent_10","tangent_11"],patterns:[{bytes:4,label:"record",children:[1,1,1,1,1,1,1,1,1,1,1,1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["tangent_0"]:values[1],["tangent_1"]:values[2],["tangent_2"]:values[3],["tangent_3"]:values[4],["tangent_4"]:values[5],["tangent_5"]:values[6],["tangent_6"]:values[7],["tangent_7"]:values[8],["tangent_8"]:values[9],["tangent_9"]:values[10],["tangent_10"]:values[11],["tangent_11"]:values[12]})}]},{kind:'record',fields:["value","tangent"],patterns:[{bytes:4,label:"record",children:[1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["tangent"]:values[1]})}]},{kind:'record',fields:["p","q","r","s","t","u"],patterns:[{bytes:4,label:"record",children:[12,12,12,12,12,12],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["p"]:values[0],["q"]:values[1],["r"]:values[2],["s"]:values[3],["t"]:values[4],["u"]:values[5]})}]},{kind:'record',fields:["a","b"],patterns:[{bytes:4,label:"record",children:[10,10],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1]})}]}];}
// Typed input construction only: plans contain literal constructor/capture
// functions emitted from source schemas. No source expression evaluator.
// All frames and private values remain in this closure; callers receive only
// an owned opaque handle after one complete, well-typed root is constructed.
const __constructorPaths=new WeakMap();
function __valueBuilder(nodes,root,identity,limits){
 const budget=createValueCaptureBudget(limits),frames=[];
 let result,targetNode,targetDepth,complete=false,closed=false,failed=false,busy=false;
 const fail=message=>{failed=true;frames.length=0;result=undefined;throw Error(message);};
 const active=()=>{if(failed||closed)throw Error('value builder is closed');};
 const expected=()=>{
  if(!frames.length){if(complete)fail('value builder root already complete');targetNode=root;targetDepth=0;return;}
  const frame=frames.at(-1),position=frame.values.length;
  if(!frame.pattern.sequence&&position>=frame.pattern.children.length)fail('value builder constructor is full');
  targetNode=frame.pattern.sequence?frame.pattern.children[0]:frame.pattern.children[position];targetDepth=frame.depth+frame.pattern.childDepth;
 };
 const accept=value=>{
  if(frames.length)frames.at(-1).values.push(value);
  else{result=value;complete=true;}
 };
 const execute=(operation,first,second)=>{
  active();if(busy)throw Error('value builder operation already active');busy=true;
  try{return operation(first,second);}catch(error){failed=true;frames.length=0;result=undefined;throw error;}finally{busy=false;}
 };
 // Compile and cache constructor paths independently of the session's values.
 const pathPlan=(choices,startNode,startDepth)=>{
   if(!Array.isArray(choices)||choices.length===0||choices.length>128)fail('invalid value builder path');
   let cache=__constructorPaths.get(nodes);if(!cache){cache=new WeakMap();__constructorPaths.set(nodes,cache);}
   let entries=cache.get(choices),saved=entries?.get(startNode);
   if(saved)return saved;
   const path=[],charges=[];let node=startNode,depth=startDepth;
   for(let i=0;i<choices.length;i++){
    const choice=choices[i],patterns=nodes[node].patterns;
    if(!Number.isSafeInteger(choice)||choice<0||!patterns||choice>=patterns.length)fail('invalid value builder constructor');
    const pattern=patterns[choice];charges.push([pattern,depth-startDepth]);path.push({pattern,node:nodes[node]});
    if(i+1<choices.length){if(pattern.sequence||pattern.children.length!==1)fail('value builder path is not unary');node=pattern.children[0];depth+=pattern.childDepth;}
   }
   const terminal=path.at(-1).pattern;
   // Compose literal constructor functions once per path, instead of
   // allocating and interpreting another recursive closure for every value.
   const compose=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=args=>args[0];
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=args=>p.make([inner(args)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?compose(last+1):args=>args[0]):compose(last);
     return args=>node.flat(index,payload(args));
    }
    const inner=at+1<path.length?compose(at+1):null;
    if(pattern.transparent)return inner??(args=>args[0]);
    return inner?args=>pattern.make([inner(args)]):pattern.make;
   };
   const make=compose(0);
   // Scalar paths use the same literal constructors, but pass the leaf
   // directly through erased records and flat sums. No temporary argument
   // array is needed at those edges. Ordinary constructors keep their array
   // calling convention; no private value reaches the public builder API.
   const composeScalar=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=value=>value;
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=value=>p.make([inner(value)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?composeScalar(last+1):value=>value):composeScalar(last);
     return value=>node.flat(index,payload(value));
    }
    const inner=at+1<path.length?composeScalar(at+1):null;
    if(pattern.transparent)return inner??(value=>value);
    return inner?value=>pattern.make([inner(value)]):value=>pattern.make([value]);
   };
   const scalar=composeScalar(0);
   const pattern={...terminal,make};
   // Only frozen arrays of ordinary data properties can key reusable plans.
   // Mutable arrays and frozen accessor arrays retain checked per-call paths.
   const fixed=charges.every(([p])=>Number.isSafeInteger(p.bytes)&&p.bytes>=4);
   const plan={pattern,scalar,charges,offset:depth-startDepth,bytes:fixed?charges.reduce((n,[p])=>n+p.bytes,0):null};
   let reusable=Object.isFrozen(choices);
   for(let i=0;reusable&&i<choices.length;i++){const field=Object.getOwnPropertyDescriptor(choices,String(i));reusable=!!field&&Object.hasOwn(field,'value');}
   if(reusable){
    if(!entries){entries=new Map();cache.set(choices,entries);}entries.set(startNode,plan);
   }
   return plan;
 };
 const chargePath=(plan,depth)=>{
  // Each emitted constructor consumes one node and a fixed frame/tag cost.
  // Only take the combined charge when every original check would succeed.
  // Replaying the original order retains the exact first failure otherwise.
  if(plan.bytes!==null&&depth+plan.offset<=budget.depth&&plan.charges.length<=budget.remaining&&budget.bytes+plan.bytes<=budget.limit){
   budget.remaining-=plan.charges.length;budget.bytes+=plan.bytes;return;
  }
  for(const [pattern,offset]of plan.charges)pattern.charge(budget,depth+offset);
 };
 // Operations are allocated once per session, and share expected-node
 // scratch only while the existing reentrancy guard is held.
 const openOperation=(choice)=>{
   expected();const node=nodes[targetNode];
   if(!Number.isSafeInteger(choice)||choice<0||!node.patterns||choice>=node.patterns.length)fail('invalid value builder constructor');
   const pattern=node.patterns[choice];pattern.charge(budget,targetDepth);
   frames.push({pattern,depth:targetDepth,values:[]});
 };
 const openPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth);
   chargePath(plan,targetDepth);
   frames.push({pattern:plan.pattern,depth:targetDepth+plan.offset,values:[]});
 };
 const scalarPathOperation=(choices,value)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==1)fail('value builder path has no scalar leaf');
   const capture=nodes[pattern.children[0]].scalar;
   if(typeof capture!=='function')fail('value builder path has no scalar leaf');
   chargePath(plan,targetDepth);
   const leaf=capture(value,budget,targetDepth+plan.offset+pattern.childDepth);
   accept(plan.scalar(leaf));
 };
 const emptyPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==0)fail('value builder path is not empty');
   chargePath(plan,targetDepth);accept(pattern.make([]));
 };
 const scalarOperation=(value)=>{
   expected();const capture=nodes[targetNode].scalar;
   if(typeof capture!=='function')fail('value builder expects a constructor');
   accept(capture(value,budget,targetDepth));
 };
 const closeOperation=()=>{
   if(!frames.length)fail('value builder has no open constructor');
   const frame=frames.at(-1),pattern=frame.pattern,count=frame.values.length;
   if(!pattern.sequence&&count!==pattern.children.length||pattern.size!==undefined&&count!==pattern.size)fail('value builder constructor arity');
   if(pattern.sequence&&count>budget.limit)fail('wire sequence size');
   const value=pattern.make(frame.values);
   frames.pop();accept(value);
 };
 const finishOperation=()=>{
   if(frames.length||!complete)fail('value builder root is incomplete');
   closed=true;const handle=__compiledHandle(identity,result);result=undefined;return handle;
 };
 const api=Object.freeze({
  open(choice){return execute(openOperation,choice);},
  // Charge every source constructor even when unary paths share one frame.
  openPath(choices){return execute(openPathOperation,choices);},
  // Complete the path and leaf without intermediate session frames.
  scalarPath(choices,value){return execute(scalarPathOperation,choices,value);},
  emptyPath(choices){return execute(emptyPathOperation,choices);},
  scalar(value){return execute(scalarOperation,value);},
  close(){return execute(closeOperation);},
  finish(){return execute(finishOperation);},
  abort(){if(busy)throw Error('value builder operation already active');failed=true;frames.length=0;result=undefined;},
 });
 return api;
}
function __reduceValue0(value,r,b,d,c){b.enter(d,4);return r[0](__reduceValue1(value["a"],r,b,d+1,c),__reduceValue1(value["b"],r,b,d+1,c),c);}
function __reduceValue1(value,r,b,d,c){b.enter(d,12);return r[1]({F64Bits:__dfBits(value).toString()},c);}
function __reduceValue2(value,r,b,d,c){b.enter(d,4);return r[2](__reduceValue0(value["p"],r,b,d+1,c),__reduceValue0(value["q"],r,b,d+1,c),__reduceValue0(value["r"],r,b,d+1,c),__reduceValue0(value["s"],r,b,d+1,c),__reduceValue0(value["t"],r,b,d+1,c),__reduceValue0(value["u"],r,b,d+1,c),c);}
function __reduceValue3(value,r,b,d,c){b.enter(d,5);return r[3](value,c);}
function __reduceValue4(value,r,b,d,c){b.enter(d,8);return r[4](value,c);}
function __reduceValue5(value,r,b,d,c){b.enter(d,4);return r[5](__reduceValue4(value["value"],r,b,d+1,c),__reduceValue6(value["previous"],r,b,d+1,c),c);}
function __reduceValue6(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'None')&&value.None===null?r[6](0,null,c):r[6](1,__reduceValue5(value.Some,r,b,d+1,c),c);}
function __reduceValue7(value,r,b,d,c){b.enter(d,4);return r[7](__reduceValue8(value["p"],r,b,d+1,c),__reduceValue8(value["q"],r,b,d+1,c),__reduceValue8(value["r"],r,b,d+1,c),__reduceValue8(value["s"],r,b,d+1,c),__reduceValue8(value["t"],r,b,d+1,c),__reduceValue8(value["u"],r,b,d+1,c),c);}
function __reduceValue8(value,r,b,d,c){b.enter(d,4);return r[8](__reduceValue9(value["a"],r,b,d+1,c),__reduceValue9(value["b"],r,b,d+1,c),c);}
function __reduceValue9(value,r,b,d,c){b.enter(d,4);return r[9](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue1(value["tangent_0"],r,b,d+1,c),__reduceValue1(value["tangent_1"],r,b,d+1,c),__reduceValue1(value["tangent_2"],r,b,d+1,c),__reduceValue1(value["tangent_3"],r,b,d+1,c),__reduceValue1(value["tangent_4"],r,b,d+1,c),__reduceValue1(value["tangent_5"],r,b,d+1,c),__reduceValue1(value["tangent_6"],r,b,d+1,c),__reduceValue1(value["tangent_7"],r,b,d+1,c),__reduceValue1(value["tangent_8"],r,b,d+1,c),__reduceValue1(value["tangent_9"],r,b,d+1,c),__reduceValue1(value["tangent_10"],r,b,d+1,c),__reduceValue1(value["tangent_11"],r,b,d+1,c),c);}
function __reduceValue10(value,r,b,d,c){b.enter(d,4);return r[10](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue1(value["tangent"],r,b,d+1,c),c);}
function __reduceValue11(value,r,b,d,c){b.enter(d,4);return r[11](__reduceValue12(value["p"],r,b,d+1,c),__reduceValue12(value["q"],r,b,d+1,c),__reduceValue12(value["r"],r,b,d+1,c),__reduceValue12(value["s"],r,b,d+1,c),__reduceValue12(value["t"],r,b,d+1,c),__reduceValue12(value["u"],r,b,d+1,c),c);}
function __reduceValue12(value,r,b,d,c){b.enter(d,4);return r[12](__reduceValue10(value["a"],r,b,d+1,c),__reduceValue10(value["b"],r,b,d+1,c),c);}
let __reductionNodeCache;function __reductionNodes(){return __reductionNodeCache??=Object.freeze([Object.freeze({"children":Object.freeze([1,1]),"fields":Object.freeze(["a","b"]),"kind":"record","name":"Pair"}),Object.freeze({"children":Object.freeze([]),"kind":"f64"}),Object.freeze({"children":Object.freeze([0,0,0,0,0,0]),"fields":Object.freeze(["p","q","r","s","t","u"]),"kind":"record","name":"Bundle"}),Object.freeze({"children":Object.freeze([]),"kind":"bool"}),Object.freeze({"children":Object.freeze([]),"kind":"u32"}),Object.freeze({"children":Object.freeze([4,6]),"fields":Object.freeze(["value","previous"]),"kind":"record","name":"Node"}),Object.freeze({"children":Object.freeze([5]),"kind":"option"}),Object.freeze({"children":Object.freeze([8,8,8,8,8,8]),"fields":Object.freeze(["p","q","r","s","t","u"]),"kind":"record","name":"__ink_differential64_4"}),Object.freeze({"children":Object.freeze([9,9]),"fields":Object.freeze(["a","b"]),"kind":"record","name":"__ink_differential64_5"}),Object.freeze({"children":Object.freeze([1,1,1,1,1,1,1,1,1,1,1,1,1]),"fields":Object.freeze(["value","tangent_0","tangent_1","tangent_2","tangent_3","tangent_4","tangent_5","tangent_6","tangent_7","tangent_8","tangent_9","tangent_10","tangent_11"]),"kind":"record","name":"__ink_differential64_2"}),Object.freeze({"children":Object.freeze([1,1]),"fields":Object.freeze(["value","tangent"]),"kind":"record","name":"__ink_differential64_0"}),Object.freeze({"children":Object.freeze([12,12,12,12,12,12]),"fields":Object.freeze(["p","q","r","s","t","u"]),"kind":"record","name":"__ink_differential64_21"}),Object.freeze({"children":Object.freeze([10,10]),"fields":Object.freeze(["a","b"]),"kind":"record","name":"__ink_differential64_22"})]);}
function __compiledNamed1(){return {"Node":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}};}
function __compiledNamed0(){return {};}
let __compiledCodec0Value;function __compiledCodec0(){return __compiledCodec0Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"2c0b82b8cbdb96c5430627da6020de8a76d66d9c2adce83f72fd5e0a194f4e8f","named":__compiledNamed0(),"root":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},__privateCapture0,__privateWireValue0,__privateWireWrite0,__compiledOwnedValue0,0,0,__reduceValue0,false,false);}
let __compiledCodec1Value;function __compiledCodec1(){return __compiledCodec1Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":__compiledNamed0(),"root":{"kind":"f64"}},__privateCapture1,__privateWireValue1,__privateWireWrite1,__compiledOwnedValue1,1,1,__reduceValue1,false,false);}
let __compiledCodec2Value;function __compiledCodec2(){return __compiledCodec2Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"6e167f69f172d2f471a5d6ccb78ce304160f062f8f680efcdb1be1838e9f1380","named":__compiledNamed0(),"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f64"}},{"name":"b","type":{"kind":"f64"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},__privateCapture2,__privateWireValue3,__privateWireWrite2,__compiledOwnedValue2,2,2,__reduceValue2,false,false);}
let __compiledCodec3Value;function __compiledCodec3(){return __compiledCodec3Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":__compiledNamed0(),"root":{"kind":"bool"}},__privateCapture3,__privateWireValue6,__privateWireWrite3,__compiledOwnedValue3,3,3,__reduceValue3,false,false);}
let __compiledCodec4Value;function __compiledCodec4(){return __compiledCodec4Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff","named":__compiledNamed0(),"root":{"kind":"u32"}},__privateCapture4,__privateWireValue11,__privateWireWrite4,__compiledOwnedValue4,4,4,__reduceValue4,false,false);}
let __compiledCodec5Value;function __compiledCodec5(){return __compiledCodec5Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"06a5b110d3c213512730b89ea5797ec6a338f55b0c357c4c3894a84ac3cfa9e3","named":__compiledNamed1(),"root":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}},__privateCapture5,__privateWireValue12,__privateWireWrite5,__compiledOwnedValue5,5,5,__reduceValue5,false,false);}
let __compiledCodec6Value;function __compiledCodec6(){return __compiledCodec6Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"b22f71fad67dddae73cbf7b48097beac8b46e56b2fdb77c47821787e4545b91e","named":__compiledNamed0(),"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}}],"kind":"record","name":"__ink_differential64_5"}}],"kind":"record","name":"__ink_differential64_4"}},__privateCapture7,__privateWireValue15,__privateWireWrite7,__compiledOwnedValue8,7,7,__reduceValue7,false,false);}
let __compiledCodec7Value;function __compiledCodec7(){return __compiledCodec7Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"48296b791ad4dd37c119c1bf7df4bcef9199640bff85b3a36cc024468a1de719","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent_0","type":{"kind":"f64"}},{"name":"tangent_1","type":{"kind":"f64"}},{"name":"tangent_2","type":{"kind":"f64"}},{"name":"tangent_3","type":{"kind":"f64"}},{"name":"tangent_4","type":{"kind":"f64"}},{"name":"tangent_5","type":{"kind":"f64"}},{"name":"tangent_6","type":{"kind":"f64"}},{"name":"tangent_7","type":{"kind":"f64"}},{"name":"tangent_8","type":{"kind":"f64"}},{"name":"tangent_9","type":{"kind":"f64"}},{"name":"tangent_10","type":{"kind":"f64"}},{"name":"tangent_11","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_2"}},__privateCapture9,__privateWireValue17,__privateWireWrite9,__compiledOwnedValue10,9,9,__reduceValue9,false,false);}
let __compiledCodec8Value;function __compiledCodec8(){return __compiledCodec8Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"0e35873fe4e2836a793d1cccc5c47875def75fd4336b47c5bfa790354746fbe1","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},__privateCapture10,__privateWireValue19,__privateWireWrite10,__compiledOwnedValue11,10,10,__reduceValue10,false,false);}
let __compiledCodec9Value;function __compiledCodec9(){return __compiledCodec9Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"227d23ab668fe8686843e124369827fd379c486bd2e7766d8505ebbff7450bfc","named":__compiledNamed0(),"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"__ink_differential64_22"}}],"kind":"record","name":"__ink_differential64_21"}},__privateCapture11,__privateWireValue23,__privateWireWrite11,__compiledOwnedValue12,11,11,__reduceValue11,false,false);}
const __compiledEntries=new Map([["component",{index:0,params:[__compiledCodec0,__compiledCodec1],result:__compiledCodec1,destination:null,arguments:__privateWireValue2,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["energy",{index:1,params:[__compiledCodec2,__compiledCodec1],result:__compiledCodec1,destination:null,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["derivatives",{index:2,params:[__compiledCodec2,__compiledCodec1],result:__compiledCodec2,destination:null,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["direction",{index:3,params:[__compiledCodec2,__compiledCodec1],result:__compiledCodec1,destination:null,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["twice",{index:4,params:[__compiledCodec0],result:__compiledCodec1,destination:null,arguments:__privateWireValue5,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["selected",{index:5,params:[__compiledCodec0,__compiledCodec3],result:__compiledCodec0,destination:null,arguments:__privateWireValue7,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["branches",{index:6,params:[__compiledCodec1,__compiledCodec3],result:__compiledCodec0,destination:null,arguments:__privateWireValue8,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["looping",{index:7,params:[__compiledCodec1],result:__compiledCodec0,destination:null,arguments:__privateWireValue9,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["strict_unused",{index:8,params:[__compiledCodec0],result:__compiledCodec1,destination:null,arguments:__privateWireValue5,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["strict",{index:9,params:[__compiledCodec1,__compiledCodec1],result:__compiledCodec1,destination:null,arguments:__privateWireValue10,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["history",{index:10,params:[__compiledCodec4],result:__compiledCodec5,destination:null,arguments:__privateWireValue14,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["__ink_differential64_3",{index:11,params:[__compiledCodec6,__compiledCodec7],result:__compiledCodec7,destination:null,arguments:__privateWireValue18,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential64_1",{index:12,params:[__compiledCodec2,__compiledCodec1],result:__compiledCodec2,destination:null,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential64_23",{index:13,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,destination:null,arguments:__privateWireValue20,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential64_27",{index:14,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,destination:null,arguments:__privateWireValue21,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential64_31",{index:15,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,destination:null,arguments:__privateWireValue22,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential64_20",{index:16,params:[__compiledCodec9,__compiledCodec8],result:__compiledCodec8,destination:null,arguments:__privateWireValue25,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential64_19",{index:17,params:[__compiledCodec2,__compiledCodec2,__compiledCodec1],result:__compiledCodec1,destination:null,arguments:__privateWireValue26,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}]]);

export const compiledValues=Object.freeze(Object.fromEntries([...__compiledEntries].map(([name,entry])=>[name,Object.freeze({get params(){return Object.freeze(entry.params.map(codec=>codec()));},get result(){return entry.result();}})])));
function __compiledValidate(entry,owned){
 const values=owned.map(v=>v.value);
 const established=entry.onlyTypeGuards&&entry.needsInvariants.every((needed,i)=>!needed||owned[i].guaranteed);
 if(entry.precondition!==null&&!established){
  if(__implementations[entry.precondition](...values)!==true)throw Error('contract precondition failed');
  for(let i=0;i<owned.length;i++)if(entry.needsInvariants[i])owned[i].guaranteed=true;
 }
 return values;
}
export function callCompiled(name,args){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(args)||args.length!==entry.params.length)throw Error('unsupported compiled call');
 const owned=entry.params.map((codec,i)=>__compiledEntry(args[i],codec().identity)),values=__compiledValidate(entry,owned);
 // Checked source outputs satisfy their declared value interfaces. Private
 // handles expose only detached copies and never retain mutable host inputs.
 return __compiledHandle(entry.result().identity,__implementations[entry.index](...values),true);
}

// Explicit sealed-value partial application. Each token owns a bounded set of
// lexical caches; no mutable host object, global memo table or error is retained.
const __preparedCompiled=new WeakMap();
export function prepareCompiled(name,bindings){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(bindings)||bindings.length>entry.params.length)throw Error('unsupported prepared compiled call');
 const captured=new Array(entry.params.length),fixed=new Array(entry.params.length).fill(false);
 for(const binding of bindings){
  if(!Array.isArray(binding)||binding.length!==2)throw Error('prepared compiled binding');
  const [index,handle]=binding;
  if(!Number.isInteger(index)||index<0||index>=fixed.length||fixed[index])throw Error('prepared compiled parameter');
  captured[index]=__compiledEntry(handle,entry.params[index]().identity);fixed[index]=true;
 }
 const remaining=fixed.flatMap((yes,i)=>yes?[]:[i]);
 const factory=__preparedFactories.get(entry.index);
 const run=factory?factory(fixed):__implementations[entry.index];
 const token=Object.freeze(Object.create(null));
 __preparedCompiled.set(token,{entry,captured,remaining,run});return token;
}
export function callPreparedCompiled(token,args){
 const prepared=__preparedCompiled.get(token);
 if(!prepared||!Array.isArray(args)||args.length!==prepared.remaining.length)throw Error('invalid prepared compiled call');
 const {entry,captured,remaining,run}=prepared,owned=captured.slice();
 for(let i=0;i<remaining.length;i++){const at=remaining[i];owned[at]=__compiledEntry(args[i],entry.params[at]().identity);}
 const values=__compiledValidate(entry,owned);
 return __compiledHandle(entry.result().identity,run(...values),true);
}
// The caller owns sufficiently large, disjoint destination storage. This is
// the trusted Into ABI, not a bounded wire/materialization operation. Private
// retained containers never escape: structured elements are deeply detached.
const __destinationBudget=Object.freeze({remaining:Infinity,enter(){},text(){}});
export function callPreparedCompiledInto(token,args,destination){
 const prepared=__preparedCompiled.get(token);
 if(!prepared||!prepared.entry.destination||!Array.isArray(args)||args.length!==prepared.remaining.length)throw Error('invalid prepared compiled destination call');
 const {entry,captured,remaining,run}=prepared,owned=captured.slice();
 for(let i=0;i<remaining.length;i++){const at=remaining[i];owned[at]=__compiledEntry(args[i],entry.params[at]().identity);}
 const values=__compiledValidate(entry,owned),into=entry.destination;
 // Ordinary scalar-list bodies can write the terminal stage directly. A
 // residual body keeps its lexical caches and copies only its final elements.
 if(into.direct&&run===__implementations[entry.index])return into.direct(...values,destination);
 const result=run(...values),n=result.length;
 for(let i=0;i<n;i++)destination[i]=into.copy(result[i],__destinationBudget,0);
 return n;
}
const __intoImplementations=[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
export const functionsInto=Object.freeze(Object.fromEntries([]));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}

function __preparedPart(mask,path){
 for(const field of path){
  if(mask===true)return true;
  if(!mask || typeof mask!=="object")return false;
  mask=Object.hasOwn(mask.fields,field)?mask.fields[field]:false;
 }
 return mask;
}
function __preparedStable(mask,path){const part=__preparedPart(mask,path);return part===true || (!!part && part.all===true);}
function __prepareFn2(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[]))))return __fn2;const v1637=depth<15&&__preparedFactories.has(12)&&((__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[])));
let v1635;
return function(v1633,v1634){let v1638;if(v1637){if(!v1635){const v1636=__preparedFactories.get(12);v1635=v1636([fixed[0],fixed[1]],depth+1);}v1638=v1635(v1633,v1634);}else{v1638=__fn12(v1633,v1634);}
return v1638;};}
function __prepareFn12(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[]))))return __fn12;const v2703=__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[]);
let v2702=false,v2701;
const v2891=__preparedPart(fixed[0],["p","a"]);
const v2892={all:__preparedStable(fixed[0],["p","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2891}};
const v2893=__preparedPart(fixed[0],["p","b"]);
const v2894={all:__preparedStable(fixed[0],["p","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2893}};
const v2895={all:__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"]),fields:{["a"]:v2892,["b"]:v2894}};
const v2896=__preparedPart(fixed[0],["q","a"]);
const v2897={all:__preparedStable(fixed[0],["q","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2896}};
const v2898=__preparedPart(fixed[0],["q","b"]);
const v2899={all:__preparedStable(fixed[0],["q","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2898}};
const v2900={all:__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"]),fields:{["a"]:v2897,["b"]:v2899}};
const v2901=__preparedPart(fixed[0],["r","a"]);
const v2902={all:__preparedStable(fixed[0],["r","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2901}};
const v2903=__preparedPart(fixed[0],["r","b"]);
const v2904={all:__preparedStable(fixed[0],["r","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2903}};
const v2905={all:__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"]),fields:{["a"]:v2902,["b"]:v2904}};
const v2906=__preparedPart(fixed[0],["s","a"]);
const v2907={all:__preparedStable(fixed[0],["s","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2906}};
const v2908=__preparedPart(fixed[0],["s","b"]);
const v2909={all:__preparedStable(fixed[0],["s","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2908}};
const v2910={all:__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"]),fields:{["a"]:v2907,["b"]:v2909}};
const v2911=__preparedPart(fixed[0],["t","a"]);
const v2912={all:__preparedStable(fixed[0],["t","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2911}};
const v2913=__preparedPart(fixed[0],["t","b"]);
const v2914={all:__preparedStable(fixed[0],["t","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2913}};
const v2915={all:__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"]),fields:{["a"]:v2912,["b"]:v2914}};
const v2916=__preparedPart(fixed[0],["u","a"]);
const v2917={all:__preparedStable(fixed[0],["u","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2916}};
const v2918=__preparedPart(fixed[0],["u","b"]);
const v2919={all:__preparedStable(fixed[0],["u","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2918}};
const v2920={all:__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"]),fields:{["a"]:v2917,["b"]:v2919}};
const v2921={all:__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"]),fields:{["p"]:v2895,["q"]:v2900,["r"]:v2905,["s"]:v2910,["t"]:v2915,["u"]:v2920}};
const v2935={all:__preparedStable(fixed[1],[]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:fixed[1]}};
const v2938=depth<15&&__preparedFactories.has(11)&&((__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[])));
let v2936;
return function(v2698,v2699){let v2700;if(v2703&&v2702){v2700=v2701;}else{
const v2704=v2698["p"];
const v2705=v2704["a"];
const v2706=1.0;
const v2707=0.0;
const v2708=0.0;
const v2709=0.0;
const v2710=0.0;
const v2711=0.0;
const v2712=0.0;
const v2713=0.0;
const v2714=0.0;
const v2715=0.0;
const v2716=0.0;
const v2717=0.0;
const v2719=v2698["p"];
const v2720=v2719["b"];
const v2721=0.0;
const v2722=1.0;
const v2723=0.0;
const v2724=0.0;
const v2725=0.0;
const v2726=0.0;
const v2727=0.0;
const v2728=0.0;
const v2729=0.0;
const v2730=0.0;
const v2731=0.0;
const v2732=0.0;
const v2735=v2698["q"];
const v2736=v2735["a"];
const v2737=0.0;
const v2738=0.0;
const v2739=1.0;
const v2740=0.0;
const v2741=0.0;
const v2742=0.0;
const v2743=0.0;
const v2744=0.0;
const v2745=0.0;
const v2746=0.0;
const v2747=0.0;
const v2748=0.0;
const v2750=v2698["q"];
const v2751=v2750["b"];
const v2752=0.0;
const v2753=0.0;
const v2754=0.0;
const v2755=1.0;
const v2756=0.0;
const v2757=0.0;
const v2758=0.0;
const v2759=0.0;
const v2760=0.0;
const v2761=0.0;
const v2762=0.0;
const v2763=0.0;
const v2766=v2698["r"];
const v2767=v2766["a"];
const v2768=0.0;
const v2769=0.0;
const v2770=0.0;
const v2771=0.0;
const v2772=1.0;
const v2773=0.0;
const v2774=0.0;
const v2775=0.0;
const v2776=0.0;
const v2777=0.0;
const v2778=0.0;
const v2779=0.0;
const v2781=v2698["r"];
const v2782=v2781["b"];
const v2783=0.0;
const v2784=0.0;
const v2785=0.0;
const v2786=0.0;
const v2787=0.0;
const v2788=1.0;
const v2789=0.0;
const v2790=0.0;
const v2791=0.0;
const v2792=0.0;
const v2793=0.0;
const v2794=0.0;
const v2797=v2698["s"];
const v2798=v2797["a"];
const v2799=0.0;
const v2800=0.0;
const v2801=0.0;
const v2802=0.0;
const v2803=0.0;
const v2804=0.0;
const v2805=1.0;
const v2806=0.0;
const v2807=0.0;
const v2808=0.0;
const v2809=0.0;
const v2810=0.0;
const v2812=v2698["s"];
const v2813=v2812["b"];
const v2814=0.0;
const v2815=0.0;
const v2816=0.0;
const v2817=0.0;
const v2818=0.0;
const v2819=0.0;
const v2820=0.0;
const v2821=1.0;
const v2822=0.0;
const v2823=0.0;
const v2824=0.0;
const v2825=0.0;
const v2828=v2698["t"];
const v2829=v2828["a"];
const v2830=0.0;
const v2831=0.0;
const v2832=0.0;
const v2833=0.0;
const v2834=0.0;
const v2835=0.0;
const v2836=0.0;
const v2837=0.0;
const v2838=1.0;
const v2839=0.0;
const v2840=0.0;
const v2841=0.0;
const v2843=v2698["t"];
const v2844=v2843["b"];
const v2845=0.0;
const v2846=0.0;
const v2847=0.0;
const v2848=0.0;
const v2849=0.0;
const v2850=0.0;
const v2851=0.0;
const v2852=0.0;
const v2853=0.0;
const v2854=1.0;
const v2855=0.0;
const v2856=0.0;
const v2859=v2698["u"];
const v2860=v2859["a"];
const v2861=0.0;
const v2862=0.0;
const v2863=0.0;
const v2864=0.0;
const v2865=0.0;
const v2866=0.0;
const v2867=0.0;
const v2868=0.0;
const v2869=0.0;
const v2870=0.0;
const v2871=1.0;
const v2872=0.0;
const v2874=v2698["u"];
const v2875=v2874["b"];
const v2876=0.0;
const v2877=0.0;
const v2878=0.0;
const v2879=0.0;
const v2880=0.0;
const v2881=0.0;
const v2882=0.0;
const v2883=0.0;
const v2884=0.0;
const v2885=0.0;
const v2886=0.0;
const v2887=1.0;
const v2890=({["p"]:({["a"]:({["value"]:v2705,["tangent_0"]:v2706,["tangent_1"]:v2707,["tangent_2"]:v2708,["tangent_3"]:v2709,["tangent_4"]:v2710,["tangent_5"]:v2711,["tangent_6"]:v2712,["tangent_7"]:v2713,["tangent_8"]:v2714,["tangent_9"]:v2715,["tangent_10"]:v2716,["tangent_11"]:v2717}),["b"]:({["value"]:v2720,["tangent_0"]:v2721,["tangent_1"]:v2722,["tangent_2"]:v2723,["tangent_3"]:v2724,["tangent_4"]:v2725,["tangent_5"]:v2726,["tangent_6"]:v2727,["tangent_7"]:v2728,["tangent_8"]:v2729,["tangent_9"]:v2730,["tangent_10"]:v2731,["tangent_11"]:v2732})}),["q"]:({["a"]:({["value"]:v2736,["tangent_0"]:v2737,["tangent_1"]:v2738,["tangent_2"]:v2739,["tangent_3"]:v2740,["tangent_4"]:v2741,["tangent_5"]:v2742,["tangent_6"]:v2743,["tangent_7"]:v2744,["tangent_8"]:v2745,["tangent_9"]:v2746,["tangent_10"]:v2747,["tangent_11"]:v2748}),["b"]:({["value"]:v2751,["tangent_0"]:v2752,["tangent_1"]:v2753,["tangent_2"]:v2754,["tangent_3"]:v2755,["tangent_4"]:v2756,["tangent_5"]:v2757,["tangent_6"]:v2758,["tangent_7"]:v2759,["tangent_8"]:v2760,["tangent_9"]:v2761,["tangent_10"]:v2762,["tangent_11"]:v2763})}),["r"]:({["a"]:({["value"]:v2767,["tangent_0"]:v2768,["tangent_1"]:v2769,["tangent_2"]:v2770,["tangent_3"]:v2771,["tangent_4"]:v2772,["tangent_5"]:v2773,["tangent_6"]:v2774,["tangent_7"]:v2775,["tangent_8"]:v2776,["tangent_9"]:v2777,["tangent_10"]:v2778,["tangent_11"]:v2779}),["b"]:({["value"]:v2782,["tangent_0"]:v2783,["tangent_1"]:v2784,["tangent_2"]:v2785,["tangent_3"]:v2786,["tangent_4"]:v2787,["tangent_5"]:v2788,["tangent_6"]:v2789,["tangent_7"]:v2790,["tangent_8"]:v2791,["tangent_9"]:v2792,["tangent_10"]:v2793,["tangent_11"]:v2794})}),["s"]:({["a"]:({["value"]:v2798,["tangent_0"]:v2799,["tangent_1"]:v2800,["tangent_2"]:v2801,["tangent_3"]:v2802,["tangent_4"]:v2803,["tangent_5"]:v2804,["tangent_6"]:v2805,["tangent_7"]:v2806,["tangent_8"]:v2807,["tangent_9"]:v2808,["tangent_10"]:v2809,["tangent_11"]:v2810}),["b"]:({["value"]:v2813,["tangent_0"]:v2814,["tangent_1"]:v2815,["tangent_2"]:v2816,["tangent_3"]:v2817,["tangent_4"]:v2818,["tangent_5"]:v2819,["tangent_6"]:v2820,["tangent_7"]:v2821,["tangent_8"]:v2822,["tangent_9"]:v2823,["tangent_10"]:v2824,["tangent_11"]:v2825})}),["t"]:({["a"]:({["value"]:v2829,["tangent_0"]:v2830,["tangent_1"]:v2831,["tangent_2"]:v2832,["tangent_3"]:v2833,["tangent_4"]:v2834,["tangent_5"]:v2835,["tangent_6"]:v2836,["tangent_7"]:v2837,["tangent_8"]:v2838,["tangent_9"]:v2839,["tangent_10"]:v2840,["tangent_11"]:v2841}),["b"]:({["value"]:v2844,["tangent_0"]:v2845,["tangent_1"]:v2846,["tangent_2"]:v2847,["tangent_3"]:v2848,["tangent_4"]:v2849,["tangent_5"]:v2850,["tangent_6"]:v2851,["tangent_7"]:v2852,["tangent_8"]:v2853,["tangent_9"]:v2854,["tangent_10"]:v2855,["tangent_11"]:v2856})}),["u"]:({["a"]:({["value"]:v2860,["tangent_0"]:v2861,["tangent_1"]:v2862,["tangent_2"]:v2863,["tangent_3"]:v2864,["tangent_4"]:v2865,["tangent_5"]:v2866,["tangent_6"]:v2867,["tangent_7"]:v2868,["tangent_8"]:v2869,["tangent_9"]:v2870,["tangent_10"]:v2871,["tangent_11"]:v2872}),["b"]:({["value"]:v2875,["tangent_0"]:v2876,["tangent_1"]:v2877,["tangent_2"]:v2878,["tangent_3"]:v2879,["tangent_4"]:v2880,["tangent_5"]:v2881,["tangent_6"]:v2882,["tangent_7"]:v2883,["tangent_8"]:v2884,["tangent_9"]:v2885,["tangent_10"]:v2886,["tangent_11"]:v2887})})});
const v2922=0.0;
const v2923=0.0;
const v2924=0.0;
const v2925=0.0;
const v2926=0.0;
const v2927=0.0;
const v2928=0.0;
const v2929=0.0;
const v2930=0.0;
const v2931=0.0;
const v2932=0.0;
const v2933=0.0;
const v2934=({["value"]:v2699,["tangent_0"]:v2922,["tangent_1"]:v2923,["tangent_2"]:v2924,["tangent_3"]:v2925,["tangent_4"]:v2926,["tangent_5"]:v2927,["tangent_6"]:v2928,["tangent_7"]:v2929,["tangent_8"]:v2930,["tangent_9"]:v2931,["tangent_10"]:v2932,["tangent_11"]:v2933});
let v2939;if(v2938){if(!v2936){const v2937=__preparedFactories.get(11);v2936=v2937([v2921,v2935],depth+1);}v2939=v2936(v2890,v2934);}else{v2939=__fn11(v2890,v2934);}
v2700=v2939;if(v2703){v2701=v2700;v2702=true;}}
const v2940=v2700;
const v2941=v2940["tangent_0"];
const v2942=v2700;
const v2943=v2942["tangent_1"];
const v2945=v2700;
const v2946=v2945["tangent_2"];
const v2947=v2700;
const v2948=v2947["tangent_3"];
const v2950=v2700;
const v2951=v2950["tangent_4"];
const v2952=v2700;
const v2953=v2952["tangent_5"];
const v2955=v2700;
const v2956=v2955["tangent_6"];
const v2957=v2700;
const v2958=v2957["tangent_7"];
const v2960=v2700;
const v2961=v2960["tangent_8"];
const v2962=v2700;
const v2963=v2962["tangent_9"];
const v2965=v2700;
const v2966=v2965["tangent_10"];
const v2967=v2700;
const v2968=v2967["tangent_11"];
return ({["p"]:({["a"]:v2941,["b"]:v2943}),["q"]:({["a"]:v2946,["b"]:v2948}),["r"]:({["a"]:v2951,["b"]:v2953}),["s"]:({["a"]:v2956,["b"]:v2958}),["t"]:({["a"]:v2961,["b"]:v2963}),["u"]:({["a"]:v2966,["b"]:v2968})});};}
const __preparedFactories=new Map([[2,__prepareFn2],[12,__prepareFn12]]);
