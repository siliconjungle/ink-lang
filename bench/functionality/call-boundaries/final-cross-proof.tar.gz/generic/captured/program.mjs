const __recordElisions=new Set([]);
const __nativeF32=true;
// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
// Binary64 uses native Numbers for finite arithmetic and immutable private
// tags only where a NaN's exact payload must survive non-arithmetic operations.
const __doubleView=new DataView(new ArrayBuffer(8));
const __double=bits=>{__doubleView.setBigUint64(0,bits,true);return __doubleView.getFloat64(0,true);};
const __doubleBits=number=>{if(Number.isNaN(number))return 0x7ff8000000000000n;__doubleView.setFloat64(0,number,true);return __doubleView.getBigUint64(0,true);};
const __dfNumber=value=>typeof value==='number'?value:__double(BigInt(value.F64Bits));
const __dfBits=value=>typeof value==='number'?__doubleBits(value):BigInt(value.F64Bits);
const __dfFromBits=bits=>(bits&0x7fffffffffffffffn)>0x7ff0000000000000n?Object.freeze({F64Bits:bits.toString()}):__double(bits);
const __dfInput=value=>typeof value==='number'?value:__dfFromBits(BigInt(value.F64Bits));
const __dfNeg=value=>typeof value==='number'&&!Number.isNaN(value)?-value:__dfFromBits(__dfBits(value)^0x8000000000000000n);
const __dfOutput=value=>{const n=__dfNumber(value);return Number.isFinite(n)?n:{F64Bits:__dfBits(value).toString()};};
const __dfCapture=value=>{
 if(typeof value==='number'&&Number.isFinite(value))return value;
 if(!value||typeof value!=='object'||Object.keys(value).length!==1||!Object.hasOwn(value,'F64Bits'))throw Error('invalid f64');const text=value.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid f64');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');return __dfFromBits(bits);
};
// Native binary32 lane for pure modules. Explicit NaN payloads remain tagged;
// arithmetic canonicalizes NaNs just as __bits does in the exact-bit lane.
// Host tags are captured once at a typed read. Only private immutable tags
// may pass through normalization without consulting a host property again.
const __nfTagged = new WeakSet();
const __nfValue = value => typeof value === 'number' ? Math.fround(value) : __nfTagged.has(value) ? value : __nfFromBits(value.F32Bits);
// Number operands have already been normalised at their typed read or producer.
const __nfNumber = value => typeof value === 'number' ? value : __float(value.F32Bits);
const __nfBits = value => typeof value === 'number' ? __bits(value) : value.F32Bits;
const __nfFromBits = bits => {
  if((bits & 0x7fffffff)<=0x7f800000)return __float(bits);
  const value=Object.freeze({F32Bits:bits});__nfTagged.add(value);return value;
};
const __nfNeg = value => typeof value === 'number' && !Number.isNaN(value) ? -value : __nfFromBits((__nfBits(value) ^ 0x80000000) >>> 0);
const __nfOutput = value => {const n=typeof value==='number'?Math.fround(value):__float(value.F32Bits);return Number.isFinite(n)?n:{F32Bits:__nfBits(value)};};
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output, capture=false) {
  const convert=__representationRaw(type,output,capture);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':capture?'capture:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output, capture) {
  switch (type.kind) {
    case 'ref': {
      let resolved;
      return (value,context)=>(resolved??=__representation(__namedTypes[type.name],output,capture))(value,context);
    }
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output,capture);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output,capture),err=__representation(type.error,output,capture);
      const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);
      if(flat)return output?(value,context)=>{const v=__sumView(key,value);return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};}:(v,context)=>Object.hasOwn(v,'Ok')?__sumMake(key,true,ok(v.Ok,context)):__sumMake(key,false,err(v.Err,context));
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f64':return output?__dfOutput:__dfInput;
    case 'f32': if(typeof __nativeF32!=='undefined'&&__nativeF32)return output?__nfOutput:capture?__nfValue:__identity;
      return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output,capture);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){
        if(!type.fields.length)return ()=>undefined; // lexically unconsumed projected input
        const field=type.fields[0],child=__representation(field.type,output,capture);
        return output?(value,context)=>({[field.name]:child(value,context)}):(value,context)=>child(value[field.name],context);
      }
      const fields = type.fields.map(field => [field.name, __representation(field.type, output,capture)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
function __stateWord(value){
 if(typeof value==='number'&&!Number.isSafeInteger(value))throw Error('u64 requires an exact integer');
 if(!['bigint','number','string'].includes(typeof value)||typeof value==='string'&&!/^(0|[1-9][0-9]*)$/.test(value))throw Error('invalid u64');
 const n=BigInt(value);if(n<0n||n>18446744073709551615n)throw Error('invalid u64');return n;
}
// Compile the capture traversal once. Each invocation still validates and owns
// every public container; no host value is retained between calls.
const __stateCaptures=new WeakMap();
function __stateCapture(type){
 const prior=__stateCaptures.get(type);if(prior)return prior;
 const capture=__compileStateCapture(type);__stateCaptures.set(type,capture);return capture;
}
function __compileStateCapture(type){
 const limited=copy=>(value,budget={cells:1000000},depth=0)=>{
  if(depth>64||--budget.cells<0)throw Error('state input resource limit');
  return copy(value,budget,depth);
 };
 const tagged=(value,tag)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
 switch(type.kind){
  case 'ref':{
   // Resolve lazily so recursive schemas compile to recursive validators rather
   // than reverting to descriptor interpretation at every referenced node.
   let resolved;
   return limited((value,budget,depth)=>(resolved??=__stateCapture(__namedTypes[type.name]))(value,budget,depth+1));
  }
  case 'u32':case 'i32':{
   const min=type.kind==='u32'?0:-2147483648,max=type.kind==='u32'?4294967295:2147483647;
   return limited(value=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;});
  }
  case 'u64':return limited(__stateWord);
  case 'f64':return limited(__dfCapture);
  case 'bool':return limited(value=>{if(typeof value!=='boolean')throw Error('invalid Bool');return value;});
  case 'unit':return limited(value=>{if(value!==null)throw Error('invalid Unit');return null;});
  case 'string':return limited(value=>{if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;});
  case 'enum':return limited(value=>{if(!type.variants.includes(value))throw Error('invalid enum');return value;});
  case 'id':return limited(value=>{if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();});
  case 'list':case 'vector':{
   const item=__stateCapture(type.element),size=type.kind==='vector'?type.size:null;
   return limited((value,budget,depth)=>{
    if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
    if(size!==null&&value.length!==size)throw Error('invalid vector length');
    const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=item(value[i],budget,depth+1);return out;
   });
  }
  case 'record':{
   const fields=type.fields.map(f=>[f.name,__stateCapture(f.type)]);
   if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name)))return limited((value,budget,depth)=>{const [name,copy]=fields[0];if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,name))throw Error('invalid record');return copy(value[name],budget,depth+1);});
   return limited((value,budget,depth)=>{
    if(!value||typeof value!=='object'||Array.isArray(value)||!fields.every(([name])=>Object.hasOwn(value,name)))throw Error('invalid record');
    const out={};for(const [name,copy]of fields){const field=copy(value[name],budget,depth+1);if(name==='__proto__')Object.defineProperty(out,name,{value:field,writable:true,enumerable:true,configurable:true});else out[name]=field;}return out;
   });
  }
  case 'option':{
   const item=__stateCapture(type.element);
   return limited((value,budget,depth)=>{if(tagged(value,'Some'))return {Some:item(value.Some,budget,depth+1)};if(tagged(value,'None')&&value.None===null)return {None:null};throw Error('invalid Option');});
  }
  case 'result':{
   const ok=__stateCapture(type.ok),err=__stateCapture(type.error);
   return limited((value,budget,depth)=>{if(tagged(value,'Ok'))return {Ok:ok(value.Ok,budget,depth+1)};if(tagged(value,'Err'))return {Err:err(value.Err,budget,depth+1)};throw Error('invalid Result');});
  }
  default:return (value,budget,depth)=>__stateInput(value,type,budget,depth);
 }
}
function __stateInput(value,type,budget={cells:1000000},depth=0,maxDepth=64){
  if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');
  const input=(v,t)=>__stateInput(v,t,budget,depth+1,maxDepth);
  const integer=(min,max)=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;};
  const tagged=tag=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
  switch(type.kind){
    case 'ref':return input(value,__namedTypes[type.name]);
    case 'u32':return integer(0,4294967295);
    case 'i32':return integer(-2147483648,2147483647);
    case 'u64':return __stateWord(value);
    case 'int':{
      if(typeof value==='bigint')return value;
      if(!tagged('Int')||typeof value.Int!=='string'||!/^(-?[0-9]+)$/.test(value.Int))throw Error('invalid Int');return BigInt(value.Int);
    }
    case 'f64':return __dfCapture(value);
    case 'f32':{
      if(typeof value==='number'&&Number.isFinite(value)){const bits=__bits(value);if((bits&0x7fffffff)===0x7f800000)throw Error('f32 overflow requires F32Bits');return bits;}
      if(!tagged('F32Bits')||!Number.isInteger(value.F32Bits)||value.F32Bits<0||value.F32Bits>4294967295)throw Error('invalid f32');return value.F32Bits;
    }
    case 'bool':if(typeof value!=='boolean')throw Error('invalid Bool');return value;
    case 'unit':if(value!==null)throw Error('invalid Unit');return null;
    case 'string':if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;
    case 'id':if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();
    case 'enum':if(!type.variants.includes(value))throw Error('invalid enum');return value;
    case 'list':case 'vector':{
      if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
      if(type.kind==='vector'&&value.length!==type.size)throw Error('invalid vector length');
      return Array.from(value,v=>input(v,type.element));
    }
    case 'record':if(!value||typeof value!=='object'||Array.isArray(value)||!type.fields.every(f=>Object.hasOwn(value,f.name)))throw Error('invalid record');if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){const f=type.fields[0];return input(value[f.name],f.type);}return Object.fromEntries(type.fields.map(f=>[f.name,input(value[f.name],f.type)]));
    case 'option':if(tagged('Some'))return {Some:input(value.Some,type.element)};if(tagged('None')&&value.None===null)return {None:null};throw Error('invalid Option');
    case 'result':{const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);if(tagged('Ok')){const child=input(value.Ok,type.ok);return flat?__sumMake(key,true,child):{Ok:child};}if(tagged('Err')){const child=input(value.Err,type.error);return flat?__sumMake(key,false,child):{Err:child};}throw Error('invalid Result');}
    default:throw Error('unsupported public value type');
  }
}
// Mutable host replies must not retain references into compiled state or its outbox.
// State results must own mutable containers. Compile the declared schema once:
// scalars need no structured clone, while nested records/lists remain detached.
function __ownershipSchema(type){
 // Nominal references and expanded declarations name the same checked sort.
 // Distinct source records retain distinct keys even if a layout erases them.
 if(type.kind==='ref'||type.kind==='record'&&type.name)return ['named',type.name];
 switch(type.kind){
  case 'list':case 'vector':return [type.kind,type.size??null,__ownershipSchema(type.element)];
  case 'option':return ['option',__ownershipSchema(type.element)];
  case 'result':return ['result',__ownershipSchema(type.ok),__ownershipSchema(type.error)];
  case 'record':return ['record',type.fields.map(f=>[f.name,__ownershipSchema(f.type)])];
  default:return type;
 }
}
function __ownedResult(copy,nested,type){
 const key='owned-state:'+JSON.stringify(__ownershipSchema(type));
 let schema=__conversionKeys.get(key);
 if(!schema){schema={};__conversionKeys.set(key,schema);}
 const owned=(value,context)=>{
  if(!context&&!nested)return copy(value,null);
  const memo=context||new WeakMap();
  if(value===null||typeof value!=='object')return copy(value,memo);
  let entries=memo.get(schema);if(!entries){entries=new WeakMap();memo.set(schema,entries);}
  if(entries.has(value))return entries.get(value);
  const result=copy(value,memo);entries.set(value,result);return result;
 };
 owned.container=true;return owned;
}
function __stateResult(type){
 switch(type.kind){
  // State storage is always exact bits, independently of pure helper carriers.
  case 'f32':return value=>{const number=__float(value);return Number.isFinite(number)?number:{F32Bits:value};};
  case 'ref':{let resolved;const copy=(value,context)=>(resolved??=__stateResult(__namedTypes[type.name]))(value,context);copy.container=true;return copy;}
  case 'record':{if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){const f=type.fields[0],copy=__stateResult(f.type);return __ownedResult((value,context)=>({[f.name]:copy(value,context)}),copy.container,type);}const fields=type.fields.map(f=>[f.name,__stateResult(f.type)]);return __ownedResult((value,context)=>Object.fromEntries(fields.map(([name,copy])=>[name,copy(value[name],context)])),fields.some(([,copy])=>copy.container),type);}
  case 'list':case 'vector':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Array.from(value,item=>copy(item,context)),copy.container,type);}
  case 'option':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Object.hasOwn(value,'Some')?{Some:copy(value.Some,context)}:{None:null},copy.container,type);}
  case 'result':{const ok=__stateResult(type.ok),err=__stateResult(type.error),key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);return __ownedResult((value,context)=>{const v=flat?__sumView(key,value):value;return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};},ok.container||err.container,type);}
  default:return __representation(type,true);
 }
}
function __stateOutput(value,type){return __stateResult(type)(value);}
const __u64 = n => BigInt.asUintN(64, n);
function __div(a, b, fallback, signed, remainder) {
  if (b === 0 || b === 0n || (signed && a === -2147483648 && b === -1)) return fallback();
  return typeof a === 'bigint' ? (remainder ? a % b : a / b) :
    ((remainder ? a % b : Math.trunc(a / b)) + 0); // integer zero has no sign
}
function __at(xs, index, fallback) { return index < xs.length ? xs[index] : fallback(); }
// Ordinary arrays retain the declared result element type when input is typed.
function __map(xs, fn) {
  const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = fn(xs[i], i);
  return out;
}
function __filter(xs, fn) {
  const out = [];
  for (let i = 0; i < xs.length; i++) if (fn(xs[i])) out.push(xs[i]);
  return out;
}
function __concat(xs, ys) {
  const left = xs.length, right = ys.length, out = new Array(left + right);
  for (let i = 0; i < left; i++) out[i] = xs[i];
  for (let i = 0; i < right; i++) out[left + i] = ys[i];
  return out;
}
function __zip(xs, ys, fn) {
  const n = Math.min(xs.length, ys.length), out = new Array(n);
  for (let i = 0; i < n; i++) out[i] = fn(xs[i], ys[i]);
  return out;
}
function __repeat(n, initial, fn) { let value = initial; for (let i = 0; i < n; i++) value = fn(i, value); return value; }
function __foldr(xs, initial, fn) { let value = initial; for (let i = xs.length - 1; i >= 0; i--) value = fn(xs[i], value); return value; }
function __scan(xs, zero, add) {
  let value = zero; const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = value = add(value, xs[i]);
  return out;
}
const __sort = xs => Array.from(xs).sort((a,b) => a < b ? -1 : a > b ? 1 : 0);

function __wordSort(xs,Storage){
 const sorted=Storage.from(xs).sort(),out=new Array(sorted.length);
 for(let i=0;i<sorted.length;i++)out[i]=sorted[i];
 return out;
}
// Fixed word semantics, including arithmetic signed right shift. Shift and
// rotation counts wrap modulo width; no source-pattern optimisation lives here.
function __word(op,a,b,bits) {
  const width=BigInt(Math.abs(bits)), k=BigInt(b??0)%width;
  const x=BigInt(a), y=BigInt(b??0), unsigned=BigInt.asUintN(Number(width),x);
  let r;
  switch(op) {
    case 'word_widen_u32_to_u64':case 'word_narrow_u64_to_u32':r=x;break;
    case 'word_not':r=~x;break;
    case 'word_and':r=x&y;break;
    case 'word_or':r=x|y;break;
    case 'word_xor':r=x^y;break;
    case 'wrapping_shl':r=x<<k;break;
    case 'wrapping_shr':r=x>>k;break;
    case 'rotate_left':r=(unsigned<<k)|(unsigned>>(width-k));break;
    case 'rotate_right':r=(unsigned>>k)|(unsigned<<(width-k));break;
    default:throw new Error('unknown word operation');
  }
  r=bits<0?BigInt.asIntN(Number(width),r):BigInt.asUintN(Number(width),r);
  return bits===64?r:Number(r);
}
// Rotations evaluate each operand once. Counts wrap modulo the width.
function __rotl32(a,k){k&=31;return (a<<k)|(a>>>((32-k)&31));}
function __rotr32(a,k){k&=31;return (a>>>k)|(a<<((32-k)&31));}
function __rotl64(a,k){const n=BigInt(k&63);return BigInt.asUintN(64,(a<<n)|(a>>((64n-n)&63n)));}
function __rotr64(a,k){const n=BigInt(k&63);return BigInt.asUintN(64,(a>>n)|(a<<((64n-n)&63n)));}
function __fn0(v0,v1){
const v2=v0["a"];
const v3=Math.fround(__nfNumber(v2) - __nfNumber(v1));
const v4=v0["b"];
const v5=Math.fround(__nfNumber(v4) + __nfNumber(v1));
const v6=Math.fround(v3 * v3);
const v7=Math.fround(v5 * v5);
return Math.fround(v6 + v7);}
function __fn1(v8,v9){
const v10=v8["p"];
const v11=v10["a"];
const v12=Math.fround(__nfNumber(v11) - __nfNumber(v9));
const v13=v8["p"];
const v14=v13["b"];
const v15=Math.fround(__nfNumber(v14) + __nfNumber(v9));
const v16=v8["q"];
const v17=v16["a"];
const v18=Math.fround(__nfNumber(v17) - __nfNumber(v9));
const v19=v8["q"];
const v20=v19["b"];
const v21=Math.fround(__nfNumber(v20) + __nfNumber(v9));
const v22=v8["r"];
const v23=v22["a"];
const v24=Math.fround(__nfNumber(v23) - __nfNumber(v9));
const v25=v8["r"];
const v26=v25["b"];
const v27=Math.fround(__nfNumber(v26) + __nfNumber(v9));
const v28=v8["s"];
const v29=v28["a"];
const v30=Math.fround(__nfNumber(v29) - __nfNumber(v9));
const v31=v8["s"];
const v32=v31["b"];
const v33=Math.fround(__nfNumber(v32) + __nfNumber(v9));
const v34=v8["t"];
const v35=v34["a"];
const v36=Math.fround(__nfNumber(v35) - __nfNumber(v9));
const v37=v8["t"];
const v38=v37["b"];
const v39=Math.fround(__nfNumber(v38) + __nfNumber(v9));
const v40=v8["u"];
const v41=v40["a"];
const v42=Math.fround(__nfNumber(v41) - __nfNumber(v9));
const v43=v8["u"];
const v44=v43["b"];
const v45=Math.fround(__nfNumber(v44) + __nfNumber(v9));
const v46=Math.fround(v12 * v12);
const v47=Math.fround(v15 * v15);
const v48=Math.fround(v46 + v47);
const v49=Math.fround(v18 * v18);
const v50=Math.fround(v48 + v49);
const v51=Math.fround(v21 * v21);
const v52=Math.fround(v50 + v51);
const v53=Math.fround(v24 * v24);
const v54=Math.fround(v52 + v53);
const v55=Math.fround(v27 * v27);
const v56=Math.fround(v54 + v55);
const v57=Math.fround(v30 * v30);
const v58=Math.fround(v56 + v57);
const v59=Math.fround(v33 * v33);
const v60=Math.fround(v58 + v59);
const v61=Math.fround(v36 * v36);
const v62=Math.fround(v60 + v61);
const v63=Math.fround(v39 * v39);
const v64=Math.fround(v62 + v63);
const v65=Math.fround(v42 * v42);
const v66=Math.fround(v64 + v65);
const v67=Math.fround(v45 * v45);
return Math.fround(v66 + v67);}
function __fn2(v68,v69){
return __fn12(v68,v69);}
function __fn3(v70,v71){
return __fn17(v70,v70,v71);}
function __fn4(v72){
const v73=v72["a"];
const v74=Math.fround(__nfNumber(v73) * __nfNumber(v73));
return Math.fround(v74 + v74);}
function __fn5(v75,v76){
let v77;if(v76){
const v78=v75["b"];
const v79=v75["b"];
const v80=Math.fround(__nfNumber(v78) * __nfNumber(v79));
const v81=v75["a"];
const v82=v75["a"];
const v83=Math.fround(__nfNumber(v81) * __nfNumber(v82));
v77=({["a"]:v80,["b"]:v83});}else{
const v84=v75["a"];
const v85=v75["a"];
const v86=Math.fround(__nfNumber(v84) * __nfNumber(v85));
const v87=v75["b"];
const v88=v75["b"];
const v89=Math.fround(__nfNumber(v87) * __nfNumber(v88));
v77=({["a"]:v86,["b"]:v89});}
return v77;}
function __fn6(v90,v91){
const v92=__nfNeg(v90);
let v95;
let v96;
if(v91){
const v97=Math.fround(__nfNumber(v92) * __nfNumber(v92));
const v98=Math.fround(__nfNumber(v90) * __nfNumber(v90));
v95=v97;
v96=v98;
}else{
const v99=Math.fround(__nfNumber(v90) * __nfNumber(v90));
const v100=Math.fround(__nfNumber(v92) * __nfNumber(v92));
v95=v99;
v96=v100;
}
return ({["a"]:v95,["b"]:v96});}
function __fn7(v101){
const v102=__nfNeg(v101);
let v103=v101;
let v104=v102;
for(let v106=0;v106<3;v106++){
const v107=(v106>>>0);
const v108=v104;
const v109=v103;
v103=v108;
v104=v109;
}
return ({["a"]:v103,["b"]:v104});}
function __fn8(v110){
const v111=v110["b"];
const v112=Math.fround(__nfNumber(v111) * __nfNumber(v111));
return v110["a"];}
function __fn9(v113,v114){
const v116=Math.fround(__nfNumber(v114) * __nfNumber(v114));
return v113;}
function __fn10(v117){
const v118=({None:null});
let v119=v117;
let v120=v118;
for(let v122=0;v122<3;v122++){
const v123=(v122>>>0);
const v124=v119;
const v125=1;
const v126=(((v124) + (v125)) >>> 0);
const v127=v119;
const v128=v120;
const v130=({Some:({["value"]:v127,["previous"]:v128})});
v119=v126;
v120=v130;
}
return ({["value"]:v119,["previous"]:v120});}
function __fn11(v131,v132){
const v133=v131["p"];
const v134=v133["a"];
const v135=v134["value"];
const v136=v132["value"];
const v137=Math.fround(__nfNumber(v135) - __nfNumber(v136));
const v138=v134["tangent_0"];
const v139=v132["tangent_0"];
const v140=Math.fround(__nfNumber(v138) - __nfNumber(v139));
const v141=v134["tangent_1"];
const v142=v132["tangent_1"];
const v143=Math.fround(__nfNumber(v141) - __nfNumber(v142));
const v144=v134["tangent_2"];
const v145=v132["tangent_2"];
const v146=Math.fround(__nfNumber(v144) - __nfNumber(v145));
const v147=v134["tangent_3"];
const v148=v132["tangent_3"];
const v149=Math.fround(__nfNumber(v147) - __nfNumber(v148));
const v150=v134["tangent_4"];
const v151=v132["tangent_4"];
const v152=Math.fround(__nfNumber(v150) - __nfNumber(v151));
const v153=v134["tangent_5"];
const v154=v132["tangent_5"];
const v155=Math.fround(__nfNumber(v153) - __nfNumber(v154));
const v156=v134["tangent_6"];
const v157=v132["tangent_6"];
const v158=Math.fround(__nfNumber(v156) - __nfNumber(v157));
const v159=v134["tangent_7"];
const v160=v132["tangent_7"];
const v161=Math.fround(__nfNumber(v159) - __nfNumber(v160));
const v162=v134["tangent_8"];
const v163=v132["tangent_8"];
const v164=Math.fround(__nfNumber(v162) - __nfNumber(v163));
const v165=v134["tangent_9"];
const v166=v132["tangent_9"];
const v167=Math.fround(__nfNumber(v165) - __nfNumber(v166));
const v168=v134["tangent_10"];
const v169=v132["tangent_10"];
const v170=Math.fround(__nfNumber(v168) - __nfNumber(v169));
const v171=v134["tangent_11"];
const v172=v132["tangent_11"];
const v173=Math.fround(__nfNumber(v171) - __nfNumber(v172));
const v175=v131["p"];
const v176=v175["b"];
const v177=v176["value"];
const v178=Math.fround(__nfNumber(v177) + __nfNumber(v136));
const v179=v176["tangent_0"];
const v180=Math.fround(__nfNumber(v179) + __nfNumber(v139));
const v181=v176["tangent_1"];
const v182=Math.fround(__nfNumber(v181) + __nfNumber(v142));
const v183=v176["tangent_2"];
const v184=Math.fround(__nfNumber(v183) + __nfNumber(v145));
const v185=v176["tangent_3"];
const v186=Math.fround(__nfNumber(v185) + __nfNumber(v148));
const v187=v176["tangent_4"];
const v188=Math.fround(__nfNumber(v187) + __nfNumber(v151));
const v189=v176["tangent_5"];
const v190=Math.fround(__nfNumber(v189) + __nfNumber(v154));
const v191=v176["tangent_6"];
const v192=Math.fround(__nfNumber(v191) + __nfNumber(v157));
const v193=v176["tangent_7"];
const v194=Math.fround(__nfNumber(v193) + __nfNumber(v160));
const v195=v176["tangent_8"];
const v196=Math.fround(__nfNumber(v195) + __nfNumber(v163));
const v197=v176["tangent_9"];
const v198=Math.fround(__nfNumber(v197) + __nfNumber(v166));
const v199=v176["tangent_10"];
const v200=Math.fround(__nfNumber(v199) + __nfNumber(v169));
const v201=v176["tangent_11"];
const v202=Math.fround(__nfNumber(v201) + __nfNumber(v172));
const v204=v131["q"];
const v205=v204["a"];
const v206=v205["value"];
const v207=Math.fround(__nfNumber(v206) - __nfNumber(v136));
const v208=v205["tangent_0"];
const v209=Math.fround(__nfNumber(v208) - __nfNumber(v139));
const v210=v205["tangent_1"];
const v211=Math.fround(__nfNumber(v210) - __nfNumber(v142));
const v212=v205["tangent_2"];
const v213=Math.fround(__nfNumber(v212) - __nfNumber(v145));
const v214=v205["tangent_3"];
const v215=Math.fround(__nfNumber(v214) - __nfNumber(v148));
const v216=v205["tangent_4"];
const v217=Math.fround(__nfNumber(v216) - __nfNumber(v151));
const v218=v205["tangent_5"];
const v219=Math.fround(__nfNumber(v218) - __nfNumber(v154));
const v220=v205["tangent_6"];
const v221=Math.fround(__nfNumber(v220) - __nfNumber(v157));
const v222=v205["tangent_7"];
const v223=Math.fround(__nfNumber(v222) - __nfNumber(v160));
const v224=v205["tangent_8"];
const v225=Math.fround(__nfNumber(v224) - __nfNumber(v163));
const v226=v205["tangent_9"];
const v227=Math.fround(__nfNumber(v226) - __nfNumber(v166));
const v228=v205["tangent_10"];
const v229=Math.fround(__nfNumber(v228) - __nfNumber(v169));
const v230=v205["tangent_11"];
const v231=Math.fround(__nfNumber(v230) - __nfNumber(v172));
const v233=v131["q"];
const v234=v233["b"];
const v235=v234["value"];
const v236=Math.fround(__nfNumber(v235) + __nfNumber(v136));
const v237=v234["tangent_0"];
const v238=Math.fround(__nfNumber(v237) + __nfNumber(v139));
const v239=v234["tangent_1"];
const v240=Math.fround(__nfNumber(v239) + __nfNumber(v142));
const v241=v234["tangent_2"];
const v242=Math.fround(__nfNumber(v241) + __nfNumber(v145));
const v243=v234["tangent_3"];
const v244=Math.fround(__nfNumber(v243) + __nfNumber(v148));
const v245=v234["tangent_4"];
const v246=Math.fround(__nfNumber(v245) + __nfNumber(v151));
const v247=v234["tangent_5"];
const v248=Math.fround(__nfNumber(v247) + __nfNumber(v154));
const v249=v234["tangent_6"];
const v250=Math.fround(__nfNumber(v249) + __nfNumber(v157));
const v251=v234["tangent_7"];
const v252=Math.fround(__nfNumber(v251) + __nfNumber(v160));
const v253=v234["tangent_8"];
const v254=Math.fround(__nfNumber(v253) + __nfNumber(v163));
const v255=v234["tangent_9"];
const v256=Math.fround(__nfNumber(v255) + __nfNumber(v166));
const v257=v234["tangent_10"];
const v258=Math.fround(__nfNumber(v257) + __nfNumber(v169));
const v259=v234["tangent_11"];
const v260=Math.fround(__nfNumber(v259) + __nfNumber(v172));
const v262=v131["r"];
const v263=v262["a"];
const v264=v263["value"];
const v265=Math.fround(__nfNumber(v264) - __nfNumber(v136));
const v266=v263["tangent_0"];
const v267=Math.fround(__nfNumber(v266) - __nfNumber(v139));
const v268=v263["tangent_1"];
const v269=Math.fround(__nfNumber(v268) - __nfNumber(v142));
const v270=v263["tangent_2"];
const v271=Math.fround(__nfNumber(v270) - __nfNumber(v145));
const v272=v263["tangent_3"];
const v273=Math.fround(__nfNumber(v272) - __nfNumber(v148));
const v274=v263["tangent_4"];
const v275=Math.fround(__nfNumber(v274) - __nfNumber(v151));
const v276=v263["tangent_5"];
const v277=Math.fround(__nfNumber(v276) - __nfNumber(v154));
const v278=v263["tangent_6"];
const v279=Math.fround(__nfNumber(v278) - __nfNumber(v157));
const v280=v263["tangent_7"];
const v281=Math.fround(__nfNumber(v280) - __nfNumber(v160));
const v282=v263["tangent_8"];
const v283=Math.fround(__nfNumber(v282) - __nfNumber(v163));
const v284=v263["tangent_9"];
const v285=Math.fround(__nfNumber(v284) - __nfNumber(v166));
const v286=v263["tangent_10"];
const v287=Math.fround(__nfNumber(v286) - __nfNumber(v169));
const v288=v263["tangent_11"];
const v289=Math.fround(__nfNumber(v288) - __nfNumber(v172));
const v291=v131["r"];
const v292=v291["b"];
const v293=v292["value"];
const v294=Math.fround(__nfNumber(v293) + __nfNumber(v136));
const v295=v292["tangent_0"];
const v296=Math.fround(__nfNumber(v295) + __nfNumber(v139));
const v297=v292["tangent_1"];
const v298=Math.fround(__nfNumber(v297) + __nfNumber(v142));
const v299=v292["tangent_2"];
const v300=Math.fround(__nfNumber(v299) + __nfNumber(v145));
const v301=v292["tangent_3"];
const v302=Math.fround(__nfNumber(v301) + __nfNumber(v148));
const v303=v292["tangent_4"];
const v304=Math.fround(__nfNumber(v303) + __nfNumber(v151));
const v305=v292["tangent_5"];
const v306=Math.fround(__nfNumber(v305) + __nfNumber(v154));
const v307=v292["tangent_6"];
const v308=Math.fround(__nfNumber(v307) + __nfNumber(v157));
const v309=v292["tangent_7"];
const v310=Math.fround(__nfNumber(v309) + __nfNumber(v160));
const v311=v292["tangent_8"];
const v312=Math.fround(__nfNumber(v311) + __nfNumber(v163));
const v313=v292["tangent_9"];
const v314=Math.fround(__nfNumber(v313) + __nfNumber(v166));
const v315=v292["tangent_10"];
const v316=Math.fround(__nfNumber(v315) + __nfNumber(v169));
const v317=v292["tangent_11"];
const v318=Math.fround(__nfNumber(v317) + __nfNumber(v172));
const v320=v131["s"];
const v321=v320["a"];
const v322=v321["value"];
const v323=Math.fround(__nfNumber(v322) - __nfNumber(v136));
const v324=v321["tangent_0"];
const v325=Math.fround(__nfNumber(v324) - __nfNumber(v139));
const v326=v321["tangent_1"];
const v327=Math.fround(__nfNumber(v326) - __nfNumber(v142));
const v328=v321["tangent_2"];
const v329=Math.fround(__nfNumber(v328) - __nfNumber(v145));
const v330=v321["tangent_3"];
const v331=Math.fround(__nfNumber(v330) - __nfNumber(v148));
const v332=v321["tangent_4"];
const v333=Math.fround(__nfNumber(v332) - __nfNumber(v151));
const v334=v321["tangent_5"];
const v335=Math.fround(__nfNumber(v334) - __nfNumber(v154));
const v336=v321["tangent_6"];
const v337=Math.fround(__nfNumber(v336) - __nfNumber(v157));
const v338=v321["tangent_7"];
const v339=Math.fround(__nfNumber(v338) - __nfNumber(v160));
const v340=v321["tangent_8"];
const v341=Math.fround(__nfNumber(v340) - __nfNumber(v163));
const v342=v321["tangent_9"];
const v343=Math.fround(__nfNumber(v342) - __nfNumber(v166));
const v344=v321["tangent_10"];
const v345=Math.fround(__nfNumber(v344) - __nfNumber(v169));
const v346=v321["tangent_11"];
const v347=Math.fround(__nfNumber(v346) - __nfNumber(v172));
const v349=v131["s"];
const v350=v349["b"];
const v351=v350["value"];
const v352=Math.fround(__nfNumber(v351) + __nfNumber(v136));
const v353=v350["tangent_0"];
const v354=Math.fround(__nfNumber(v353) + __nfNumber(v139));
const v355=v350["tangent_1"];
const v356=Math.fround(__nfNumber(v355) + __nfNumber(v142));
const v357=v350["tangent_2"];
const v358=Math.fround(__nfNumber(v357) + __nfNumber(v145));
const v359=v350["tangent_3"];
const v360=Math.fround(__nfNumber(v359) + __nfNumber(v148));
const v361=v350["tangent_4"];
const v362=Math.fround(__nfNumber(v361) + __nfNumber(v151));
const v363=v350["tangent_5"];
const v364=Math.fround(__nfNumber(v363) + __nfNumber(v154));
const v365=v350["tangent_6"];
const v366=Math.fround(__nfNumber(v365) + __nfNumber(v157));
const v367=v350["tangent_7"];
const v368=Math.fround(__nfNumber(v367) + __nfNumber(v160));
const v369=v350["tangent_8"];
const v370=Math.fround(__nfNumber(v369) + __nfNumber(v163));
const v371=v350["tangent_9"];
const v372=Math.fround(__nfNumber(v371) + __nfNumber(v166));
const v373=v350["tangent_10"];
const v374=Math.fround(__nfNumber(v373) + __nfNumber(v169));
const v375=v350["tangent_11"];
const v376=Math.fround(__nfNumber(v375) + __nfNumber(v172));
const v378=v131["t"];
const v379=v378["a"];
const v380=v379["value"];
const v381=Math.fround(__nfNumber(v380) - __nfNumber(v136));
const v382=v379["tangent_0"];
const v383=Math.fround(__nfNumber(v382) - __nfNumber(v139));
const v384=v379["tangent_1"];
const v385=Math.fround(__nfNumber(v384) - __nfNumber(v142));
const v386=v379["tangent_2"];
const v387=Math.fround(__nfNumber(v386) - __nfNumber(v145));
const v388=v379["tangent_3"];
const v389=Math.fround(__nfNumber(v388) - __nfNumber(v148));
const v390=v379["tangent_4"];
const v391=Math.fround(__nfNumber(v390) - __nfNumber(v151));
const v392=v379["tangent_5"];
const v393=Math.fround(__nfNumber(v392) - __nfNumber(v154));
const v394=v379["tangent_6"];
const v395=Math.fround(__nfNumber(v394) - __nfNumber(v157));
const v396=v379["tangent_7"];
const v397=Math.fround(__nfNumber(v396) - __nfNumber(v160));
const v398=v379["tangent_8"];
const v399=Math.fround(__nfNumber(v398) - __nfNumber(v163));
const v400=v379["tangent_9"];
const v401=Math.fround(__nfNumber(v400) - __nfNumber(v166));
const v402=v379["tangent_10"];
const v403=Math.fround(__nfNumber(v402) - __nfNumber(v169));
const v404=v379["tangent_11"];
const v405=Math.fround(__nfNumber(v404) - __nfNumber(v172));
const v407=v131["t"];
const v408=v407["b"];
const v409=v408["value"];
const v410=Math.fround(__nfNumber(v409) + __nfNumber(v136));
const v411=v408["tangent_0"];
const v412=Math.fround(__nfNumber(v411) + __nfNumber(v139));
const v413=v408["tangent_1"];
const v414=Math.fround(__nfNumber(v413) + __nfNumber(v142));
const v415=v408["tangent_2"];
const v416=Math.fround(__nfNumber(v415) + __nfNumber(v145));
const v417=v408["tangent_3"];
const v418=Math.fround(__nfNumber(v417) + __nfNumber(v148));
const v419=v408["tangent_4"];
const v420=Math.fround(__nfNumber(v419) + __nfNumber(v151));
const v421=v408["tangent_5"];
const v422=Math.fround(__nfNumber(v421) + __nfNumber(v154));
const v423=v408["tangent_6"];
const v424=Math.fround(__nfNumber(v423) + __nfNumber(v157));
const v425=v408["tangent_7"];
const v426=Math.fround(__nfNumber(v425) + __nfNumber(v160));
const v427=v408["tangent_8"];
const v428=Math.fround(__nfNumber(v427) + __nfNumber(v163));
const v429=v408["tangent_9"];
const v430=Math.fround(__nfNumber(v429) + __nfNumber(v166));
const v431=v408["tangent_10"];
const v432=Math.fround(__nfNumber(v431) + __nfNumber(v169));
const v433=v408["tangent_11"];
const v434=Math.fround(__nfNumber(v433) + __nfNumber(v172));
const v436=v131["u"];
const v437=v436["a"];
const v438=v437["value"];
const v439=Math.fround(__nfNumber(v438) - __nfNumber(v136));
const v440=v437["tangent_0"];
const v441=Math.fround(__nfNumber(v440) - __nfNumber(v139));
const v442=v437["tangent_1"];
const v443=Math.fround(__nfNumber(v442) - __nfNumber(v142));
const v444=v437["tangent_2"];
const v445=Math.fround(__nfNumber(v444) - __nfNumber(v145));
const v446=v437["tangent_3"];
const v447=Math.fround(__nfNumber(v446) - __nfNumber(v148));
const v448=v437["tangent_4"];
const v449=Math.fround(__nfNumber(v448) - __nfNumber(v151));
const v450=v437["tangent_5"];
const v451=Math.fround(__nfNumber(v450) - __nfNumber(v154));
const v452=v437["tangent_6"];
const v453=Math.fround(__nfNumber(v452) - __nfNumber(v157));
const v454=v437["tangent_7"];
const v455=Math.fround(__nfNumber(v454) - __nfNumber(v160));
const v456=v437["tangent_8"];
const v457=Math.fround(__nfNumber(v456) - __nfNumber(v163));
const v458=v437["tangent_9"];
const v459=Math.fround(__nfNumber(v458) - __nfNumber(v166));
const v460=v437["tangent_10"];
const v461=Math.fround(__nfNumber(v460) - __nfNumber(v169));
const v462=v437["tangent_11"];
const v463=Math.fround(__nfNumber(v462) - __nfNumber(v172));
const v465=v131["u"];
const v466=v465["b"];
const v467=v466["value"];
const v468=Math.fround(__nfNumber(v467) + __nfNumber(v136));
const v469=v466["tangent_0"];
const v470=Math.fround(__nfNumber(v469) + __nfNumber(v139));
const v471=v466["tangent_1"];
const v472=Math.fround(__nfNumber(v471) + __nfNumber(v142));
const v473=v466["tangent_2"];
const v474=Math.fround(__nfNumber(v473) + __nfNumber(v145));
const v475=v466["tangent_3"];
const v476=Math.fround(__nfNumber(v475) + __nfNumber(v148));
const v477=v466["tangent_4"];
const v478=Math.fround(__nfNumber(v477) + __nfNumber(v151));
const v479=v466["tangent_5"];
const v480=Math.fround(__nfNumber(v479) + __nfNumber(v154));
const v481=v466["tangent_6"];
const v482=Math.fround(__nfNumber(v481) + __nfNumber(v157));
const v483=v466["tangent_7"];
const v484=Math.fround(__nfNumber(v483) + __nfNumber(v160));
const v485=v466["tangent_8"];
const v486=Math.fround(__nfNumber(v485) + __nfNumber(v163));
const v487=v466["tangent_9"];
const v488=Math.fround(__nfNumber(v487) + __nfNumber(v166));
const v489=v466["tangent_10"];
const v490=Math.fround(__nfNumber(v489) + __nfNumber(v169));
const v491=v466["tangent_11"];
const v492=Math.fround(__nfNumber(v491) + __nfNumber(v172));
const v494=Math.fround(v137 * v137);
const v495=Math.fround(v140 * v137);
const v496=Math.fround(v137 * v140);
const v497=Math.fround(v495 + v496);
const v498=Math.fround(v143 * v137);
const v499=Math.fround(v137 * v143);
const v500=Math.fround(v498 + v499);
const v501=Math.fround(v146 * v137);
const v502=Math.fround(v137 * v146);
const v503=Math.fround(v501 + v502);
const v504=Math.fround(v149 * v137);
const v505=Math.fround(v137 * v149);
const v506=Math.fround(v504 + v505);
const v507=Math.fround(v152 * v137);
const v508=Math.fround(v137 * v152);
const v509=Math.fround(v507 + v508);
const v510=Math.fround(v155 * v137);
const v511=Math.fround(v137 * v155);
const v512=Math.fround(v510 + v511);
const v513=Math.fround(v158 * v137);
const v514=Math.fround(v137 * v158);
const v515=Math.fround(v513 + v514);
const v516=Math.fround(v161 * v137);
const v517=Math.fround(v137 * v161);
const v518=Math.fround(v516 + v517);
const v519=Math.fround(v164 * v137);
const v520=Math.fround(v137 * v164);
const v521=Math.fround(v519 + v520);
const v522=Math.fround(v167 * v137);
const v523=Math.fround(v137 * v167);
const v524=Math.fround(v522 + v523);
const v525=Math.fround(v170 * v137);
const v526=Math.fround(v137 * v170);
const v527=Math.fround(v525 + v526);
const v528=Math.fround(v173 * v137);
const v529=Math.fround(v137 * v173);
const v530=Math.fround(v528 + v529);
const v532=Math.fround(v178 * v178);
const v533=Math.fround(v180 * v178);
const v534=Math.fround(v178 * v180);
const v535=Math.fround(v533 + v534);
const v536=Math.fround(v182 * v178);
const v537=Math.fround(v178 * v182);
const v538=Math.fround(v536 + v537);
const v539=Math.fround(v184 * v178);
const v540=Math.fround(v178 * v184);
const v541=Math.fround(v539 + v540);
const v542=Math.fround(v186 * v178);
const v543=Math.fround(v178 * v186);
const v544=Math.fround(v542 + v543);
const v545=Math.fround(v188 * v178);
const v546=Math.fround(v178 * v188);
const v547=Math.fround(v545 + v546);
const v548=Math.fround(v190 * v178);
const v549=Math.fround(v178 * v190);
const v550=Math.fround(v548 + v549);
const v551=Math.fround(v192 * v178);
const v552=Math.fround(v178 * v192);
const v553=Math.fround(v551 + v552);
const v554=Math.fround(v194 * v178);
const v555=Math.fround(v178 * v194);
const v556=Math.fround(v554 + v555);
const v557=Math.fround(v196 * v178);
const v558=Math.fround(v178 * v196);
const v559=Math.fround(v557 + v558);
const v560=Math.fround(v198 * v178);
const v561=Math.fround(v178 * v198);
const v562=Math.fround(v560 + v561);
const v563=Math.fround(v200 * v178);
const v564=Math.fround(v178 * v200);
const v565=Math.fround(v563 + v564);
const v566=Math.fround(v202 * v178);
const v567=Math.fround(v178 * v202);
const v568=Math.fround(v566 + v567);
const v570=Math.fround(v494 + v532);
const v571=Math.fround(v497 + v535);
const v572=Math.fround(v500 + v538);
const v573=Math.fround(v503 + v541);
const v574=Math.fround(v506 + v544);
const v575=Math.fround(v509 + v547);
const v576=Math.fround(v512 + v550);
const v577=Math.fround(v515 + v553);
const v578=Math.fround(v518 + v556);
const v579=Math.fround(v521 + v559);
const v580=Math.fround(v524 + v562);
const v581=Math.fround(v527 + v565);
const v582=Math.fround(v530 + v568);
const v584=Math.fround(v207 * v207);
const v585=Math.fround(v209 * v207);
const v586=Math.fround(v207 * v209);
const v587=Math.fround(v585 + v586);
const v588=Math.fround(v211 * v207);
const v589=Math.fround(v207 * v211);
const v590=Math.fround(v588 + v589);
const v591=Math.fround(v213 * v207);
const v592=Math.fround(v207 * v213);
const v593=Math.fround(v591 + v592);
const v594=Math.fround(v215 * v207);
const v595=Math.fround(v207 * v215);
const v596=Math.fround(v594 + v595);
const v597=Math.fround(v217 * v207);
const v598=Math.fround(v207 * v217);
const v599=Math.fround(v597 + v598);
const v600=Math.fround(v219 * v207);
const v601=Math.fround(v207 * v219);
const v602=Math.fround(v600 + v601);
const v603=Math.fround(v221 * v207);
const v604=Math.fround(v207 * v221);
const v605=Math.fround(v603 + v604);
const v606=Math.fround(v223 * v207);
const v607=Math.fround(v207 * v223);
const v608=Math.fround(v606 + v607);
const v609=Math.fround(v225 * v207);
const v610=Math.fround(v207 * v225);
const v611=Math.fround(v609 + v610);
const v612=Math.fround(v227 * v207);
const v613=Math.fround(v207 * v227);
const v614=Math.fround(v612 + v613);
const v615=Math.fround(v229 * v207);
const v616=Math.fround(v207 * v229);
const v617=Math.fround(v615 + v616);
const v618=Math.fround(v231 * v207);
const v619=Math.fround(v207 * v231);
const v620=Math.fround(v618 + v619);
const v622=Math.fround(v570 + v584);
const v623=Math.fround(v571 + v587);
const v624=Math.fround(v572 + v590);
const v625=Math.fround(v573 + v593);
const v626=Math.fround(v574 + v596);
const v627=Math.fround(v575 + v599);
const v628=Math.fround(v576 + v602);
const v629=Math.fround(v577 + v605);
const v630=Math.fround(v578 + v608);
const v631=Math.fround(v579 + v611);
const v632=Math.fround(v580 + v614);
const v633=Math.fround(v581 + v617);
const v634=Math.fround(v582 + v620);
const v636=Math.fround(v236 * v236);
const v637=Math.fround(v238 * v236);
const v638=Math.fround(v236 * v238);
const v639=Math.fround(v637 + v638);
const v640=Math.fround(v240 * v236);
const v641=Math.fround(v236 * v240);
const v642=Math.fround(v640 + v641);
const v643=Math.fround(v242 * v236);
const v644=Math.fround(v236 * v242);
const v645=Math.fround(v643 + v644);
const v646=Math.fround(v244 * v236);
const v647=Math.fround(v236 * v244);
const v648=Math.fround(v646 + v647);
const v649=Math.fround(v246 * v236);
const v650=Math.fround(v236 * v246);
const v651=Math.fround(v649 + v650);
const v652=Math.fround(v248 * v236);
const v653=Math.fround(v236 * v248);
const v654=Math.fround(v652 + v653);
const v655=Math.fround(v250 * v236);
const v656=Math.fround(v236 * v250);
const v657=Math.fround(v655 + v656);
const v658=Math.fround(v252 * v236);
const v659=Math.fround(v236 * v252);
const v660=Math.fround(v658 + v659);
const v661=Math.fround(v254 * v236);
const v662=Math.fround(v236 * v254);
const v663=Math.fround(v661 + v662);
const v664=Math.fround(v256 * v236);
const v665=Math.fround(v236 * v256);
const v666=Math.fround(v664 + v665);
const v667=Math.fround(v258 * v236);
const v668=Math.fround(v236 * v258);
const v669=Math.fround(v667 + v668);
const v670=Math.fround(v260 * v236);
const v671=Math.fround(v236 * v260);
const v672=Math.fround(v670 + v671);
const v674=Math.fround(v622 + v636);
const v675=Math.fround(v623 + v639);
const v676=Math.fround(v624 + v642);
const v677=Math.fround(v625 + v645);
const v678=Math.fround(v626 + v648);
const v679=Math.fround(v627 + v651);
const v680=Math.fround(v628 + v654);
const v681=Math.fround(v629 + v657);
const v682=Math.fround(v630 + v660);
const v683=Math.fround(v631 + v663);
const v684=Math.fround(v632 + v666);
const v685=Math.fround(v633 + v669);
const v686=Math.fround(v634 + v672);
const v688=Math.fround(v265 * v265);
const v689=Math.fround(v267 * v265);
const v690=Math.fround(v265 * v267);
const v691=Math.fround(v689 + v690);
const v692=Math.fround(v269 * v265);
const v693=Math.fround(v265 * v269);
const v694=Math.fround(v692 + v693);
const v695=Math.fround(v271 * v265);
const v696=Math.fround(v265 * v271);
const v697=Math.fround(v695 + v696);
const v698=Math.fround(v273 * v265);
const v699=Math.fround(v265 * v273);
const v700=Math.fround(v698 + v699);
const v701=Math.fround(v275 * v265);
const v702=Math.fround(v265 * v275);
const v703=Math.fround(v701 + v702);
const v704=Math.fround(v277 * v265);
const v705=Math.fround(v265 * v277);
const v706=Math.fround(v704 + v705);
const v707=Math.fround(v279 * v265);
const v708=Math.fround(v265 * v279);
const v709=Math.fround(v707 + v708);
const v710=Math.fround(v281 * v265);
const v711=Math.fround(v265 * v281);
const v712=Math.fround(v710 + v711);
const v713=Math.fround(v283 * v265);
const v714=Math.fround(v265 * v283);
const v715=Math.fround(v713 + v714);
const v716=Math.fround(v285 * v265);
const v717=Math.fround(v265 * v285);
const v718=Math.fround(v716 + v717);
const v719=Math.fround(v287 * v265);
const v720=Math.fround(v265 * v287);
const v721=Math.fround(v719 + v720);
const v722=Math.fround(v289 * v265);
const v723=Math.fround(v265 * v289);
const v724=Math.fround(v722 + v723);
const v726=Math.fround(v674 + v688);
const v727=Math.fround(v675 + v691);
const v728=Math.fround(v676 + v694);
const v729=Math.fround(v677 + v697);
const v730=Math.fround(v678 + v700);
const v731=Math.fround(v679 + v703);
const v732=Math.fround(v680 + v706);
const v733=Math.fround(v681 + v709);
const v734=Math.fround(v682 + v712);
const v735=Math.fround(v683 + v715);
const v736=Math.fround(v684 + v718);
const v737=Math.fround(v685 + v721);
const v738=Math.fround(v686 + v724);
const v740=Math.fround(v294 * v294);
const v741=Math.fround(v296 * v294);
const v742=Math.fround(v294 * v296);
const v743=Math.fround(v741 + v742);
const v744=Math.fround(v298 * v294);
const v745=Math.fround(v294 * v298);
const v746=Math.fround(v744 + v745);
const v747=Math.fround(v300 * v294);
const v748=Math.fround(v294 * v300);
const v749=Math.fround(v747 + v748);
const v750=Math.fround(v302 * v294);
const v751=Math.fround(v294 * v302);
const v752=Math.fround(v750 + v751);
const v753=Math.fround(v304 * v294);
const v754=Math.fround(v294 * v304);
const v755=Math.fround(v753 + v754);
const v756=Math.fround(v306 * v294);
const v757=Math.fround(v294 * v306);
const v758=Math.fround(v756 + v757);
const v759=Math.fround(v308 * v294);
const v760=Math.fround(v294 * v308);
const v761=Math.fround(v759 + v760);
const v762=Math.fround(v310 * v294);
const v763=Math.fround(v294 * v310);
const v764=Math.fround(v762 + v763);
const v765=Math.fround(v312 * v294);
const v766=Math.fround(v294 * v312);
const v767=Math.fround(v765 + v766);
const v768=Math.fround(v314 * v294);
const v769=Math.fround(v294 * v314);
const v770=Math.fround(v768 + v769);
const v771=Math.fround(v316 * v294);
const v772=Math.fround(v294 * v316);
const v773=Math.fround(v771 + v772);
const v774=Math.fround(v318 * v294);
const v775=Math.fround(v294 * v318);
const v776=Math.fround(v774 + v775);
const v778=Math.fround(v726 + v740);
const v779=Math.fround(v727 + v743);
const v780=Math.fround(v728 + v746);
const v781=Math.fround(v729 + v749);
const v782=Math.fround(v730 + v752);
const v783=Math.fround(v731 + v755);
const v784=Math.fround(v732 + v758);
const v785=Math.fround(v733 + v761);
const v786=Math.fround(v734 + v764);
const v787=Math.fround(v735 + v767);
const v788=Math.fround(v736 + v770);
const v789=Math.fround(v737 + v773);
const v790=Math.fround(v738 + v776);
const v792=Math.fround(v323 * v323);
const v793=Math.fround(v325 * v323);
const v794=Math.fround(v323 * v325);
const v795=Math.fround(v793 + v794);
const v796=Math.fround(v327 * v323);
const v797=Math.fround(v323 * v327);
const v798=Math.fround(v796 + v797);
const v799=Math.fround(v329 * v323);
const v800=Math.fround(v323 * v329);
const v801=Math.fround(v799 + v800);
const v802=Math.fround(v331 * v323);
const v803=Math.fround(v323 * v331);
const v804=Math.fround(v802 + v803);
const v805=Math.fround(v333 * v323);
const v806=Math.fround(v323 * v333);
const v807=Math.fround(v805 + v806);
const v808=Math.fround(v335 * v323);
const v809=Math.fround(v323 * v335);
const v810=Math.fround(v808 + v809);
const v811=Math.fround(v337 * v323);
const v812=Math.fround(v323 * v337);
const v813=Math.fround(v811 + v812);
const v814=Math.fround(v339 * v323);
const v815=Math.fround(v323 * v339);
const v816=Math.fround(v814 + v815);
const v817=Math.fround(v341 * v323);
const v818=Math.fround(v323 * v341);
const v819=Math.fround(v817 + v818);
const v820=Math.fround(v343 * v323);
const v821=Math.fround(v323 * v343);
const v822=Math.fround(v820 + v821);
const v823=Math.fround(v345 * v323);
const v824=Math.fround(v323 * v345);
const v825=Math.fround(v823 + v824);
const v826=Math.fround(v347 * v323);
const v827=Math.fround(v323 * v347);
const v828=Math.fround(v826 + v827);
const v830=Math.fround(v778 + v792);
const v831=Math.fround(v779 + v795);
const v832=Math.fround(v780 + v798);
const v833=Math.fround(v781 + v801);
const v834=Math.fround(v782 + v804);
const v835=Math.fround(v783 + v807);
const v836=Math.fround(v784 + v810);
const v837=Math.fround(v785 + v813);
const v838=Math.fround(v786 + v816);
const v839=Math.fround(v787 + v819);
const v840=Math.fround(v788 + v822);
const v841=Math.fround(v789 + v825);
const v842=Math.fround(v790 + v828);
const v844=Math.fround(v352 * v352);
const v845=Math.fround(v354 * v352);
const v846=Math.fround(v352 * v354);
const v847=Math.fround(v845 + v846);
const v848=Math.fround(v356 * v352);
const v849=Math.fround(v352 * v356);
const v850=Math.fround(v848 + v849);
const v851=Math.fround(v358 * v352);
const v852=Math.fround(v352 * v358);
const v853=Math.fround(v851 + v852);
const v854=Math.fround(v360 * v352);
const v855=Math.fround(v352 * v360);
const v856=Math.fround(v854 + v855);
const v857=Math.fround(v362 * v352);
const v858=Math.fround(v352 * v362);
const v859=Math.fround(v857 + v858);
const v860=Math.fround(v364 * v352);
const v861=Math.fround(v352 * v364);
const v862=Math.fround(v860 + v861);
const v863=Math.fround(v366 * v352);
const v864=Math.fround(v352 * v366);
const v865=Math.fround(v863 + v864);
const v866=Math.fround(v368 * v352);
const v867=Math.fround(v352 * v368);
const v868=Math.fround(v866 + v867);
const v869=Math.fround(v370 * v352);
const v870=Math.fround(v352 * v370);
const v871=Math.fround(v869 + v870);
const v872=Math.fround(v372 * v352);
const v873=Math.fround(v352 * v372);
const v874=Math.fround(v872 + v873);
const v875=Math.fround(v374 * v352);
const v876=Math.fround(v352 * v374);
const v877=Math.fround(v875 + v876);
const v878=Math.fround(v376 * v352);
const v879=Math.fround(v352 * v376);
const v880=Math.fround(v878 + v879);
const v882=Math.fround(v830 + v844);
const v883=Math.fround(v831 + v847);
const v884=Math.fround(v832 + v850);
const v885=Math.fround(v833 + v853);
const v886=Math.fround(v834 + v856);
const v887=Math.fround(v835 + v859);
const v888=Math.fround(v836 + v862);
const v889=Math.fround(v837 + v865);
const v890=Math.fround(v838 + v868);
const v891=Math.fround(v839 + v871);
const v892=Math.fround(v840 + v874);
const v893=Math.fround(v841 + v877);
const v894=Math.fround(v842 + v880);
const v896=Math.fround(v381 * v381);
const v897=Math.fround(v383 * v381);
const v898=Math.fround(v381 * v383);
const v899=Math.fround(v897 + v898);
const v900=Math.fround(v385 * v381);
const v901=Math.fround(v381 * v385);
const v902=Math.fround(v900 + v901);
const v903=Math.fround(v387 * v381);
const v904=Math.fround(v381 * v387);
const v905=Math.fround(v903 + v904);
const v906=Math.fround(v389 * v381);
const v907=Math.fround(v381 * v389);
const v908=Math.fround(v906 + v907);
const v909=Math.fround(v391 * v381);
const v910=Math.fround(v381 * v391);
const v911=Math.fround(v909 + v910);
const v912=Math.fround(v393 * v381);
const v913=Math.fround(v381 * v393);
const v914=Math.fround(v912 + v913);
const v915=Math.fround(v395 * v381);
const v916=Math.fround(v381 * v395);
const v917=Math.fround(v915 + v916);
const v918=Math.fround(v397 * v381);
const v919=Math.fround(v381 * v397);
const v920=Math.fround(v918 + v919);
const v921=Math.fround(v399 * v381);
const v922=Math.fround(v381 * v399);
const v923=Math.fround(v921 + v922);
const v924=Math.fround(v401 * v381);
const v925=Math.fround(v381 * v401);
const v926=Math.fround(v924 + v925);
const v927=Math.fround(v403 * v381);
const v928=Math.fround(v381 * v403);
const v929=Math.fround(v927 + v928);
const v930=Math.fround(v405 * v381);
const v931=Math.fround(v381 * v405);
const v932=Math.fround(v930 + v931);
const v934=Math.fround(v882 + v896);
const v935=Math.fround(v883 + v899);
const v936=Math.fround(v884 + v902);
const v937=Math.fround(v885 + v905);
const v938=Math.fround(v886 + v908);
const v939=Math.fround(v887 + v911);
const v940=Math.fround(v888 + v914);
const v941=Math.fround(v889 + v917);
const v942=Math.fround(v890 + v920);
const v943=Math.fround(v891 + v923);
const v944=Math.fround(v892 + v926);
const v945=Math.fround(v893 + v929);
const v946=Math.fround(v894 + v932);
const v948=Math.fround(v410 * v410);
const v949=Math.fround(v412 * v410);
const v950=Math.fround(v410 * v412);
const v951=Math.fround(v949 + v950);
const v952=Math.fround(v414 * v410);
const v953=Math.fround(v410 * v414);
const v954=Math.fround(v952 + v953);
const v955=Math.fround(v416 * v410);
const v956=Math.fround(v410 * v416);
const v957=Math.fround(v955 + v956);
const v958=Math.fround(v418 * v410);
const v959=Math.fround(v410 * v418);
const v960=Math.fround(v958 + v959);
const v961=Math.fround(v420 * v410);
const v962=Math.fround(v410 * v420);
const v963=Math.fround(v961 + v962);
const v964=Math.fround(v422 * v410);
const v965=Math.fround(v410 * v422);
const v966=Math.fround(v964 + v965);
const v967=Math.fround(v424 * v410);
const v968=Math.fround(v410 * v424);
const v969=Math.fround(v967 + v968);
const v970=Math.fround(v426 * v410);
const v971=Math.fround(v410 * v426);
const v972=Math.fround(v970 + v971);
const v973=Math.fround(v428 * v410);
const v974=Math.fround(v410 * v428);
const v975=Math.fround(v973 + v974);
const v976=Math.fround(v430 * v410);
const v977=Math.fround(v410 * v430);
const v978=Math.fround(v976 + v977);
const v979=Math.fround(v432 * v410);
const v980=Math.fround(v410 * v432);
const v981=Math.fround(v979 + v980);
const v982=Math.fround(v434 * v410);
const v983=Math.fround(v410 * v434);
const v984=Math.fround(v982 + v983);
const v986=Math.fround(v934 + v948);
const v987=Math.fround(v935 + v951);
const v988=Math.fround(v936 + v954);
const v989=Math.fround(v937 + v957);
const v990=Math.fround(v938 + v960);
const v991=Math.fround(v939 + v963);
const v992=Math.fround(v940 + v966);
const v993=Math.fround(v941 + v969);
const v994=Math.fround(v942 + v972);
const v995=Math.fround(v943 + v975);
const v996=Math.fround(v944 + v978);
const v997=Math.fround(v945 + v981);
const v998=Math.fround(v946 + v984);
const v1000=Math.fround(v439 * v439);
const v1001=Math.fround(v441 * v439);
const v1002=Math.fround(v439 * v441);
const v1003=Math.fround(v1001 + v1002);
const v1004=Math.fround(v443 * v439);
const v1005=Math.fround(v439 * v443);
const v1006=Math.fround(v1004 + v1005);
const v1007=Math.fround(v445 * v439);
const v1008=Math.fround(v439 * v445);
const v1009=Math.fround(v1007 + v1008);
const v1010=Math.fround(v447 * v439);
const v1011=Math.fround(v439 * v447);
const v1012=Math.fround(v1010 + v1011);
const v1013=Math.fround(v449 * v439);
const v1014=Math.fround(v439 * v449);
const v1015=Math.fround(v1013 + v1014);
const v1016=Math.fround(v451 * v439);
const v1017=Math.fround(v439 * v451);
const v1018=Math.fround(v1016 + v1017);
const v1019=Math.fround(v453 * v439);
const v1020=Math.fround(v439 * v453);
const v1021=Math.fround(v1019 + v1020);
const v1022=Math.fround(v455 * v439);
const v1023=Math.fround(v439 * v455);
const v1024=Math.fround(v1022 + v1023);
const v1025=Math.fround(v457 * v439);
const v1026=Math.fround(v439 * v457);
const v1027=Math.fround(v1025 + v1026);
const v1028=Math.fround(v459 * v439);
const v1029=Math.fround(v439 * v459);
const v1030=Math.fround(v1028 + v1029);
const v1031=Math.fround(v461 * v439);
const v1032=Math.fround(v439 * v461);
const v1033=Math.fround(v1031 + v1032);
const v1034=Math.fround(v463 * v439);
const v1035=Math.fround(v439 * v463);
const v1036=Math.fround(v1034 + v1035);
const v1038=Math.fround(v986 + v1000);
const v1039=Math.fround(v987 + v1003);
const v1040=Math.fround(v988 + v1006);
const v1041=Math.fround(v989 + v1009);
const v1042=Math.fround(v990 + v1012);
const v1043=Math.fround(v991 + v1015);
const v1044=Math.fround(v992 + v1018);
const v1045=Math.fround(v993 + v1021);
const v1046=Math.fround(v994 + v1024);
const v1047=Math.fround(v995 + v1027);
const v1048=Math.fround(v996 + v1030);
const v1049=Math.fround(v997 + v1033);
const v1050=Math.fround(v998 + v1036);
const v1052=Math.fround(v468 * v468);
const v1053=Math.fround(v470 * v468);
const v1054=Math.fround(v468 * v470);
const v1055=Math.fround(v1053 + v1054);
const v1056=Math.fround(v472 * v468);
const v1057=Math.fround(v468 * v472);
const v1058=Math.fround(v1056 + v1057);
const v1059=Math.fround(v474 * v468);
const v1060=Math.fround(v468 * v474);
const v1061=Math.fround(v1059 + v1060);
const v1062=Math.fround(v476 * v468);
const v1063=Math.fround(v468 * v476);
const v1064=Math.fround(v1062 + v1063);
const v1065=Math.fround(v478 * v468);
const v1066=Math.fround(v468 * v478);
const v1067=Math.fround(v1065 + v1066);
const v1068=Math.fround(v480 * v468);
const v1069=Math.fround(v468 * v480);
const v1070=Math.fround(v1068 + v1069);
const v1071=Math.fround(v482 * v468);
const v1072=Math.fround(v468 * v482);
const v1073=Math.fround(v1071 + v1072);
const v1074=Math.fround(v484 * v468);
const v1075=Math.fround(v468 * v484);
const v1076=Math.fround(v1074 + v1075);
const v1077=Math.fround(v486 * v468);
const v1078=Math.fround(v468 * v486);
const v1079=Math.fround(v1077 + v1078);
const v1080=Math.fround(v488 * v468);
const v1081=Math.fround(v468 * v488);
const v1082=Math.fround(v1080 + v1081);
const v1083=Math.fround(v490 * v468);
const v1084=Math.fround(v468 * v490);
const v1085=Math.fround(v1083 + v1084);
const v1086=Math.fround(v492 * v468);
const v1087=Math.fround(v468 * v492);
const v1088=Math.fround(v1086 + v1087);
const v1090=Math.fround(v1038 + v1052);
const v1091=Math.fround(v1039 + v1055);
const v1092=Math.fround(v1040 + v1058);
const v1093=Math.fround(v1041 + v1061);
const v1094=Math.fround(v1042 + v1064);
const v1095=Math.fround(v1043 + v1067);
const v1096=Math.fround(v1044 + v1070);
const v1097=Math.fround(v1045 + v1073);
const v1098=Math.fround(v1046 + v1076);
const v1099=Math.fround(v1047 + v1079);
const v1100=Math.fround(v1048 + v1082);
const v1101=Math.fround(v1049 + v1085);
const v1102=Math.fround(v1050 + v1088);
return ({["value"]:v1090,["tangent_0"]:v1091,["tangent_1"]:v1092,["tangent_2"]:v1093,["tangent_3"]:v1094,["tangent_4"]:v1095,["tangent_5"]:v1096,["tangent_6"]:v1097,["tangent_7"]:v1098,["tangent_8"]:v1099,["tangent_9"]:v1100,["tangent_10"]:v1101,["tangent_11"]:v1102});}
function __fn12(v1103,v1104){
const v1105=v1103["p"];
const v1106=v1105["a"];
const v1107=1.0;
const v1108=0.0;
const v1110=v1103["p"];
const v1111=v1110["b"];
const v1114=v1103["q"];
const v1115=v1114["a"];
const v1117=v1103["q"];
const v1118=v1117["b"];
const v1121=v1103["r"];
const v1122=v1121["a"];
const v1124=v1103["r"];
const v1125=v1124["b"];
const v1128=v1103["s"];
const v1129=v1128["a"];
const v1131=v1103["s"];
const v1132=v1131["b"];
const v1135=v1103["t"];
const v1136=v1135["a"];
const v1138=v1103["t"];
const v1139=v1138["b"];
const v1142=v1103["u"];
const v1143=v1142["a"];
const v1145=v1103["u"];
const v1146=v1145["b"];
const v1151=__record0(v1106,v1111,v1115,v1118,v1122,v1125,v1129,v1132,v1136,v1139,v1143,v1146,v1104);
const v1152=v1151["tangent_0"];
const v1153=v1151["tangent_1"];
const v1155=v1151["tangent_2"];
const v1156=v1151["tangent_3"];
const v1158=v1151["tangent_4"];
const v1159=v1151["tangent_5"];
const v1161=v1151["tangent_6"];
const v1162=v1151["tangent_7"];
const v1164=v1151["tangent_8"];
const v1165=v1151["tangent_9"];
const v1167=v1151["tangent_10"];
const v1168=v1151["tangent_11"];
return ({["p"]:({["a"]:v1152,["b"]:v1153}),["q"]:({["a"]:v1155,["b"]:v1156}),["r"]:({["a"]:v1158,["b"]:v1159}),["s"]:({["a"]:v1161,["b"]:v1162}),["t"]:({["a"]:v1164,["b"]:v1165}),["u"]:({["a"]:v1167,["b"]:v1168})});}
function __fn13(v1170,v1171){
const v1172=v1170["value"];
const v1173=v1171["value"];
const v1174=Math.fround(__nfNumber(v1172) - __nfNumber(v1173));
const v1175=v1170["tangent"];
const v1176=v1171["tangent"];
const v1177=Math.fround(__nfNumber(v1175) - __nfNumber(v1176));
return ({["value"]:v1174,["tangent"]:v1177});}
function __fn14(v1178,v1179){
const v1180=v1178["value"];
const v1181=v1179["value"];
const v1182=Math.fround(__nfNumber(v1180) + __nfNumber(v1181));
const v1183=v1178["tangent"];
const v1184=v1179["tangent"];
const v1185=Math.fround(__nfNumber(v1183) + __nfNumber(v1184));
return ({["value"]:v1182,["tangent"]:v1185});}
function __fn15(v1186,v1187){
const v1188=v1186["value"];
const v1189=v1187["value"];
const v1190=Math.fround(__nfNumber(v1188) * __nfNumber(v1189));
const v1191=v1186["tangent"];
const v1192=Math.fround(__nfNumber(v1191) * __nfNumber(v1189));
const v1193=v1187["tangent"];
const v1194=Math.fround(__nfNumber(v1188) * __nfNumber(v1193));
const v1195=Math.fround(v1192 + v1194);
return ({["value"]:v1190,["tangent"]:v1195});}
function __fn16(v1196,v1197){
const v1198=v1196["p"];
const v1199=v1198["a"];
const v1200=__fn13(v1199,v1197);
const v1201=v1196["p"];
const v1202=v1201["b"];
const v1203=__fn14(v1202,v1197);
const v1204=v1196["q"];
const v1205=v1204["a"];
const v1206=__fn13(v1205,v1197);
const v1207=v1196["q"];
const v1208=v1207["b"];
const v1209=__fn14(v1208,v1197);
const v1210=v1196["r"];
const v1211=v1210["a"];
const v1212=__fn13(v1211,v1197);
const v1213=v1196["r"];
const v1214=v1213["b"];
const v1215=__fn14(v1214,v1197);
const v1216=v1196["s"];
const v1217=v1216["a"];
const v1218=__fn13(v1217,v1197);
const v1219=v1196["s"];
const v1220=v1219["b"];
const v1221=__fn14(v1220,v1197);
const v1222=v1196["t"];
const v1223=v1222["a"];
const v1224=__fn13(v1223,v1197);
const v1225=v1196["t"];
const v1226=v1225["b"];
const v1227=__fn14(v1226,v1197);
const v1228=v1196["u"];
const v1229=v1228["a"];
const v1230=__fn13(v1229,v1197);
const v1231=v1196["u"];
const v1232=v1231["b"];
const v1233=__fn14(v1232,v1197);
const v1234=__fn15(v1200,v1200);
const v1235=__fn15(v1203,v1203);
const v1236=__fn14(v1234,v1235);
const v1237=__fn15(v1206,v1206);
const v1238=__fn14(v1236,v1237);
const v1239=__fn15(v1209,v1209);
const v1240=__fn14(v1238,v1239);
const v1241=__fn15(v1212,v1212);
const v1242=__fn14(v1240,v1241);
const v1243=__fn15(v1215,v1215);
const v1244=__fn14(v1242,v1243);
const v1245=__fn15(v1218,v1218);
const v1246=__fn14(v1244,v1245);
const v1247=__fn15(v1221,v1221);
const v1248=__fn14(v1246,v1247);
const v1249=__fn15(v1224,v1224);
const v1250=__fn14(v1248,v1249);
const v1251=__fn15(v1227,v1227);
const v1252=__fn14(v1250,v1251);
const v1253=__fn15(v1230,v1230);
const v1254=__fn14(v1252,v1253);
const v1255=__fn15(v1233,v1233);
return __fn14(v1254,v1255);}
function __fn17(v1256,v1257,v1258){
const v1259=v1256["p"];
const v1260=v1259["a"];
const v1261=v1257["p"];
const v1262=v1261["a"];
const v1264=v1256["p"];
const v1265=v1264["b"];
const v1266=v1257["p"];
const v1267=v1266["b"];
const v1270=v1256["q"];
const v1271=v1270["a"];
const v1272=v1257["q"];
const v1273=v1272["a"];
const v1275=v1256["q"];
const v1276=v1275["b"];
const v1277=v1257["q"];
const v1278=v1277["b"];
const v1281=v1256["r"];
const v1282=v1281["a"];
const v1283=v1257["r"];
const v1284=v1283["a"];
const v1286=v1256["r"];
const v1287=v1286["b"];
const v1288=v1257["r"];
const v1289=v1288["b"];
const v1292=v1256["s"];
const v1293=v1292["a"];
const v1294=v1257["s"];
const v1295=v1294["a"];
const v1297=v1256["s"];
const v1298=v1297["b"];
const v1299=v1257["s"];
const v1300=v1299["b"];
const v1303=v1256["t"];
const v1304=v1303["a"];
const v1305=v1257["t"];
const v1306=v1305["a"];
const v1308=v1256["t"];
const v1309=v1308["b"];
const v1310=v1257["t"];
const v1311=v1310["b"];
const v1314=v1256["u"];
const v1315=v1314["a"];
const v1316=v1257["u"];
const v1317=v1316["a"];
const v1319=v1256["u"];
const v1320=v1319["b"];
const v1321=v1257["u"];
const v1322=v1321["b"];
const v1326=0.0;
const v1330=Math.fround(__nfNumber(v1260) - __nfNumber(v1258));
const v1331=Math.fround(__nfNumber(v1262) - v1326);
const v1335=Math.fround(__nfNumber(v1265) + __nfNumber(v1258));
const v1336=Math.fround(__nfNumber(v1267) + v1326);
const v1340=Math.fround(__nfNumber(v1271) - __nfNumber(v1258));
const v1341=Math.fround(__nfNumber(v1273) - v1326);
const v1345=Math.fround(__nfNumber(v1276) + __nfNumber(v1258));
const v1346=Math.fround(__nfNumber(v1278) + v1326);
const v1350=Math.fround(__nfNumber(v1282) - __nfNumber(v1258));
const v1351=Math.fround(__nfNumber(v1284) - v1326);
const v1355=Math.fround(__nfNumber(v1287) + __nfNumber(v1258));
const v1356=Math.fround(__nfNumber(v1289) + v1326);
const v1360=Math.fround(__nfNumber(v1293) - __nfNumber(v1258));
const v1361=Math.fround(__nfNumber(v1295) - v1326);
const v1365=Math.fround(__nfNumber(v1298) + __nfNumber(v1258));
const v1366=Math.fround(__nfNumber(v1300) + v1326);
const v1370=Math.fround(__nfNumber(v1304) - __nfNumber(v1258));
const v1371=Math.fround(__nfNumber(v1306) - v1326);
const v1375=Math.fround(__nfNumber(v1309) + __nfNumber(v1258));
const v1376=Math.fround(__nfNumber(v1311) + v1326);
const v1380=Math.fround(__nfNumber(v1315) - __nfNumber(v1258));
const v1381=Math.fround(__nfNumber(v1317) - v1326);
const v1385=Math.fround(__nfNumber(v1320) + __nfNumber(v1258));
const v1386=Math.fround(__nfNumber(v1322) + v1326);
const v1390=__record1(v1330,v1331,v1330,v1331);
const v1393=__record1(v1335,v1336,v1335,v1336);
const v1394=__fn14(v1390,v1393);
const v1397=__record1(v1340,v1341,v1340,v1341);
const v1398=__fn14(v1394,v1397);
const v1401=__record1(v1345,v1346,v1345,v1346);
const v1402=__fn14(v1398,v1401);
const v1405=__record1(v1350,v1351,v1350,v1351);
const v1406=__fn14(v1402,v1405);
const v1409=Math.fround(v1355 * v1355);
const v1410=Math.fround(v1356 * v1355);
const v1411=Math.fround(v1355 * v1356);
const v1412=Math.fround(v1410 + v1411);
const v1414=v1406["value"];
const v1415=Math.fround(__nfNumber(v1414) + v1409);
const v1416=v1406["tangent"];
const v1417=Math.fround(__nfNumber(v1416) + v1412);
const v1421=Math.fround(v1360 * v1360);
const v1422=Math.fround(v1361 * v1360);
const v1423=Math.fround(v1360 * v1361);
const v1424=Math.fround(v1422 + v1423);
const v1426=Math.fround(v1415 + v1421);
const v1427=Math.fround(v1417 + v1424);
const v1431=Math.fround(v1365 * v1365);
const v1432=Math.fround(v1366 * v1365);
const v1433=Math.fround(v1365 * v1366);
const v1434=Math.fround(v1432 + v1433);
const v1436=Math.fround(v1426 + v1431);
const v1437=Math.fround(v1427 + v1434);
const v1441=Math.fround(v1370 * v1370);
const v1442=Math.fround(v1371 * v1370);
const v1443=Math.fround(v1370 * v1371);
const v1444=Math.fround(v1442 + v1443);
const v1446=Math.fround(v1436 + v1441);
const v1447=Math.fround(v1437 + v1444);
const v1451=Math.fround(v1375 * v1375);
const v1452=Math.fround(v1376 * v1375);
const v1453=Math.fround(v1375 * v1376);
const v1454=Math.fround(v1452 + v1453);
const v1456=Math.fround(v1446 + v1451);
const v1457=Math.fround(v1447 + v1454);
const v1461=Math.fround(v1380 * v1380);
const v1462=Math.fround(v1381 * v1380);
const v1463=Math.fround(v1380 * v1381);
const v1464=Math.fround(v1462 + v1463);
const v1466=Math.fround(v1456 + v1461);
const v1467=Math.fround(v1457 + v1464);
const v1471=Math.fround(v1385 * v1385);
const v1472=Math.fround(v1386 * v1385);
const v1473=Math.fround(v1385 * v1386);
const v1474=Math.fround(v1472 + v1473);
const v1476=Math.fround(v1466 + v1471);
const v1477=Math.fround(v1467 + v1474);
const v1478=({["value"]:v1476,["tangent"]:v1477});
return v1477;}
function __record0(v2831,v2832,v2833,v2834,v2835,v2836,v2837,v2838,v2839,v2840,v2841,v2842,v2843){
const v2844=1.0;
const v2845=0.0;
const v2867=Math.fround(__nfNumber(v2831) - __nfNumber(v2843));
const v2868=Math.fround(v2844 - v2845);
const v2869=Math.fround(v2845 - v2845);
const v2872=Math.fround(__nfNumber(v2832) + __nfNumber(v2843));
const v2873=Math.fround(v2845 + v2845);
const v2874=Math.fround(v2844 + v2845);
const v2877=Math.fround(__nfNumber(v2833) - __nfNumber(v2843));
const v2880=Math.fround(__nfNumber(v2834) + __nfNumber(v2843));
const v2883=Math.fround(__nfNumber(v2835) - __nfNumber(v2843));
const v2886=Math.fround(__nfNumber(v2836) + __nfNumber(v2843));
const v2889=Math.fround(__nfNumber(v2837) - __nfNumber(v2843));
const v2892=Math.fround(__nfNumber(v2838) + __nfNumber(v2843));
const v2895=Math.fround(__nfNumber(v2839) - __nfNumber(v2843));
const v2898=Math.fround(__nfNumber(v2840) + __nfNumber(v2843));
const v2901=Math.fround(__nfNumber(v2841) - __nfNumber(v2843));
const v2904=Math.fround(__nfNumber(v2842) + __nfNumber(v2843));
const v2906=Math.fround(v2867 * v2867);
const v2907=Math.fround(v2868 * v2867);
const v2908=Math.fround(v2867 * v2868);
const v2909=Math.fround(v2907 + v2908);
const v2910=Math.fround(v2869 * v2867);
const v2911=Math.fround(v2867 * v2869);
const v2912=Math.fround(v2910 + v2911);
const v2914=Math.fround(v2872 * v2872);
const v2915=Math.fround(v2873 * v2872);
const v2916=Math.fround(v2872 * v2873);
const v2917=Math.fround(v2915 + v2916);
const v2918=Math.fround(v2874 * v2872);
const v2919=Math.fround(v2872 * v2874);
const v2920=Math.fround(v2918 + v2919);
const v2922=Math.fround(v2906 + v2914);
const v2923=Math.fround(v2909 + v2917);
const v2924=Math.fround(v2912 + v2920);
const v2925=Math.fround(v2912 + v2917);
const v2927=Math.fround(v2877 * v2877);
const v2928=Math.fround(v2869 * v2877);
const v2929=Math.fround(v2877 * v2869);
const v2930=Math.fround(v2928 + v2929);
const v2931=Math.fround(v2868 * v2877);
const v2932=Math.fround(v2877 * v2868);
const v2933=Math.fround(v2931 + v2932);
const v2935=Math.fround(v2922 + v2927);
const v2936=Math.fround(v2923 + v2930);
const v2937=Math.fround(v2924 + v2930);
const v2938=Math.fround(v2925 + v2933);
const v2939=Math.fround(v2925 + v2930);
const v2941=Math.fround(v2880 * v2880);
const v2942=Math.fround(v2873 * v2880);
const v2943=Math.fround(v2880 * v2873);
const v2944=Math.fround(v2942 + v2943);
const v2945=Math.fround(v2874 * v2880);
const v2946=Math.fround(v2880 * v2874);
const v2947=Math.fround(v2945 + v2946);
const v2949=Math.fround(v2935 + v2941);
const v2950=Math.fround(v2936 + v2944);
const v2951=Math.fround(v2937 + v2944);
const v2952=Math.fround(v2938 + v2944);
const v2953=Math.fround(v2939 + v2947);
const v2954=Math.fround(v2939 + v2944);
const v2956=Math.fround(v2883 * v2883);
const v2957=Math.fround(v2869 * v2883);
const v2958=Math.fround(v2883 * v2869);
const v2959=Math.fround(v2957 + v2958);
const v2960=Math.fround(v2868 * v2883);
const v2961=Math.fround(v2883 * v2868);
const v2962=Math.fround(v2960 + v2961);
const v2964=Math.fround(v2949 + v2956);
const v2965=Math.fround(v2950 + v2959);
const v2966=Math.fround(v2951 + v2959);
const v2967=Math.fround(v2952 + v2959);
const v2968=Math.fround(v2953 + v2959);
const v2969=Math.fround(v2954 + v2962);
const v2970=Math.fround(v2954 + v2959);
const v2972=Math.fround(v2886 * v2886);
const v2973=Math.fround(v2873 * v2886);
const v2974=Math.fround(v2886 * v2873);
const v2975=Math.fround(v2973 + v2974);
const v2976=Math.fround(v2874 * v2886);
const v2977=Math.fround(v2886 * v2874);
const v2978=Math.fround(v2976 + v2977);
const v2980=Math.fround(v2964 + v2972);
const v2981=Math.fround(v2965 + v2975);
const v2982=Math.fround(v2966 + v2975);
const v2983=Math.fround(v2967 + v2975);
const v2984=Math.fround(v2968 + v2975);
const v2985=Math.fround(v2969 + v2975);
const v2986=Math.fround(v2970 + v2978);
const v2987=Math.fround(v2970 + v2975);
const v2989=Math.fround(v2889 * v2889);
const v2990=Math.fround(v2869 * v2889);
const v2991=Math.fround(v2889 * v2869);
const v2992=Math.fround(v2990 + v2991);
const v2993=Math.fround(v2868 * v2889);
const v2994=Math.fround(v2889 * v2868);
const v2995=Math.fround(v2993 + v2994);
const v2997=Math.fround(v2980 + v2989);
const v2998=Math.fround(v2981 + v2992);
const v2999=Math.fround(v2982 + v2992);
const v3000=Math.fround(v2983 + v2992);
const v3001=Math.fround(v2984 + v2992);
const v3002=Math.fround(v2985 + v2992);
const v3003=Math.fround(v2986 + v2992);
const v3004=Math.fround(v2987 + v2995);
const v3005=Math.fround(v2987 + v2992);
const v3007=Math.fround(v2892 * v2892);
const v3008=Math.fround(v2873 * v2892);
const v3009=Math.fround(v2892 * v2873);
const v3010=Math.fround(v3008 + v3009);
const v3011=Math.fround(v2874 * v2892);
const v3012=Math.fround(v2892 * v2874);
const v3013=Math.fround(v3011 + v3012);
const v3015=Math.fround(v2997 + v3007);
const v3016=Math.fround(v2998 + v3010);
const v3017=Math.fround(v2999 + v3010);
const v3018=Math.fround(v3000 + v3010);
const v3019=Math.fround(v3001 + v3010);
const v3020=Math.fround(v3002 + v3010);
const v3021=Math.fround(v3003 + v3010);
const v3022=Math.fround(v3004 + v3010);
const v3023=Math.fround(v3005 + v3013);
const v3024=Math.fround(v3005 + v3010);
const v3026=Math.fround(v2895 * v2895);
const v3027=Math.fround(v2869 * v2895);
const v3028=Math.fround(v2895 * v2869);
const v3029=Math.fround(v3027 + v3028);
const v3030=Math.fround(v2868 * v2895);
const v3031=Math.fround(v2895 * v2868);
const v3032=Math.fround(v3030 + v3031);
const v3034=Math.fround(v3015 + v3026);
const v3035=Math.fround(v3016 + v3029);
const v3036=Math.fround(v3017 + v3029);
const v3037=Math.fround(v3018 + v3029);
const v3038=Math.fround(v3019 + v3029);
const v3039=Math.fround(v3020 + v3029);
const v3040=Math.fround(v3021 + v3029);
const v3041=Math.fround(v3022 + v3029);
const v3042=Math.fround(v3023 + v3029);
const v3043=Math.fround(v3024 + v3032);
const v3044=Math.fround(v3024 + v3029);
const v3046=Math.fround(v2898 * v2898);
const v3047=Math.fround(v2873 * v2898);
const v3048=Math.fround(v2898 * v2873);
const v3049=Math.fround(v3047 + v3048);
const v3050=Math.fround(v2874 * v2898);
const v3051=Math.fround(v2898 * v2874);
const v3052=Math.fround(v3050 + v3051);
const v3054=Math.fround(v3034 + v3046);
const v3055=Math.fround(v3035 + v3049);
const v3056=Math.fround(v3036 + v3049);
const v3057=Math.fround(v3037 + v3049);
const v3058=Math.fround(v3038 + v3049);
const v3059=Math.fround(v3039 + v3049);
const v3060=Math.fround(v3040 + v3049);
const v3061=Math.fround(v3041 + v3049);
const v3062=Math.fround(v3042 + v3049);
const v3063=Math.fround(v3043 + v3049);
const v3064=Math.fround(v3044 + v3052);
const v3065=Math.fround(v3044 + v3049);
const v3067=Math.fround(v2901 * v2901);
const v3068=Math.fround(v2869 * v2901);
const v3069=Math.fround(v2901 * v2869);
const v3070=Math.fround(v3068 + v3069);
const v3071=Math.fround(v2868 * v2901);
const v3072=Math.fround(v2901 * v2868);
const v3073=Math.fround(v3071 + v3072);
const v3075=Math.fround(v3054 + v3067);
const v3076=Math.fround(v3055 + v3070);
const v3077=Math.fround(v3056 + v3070);
const v3078=Math.fround(v3057 + v3070);
const v3079=Math.fround(v3058 + v3070);
const v3080=Math.fround(v3059 + v3070);
const v3081=Math.fround(v3060 + v3070);
const v3082=Math.fround(v3061 + v3070);
const v3083=Math.fround(v3062 + v3070);
const v3084=Math.fround(v3063 + v3070);
const v3085=Math.fround(v3064 + v3070);
const v3086=Math.fround(v3065 + v3073);
const v3087=Math.fround(v3065 + v3070);
const v3089=Math.fround(v2904 * v2904);
const v3090=Math.fround(v2873 * v2904);
const v3091=Math.fround(v2904 * v2873);
const v3092=Math.fround(v3090 + v3091);
const v3093=Math.fround(v2874 * v2904);
const v3094=Math.fround(v2904 * v2874);
const v3095=Math.fround(v3093 + v3094);
const v3097=Math.fround(v3075 + v3089);
const v3098=Math.fround(v3076 + v3092);
const v3099=Math.fround(v3077 + v3092);
const v3100=Math.fround(v3078 + v3092);
const v3101=Math.fround(v3079 + v3092);
const v3102=Math.fround(v3080 + v3092);
const v3103=Math.fround(v3081 + v3092);
const v3104=Math.fround(v3082 + v3092);
const v3105=Math.fround(v3083 + v3092);
const v3106=Math.fround(v3084 + v3092);
const v3107=Math.fround(v3085 + v3092);
const v3108=Math.fround(v3086 + v3092);
const v3109=Math.fround(v3087 + v3095);
return ({["value"]:v3097,["tangent_0"]:v3098,["tangent_1"]:v3099,["tangent_2"]:v3100,["tangent_3"]:v3101,["tangent_4"]:v3102,["tangent_5"]:v3103,["tangent_6"]:v3104,["tangent_7"]:v3105,["tangent_8"]:v3106,["tangent_9"]:v3107,["tangent_10"]:v3108,["tangent_11"]:v3109});}
function __record1(v3110,v3111,v3112,v3113){
const v3116=Math.fround(v3110 * v3112);
const v3117=Math.fround(v3111 * v3112);
const v3118=Math.fround(v3110 * v3113);
const v3119=Math.fround(v3117 + v3118);
return ({["value"]:v3116,["tangent"]:v3119});}
const __namedTypes={"Bundle":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},"Node":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"},"Pair":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"},"__ink_differential_0":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"__ink_differential_2":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"},"__ink_differential_21":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"},"__ink_differential_22":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"},"__ink_differential_4":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"},"__ink_differential_5":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}};
function __stateFloat2(value){return ({["p"]:__stateFloat3(value["p"]),["q"]:__stateFloat3(value["q"]),["r"]:__stateFloat3(value["r"]),["s"]:__stateFloat3(value["s"]),["t"]:__stateFloat3(value["t"]),["u"]:__stateFloat3(value["u"])});}
function __stateFloat1(value){return ({["p"]:__stateFloat0(value["p"]),["q"]:__stateFloat0(value["q"]),["r"]:__stateFloat0(value["r"]),["s"]:__stateFloat0(value["s"]),["t"]:__stateFloat0(value["t"]),["u"]:__stateFloat0(value["u"])});}
function __stateFloat3(value){return ({["a"]:__nfBits(value["a"]),["b"]:__nfBits(value["b"])});}
function __stateFloat0(value){return ({["a"]:__nfFromBits(value["a"]),["b"]:__nfFromBits(value["b"])});}
function __stateFloat9(value){return ({["value"]:__nfBits(value["value"]),["tangent"]:__nfBits(value["tangent"])});}
function __stateFloat8(value){return ({["value"]:__nfFromBits(value["value"]),["tangent"]:__nfFromBits(value["tangent"])});}
function __stateFloat7(value){return ({["value"]:__nfBits(value["value"]),["tangent_0"]:__nfBits(value["tangent_0"]),["tangent_1"]:__nfBits(value["tangent_1"]),["tangent_2"]:__nfBits(value["tangent_2"]),["tangent_3"]:__nfBits(value["tangent_3"]),["tangent_4"]:__nfBits(value["tangent_4"]),["tangent_5"]:__nfBits(value["tangent_5"]),["tangent_6"]:__nfBits(value["tangent_6"]),["tangent_7"]:__nfBits(value["tangent_7"]),["tangent_8"]:__nfBits(value["tangent_8"]),["tangent_9"]:__nfBits(value["tangent_9"]),["tangent_10"]:__nfBits(value["tangent_10"]),["tangent_11"]:__nfBits(value["tangent_11"])});}
function __stateFloat6(value){return ({["value"]:__nfFromBits(value["value"]),["tangent_0"]:__nfFromBits(value["tangent_0"]),["tangent_1"]:__nfFromBits(value["tangent_1"]),["tangent_2"]:__nfFromBits(value["tangent_2"]),["tangent_3"]:__nfFromBits(value["tangent_3"]),["tangent_4"]:__nfFromBits(value["tangent_4"]),["tangent_5"]:__nfFromBits(value["tangent_5"]),["tangent_6"]:__nfFromBits(value["tangent_6"]),["tangent_7"]:__nfFromBits(value["tangent_7"]),["tangent_8"]:__nfFromBits(value["tangent_8"]),["tangent_9"]:__nfFromBits(value["tangent_9"]),["tangent_10"]:__nfFromBits(value["tangent_10"]),["tangent_11"]:__nfFromBits(value["tangent_11"])});}
function __stateFloat10(value){return ({["p"]:__stateFloat11(value["p"]),["q"]:__stateFloat11(value["q"]),["r"]:__stateFloat11(value["r"]),["s"]:__stateFloat11(value["s"]),["t"]:__stateFloat11(value["t"]),["u"]:__stateFloat11(value["u"])});}
function __stateFloat11(value){return ({["a"]:__stateFloat8(value["a"]),["b"]:__stateFloat8(value["b"])});}
function __stateFloat4(value){return ({["p"]:__stateFloat5(value["p"]),["q"]:__stateFloat5(value["q"]),["r"]:__stateFloat5(value["r"]),["s"]:__stateFloat5(value["s"]),["t"]:__stateFloat5(value["t"]),["u"]:__stateFloat5(value["u"])});}
function __stateFloat5(value){return ({["a"]:__stateFloat6(value["a"]),["b"]:__stateFloat6(value["b"])});}
function __stateFn0(a0,a1){return __nfBits(__fn0(__stateFloat0(a0),__nfFromBits(a1)));}
function __stateFn1(a0,a1){return __nfBits(__fn1(__stateFloat1(a0),__nfFromBits(a1)));}
function __stateFn2(a0,a1){return __stateFloat2(__fn2(__stateFloat1(a0),__nfFromBits(a1)));}
function __stateFn3(a0,a1){return __nfBits(__fn3(__stateFloat1(a0),__nfFromBits(a1)));}
function __stateFn4(a0){return __nfBits(__fn4(__stateFloat0(a0)));}
function __stateFn5(a0,a1){return __stateFloat3(__fn5(__stateFloat0(a0),a1));}
function __stateFn6(a0,a1){return __stateFloat3(__fn6(__nfFromBits(a0),a1));}
function __stateFn7(a0){return __stateFloat3(__fn7(__nfFromBits(a0)));}
function __stateFn8(a0){return __nfBits(__fn8(__stateFloat0(a0)));}
function __stateFn9(a0,a1){return __nfBits(__fn9(__nfFromBits(a0),__nfFromBits(a1)));}
function __stateFn11(a0,a1){return __stateFloat7(__fn11(__stateFloat4(a0),__stateFloat6(a1)));}
function __stateFn12(a0,a1){return __stateFloat2(__fn12(__stateFloat1(a0),__nfFromBits(a1)));}
function __stateFn13(a0,a1){return __stateFloat9(__fn13(__stateFloat8(a0),__stateFloat8(a1)));}
function __stateFn14(a0,a1){return __stateFloat9(__fn14(__stateFloat8(a0),__stateFloat8(a1)));}
function __stateFn15(a0,a1){return __stateFloat9(__fn15(__stateFloat8(a0),__stateFloat8(a1)));}
function __stateFn16(a0,a1){return __stateFloat9(__fn16(__stateFloat10(a0),__stateFloat8(a1)));}
function __stateFn17(a0,a1,a2){return __nfBits(__fn17(__stateFloat1(a0),__stateFloat1(a1),__nfFromBits(a2)));}
// Portable snapshot ABI shared with native/Wasm. Hashing uses Web Crypto.
function __snapshotLimits(limits={}){
 const result={bytes:64*1024*1024,values:1000000,depth:128,...limits};
 for(const k of ['bytes','values','depth'])if(!Number.isSafeInteger(result[k])||result[k]<0||result[k]>(k==='depth'?128:k==='values'?1000000:64*1024*1024))throw Error('invalid snapshot limits');
 return result;
}
const __hash=async bytes=>new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256',bytes));
function __snapshotWriter(limits){
 const out=[];let left=limits.values,maxDepth=0;
 function bytes(xs){if(xs.length>limits.bytes-out.length)throw Error('snapshot byte limit exceeded');for(const x of xs)out.push(x);}
 function integer(n,size){n=BigInt(n);for(let i=0;i<size;i++){bytes([Number(n&255n)]);n>>=8n;}}
 function raw(xs){integer(xs.length,8);bytes(xs);}
 function value(v,t,depth=0,bindings=[]){maxDepth=Math.max(maxDepth,depth);if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{value(v,t.body,depth+1,bindings);}finally{bindings.pop();}break;
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');value(v,bound[1],depth+1,bindings);break;}
  case 'unit':break;case 'bool':bytes([v?1:0]);break;
  case 'u32':case 'i32':case 'f32':integer(v,4);break;case 'u64':integer(v,8);break;
  case 'f64':integer(__dfBits(v),8);break;
  case 'vector':if(v.length!==t.size)throw Error('vector dimension mismatch');for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'int':{let n=v<0n?-v:v;const xs=[];while(n){if(xs.length>=4096)throw Error('snapshot Int exceeds size limit');xs.push(Number(n&255n));n>>=8n;}bytes([v===0n?0:v>0n?1:2]);raw(xs);break;}
  case 'string':raw(__encoder.encode(v));break;
  case 'id':integer(BigInt('0x'+v),16);break;
  case 'enum':integer(t.variants.indexOf(v),4);break;
  case 'record':for(const f of t.fields)value(t.elided?v:v[f.name],f.type,depth+1,bindings);break;
  case 'list':if(v.length>left)throw Error('snapshot value limit exceeded');integer(v.length,8);for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'option':if(Object.hasOwn(v,'Some')){bytes([1]);value(v.Some,t.element,depth+1,bindings);}else bytes([0]);break;
  case 'result':{const branch=t.sum_key?__sumView(t.sum_key,v):v;if(Object.hasOwn(branch,'Ok')){bytes([0]);value(branch.Ok,t.ok,depth+1,bindings);}else{bytes([1]);value(branch.Err,t.error,depth+1,bindings);}break;}
  default:throw Error('unsupported snapshot type');
 }}
 return {bytes,integer,raw,value,charge(cells,depth){left-=cells;if(left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');},get maxDepth(){return maxDepth;},get left(){return left;},finish:()=>new Uint8Array(out)};
}
async function __snapshotEncode(meta,state,options){
 const limits=__snapshotLimits(options),w=__snapshotWriter(limits);
 w.integer(state.version,8);
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const rows=[...state.tables[r.index].entries()].sort((a,b)=>__keyCompare(a[0],b[0],r.key));if(rows.length>Math.floor(w.left/2))throw Error('snapshot row limit exceeded');w.integer(rows.length,8);for(const [k,v]of rows){
  if(!meta.snapshotRows){w.value(k,r.snapshotKey??r.key);w.value(v,r.snapshotValue??r.value);continue;}
  const cache=state.snapshotRows[r.index];let packed=cache.get(k);
  if(!packed){const row=__snapshotWriter(limits);row.value(k,r.snapshotKey??r.key);row.value(v,r.snapshotValue??r.value);packed={bytes:row.finish(),cells:limits.values-row.left,depth:row.maxDepth};cache.set(k,packed);}
  w.charge(packed.cells,packed.depth);w.bytes(packed.bytes);
 }}
 w.integer(state.outbox.length,8);
 for(const e of state.outbox){const channel=meta.events.findIndex(t=>t.name===e.channel);w.integer(e.commit,8);w.integer(e.position,8);w.integer(channel,4);w.value(e.value,meta.events[channel].snapshotType??meta.events[channel].type);}
 const payload=w.finish(),header=__snapshotWriter(limits);header.bytes([86,76,83,84,65,84,69,0,1,0,1,0]);header.bytes(meta.snapshot.program);header.bytes(meta.snapshot.schema);header.integer(payload.length,8);header.bytes(payload);
 const bytes=header.finish();if(bytes.length+32>limits.bytes)throw Error('snapshot byte limit exceeded');const digest=await __hash(bytes);const result=new Uint8Array(bytes.length+32);result.set(bytes);result.set(digest,bytes.length);return result;
}
async function __snapshotDecode(meta,input,options){
 const limits=__snapshotLimits(options);
 if(!(input instanceof Uint8Array)&&!Array.isArray(input))throw Error('expected snapshot bytes');
 if(input.length>limits.bytes||input.length<116)throw Error('snapshot byte length invalid');
 if(Array.isArray(input)&&input.some(b=>!Number.isInteger(b)||b<0||b>255))throw Error('invalid snapshot bytes');
 const bytes=new Uint8Array(input); // capture before asynchronous integrity work
 function same(a,b){return a.length===b.length&&a.every((v,i)=>v===b[i]);}
 if(!same(bytes.subarray(0,12),[86,76,83,84,65,84,69,0,1,0,1,0]))throw Error('snapshot format or semantics version mismatch');
 if(!same(bytes.subarray(12,44),meta.snapshot.program)||!same(bytes.subarray(44,76),meta.snapshot.schema))throw Error('snapshot program or schema identity mismatch');
 const end=bytes.length-32,digest=await __hash(bytes.subarray(0,end));if(!same(digest,bytes.subarray(end)))throw Error('snapshot integrity check failed');
 let at=76,left=limits.values;
 function take(n){if(!Number.isSafeInteger(n)||n<0||n>end-at)throw Error('truncated snapshot');const x=bytes.subarray(at,at+n);at+=n;return x;}
 function integer(size){const xs=take(size);let n=0n;for(let i=size-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return n;}
 function length(){const n=integer(8);if(n>BigInt(Number.MAX_SAFE_INTEGER))throw Error('snapshot length not addressable');return Number(n);}
 function sequence(){const n=length();if(n>left)throw Error('snapshot value limit exceeded');return n;}
 function raw(){return take(length());}
 const n=length();if(n!==end-84)throw Error('snapshot payload length mismatch');
 function value(t,depth=0,bindings=[]){if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{return value(t.body,depth+1,bindings);}finally{bindings.pop();}
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');return value(bound[1],depth+1,bindings);}
  case 'unit':return null;case 'bool':{const b=take(1)[0];if(b>1)throw Error('invalid Bool tag');return b===1;}
  case 'u32':case 'f32':return Number(integer(4));case 'i32':return Number(BigInt.asIntN(32,integer(4)));case 'u64':return integer(8);
  case 'f64':return __dfFromBits(integer(8));
  case 'vector':{const xs=[];for(let i=0;i<t.size;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'int':{const sign=take(1)[0],xs=raw();if(xs.length>4096)throw Error('snapshot Int exceeds size limit');if(!((sign===0&&xs.length===0)||((sign===1||sign===2)&&xs.length>0&&xs[xs.length-1]!==0)))throw Error('noncanonical signed integer');let n=0n;for(let i=xs.length-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return sign===2?-n:n;}
  case 'string':return new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(raw());
  case 'id':return integer(16).toString(16).padStart(32,'0');
  case 'enum':{const i=Number(integer(4));if(i>=t.variants.length)throw Error('invalid enum tag');return t.variants[i];}
  case 'record':if(t.elided)return value(t.fields[0].type,depth+1,bindings);return Object.fromEntries(t.fields.map(f=>[f.name,value(f.type,depth+1,bindings)]));
  case 'list':{const n=sequence(),xs=[];for(let i=0;i<n;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'option':{const tag=take(1)[0];if(tag===0)return {None:null};if(tag===1)return {Some:value(t.element,depth+1,bindings)};throw Error('invalid Option tag');}
  case 'result':{const tag=take(1)[0];if(tag===0){const child=value(t.ok,depth+1,bindings);return t.sum_key?__sumMake(t.sum_key,true,child):{Ok:child};}if(tag===1){const child=value(t.error,depth+1,bindings);return t.sum_key?__sumMake(t.sum_key,false,child):{Err:child};}throw Error('invalid Result tag');}
  default:throw Error('unsupported snapshot type');
 }}
 const version=integer(8),tables=meta.roots.map(()=>new Map());
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const n=sequence();if(n>Math.floor(left/2))throw Error('snapshot row limit exceeded');let prior;for(let i=0;i<n;i++){const k=value(r.snapshotKey??r.key),v=value(r.snapshotValue??r.value);if(i&&__keyCompare(prior,k,r.key)>=0)throw Error('duplicate or unordered snapshot key');tables[r.index].set(k,v);prior=k;}}
 const count=sequence(),outbox=[];let prior;
 for(let i=0;i<count;i++){const commit=integer(8),position=integer(8),channel=Number(integer(4));if(!meta.events[channel])throw Error('unknown snapshot event channel');const v=value(meta.events[channel].snapshotType??meta.events[channel].type);if(commit===0n||commit>version||(prior&&(commit<prior.commit||(commit===prior.commit&&position<=prior.position))))throw Error('invalid snapshot event sequence');const e={commit,position,channel:meta.events[channel].name,value:v};outbox.push(e);prior=e;}
 if(at!==end)throw Error('trailing snapshot payload');return {version,tables,outbox};
}
// Fixed subscription lifecycle. Root/output edges derive from checked source;
// values and ownership codecs are compiled from each query's declared type.
function __createObservers(prepare){
 const subscriptions=new Map(),byRoot=new Map(),errors=[],directRoots=[],rootSchedules=[];
 let pending=[],spare=[];
 let next=0,held=0,flushing=false;
 function report(s,error,phase){errors.push({query:s?.query??null,error,phase});if(s?.onError)try{s.onError(error);}catch(e){errors.push({query:s.query,error:e,phase:'error-handler'});}}
 function flush(initialPasses=0){
  if(held||flushing||!pending.length)return;
  flushing=true;let passes=initialPasses;
  try{
   while(pending.length&&!held){
    if(++passes>1024){report(null,Error('subscription publication budget exhausted'),'publication');break;}
    const affected=pending;pending=spare;spare=affected;
    for(const s of affected)s.queued=false;
    // Snapshot every affected value before consumers run. Deliveries reside in
    // the stable subscription slots; no per-delivery tuple is allocated.
    for(const s of affected){if(!s.active)continue;s.deliver=false;
     try{if(s.pair){const a=s.pairState?s.pairState.keeps[s.keep0]:s.read0(),b=s.pairState?s.pairState.keeps[s.keep1]:s.read1();if(s.value0!==a||s.value1!==b){s.value0=a;s.value1=b;s.delivery0=a;s.delivery1=b;s.deliver=true;}}else{const value=s.capture(s.read());if(!s.equal(s.value,value)){s.value=value;s.delivery=value;s.deliver=true;}}}
     catch(e){report(s,e,'query');}
    }
    for(const s of affected){if(!s.active||!s.deliver)continue;const value=s.delivery;s.deliver=false;s.delivery=undefined;
     try{if(s.pair)s.callback(s.delivery0,s.delivery1);else s.callback(s.output(value));}catch(e){report(s,e,'listener');}
    }
    affected.length=0;
   }
  }finally{flushing=false;}
 }
 function install(query,q,callback,{immediate=true,onError}={}){
  if(typeof callback!=='function'||onError!==undefined&&typeof onError!=='function')throw TypeError('subscription callback');
  const s={...q,id:next++,query,callback,onError,active:true,queued:false,deliver:false,delivery:undefined};
  if(s.pair){s.value0=s.pairState?s.pairState.keeps[s.keep0]:s.read0();s.value1=s.pairState?s.pairState.keeps[s.keep1]:s.read1();}else{s.value=s.capture(s.read());}subscriptions.set(s.id,s);
  for(const root of s.roots){let ids=byRoot.get(root);if(!ids)byRoot.set(root,ids=[]);ids.push(s);schedule(root,ids);}
  const dispose=()=>{if(!subscriptions.delete(s.id))return;s.active=false;for(const root of s.roots){const ids=byRoot.get(root);ids.splice(ids.indexOf(s),1);schedule(root,ids);if(!ids.length)byRoot.delete(root);}};
  if(immediate)try{if(s.pair)callback(s.value0,s.value1);else callback(s.output(s.value));}catch(e){dispose();throw e;}
  return dispose;
 }
 // Bind the publication implementation when consumers change, instead of
 // rediscovering the one-consumer schedule on each source mutation.
 function schedule(root,ids){
  const s=directRoots[root]=ids.length===1&&ids[0].pairState?ids[0]:null;
  rootSchedules[root]=!ids.length?null:s?()=>publishPair(s):(outputs,epoch)=>{enqueueRoot(root,outputs,epoch);flush();};
 }
 function publishPair(s){
  const a=s.pairState.keeps[s.keep0],b=s.pairState.keeps[s.keep1];
  if(s.value0===a&&s.value1===b)return;
  if(!held&&!flushing&&!pending.length){
   s.value0=a;s.value1=b;flushing=true;
   try{s.callback(a,b);}catch(e){report(s,e,'listener');}finally{flushing=false;}
   flush(1);return;
  }
  if(!s.queued){s.queued=true;pending.push(s);}flush();
 }
 function enqueueRoot(root,outputs,epoch){
  const slots=byRoot.get(root);if(!slots)return;
  for(let i=0;i<slots.length;i++){
   const s=slots[i];if(s.queued)continue;
   if(outputs!==null&&s.outputs?.length){
    let changed=false;for(let j=0;j<s.outputs.length;j++)if(epoch?outputs[s.outputs[j]]===epoch:outputs.has(s.outputs[j])){changed=true;break;}
    if(!changed)continue;
   }
   s.queued=true;pending.push(s);
  }
 }
 return {
  directRoots,rootSchedules,
  get active(){return subscriptions.size!==0;},
  subscribe(query,args,callback,options){return install(query,prepare(query,args),callback,options);},
  subscribeGroup(queries,callback,options){
   if(!Array.isArray(queries)||!queries.length)throw TypeError('subscription group requires queries');
   const qs=queries.map(q=>typeof q==='string'?prepare(q,[]):prepare(q.query,q.args??[]));
   const roots=[...new Set(qs.flatMap(q=>q.roots))];
   // An unknown dependency forces ordinary root invalidation for the group.
   const outputs=qs.every(q=>q.outputs?.length)?[...new Set(qs.flatMap(q=>q.outputs))]:[];
   const scalar=qs.every(q=>q.scalar),direct=qs.every(q=>q.direct);
   return install(queries,{roots,outputs,read:direct?()=>qs.map(q=>q.direct()):()=>qs.map(q=>q.read()),capture:scalar?values=>values:values=>values.map((v,i)=>qs[i].capture(v)),output:scalar?values=>values.slice():values=>values.map((v,i)=>qs[i].output(v)),equal:scalar?(a,b)=>a.every((v,i)=>v===b[i]):(a,b)=>a.every((v,i)=>qs[i].equal(v,b[i]))},callback,options);
  },
  subscribeValues(queries,callback,options){
   if(!Array.isArray(queries)||!queries.length)throw TypeError('subscription group requires queries');
   if(typeof callback!=='function')throw TypeError('subscription callback');
   const qs=queries.map(q=>typeof q==='string'?prepare(q,[]):prepare(q.query,q.args??[]));
   if(qs.length===2&&qs.every(q=>q.scalar)){
    const roots=[...new Set(qs.flatMap(q=>q.roots))],outputs=qs.every(q=>q.outputs?.length)?[...new Set(qs.flatMap(q=>q.outputs))]:[];
    const pairState=qs[0].committed&&qs[1].committed&&qs[0].committed.state===qs[1].committed.state?qs[0].committed.state:null;
    return install(queries,{roots,outputs,pair:true,pairState,keep0:qs[0].committed?.keep,keep1:qs[1].committed?.keep,read0:qs[0].direct||qs[0].read,read1:qs[1].direct||qs[1].read},callback,options);
   }
   return this.subscribeGroup(queries,values=>callback(...values),options);
  },
  commit(roots,outputs=null){
   if(!subscriptions.size)return;
   for(const root of roots)enqueueRoot(root,outputs,false);
   flush();
  },
  // A checked single-root action supplies a reusable array of changed outputs.
  // No root carrier, Set, affected-ID array or Map lookup per delivery is needed.
  commitRoot(root,outputs=null,epoch=0){
   rootSchedules[root]?.(outputs,epoch);
  },
  hold(){held++;return pending.slice();},
  release(){if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  rollback(mark){for(const s of pending)s.queued=false;pending.length=0;for(const s of mark)if(s.active&&!s.queued){s.queued=true;pending.push(s);}if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  batch(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('batch callback must be synchronous');held++;
   try{const value=callback();if(value&&typeof value.then==='function')throw TypeError('state batch callback must be synchronous');return value;}
   finally{held--;flush();}
  },
  flush,takeErrors(){return errors.splice(0);}
 };
}
function __versionWord(v){return typeof v==='number'?BigInt(v):v;}
function __storedCommit(meta,v){return meta.compactCommits&&v<=9007199254740991n?Number(v):v;}
function __nextCommit(v){return typeof v==='number'&&v<9007199254740991?v+1:BigInt(v)+1n;}
// Private column event log. Public records and portable event ordering are unchanged.
// Private event storage. Public events and portable snapshots keep their ordinary
// ordered records. A selected contiguous run omits repeated commit metadata;
// gaps and duplicate commits materialise an exact literal column.
class __EventColumns {
 constructor(channels,compact=false,runs=false){this.channels=channels;this.compact=compact;this.runs=runs;this.commits=runs?null:[];this.base=undefined;this.values=[];this.positions=null;this.channelValues=channels.length===1?null:[];}
 get length(){return this.values.length;}
 set length(n){if(!Number.isSafeInteger(n)||n<0||n>this.length)throw Error('event log truncate');if(this.commits)this.commits.length=n;this.values.length=n;if(this.positions)this.positions.length=n;if(this.channelValues)this.channelValues.length=n;if(n===0){this.base=undefined;if(this.runs)this.commits=null;}}
 append(commit,position,channel,value){
  const i=this.values.length;
  if(this.commits)this.commits.push(commit);
  else if(!i)this.base=commit;
  else{
   const small=typeof this.base==='number'&&typeof commit==='number';
   const expected=small?this.base+i:__versionWord(this.base)+BigInt(i);
   if(expected!==commit){
    this.commits=[];
    for(let j=0;j<i;j++){const word=__versionWord(this.base)+BigInt(j);this.commits.push(this.compact&&word<=9007199254740991n?Number(word):word);}
    this.commits.push(commit);
   }
  }
  this.values.push(value);if(this.channelValues)this.channelValues.push(channel);if(position!==0n&&!this.positions)this.positions=new Array(i).fill(0n);if(this.positions)this.positions.push(position);
 }
 push(e){this.append(this.compact&&e.commit<=9007199254740991n?Number(e.commit):e.commit,e.position,e.channel,e.value);return this.length;}
 at(i){if(i<0)i+=this.length;if(i<0||i>=this.length)return undefined;return {commit:this.commits?__versionWord(this.commits[i]):__versionWord(this.base)+BigInt(i),position:this.positions?this.positions[i]:0n,channel:this.channelValues?this.channelValues[i]:this.channels[0],value:this.values[i]};}
 *[Symbol.iterator](){for(let i=0;i<this.length;i++)yield this.at(i);}
 map(f){const out=new Array(this.length);for(let i=0;i<this.length;i++)out[i]=f(this.at(i),i);return out;}
 filter(f){const out=new __EventColumns(this.channels,this.compact,this.runs);for(let i=0;i<this.length;i++){const e=this.at(i);if(f(e,i))out.push(e);}return out;}
}
function __eventLog(meta,events=[]){
 if(!meta.eventColumns)return meta.compactCommits?events.map(e=>({...e,commit:__storedCommit(meta,e.commit)})):events;
 const log=new __EventColumns(meta.events.map(e=>e.name),meta.compactCommits,meta.eventRuns);for(const e of events)log.append(__storedCommit(meta,e.commit),e.position,e.channel,e.value);return log;
}
// CALLER CONTRACT: arguments must match declared types; malformed data may throw or corrupt state.
// Fixed state primitives used by emitted action bodies, without an AST evaluator.
class __Abort {constructor(value){this.value=value;}}
function __preflightError(message){throw Error(message);}
function __try(value){if(Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value.Ok;}
function __nested(value,change){if(change && Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value;}
function __equal(a,b){if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object')return false;const ak=Object.keys(a),bk=Object.keys(b);return ak.length===bk.length&&ak.every(k=>Object.hasOwn(b,k)&&__equal(a[k],b[k]));}
function __checked(op,a,b,bits){const x=BigInt(a),y=BigInt(b),n=op==='checked_add'?x+y:op==='checked_sub'?x-y:x*y;const min=bits===-32?-2147483648n:0n,max=bits===-32?2147483648n:1n<<BigInt(bits);return n<min||n>=max?{Err:'ArithmeticError.Overflow'}:{Ok:Math.abs(bits)===32?Number(n):n};}
function __okOr(value,error){return Object.hasOwn(value,'Some')?{Ok:value.Some}:{Err:error};}
function __mapValue(value,kind,method,fn){
 if(kind==='list')return value[method](fn);
 if(kind==='option')return Object.hasOwn(value,'Some')?{Some:fn(value.Some)}:{None:null};
 const tag=method==='map_err'?'Err':'Ok';return Object.hasOwn(value,tag)?{[tag]:fn(value[tag])}:value;
}
const __encoder=new TextEncoder();
function __tick(ctx){if(--ctx.fuel<0)throw Error('Ink state execution budget exhausted');}
function __keyCompare(a,b,type){
 if(type.kind==='string'){let i=0,j=0;while(i<a.length&&j<b.length){const x=a.codePointAt(i),y=b.codePointAt(j);if(x!==y)return x-y;i+=x>65535?2:1;j+=y>65535?2:1;}return (i<a.length?1:0)-(j<b.length?1:0);}
 return a<b?-1:a>b?1:0;
}
// A table's ordered key view is reused until membership changes. Values are
// fetched at traversal time, so replacement never leaves stale row payloads.
const __tableOrder=new WeakMap();
function __keyPosition(keys,key,type){let low=0,high=keys.length;while(low<high){const middle=(low+high)>>>1;if(__keyCompare(keys[middle],key,type)<0)low=middle+1;else high=middle;}return low;}
function __tableMembership(rt,index,key,present){
 const view=__tableOrder.get(rt.tables[index]);if(!view)return;
 const at=__keyPosition(view.keys,key,rt.meta.roots[index].key);
 if((at<view.keys.length&&view.keys[at]===key)===present)view.pending.delete(key);
 else view.pending.set(key,present);
}
function __orderedKeys(rt,index){
 const table=rt.tables[index],type=rt.meta.roots[index].key;let view=__tableOrder.get(table);
 if(!view){view={keys:[...table.keys()].sort((a,b)=>__keyCompare(a,b,type)),pending:new Map()};__tableOrder.set(table,view);}
 if(view.pending.size){
  const changes=[...view.pending.keys()].sort((a,b)=>__keyCompare(a,b,type)),merged=[];let i=0,j=0;
  while(i<view.keys.length||j<changes.length){
   if(j===changes.length||(i<view.keys.length&&__keyCompare(view.keys[i],changes[j],type)<0))merged.push(view.keys[i++]);
   else{const key=changes[j++];if(i<view.keys.length&&view.keys[i]===key)i++;if(view.pending.get(key))merged.push(key);}
  }
  view.keys=merged;view.pending.clear();
 }
 const keys=view.keys;
 const cell=rt.cell;
 if(cell&&cell.index===index&&table.has(cell.key)!==(cell.next!==undefined)){
  if(cell.next===undefined)return keys.filter(k=>k!==cell.key);
  const at=__keyPosition(keys,cell.key,type);return [...keys.slice(0,at),cell.key,...keys.slice(at)];
 }
 return keys;
}
function __cellGet(rt,index,key){const cell=rt.cell;return cell&&cell.index===index&&cell.key===key?cell.next:rt.tables[index].get(key);}
function __readTable(rt,index){const cell=rt.cell;if(!cell||cell.index!==index)return rt.tables[index];const table=new Map(rt.tables[index]);if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);return table;}
// The first before-image of each cell suffices for whole-transaction rollback.
function __remember(rt,index,key,present,value){if(rt.cellMode)return;if(!rt.seen[index].has(key)){rt.seen[index].add(key);rt.undo.push([index,key,present,value]);}}
// Immutable keeps retain private values. Public results remain owned copies.
// Reverse edges come from checked source effects.
// Before-images preserve cached values across failed actions; host rollback and
// restore discard caches rather than serializing them into logical snapshots.
function __invalidateKeeps(rt,index){
 if(rt.observers?.active)rt.changedRoots.add(index);
 if(!rt.keeps||rt.cellMode)return;
 for(const keep of rt.meta.keepInvalidations[index]){
  if(!rt.keepDirty[keep]){rt.keepDirty[keep]=1;rt.keepUndoIndices[rt.keepUndoCount++]=keep;rt.keepBefore[keep]=rt.keeps[keep];}
  rt.keeps[keep]=undefined;
 }
}
function __restoreKeeps(rt){for(let i=rt.keepUndoCount-1;i>=0;i--){const keep=rt.keepUndoIndices[i];rt.keeps[keep]=rt.keepBefore[keep];}__refreshActiveViews(rt);}
function __clearKeepJournal(rt){for(let i=0;i<rt.keepUndoCount;i++){const keep=rt.keepUndoIndices[i];rt.keepDirty[keep]=0;rt.keepBefore[keep]=undefined;}rt.keepUndoCount=0;}
function __rebuildViews(rt){
 rt.activeViewRoots=new Uint8Array(rt.meta.roots.length);
 for(const view of rt.views){rt.keeps[view.keep]=undefined;if(!rt.meta.lazyMaintenance)__viewBase(rt,view);}
}
function __refreshActiveViews(rt){rt.activeViewRoots.fill(0);for(const view of rt.views)if(rt.keeps[view.keep]!==undefined)rt.activeViewRoots[view.root]=1;}
function __viewBase(rt,view){
 if(rt.keeps[view.keep]===undefined){let value=view.zero;for(const [key,row]of rt.tables[view.root])value=view.combine(value,view.contribution(key,row));rt.keeps[view.keep]=value;rt.activeViewRoots[view.root]=1;}
 return rt.keeps[view.keep];
}
function __viewValue(view,value,key,oldValue,newValue){
 if(oldValue===undefined)return view.insert?view.insert(value,key,newValue):view.combine(value,view.contribution(key,newValue));
 if(newValue===undefined)return view.remove?view.remove(value,key,oldValue):view.combine(value,view.inverse(view.contribution(key,oldValue)));
 return view.replace?view.replace(value,key,oldValue,newValue):view.combine(view.combine(value,view.inverse(view.contribution(key,oldValue))),view.contribution(key,newValue));
}
function __updateViews(rt,index,key,oldValue,newValue){
 if(!rt.activeViewRoots[index])return null;
 const updates=rt.viewNext;
 for(const view of rt.viewsByRoot[index])updates[view.keep]=rt.keeps[view.keep]===undefined?undefined:__viewValue(view,rt.keeps[view.keep],key,oldValue,newValue);
 return updates;
}
function __installViews(rt,updates,index){if(updates)for(const view of rt.viewsByRoot[index])rt.keeps[view.keep]=updates[view.keep];}
function __pendingView(rt,view){
 const keep=view.keep;
 if(rt.pendingValues[keep]===undefined){
  const cell=rt.cell;
  rt.pendingValues[keep]=__viewValue(view,__viewBase(rt,view),cell.key,cell.prior,cell.next);
  rt.pendingIndices.push(keep);
 }
 return rt.pendingValues[keep];
}
function __prepareCell(rt){if(rt.cell&&rt.activeViewRoots[rt.cell.index]){const prepare=rt.views.prepareRoots?.[rt.cell.index];if(prepare)prepare(rt,rt.cell);else for(const view of rt.viewsByRoot[rt.cell.index])if(rt.keeps[view.keep]!==undefined)__pendingView(rt,view);}}
function __invalidateSnapshotRow(rt,index,key){rt.snapshotRows?.[index].delete(key);}
function __writeCell(rt,index,key,next,prior){
 if(rt.cellMode){if(rt.cell)throw Error('checked single-cell bound exceeded');rt.cell={index,key,next,prior};}
 else{const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);if(rt.changeTracking)__recordChange(rt,index,key,prior,next);if((prior!==undefined)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);if(next===undefined)table.delete(key);else table.set(key,next);}
}
function __commitCell(rt){
 const cell=rt.cell;if(!cell)return;
 const table=rt.tables[cell.index];__invalidateSnapshotRow(rt,cell.index,cell.key);
 if(rt.changeTracking)__recordChange(rt,cell.index,cell.key,cell.prior,cell.next);
 if((cell.prior!==undefined)!==(cell.next!==undefined))__tableMembership(rt,cell.index,cell.key,cell.next!==undefined);
 if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);
 for(const keep of rt.meta.keepInvalidations[cell.index])rt.keeps[keep]=rt.pendingValues[keep];
 rt.cell=null;
}
// Preflight scratch has no logical state or rollback obligations. Definitions
// are the same admitted group operations used by ordinary cell maintenance.
function __prepareDirect(rt,index,key,prior,next){
 const prepare=rt.views.directRoots?.[index];
 if(prepare)prepare(rt,key,prior,next);
 else for(const view of rt.viewsByRoot[index])rt.viewNext[view.keep]=__viewValue(view,rt.keeps[view.keep],key,prior,next);
}
function __storeDirect(rt,index,key,prior,next,slot){
 const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);
 if((prior!==undefined)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);
 if(rt.changeTracking)__recordChange(rt,index,key,prior,next);
 if(slot===undefined){if(next===undefined)table.delete(key);else table.set(key,next);}
 else{
  // The checked preflight lookup retains the dense slot until this commit.
  // No callback or source write can intervene; sparse keys retain exact identity.
  if(slot<0){if(next===undefined)table.sparse.delete(key);else table.sparse.set(key,next);}else table.dense[slot]=next;
  if(prior===undefined&&next!==undefined)table.members.add(key);else if(prior!==undefined&&next===undefined)table.members.delete(key);
 }
}
function __commitDirect(rt,index,key,prior,next,slot){
 __storeDirect(rt,index,key,prior,next,slot);
 const publishOutputs=rt.meta.outputPublication&&!rt.observers.directRoots[index]&&rt.observers.active;
 if(publishOutputs&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}

 for(const keep of rt.meta.keepInvalidations[index]){
  const value=rt.viewByKeep[keep]?rt.viewNext[keep]:undefined;
  if(publishOutputs)rt.changedOutputs[keep]=rt.keeps[keep]!==value?rt.changedOutputEpoch:0;
  rt.keeps[keep]=value;
 }
}
function __emit(rt,channel,value){
 if(rt.eventCount++===0){rt.eventChannel=channel;rt.eventValue=value;}
 else rt.staged.push([channel,value]);
}
// Checked prefix capacities are at most 2^20. Number conversion is exact
// inside that prefix; rounding a wide word cannot move it into the prefix.
// Wide keys retain their original full-width value in the sparse fallback.
class __DenseTable{
 constructor(capacity){this.limit=capacity;this.dense=[];for(let i=0;i<capacity;i++)this.dense.push(undefined);this.sparse=new Map();this.members=new Set();}
 clear(){this.dense.fill(undefined);this.sparse.clear();this.members.clear();__tableOrder.delete(this);return this;}
 slot(key){const i=Number(key);return Number.isInteger(i)&&i>=0&&i<this.limit?i:-1;}
 get size(){return this.members.size;}
 get(key){const i=this.slot(key);return i<0?this.sparse.get(key):this.dense[i];}
 has(key){return this.get(key)!==undefined;}
 set(key,value){const i=this.slot(key),present=i<0?this.sparse.has(key):this.dense[i]!==undefined;if(i<0)this.sparse.set(key,value);else this.dense[i]=value;if(!present)this.members.add(key);return this;}
 delete(key){const i=this.slot(key);if(i<0)this.sparse.delete(key);else this.dense[i]=undefined;return this.members.delete(key);}
 keys(){return this.members.keys();}
 *values(){for(const key of this.members)yield this.get(key);}
 *entries(){for(const key of this.members)yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
class __ColumnTable {
 constructor(root){
  this.limit=root.columnPrefix.capacity;this.keyBig=root.key.kind==='u64';
  this.fields=root.value.fields;this.exactNumbers=root.columnPrefix.exactNumbers;
  this.present=new Uint8Array(this.limit);this.count=0;this.sparse=new Map();
  this.lanes=this.fields.map(f=>f.type.kind==='u64'?(this.exactNumbers?new Float64Array(this.limit):new BigUint64Array(this.limit)):f.type.kind==='i32'?new Int32Array(this.limit):f.type.kind==='bool'?new Uint8Array(this.limit):new Uint32Array(this.limit));
  this.wide=this.fields.map(f=>f.type.kind==='u64'&&this.exactNumbers?new Map():null);
 }
 slot(key){const i=Number(key);return Number.isInteger(i)&&i>=0&&i<this.limit?i:-1;}
 get size(){return this.count+this.sparse.size;}
 has(key){const i=this.slot(key);return i<0?this.sparse.has(key):this.present[i]!==0;}
 get(key){const i=this.slot(key);if(i<0)return this.sparse.get(key);if(!this.present[i])return undefined;const row=Object.create(null);for(let j=0;j<this.fields.length;j++){const f=this.fields[j],v=this.lanes[j][i];row[f.name]=f.type.kind==='bool'?v!==0:f.type.kind==='u64'&&this.exactNumbers?(this.wide[j].get(i)??BigInt(v)):v;}return row;}
 set(key,row){const i=this.slot(key);if(i<0){this.sparse.set(key,row);return this;}for(let j=0;j<this.fields.length;j++){const f=this.fields[j],v=row[f.name];if(f.type.kind==='u64'&&this.exactNumbers){if(v<=9007199254740991n){this.lanes[j][i]=Number(v);this.wide[j].delete(i);}else{this.lanes[j][i]=0;this.wide[j].set(i,v);}}else this.lanes[j][i]=f.type.kind==='bool'?Number(v):v;}if(!this.present[i]){this.present[i]=1;this.count++;}return this;}
 delete(key){const i=this.slot(key);if(i<0)return this.sparse.delete(key);if(!this.present[i])return false;this.present[i]=0;this.count--;for(const wide of this.wide)wide?.delete(i);return true;}
 *keys(){for(let i=0;i<this.limit;i++)if(this.present[i])yield this.keyBig?BigInt(i):i;yield* this.sparse.keys();}
 *values(){for(const key of this.keys())yield this.get(key);}
 *entries(){for(const key of this.keys())yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
function __newTables(meta,prefixes,old,spares){return meta.roots.map((root,i)=>{const prior=spares?.[i];const t=root.columnPrefix?new __ColumnTable(root):prefixes[i]?(prior instanceof __DenseTable&&prior.limit===prefixes[i]?prior.clear():new __DenseTable(prefixes[i])):new Map();if(old)for(const [k,v]of old[i])t.set(k,v);return t;});}
// Only inactive containers are reused. Consume the spare before preparation so
// a failed invariant/rebuild cannot expose its partially reconstructed contents.
// Rows remain immutable; the current logical state changes only at installation.
function __restoreTables(rt,prefixes,old){const spares=rt.restoreSpares;rt.restoreSpares=null;return __newTables(rt.meta,prefixes,old,spares);}
function __cachedKeep(ctx,rt,index,compute){
 if(rt.cell&&rt.meta.keepInvalidations[rt.cell.index].includes(index)){
  const view=rt.viewByKeep[index];
  if(view)return __pendingView(rt,view);
  if(rt.pendingValues[index]===undefined){rt.pendingValues[index]=compute(ctx,rt);rt.pendingIndices.push(index);}
  return rt.pendingValues[index];
 }
 const prior=rt.keeps[index];if(prior!==undefined)return prior;
 const view=rt.viewByKeep[index];if(view)return __viewBase(rt,view);
 const value=compute(ctx,rt);rt.keeps[index]=value;return value;
}
function __tableContains(rt,index,key){return __cellGet(rt,index,key)!==undefined;}
function __tableGet(rt,index,key){const value=__cellGet(rt,index,key);return value===undefined?{None:null}:{Some:value};}
function __tablePut(rt,index,key,next,mode=0){
 const prior=rt.tables[index].get(key),present=prior!==undefined;
 if(mode===1&&present)throw Error('insert key already present');
 if(mode===2&&!present)throw Error('replace key absent');
 if(present&&__stateRootEquals[index](prior,next))return null;
 const updates=rt.cellMode?null:__updateViews(rt,index,key,prior,next);
 __invalidateKeeps(rt,index);__remember(rt,index,key,present,prior);
 __writeCell(rt,index,key,next,prior);__installViews(rt,updates,index);return null;
}
function __tableRemove(rt,index,key){
 const value=rt.tables[index].get(key);
 if(value===undefined)return {None:null};
 const updates=rt.cellMode?null:__updateViews(rt,index,key,value,undefined);
 __invalidateKeeps(rt,index);__remember(rt,index,key,true,value);
 __writeCell(rt,index,key,undefined,value);__installViews(rt,updates,index);return {Some:value};
}
function __table(rt,index,method,args){
 const key=args[0];
 if(method==='get')return __tableGet(rt,index,key);
 if(method==='contains')return __tableContains(rt,index,key);
 const table=rt.tables[index];
 if(method==='values'||method==='keys'){const keys=__orderedKeys(rt,index);return method==='keys'?keys.slice():keys.map(k=>__cellGet(rt,index,k));}
 if(method==='intersect_table'){const current=__readTable(rt,index),other=__readTable(rt,args[0]),small=current.size<=other.size?current:other,large=small===current?other:current;const result=[];for(const k of small.keys())if(large.has(k))result.push(k);return result.sort((a,b)=>__keyCompare(a,b,rt.meta.roots[index].key));}
 if(method==='intersect_keys'){const requested=args[0],size=rt.tables[index].size;
  // Fewer requested keys than rows: look each one up instead of scanning.
  if(requested.length<size){const type=rt.meta.roots[index].key;return [...new Set(requested)].filter(k=>__cellGet(rt,index,k)!==undefined).sort((a,b)=>__keyCompare(a,b,type));}
  const selected=new Set(requested);return __orderedKeys(rt,index).filter(k=>selected.has(k));}
 if(method==='put_many'){const keys=args[0],values=args[1];if(keys.length!==values.length)return {Err:'table bulk length mismatch'};for(let i=0;i<keys.length;i++)__table(rt,index,'put',[keys[i],values[i]]);return {Ok:null};}
 if(method==='remove_many'){for(const k of args[0])__table(rt,index,'remove',[k]);return null;}
 if(method==='remove')return __tableRemove(rt,index,key);
 return __tablePut(rt,index,key,args[1],method==='insert'?1:method==='replace'?2:0);
}

function __rollback(rt,mark){for(let i=rt.undo.length-1;i>=mark;i--){const [index,key,present,value]=rt.undo[i];const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);if(table.has(key)!==present)__tableMembership(rt,index,key,present);if(present)table.set(key,value);else table.delete(key);}rt.undo.length=mark;}
function __recordChange(rt,index,key,prior,next){rt.changeLog.push([index,key,prior,next]);}
function __fixedTableBytes(root,table){
 const writer=__snapshotWriter(__snapshotLimits());
 const rows=[...table.entries()].sort((a,b)=>__keyCompare(a[0],b[0],root.key));
 writer.integer(rows.length,8);
 for(const [key,value]of rows){writer.value(key,root.snapshotKey??root.key);writer.value(value,root.snapshotValue??root.value);}
 return writer.finish();
}
function __createState(meta,implementations,captures=null,views=[],prefixes=[]){
 const rt={meta,tables:__newTables(meta,prefixes),version:meta.compactCommits?0:0n,outbox:__eventLog(meta),staged:[],busy:false,undo:[],seen:meta.roots.map(()=>new Set()),host:null,keeps:new Array(meta.keeps.length),keepDirty:meta.keeps.length?new Uint8Array(meta.keeps.length):null,keepUndoIndices:meta.keeps.length?new Uint32Array(meta.keeps.length):null,keepUndoCount:0};
 const fixed=typeof __stateFrozenFactories==='undefined'?[]:__stateFrozenFactories;
 const fixedBytes=[];
 for(let i=0;i<fixed.length;i++)if(fixed[i]){for(const [key,value]of fixed[i]())rt.tables[i].set(key,value);fixedBytes[i]=__fixedTableBytes(meta.roots[i],rt.tables[i]);}
 function checkFixed(tables){for(let i=0;i<fixedBytes.length;i++)if(fixedBytes[i]){const bytes=__fixedTableBytes(meta.roots[i],tables[i]);if(bytes.length!==fixedBytes[i].length||!bytes.every((v,n)=>v===fixedBytes[i][n]))throw Error('snapshot changes frozen state: '+meta.roots[i].name);}}
 rt.views=views;rt.viewsByRoot=meta.roots.map((_,root)=>views.filter(v=>v.root===root));__rebuildViews(rt);
 rt.viewByKeep=new Array(meta.keeps.length);for(const view of views)rt.viewByKeep[view.keep]=view;
 rt.pendingIndices=[];rt.pendingValues=new Array(meta.keeps.length);
 rt.eventCount=0;rt.eventChannel=null;rt.eventValue=null;
 rt.viewNext=new Array(meta.keeps.length);rt.cell=null;rt.cellMode=false;rt.ctx={fuel:100000000};
 rt.keepBefore=meta.keeps.length?new Array(meta.keeps.length):null;
 rt.changedRoots=new Set();rt.changedOutputs=new Array(meta.keeps.length).fill(0);rt.changedOutputEpoch=0;
 rt.snapshotRows=meta.snapshotRows?meta.roots.map(()=>new Map()):null;
 rt.restoreSpares=null;rt.changeTracking=false;rt.changeLog=[];rt.changeEpoch=0;rt.changeTokens=new Map();
 const actionMap=new Map(meta.actions.map(a=>[a.name,{...a,inputs:captures?captures[a.index]:a.params.map(p=>__stateCapture(p.type)),output:__stateResult(a.result)}]));
 const eventOutput=new Map(meta.events.map(e=>[e.name,__stateResult(e.type)]));
 rt.eventOutput=eventOutput;
 const prepared=new WeakMap();
 const observers=rt.observers=__createObservers((name,args)=>{
  const a=actionMap.get(name);if(!a||a.change)throw Error('subscription requires a readonly query');
  const captured=a.inputs.map((convert,i)=>convert(args[i]));
  const publicArgs=captured.map((v,i)=>__stateResult(a.params[i].type)(v));
  const scalar=['u64','u32','i32','bool','string','unit','enum','id'].includes(a.result.kind);
  return {scalar,committed:scalar&&a.directKeep!==null&&a.directKeep!==undefined?{state:rt,keep:a.directKeep}:null,direct:scalar&&a.directKeep!==null&&a.directKeep!==undefined?()=>rt.keeps[a.directKeep]:null,roots:a.roots,outputs:rt.meta.outputPublication&&a.directKeep!==null&&a.directKeep!==undefined?[a.directKeep]:[],read:!a.precondition&&a.params.length===0?readZero(a,true):()=>run(a,publicArgs,null,null,true),capture:scalar?v=>v:__stateCapture(a.result),output:scalar?v=>v:a.output,equal:__stateQueryEquals[a.index]};
 });
 function invoke(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);return run(a,args);}
 function readZero(a,resultOnly){
  const implementation=implementations[a.index],output=a.output,fresh=a.freshResult;
  if(resultOnly&&fresh&&__stateDirectReadFactories[a.index])return __stateDirectReadFactories[a.index](rt);
  if(a.directKeep!==null&&a.directKeep!==undefined)return ()=>{
   if(rt.busy)throw Error('state operation already in progress');
   const value=rt.keeps[a.directKeep],result=fresh?value:output(value);
   return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};
  };
  return ()=>{
   if(rt.busy)throw Error('state operation already in progress');rt.busy=true;rt.ctx.fuel=100000000;
   try{const value=implementation(rt.ctx,rt),result=fresh?value:output(value);return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};}
   finally{rt.busy=false;}
  };
 }
 function read(a,args,inputs,output,resultOnly,owned=false){
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  rt.busy=true;
  try{const value=implementations[a.index](ctx,rt,...captured),result=a.freshResult?value:(output||a.output)(value);return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};}
  finally{rt.busy=false;}
 }
 function begin(a){
  if(rt.busy)throw Error('state operation already in progress');
  rt.ctx.fuel=100000000;
  rt.actionMark=rt.undo.length;rt.actionVersion=rt.version;rt.actionOutbox=rt.outbox;rt.actionOutboxLength=rt.outbox.length;rt.actionChangeMark=rt.changeLog.length;
  rt.busy=true;rt.cellMode=a.singleCell&&!rt.host;rt.staged.length=0;rt.eventCount=0;rt.changedRoots.clear();rt.actionSuccessful=false;
 }
 function complete(a,value,output,resultOnly){
  const result=a.freshResult?value:(output||a.output)(value);
  const version=rt.actionVersion;
  if(a.fallible && (a.flatFailure?value.tag!==0:Object.hasOwn(value,'Err'))){rt.changeLog.length=rt.actionChangeMark;__rollback(rt,rt.actionMark);__restoreKeeps(rt);if(rt.host?.strict)rt.host.failure=Object.assign(Error('transaction action failed'),{action:a.name,result});return resultOnly?result:{result,committed:false,version:__versionWord(version),events:[]};}
  if(version===18446744073709551615n)throw Error('commit sequence exhausted');
  const next=rt.meta.compactCommits?__nextCommit(version):version+1n;
  const publicNext=resultOnly?null:__versionWord(next);
  __prepareCell(rt);
  const events=resultOnly?null:new Array(rt.eventCount);
  if(rt.eventCount){
   const channel=rt.eventChannel,value=rt.eventValue;
   rt.outbox.push({commit:next,position:0n,channel,value});
   if(events)events[0]={commit:publicNext,position:0n,channel,value:eventOutput.get(channel)(value)};
   for(let i=0;i<rt.staged.length;i++){
    const [channel,value]=rt.staged[i],position=BigInt(i+1);
    rt.outbox.push({commit:next,position,channel,value});
    if(events)events[i+1]={commit:publicNext,position,channel,value:eventOutput.get(channel)(value)};
   }
  }
  __commitCell(rt);rt.version=next;rt.actionSuccessful=true;
  return resultOnly?result:{result,committed:true,version:publicNext,events};
 }
 function abort(e){
  rt.changeLog.length=rt.actionChangeMark;__rollback(rt,rt.actionMark);__restoreKeeps(rt);rt.version=rt.actionVersion;rt.outbox=rt.actionOutbox;rt.outbox.length=rt.actionOutboxLength;if(rt.host?.strict)rt.host.failure=e;throw e;
 }
 function end(){
  const successful=rt.actionSuccessful,single=rt.cellMode;
  rt.cell=null;rt.cellMode=false;rt.staged.length=0;rt.eventCount=0;rt.eventChannel=null;rt.eventValue=null;
  for(const keep of rt.pendingIndices)rt.pendingValues[keep]=undefined;rt.pendingIndices.length=0;
  if(!single){__clearKeepJournal(rt);for(const seen of rt.seen)seen.clear();if(!rt.host)rt.undo.length=0;}
  rt.actionOutbox=null;rt.busy=false;
  if(successful)observers.commit(rt.changedRoots);
 }
 function run(a,args,inputs=null,output=null,resultOnly=false,owned=false){
  if(a.kernels&&!rt.host){
   if(rt.busy)throw Error('state operation already in progress');
   const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
   return a.kernels[resultOnly?1:0](...captured);
  }
  if(!a.change)return read(a,args,inputs,output,resultOnly,owned);
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  begin(a);
  try{return complete(a,implementations[a.index](ctx,rt,...captured),output,resultOnly);}
  catch(e){return abort(e);}
  finally{end();}
 }

 for(const a of actionMap.values())if(__statePreflightFactories[a.index]){
  // run() supplies module-owned captured values; bound native entries still capture composites.
  a.kernels=[false,true].map(only=>__statePreflightFactories[a.index](run,a,a.inputs,a.output,only,rt,begin,complete,abort,end,true));
 }
 return Object.freeze({
  subscribeValues(queries,callback,options){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribeValues(queries,callback,options);},
  subscribeGroup(queries,callback,options){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribeGroup(queries,callback,options);},
  subscribe(...args){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribe(...args);},
  batch:observers.batch,flushSubscriptions:observers.flush,takeSubscriptionErrors:observers.takeErrors,
  transaction(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('transaction callback must be synchronous');this.beginTransaction();rt.host.strict=true;
   try{const value=callback(this);if(value&&typeof value.then==='function')throw TypeError('state transaction callback must be synchronous');this.commitTransaction();return value;}catch(e){this.rollbackTransaction();throw e;}
  },
  invoke,invoke_json:invoke,
  prepare(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);const captured=a.inputs.map((convert,i)=>convert(args[i])),token=Object.freeze({});prepared.set(token,{action:a,args:captured});return token;},
  invokePrepared(token){const packet=prepared.get(token);if(!packet)throw Error('invalid prepared state call');return run(packet.action,packet.args,null,null,false,true);},
  // A prebound typed entrypoint: scalar arguments obey the native caller contract.
  // Composite arguments still capture owned input; events remain in the outbox.
  bind(name,{resultOnly=false}={}){
   const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);
   const inputs=a.params.map((p,i)=>p.type.kind==='f32'?(value=>typeof value==='number'?__bits(value):value.F32Bits):['u32','i32','u64','bool','unit','string','f64','id','enum','int'].includes(p.type.kind)?__representation(p.type,false):a.inputs[i]);
   if(!a.change&&!a.precondition&&inputs.length===0)return readZero(a,resultOnly);
   return (__statePreflightFactories[a.index]||__stateBoundFactories[a.index])(run,a,inputs,a.output,resultOnly,rt,begin,complete,abort,end);
  },
  beginTransaction(){if(rt.busy||rt.host||rt.undo.length)throw Error('transaction already in progress');rt.host={version:rt.version,outbox:rt.outbox,length:rt.outbox.length,keeps:rt.keeps.slice(),changeMark:rt.changeLog.length,notificationMark:observers.hold()};return true;},
  commitTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');if(rt.host.failure)throw rt.host.failure;rt.host=null;rt.undo.length=0;observers.release();},
  rollbackTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');__rollback(rt,0);rt.version=rt.host.version;rt.outbox=rt.host.outbox;rt.outbox.length=rt.host.length;rt.keeps=rt.host.keeps;__refreshActiveViews(rt);rt.changeLog.length=rt.host.changeMark;rt.changeEpoch++;const mark=rt.host.notificationMark;rt.host=null;observers.rollback(mark);},
  changeToken(){
   if(rt.busy||rt.host)throw Error('change token requires transaction boundary');
   const token=Object.freeze({});rt.changeTracking=true;rt.changeTokens.set(token,{epoch:rt.changeEpoch,index:rt.changeLog.length,version:__versionWord(rt.version)});return token;
  },
  releaseChangeToken(token){rt.changeTokens.delete(token);if(!rt.changeTokens.size){rt.changeTracking=false;rt.changeLog.length=0;}},
  changesSince(token){
   if(rt.busy||rt.host)throw Error('changes require transaction boundary');
   const mark=rt.changeTokens.get(token);if(!mark||mark.epoch!==rt.changeEpoch)throw Error('invalid change token lineage');
   const roots=new Map();
   for(let i=mark.index;i<rt.changeLog.length;i++){
    const [root,key,before,after]=rt.changeLog[i];let cells=roots.get(root);if(!cells)roots.set(root,cells=new Map());
    const prior=cells.get(key);if(prior)prior.after=after;else cells.set(key,{before,after});
   }
   const changes=[];
   const codecs=rt.changeOutputs??=meta.roots.map(schema=>({key:__stateResult(schema.key),row:__stateResult(schema.value)}));
   for(const [root,cells]of roots){const schema=meta.roots[root],keyOut=codecs[root].key,rowOut=codecs[root].row;
    for(const [key,{before,after}]of cells){if(before===undefined&&after===undefined||before!==undefined&&after!==undefined&&__stateRootEquals[root](before,after))continue;
     changes.push({table:schema.name,key:keyOut(key),before:before===undefined?{None:null}:{Some:rowOut(before)},after:after===undefined?{None:null}:{Some:rowOut(after)}});
    }
   }
   return {from:mark.version,to:__versionWord(rt.version),changes};
  },
  get version(){return __versionWord(rt.version);},
  get outbox(){return rt.outbox.map(e=>({...e,commit:__versionWord(e.commit),value:eventOutput.get(e.channel)(e.value)}));},
  acknowledgeThrough(commit,position){if(rt.busy)throw Error('state operation already in progress');commit=__stateWord(commit);position=__stateWord(position);const last=rt.outbox.at(-1);if(!last)return;const lastCommit=__versionWord(last.commit);if(lastCommit<commit||(lastCommit===commit&&last.position<=position)){if(rt.host)rt.outbox=__eventLog(meta);else rt.outbox.length=0;return;}rt.outbox=rt.outbox.filter(e=>{const c=__versionWord(e.commit);return c>commit||(c===commit&&e.position>position);});},
  async invokeAsync(name,args){
   if(typeof __parallelInvokeAsync!=='function')return invoke(name,args);
   if(rt.busy||rt.host)throw Error('parallel state call requires transaction boundary');const captured=structuredClone(args);rt.busy=true;observers.hold();let completed=false;
   try{const snapshot=await __snapshotEncode(meta,rt);const reply=await __parallelInvokeAsync(name,captured,snapshot);const s=await __snapshotDecode(meta,reply.snapshot);checkFixed(s.tables);const candidate={...rt,tables:__restoreTables(rt,prefixes,s.tables),keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);const previousTables=rt.tables;rt.tables=candidate.tables;rt.restoreSpares=previousTables.map(table=>table instanceof __DenseTable?table:null);rt.version=__storedCommit(meta,s.version);rt.outbox=__eventLog(meta,s.outbox);rt.keeps=candidate.keeps;rt.activeViewRoots=candidate.activeViewRoots;if(rt.snapshotRows)rt.snapshotRows=meta.roots.map(()=>new Map());rt.changeEpoch++;rt.changeLog.length=0;completed=true;return reply.value;}finally{rt.busy=false;if(completed)observers.commit(meta.roots.map((_,i)=>i));observers.release();}
  },
  checkpoint(limits){if(rt.busy)throw Error('checkpoint requires transaction boundary');return __snapshotEncode(meta,rt,limits);},
  async restore(bytes,limits){if(rt.host)throw Error('restore during transaction');if(rt.busy)throw Error('restore requires transaction boundary');rt.busy=true;rt.ctx.fuel=100000000;observers.hold();let restored=false;try{const s=await __snapshotDecode(meta,bytes,limits);checkFixed(s.tables);const candidate={...rt,tables:__restoreTables(rt,prefixes,s.tables),version:__storedCommit(meta,s.version),outbox:s.outbox,keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);for(const name of meta.invariantChecks||[]){const a=actionMap.get(name);if(implementations[a.index](rt.ctx,candidate)!==true)throw Error('snapshot violates state invariant');}const previousTables=rt.tables;rt.tables=candidate.tables;rt.restoreSpares=previousTables.map(table=>table instanceof __DenseTable?table:null);rt.version=__storedCommit(meta,s.version);rt.outbox=__eventLog(meta,s.outbox);rt.keeps=candidate.keeps;rt.activeViewRoots=candidate.activeViewRoots;if(rt.snapshotRows)rt.snapshotRows=meta.roots.map(()=>new Map());rt.changeEpoch++;rt.changeLog.length=0;restored=true;}finally{rt.busy=false;if(restored)observers.commit(meta.roots.map((_,i)=>i));observers.release();}},
 });
}
function __stateCommitRoot0(rt,key,prior,next,slot){__storeDirect(rt,0,key,prior,next,slot);const publish=rt.meta.outputPublication&&!rt.observers.directRoots[0]&&rt.observers.active;if(publish&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}}
const __stateDirectReadFactories=[];
const __stateFrozenFactories=[];
const __stateQueryEquals=[];
const __stateRootEquals=[(a,b)=>(a===b)];
const __stateBoundFactories=[];const __statePreflightFactories=[];
const __stateMetadata={"actions":[],"compactCommits":false,"eventColumns":false,"eventRuns":false,"events":[],"invariantChecks":[],"keepInvalidations":[[]],"keeps":[],"lazyMaintenance":true,"outputPublication":false,"roots":[{"key":{"kind":"u32"},"name":"Counter","snapshotKey":{"kind":"u32"},"snapshotValue":{"kind":"u32"},"value":{"kind":"u32"}}],"snapshot":{"program":[147,158,19,28,2,101,120,194,53,75,87,139,137,116,54,67,9,43,35,74,241,114,112,134,77,215,234,218,204,80,173,242],"schema":[78,116,32,200,30,17,164,209,84,242,145,99,104,60,11,144,181,111,135,33,24,37,47,123,243,81,245,13,38,7,160,171]},"snapshotRows":false};const __actions=[];const __stateInputCaptures=[];
export function createState(){return __createState(__stateMetadata,__actions,__stateInputCaptures);}
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v8","core_sha256":"c332b40f4d3ae42d6f2d5ddb8b4b1282486897fb0bc9cb34d660f919885da9f8","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"f32_computation":"native-number-with-exact-nonfinite-tags","f32_storage":"exact-u32-bits","functions":[{"destination":null,"index":0,"internal":false,"name":"component","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":1,"internal":false,"name":"energy","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":2,"internal":false,"name":"derivatives","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"destination":null,"index":3,"internal":false,"name":"direction","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":4,"internal":false,"name":"twice","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":5,"internal":false,"name":"selected","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"c","type":{"kind":"bool"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"destination":null,"index":6,"internal":false,"name":"branches","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}},{"name":"c","type":{"kind":"bool"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"destination":null,"index":7,"internal":false,"name":"looping","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"destination":null,"index":8,"internal":false,"name":"strict_unused","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":9,"internal":false,"name":"strict","parallel":false,"params":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":10,"internal":false,"name":"history","parallel":false,"params":[{"name":"x","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}},{"destination":null,"index":11,"internal":false,"name":"__ink_differential_3","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"}},{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"destination":null,"index":12,"internal":false,"name":"__ink_differential_1","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"destination":null,"index":13,"internal":false,"name":"__ink_differential_23","parallel":false,"params":[{"name":"__ink_differential_24","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_25","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":14,"internal":false,"name":"__ink_differential_27","parallel":false,"params":[{"name":"__ink_differential_28","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_29","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":15,"internal":false,"name":"__ink_differential_31","parallel":false,"params":[{"name":"__ink_differential_32","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_33","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":16,"internal":false,"name":"__ink_differential_20","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"}},{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":17,"internal":false,"name":"__ink_differential_19","parallel":false,"params":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"__ink_differential_35","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}}],"named_types":{"Bundle":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},"Node":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"},"Pair":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"},"__ink_differential_0":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"__ink_differential_2":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"},"__ink_differential_21":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"},"__ink_differential_22":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"},"__ink_differential_4":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"},"__ink_differential_5":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},"prepared_compiled":{"destination":{"call":"callPreparedCompiledInto","capacity":"trusted","failure":"destination may be partially written","float_values":"trusted public representation","inputs":"sealed compiled values","ownership":"caller-owned","structured_elements":"detached","tail":"unwritten"},"evaluation":"lazy source-order; successful bindings only","functions":[{"factory":false,"function":"component","reason":"no reusable captured work"},{"factory":false,"function":"energy","reason":"no reusable captured work"},{"delegated_calls":1,"factory":true,"function":"derivatives","retained_bindings":0},{"factory":false,"function":"direction","reason":"no reusable captured work"},{"factory":false,"function":"twice","reason":"no reusable captured work"},{"factory":false,"function":"selected","reason":"no reusable captured work"},{"factory":false,"function":"branches","reason":"no reusable captured work"},{"factory":false,"function":"looping","reason":"no reusable captured work"},{"factory":false,"function":"strict_unused","reason":"no reusable captured work"},{"factory":false,"function":"strict","reason":"no reusable captured work"},{"factory":false,"function":"history","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_3","reason":"prepared residual binding budget"},{"delegated_calls":1,"factory":true,"function":"__ink_differential_1","retained_bindings":1},{"factory":false,"function":"__ink_differential_23","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_27","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_31","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_20","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_19","reason":"no reusable captured work"}],"lifetime":"prepared token","semantics":"sealed-value-residual-v1"},"private_record_elisions":[],"private_sum_spines":[],"schema":1,"state":{"actions":[],"compactCommits":false,"eventColumns":false,"eventRuns":false,"events":[],"invariantChecks":[],"keepInvalidations":[[]],"keeps":[],"lazyMaintenance":true,"outputPublication":false,"roots":[{"key":{"kind":"u32"},"name":"Counter","snapshotKey":{"kind":"u32"},"snapshotValue":{"kind":"u32"},"value":{"kind":"u32"}}],"snapshot":{"program":[147,158,19,28,2,101,120,194,53,75,87,139,137,116,54,67,9,43,35,74,241,114,112,134,77,215,234,218,204,80,173,242],"schema":[78,116,32,200,30,17,164,209,84,242,145,99,104,60,11,144,181,111,135,33,24,37,47,123,243,81,245,13,38,7,160,171]},"snapshotRows":false},"wire":{"format":"ink-value-wire-v1","functions":{"__ink_differential_1":{"arguments":{"format":"ink-value-wire-v1","identity":"0682599d89e5a0da92fd3bb3a63bdbef728533bcace07efac64cbc6207072abd","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"7882b66162c075a7679604fdc86c31922fb250d10394af5aa2d1354c654b72e5","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}}},"__ink_differential_19":{"arguments":{"format":"ink-value-wire-v1","identity":"4b9a4eccc6d2615eb92680d1626d236c77340ef306b699fe9722c753783a60da","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"__ink_differential_35","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"__ink_differential_20":{"arguments":{"format":"ink-value-wire-v1","identity":"009ea546acc19d5b810484974d68d3c4457e94cf4bde388fdf2151c2e57e2a8b","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"}},{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_23":{"arguments":{"format":"ink-value-wire-v1","identity":"14dad48e9c7540e15bc5834542aecb46075a5f6db75bdf730ed1ae3cea29fd65","named":{},"root":{"fields":[{"name":"__ink_differential_24","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_25","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_27":{"arguments":{"format":"ink-value-wire-v1","identity":"3ff642723860241049980d889d5b40bc6385dbe1d5565864a6f0cff2789d7d65","named":{},"root":{"fields":[{"name":"__ink_differential_28","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_29","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_3":{"arguments":{"format":"ink-value-wire-v1","identity":"1d368d11ae3fd3df968cc51472c46914649ff205acd33e8d0894f38dfbe17c52","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"}},{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"bb2b2f3efce5ad7f78fd263ef8cf59e1adcabaeb4e987b0d193c2a16c631b760","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}},"__ink_differential_31":{"arguments":{"format":"ink-value-wire-v1","identity":"b89078033f0e43e3b942a030299778636af73ee6bf52de60b442828bffa87a4a","named":{},"root":{"fields":[{"name":"__ink_differential_32","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_33","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"branches":{"arguments":{"format":"ink-value-wire-v1","identity":"7e470bcf24f723adb7da774fec6821c355982fbef8ce2c31b5fee833dcc69a2c","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"c","type":{"kind":"bool"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"5728eeaa0e138ea2f93b2c91d176edec672a97fdd0e45fa08b4dacd31d4beebf","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}},"component":{"arguments":{"format":"ink-value-wire-v1","identity":"9e9f426322cda6dcb4444ebcf8caf3792884cce27574c91c49d8c179e163ada6","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"derivatives":{"arguments":{"format":"ink-value-wire-v1","identity":"0682599d89e5a0da92fd3bb3a63bdbef728533bcace07efac64cbc6207072abd","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"7882b66162c075a7679604fdc86c31922fb250d10394af5aa2d1354c654b72e5","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}}},"direction":{"arguments":{"format":"ink-value-wire-v1","identity":"0682599d89e5a0da92fd3bb3a63bdbef728533bcace07efac64cbc6207072abd","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"energy":{"arguments":{"format":"ink-value-wire-v1","identity":"0682599d89e5a0da92fd3bb3a63bdbef728533bcace07efac64cbc6207072abd","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"history":{"arguments":{"format":"ink-value-wire-v1","identity":"cc08f1332c0bbd676577f3e81f06e85cc8ef81a32bcbe10b3177d811cc8e0ae2","named":{},"root":{"fields":[{"name":"x","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"06a5b110d3c213512730b89ea5797ec6a338f55b0c357c4c3894a84ac3cfa9e3","named":{"Node":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}},"root":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}}},"looping":{"arguments":{"format":"ink-value-wire-v1","identity":"3d9fa005996e654b10e4e749ab0e2c4a9988b4ba944f21f1019c2132cbcb62b2","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"5728eeaa0e138ea2f93b2c91d176edec672a97fdd0e45fa08b4dacd31d4beebf","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}},"selected":{"arguments":{"format":"ink-value-wire-v1","identity":"a8946948d6a1d8ee77f631669030cc4c45446359c5b73e5817d71710ec234e83","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"c","type":{"kind":"bool"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"5728eeaa0e138ea2f93b2c91d176edec672a97fdd0e45fa08b4dacd31d4beebf","named":{},"root":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}},"strict":{"arguments":{"format":"ink-value-wire-v1","identity":"3a34365b0c77659a92326203e995cfb8b5864a51d9641ba81afbf209004e3844","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f32"}},{"name":"y","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"strict_unused":{"arguments":{"format":"ink-value-wire-v1","identity":"84d59578f8c7aa53acd5daacd88e348b3c426255a392adda48076dcabfcaf9f1","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"twice":{"arguments":{"format":"ink-value-wire-v1","identity":"84d59578f8c7aa53acd5daacd88e348b3c426255a392adda48076dcabfcaf9f1","named":{},"root":{"fields":[{"name":"w","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}}}}};
const __implementations=[__fn0,__fn1,__fn2,__fn3,__fn4,__fn5,__fn6,__fn7,__fn8,__fn9,__fn10,__fn11,__fn12,__fn13,__fn14,__fn15,__fn16,__fn17];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
const __inputTypes=[{"capture":[true,true],"types":[{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"},{"kind":"f32"}]},{"capture":[true,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f32"}]},{"capture":[true,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f32"}]},{"capture":[true,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f32"}]},{"capture":[true],"types":[{"fields":[{"name":"a","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}]},{"capture":[true,true],"types":[{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"},{"kind":"bool"}]},{"capture":[true,true],"types":[{"kind":"f32"},{"kind":"bool"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[true],"types":[{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}]},{"capture":[true,true],"types":[{"kind":"f32"},{"kind":"f32"}]},{"capture":[true],"types":[{"kind":"u32"}]},{"capture":[true,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}]},{"capture":[true,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f32"}]},{"capture":[true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[true,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[true,true,true],"types":[{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"},{"kind":"f32"}]}];
export const functions=Object.freeze({...Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=> {
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const output=__representation(f.result,true);
  const body=__implementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
  const needsInput=input.some(c=>c!==__identity);
  const entry=!needsInput && output===__identity ? implementation :
    (...args)=>{const context=new WeakMap();return output(implementation(...(needsInput ? args.map((v,i)=>input[i](v,context)) : args)),context);};
  return [f.name,entry];
}))),...Object.freeze(Object.fromEntries([["component",(()=>{const c0=__representation(__inputTypes[0].types[0],false,__inputTypes[0].capture[0]);const c1=__representation(__inputTypes[0].types[1],false,__inputTypes[0].capture[1]);const output=__representation(metadata.functions[0].result,true);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity&&output===__identity)return __fn0;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn0(...values),context);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return output(__fn0(v0,v1),context);};})()],
["energy",(()=>{const c0=__representation(__inputTypes[1].types[0],false,__inputTypes[1].capture[0]);const c1=__representation(__inputTypes[1].types[1],false,__inputTypes[1].capture[1]);const output=__representation(metadata.functions[1].result,true);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity&&output===__identity)return __fn1;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn1(...values),context);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return output(__fn1(v0,v1),context);};})()],
["direction",(()=>{const c0=__representation(__inputTypes[3].types[0],false,__inputTypes[3].capture[0]);const c1=__representation(__inputTypes[3].types[1],false,__inputTypes[3].capture[1]);const output=__representation(metadata.functions[3].result,true);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity&&output===__identity)return __fn3;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn3(...values),context);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return output(__fn3(v0,v1),context);};})()],
["twice",(()=>{const c0=__representation(__inputTypes[4].types[0],false,__inputTypes[4].capture[0]);const output=__representation(metadata.functions[4].result,true);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&output===__identity)return __fn4;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn4(...values),context);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return output(__fn4(v0),context);};})()],
["strict_unused",(()=>{const c0=__representation(__inputTypes[8].types[0],false,__inputTypes[8].capture[0]);const output=__representation(metadata.functions[8].result,true);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&output===__identity)return __fn8;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn8(...values),context);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return output(__fn8(v0),context);};})()],
["strict",(()=>{const c0=__representation(__inputTypes[9].types[0],false,__inputTypes[9].capture[0]);const c1=__representation(__inputTypes[9].types[1],false,__inputTypes[9].capture[1]);const output=__representation(metadata.functions[9].result,true);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=false;if(c0===__identity&&c1===__identity&&output===__identity)return __fn9;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn9(...values),context);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return output(__fn9(v0,v1),context);};})()],
["__ink_differential_19",(()=>{const c0=__representation(__inputTypes[17].types[0],false,__inputTypes[17].capture[0]);const c1=__representation(__inputTypes[17].types[1],false,__inputTypes[17].capture[1]);const c2=__representation(__inputTypes[17].types[2],false,__inputTypes[17].capture[2]);const output=__representation(metadata.functions[17].result,true);const input=[c0,c1,c2],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity&&c2===__identity&&output===__identity)return __fn17;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return output(__fn17(...values),context);};return function(a0,a1,a2){if(arguments.length!==3)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object')+Number(c2!==__identity&&a2!==null&&typeof a2==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);const v2=c2(a2,context);return output(__fn17(v0,v1,v2),context);};})()]]))});
export function call(name,args) { return functions[name](...args); }
// Shared bounded binary codec; generated code supplies exact descriptors.
export const valueWireFormat='ink-value-wire-v1';
// A connection agrees on the complete value schema before using this format.
// Version byte + schema-directed fields; schema identity is out of band.
export const compactValueWireFormat='ink-value-session-v1';
const wireMagic=Uint8Array.of(73,78,75,86,65,76,0,1);
const wireEncoder=new TextEncoder(),wireDecoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const wireDefaults=Object.freeze({bytes:16777216,nodes:1000000,depth:128}),wireDefaultOptions=Object.freeze({});
const wireDecimal=s=>typeof s==='string'&&/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(s);
function wireLimits(options){if(options===wireDefaultOptions||options===wireDefaults)return wireDefaults;const l={...wireDefaults,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>wireDefaults[k])throw Error('wire hard resource limit');return l;}
const wireFloat=new DataView(new ArrayBuffer(4));
function wireDecodeText(bytes,start,end){
 if(end-start<=16){let text='';for(let i=start;i<end;i++){const byte=bytes[i];if(byte>=128)return wireDecoder.decode(bytes.subarray(start,end));text+=String.fromCharCode(byte);}return text;}
 return wireDecoder.decode(bytes.subarray(start,end));
}
function wireUtf8Length(text){let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const wireOwn=(v,k)=>v!==null&&typeof v==='object'&&Object.hasOwn(v,k);
const wireTagged=(v,k)=>wireOwn(v,k)&&Object.keys(v).length===1;
const wireDouble=new DataView(new ArrayBuffer(8));
function wireF64Bits(v){
 if(typeof v==='number'&&Number.isFinite(v)){wireDouble.setFloat64(0,v,true);return wireDouble.getBigUint64(0,true);}
 if(!wireTagged(v,'F64Bits'))wireInvalidValue();const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))wireInvalidValue();
 const bits=BigInt(text);if(bits>18446744073709551615n)wireInvalidValue();return bits;
}
const wireCanonical=v=>Array.isArray(v)?'['+v.map(wireCanonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort((a,b)=>{const x=Array.from(a,c=>c.codePointAt(0)),y=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]-y[i];return x.length-y.length;}).map(k=>JSON.stringify(k)+':'+wireCanonical(v[k])).join(',')+'}':JSON.stringify(v);
export async function createValueCodec(root,named={}){
 const used=new Set(),budget={nodes:100000};
 function check(t,d=0){
  if(d>64||--budget.nodes<0)throw Error('wire descriptor limit');
  const keys={u32:['kind'],u64:['kind'],i32:['kind'],f32:['kind'],f64:['kind'],bool:['kind'],unit:['kind'],string:['kind'],int:['kind'],id:['kind','name'],ref:['kind','name'],enum:['kind','name','variants'],record:['kind','name','fields'],list:['kind','element'],option:['kind','element'],vector:['kind','element','size'],result:['kind','ok','error']}[t?.kind];
  if(!keys||Object.keys(t).length!==keys.length||keys.some(k=>!Object.hasOwn(t,k)))throw Error('invalid wire descriptor');
  if(keys.includes('name')&&(typeof t.name!=='string'||!t.name.isWellFormed()))throw Error('invalid descriptor name');
  if(t.kind==='ref'){if(!used.has(t.name)){used.add(t.name);if(named[t.name]?.kind!=='record'||named[t.name].name!==t.name)throw Error('unresolved wire reference');check(named[t.name],d+1);}}
  if(t.kind==='record'){if(!Array.isArray(t.fields))throw Error('wire fields');const names=new Set();for(const f of t.fields){if(Object.keys(f).length!==2||typeof f.name!=='string'||!f.name.isWellFormed()||names.has(f.name))throw Error('duplicate wire field');names.add(f.name);check(f.type,d+1);}}
  if(t.kind==='enum'&&(!Array.isArray(t.variants)||!t.variants.length||t.variants.length>64||t.variants.some(v=>typeof v!=='string'||!v.isWellFormed())||new Set(t.variants).size!==t.variants.length))throw Error('wire enum');
  if(['list','vector','option'].includes(t.kind)){if(t.kind==='vector'&&(!Number.isInteger(t.size)||t.size<1||t.size>64))throw Error('wire vector');check(t.element,d+1);}
  if(t.kind==='result'){check(t.ok,d+1);check(t.error,d+1);}
 }
 check(root);const names=Object.fromEntries([...used].sort().map(k=>[k,named[k]]));
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',wireEncoder.encode(wireCanonical({format:valueWireFormat,root,named:names}))));
 return new ValueCodec({format:valueWireFormat,root,named:names,identity:Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('')});
}
// Resolve immutable descriptor edges once. Logical validation traverses the
// literal schema; single-child nodes use a loop rather than recursive closures.
function wireValuePlan(codec){
 const seen=new WeakMap();let remaining=100000;
 const build=type=>{
  const t=codec.resolve(type);if(seen.has(t))return seen.get(t);
  if(--remaining<0)throw Error('wire descriptor limit');const p={kind:t.kind,type:t,decode:null,decodeCompact:null};seen.set(t,p);
  if(t.kind==='record')p.fields=t.fields.map(f=>({name:f.name,plan:build(f.type)}));
  if(t.kind==='list'||t.kind==='vector'||t.kind==='option')p.element=build(t.element);
  if(t.kind==='result'){p.ok=build(t.ok);p.error=build(t.error);}
  return p;
 };return build(codec.descriptor.root);
}
function wireBindDecodePlan(root,compact=false){
 const seen=new Set(),pending=[root];let flags=0;
 while(pending.length){
  const p=pending.pop();if(seen.has(p))continue;seen.add(p);if(compact)p.decodeCompact=compactDecodeOperation(p);else p.decode=wireDecodeOperation(p);
  if(p.fields?.length>4)flags|=1;
  if(p.kind==='u32'||p.kind==='i32'||p.kind==='u64'||p.kind==='f32'||p.kind==='f64')flags|=2;
  if(p.fields)for(const f of p.fields)pending.push(f.plan);
  if(p.element)pending.push(p.element);
  if(p.ok){pending.push(p.ok);pending.push(p.error);}
 }
 return flags|4;
}
// Select literal descriptor operations once, without runtime source generation
// or eval. Recursive edges call the completed plan. The generic scanner remains
// the visitor/validation path and an independent materialisation implementation.
function wireReadOperation(p){
 const t=p.type;
 let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':read=(r,end)=>{r.size(end,4);const value={F32Bits:r.view.getUint32(r.cursor,true)};r.cursor=end;return value;};break;
  case 'f64':read=(r,end)=>{r.size(end,8);const value={F64Bits:r.view.getBigUint64(r.cursor,true).toString()};r.cursor=end;return value;};break;
  case 'u64':read=(r,end)=>{r.size(end,8);const value=r.view.getBigUint64(r.cursor,true);r.cursor=end;return value;};break;
  case 'string':read=(r,end)=>r.text(end);break;
  case 'int':read=(r,end)=>{const text=r.text(end);if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=(r,end)=>{const text=r.text(end);if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=(r,end)=>{const text=r.text(end);if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{
    if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;
    if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');
    const values=new Array(n);for(let i=0;i<n;i++)values[i]=element.decode(r,end,d+1);return values;
   };break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1)});break;
    case 2:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1)});break;
    case 3:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1)});break;
    case 4:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1),[fs[3].name]:fs[3].plan.decode(r,end,d+1)});break;
    default:read=(r,end,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decode(r,end,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,end,d)=>{const tag=r.tag(end);return tag?{Some:p.element.decode(r,end,d+1)}:{None:null};};break;
  case 'result':read=(r,end,d)=>r.tag(end)?{Err:p.error.decode(r,end,d+1)}:{Ok:p.ok.decode(r,end,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function wireDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=wireReadOperation(field.plan),name=field.name;
  return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),childEnd=r.enter(end,d+1),item=read(r,childEnd,d+1);if(r.cursor!==childEnd)throw Error('trailing wire frame bytes');const value={[name]:item};if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
 }
 const read=wireReadOperation(p);
 return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
}
class WireDecodeCursor{
 constructor(bytes,view,limits){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
// Bind literal validation and postorder visitation once for every descriptor.
// No logical carriers are allocated; projection still validates every child.
function wireScanPlan(root){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,scan:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.scan=wireScanOperation(p);return p;
 };
 return build(root);
}
function wireScanOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':case 'f64':case 'u64':{const size=p.kind==='f32'?4:8;read=(r,end)=>{r.size(end,size);r.cursor=end;};break;}
  case 'string':read=(r,end)=>{let i=r.cursor;while(i<end&&r.bytes[i]<128)i++;if(i<end)wireDecoder.decode(r.bytes.subarray(r.cursor,end));r.cursor=end;};break;
  case 'int':case 'id':case 'enum':read=(r,end)=>{const text=r.text(end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');for(let i=0;i<n;i++)element.scan(r,end,d+1);};break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>{};break;
    case 1:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);};break;
    case 2:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);};break;
    case 3:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);};break;
    case 4:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);fs[3].plan.scan(r,end,d+1);};break;
    default:read=(r,end,d)=>{for(const f of fs)f.plan.scan(r,end,d+1);};
   }break;
  }
  case 'option':read=(r,end,d)=>{if(r.tag(end))p.element.scan(r,end,d+1);};break;
  case 'result':read=(r,end,d)=>{(r.tag(end)?p.error:p.ok).scan(r,end,d+1);};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return (r,parentEnd,d)=>{
  const end=r.enter(parentEnd,d),start=r.cursor,value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');
  const visitor=r.visitor;if(visitor&&(!r.selected||r.selected.has(t.name))){if(r.spans)visitor(t,r.bytes,start,end,d);else visitor(t,r.bytes.subarray(start,end),d);}
  return value;
 };
}
// Separate methods keep decoding's cursor callsites monomorphic. Both cursors
// are checked against the independent generic scanner and malformed fixtures.
class WireScanCursor{
 constructor(bytes,view,limits,visitor,selected,spans){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.visitor=visitor;this.selected=selected;this.spans=spans;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
function compactReadOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=()=>null;break;
  case 'bool':read=r=>{r.require(1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':case 'i32':read=r=>{r.require(4);const n=p.kind==='u32'?r.view.getUint32(r.cursor,true):r.view.getInt32(r.cursor,true);r.cursor+=4;return n;};break;
  case 'f32':read=r=>{r.require(4);const n=r.view.getUint32(r.cursor,true);r.cursor+=4;return {F32Bits:n};};break;
  case 'f64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return {F64Bits:n.toString()};};break;
  case 'u64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return n;};break;
  case 'string':read=r=>r.text();break;
  case 'int':read=r=>{const text=r.text();if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=r=>{const text=r.text();if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=r=>{const text=r.text();if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':read=(r,d)=>{const n=r.count();if(n>r.remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');const values=new Array(n);for(let i=0;i<n;i++)values[i]=p.element.decodeCompact(r,d+1);return values;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1)});break;
    case 2:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1)});break;
    case 3:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1)});break;
    case 4:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1),[fs[3].name]:fs[3].plan.decodeCompact(r,d+1)});break;
    default:read=(r,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decodeCompact(r,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,d)=>r.tag()?{Some:p.element.decodeCompact(r,d+1)}:{None:null};break;
  case 'result':read=(r,d)=>r.tag()?{Err:p.error.decodeCompact(r,d+1)}:{Ok:p.ok.decodeCompact(r,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function compactDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=compactReadOperation(field.plan),name=field.name;
  return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');if(d+1>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return {[name]:read(r,d+1)};};
 }
 const read=compactReadOperation(p);
 return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return read(r,d);};
}
class CompactDecodeCursor{
 constructor(bytes,limits,flags){this.bytes=bytes;this.view=flags&2?new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength):null;this.cursor=1;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 require(n){if(n>this.bytes.length-this.cursor)throw Error('truncated compact value');}
 count(){
  if(this.cursor>=this.bytes.length)throw Error('truncated compact value');
  const first=this.bytes[this.cursor++];if(first<128)return first;
  let value=first&127,scale=128;
  for(let i=1;i<5;i++){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const byte=this.bytes[this.cursor++];if(i===4&&byte>15)throw Error('compact count overflow');value+=(byte&127)*scale;if(byte<128){if(byte===0)throw Error('noncanonical compact count');return value;}scale*=128;}throw Error('compact count overflow');
 }
 tag(){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const tag=this.bytes[this.cursor++];if(tag>1)throw Error('wire sum tag');return tag;}
 text(){const n=this.count();this.require(n);const start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
function wireInvalidValue(){throw Error('invalid value for wire schema');}
// Capture has the canonical logical meaning of decode(encode(value)), without
// allocating wire bytes. A separate plan leaves validation/decoder hot shapes
// unchanged and never retains host input containers between calls.
function wireCapturePlan(root,checked=true){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,capture:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({name:f.name,plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.capture=checked?wireCaptureOperation(p):wireCopyOperation(p);return p;
 };return build(root);
}
function wireCaptureOperation(p){
 const t=p.type;let copy;
 switch(p.kind){
  case 'unit':copy=v=>{if(v!==null)wireInvalidValue();return null;};break;
  case 'bool':copy=(v,r)=>{if(typeof v!=='boolean')wireInvalidValue();r.add(1);return v;};break;
  case 'u32':case 'i32':{
   const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
   copy=(v,r)=>{if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();r.add(4);return v===0?0:v;};break;
  }
  case 'u64':copy=(v,r)=>{const kind=typeof v;if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();r.add(8);return n;};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'int':case 'id':case 'enum':copy=(v,r)=>{const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;if(typeof text!=='string'||!text.isWellFormed()||text.length>r.limit)wireInvalidValue();if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();r.add(wireUtf8Length(text));return p.kind==='int'?{Int:text}:text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   copy=(v,r,d)=>{if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();const n=v.length;if(n>r.remaining||size!==null&&n!==size)wireInvalidValue();r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=element.capture(v[i],r,d+1);return out;};break;
  }
  case 'record':{
   const fs=p.fields;let fields;
   switch(fs.length){
    case 0:fields=()=>({});break;
    case 1:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:fields=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }
   copy=(v,r,d)=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();for(const f of fs)if(!wireOwn(v,f.name))wireInvalidValue();return fields(v,r,d);};break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'None')&&v.None===null)return {None:null};if(wireTagged(v,'Some'))return {Some:p.element.capture(v.Some,r,d+1)};wireInvalidValue();};break;
  case 'result':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'Ok'))return {Ok:p.ok.capture(v.Ok,r,d+1)};if(wireTagged(v,'Err'))return {Err:p.error.capture(v.Err,r,d+1)};wireInvalidValue();};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
class WireCaptureCursor{
 constructor(limits){this.remaining=limits.nodes;this.depth=limits.depth;this.limit=limits.bytes;this.bytes=40;this.add(0);}
 add(n){this.bytes+=n;if(this.bytes>this.limit)throw Error('wire byte limit');}
 enter(depth,bytes){if(depth>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.add(bytes);}
 text(value){if(value.length>this.limit)throw Error('wire byte limit');this.add(wireUtf8Length(value));}
}
// Literal lowerers share this fixed resource policy with logical capture.
export function createValueCaptureBudget(options=wireDefaultOptions){return new WireCaptureCursor(wireLimits(options));}
// The trusted-value API has the same canonical copy and ownership semantics.
// Its caller supplies a stable value accepted by validateValue. Shape/range
// checks remain at external capture boundaries; resource limits still apply.
function wireCopyOperation(p){
 let copy;
 switch(p.kind){
  case 'unit':copy=()=>null;break;
  case 'bool':copy=(v,r)=>{r.add(1);return v;};break;
  case 'u32':copy=(v,r)=>{r.add(4);return v>>>0;};break;
  case 'i32':copy=(v,r)=>{r.add(4);return v|0;};break;
  case 'u64':copy=(v,r)=>{r.add(8);return BigInt(v);};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'){wireFloat.setFloat32(0,v,true);bits=wireFloat.getUint32(0,true);}else bits=v.F32Bits;r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'id':case 'enum':copy=(v,r)=>{r.add(wireUtf8Length(v));return v;};break;
  case 'int':copy=(v,r)=>{const text=typeof v==='bigint'?v.toString():v.Int;r.add(wireUtf8Length(text));return {Int:text};};break;
  case 'list':case 'vector':copy=(v,r,d)=>{const n=v.length;if(n>r.remaining)throw Error('wire sequence size');r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=p.element.capture(v[i],r,d+1);return out;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:copy=()=>({});break;
    case 1:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:copy=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'None')&&v.None===null?{None:null}:{Some:p.element.capture(v.Some,r,d+1)};};break;
  case 'result':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'Ok')?{Ok:p.ok.capture(v.Ok,r,d+1)}:{Err:p.error.capture(v.Err,r,d+1)};};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
// Emit the cached literal schema with one forward writer. Each value is checked
// where it is consumed; byte bounds belong to the writer, not a second size walk.
function wireEncodeValue(root,value,l,w){
 let remaining=l.nodes;const depthLimit=l.depth;
 const node=(p,v,d)=>{
  if(d>depthLimit||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type,start=w.beginNode();
  switch(p.kind){
   case 'unit':if(v!==null)wireInvalidValue();break;
   case 'bool':if(typeof v!=='boolean')wireInvalidValue();w.byte(+v);break;
   case 'u32':case 'i32':{
    const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
    if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();w.word(v>>>0);break;
   }
   case 'u64':{
    const kind=typeof v;
    if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
    const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();w.wide(n);break;
   }
   case 'f64':w.wide(wireF64Bits(v));break;
   case 'f32':{
    let bits;
    if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}
    else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
    w.word(bits);break;
   }
   case 'string':case 'int':case 'id':case 'enum':{
    const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
    if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&(typeof text!=='string'||!/^[0-9a-f]{32}$/.test(text))||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
    w.text(text);break;
   }
   case 'list':case 'vector':{
    if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
    if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
    w.count(v.length);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);break;
   }
   case 'record':{
    const fs=p.fields;
    if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
    for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
    for(let i=0;i<fs.length;i++){const f=fs[i];node(f.plan,v[f.name],d+1);}break;
   }
   case 'option':{
    if(wireTagged(v,'None')&&v.None===null)w.byte(0);
    else if(wireTagged(v,'Some')){w.byte(1);node(p.element,v.Some,d+1);}else wireInvalidValue();break;
   }
   case 'result':{
    if(wireTagged(v,'Ok')){w.byte(0);node(p.ok,v.Ok,d+1);}
    else if(wireTagged(v,'Err')){w.byte(1);node(p.error,v.Err,d+1);}else wireInvalidValue();break;
   }
   default:throw Error('unsupported wire kind');
  }
  w.endNode(start);
 };
 node(root,value,0);
}
function wireCheckValue(root,value,l){
 let remaining=l.nodes,total=40;
 const add=n=>{total+=n;if(total>l.bytes)throw Error('wire byte limit');};
 const node=(p,v,d)=>{
  while(true){
   if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
   const t=p.type;
   switch(p.kind){
    case 'unit':if(v!==null)wireInvalidValue();add(4);return;
    case 'bool':if(typeof v!=='boolean')wireInvalidValue();add(5);return;
    case 'u32':case 'i32':{
     const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
     if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();add(8);return;
    }
    case 'u64':{
     const kind=typeof v;
     if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
     const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();add(12);return;
    }
    case 'f64':wireF64Bits(v);add(12);return;
    case 'f32':{
     if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();}
     else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();const bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
     add(8);return;
    }
    case 'string':case 'int':case 'id':case 'enum':{
     const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
     if(typeof text!=='string'||!text.isWellFormed()||text.length>l.bytes)wireInvalidValue();
     if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
     add(4+wireUtf8Length(text));return;
    }
    case 'list':case 'vector':{
     if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
     if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
     add(8);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);return;
    }
    case 'record':{
     const fs=p.fields;
     if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
     for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
     add(4);if(!fs.length)return;
     for(let i=0;i<fs.length-1;i++)node(fs[i].plan,v[fs[i].name],d+1);
     const f=fs[fs.length-1];p=f.plan;v=v[f.name];d++;continue;
    }
    case 'option':{
     if(wireTagged(v,'None')&&v.None===null){add(5);return;}
     if(!wireTagged(v,'Some'))wireInvalidValue();add(5);p=p.element;v=v.Some;d++;continue;
    }
    case 'result':{
     if(wireTagged(v,'Ok')){add(5);p=p.ok;v=v.Ok;}
     else if(wireTagged(v,'Err')){add(5);p=p.error;v=v.Err;}else wireInvalidValue();
     d++;continue;
    }
    default:throw Error('unsupported wire kind');
   }
  }
 };
 node(root,value,0);if(total>l.bytes)throw Error('wire byte limit');
}
// A single cursor replaces per-node child closures and {end,value} temporaries.
// Projection filters limit callback materialisation, never schema validation.
function wireScanValue(root,bytes,view,l,materialize,visitor,selected,spans){
 let cursor=40,remaining=l.nodes;
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,parentEnd,d)=>{
  if(d>l.depth||--remaining<0||cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const t=p.type,start=cursor+4,end=start+view.getUint32(cursor,true);if(end>parentEnd)throw Error('truncated wire frame');cursor=start;let value;
  switch(p.kind){
   case 'unit':if(end-start!==0)throw Error('malformed wire scalar');value=null;break;
   case 'bool':if(end-start!==1)throw Error('malformed wire scalar');if(bytes[start]>1)throw Error('invalid wire Bool');value=!!bytes[start];cursor=end;break;
   case 'u32':case 'i32':if(end-start!==4)throw Error('malformed wire scalar');value=p.kind==='u32'?view.getUint32(start,true):view.getInt32(start,true);cursor=end;break;
   case 'f32':if(end-start!==4)throw Error('malformed wire scalar');if(materialize)value={F32Bits:view.getUint32(start,true)};cursor=end;break;
   case 'f64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value={F64Bits:view.getBigUint64(start,true).toString()};cursor=end;break;
   case 'u64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value=view.getBigUint64(start,true);cursor=end;break;
   case 'string':case 'int':case 'id':case 'enum':{
    if(p.kind==='string'&&!materialize){let i=start;while(i<end&&bytes[i]<128)i++;if(i<end)wireDecoder.decode(bytes.subarray(start,end));}
    else{const text=wireDecodeText(bytes,start,end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    cursor=end;break;
   }
   case 'list':case 'vector':{
    if(start+4>end)throw Error('wire list count');const n=view.getUint32(start,true);cursor+=4;
    if(n>remaining||n>Math.floor((end-cursor)/4)||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,end,d+1);if(materialize)value.push(child);}break;
   }
   case 'record':{
    const fs=p.fields;
    // Computed literal keys create own data properties even for __proto__ or
    // prototype setters. Common small records need no descriptor allocations.
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:value={};break;case 1:value={[fs[0].name]:node(fs[0].plan,end,d+1)};break;case 2:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1)};break;case 3:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1)};break;case 4:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1),[fs[3].name]:node(fs[3].plan,end,d+1)};break;}
    }else{if(materialize)value={};for(const f of fs){const child=node(f.plan,end,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}}break;
   }
   case 'option':case 'result':{
    if(start===end||bytes[cursor]>1)throw Error('wire sum tag');const tag=bytes[cursor++];
    if(p.kind==='option'&&tag===0){if(materialize)value={None:null};}
    else{const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,end,d+1);if(materialize)value={[label]:child};}break;
   }
   default:throw Error('unsupported wire kind');
  }
  if(cursor!==end)throw Error('trailing wire frame bytes');
  if(visitor&&(!selected||selected.has(t.name))){if(spans)visitor(t,bytes,start,end,d);else visitor(t,bytes.subarray(start,end),d);}
  return value;
 };
 const result=node(root,bytes.length,0);if(cursor!==bytes.length)throw Error('trailing wire bytes');return result;
}
export class ValueCodec{
 #hash;
 #header;
 #headerWords;
 #descriptor;
 #valuePlan;
 #compactCodec;
 #encoder;
 #decodeBound=0;
 #scanPlan=null;
 #capturePlan=null;
 #copyPlan=null;
 get descriptor(){return this.#descriptor;}
 constructor(descriptor){
  // This synchronous path is for compiler-generated immutable metadata. For
  // untrusted descriptors use createValueCodec and compare the computed identity.
  if(descriptor?.format!==valueWireFormat||!/^[0-9a-f]{64}$/.test(descriptor.identity))throw Error('invalid wire schema');
  this.#descriptor=structuredClone(descriptor);this.#hash=Uint8Array.from(descriptor.identity.match(/../g),s=>parseInt(s,16));
  this.#header=new Uint8Array(40);this.#header.set(wireMagic);this.#header.set(this.#hash,8);
  const headerView=new DataView(this.#header.buffer);this.#headerWords=Array.from({length:10},(_,i)=>headerView.getUint32(i*4,true));
  const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}};freeze(this.descriptor);this.#valuePlan=wireValuePlan(this);
 }
 resolve(t){for(let i=0;i<64;i++){if(t.kind!=='ref')return t;t=this.descriptor.named[t.name];if(!t)throw Error('wire reference');}throw Error('wire reference cycle');}
 validateValue(value,options=wireDefaultOptions){wireCheckValue(this.#valuePlan,value,wireLimits(options));return true;}
 capture(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#capturePlan??=wireCapturePlan(this.#valuePlan);return this.#capturePlan.capture(value,new WireCaptureCursor(limits),0);}
 copy(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#copyPlan??=wireCapturePlan(this.#valuePlan,false);return this.#copyPlan.capture(value,new WireCaptureCursor(limits),0);}
 compact(){return this.#compactCodec??=new CompactValueCodec(this);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new WireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.bytes(this.#header);wireEncodeValue(this.#valuePlan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new WireEncoder(options);w.bytes(wireMagic);w.bytes(this.#hash);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 scan(bytes,options=wireDefaultOptions,materialize=false,visitor=null,names=null,spans=false){
  const l=wireLimits(options);if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<44||bytes.length>l.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==this.#headerWords[i])throw Error('wire format or schema mismatch');
  if(names!==null&&(!Array.isArray(names)||names.length>100000||names.some(n=>typeof n!=='string')))throw Error('wire visitor names');
  if(materialize&&!visitor){this.#decodeBound||=wireBindDecodePlan(this.#valuePlan);const cursor=new WireDecodeCursor(bytes,view,l);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#valuePlan.decode(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  if(!materialize){this.#scanPlan??=wireScanPlan(this.#valuePlan);const cursor=new WireScanCursor(bytes,view,l,visitor,names===null?null:new Set(names),spans),value=this.#scanPlan.scan(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  return wireScanValue(this.#valuePlan,bytes,view,l,materialize,visitor,names===null?null:new Set(names),spans);
 }
 visit(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names);}
 visitSpans(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names,true);}
 validate(bytes,options=wireDefaultOptions){this.scan(bytes,options,false);return true;}
 decode(bytes,options=wireDefaultOptions){return this.scan(bytes,options,true);}
}

// Bounded forward emission avoids building and repeatedly joining child buffers.
class WireEncoder{
 #data=new Uint8Array(256);#view=new DataView(this.#data.buffer);#at=0;#remaining;#depth=0;#byteLimit;#depthLimit;
 active=false;
 constructor(options){this.reset(options);}
 reset(options){const limits=wireLimits(options);this.#byteLimit=limits.bytes;this.#depthLimit=limits.depth;this.#remaining=limits.nodes;this.#depth=0;this.#at=0;this.active=true;}
 get capacity(){return this.#data.length;}
 get position(){return this.#at;}
 beginNode(){const at=this.#at;this.word(0);return at;}
 endNode(at){this.patchWord(at,this.#at-at-4);}
 count(n){this.word(n);}
 beginCount(){const at=this.position;this.count(0);return at;}
 endCount(at,n){this.patchWord(at,n);}
 #reserve(size){
  const end=this.#at+size;if(end>this.#byteLimit)throw Error('wire byte limit');
  if(end>this.#data.length){const next=new Uint8Array(Math.min(this.#byteLimit,Math.max(end,this.#data.length*2)));next.set(this.#data.subarray(0,this.#at));this.#data=next;this.#view=new DataView(next.buffer);}
  return end;
 }
 bytes(bytes){const end=this.#reserve(bytes.length);this.#data.set(bytes,this.#at);this.#at=end;}
 byte(n){if(!Number.isInteger(n)||n<0||n>255)throw Error('wire byte range');this.#reserve(1);this.#data[this.#at++]=n;}
 word(n){if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire word range');const end=this.#reserve(4);this.#view.setUint32(this.#at,n,true);this.#at=end;}
 wide(n){if(typeof n!=='bigint'||n<0n||n>18446744073709551615n)throw Error('wire wide range');const end=this.#reserve(8);this.#view.setBigUint64(this.#at,n,true);this.#at=end;}
 text(text,count=false){
  if(typeof text!=='string')throw Error('wire Unicode');
  if(text.length<=16){
   let ascii=true;for(let i=0;i<text.length;i++)if(text.charCodeAt(i)>=128){ascii=false;break;}
   if(ascii){if(count)this.count(text.length);const end=this.#reserve(text.length);for(let i=0;i<text.length;i++)this.#data[this.#at+i]=text.charCodeAt(i);this.#at=end;return;}
  }
  if(!text.isWellFormed())throw Error('wire Unicode');const size=wireUtf8Length(text);if(count)this.count(size);
  const end=this.#reserve(size),r=wireEncoder.encodeInto(text,this.#data.subarray(this.#at,end));if(r.read!==text.length||r.written!==size)throw Error('wire UTF-8 size');this.#at=end;
 }
 patchWord(at,n){if(!Number.isInteger(at)||at<0||at+4>this.#at||!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire patch offset');this.#view.setUint32(at,n,true);}
 patchByte(at,n){if(!Number.isInteger(at)||at<0||at>=this.#at||!Number.isInteger(n)||n<0||n>255)throw Error('wire patch offset');this.#data[at]=n;}
 replace(at,removed,bytes){
  if(!Number.isInteger(at)||!Number.isInteger(removed)||at<0||removed<0||at+removed>this.#at||!(bytes instanceof Uint8Array))throw Error('wire replacement range');
  const extra=bytes.length-removed,end=extra>0?this.#reserve(extra):this.#at+extra;
  this.#data.copyWithin(at+bytes.length,at+removed,this.#at);this.#data.set(bytes,at);this.#at=end;
 }
 // Literal generated writers use balanced frames without per-node callbacks.
 // An exception abandons this invocation; encodeWith never reuses its writer.
 openFrame(){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;return at;}
 closeFrame(at){if(this.#depth===0)throw Error('wire frame boundary');this.#depth--;this.endNode(at);}
 frame(emit){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;try{emit(this);}finally{this.#depth--;}this.endNode(at);}
 reorder(start,spans){
  const sorted=spans.slice().sort((a,b)=>a[0]-b[0]);let at=start;
  for(const [a,b] of sorted){if(!Number.isInteger(a)||!Number.isInteger(b)||a!==at||b<a)throw Error('wire span permutation');at=b;}
  if(start<0||start>this.#at||at!==this.#at)throw Error('wire span permutation');
  if(spans.every((s,i)=>s===sorted[i]))return;
  const copy=this.#data.slice(start,this.#at);at=start;for(const [a,b] of spans){this.#data.set(copy.subarray(a-start,b-start),at);at+=b-a;}
 }
 finish(){if(this.#depth!==0)throw Error('wire frame boundary');return this.#data.slice(0,this.#at);}
}

class CompactWireEncoder extends WireEncoder{
 beginNode(){return 0;}
 endNode(){}
 endCount(at,n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  if(n<128){this.patchByte(at,n);return;}
  const bytes=[];while(n>=128){bytes.push(n%128+128);n=Math.floor(n/128);}bytes.push(n);this.replace(at,1,Uint8Array.from(bytes));
 }
 count(n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  while(n>=128){this.byte(n%128+128);n=Math.floor(n/128);}this.byte(n);
 }
 text(text){super.text(text,true);}
}

function compactScanValue(root,bytes,l,materialize){
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let cursor=1,remaining=l.nodes;
 const require=n=>{if(n>bytes.length-cursor)throw Error('truncated compact value');};
 const count=()=>{
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   require(1);const byte=bytes[cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }throw Error('compact count overflow');
 };
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,d)=>{
  if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type;let value;
  switch(p.kind){
   case 'unit':return null;
   case 'bool':require(1);if(bytes[cursor]>1)throw Error('invalid wire Bool');return !!bytes[cursor++];
   case 'u32':case 'i32':require(4);value=p.kind==='u32'?view.getUint32(cursor,true):view.getInt32(cursor,true);cursor+=4;return value;
   case 'f32':require(4);if(materialize)value={F32Bits:view.getUint32(cursor,true)};cursor+=4;return value;
   case 'f64':require(8);if(materialize)value={F64Bits:view.getBigUint64(cursor,true).toString()};cursor+=8;return value;
   case 'u64':require(8);if(materialize)value=view.getBigUint64(cursor,true);cursor+=8;return value;
   case 'string':case 'int':case 'id':case 'enum':{
    const n=count();require(n);const start=cursor;cursor+=n;
    if(p.kind==='string'&&!materialize){let i=start;while(i<cursor&&bytes[i]<128)i++;if(i<cursor)wireDecoder.decode(bytes.subarray(start,cursor));}
    else{const text=wireDecodeText(bytes,start,cursor);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    return value;
   }
   case 'list':case 'vector':{
    const n=count();if(n>remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,d+1);if(materialize)value.push(child);}return value;
   }
   case 'record':{
    const fs=p.fields;
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:return {};case 1:return {[fs[0].name]:node(fs[0].plan,d+1)};case 2:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1)};case 3:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1)};case 4:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1),[fs[3].name]:node(fs[3].plan,d+1)};}
    }
    if(materialize)value={};for(const f of fs){const child=node(f.plan,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}return value;
   }
   case 'option':case 'result':{
    require(1);const tag=bytes[cursor++];if(tag>1)throw Error('wire sum tag');
    if(p.kind==='option'&&tag===0)return materialize?{None:null}:undefined;
    const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,d+1);
    return materialize?{[label]:child}:undefined;
   }
   default:throw Error('unsupported wire kind');
  }
 };
 const value=node(root,0);if(cursor!==bytes.length)throw Error('trailing compact bytes');return value;
}

// General transport codec, independent of source rewrites and checkpoints.
// The sender/receiver must negotiate this exact identity and format. There is
// deliberately no claim that the bytes themselves identify their schema.
export class CompactValueCodec{
 #source;#plan;#encoder;#decodeBound=0;
 get format(){return compactValueWireFormat;}
 get identity(){return this.#source.descriptor.identity;}
 constructor(valueCodec){if(!(valueCodec instanceof ValueCodec))throw Error('compact codec requires a checked value codec');this.#source=valueCodec;this.#plan=wireValuePlan(valueCodec);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new CompactWireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.byte(1);wireEncodeValue(this.#plan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new CompactWireEncoder(options);w.byte(1);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 #scan(bytes,options,materialize){
  const l=wireLimits(options);
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<1||bytes.length>l.bytes)throw Error('wire byte limit or header');
  if(bytes[0]!==1)throw Error('compact format mismatch');
  if(materialize){this.#decodeBound||=wireBindDecodePlan(this.#plan,true);const cursor=new CompactDecodeCursor(bytes,l,this.#decodeBound);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#plan.decodeCompact(cursor,0);if(cursor.cursor!==bytes.length)throw Error('trailing compact bytes');return value;}
  return compactScanValue(this.#plan,bytes,l,materialize);
 }
 decode(bytes,options=wireDefaultOptions){return this.#scan(bytes,options,true);}
 validate(bytes,options=wireDefaultOptions){this.#scan(bytes,options,false);return true;}
}

// Compiler materialisers consume already validated bytes synchronously. This
// factory is for trusted emitted code, not untrusted descriptor/callback data.
// The complete generic validator runs before any compiler reader is invoked.
class ValidatedValueReader{
 constructor(bytes,compact){this.bytes=bytes;this.view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);this.cursor=compact?1:40;this.compact=compact;}
 frame(){if(this.compact)return 0;const end=this.cursor+4+this.view.getUint32(this.cursor,true);this.cursor+=4;return end;}
 finish(end){if(!this.compact&&this.cursor!==end)throw Error('compiled reader frame mismatch');}
 byte(){return this.bytes[this.cursor++];}
 word(){const n=this.view.getUint32(this.cursor,true);this.cursor+=4;return n;}
 signed(){const n=this.view.getInt32(this.cursor,true);this.cursor+=4;return n;}
 wide(){const n=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return n;}
 count(){if(!this.compact)return this.word();let n=0,scale=1,byte;do{byte=this.byte();n+=(byte&127)*scale;scale*=128;}while(byte>=128);return n;}
 text(end){const n=this.compact?this.count():end-this.cursor,start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
class CompiledCompactValueCodec extends CompactValueCodec{
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,true),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
}
class CompiledValueCodec extends ValueCodec{
 #read;#compiledCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,false),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
 compact(){return this.#compiledCompact??=new CompiledCompactValueCodec(this,this.#read);}
}
export function createCompiledValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new CompiledValueCodec(descriptor,read);}

// Trusted literal materialisers may use this checked reader to validate and
// construct in one traversal. The emitter must use frame/finish at every source
// node, typed text reads and counted sequence reads; arbitrary callbacks do not
// establish a schema correspondence proof. The independent scanner remains the
// validation oracle and the original factory retains its pre-validation path.
function literalValueHeader(identity){
 const bytes=new Uint8Array(40);bytes.set(wireMagic);
 for(let i=0;i<32;i++)bytes[i+8]=parseInt(identity.slice(i*2,i*2+2),16);
 const view=new DataView(bytes.buffer),words=new Uint32Array(10);
 for(let i=0;i<10;i++)words[i]=view.getUint32(i*4,true);
 return words;
}
class CheckedLiteralValueReader {
 constructor(bytes,header,compact,limits){
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<(compact?1:44)||bytes.length>limits.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  if(compact){if(bytes[0]!==1)throw Error('compact format mismatch');}
  else for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==header[i])throw Error('wire format or schema mismatch');
  this.bytes=bytes;this.view=view;
  this.cursor=compact?1:40;this.compact=compact;this.remaining=limits.nodes;this.depth=limits.depth;this.ends=[];
 }
 require(n){if(this.cursor+n>(this.ends.at(-1)??this.bytes.length))throw Error('truncated wire frame');}
 frame(){
  if(this.ends.length>this.depth||--this.remaining<0)throw Error('wire node or depth limit');
  let end=this.bytes.length;
  if(!this.compact){this.require(4);end=this.cursor+4+this.view.getUint32(this.cursor,true);this.require(end-this.cursor);this.cursor+=4;}
  this.ends.push(end);return this.compact?0:end;
 }
 finish(end){
  if(!this.ends.length||!this.compact&&(this.ends.at(-1)!==end||this.cursor!==end))throw Error('compiled reader frame mismatch');
  this.ends.pop();
 }
 byte(){this.require(1);const value=this.bytes[this.cursor++];if(value>1)throw Error('wire sum tag or Bool');return value;}
 word(){this.require(4);const value=this.view.getUint32(this.cursor,true);this.cursor+=4;return value;}
 signed(){this.require(4);const value=this.view.getInt32(this.cursor,true);this.cursor+=4;return value;}
 wide(){this.require(8);const value=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return value;}
 rawCount(){
  if(!this.compact)return this.word();
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   this.require(1);const byte=this.bytes[this.cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }
  throw Error('compact count overflow');
 }
 count(size){
  const value=this.rawCount();
  if(value>this.remaining||size!==undefined&&value!==size)throw Error('wire sequence size');
  return value;
 }
 text(end,kind='string',variants){
  const size=this.compact?this.rawCount():end-this.cursor;
  this.require(size);const start=this.cursor;this.cursor+=size;
  const value=wireDecodeText(this.bytes,start,this.cursor);
  if(kind==='int'&&!wireDecimal(value)||kind==='id'&&!/^[0-9a-f]{32}$/.test(value)||kind==='enum'&&!variants.includes(value))throw Error('malformed wire text');
  return value;
 }
 complete(){if(this.ends.length||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
// Compact source nodes have no individual frame ends: retain the same checked
// depth/node order using a counter, with bounds against the complete buffer.
class CheckedCompactLiteralValueReader extends CheckedLiteralValueReader {
 constructor(bytes,limits){super(bytes,null,true,limits);this.level=0;}
 require(n){if(this.cursor+n>this.bytes.length)throw Error('truncated wire frame');}
 frame(){if(this.level>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.level++;return 0;}
 finish(_end){if(!this.level)throw Error('compiled reader frame mismatch');this.level--;}
 complete(){if(this.level||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
class FusedCompactValueCodec extends CompactValueCodec {
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedCompactLiteralValueReader(bytes,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
}
class FusedValueCodec extends ValueCodec {
 #read;#header;#fusedCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;this.#header=literalValueHeader(this.descriptor.identity);}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedLiteralValueReader(bytes,this.#header,false,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
 compact(){return this.#fusedCompact??=new FusedCompactValueCodec(this,this.#read);}
}
export function createFusedValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new FusedValueCodec(descriptor,read);}
// JSON text is a boundary adapter to an ordinary recursive Ink datatype.
// No JavaScript Number conversion occurs for JSON numeric tokens.
export function jsonNumberToken(s){return typeof s==='string'&&/^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/.test(s);}
// JSON numeric tokens have an ASCII grammar. Check validated UTF-8 spans
// directly, preserving exact lexemes without allocating a decoded String.
function jsonNumberSpan(bytes,lo,hi){
 let at=lo;if(bytes[at]===45)at++;
 if(at>=hi)return false;
 if(bytes[at]===48)at++;
 else{if(bytes[at]<49||bytes[at]>57)return false;do{at++;}while(at<hi&&bytes[at]>=48&&bytes[at]<=57);}
 if(at<hi&&bytes[at]===46){const start=++at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 if(at<hi&&(bytes[at]===69||bytes[at]===101)){at++;if(at<hi&&(bytes[at]===43||bytes[at]===45))at++;const start=at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 return at===hi;
}
const jsonWireEncoder=new TextEncoder();
// Scalar conversion completes before writer callbacks; no per-value byte array.
const jsonFloatScratch=new DataView(new ArrayBuffer(4));
function jsonUtf8Length(text){if(text.length>16&&!/[^\x00-\x7f]/.test(text))return text.length;let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const jsonLimits={bytes:16777216,nodes:1000000,depth:128};
const jsonQuoters=new WeakSet();
/** Explicit, bounded reuse of immutable JSON string quotes. Cache payload bytes
 * are UTF-16 storage estimates; entry caps bound separate Map/object overhead.
 * Logical output budgets are charged again on every use, including cache hits.
 */
export function createJsonQuoter({maxEntries=1024,maxBytes=131072}={}){
 if(!Number.isSafeInteger(maxEntries)||maxEntries<0||maxEntries>65536||!Number.isSafeInteger(maxBytes)||maxBytes<0||maxBytes>16777216)throw Error('JSON quote cache budget');
 const entries=new Map();let bytes=0,hits=0,misses=0;
 const token=value=>{
  const prior=entries.get(value);if(prior!==undefined){hits++;return prior;}
  if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid JSON String');
  misses++;const text=JSON.stringify(value),size=2*(value.length+text.length),quoted=Object.freeze({text,utf8Bytes:jsonUtf8Length(text)});
  if(maxEntries&&size<=maxBytes){
   while(entries.size&&(entries.size>=maxEntries||bytes+size>maxBytes)){const key=entries.keys().next().value;bytes-=2*(key.length+entries.get(key).text.length);entries.delete(key);}
   entries.set(value,quoted);bytes+=size;
  }
  return quoted;
 };
 const quoter=Object.freeze({
  token,
  quote(value){return token(value).text;},
  clear(){entries.clear();bytes=0;},
  stats(){return {entries:entries.size,payload_bytes:bytes,hits,misses};},
 });jsonQuoters.add(quoter);return quoter;
}
function checkedJsonLimits(options){const l={...jsonLimits,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>jsonLimits[k])throw Error('JSON hard resource limit');return l;}
function jsonVariant(index,item){let payload=index===0?{}:{item0:item};if(index<5)payload={Ok:payload};for(let i=0;i<index;i++)payload={Err:payload};return {payload};}
export function parseJson(text,options={}){return parseJsonValue(text,options,null);}
function parseJsonValue(text,options,boundary){
 const p=new JsonWireReader(text,options);
 const value=(d,wireDepth=0)=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){boundary?.node(0,wireDepth);p.at+=4;return jsonVariant(0,null);}if(c==='t'&&text.startsWith('true',p.at)){boundary?.node(1,wireDepth);p.at+=4;return jsonVariant(1,true);}if(c==='f'&&text.startsWith('false',p.at)){boundary?.node(1,wireDepth);p.at+=5;return jsonVariant(1,false);}
  if(c==='"'){boundary?.node(3,wireDepth);const item=p.string();boundary?.text(item);return jsonVariant(3,item);}
  if(c==='['){boundary?.node(4,wireDepth);p.at++;const xs=[];if(!p.eat(']'))while(true){xs.push(value(d+1,wireDepth+8));if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}return jsonVariant(4,xs);}
  if(c==='{'){boundary?.node(5,wireDepth);p.at++;const xs=[],seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary?.member(key,wireDepth);if(!p.eat(':'))throw Error('JSON object colon');xs.push({key,value:value(d+1,wireDepth+9)});if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}return jsonVariant(5,xs);}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();boundary?.node(2,wireDepth);boundary?.text(token);return jsonVariant(2,token);}
  throw Error('invalid JSON value');
 };
 const out=value(0);p.finish();return out;
}
export function stringifyJson(value,options={}){return stringifyJsonValue(value,options,null);}
function stringifyJsonValue(value,options,boundary){
 const l=checkedJsonLimits(options);let remaining=l.nodes,bytes=0,output='';
 const emit=s=>{bytes+=jsonUtf8Length(s);if(bytes>l.bytes)throw Error('JSON byte limit');output+=s;};
 const write=(v,d,wireDepth=0)=>{
  if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');if(!v||Object.keys(v).length!==1||!Object.hasOwn(v,'payload'))throw Error('invalid JSON record');let p=v.payload,index=0;
  while(index<5&&p&&Object.hasOwn(p,'Err')){if(Object.keys(p).length!==1||boundary&&Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Err;index++;}
  if(index<5){if(!p||Object.keys(p).length!==1||!Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Ok;}
  if(!p||Object.keys(p).length!==(index===0?0:1)||index>0&&!Object.hasOwn(p,'item0'))throw Error('invalid JSON payload');const item=p.item0;boundary?.node(index,wireDepth);
  switch(index){
   case 0:emit('null');break;
   case 1:if(typeof item!=='boolean')throw Error('invalid JSON Boolean');emit(item?'true':'false');break;
   case 2:if(!jsonNumberToken(item))throw Error('invalid JSON number');boundary?.text(item);emit(item);break;
   case 3:if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary?.text(item);emit(JSON.stringify(item));break;
   case 4:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Array');const count=item.length;let visited=0;emit('[');item.forEach((x,i)=>{visited++;if(i)emit(',');write(x,d+1,wireDepth+8);});if(visited!==count)throw Error('invalid JSON Array');emit(']');break;}
   case 5:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Object');const count=item.length,seen=new Set();let visited=0;emit('{');item.forEach((m,i)=>{visited++;if(!m||Object.keys(m).length!==2||typeof m.key!=='string'||!m.key.isWellFormed()||!Object.hasOwn(m,'value')||boundary&&!Object.hasOwn(m,'key'))throw Error('invalid JSON member');if(seen.has(m.key))throw Error('duplicate JSON object key');seen.add(m.key);boundary?.member(m.key,wireDepth);if(i)emit(',');emit(JSON.stringify(m.key));emit(':');write(m.value,d+1,wireDepth+9);});if(visited!==count)throw Error('invalid JSON Object');emit('}');break;}
  }
 };write(value,0);return output;
}
// The adapter's schema is the fixed recursive JSON library shape checked by
// JsonCodec. Charge its ordinary record/sum/list wire nodes while parsing or
// rendering, rather than interpreting and walking the completed tree again.
function jsonBoundaryBudget(options){
 const l=checkedJsonLimits(options);let remaining=l.nodes,total=40;
 const charge=(nodes,bytes,depth)=>{remaining-=nodes;total+=bytes;if(remaining<0||depth>l.depth)throw Error('wire node or depth limit');if(total>l.bytes)throw Error('wire byte limit');};
 return {
  node(index,depth){charge(index===0?3:index<4?index+4:8,index===0?13:index===1?23:index===2?27:index===3?32:41,depth+(index===0?2:index<4?index+3:7));},
  text(text){charge(0,jsonUtf8Length(text),0);},
  member(key,depth){charge(2,8+jsonUtf8Length(key),depth+9);},
 };
}
function jsonSameSchema(a,b){
 if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;
 const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>Object.hasOwn(b,k)&&jsonSameSchema(a[k],b[k]));
}
// Host-object conversion is opt-in and JavaScript-only. Inspect data properties
// rather than invoking getters/toJSON; reflection is not a sandbox for proxies.
function jsonJSKeys(value){
 if(!value||typeof value!=='object')throw Error('expected a plain JavaScript object');
 const prototype=Object.getPrototypeOf(value);
 if(prototype!==Object.prototype&&prototype!==null)throw Error('expected a plain JavaScript object');
 const keys=Reflect.ownKeys(value);
 if(keys.some(k=>typeof k!=='string'))throw Error('JavaScript symbol keys are unsupported');
 return keys;
}
function jsonJSData(value,key){
 const property=Object.getOwnPropertyDescriptor(value,key);
 if(!property||!property.enumerable||!Object.hasOwn(property,'value'))throw Error('expected an enumerable own data property');
 return property.value;
}
function jsonJSRecord(value,names){
 const keys=jsonJSKeys(value);
 if(keys.length!==names.length||keys.some(k=>!names.includes(k)))throw Error('invalid JSON record or variant');
}
function jsonJSArray(value,remaining){
 if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype)throw Error('expected a plain JavaScript array');
 const length=value.length;
 if(length>remaining)throw Error('JSON node limit');
 const keys=Reflect.ownKeys(value);
 if(keys.length!==length+1||keys.some(k=>typeof k!=='string'||k!=='length'&&(!/^(0|[1-9][0-9]*)$/.test(k)||Number(k)>=length)))throw Error('sparse or decorated JavaScript arrays are unsupported');
 return length;
}
function jsonFromJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),active=new WeakSet();let remaining=limits.nodes;
 const text=value=>{if(!value.isWellFormed())throw Error('invalid JSON Unicode');boundary.text(value);return value;};
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  if(value===null){boundary.node(0,wireDepth);return jsonVariant(0);}
  switch(typeof value){
   case 'boolean':boundary.node(1,wireDepth);return jsonVariant(1,value);
   case 'string':boundary.node(3,wireDepth);return jsonVariant(3,text(value));
   case 'number':
    if(!Number.isFinite(value))throw Error('non-finite JavaScript numbers are unsupported');
    boundary.node(2,wireDepth);return jsonVariant(2,text(Object.is(value,-0)?'-0':String(value)));
   case 'bigint':boundary.node(2,wireDepth);return jsonVariant(2,text(String(value)));
   case 'object':break;
   default:throw Error('unsupported JavaScript value');
  }
  if(active.has(value))throw Error('cyclic JavaScript value');
  active.add(value);
  try{
   if(Array.isArray(value)){
    boundary.node(4,wireDepth);const count=jsonJSArray(value,remaining),items=[];
    for(let i=0;i<count;i++)items.push(visit(jsonJSData(value,String(i)),depth+1,wireDepth+8));
    return jsonVariant(4,items);
   }
   boundary.node(5,wireDepth);const keys=jsonJSKeys(value),members=[];
   if(keys.length>remaining)throw Error('JSON node limit');
   for(const key of keys){
    if(!key.isWellFormed())throw Error('invalid JSON Unicode');
    boundary.member(key,wireDepth);
    members.push({key,value:visit(jsonJSData(value,key),depth+1,wireDepth+9)});
   }
   return jsonVariant(5,members);
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
function jsonDecimalKey(token){
 const [,sign,whole,fraction='',exponent='0']=/^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(token);
 const digits=(whole+fraction).replace(/^0+/,'');
 if(!digits)return '0';
 const trimmed=digits.replace(/0+$/,'');
 return sign+trimmed+'e'+(Number(exponent)-fraction.length+digits.length-trimmed.length);
}
function jsonToJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),mode=options?.numbers??'number',active=new WeakSet();let remaining=limits.nodes;
 if(!['number','bigint','string'].includes(mode))throw Error('unknown JavaScript number policy');
 const number=token=>{
  if(!jsonNumberToken(token))throw Error('invalid JSON number');
  boundary.text(token);
  if(mode==='string')return token;
  if(mode==='bigint')return BigInt(jsonInteger(token,4096));
  const result=Number(token);
  if(!Number.isFinite(result)||jsonDecimalKey(token)!==jsonDecimalKey(String(result)))throw Error('JSON number loses precision as JavaScript Number; choose numbers: bigint or string');
  return result;
 };
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  jsonJSRecord(value,['payload']);
  if(active.has(value))throw Error('cyclic JSON value');
  active.add(value);
  try{
   let payload=jsonJSData(value,'payload'),index=0;
   while(index<5&&Object.hasOwn(payload,'Err')){jsonJSRecord(payload,['Err']);payload=jsonJSData(payload,'Err');index++;}
   if(index<5){jsonJSRecord(payload,['Ok']);payload=jsonJSData(payload,'Ok');}
   jsonJSRecord(payload,index===0?[]:['item0']);boundary.node(index,wireDepth);
   const item=index===0?null:jsonJSData(payload,'item0');
   if(index===0)return null;
   if(index===1){if(typeof item!=='boolean')throw Error('invalid JSON Boolean');return item;}
   if(index===2)return number(item);
   if(index===3){if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary.text(item);return item;}
   const count=jsonJSArray(item,remaining);
   if(index===4){const out=[];for(let i=0;i<count;i++)out.push(visit(jsonJSData(item,String(i)),depth+1,wireDepth+8));return out;}
   const out={},seen=new Set();
   for(let i=0;i<count;i++){
    const member=jsonJSData(item,String(i));jsonJSRecord(member,['key','value']);const key=jsonJSData(member,'key');
    if(typeof key!=='string'||!key.isWellFormed())throw Error('invalid JSON member key');
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary.member(key,wireDepth);
    Object.defineProperty(out,key,{value:visit(jsonJSData(member,'value'),depth+1,wireDepth+9),enumerable:true,writable:true,configurable:true});
   }
   return out;
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
const jsonConstructionPaths=Object.freeze(Array.from({length:6},(_,index)=>Object.freeze([0,...Array(index).fill(1),...(index<5?[0]:[]),0])));
function parseJsonConstructed(text,options,builder){
 const p=new JsonWireReader(text,options);
 const paths=jsonConstructionPaths;
 const fused=typeof builder.openPath==='function';
 const begin=index=>{if(fused){builder.openPath(paths[index]);return;}for(const choice of paths[index])builder.open(choice);};
 const end=index=>{for(let i=0;i<(fused?1:index<5?index+3:7);i++)builder.close();};
 const leaf=(index,item)=>{if(typeof builder.scalarPath==='function'){builder.scalarPath(paths[index],item);return;}begin(index);builder.scalar(item);end(index);};
 const value=d=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){p.at+=4;if(typeof builder.emptyPath==='function')builder.emptyPath(paths[0]);else{begin(0);end(0);}return;}
  if(c==='t'&&text.startsWith('true',p.at)){p.at+=4;leaf(1,true);return;}
  if(c==='f'&&text.startsWith('false',p.at)){p.at+=5;leaf(1,false);return;}
  if(c==='"'){leaf(3,p.string());return;}
  if(c==='['){begin(4);builder.open(0);p.at++;if(!p.eat(']'))while(true){value(d+1);if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}builder.close();end(4);return;}
  if(c==='{'){begin(5);builder.open(0);p.at++;const seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');builder.open(0);builder.scalar(key);value(d+1);builder.close();if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}builder.close();end(5);return;}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();leaf(2,token);return;}
  throw Error('invalid JSON value');
 };
 value(0);p.finish();return builder.finish();
}
const jsonCompiledRenderers=new WeakMap();
function compiledJsonRenderer(json,codec,unwrap){
 if(typeof codec?.reducer!=='function')throw Error('compiled JSON reduction unavailable');
 const source=codec.resolve(codec.descriptor.root),root=json.values.descriptor.root;
 const selected=unwrap&&source.kind==='result'?codec.resolve(source.ok):source;
 if(!jsonSameSchema(root,selected)||unwrap&&source.kind!=='result')throw Error('compiled JSON schema mismatch');
 let variants=root.fields[0].type;const roles=new Map([[root.name,'root']]);
 let member;
 for(let index=0;index<6;index++){
  const branch=index<5?variants.ok:variants;roles.set(branch.name,index);
  if(index===5){member=branch.fields[0].type.element.name;roles.set(member,'member');}
  if(index<5)variants=variants.error;
 }
 const nodeRoles=new Map();
 return codec.reducer((node,index)=>{
  const role=roles.get(node.name);nodeRoles.set(index,role);
  if(node.kind==='record'){
   if(role==='root')return value=>value;
   if(role==='member')return (key,value,context)=>{
    const text=(context.quoter?context.quote(key,true):context.add(JSON.stringify(key)+':'))+value,seen=context.members;
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);return text;
   };
   if(role===0)return context=>context.add('null');
   if(role===1)return (value,context)=>context.add(value?'true':'false');
   if(role===2)return (token,context)=>{if(!jsonNumberToken(token))throw Error('invalid JSON number');return context.add(token);};
   if(role===3)return (value,context)=>context.quoter?context.quote(value,false):context.add(JSON.stringify(value));
   if(role===4)return (value,context)=>{context.add('[]');return '['+value+']';};
   if(role===5)return (value,context)=>{context.add('{}');return '{'+value+'}';};
   return ()=>null;
  }
  if(node.kind==='list'||node.kind==='vector'){
   const members=nodeRoles.get(node.children[0])==='member';
   return {
    start:(_length,context)=>{
     const out={text:'',parent:members?context.members:null};
     if(members)context.members=new Set();return out;
    },
    step:(out,value,index,context)=>{out.text+=(index?context.add(','):'')+value;return out;},
    finish:(out,context)=>{if(members)context.members=out.parent;return out.text;},
   };
  }
  if(node.kind==='result'){
   // A Result<Json,E> boundary is explicitly requested by the caller. Ordinary
   // JSON's own sums only propagate an already rendered branch.
   if(unwrap&&nodeRoles.get(node.children[0])==='root')return (tag,value)=>{if(tag)throw Error('JSON result is Err');return value;};
   return (_tag,value)=>value;
  }
  if(node.kind==='string')return value=>{if(!value.isWellFormed())throw Error('invalid JSON String');return value;};
  return value=>value;
 });
}
export class JsonCodec{
 constructor(valueCodec){
  const root=valueCodec.descriptor.root,fields=root.fields;if(root.kind!=='record'||!Array.isArray(fields)||fields.length!==1||fields[0].name!=='payload')throw Error('JSON schema payload');let sum=fields[0].type;
  for(let i=0;i<6;i++){
   if(i<5&&sum.kind!=='result')throw Error('JSON schema sum');const branch=i<5?sum.ok:sum,fs=branch.fields;
   if(branch.kind!=='record'||!Array.isArray(fs)||fs.length!==(i?1:0)||i&&fs[0].name!=='item0')throw Error('JSON schema branch');
   if(i){const t=fs[0].type;if(i===1&&t.kind!=='bool'||(i===2||i===3)&&t.kind!=='string'||i===4&&(t.kind!=='list'||t.element.kind!=='ref'||t.element.name!==root.name))throw Error('JSON schema variant');if(i===5){const mf=t.element?.fields;if(t.kind!=='list'||t.element?.kind!=='record'||!Array.isArray(mf)||mf.length!==2||mf[0].name!=='key'||mf[0].type.kind!=='string'||mf[1].name!=='value'||mf[1].type.kind!=='ref'||mf[1].type.name!==root.name)throw Error('JSON schema member');}}
   if(i===2)this.numberBranch=branch.name;if(i===5)this.objectBranch=branch.name;
   if(i<5)sum=sum.error;
  }if(!jsonSameSchema(root,valueCodec.resolve({kind:'ref',name:root.name})))throw Error('JSON recursive schema mismatch');this.values=valueCodec;
 }
 parse(text,options={}){return parseJsonValue(text,options,jsonBoundaryBudget(options));}
 parseCompiled(codec,text,options={}){
  if(codec?.identity!==this.values.descriptor.identity||typeof codec.builder!=='function')throw Error('compiled JSON schema mismatch');
  const builder=codec.builder(options);try{return parseJsonConstructed(text,options,builder);}catch(error){builder.abort();throw error;}
 }
 stringify(value,options={}){return stringifyJsonValue(value,options,jsonBoundaryBudget(options));}
 stringifyCompiled(codec,handle,options={}){
  const limits=checkedJsonLimits(options),unwrap=options.unwrapResult===true;
  const quoter=options.quoter;if(quoter!==undefined&&!jsonQuoters.has(quoter))throw Error('JSON quote cache owner mismatch');
  let codecs=jsonCompiledRenderers.get(this);if(!codecs)jsonCompiledRenderers.set(this,codecs=new WeakMap());
  let renderers=codecs.get(codec);if(!renderers)codecs.set(codec,renderers=new Map());
  let render=renderers.get(unwrap);if(!render)renderers.set(unwrap,render=compiledJsonRenderer(this,codec,unwrap));
  let bytes=0;const context={
   quoter,
   add(text){bytes+=jsonUtf8Length(text);if(bytes>limits.bytes)throw Error('JSON byte limit');return text;},
   quote(value,colon){
    if(!quoter)return this.add(JSON.stringify(value)+(colon?':':''));
    const token=quoter.token(value);bytes+=token.utf8Bytes+(colon?1:0);if(bytes>limits.bytes)throw Error('JSON byte limit');return token.text+(colon?':':'');
   },
  };
  const text=render(handle,context,limits);
  return text;
 }
 fromJS(value,options={}){return jsonFromJS(value,options);}
 toJS(value,options={}){return jsonToJS(value,options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,false);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,false,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,true);}
 validateBinary(bytes,options={}){
  const decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});let view;
  this.values.visitSpans(bytes,(type,data,start,end)=>{
   view??=new DataView(data.buffer,data.byteOffset,data.byteLength);
   if(type.name===this.numberBranch){const length=view.getUint32(start,true);if(!jsonNumberSpan(data,start+4,start+4+length))throw Error('invalid JSON number token');}
   if(type.name===this.objectBranch){const listEnd=start+4+view.getUint32(start,true),count=view.getUint32(start+4,true),seen=new Set();let at=start+8;for(let i=0;i<count;i++){const memberEnd=at+4+view.getUint32(at,true),keyStart=at+8,keyEnd=keyStart+view.getUint32(at+4,true),key=decoder.decode(data.subarray(keyStart,keyEnd));if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);at=memberEnd;}if(at!==listEnd)throw Error('invalid JSON object frame');}
  },options,[this.numberBranch,this.objectBranch]);return true;

 }
}
function jsonUnpack(value){let p=value.payload,i=0;while(i<5&&Object.hasOwn(p,'Err')){p=p.Err;i++;}return [i,(i<5?p.Ok:p).item0];}
function jsonInteger(token,limit){
 if(!jsonNumberToken(token))throw Error('invalid JSON number');const negative=token[0]==='-',raw=negative?token.slice(1):token,[mantissa,exp='0']=raw.split(/[eE]/);let digits=mantissa.replace('.','');if(/^0+$/.test(digits))return '0';const exponent=Number(exp),fraction=mantissa.includes('.')?mantissa.length-mantissa.indexOf('.')-1:0,shift=exponent-fraction;
 if(!Number.isSafeInteger(exponent)||!Number.isSafeInteger(shift))throw Error('JSON integer exponent limit');
 if(shift<0){const cut=-shift;if(cut>=digits.length||!/^[0]+$/.test(digits.slice(-cut)))throw Error('JSON number is not an integer');digits=digits.slice(0,-cut);}else{if(digits.length+shift>limit)throw Error('JSON integer magnitude limit');digits+='0'.repeat(shift);}
 digits=digits.replace(/^0+/,'');if(digits.length>limit)throw Error('JSON integer magnitude limit');return (negative?'-':'')+digits;
}
function jsonBinary64Value(v){
 if(typeof v==='number')return v;
 const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid F64Bits');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');
 const b=new DataView(new ArrayBuffer(8));b.setBigUint64(0,bits,true);return b.getFloat64(0,true);
}
export class TypedJsonCodec{
 constructor(valueCodec){this.values=valueCodec;}
 decode(document,options={}){
  // Validate JSON-specific invariants before interpreting any tagged/record
  // shape, including duplicated names and malformed numeric tokens.
  stringifyJson(document,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const read=(type,value,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type),[kind,item]=jsonUnpack(value);const fail=()=>{throw Error('JSON does not match '+t.kind);};
   switch(t.kind){
    case 'unit':if(kind!==0)fail();return null;
    case 'bool':if(kind!==1)fail();return item;
    case 'u32':case 'u64':case 'i32':case 'int':{if(kind!==2)fail();const text=jsonInteger(item,t.kind==='int'?4096:t.kind==='u64'?20:10);return t.kind==='int'?{Int:text}:t.kind==='u64'?BigInt(text):Number(text);}
    case 'f64':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(8));if(!Number.isFinite(n))throw Error('JSON f64 overflow');b.setFloat64(0,n,true);return {F64Bits:b.getBigUint64(0,true).toString()};}
    case 'f32':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(4));b.setFloat32(0,n,true);if(!Number.isFinite(b.getFloat32(0,true)))throw Error('JSON f32 overflow');return {F32Bits:b.getUint32(0,true)};}
    case 'string':case 'enum':case 'id':if(kind!==3)fail();return item;
    case 'list':case 'vector':if(kind!==4)fail();return item.map(x=>read(t.element,x,d+1));
    case 'record':{if(kind!==5||item.length!==t.fields.length)throw Error('unknown or missing JSON record field');const fields=new Map(item.map(m=>[m.key,m.value])),out={};for(const f of t.fields){if(!fields.has(f.name))throw Error('missing JSON record field');Object.defineProperty(out,f.name,{value:read(f.type,fields.get(f.name),d+1),writable:true,enumerable:true,configurable:true});}return out;}
    case 'option':case 'result':{if(kind!==5||item.length!==1)fail();const m=item[0];if(t.kind==='option'&&m.key==='None'&&jsonUnpack(m.value)[0]===0)return {None:null};const child=t.kind==='option'&&m.key==='Some'?t.element:t.kind==='result'&&m.key==='Ok'?t.ok:t.kind==='result'&&m.key==='Err'?t.error:null;if(!child)fail();return {[m.key]:read(child,m.value,d+1)};}
    default:fail();
   }
  };
  const out=read(this.values.descriptor.root,document,0);this.values.validateValue(out,options);return out;
 }
 encode(value,options={}){
  this.values.validateValue(value,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const write=(type,v,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type);
   switch(t.kind){
    case 'unit':return jsonVariant(0);
    case 'bool':return jsonVariant(1,v);
    case 'u32':case 'u64':case 'i32':return jsonVariant(2,String(v));
    case 'int':return jsonVariant(2,typeof v==='bigint'?String(v):v.Int);
    case 'f64':{const n=jsonBinary64Value(v);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'f32':{let n;if(typeof v==='number')n=Math.fround(v);else{const b=new DataView(new ArrayBuffer(4));b.setUint32(0,v.F32Bits,true);n=b.getFloat32(0,true);}if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'string':case 'id':case 'enum':return jsonVariant(3,v);
    case 'list':case 'vector':return jsonVariant(4,Array.from(v,x=>write(t.element,x,d+1)));
    case 'record':return jsonVariant(5,t.fields.map(f=>({key:f.name,value:write(f.type,v[f.name],d+1)})));
    case 'option':return jsonVariant(5,[Object.hasOwn(v,'Some')?{key:'Some',value:write(t.element,v.Some,d+1)}:{key:'None',value:jsonVariant(0)}]);
    case 'result':return jsonVariant(5,[Object.hasOwn(v,'Ok')?{key:'Ok',value:write(t.ok,v.Ok,d+1)}:{key:'Err',value:write(t.error,v.Err,d+1)}]);
    default:throw Error('unsupported typed JSON descriptor');
   }
  };return write(this.values.descriptor.root,value,0);
 }
 parse(text,options={}){return this.decode(parseJson(text,options),options);}
 stringify(value,options={}){return stringifyJson(this.encode(value,options),options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,true);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,true,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,false);}
}

// Token reader shared by schema-directed and arbitrary-JSON wire emission.
class JsonWireReader{
 constructor(text,options){this.l=checkedJsonLimits(options);if(typeof text!=='string'||!text.isWellFormed()||text.length>this.l.bytes||jsonUtf8Length(text)>this.l.bytes)throw Error('JSON byte or Unicode limit');this.text=text;this.at=0;this.remaining=this.l.nodes;}
 ws(){while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(c!==32&&c!==9&&c!==10&&c!==13)break;this.at++;}}
 peek(){this.ws();return this.text[this.at];}
 eat(c){this.ws();if(this.text[this.at]===c){this.at++;return true;}return false;}
 node(d){if(d>this.l.depth||--this.remaining<0)throw Error('JSON node or depth limit');}
 string(){
  this.ws();const start=this.at;if(this.text[start]!=='"')throw Error('expected JSON string');
  const end=this.text.indexOf('"',start+1);if(end<0)throw Error('unterminated JSON string');
  const raw=this.text.slice(start+1,end);
  if(!raw.includes('\\')&&!/[\x00-\x1f]/.test(raw)){this.at=end+1;return raw;}
  this.at=start+1;while(this.at<this.text.length){if(this.text[this.at]==='"'){this.at++;const v=JSON.parse(this.text.slice(start,this.at));if(!v.isWellFormed())throw Error('invalid JSON Unicode');return v;}if(this.text[this.at]==='\\')this.at+=2;else this.at++;}throw Error('unterminated JSON string');
 }
 number(){const start=this.at;while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(!(c>=48&&c<=57||c===45||c===43||c===46||c===101||c===69))break;this.at++;}const token=this.text.slice(start,this.at);if(!jsonNumberToken(token))throw Error('invalid JSON number');return token;}
 leaf(d){this.node(d);const c=this.peek();if(c==='n'&&this.text.startsWith('null',this.at)){this.at+=4;return null;}if(c==='t'&&this.text.startsWith('true',this.at)){this.at+=4;return true;}if(c==='f'&&this.text.startsWith('false',this.at)){this.at+=5;return false;}if(c==='"')return this.string();if(c==='-'||c>='0'&&c<='9')return this.number();throw Error('invalid JSON scalar');}
 finish(){this.ws();if(this.at!==this.text.length)throw Error('trailing JSON text');}
}
function streamJsonBinary(values,text,options,typed,compact=false){
 const p=new JsonWireReader(text,options),utf8=jsonWireEncoder;
 const list=(w,open,close,item)=>{if(!p.eat(open))throw Error('JSON container shape');const at=w.beginCount();let count=0;if(!p.eat(close))while(true){item(w);count++;if(p.eat(close))break;if(!p.eat(','))throw Error('JSON container separator');}w.endCount(at,count);};
 const variant=(w,index,level,emit)=>{if(level<index)w.frame(w=>{w.byte(1);variant(w,index,level+1,emit);});else if(index<5)w.frame(w=>{w.byte(0);w.frame(emit);});else w.frame(emit);};
 const json=(w,d)=>{
  const ch=p.peek(),index=ch==='n'?0:ch==='t'||ch==='f'?1:ch==='-'||ch>='0'&&ch<='9'?2:ch==='"'?3:ch==='['?4:ch==='{'?5:-1;if(index<0)throw Error('invalid JSON value');
  const leaf=index<4?p.leaf(d):null;if(index>=4)p.node(d);
  w.frame(w=>variant(w,index,0,w=>{
   if(index===0)return;if(index===1){w.frame(w=>w.byte(+leaf));return;}
   if(index===2||index===3){w.frame(w=>w.text(leaf));return;}
   w.frame(w=>{if(index===4)list(w,'[',']',w=>json(w,d+1));else{const seen=new Set();list(w,'{','}',w=>{const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');w.frame(w=>{w.frame(w=>w.text(key));json(w,d+1);});});}});
  }));
 };
 const read=(type,w,d)=>{
  const t=values.resolve(type);w.frame(w=>{
   if(t.kind==='list'||t.kind==='vector'){p.node(d);list(w,'[',']',w=>read(t.element,w,d+1));return;}
   if(t.kind==='record'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON record');const start=w.position,spans=new Array(t.fields.length).fill(null);
    if(!p.eat('}'))while(true){const key=p.string(),i=t.fields.findIndex(f=>f.name===key);if(i<0)throw Error('unknown JSON record field');if(spans[i])throw Error('duplicate JSON record field');if(!p.eat(':'))throw Error('JSON record colon');const at=w.position;read(t.fields[i].type,w,d+1);spans[i]=[at,w.position];if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON record separator');}
    if(spans.some(s=>s===null))throw Error('missing JSON record field');w.reorder(start,spans);return;
   }
   if(t.kind==='option'||t.kind==='result'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON tagged value');const key=p.string();if(!p.eat(':'))throw Error('JSON tag colon');
    if(t.kind==='option'&&key==='None'){if(p.leaf(d+1)!==null)throw Error('JSON None payload');w.byte(0);}
    else{const child=t.kind==='option'&&key==='Some'?t.element:t.kind==='result'&&key==='Ok'?t.ok:t.kind==='result'&&key==='Err'?t.error:null;if(!child)throw Error('invalid JSON tag');w.byte(key==='Ok'?0:1);read(child,w,d+1);}
    if(!p.eat('}'))throw Error('expected exactly one JSON tag');return;
   }
   const ch=p.peek(),v=p.leaf(d),bad=()=>{throw Error('JSON does not match '+t.kind);};
   if(t.kind==='unit'){if(v!==null)bad();return;}
   if(t.kind==='bool'){if(typeof v!=='boolean')bad();w.byte(+v);return;}
   if(['string','id','enum'].includes(t.kind)){if(ch!=='"')bad();w.text(v);return;}
   if(ch!=='-'&&!(ch>='0'&&ch<='9'))bad();
   if(t.kind==='int'){w.text(jsonInteger(v,4096));return;}
   if(t.kind==='f64'){const n=Number(v);if(!Number.isFinite(n))throw Error('JSON f64 overflow');const b=new DataView(new ArrayBuffer(8));b.setFloat64(0,n,true);w.wide(b.getBigUint64(0,true));}
   else if(t.kind==='f32'){jsonFloatScratch.setFloat32(0,Number(v),true);if(!Number.isFinite(jsonFloatScratch.getFloat32(0,true)))throw Error('JSON f32 overflow');w.word(jsonFloatScratch.getUint32(0,true));}
   else{const n=BigInt(jsonInteger(v,t.kind==='u64'?20:10));if(t.kind==='u64'){if(n<0n||n>18446744073709551615n)bad();w.wide(n);}else if(t.kind==='u32'){if(n<0n||n>4294967295n)bad();w.word(Number(n));}else if(t.kind==='i32'){if(n< -2147483648n||n>2147483647n)bad();w.word(Number(n)>>>0);}else bad();}
  });
 };
 return (compact?values.compact():values).encodeWith(w=>{if(typed)read(values.descriptor.root,w,0);else json(w,0);p.finish();},options);
}

// Render validated bytes in a single traversal; only the final text is owned.
function streamWireJsonText(values,bytes,options,library){
 values.validate(bytes,options);const l=checkedJsonLimits(options),parts=[];let size=0,remaining=l.nodes;const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 const emit=s=>{size+=jsonUtf8Length(s);if(size>l.bytes)throw Error('JSON byte limit');parts.push(s);};
 const string=s=>emit(JSON.stringify(s));const node=d=>{if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');};
 const frame=(type,at)=>{const t=values.resolve(type),start=at+4,end=start+dv.getUint32(at,true);return{t,start,end};};
 const json=(type,at,d)=>{
  node(d);let root=frame(type,at),sum=frame(root.t.fields[0].type,root.start),index=0;
  while(index<5){const err=bytes[sum.start];sum=frame(err?sum.t.error:sum.t.ok,sum.start+1);if(!err)break;index++;}
  if(index===0){emit('null');return root.end;}
  const item=frame(sum.t.fields[0].type,sum.start);
  if(index===1)emit(bytes[item.start]?'true':'false');
  else if(index===2){const token=decoder.decode(bytes.subarray(item.start,item.end));if(!jsonNumberToken(token))throw Error('invalid JSON number token');emit(token);}
  else if(index===3)string(decoder.decode(bytes.subarray(item.start,item.end)));
  else{const count=dv.getUint32(item.start,true);let p=item.start+4;emit(index===4?'[':'{');const seen=new Set();for(let i=0;i<count;i++){if(i)emit(',');if(index===4)p=json(item.t.element,p,d+1);else{const member=frame(item.t.element,p),key=frame(member.t.fields[0].type,member.start),name=decoder.decode(bytes.subarray(key.start,key.end));if(seen.has(name))throw Error('duplicate JSON object key');seen.add(name);string(name);emit(':');json(member.t.fields[1].type,key.end,d+1);p=member.end;}}emit(index===4?']':'}');}
  return root.end;
 };
 const typed=(type,at,d)=>{
  node(d);const f=frame(type,at),t=f.t;let p=f.start;
  switch(t.kind){
   case 'unit':emit('null');break;
   case 'bool':emit(bytes[p]?'true':'false');break;
   case 'u32':emit(String(dv.getUint32(p,true)));break;
   case 'u64':emit(String(dv.getBigUint64(p,true)));break;
   case 'i32':emit(String(dv.getInt32(p,true)));break;
   case 'f64':{const n=dv.getFloat64(p,true);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'f32':{const n=dv.getFloat32(p,true);if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'int':emit(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'string':case 'id':case 'enum':string(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'list':case 'vector':{const n=dv.getUint32(p,true);p+=4;emit('[');for(let i=0;i<n;i++){if(i)emit(',');p=typed(t.element,p,d+1);}emit(']');break;}
   case 'record':emit('{');for(let i=0;i<t.fields.length;i++){if(i)emit(',');const field=t.fields[i];string(field.name);emit(':');p=typed(field.type,p,d+1);}emit('}');break;
   case 'option':case 'result':{const tag=bytes[p++],key=t.kind==='option'?(tag?'Some':'None'):tag?'Err':'Ok';emit('{');string(key);emit(':');if(t.kind==='option'&&!tag){node(d+1);emit('null');}else typed(t.kind==='option'?t.element:tag?t.error:t.ok,p,d+1);emit('}');break;}
   default:throw Error('unsupported typed JSON descriptor');
  }return f.end;
 };
 if(library)json(values.descriptor.root,40,0);else typed(values.descriptor.root,40,0);return parts.join('');
}

/** Owned, optional read view of arbitrary JSON. Auxiliary indexes contain member
 * offsets only. Logical order, exact number tokens and missing/null remain intact.
 * This does not transparently replace any compiled Ink action or its state.
 */
export function createJsonLookup(text,{stepEntries=16,minReads=4,maxEntries=4096,maxObjects=64,maxIndexBytes=262144,...limits}={}){
 for(const [v,max]of [[stepEntries,4096],[minReads,1000000],[maxEntries,1000000],[maxObjects,256],[maxIndexBytes,16777216]])if(!Number.isSafeInteger(v)||v<0||v>max)throw Error('JSON index budget');
 let root=parseJson(text,limits),indexes=new Map(),entries=0,indexBytes=0;
 const stats={reads:0,writes:0,scanned_members:0,index_hits:0,built_entries:0,invalidations:0};
 function parts(path){
  if(!Array.isArray(path))throw Error('JSON lookup path');const n=path.length;if(n>128)throw Error('JSON lookup path');
  const owned=[];for(let i=0;i<n;i++){const d=Object.getOwnPropertyDescriptor(path,String(i));if(!d||!Object.hasOwn(d,'value'))throw Error('JSON lookup path');const p=d.value;if(!(typeof p==='string'&&p.isWellFormed()&&p.length<=4096)&&!(Number.isSafeInteger(p)&&p>=0))throw Error('JSON lookup path');owned.push(p);}return owned;
 }
 function variant(value){let p=value.payload,index=0;while(index<5&&Object.hasOwn(p,'Err')){p=p.Err;index++;}return {index,item:(index<5?p.Ok:p).item0};}
 function resolve(document,path,indexed){
  let value=document,budget=stepEntries;
  for(let depth=0;depth<path.length;depth++){
   const part=path[depth],v=variant(value);
   if(typeof part==='number'){
    if(v.index!==4)throw Error('expected JSON array');if(part>=v.item.length)return {found:false};value=v.item[part];continue;
   }
   if(v.index!==5)throw Error('expected JSON object');
   const prefix=path.slice(0,depth),key=JSON.stringify(prefix),overhead=128+prefix.reduce((n,p)=>n+(typeof p==='string'?16+p.length*2:8),0);let idx=indexed?indexes.get(key):null;
   if(indexed&&!idx&&indexes.size<maxObjects&&indexBytes+overhead<=maxIndexBytes){idx={path:prefix,reads:0,cursor:0,keys:new Map(),bytes:overhead};indexes.set(key,idx);indexBytes+=overhead;}
   if(idx){
    idx.reads++;
    if(idx.reads>=minReads)while(budget>0&&idx.cursor<v.item.length&&entries<maxEntries){
     const member=v.item[idx.cursor],bytes=64+member.key.length*2;
     if(indexBytes+bytes>maxIndexBytes)break;
     idx.keys.set(member.key,idx.cursor++);idx.bytes+=bytes;indexBytes+=bytes;entries++;stats.built_entries++;budget--;
    }
    if(idx.keys.has(part)){stats.index_hits++;value=v.item[idx.keys.get(part)].value;continue;}
   }
   let found=false;
   for(let i=idx?.cursor??0;i<v.item.length;i++){if(indexed)stats.scanned_members++;if(v.item[i].key===part){value=v.item[i].value;found=true;break;}}
   if(!found)return {found:false};
  }
  return {found:true,value};
 }
 return {
  lookup(path){stats.reads++;const r=resolve(root,parts(path),true);return r.found?{found:true,value:structuredClone(r.value)}:r;},
  set(path,key,text){
   path=parts(path);if(typeof key!=='string'||!key.isWellFormed())throw Error('JSON object key');
   const replacement=parseJson(text,limits),next=structuredClone(root),r=resolve(next,path,false);
   if(!r.found)throw Error('JSON update path missing');const object=variant(r.value);if(object.index!==5)throw Error('expected JSON object');
   const members=[{key,value:replacement},...object.item.filter(m=>m.key!==key)];
   // Validate the complete resulting document before publishing a write.
   let payload=r.value.payload;for(let i=0;i<5;i++)payload=payload.Err;payload.item0=members;
   stringifyJson(next,limits);root=next;stats.writes++;
   for(const [id,idx]of indexes)if(idx.path.length>=path.length&&path.every((p,i)=>p===idx.path[i])){entries-=idx.keys.size;indexBytes-=idx.bytes;indexes.delete(id);stats.invalidations++;}
  },
  replace(text){const next=parseJson(text,limits);root=next;stats.writes++;stats.invalidations+=indexes.size;indexes.clear();entries=0;indexBytes=0;},
  stringify(){return stringifyJson(root,limits);},
  stats(){return {...stats,index_entries:entries,index_objects:indexes.size,index_bytes:indexBytes};}
 };
}
function __ownedValue5(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__ownedValue6(value.Some,budget,depth+1)};}
function __ownedValue2(value,budget,depth){budget.enter(depth,4);return {["a"]:__ownedValue0(value["a"],budget,depth+1),["b"]:__ownedValue0(value["b"],budget,depth+1)};}
function __ownedValue1(value,budget,depth){budget.enter(depth,4);return {["p"]:__ownedValue2(value["p"],budget,depth+1),["q"]:__ownedValue2(value["q"],budget,depth+1),["r"]:__ownedValue2(value["r"],budget,depth+1),["s"]:__ownedValue2(value["s"],budget,depth+1),["t"]:__ownedValue2(value["t"],budget,depth+1),["u"]:__ownedValue2(value["u"],budget,depth+1)};}
function __ownedValue8(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue0(value["value"],budget,depth+1),["tangent"]:__ownedValue0(value["tangent"],budget,depth+1)};}
function __ownedValue7(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue0(value["value"],budget,depth+1),["tangent_0"]:__ownedValue0(value["tangent_0"],budget,depth+1),["tangent_1"]:__ownedValue0(value["tangent_1"],budget,depth+1),["tangent_2"]:__ownedValue0(value["tangent_2"],budget,depth+1),["tangent_3"]:__ownedValue0(value["tangent_3"],budget,depth+1),["tangent_4"]:__ownedValue0(value["tangent_4"],budget,depth+1),["tangent_5"]:__ownedValue0(value["tangent_5"],budget,depth+1),["tangent_6"]:__ownedValue0(value["tangent_6"],budget,depth+1),["tangent_7"]:__ownedValue0(value["tangent_7"],budget,depth+1),["tangent_8"]:__ownedValue0(value["tangent_8"],budget,depth+1),["tangent_9"]:__ownedValue0(value["tangent_9"],budget,depth+1),["tangent_10"]:__ownedValue0(value["tangent_10"],budget,depth+1),["tangent_11"]:__ownedValue0(value["tangent_11"],budget,depth+1)};}
function __ownedValue3(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue4(value["value"],budget,depth+1),["previous"]:__ownedValue5(value["previous"],budget,depth+1)};}
function __ownedValue0(value,budget,depth){budget.enter(depth,8);const bits=typeof value==='number'?__bits(value):value.F32Bits;return {F32Bits:bits===0?0:bits};}
function __ownedValue6(value,budget,depth){return __ownedValue3(value,budget,depth);}
function __ownedValue4(value,budget,depth){budget.enter(depth,8);return value>>>0;}
const __ownedFunctions=Object.freeze(Object.fromEntries([["component",__ownedValue0],["energy",__ownedValue0],["derivatives",__ownedValue1],["direction",__ownedValue0],["twice",__ownedValue0],["selected",__ownedValue2],["branches",__ownedValue2],["looping",__ownedValue2],["strict_unused",__ownedValue0],["strict",__ownedValue0],["history",__ownedValue3],["__ink_differential_3",__ownedValue7],["__ink_differential_1",__ownedValue1],["__ink_differential_23",__ownedValue8],["__ink_differential_27",__ownedValue8],["__ink_differential_31",__ownedValue8],["__ink_differential_20",__ownedValue8],["__ink_differential_19",__ownedValue0]]));
function __wireValue22(reader){const end=reader.frame();const value=reader.byte()?{Some:__wireValue21(reader)}:{None:null};reader.finish(end);return value;}
function __wireValue9(reader){const end=reader.frame();const value={["__ink_differential_24"]:__wireValue8(reader),["__ink_differential_25"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue10(reader){const end=reader.frame();const value={["__ink_differential_28"]:__wireValue8(reader),["__ink_differential_29"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue15(reader){const end=reader.frame();const value={["__ink_differential_32"]:__wireValue8(reader),["__ink_differential_33"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue7(reader){const end=reader.frame();const value={["a"]:__wireValue8(reader),["b"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue13(reader){const end=reader.frame();const value={["a"]:__wireValue14(reader),["b"]:__wireValue14(reader)};reader.finish(end);return value;}
function __wireValue2(reader){const end=reader.frame();const value={["a"]:__wireValue3(reader),["b"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue6(reader){const end=reader.frame();const value={["p"]:__wireValue7(reader),["q"]:__wireValue7(reader),["r"]:__wireValue7(reader),["s"]:__wireValue7(reader),["t"]:__wireValue7(reader),["u"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue12(reader){const end=reader.frame();const value={["p"]:__wireValue13(reader),["q"]:__wireValue13(reader),["r"]:__wireValue13(reader),["s"]:__wireValue13(reader),["t"]:__wireValue13(reader),["u"]:__wireValue13(reader)};reader.finish(end);return value;}
function __wireValue1(reader){const end=reader.frame();const value={["p"]:__wireValue2(reader),["q"]:__wireValue2(reader),["r"]:__wireValue2(reader),["s"]:__wireValue2(reader),["t"]:__wireValue2(reader),["u"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue8(reader){const end=reader.frame();const value={["value"]:__wireValue3(reader),["tangent"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue14(reader){const end=reader.frame();const value={["value"]:__wireValue3(reader),["tangent_0"]:__wireValue3(reader),["tangent_1"]:__wireValue3(reader),["tangent_2"]:__wireValue3(reader),["tangent_3"]:__wireValue3(reader),["tangent_4"]:__wireValue3(reader),["tangent_5"]:__wireValue3(reader),["tangent_6"]:__wireValue3(reader),["tangent_7"]:__wireValue3(reader),["tangent_8"]:__wireValue3(reader),["tangent_9"]:__wireValue3(reader),["tangent_10"]:__wireValue3(reader),["tangent_11"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue21(reader){const end=reader.frame();const value={["value"]:__wireValue20(reader),["previous"]:__wireValue22(reader)};reader.finish(end);return value;}
function __wireValue24(reader){const end=reader.frame();const value={["w"]:__wireValue2(reader),["c"]:__wireValue17(reader)};reader.finish(end);return value;}
function __wireValue18(reader){const end=reader.frame();const value={["w"]:__wireValue2(reader),["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue26(reader){const end=reader.frame();const value={["w"]:__wireValue2(reader)};reader.finish(end);return value;}
function __wireValue5(reader){const end=reader.frame();const value={["w"]:__wireValue6(reader),["x"]:__wireValue8(reader)};reader.finish(end);return value;}
function __wireValue11(reader){const end=reader.frame();const value={["w"]:__wireValue12(reader),["x"]:__wireValue14(reader)};reader.finish(end);return value;}
function __wireValue4(reader){const end=reader.frame();const value={["w"]:__wireValue1(reader),["__ink_differential_35"]:__wireValue1(reader),["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue0(reader){const end=reader.frame();const value={["w"]:__wireValue1(reader),["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue16(reader){const end=reader.frame();const value={["x"]:__wireValue3(reader),["c"]:__wireValue17(reader)};reader.finish(end);return value;}
function __wireValue25(reader){const end=reader.frame();const value={["x"]:__wireValue3(reader),["y"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue23(reader){const end=reader.frame();const value={["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue19(reader){const end=reader.frame();const value={["x"]:__wireValue20(reader)};reader.finish(end);return value;}
function __wireValue17(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __wireValue3(reader){const end=reader.frame();const value={F32Bits:reader.word()};reader.finish(end);return value;}
function __wireValue20(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
const __wireReaders=Object.freeze(Object.fromEntries([["__ink_differential_1",[__wireValue0,__wireValue1]],["__ink_differential_19",[__wireValue4,__wireValue3]],["__ink_differential_20",[__wireValue5,__wireValue8]],["__ink_differential_23",[__wireValue9,__wireValue8]],["__ink_differential_27",[__wireValue10,__wireValue8]],["__ink_differential_3",[__wireValue11,__wireValue14]],["__ink_differential_31",[__wireValue15,__wireValue8]],["branches",[__wireValue16,__wireValue2]],["component",[__wireValue18,__wireValue3]],["derivatives",[__wireValue0,__wireValue1]],["direction",[__wireValue0,__wireValue3]],["energy",[__wireValue0,__wireValue3]],["history",[__wireValue19,__wireValue21]],["looping",[__wireValue23,__wireValue2]],["selected",[__wireValue24,__wireValue2]],["strict",[__wireValue25,__wireValue3]],["strict_unused",[__wireValue26,__wireValue3]],["twice",[__wireValue26,__wireValue3]]]));
const __ownedImplementations=Object.freeze(Object.fromEntries([["component",(()=>{const c0=__representation(__inputTypes[0].types[0],false,__inputTypes[0].capture[0]);const c1=__representation(__inputTypes[0].types[1],false,__inputTypes[0].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn0;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn0(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn0(v0,v1);};})()],
["energy",(()=>{const c0=__representation(__inputTypes[1].types[0],false,__inputTypes[1].capture[0]);const c1=__representation(__inputTypes[1].types[1],false,__inputTypes[1].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn1;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn1(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn1(v0,v1);};})()],
["derivatives",(()=>{const c0=__representation(__inputTypes[2].types[0],false,__inputTypes[2].capture[0]);const c1=__representation(__inputTypes[2].types[1],false,__inputTypes[2].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn2;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn2(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn2(v0,v1);};})()],
["direction",(()=>{const c0=__representation(__inputTypes[3].types[0],false,__inputTypes[3].capture[0]);const c1=__representation(__inputTypes[3].types[1],false,__inputTypes[3].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn3;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn3(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn3(v0,v1);};})()],
["twice",(()=>{const c0=__representation(__inputTypes[4].types[0],false,__inputTypes[4].capture[0]);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity)return __fn4;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn4(...values);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return __fn4(v0);};})()],
["selected",(()=>{const c0=__representation(__inputTypes[5].types[0],false,__inputTypes[5].capture[0]);const c1=__representation(__inputTypes[5].types[1],false,__inputTypes[5].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn5;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn5(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn5(v0,v1);};})()],
["branches",(()=>{const c0=__representation(__inputTypes[6].types[0],false,__inputTypes[6].capture[0]);const c1=__representation(__inputTypes[6].types[1],false,__inputTypes[6].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=false;if(c0===__identity&&c1===__identity)return __fn6;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn6(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn6(v0,v1);};})()],
["looping",(()=>{const c0=__representation(__inputTypes[7].types[0],false,__inputTypes[7].capture[0]);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=false;if(c0===__identity)return __fn7;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn7(...values);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return __fn7(v0);};})()],
["strict_unused",(()=>{const c0=__representation(__inputTypes[8].types[0],false,__inputTypes[8].capture[0]);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity)return __fn8;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn8(...values);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return __fn8(v0);};})()],
["strict",(()=>{const c0=__representation(__inputTypes[9].types[0],false,__inputTypes[9].capture[0]);const c1=__representation(__inputTypes[9].types[1],false,__inputTypes[9].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=false;if(c0===__identity&&c1===__identity)return __fn9;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn9(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn9(v0,v1);};})()],
["history",(()=>{const c0=__representation(__inputTypes[10].types[0],false,__inputTypes[10].capture[0]);const input=[c0],needsInput=input.some(c=>c!==__identity);const needsContext=false;if(c0===__identity)return __fn10;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn10(...values);};return function(a0){if(arguments.length!==1)return fallback(...arguments);const context=(needsContext)?new WeakMap():null;const v0=c0(a0,context);return __fn10(v0);};})()],
["__ink_differential_3",(()=>{const c0=__representation(__inputTypes[11].types[0],false,__inputTypes[11].capture[0]);const c1=__representation(__inputTypes[11].types[1],false,__inputTypes[11].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity)return __fn11;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn11(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn11(v0,v1);};})()],
["__ink_differential_1",(()=>{const c0=__representation(__inputTypes[12].types[0],false,__inputTypes[12].capture[0]);const c1=__representation(__inputTypes[12].types[1],false,__inputTypes[12].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity);if(c0===__identity&&c1===__identity)return __fn12;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn12(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn12(v0,v1);};})()],
["__ink_differential_23",(()=>{const c0=__representation(__inputTypes[13].types[0],false,__inputTypes[13].capture[0]);const c1=__representation(__inputTypes[13].types[1],false,__inputTypes[13].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity)return __fn13;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn13(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn13(v0,v1);};})()],
["__ink_differential_27",(()=>{const c0=__representation(__inputTypes[14].types[0],false,__inputTypes[14].capture[0]);const c1=__representation(__inputTypes[14].types[1],false,__inputTypes[14].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity)return __fn14;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn14(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn14(v0,v1);};})()],
["__ink_differential_31",(()=>{const c0=__representation(__inputTypes[15].types[0],false,__inputTypes[15].capture[0]);const c1=__representation(__inputTypes[15].types[1],false,__inputTypes[15].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity)return __fn15;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn15(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn15(v0,v1);};})()],
["__ink_differential_20",(()=>{const c0=__representation(__inputTypes[16].types[0],false,__inputTypes[16].capture[0]);const c1=__representation(__inputTypes[16].types[1],false,__inputTypes[16].capture[1]);const input=[c0,c1],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity)return __fn16;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn16(...values);};return function(a0,a1){if(arguments.length!==2)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);return __fn16(v0,v1);};})()],
["__ink_differential_19",(()=>{const c0=__representation(__inputTypes[17].types[0],false,__inputTypes[17].capture[0]);const c1=__representation(__inputTypes[17].types[1],false,__inputTypes[17].capture[1]);const c2=__representation(__inputTypes[17].types[2],false,__inputTypes[17].capture[2]);const input=[c0,c1,c2],needsInput=input.some(c=>c!==__identity);const needsContext=(c0!==__identity||c1!==__identity);if(c0===__identity&&c1===__identity&&c2===__identity)return __fn17;const fallback=(...args)=>{const context=new WeakMap();const values=needsInput?args.map((v,i)=>input[i](v,context)):args;return __fn17(...values);};return function(a0,a1,a2){if(arguments.length!==3)return fallback(...arguments);const context=(needsContext||(Number(c0!==__identity&&a0!==null&&typeof a0==='object')+Number(c1!==__identity&&a1!==null&&typeof a1==='object')+Number(c2!==__identity&&a2!==null&&typeof a2==='object'))>1)?new WeakMap():null;const v0=c0(a0,context);const v1=c1(a1,context);const v2=c2(a2,context);return __fn17(v0,v1,v2);};})()]]));

export const valueCodecs=(()=>{const codecs={};for(const [name,s] of Object.entries(metadata.wire.functions)){if(s.unsupported)continue;let value;Object.defineProperty(codecs,name,{enumerable:true,get:()=>value??=(Object.freeze(Object.hasOwn(__wireReaders,name)?{arguments:createCompiledValueCodec(s.arguments,__wireReaders[name][0]),result:createCompiledValueCodec(s.result,__wireReaders[name][1])}:{arguments:new ValueCodec(s.arguments),result:new ValueCodec(s.result)}))});}return Object.freeze(codecs);})();
function __callEncoded(name,bytes,limits,compact){
 const f=metadata.functions.find(f=>f.name===name&&!f.internal),codecs=valueCodecs[name];
 if(!f||!codecs)throw Error('unsupported binary function');
 const input=compact?codecs.arguments.compact():codecs.arguments,output=compact?codecs.result.compact():codecs.result;
 const entry=__compiledEntries.get(name);
 if(entry){
  const slot=compact?1:0;
  entry.argumentCodecs[slot]??=(entry.boundaryReaders[slot]?createFusedValueCodec:createCompiledValueCodec)(metadata.wire.functions[name].arguments,entry.arguments);
  const decoder=entry.argumentCodecs[slot];
  const values=(compact?decoder.compact():decoder).decode(bytes,limits),args=f.params.map(p=>values[p.name]);
  if(entry.precondition!==null&&__implementations[entry.precondition](...args)!==true)throw Error('contract precondition failed');
  return __compiledEncodeResult(entry,__implementations[entry.index](...args),limits,compact);
 }
 const values=input.decode(bytes,limits);
 const result=call(name,f.params.map(p=>values[p.name]));
 return output.encode(result,limits);
}
export function callBinary(name,bytes,limits={}){return __callEncoded(name,bytes,limits,false);}
export function callCompact(name,bytes,limits={}){return __callEncoded(name,bytes,limits,true);}
// Same stable, well-typed caller inputs as call; the result owns every container.
// The checked source return type justifies trusted copying, not arbitrary input.
export function callOwned(name,args,limits={}){
 if(!Object.hasOwn(__ownedFunctions,name)||!Object.hasOwn(functions,name))throw Error('unsupported owned function');
 const result=__ownedImplementations[name](...args);return __ownedFunctions[name](result,createValueCaptureBudget(limits),0);
}
function __privateCapture6(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if((value!==null&&typeof value==='object'&&Object.hasOwn(value,'None')&&Object.keys(value).length===1)&&value.None===null)return {None:null};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Some')&&Object.keys(value).length===1)return {Some:__privateCapture5(value.Some,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture12(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture10(value["a"],budget,depth+1),["b"]:__privateCapture10(value["b"],budget,depth+1)};}
function __privateCapture8(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture9(value["a"],budget,depth+1),["b"]:__privateCapture9(value["b"],budget,depth+1)};}
function __privateCapture0(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}return {["a"]:__privateCapture1(value["a"],budget,depth+1),["b"]:__privateCapture1(value["b"],budget,depth+1)};}
function __privateCapture11(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"p")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"q")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"r")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"s")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"t")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"u")){throw Error('invalid value for wire schema');}return {["p"]:__privateCapture12(value["p"],budget,depth+1),["q"]:__privateCapture12(value["q"],budget,depth+1),["r"]:__privateCapture12(value["r"],budget,depth+1),["s"]:__privateCapture12(value["s"],budget,depth+1),["t"]:__privateCapture12(value["t"],budget,depth+1),["u"]:__privateCapture12(value["u"],budget,depth+1)};}
function __privateCapture7(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"p")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"q")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"r")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"s")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"t")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"u")){throw Error('invalid value for wire schema');}return {["p"]:__privateCapture8(value["p"],budget,depth+1),["q"]:__privateCapture8(value["q"],budget,depth+1),["r"]:__privateCapture8(value["r"],budget,depth+1),["s"]:__privateCapture8(value["s"],budget,depth+1),["t"]:__privateCapture8(value["t"],budget,depth+1),["u"]:__privateCapture8(value["u"],budget,depth+1)};}
function __privateCapture2(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"p")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"q")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"r")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"s")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"t")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"u")){throw Error('invalid value for wire schema');}return {["p"]:__privateCapture0(value["p"],budget,depth+1),["q"]:__privateCapture0(value["q"],budget,depth+1),["r"]:__privateCapture0(value["r"],budget,depth+1),["s"]:__privateCapture0(value["s"],budget,depth+1),["t"]:__privateCapture0(value["t"],budget,depth+1),["u"]:__privateCapture0(value["u"],budget,depth+1)};}
function __privateCapture10(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["tangent"]:__privateCapture1(value["tangent"],budget,depth+1)};}
function __privateCapture9(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==13){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_0")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_1")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_2")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_3")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_4")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_5")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_6")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_7")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_8")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_9")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_10")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent_11")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["tangent_0"]:__privateCapture1(value["tangent_0"],budget,depth+1),["tangent_1"]:__privateCapture1(value["tangent_1"],budget,depth+1),["tangent_2"]:__privateCapture1(value["tangent_2"],budget,depth+1),["tangent_3"]:__privateCapture1(value["tangent_3"],budget,depth+1),["tangent_4"]:__privateCapture1(value["tangent_4"],budget,depth+1),["tangent_5"]:__privateCapture1(value["tangent_5"],budget,depth+1),["tangent_6"]:__privateCapture1(value["tangent_6"],budget,depth+1),["tangent_7"]:__privateCapture1(value["tangent_7"],budget,depth+1),["tangent_8"]:__privateCapture1(value["tangent_8"],budget,depth+1),["tangent_9"]:__privateCapture1(value["tangent_9"],budget,depth+1),["tangent_10"]:__privateCapture1(value["tangent_10"],budget,depth+1),["tangent_11"]:__privateCapture1(value["tangent_11"],budget,depth+1)};}
function __privateCapture5(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"previous")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture4(value["value"],budget,depth+1),["previous"]:__privateCapture6(value["previous"],budget,depth+1)};}
function __privateCapture3(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='boolean'){throw Error('invalid value for wire schema');}budget.add(1);return value;}
function __privateCapture1(value,budget,depth=0){budget.enter(depth,4);let bits;if(typeof value==='number'&&Number.isFinite(value)){bits=__bits(value);if(!Number.isFinite(__float(bits))){throw Error('invalid value for wire schema');}}else{if(!(value!==null&&typeof value==='object'&&Object.hasOwn(value,'F32Bits')&&Object.keys(value).length===1)){throw Error('invalid value for wire schema');}bits=value.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295){throw Error('invalid value for wire schema');}}budget.add(4);return __nfFromBits(bits);}
function __privateCapture4(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='number'||!Number.isInteger(value)||value<0||value>4294967295){throw Error('invalid value for wire schema');}budget.add(4);return value===0?0:value;}
function __privateWireValue13(reader){const end=reader.frame();const value=reader.byte()?{Some:__privateWireValue12(reader)}:{None:null};reader.finish(end);return value;}
function __privateWireValue20(reader){const end=reader.frame();const value={["__ink_differential_24"]:__privateWireValue19(reader),["__ink_differential_25"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue21(reader){const end=reader.frame();const value={["__ink_differential_28"]:__privateWireValue19(reader),["__ink_differential_29"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue22(reader){const end=reader.frame();const value={["__ink_differential_32"]:__privateWireValue19(reader),["__ink_differential_33"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue24(reader){const end=reader.frame();const value={["a"]:__privateWireValue19(reader),["b"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue16(reader){const end=reader.frame();const value={["a"]:__privateWireValue17(reader),["b"]:__privateWireValue17(reader)};reader.finish(end);return value;}
function __privateWireValue0(reader){const end=reader.frame();const value={["a"]:__privateWireValue1(reader),["b"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue23(reader){const end=reader.frame();const value={["p"]:__privateWireValue24(reader),["q"]:__privateWireValue24(reader),["r"]:__privateWireValue24(reader),["s"]:__privateWireValue24(reader),["t"]:__privateWireValue24(reader),["u"]:__privateWireValue24(reader)};reader.finish(end);return value;}
function __privateWireValue15(reader){const end=reader.frame();const value={["p"]:__privateWireValue16(reader),["q"]:__privateWireValue16(reader),["r"]:__privateWireValue16(reader),["s"]:__privateWireValue16(reader),["t"]:__privateWireValue16(reader),["u"]:__privateWireValue16(reader)};reader.finish(end);return value;}
function __privateWireValue3(reader){const end=reader.frame();const value={["p"]:__privateWireValue0(reader),["q"]:__privateWireValue0(reader),["r"]:__privateWireValue0(reader),["s"]:__privateWireValue0(reader),["t"]:__privateWireValue0(reader),["u"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue19(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["tangent"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue17(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["tangent_0"]:__privateWireValue1(reader),["tangent_1"]:__privateWireValue1(reader),["tangent_2"]:__privateWireValue1(reader),["tangent_3"]:__privateWireValue1(reader),["tangent_4"]:__privateWireValue1(reader),["tangent_5"]:__privateWireValue1(reader),["tangent_6"]:__privateWireValue1(reader),["tangent_7"]:__privateWireValue1(reader),["tangent_8"]:__privateWireValue1(reader),["tangent_9"]:__privateWireValue1(reader),["tangent_10"]:__privateWireValue1(reader),["tangent_11"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue12(reader){const end=reader.frame();const value={["value"]:__privateWireValue11(reader),["previous"]:__privateWireValue13(reader)};reader.finish(end);return value;}
function __privateWireValue7(reader){const end=reader.frame();const value={["w"]:__privateWireValue0(reader),["c"]:__privateWireValue6(reader)};reader.finish(end);return value;}
function __privateWireValue2(reader){const end=reader.frame();const value={["w"]:__privateWireValue0(reader),["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue5(reader){const end=reader.frame();const value={["w"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue25(reader){const end=reader.frame();const value={["w"]:__privateWireValue23(reader),["x"]:__privateWireValue19(reader)};reader.finish(end);return value;}
function __privateWireValue18(reader){const end=reader.frame();const value={["w"]:__privateWireValue15(reader),["x"]:__privateWireValue17(reader)};reader.finish(end);return value;}
function __privateWireValue26(reader){const end=reader.frame();const value={["w"]:__privateWireValue3(reader),["__ink_differential_35"]:__privateWireValue3(reader),["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue4(reader){const end=reader.frame();const value={["w"]:__privateWireValue3(reader),["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue8(reader){const end=reader.frame();const value={["x"]:__privateWireValue1(reader),["c"]:__privateWireValue6(reader)};reader.finish(end);return value;}
function __privateWireValue10(reader){const end=reader.frame();const value={["x"]:__privateWireValue1(reader),["y"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue9(reader){const end=reader.frame();const value={["x"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue14(reader){const end=reader.frame();const value={["x"]:__privateWireValue11(reader)};reader.finish(end);return value;}
function __privateWireValue6(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __privateWireValue1(reader){const end=reader.frame();const value=__nfFromBits(reader.word());reader.finish(end);return value;}
function __privateWireValue11(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __compiledOwnedValue6(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__compiledOwnedValue7(value.Some,budget,depth+1)};}
function __compiledOwnedValue13(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue11(value["a"],budget,depth+1),["b"]:__compiledOwnedValue11(value["b"],budget,depth+1)};}
function __compiledOwnedValue9(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue10(value["a"],budget,depth+1),["b"]:__compiledOwnedValue10(value["b"],budget,depth+1)};}
function __compiledOwnedValue0(value,budget,depth){budget.enter(depth,4);return {["a"]:__compiledOwnedValue1(value["a"],budget,depth+1),["b"]:__compiledOwnedValue1(value["b"],budget,depth+1)};}
function __compiledOwnedValue12(value,budget,depth){budget.enter(depth,4);return {["p"]:__compiledOwnedValue13(value["p"],budget,depth+1),["q"]:__compiledOwnedValue13(value["q"],budget,depth+1),["r"]:__compiledOwnedValue13(value["r"],budget,depth+1),["s"]:__compiledOwnedValue13(value["s"],budget,depth+1),["t"]:__compiledOwnedValue13(value["t"],budget,depth+1),["u"]:__compiledOwnedValue13(value["u"],budget,depth+1)};}
function __compiledOwnedValue8(value,budget,depth){budget.enter(depth,4);return {["p"]:__compiledOwnedValue9(value["p"],budget,depth+1),["q"]:__compiledOwnedValue9(value["q"],budget,depth+1),["r"]:__compiledOwnedValue9(value["r"],budget,depth+1),["s"]:__compiledOwnedValue9(value["s"],budget,depth+1),["t"]:__compiledOwnedValue9(value["t"],budget,depth+1),["u"]:__compiledOwnedValue9(value["u"],budget,depth+1)};}
function __compiledOwnedValue2(value,budget,depth){budget.enter(depth,4);return {["p"]:__compiledOwnedValue0(value["p"],budget,depth+1),["q"]:__compiledOwnedValue0(value["q"],budget,depth+1),["r"]:__compiledOwnedValue0(value["r"],budget,depth+1),["s"]:__compiledOwnedValue0(value["s"],budget,depth+1),["t"]:__compiledOwnedValue0(value["t"],budget,depth+1),["u"]:__compiledOwnedValue0(value["u"],budget,depth+1)};}
function __compiledOwnedValue11(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["tangent"]:__compiledOwnedValue1(value["tangent"],budget,depth+1)};}
function __compiledOwnedValue10(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["tangent_0"]:__compiledOwnedValue1(value["tangent_0"],budget,depth+1),["tangent_1"]:__compiledOwnedValue1(value["tangent_1"],budget,depth+1),["tangent_2"]:__compiledOwnedValue1(value["tangent_2"],budget,depth+1),["tangent_3"]:__compiledOwnedValue1(value["tangent_3"],budget,depth+1),["tangent_4"]:__compiledOwnedValue1(value["tangent_4"],budget,depth+1),["tangent_5"]:__compiledOwnedValue1(value["tangent_5"],budget,depth+1),["tangent_6"]:__compiledOwnedValue1(value["tangent_6"],budget,depth+1),["tangent_7"]:__compiledOwnedValue1(value["tangent_7"],budget,depth+1),["tangent_8"]:__compiledOwnedValue1(value["tangent_8"],budget,depth+1),["tangent_9"]:__compiledOwnedValue1(value["tangent_9"],budget,depth+1),["tangent_10"]:__compiledOwnedValue1(value["tangent_10"],budget,depth+1),["tangent_11"]:__compiledOwnedValue1(value["tangent_11"],budget,depth+1)};}
function __compiledOwnedValue5(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue4(value["value"],budget,depth+1),["previous"]:__compiledOwnedValue6(value["previous"],budget,depth+1)};}
function __compiledOwnedValue3(value,budget,depth){budget.enter(depth,5);return value;}
function __compiledOwnedValue1(value,budget,depth){budget.enter(depth,8);const bits=typeof value==='number'?__bits(value):value.F32Bits;return {F32Bits:bits===0?0:bits};}
function __compiledOwnedValue7(value,budget,depth){return __compiledOwnedValue5(value,budget,depth);}
function __compiledOwnedValue4(value,budget,depth){budget.enter(depth,8);return value>>>0;}
function __privateWireWrite6(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Some')){writer.byte(1);__privateWireWrite5(writer,value.Some,compact);}else{writer.byte(0);}writer.closeFrame(frame);}
function __privateWireWrite12(writer,value,compact){const frame=writer.openFrame();__privateWireWrite10(writer,value["a"],compact);__privateWireWrite10(writer,value["b"],compact);writer.closeFrame(frame);}
function __privateWireWrite8(writer,value,compact){const frame=writer.openFrame();__privateWireWrite9(writer,value["a"],compact);__privateWireWrite9(writer,value["b"],compact);writer.closeFrame(frame);}
function __privateWireWrite0(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["a"],compact);__privateWireWrite1(writer,value["b"],compact);writer.closeFrame(frame);}
function __privateWireWrite11(writer,value,compact){const frame=writer.openFrame();__privateWireWrite12(writer,value["p"],compact);__privateWireWrite12(writer,value["q"],compact);__privateWireWrite12(writer,value["r"],compact);__privateWireWrite12(writer,value["s"],compact);__privateWireWrite12(writer,value["t"],compact);__privateWireWrite12(writer,value["u"],compact);writer.closeFrame(frame);}
function __privateWireWrite7(writer,value,compact){const frame=writer.openFrame();__privateWireWrite8(writer,value["p"],compact);__privateWireWrite8(writer,value["q"],compact);__privateWireWrite8(writer,value["r"],compact);__privateWireWrite8(writer,value["s"],compact);__privateWireWrite8(writer,value["t"],compact);__privateWireWrite8(writer,value["u"],compact);writer.closeFrame(frame);}
function __privateWireWrite2(writer,value,compact){const frame=writer.openFrame();__privateWireWrite0(writer,value["p"],compact);__privateWireWrite0(writer,value["q"],compact);__privateWireWrite0(writer,value["r"],compact);__privateWireWrite0(writer,value["s"],compact);__privateWireWrite0(writer,value["t"],compact);__privateWireWrite0(writer,value["u"],compact);writer.closeFrame(frame);}
function __privateWireWrite10(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite1(writer,value["tangent"],compact);writer.closeFrame(frame);}
function __privateWireWrite9(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite1(writer,value["tangent_0"],compact);__privateWireWrite1(writer,value["tangent_1"],compact);__privateWireWrite1(writer,value["tangent_2"],compact);__privateWireWrite1(writer,value["tangent_3"],compact);__privateWireWrite1(writer,value["tangent_4"],compact);__privateWireWrite1(writer,value["tangent_5"],compact);__privateWireWrite1(writer,value["tangent_6"],compact);__privateWireWrite1(writer,value["tangent_7"],compact);__privateWireWrite1(writer,value["tangent_8"],compact);__privateWireWrite1(writer,value["tangent_9"],compact);__privateWireWrite1(writer,value["tangent_10"],compact);__privateWireWrite1(writer,value["tangent_11"],compact);writer.closeFrame(frame);}
function __privateWireWrite5(writer,value,compact){const frame=writer.openFrame();__privateWireWrite4(writer,value["value"],compact);__privateWireWrite6(writer,value["previous"],compact);writer.closeFrame(frame);}
function __privateWireWrite3(writer,value,compact){const frame=writer.openFrame();writer.byte(value?1:0);writer.closeFrame(frame);}
function __privateWireWrite1(writer,value,compact){const frame=writer.openFrame();writer.word(__nfBits(value));writer.closeFrame(frame);}
function __privateWireWrite4(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
// Handles have no mutable private payload surface. Membership and type identity
// are checked by this module's closure; copied/foreign objects cannot forge them.
const __compiledHandles=new WeakMap();
const __compiledBindings=new WeakMap();
function __compiledHandle(identity,value,guaranteed=false){
 const handle=Object.freeze(Object.create(null));
 __compiledHandles.set(handle,{identity,value,guaranteed});return handle;
}
function __compiledEntry(handle,identity){
 const entry=__compiledHandles.get(handle);
 if(!entry||entry.identity!==identity)throw Error('compiled value type or owner mismatch');
 return entry;
}
function __compiledUnwrap(handle,identity){return __compiledEntry(handle,identity).value;}
// Emit the portable schema's framing/scalar events without creating a buffer
// or exposing private composite nodes. Only this wrapper receives callbacks
// from the literal writer; host visitors never receive those closures.
function __compiledValueEvents(sink,limits){
 const methods=['begin','end','byte','word','wide','text','count'];
 for(const name of methods)if(typeof sink?.[name]!=='function')throw Error('compiled value visitor method: '+name);
 const budget=createValueCaptureBudget(limits);let depth=0,closed=false;
 const active=()=>{if(closed)throw Error('compiled value visitor is closed');};
 const writer=Object.freeze({
  openFrame(){active();budget.enter(depth,4);depth++;sink.begin();return 0;}
  ,closeFrame(){active();if(depth===0)throw Error('wire frame boundary');try{sink.end();}finally{depth--;}}
  ,frame(emit){active();budget.enter(depth,4);depth++;sink.begin();try{emit();sink.end();}finally{depth--;}}
  ,byte(value){active();budget.add(1);sink.byte(value);}
  ,word(value){active();budget.add(4);sink.word(value);}
  ,wide(value){active();budget.add(8);sink.wide(value);}
  ,text(value){active();budget.text(value);sink.text(value);}
  ,count(value){active();budget.add(4);if(value>budget.remaining)throw Error('wire sequence size');sink.count(value);}
 });
 return {writer,close(){closed=true;}};
}
function __compiledReduction(factory,root,reduce,identity){
 if(typeof factory!=='function')throw Error('compiled reduction factory');
 const reducers=[],seen=new Set(),nodes=__reductionNodes();
 const prepare=index=>{
  if(seen.has(index))return;seen.add(index);
  const node=nodes[index];
  for(const child of node.children)prepare(child);
  const reducer=factory(node,index);
  if(node.kind==='list'||node.kind==='vector'){
   const start=reducer?.start,step=reducer?.step,finish=reducer?.finish;
   if(typeof start!=='function'||typeof step!=='function'||typeof finish!=='function')throw Error('compiled collection reduction');
   reducers[index]=Object.freeze({start,step,finish});
  }else{
   if(typeof reducer!=='function')throw Error('compiled value reduction');
   reducers[index]=reducer;
  }
 };
 prepare(root);Object.freeze(reducers);
 return Object.freeze(function(handle,context,limits={}){
  const value=__compiledUnwrap(handle,identity),budget=createValueCaptureBudget(limits);
  return reduce(value,reducers,budget,0,context);
 });
}
function __compiledCodec(schema,capture,read,write,copy,constructorRoot,reductionRoot,reduce,portableFused=false,compactFused=false){
 const privateCodec=createCompiledValueCodec(schema,read),publicCodec=privateCodec;
 let fusedCodec;const fused=()=>fusedCodec??=createFusedValueCodec(schema,read);
 const identity=schema.identity;
 const codec=Object.freeze({
  identity,
  descriptor:publicCodec.descriptor,
  resolve(type){return publicCodec.resolve(type);},
  capture(value,limits={}){
   return __compiledHandle(identity,capture(value,createValueCaptureBudget(limits),0));
  },
  decode(bytes,limits={}){return __compiledHandle(identity,(portableFused?fused():privateCodec).decode(bytes,limits));},
  decodeCompact(bytes,limits={}){return __compiledHandle(identity,(compactFused?fused():privateCodec).compact().decode(bytes,limits));},
  decodeFused(bytes,limits={}){return __compiledHandle(identity,fused().decode(bytes,limits));},
  decodeCompactFused(bytes,limits={}){return __compiledHandle(identity,fused().compact().decode(bytes,limits));},
  encode(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.encodeWith(writer=>write(writer,value,false),limits);},
  encodeCompact(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.compact().encodeWith(writer=>write(writer,value,true),limits);},
  materialize(handle,limits={}){return copy(__compiledUnwrap(handle,identity),createValueCaptureBudget(limits),0);},
  builder(limits={}){return __valueBuilder(__constructorNodes(),constructorRoot,identity,limits);},
  reducer(factory){return __compiledReduction(factory,reductionRoot,reduce,identity);},
  visit(handle,sink,limits={}){
   const value=__compiledUnwrap(handle,identity),events=__compiledValueEvents(sink,limits);
   try{write(events.writer,value,false);}finally{events.close();}
  },
 });
 __compiledBindings.set(codec,{publicCodec,write,capture});return codec;
}

function __compiledEncodeResult(entry,value,limits,compact){
 const {publicCodec,write}=__compiledBindings.get(entry.result());
 return (compact?publicCodec.compact():publicCodec).encodeWith(writer=>write(writer,value,compact),limits);
}
let __constructorNodesValue;function __constructorNodes(){return __constructorNodesValue??=[{kind:'record',fields:["a","b"],patterns:[{bytes:4,label:"record",children:[1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1]})}]},{kind:"f32",scalar:__privateCapture1},{kind:'record',fields:["p","q","r","s","t","u"],patterns:[{bytes:4,label:"record",children:[0,0,0,0,0,0],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["p"]:values[0],["q"]:values[1],["r"]:values[2],["s"]:values[3],["t"]:values[4],["u"]:values[5]})}]},{kind:"bool",scalar:__privateCapture3},{kind:"u32",scalar:__privateCapture4},{kind:'record',fields:["value","previous"],patterns:[{bytes:4,label:"record",children:[4,6],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["previous"]:values[1]})}]},{kind:'option',patterns:[{bytes:5,label:"None",children:[],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({None:null})},{bytes:5,label:"Some",children:[5],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({Some:values[0]})}]},{kind:'record',fields:["p","q","r","s","t","u"],patterns:[{bytes:4,label:"record",children:[8,8,8,8,8,8],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["p"]:values[0],["q"]:values[1],["r"]:values[2],["s"]:values[3],["t"]:values[4],["u"]:values[5]})}]},{kind:'record',fields:["a","b"],patterns:[{bytes:4,label:"record",children:[9,9],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1]})}]},{kind:'record',fields:["value","tangent_0","tangent_1","tangent_2","tangent_3","tangent_4","tangent_5","tangent_6","tangent_7","tangent_8","tangent_9","tangent_10","tangent_11"],patterns:[{bytes:4,label:"record",children:[1,1,1,1,1,1,1,1,1,1,1,1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["tangent_0"]:values[1],["tangent_1"]:values[2],["tangent_2"]:values[3],["tangent_3"]:values[4],["tangent_4"]:values[5],["tangent_5"]:values[6],["tangent_6"]:values[7],["tangent_7"]:values[8],["tangent_8"]:values[9],["tangent_9"]:values[10],["tangent_10"]:values[11],["tangent_11"]:values[12]})}]},{kind:'record',fields:["value","tangent"],patterns:[{bytes:4,label:"record",children:[1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["tangent"]:values[1]})}]},{kind:'record',fields:["p","q","r","s","t","u"],patterns:[{bytes:4,label:"record",children:[12,12,12,12,12,12],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["p"]:values[0],["q"]:values[1],["r"]:values[2],["s"]:values[3],["t"]:values[4],["u"]:values[5]})}]},{kind:'record',fields:["a","b"],patterns:[{bytes:4,label:"record",children:[10,10],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["a"]:values[0],["b"]:values[1]})}]}];}
// Typed input construction only: plans contain literal constructor/capture
// functions emitted from source schemas. No source expression evaluator.
// All frames and private values remain in this closure; callers receive only
// an owned opaque handle after one complete, well-typed root is constructed.
const __constructorPaths=new WeakMap();
function __valueBuilder(nodes,root,identity,limits){
 const budget=createValueCaptureBudget(limits),frames=[];
 let result,targetNode,targetDepth,complete=false,closed=false,failed=false,busy=false;
 const fail=message=>{failed=true;frames.length=0;result=undefined;throw Error(message);};
 const active=()=>{if(failed||closed)throw Error('value builder is closed');};
 const expected=()=>{
  if(!frames.length){if(complete)fail('value builder root already complete');targetNode=root;targetDepth=0;return;}
  const frame=frames.at(-1),position=frame.values.length;
  if(!frame.pattern.sequence&&position>=frame.pattern.children.length)fail('value builder constructor is full');
  targetNode=frame.pattern.sequence?frame.pattern.children[0]:frame.pattern.children[position];targetDepth=frame.depth+frame.pattern.childDepth;
 };
 const accept=value=>{
  if(frames.length)frames.at(-1).values.push(value);
  else{result=value;complete=true;}
 };
 const execute=(operation,first,second)=>{
  active();if(busy)throw Error('value builder operation already active');busy=true;
  try{return operation(first,second);}catch(error){failed=true;frames.length=0;result=undefined;throw error;}finally{busy=false;}
 };
 // Compile and cache constructor paths independently of the session's values.
 const pathPlan=(choices,startNode,startDepth)=>{
   if(!Array.isArray(choices)||choices.length===0||choices.length>128)fail('invalid value builder path');
   let cache=__constructorPaths.get(nodes);if(!cache){cache=new WeakMap();__constructorPaths.set(nodes,cache);}
   let entries=cache.get(choices),saved=entries?.get(startNode);
   if(saved)return saved;
   const path=[],charges=[];let node=startNode,depth=startDepth;
   for(let i=0;i<choices.length;i++){
    const choice=choices[i],patterns=nodes[node].patterns;
    if(!Number.isSafeInteger(choice)||choice<0||!patterns||choice>=patterns.length)fail('invalid value builder constructor');
    const pattern=patterns[choice];charges.push([pattern,depth-startDepth]);path.push({pattern,node:nodes[node]});
    if(i+1<choices.length){if(pattern.sequence||pattern.children.length!==1)fail('value builder path is not unary');node=pattern.children[0];depth+=pattern.childDepth;}
   }
   const terminal=path.at(-1).pattern;
   // Compose literal constructor functions once per path, instead of
   // allocating and interpreting another recursive closure for every value.
   const compose=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=args=>args[0];
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=args=>p.make([inner(args)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?compose(last+1):args=>args[0]):compose(last);
     return args=>node.flat(index,payload(args));
    }
    const inner=at+1<path.length?compose(at+1):null;
    if(pattern.transparent)return inner??(args=>args[0]);
    return inner?args=>pattern.make([inner(args)]):pattern.make;
   };
   const make=compose(0);
   // Scalar paths use the same literal constructors, but pass the leaf
   // directly through erased records and flat sums. No temporary argument
   // array is needed at those edges. Ordinary constructors keep their array
   // calling convention; no private value reaches the public builder API.
   const composeScalar=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=value=>value;
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=value=>p.make([inner(value)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?composeScalar(last+1):value=>value):composeScalar(last);
     return value=>node.flat(index,payload(value));
    }
    const inner=at+1<path.length?composeScalar(at+1):null;
    if(pattern.transparent)return inner??(value=>value);
    return inner?value=>pattern.make([inner(value)]):value=>pattern.make([value]);
   };
   const scalar=composeScalar(0);
   const pattern={...terminal,make};
   // Only frozen arrays of ordinary data properties can key reusable plans.
   // Mutable arrays and frozen accessor arrays retain checked per-call paths.
   const fixed=charges.every(([p])=>Number.isSafeInteger(p.bytes)&&p.bytes>=4);
   const plan={pattern,scalar,charges,offset:depth-startDepth,bytes:fixed?charges.reduce((n,[p])=>n+p.bytes,0):null};
   let reusable=Object.isFrozen(choices);
   for(let i=0;reusable&&i<choices.length;i++){const field=Object.getOwnPropertyDescriptor(choices,String(i));reusable=!!field&&Object.hasOwn(field,'value');}
   if(reusable){
    if(!entries){entries=new Map();cache.set(choices,entries);}entries.set(startNode,plan);
   }
   return plan;
 };
 const chargePath=(plan,depth)=>{
  // Each emitted constructor consumes one node and a fixed frame/tag cost.
  // Only take the combined charge when every original check would succeed.
  // Replaying the original order retains the exact first failure otherwise.
  if(plan.bytes!==null&&depth+plan.offset<=budget.depth&&plan.charges.length<=budget.remaining&&budget.bytes+plan.bytes<=budget.limit){
   budget.remaining-=plan.charges.length;budget.bytes+=plan.bytes;return;
  }
  for(const [pattern,offset]of plan.charges)pattern.charge(budget,depth+offset);
 };
 // Operations are allocated once per session, and share expected-node
 // scratch only while the existing reentrancy guard is held.
 const openOperation=(choice)=>{
   expected();const node=nodes[targetNode];
   if(!Number.isSafeInteger(choice)||choice<0||!node.patterns||choice>=node.patterns.length)fail('invalid value builder constructor');
   const pattern=node.patterns[choice];pattern.charge(budget,targetDepth);
   frames.push({pattern,depth:targetDepth,values:[]});
 };
 const openPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth);
   chargePath(plan,targetDepth);
   frames.push({pattern:plan.pattern,depth:targetDepth+plan.offset,values:[]});
 };
 const scalarPathOperation=(choices,value)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==1)fail('value builder path has no scalar leaf');
   const capture=nodes[pattern.children[0]].scalar;
   if(typeof capture!=='function')fail('value builder path has no scalar leaf');
   chargePath(plan,targetDepth);
   const leaf=capture(value,budget,targetDepth+plan.offset+pattern.childDepth);
   accept(plan.scalar(leaf));
 };
 const emptyPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==0)fail('value builder path is not empty');
   chargePath(plan,targetDepth);accept(pattern.make([]));
 };
 const scalarOperation=(value)=>{
   expected();const capture=nodes[targetNode].scalar;
   if(typeof capture!=='function')fail('value builder expects a constructor');
   accept(capture(value,budget,targetDepth));
 };
 const closeOperation=()=>{
   if(!frames.length)fail('value builder has no open constructor');
   const frame=frames.at(-1),pattern=frame.pattern,count=frame.values.length;
   if(!pattern.sequence&&count!==pattern.children.length||pattern.size!==undefined&&count!==pattern.size)fail('value builder constructor arity');
   if(pattern.sequence&&count>budget.limit)fail('wire sequence size');
   const value=pattern.make(frame.values);
   frames.pop();accept(value);
 };
 const finishOperation=()=>{
   if(frames.length||!complete)fail('value builder root is incomplete');
   closed=true;const handle=__compiledHandle(identity,result);result=undefined;return handle;
 };
 const api=Object.freeze({
  open(choice){return execute(openOperation,choice);},
  // Charge every source constructor even when unary paths share one frame.
  openPath(choices){return execute(openPathOperation,choices);},
  // Complete the path and leaf without intermediate session frames.
  scalarPath(choices,value){return execute(scalarPathOperation,choices,value);},
  emptyPath(choices){return execute(emptyPathOperation,choices);},
  scalar(value){return execute(scalarOperation,value);},
  close(){return execute(closeOperation);},
  finish(){return execute(finishOperation);},
  abort(){if(busy)throw Error('value builder operation already active');failed=true;frames.length=0;result=undefined;},
 });
 return api;
}
function __reduceValue0(value,r,b,d,c){b.enter(d,4);return r[0](__reduceValue1(value["a"],r,b,d+1,c),__reduceValue1(value["b"],r,b,d+1,c),c);}
function __reduceValue1(value,r,b,d,c){b.enter(d,8);return r[1]({F32Bits:__nfBits(value)},c);}
function __reduceValue2(value,r,b,d,c){b.enter(d,4);return r[2](__reduceValue0(value["p"],r,b,d+1,c),__reduceValue0(value["q"],r,b,d+1,c),__reduceValue0(value["r"],r,b,d+1,c),__reduceValue0(value["s"],r,b,d+1,c),__reduceValue0(value["t"],r,b,d+1,c),__reduceValue0(value["u"],r,b,d+1,c),c);}
function __reduceValue3(value,r,b,d,c){b.enter(d,5);return r[3](value,c);}
function __reduceValue4(value,r,b,d,c){b.enter(d,8);return r[4](value,c);}
function __reduceValue5(value,r,b,d,c){b.enter(d,4);return r[5](__reduceValue4(value["value"],r,b,d+1,c),__reduceValue6(value["previous"],r,b,d+1,c),c);}
function __reduceValue6(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'None')&&value.None===null?r[6](0,null,c):r[6](1,__reduceValue5(value.Some,r,b,d+1,c),c);}
function __reduceValue7(value,r,b,d,c){b.enter(d,4);return r[7](__reduceValue8(value["p"],r,b,d+1,c),__reduceValue8(value["q"],r,b,d+1,c),__reduceValue8(value["r"],r,b,d+1,c),__reduceValue8(value["s"],r,b,d+1,c),__reduceValue8(value["t"],r,b,d+1,c),__reduceValue8(value["u"],r,b,d+1,c),c);}
function __reduceValue8(value,r,b,d,c){b.enter(d,4);return r[8](__reduceValue9(value["a"],r,b,d+1,c),__reduceValue9(value["b"],r,b,d+1,c),c);}
function __reduceValue9(value,r,b,d,c){b.enter(d,4);return r[9](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue1(value["tangent_0"],r,b,d+1,c),__reduceValue1(value["tangent_1"],r,b,d+1,c),__reduceValue1(value["tangent_2"],r,b,d+1,c),__reduceValue1(value["tangent_3"],r,b,d+1,c),__reduceValue1(value["tangent_4"],r,b,d+1,c),__reduceValue1(value["tangent_5"],r,b,d+1,c),__reduceValue1(value["tangent_6"],r,b,d+1,c),__reduceValue1(value["tangent_7"],r,b,d+1,c),__reduceValue1(value["tangent_8"],r,b,d+1,c),__reduceValue1(value["tangent_9"],r,b,d+1,c),__reduceValue1(value["tangent_10"],r,b,d+1,c),__reduceValue1(value["tangent_11"],r,b,d+1,c),c);}
function __reduceValue10(value,r,b,d,c){b.enter(d,4);return r[10](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue1(value["tangent"],r,b,d+1,c),c);}
function __reduceValue11(value,r,b,d,c){b.enter(d,4);return r[11](__reduceValue12(value["p"],r,b,d+1,c),__reduceValue12(value["q"],r,b,d+1,c),__reduceValue12(value["r"],r,b,d+1,c),__reduceValue12(value["s"],r,b,d+1,c),__reduceValue12(value["t"],r,b,d+1,c),__reduceValue12(value["u"],r,b,d+1,c),c);}
function __reduceValue12(value,r,b,d,c){b.enter(d,4);return r[12](__reduceValue10(value["a"],r,b,d+1,c),__reduceValue10(value["b"],r,b,d+1,c),c);}
let __reductionNodeCache;function __reductionNodes(){return __reductionNodeCache??=Object.freeze([Object.freeze({"children":Object.freeze([1,1]),"fields":Object.freeze(["a","b"]),"kind":"record","name":"Pair"}),Object.freeze({"children":Object.freeze([]),"kind":"f32"}),Object.freeze({"children":Object.freeze([0,0,0,0,0,0]),"fields":Object.freeze(["p","q","r","s","t","u"]),"kind":"record","name":"Bundle"}),Object.freeze({"children":Object.freeze([]),"kind":"bool"}),Object.freeze({"children":Object.freeze([]),"kind":"u32"}),Object.freeze({"children":Object.freeze([4,6]),"fields":Object.freeze(["value","previous"]),"kind":"record","name":"Node"}),Object.freeze({"children":Object.freeze([5]),"kind":"option"}),Object.freeze({"children":Object.freeze([8,8,8,8,8,8]),"fields":Object.freeze(["p","q","r","s","t","u"]),"kind":"record","name":"__ink_differential_4"}),Object.freeze({"children":Object.freeze([9,9]),"fields":Object.freeze(["a","b"]),"kind":"record","name":"__ink_differential_5"}),Object.freeze({"children":Object.freeze([1,1,1,1,1,1,1,1,1,1,1,1,1]),"fields":Object.freeze(["value","tangent_0","tangent_1","tangent_2","tangent_3","tangent_4","tangent_5","tangent_6","tangent_7","tangent_8","tangent_9","tangent_10","tangent_11"]),"kind":"record","name":"__ink_differential_2"}),Object.freeze({"children":Object.freeze([1,1]),"fields":Object.freeze(["value","tangent"]),"kind":"record","name":"__ink_differential_0"}),Object.freeze({"children":Object.freeze([12,12,12,12,12,12]),"fields":Object.freeze(["p","q","r","s","t","u"]),"kind":"record","name":"__ink_differential_21"}),Object.freeze({"children":Object.freeze([10,10]),"fields":Object.freeze(["a","b"]),"kind":"record","name":"__ink_differential_22"})]);}
function __compiledNamed1(){return {"Node":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}};}
function __compiledNamed0(){return {};}
let __compiledCodec0Value;function __compiledCodec0(){return __compiledCodec0Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"5728eeaa0e138ea2f93b2c91d176edec672a97fdd0e45fa08b4dacd31d4beebf","named":__compiledNamed0(),"root":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},__privateCapture0,__privateWireValue0,__privateWireWrite0,__compiledOwnedValue0,0,0,__reduceValue0,false,false);}
let __compiledCodec1Value;function __compiledCodec1(){return __compiledCodec1Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":__compiledNamed0(),"root":{"kind":"f32"}},__privateCapture1,__privateWireValue1,__privateWireWrite1,__compiledOwnedValue1,1,1,__reduceValue1,false,false);}
let __compiledCodec2Value;function __compiledCodec2(){return __compiledCodec2Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"7882b66162c075a7679604fdc86c31922fb250d10394af5aa2d1354c654b72e5","named":__compiledNamed0(),"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"q","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"r","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"s","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"t","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}},{"name":"u","type":{"fields":[{"name":"a","type":{"kind":"f32"}},{"name":"b","type":{"kind":"f32"}}],"kind":"record","name":"Pair"}}],"kind":"record","name":"Bundle"}},__privateCapture2,__privateWireValue3,__privateWireWrite2,__compiledOwnedValue2,2,2,__reduceValue2,false,false);}
let __compiledCodec3Value;function __compiledCodec3(){return __compiledCodec3Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":__compiledNamed0(),"root":{"kind":"bool"}},__privateCapture3,__privateWireValue6,__privateWireWrite3,__compiledOwnedValue3,3,3,__reduceValue3,false,false);}
let __compiledCodec4Value;function __compiledCodec4(){return __compiledCodec4Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff","named":__compiledNamed0(),"root":{"kind":"u32"}},__privateCapture4,__privateWireValue11,__privateWireWrite4,__compiledOwnedValue4,4,4,__reduceValue4,false,false);}
let __compiledCodec5Value;function __compiledCodec5(){return __compiledCodec5Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"06a5b110d3c213512730b89ea5797ec6a338f55b0c357c4c3894a84ac3cfa9e3","named":__compiledNamed1(),"root":{"fields":[{"name":"value","type":{"kind":"u32"}},{"name":"previous","type":{"element":{"kind":"ref","name":"Node"},"kind":"option"}}],"kind":"record","name":"Node"}},__privateCapture5,__privateWireValue12,__privateWireWrite5,__compiledOwnedValue5,5,5,__reduceValue5,false,false);}
let __compiledCodec6Value;function __compiledCodec6(){return __compiledCodec6Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"1ed4df67eec523fb721f2ffb2ccd09b8aa81b446e7cf8b212dcb0624fdc7c7ae","named":__compiledNamed0(),"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}}],"kind":"record","name":"__ink_differential_5"}}],"kind":"record","name":"__ink_differential_4"}},__privateCapture7,__privateWireValue15,__privateWireWrite7,__compiledOwnedValue8,7,7,__reduceValue7,false,false);}
let __compiledCodec7Value;function __compiledCodec7(){return __compiledCodec7Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"bb2b2f3efce5ad7f78fd263ef8cf59e1adcabaeb4e987b0d193c2a16c631b760","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent_0","type":{"kind":"f32"}},{"name":"tangent_1","type":{"kind":"f32"}},{"name":"tangent_2","type":{"kind":"f32"}},{"name":"tangent_3","type":{"kind":"f32"}},{"name":"tangent_4","type":{"kind":"f32"}},{"name":"tangent_5","type":{"kind":"f32"}},{"name":"tangent_6","type":{"kind":"f32"}},{"name":"tangent_7","type":{"kind":"f32"}},{"name":"tangent_8","type":{"kind":"f32"}},{"name":"tangent_9","type":{"kind":"f32"}},{"name":"tangent_10","type":{"kind":"f32"}},{"name":"tangent_11","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_2"}},__privateCapture9,__privateWireValue17,__privateWireWrite9,__compiledOwnedValue10,9,9,__reduceValue9,false,false);}
let __compiledCodec8Value;function __compiledCodec8(){return __compiledCodec8Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},__privateCapture10,__privateWireValue19,__privateWireWrite10,__compiledOwnedValue11,10,10,__reduceValue10,false,false);}
let __compiledCodec9Value;function __compiledCodec9(){return __compiledCodec9Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"184b9a0f696a7df0c965d31530477d4a3b357365123b431716058e9a227b0ea0","named":__compiledNamed0(),"root":{"fields":[{"name":"p","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"q","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"r","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"s","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"t","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}},{"name":"u","type":{"fields":[{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"__ink_differential_22"}}],"kind":"record","name":"__ink_differential_21"}},__privateCapture11,__privateWireValue23,__privateWireWrite11,__compiledOwnedValue12,11,11,__reduceValue11,false,false);}
const __compiledEntries=new Map([["component",{index:0,params:[__compiledCodec0,__compiledCodec1],result:__compiledCodec1,destination:null,arguments:__privateWireValue2,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["energy",{index:1,params:[__compiledCodec2,__compiledCodec1],result:__compiledCodec1,destination:null,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["derivatives",{index:2,params:[__compiledCodec2,__compiledCodec1],result:__compiledCodec2,destination:null,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["direction",{index:3,params:[__compiledCodec2,__compiledCodec1],result:__compiledCodec1,destination:null,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["twice",{index:4,params:[__compiledCodec0],result:__compiledCodec1,destination:null,arguments:__privateWireValue5,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["selected",{index:5,params:[__compiledCodec0,__compiledCodec3],result:__compiledCodec0,destination:null,arguments:__privateWireValue7,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["branches",{index:6,params:[__compiledCodec1,__compiledCodec3],result:__compiledCodec0,destination:null,arguments:__privateWireValue8,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["looping",{index:7,params:[__compiledCodec1],result:__compiledCodec0,destination:null,arguments:__privateWireValue9,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["strict_unused",{index:8,params:[__compiledCodec0],result:__compiledCodec1,destination:null,arguments:__privateWireValue5,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["strict",{index:9,params:[__compiledCodec1,__compiledCodec1],result:__compiledCodec1,destination:null,arguments:__privateWireValue10,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["history",{index:10,params:[__compiledCodec4],result:__compiledCodec5,destination:null,arguments:__privateWireValue14,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["__ink_differential_3",{index:11,params:[__compiledCodec6,__compiledCodec7],result:__compiledCodec7,destination:null,arguments:__privateWireValue18,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_1",{index:12,params:[__compiledCodec2,__compiledCodec1],result:__compiledCodec2,destination:null,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_23",{index:13,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,destination:null,arguments:__privateWireValue20,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_27",{index:14,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,destination:null,arguments:__privateWireValue21,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_31",{index:15,params:[__compiledCodec8,__compiledCodec8],result:__compiledCodec8,destination:null,arguments:__privateWireValue22,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_20",{index:16,params:[__compiledCodec9,__compiledCodec8],result:__compiledCodec8,destination:null,arguments:__privateWireValue25,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_19",{index:17,params:[__compiledCodec2,__compiledCodec2,__compiledCodec1],result:__compiledCodec1,destination:null,arguments:__privateWireValue26,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}]]);

export const compiledValues=Object.freeze(Object.fromEntries([...__compiledEntries].map(([name,entry])=>[name,Object.freeze({get params(){return Object.freeze(entry.params.map(codec=>codec()));},get result(){return entry.result();}})])));
function __compiledValidate(entry,owned){
 const values=owned.map(v=>v.value);
 const established=entry.onlyTypeGuards&&entry.needsInvariants.every((needed,i)=>!needed||owned[i].guaranteed);
 if(entry.precondition!==null&&!established){
  if(__implementations[entry.precondition](...values)!==true)throw Error('contract precondition failed');
  for(let i=0;i<owned.length;i++)if(entry.needsInvariants[i])owned[i].guaranteed=true;
 }
 return values;
}
export function callCompiled(name,args){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(args)||args.length!==entry.params.length)throw Error('unsupported compiled call');
 const owned=entry.params.map((codec,i)=>__compiledEntry(args[i],codec().identity)),values=__compiledValidate(entry,owned);
 // Checked source outputs satisfy their declared value interfaces. Private
 // handles expose only detached copies and never retain mutable host inputs.
 return __compiledHandle(entry.result().identity,__implementations[entry.index](...values),true);
}

// Explicit sealed-value partial application. Each token owns a bounded set of
// lexical caches; no mutable host object, global memo table or error is retained.
const __preparedCompiled=new WeakMap();
export function prepareCompiled(name,bindings){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(bindings)||bindings.length>entry.params.length)throw Error('unsupported prepared compiled call');
 const captured=new Array(entry.params.length),fixed=new Array(entry.params.length).fill(false);
 for(const binding of bindings){
  if(!Array.isArray(binding)||binding.length!==2)throw Error('prepared compiled binding');
  const [index,handle]=binding;
  if(!Number.isInteger(index)||index<0||index>=fixed.length||fixed[index])throw Error('prepared compiled parameter');
  captured[index]=__compiledEntry(handle,entry.params[index]().identity);fixed[index]=true;
 }
 const remaining=fixed.flatMap((yes,i)=>yes?[]:[i]);
 const factory=__preparedFactories.get(entry.index);
 const run=factory?factory(fixed):__implementations[entry.index];
 const token=Object.freeze(Object.create(null));
 __preparedCompiled.set(token,{entry,captured,remaining,run});return token;
}
export function callPreparedCompiled(token,args){
 const prepared=__preparedCompiled.get(token);
 if(!prepared||!Array.isArray(args)||args.length!==prepared.remaining.length)throw Error('invalid prepared compiled call');
 const {entry,captured,remaining,run}=prepared,owned=captured.slice();
 for(let i=0;i<remaining.length;i++){const at=remaining[i];owned[at]=__compiledEntry(args[i],entry.params[at]().identity);}
 const values=__compiledValidate(entry,owned);
 return __compiledHandle(entry.result().identity,run(...values),true);
}
// The caller owns sufficiently large, disjoint destination storage. This is
// the trusted Into ABI, not a bounded wire/materialization operation. Private
// retained containers never escape: structured elements are deeply detached.
const __destinationBudget=Object.freeze({remaining:Infinity,enter(){},text(){}});
export function callPreparedCompiledInto(token,args,destination){
 const prepared=__preparedCompiled.get(token);
 if(!prepared||!prepared.entry.destination||!Array.isArray(args)||args.length!==prepared.remaining.length)throw Error('invalid prepared compiled destination call');
 const {entry,captured,remaining,run}=prepared,owned=captured.slice();
 for(let i=0;i<remaining.length;i++){const at=remaining[i];owned[at]=__compiledEntry(args[i],entry.params[at]().identity);}
 const values=__compiledValidate(entry,owned),into=entry.destination;
 // Ordinary scalar-list bodies can write the terminal stage directly. A
 // residual body keeps its lexical caches and copies only its final elements.
 if(into.direct&&run===__implementations[entry.index])return into.direct(...values,destination);
 const result=run(...values),n=result.length;
 for(let i=0;i<n;i++)destination[i]=into.copy(result[i],__destinationBudget,0);
 return n;
}
const __intoImplementations=[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null];
export const functionsInto=Object.freeze(Object.fromEntries([]));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}

function __preparedPart(mask,path){
 for(const field of path){
  if(mask===true)return true;
  if(!mask || typeof mask!=="object")return false;
  mask=Object.hasOwn(mask.fields,field)?mask.fields[field]:false;
 }
 return mask;
}
function __preparedStable(mask,path){const part=__preparedPart(mask,path);return part===true || (!!part && part.all===true);}
function __prepareFn2(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[]))))return __fn2;const v1487=depth<15&&__preparedFactories.has(12)&&((__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[])));
let v1485;
return function(v1483,v1484){let v1488;if(v1487){if(!v1485){const v1486=__preparedFactories.get(12);v1485=v1486([fixed[0],fixed[1]],depth+1);}v1488=v1485(v1483,v1484);}else{v1488=__fn12(v1483,v1484);}
return v1488;};}
function __prepareFn12(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[]))))return __fn12;const v2553=__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[]);
let v2552=false,v2551;
const v2741=__preparedPart(fixed[0],["p","a"]);
const v2742={all:__preparedStable(fixed[0],["p","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2741}};
const v2743=__preparedPart(fixed[0],["p","b"]);
const v2744={all:__preparedStable(fixed[0],["p","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2743}};
const v2745={all:__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"]),fields:{["a"]:v2742,["b"]:v2744}};
const v2746=__preparedPart(fixed[0],["q","a"]);
const v2747={all:__preparedStable(fixed[0],["q","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2746}};
const v2748=__preparedPart(fixed[0],["q","b"]);
const v2749={all:__preparedStable(fixed[0],["q","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2748}};
const v2750={all:__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"]),fields:{["a"]:v2747,["b"]:v2749}};
const v2751=__preparedPart(fixed[0],["r","a"]);
const v2752={all:__preparedStable(fixed[0],["r","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2751}};
const v2753=__preparedPart(fixed[0],["r","b"]);
const v2754={all:__preparedStable(fixed[0],["r","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2753}};
const v2755={all:__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"]),fields:{["a"]:v2752,["b"]:v2754}};
const v2756=__preparedPart(fixed[0],["s","a"]);
const v2757={all:__preparedStable(fixed[0],["s","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2756}};
const v2758=__preparedPart(fixed[0],["s","b"]);
const v2759={all:__preparedStable(fixed[0],["s","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2758}};
const v2760={all:__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"]),fields:{["a"]:v2757,["b"]:v2759}};
const v2761=__preparedPart(fixed[0],["t","a"]);
const v2762={all:__preparedStable(fixed[0],["t","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2761}};
const v2763=__preparedPart(fixed[0],["t","b"]);
const v2764={all:__preparedStable(fixed[0],["t","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2763}};
const v2765={all:__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"]),fields:{["a"]:v2762,["b"]:v2764}};
const v2766=__preparedPart(fixed[0],["u","a"]);
const v2767={all:__preparedStable(fixed[0],["u","a"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2766}};
const v2768=__preparedPart(fixed[0],["u","b"]);
const v2769={all:__preparedStable(fixed[0],["u","b"]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:v2768}};
const v2770={all:__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"]),fields:{["a"]:v2767,["b"]:v2769}};
const v2771={all:__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"]),fields:{["p"]:v2745,["q"]:v2750,["r"]:v2755,["s"]:v2760,["t"]:v2765,["u"]:v2770}};
const v2785={all:__preparedStable(fixed[1],[]),fields:{["tangent_0"]:true,["tangent_1"]:true,["tangent_10"]:true,["tangent_11"]:true,["tangent_2"]:true,["tangent_3"]:true,["tangent_4"]:true,["tangent_5"]:true,["tangent_6"]:true,["tangent_7"]:true,["tangent_8"]:true,["tangent_9"]:true,["value"]:fixed[1]}};
const v2788=depth<15&&__preparedFactories.has(11)&&((__preparedStable(fixed[0],["p","a"])&&__preparedStable(fixed[0],["p","b"])&&__preparedStable(fixed[0],["q","a"])&&__preparedStable(fixed[0],["q","b"])&&__preparedStable(fixed[0],["r","a"])&&__preparedStable(fixed[0],["r","b"])&&__preparedStable(fixed[0],["s","a"])&&__preparedStable(fixed[0],["s","b"])&&__preparedStable(fixed[0],["t","a"])&&__preparedStable(fixed[0],["t","b"])&&__preparedStable(fixed[0],["u","a"])&&__preparedStable(fixed[0],["u","b"])&&__preparedStable(fixed[1],[])));
let v2786;
return function(v2548,v2549){let v2550;if(v2553&&v2552){v2550=v2551;}else{
const v2554=v2548["p"];
const v2555=v2554["a"];
const v2556=1.0;
const v2557=0.0;
const v2558=0.0;
const v2559=0.0;
const v2560=0.0;
const v2561=0.0;
const v2562=0.0;
const v2563=0.0;
const v2564=0.0;
const v2565=0.0;
const v2566=0.0;
const v2567=0.0;
const v2569=v2548["p"];
const v2570=v2569["b"];
const v2571=0.0;
const v2572=1.0;
const v2573=0.0;
const v2574=0.0;
const v2575=0.0;
const v2576=0.0;
const v2577=0.0;
const v2578=0.0;
const v2579=0.0;
const v2580=0.0;
const v2581=0.0;
const v2582=0.0;
const v2585=v2548["q"];
const v2586=v2585["a"];
const v2587=0.0;
const v2588=0.0;
const v2589=1.0;
const v2590=0.0;
const v2591=0.0;
const v2592=0.0;
const v2593=0.0;
const v2594=0.0;
const v2595=0.0;
const v2596=0.0;
const v2597=0.0;
const v2598=0.0;
const v2600=v2548["q"];
const v2601=v2600["b"];
const v2602=0.0;
const v2603=0.0;
const v2604=0.0;
const v2605=1.0;
const v2606=0.0;
const v2607=0.0;
const v2608=0.0;
const v2609=0.0;
const v2610=0.0;
const v2611=0.0;
const v2612=0.0;
const v2613=0.0;
const v2616=v2548["r"];
const v2617=v2616["a"];
const v2618=0.0;
const v2619=0.0;
const v2620=0.0;
const v2621=0.0;
const v2622=1.0;
const v2623=0.0;
const v2624=0.0;
const v2625=0.0;
const v2626=0.0;
const v2627=0.0;
const v2628=0.0;
const v2629=0.0;
const v2631=v2548["r"];
const v2632=v2631["b"];
const v2633=0.0;
const v2634=0.0;
const v2635=0.0;
const v2636=0.0;
const v2637=0.0;
const v2638=1.0;
const v2639=0.0;
const v2640=0.0;
const v2641=0.0;
const v2642=0.0;
const v2643=0.0;
const v2644=0.0;
const v2647=v2548["s"];
const v2648=v2647["a"];
const v2649=0.0;
const v2650=0.0;
const v2651=0.0;
const v2652=0.0;
const v2653=0.0;
const v2654=0.0;
const v2655=1.0;
const v2656=0.0;
const v2657=0.0;
const v2658=0.0;
const v2659=0.0;
const v2660=0.0;
const v2662=v2548["s"];
const v2663=v2662["b"];
const v2664=0.0;
const v2665=0.0;
const v2666=0.0;
const v2667=0.0;
const v2668=0.0;
const v2669=0.0;
const v2670=0.0;
const v2671=1.0;
const v2672=0.0;
const v2673=0.0;
const v2674=0.0;
const v2675=0.0;
const v2678=v2548["t"];
const v2679=v2678["a"];
const v2680=0.0;
const v2681=0.0;
const v2682=0.0;
const v2683=0.0;
const v2684=0.0;
const v2685=0.0;
const v2686=0.0;
const v2687=0.0;
const v2688=1.0;
const v2689=0.0;
const v2690=0.0;
const v2691=0.0;
const v2693=v2548["t"];
const v2694=v2693["b"];
const v2695=0.0;
const v2696=0.0;
const v2697=0.0;
const v2698=0.0;
const v2699=0.0;
const v2700=0.0;
const v2701=0.0;
const v2702=0.0;
const v2703=0.0;
const v2704=1.0;
const v2705=0.0;
const v2706=0.0;
const v2709=v2548["u"];
const v2710=v2709["a"];
const v2711=0.0;
const v2712=0.0;
const v2713=0.0;
const v2714=0.0;
const v2715=0.0;
const v2716=0.0;
const v2717=0.0;
const v2718=0.0;
const v2719=0.0;
const v2720=0.0;
const v2721=1.0;
const v2722=0.0;
const v2724=v2548["u"];
const v2725=v2724["b"];
const v2726=0.0;
const v2727=0.0;
const v2728=0.0;
const v2729=0.0;
const v2730=0.0;
const v2731=0.0;
const v2732=0.0;
const v2733=0.0;
const v2734=0.0;
const v2735=0.0;
const v2736=0.0;
const v2737=1.0;
const v2740=({["p"]:({["a"]:({["value"]:v2555,["tangent_0"]:v2556,["tangent_1"]:v2557,["tangent_2"]:v2558,["tangent_3"]:v2559,["tangent_4"]:v2560,["tangent_5"]:v2561,["tangent_6"]:v2562,["tangent_7"]:v2563,["tangent_8"]:v2564,["tangent_9"]:v2565,["tangent_10"]:v2566,["tangent_11"]:v2567}),["b"]:({["value"]:v2570,["tangent_0"]:v2571,["tangent_1"]:v2572,["tangent_2"]:v2573,["tangent_3"]:v2574,["tangent_4"]:v2575,["tangent_5"]:v2576,["tangent_6"]:v2577,["tangent_7"]:v2578,["tangent_8"]:v2579,["tangent_9"]:v2580,["tangent_10"]:v2581,["tangent_11"]:v2582})}),["q"]:({["a"]:({["value"]:v2586,["tangent_0"]:v2587,["tangent_1"]:v2588,["tangent_2"]:v2589,["tangent_3"]:v2590,["tangent_4"]:v2591,["tangent_5"]:v2592,["tangent_6"]:v2593,["tangent_7"]:v2594,["tangent_8"]:v2595,["tangent_9"]:v2596,["tangent_10"]:v2597,["tangent_11"]:v2598}),["b"]:({["value"]:v2601,["tangent_0"]:v2602,["tangent_1"]:v2603,["tangent_2"]:v2604,["tangent_3"]:v2605,["tangent_4"]:v2606,["tangent_5"]:v2607,["tangent_6"]:v2608,["tangent_7"]:v2609,["tangent_8"]:v2610,["tangent_9"]:v2611,["tangent_10"]:v2612,["tangent_11"]:v2613})}),["r"]:({["a"]:({["value"]:v2617,["tangent_0"]:v2618,["tangent_1"]:v2619,["tangent_2"]:v2620,["tangent_3"]:v2621,["tangent_4"]:v2622,["tangent_5"]:v2623,["tangent_6"]:v2624,["tangent_7"]:v2625,["tangent_8"]:v2626,["tangent_9"]:v2627,["tangent_10"]:v2628,["tangent_11"]:v2629}),["b"]:({["value"]:v2632,["tangent_0"]:v2633,["tangent_1"]:v2634,["tangent_2"]:v2635,["tangent_3"]:v2636,["tangent_4"]:v2637,["tangent_5"]:v2638,["tangent_6"]:v2639,["tangent_7"]:v2640,["tangent_8"]:v2641,["tangent_9"]:v2642,["tangent_10"]:v2643,["tangent_11"]:v2644})}),["s"]:({["a"]:({["value"]:v2648,["tangent_0"]:v2649,["tangent_1"]:v2650,["tangent_2"]:v2651,["tangent_3"]:v2652,["tangent_4"]:v2653,["tangent_5"]:v2654,["tangent_6"]:v2655,["tangent_7"]:v2656,["tangent_8"]:v2657,["tangent_9"]:v2658,["tangent_10"]:v2659,["tangent_11"]:v2660}),["b"]:({["value"]:v2663,["tangent_0"]:v2664,["tangent_1"]:v2665,["tangent_2"]:v2666,["tangent_3"]:v2667,["tangent_4"]:v2668,["tangent_5"]:v2669,["tangent_6"]:v2670,["tangent_7"]:v2671,["tangent_8"]:v2672,["tangent_9"]:v2673,["tangent_10"]:v2674,["tangent_11"]:v2675})}),["t"]:({["a"]:({["value"]:v2679,["tangent_0"]:v2680,["tangent_1"]:v2681,["tangent_2"]:v2682,["tangent_3"]:v2683,["tangent_4"]:v2684,["tangent_5"]:v2685,["tangent_6"]:v2686,["tangent_7"]:v2687,["tangent_8"]:v2688,["tangent_9"]:v2689,["tangent_10"]:v2690,["tangent_11"]:v2691}),["b"]:({["value"]:v2694,["tangent_0"]:v2695,["tangent_1"]:v2696,["tangent_2"]:v2697,["tangent_3"]:v2698,["tangent_4"]:v2699,["tangent_5"]:v2700,["tangent_6"]:v2701,["tangent_7"]:v2702,["tangent_8"]:v2703,["tangent_9"]:v2704,["tangent_10"]:v2705,["tangent_11"]:v2706})}),["u"]:({["a"]:({["value"]:v2710,["tangent_0"]:v2711,["tangent_1"]:v2712,["tangent_2"]:v2713,["tangent_3"]:v2714,["tangent_4"]:v2715,["tangent_5"]:v2716,["tangent_6"]:v2717,["tangent_7"]:v2718,["tangent_8"]:v2719,["tangent_9"]:v2720,["tangent_10"]:v2721,["tangent_11"]:v2722}),["b"]:({["value"]:v2725,["tangent_0"]:v2726,["tangent_1"]:v2727,["tangent_2"]:v2728,["tangent_3"]:v2729,["tangent_4"]:v2730,["tangent_5"]:v2731,["tangent_6"]:v2732,["tangent_7"]:v2733,["tangent_8"]:v2734,["tangent_9"]:v2735,["tangent_10"]:v2736,["tangent_11"]:v2737})})});
const v2772=0.0;
const v2773=0.0;
const v2774=0.0;
const v2775=0.0;
const v2776=0.0;
const v2777=0.0;
const v2778=0.0;
const v2779=0.0;
const v2780=0.0;
const v2781=0.0;
const v2782=0.0;
const v2783=0.0;
const v2784=({["value"]:v2549,["tangent_0"]:v2772,["tangent_1"]:v2773,["tangent_2"]:v2774,["tangent_3"]:v2775,["tangent_4"]:v2776,["tangent_5"]:v2777,["tangent_6"]:v2778,["tangent_7"]:v2779,["tangent_8"]:v2780,["tangent_9"]:v2781,["tangent_10"]:v2782,["tangent_11"]:v2783});
let v2789;if(v2788){if(!v2786){const v2787=__preparedFactories.get(11);v2786=v2787([v2771,v2785],depth+1);}v2789=v2786(v2740,v2784);}else{v2789=__fn11(v2740,v2784);}
v2550=v2789;if(v2553){v2551=v2550;v2552=true;}}
const v2790=v2550;
const v2791=v2790["tangent_0"];
const v2792=v2550;
const v2793=v2792["tangent_1"];
const v2795=v2550;
const v2796=v2795["tangent_2"];
const v2797=v2550;
const v2798=v2797["tangent_3"];
const v2800=v2550;
const v2801=v2800["tangent_4"];
const v2802=v2550;
const v2803=v2802["tangent_5"];
const v2805=v2550;
const v2806=v2805["tangent_6"];
const v2807=v2550;
const v2808=v2807["tangent_7"];
const v2810=v2550;
const v2811=v2810["tangent_8"];
const v2812=v2550;
const v2813=v2812["tangent_9"];
const v2815=v2550;
const v2816=v2815["tangent_10"];
const v2817=v2550;
const v2818=v2817["tangent_11"];
return ({["p"]:({["a"]:v2791,["b"]:v2793}),["q"]:({["a"]:v2796,["b"]:v2798}),["r"]:({["a"]:v2801,["b"]:v2803}),["s"]:({["a"]:v2806,["b"]:v2808}),["t"]:({["a"]:v2811,["b"]:v2813}),["u"]:({["a"]:v2816,["b"]:v2818})});};}
const __preparedFactories=new Map([[2,__prepareFn2],[12,__prepareFn12]]);
