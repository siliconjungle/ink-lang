const __recordElisions=new Set([]);
const __nativeF32=false;
// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
// Binary64 uses native Numbers for finite arithmetic and immutable private
// tags only where a NaN's exact payload must survive non-arithmetic operations.
const __doubleView=new DataView(new ArrayBuffer(8));
const __double=bits=>{__doubleView.setBigUint64(0,bits,true);return __doubleView.getFloat64(0,true);};
const __doubleBits=number=>{if(Number.isNaN(number))return 0x7ff8000000000000n;__doubleView.setFloat64(0,number,true);return __doubleView.getBigUint64(0,true);};
const __dfNumber=value=>typeof value==='number'?value:__double(BigInt(value.F64Bits));
const __dfBits=value=>typeof value==='number'?__doubleBits(value):BigInt(value.F64Bits);
const __dfFromBits=bits=>(bits&0x7fffffffffffffffn)>0x7ff0000000000000n?Object.freeze({F64Bits:bits.toString()}):__double(bits);
const __dfInput=value=>typeof value==='number'?value:__dfFromBits(BigInt(value.F64Bits));
const __dfNeg=value=>typeof value==='number'&&!Number.isNaN(value)?-value:__dfFromBits(__dfBits(value)^0x8000000000000000n);
const __dfOutput=value=>{const n=__dfNumber(value);return Number.isFinite(n)?n:{F64Bits:__dfBits(value).toString()};};
const __dfCapture=value=>{
 if(typeof value==='number'&&Number.isFinite(value))return value;
 if(!value||typeof value!=='object'||Object.keys(value).length!==1||!Object.hasOwn(value,'F64Bits'))throw Error('invalid f64');const text=value.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid f64');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');return __dfFromBits(bits);
};
// Native binary32 lane for pure modules. Explicit NaN payloads remain tagged;
// arithmetic canonicalizes NaNs just as __bits does in the exact-bit lane.
// Host tags are captured once at a typed read. Only private immutable tags
// may pass through normalization without consulting a host property again.
const __nfTagged = new WeakSet();
const __nfValue = value => typeof value === 'number' ? Math.fround(value) : __nfTagged.has(value) ? value : __nfFromBits(value.F32Bits);
// Number operands have already been normalised at their typed read or producer.
const __nfNumber = value => typeof value === 'number' ? value : __float(value.F32Bits);
const __nfBits = value => typeof value === 'number' ? __bits(value) : value.F32Bits;
const __nfFromBits = bits => {
  if((bits & 0x7fffffff)<=0x7f800000)return __float(bits);
  const value=Object.freeze({F32Bits:bits});__nfTagged.add(value);return value;
};
const __nfNeg = value => typeof value === 'number' && !Number.isNaN(value) ? -value : __nfFromBits((__nfBits(value) ^ 0x80000000) >>> 0);
const __nfOutput = value => {const n=typeof value==='number'?Math.fround(value):__float(value.F32Bits);return Number.isFinite(n)?n:{F32Bits:__nfBits(value)};};
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output, capture=false) {
  const convert=__representationRaw(type,output,capture);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':capture?'capture:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output, capture) {
  switch (type.kind) {
    case 'ref': {
      let resolved;
      return (value,context)=>(resolved??=__representation(__namedTypes[type.name],output,capture))(value,context);
    }
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output,capture);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output,capture),err=__representation(type.error,output,capture);
      const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);
      if(flat)return output?(value,context)=>{const v=__sumView(key,value);return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};}:(v,context)=>Object.hasOwn(v,'Ok')?__sumMake(key,true,ok(v.Ok,context)):__sumMake(key,false,err(v.Err,context));
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f64':return output?__dfOutput:__dfInput;
    case 'f32': if(typeof __nativeF32!=='undefined'&&__nativeF32)return output?__nfOutput:capture?__nfValue:__identity;
      return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output,capture);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){
        if(!type.fields.length)return ()=>undefined; // lexically unconsumed projected input
        const field=type.fields[0],child=__representation(field.type,output,capture);
        return output?(value,context)=>({[field.name]:child(value,context)}):(value,context)=>child(value[field.name],context);
      }
      const fields = type.fields.map(field => [field.name, __representation(field.type, output,capture)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
function __stateWord(value){
 if(typeof value==='number'&&!Number.isSafeInteger(value))throw Error('u64 requires an exact integer');
 if(!['bigint','number','string'].includes(typeof value)||typeof value==='string'&&!/^(0|[1-9][0-9]*)$/.test(value))throw Error('invalid u64');
 const n=BigInt(value);if(n<0n||n>18446744073709551615n)throw Error('invalid u64');return n;
}
// Compile the capture traversal once. Each invocation still validates and owns
// every public container; no host value is retained between calls.
const __stateCaptures=new WeakMap();
function __stateCapture(type){
 const prior=__stateCaptures.get(type);if(prior)return prior;
 const capture=__compileStateCapture(type);__stateCaptures.set(type,capture);return capture;
}
function __compileStateCapture(type){
 const limited=copy=>(value,budget={cells:1000000},depth=0)=>{
  if(depth>64||--budget.cells<0)throw Error('state input resource limit');
  return copy(value,budget,depth);
 };
 const tagged=(value,tag)=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
 switch(type.kind){
  case 'ref':{
   // Resolve lazily so recursive schemas compile to recursive validators rather
   // than reverting to descriptor interpretation at every referenced node.
   let resolved;
   return limited((value,budget,depth)=>(resolved??=__stateCapture(__namedTypes[type.name]))(value,budget,depth+1));
  }
  case 'u32':case 'i32':{
   const min=type.kind==='u32'?0:-2147483648,max=type.kind==='u32'?4294967295:2147483647;
   return limited(value=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;});
  }
  case 'u64':return limited(__stateWord);
  case 'f64':return limited(__dfCapture);
  case 'bool':return limited(value=>{if(typeof value!=='boolean')throw Error('invalid Bool');return value;});
  case 'unit':return limited(value=>{if(value!==null)throw Error('invalid Unit');return null;});
  case 'string':return limited(value=>{if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;});
  case 'enum':return limited(value=>{if(!type.variants.includes(value))throw Error('invalid enum');return value;});
  case 'id':return limited(value=>{if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();});
  case 'list':case 'vector':{
   const item=__stateCapture(type.element),size=type.kind==='vector'?type.size:null;
   return limited((value,budget,depth)=>{
    if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
    if(size!==null&&value.length!==size)throw Error('invalid vector length');
    const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=item(value[i],budget,depth+1);return out;
   });
  }
  case 'record':{
   const fields=type.fields.map(f=>[f.name,__stateCapture(f.type)]);
   if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name)))return limited((value,budget,depth)=>{const [name,copy]=fields[0];if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,name))throw Error('invalid record');return copy(value[name],budget,depth+1);});
   return limited((value,budget,depth)=>{
    if(!value||typeof value!=='object'||Array.isArray(value)||!fields.every(([name])=>Object.hasOwn(value,name)))throw Error('invalid record');
    const out={};for(const [name,copy]of fields){const field=copy(value[name],budget,depth+1);if(name==='__proto__')Object.defineProperty(out,name,{value:field,writable:true,enumerable:true,configurable:true});else out[name]=field;}return out;
   });
  }
  case 'option':{
   const item=__stateCapture(type.element);
   return limited((value,budget,depth)=>{if(tagged(value,'Some'))return {Some:item(value.Some,budget,depth+1)};if(tagged(value,'None')&&value.None===null)return {None:null};throw Error('invalid Option');});
  }
  case 'result':{
   const ok=__stateCapture(type.ok),err=__stateCapture(type.error);
   return limited((value,budget,depth)=>{if(tagged(value,'Ok'))return {Ok:ok(value.Ok,budget,depth+1)};if(tagged(value,'Err'))return {Err:err(value.Err,budget,depth+1)};throw Error('invalid Result');});
  }
  default:return (value,budget,depth)=>__stateInput(value,type,budget,depth);
 }
}
function __stateInput(value,type,budget={cells:1000000},depth=0,maxDepth=64){
  if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');
  const input=(v,t)=>__stateInput(v,t,budget,depth+1,maxDepth);
  const integer=(min,max)=>{if(typeof value!=='number'||!Number.isInteger(value)||value<min||value>max)throw Error('invalid '+type.kind);return value===0?0:value;};
  const tagged=tag=>value&&typeof value==='object'&&!Array.isArray(value)&&Object.keys(value).length===1&&Object.hasOwn(value,tag);
  switch(type.kind){
    case 'ref':return input(value,__namedTypes[type.name]);
    case 'u32':return integer(0,4294967295);
    case 'i32':return integer(-2147483648,2147483647);
    case 'u64':return __stateWord(value);
    case 'int':{
      if(typeof value==='bigint')return value;
      if(!tagged('Int')||typeof value.Int!=='string'||!/^(-?[0-9]+)$/.test(value.Int))throw Error('invalid Int');return BigInt(value.Int);
    }
    case 'f64':return __dfCapture(value);
    case 'f32':{
      if(typeof value==='number'&&Number.isFinite(value)){const bits=__bits(value);if((bits&0x7fffffff)===0x7f800000)throw Error('f32 overflow requires F32Bits');return bits;}
      if(!tagged('F32Bits')||!Number.isInteger(value.F32Bits)||value.F32Bits<0||value.F32Bits>4294967295)throw Error('invalid f32');return value.F32Bits;
    }
    case 'bool':if(typeof value!=='boolean')throw Error('invalid Bool');return value;
    case 'unit':if(value!==null)throw Error('invalid Unit');return null;
    case 'string':if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid String');return value;
    case 'id':if(typeof value!=='string'||! /^[0-9a-fA-F]{32}$/.test(value))throw Error('invalid ID');return value.toLowerCase();
    case 'enum':if(!type.variants.includes(value))throw Error('invalid enum');return value;
    case 'list':case 'vector':{
      if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');
      if(type.kind==='vector'&&value.length!==type.size)throw Error('invalid vector length');
      return Array.from(value,v=>input(v,type.element));
    }
    case 'record':if(!value||typeof value!=='object'||Array.isArray(value)||!type.fields.every(f=>Object.hasOwn(value,f.name)))throw Error('invalid record');if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){const f=type.fields[0];return input(value[f.name],f.type);}return Object.fromEntries(type.fields.map(f=>[f.name,input(value[f.name],f.type)]));
    case 'option':if(tagged('Some'))return {Some:input(value.Some,type.element)};if(tagged('None')&&value.None===null)return {None:null};throw Error('invalid Option');
    case 'result':{const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);if(tagged('Ok')){const child=input(value.Ok,type.ok);return flat?__sumMake(key,true,child):{Ok:child};}if(tagged('Err')){const child=input(value.Err,type.error);return flat?__sumMake(key,false,child):{Err:child};}throw Error('invalid Result');}
    default:throw Error('unsupported public value type');
  }
}
// Mutable host replies must not retain references into compiled state or its outbox.
// State results must own mutable containers. Compile the declared schema once:
// scalars need no structured clone, while nested records/lists remain detached.
function __ownershipSchema(type){
 // Nominal references and expanded declarations name the same checked sort.
 // Distinct source records retain distinct keys even if a layout erases them.
 if(type.kind==='ref'||type.kind==='record'&&type.name)return ['named',type.name];
 switch(type.kind){
  case 'list':case 'vector':return [type.kind,type.size??null,__ownershipSchema(type.element)];
  case 'option':return ['option',__ownershipSchema(type.element)];
  case 'result':return ['result',__ownershipSchema(type.ok),__ownershipSchema(type.error)];
  case 'record':return ['record',type.fields.map(f=>[f.name,__ownershipSchema(f.type)])];
  default:return type;
 }
}
function __ownedResult(copy,nested,type){
 const key='owned-state:'+JSON.stringify(__ownershipSchema(type));
 let schema=__conversionKeys.get(key);
 if(!schema){schema={};__conversionKeys.set(key,schema);}
 const owned=(value,context)=>{
  if(!context&&!nested)return copy(value,null);
  const memo=context||new WeakMap();
  if(value===null||typeof value!=='object')return copy(value,memo);
  let entries=memo.get(schema);if(!entries){entries=new WeakMap();memo.set(schema,entries);}
  if(entries.has(value))return entries.get(value);
  const result=copy(value,memo);entries.set(value,result);return result;
 };
 owned.container=true;return owned;
}
function __stateResult(type){
 switch(type.kind){
  case 'ref':{let resolved;const copy=(value,context)=>(resolved??=__stateResult(__namedTypes[type.name]))(value,context);copy.container=true;return copy;}
  case 'record':{if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){const f=type.fields[0],copy=__stateResult(f.type);return __ownedResult((value,context)=>({[f.name]:copy(value,context)}),copy.container,type);}const fields=type.fields.map(f=>[f.name,__stateResult(f.type)]);return __ownedResult((value,context)=>Object.fromEntries(fields.map(([name,copy])=>[name,copy(value[name],context)])),fields.some(([,copy])=>copy.container),type);}
  case 'list':case 'vector':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Array.from(value,item=>copy(item,context)),copy.container,type);}
  case 'option':{const copy=__stateResult(type.element);return __ownedResult((value,context)=>Object.hasOwn(value,'Some')?{Some:copy(value.Some,context)}:{None:null},copy.container,type);}
  case 'result':{const ok=__stateResult(type.ok),err=__stateResult(type.error),key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);return __ownedResult((value,context)=>{const v=flat?__sumView(key,value):value;return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};},ok.container||err.container,type);}
  default:return __representation(type,true);
 }
}
function __stateOutput(value,type){return __stateResult(type)(value);}
const __u64 = n => BigInt.asUintN(64, n);
function __div(a, b, fallback, signed, remainder) {
  if (b === 0 || b === 0n || (signed && a === -2147483648 && b === -1)) return fallback();
  return typeof a === 'bigint' ? (remainder ? a % b : a / b) :
    ((remainder ? a % b : Math.trunc(a / b)) + 0); // integer zero has no sign
}
function __at(xs, index, fallback) { return index < xs.length ? xs[index] : fallback(); }
// Ordinary arrays retain the declared result element type when input is typed.
function __map(xs, fn) {
  const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = fn(xs[i], i);
  return out;
}
function __filter(xs, fn) {
  const out = [];
  for (let i = 0; i < xs.length; i++) if (fn(xs[i])) out.push(xs[i]);
  return out;
}
function __concat(xs, ys) {
  const left = xs.length, right = ys.length, out = new Array(left + right);
  for (let i = 0; i < left; i++) out[i] = xs[i];
  for (let i = 0; i < right; i++) out[left + i] = ys[i];
  return out;
}
function __zip(xs, ys, fn) {
  const n = Math.min(xs.length, ys.length), out = new Array(n);
  for (let i = 0; i < n; i++) out[i] = fn(xs[i], ys[i]);
  return out;
}
function __repeat(n, initial, fn) { let value = initial; for (let i = 0; i < n; i++) value = fn(i, value); return value; }
function __foldr(xs, initial, fn) { let value = initial; for (let i = xs.length - 1; i >= 0; i--) value = fn(xs[i], value); return value; }
function __scan(xs, zero, add) {
  let value = zero; const out = new Array(xs.length);
  for (let i = 0; i < xs.length; i++) out[i] = value = add(value, xs[i]);
  return out;
}
const __sort = xs => Array.from(xs).sort((a,b) => a < b ? -1 : a > b ? 1 : 0);

function __wordSort(xs,Storage){
 const sorted=Storage.from(xs).sort(),out=new Array(sorted.length);
 for(let i=0;i<sorted.length;i++)out[i]=sorted[i];
 return out;
}
// Fixed primitives; no cross-invocation host caches.
function __ink_round_even(x){if(!Number.isFinite(x)||Math.abs(x)>=8388608)return x;const a=Math.abs(x),i=Math.floor(a),r=a-i;const y=i+Number(r>0.5||(r===0.5&&i%2===1));return x<0||Object.is(x,-0)?-y:y;}
function __ink_round_even_f64(x){if(!Number.isFinite(x)||Math.abs(x)>=4503599627370496)return x;const a=Math.abs(x),i=Math.floor(a),r=a-i;const y=i+Number(r>0.5||(r===0.5&&i%2===1));return x<0||Object.is(x,-0)?-y:y;}
// Direct BigInt -> binary32 avoids double rounding through binary64.
function __ink_big_float(x){if(x===0n)return 0;const neg=x<0n;if(neg)x=-x;let e=x.toString(2).length-1;if(e<=23)return Number(neg?-x:x);const shift=BigInt(e-23),mask=(1n<<shift)-1n;let q=x>>shift;const rem=x&mask,half=1n<<(shift-1n);if(rem>half||(rem===half&&(q&1n)!==0n))q++;if(q===16777216n){q>>=1n;e++;}if(e>127)return neg?-Infinity:Infinity;return (neg?-1:1)*Number(q)*2**(e-23);}
function __ink_from_float(x,t){x=Math.trunc(x);if(!Number.isFinite(x))return {None:null};const valid=t==='i32'?x>=-2147483648&&x<2147483648:x>=0&&x<(t==='u32'?4294967296:18446744073709551616);return valid?{Some:t==='u64'?BigInt(x):x===0?0:x}:{None:null};}
function __ink_count(x,n,width){if(width===64){x=BigInt.asUintN(64,x);if(n==='popcount'){let count=0;while(x){x&=x-1n;count++;}return count;}if(x===0n)return 64;if(n==='leading_zeros')return 64-x.toString(2).length;let count=0;while((x&1n)===0n){x>>=1n;count++;}return count;}x>>>=0;if(n==='leading_zeros')return Math.clz32(x);if(n==='trailing_zeros')return x===0?32:31-Math.clz32((x&-x)>>>0);x=x-((x>>>1)&0x55555555);x=(x&0x33333333)+((x>>>2)&0x33333333);return Math.imul((x+(x>>>4))&0x0f0f0f0f,0x01010101)>>>24;}
const __ink_encoder=new TextEncoder(),__ink_decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const __ink_bytes=s=>__ink_encoder.encode(s);
// Count UTF-8 bytes directly; valid Ink strings contain Unicode scalar values.
// Preserve TextEncoder's replacement width for a lone surrogate at trusted hosts.
function __ink_byte_len(s,start=0,end=s.length){let n=0;for(let i=start;i<end;i++){const c=s.charCodeAt(i);if(c<128)n++;else if(c<2048)n+=2;else if(c>=0xd800&&c<=0xdbff&&i+1<end&&s.charCodeAt(i+1)>=0xdc00&&s.charCodeAt(i+1)<=0xdfff){n+=4;i++;}else n+=3;}return n;}
const __ink_boundary=(b,i)=>i<=b.length&&(i===b.length||(b[i]&0xc0)!==0x80);
function __ink_byte_at(s,i){const b=__ink_bytes(s);return i<b.length?{Some:b[i]}:{None:null};}
function __ink_slice(s,a,z){const b=__ink_bytes(s);return a<=z&&__ink_boundary(b,a)&&__ink_boundary(b,z)?{Some:__ink_decoder.decode(b.subarray(a,z))}:{None:null};}
function __ink_concat(a,b){const s=a+b;if(__ink_byte_len(s)>4294967295)throw Error('String exceeds U32 byte length');return s;}
function __ink_find(s,needle,from){let unit=0,bytes=0;while(bytes<from&&unit<s.length){const c=s.charCodeAt(unit++);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff&&unit<s.length&&s.charCodeAt(unit)>=0xdc00&&s.charCodeAt(unit)<=0xdfff){bytes+=4;unit++;}else bytes+=3;}if(bytes!==from)return {None:null};const at=s.indexOf(needle,unit);return at<0?{None:null}:{Some:bytes+__ink_byte_len(s,unit,at)};}

function __ink_int_from_float(x){return Number.isFinite(x)?{Some:BigInt(Math.trunc(x))}:{None:null};}
// Affine buffers expose bounded disjoint ranges over one allocation. Source
// ownership prevents retaining a parent; growth detaches shared ranges.
// Elements cannot own temporary storage: they are immutable logical values.
// Copy the slot array when acquiring ownership, never the reachable records.
class __InkBuffer {
 constructor(data,start=0,end=data.length,shared=false){this.data=data;this.start=start;this.end=end;this.shared=shared;}
 get length(){return this.end-this.start;}
 set length(n){this.end=this.start+Math.min(this.length,n);if(!this.shared&&this.start===0)this.data.length=this.end;}
 item(i){return this.data[this.start+i];}
 range(start,count){const begin=this.start+Math.min(start,this.length);return new __InkBuffer(this.data,begin,begin+Math.min(count,this.end-begin),true);}
 set(i,v){if(i<this.length)this.data[this.start+i]=v;return this;}
 swap(a,b){if(a<this.length&&b<this.length){const x=this.item(a);this.set(a,this.item(b));this.set(b,x);}return this;}
 fill_range(start,count,value){start=Math.min(start,this.length);count=Math.min(count,this.length-start);this.data.fill(value,this.start+start,this.start+start+count);return this;}
 copy_within(source,destination,count){source=Math.min(source,this.length);destination=Math.min(destination,this.length);count=Math.min(count,this.length-source,this.length-destination);this.data.copyWithin(this.start+destination,this.start+source,this.start+source+count);return this;}
 detach(){if(this.shared||this.start!==0||this.end!==this.data.length){this.data=this.data.slice(this.start,this.end);this.start=0;this.end=this.data.length;this.shared=false;}}
 push(v){if(this.length>=4294967295)throw Error('buffer length exhausted');this.detach();this.data.push(v);this.end++;return this;}
 pop(){this.length=Math.max(0,this.length-1);return this;}
 truncate(n){this.length=Math.min(this.length,n);return this;}
 slice(start=0,end=this.length){return this.data.slice(this.start+start,this.start+Math.min(end,this.length));}
 freeze(){return this.start===0&&this.end===this.data.length?this.data:this.data.slice(this.start,this.end);}
 *[Symbol.iterator](){for(let i=this.start;i<this.end;i++)yield this.data[i];}
}
function __bufferSplit(x,at){const cut=x.start+Math.min(at,x.length);x.shared=true;return [new __InkBuffer(x.data,x.start,cut,true),new __InkBuffer(x.data,cut,x.end,true)];}
function __bufferAppend(a,b){
 if(a.length+b.length>4294967295)throw Error('buffer length exhausted');
 if(a.data===b.data&&a.end===b.start)return new __InkBuffer(a.data,a.start,b.end,a.start!==0||b.end!==a.data.length);
 a.detach();for(const item of b)a.push(item);return a;
}

function __repeat_until(limit,acc,stop,step){for(let i=0;i<limit;i++){if(stop(acc))break;acc=step(i,acc);}return acc;}
function __bufferFill(n,v){return new __InkBuffer(new Array(n).fill(v));}
function __mapGet(m,k,f){return m.has(k)?m.get(k):f();}
function __mapEntries(m,keys){return [...m.entries()].sort(([a],[b])=>a<b?-1:a>b?1:0).map(([k,v])=>keys?k:v);}
function __tempSet(x,k,v,map){x.set(k,v);return x;}
function __bufferSwap(x,a,b){return x.swap(a,b);}
function __tempEdit(x,op,...args){if(op==='push'){x.push(args[0]);}else if(op==='pop')x.pop();else if(op==='truncate')x.truncate(args[0]);else if(op==='remove')x.delete(args[0]);return x;}
// Fixed word semantics, including arithmetic signed right shift. Shift and
// rotation counts wrap modulo width; no source-pattern optimisation lives here.
function __word(op,a,b,bits) {
  const width=BigInt(Math.abs(bits)), k=BigInt(b??0)%width;
  const x=BigInt(a), y=BigInt(b??0), unsigned=BigInt.asUintN(Number(width),x);
  let r;
  switch(op) {
    case 'word_widen_u32_to_u64':case 'word_narrow_u64_to_u32':r=x;break;
    case 'word_not':r=~x;break;
    case 'word_and':r=x&y;break;
    case 'word_or':r=x|y;break;
    case 'word_xor':r=x^y;break;
    case 'wrapping_shl':r=x<<k;break;
    case 'wrapping_shr':r=x>>k;break;
    case 'rotate_left':r=(unsigned<<k)|(unsigned>>(width-k));break;
    case 'rotate_right':r=(unsigned>>k)|(unsigned<<(width-k));break;
    default:throw new Error('unknown word operation');
  }
  r=bits<0?BigInt.asIntN(Number(width),r):BigInt.asUintN(Number(width),r);
  return bits===64?r:Number(r);
}
// Rotations evaluate each operand once. Counts wrap modulo the width.
function __rotl32(a,k){k&=31;return (a<<k)|(a>>>((32-k)&31));}
function __rotr32(a,k){k&=31;return (a>>>k)|(a<<((32-k)&31));}
function __rotl64(a,k){const n=BigInt(k&63);return BigInt.asUintN(64,(a<<n)|(a>>((64n-n)&63n)));}
function __rotr64(a,k){const n=BigInt(k&63);return BigInt.asUintN(64,(a>>n)|(a<<((64n-n)&63n)));}
function __fn0(){
let v0=new __InkBuffer([]);
for(let v1=0;v1<64;v1++){
const v2=(v1>>>0);
const v3=v0;
const v4=0;
v0=__tempEdit(v3,"push",v4);}
const v5=v0;
return v5.freeze();}
function __fn1(v6,v7){
const v8=v7["features"];
const v9=Math.min(v6.length,v8.length);
const v10=new Array(v9);
for(let v11=0;v11<v9;v11++){
const v12=v6[v11];
const v13=v8[v11];
v10[v11]=__bits(__float(v12) * __float(v13));
}
let v14=0;for(let v15=0;v15<v10.length;v15++){
const v16=v10[v15];
v14=__bits(__float(v14) + __float(v16));}
return v14;}
function __fn2(v17,v18){
const v19=__fn1(v17,v18);
const v20=v18["target"];
const v21=Math.fround(__float(v19) - __float(v20));
return __bits(v21 * v21);}
function __fn3(v22,v23,v24){
const v25=true;
return __fn21(v22,v24,v25,v23);}
function __fn4(v26,v27,v28){
const v29=true;
const v30=__fn22(v26,v28,v29,v27);
let v31;if(Object.hasOwn(v30,"Ok")){
const v32=v30["Ok"];
v31=({Ok:v32["value"]});}else{v31=({Err:v30.Err});}
return v31;}
function __fn5(v33){
let v34=true;
for(let v35=0;v35<v33.length;v35++){
const v36=v33[v35];
const v37=v34;
let v38=v37;if(v38){
v38=Number.isFinite(__float(v36));}
const v39=v38;
let v40=v39;if(v40){
const v41=1098907648;
const v42=((v41 ^ 2147483648) >>> 0);
v40=((__float(v36)) >= (__float(v42)));}
const v43=v40;
let v44=v43;if(v44){
const v45=1098907648;
v44=((__float(v36)) <= (__float(v45)));}
v34=v44;
}
return v34;}
function __fn6(v46,v47,v48){
const v49=v46.length;
const v50=new Array(v49);
for(let v51=0;v51<v49;v51++){
const v52=v46[v51];
const v53=(v51>>>0);
let v54;if(v53<v47.length){v54=v47[v53];}else{
v54=0;}
const v55=v54;
const v56=Math.fround(__float(v48) * __float(v55));
v50[v51]=__bits(__float(v52) - v56);
}
return v50;}
function __fn7(v57){
const v58=(v57["features"]).length;
const v59=64;
const v60=(v58===v59);
let v61=v60;if(v61){
v61=Number.isFinite(__float(v57["target"]));}
return v61;}
function __fn8(v62){
const v63=1;
const v64=new __InkBuffer(Array.from([v63]));
let v65;if(Object.hasOwn(v62,"Some")){
const v66=v62["Some"];
v65=__tempEdit(v64,"push",v66);}else{
const v67=null;
const v68=9;
v65=__tempEdit(v64,"push",v68);}
const v69=v65;
return v69.freeze();}
function __fn9(v70){
const v71=v70.length;
const v72=new Array(v71);
for(let v73=0;v73<v71;v73++){
const v74=v70[v73];
const v75=1073741824;
const v76=Math.fround(__float(v74) * __float(v75));
const v77=1065353216;
v72[v73]=__bits(v76 + __float(v77));
}
return v72;}
function __fn10(v78){
const v79=4294967295;
return ({["value"]:v78,["id"]:v79});}
function __fn11(v80,v81,v82){
const v83=false;
const v84=(v82===v83);
let v85=v84;if(!v85){
v85=v80["failed"];}
let v86;if(v85){
const v87=v81["value"];
const v88=__fn10(v87);
v86=({["value"]:v88,["tape"]:v80});}else{
const v89=v80["nodes"];
const v90=(v89).length;
const v91=v80["maximum"];
let v92;if(((v90) >= (v91))){
const v93=v81["value"];
const v94=__fn10(v93);
const v95=true;
const v96=v80["nodes"];
const v97=v80["maximum"];
const v98=({["nodes"]:v96,["maximum"]:v97,["failed"]:v95});
v92=({["value"]:v94,["tape"]:v98});}else{
const v99=v81["value"];
const v100=({["value"]:v99,["id"]:v90});
const v101=v80["nodes"];
const v102=__tempEdit(v101,"push",v81);
const v103=v80["maximum"];
const v104=v80["failed"];
const v105=({["nodes"]:v102,["maximum"]:v103,["failed"]:v104});
v92=({["value"]:v100,["tape"]:v105});}
v86=v92;}
return v86;}
function __fn12(v106,v107){
const v108=0;
const v109=4294967295;
const v110=4294967295;
const v111=0;
const v112=0;
const v114=true;
const v115=false;
const v116=(v114===v115);
let v117=v116;if(!v117){
v117=v107["failed"];}
let v118;
let v119;
if(v117){
const v120=__fn10(v106);
v118=v120;
v119=v107;
}else{
const v121=v107["nodes"];
const v122=(v121).length;
const v123=v107["maximum"];
let v124;
let v125;
if(((v122) >= (v123))){
const v126=__fn10(v106);
const v127=true;
const v128=v107["nodes"];
const v129=v107["maximum"];
const v130=({["nodes"]:v128,["maximum"]:v129,["failed"]:v127});
v124=v126;
v125=v130;
}else{
const v131=({["value"]:v106,["id"]:v122});
const v132=v107["nodes"];
const v133=({["op"]:v108,["a"]:v109,["b"]:v110,["av"]:v111,["bv"]:v112,["value"]:v106});
const v134=__tempEdit(v132,"push",v133);
const v135=v107["maximum"];
const v136=v107["failed"];
const v137=({["nodes"]:v134,["maximum"]:v135,["failed"]:v136});
v124=v131;
v125=v137;
}
v118=v124;
v119=v125;
}
return ({["value"]:v118,["tape"]:v119});}
function __fn13(v138,v139,v140,v141){
const v142=1;
let v143;if((v138===v142)){
const v144=v140["value"];
const v145=v141["value"];
v143=__bits(__float(v144) + __float(v145));}else{
const v146=2;
let v147;if((v138===v146)){
const v148=v140["value"];
const v149=v141["value"];
v147=__bits(__float(v148) - __float(v149));}else{
const v150=3;
let v151;if((v138===v150)){
const v152=v140["value"];
const v153=v141["value"];
v151=__bits(__float(v152) * __float(v153));}else{
v151=__bits((__float(v140["value"]))/(__float(v141["value"])));}
v147=v151;}
v143=v147;}
const v154=v143;
const v155=v140["id"];
const v156=v141["id"];
const v157=v140["value"];
const v158=v141["value"];
const v160=v140["id"];
const v161=4294967295;
const v162=!(v160===v161);
let v163=v162;if(!v163){
const v164=v141["id"];
const v165=4294967295;
v163=!(v164===v165);}
const v166=v163;
const v167=false;
const v168=(v166===v167);
let v169=v168;if(!v169){
v169=v139["failed"];}
let v170;
let v171;
if(v169){
const v172=__fn10(v154);
v170=v172;
v171=v139;
}else{
const v173=v139["nodes"];
const v174=(v173).length;
const v175=v139["maximum"];
let v176;
let v177;
if(((v174) >= (v175))){
const v178=__fn10(v154);
const v179=true;
const v180=v139["nodes"];
const v181=v139["maximum"];
const v182=({["nodes"]:v180,["maximum"]:v181,["failed"]:v179});
v176=v178;
v177=v182;
}else{
const v183=({["value"]:v154,["id"]:v174});
const v184=v139["nodes"];
const v185=({["op"]:v138,["a"]:v155,["b"]:v156,["av"]:v157,["bv"]:v158,["value"]:v154});
const v186=__tempEdit(v184,"push",v185);
const v187=v139["maximum"];
const v188=v139["failed"];
const v189=({["nodes"]:v186,["maximum"]:v187,["failed"]:v188});
v176=v183;
v177=v189;
}
v170=v176;
v171=v177;
}
return ({["value"]:v170,["tape"]:v171});}
function __fn14(v190,v191,v192){
const v193=5;
let v194;if((v190===v193)){
const v195=v192["value"];
v194=((v195 ^ 2147483648) >>> 0);}else{
v194=__bits(Math.sqrt(__float(v192["value"])));}
const v196=v194;
const v197=v192["id"];
const v198=4294967295;
const v199=v192["value"];
const v200=0;
const v202=v192["id"];
const v203=4294967295;
const v204=!(v202===v203);
const v205=false;
const v206=(v204===v205);
let v207=v206;if(!v207){
v207=v191["failed"];}
let v208;
let v209;
if(v207){
const v210=__fn10(v196);
v208=v210;
v209=v191;
}else{
const v211=v191["nodes"];
const v212=(v211).length;
const v213=v191["maximum"];
let v214;
let v215;
if(((v212) >= (v213))){
const v216=__fn10(v196);
const v217=true;
const v218=v191["nodes"];
const v219=v191["maximum"];
const v220=({["nodes"]:v218,["maximum"]:v219,["failed"]:v217});
v214=v216;
v215=v220;
}else{
const v221=({["value"]:v196,["id"]:v212});
const v222=v191["nodes"];
const v223=({["op"]:v190,["a"]:v197,["b"]:v198,["av"]:v199,["bv"]:v200,["value"]:v196});
const v224=__tempEdit(v222,"push",v223);
const v225=v191["maximum"];
const v226=v191["failed"];
const v227=({["nodes"]:v224,["maximum"]:v225,["failed"]:v226});
v214=v221;
v215=v227;
}
v208=v214;
v209=v215;
}
return ({["value"]:v208,["tape"]:v209});}
function __fn15(v228,v229,v230){
const v231=4294967295;
let v232;if((v229===v231)){
v232=v228;}else{
let v233;if(v229<v228.length){v233=v228.item(v229);}else{
v233=0;}
const v234=v233;
v232=__tempSet(v228,v229,__bits(__float(v234) + __float(v230)),false);}
return v232;}
function __fn16(v235,v236,v237){
const v238=v235["op"];
const v239=1;
let v240;if((v238===v239)){
const v241=v235["a"];
const v242=4294967295;
let v243;if((v241===v242)){
v243=v237;}else{
let v244;if(v241<v237.length){v244=v237.item(v241);}else{
v244=0;}
const v245=v244;
v243=__tempSet(v237,v241,__bits(__float(v245) + __float(v236)),false);}
const v246=v243;
const v247=v235["b"];
const v248=4294967295;
let v249;if((v247===v248)){
v249=v246;}else{
let v250;if(v247<v246.length){v250=v246.item(v247);}else{
v250=0;}
const v251=v250;
v249=__tempSet(v246,v247,__bits(__float(v251) + __float(v236)),false);}
v240=v249;}else{
const v252=v235["op"];
const v253=2;
let v254;if((v252===v253)){
const v255=v235["a"];
const v256=4294967295;
let v257;if((v255===v256)){
v257=v237;}else{
let v258;if(v255<v237.length){v258=v237.item(v255);}else{
v258=0;}
const v259=v258;
v257=__tempSet(v237,v255,__bits(__float(v259) + __float(v236)),false);}
const v260=v257;
const v261=v235["b"];
const v262=((v236 ^ 2147483648) >>> 0);
const v263=4294967295;
let v264;if((v261===v263)){
v264=v260;}else{
let v265;if(v261<v260.length){v265=v260.item(v261);}else{
v265=0;}
const v266=v265;
v264=__tempSet(v260,v261,__bits(__float(v266) + __float(v262)),false);}
v254=v264;}else{
const v267=v235["op"];
const v268=3;
let v269;if((v267===v268)){
const v270=v235["a"];
const v271=v235["bv"];
const v272=__bits(__float(v236) * __float(v271));
const v273=4294967295;
let v274;if((v270===v273)){
v274=v237;}else{
let v275;if(v270<v237.length){v275=v237.item(v270);}else{
v275=0;}
const v276=v275;
v274=__tempSet(v237,v270,__bits(__float(v276) + __float(v272)),false);}
const v277=v274;
const v278=v235["b"];
const v279=v235["av"];
const v280=__bits(__float(v236) * __float(v279));
const v281=4294967295;
let v282;if((v278===v281)){
v282=v277;}else{
let v283;if(v278<v277.length){v283=v277.item(v278);}else{
v283=0;}
const v284=v283;
v282=__tempSet(v277,v278,__bits(__float(v284) + __float(v280)),false);}
v269=v282;}else{
const v285=v235["op"];
const v286=4;
let v287;if((v285===v286)){
const v288=v235["a"];
const v289=__bits((__float(v236))/(__float(v235["bv"])));
const v290=4294967295;
let v291;if((v288===v290)){
v291=v237;}else{
let v292;if(v288<v237.length){v292=v237.item(v288);}else{
v292=0;}
const v293=v292;
v291=__tempSet(v237,v288,__bits(__float(v293) + __float(v289)),false);}
const v294=v291;
const v295=v235["b"];
const v296=v235["av"];
const v297=v235["bv"];
const v298=v235["bv"];
const v299=__bits((__float(__bits(__float(v236) * __float(v296))))/(__float(__bits(__float(v297) * __float(v298)))));
const v300=((v299 ^ 2147483648) >>> 0);
const v301=4294967295;
let v302;if((v295===v301)){
v302=v294;}else{
let v303;if(v295<v294.length){v303=v294.item(v295);}else{
v303=0;}
const v304=v303;
v302=__tempSet(v294,v295,__bits(__float(v304) + __float(v300)),false);}
v287=v302;}else{
const v305=v235["op"];
const v306=5;
let v307;if((v305===v306)){
const v308=v235["a"];
const v309=((v236 ^ 2147483648) >>> 0);
const v310=4294967295;
let v311;if((v308===v310)){
v311=v237;}else{
let v312;if(v308<v237.length){v312=v237.item(v308);}else{
v312=0;}
const v313=v312;
v311=__tempSet(v237,v308,__bits(__float(v313) + __float(v309)),false);}
v307=v311;}else{
const v314=v235["op"];
const v315=6;
let v316;if((v314===v315)){
const v317=v235["a"];
const v318=1073741824;
const v319=v235["value"];
const v320=__bits((__float(v236))/(__float(__bits(__float(v318) * __float(v319)))));
const v321=4294967295;
let v322;if((v317===v321)){
v322=v237;}else{
let v323;if(v317<v237.length){v323=v237.item(v317);}else{
v323=0;}
const v324=v323;
v322=__tempSet(v237,v317,__bits(__float(v324) + __float(v320)),false);}
v316=v322;}else{
v316=v237;}
v307=v316;}
v287=v307;}
v269=v287;}
v254=v269;}
v240=v254;}
return v240;}
function __fn17(v325,v326,v327){
const v328=v326["index"];
const v329=1;
const v330=(((v328) - (v329)) >>> 0);
const v331=v326["gradient"];
let v332;if(v330<v331.length){v332=v331.item(v330);}else{
v332=0;}
const v333=v332;
let v334=v327;if(v334){
const v335=0;
v334=((__float(v333)) === (__float(v335)));}
let v336;if(v334){
v336=v326["gradient"];}else{
const v337=v326["gradient"];
const v338=v325["op"];
const v339=1;
let v340;if((v338===v339)){
const v341=v325["a"];
const v342=4294967295;
let v343;if((v341===v342)){
v343=v337;}else{
let v344;if(v341<v337.length){v344=v337.item(v341);}else{
v344=0;}
const v345=v344;
v343=__tempSet(v337,v341,__bits(__float(v345) + __float(v333)),false);}
const v346=v343;
const v347=v325["b"];
const v348=4294967295;
let v349;if((v347===v348)){
v349=v346;}else{
let v350;if(v347<v346.length){v350=v346.item(v347);}else{
v350=0;}
const v351=v350;
v349=__tempSet(v346,v347,__bits(__float(v351) + __float(v333)),false);}
v340=v349;}else{
const v352=v325["op"];
const v353=2;
let v354;if((v352===v353)){
const v355=v325["a"];
const v356=4294967295;
let v357;if((v355===v356)){
v357=v337;}else{
let v358;if(v355<v337.length){v358=v337.item(v355);}else{
v358=0;}
const v359=v358;
v357=__tempSet(v337,v355,__bits(__float(v359) + __float(v333)),false);}
const v360=v357;
const v361=v325["b"];
const v362=((v333 ^ 2147483648) >>> 0);
const v363=4294967295;
let v364;if((v361===v363)){
v364=v360;}else{
let v365;if(v361<v360.length){v365=v360.item(v361);}else{
v365=0;}
const v366=v365;
v364=__tempSet(v360,v361,__bits(__float(v366) + __float(v362)),false);}
v354=v364;}else{
const v367=v325["op"];
const v368=3;
let v369;if((v367===v368)){
const v370=v325["a"];
const v371=v325["bv"];
const v372=__bits(__float(v333) * __float(v371));
const v373=4294967295;
let v374;if((v370===v373)){
v374=v337;}else{
let v375;if(v370<v337.length){v375=v337.item(v370);}else{
v375=0;}
const v376=v375;
v374=__tempSet(v337,v370,__bits(__float(v376) + __float(v372)),false);}
const v377=v374;
const v378=v325["b"];
const v379=v325["av"];
const v380=__bits(__float(v333) * __float(v379));
const v381=4294967295;
let v382;if((v378===v381)){
v382=v377;}else{
let v383;if(v378<v377.length){v383=v377.item(v378);}else{
v383=0;}
const v384=v383;
v382=__tempSet(v377,v378,__bits(__float(v384) + __float(v380)),false);}
v369=v382;}else{
const v385=v325["op"];
const v386=4;
let v387;if((v385===v386)){
const v388=v325["a"];
const v389=__bits((__float(v333))/(__float(v325["bv"])));
const v390=4294967295;
let v391;if((v388===v390)){
v391=v337;}else{
let v392;if(v388<v337.length){v392=v337.item(v388);}else{
v392=0;}
const v393=v392;
v391=__tempSet(v337,v388,__bits(__float(v393) + __float(v389)),false);}
const v394=v391;
const v395=v325["b"];
const v396=v325["av"];
const v397=v325["bv"];
const v398=v325["bv"];
const v399=__bits((__float(__bits(__float(v333) * __float(v396))))/(__float(__bits(__float(v397) * __float(v398)))));
const v400=((v399 ^ 2147483648) >>> 0);
const v401=4294967295;
let v402;if((v395===v401)){
v402=v394;}else{
let v403;if(v395<v394.length){v403=v394.item(v395);}else{
v403=0;}
const v404=v403;
v402=__tempSet(v394,v395,__bits(__float(v404) + __float(v400)),false);}
v387=v402;}else{
const v405=v325["op"];
const v406=5;
let v407;if((v405===v406)){
const v408=v325["a"];
const v409=((v333 ^ 2147483648) >>> 0);
const v410=4294967295;
let v411;if((v408===v410)){
v411=v337;}else{
let v412;if(v408<v337.length){v412=v337.item(v408);}else{
v412=0;}
const v413=v412;
v411=__tempSet(v337,v408,__bits(__float(v413) + __float(v409)),false);}
v407=v411;}else{
const v414=v325["op"];
const v415=6;
let v416;if((v414===v415)){
const v417=v325["a"];
const v418=1073741824;
const v419=v325["value"];
const v420=__bits((__float(v333))/(__float(__bits(__float(v418) * __float(v419)))));
const v421=4294967295;
let v422;if((v417===v421)){
v422=v337;}else{
let v423;if(v417<v337.length){v423=v337.item(v417);}else{
v423=0;}
const v424=v423;
v422=__tempSet(v337,v417,__bits(__float(v424) + __float(v420)),false);}
v416=v422;}else{
v416=v337;}
v407=v416;}
v387=v407;}
v369=v387;}
v354=v369;}
v340=v354;}
v336=v340;}
const v425=v336;
return ({["index"]:v330,["gradient"]:v425});}
function __fn18(v426,v427,v428){
let v429=new __InkBuffer([]);
for(let v430=0;v430<v426.length;v430++){
const v431=v426[v430];
const v432=v429;
const v433=0;
v429=__tempEdit(v432,"push",v433);
}
const v434=v429;
const v435=v427["id"];
const v436=1065353216;
const v437=4294967295;
let v438;if((v435===v437)){
v438=v434;}else{
let v439;if(v435<v434.length){v439=v434.item(v435);}else{
v439=0;}
const v440=v439;
v438=__tempSet(v434,v435,__bits(__float(v440) + __float(v436)),false);}
const v441=v438;
const v442=(v426).length;
let v443=v441;
let v444=v442;
for(let v446=v426.length-1;v446>=0;v446--){
const v447=v426[v446];
const v449=v444;
const v450=1;
const v451=(((v449) - (v450)) >>> 0);
const v452=v443;
let v453;if(v451<v452.length){v453=v452.item(v451);}else{
v453=0;}
const v454=v453;
let v455=v428;if(v455){
const v456=0;
v455=((__float(v454)) === (__float(v456)));}
let v457;if(v455){
v457=v443;}else{
const v458=v443;
const v459=v447["op"];
const v460=1;
let v461;if((v459===v460)){
const v462=v447["a"];
const v463=4294967295;
let v464;if((v462===v463)){
v464=v458;}else{
let v465;if(v462<v458.length){v465=v458.item(v462);}else{
v465=0;}
const v466=v465;
v464=__tempSet(v458,v462,__bits(__float(v466) + __float(v454)),false);}
const v467=v464;
const v468=v447["b"];
const v469=4294967295;
let v470;if((v468===v469)){
v470=v467;}else{
let v471;if(v468<v467.length){v471=v467.item(v468);}else{
v471=0;}
const v472=v471;
v470=__tempSet(v467,v468,__bits(__float(v472) + __float(v454)),false);}
v461=v470;}else{
const v473=v447["op"];
const v474=2;
let v475;if((v473===v474)){
const v476=v447["a"];
const v477=4294967295;
let v478;if((v476===v477)){
v478=v458;}else{
let v479;if(v476<v458.length){v479=v458.item(v476);}else{
v479=0;}
const v480=v479;
v478=__tempSet(v458,v476,__bits(__float(v480) + __float(v454)),false);}
const v481=v478;
const v482=v447["b"];
const v483=((v454 ^ 2147483648) >>> 0);
const v484=4294967295;
let v485;if((v482===v484)){
v485=v481;}else{
let v486;if(v482<v481.length){v486=v481.item(v482);}else{
v486=0;}
const v487=v486;
v485=__tempSet(v481,v482,__bits(__float(v487) + __float(v483)),false);}
v475=v485;}else{
const v488=v447["op"];
const v489=3;
let v490;if((v488===v489)){
const v491=v447["a"];
const v492=v447["bv"];
const v493=__bits(__float(v454) * __float(v492));
const v494=4294967295;
let v495;if((v491===v494)){
v495=v458;}else{
let v496;if(v491<v458.length){v496=v458.item(v491);}else{
v496=0;}
const v497=v496;
v495=__tempSet(v458,v491,__bits(__float(v497) + __float(v493)),false);}
const v498=v495;
const v499=v447["b"];
const v500=v447["av"];
const v501=__bits(__float(v454) * __float(v500));
const v502=4294967295;
let v503;if((v499===v502)){
v503=v498;}else{
let v504;if(v499<v498.length){v504=v498.item(v499);}else{
v504=0;}
const v505=v504;
v503=__tempSet(v498,v499,__bits(__float(v505) + __float(v501)),false);}
v490=v503;}else{
const v506=v447["op"];
const v507=4;
let v508;if((v506===v507)){
const v509=v447["a"];
const v510=__bits((__float(v454))/(__float(v447["bv"])));
const v511=4294967295;
let v512;if((v509===v511)){
v512=v458;}else{
let v513;if(v509<v458.length){v513=v458.item(v509);}else{
v513=0;}
const v514=v513;
v512=__tempSet(v458,v509,__bits(__float(v514) + __float(v510)),false);}
const v515=v512;
const v516=v447["b"];
const v517=v447["av"];
const v518=v447["bv"];
const v519=v447["bv"];
const v520=__bits((__float(__bits(__float(v454) * __float(v517))))/(__float(__bits(__float(v518) * __float(v519)))));
const v521=((v520 ^ 2147483648) >>> 0);
const v522=4294967295;
let v523;if((v516===v522)){
v523=v515;}else{
let v524;if(v516<v515.length){v524=v515.item(v516);}else{
v524=0;}
const v525=v524;
v523=__tempSet(v515,v516,__bits(__float(v525) + __float(v521)),false);}
v508=v523;}else{
const v526=v447["op"];
const v527=5;
let v528;if((v526===v527)){
const v529=v447["a"];
const v530=((v454 ^ 2147483648) >>> 0);
const v531=4294967295;
let v532;if((v529===v531)){
v532=v458;}else{
let v533;if(v529<v458.length){v533=v458.item(v529);}else{
v533=0;}
const v534=v533;
v532=__tempSet(v458,v529,__bits(__float(v534) + __float(v530)),false);}
v528=v532;}else{
const v535=v447["op"];
const v536=6;
let v537;if((v535===v536)){
const v538=v447["a"];
const v539=1073741824;
const v540=v447["value"];
const v541=__bits((__float(v454))/(__float(__bits(__float(v539) * __float(v540)))));
const v542=4294967295;
let v543;if((v538===v542)){
v543=v458;}else{
let v544;if(v538<v458.length){v544=v458.item(v538);}else{
v544=0;}
const v545=v544;
v543=__tempSet(v458,v538,__bits(__float(v545) + __float(v541)),false);}
v537=v543;}else{
v537=v458;}
v528=v537;}
v508=v528;}
v490=v508;}
v475=v490;}
v461=v475;}
v457=v461;}
const v546=v457;
const v547=({["index"]:v451,["gradient"]:v546});
v443=v547["gradient"];
v444=v547["index"];
}
const v549=v443;
return v549.freeze();}
function __fn19(v550,v551,v552){
const v555=v551["features"];
const v557=Math.min(v550.length,v555.length);
const v558=new Array(v557);
for(let v559=0;v559<v557;v559++){
const v560=v550[v559];
const v561=v555[v559];
v558[v559]=({["left"]:v560,["right"]:v561});
}
const v562=new __InkBuffer([]);
const v563=0;
let v564=v562;
let v565=v552;
let v566=v563;
for(let v568=0;v568<v558.length;v568++){
const v569=v558[v568];
const v570=v569["left"];
const v571=v569["right"];
const v572=v565;
const v575=3;
const v576=1;
let v577;if((v575===v576)){
const v578=v570["value"];
const v579=v571["value"];
v577=__bits(__float(v578) + __float(v579));}else{
const v580=2;
let v581;if((v575===v580)){
const v582=v570["value"];
const v583=v571["value"];
v581=__bits(__float(v582) - __float(v583));}else{
const v584=3;
let v585;if((v575===v584)){
const v586=v570["value"];
const v587=v571["value"];
v585=__bits(__float(v586) * __float(v587));}else{
v585=__bits((__float(v570["value"]))/(__float(v571["value"])));}
v581=v585;}
v577=v581;}
const v588=v577;
const v589=v570["id"];
const v590=v571["id"];
const v591=v570["value"];
const v592=v571["value"];
const v594=v570["id"];
const v595=4294967295;
const v596=!(v594===v595);
let v597=v596;if(!v597){
const v598=v571["id"];
const v599=4294967295;
v597=!(v598===v599);}
const v600=v597;
const v601=false;
const v602=(v600===v601);
let v603=v602;if(!v603){
v603=v572["failed"];}
let v604;
let v605;
if(v603){
const v606=__fn10(v588);
v604=v606;
v605=v572;
}else{
const v607=v572["nodes"];
const v608=(v607).length;
const v609=v572["maximum"];
let v610;
let v611;
if(((v608) >= (v609))){
const v612=__fn10(v588);
const v613=true;
const v614=v572["nodes"];
const v615=v572["maximum"];
const v616=({["nodes"]:v614,["maximum"]:v615,["failed"]:v613});
v610=v612;
v611=v616;
}else{
const v617=({["value"]:v588,["id"]:v608});
const v618=v572["nodes"];
const v619=({["op"]:v575,["a"]:v589,["b"]:v590,["av"]:v591,["bv"]:v592,["value"]:v588});
const v620=__tempEdit(v618,"push",v619);
const v621=v572["maximum"];
const v622=v572["failed"];
const v623=({["nodes"]:v620,["maximum"]:v621,["failed"]:v622});
v610=v617;
v611=v623;
}
v604=v610;
v605=v611;
}
const v625=v564;
const v626=v604;
const v627=__tempEdit(v625,"push",v626);
const v628=v605;
const v629=v566;
const v630=1;
const v631=(((v629) + (v630)) >>> 0);
v564=v627;
v565=v628;
v566=v631;
}
const v633=v564;
const v634=v633.freeze();
const v635=v565;
const v637=0;
const v638=__fn10(v637);
let v639=v638;
let v640=v635;
for(let v642=0;v642<v634.length;v642++){
const v643=v634[v642];
const v644=1;
const v645=v640;
const v646=v639;
const v647=1;
let v648;if((v644===v647)){
const v649=v646["value"];
const v650=v643["value"];
v648=__bits(__float(v649) + __float(v650));}else{
const v651=2;
let v652;if((v644===v651)){
const v653=v646["value"];
const v654=v643["value"];
v652=__bits(__float(v653) - __float(v654));}else{
const v655=3;
let v656;if((v644===v655)){
const v657=v646["value"];
const v658=v643["value"];
v656=__bits(__float(v657) * __float(v658));}else{
v656=__bits((__float(v646["value"]))/(__float(v643["value"])));}
v652=v656;}
v648=v652;}
const v659=v648;
const v660=v646["id"];
const v661=v643["id"];
const v662=v646["value"];
const v663=v643["value"];
const v665=v646["id"];
const v666=4294967295;
const v667=!(v665===v666);
let v668=v667;if(!v668){
const v669=v643["id"];
const v670=4294967295;
v668=!(v669===v670);}
const v671=v668;
const v672=false;
const v673=(v671===v672);
let v674=v673;if(!v674){
v674=v645["failed"];}
let v675;
let v676;
if(v674){
const v677=__fn10(v659);
v675=v677;
v676=v645;
}else{
const v678=v645["nodes"];
const v679=(v678).length;
const v680=v645["maximum"];
let v681;
let v682;
if(((v679) >= (v680))){
const v683=__fn10(v659);
const v684=true;
const v685=v645["nodes"];
const v686=v645["maximum"];
const v687=({["nodes"]:v685,["maximum"]:v686,["failed"]:v684});
v681=v683;
v682=v687;
}else{
const v688=({["value"]:v659,["id"]:v679});
const v689=v645["nodes"];
const v690=({["op"]:v644,["a"]:v660,["b"]:v661,["av"]:v662,["bv"]:v663,["value"]:v659});
const v691=__tempEdit(v689,"push",v690);
const v692=v645["maximum"];
const v693=v645["failed"];
const v694=({["nodes"]:v691,["maximum"]:v692,["failed"]:v693});
v681=v688;
v682=v694;
}
v675=v681;
v676=v682;
}
v639=v675;
v640=v676;
}
return ({["value"]:v639,["tape"]:v640});}
function __fn20(v695,v696,v697){
const v702=v696["features"];
const v704=Math.min(v695.length,v702.length);
const v705=new Array(v704);
for(let v706=0;v706<v704;v706++){
const v707=v695[v706];
const v708=v702[v706];
v705[v706]=({["left"]:v707,["right"]:v708});
}
const v709=new __InkBuffer([]);
const v710=0;
let v711=v709;
let v712=v697;
let v713=v710;
for(let v715=0;v715<v705.length;v715++){
const v716=v705[v715];
const v717=v716["left"];
const v718=v716["right"];
const v719=v712;
const v722=3;
const v723=1;
let v724;if((v722===v723)){
const v725=v717["value"];
const v726=v718["value"];
v724=__bits(__float(v725) + __float(v726));}else{
const v727=2;
let v728;if((v722===v727)){
const v729=v717["value"];
const v730=v718["value"];
v728=__bits(__float(v729) - __float(v730));}else{
const v731=3;
let v732;if((v722===v731)){
const v733=v717["value"];
const v734=v718["value"];
v732=__bits(__float(v733) * __float(v734));}else{
v732=__bits((__float(v717["value"]))/(__float(v718["value"])));}
v728=v732;}
v724=v728;}
const v735=v724;
const v736=v717["id"];
const v737=v718["id"];
const v738=v717["value"];
const v739=v718["value"];
const v741=v717["id"];
const v742=4294967295;
const v743=!(v741===v742);
let v744=v743;if(!v744){
const v745=v718["id"];
const v746=4294967295;
v744=!(v745===v746);}
const v747=v744;
const v748=false;
const v749=(v747===v748);
let v750=v749;if(!v750){
v750=v719["failed"];}
let v751;
let v752;
if(v750){
const v753=__fn10(v735);
v751=v753;
v752=v719;
}else{
const v754=v719["nodes"];
const v755=(v754).length;
const v756=v719["maximum"];
let v757;
let v758;
if(((v755) >= (v756))){
const v759=__fn10(v735);
const v760=true;
const v761=v719["nodes"];
const v762=v719["maximum"];
const v763=({["nodes"]:v761,["maximum"]:v762,["failed"]:v760});
v757=v759;
v758=v763;
}else{
const v764=({["value"]:v735,["id"]:v755});
const v765=v719["nodes"];
const v766=({["op"]:v722,["a"]:v736,["b"]:v737,["av"]:v738,["bv"]:v739,["value"]:v735});
const v767=__tempEdit(v765,"push",v766);
const v768=v719["maximum"];
const v769=v719["failed"];
const v770=({["nodes"]:v767,["maximum"]:v768,["failed"]:v769});
v757=v764;
v758=v770;
}
v751=v757;
v752=v758;
}
const v772=v711;
const v773=v751;
const v774=__tempEdit(v772,"push",v773);
const v775=v752;
const v776=v713;
const v777=1;
const v778=(((v776) + (v777)) >>> 0);
v711=v774;
v712=v775;
v713=v778;
}
const v780=v711;
const v781=v780.freeze();
const v782=v712;
const v784=0;
const v785=__fn10(v784);
let v786=v785;
let v787=v782;
for(let v789=0;v789<v781.length;v789++){
const v790=v781[v789];
const v791=1;
const v792=v787;
const v793=v786;
const v794=1;
let v795;if((v791===v794)){
const v796=v793["value"];
const v797=v790["value"];
v795=__bits(__float(v796) + __float(v797));}else{
const v798=2;
let v799;if((v791===v798)){
const v800=v793["value"];
const v801=v790["value"];
v799=__bits(__float(v800) - __float(v801));}else{
const v802=3;
let v803;if((v791===v802)){
const v804=v793["value"];
const v805=v790["value"];
v803=__bits(__float(v804) * __float(v805));}else{
v803=__bits((__float(v793["value"]))/(__float(v790["value"])));}
v799=v803;}
v795=v799;}
const v806=v795;
const v807=v793["id"];
const v808=v790["id"];
const v809=v793["value"];
const v810=v790["value"];
const v812=v793["id"];
const v813=4294967295;
const v814=!(v812===v813);
let v815=v814;if(!v815){
const v816=v790["id"];
const v817=4294967295;
v815=!(v816===v817);}
const v818=v815;
const v819=false;
const v820=(v818===v819);
let v821=v820;if(!v821){
v821=v792["failed"];}
let v822;
let v823;
if(v821){
const v824=__fn10(v806);
v822=v824;
v823=v792;
}else{
const v825=v792["nodes"];
const v826=(v825).length;
const v827=v792["maximum"];
let v828;
let v829;
if(((v826) >= (v827))){
const v830=__fn10(v806);
const v831=true;
const v832=v792["nodes"];
const v833=v792["maximum"];
const v834=({["nodes"]:v832,["maximum"]:v833,["failed"]:v831});
v828=v830;
v829=v834;
}else{
const v835=({["value"]:v806,["id"]:v826});
const v836=v792["nodes"];
const v837=({["op"]:v791,["a"]:v807,["b"]:v808,["av"]:v809,["bv"]:v810,["value"]:v806});
const v838=__tempEdit(v836,"push",v837);
const v839=v792["maximum"];
const v840=v792["failed"];
const v841=({["nodes"]:v838,["maximum"]:v839,["failed"]:v840});
v828=v835;
v829=v841;
}
v822=v828;
v823=v829;
}
v786=v822;
v787=v823;
}
const v843=v787;
const v845=v696["target"];
const v847=2;
const v848=v786;
const v849=1;
let v850;if((v847===v849)){
const v851=v848["value"];
const v852=v845["value"];
v850=__bits(__float(v851) + __float(v852));}else{
const v853=2;
let v854;if((v847===v853)){
const v855=v848["value"];
const v856=v845["value"];
v854=__bits(__float(v855) - __float(v856));}else{
const v857=3;
let v858;if((v847===v857)){
const v859=v848["value"];
const v860=v845["value"];
v858=__bits(__float(v859) * __float(v860));}else{
v858=__bits((__float(v848["value"]))/(__float(v845["value"])));}
v854=v858;}
v850=v854;}
const v861=v850;
const v862=v848["id"];
const v863=v845["id"];
const v864=v848["value"];
const v865=v845["value"];
const v867=v848["id"];
const v868=4294967295;
const v869=!(v867===v868);
let v870=v869;if(!v870){
const v871=v845["id"];
const v872=4294967295;
v870=!(v871===v872);}
const v873=v870;
const v874=false;
const v875=(v873===v874);
let v876=v875;if(!v876){
v876=v843["failed"];}
let v877;
let v878;
if(v876){
const v879=__fn10(v861);
v877=v879;
v878=v843;
}else{
const v880=v843["nodes"];
const v881=(v880).length;
const v882=v843["maximum"];
let v883;
let v884;
if(((v881) >= (v882))){
const v885=__fn10(v861);
const v886=true;
const v887=v843["nodes"];
const v888=v843["maximum"];
const v889=({["nodes"]:v887,["maximum"]:v888,["failed"]:v886});
v883=v885;
v884=v889;
}else{
const v890=({["value"]:v861,["id"]:v881});
const v891=v843["nodes"];
const v892=({["op"]:v847,["a"]:v862,["b"]:v863,["av"]:v864,["bv"]:v865,["value"]:v861});
const v893=__tempEdit(v891,"push",v892);
const v894=v843["maximum"];
const v895=v843["failed"];
const v896=({["nodes"]:v893,["maximum"]:v894,["failed"]:v895});
v883=v890;
v884=v896;
}
v877=v883;
v878=v884;
}
const v898=v877;
const v899=v878;
const v902=3;
const v903=1;
let v904;if((v902===v903)){
const v905=v898["value"];
const v906=v898["value"];
v904=__bits(__float(v905) + __float(v906));}else{
const v907=2;
let v908;if((v902===v907)){
const v909=v898["value"];
const v910=v898["value"];
v908=__bits(__float(v909) - __float(v910));}else{
const v911=3;
let v912;if((v902===v911)){
const v913=v898["value"];
const v914=v898["value"];
v912=__bits(__float(v913) * __float(v914));}else{
v912=__bits((__float(v898["value"]))/(__float(v898["value"])));}
v908=v912;}
v904=v908;}
const v915=v904;
const v916=v898["id"];
const v917=v898["id"];
const v918=v898["value"];
const v919=v898["value"];
const v921=v898["id"];
const v922=4294967295;
const v923=!(v921===v922);
let v924=v923;if(!v924){
const v925=v898["id"];
const v926=4294967295;
v924=!(v925===v926);}
const v927=v924;
const v928=false;
const v929=(v927===v928);
let v930=v929;if(!v930){
v930=v899["failed"];}
let v931;
let v932;
if(v930){
const v933=__fn10(v915);
v931=v933;
v932=v899;
}else{
const v934=v899["nodes"];
const v935=(v934).length;
const v936=v899["maximum"];
let v937;
let v938;
if(((v935) >= (v936))){
const v939=__fn10(v915);
const v940=true;
const v941=v899["nodes"];
const v942=v899["maximum"];
const v943=({["nodes"]:v941,["maximum"]:v942,["failed"]:v940});
v937=v939;
v938=v943;
}else{
const v944=({["value"]:v915,["id"]:v935});
const v945=v899["nodes"];
const v946=({["op"]:v902,["a"]:v916,["b"]:v917,["av"]:v918,["bv"]:v919,["value"]:v915});
const v947=__tempEdit(v945,"push",v946);
const v948=v899["maximum"];
const v949=v899["failed"];
const v950=({["nodes"]:v947,["maximum"]:v948,["failed"]:v949});
v937=v944;
v938=v950;
}
v931=v937;
v932=v938;
}
return ({["value"]:v931,["tape"]:v932});}
function __fn21(v951,v952,v953,v954){
const v955=1000000;
let v956;if(((v952) > (v955))){
v956=({Err:"reverse differentiation capacity exceeds one million nodes"});}else{
const v957=new __InkBuffer([]);
const v958=new __InkBuffer([]);
const v959=false;
const v960=({["nodes"]:v958,["maximum"]:v952,["failed"]:v959});
const v961=0;
let v962=v957;
let v963=v960;
let v964=v961;
for(let v966=0;v966<v951.length;v966++){
const v967=v951[v966];
const v968=v963;
const v969=0;
const v970=4294967295;
const v971=4294967295;
const v972=0;
const v973=0;
const v975=true;
const v976=false;
const v977=(v975===v976);
let v978=v977;if(!v978){
v978=v968["failed"];}
let v979;
let v980;
if(v978){
const v981=__fn10(v967);
v979=v981;
v980=v968;
}else{
const v982=v968["nodes"];
const v983=(v982).length;
const v984=v968["maximum"];
let v985;
let v986;
if(((v983) >= (v984))){
const v987=__fn10(v967);
const v988=true;
const v989=v968["nodes"];
const v990=v968["maximum"];
const v991=({["nodes"]:v989,["maximum"]:v990,["failed"]:v988});
v985=v987;
v986=v991;
}else{
const v992=({["value"]:v967,["id"]:v983});
const v993=v968["nodes"];
const v994=({["op"]:v969,["a"]:v970,["b"]:v971,["av"]:v972,["bv"]:v973,["value"]:v967});
const v995=__tempEdit(v993,"push",v994);
const v996=v968["maximum"];
const v997=v968["failed"];
const v998=({["nodes"]:v995,["maximum"]:v996,["failed"]:v997});
v985=v992;
v986=v998;
}
v979=v985;
v980=v986;
}
const v1000=v962;
const v1001=v979;
const v1002=__tempEdit(v1000,"push",v1001);
const v1003=v980;
const v1004=v964;
const v1005=1;
const v1006=(((v1004) + (v1005)) >>> 0);
v962=v1002;
v963=v1003;
v964=v1006;
}
const v1008=v962;
const v1009=v1008.freeze();
const v1010=v963;
const v1012=v954["features"];
const v1013=v1012.length;
const v1014=new Array(v1013);
for(let v1015=0;v1015<v1013;v1015++){
const v1016=v1012[v1015];
v1014[v1015]=__fn10(v1016);
}
const v1017=v954["target"];
const v1018=__fn10(v1017);
const v1021=({["features"]:v1014,["target"]:v1018});
const v1025=v1021["features"];
const v1027=Math.min(v1009.length,v1025.length);
const v1028=new Array(v1027);
for(let v1029=0;v1029<v1027;v1029++){
const v1030=v1009[v1029];
const v1031=v1025[v1029];
v1028[v1029]=({["left"]:v1030,["right"]:v1031});
}
const v1032=new __InkBuffer([]);
const v1033=0;
let v1034=v1032;
let v1035=v1010;
let v1036=v1033;
for(let v1038=0;v1038<v1028.length;v1038++){
const v1039=v1028[v1038];
const v1040=v1039["left"];
const v1041=v1039["right"];
const v1042=v1035;
const v1045=3;
const v1046=1;
let v1047;if((v1045===v1046)){
const v1048=v1040["value"];
const v1049=v1041["value"];
v1047=__bits(__float(v1048) + __float(v1049));}else{
const v1050=2;
let v1051;if((v1045===v1050)){
const v1052=v1040["value"];
const v1053=v1041["value"];
v1051=__bits(__float(v1052) - __float(v1053));}else{
const v1054=3;
let v1055;if((v1045===v1054)){
const v1056=v1040["value"];
const v1057=v1041["value"];
v1055=__bits(__float(v1056) * __float(v1057));}else{
v1055=__bits((__float(v1040["value"]))/(__float(v1041["value"])));}
v1051=v1055;}
v1047=v1051;}
const v1058=v1047;
const v1059=v1040["id"];
const v1060=v1041["id"];
const v1061=v1040["value"];
const v1062=v1041["value"];
const v1063=({["op"]:v1045,["a"]:v1059,["b"]:v1060,["av"]:v1061,["bv"]:v1062,["value"]:v1058});
const v1064=v1040["id"];
const v1065=4294967295;
const v1066=!(v1064===v1065);
let v1067=v1066;if(!v1067){
const v1068=v1041["id"];
const v1069=4294967295;
v1067=!(v1068===v1069);}
const v1070=v1067;
const v1071=__fn11(v1042,v1063,v1070);
const v1072=v1034;
const v1073=v1071["value"];
const v1074=__tempEdit(v1072,"push",v1073);
const v1075=v1071["tape"];
const v1076=v1036;
const v1077=1;
const v1078=(((v1076) + (v1077)) >>> 0);
v1034=v1074;
v1035=v1075;
v1036=v1078;
}
const v1080=v1034;
const v1081=v1080.freeze();
const v1082=v1035;
const v1084=0;
const v1085=__fn10(v1084);
let v1086=v1085;
let v1087=v1082;
for(let v1089=0;v1089<v1081.length;v1089++){
const v1090=v1081[v1089];
const v1091=1;
const v1092=v1087;
const v1093=v1086;
const v1094=1;
let v1095;if((v1091===v1094)){
const v1096=v1093["value"];
const v1097=v1090["value"];
v1095=__bits(__float(v1096) + __float(v1097));}else{
const v1098=2;
let v1099;if((v1091===v1098)){
const v1100=v1093["value"];
const v1101=v1090["value"];
v1099=__bits(__float(v1100) - __float(v1101));}else{
const v1102=3;
let v1103;if((v1091===v1102)){
const v1104=v1093["value"];
const v1105=v1090["value"];
v1103=__bits(__float(v1104) * __float(v1105));}else{
v1103=__bits((__float(v1093["value"]))/(__float(v1090["value"])));}
v1099=v1103;}
v1095=v1099;}
const v1106=v1095;
const v1107=v1093["id"];
const v1108=v1090["id"];
const v1109=v1093["value"];
const v1110=v1090["value"];
const v1112=v1093["id"];
const v1113=4294967295;
const v1114=!(v1112===v1113);
let v1115=v1114;if(!v1115){
const v1116=v1090["id"];
const v1117=4294967295;
v1115=!(v1116===v1117);}
const v1118=v1115;
const v1119=false;
const v1120=(v1118===v1119);
let v1121=v1120;if(!v1121){
v1121=v1092["failed"];}
let v1122;
let v1123;
if(v1121){
const v1124=__fn10(v1106);
v1122=v1124;
v1123=v1092;
}else{
const v1125=v1092["nodes"];
const v1126=(v1125).length;
const v1127=v1092["maximum"];
let v1128;
let v1129;
if(((v1126) >= (v1127))){
const v1130=__fn10(v1106);
const v1131=true;
const v1132=v1092["nodes"];
const v1133=v1092["maximum"];
const v1134=({["nodes"]:v1132,["maximum"]:v1133,["failed"]:v1131});
v1128=v1130;
v1129=v1134;
}else{
const v1135=({["value"]:v1106,["id"]:v1126});
const v1136=v1092["nodes"];
const v1137=({["op"]:v1091,["a"]:v1107,["b"]:v1108,["av"]:v1109,["bv"]:v1110,["value"]:v1106});
const v1138=__tempEdit(v1136,"push",v1137);
const v1139=v1092["maximum"];
const v1140=v1092["failed"];
const v1141=({["nodes"]:v1138,["maximum"]:v1139,["failed"]:v1140});
v1128=v1135;
v1129=v1141;
}
v1122=v1128;
v1123=v1129;
}
v1086=v1122;
v1087=v1123;
}
const v1143=({["features"]:v1014,["target"]:v1018});
const v1144=v1087;
const v1146=v1143["target"];
const v1148=2;
const v1149=v1086;
const v1150=1;
let v1151;if((v1148===v1150)){
const v1152=v1149["value"];
const v1153=v1146["value"];
v1151=__bits(__float(v1152) + __float(v1153));}else{
const v1154=2;
let v1155;if((v1148===v1154)){
const v1156=v1149["value"];
const v1157=v1146["value"];
v1155=__bits(__float(v1156) - __float(v1157));}else{
const v1158=3;
let v1159;if((v1148===v1158)){
const v1160=v1149["value"];
const v1161=v1146["value"];
v1159=__bits(__float(v1160) * __float(v1161));}else{
v1159=__bits((__float(v1149["value"]))/(__float(v1146["value"])));}
v1155=v1159;}
v1151=v1155;}
const v1162=v1151;
const v1163=v1149["id"];
const v1164=v1146["id"];
const v1165=v1149["value"];
const v1166=v1146["value"];
const v1168=v1149["id"];
const v1169=4294967295;
const v1170=!(v1168===v1169);
let v1171=v1170;if(!v1171){
const v1172=v1146["id"];
const v1173=4294967295;
v1171=!(v1172===v1173);}
const v1174=v1171;
const v1175=false;
const v1176=(v1174===v1175);
let v1177=v1176;if(!v1177){
v1177=v1144["failed"];}
let v1178;
let v1179;
if(v1177){
const v1180=__fn10(v1162);
v1178=v1180;
v1179=v1144;
}else{
const v1181=v1144["nodes"];
const v1182=(v1181).length;
const v1183=v1144["maximum"];
let v1184;
let v1185;
if(((v1182) >= (v1183))){
const v1186=__fn10(v1162);
const v1187=true;
const v1188=v1144["nodes"];
const v1189=v1144["maximum"];
const v1190=({["nodes"]:v1188,["maximum"]:v1189,["failed"]:v1187});
v1184=v1186;
v1185=v1190;
}else{
const v1191=({["value"]:v1162,["id"]:v1182});
const v1192=v1144["nodes"];
const v1193=({["op"]:v1148,["a"]:v1163,["b"]:v1164,["av"]:v1165,["bv"]:v1166,["value"]:v1162});
const v1194=__tempEdit(v1192,"push",v1193);
const v1195=v1144["maximum"];
const v1196=v1144["failed"];
const v1197=({["nodes"]:v1194,["maximum"]:v1195,["failed"]:v1196});
v1184=v1191;
v1185=v1197;
}
v1178=v1184;
v1179=v1185;
}
const v1199=v1178;
const v1200=v1179;
const v1203=3;
const v1204=1;
let v1205;if((v1203===v1204)){
const v1206=v1199["value"];
const v1207=v1199["value"];
v1205=__bits(__float(v1206) + __float(v1207));}else{
const v1208=2;
let v1209;if((v1203===v1208)){
const v1210=v1199["value"];
const v1211=v1199["value"];
v1209=__bits(__float(v1210) - __float(v1211));}else{
const v1212=3;
let v1213;if((v1203===v1212)){
const v1214=v1199["value"];
const v1215=v1199["value"];
v1213=__bits(__float(v1214) * __float(v1215));}else{
v1213=__bits((__float(v1199["value"]))/(__float(v1199["value"])));}
v1209=v1213;}
v1205=v1209;}
const v1216=v1205;
const v1217=v1199["id"];
const v1218=v1199["id"];
const v1219=v1199["value"];
const v1220=v1199["value"];
const v1222=v1199["id"];
const v1223=4294967295;
const v1224=!(v1222===v1223);
let v1225=v1224;if(!v1225){
const v1226=v1199["id"];
const v1227=4294967295;
v1225=!(v1226===v1227);}
const v1228=v1225;
const v1229=false;
const v1230=(v1228===v1229);
let v1231=v1230;if(!v1231){
v1231=v1200["failed"];}
let v1232;
let v1233;
if(v1231){
const v1234=__fn10(v1216);
v1232=v1234;
v1233=v1200;
}else{
const v1235=v1200["nodes"];
const v1236=(v1235).length;
const v1237=v1200["maximum"];
let v1238;
let v1239;
if(((v1236) >= (v1237))){
const v1240=__fn10(v1216);
const v1241=true;
const v1242=v1200["nodes"];
const v1243=v1200["maximum"];
const v1244=({["nodes"]:v1242,["maximum"]:v1243,["failed"]:v1241});
v1238=v1240;
v1239=v1244;
}else{
const v1245=({["value"]:v1216,["id"]:v1236});
const v1246=v1200["nodes"];
const v1247=({["op"]:v1203,["a"]:v1217,["b"]:v1218,["av"]:v1219,["bv"]:v1220,["value"]:v1216});
const v1248=__tempEdit(v1246,"push",v1247);
const v1249=v1200["maximum"];
const v1250=v1200["failed"];
const v1251=({["nodes"]:v1248,["maximum"]:v1249,["failed"]:v1250});
v1238=v1245;
v1239=v1251;
}
v1232=v1238;
v1233=v1239;
}
const v1253=v1233;
let v1254;if(v1253["failed"]){
v1254=({Err:"reverse differentiation tape capacity exceeded"});}else{
const v1255=v1233;
const v1256=v1255["nodes"];
const v1257=v1256.freeze();
const v1258=v1232;
const v1259=__fn18(v1257,v1258,v953);
const v1260=v1009.length;
const v1261=new Array(v1260);
for(let v1262=0;v1262<v1260;v1262++){
const v1263=v1009[v1262];
const v1264=v1263["id"];
let v1265;if(v1264<v1259.length){v1265=v1259[v1264];}else{
v1265=0;}
v1261[v1262]=v1265;
}
v1254=({Ok:v1261});}
v956=v1254;}
return v956;}
function __fn22(v1266,v1267,v1268,v1269){
const v1270=1000000;
let v1271;if(((v1267) > (v1270))){
v1271=({Err:"reverse differentiation capacity exceeds one million nodes"});}else{
const v1272=new __InkBuffer([]);
const v1273=new __InkBuffer([]);
const v1274=false;
const v1275=({["nodes"]:v1273,["maximum"]:v1267,["failed"]:v1274});
const v1276=0;
let v1277=v1272;
let v1278=v1275;
let v1279=v1276;
for(let v1281=0;v1281<v1266.length;v1281++){
const v1282=v1266[v1281];
const v1283=v1278;
const v1284=0;
const v1285=4294967295;
const v1286=4294967295;
const v1287=0;
const v1288=0;
const v1290=true;
const v1291=false;
const v1292=(v1290===v1291);
let v1293=v1292;if(!v1293){
v1293=v1283["failed"];}
let v1294;
let v1295;
if(v1293){
const v1296=__fn10(v1282);
v1294=v1296;
v1295=v1283;
}else{
const v1297=v1283["nodes"];
const v1298=(v1297).length;
const v1299=v1283["maximum"];
let v1300;
let v1301;
if(((v1298) >= (v1299))){
const v1302=__fn10(v1282);
const v1303=true;
const v1304=v1283["nodes"];
const v1305=v1283["maximum"];
const v1306=({["nodes"]:v1304,["maximum"]:v1305,["failed"]:v1303});
v1300=v1302;
v1301=v1306;
}else{
const v1307=({["value"]:v1282,["id"]:v1298});
const v1308=v1283["nodes"];
const v1309=({["op"]:v1284,["a"]:v1285,["b"]:v1286,["av"]:v1287,["bv"]:v1288,["value"]:v1282});
const v1310=__tempEdit(v1308,"push",v1309);
const v1311=v1283["maximum"];
const v1312=v1283["failed"];
const v1313=({["nodes"]:v1310,["maximum"]:v1311,["failed"]:v1312});
v1300=v1307;
v1301=v1313;
}
v1294=v1300;
v1295=v1301;
}
const v1315=v1277;
const v1316=v1294;
const v1317=__tempEdit(v1315,"push",v1316);
const v1318=v1295;
const v1319=v1279;
const v1320=1;
const v1321=(((v1319) + (v1320)) >>> 0);
v1277=v1317;
v1278=v1318;
v1279=v1321;
}
const v1323=v1277;
const v1324=v1323.freeze();
const v1325=v1278;
const v1327=v1269["features"];
const v1328=v1327.length;
const v1329=new Array(v1328);
for(let v1330=0;v1330<v1328;v1330++){
const v1331=v1327[v1330];
v1329[v1330]=__fn10(v1331);
}
const v1332=v1269["target"];
const v1333=__fn10(v1332);
const v1336=({["features"]:v1329,["target"]:v1333});
const v1340=v1336["features"];
const v1342=Math.min(v1324.length,v1340.length);
const v1343=new Array(v1342);
for(let v1344=0;v1344<v1342;v1344++){
const v1345=v1324[v1344];
const v1346=v1340[v1344];
v1343[v1344]=({["left"]:v1345,["right"]:v1346});
}
const v1347=new __InkBuffer([]);
const v1348=0;
let v1349=v1347;
let v1350=v1325;
let v1351=v1348;
for(let v1353=0;v1353<v1343.length;v1353++){
const v1354=v1343[v1353];
const v1355=v1354["left"];
const v1356=v1354["right"];
const v1357=v1350;
const v1360=3;
const v1361=1;
let v1362;if((v1360===v1361)){
const v1363=v1355["value"];
const v1364=v1356["value"];
v1362=__bits(__float(v1363) + __float(v1364));}else{
const v1365=2;
let v1366;if((v1360===v1365)){
const v1367=v1355["value"];
const v1368=v1356["value"];
v1366=__bits(__float(v1367) - __float(v1368));}else{
const v1369=3;
let v1370;if((v1360===v1369)){
const v1371=v1355["value"];
const v1372=v1356["value"];
v1370=__bits(__float(v1371) * __float(v1372));}else{
v1370=__bits((__float(v1355["value"]))/(__float(v1356["value"])));}
v1366=v1370;}
v1362=v1366;}
const v1373=v1362;
const v1374=v1355["id"];
const v1375=v1356["id"];
const v1376=v1355["value"];
const v1377=v1356["value"];
const v1378=({["op"]:v1360,["a"]:v1374,["b"]:v1375,["av"]:v1376,["bv"]:v1377,["value"]:v1373});
const v1379=v1355["id"];
const v1380=4294967295;
const v1381=!(v1379===v1380);
let v1382=v1381;if(!v1382){
const v1383=v1356["id"];
const v1384=4294967295;
v1382=!(v1383===v1384);}
const v1385=v1382;
const v1386=__fn11(v1357,v1378,v1385);
const v1387=v1349;
const v1388=v1386["value"];
const v1389=__tempEdit(v1387,"push",v1388);
const v1390=v1386["tape"];
const v1391=v1351;
const v1392=1;
const v1393=(((v1391) + (v1392)) >>> 0);
v1349=v1389;
v1350=v1390;
v1351=v1393;
}
const v1395=v1349;
const v1396=v1395.freeze();
const v1397=v1350;
const v1399=0;
const v1400=__fn10(v1399);
let v1401=v1400;
let v1402=v1397;
for(let v1404=0;v1404<v1396.length;v1404++){
const v1405=v1396[v1404];
const v1406=1;
const v1407=v1402;
const v1408=v1401;
const v1409=1;
let v1410;if((v1406===v1409)){
const v1411=v1408["value"];
const v1412=v1405["value"];
v1410=__bits(__float(v1411) + __float(v1412));}else{
const v1413=2;
let v1414;if((v1406===v1413)){
const v1415=v1408["value"];
const v1416=v1405["value"];
v1414=__bits(__float(v1415) - __float(v1416));}else{
const v1417=3;
let v1418;if((v1406===v1417)){
const v1419=v1408["value"];
const v1420=v1405["value"];
v1418=__bits(__float(v1419) * __float(v1420));}else{
v1418=__bits((__float(v1408["value"]))/(__float(v1405["value"])));}
v1414=v1418;}
v1410=v1414;}
const v1421=v1410;
const v1422=v1408["id"];
const v1423=v1405["id"];
const v1424=v1408["value"];
const v1425=v1405["value"];
const v1427=v1408["id"];
const v1428=4294967295;
const v1429=!(v1427===v1428);
let v1430=v1429;if(!v1430){
const v1431=v1405["id"];
const v1432=4294967295;
v1430=!(v1431===v1432);}
const v1433=v1430;
const v1434=false;
const v1435=(v1433===v1434);
let v1436=v1435;if(!v1436){
v1436=v1407["failed"];}
let v1437;
let v1438;
if(v1436){
const v1439=__fn10(v1421);
v1437=v1439;
v1438=v1407;
}else{
const v1440=v1407["nodes"];
const v1441=(v1440).length;
const v1442=v1407["maximum"];
let v1443;
let v1444;
if(((v1441) >= (v1442))){
const v1445=__fn10(v1421);
const v1446=true;
const v1447=v1407["nodes"];
const v1448=v1407["maximum"];
const v1449=({["nodes"]:v1447,["maximum"]:v1448,["failed"]:v1446});
v1443=v1445;
v1444=v1449;
}else{
const v1450=({["value"]:v1421,["id"]:v1441});
const v1451=v1407["nodes"];
const v1452=({["op"]:v1406,["a"]:v1422,["b"]:v1423,["av"]:v1424,["bv"]:v1425,["value"]:v1421});
const v1453=__tempEdit(v1451,"push",v1452);
const v1454=v1407["maximum"];
const v1455=v1407["failed"];
const v1456=({["nodes"]:v1453,["maximum"]:v1454,["failed"]:v1455});
v1443=v1450;
v1444=v1456;
}
v1437=v1443;
v1438=v1444;
}
v1401=v1437;
v1402=v1438;
}
const v1458=({["features"]:v1329,["target"]:v1333});
const v1459=v1402;
const v1461=v1458["target"];
const v1463=2;
const v1464=v1401;
const v1465=1;
let v1466;if((v1463===v1465)){
const v1467=v1464["value"];
const v1468=v1461["value"];
v1466=__bits(__float(v1467) + __float(v1468));}else{
const v1469=2;
let v1470;if((v1463===v1469)){
const v1471=v1464["value"];
const v1472=v1461["value"];
v1470=__bits(__float(v1471) - __float(v1472));}else{
const v1473=3;
let v1474;if((v1463===v1473)){
const v1475=v1464["value"];
const v1476=v1461["value"];
v1474=__bits(__float(v1475) * __float(v1476));}else{
v1474=__bits((__float(v1464["value"]))/(__float(v1461["value"])));}
v1470=v1474;}
v1466=v1470;}
const v1477=v1466;
const v1478=v1464["id"];
const v1479=v1461["id"];
const v1480=v1464["value"];
const v1481=v1461["value"];
const v1483=v1464["id"];
const v1484=4294967295;
const v1485=!(v1483===v1484);
let v1486=v1485;if(!v1486){
const v1487=v1461["id"];
const v1488=4294967295;
v1486=!(v1487===v1488);}
const v1489=v1486;
const v1490=false;
const v1491=(v1489===v1490);
let v1492=v1491;if(!v1492){
v1492=v1459["failed"];}
let v1493;
let v1494;
if(v1492){
const v1495=__fn10(v1477);
v1493=v1495;
v1494=v1459;
}else{
const v1496=v1459["nodes"];
const v1497=(v1496).length;
const v1498=v1459["maximum"];
let v1499;
let v1500;
if(((v1497) >= (v1498))){
const v1501=__fn10(v1477);
const v1502=true;
const v1503=v1459["nodes"];
const v1504=v1459["maximum"];
const v1505=({["nodes"]:v1503,["maximum"]:v1504,["failed"]:v1502});
v1499=v1501;
v1500=v1505;
}else{
const v1506=({["value"]:v1477,["id"]:v1497});
const v1507=v1459["nodes"];
const v1508=({["op"]:v1463,["a"]:v1478,["b"]:v1479,["av"]:v1480,["bv"]:v1481,["value"]:v1477});
const v1509=__tempEdit(v1507,"push",v1508);
const v1510=v1459["maximum"];
const v1511=v1459["failed"];
const v1512=({["nodes"]:v1509,["maximum"]:v1510,["failed"]:v1511});
v1499=v1506;
v1500=v1512;
}
v1493=v1499;
v1494=v1500;
}
const v1514=v1493;
const v1515=v1494;
const v1518=3;
const v1519=1;
let v1520;if((v1518===v1519)){
const v1521=v1514["value"];
const v1522=v1514["value"];
v1520=__bits(__float(v1521) + __float(v1522));}else{
const v1523=2;
let v1524;if((v1518===v1523)){
const v1525=v1514["value"];
const v1526=v1514["value"];
v1524=__bits(__float(v1525) - __float(v1526));}else{
const v1527=3;
let v1528;if((v1518===v1527)){
const v1529=v1514["value"];
const v1530=v1514["value"];
v1528=__bits(__float(v1529) * __float(v1530));}else{
v1528=__bits((__float(v1514["value"]))/(__float(v1514["value"])));}
v1524=v1528;}
v1520=v1524;}
const v1531=v1520;
const v1532=v1514["id"];
const v1533=v1514["id"];
const v1534=v1514["value"];
const v1535=v1514["value"];
const v1537=v1514["id"];
const v1538=4294967295;
const v1539=!(v1537===v1538);
let v1540=v1539;if(!v1540){
const v1541=v1514["id"];
const v1542=4294967295;
v1540=!(v1541===v1542);}
const v1543=v1540;
const v1544=false;
const v1545=(v1543===v1544);
let v1546=v1545;if(!v1546){
v1546=v1515["failed"];}
let v1547;
let v1548;
if(v1546){
const v1549=__fn10(v1531);
v1547=v1549;
v1548=v1515;
}else{
const v1550=v1515["nodes"];
const v1551=(v1550).length;
const v1552=v1515["maximum"];
let v1553;
let v1554;
if(((v1551) >= (v1552))){
const v1555=__fn10(v1531);
const v1556=true;
const v1557=v1515["nodes"];
const v1558=v1515["maximum"];
const v1559=({["nodes"]:v1557,["maximum"]:v1558,["failed"]:v1556});
v1553=v1555;
v1554=v1559;
}else{
const v1560=({["value"]:v1531,["id"]:v1551});
const v1561=v1515["nodes"];
const v1562=({["op"]:v1518,["a"]:v1532,["b"]:v1533,["av"]:v1534,["bv"]:v1535,["value"]:v1531});
const v1563=__tempEdit(v1561,"push",v1562);
const v1564=v1515["maximum"];
const v1565=v1515["failed"];
const v1566=({["nodes"]:v1563,["maximum"]:v1564,["failed"]:v1565});
v1553=v1560;
v1554=v1566;
}
v1547=v1553;
v1548=v1554;
}
const v1568=v1548;
let v1569;if(v1568["failed"]){
v1569=({Err:"reverse differentiation tape capacity exceeded"});}else{
const v1570=v1548;
const v1571=v1570["nodes"];
const v1572=v1571.freeze();
const v1573=v1547;
const v1574=__fn18(v1572,v1573,v1268);
const v1575=v1547;
const v1576=v1575["value"];
const v1577=v1324.length;
const v1578=new Array(v1577);
for(let v1579=0;v1579<v1577;v1579++){
const v1580=v1324[v1579];
const v1581=v1580["id"];
let v1582;if(v1581<v1574.length){v1582=v1574[v1581];}else{
v1582=0;}
v1578[v1579]=v1582;
}
v1569=({Ok:({["value"]:v1576,["gradient"]:v1578})});}
v1271=v1569;}
return v1271;}
function __into0(v1583){
let v1584=new __InkBuffer([]);
for(let v1585=0;v1585<64;v1585++){
const v1586=(v1585>>>0);
const v1587=v1584;
const v1588=0;
v1584=__tempEdit(v1587,"push",v1588);}
const v1589=v1584;
const v1590=v1589.freeze();
const v1591=v1590.length;
for(let v1592=0;v1592<v1591;v1592++){
v1583[v1592]=__intoOutput0(v1590[v1592]);
}
return v1591;}
function __into6(v1593,v1594,v1595,v1596){
const v1597=v1593.length;
for(let v1599=0;v1599<v1597;v1599++){
const v1600=v1593[v1599];
const v1601=(v1599>>>0);
let v1602;if(v1601<v1594.length){v1602=v1594[v1601];}else{
v1602=0;}
const v1603=v1602;
const v1604=Math.fround(__float(v1595) * __float(v1603));
v1596[v1599]=__intoOutput6(__bits(__float(v1600) - v1604));
}
return v1597;}
function __into8(v1605,v1606){
const v1607=1;
const v1608=new __InkBuffer(Array.from([v1607]));
let v1609;if(Object.hasOwn(v1605,"Some")){
const v1610=v1605["Some"];
v1609=__tempEdit(v1608,"push",v1610);}else{
const v1611=null;
const v1612=9;
v1609=__tempEdit(v1608,"push",v1612);}
const v1613=v1609;
const v1614=v1613.freeze();
const v1615=v1614.length;
for(let v1616=0;v1616<v1615;v1616++){
v1606[v1616]=v1614[v1616];
}
return v1615;}
function __into9(v1617,v1618){
const v1619=v1617.length;
for(let v1621=0;v1621<v1619;v1621++){
const v1622=v1617[v1621];
const v1623=1073741824;
const v1624=Math.fround(__float(v1622) * __float(v1623));
const v1625=1065353216;
v1618[v1621]=__intoOutput9(__bits(v1624 + __float(v1625)));
}
return v1619;}
function __into18(v1626,v1627,v1628,v1629){
let v1630=new __InkBuffer([]);
for(let v1631=0;v1631<v1626.length;v1631++){
const v1632=v1626[v1631];
const v1633=v1630;
const v1634=0;
v1630=__tempEdit(v1633,"push",v1634);
}
const v1635=v1630;
const v1636=v1627["id"];
const v1637=1065353216;
const v1638=4294967295;
let v1639;if((v1636===v1638)){
v1639=v1635;}else{
let v1640;if(v1636<v1635.length){v1640=v1635.item(v1636);}else{
v1640=0;}
const v1641=v1640;
v1639=__tempSet(v1635,v1636,__bits(__float(v1641) + __float(v1637)),false);}
const v1642=v1639;
const v1643=(v1626).length;
let v1644=v1642;
let v1645=v1643;
for(let v1647=v1626.length-1;v1647>=0;v1647--){
const v1648=v1626[v1647];
const v1650=v1645;
const v1651=1;
const v1652=(((v1650) - (v1651)) >>> 0);
const v1653=v1644;
let v1654;if(v1652<v1653.length){v1654=v1653.item(v1652);}else{
v1654=0;}
const v1655=v1654;
let v1656=v1628;if(v1656){
const v1657=0;
v1656=((__float(v1655)) === (__float(v1657)));}
let v1658;if(v1656){
v1658=v1644;}else{
const v1659=v1644;
const v1660=v1648["op"];
const v1661=1;
let v1662;if((v1660===v1661)){
const v1663=v1648["a"];
const v1664=4294967295;
let v1665;if((v1663===v1664)){
v1665=v1659;}else{
let v1666;if(v1663<v1659.length){v1666=v1659.item(v1663);}else{
v1666=0;}
const v1667=v1666;
v1665=__tempSet(v1659,v1663,__bits(__float(v1667) + __float(v1655)),false);}
const v1668=v1665;
const v1669=v1648["b"];
const v1670=4294967295;
let v1671;if((v1669===v1670)){
v1671=v1668;}else{
let v1672;if(v1669<v1668.length){v1672=v1668.item(v1669);}else{
v1672=0;}
const v1673=v1672;
v1671=__tempSet(v1668,v1669,__bits(__float(v1673) + __float(v1655)),false);}
v1662=v1671;}else{
const v1674=v1648["op"];
const v1675=2;
let v1676;if((v1674===v1675)){
const v1677=v1648["a"];
const v1678=4294967295;
let v1679;if((v1677===v1678)){
v1679=v1659;}else{
let v1680;if(v1677<v1659.length){v1680=v1659.item(v1677);}else{
v1680=0;}
const v1681=v1680;
v1679=__tempSet(v1659,v1677,__bits(__float(v1681) + __float(v1655)),false);}
const v1682=v1679;
const v1683=v1648["b"];
const v1684=((v1655 ^ 2147483648) >>> 0);
const v1685=4294967295;
let v1686;if((v1683===v1685)){
v1686=v1682;}else{
let v1687;if(v1683<v1682.length){v1687=v1682.item(v1683);}else{
v1687=0;}
const v1688=v1687;
v1686=__tempSet(v1682,v1683,__bits(__float(v1688) + __float(v1684)),false);}
v1676=v1686;}else{
const v1689=v1648["op"];
const v1690=3;
let v1691;if((v1689===v1690)){
const v1692=v1648["a"];
const v1693=v1648["bv"];
const v1694=__bits(__float(v1655) * __float(v1693));
const v1695=4294967295;
let v1696;if((v1692===v1695)){
v1696=v1659;}else{
let v1697;if(v1692<v1659.length){v1697=v1659.item(v1692);}else{
v1697=0;}
const v1698=v1697;
v1696=__tempSet(v1659,v1692,__bits(__float(v1698) + __float(v1694)),false);}
const v1699=v1696;
const v1700=v1648["b"];
const v1701=v1648["av"];
const v1702=__bits(__float(v1655) * __float(v1701));
const v1703=4294967295;
let v1704;if((v1700===v1703)){
v1704=v1699;}else{
let v1705;if(v1700<v1699.length){v1705=v1699.item(v1700);}else{
v1705=0;}
const v1706=v1705;
v1704=__tempSet(v1699,v1700,__bits(__float(v1706) + __float(v1702)),false);}
v1691=v1704;}else{
const v1707=v1648["op"];
const v1708=4;
let v1709;if((v1707===v1708)){
const v1710=v1648["a"];
const v1711=__bits((__float(v1655))/(__float(v1648["bv"])));
const v1712=4294967295;
let v1713;if((v1710===v1712)){
v1713=v1659;}else{
let v1714;if(v1710<v1659.length){v1714=v1659.item(v1710);}else{
v1714=0;}
const v1715=v1714;
v1713=__tempSet(v1659,v1710,__bits(__float(v1715) + __float(v1711)),false);}
const v1716=v1713;
const v1717=v1648["b"];
const v1718=v1648["av"];
const v1719=v1648["bv"];
const v1720=v1648["bv"];
const v1721=__bits((__float(__bits(__float(v1655) * __float(v1718))))/(__float(__bits(__float(v1719) * __float(v1720)))));
const v1722=((v1721 ^ 2147483648) >>> 0);
const v1723=4294967295;
let v1724;if((v1717===v1723)){
v1724=v1716;}else{
let v1725;if(v1717<v1716.length){v1725=v1716.item(v1717);}else{
v1725=0;}
const v1726=v1725;
v1724=__tempSet(v1716,v1717,__bits(__float(v1726) + __float(v1722)),false);}
v1709=v1724;}else{
const v1727=v1648["op"];
const v1728=5;
let v1729;if((v1727===v1728)){
const v1730=v1648["a"];
const v1731=((v1655 ^ 2147483648) >>> 0);
const v1732=4294967295;
let v1733;if((v1730===v1732)){
v1733=v1659;}else{
let v1734;if(v1730<v1659.length){v1734=v1659.item(v1730);}else{
v1734=0;}
const v1735=v1734;
v1733=__tempSet(v1659,v1730,__bits(__float(v1735) + __float(v1731)),false);}
v1729=v1733;}else{
const v1736=v1648["op"];
const v1737=6;
let v1738;if((v1736===v1737)){
const v1739=v1648["a"];
const v1740=1073741824;
const v1741=v1648["value"];
const v1742=__bits((__float(v1655))/(__float(__bits(__float(v1740) * __float(v1741)))));
const v1743=4294967295;
let v1744;if((v1739===v1743)){
v1744=v1659;}else{
let v1745;if(v1739<v1659.length){v1745=v1659.item(v1739);}else{
v1745=0;}
const v1746=v1745;
v1744=__tempSet(v1659,v1739,__bits(__float(v1746) + __float(v1742)),false);}
v1738=v1744;}else{
v1738=v1659;}
v1729=v1738;}
v1709=v1729;}
v1691=v1709;}
v1676=v1691;}
v1662=v1676;}
v1658=v1662;}
const v1747=v1658;
const v1748=({["index"]:v1652,["gradient"]:v1747});
v1644=v1748["gradient"];
v1645=v1748["index"];
}
const v1749=({["gradient"]:v1644,["index"]:v1645});
const v1750=v1749["gradient"];
const v1751=v1750.freeze();
const v1752=v1751.length;
for(let v1753=0;v1753<v1752;v1753++){
v1629[v1753]=__intoOutput18(v1751[v1753]);
}
return v1752;}
const __namedTypes={"Context":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"},"__ink_reverse_0_Flow":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"},"__ink_reverse_0_Node":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"__ink_reverse_0_Reverse":{"fields":[{"name":"gradient","type":{"kind":"temporary"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Reverse"},"__ink_reverse_0_Tape":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"},"__ink_reverse_0_Wire":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"__ink_reverse_13":{"fields":[{"name":"left","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"right","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_13"},"__ink_reverse_18":{"fields":[{"name":"values","type":{"kind":"temporary"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_18"},"__ink_reverse_3":{"fields":[{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_3"},"__ink_reverse_42":{"fields":[{"name":"values","type":{"kind":"temporary"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_42"},"__ink_reverse_55":{"fields":[{"name":"values","type":{"kind":"temporary"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_55"},"__ink_reverse_58":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"__ink_reverse_58"},"__ink_reverse_6":{"fields":[{"name":"value","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_6"},"__ink_reverse_8":{"fields":[{"name":"value","type":{"fields":[{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_3"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_8"}};
// Portable snapshot ABI shared with native/Wasm. Hashing uses Web Crypto.
function __snapshotLimits(limits={}){
 const result={bytes:64*1024*1024,values:1000000,depth:128,...limits};
 for(const k of ['bytes','values','depth'])if(!Number.isSafeInteger(result[k])||result[k]<0||result[k]>(k==='depth'?128:k==='values'?1000000:64*1024*1024))throw Error('invalid snapshot limits');
 return result;
}
const __hash=async bytes=>new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256',bytes));
function __snapshotWriter(limits){
 const out=[];let left=limits.values,maxDepth=0;
 function bytes(xs){if(xs.length>limits.bytes-out.length)throw Error('snapshot byte limit exceeded');for(const x of xs)out.push(x);}
 function integer(n,size){n=BigInt(n);for(let i=0;i<size;i++){bytes([Number(n&255n)]);n>>=8n;}}
 function raw(xs){integer(xs.length,8);bytes(xs);}
 function value(v,t,depth=0,bindings=[]){maxDepth=Math.max(maxDepth,depth);if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{value(v,t.body,depth+1,bindings);}finally{bindings.pop();}break;
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');value(v,bound[1],depth+1,bindings);break;}
  case 'unit':break;case 'bool':bytes([v?1:0]);break;
  case 'u32':case 'i32':case 'f32':integer(v,4);break;case 'u64':integer(v,8);break;
  case 'f64':integer(__dfBits(v),8);break;
  case 'vector':if(v.length!==t.size)throw Error('vector dimension mismatch');for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'int':{let n=v<0n?-v:v;const xs=[];while(n){if(xs.length>=4096)throw Error('snapshot Int exceeds size limit');xs.push(Number(n&255n));n>>=8n;}bytes([v===0n?0:v>0n?1:2]);raw(xs);break;}
  case 'string':raw(__encoder.encode(v));break;
  case 'id':integer(BigInt('0x'+v),16);break;
  case 'enum':integer(t.variants.indexOf(v),4);break;
  case 'record':for(const f of t.fields)value(t.elided?v:v[f.name],f.type,depth+1,bindings);break;
  case 'list':if(v.length>left)throw Error('snapshot value limit exceeded');integer(v.length,8);for(const x of v)value(x,t.element,depth+1,bindings);break;
  case 'option':if(Object.hasOwn(v,'Some')){bytes([1]);value(v.Some,t.element,depth+1,bindings);}else bytes([0]);break;
  case 'result':{const branch=t.sum_key?__sumView(t.sum_key,v):v;if(Object.hasOwn(branch,'Ok')){bytes([0]);value(branch.Ok,t.ok,depth+1,bindings);}else{bytes([1]);value(branch.Err,t.error,depth+1,bindings);}break;}
  default:throw Error('unsupported snapshot type');
 }}
 return {bytes,integer,raw,value,charge(cells,depth){left-=cells;if(left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');},get maxDepth(){return maxDepth;},get left(){return left;},finish:()=>new Uint8Array(out)};
}
async function __snapshotEncode(meta,state,options){
 const limits=__snapshotLimits(options),w=__snapshotWriter(limits);
 w.integer(state.version,8);
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const rows=[...state.tables[r.index].entries()].sort((a,b)=>__keyCompare(a[0],b[0],r.key));if(rows.length>Math.floor(w.left/2))throw Error('snapshot row limit exceeded');w.integer(rows.length,8);for(const [k,v]of rows){
  if(!meta.snapshotRows){w.value(k,r.snapshotKey??r.key);w.value(v,r.snapshotValue??r.value);continue;}
  const cache=state.snapshotRows[r.index];let packed=cache.get(k);
  if(!packed){const row=__snapshotWriter(limits);row.value(k,r.snapshotKey??r.key);row.value(v,r.snapshotValue??r.value);packed={bytes:row.finish(),cells:limits.values-row.left,depth:row.maxDepth};cache.set(k,packed);}
  w.charge(packed.cells,packed.depth);w.bytes(packed.bytes);
 }}
 w.integer(state.outbox.length,8);
 for(const e of state.outbox){const channel=meta.events.findIndex(t=>t.name===e.channel);w.integer(e.commit,8);w.integer(e.position,8);w.integer(channel,4);w.value(e.value,meta.events[channel].snapshotType??meta.events[channel].type);}
 const payload=w.finish(),header=__snapshotWriter(limits);header.bytes([86,76,83,84,65,84,69,0,1,0,1,0]);header.bytes(meta.snapshot.program);header.bytes(meta.snapshot.schema);header.integer(payload.length,8);header.bytes(payload);
 const bytes=header.finish();if(bytes.length+32>limits.bytes)throw Error('snapshot byte limit exceeded');const digest=await __hash(bytes);const result=new Uint8Array(bytes.length+32);result.set(bytes);result.set(digest,bytes.length);return result;
}
async function __snapshotDecode(meta,input,options){
 const limits=__snapshotLimits(options);
 if(!(input instanceof Uint8Array)&&!Array.isArray(input))throw Error('expected snapshot bytes');
 if(input.length>limits.bytes||input.length<116)throw Error('snapshot byte length invalid');
 if(Array.isArray(input)&&input.some(b=>!Number.isInteger(b)||b<0||b>255))throw Error('invalid snapshot bytes');
 const bytes=new Uint8Array(input); // capture before asynchronous integrity work
 function same(a,b){return a.length===b.length&&a.every((v,i)=>v===b[i]);}
 if(!same(bytes.subarray(0,12),[86,76,83,84,65,84,69,0,1,0,1,0]))throw Error('snapshot format or semantics version mismatch');
 if(!same(bytes.subarray(12,44),meta.snapshot.program)||!same(bytes.subarray(44,76),meta.snapshot.schema))throw Error('snapshot program or schema identity mismatch');
 const end=bytes.length-32,digest=await __hash(bytes.subarray(0,end));if(!same(digest,bytes.subarray(end)))throw Error('snapshot integrity check failed');
 let at=76,left=limits.values;
 function take(n){if(!Number.isSafeInteger(n)||n<0||n>end-at)throw Error('truncated snapshot');const x=bytes.subarray(at,at+n);at+=n;return x;}
 function integer(size){const xs=take(size);let n=0n;for(let i=size-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return n;}
 function length(){const n=integer(8);if(n>BigInt(Number.MAX_SAFE_INTEGER))throw Error('snapshot length not addressable');return Number(n);}
 function sequence(){const n=length();if(n>left)throw Error('snapshot value limit exceeded');return n;}
 function raw(){return take(length());}
 const n=length();if(n!==end-84)throw Error('snapshot payload length mismatch');
 function value(t,depth=0,bindings=[]){if(--left<0||depth>limits.depth)throw Error('snapshot value/depth limit exceeded');switch(t.kind){
  case 'bind':bindings.push([t.name,t.body]);try{return value(t.body,depth+1,bindings);}finally{bindings.pop();}
  case 'ref':{const bound=bindings.findLast(([name])=>name===t.name);if(!bound)throw Error('unbound recursive snapshot schema');return value(bound[1],depth+1,bindings);}
  case 'unit':return null;case 'bool':{const b=take(1)[0];if(b>1)throw Error('invalid Bool tag');return b===1;}
  case 'u32':case 'f32':return Number(integer(4));case 'i32':return Number(BigInt.asIntN(32,integer(4)));case 'u64':return integer(8);
  case 'f64':return __dfFromBits(integer(8));
  case 'vector':{const xs=[];for(let i=0;i<t.size;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'int':{const sign=take(1)[0],xs=raw();if(xs.length>4096)throw Error('snapshot Int exceeds size limit');if(!((sign===0&&xs.length===0)||((sign===1||sign===2)&&xs.length>0&&xs[xs.length-1]!==0)))throw Error('noncanonical signed integer');let n=0n;for(let i=xs.length-1;i>=0;i--)n=(n<<8n)+BigInt(xs[i]);return sign===2?-n:n;}
  case 'string':return new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(raw());
  case 'id':return integer(16).toString(16).padStart(32,'0');
  case 'enum':{const i=Number(integer(4));if(i>=t.variants.length)throw Error('invalid enum tag');return t.variants[i];}
  case 'record':if(t.elided)return value(t.fields[0].type,depth+1,bindings);return Object.fromEntries(t.fields.map(f=>[f.name,value(f.type,depth+1,bindings)]));
  case 'list':{const n=sequence(),xs=[];for(let i=0;i<n;i++)xs.push(value(t.element,depth+1,bindings));return xs;}
  case 'option':{const tag=take(1)[0];if(tag===0)return {None:null};if(tag===1)return {Some:value(t.element,depth+1,bindings)};throw Error('invalid Option tag');}
  case 'result':{const tag=take(1)[0];if(tag===0){const child=value(t.ok,depth+1,bindings);return t.sum_key?__sumMake(t.sum_key,true,child):{Ok:child};}if(tag===1){const child=value(t.error,depth+1,bindings);return t.sum_key?__sumMake(t.sum_key,false,child):{Err:child};}throw Error('invalid Result tag');}
  default:throw Error('unsupported snapshot type');
 }}
 const version=integer(8),tables=meta.roots.map(()=>new Map());
 const roots=meta.roots.map((r,i)=>({...r,index:i})).sort((a,b)=>a.name<b.name?-1:1);
 for(const r of roots){const n=sequence();if(n>Math.floor(left/2))throw Error('snapshot row limit exceeded');let prior;for(let i=0;i<n;i++){const k=value(r.snapshotKey??r.key),v=value(r.snapshotValue??r.value);if(i&&__keyCompare(prior,k,r.key)>=0)throw Error('duplicate or unordered snapshot key');tables[r.index].set(k,v);prior=k;}}
 const count=sequence(),outbox=[];let prior;
 for(let i=0;i<count;i++){const commit=integer(8),position=integer(8),channel=Number(integer(4));if(!meta.events[channel])throw Error('unknown snapshot event channel');const v=value(meta.events[channel].snapshotType??meta.events[channel].type);if(commit===0n||commit>version||(prior&&(commit<prior.commit||(commit===prior.commit&&position<=prior.position))))throw Error('invalid snapshot event sequence');const e={commit,position,channel:meta.events[channel].name,value:v};outbox.push(e);prior=e;}
 if(at!==end)throw Error('trailing snapshot payload');return {version,tables,outbox};
}
// Fixed subscription lifecycle. Root/output edges derive from checked source;
// values and ownership codecs are compiled from each query's declared type.
function __createObservers(prepare){
 const subscriptions=new Map(),byRoot=new Map(),errors=[],directRoots=[],rootSchedules=[];
 let pending=[],spare=[];
 let next=0,held=0,flushing=false;
 function report(s,error,phase){errors.push({query:s?.query??null,error,phase});if(s?.onError)try{s.onError(error);}catch(e){errors.push({query:s.query,error:e,phase:'error-handler'});}}
 function flush(initialPasses=0){
  if(held||flushing||!pending.length)return;
  flushing=true;let passes=initialPasses;
  try{
   while(pending.length&&!held){
    if(++passes>1024){report(null,Error('subscription publication budget exhausted'),'publication');break;}
    const affected=pending;pending=spare;spare=affected;
    for(const s of affected)s.queued=false;
    // Snapshot every affected value before consumers run. Deliveries reside in
    // the stable subscription slots; no per-delivery tuple is allocated.
    for(const s of affected){if(!s.active)continue;s.deliver=false;
     try{if(s.pair){const a=s.pairState?s.pairState.keeps[s.keep0]:s.read0(),b=s.pairState?s.pairState.keeps[s.keep1]:s.read1();if(s.value0!==a||s.value1!==b){s.value0=a;s.value1=b;s.delivery0=a;s.delivery1=b;s.deliver=true;}}else{const value=s.capture(s.read());if(!s.equal(s.value,value)){s.value=value;s.delivery=value;s.deliver=true;}}}
     catch(e){report(s,e,'query');}
    }
    for(const s of affected){if(!s.active||!s.deliver)continue;const value=s.delivery;s.deliver=false;s.delivery=undefined;
     try{if(s.pair)s.callback(s.delivery0,s.delivery1);else s.callback(s.output(value));}catch(e){report(s,e,'listener');}
    }
    affected.length=0;
   }
  }finally{flushing=false;}
 }
 function install(query,q,callback,{immediate=true,onError}={}){
  if(typeof callback!=='function'||onError!==undefined&&typeof onError!=='function')throw TypeError('subscription callback');
  const s={...q,id:next++,query,callback,onError,active:true,queued:false,deliver:false,delivery:undefined};
  if(s.pair){s.value0=s.pairState?s.pairState.keeps[s.keep0]:s.read0();s.value1=s.pairState?s.pairState.keeps[s.keep1]:s.read1();}else{s.value=s.capture(s.read());}subscriptions.set(s.id,s);
  for(const root of s.roots){let ids=byRoot.get(root);if(!ids)byRoot.set(root,ids=[]);ids.push(s);schedule(root,ids);}
  const dispose=()=>{if(!subscriptions.delete(s.id))return;s.active=false;for(const root of s.roots){const ids=byRoot.get(root);ids.splice(ids.indexOf(s),1);schedule(root,ids);if(!ids.length)byRoot.delete(root);}};
  if(immediate)try{if(s.pair)callback(s.value0,s.value1);else callback(s.output(s.value));}catch(e){dispose();throw e;}
  return dispose;
 }
 // Bind the publication implementation when consumers change, instead of
 // rediscovering the one-consumer schedule on each source mutation.
 function schedule(root,ids){
  const s=directRoots[root]=ids.length===1&&ids[0].pairState?ids[0]:null;
  rootSchedules[root]=!ids.length?null:s?()=>publishPair(s):(outputs,epoch)=>{enqueueRoot(root,outputs,epoch);flush();};
 }
 function publishPair(s){
  const a=s.pairState.keeps[s.keep0],b=s.pairState.keeps[s.keep1];
  if(s.value0===a&&s.value1===b)return;
  if(!held&&!flushing&&!pending.length){
   s.value0=a;s.value1=b;flushing=true;
   try{s.callback(a,b);}catch(e){report(s,e,'listener');}finally{flushing=false;}
   flush(1);return;
  }
  if(!s.queued){s.queued=true;pending.push(s);}flush();
 }
 function enqueueRoot(root,outputs,epoch){
  const slots=byRoot.get(root);if(!slots)return;
  for(let i=0;i<slots.length;i++){
   const s=slots[i];if(s.queued)continue;
   if(outputs!==null&&s.outputs?.length){
    let changed=false;for(let j=0;j<s.outputs.length;j++)if(epoch?outputs[s.outputs[j]]===epoch:outputs.has(s.outputs[j])){changed=true;break;}
    if(!changed)continue;
   }
   s.queued=true;pending.push(s);
  }
 }
 return {
  directRoots,rootSchedules,
  get active(){return subscriptions.size!==0;},
  subscribe(query,args,callback,options){return install(query,prepare(query,args),callback,options);},
  subscribeGroup(queries,callback,options){
   if(!Array.isArray(queries)||!queries.length)throw TypeError('subscription group requires queries');
   const qs=queries.map(q=>typeof q==='string'?prepare(q,[]):prepare(q.query,q.args??[]));
   const roots=[...new Set(qs.flatMap(q=>q.roots))];
   // An unknown dependency forces ordinary root invalidation for the group.
   const outputs=qs.every(q=>q.outputs?.length)?[...new Set(qs.flatMap(q=>q.outputs))]:[];
   const scalar=qs.every(q=>q.scalar),direct=qs.every(q=>q.direct);
   return install(queries,{roots,outputs,read:direct?()=>qs.map(q=>q.direct()):()=>qs.map(q=>q.read()),capture:scalar?values=>values:values=>values.map((v,i)=>qs[i].capture(v)),output:scalar?values=>values.slice():values=>values.map((v,i)=>qs[i].output(v)),equal:scalar?(a,b)=>a.every((v,i)=>v===b[i]):(a,b)=>a.every((v,i)=>qs[i].equal(v,b[i]))},callback,options);
  },
  subscribeValues(queries,callback,options){
   if(!Array.isArray(queries)||!queries.length)throw TypeError('subscription group requires queries');
   if(typeof callback!=='function')throw TypeError('subscription callback');
   const qs=queries.map(q=>typeof q==='string'?prepare(q,[]):prepare(q.query,q.args??[]));
   if(qs.length===2&&qs.every(q=>q.scalar)){
    const roots=[...new Set(qs.flatMap(q=>q.roots))],outputs=qs.every(q=>q.outputs?.length)?[...new Set(qs.flatMap(q=>q.outputs))]:[];
    const pairState=qs[0].committed&&qs[1].committed&&qs[0].committed.state===qs[1].committed.state?qs[0].committed.state:null;
    return install(queries,{roots,outputs,pair:true,pairState,keep0:qs[0].committed?.keep,keep1:qs[1].committed?.keep,read0:qs[0].direct||qs[0].read,read1:qs[1].direct||qs[1].read},callback,options);
   }
   return this.subscribeGroup(queries,values=>callback(...values),options);
  },
  commit(roots,outputs=null){
   if(!subscriptions.size)return;
   for(const root of roots)enqueueRoot(root,outputs,false);
   flush();
  },
  // A checked single-root action supplies a reusable array of changed outputs.
  // No root carrier, Set, affected-ID array or Map lookup per delivery is needed.
  commitRoot(root,outputs=null,epoch=0){
   rootSchedules[root]?.(outputs,epoch);
  },
  hold(){held++;return pending.slice();},
  release(){if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  rollback(mark){for(const s of pending)s.queued=false;pending.length=0;for(const s of mark)if(s.active&&!s.queued){s.queued=true;pending.push(s);}if(!held)throw Error('subscription boundary mismatch');held--;flush();},
  batch(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('batch callback must be synchronous');held++;
   try{const value=callback();if(value&&typeof value.then==='function')throw TypeError('state batch callback must be synchronous');return value;}
   finally{held--;flush();}
  },
  flush,takeErrors(){return errors.splice(0);}
 };
}
function __versionWord(v){return typeof v==='number'?BigInt(v):v;}
function __storedCommit(meta,v){return meta.compactCommits&&v<=9007199254740991n?Number(v):v;}
function __nextCommit(v){return typeof v==='number'&&v<9007199254740991?v+1:BigInt(v)+1n;}
// Private column event log. Public records and portable event ordering are unchanged.
// Private event storage. Public events and portable snapshots keep their ordinary
// ordered records. A selected contiguous run omits repeated commit metadata;
// gaps and duplicate commits materialise an exact literal column.
class __EventColumns {
 constructor(channels,compact=false,runs=false){this.channels=channels;this.compact=compact;this.runs=runs;this.commits=runs?null:[];this.base=undefined;this.values=[];this.positions=null;this.channelValues=channels.length===1?null:[];}
 get length(){return this.values.length;}
 set length(n){if(!Number.isSafeInteger(n)||n<0||n>this.length)throw Error('event log truncate');if(this.commits)this.commits.length=n;this.values.length=n;if(this.positions)this.positions.length=n;if(this.channelValues)this.channelValues.length=n;if(n===0){this.base=undefined;if(this.runs)this.commits=null;}}
 append(commit,position,channel,value){
  const i=this.values.length;
  if(this.commits)this.commits.push(commit);
  else if(!i)this.base=commit;
  else{
   const small=typeof this.base==='number'&&typeof commit==='number';
   const expected=small?this.base+i:__versionWord(this.base)+BigInt(i);
   if(expected!==commit){
    this.commits=[];
    for(let j=0;j<i;j++){const word=__versionWord(this.base)+BigInt(j);this.commits.push(this.compact&&word<=9007199254740991n?Number(word):word);}
    this.commits.push(commit);
   }
  }
  this.values.push(value);if(this.channelValues)this.channelValues.push(channel);if(position!==0n&&!this.positions)this.positions=new Array(i).fill(0n);if(this.positions)this.positions.push(position);
 }
 push(e){this.append(this.compact&&e.commit<=9007199254740991n?Number(e.commit):e.commit,e.position,e.channel,e.value);return this.length;}
 at(i){if(i<0)i+=this.length;if(i<0||i>=this.length)return undefined;return {commit:this.commits?__versionWord(this.commits[i]):__versionWord(this.base)+BigInt(i),position:this.positions?this.positions[i]:0n,channel:this.channelValues?this.channelValues[i]:this.channels[0],value:this.values[i]};}
 *[Symbol.iterator](){for(let i=0;i<this.length;i++)yield this.at(i);}
 map(f){const out=new Array(this.length);for(let i=0;i<this.length;i++)out[i]=f(this.at(i),i);return out;}
 filter(f){const out=new __EventColumns(this.channels,this.compact,this.runs);for(let i=0;i<this.length;i++){const e=this.at(i);if(f(e,i))out.push(e);}return out;}
}
function __eventLog(meta,events=[]){
 if(!meta.eventColumns)return meta.compactCommits?events.map(e=>({...e,commit:__storedCommit(meta,e.commit)})):events;
 const log=new __EventColumns(meta.events.map(e=>e.name),meta.compactCommits,meta.eventRuns);for(const e of events)log.append(__storedCommit(meta,e.commit),e.position,e.channel,e.value);return log;
}
// CALLER CONTRACT: arguments must match declared types; malformed data may throw or corrupt state.
// Fixed state primitives used by emitted action bodies, without an AST evaluator.
class __Abort {constructor(value){this.value=value;}}
function __preflightError(message){throw Error(message);}
function __try(value){if(Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value.Ok;}
function __nested(value,change){if(change && Object.hasOwn(value,'Err'))throw new __Abort(value.Err);return value;}
function __equal(a,b){if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object')return false;const ak=Object.keys(a),bk=Object.keys(b);return ak.length===bk.length&&ak.every(k=>Object.hasOwn(b,k)&&__equal(a[k],b[k]));}
function __checked(op,a,b,bits){const x=BigInt(a),y=BigInt(b),n=op==='checked_add'?x+y:op==='checked_sub'?x-y:x*y;const min=bits===-32?-2147483648n:0n,max=bits===-32?2147483648n:1n<<BigInt(bits);return n<min||n>=max?{Err:'ArithmeticError.Overflow'}:{Ok:Math.abs(bits)===32?Number(n):n};}
function __okOr(value,error){return Object.hasOwn(value,'Some')?{Ok:value.Some}:{Err:error};}
function __mapValue(value,kind,method,fn){
 if(kind==='list')return value[method](fn);
 if(kind==='option')return Object.hasOwn(value,'Some')?{Some:fn(value.Some)}:{None:null};
 const tag=method==='map_err'?'Err':'Ok';return Object.hasOwn(value,tag)?{[tag]:fn(value[tag])}:value;
}
const __encoder=new TextEncoder();
function __tick(ctx){if(--ctx.fuel<0)throw Error('Ink state execution budget exhausted');}
function __keyCompare(a,b,type){
 if(type.kind==='string'){let i=0,j=0;while(i<a.length&&j<b.length){const x=a.codePointAt(i),y=b.codePointAt(j);if(x!==y)return x-y;i+=x>65535?2:1;j+=y>65535?2:1;}return (i<a.length?1:0)-(j<b.length?1:0);}
 return a<b?-1:a>b?1:0;
}
// A table's ordered key view is reused until membership changes. Values are
// fetched at traversal time, so replacement never leaves stale row payloads.
const __tableOrder=new WeakMap();
function __keyPosition(keys,key,type){let low=0,high=keys.length;while(low<high){const middle=(low+high)>>>1;if(__keyCompare(keys[middle],key,type)<0)low=middle+1;else high=middle;}return low;}
function __tableMembership(rt,index,key,present){
 const view=__tableOrder.get(rt.tables[index]);if(!view)return;
 const at=__keyPosition(view.keys,key,rt.meta.roots[index].key);
 if((at<view.keys.length&&view.keys[at]===key)===present)view.pending.delete(key);
 else view.pending.set(key,present);
}
function __orderedKeys(rt,index){
 const table=rt.tables[index],type=rt.meta.roots[index].key;let view=__tableOrder.get(table);
 if(!view){view={keys:[...table.keys()].sort((a,b)=>__keyCompare(a,b,type)),pending:new Map()};__tableOrder.set(table,view);}
 if(view.pending.size){
  const changes=[...view.pending.keys()].sort((a,b)=>__keyCompare(a,b,type)),merged=[];let i=0,j=0;
  while(i<view.keys.length||j<changes.length){
   if(j===changes.length||(i<view.keys.length&&__keyCompare(view.keys[i],changes[j],type)<0))merged.push(view.keys[i++]);
   else{const key=changes[j++];if(i<view.keys.length&&view.keys[i]===key)i++;if(view.pending.get(key))merged.push(key);}
  }
  view.keys=merged;view.pending.clear();
 }
 const keys=view.keys;
 const cell=rt.cell;
 if(cell&&cell.index===index&&table.has(cell.key)!==(cell.next!==undefined)){
  if(cell.next===undefined)return keys.filter(k=>k!==cell.key);
  const at=__keyPosition(keys,cell.key,type);return [...keys.slice(0,at),cell.key,...keys.slice(at)];
 }
 return keys;
}
function __cellGet(rt,index,key){const cell=rt.cell;return cell&&cell.index===index&&cell.key===key?cell.next:rt.tables[index].get(key);}
function __readTable(rt,index){const cell=rt.cell;if(!cell||cell.index!==index)return rt.tables[index];const table=new Map(rt.tables[index]);if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);return table;}
// The first before-image of each cell suffices for whole-transaction rollback.
function __remember(rt,index,key,present,value){if(rt.cellMode)return;if(!rt.seen[index].has(key)){rt.seen[index].add(key);rt.undo.push([index,key,present,value]);}}
// Immutable keeps retain private values. Public results remain owned copies.
// Reverse edges come from checked source effects.
// Before-images preserve cached values across failed actions; host rollback and
// restore discard caches rather than serializing them into logical snapshots.
function __invalidateKeeps(rt,index){
 if(rt.observers?.active)rt.changedRoots.add(index);
 if(!rt.keeps||rt.cellMode)return;
 for(const keep of rt.meta.keepInvalidations[index]){
  if(!rt.keepDirty[keep]){rt.keepDirty[keep]=1;rt.keepUndoIndices[rt.keepUndoCount++]=keep;rt.keepBefore[keep]=rt.keeps[keep];}
  rt.keeps[keep]=undefined;
 }
}
function __restoreKeeps(rt){for(let i=rt.keepUndoCount-1;i>=0;i--){const keep=rt.keepUndoIndices[i];rt.keeps[keep]=rt.keepBefore[keep];}__refreshActiveViews(rt);}
function __clearKeepJournal(rt){for(let i=0;i<rt.keepUndoCount;i++){const keep=rt.keepUndoIndices[i];rt.keepDirty[keep]=0;rt.keepBefore[keep]=undefined;}rt.keepUndoCount=0;}
function __rebuildViews(rt){
 rt.activeViewRoots=new Uint8Array(rt.meta.roots.length);
 for(const view of rt.views){rt.keeps[view.keep]=undefined;if(!rt.meta.lazyMaintenance)__viewBase(rt,view);}
}
function __refreshActiveViews(rt){rt.activeViewRoots.fill(0);for(const view of rt.views)if(rt.keeps[view.keep]!==undefined)rt.activeViewRoots[view.root]=1;}
function __viewBase(rt,view){
 if(rt.keeps[view.keep]===undefined){let value=view.zero;for(const [key,row]of rt.tables[view.root])value=view.combine(value,view.contribution(key,row));rt.keeps[view.keep]=value;rt.activeViewRoots[view.root]=1;}
 return rt.keeps[view.keep];
}
function __viewValue(view,value,key,oldValue,newValue){
 if(oldValue===undefined)return view.insert?view.insert(value,key,newValue):view.combine(value,view.contribution(key,newValue));
 if(newValue===undefined)return view.remove?view.remove(value,key,oldValue):view.combine(value,view.inverse(view.contribution(key,oldValue)));
 return view.replace?view.replace(value,key,oldValue,newValue):view.combine(view.combine(value,view.inverse(view.contribution(key,oldValue))),view.contribution(key,newValue));
}
function __updateViews(rt,index,key,oldValue,newValue){
 if(!rt.activeViewRoots[index])return null;
 const updates=rt.viewNext;
 for(const view of rt.viewsByRoot[index])updates[view.keep]=rt.keeps[view.keep]===undefined?undefined:__viewValue(view,rt.keeps[view.keep],key,oldValue,newValue);
 return updates;
}
function __installViews(rt,updates,index){if(updates)for(const view of rt.viewsByRoot[index])rt.keeps[view.keep]=updates[view.keep];}
function __pendingView(rt,view){
 const keep=view.keep;
 if(rt.pendingValues[keep]===undefined){
  const cell=rt.cell;
  rt.pendingValues[keep]=__viewValue(view,__viewBase(rt,view),cell.key,cell.prior,cell.next);
  rt.pendingIndices.push(keep);
 }
 return rt.pendingValues[keep];
}
function __prepareCell(rt){if(rt.cell&&rt.activeViewRoots[rt.cell.index]){const prepare=rt.views.prepareRoots?.[rt.cell.index];if(prepare)prepare(rt,rt.cell);else for(const view of rt.viewsByRoot[rt.cell.index])if(rt.keeps[view.keep]!==undefined)__pendingView(rt,view);}}
function __invalidateSnapshotRow(rt,index,key){rt.snapshotRows?.[index].delete(key);}
function __writeCell(rt,index,key,next,prior){
 if(rt.cellMode){if(rt.cell)throw Error('checked single-cell bound exceeded');rt.cell={index,key,next,prior};}
 else{const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);if(rt.changeTracking)__recordChange(rt,index,key,prior,next);if((prior!==undefined)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);if(next===undefined)table.delete(key);else table.set(key,next);}
}
function __commitCell(rt){
 const cell=rt.cell;if(!cell)return;
 const table=rt.tables[cell.index];__invalidateSnapshotRow(rt,cell.index,cell.key);
 if(rt.changeTracking)__recordChange(rt,cell.index,cell.key,cell.prior,cell.next);
 if((cell.prior!==undefined)!==(cell.next!==undefined))__tableMembership(rt,cell.index,cell.key,cell.next!==undefined);
 if(cell.next===undefined)table.delete(cell.key);else table.set(cell.key,cell.next);
 for(const keep of rt.meta.keepInvalidations[cell.index])rt.keeps[keep]=rt.pendingValues[keep];
 rt.cell=null;
}
// Preflight scratch has no logical state or rollback obligations. Definitions
// are the same admitted group operations used by ordinary cell maintenance.
function __prepareDirect(rt,index,key,prior,next){
 const prepare=rt.views.directRoots?.[index];
 if(prepare)prepare(rt,key,prior,next);
 else for(const view of rt.viewsByRoot[index])rt.viewNext[view.keep]=__viewValue(view,rt.keeps[view.keep],key,prior,next);
}
function __storeDirect(rt,index,key,prior,next,slot){
 const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);
 if((prior!==undefined)!==(next!==undefined))__tableMembership(rt,index,key,next!==undefined);
 if(rt.changeTracking)__recordChange(rt,index,key,prior,next);
 if(slot===undefined){if(next===undefined)table.delete(key);else table.set(key,next);}
 else{
  // The checked preflight lookup retains the dense slot until this commit.
  // No callback or source write can intervene; sparse keys retain exact identity.
  if(slot<0){if(next===undefined)table.sparse.delete(key);else table.sparse.set(key,next);}else table.dense[slot]=next;
  if(prior===undefined&&next!==undefined)table.members.add(key);else if(prior!==undefined&&next===undefined)table.members.delete(key);
 }
}
function __commitDirect(rt,index,key,prior,next,slot){
 __storeDirect(rt,index,key,prior,next,slot);
 const publishOutputs=rt.meta.outputPublication&&!rt.observers.directRoots[index]&&rt.observers.active;
 if(publishOutputs&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}

 for(const keep of rt.meta.keepInvalidations[index]){
  const value=rt.viewByKeep[keep]?rt.viewNext[keep]:undefined;
  if(publishOutputs)rt.changedOutputs[keep]=rt.keeps[keep]!==value?rt.changedOutputEpoch:0;
  rt.keeps[keep]=value;
 }
}
function __emit(rt,channel,value){
 if(rt.eventCount++===0){rt.eventChannel=channel;rt.eventValue=value;}
 else rt.staged.push([channel,value]);
}
// Checked prefix capacities are at most 2^20. Number conversion is exact
// inside that prefix; rounding a wide word cannot move it into the prefix.
// Wide keys retain their original full-width value in the sparse fallback.
class __DenseTable{
 constructor(capacity){this.limit=capacity;this.dense=[];for(let i=0;i<capacity;i++)this.dense.push(undefined);this.sparse=new Map();this.members=new Set();}
 clear(){this.dense.fill(undefined);this.sparse.clear();this.members.clear();__tableOrder.delete(this);return this;}
 slot(key){const i=Number(key);return Number.isInteger(i)&&i>=0&&i<this.limit?i:-1;}
 get size(){return this.members.size;}
 get(key){const i=this.slot(key);return i<0?this.sparse.get(key):this.dense[i];}
 has(key){return this.get(key)!==undefined;}
 set(key,value){const i=this.slot(key),present=i<0?this.sparse.has(key):this.dense[i]!==undefined;if(i<0)this.sparse.set(key,value);else this.dense[i]=value;if(!present)this.members.add(key);return this;}
 delete(key){const i=this.slot(key);if(i<0)this.sparse.delete(key);else this.dense[i]=undefined;return this.members.delete(key);}
 keys(){return this.members.keys();}
 *values(){for(const key of this.members)yield this.get(key);}
 *entries(){for(const key of this.members)yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
class __ColumnTable {
 constructor(root){
  this.limit=root.columnPrefix.capacity;this.keyBig=root.key.kind==='u64';
  this.fields=root.value.fields;this.exactNumbers=root.columnPrefix.exactNumbers;
  this.present=new Uint8Array(this.limit);this.count=0;this.sparse=new Map();
  this.lanes=this.fields.map(f=>f.type.kind==='u64'?(this.exactNumbers?new Float64Array(this.limit):new BigUint64Array(this.limit)):f.type.kind==='i32'?new Int32Array(this.limit):f.type.kind==='bool'?new Uint8Array(this.limit):new Uint32Array(this.limit));
  this.wide=this.fields.map(f=>f.type.kind==='u64'&&this.exactNumbers?new Map():null);
 }
 slot(key){const i=Number(key);return Number.isInteger(i)&&i>=0&&i<this.limit?i:-1;}
 get size(){return this.count+this.sparse.size;}
 has(key){const i=this.slot(key);return i<0?this.sparse.has(key):this.present[i]!==0;}
 get(key){const i=this.slot(key);if(i<0)return this.sparse.get(key);if(!this.present[i])return undefined;const row=Object.create(null);for(let j=0;j<this.fields.length;j++){const f=this.fields[j],v=this.lanes[j][i];row[f.name]=f.type.kind==='bool'?v!==0:f.type.kind==='u64'&&this.exactNumbers?(this.wide[j].get(i)??BigInt(v)):v;}return row;}
 set(key,row){const i=this.slot(key);if(i<0){this.sparse.set(key,row);return this;}for(let j=0;j<this.fields.length;j++){const f=this.fields[j],v=row[f.name];if(f.type.kind==='u64'&&this.exactNumbers){if(v<=9007199254740991n){this.lanes[j][i]=Number(v);this.wide[j].delete(i);}else{this.lanes[j][i]=0;this.wide[j].set(i,v);}}else this.lanes[j][i]=f.type.kind==='bool'?Number(v):v;}if(!this.present[i]){this.present[i]=1;this.count++;}return this;}
 delete(key){const i=this.slot(key);if(i<0)return this.sparse.delete(key);if(!this.present[i])return false;this.present[i]=0;this.count--;for(const wide of this.wide)wide?.delete(i);return true;}
 *keys(){for(let i=0;i<this.limit;i++)if(this.present[i])yield this.keyBig?BigInt(i):i;yield* this.sparse.keys();}
 *values(){for(const key of this.keys())yield this.get(key);}
 *entries(){for(const key of this.keys())yield [key,this.get(key)];}
 [Symbol.iterator](){return this.entries();}
}
function __newTables(meta,prefixes,old,spares){return meta.roots.map((root,i)=>{const prior=spares?.[i];const t=root.columnPrefix?new __ColumnTable(root):prefixes[i]?(prior instanceof __DenseTable&&prior.limit===prefixes[i]?prior.clear():new __DenseTable(prefixes[i])):new Map();if(old)for(const [k,v]of old[i])t.set(k,v);return t;});}
// Only inactive containers are reused. Consume the spare before preparation so
// a failed invariant/rebuild cannot expose its partially reconstructed contents.
// Rows remain immutable; the current logical state changes only at installation.
function __restoreTables(rt,prefixes,old){const spares=rt.restoreSpares;rt.restoreSpares=null;return __newTables(rt.meta,prefixes,old,spares);}
function __cachedKeep(ctx,rt,index,compute){
 if(rt.cell&&rt.meta.keepInvalidations[rt.cell.index].includes(index)){
  const view=rt.viewByKeep[index];
  if(view)return __pendingView(rt,view);
  if(rt.pendingValues[index]===undefined){rt.pendingValues[index]=compute(ctx,rt);rt.pendingIndices.push(index);}
  return rt.pendingValues[index];
 }
 const prior=rt.keeps[index];if(prior!==undefined)return prior;
 const view=rt.viewByKeep[index];if(view)return __viewBase(rt,view);
 const value=compute(ctx,rt);rt.keeps[index]=value;return value;
}
function __tableContains(rt,index,key){return __cellGet(rt,index,key)!==undefined;}
function __tableGet(rt,index,key){const value=__cellGet(rt,index,key);return value===undefined?{None:null}:{Some:value};}
function __tablePut(rt,index,key,next,mode=0){
 const prior=rt.tables[index].get(key),present=prior!==undefined;
 if(mode===1&&present)throw Error('insert key already present');
 if(mode===2&&!present)throw Error('replace key absent');
 if(present&&__stateRootEquals[index](prior,next))return null;
 const updates=rt.cellMode?null:__updateViews(rt,index,key,prior,next);
 __invalidateKeeps(rt,index);__remember(rt,index,key,present,prior);
 __writeCell(rt,index,key,next,prior);__installViews(rt,updates,index);return null;
}
function __tableRemove(rt,index,key){
 const value=rt.tables[index].get(key);
 if(value===undefined)return {None:null};
 const updates=rt.cellMode?null:__updateViews(rt,index,key,value,undefined);
 __invalidateKeeps(rt,index);__remember(rt,index,key,true,value);
 __writeCell(rt,index,key,undefined,value);__installViews(rt,updates,index);return {Some:value};
}
function __table(rt,index,method,args){
 const key=args[0];
 if(method==='get')return __tableGet(rt,index,key);
 if(method==='contains')return __tableContains(rt,index,key);
 const table=rt.tables[index];
 if(method==='values'||method==='keys'){const keys=__orderedKeys(rt,index);return method==='keys'?keys.slice():keys.map(k=>__cellGet(rt,index,k));}
 if(method==='intersect_table'){const current=__readTable(rt,index),other=__readTable(rt,args[0]),small=current.size<=other.size?current:other,large=small===current?other:current;const result=[];for(const k of small.keys())if(large.has(k))result.push(k);return result.sort((a,b)=>__keyCompare(a,b,rt.meta.roots[index].key));}
 if(method==='intersect_keys'){const requested=args[0],size=rt.tables[index].size;
  // Fewer requested keys than rows: look each one up instead of scanning.
  if(requested.length<size){const type=rt.meta.roots[index].key;return [...new Set(requested)].filter(k=>__cellGet(rt,index,k)!==undefined).sort((a,b)=>__keyCompare(a,b,type));}
  const selected=new Set(requested);return __orderedKeys(rt,index).filter(k=>selected.has(k));}
 if(method==='put_many'){const keys=args[0],values=args[1];if(keys.length!==values.length)return {Err:'table bulk length mismatch'};for(let i=0;i<keys.length;i++)__table(rt,index,'put',[keys[i],values[i]]);return {Ok:null};}
 if(method==='remove_many'){for(const k of args[0])__table(rt,index,'remove',[k]);return null;}
 if(method==='remove')return __tableRemove(rt,index,key);
 return __tablePut(rt,index,key,args[1],method==='insert'?1:method==='replace'?2:0);
}

function __rollback(rt,mark){for(let i=rt.undo.length-1;i>=mark;i--){const [index,key,present,value]=rt.undo[i];const table=rt.tables[index];__invalidateSnapshotRow(rt,index,key);if(table.has(key)!==present)__tableMembership(rt,index,key,present);if(present)table.set(key,value);else table.delete(key);}rt.undo.length=mark;}
function __recordChange(rt,index,key,prior,next){rt.changeLog.push([index,key,prior,next]);}
function __fixedTableBytes(root,table){
 const writer=__snapshotWriter(__snapshotLimits());
 const rows=[...table.entries()].sort((a,b)=>__keyCompare(a[0],b[0],root.key));
 writer.integer(rows.length,8);
 for(const [key,value]of rows){writer.value(key,root.snapshotKey??root.key);writer.value(value,root.snapshotValue??root.value);}
 return writer.finish();
}
function __createState(meta,implementations,captures=null,views=[],prefixes=[]){
 const rt={meta,tables:__newTables(meta,prefixes),version:meta.compactCommits?0:0n,outbox:__eventLog(meta),staged:[],busy:false,undo:[],seen:meta.roots.map(()=>new Set()),host:null,keeps:new Array(meta.keeps.length),keepDirty:meta.keeps.length?new Uint8Array(meta.keeps.length):null,keepUndoIndices:meta.keeps.length?new Uint32Array(meta.keeps.length):null,keepUndoCount:0};
 const fixed=typeof __stateFrozenFactories==='undefined'?[]:__stateFrozenFactories;
 const fixedBytes=[];
 for(let i=0;i<fixed.length;i++)if(fixed[i]){for(const [key,value]of fixed[i]())rt.tables[i].set(key,value);fixedBytes[i]=__fixedTableBytes(meta.roots[i],rt.tables[i]);}
 function checkFixed(tables){for(let i=0;i<fixedBytes.length;i++)if(fixedBytes[i]){const bytes=__fixedTableBytes(meta.roots[i],tables[i]);if(bytes.length!==fixedBytes[i].length||!bytes.every((v,n)=>v===fixedBytes[i][n]))throw Error('snapshot changes frozen state: '+meta.roots[i].name);}}
 rt.views=views;rt.viewsByRoot=meta.roots.map((_,root)=>views.filter(v=>v.root===root));__rebuildViews(rt);
 rt.viewByKeep=new Array(meta.keeps.length);for(const view of views)rt.viewByKeep[view.keep]=view;
 rt.pendingIndices=[];rt.pendingValues=new Array(meta.keeps.length);
 rt.eventCount=0;rt.eventChannel=null;rt.eventValue=null;
 rt.viewNext=new Array(meta.keeps.length);rt.cell=null;rt.cellMode=false;rt.ctx={fuel:100000000};
 rt.keepBefore=meta.keeps.length?new Array(meta.keeps.length):null;
 rt.changedRoots=new Set();rt.changedOutputs=new Array(meta.keeps.length).fill(0);rt.changedOutputEpoch=0;
 rt.snapshotRows=meta.snapshotRows?meta.roots.map(()=>new Map()):null;
 rt.restoreSpares=null;rt.changeTracking=false;rt.changeLog=[];rt.changeEpoch=0;rt.changeTokens=new Map();
 const actionMap=new Map(meta.actions.map(a=>[a.name,{...a,inputs:captures?captures[a.index]:a.params.map(p=>__stateCapture(p.type)),output:__stateResult(a.result)}]));
 const eventOutput=new Map(meta.events.map(e=>[e.name,__stateResult(e.type)]));
 rt.eventOutput=eventOutput;
 const prepared=new WeakMap();
 const observers=rt.observers=__createObservers((name,args)=>{
  const a=actionMap.get(name);if(!a||a.change)throw Error('subscription requires a readonly query');
  const captured=a.inputs.map((convert,i)=>convert(args[i]));
  const publicArgs=captured.map((v,i)=>__stateResult(a.params[i].type)(v));
  const scalar=['u64','u32','i32','bool','string','unit','enum','id'].includes(a.result.kind);
  return {scalar,committed:scalar&&a.directKeep!==null&&a.directKeep!==undefined?{state:rt,keep:a.directKeep}:null,direct:scalar&&a.directKeep!==null&&a.directKeep!==undefined?()=>rt.keeps[a.directKeep]:null,roots:a.roots,outputs:rt.meta.outputPublication&&a.directKeep!==null&&a.directKeep!==undefined?[a.directKeep]:[],read:!a.precondition&&a.params.length===0?readZero(a,true):()=>run(a,publicArgs,null,null,true),capture:scalar?v=>v:__stateCapture(a.result),output:scalar?v=>v:a.output,equal:__stateQueryEquals[a.index]};
 });
 function invoke(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);return run(a,args);}
 function readZero(a,resultOnly){
  const implementation=implementations[a.index],output=a.output,fresh=a.freshResult;
  if(resultOnly&&fresh&&__stateDirectReadFactories[a.index])return __stateDirectReadFactories[a.index](rt);
  if(a.directKeep!==null&&a.directKeep!==undefined)return ()=>{
   if(rt.busy)throw Error('state operation already in progress');
   const value=rt.keeps[a.directKeep],result=fresh?value:output(value);
   return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};
  };
  return ()=>{
   if(rt.busy)throw Error('state operation already in progress');rt.busy=true;rt.ctx.fuel=100000000;
   try{const value=implementation(rt.ctx,rt),result=fresh?value:output(value);return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};}
   finally{rt.busy=false;}
  };
 }
 function read(a,args,inputs,output,resultOnly,owned=false){
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  rt.busy=true;
  try{const value=implementations[a.index](ctx,rt,...captured),result=a.freshResult?value:(output||a.output)(value);return resultOnly?result:{result,committed:false,version:__versionWord(rt.version),events:[]};}
  finally{rt.busy=false;}
 }
 function begin(a){
  if(rt.busy)throw Error('state operation already in progress');
  rt.ctx.fuel=100000000;
  rt.actionMark=rt.undo.length;rt.actionVersion=rt.version;rt.actionOutbox=rt.outbox;rt.actionOutboxLength=rt.outbox.length;rt.actionChangeMark=rt.changeLog.length;
  rt.busy=true;rt.cellMode=a.singleCell&&!rt.host;rt.staged.length=0;rt.eventCount=0;rt.changedRoots.clear();rt.actionSuccessful=false;
 }
 function complete(a,value,output,resultOnly){
  const result=a.freshResult?value:(output||a.output)(value);
  const version=rt.actionVersion;
  if(a.fallible && (a.flatFailure?value.tag!==0:Object.hasOwn(value,'Err'))){rt.changeLog.length=rt.actionChangeMark;__rollback(rt,rt.actionMark);__restoreKeeps(rt);if(rt.host?.strict)rt.host.failure=Object.assign(Error('transaction action failed'),{action:a.name,result});return resultOnly?result:{result,committed:false,version:__versionWord(version),events:[]};}
  if(version===18446744073709551615n)throw Error('commit sequence exhausted');
  const next=rt.meta.compactCommits?__nextCommit(version):version+1n;
  const publicNext=resultOnly?null:__versionWord(next);
  __prepareCell(rt);
  const events=resultOnly?null:new Array(rt.eventCount);
  if(rt.eventCount){
   const channel=rt.eventChannel,value=rt.eventValue;
   rt.outbox.push({commit:next,position:0n,channel,value});
   if(events)events[0]={commit:publicNext,position:0n,channel,value:eventOutput.get(channel)(value)};
   for(let i=0;i<rt.staged.length;i++){
    const [channel,value]=rt.staged[i],position=BigInt(i+1);
    rt.outbox.push({commit:next,position,channel,value});
    if(events)events[i+1]={commit:publicNext,position,channel,value:eventOutput.get(channel)(value)};
   }
  }
  __commitCell(rt);rt.version=next;rt.actionSuccessful=true;
  return resultOnly?result:{result,committed:true,version:publicNext,events};
 }
 function abort(e){
  rt.changeLog.length=rt.actionChangeMark;__rollback(rt,rt.actionMark);__restoreKeeps(rt);rt.version=rt.actionVersion;rt.outbox=rt.actionOutbox;rt.outbox.length=rt.actionOutboxLength;if(rt.host?.strict)rt.host.failure=e;throw e;
 }
 function end(){
  const successful=rt.actionSuccessful,single=rt.cellMode;
  rt.cell=null;rt.cellMode=false;rt.staged.length=0;rt.eventCount=0;rt.eventChannel=null;rt.eventValue=null;
  for(const keep of rt.pendingIndices)rt.pendingValues[keep]=undefined;rt.pendingIndices.length=0;
  if(!single){__clearKeepJournal(rt);for(const seen of rt.seen)seen.clear();if(!rt.host)rt.undo.length=0;}
  rt.actionOutbox=null;rt.busy=false;
  if(successful)observers.commit(rt.changedRoots);
 }
 function run(a,args,inputs=null,output=null,resultOnly=false,owned=false){
  if(a.kernels&&!rt.host){
   if(rt.busy)throw Error('state operation already in progress');
   const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
   return a.kernels[resultOnly?1:0](...captured);
  }
  if(!a.change)return read(a,args,inputs,output,resultOnly,owned);
  if(rt.busy)throw Error('state operation already in progress');
  const captured=owned?args:(inputs||a.inputs).map((convert,i)=>convert(args[i]));
  const ctx=rt.ctx;ctx.fuel=100000000;
  if(a.precondition && implementations[actionMap.get(a.precondition).index](ctx,rt,...captured)!==true)throw Error('contract precondition failed');
  begin(a);
  try{return complete(a,implementations[a.index](ctx,rt,...captured),output,resultOnly);}
  catch(e){return abort(e);}
  finally{end();}
 }

 for(const a of actionMap.values())if(__statePreflightFactories[a.index]){
  // run() supplies module-owned captured values; bound native entries still capture composites.
  a.kernels=[false,true].map(only=>__statePreflightFactories[a.index](run,a,a.inputs,a.output,only,rt,begin,complete,abort,end,true));
 }
 return Object.freeze({
  subscribeValues(queries,callback,options){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribeValues(queries,callback,options);},
  subscribeGroup(queries,callback,options){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribeGroup(queries,callback,options);},
  subscribe(...args){if(rt.busy||rt.host)throw Error('subscription requires transaction boundary');return observers.subscribe(...args);},
  batch:observers.batch,flushSubscriptions:observers.flush,takeSubscriptionErrors:observers.takeErrors,
  transaction(callback){
   if(typeof callback!=='function'||Object.prototype.toString.call(callback)==='[object AsyncFunction]')throw TypeError('transaction callback must be synchronous');this.beginTransaction();rt.host.strict=true;
   try{const value=callback(this);if(value&&typeof value.then==='function')throw TypeError('state transaction callback must be synchronous');this.commitTransaction();return value;}catch(e){this.rollbackTransaction();throw e;}
  },
  invoke,invoke_json:invoke,
  prepare(name,args){const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);const captured=a.inputs.map((convert,i)=>convert(args[i])),token=Object.freeze({});prepared.set(token,{action:a,args:captured});return token;},
  invokePrepared(token){const packet=prepared.get(token);if(!packet)throw Error('invalid prepared state call');return run(packet.action,packet.args,null,null,false,true);},
  // A prebound typed entrypoint: scalar arguments obey the native caller contract.
  // Composite arguments still capture owned input; events remain in the outbox.
  bind(name,{resultOnly=false}={}){
   const a=actionMap.get(name);if(!a)throw Error(`unknown action ${name}`);
   const inputs=a.params.map((p,i)=>['u32','i32','u64','bool','unit','string','f32','f64','id','enum','int'].includes(p.type.kind)?__representation(p.type,false):a.inputs[i]);
   if(!a.change&&!a.precondition&&inputs.length===0)return readZero(a,resultOnly);
   return (__statePreflightFactories[a.index]||__stateBoundFactories[a.index])(run,a,inputs,a.output,resultOnly,rt,begin,complete,abort,end);
  },
  beginTransaction(){if(rt.busy||rt.host||rt.undo.length)throw Error('transaction already in progress');rt.host={version:rt.version,outbox:rt.outbox,length:rt.outbox.length,keeps:rt.keeps.slice(),changeMark:rt.changeLog.length,notificationMark:observers.hold()};return true;},
  commitTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');if(rt.host.failure)throw rt.host.failure;rt.host=null;rt.undo.length=0;observers.release();},
  rollbackTransaction(){if(rt.busy||!rt.host)throw Error('no state transaction');__rollback(rt,0);rt.version=rt.host.version;rt.outbox=rt.host.outbox;rt.outbox.length=rt.host.length;rt.keeps=rt.host.keeps;__refreshActiveViews(rt);rt.changeLog.length=rt.host.changeMark;rt.changeEpoch++;const mark=rt.host.notificationMark;rt.host=null;observers.rollback(mark);},
  changeToken(){
   if(rt.busy||rt.host)throw Error('change token requires transaction boundary');
   const token=Object.freeze({});rt.changeTracking=true;rt.changeTokens.set(token,{epoch:rt.changeEpoch,index:rt.changeLog.length,version:__versionWord(rt.version)});return token;
  },
  releaseChangeToken(token){rt.changeTokens.delete(token);if(!rt.changeTokens.size){rt.changeTracking=false;rt.changeLog.length=0;}},
  changesSince(token){
   if(rt.busy||rt.host)throw Error('changes require transaction boundary');
   const mark=rt.changeTokens.get(token);if(!mark||mark.epoch!==rt.changeEpoch)throw Error('invalid change token lineage');
   const roots=new Map();
   for(let i=mark.index;i<rt.changeLog.length;i++){
    const [root,key,before,after]=rt.changeLog[i];let cells=roots.get(root);if(!cells)roots.set(root,cells=new Map());
    const prior=cells.get(key);if(prior)prior.after=after;else cells.set(key,{before,after});
   }
   const changes=[];
   const codecs=rt.changeOutputs??=meta.roots.map(schema=>({key:__stateResult(schema.key),row:__stateResult(schema.value)}));
   for(const [root,cells]of roots){const schema=meta.roots[root],keyOut=codecs[root].key,rowOut=codecs[root].row;
    for(const [key,{before,after}]of cells){if(before===undefined&&after===undefined||before!==undefined&&after!==undefined&&__stateRootEquals[root](before,after))continue;
     changes.push({table:schema.name,key:keyOut(key),before:before===undefined?{None:null}:{Some:rowOut(before)},after:after===undefined?{None:null}:{Some:rowOut(after)}});
    }
   }
   return {from:mark.version,to:__versionWord(rt.version),changes};
  },
  get version(){return __versionWord(rt.version);},
  get outbox(){return rt.outbox.map(e=>({...e,commit:__versionWord(e.commit),value:eventOutput.get(e.channel)(e.value)}));},
  acknowledgeThrough(commit,position){if(rt.busy)throw Error('state operation already in progress');commit=__stateWord(commit);position=__stateWord(position);const last=rt.outbox.at(-1);if(!last)return;const lastCommit=__versionWord(last.commit);if(lastCommit<commit||(lastCommit===commit&&last.position<=position)){if(rt.host)rt.outbox=__eventLog(meta);else rt.outbox.length=0;return;}rt.outbox=rt.outbox.filter(e=>{const c=__versionWord(e.commit);return c>commit||(c===commit&&e.position>position);});},
  async invokeAsync(name,args){
   if(typeof __parallelInvokeAsync!=='function')return invoke(name,args);
   if(rt.busy||rt.host)throw Error('parallel state call requires transaction boundary');const captured=structuredClone(args);rt.busy=true;observers.hold();let completed=false;
   try{const snapshot=await __snapshotEncode(meta,rt);const reply=await __parallelInvokeAsync(name,captured,snapshot);const s=await __snapshotDecode(meta,reply.snapshot);checkFixed(s.tables);const candidate={...rt,tables:__restoreTables(rt,prefixes,s.tables),keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);const previousTables=rt.tables;rt.tables=candidate.tables;rt.restoreSpares=previousTables.map(table=>table instanceof __DenseTable?table:null);rt.version=__storedCommit(meta,s.version);rt.outbox=__eventLog(meta,s.outbox);rt.keeps=candidate.keeps;rt.activeViewRoots=candidate.activeViewRoots;if(rt.snapshotRows)rt.snapshotRows=meta.roots.map(()=>new Map());rt.changeEpoch++;rt.changeLog.length=0;completed=true;return reply.value;}finally{rt.busy=false;if(completed)observers.commit(meta.roots.map((_,i)=>i));observers.release();}
  },
  checkpoint(limits){if(rt.busy)throw Error('checkpoint requires transaction boundary');return __snapshotEncode(meta,rt,limits);},
  async restore(bytes,limits){if(rt.host)throw Error('restore during transaction');if(rt.busy)throw Error('restore requires transaction boundary');rt.busy=true;rt.ctx.fuel=100000000;observers.hold();let restored=false;try{const s=await __snapshotDecode(meta,bytes,limits);checkFixed(s.tables);const candidate={...rt,tables:__restoreTables(rt,prefixes,s.tables),version:__storedCommit(meta,s.version),outbox:s.outbox,keeps:rt.keeps.map(()=>undefined)};__rebuildViews(candidate);for(const name of meta.invariantChecks||[]){const a=actionMap.get(name);if(implementations[a.index](rt.ctx,candidate)!==true)throw Error('snapshot violates state invariant');}const previousTables=rt.tables;rt.tables=candidate.tables;rt.restoreSpares=previousTables.map(table=>table instanceof __DenseTable?table:null);rt.version=__storedCommit(meta,s.version);rt.outbox=__eventLog(meta,s.outbox);rt.keeps=candidate.keeps;rt.activeViewRoots=candidate.activeViewRoots;if(rt.snapshotRows)rt.snapshotRows=meta.roots.map(()=>new Map());rt.changeEpoch++;rt.changeLog.length=0;restored=true;}finally{rt.busy=false;if(restored)observers.commit(meta.roots.map((_,i)=>i));observers.release();}},
 });
}
function __action0(ctx,rt,s0){__tick(ctx);__tick(ctx);return __fn1(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),__fn0()),s0);}
function __action1(ctx,rt,s1){__tick(ctx);__tick(ctx);return __fn2(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),__fn0()),s1);}
function __action2(ctx,rt){__tick(ctx);__tick(ctx);return ((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),__fn0());}
function __action3(ctx,rt,s2,s3,s4){__tick(ctx);try{__tick(ctx);const s5=({Some:null});if(((s6)=>Object.hasOwn(s6,"Some")?((s7)=>(((((__fn7(s2)) && ((__float(s3) > __float(0))))) && ((__float(s3) <= __float(1048576000))))))(s6["Some"]):((s8)=>(((((__fn7(s2)) && ((__float(s3) > __float(0))))) && ((__float(s3) <= __float(1048576000))))))(null))(s5)){__tick(ctx);const s9=__try(__fn3(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),__fn0()),s2,s4));__tick(ctx);__tablePut(rt,0,0,__fn6(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),__fn0()),s9,s3),0);__tick(ctx);const s10=__fn2(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),__fn0()),s2);__tick(ctx);__emit(rt,"learned",s10);__tick(ctx);const s11=({Ok:s10});return ((()=>{const s12=({Some:null});return ((s13)=>Object.hasOwn(s13,"Some")?((s14)=>(__fn5(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),__fn0()))))(s13["Some"]):((s15)=>(__fn5(((v,fallback)=>Object.hasOwn(v,'Some')?v.Some:fallback)(__tableGet(rt,0,0),__fn0()))))(null))(s12);})()?s11:({Err:(()=>{const s16=({Some:null});return ((s17)=>Object.hasOwn(s17,"Some")?((s18)=>("weight domain"))(s17["Some"]):((s19)=>("weight domain"))(null))(s16);})()}));}else{__tick(ctx);return ({Err:(()=>{const s20=({Some:null});return ((s21)=>Object.hasOwn(s21,"Some")?((s22)=>("training domain"))(s21["Some"]):((s23)=>("training domain"))(null))(s20);})()});}}catch(e){if(e instanceof __Abort)return ({Err:e.value});throw e;}}
function __stateCommitRoot0(rt,key,prior,next,slot){__storeDirect(rt,0,key,prior,next,slot);const publish=rt.meta.outputPublication&&!rt.observers.directRoots[0]&&rt.observers.active;if(publish&&++rt.changedOutputEpoch===4294967296){rt.changedOutputs.fill(0);rt.changedOutputEpoch=1;}}
const __stateDirectReadFactories=[null,null,null,null];
function __stateValueEqual0(a,b){if(a===b)return true;if(a.length!==b.length)return false;for(let i=0;i<a.length;i++)if(!((a[i]===b[i])))return false;return true;}
function __stateValueEqual1(a,b){if(a===b)return true;const xv=a,yv=b,x=Object.hasOwn(xv,'Ok');return x===Object.hasOwn(yv,'Ok')&&(x?(xv.Ok===yv.Ok):(xv.Err===yv.Err));}
function __ownedInput1(value,budget={cells:1000000},depth=0,maxDepth=64){if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView)))throw Error('invalid list');const out=new Array(value.length);for(let i=0;i<out.length;i++)out[i]=__ownedInput2(value[i],budget,depth+1,maxDepth);return out;}
function __ownedInput0(value,budget={cells:1000000},depth=0,maxDepth=64){if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(!value||typeof value!=='object'||Array.isArray(value)||!Object.hasOwn(value,"features")||!Object.hasOwn(value,"target"))throw Error('invalid record');const field0=__ownedInput1(value["features"],budget,depth+1,maxDepth);const field1=__ownedInput2(value["target"],budget,depth+1,maxDepth);return {["features"]:field0,["target"]:field1};}
const __ownedType2={"kind":"f32"};
function __ownedInput2(value,budget={cells:1000000},depth=0,maxDepth=64){return __stateInput(value,__ownedType2,budget,depth,maxDepth);}
function __ownedInput3(value,budget={cells:1000000},depth=0,maxDepth=64){let scalar=value;if(depth>maxDepth||--budget.cells<0)throw Error('state input resource limit');if(typeof scalar!=='number'||!Number.isInteger(scalar)||scalar<0||scalar>4294967295)throw Error('invalid u32');if(scalar===0)scalar=0;return scalar;}
const __stateFrozenFactories=[];
const __stateQueryEquals=[(a,b)=>(a===b),(a,b)=>(a===b),(a,b)=>__stateValueEqual0(a,b),(a,b)=>__stateValueEqual1(a,b)];
const __stateRootEquals=[(a,b)=>__stateValueEqual0(a,b)];
const __stateBoundFactories=[(run,a,inputs,output,only)=>(p0)=>run(a,[inputs[0](p0)],null,output,only,true),(run,a,inputs,output,only)=>(p0)=>run(a,[inputs[0](p0)],null,output,only,true),(run,a,inputs,output,only)=>()=>run(a,[],null,output,only,true),(run,a,inputs,output,only,rt,begin,complete,abort,end)=>a.precondition?(p0,p1,p2)=>run(a,[inputs[0](p0),inputs[1](p1),inputs[2](p2)],null,output,only,true):(p0,p1,p2)=>{const b0=inputs[0](p0);const b1=inputs[1](p1);const b2=inputs[2](p2);begin(a);try{return complete(a,__action3(rt.ctx,rt,b0,b1,b2),output,only);}catch(e){return abort(e);}finally{end();}}];const __statePreflightFactories=[null,null,null,null];
const __stateMetadata={"actions":[{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":0,"name":"prediction","params":[{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"kind":"f32"},"roots":[0],"singleCell":true},{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":1,"name":"loss","params":[{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"kind":"f32"},"roots":[0],"singleCell":true},{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":2,"name":"parameters","params":[],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"},"roots":[0],"singleCell":true},{"change":true,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":false,"index":3,"name":"observe","params":[{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}},{"name":"rate","type":{"kind":"f32"}},{"name":"maximum","type":{"kind":"u32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"f32"}},"roots":[0],"singleCell":true}],"compactCommits":false,"eventColumns":false,"eventRuns":false,"events":[{"name":"learned","snapshotType":{"kind":"f32"},"type":{"kind":"f32"}}],"invariantChecks":[],"keepInvalidations":[[]],"keeps":[],"lazyMaintenance":true,"outputPublication":false,"roots":[{"key":{"kind":"u32"},"name":"Weights","snapshotKey":{"kind":"u32"},"snapshotValue":{"element":{"kind":"f32"},"kind":"list"},"value":{"element":{"kind":"f32"},"kind":"list"}}],"snapshot":{"program":[111,122,51,172,254,118,203,110,91,51,38,205,254,174,218,250,46,108,27,174,167,117,234,201,66,170,229,126,236,164,236,156],"schema":[88,237,187,8,176,224,234,212,255,33,114,68,240,149,102,187,10,107,85,221,202,66,9,105,147,239,26,11,119,207,53,167]},"snapshotRows":false};const __actions=[__action0,__action1,__action2,__action3];const __stateInputCaptures=[[__ownedInput0],[__ownedInput0],[],[__ownedInput0,__ownedInput2,__ownedInput3]];
export function createState(){return __createState(__stateMetadata,__actions,__stateInputCaptures);}
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v11","core_sha256":"392e6e8e5d1079cb661f6356afe30396c8a469a8346fdc52b42f4a011afc40b7","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"f32_storage":"exact-u32-bits","functions":[{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":0,"internal":false,"name":"initial","parallel":false,"params":[],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":1,"internal":false,"name":"model","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":2,"internal":false,"name":"objective","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":3,"internal":false,"name":"derivatives","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}},{"name":"maximum","type":{"kind":"u32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"destination":null,"index":4,"internal":false,"name":"linearized_value","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}},{"name":"maximum","type":{"kind":"u32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"f32"}}},{"destination":null,"index":5,"internal":false,"name":"valid","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":6,"internal":false,"name":"update","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"rate","type":{"kind":"f32"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":7,"internal":false,"name":"admissible","parallel":false,"params":[{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":8,"internal":false,"name":"branch_owned","parallel":false,"params":[{"name":"input","type":{"element":{"kind":"u32"},"kind":"option"}}],"precondition":null,"result":{"element":{"kind":"u32"},"kind":"list"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":9,"internal":false,"name":"device","parallel":false,"params":[{"name":"inputs","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":10,"internal":false,"name":"__ink_reverse_0_constant","parallel":false,"params":[{"name":"value","type":{"kind":"f32"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"destination":null,"index":11,"internal":true,"name":"__ink_reverse_0_append","parallel":false,"params":[{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"node","type":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"}},{"name":"active","type":{"kind":"bool"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":12,"internal":true,"name":"__ink_reverse_0_seed","parallel":false,"params":[{"name":"value","type":{"kind":"f32"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":13,"internal":true,"name":"__ink_reverse_0_binary","parallel":false,"params":[{"name":"op","type":{"kind":"u32"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"b","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":14,"internal":true,"name":"__ink_reverse_0_unary","parallel":false,"params":[{"name":"op","type":{"kind":"u32"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"a","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":15,"internal":true,"name":"__ink_reverse_0_add","parallel":false,"params":[{"name":"g","type":{"kind":"temporary"}},{"name":"id","type":{"kind":"u32"}},{"name":"value","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"temporary"}},{"destination":null,"index":16,"internal":true,"name":"__ink_reverse_0_back_node","parallel":false,"params":[{"name":"node","type":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"}},{"name":"amount","type":{"kind":"f32"}},{"name":"g","type":{"kind":"temporary"}}],"precondition":null,"result":{"kind":"temporary"}},{"destination":null,"index":17,"internal":true,"name":"__ink_reverse_0_back_step","parallel":false,"params":[{"name":"node","type":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"}},{"name":"work","type":{"fields":[{"name":"gradient","type":{"kind":"temporary"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Reverse"}},{"name":"stopZero","type":{"kind":"bool"}}],"precondition":null,"result":{"fields":[{"name":"gradient","type":{"kind":"temporary"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Reverse"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":18,"internal":false,"name":"__ink_reverse_0_backward","parallel":false,"params":[{"name":"nodes","type":{"element":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"kind":"list"}},{"name":"output","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"stopZero","type":{"kind":"bool"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":19,"internal":true,"name":"__ink_reverse_4","parallel":false,"params":[{"name":"weights","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_3"}},{"name":"__ink_reverse_5","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":20,"internal":true,"name":"__ink_reverse_1","parallel":false,"params":[{"name":"weights","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_3"}},{"name":"__ink_reverse_2","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"}},{"destination":null,"index":21,"internal":false,"name":"__ink_reverse_37","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"__ink_reverse_32","type":{"kind":"u32"}},{"name":"__ink_reverse_33","type":{"kind":"bool"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},{"destination":null,"index":22,"internal":false,"name":"__ink_reverse_50","parallel":false,"params":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"__ink_reverse_45","type":{"kind":"u32"}},{"name":"__ink_reverse_46","type":{"kind":"bool"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"__ink_reverse_58"}}}],"named_types":{"Context":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"},"__ink_reverse_0_Flow":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_0_Flow"},"__ink_reverse_0_Node":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"__ink_reverse_0_Reverse":{"fields":[{"name":"gradient","type":{"kind":"temporary"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Reverse"},"__ink_reverse_0_Tape":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"},"__ink_reverse_0_Wire":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"__ink_reverse_13":{"fields":[{"name":"left","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"right","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_13"},"__ink_reverse_18":{"fields":[{"name":"values","type":{"kind":"temporary"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_18"},"__ink_reverse_3":{"fields":[{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_3"},"__ink_reverse_42":{"fields":[{"name":"values","type":{"kind":"temporary"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_42"},"__ink_reverse_55":{"fields":[{"name":"values","type":{"kind":"temporary"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_55"},"__ink_reverse_58":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"__ink_reverse_58"},"__ink_reverse_6":{"fields":[{"name":"value","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_6"},"__ink_reverse_8":{"fields":[{"name":"value","type":{"fields":[{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_3"}},{"name":"tape","type":{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}}],"kind":"record","name":"__ink_reverse_8"}},"prepared_compiled":{"evaluation":"lazy source-order; successful bindings only","functions":[{"factory":false,"function":"initial","reason":"no reusable captured work"},{"factory":false,"function":"model","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"objective","retained_bindings":1},{"delegated_calls":1,"factory":true,"function":"derivatives","retained_bindings":0},{"delegated_calls":1,"factory":true,"function":"linearized_value","retained_bindings":0},{"factory":false,"function":"valid","reason":"no reusable captured work"},{"factory":false,"function":"update","reason":"no reusable captured work"},{"factory":false,"function":"admissible","reason":"no reusable captured work"},{"factory":false,"function":"branch_owned","reason":"no reusable captured work"},{"factory":false,"function":"device","reason":"no reusable captured work"},{"factory":false,"function":"__ink_reverse_0_constant","reason":"no reusable captured work"},{"factory":false,"function":"__ink_reverse_0_append","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_seed","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_binary","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_unary","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_add","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_back_node","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_back_step","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_0_backward","reason":"no reusable lexical bindings"},{"factory":false,"function":"__ink_reverse_4","reason":"prepared residual requires a bounded pure value entry"},{"factory":false,"function":"__ink_reverse_1","reason":"prepared residual requires a bounded pure value entry"},{"delegated_calls":1,"factory":true,"function":"__ink_reverse_37","retained_bindings":1},{"delegated_calls":1,"factory":true,"function":"__ink_reverse_50","retained_bindings":1}],"lifetime":"prepared token","semantics":"sealed-value-residual-v1"},"private_record_elisions":[],"private_sum_spines":[],"schema":1,"state":{"actions":[{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":0,"name":"prediction","params":[{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"kind":"f32"},"roots":[0],"singleCell":true},{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":1,"name":"loss","params":[{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"precondition":null,"result":{"kind":"f32"},"roots":[0],"singleCell":true},{"change":false,"directKeep":null,"fallible":false,"flatFailure":false,"freshResult":false,"index":2,"name":"parameters","params":[],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"},"roots":[0],"singleCell":true},{"change":true,"directKeep":null,"fallible":true,"flatFailure":false,"freshResult":false,"index":3,"name":"observe","params":[{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}},{"name":"rate","type":{"kind":"f32"}},{"name":"maximum","type":{"kind":"u32"}}],"precondition":null,"result":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"f32"}},"roots":[0],"singleCell":true}],"compactCommits":false,"eventColumns":false,"eventRuns":false,"events":[{"name":"learned","snapshotType":{"kind":"f32"},"type":{"kind":"f32"}}],"invariantChecks":[],"keepInvalidations":[[]],"keeps":[],"lazyMaintenance":true,"outputPublication":false,"roots":[{"key":{"kind":"u32"},"name":"Weights","snapshotKey":{"kind":"u32"},"snapshotValue":{"element":{"kind":"f32"},"kind":"list"},"value":{"element":{"kind":"f32"},"kind":"list"}}],"snapshot":{"program":[111,122,51,172,254,118,203,110,91,51,38,205,254,174,218,250,46,108,27,174,167,117,234,201,66,170,229,126,236,164,236,156],"schema":[88,237,187,8,176,224,234,212,255,33,114,68,240,149,102,187,10,107,85,221,202,66,9,105,147,239,26,11,119,207,53,167]},"snapshotRows":false},"wire":{"format":"ink-value-wire-v1","functions":{"__ink_reverse_0_add":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_append":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_back_node":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_back_step":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_backward":{"arguments":{"format":"ink-value-wire-v1","identity":"369ca7294b9f7da184514c2d74f2fbffa34696c1fa5d3a2adaf1f053340d482d","named":{},"root":{"fields":[{"name":"nodes","type":{"element":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"kind":"list"}},{"name":"output","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},{"name":"stopZero","type":{"kind":"bool"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"__ink_reverse_0_binary":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_constant":{"arguments":{"format":"ink-value-wire-v1","identity":"d4cb0361a7a8833933106ca6dd70006e19100c770fe048f31d961bc14fa899fc","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fabc4e63e940c6190680726874c8654deced79200b320c057b9389a135a08557","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}},"__ink_reverse_0_seed":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_0_unary":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_1":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_37":{"arguments":{"format":"ink-value-wire-v1","identity":"aa6ffaee463edc2bbb4595b3448a47ccf9f902019bdfa1698cab5a40095ebc3a","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"__ink_reverse_32","type":{"kind":"u32"}},{"name":"__ink_reverse_33","type":{"kind":"bool"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}}},"__ink_reverse_4":{"unsupported":"unsupported wire descriptor"},"__ink_reverse_50":{"arguments":{"format":"ink-value-wire-v1","identity":"064915d4b19973c0396dcdd3a9a8b095ad4e22429872efaf1a375b4c54eac3aa","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"__ink_reverse_45","type":{"kind":"u32"}},{"name":"__ink_reverse_46","type":{"kind":"bool"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"f2d8a6a6c76daa0750e8dd172034ca17108eb15fc853843947bdb021fd452611","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"__ink_reverse_58"}}}},"admissible":{"arguments":{"format":"ink-value-wire-v1","identity":"a4c45ed22b0e345add1a53da55d4f9aa0442ed173ee8c7734a183b368c9d0031","named":{},"root":{"fields":[{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"branch_owned":{"arguments":{"format":"ink-value-wire-v1","identity":"6ea13b740766255e668bdce007ed0ea6f6091b69fe3a9d897ca135f5edeef7cd","named":{},"root":{"fields":[{"name":"input","type":{"element":{"kind":"u32"},"kind":"option"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"69ebf947aa59a2546656d1976b0baa6e56e7182d989425379b31e3bff74168ca","named":{},"root":{"element":{"kind":"u32"},"kind":"list"}}},"derivatives":{"arguments":{"format":"ink-value-wire-v1","identity":"d0fa6f5fad6d5ea49ecfccbf7a1a5bdf4d65384297c30db7f5989fa6013499be","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}},{"name":"maximum","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}}},"device":{"arguments":{"format":"ink-value-wire-v1","identity":"83b9b7354aba5e748ee768e3487afeb50ddd616def9b5be81dbc74b6305f501b","named":{},"root":{"fields":[{"name":"inputs","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"initial":{"arguments":{"format":"ink-value-wire-v1","identity":"3720cf83cb9a672c0c70e7f80cfe0abe0bf9b7df73d40a9def0c7436234026b2","named":{},"root":{"fields":[],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"linearized_value":{"arguments":{"format":"ink-value-wire-v1","identity":"d0fa6f5fad6d5ea49ecfccbf7a1a5bdf4d65384297c30db7f5989fa6013499be","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}},{"name":"maximum","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"29bcdada2d2b5ecb6deae18e25401ad25c1f0dc80bcd50defebf64892403468d","named":{},"root":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"f32"}}}},"model":{"arguments":{"format":"ink-value-wire-v1","identity":"97019f1af0dd8c1360f443304271bf6d17719aef581eca5c217e172f074ab50e","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"objective":{"arguments":{"format":"ink-value-wire-v1","identity":"97019f1af0dd8c1360f443304271bf6d17719aef581eca5c217e172f074ab50e","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"context","type":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"update":{"arguments":{"format":"ink-value-wire-v1","identity":"907283cc95c811b8b6e4d273283b1227f8a468df3df28f504ee2584d9d3791aa","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"rate","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"valid":{"arguments":{"format":"ink-value-wire-v1","identity":"fb0d53fcc5118c446d80e19c4ffd8b95f7979f94f7fb23149d3518375b621a75","named":{},"root":{"fields":[{"name":"weights","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}}}}};
const __implementations=[__fn0,__fn1,__fn2,__fn3,__fn4,__fn5,__fn6,__fn7,__fn8,__fn9,__fn10,__fn11,__fn12,__fn13,__fn14,__fn15,__fn16,__fn17,__fn18,__fn19,__fn20,__fn21,__fn22];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
const __inputTypes=[{"capture":[],"types":[]},{"capture":[true,false],"types":[{"element":{"kind":"f32"},"kind":"list"},{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"Context"}]},{"capture":[true,false],"types":[{"element":{"kind":"f32"},"kind":"list"},{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}]},{"capture":[true,false,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"},{"kind":"u32"}]},{"capture":[true,false,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"},{"kind":"u32"}]},{"capture":[true],"types":[{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[true,true,true],"types":[{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"kind":"f32"}]},{"capture":[false],"types":[{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}]},{"capture":[true],"types":[{"element":{"kind":"u32"},"kind":"option"}]},{"capture":[true],"types":[{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[true],"types":[{"kind":"f32"}]},{"capture":[true,true,true],"types":[{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"},{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},{"kind":"bool"}]},{"capture":[true,true],"types":[{"kind":"f32"},{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}]},{"capture":[true,true,false,false],"types":[{"kind":"u32"},{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}]},{"capture":[true,true,false],"types":[{"kind":"u32"},{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}]},{"capture":[true,true,true],"types":[{"kind":"temporary"},{"kind":"u32"},{"kind":"f32"}]},{"capture":[false,true,true],"types":[{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},{"kind":"f32"},{"kind":"temporary"}]},{"capture":[false,false,true],"types":[{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},{"fields":[{"name":"gradient","type":{"kind":"temporary"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Reverse"},{"kind":"bool"}]},{"capture":[false,false,true],"types":[{"element":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"kind":"list"},{"fields":[{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},{"kind":"bool"}]},{"capture":[true,true,true],"types":[{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"},{"fields":[{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_3"},{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}]},{"capture":[true,true,true],"types":[{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"},{"fields":[{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"},"kind":"list"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}}],"kind":"record","name":"__ink_reverse_3"},{"fields":[{"name":"nodes","type":{"kind":"temporary"}},{"name":"maximum","type":{"kind":"u32"}},{"name":"failed","type":{"kind":"bool"}}],"kind":"record","name":"__ink_reverse_0_Tape"}]},{"capture":[true,true,true,false],"types":[{"element":{"kind":"f32"},"kind":"list"},{"kind":"u32"},{"kind":"bool"},{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}]},{"capture":[true,true,true,false],"types":[{"element":{"kind":"f32"},"kind":"list"},{"kind":"u32"},{"kind":"bool"},{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}]}];

// Descriptor work occurs once at module initialisation, never per word-list call.
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=> {
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const output=__representation(f.result,true);
  const body=__implementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
  const needsInput=input.some(c=>c!==__identity);
  const entry=!needsInput && output===__identity ? implementation :
    (...args)=>{const context=new WeakMap();return output(implementation(...(needsInput ? args.map((v,i)=>input[i](v,context)) : args)),context);};
  return [f.name,entry];
})));
export function call(name,args) {switch(name){case "__ink_reverse_0_append":case "__ink_reverse_0_seed":case "__ink_reverse_0_binary":case "__ink_reverse_0_unary":case "__ink_reverse_0_add":case "__ink_reverse_0_back_node":case "__ink_reverse_0_back_step":case "__ink_reverse_4":case "__ink_reverse_1":throw new Error('temporary storage is internal to a pure invocation');}return functions[name](...args);}
// Shared bounded binary codec; generated code supplies exact descriptors.
export const valueWireFormat='ink-value-wire-v1';
// A connection agrees on the complete value schema before using this format.
// Version byte + schema-directed fields; schema identity is out of band.
export const compactValueWireFormat='ink-value-session-v1';
const wireMagic=Uint8Array.of(73,78,75,86,65,76,0,1);
const wireEncoder=new TextEncoder(),wireDecoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const wireDefaults=Object.freeze({bytes:16777216,nodes:1000000,depth:128}),wireDefaultOptions=Object.freeze({});
const wireDecimal=s=>typeof s==='string'&&/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(s);
function wireLimits(options){if(options===wireDefaultOptions||options===wireDefaults)return wireDefaults;const l={...wireDefaults,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>wireDefaults[k])throw Error('wire hard resource limit');return l;}
const wireFloat=new DataView(new ArrayBuffer(4));
function wireDecodeText(bytes,start,end){
 if(end-start<=16){let text='';for(let i=start;i<end;i++){const byte=bytes[i];if(byte>=128)return wireDecoder.decode(bytes.subarray(start,end));text+=String.fromCharCode(byte);}return text;}
 return wireDecoder.decode(bytes.subarray(start,end));
}
function wireUtf8Length(text){let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const wireOwn=(v,k)=>v!==null&&typeof v==='object'&&Object.hasOwn(v,k);
const wireTagged=(v,k)=>wireOwn(v,k)&&Object.keys(v).length===1;
const wireDouble=new DataView(new ArrayBuffer(8));
function wireF64Bits(v){
 if(typeof v==='number'&&Number.isFinite(v)){wireDouble.setFloat64(0,v,true);return wireDouble.getBigUint64(0,true);}
 if(!wireTagged(v,'F64Bits'))wireInvalidValue();const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))wireInvalidValue();
 const bits=BigInt(text);if(bits>18446744073709551615n)wireInvalidValue();return bits;
}
const wireCanonical=v=>Array.isArray(v)?'['+v.map(wireCanonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort((a,b)=>{const x=Array.from(a,c=>c.codePointAt(0)),y=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]-y[i];return x.length-y.length;}).map(k=>JSON.stringify(k)+':'+wireCanonical(v[k])).join(',')+'}':JSON.stringify(v);
export async function createValueCodec(root,named={}){
 const used=new Set(),budget={nodes:100000};
 function check(t,d=0){
  if(d>64||--budget.nodes<0)throw Error('wire descriptor limit');
  const keys={u32:['kind'],u64:['kind'],i32:['kind'],f32:['kind'],f64:['kind'],bool:['kind'],unit:['kind'],string:['kind'],int:['kind'],id:['kind','name'],ref:['kind','name'],enum:['kind','name','variants'],record:['kind','name','fields'],list:['kind','element'],option:['kind','element'],vector:['kind','element','size'],result:['kind','ok','error']}[t?.kind];
  if(!keys||Object.keys(t).length!==keys.length||keys.some(k=>!Object.hasOwn(t,k)))throw Error('invalid wire descriptor');
  if(keys.includes('name')&&(typeof t.name!=='string'||!t.name.isWellFormed()))throw Error('invalid descriptor name');
  if(t.kind==='ref'){if(!used.has(t.name)){used.add(t.name);if(named[t.name]?.kind!=='record'||named[t.name].name!==t.name)throw Error('unresolved wire reference');check(named[t.name],d+1);}}
  if(t.kind==='record'){if(!Array.isArray(t.fields))throw Error('wire fields');const names=new Set();for(const f of t.fields){if(Object.keys(f).length!==2||typeof f.name!=='string'||!f.name.isWellFormed()||names.has(f.name))throw Error('duplicate wire field');names.add(f.name);check(f.type,d+1);}}
  if(t.kind==='enum'&&(!Array.isArray(t.variants)||!t.variants.length||t.variants.length>64||t.variants.some(v=>typeof v!=='string'||!v.isWellFormed())||new Set(t.variants).size!==t.variants.length))throw Error('wire enum');
  if(['list','vector','option'].includes(t.kind)){if(t.kind==='vector'&&(!Number.isInteger(t.size)||t.size<1||t.size>64))throw Error('wire vector');check(t.element,d+1);}
  if(t.kind==='result'){check(t.ok,d+1);check(t.error,d+1);}
 }
 check(root);const names=Object.fromEntries([...used].sort().map(k=>[k,named[k]]));
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',wireEncoder.encode(wireCanonical({format:valueWireFormat,root,named:names}))));
 return new ValueCodec({format:valueWireFormat,root,named:names,identity:Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('')});
}
// Resolve immutable descriptor edges once. Logical validation traverses the
// literal schema; single-child nodes use a loop rather than recursive closures.
function wireValuePlan(codec){
 const seen=new WeakMap();let remaining=100000;
 const build=type=>{
  const t=codec.resolve(type);if(seen.has(t))return seen.get(t);
  if(--remaining<0)throw Error('wire descriptor limit');const p={kind:t.kind,type:t,decode:null,decodeCompact:null};seen.set(t,p);
  if(t.kind==='record')p.fields=t.fields.map(f=>({name:f.name,plan:build(f.type)}));
  if(t.kind==='list'||t.kind==='vector'||t.kind==='option')p.element=build(t.element);
  if(t.kind==='result'){p.ok=build(t.ok);p.error=build(t.error);}
  return p;
 };return build(codec.descriptor.root);
}
function wireBindDecodePlan(root,compact=false){
 const seen=new Set(),pending=[root];let flags=0;
 while(pending.length){
  const p=pending.pop();if(seen.has(p))continue;seen.add(p);if(compact)p.decodeCompact=compactDecodeOperation(p);else p.decode=wireDecodeOperation(p);
  if(p.fields?.length>4)flags|=1;
  if(p.kind==='u32'||p.kind==='i32'||p.kind==='u64'||p.kind==='f32'||p.kind==='f64')flags|=2;
  if(p.fields)for(const f of p.fields)pending.push(f.plan);
  if(p.element)pending.push(p.element);
  if(p.ok){pending.push(p.ok);pending.push(p.error);}
 }
 return flags|4;
}
// Select literal descriptor operations once, without runtime source generation
// or eval. Recursive edges call the completed plan. The generic scanner remains
// the visitor/validation path and an independent materialisation implementation.
function wireReadOperation(p){
 const t=p.type;
 let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':read=(r,end)=>{r.size(end,4);const value={F32Bits:r.view.getUint32(r.cursor,true)};r.cursor=end;return value;};break;
  case 'f64':read=(r,end)=>{r.size(end,8);const value={F64Bits:r.view.getBigUint64(r.cursor,true).toString()};r.cursor=end;return value;};break;
  case 'u64':read=(r,end)=>{r.size(end,8);const value=r.view.getBigUint64(r.cursor,true);r.cursor=end;return value;};break;
  case 'string':read=(r,end)=>r.text(end);break;
  case 'int':read=(r,end)=>{const text=r.text(end);if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=(r,end)=>{const text=r.text(end);if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=(r,end)=>{const text=r.text(end);if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{
    if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;
    if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');
    const values=new Array(n);for(let i=0;i<n;i++)values[i]=element.decode(r,end,d+1);return values;
   };break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1)});break;
    case 2:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1)});break;
    case 3:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1)});break;
    case 4:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1),[fs[3].name]:fs[3].plan.decode(r,end,d+1)});break;
    default:read=(r,end,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decode(r,end,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,end,d)=>{const tag=r.tag(end);return tag?{Some:p.element.decode(r,end,d+1)}:{None:null};};break;
  case 'result':read=(r,end,d)=>r.tag(end)?{Err:p.error.decode(r,end,d+1)}:{Ok:p.ok.decode(r,end,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function wireDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=wireReadOperation(field.plan),name=field.name;
  return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),childEnd=r.enter(end,d+1),item=read(r,childEnd,d+1);if(r.cursor!==childEnd)throw Error('trailing wire frame bytes');const value={[name]:item};if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
 }
 const read=wireReadOperation(p);
 return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
}
class WireDecodeCursor{
 constructor(bytes,view,limits){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
// Bind literal validation and postorder visitation once for every descriptor.
// No logical carriers are allocated; projection still validates every child.
function wireScanPlan(root){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,scan:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.scan=wireScanOperation(p);return p;
 };
 return build(root);
}
function wireScanOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':case 'f64':case 'u64':{const size=p.kind==='f32'?4:8;read=(r,end)=>{r.size(end,size);r.cursor=end;};break;}
  case 'string':read=(r,end)=>{let i=r.cursor;while(i<end&&r.bytes[i]<128)i++;if(i<end)wireDecoder.decode(r.bytes.subarray(r.cursor,end));r.cursor=end;};break;
  case 'int':case 'id':case 'enum':read=(r,end)=>{const text=r.text(end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');for(let i=0;i<n;i++)element.scan(r,end,d+1);};break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>{};break;
    case 1:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);};break;
    case 2:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);};break;
    case 3:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);};break;
    case 4:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);fs[3].plan.scan(r,end,d+1);};break;
    default:read=(r,end,d)=>{for(const f of fs)f.plan.scan(r,end,d+1);};
   }break;
  }
  case 'option':read=(r,end,d)=>{if(r.tag(end))p.element.scan(r,end,d+1);};break;
  case 'result':read=(r,end,d)=>{(r.tag(end)?p.error:p.ok).scan(r,end,d+1);};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return (r,parentEnd,d)=>{
  const end=r.enter(parentEnd,d),start=r.cursor,value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');
  const visitor=r.visitor;if(visitor&&(!r.selected||r.selected.has(t.name))){if(r.spans)visitor(t,r.bytes,start,end,d);else visitor(t,r.bytes.subarray(start,end),d);}
  return value;
 };
}
// Separate methods keep decoding's cursor callsites monomorphic. Both cursors
// are checked against the independent generic scanner and malformed fixtures.
class WireScanCursor{
 constructor(bytes,view,limits,visitor,selected,spans){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.visitor=visitor;this.selected=selected;this.spans=spans;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
function compactReadOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=()=>null;break;
  case 'bool':read=r=>{r.require(1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':case 'i32':read=r=>{r.require(4);const n=p.kind==='u32'?r.view.getUint32(r.cursor,true):r.view.getInt32(r.cursor,true);r.cursor+=4;return n;};break;
  case 'f32':read=r=>{r.require(4);const n=r.view.getUint32(r.cursor,true);r.cursor+=4;return {F32Bits:n};};break;
  case 'f64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return {F64Bits:n.toString()};};break;
  case 'u64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return n;};break;
  case 'string':read=r=>r.text();break;
  case 'int':read=r=>{const text=r.text();if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=r=>{const text=r.text();if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=r=>{const text=r.text();if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':read=(r,d)=>{const n=r.count();if(n>r.remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');const values=new Array(n);for(let i=0;i<n;i++)values[i]=p.element.decodeCompact(r,d+1);return values;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1)});break;
    case 2:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1)});break;
    case 3:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1)});break;
    case 4:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1),[fs[3].name]:fs[3].plan.decodeCompact(r,d+1)});break;
    default:read=(r,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decodeCompact(r,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,d)=>r.tag()?{Some:p.element.decodeCompact(r,d+1)}:{None:null};break;
  case 'result':read=(r,d)=>r.tag()?{Err:p.error.decodeCompact(r,d+1)}:{Ok:p.ok.decodeCompact(r,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function compactDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=compactReadOperation(field.plan),name=field.name;
  return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');if(d+1>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return {[name]:read(r,d+1)};};
 }
 const read=compactReadOperation(p);
 return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return read(r,d);};
}
class CompactDecodeCursor{
 constructor(bytes,limits,flags){this.bytes=bytes;this.view=flags&2?new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength):null;this.cursor=1;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 require(n){if(n>this.bytes.length-this.cursor)throw Error('truncated compact value');}
 count(){
  if(this.cursor>=this.bytes.length)throw Error('truncated compact value');
  const first=this.bytes[this.cursor++];if(first<128)return first;
  let value=first&127,scale=128;
  for(let i=1;i<5;i++){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const byte=this.bytes[this.cursor++];if(i===4&&byte>15)throw Error('compact count overflow');value+=(byte&127)*scale;if(byte<128){if(byte===0)throw Error('noncanonical compact count');return value;}scale*=128;}throw Error('compact count overflow');
 }
 tag(){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const tag=this.bytes[this.cursor++];if(tag>1)throw Error('wire sum tag');return tag;}
 text(){const n=this.count();this.require(n);const start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
function wireInvalidValue(){throw Error('invalid value for wire schema');}
// Capture has the canonical logical meaning of decode(encode(value)), without
// allocating wire bytes. A separate plan leaves validation/decoder hot shapes
// unchanged and never retains host input containers between calls.
function wireCapturePlan(root,checked=true){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,capture:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({name:f.name,plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.capture=checked?wireCaptureOperation(p):wireCopyOperation(p);return p;
 };return build(root);
}
function wireCaptureOperation(p){
 const t=p.type;let copy;
 switch(p.kind){
  case 'unit':copy=v=>{if(v!==null)wireInvalidValue();return null;};break;
  case 'bool':copy=(v,r)=>{if(typeof v!=='boolean')wireInvalidValue();r.add(1);return v;};break;
  case 'u32':case 'i32':{
   const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
   copy=(v,r)=>{if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();r.add(4);return v===0?0:v;};break;
  }
  case 'u64':copy=(v,r)=>{const kind=typeof v;if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();r.add(8);return n;};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'int':case 'id':case 'enum':copy=(v,r)=>{const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;if(typeof text!=='string'||!text.isWellFormed()||text.length>r.limit)wireInvalidValue();if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();r.add(wireUtf8Length(text));return p.kind==='int'?{Int:text}:text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   copy=(v,r,d)=>{if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();const n=v.length;if(n>r.remaining||size!==null&&n!==size)wireInvalidValue();r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=element.capture(v[i],r,d+1);return out;};break;
  }
  case 'record':{
   const fs=p.fields;let fields;
   switch(fs.length){
    case 0:fields=()=>({});break;
    case 1:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:fields=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }
   copy=(v,r,d)=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();for(const f of fs)if(!wireOwn(v,f.name))wireInvalidValue();return fields(v,r,d);};break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'None')&&v.None===null)return {None:null};if(wireTagged(v,'Some'))return {Some:p.element.capture(v.Some,r,d+1)};wireInvalidValue();};break;
  case 'result':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'Ok'))return {Ok:p.ok.capture(v.Ok,r,d+1)};if(wireTagged(v,'Err'))return {Err:p.error.capture(v.Err,r,d+1)};wireInvalidValue();};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
class WireCaptureCursor{
 constructor(limits){this.remaining=limits.nodes;this.depth=limits.depth;this.limit=limits.bytes;this.bytes=40;this.add(0);}
 add(n){this.bytes+=n;if(this.bytes>this.limit)throw Error('wire byte limit');}
 enter(depth,bytes){if(depth>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.add(bytes);}
 text(value){if(value.length>this.limit)throw Error('wire byte limit');this.add(wireUtf8Length(value));}
}
// Literal lowerers share this fixed resource policy with logical capture.
export function createValueCaptureBudget(options=wireDefaultOptions){return new WireCaptureCursor(wireLimits(options));}
// The trusted-value API has the same canonical copy and ownership semantics.
// Its caller supplies a stable value accepted by validateValue. Shape/range
// checks remain at external capture boundaries; resource limits still apply.
function wireCopyOperation(p){
 let copy;
 switch(p.kind){
  case 'unit':copy=()=>null;break;
  case 'bool':copy=(v,r)=>{r.add(1);return v;};break;
  case 'u32':copy=(v,r)=>{r.add(4);return v>>>0;};break;
  case 'i32':copy=(v,r)=>{r.add(4);return v|0;};break;
  case 'u64':copy=(v,r)=>{r.add(8);return BigInt(v);};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'){wireFloat.setFloat32(0,v,true);bits=wireFloat.getUint32(0,true);}else bits=v.F32Bits;r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'id':case 'enum':copy=(v,r)=>{r.add(wireUtf8Length(v));return v;};break;
  case 'int':copy=(v,r)=>{const text=typeof v==='bigint'?v.toString():v.Int;r.add(wireUtf8Length(text));return {Int:text};};break;
  case 'list':case 'vector':copy=(v,r,d)=>{const n=v.length;if(n>r.remaining)throw Error('wire sequence size');r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=p.element.capture(v[i],r,d+1);return out;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:copy=()=>({});break;
    case 1:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:copy=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'None')&&v.None===null?{None:null}:{Some:p.element.capture(v.Some,r,d+1)};};break;
  case 'result':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'Ok')?{Ok:p.ok.capture(v.Ok,r,d+1)}:{Err:p.error.capture(v.Err,r,d+1)};};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
// Emit the cached literal schema with one forward writer. Each value is checked
// where it is consumed; byte bounds belong to the writer, not a second size walk.
function wireEncodeValue(root,value,l,w){
 let remaining=l.nodes;const depthLimit=l.depth;
 const node=(p,v,d)=>{
  if(d>depthLimit||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type,start=w.beginNode();
  switch(p.kind){
   case 'unit':if(v!==null)wireInvalidValue();break;
   case 'bool':if(typeof v!=='boolean')wireInvalidValue();w.byte(+v);break;
   case 'u32':case 'i32':{
    const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
    if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();w.word(v>>>0);break;
   }
   case 'u64':{
    const kind=typeof v;
    if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
    const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();w.wide(n);break;
   }
   case 'f64':w.wide(wireF64Bits(v));break;
   case 'f32':{
    let bits;
    if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}
    else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
    w.word(bits);break;
   }
   case 'string':case 'int':case 'id':case 'enum':{
    const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
    if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&(typeof text!=='string'||!/^[0-9a-f]{32}$/.test(text))||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
    w.text(text);break;
   }
   case 'list':case 'vector':{
    if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
    if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
    w.count(v.length);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);break;
   }
   case 'record':{
    const fs=p.fields;
    if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
    for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
    for(let i=0;i<fs.length;i++){const f=fs[i];node(f.plan,v[f.name],d+1);}break;
   }
   case 'option':{
    if(wireTagged(v,'None')&&v.None===null)w.byte(0);
    else if(wireTagged(v,'Some')){w.byte(1);node(p.element,v.Some,d+1);}else wireInvalidValue();break;
   }
   case 'result':{
    if(wireTagged(v,'Ok')){w.byte(0);node(p.ok,v.Ok,d+1);}
    else if(wireTagged(v,'Err')){w.byte(1);node(p.error,v.Err,d+1);}else wireInvalidValue();break;
   }
   default:throw Error('unsupported wire kind');
  }
  w.endNode(start);
 };
 node(root,value,0);
}
function wireCheckValue(root,value,l){
 let remaining=l.nodes,total=40;
 const add=n=>{total+=n;if(total>l.bytes)throw Error('wire byte limit');};
 const node=(p,v,d)=>{
  while(true){
   if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
   const t=p.type;
   switch(p.kind){
    case 'unit':if(v!==null)wireInvalidValue();add(4);return;
    case 'bool':if(typeof v!=='boolean')wireInvalidValue();add(5);return;
    case 'u32':case 'i32':{
     const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
     if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();add(8);return;
    }
    case 'u64':{
     const kind=typeof v;
     if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
     const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();add(12);return;
    }
    case 'f64':wireF64Bits(v);add(12);return;
    case 'f32':{
     if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();}
     else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();const bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
     add(8);return;
    }
    case 'string':case 'int':case 'id':case 'enum':{
     const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
     if(typeof text!=='string'||!text.isWellFormed()||text.length>l.bytes)wireInvalidValue();
     if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
     add(4+wireUtf8Length(text));return;
    }
    case 'list':case 'vector':{
     if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
     if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
     add(8);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);return;
    }
    case 'record':{
     const fs=p.fields;
     if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
     for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
     add(4);if(!fs.length)return;
     for(let i=0;i<fs.length-1;i++)node(fs[i].plan,v[fs[i].name],d+1);
     const f=fs[fs.length-1];p=f.plan;v=v[f.name];d++;continue;
    }
    case 'option':{
     if(wireTagged(v,'None')&&v.None===null){add(5);return;}
     if(!wireTagged(v,'Some'))wireInvalidValue();add(5);p=p.element;v=v.Some;d++;continue;
    }
    case 'result':{
     if(wireTagged(v,'Ok')){add(5);p=p.ok;v=v.Ok;}
     else if(wireTagged(v,'Err')){add(5);p=p.error;v=v.Err;}else wireInvalidValue();
     d++;continue;
    }
    default:throw Error('unsupported wire kind');
   }
  }
 };
 node(root,value,0);if(total>l.bytes)throw Error('wire byte limit');
}
// A single cursor replaces per-node child closures and {end,value} temporaries.
// Projection filters limit callback materialisation, never schema validation.
function wireScanValue(root,bytes,view,l,materialize,visitor,selected,spans){
 let cursor=40,remaining=l.nodes;
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,parentEnd,d)=>{
  if(d>l.depth||--remaining<0||cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const t=p.type,start=cursor+4,end=start+view.getUint32(cursor,true);if(end>parentEnd)throw Error('truncated wire frame');cursor=start;let value;
  switch(p.kind){
   case 'unit':if(end-start!==0)throw Error('malformed wire scalar');value=null;break;
   case 'bool':if(end-start!==1)throw Error('malformed wire scalar');if(bytes[start]>1)throw Error('invalid wire Bool');value=!!bytes[start];cursor=end;break;
   case 'u32':case 'i32':if(end-start!==4)throw Error('malformed wire scalar');value=p.kind==='u32'?view.getUint32(start,true):view.getInt32(start,true);cursor=end;break;
   case 'f32':if(end-start!==4)throw Error('malformed wire scalar');if(materialize)value={F32Bits:view.getUint32(start,true)};cursor=end;break;
   case 'f64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value={F64Bits:view.getBigUint64(start,true).toString()};cursor=end;break;
   case 'u64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value=view.getBigUint64(start,true);cursor=end;break;
   case 'string':case 'int':case 'id':case 'enum':{
    if(p.kind==='string'&&!materialize){let i=start;while(i<end&&bytes[i]<128)i++;if(i<end)wireDecoder.decode(bytes.subarray(start,end));}
    else{const text=wireDecodeText(bytes,start,end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    cursor=end;break;
   }
   case 'list':case 'vector':{
    if(start+4>end)throw Error('wire list count');const n=view.getUint32(start,true);cursor+=4;
    if(n>remaining||n>Math.floor((end-cursor)/4)||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,end,d+1);if(materialize)value.push(child);}break;
   }
   case 'record':{
    const fs=p.fields;
    // Computed literal keys create own data properties even for __proto__ or
    // prototype setters. Common small records need no descriptor allocations.
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:value={};break;case 1:value={[fs[0].name]:node(fs[0].plan,end,d+1)};break;case 2:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1)};break;case 3:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1)};break;case 4:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1),[fs[3].name]:node(fs[3].plan,end,d+1)};break;}
    }else{if(materialize)value={};for(const f of fs){const child=node(f.plan,end,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}}break;
   }
   case 'option':case 'result':{
    if(start===end||bytes[cursor]>1)throw Error('wire sum tag');const tag=bytes[cursor++];
    if(p.kind==='option'&&tag===0){if(materialize)value={None:null};}
    else{const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,end,d+1);if(materialize)value={[label]:child};}break;
   }
   default:throw Error('unsupported wire kind');
  }
  if(cursor!==end)throw Error('trailing wire frame bytes');
  if(visitor&&(!selected||selected.has(t.name))){if(spans)visitor(t,bytes,start,end,d);else visitor(t,bytes.subarray(start,end),d);}
  return value;
 };
 const result=node(root,bytes.length,0);if(cursor!==bytes.length)throw Error('trailing wire bytes');return result;
}
export class ValueCodec{
 #hash;
 #header;
 #headerWords;
 #descriptor;
 #valuePlan;
 #compactCodec;
 #encoder;
 #decodeBound=0;
 #scanPlan=null;
 #capturePlan=null;
 #copyPlan=null;
 get descriptor(){return this.#descriptor;}
 constructor(descriptor){
  // This synchronous path is for compiler-generated immutable metadata. For
  // untrusted descriptors use createValueCodec and compare the computed identity.
  if(descriptor?.format!==valueWireFormat||!/^[0-9a-f]{64}$/.test(descriptor.identity))throw Error('invalid wire schema');
  this.#descriptor=structuredClone(descriptor);this.#hash=Uint8Array.from(descriptor.identity.match(/../g),s=>parseInt(s,16));
  this.#header=new Uint8Array(40);this.#header.set(wireMagic);this.#header.set(this.#hash,8);
  const headerView=new DataView(this.#header.buffer);this.#headerWords=Array.from({length:10},(_,i)=>headerView.getUint32(i*4,true));
  const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}};freeze(this.descriptor);this.#valuePlan=wireValuePlan(this);
 }
 resolve(t){for(let i=0;i<64;i++){if(t.kind!=='ref')return t;t=this.descriptor.named[t.name];if(!t)throw Error('wire reference');}throw Error('wire reference cycle');}
 validateValue(value,options=wireDefaultOptions){wireCheckValue(this.#valuePlan,value,wireLimits(options));return true;}
 capture(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#capturePlan??=wireCapturePlan(this.#valuePlan);return this.#capturePlan.capture(value,new WireCaptureCursor(limits),0);}
 copy(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#copyPlan??=wireCapturePlan(this.#valuePlan,false);return this.#copyPlan.capture(value,new WireCaptureCursor(limits),0);}
 compact(){return this.#compactCodec??=new CompactValueCodec(this);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new WireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.bytes(this.#header);wireEncodeValue(this.#valuePlan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new WireEncoder(options);w.bytes(wireMagic);w.bytes(this.#hash);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 scan(bytes,options=wireDefaultOptions,materialize=false,visitor=null,names=null,spans=false){
  const l=wireLimits(options);if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<44||bytes.length>l.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==this.#headerWords[i])throw Error('wire format or schema mismatch');
  if(names!==null&&(!Array.isArray(names)||names.length>100000||names.some(n=>typeof n!=='string')))throw Error('wire visitor names');
  if(materialize&&!visitor){this.#decodeBound||=wireBindDecodePlan(this.#valuePlan);const cursor=new WireDecodeCursor(bytes,view,l);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#valuePlan.decode(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  if(!materialize){this.#scanPlan??=wireScanPlan(this.#valuePlan);const cursor=new WireScanCursor(bytes,view,l,visitor,names===null?null:new Set(names),spans),value=this.#scanPlan.scan(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  return wireScanValue(this.#valuePlan,bytes,view,l,materialize,visitor,names===null?null:new Set(names),spans);
 }
 visit(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names);}
 visitSpans(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names,true);}
 validate(bytes,options=wireDefaultOptions){this.scan(bytes,options,false);return true;}
 decode(bytes,options=wireDefaultOptions){return this.scan(bytes,options,true);}
}

// Bounded forward emission avoids building and repeatedly joining child buffers.
class WireEncoder{
 #data=new Uint8Array(256);#view=new DataView(this.#data.buffer);#at=0;#remaining;#depth=0;#byteLimit;#depthLimit;
 active=false;
 constructor(options){this.reset(options);}
 reset(options){const limits=wireLimits(options);this.#byteLimit=limits.bytes;this.#depthLimit=limits.depth;this.#remaining=limits.nodes;this.#depth=0;this.#at=0;this.active=true;}
 get capacity(){return this.#data.length;}
 get position(){return this.#at;}
 beginNode(){const at=this.#at;this.word(0);return at;}
 endNode(at){this.patchWord(at,this.#at-at-4);}
 count(n){this.word(n);}
 beginCount(){const at=this.position;this.count(0);return at;}
 endCount(at,n){this.patchWord(at,n);}
 #reserve(size){
  const end=this.#at+size;if(end>this.#byteLimit)throw Error('wire byte limit');
  if(end>this.#data.length){const next=new Uint8Array(Math.min(this.#byteLimit,Math.max(end,this.#data.length*2)));next.set(this.#data.subarray(0,this.#at));this.#data=next;this.#view=new DataView(next.buffer);}
  return end;
 }
 bytes(bytes){const end=this.#reserve(bytes.length);this.#data.set(bytes,this.#at);this.#at=end;}
 byte(n){if(!Number.isInteger(n)||n<0||n>255)throw Error('wire byte range');this.#reserve(1);this.#data[this.#at++]=n;}
 word(n){if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire word range');const end=this.#reserve(4);this.#view.setUint32(this.#at,n,true);this.#at=end;}
 wide(n){if(typeof n!=='bigint'||n<0n||n>18446744073709551615n)throw Error('wire wide range');const end=this.#reserve(8);this.#view.setBigUint64(this.#at,n,true);this.#at=end;}
 text(text,count=false){
  if(typeof text!=='string')throw Error('wire Unicode');
  if(text.length<=16){
   let ascii=true;for(let i=0;i<text.length;i++)if(text.charCodeAt(i)>=128){ascii=false;break;}
   if(ascii){if(count)this.count(text.length);const end=this.#reserve(text.length);for(let i=0;i<text.length;i++)this.#data[this.#at+i]=text.charCodeAt(i);this.#at=end;return;}
  }
  if(!text.isWellFormed())throw Error('wire Unicode');const size=wireUtf8Length(text);if(count)this.count(size);
  const end=this.#reserve(size),r=wireEncoder.encodeInto(text,this.#data.subarray(this.#at,end));if(r.read!==text.length||r.written!==size)throw Error('wire UTF-8 size');this.#at=end;
 }
 patchWord(at,n){if(!Number.isInteger(at)||at<0||at+4>this.#at||!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire patch offset');this.#view.setUint32(at,n,true);}
 patchByte(at,n){if(!Number.isInteger(at)||at<0||at>=this.#at||!Number.isInteger(n)||n<0||n>255)throw Error('wire patch offset');this.#data[at]=n;}
 replace(at,removed,bytes){
  if(!Number.isInteger(at)||!Number.isInteger(removed)||at<0||removed<0||at+removed>this.#at||!(bytes instanceof Uint8Array))throw Error('wire replacement range');
  const extra=bytes.length-removed,end=extra>0?this.#reserve(extra):this.#at+extra;
  this.#data.copyWithin(at+bytes.length,at+removed,this.#at);this.#data.set(bytes,at);this.#at=end;
 }
 // Literal generated writers use balanced frames without per-node callbacks.
 // An exception abandons this invocation; encodeWith never reuses its writer.
 openFrame(){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;return at;}
 closeFrame(at){if(this.#depth===0)throw Error('wire frame boundary');this.#depth--;this.endNode(at);}
 frame(emit){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;try{emit(this);}finally{this.#depth--;}this.endNode(at);}
 reorder(start,spans){
  const sorted=spans.slice().sort((a,b)=>a[0]-b[0]);let at=start;
  for(const [a,b] of sorted){if(!Number.isInteger(a)||!Number.isInteger(b)||a!==at||b<a)throw Error('wire span permutation');at=b;}
  if(start<0||start>this.#at||at!==this.#at)throw Error('wire span permutation');
  if(spans.every((s,i)=>s===sorted[i]))return;
  const copy=this.#data.slice(start,this.#at);at=start;for(const [a,b] of spans){this.#data.set(copy.subarray(a-start,b-start),at);at+=b-a;}
 }
 finish(){if(this.#depth!==0)throw Error('wire frame boundary');return this.#data.slice(0,this.#at);}
}

class CompactWireEncoder extends WireEncoder{
 beginNode(){return 0;}
 endNode(){}
 endCount(at,n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  if(n<128){this.patchByte(at,n);return;}
  const bytes=[];while(n>=128){bytes.push(n%128+128);n=Math.floor(n/128);}bytes.push(n);this.replace(at,1,Uint8Array.from(bytes));
 }
 count(n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  while(n>=128){this.byte(n%128+128);n=Math.floor(n/128);}this.byte(n);
 }
 text(text){super.text(text,true);}
}

function compactScanValue(root,bytes,l,materialize){
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let cursor=1,remaining=l.nodes;
 const require=n=>{if(n>bytes.length-cursor)throw Error('truncated compact value');};
 const count=()=>{
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   require(1);const byte=bytes[cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }throw Error('compact count overflow');
 };
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,d)=>{
  if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type;let value;
  switch(p.kind){
   case 'unit':return null;
   case 'bool':require(1);if(bytes[cursor]>1)throw Error('invalid wire Bool');return !!bytes[cursor++];
   case 'u32':case 'i32':require(4);value=p.kind==='u32'?view.getUint32(cursor,true):view.getInt32(cursor,true);cursor+=4;return value;
   case 'f32':require(4);if(materialize)value={F32Bits:view.getUint32(cursor,true)};cursor+=4;return value;
   case 'f64':require(8);if(materialize)value={F64Bits:view.getBigUint64(cursor,true).toString()};cursor+=8;return value;
   case 'u64':require(8);if(materialize)value=view.getBigUint64(cursor,true);cursor+=8;return value;
   case 'string':case 'int':case 'id':case 'enum':{
    const n=count();require(n);const start=cursor;cursor+=n;
    if(p.kind==='string'&&!materialize){let i=start;while(i<cursor&&bytes[i]<128)i++;if(i<cursor)wireDecoder.decode(bytes.subarray(start,cursor));}
    else{const text=wireDecodeText(bytes,start,cursor);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    return value;
   }
   case 'list':case 'vector':{
    const n=count();if(n>remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,d+1);if(materialize)value.push(child);}return value;
   }
   case 'record':{
    const fs=p.fields;
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:return {};case 1:return {[fs[0].name]:node(fs[0].plan,d+1)};case 2:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1)};case 3:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1)};case 4:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1),[fs[3].name]:node(fs[3].plan,d+1)};}
    }
    if(materialize)value={};for(const f of fs){const child=node(f.plan,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}return value;
   }
   case 'option':case 'result':{
    require(1);const tag=bytes[cursor++];if(tag>1)throw Error('wire sum tag');
    if(p.kind==='option'&&tag===0)return materialize?{None:null}:undefined;
    const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,d+1);
    return materialize?{[label]:child}:undefined;
   }
   default:throw Error('unsupported wire kind');
  }
 };
 const value=node(root,0);if(cursor!==bytes.length)throw Error('trailing compact bytes');return value;
}

// General transport codec, independent of source rewrites and checkpoints.
// The sender/receiver must negotiate this exact identity and format. There is
// deliberately no claim that the bytes themselves identify their schema.
export class CompactValueCodec{
 #source;#plan;#encoder;#decodeBound=0;
 get format(){return compactValueWireFormat;}
 get identity(){return this.#source.descriptor.identity;}
 constructor(valueCodec){if(!(valueCodec instanceof ValueCodec))throw Error('compact codec requires a checked value codec');this.#source=valueCodec;this.#plan=wireValuePlan(valueCodec);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new CompactWireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.byte(1);wireEncodeValue(this.#plan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new CompactWireEncoder(options);w.byte(1);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 #scan(bytes,options,materialize){
  const l=wireLimits(options);
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<1||bytes.length>l.bytes)throw Error('wire byte limit or header');
  if(bytes[0]!==1)throw Error('compact format mismatch');
  if(materialize){this.#decodeBound||=wireBindDecodePlan(this.#plan,true);const cursor=new CompactDecodeCursor(bytes,l,this.#decodeBound);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#plan.decodeCompact(cursor,0);if(cursor.cursor!==bytes.length)throw Error('trailing compact bytes');return value;}
  return compactScanValue(this.#plan,bytes,l,materialize);
 }
 decode(bytes,options=wireDefaultOptions){return this.#scan(bytes,options,true);}
 validate(bytes,options=wireDefaultOptions){this.#scan(bytes,options,false);return true;}
}

// Compiler materialisers consume already validated bytes synchronously. This
// factory is for trusted emitted code, not untrusted descriptor/callback data.
// The complete generic validator runs before any compiler reader is invoked.
class ValidatedValueReader{
 constructor(bytes,compact){this.bytes=bytes;this.view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);this.cursor=compact?1:40;this.compact=compact;}
 frame(){if(this.compact)return 0;const end=this.cursor+4+this.view.getUint32(this.cursor,true);this.cursor+=4;return end;}
 finish(end){if(!this.compact&&this.cursor!==end)throw Error('compiled reader frame mismatch');}
 byte(){return this.bytes[this.cursor++];}
 word(){const n=this.view.getUint32(this.cursor,true);this.cursor+=4;return n;}
 signed(){const n=this.view.getInt32(this.cursor,true);this.cursor+=4;return n;}
 wide(){const n=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return n;}
 count(){if(!this.compact)return this.word();let n=0,scale=1,byte;do{byte=this.byte();n+=(byte&127)*scale;scale*=128;}while(byte>=128);return n;}
 text(end){const n=this.compact?this.count():end-this.cursor,start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
class CompiledCompactValueCodec extends CompactValueCodec{
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,true),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
}
class CompiledValueCodec extends ValueCodec{
 #read;#compiledCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,false),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
 compact(){return this.#compiledCompact??=new CompiledCompactValueCodec(this,this.#read);}
}
export function createCompiledValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new CompiledValueCodec(descriptor,read);}

// Trusted literal materialisers may use this checked reader to validate and
// construct in one traversal. The emitter must use frame/finish at every source
// node, typed text reads and counted sequence reads; arbitrary callbacks do not
// establish a schema correspondence proof. The independent scanner remains the
// validation oracle and the original factory retains its pre-validation path.
function literalValueHeader(identity){
 const bytes=new Uint8Array(40);bytes.set(wireMagic);
 for(let i=0;i<32;i++)bytes[i+8]=parseInt(identity.slice(i*2,i*2+2),16);
 const view=new DataView(bytes.buffer),words=new Uint32Array(10);
 for(let i=0;i<10;i++)words[i]=view.getUint32(i*4,true);
 return words;
}
class CheckedLiteralValueReader {
 constructor(bytes,header,compact,limits){
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<(compact?1:44)||bytes.length>limits.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  if(compact){if(bytes[0]!==1)throw Error('compact format mismatch');}
  else for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==header[i])throw Error('wire format or schema mismatch');
  this.bytes=bytes;this.view=view;
  this.cursor=compact?1:40;this.compact=compact;this.remaining=limits.nodes;this.depth=limits.depth;this.ends=[];
 }
 require(n){if(this.cursor+n>(this.ends.at(-1)??this.bytes.length))throw Error('truncated wire frame');}
 frame(){
  if(this.ends.length>this.depth||--this.remaining<0)throw Error('wire node or depth limit');
  let end=this.bytes.length;
  if(!this.compact){this.require(4);end=this.cursor+4+this.view.getUint32(this.cursor,true);this.require(end-this.cursor);this.cursor+=4;}
  this.ends.push(end);return this.compact?0:end;
 }
 finish(end){
  if(!this.ends.length||!this.compact&&(this.ends.at(-1)!==end||this.cursor!==end))throw Error('compiled reader frame mismatch');
  this.ends.pop();
 }
 byte(){this.require(1);const value=this.bytes[this.cursor++];if(value>1)throw Error('wire sum tag or Bool');return value;}
 word(){this.require(4);const value=this.view.getUint32(this.cursor,true);this.cursor+=4;return value;}
 signed(){this.require(4);const value=this.view.getInt32(this.cursor,true);this.cursor+=4;return value;}
 wide(){this.require(8);const value=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return value;}
 rawCount(){
  if(!this.compact)return this.word();
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   this.require(1);const byte=this.bytes[this.cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }
  throw Error('compact count overflow');
 }
 count(size){
  const value=this.rawCount();
  if(value>this.remaining||size!==undefined&&value!==size)throw Error('wire sequence size');
  return value;
 }
 text(end,kind='string',variants){
  const size=this.compact?this.rawCount():end-this.cursor;
  this.require(size);const start=this.cursor;this.cursor+=size;
  const value=wireDecodeText(this.bytes,start,this.cursor);
  if(kind==='int'&&!wireDecimal(value)||kind==='id'&&!/^[0-9a-f]{32}$/.test(value)||kind==='enum'&&!variants.includes(value))throw Error('malformed wire text');
  return value;
 }
 complete(){if(this.ends.length||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
// Compact source nodes have no individual frame ends: retain the same checked
// depth/node order using a counter, with bounds against the complete buffer.
class CheckedCompactLiteralValueReader extends CheckedLiteralValueReader {
 constructor(bytes,limits){super(bytes,null,true,limits);this.level=0;}
 require(n){if(this.cursor+n>this.bytes.length)throw Error('truncated wire frame');}
 frame(){if(this.level>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.level++;return 0;}
 finish(_end){if(!this.level)throw Error('compiled reader frame mismatch');this.level--;}
 complete(){if(this.level||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
class FusedCompactValueCodec extends CompactValueCodec {
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedCompactLiteralValueReader(bytes,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
}
class FusedValueCodec extends ValueCodec {
 #read;#header;#fusedCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;this.#header=literalValueHeader(this.descriptor.identity);}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedLiteralValueReader(bytes,this.#header,false,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
 compact(){return this.#fusedCompact??=new FusedCompactValueCodec(this,this.#read);}
}
export function createFusedValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new FusedValueCodec(descriptor,read);}
// JSON text is a boundary adapter to an ordinary recursive Ink datatype.
// No JavaScript Number conversion occurs for JSON numeric tokens.
export function jsonNumberToken(s){return typeof s==='string'&&/^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/.test(s);}
// JSON numeric tokens have an ASCII grammar. Check validated UTF-8 spans
// directly, preserving exact lexemes without allocating a decoded String.
function jsonNumberSpan(bytes,lo,hi){
 let at=lo;if(bytes[at]===45)at++;
 if(at>=hi)return false;
 if(bytes[at]===48)at++;
 else{if(bytes[at]<49||bytes[at]>57)return false;do{at++;}while(at<hi&&bytes[at]>=48&&bytes[at]<=57);}
 if(at<hi&&bytes[at]===46){const start=++at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 if(at<hi&&(bytes[at]===69||bytes[at]===101)){at++;if(at<hi&&(bytes[at]===43||bytes[at]===45))at++;const start=at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 return at===hi;
}
const jsonWireEncoder=new TextEncoder();
// Scalar conversion completes before writer callbacks; no per-value byte array.
const jsonFloatScratch=new DataView(new ArrayBuffer(4));
function jsonUtf8Length(text){if(text.length>16&&!/[^\x00-\x7f]/.test(text))return text.length;let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const jsonLimits={bytes:16777216,nodes:1000000,depth:128};
const jsonQuoters=new WeakSet();
/** Explicit, bounded reuse of immutable JSON string quotes. Cache payload bytes
 * are UTF-16 storage estimates; entry caps bound separate Map/object overhead.
 * Logical output budgets are charged again on every use, including cache hits.
 */
export function createJsonQuoter({maxEntries=1024,maxBytes=131072}={}){
 if(!Number.isSafeInteger(maxEntries)||maxEntries<0||maxEntries>65536||!Number.isSafeInteger(maxBytes)||maxBytes<0||maxBytes>16777216)throw Error('JSON quote cache budget');
 const entries=new Map();let bytes=0,hits=0,misses=0;
 const token=value=>{
  const prior=entries.get(value);if(prior!==undefined){hits++;return prior;}
  if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid JSON String');
  misses++;const text=JSON.stringify(value),size=2*(value.length+text.length),quoted=Object.freeze({text,utf8Bytes:jsonUtf8Length(text)});
  if(maxEntries&&size<=maxBytes){
   while(entries.size&&(entries.size>=maxEntries||bytes+size>maxBytes)){const key=entries.keys().next().value;bytes-=2*(key.length+entries.get(key).text.length);entries.delete(key);}
   entries.set(value,quoted);bytes+=size;
  }
  return quoted;
 };
 const quoter=Object.freeze({
  token,
  quote(value){return token(value).text;},
  clear(){entries.clear();bytes=0;},
  stats(){return {entries:entries.size,payload_bytes:bytes,hits,misses};},
 });jsonQuoters.add(quoter);return quoter;
}
function checkedJsonLimits(options){const l={...jsonLimits,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>jsonLimits[k])throw Error('JSON hard resource limit');return l;}
function jsonVariant(index,item){let payload=index===0?{}:{item0:item};if(index<5)payload={Ok:payload};for(let i=0;i<index;i++)payload={Err:payload};return {payload};}
export function parseJson(text,options={}){return parseJsonValue(text,options,null);}
function parseJsonValue(text,options,boundary){
 const p=new JsonWireReader(text,options);
 const value=(d,wireDepth=0)=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){boundary?.node(0,wireDepth);p.at+=4;return jsonVariant(0,null);}if(c==='t'&&text.startsWith('true',p.at)){boundary?.node(1,wireDepth);p.at+=4;return jsonVariant(1,true);}if(c==='f'&&text.startsWith('false',p.at)){boundary?.node(1,wireDepth);p.at+=5;return jsonVariant(1,false);}
  if(c==='"'){boundary?.node(3,wireDepth);const item=p.string();boundary?.text(item);return jsonVariant(3,item);}
  if(c==='['){boundary?.node(4,wireDepth);p.at++;const xs=[];if(!p.eat(']'))while(true){xs.push(value(d+1,wireDepth+8));if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}return jsonVariant(4,xs);}
  if(c==='{'){boundary?.node(5,wireDepth);p.at++;const xs=[],seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary?.member(key,wireDepth);if(!p.eat(':'))throw Error('JSON object colon');xs.push({key,value:value(d+1,wireDepth+9)});if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}return jsonVariant(5,xs);}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();boundary?.node(2,wireDepth);boundary?.text(token);return jsonVariant(2,token);}
  throw Error('invalid JSON value');
 };
 const out=value(0);p.finish();return out;
}
export function stringifyJson(value,options={}){return stringifyJsonValue(value,options,null);}
function stringifyJsonValue(value,options,boundary){
 const l=checkedJsonLimits(options);let remaining=l.nodes,bytes=0,output='';
 const emit=s=>{bytes+=jsonUtf8Length(s);if(bytes>l.bytes)throw Error('JSON byte limit');output+=s;};
 const write=(v,d,wireDepth=0)=>{
  if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');if(!v||Object.keys(v).length!==1||!Object.hasOwn(v,'payload'))throw Error('invalid JSON record');let p=v.payload,index=0;
  while(index<5&&p&&Object.hasOwn(p,'Err')){if(Object.keys(p).length!==1||boundary&&Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Err;index++;}
  if(index<5){if(!p||Object.keys(p).length!==1||!Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Ok;}
  if(!p||Object.keys(p).length!==(index===0?0:1)||index>0&&!Object.hasOwn(p,'item0'))throw Error('invalid JSON payload');const item=p.item0;boundary?.node(index,wireDepth);
  switch(index){
   case 0:emit('null');break;
   case 1:if(typeof item!=='boolean')throw Error('invalid JSON Boolean');emit(item?'true':'false');break;
   case 2:if(!jsonNumberToken(item))throw Error('invalid JSON number');boundary?.text(item);emit(item);break;
   case 3:if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary?.text(item);emit(JSON.stringify(item));break;
   case 4:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Array');const count=item.length;let visited=0;emit('[');item.forEach((x,i)=>{visited++;if(i)emit(',');write(x,d+1,wireDepth+8);});if(visited!==count)throw Error('invalid JSON Array');emit(']');break;}
   case 5:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Object');const count=item.length,seen=new Set();let visited=0;emit('{');item.forEach((m,i)=>{visited++;if(!m||Object.keys(m).length!==2||typeof m.key!=='string'||!m.key.isWellFormed()||!Object.hasOwn(m,'value')||boundary&&!Object.hasOwn(m,'key'))throw Error('invalid JSON member');if(seen.has(m.key))throw Error('duplicate JSON object key');seen.add(m.key);boundary?.member(m.key,wireDepth);if(i)emit(',');emit(JSON.stringify(m.key));emit(':');write(m.value,d+1,wireDepth+9);});if(visited!==count)throw Error('invalid JSON Object');emit('}');break;}
  }
 };write(value,0);return output;
}
// The adapter's schema is the fixed recursive JSON library shape checked by
// JsonCodec. Charge its ordinary record/sum/list wire nodes while parsing or
// rendering, rather than interpreting and walking the completed tree again.
function jsonBoundaryBudget(options){
 const l=checkedJsonLimits(options);let remaining=l.nodes,total=40;
 const charge=(nodes,bytes,depth)=>{remaining-=nodes;total+=bytes;if(remaining<0||depth>l.depth)throw Error('wire node or depth limit');if(total>l.bytes)throw Error('wire byte limit');};
 return {
  node(index,depth){charge(index===0?3:index<4?index+4:8,index===0?13:index===1?23:index===2?27:index===3?32:41,depth+(index===0?2:index<4?index+3:7));},
  text(text){charge(0,jsonUtf8Length(text),0);},
  member(key,depth){charge(2,8+jsonUtf8Length(key),depth+9);},
 };
}
function jsonSameSchema(a,b){
 if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;
 const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>Object.hasOwn(b,k)&&jsonSameSchema(a[k],b[k]));
}
// Host-object conversion is opt-in and JavaScript-only. Inspect data properties
// rather than invoking getters/toJSON; reflection is not a sandbox for proxies.
function jsonJSKeys(value){
 if(!value||typeof value!=='object')throw Error('expected a plain JavaScript object');
 const prototype=Object.getPrototypeOf(value);
 if(prototype!==Object.prototype&&prototype!==null)throw Error('expected a plain JavaScript object');
 const keys=Reflect.ownKeys(value);
 if(keys.some(k=>typeof k!=='string'))throw Error('JavaScript symbol keys are unsupported');
 return keys;
}
function jsonJSData(value,key){
 const property=Object.getOwnPropertyDescriptor(value,key);
 if(!property||!property.enumerable||!Object.hasOwn(property,'value'))throw Error('expected an enumerable own data property');
 return property.value;
}
function jsonJSRecord(value,names){
 const keys=jsonJSKeys(value);
 if(keys.length!==names.length||keys.some(k=>!names.includes(k)))throw Error('invalid JSON record or variant');
}
function jsonJSArray(value,remaining){
 if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype)throw Error('expected a plain JavaScript array');
 const length=value.length;
 if(length>remaining)throw Error('JSON node limit');
 const keys=Reflect.ownKeys(value);
 if(keys.length!==length+1||keys.some(k=>typeof k!=='string'||k!=='length'&&(!/^(0|[1-9][0-9]*)$/.test(k)||Number(k)>=length)))throw Error('sparse or decorated JavaScript arrays are unsupported');
 return length;
}
function jsonFromJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),active=new WeakSet();let remaining=limits.nodes;
 const text=value=>{if(!value.isWellFormed())throw Error('invalid JSON Unicode');boundary.text(value);return value;};
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  if(value===null){boundary.node(0,wireDepth);return jsonVariant(0);}
  switch(typeof value){
   case 'boolean':boundary.node(1,wireDepth);return jsonVariant(1,value);
   case 'string':boundary.node(3,wireDepth);return jsonVariant(3,text(value));
   case 'number':
    if(!Number.isFinite(value))throw Error('non-finite JavaScript numbers are unsupported');
    boundary.node(2,wireDepth);return jsonVariant(2,text(Object.is(value,-0)?'-0':String(value)));
   case 'bigint':boundary.node(2,wireDepth);return jsonVariant(2,text(String(value)));
   case 'object':break;
   default:throw Error('unsupported JavaScript value');
  }
  if(active.has(value))throw Error('cyclic JavaScript value');
  active.add(value);
  try{
   if(Array.isArray(value)){
    boundary.node(4,wireDepth);const count=jsonJSArray(value,remaining),items=[];
    for(let i=0;i<count;i++)items.push(visit(jsonJSData(value,String(i)),depth+1,wireDepth+8));
    return jsonVariant(4,items);
   }
   boundary.node(5,wireDepth);const keys=jsonJSKeys(value),members=[];
   if(keys.length>remaining)throw Error('JSON node limit');
   for(const key of keys){
    if(!key.isWellFormed())throw Error('invalid JSON Unicode');
    boundary.member(key,wireDepth);
    members.push({key,value:visit(jsonJSData(value,key),depth+1,wireDepth+9)});
   }
   return jsonVariant(5,members);
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
function jsonDecimalKey(token){
 const [,sign,whole,fraction='',exponent='0']=/^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(token);
 const digits=(whole+fraction).replace(/^0+/,'');
 if(!digits)return '0';
 const trimmed=digits.replace(/0+$/,'');
 return sign+trimmed+'e'+(Number(exponent)-fraction.length+digits.length-trimmed.length);
}
function jsonToJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),mode=options?.numbers??'number',active=new WeakSet();let remaining=limits.nodes;
 if(!['number','bigint','string'].includes(mode))throw Error('unknown JavaScript number policy');
 const number=token=>{
  if(!jsonNumberToken(token))throw Error('invalid JSON number');
  boundary.text(token);
  if(mode==='string')return token;
  if(mode==='bigint')return BigInt(jsonInteger(token,4096));
  const result=Number(token);
  if(!Number.isFinite(result)||jsonDecimalKey(token)!==jsonDecimalKey(String(result)))throw Error('JSON number loses precision as JavaScript Number; choose numbers: bigint or string');
  return result;
 };
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  jsonJSRecord(value,['payload']);
  if(active.has(value))throw Error('cyclic JSON value');
  active.add(value);
  try{
   let payload=jsonJSData(value,'payload'),index=0;
   while(index<5&&Object.hasOwn(payload,'Err')){jsonJSRecord(payload,['Err']);payload=jsonJSData(payload,'Err');index++;}
   if(index<5){jsonJSRecord(payload,['Ok']);payload=jsonJSData(payload,'Ok');}
   jsonJSRecord(payload,index===0?[]:['item0']);boundary.node(index,wireDepth);
   const item=index===0?null:jsonJSData(payload,'item0');
   if(index===0)return null;
   if(index===1){if(typeof item!=='boolean')throw Error('invalid JSON Boolean');return item;}
   if(index===2)return number(item);
   if(index===3){if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary.text(item);return item;}
   const count=jsonJSArray(item,remaining);
   if(index===4){const out=[];for(let i=0;i<count;i++)out.push(visit(jsonJSData(item,String(i)),depth+1,wireDepth+8));return out;}
   const out={},seen=new Set();
   for(let i=0;i<count;i++){
    const member=jsonJSData(item,String(i));jsonJSRecord(member,['key','value']);const key=jsonJSData(member,'key');
    if(typeof key!=='string'||!key.isWellFormed())throw Error('invalid JSON member key');
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary.member(key,wireDepth);
    Object.defineProperty(out,key,{value:visit(jsonJSData(member,'value'),depth+1,wireDepth+9),enumerable:true,writable:true,configurable:true});
   }
   return out;
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
const jsonConstructionPaths=Object.freeze(Array.from({length:6},(_,index)=>Object.freeze([0,...Array(index).fill(1),...(index<5?[0]:[]),0])));
function parseJsonConstructed(text,options,builder){
 const p=new JsonWireReader(text,options);
 const paths=jsonConstructionPaths;
 const fused=typeof builder.openPath==='function';
 const begin=index=>{if(fused){builder.openPath(paths[index]);return;}for(const choice of paths[index])builder.open(choice);};
 const end=index=>{for(let i=0;i<(fused?1:index<5?index+3:7);i++)builder.close();};
 const leaf=(index,item)=>{if(typeof builder.scalarPath==='function'){builder.scalarPath(paths[index],item);return;}begin(index);builder.scalar(item);end(index);};
 const value=d=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){p.at+=4;if(typeof builder.emptyPath==='function')builder.emptyPath(paths[0]);else{begin(0);end(0);}return;}
  if(c==='t'&&text.startsWith('true',p.at)){p.at+=4;leaf(1,true);return;}
  if(c==='f'&&text.startsWith('false',p.at)){p.at+=5;leaf(1,false);return;}
  if(c==='"'){leaf(3,p.string());return;}
  if(c==='['){begin(4);builder.open(0);p.at++;if(!p.eat(']'))while(true){value(d+1);if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}builder.close();end(4);return;}
  if(c==='{'){begin(5);builder.open(0);p.at++;const seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');builder.open(0);builder.scalar(key);value(d+1);builder.close();if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}builder.close();end(5);return;}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();leaf(2,token);return;}
  throw Error('invalid JSON value');
 };
 value(0);p.finish();return builder.finish();
}
const jsonCompiledRenderers=new WeakMap();
function compiledJsonRenderer(json,codec,unwrap){
 if(typeof codec?.reducer!=='function')throw Error('compiled JSON reduction unavailable');
 const source=codec.resolve(codec.descriptor.root),root=json.values.descriptor.root;
 const selected=unwrap&&source.kind==='result'?codec.resolve(source.ok):source;
 if(!jsonSameSchema(root,selected)||unwrap&&source.kind!=='result')throw Error('compiled JSON schema mismatch');
 let variants=root.fields[0].type;const roles=new Map([[root.name,'root']]);
 let member;
 for(let index=0;index<6;index++){
  const branch=index<5?variants.ok:variants;roles.set(branch.name,index);
  if(index===5){member=branch.fields[0].type.element.name;roles.set(member,'member');}
  if(index<5)variants=variants.error;
 }
 const nodeRoles=new Map();
 return codec.reducer((node,index)=>{
  const role=roles.get(node.name);nodeRoles.set(index,role);
  if(node.kind==='record'){
   if(role==='root')return value=>value;
   if(role==='member')return (key,value,context)=>{
    const text=(context.quoter?context.quote(key,true):context.add(JSON.stringify(key)+':'))+value,seen=context.members;
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);return text;
   };
   if(role===0)return context=>context.add('null');
   if(role===1)return (value,context)=>context.add(value?'true':'false');
   if(role===2)return (token,context)=>{if(!jsonNumberToken(token))throw Error('invalid JSON number');return context.add(token);};
   if(role===3)return (value,context)=>context.quoter?context.quote(value,false):context.add(JSON.stringify(value));
   if(role===4)return (value,context)=>{context.add('[]');return '['+value+']';};
   if(role===5)return (value,context)=>{context.add('{}');return '{'+value+'}';};
   return ()=>null;
  }
  if(node.kind==='list'||node.kind==='vector'){
   const members=nodeRoles.get(node.children[0])==='member';
   return {
    start:(_length,context)=>{
     const out={text:'',parent:members?context.members:null};
     if(members)context.members=new Set();return out;
    },
    step:(out,value,index,context)=>{out.text+=(index?context.add(','):'')+value;return out;},
    finish:(out,context)=>{if(members)context.members=out.parent;return out.text;},
   };
  }
  if(node.kind==='result'){
   // A Result<Json,E> boundary is explicitly requested by the caller. Ordinary
   // JSON's own sums only propagate an already rendered branch.
   if(unwrap&&nodeRoles.get(node.children[0])==='root')return (tag,value)=>{if(tag)throw Error('JSON result is Err');return value;};
   return (_tag,value)=>value;
  }
  if(node.kind==='string')return value=>{if(!value.isWellFormed())throw Error('invalid JSON String');return value;};
  return value=>value;
 });
}
export class JsonCodec{
 constructor(valueCodec){
  const root=valueCodec.descriptor.root,fields=root.fields;if(root.kind!=='record'||!Array.isArray(fields)||fields.length!==1||fields[0].name!=='payload')throw Error('JSON schema payload');let sum=fields[0].type;
  for(let i=0;i<6;i++){
   if(i<5&&sum.kind!=='result')throw Error('JSON schema sum');const branch=i<5?sum.ok:sum,fs=branch.fields;
   if(branch.kind!=='record'||!Array.isArray(fs)||fs.length!==(i?1:0)||i&&fs[0].name!=='item0')throw Error('JSON schema branch');
   if(i){const t=fs[0].type;if(i===1&&t.kind!=='bool'||(i===2||i===3)&&t.kind!=='string'||i===4&&(t.kind!=='list'||t.element.kind!=='ref'||t.element.name!==root.name))throw Error('JSON schema variant');if(i===5){const mf=t.element?.fields;if(t.kind!=='list'||t.element?.kind!=='record'||!Array.isArray(mf)||mf.length!==2||mf[0].name!=='key'||mf[0].type.kind!=='string'||mf[1].name!=='value'||mf[1].type.kind!=='ref'||mf[1].type.name!==root.name)throw Error('JSON schema member');}}
   if(i===2)this.numberBranch=branch.name;if(i===5)this.objectBranch=branch.name;
   if(i<5)sum=sum.error;
  }if(!jsonSameSchema(root,valueCodec.resolve({kind:'ref',name:root.name})))throw Error('JSON recursive schema mismatch');this.values=valueCodec;
 }
 parse(text,options={}){return parseJsonValue(text,options,jsonBoundaryBudget(options));}
 parseCompiled(codec,text,options={}){
  if(codec?.identity!==this.values.descriptor.identity||typeof codec.builder!=='function')throw Error('compiled JSON schema mismatch');
  const builder=codec.builder(options);try{return parseJsonConstructed(text,options,builder);}catch(error){builder.abort();throw error;}
 }
 stringify(value,options={}){return stringifyJsonValue(value,options,jsonBoundaryBudget(options));}
 stringifyCompiled(codec,handle,options={}){
  const limits=checkedJsonLimits(options),unwrap=options.unwrapResult===true;
  const quoter=options.quoter;if(quoter!==undefined&&!jsonQuoters.has(quoter))throw Error('JSON quote cache owner mismatch');
  let codecs=jsonCompiledRenderers.get(this);if(!codecs)jsonCompiledRenderers.set(this,codecs=new WeakMap());
  let renderers=codecs.get(codec);if(!renderers)codecs.set(codec,renderers=new Map());
  let render=renderers.get(unwrap);if(!render)renderers.set(unwrap,render=compiledJsonRenderer(this,codec,unwrap));
  let bytes=0;const context={
   quoter,
   add(text){bytes+=jsonUtf8Length(text);if(bytes>limits.bytes)throw Error('JSON byte limit');return text;},
   quote(value,colon){
    if(!quoter)return this.add(JSON.stringify(value)+(colon?':':''));
    const token=quoter.token(value);bytes+=token.utf8Bytes+(colon?1:0);if(bytes>limits.bytes)throw Error('JSON byte limit');return token.text+(colon?':':'');
   },
  };
  const text=render(handle,context,limits);
  return text;
 }
 fromJS(value,options={}){return jsonFromJS(value,options);}
 toJS(value,options={}){return jsonToJS(value,options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,false);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,false,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,true);}
 validateBinary(bytes,options={}){
  const decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});let view;
  this.values.visitSpans(bytes,(type,data,start,end)=>{
   view??=new DataView(data.buffer,data.byteOffset,data.byteLength);
   if(type.name===this.numberBranch){const length=view.getUint32(start,true);if(!jsonNumberSpan(data,start+4,start+4+length))throw Error('invalid JSON number token');}
   if(type.name===this.objectBranch){const listEnd=start+4+view.getUint32(start,true),count=view.getUint32(start+4,true),seen=new Set();let at=start+8;for(let i=0;i<count;i++){const memberEnd=at+4+view.getUint32(at,true),keyStart=at+8,keyEnd=keyStart+view.getUint32(at+4,true),key=decoder.decode(data.subarray(keyStart,keyEnd));if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);at=memberEnd;}if(at!==listEnd)throw Error('invalid JSON object frame');}
  },options,[this.numberBranch,this.objectBranch]);return true;

 }
}
function jsonUnpack(value){let p=value.payload,i=0;while(i<5&&Object.hasOwn(p,'Err')){p=p.Err;i++;}return [i,(i<5?p.Ok:p).item0];}
function jsonInteger(token,limit){
 if(!jsonNumberToken(token))throw Error('invalid JSON number');const negative=token[0]==='-',raw=negative?token.slice(1):token,[mantissa,exp='0']=raw.split(/[eE]/);let digits=mantissa.replace('.','');if(/^0+$/.test(digits))return '0';const exponent=Number(exp),fraction=mantissa.includes('.')?mantissa.length-mantissa.indexOf('.')-1:0,shift=exponent-fraction;
 if(!Number.isSafeInteger(exponent)||!Number.isSafeInteger(shift))throw Error('JSON integer exponent limit');
 if(shift<0){const cut=-shift;if(cut>=digits.length||!/^[0]+$/.test(digits.slice(-cut)))throw Error('JSON number is not an integer');digits=digits.slice(0,-cut);}else{if(digits.length+shift>limit)throw Error('JSON integer magnitude limit');digits+='0'.repeat(shift);}
 digits=digits.replace(/^0+/,'');if(digits.length>limit)throw Error('JSON integer magnitude limit');return (negative?'-':'')+digits;
}
function jsonBinary64Value(v){
 if(typeof v==='number')return v;
 const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid F64Bits');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');
 const b=new DataView(new ArrayBuffer(8));b.setBigUint64(0,bits,true);return b.getFloat64(0,true);
}
export class TypedJsonCodec{
 constructor(valueCodec){this.values=valueCodec;}
 decode(document,options={}){
  // Validate JSON-specific invariants before interpreting any tagged/record
  // shape, including duplicated names and malformed numeric tokens.
  stringifyJson(document,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const read=(type,value,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type),[kind,item]=jsonUnpack(value);const fail=()=>{throw Error('JSON does not match '+t.kind);};
   switch(t.kind){
    case 'unit':if(kind!==0)fail();return null;
    case 'bool':if(kind!==1)fail();return item;
    case 'u32':case 'u64':case 'i32':case 'int':{if(kind!==2)fail();const text=jsonInteger(item,t.kind==='int'?4096:t.kind==='u64'?20:10);return t.kind==='int'?{Int:text}:t.kind==='u64'?BigInt(text):Number(text);}
    case 'f64':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(8));if(!Number.isFinite(n))throw Error('JSON f64 overflow');b.setFloat64(0,n,true);return {F64Bits:b.getBigUint64(0,true).toString()};}
    case 'f32':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(4));b.setFloat32(0,n,true);if(!Number.isFinite(b.getFloat32(0,true)))throw Error('JSON f32 overflow');return {F32Bits:b.getUint32(0,true)};}
    case 'string':case 'enum':case 'id':if(kind!==3)fail();return item;
    case 'list':case 'vector':if(kind!==4)fail();return item.map(x=>read(t.element,x,d+1));
    case 'record':{if(kind!==5||item.length!==t.fields.length)throw Error('unknown or missing JSON record field');const fields=new Map(item.map(m=>[m.key,m.value])),out={};for(const f of t.fields){if(!fields.has(f.name))throw Error('missing JSON record field');Object.defineProperty(out,f.name,{value:read(f.type,fields.get(f.name),d+1),writable:true,enumerable:true,configurable:true});}return out;}
    case 'option':case 'result':{if(kind!==5||item.length!==1)fail();const m=item[0];if(t.kind==='option'&&m.key==='None'&&jsonUnpack(m.value)[0]===0)return {None:null};const child=t.kind==='option'&&m.key==='Some'?t.element:t.kind==='result'&&m.key==='Ok'?t.ok:t.kind==='result'&&m.key==='Err'?t.error:null;if(!child)fail();return {[m.key]:read(child,m.value,d+1)};}
    default:fail();
   }
  };
  const out=read(this.values.descriptor.root,document,0);this.values.validateValue(out,options);return out;
 }
 encode(value,options={}){
  this.values.validateValue(value,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const write=(type,v,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type);
   switch(t.kind){
    case 'unit':return jsonVariant(0);
    case 'bool':return jsonVariant(1,v);
    case 'u32':case 'u64':case 'i32':return jsonVariant(2,String(v));
    case 'int':return jsonVariant(2,typeof v==='bigint'?String(v):v.Int);
    case 'f64':{const n=jsonBinary64Value(v);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'f32':{let n;if(typeof v==='number')n=Math.fround(v);else{const b=new DataView(new ArrayBuffer(4));b.setUint32(0,v.F32Bits,true);n=b.getFloat32(0,true);}if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'string':case 'id':case 'enum':return jsonVariant(3,v);
    case 'list':case 'vector':return jsonVariant(4,Array.from(v,x=>write(t.element,x,d+1)));
    case 'record':return jsonVariant(5,t.fields.map(f=>({key:f.name,value:write(f.type,v[f.name],d+1)})));
    case 'option':return jsonVariant(5,[Object.hasOwn(v,'Some')?{key:'Some',value:write(t.element,v.Some,d+1)}:{key:'None',value:jsonVariant(0)}]);
    case 'result':return jsonVariant(5,[Object.hasOwn(v,'Ok')?{key:'Ok',value:write(t.ok,v.Ok,d+1)}:{key:'Err',value:write(t.error,v.Err,d+1)}]);
    default:throw Error('unsupported typed JSON descriptor');
   }
  };return write(this.values.descriptor.root,value,0);
 }
 parse(text,options={}){return this.decode(parseJson(text,options),options);}
 stringify(value,options={}){return stringifyJson(this.encode(value,options),options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,true);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,true,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,false);}
}

// Token reader shared by schema-directed and arbitrary-JSON wire emission.
class JsonWireReader{
 constructor(text,options){this.l=checkedJsonLimits(options);if(typeof text!=='string'||!text.isWellFormed()||text.length>this.l.bytes||jsonUtf8Length(text)>this.l.bytes)throw Error('JSON byte or Unicode limit');this.text=text;this.at=0;this.remaining=this.l.nodes;}
 ws(){while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(c!==32&&c!==9&&c!==10&&c!==13)break;this.at++;}}
 peek(){this.ws();return this.text[this.at];}
 eat(c){this.ws();if(this.text[this.at]===c){this.at++;return true;}return false;}
 node(d){if(d>this.l.depth||--this.remaining<0)throw Error('JSON node or depth limit');}
 string(){
  this.ws();const start=this.at;if(this.text[start]!=='"')throw Error('expected JSON string');
  const end=this.text.indexOf('"',start+1);if(end<0)throw Error('unterminated JSON string');
  const raw=this.text.slice(start+1,end);
  if(!raw.includes('\\')&&!/[\x00-\x1f]/.test(raw)){this.at=end+1;return raw;}
  this.at=start+1;while(this.at<this.text.length){if(this.text[this.at]==='"'){this.at++;const v=JSON.parse(this.text.slice(start,this.at));if(!v.isWellFormed())throw Error('invalid JSON Unicode');return v;}if(this.text[this.at]==='\\')this.at+=2;else this.at++;}throw Error('unterminated JSON string');
 }
 number(){const start=this.at;while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(!(c>=48&&c<=57||c===45||c===43||c===46||c===101||c===69))break;this.at++;}const token=this.text.slice(start,this.at);if(!jsonNumberToken(token))throw Error('invalid JSON number');return token;}
 leaf(d){this.node(d);const c=this.peek();if(c==='n'&&this.text.startsWith('null',this.at)){this.at+=4;return null;}if(c==='t'&&this.text.startsWith('true',this.at)){this.at+=4;return true;}if(c==='f'&&this.text.startsWith('false',this.at)){this.at+=5;return false;}if(c==='"')return this.string();if(c==='-'||c>='0'&&c<='9')return this.number();throw Error('invalid JSON scalar');}
 finish(){this.ws();if(this.at!==this.text.length)throw Error('trailing JSON text');}
}
function streamJsonBinary(values,text,options,typed,compact=false){
 const p=new JsonWireReader(text,options),utf8=jsonWireEncoder;
 const list=(w,open,close,item)=>{if(!p.eat(open))throw Error('JSON container shape');const at=w.beginCount();let count=0;if(!p.eat(close))while(true){item(w);count++;if(p.eat(close))break;if(!p.eat(','))throw Error('JSON container separator');}w.endCount(at,count);};
 const variant=(w,index,level,emit)=>{if(level<index)w.frame(w=>{w.byte(1);variant(w,index,level+1,emit);});else if(index<5)w.frame(w=>{w.byte(0);w.frame(emit);});else w.frame(emit);};
 const json=(w,d)=>{
  const ch=p.peek(),index=ch==='n'?0:ch==='t'||ch==='f'?1:ch==='-'||ch>='0'&&ch<='9'?2:ch==='"'?3:ch==='['?4:ch==='{'?5:-1;if(index<0)throw Error('invalid JSON value');
  const leaf=index<4?p.leaf(d):null;if(index>=4)p.node(d);
  w.frame(w=>variant(w,index,0,w=>{
   if(index===0)return;if(index===1){w.frame(w=>w.byte(+leaf));return;}
   if(index===2||index===3){w.frame(w=>w.text(leaf));return;}
   w.frame(w=>{if(index===4)list(w,'[',']',w=>json(w,d+1));else{const seen=new Set();list(w,'{','}',w=>{const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');w.frame(w=>{w.frame(w=>w.text(key));json(w,d+1);});});}});
  }));
 };
 const read=(type,w,d)=>{
  const t=values.resolve(type);w.frame(w=>{
   if(t.kind==='list'||t.kind==='vector'){p.node(d);list(w,'[',']',w=>read(t.element,w,d+1));return;}
   if(t.kind==='record'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON record');const start=w.position,spans=new Array(t.fields.length).fill(null);
    if(!p.eat('}'))while(true){const key=p.string(),i=t.fields.findIndex(f=>f.name===key);if(i<0)throw Error('unknown JSON record field');if(spans[i])throw Error('duplicate JSON record field');if(!p.eat(':'))throw Error('JSON record colon');const at=w.position;read(t.fields[i].type,w,d+1);spans[i]=[at,w.position];if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON record separator');}
    if(spans.some(s=>s===null))throw Error('missing JSON record field');w.reorder(start,spans);return;
   }
   if(t.kind==='option'||t.kind==='result'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON tagged value');const key=p.string();if(!p.eat(':'))throw Error('JSON tag colon');
    if(t.kind==='option'&&key==='None'){if(p.leaf(d+1)!==null)throw Error('JSON None payload');w.byte(0);}
    else{const child=t.kind==='option'&&key==='Some'?t.element:t.kind==='result'&&key==='Ok'?t.ok:t.kind==='result'&&key==='Err'?t.error:null;if(!child)throw Error('invalid JSON tag');w.byte(key==='Ok'?0:1);read(child,w,d+1);}
    if(!p.eat('}'))throw Error('expected exactly one JSON tag');return;
   }
   const ch=p.peek(),v=p.leaf(d),bad=()=>{throw Error('JSON does not match '+t.kind);};
   if(t.kind==='unit'){if(v!==null)bad();return;}
   if(t.kind==='bool'){if(typeof v!=='boolean')bad();w.byte(+v);return;}
   if(['string','id','enum'].includes(t.kind)){if(ch!=='"')bad();w.text(v);return;}
   if(ch!=='-'&&!(ch>='0'&&ch<='9'))bad();
   if(t.kind==='int'){w.text(jsonInteger(v,4096));return;}
   if(t.kind==='f64'){const n=Number(v);if(!Number.isFinite(n))throw Error('JSON f64 overflow');const b=new DataView(new ArrayBuffer(8));b.setFloat64(0,n,true);w.wide(b.getBigUint64(0,true));}
   else if(t.kind==='f32'){jsonFloatScratch.setFloat32(0,Number(v),true);if(!Number.isFinite(jsonFloatScratch.getFloat32(0,true)))throw Error('JSON f32 overflow');w.word(jsonFloatScratch.getUint32(0,true));}
   else{const n=BigInt(jsonInteger(v,t.kind==='u64'?20:10));if(t.kind==='u64'){if(n<0n||n>18446744073709551615n)bad();w.wide(n);}else if(t.kind==='u32'){if(n<0n||n>4294967295n)bad();w.word(Number(n));}else if(t.kind==='i32'){if(n< -2147483648n||n>2147483647n)bad();w.word(Number(n)>>>0);}else bad();}
  });
 };
 return (compact?values.compact():values).encodeWith(w=>{if(typed)read(values.descriptor.root,w,0);else json(w,0);p.finish();},options);
}

// Render validated bytes in a single traversal; only the final text is owned.
function streamWireJsonText(values,bytes,options,library){
 values.validate(bytes,options);const l=checkedJsonLimits(options),parts=[];let size=0,remaining=l.nodes;const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 const emit=s=>{size+=jsonUtf8Length(s);if(size>l.bytes)throw Error('JSON byte limit');parts.push(s);};
 const string=s=>emit(JSON.stringify(s));const node=d=>{if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');};
 const frame=(type,at)=>{const t=values.resolve(type),start=at+4,end=start+dv.getUint32(at,true);return{t,start,end};};
 const json=(type,at,d)=>{
  node(d);let root=frame(type,at),sum=frame(root.t.fields[0].type,root.start),index=0;
  while(index<5){const err=bytes[sum.start];sum=frame(err?sum.t.error:sum.t.ok,sum.start+1);if(!err)break;index++;}
  if(index===0){emit('null');return root.end;}
  const item=frame(sum.t.fields[0].type,sum.start);
  if(index===1)emit(bytes[item.start]?'true':'false');
  else if(index===2){const token=decoder.decode(bytes.subarray(item.start,item.end));if(!jsonNumberToken(token))throw Error('invalid JSON number token');emit(token);}
  else if(index===3)string(decoder.decode(bytes.subarray(item.start,item.end)));
  else{const count=dv.getUint32(item.start,true);let p=item.start+4;emit(index===4?'[':'{');const seen=new Set();for(let i=0;i<count;i++){if(i)emit(',');if(index===4)p=json(item.t.element,p,d+1);else{const member=frame(item.t.element,p),key=frame(member.t.fields[0].type,member.start),name=decoder.decode(bytes.subarray(key.start,key.end));if(seen.has(name))throw Error('duplicate JSON object key');seen.add(name);string(name);emit(':');json(member.t.fields[1].type,key.end,d+1);p=member.end;}}emit(index===4?']':'}');}
  return root.end;
 };
 const typed=(type,at,d)=>{
  node(d);const f=frame(type,at),t=f.t;let p=f.start;
  switch(t.kind){
   case 'unit':emit('null');break;
   case 'bool':emit(bytes[p]?'true':'false');break;
   case 'u32':emit(String(dv.getUint32(p,true)));break;
   case 'u64':emit(String(dv.getBigUint64(p,true)));break;
   case 'i32':emit(String(dv.getInt32(p,true)));break;
   case 'f64':{const n=dv.getFloat64(p,true);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'f32':{const n=dv.getFloat32(p,true);if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'int':emit(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'string':case 'id':case 'enum':string(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'list':case 'vector':{const n=dv.getUint32(p,true);p+=4;emit('[');for(let i=0;i<n;i++){if(i)emit(',');p=typed(t.element,p,d+1);}emit(']');break;}
   case 'record':emit('{');for(let i=0;i<t.fields.length;i++){if(i)emit(',');const field=t.fields[i];string(field.name);emit(':');p=typed(field.type,p,d+1);}emit('}');break;
   case 'option':case 'result':{const tag=bytes[p++],key=t.kind==='option'?(tag?'Some':'None'):tag?'Err':'Ok';emit('{');string(key);emit(':');if(t.kind==='option'&&!tag){node(d+1);emit('null');}else typed(t.kind==='option'?t.element:tag?t.error:t.ok,p,d+1);emit('}');break;}
   default:throw Error('unsupported typed JSON descriptor');
  }return f.end;
 };
 if(library)json(values.descriptor.root,40,0);else typed(values.descriptor.root,40,0);return parts.join('');
}

/** Owned, optional read view of arbitrary JSON. Auxiliary indexes contain member
 * offsets only. Logical order, exact number tokens and missing/null remain intact.
 * This does not transparently replace any compiled Ink action or its state.
 */
export function createJsonLookup(text,{stepEntries=16,minReads=4,maxEntries=4096,maxObjects=64,maxIndexBytes=262144,...limits}={}){
 for(const [v,max]of [[stepEntries,4096],[minReads,1000000],[maxEntries,1000000],[maxObjects,256],[maxIndexBytes,16777216]])if(!Number.isSafeInteger(v)||v<0||v>max)throw Error('JSON index budget');
 let root=parseJson(text,limits),indexes=new Map(),entries=0,indexBytes=0;
 const stats={reads:0,writes:0,scanned_members:0,index_hits:0,built_entries:0,invalidations:0};
 function parts(path){
  if(!Array.isArray(path))throw Error('JSON lookup path');const n=path.length;if(n>128)throw Error('JSON lookup path');
  const owned=[];for(let i=0;i<n;i++){const d=Object.getOwnPropertyDescriptor(path,String(i));if(!d||!Object.hasOwn(d,'value'))throw Error('JSON lookup path');const p=d.value;if(!(typeof p==='string'&&p.isWellFormed()&&p.length<=4096)&&!(Number.isSafeInteger(p)&&p>=0))throw Error('JSON lookup path');owned.push(p);}return owned;
 }
 function variant(value){let p=value.payload,index=0;while(index<5&&Object.hasOwn(p,'Err')){p=p.Err;index++;}return {index,item:(index<5?p.Ok:p).item0};}
 function resolve(document,path,indexed){
  let value=document,budget=stepEntries;
  for(let depth=0;depth<path.length;depth++){
   const part=path[depth],v=variant(value);
   if(typeof part==='number'){
    if(v.index!==4)throw Error('expected JSON array');if(part>=v.item.length)return {found:false};value=v.item[part];continue;
   }
   if(v.index!==5)throw Error('expected JSON object');
   const prefix=path.slice(0,depth),key=JSON.stringify(prefix),overhead=128+prefix.reduce((n,p)=>n+(typeof p==='string'?16+p.length*2:8),0);let idx=indexed?indexes.get(key):null;
   if(indexed&&!idx&&indexes.size<maxObjects&&indexBytes+overhead<=maxIndexBytes){idx={path:prefix,reads:0,cursor:0,keys:new Map(),bytes:overhead};indexes.set(key,idx);indexBytes+=overhead;}
   if(idx){
    idx.reads++;
    if(idx.reads>=minReads)while(budget>0&&idx.cursor<v.item.length&&entries<maxEntries){
     const member=v.item[idx.cursor],bytes=64+member.key.length*2;
     if(indexBytes+bytes>maxIndexBytes)break;
     idx.keys.set(member.key,idx.cursor++);idx.bytes+=bytes;indexBytes+=bytes;entries++;stats.built_entries++;budget--;
    }
    if(idx.keys.has(part)){stats.index_hits++;value=v.item[idx.keys.get(part)].value;continue;}
   }
   let found=false;
   for(let i=idx?.cursor??0;i<v.item.length;i++){if(indexed)stats.scanned_members++;if(v.item[i].key===part){value=v.item[i].value;found=true;break;}}
   if(!found)return {found:false};
  }
  return {found:true,value};
 }
 return {
  lookup(path){stats.reads++;const r=resolve(root,parts(path),true);return r.found?{found:true,value:structuredClone(r.value)}:r;},
  set(path,key,text){
   path=parts(path);if(typeof key!=='string'||!key.isWellFormed())throw Error('JSON object key');
   const replacement=parseJson(text,limits),next=structuredClone(root),r=resolve(next,path,false);
   if(!r.found)throw Error('JSON update path missing');const object=variant(r.value);if(object.index!==5)throw Error('expected JSON object');
   const members=[{key,value:replacement},...object.item.filter(m=>m.key!==key)];
   // Validate the complete resulting document before publishing a write.
   let payload=r.value.payload;for(let i=0;i<5;i++)payload=payload.Err;payload.item0=members;
   stringifyJson(next,limits);root=next;stats.writes++;
   for(const [id,idx]of indexes)if(idx.path.length>=path.length&&path.every((p,i)=>p===idx.path[i])){entries-=idx.keys.size;indexBytes-=idx.bytes;indexes.delete(id);stats.invalidations++;}
  },
  replace(text){const next=parseJson(text,limits);root=next;stats.writes++;stats.invalidations+=indexes.size;indexes.clear();entries=0;indexBytes=0;},
  stringify(){return stringifyJson(root,limits);},
  stats(){return {...stats,index_entries:entries,index_objects:indexes.size,index_bytes:indexBytes};}
 };
}
function __ownedValue0(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue1(value[i],budget,depth+1);return out;}
function __ownedValue6(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue7(value[i],budget,depth+1);return out;}
function __ownedValue2(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue0(value.Ok,budget,depth+1)}:{Err:__ownedValue3(value.Err,budget,depth+1)};}
function __ownedValue9(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue10(value.Ok,budget,depth+1)}:{Err:__ownedValue3(value.Err,budget,depth+1)};}
function __ownedValue4(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__ownedValue1(value.Ok,budget,depth+1)}:{Err:__ownedValue3(value.Err,budget,depth+1)};}
function __ownedValue10(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue1(value["value"],budget,depth+1),["gradient"]:__ownedValue0(value["gradient"],budget,depth+1)};}
function __ownedValue8(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue1(value["value"],budget,depth+1),["id"]:__ownedValue7(value["id"],budget,depth+1)};}
function __ownedValue5(value,budget,depth){budget.enter(depth,5);return value;}
function __ownedValue1(value,budget,depth){budget.enter(depth,8);return {F32Bits:value===0?0:value};}
function __ownedValue3(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __ownedValue7(value,budget,depth){budget.enter(depth,8);return value>>>0;}
const __ownedFunctions=Object.freeze(Object.fromEntries([["initial",__ownedValue0],["model",__ownedValue1],["objective",__ownedValue1],["derivatives",__ownedValue2],["linearized_value",__ownedValue4],["valid",__ownedValue5],["update",__ownedValue0],["admissible",__ownedValue5],["branch_owned",__ownedValue6],["device",__ownedValue0],["__ink_reverse_0_constant",__ownedValue8],["__ink_reverse_0_backward",__ownedValue0],["__ink_reverse_37",__ownedValue2],["__ink_reverse_50",__ownedValue9]]));
function __wireValue1(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue2(reader);reader.finish(end);return value;}
function __wireValue7(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue4(reader);reader.finish(end);return value;}
function __wireValue19(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue3(reader);reader.finish(end);return value;}
function __wireValue18(reader){const end=reader.frame();const value=reader.byte()?{Some:__wireValue3(reader)}:{None:null};reader.finish(end);return value;}
function __wireValue11(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue12(reader)}:{Ok:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue14(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue12(reader)}:{Ok:__wireValue15(reader)};reader.finish(end);return value;}
function __wireValue23(reader){const end=reader.frame();const value=reader.byte()?{Err:__wireValue12(reader)}:{Ok:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue22(reader){const end=reader.frame();const value={};reader.finish(end);return value;}
function __wireValue16(reader){const end=reader.frame();const value={["context"]:__wireValue10(reader)};reader.finish(end);return value;}
function __wireValue10(reader){const end=reader.frame();const value={["features"]:__wireValue7(reader),["target"]:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue17(reader){const end=reader.frame();const value={["input"]:__wireValue18(reader)};reader.finish(end);return value;}
function __wireValue21(reader){const end=reader.frame();const value={["inputs"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue0(reader){const end=reader.frame();const value={["nodes"]:__wireValue1(reader),["output"]:__wireValue5(reader),["stopZero"]:__wireValue6(reader)};reader.finish(end);return value;}
function __wireValue2(reader){const end=reader.frame();const value={["op"]:__wireValue3(reader),["a"]:__wireValue3(reader),["b"]:__wireValue3(reader),["av"]:__wireValue4(reader),["bv"]:__wireValue4(reader),["value"]:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue15(reader){const end=reader.frame();const value={["value"]:__wireValue4(reader),["gradient"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue5(reader){const end=reader.frame();const value={["value"]:__wireValue4(reader),["id"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue8(reader){const end=reader.frame();const value={["value"]:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue9(reader){const end=reader.frame();const value={["weights"]:__wireValue7(reader),["__ink_reverse_32"]:__wireValue3(reader),["__ink_reverse_33"]:__wireValue6(reader),["context"]:__wireValue10(reader)};reader.finish(end);return value;}
function __wireValue13(reader){const end=reader.frame();const value={["weights"]:__wireValue7(reader),["__ink_reverse_45"]:__wireValue3(reader),["__ink_reverse_46"]:__wireValue6(reader),["context"]:__wireValue10(reader)};reader.finish(end);return value;}
function __wireValue20(reader){const end=reader.frame();const value={["weights"]:__wireValue7(reader),["context"]:__wireValue10(reader),["maximum"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue24(reader){const end=reader.frame();const value={["weights"]:__wireValue7(reader),["context"]:__wireValue10(reader)};reader.finish(end);return value;}
function __wireValue25(reader){const end=reader.frame();const value={["weights"]:__wireValue7(reader),["gradient"]:__wireValue7(reader),["rate"]:__wireValue4(reader)};reader.finish(end);return value;}
function __wireValue26(reader){const end=reader.frame();const value={["weights"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue6(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __wireValue4(reader){const end=reader.frame();const value={F32Bits:reader.word()};reader.finish(end);return value;}
function __wireValue12(reader){const end=reader.frame();const value=reader.text(end,"string");reader.finish(end);return value;}
function __wireValue3(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
const __wireReaders=Object.freeze(Object.fromEntries([["__ink_reverse_0_backward",[__wireValue0,__wireValue7]],["__ink_reverse_0_constant",[__wireValue8,__wireValue5]],["__ink_reverse_37",[__wireValue9,__wireValue11]],["__ink_reverse_50",[__wireValue13,__wireValue14]],["admissible",[__wireValue16,__wireValue6]],["branch_owned",[__wireValue17,__wireValue19]],["derivatives",[__wireValue20,__wireValue11]],["device",[__wireValue21,__wireValue7]],["initial",[__wireValue22,__wireValue7]],["linearized_value",[__wireValue20,__wireValue23]],["model",[__wireValue24,__wireValue4]],["objective",[__wireValue24,__wireValue4]],["update",[__wireValue25,__wireValue7]],["valid",[__wireValue26,__wireValue6]]]));

const __ownedImplementations=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>{
 const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
 const body=__implementations[f.index];
 const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
 return [f.name,input.every(c=>c===__identity)?implementation:(...args)=>{const context=new WeakMap();return implementation(...args.map((v,i)=>input[i](v,context)));}];
})));

export const valueCodecs=(()=>{const codecs={};for(const [name,s] of Object.entries(metadata.wire.functions)){if(s.unsupported)continue;let value;Object.defineProperty(codecs,name,{enumerable:true,get:()=>value??=(Object.freeze(Object.hasOwn(__wireReaders,name)?{arguments:createCompiledValueCodec(s.arguments,__wireReaders[name][0]),result:createCompiledValueCodec(s.result,__wireReaders[name][1])}:{arguments:new ValueCodec(s.arguments),result:new ValueCodec(s.result)}))});}return Object.freeze(codecs);})();
function __callEncoded(name,bytes,limits,compact){
 const f=metadata.functions.find(f=>f.name===name&&!f.internal),codecs=valueCodecs[name];
 if(!f||!codecs)throw Error('unsupported binary function');
 const input=compact?codecs.arguments.compact():codecs.arguments,output=compact?codecs.result.compact():codecs.result;
 const entry=__compiledEntries.get(name);
 if(entry){
  const slot=compact?1:0;
  entry.argumentCodecs[slot]??=(entry.boundaryReaders[slot]?createFusedValueCodec:createCompiledValueCodec)(metadata.wire.functions[name].arguments,entry.arguments);
  const decoder=entry.argumentCodecs[slot];
  const values=(compact?decoder.compact():decoder).decode(bytes,limits),args=f.params.map(p=>values[p.name]);
  if(entry.precondition!==null&&__implementations[entry.precondition](...args)!==true)throw Error('contract precondition failed');
  return __compiledEncodeResult(entry,__implementations[entry.index](...args),limits,compact);
 }
 const values=input.decode(bytes,limits);
 const result=call(name,f.params.map(p=>values[p.name]));
 return output.encode(result,limits);
}
export function callBinary(name,bytes,limits={}){return __callEncoded(name,bytes,limits,false);}
export function callCompact(name,bytes,limits={}){return __callEncoded(name,bytes,limits,true);}
// Same stable, well-typed caller inputs as call; the result owns every container.
// The checked source return type justifies trusted copying, not arbitrary input.
export function callOwned(name,args,limits={}){
 if(!Object.hasOwn(__ownedFunctions,name)||!Object.hasOwn(functions,name))throw Error('unsupported owned function');
 const result=__ownedImplementations[name](...args);return __ownedFunctions[name](result,createValueCaptureBudget(limits),0);
}
function __privateCapture11(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture12(value[i],budget,depth+1);return out;}
function __privateCapture0(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture1(value[i],budget,depth+1);return out;}
function __privateCapture9(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture3(value[i],budget,depth+1);return out;}
function __privateCapture8(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if((value!==null&&typeof value==='object'&&Object.hasOwn(value,'None')&&Object.keys(value).length===1)&&value.None===null)return {None:null};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Some')&&Object.keys(value).length===1)return {Some:__privateCapture3(value.Some,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture4(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture0(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture5(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture13(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture14(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture5(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture6(value,budget,depth=0){budget.enter(depth,4);budget.add(1);if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Ok')&&Object.keys(value).length===1)return {Ok:__privateCapture1(value.Ok,budget,depth+1)};if(value!==null&&typeof value==='object'&&Object.hasOwn(value,'Err')&&Object.keys(value).length===1)return {Err:__privateCapture5(value.Err,budget,depth+1)};throw Error('invalid value for wire schema');}
function __privateCapture2(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"features")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"target")){throw Error('invalid value for wire schema');}return {["features"]:__privateCapture0(value["features"],budget,depth+1),["target"]:__privateCapture1(value["target"],budget,depth+1)};}
function __privateCapture12(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"op")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"a")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"b")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"av")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"bv")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}return {["op"]:__privateCapture3(value["op"],budget,depth+1),["a"]:__privateCapture3(value["a"],budget,depth+1),["b"]:__privateCapture3(value["b"],budget,depth+1),["av"]:__privateCapture1(value["av"],budget,depth+1),["bv"]:__privateCapture1(value["bv"],budget,depth+1),["value"]:__privateCapture1(value["value"],budget,depth+1)};}
function __privateCapture14(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"gradient")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["gradient"]:__privateCapture0(value["gradient"],budget,depth+1)};}
function __privateCapture10(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"id")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["id"]:__privateCapture3(value["id"],budget,depth+1)};}
function __privateCapture7(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='boolean'){throw Error('invalid value for wire schema');}budget.add(1);return value;}
function __privateCapture1(value,budget,depth=0){budget.enter(depth,4);let bits;if(typeof value==='number'&&Number.isFinite(value)){bits=__bits(value);if(!Number.isFinite(__float(bits))){throw Error('invalid value for wire schema');}}else{if(!(value!==null&&typeof value==='object'&&Object.hasOwn(value,'F32Bits')&&Object.keys(value).length===1)){throw Error('invalid value for wire schema');}bits=value.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295){throw Error('invalid value for wire schema');}}budget.add(4);return bits===0?0:bits;}
function __privateCapture5(value,budget,depth=0){budget.enter(depth,4);const text=value;if(typeof text!=='string'||!text.isWellFormed()||text.length>budget.limit){throw Error('invalid value for wire schema');}budget.text(text);return text;}
function __privateCapture3(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='number'||!Number.isInteger(value)||value<0||value>4294967295){throw Error('invalid value for wire schema');}budget.add(4);return value===0?0:value;}
function __privateWireValue20(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue21(reader);reader.finish(end);return value;}
function __privateWireValue0(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue1(reader);reader.finish(end);return value;}
function __privateWireValue15(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue5(reader);reader.finish(end);return value;}
function __privateWireValue14(reader){const end=reader.frame();const value=reader.byte()?{Some:__privateWireValue5(reader)}:{None:null};reader.finish(end);return value;}
function __privateWireValue6(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue7(reader)}:{Ok:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue24(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue7(reader)}:{Ok:__privateWireValue25(reader)};reader.finish(end);return value;}
function __privateWireValue9(reader){const end=reader.frame();const value=reader.byte()?{Err:__privateWireValue7(reader)}:{Ok:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue2(reader){const end=reader.frame();const value={};reader.finish(end);return value;}
function __privateWireValue13(reader){const end=reader.frame();const value={["context"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue3(reader){const end=reader.frame();const value={["features"]:__privateWireValue0(reader),["target"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue16(reader){const end=reader.frame();const value={["input"]:__privateWireValue14(reader)};reader.finish(end);return value;}
function __privateWireValue17(reader){const end=reader.frame();const value={["inputs"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue22(reader){const end=reader.frame();const value={["nodes"]:__privateWireValue20(reader),["output"]:__privateWireValue18(reader),["stopZero"]:__privateWireValue10(reader)};reader.finish(end);return value;}
function __privateWireValue21(reader){const end=reader.frame();const value={["op"]:__privateWireValue5(reader),["a"]:__privateWireValue5(reader),["b"]:__privateWireValue5(reader),["av"]:__privateWireValue1(reader),["bv"]:__privateWireValue1(reader),["value"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue25(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["gradient"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue18(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["id"]:__privateWireValue5(reader)};reader.finish(end);return value;}
function __privateWireValue19(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue23(reader){const end=reader.frame();const value={["weights"]:__privateWireValue0(reader),["__ink_reverse_32"]:__privateWireValue5(reader),["__ink_reverse_33"]:__privateWireValue10(reader),["context"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue26(reader){const end=reader.frame();const value={["weights"]:__privateWireValue0(reader),["__ink_reverse_45"]:__privateWireValue5(reader),["__ink_reverse_46"]:__privateWireValue10(reader),["context"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue8(reader){const end=reader.frame();const value={["weights"]:__privateWireValue0(reader),["context"]:__privateWireValue3(reader),["maximum"]:__privateWireValue5(reader)};reader.finish(end);return value;}
function __privateWireValue4(reader){const end=reader.frame();const value={["weights"]:__privateWireValue0(reader),["context"]:__privateWireValue3(reader)};reader.finish(end);return value;}
function __privateWireValue12(reader){const end=reader.frame();const value={["weights"]:__privateWireValue0(reader),["gradient"]:__privateWireValue0(reader),["rate"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue11(reader){const end=reader.frame();const value={["weights"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue10(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __privateWireValue1(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __privateWireValue7(reader){const end=reader.frame();const value=reader.text(end,"string");reader.finish(end);return value;}
function __privateWireValue5(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __compiledOwnedValue11(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue12(value[i],budget,depth+1);return out;}
function __compiledOwnedValue0(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue1(value[i],budget,depth+1);return out;}
function __compiledOwnedValue9(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue3(value[i],budget,depth+1);return out;}
function __compiledOwnedValue8(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'None')&&value.None===null?{None:null}:{Some:__compiledOwnedValue3(value.Some,budget,depth+1)};}
function __compiledOwnedValue4(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue0(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue5(value.Err,budget,depth+1)};}
function __compiledOwnedValue13(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue14(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue5(value.Err,budget,depth+1)};}
function __compiledOwnedValue6(value,budget,depth){budget.enter(depth,5);return Object.hasOwn(value,'Ok')?{Ok:__compiledOwnedValue1(value.Ok,budget,depth+1)}:{Err:__compiledOwnedValue5(value.Err,budget,depth+1)};}
function __compiledOwnedValue2(value,budget,depth){budget.enter(depth,4);return {["features"]:__compiledOwnedValue0(value["features"],budget,depth+1),["target"]:__compiledOwnedValue1(value["target"],budget,depth+1)};}
function __compiledOwnedValue12(value,budget,depth){budget.enter(depth,4);return {["op"]:__compiledOwnedValue3(value["op"],budget,depth+1),["a"]:__compiledOwnedValue3(value["a"],budget,depth+1),["b"]:__compiledOwnedValue3(value["b"],budget,depth+1),["av"]:__compiledOwnedValue1(value["av"],budget,depth+1),["bv"]:__compiledOwnedValue1(value["bv"],budget,depth+1),["value"]:__compiledOwnedValue1(value["value"],budget,depth+1)};}
function __compiledOwnedValue14(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["gradient"]:__compiledOwnedValue0(value["gradient"],budget,depth+1)};}
function __compiledOwnedValue10(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["id"]:__compiledOwnedValue3(value["id"],budget,depth+1)};}
function __compiledOwnedValue7(value,budget,depth){budget.enter(depth,5);return value;}
function __compiledOwnedValue1(value,budget,depth){budget.enter(depth,8);return {F32Bits:value===0?0:value};}
function __compiledOwnedValue5(value,budget,depth){budget.enter(depth,4);budget.text(value);return value;}
function __compiledOwnedValue3(value,budget,depth){budget.enter(depth,8);return value>>>0;}
function __privateWireWrite11(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite12(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite0(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite1(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite9(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite3(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite8(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Some')){writer.byte(1);__privateWireWrite3(writer,value.Some,compact);}else{writer.byte(0);}writer.closeFrame(frame);}
function __privateWireWrite4(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite0(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite5(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite13(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite14(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite5(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite6(writer,value,compact){const frame=writer.openFrame();if(Object.hasOwn(value,'Ok')){writer.byte(0);__privateWireWrite1(writer,value.Ok,compact);}else{writer.byte(1);__privateWireWrite5(writer,value.Err,compact);}writer.closeFrame(frame);}
function __privateWireWrite2(writer,value,compact){const frame=writer.openFrame();__privateWireWrite0(writer,value["features"],compact);__privateWireWrite1(writer,value["target"],compact);writer.closeFrame(frame);}
function __privateWireWrite12(writer,value,compact){const frame=writer.openFrame();__privateWireWrite3(writer,value["op"],compact);__privateWireWrite3(writer,value["a"],compact);__privateWireWrite3(writer,value["b"],compact);__privateWireWrite1(writer,value["av"],compact);__privateWireWrite1(writer,value["bv"],compact);__privateWireWrite1(writer,value["value"],compact);writer.closeFrame(frame);}
function __privateWireWrite14(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite0(writer,value["gradient"],compact);writer.closeFrame(frame);}
function __privateWireWrite10(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite3(writer,value["id"],compact);writer.closeFrame(frame);}
function __privateWireWrite7(writer,value,compact){const frame=writer.openFrame();writer.byte(value?1:0);writer.closeFrame(frame);}
function __privateWireWrite1(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
function __privateWireWrite5(writer,value,compact){const frame=writer.openFrame();writer.text(value,compact);writer.closeFrame(frame);}
function __privateWireWrite3(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
// Handles have no mutable private payload surface. Membership and type identity
// are checked by this module's closure; copied/foreign objects cannot forge them.
const __compiledHandles=new WeakMap();
const __compiledBindings=new WeakMap();
function __compiledHandle(identity,value,guaranteed=false){
 const handle=Object.freeze(Object.create(null));
 __compiledHandles.set(handle,{identity,value,guaranteed});return handle;
}
function __compiledEntry(handle,identity){
 const entry=__compiledHandles.get(handle);
 if(!entry||entry.identity!==identity)throw Error('compiled value type or owner mismatch');
 return entry;
}
function __compiledUnwrap(handle,identity){return __compiledEntry(handle,identity).value;}
// Emit the portable schema's framing/scalar events without creating a buffer
// or exposing private composite nodes. Only this wrapper receives callbacks
// from the literal writer; host visitors never receive those closures.
function __compiledValueEvents(sink,limits){
 const methods=['begin','end','byte','word','wide','text','count'];
 for(const name of methods)if(typeof sink?.[name]!=='function')throw Error('compiled value visitor method: '+name);
 const budget=createValueCaptureBudget(limits);let depth=0,closed=false;
 const active=()=>{if(closed)throw Error('compiled value visitor is closed');};
 const writer=Object.freeze({
  openFrame(){active();budget.enter(depth,4);depth++;sink.begin();return 0;}
  ,closeFrame(){active();if(depth===0)throw Error('wire frame boundary');try{sink.end();}finally{depth--;}}
  ,frame(emit){active();budget.enter(depth,4);depth++;sink.begin();try{emit();sink.end();}finally{depth--;}}
  ,byte(value){active();budget.add(1);sink.byte(value);}
  ,word(value){active();budget.add(4);sink.word(value);}
  ,wide(value){active();budget.add(8);sink.wide(value);}
  ,text(value){active();budget.text(value);sink.text(value);}
  ,count(value){active();budget.add(4);if(value>budget.remaining)throw Error('wire sequence size');sink.count(value);}
 });
 return {writer,close(){closed=true;}};
}
function __compiledReduction(factory,root,reduce,identity){
 if(typeof factory!=='function')throw Error('compiled reduction factory');
 const reducers=[],seen=new Set(),nodes=__reductionNodes();
 const prepare=index=>{
  if(seen.has(index))return;seen.add(index);
  const node=nodes[index];
  for(const child of node.children)prepare(child);
  const reducer=factory(node,index);
  if(node.kind==='list'||node.kind==='vector'){
   const start=reducer?.start,step=reducer?.step,finish=reducer?.finish;
   if(typeof start!=='function'||typeof step!=='function'||typeof finish!=='function')throw Error('compiled collection reduction');
   reducers[index]=Object.freeze({start,step,finish});
  }else{
   if(typeof reducer!=='function')throw Error('compiled value reduction');
   reducers[index]=reducer;
  }
 };
 prepare(root);Object.freeze(reducers);
 return Object.freeze(function(handle,context,limits={}){
  const value=__compiledUnwrap(handle,identity),budget=createValueCaptureBudget(limits);
  return reduce(value,reducers,budget,0,context);
 });
}
function __compiledCodec(schema,capture,read,write,copy,constructorRoot,reductionRoot,reduce,portableFused=false,compactFused=false){
 const privateCodec=createCompiledValueCodec(schema,read),publicCodec=privateCodec;
 let fusedCodec;const fused=()=>fusedCodec??=createFusedValueCodec(schema,read);
 const identity=schema.identity;
 const codec=Object.freeze({
  identity,
  descriptor:publicCodec.descriptor,
  resolve(type){return publicCodec.resolve(type);},
  capture(value,limits={}){
   return __compiledHandle(identity,capture(value,createValueCaptureBudget(limits),0));
  },
  decode(bytes,limits={}){return __compiledHandle(identity,(portableFused?fused():privateCodec).decode(bytes,limits));},
  decodeCompact(bytes,limits={}){return __compiledHandle(identity,(compactFused?fused():privateCodec).compact().decode(bytes,limits));},
  decodeFused(bytes,limits={}){return __compiledHandle(identity,fused().decode(bytes,limits));},
  decodeCompactFused(bytes,limits={}){return __compiledHandle(identity,fused().compact().decode(bytes,limits));},
  encode(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.encodeWith(writer=>write(writer,value,false),limits);},
  encodeCompact(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.compact().encodeWith(writer=>write(writer,value,true),limits);},
  materialize(handle,limits={}){return copy(__compiledUnwrap(handle,identity),createValueCaptureBudget(limits),0);},
  builder(limits={}){return __valueBuilder(__constructorNodes(),constructorRoot,identity,limits);},
  reducer(factory){return __compiledReduction(factory,reductionRoot,reduce,identity);},
  visit(handle,sink,limits={}){
   const value=__compiledUnwrap(handle,identity),events=__compiledValueEvents(sink,limits);
   try{write(events.writer,value,false);}finally{events.close();}
  },
 });
 __compiledBindings.set(codec,{publicCodec,write,capture});return codec;
}

function __compiledEncodeResult(entry,value,limits,compact){
 const {publicCodec,write}=__compiledBindings.get(entry.result());
 return (compact?publicCodec.compact():publicCodec).encodeWith(writer=>write(writer,value,compact),limits);
}
let __constructorNodesValue;function __constructorNodes(){return __constructorNodesValue??=[{kind:"list",patterns:[{bytes:8,label:"sequence",children:[1],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:"f32",scalar:__privateCapture1},{kind:'record',fields:["features","target"],patterns:[{bytes:4,label:"record",children:[0,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["features"]:values[0],["target"]:values[1]})}]},{kind:"u32",scalar:__privateCapture3},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[0],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[5],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:"string",scalar:__privateCapture5},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[1],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[5],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:"bool",scalar:__privateCapture7},{kind:'option',patterns:[{bytes:5,label:"None",children:[],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({None:null})},{bytes:5,label:"Some",children:[3],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>({Some:values[0]})}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[3],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["value","id"],patterns:[{bytes:4,label:"record",children:[1,3],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["id"]:values[1]})}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[12],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["op","a","b","av","bv","value"],patterns:[{bytes:4,label:"record",children:[3,3,3,1,1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["op"]:values[0],["a"]:values[1],["b"]:values[2],["av"]:values[3],["bv"]:values[4],["value"]:values[5]})}]},{kind:'result',flat:null,patterns:[{bytes:5,label:"Ok",children:[14],childDepth:1,sumBranch:0,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Ok:values[0]}))},{bytes:5,label:"Err",children:[5],childDepth:1,sumBranch:1,charge:(budget,depth)=>{budget.enter(depth,5);},make:values=>(({Err:values[0]}))}]},{kind:'record',fields:["value","gradient"],patterns:[{bytes:4,label:"record",children:[1,0],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["gradient"]:values[1]})}]}];}
// Typed input construction only: plans contain literal constructor/capture
// functions emitted from source schemas. No source expression evaluator.
// All frames and private values remain in this closure; callers receive only
// an owned opaque handle after one complete, well-typed root is constructed.
const __constructorPaths=new WeakMap();
function __valueBuilder(nodes,root,identity,limits){
 const budget=createValueCaptureBudget(limits),frames=[];
 let result,targetNode,targetDepth,complete=false,closed=false,failed=false,busy=false;
 const fail=message=>{failed=true;frames.length=0;result=undefined;throw Error(message);};
 const active=()=>{if(failed||closed)throw Error('value builder is closed');};
 const expected=()=>{
  if(!frames.length){if(complete)fail('value builder root already complete');targetNode=root;targetDepth=0;return;}
  const frame=frames.at(-1),position=frame.values.length;
  if(!frame.pattern.sequence&&position>=frame.pattern.children.length)fail('value builder constructor is full');
  targetNode=frame.pattern.sequence?frame.pattern.children[0]:frame.pattern.children[position];targetDepth=frame.depth+frame.pattern.childDepth;
 };
 const accept=value=>{
  if(frames.length)frames.at(-1).values.push(value);
  else{result=value;complete=true;}
 };
 const execute=(operation,first,second)=>{
  active();if(busy)throw Error('value builder operation already active');busy=true;
  try{return operation(first,second);}catch(error){failed=true;frames.length=0;result=undefined;throw error;}finally{busy=false;}
 };
 // Compile and cache constructor paths independently of the session's values.
 const pathPlan=(choices,startNode,startDepth)=>{
   if(!Array.isArray(choices)||choices.length===0||choices.length>128)fail('invalid value builder path');
   let cache=__constructorPaths.get(nodes);if(!cache){cache=new WeakMap();__constructorPaths.set(nodes,cache);}
   let entries=cache.get(choices),saved=entries?.get(startNode);
   if(saved)return saved;
   const path=[],charges=[];let node=startNode,depth=startDepth;
   for(let i=0;i<choices.length;i++){
    const choice=choices[i],patterns=nodes[node].patterns;
    if(!Number.isSafeInteger(choice)||choice<0||!patterns||choice>=patterns.length)fail('invalid value builder constructor');
    const pattern=patterns[choice];charges.push([pattern,depth-startDepth]);path.push({pattern,node:nodes[node]});
    if(i+1<choices.length){if(pattern.sequence||pattern.children.length!==1)fail('value builder path is not unary');node=pattern.children[0];depth+=pattern.childDepth;}
   }
   const terminal=path.at(-1).pattern;
   // Compose literal constructor functions once per path, instead of
   // allocating and interpreting another recursive closure for every value.
   const compose=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=args=>args[0];
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=args=>p.make([inner(args)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?compose(last+1):args=>args[0]):compose(last);
     return args=>node.flat(index,payload(args));
    }
    const inner=at+1<path.length?compose(at+1):null;
    if(pattern.transparent)return inner??(args=>args[0]);
    return inner?args=>pattern.make([inner(args)]):pattern.make;
   };
   const make=compose(0);
   // Scalar paths use the same literal constructors, but pass the leaf
   // directly through erased records and flat sums. No temporary argument
   // array is needed at those edges. Ordinary constructors keep their array
   // calling convention; no private value reaches the public builder API.
   const composeScalar=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=value=>value;
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=value=>p.make([inner(value)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?composeScalar(last+1):value=>value):composeScalar(last);
     return value=>node.flat(index,payload(value));
    }
    const inner=at+1<path.length?composeScalar(at+1):null;
    if(pattern.transparent)return inner??(value=>value);
    return inner?value=>pattern.make([inner(value)]):value=>pattern.make([value]);
   };
   const scalar=composeScalar(0);
   const pattern={...terminal,make};
   // Only frozen arrays of ordinary data properties can key reusable plans.
   // Mutable arrays and frozen accessor arrays retain checked per-call paths.
   const fixed=charges.every(([p])=>Number.isSafeInteger(p.bytes)&&p.bytes>=4);
   const plan={pattern,scalar,charges,offset:depth-startDepth,bytes:fixed?charges.reduce((n,[p])=>n+p.bytes,0):null};
   let reusable=Object.isFrozen(choices);
   for(let i=0;reusable&&i<choices.length;i++){const field=Object.getOwnPropertyDescriptor(choices,String(i));reusable=!!field&&Object.hasOwn(field,'value');}
   if(reusable){
    if(!entries){entries=new Map();cache.set(choices,entries);}entries.set(startNode,plan);
   }
   return plan;
 };
 const chargePath=(plan,depth)=>{
  // Each emitted constructor consumes one node and a fixed frame/tag cost.
  // Only take the combined charge when every original check would succeed.
  // Replaying the original order retains the exact first failure otherwise.
  if(plan.bytes!==null&&depth+plan.offset<=budget.depth&&plan.charges.length<=budget.remaining&&budget.bytes+plan.bytes<=budget.limit){
   budget.remaining-=plan.charges.length;budget.bytes+=plan.bytes;return;
  }
  for(const [pattern,offset]of plan.charges)pattern.charge(budget,depth+offset);
 };
 // Operations are allocated once per session, and share expected-node
 // scratch only while the existing reentrancy guard is held.
 const openOperation=(choice)=>{
   expected();const node=nodes[targetNode];
   if(!Number.isSafeInteger(choice)||choice<0||!node.patterns||choice>=node.patterns.length)fail('invalid value builder constructor');
   const pattern=node.patterns[choice];pattern.charge(budget,targetDepth);
   frames.push({pattern,depth:targetDepth,values:[]});
 };
 const openPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth);
   chargePath(plan,targetDepth);
   frames.push({pattern:plan.pattern,depth:targetDepth+plan.offset,values:[]});
 };
 const scalarPathOperation=(choices,value)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==1)fail('value builder path has no scalar leaf');
   const capture=nodes[pattern.children[0]].scalar;
   if(typeof capture!=='function')fail('value builder path has no scalar leaf');
   chargePath(plan,targetDepth);
   const leaf=capture(value,budget,targetDepth+plan.offset+pattern.childDepth);
   accept(plan.scalar(leaf));
 };
 const emptyPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==0)fail('value builder path is not empty');
   chargePath(plan,targetDepth);accept(pattern.make([]));
 };
 const scalarOperation=(value)=>{
   expected();const capture=nodes[targetNode].scalar;
   if(typeof capture!=='function')fail('value builder expects a constructor');
   accept(capture(value,budget,targetDepth));
 };
 const closeOperation=()=>{
   if(!frames.length)fail('value builder has no open constructor');
   const frame=frames.at(-1),pattern=frame.pattern,count=frame.values.length;
   if(!pattern.sequence&&count!==pattern.children.length||pattern.size!==undefined&&count!==pattern.size)fail('value builder constructor arity');
   if(pattern.sequence&&count>budget.limit)fail('wire sequence size');
   const value=pattern.make(frame.values);
   frames.pop();accept(value);
 };
 const finishOperation=()=>{
   if(frames.length||!complete)fail('value builder root is incomplete');
   closed=true;const handle=__compiledHandle(identity,result);result=undefined;return handle;
 };
 const api=Object.freeze({
  open(choice){return execute(openOperation,choice);},
  // Charge every source constructor even when unary paths share one frame.
  openPath(choices){return execute(openPathOperation,choices);},
  // Complete the path and leaf without intermediate session frames.
  scalarPath(choices,value){return execute(scalarPathOperation,choices,value);},
  emptyPath(choices){return execute(emptyPathOperation,choices);},
  scalar(value){return execute(scalarOperation,value);},
  close(){return execute(closeOperation);},
  finish(){return execute(finishOperation);},
  abort(){if(busy)throw Error('value builder operation already active');failed=true;frames.length=0;result=undefined;},
 });
 return api;
}
function __reduceValue0(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[0];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue1(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue1(value,r,b,d,c){b.enter(d,8);return r[1]({F32Bits:value},c);}
function __reduceValue2(value,r,b,d,c){b.enter(d,4);return r[2](__reduceValue0(value["features"],r,b,d+1,c),__reduceValue1(value["target"],r,b,d+1,c),c);}
function __reduceValue3(value,r,b,d,c){b.enter(d,8);return r[3](value,c);}
function __reduceValue4(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[4](0,__reduceValue0(value.Ok,r,b,d+1,c),c):r[4](1,__reduceValue5(value.Err,r,b,d+1,c),c);}
function __reduceValue5(value,r,b,d,c){b.enter(d,4);b.text(value);return r[5](value,c);}
function __reduceValue6(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[6](0,__reduceValue1(value.Ok,r,b,d+1,c),c):r[6](1,__reduceValue5(value.Err,r,b,d+1,c),c);}
function __reduceValue7(value,r,b,d,c){b.enter(d,5);return r[7](value,c);}
function __reduceValue8(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'None')&&value.None===null?r[8](0,null,c):r[8](1,__reduceValue3(value.Some,r,b,d+1,c),c);}
function __reduceValue9(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[9];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue3(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue10(value,r,b,d,c){b.enter(d,4);return r[10](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue3(value["id"],r,b,d+1,c),c);}
function __reduceValue11(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[11];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue12(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue12(value,r,b,d,c){b.enter(d,4);return r[12](__reduceValue3(value["op"],r,b,d+1,c),__reduceValue3(value["a"],r,b,d+1,c),__reduceValue3(value["b"],r,b,d+1,c),__reduceValue1(value["av"],r,b,d+1,c),__reduceValue1(value["bv"],r,b,d+1,c),__reduceValue1(value["value"],r,b,d+1,c),c);}
function __reduceValue13(value,r,b,d,c){b.enter(d,5);return Object.hasOwn(value,'Ok')?r[13](0,__reduceValue14(value.Ok,r,b,d+1,c),c):r[13](1,__reduceValue5(value.Err,r,b,d+1,c),c);}
function __reduceValue14(value,r,b,d,c){b.enter(d,4);return r[14](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue0(value["gradient"],r,b,d+1,c),c);}
let __reductionNodeCache;function __reductionNodes(){return __reductionNodeCache??=Object.freeze([Object.freeze({"children":Object.freeze([1]),"kind":"list"}),Object.freeze({"children":Object.freeze([]),"kind":"f32"}),Object.freeze({"children":Object.freeze([0,1]),"fields":Object.freeze(["features","target"]),"kind":"record","name":"Context"}),Object.freeze({"children":Object.freeze([]),"kind":"u32"}),Object.freeze({"children":Object.freeze([0,5]),"kind":"result"}),Object.freeze({"children":Object.freeze([]),"kind":"string"}),Object.freeze({"children":Object.freeze([1,5]),"kind":"result"}),Object.freeze({"children":Object.freeze([]),"kind":"bool"}),Object.freeze({"children":Object.freeze([3]),"kind":"option"}),Object.freeze({"children":Object.freeze([3]),"kind":"list"}),Object.freeze({"children":Object.freeze([1,3]),"fields":Object.freeze(["value","id"]),"kind":"record","name":"__ink_reverse_0_Wire"}),Object.freeze({"children":Object.freeze([12]),"kind":"list"}),Object.freeze({"children":Object.freeze([3,3,3,1,1,1]),"fields":Object.freeze(["op","a","b","av","bv","value"]),"kind":"record","name":"__ink_reverse_0_Node"}),Object.freeze({"children":Object.freeze([14,5]),"kind":"result"}),Object.freeze({"children":Object.freeze([1,0]),"fields":Object.freeze(["value","gradient"]),"kind":"record","name":"__ink_reverse_58"})]);}
function __compiledNamed0(){return {};}
let __compiledCodec0Value;function __compiledCodec0(){return __compiledCodec0Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":__compiledNamed0(),"root":{"element":{"kind":"f32"},"kind":"list"}},__privateCapture0,__privateWireValue0,__privateWireWrite0,__compiledOwnedValue0,0,0,__reduceValue0,false,false);}
let __compiledCodec1Value;function __compiledCodec1(){return __compiledCodec1Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"80e41dc143c0deefa2b964386ffbcbf6c9b2a0241f99ce0592f21e733bbd835f","named":__compiledNamed0(),"root":{"fields":[{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"Context"}},__privateCapture2,__privateWireValue3,__privateWireWrite2,__compiledOwnedValue2,2,2,__reduceValue2,false,false);}
let __compiledCodec2Value;function __compiledCodec2(){return __compiledCodec2Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":__compiledNamed0(),"root":{"kind":"f32"}},__privateCapture1,__privateWireValue1,__privateWireWrite1,__compiledOwnedValue1,1,1,__reduceValue1,false,false);}
let __compiledCodec3Value;function __compiledCodec3(){return __compiledCodec3Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff","named":__compiledNamed0(),"root":{"kind":"u32"}},__privateCapture3,__privateWireValue5,__privateWireWrite3,__compiledOwnedValue3,3,3,__reduceValue3,false,false);}
let __compiledCodec4Value;function __compiledCodec4(){return __compiledCodec4Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"b04d6d649eefb7b6403c8a905c4f10916e9a95616519c1b03136a24a64f35c31","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"element":{"kind":"f32"},"kind":"list"}}},__privateCapture4,__privateWireValue6,__privateWireWrite4,__compiledOwnedValue4,4,4,__reduceValue4,false,false);}
let __compiledCodec5Value;function __compiledCodec5(){return __compiledCodec5Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"29bcdada2d2b5ecb6deae18e25401ad25c1f0dc80bcd50defebf64892403468d","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"kind":"f32"}}},__privateCapture6,__privateWireValue9,__privateWireWrite6,__compiledOwnedValue6,6,6,__reduceValue6,false,false);}
let __compiledCodec6Value;function __compiledCodec6(){return __compiledCodec6Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":__compiledNamed0(),"root":{"kind":"bool"}},__privateCapture7,__privateWireValue10,__privateWireWrite7,__compiledOwnedValue7,7,7,__reduceValue7,false,false);}
let __compiledCodec7Value;function __compiledCodec7(){return __compiledCodec7Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"f4055357f369cc8f275f6cc1d5569678031edf449ad32c3c8d392d37fab5b1ed","named":__compiledNamed0(),"root":{"element":{"kind":"u32"},"kind":"option"}},__privateCapture8,__privateWireValue14,__privateWireWrite8,__compiledOwnedValue8,8,8,__reduceValue8,false,false);}
let __compiledCodec8Value;function __compiledCodec8(){return __compiledCodec8Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"69ebf947aa59a2546656d1976b0baa6e56e7182d989425379b31e3bff74168ca","named":__compiledNamed0(),"root":{"element":{"kind":"u32"},"kind":"list"}},__privateCapture9,__privateWireValue15,__privateWireWrite9,__compiledOwnedValue9,9,9,__reduceValue9,false,false);}
let __compiledCodec9Value;function __compiledCodec9(){return __compiledCodec9Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fabc4e63e940c6190680726874c8654deced79200b320c057b9389a135a08557","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"id","type":{"kind":"u32"}}],"kind":"record","name":"__ink_reverse_0_Wire"}},__privateCapture10,__privateWireValue18,__privateWireWrite10,__compiledOwnedValue10,10,10,__reduceValue10,false,false);}
let __compiledCodec10Value;function __compiledCodec10(){return __compiledCodec10Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"8d20db2e18176975b811079510807748b5da77b30341fa86eaec165fb19262b0","named":__compiledNamed0(),"root":{"element":{"fields":[{"name":"op","type":{"kind":"u32"}},{"name":"a","type":{"kind":"u32"}},{"name":"b","type":{"kind":"u32"}},{"name":"av","type":{"kind":"f32"}},{"name":"bv","type":{"kind":"f32"}},{"name":"value","type":{"kind":"f32"}}],"kind":"record","name":"__ink_reverse_0_Node"},"kind":"list"}},__privateCapture11,__privateWireValue20,__privateWireWrite11,__compiledOwnedValue11,11,11,__reduceValue11,false,false);}
let __compiledCodec11Value;function __compiledCodec11(){return __compiledCodec11Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"f2d8a6a6c76daa0750e8dd172034ca17108eb15fc853843947bdb021fd452611","named":__compiledNamed0(),"root":{"error":{"kind":"string"},"kind":"result","ok":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"__ink_reverse_58"}}},__privateCapture13,__privateWireValue24,__privateWireWrite13,__compiledOwnedValue13,13,13,__reduceValue13,false,false);}
const __compiledEntries=new Map([["initial",{index:0,params:[],result:__compiledCodec0,arguments:__privateWireValue2,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[],precondition:null}],["model",{index:1,params:[__compiledCodec0,__compiledCodec1],result:__compiledCodec2,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["objective",{index:2,params:[__compiledCodec0,__compiledCodec1],result:__compiledCodec2,arguments:__privateWireValue4,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["derivatives",{index:3,params:[__compiledCodec0,__compiledCodec1,__compiledCodec3],result:__compiledCodec4,arguments:__privateWireValue8,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["linearized_value",{index:4,params:[__compiledCodec0,__compiledCodec1,__compiledCodec3],result:__compiledCodec5,arguments:__privateWireValue8,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["valid",{index:5,params:[__compiledCodec0],result:__compiledCodec6,arguments:__privateWireValue11,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["update",{index:6,params:[__compiledCodec0,__compiledCodec0,__compiledCodec2],result:__compiledCodec0,arguments:__privateWireValue12,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["admissible",{index:7,params:[__compiledCodec1],result:__compiledCodec6,arguments:__privateWireValue13,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["branch_owned",{index:8,params:[__compiledCodec7],result:__compiledCodec8,arguments:__privateWireValue16,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["device",{index:9,params:[__compiledCodec0],result:__compiledCodec0,arguments:__privateWireValue17,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["__ink_reverse_0_constant",{index:10,params:[__compiledCodec2],result:__compiledCodec9,arguments:__privateWireValue19,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["__ink_reverse_0_backward",{index:18,params:[__compiledCodec10,__compiledCodec9,__compiledCodec6],result:__compiledCodec0,arguments:__privateWireValue22,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["__ink_reverse_37",{index:21,params:[__compiledCodec0,__compiledCodec3,__compiledCodec6,__compiledCodec1],result:__compiledCodec4,arguments:__privateWireValue23,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["__ink_reverse_50",{index:22,params:[__compiledCodec0,__compiledCodec3,__compiledCodec6,__compiledCodec1],result:__compiledCodec11,arguments:__privateWireValue26,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}]]);

export const compiledValues=Object.freeze(Object.fromEntries([...__compiledEntries].map(([name,entry])=>[name,Object.freeze({get params(){return Object.freeze(entry.params.map(codec=>codec()));},get result(){return entry.result();}})])));
function __compiledValidate(entry,owned){
 const values=owned.map(v=>v.value);
 const established=entry.onlyTypeGuards&&entry.needsInvariants.every((needed,i)=>!needed||owned[i].guaranteed);
 if(entry.precondition!==null&&!established){
  if(__implementations[entry.precondition](...values)!==true)throw Error('contract precondition failed');
  for(let i=0;i<owned.length;i++)if(entry.needsInvariants[i])owned[i].guaranteed=true;
 }
 return values;
}
export function callCompiled(name,args){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(args)||args.length!==entry.params.length)throw Error('unsupported compiled call');
 const owned=entry.params.map((codec,i)=>__compiledEntry(args[i],codec().identity)),values=__compiledValidate(entry,owned);
 // Checked source outputs satisfy their declared value interfaces. Private
 // handles expose only detached copies and never retain mutable host inputs.
 return __compiledHandle(entry.result().identity,__implementations[entry.index](...values),true);
}

// Explicit sealed-value partial application. Each token owns a bounded set of
// lexical caches; no mutable host object, global memo table or error is retained.
const __preparedCompiled=new WeakMap();
export function prepareCompiled(name,bindings){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(bindings)||bindings.length>entry.params.length)throw Error('unsupported prepared compiled call');
 const captured=new Array(entry.params.length),fixed=new Array(entry.params.length).fill(false);
 for(const binding of bindings){
  if(!Array.isArray(binding)||binding.length!==2)throw Error('prepared compiled binding');
  const [index,handle]=binding;
  if(!Number.isInteger(index)||index<0||index>=fixed.length||fixed[index])throw Error('prepared compiled parameter');
  captured[index]=__compiledEntry(handle,entry.params[index]().identity);fixed[index]=true;
 }
 const remaining=fixed.flatMap((yes,i)=>yes?[]:[i]);
 const factory=__preparedFactories.get(entry.index);
 const run=factory?factory(fixed):__implementations[entry.index];
 const token=Object.freeze(Object.create(null));
 __preparedCompiled.set(token,{entry,captured,remaining,run});return token;
}
export function callPreparedCompiled(token,args){
 const prepared=__preparedCompiled.get(token);
 if(!prepared||!Array.isArray(args)||args.length!==prepared.remaining.length)throw Error('invalid prepared compiled call');
 const {entry,captured,remaining,run}=prepared,owned=captured.slice();
 for(let i=0;i<remaining.length;i++){const at=remaining[i];owned[at]=__compiledEntry(args[i],entry.params[at]().identity);}
 const values=__compiledValidate(entry,owned);
 return __compiledHandle(entry.result().identity,run(...values),true);
}
const __intoOutput0=__representation(metadata.functions[0].result.element,true);
const __intoOutput6=__representation(metadata.functions[6].result.element,true);
const __intoOutput9=__representation(metadata.functions[9].result.element,true);
const __intoOutput18=__representation(metadata.functions[18].result.element,true);
const __intoImplementations=[__into0,null,null,null,null,null,__into6,null,__into8,__into9,null,null,null,null,null,null,null,null,__into18,null,null,null,null];

export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>{
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const body=__intoImplementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args.slice(0,f.params.length))!==true)throw Error('contract precondition failed');return body(...args);};
  const entry=input.every(c=>c===__identity)?implementation:(...values)=>{const context=new WeakMap();return implementation(...input.map((convert,i)=>convert(values[i],context)),values[f.params.length]);};
  return [f.name,entry];
})));
export function callInto(name,args,destination){switch(name){case "__ink_reverse_0_append":case "__ink_reverse_0_seed":case "__ink_reverse_0_binary":case "__ink_reverse_0_unary":case "__ink_reverse_0_add":case "__ink_reverse_0_back_node":case "__ink_reverse_0_back_step":case "__ink_reverse_4":case "__ink_reverse_1":throw new Error('temporary storage is internal to a pure invocation');}return functionsInto[name](...args,destination);}

function __preparedPart(mask,path){
 for(const field of path){
  if(mask===true)return true;
  if(!mask || typeof mask!=="object")return false;
  mask=Object.hasOwn(mask.fields,field)?mask.fields[field]:false;
 }
 return mask;
}
function __preparedStable(mask,path){const part=__preparedPart(mask,path);return part===true || (!!part && part.all===true);}
function __prepareFn2(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn2;const v1761=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]);
let v1760=false,v1759;
return function(v1756,v1757){let v1758;if(v1761&&v1760){v1758=v1759;}else{
const v1762=__fn1(v1756,v1757);
const v1763=v1757["target"];
v1758=__bits(__float(v1762) - __float(v1763));if(v1761){v1759=v1758;v1760=true;}}
const v1764=v1758;
const v1765=v1758;
return __bits(__float(v1764) * __float(v1765));};}
function __prepareFn3(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[]))))return __fn3;const v1772=depth<15&&__preparedFactories.has(21)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[])));
let v1770;
return function(v1766,v1767,v1768){const v1769=true;
let v1773;if(v1772){if(!v1770){const v1771=__preparedFactories.get(21);v1770=v1771([fixed[0],fixed[2],true,fixed[1]],depth+1);}v1773=v1770(v1766,v1768,v1769,v1767);}else{v1773=__fn21(v1766,v1768,v1769,v1767);}
return v1773;};}
function __prepareFn4(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[]))))return __fn4;const v1780=depth<15&&__preparedFactories.has(22)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[2],[])));
let v1778;
return function(v1774,v1775,v1776){const v1777=true;
let v1781;if(v1780){if(!v1778){const v1779=__preparedFactories.get(22);v1778=v1779([fixed[0],fixed[2],true,fixed[1]],depth+1);}v1781=v1778(v1774,v1776,v1777,v1775);}else{v1781=__fn22(v1774,v1776,v1777,v1775);}
const v1782=v1781;
let v1783;if(Object.hasOwn(v1782,"Ok")){
const v1784=v1782["Ok"];
v1783=({Ok:v1784["value"]});}else{
v1783=({Err:v1782["Err"]});}
return v1783;};}
function __prepareFn21(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn21;const v2259=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],["features"])&&__preparedStable(fixed[3],["target"]);
let v2258=false,v2257;
const v2264=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[3],["features"])&&__preparedStable(fixed[3],["target"]);
const v2269=depth<15&&__preparedFactories.has(18)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[3],["features"])&&__preparedStable(fixed[3],["target"])));
let v2267;
return function(v1920,v1921,v1922,v1923){const v1924=1000000;
const v1925=((v1921) > (v1924));
let v1926;if(v1925){
v1926=({Err:"reverse differentiation capacity exceeds one million nodes"});}else{
const v1929=new __InkBuffer([]);
const v1930=new __InkBuffer([]);
const v1931=false;
const v1932=({["nodes"]:v1930,["maximum"]:v1921,["failed"]:v1931});
const v1933=0;
let v1934=v1929;
let v1935=v1932;
let v1936=v1933;
for(let v1938=0;v1938<v1920.length;v1938++){
const v1939=v1920[v1938];
const v1940=v1935;
const v1941=0;
const v1942=4294967295;
const v1943=4294967295;
const v1944=0;
const v1945=0;
const v1947=true;
const v1948=false;
const v1949=(v1947===v1948);
let v1950=v1949;if(!v1950){
v1950=v1940["failed"];}
let v1951;
let v1952;
if(v1950){
const v1953=__fn10(v1939);
v1951=v1953;
v1952=v1940;
}else{
const v1954=v1940["nodes"];
const v1955=(v1954).length;
const v1956=v1940["maximum"];
let v1957;
let v1958;
if(((v1955) >= (v1956))){
const v1959=__fn10(v1939);
const v1960=true;
const v1961=v1940["nodes"];
const v1962=v1940["maximum"];
const v1963=({["nodes"]:v1961,["maximum"]:v1962,["failed"]:v1960});
v1957=v1959;
v1958=v1963;
}else{
const v1964=({["value"]:v1939,["id"]:v1955});
const v1965=v1940["nodes"];
const v1966=({["op"]:v1941,["a"]:v1942,["b"]:v1943,["av"]:v1944,["bv"]:v1945,["value"]:v1939});
const v1967=__tempEdit(v1965,"push",v1966);
const v1968=v1940["maximum"];
const v1969=v1940["failed"];
const v1970=({["nodes"]:v1967,["maximum"]:v1968,["failed"]:v1969});
v1957=v1964;
v1958=v1970;
}
v1951=v1957;
v1952=v1958;
}
const v1972=v1934;
const v1973=v1951;
const v1974=__tempEdit(v1972,"push",v1973);
const v1975=v1952;
const v1976=v1936;
const v1977=1;
const v1978=(((v1976) + (v1977)) >>> 0);
v1934=v1974;
v1935=v1975;
v1936=v1978;
}
const v1928=({["values"]:v1934,["tape"]:v1935,["index"]:v1936});
const v1979=v1928;
const v1980=v1979["values"];
const v1981=v1980.freeze();
const v1982=v1928;
const v1983=v1982["tape"];
const v1927=({["value"]:v1981,["tape"]:v1983});
const v1985=v1927;
const v1986=v1985["value"];
const v1987=v1923["features"];
const v1988=v1987.length;
const v1989=new Array(v1988);
for(let v1990=0;v1990<v1988;v1990++){
const v1991=v1987[v1990];
v1989[v1990]=__fn10(v1991);
}
const v1992=v1923["target"];
const v1993=__fn10(v1992);
const v1995=v1927;
const v1996=v1995["tape"];
const v1998=({["features"]:v1989,["target"]:v1993});
const v2002=v1998["features"];
const v2004=Math.min(v1986.length,v2002.length);
const v2005=new Array(v2004);
for(let v2006=0;v2006<v2004;v2006++){
const v2007=v1986[v2006];
const v2008=v2002[v2006];
v2005[v2006]=({["left"]:v2007,["right"]:v2008});
}
const v2009=new __InkBuffer([]);
const v2010=0;
let v2011=v2009;
let v2012=v1996;
let v2013=v2010;
for(let v2015=0;v2015<v2005.length;v2015++){
const v2016=v2005[v2015];
const v2017=v2016["left"];
const v2018=v2016["right"];
const v2019=v2012;
const v2022=3;
const v2023=1;
let v2024;if((v2022===v2023)){
const v2025=v2017["value"];
const v2026=v2018["value"];
v2024=__bits(__float(v2025) + __float(v2026));}else{
const v2027=2;
let v2028;if((v2022===v2027)){
const v2029=v2017["value"];
const v2030=v2018["value"];
v2028=__bits(__float(v2029) - __float(v2030));}else{
const v2031=3;
let v2032;if((v2022===v2031)){
const v2033=v2017["value"];
const v2034=v2018["value"];
v2032=__bits(__float(v2033) * __float(v2034));}else{
v2032=__bits((__float(v2017["value"]))/(__float(v2018["value"])));}
v2028=v2032;}
v2024=v2028;}
const v2035=v2024;
const v2036=v2017["id"];
const v2037=v2018["id"];
const v2038=v2017["value"];
const v2039=v2018["value"];
const v2041=v2017["id"];
const v2042=4294967295;
const v2043=!(v2041===v2042);
let v2044=v2043;if(!v2044){
const v2045=v2018["id"];
const v2046=4294967295;
v2044=!(v2045===v2046);}
const v2047=v2044;
const v2048=false;
const v2049=(v2047===v2048);
let v2050=v2049;if(!v2050){
v2050=v2019["failed"];}
let v2051;
let v2052;
if(v2050){
const v2053=__fn10(v2035);
v2051=v2053;
v2052=v2019;
}else{
const v2054=v2019["nodes"];
const v2055=(v2054).length;
const v2056=v2019["maximum"];
let v2057;
let v2058;
if(((v2055) >= (v2056))){
const v2059=__fn10(v2035);
const v2060=true;
const v2061=v2019["nodes"];
const v2062=v2019["maximum"];
const v2063=({["nodes"]:v2061,["maximum"]:v2062,["failed"]:v2060});
v2057=v2059;
v2058=v2063;
}else{
const v2064=({["value"]:v2035,["id"]:v2055});
const v2065=v2019["nodes"];
const v2066=({["op"]:v2022,["a"]:v2036,["b"]:v2037,["av"]:v2038,["bv"]:v2039,["value"]:v2035});
const v2067=__tempEdit(v2065,"push",v2066);
const v2068=v2019["maximum"];
const v2069=v2019["failed"];
const v2070=({["nodes"]:v2067,["maximum"]:v2068,["failed"]:v2069});
v2057=v2064;
v2058=v2070;
}
v2051=v2057;
v2052=v2058;
}
const v2072=v2011;
const v2073=v2051;
const v2074=__tempEdit(v2072,"push",v2073);
const v2075=v2052;
const v2076=v2013;
const v2077=1;
const v2078=(((v2076) + (v2077)) >>> 0);
v2011=v2074;
v2012=v2075;
v2013=v2078;
}
const v2080=v2011;
const v2081=v2080.freeze();
const v2082=v2012;
const v2084=0;
const v2085=__fn10(v2084);
let v2086=v2085;
let v2087=v2082;
for(let v2089=0;v2089<v2081.length;v2089++){
const v2090=v2081[v2089];
const v2091=1;
const v2092=v2087;
const v2093=v2086;
const v2094=1;
let v2095;if((v2091===v2094)){
const v2096=v2093["value"];
const v2097=v2090["value"];
v2095=__bits(__float(v2096) + __float(v2097));}else{
const v2098=2;
let v2099;if((v2091===v2098)){
const v2100=v2093["value"];
const v2101=v2090["value"];
v2099=__bits(__float(v2100) - __float(v2101));}else{
const v2102=3;
let v2103;if((v2091===v2102)){
const v2104=v2093["value"];
const v2105=v2090["value"];
v2103=__bits(__float(v2104) * __float(v2105));}else{
v2103=__bits((__float(v2093["value"]))/(__float(v2090["value"])));}
v2099=v2103;}
v2095=v2099;}
const v2106=v2095;
const v2107=v2093["id"];
const v2108=v2090["id"];
const v2109=v2093["value"];
const v2110=v2090["value"];
const v2112=v2093["id"];
const v2113=4294967295;
const v2114=!(v2112===v2113);
let v2115=v2114;if(!v2115){
const v2116=v2090["id"];
const v2117=4294967295;
v2115=!(v2116===v2117);}
const v2118=v2115;
const v2119=false;
const v2120=(v2118===v2119);
let v2121=v2120;if(!v2121){
v2121=v2092["failed"];}
let v2122;
let v2123;
if(v2121){
const v2124=__fn10(v2106);
v2122=v2124;
v2123=v2092;
}else{
const v2125=v2092["nodes"];
const v2126=(v2125).length;
const v2127=v2092["maximum"];
let v2128;
let v2129;
if(((v2126) >= (v2127))){
const v2130=__fn10(v2106);
const v2131=true;
const v2132=v2092["nodes"];
const v2133=v2092["maximum"];
const v2134=({["nodes"]:v2132,["maximum"]:v2133,["failed"]:v2131});
v2128=v2130;
v2129=v2134;
}else{
const v2135=({["value"]:v2106,["id"]:v2126});
const v2136=v2092["nodes"];
const v2137=({["op"]:v2091,["a"]:v2107,["b"]:v2108,["av"]:v2109,["bv"]:v2110,["value"]:v2106});
const v2138=__tempEdit(v2136,"push",v2137);
const v2139=v2092["maximum"];
const v2140=v2092["failed"];
const v2141=({["nodes"]:v2138,["maximum"]:v2139,["failed"]:v2140});
v2128=v2135;
v2129=v2141;
}
v2122=v2128;
v2123=v2129;
}
v2086=v2122;
v2087=v2123;
}
const v2143=({["features"]:v1989,["target"]:v1993});
const v2144=v2087;
const v2146=v2143["target"];
const v2148=2;
const v2149=v2086;
const v2150=1;
let v2151;if((v2148===v2150)){
const v2152=v2149["value"];
const v2153=v2146["value"];
v2151=__bits(__float(v2152) + __float(v2153));}else{
const v2154=2;
let v2155;if((v2148===v2154)){
const v2156=v2149["value"];
const v2157=v2146["value"];
v2155=__bits(__float(v2156) - __float(v2157));}else{
const v2158=3;
let v2159;if((v2148===v2158)){
const v2160=v2149["value"];
const v2161=v2146["value"];
v2159=__bits(__float(v2160) * __float(v2161));}else{
v2159=__bits((__float(v2149["value"]))/(__float(v2146["value"])));}
v2155=v2159;}
v2151=v2155;}
const v2162=v2151;
const v2163=v2149["id"];
const v2164=v2146["id"];
const v2165=v2149["value"];
const v2166=v2146["value"];
const v2168=v2149["id"];
const v2169=4294967295;
const v2170=!(v2168===v2169);
let v2171=v2170;if(!v2171){
const v2172=v2146["id"];
const v2173=4294967295;
v2171=!(v2172===v2173);}
const v2174=v2171;
const v2175=false;
const v2176=(v2174===v2175);
let v2177=v2176;if(!v2177){
v2177=v2144["failed"];}
let v2178;
let v2179;
if(v2177){
const v2180=__fn10(v2162);
v2178=v2180;
v2179=v2144;
}else{
const v2181=v2144["nodes"];
const v2182=(v2181).length;
const v2183=v2144["maximum"];
let v2184;
let v2185;
if(((v2182) >= (v2183))){
const v2186=__fn10(v2162);
const v2187=true;
const v2188=v2144["nodes"];
const v2189=v2144["maximum"];
const v2190=({["nodes"]:v2188,["maximum"]:v2189,["failed"]:v2187});
v2184=v2186;
v2185=v2190;
}else{
const v2191=({["value"]:v2162,["id"]:v2182});
const v2192=v2144["nodes"];
const v2193=({["op"]:v2148,["a"]:v2163,["b"]:v2164,["av"]:v2165,["bv"]:v2166,["value"]:v2162});
const v2194=__tempEdit(v2192,"push",v2193);
const v2195=v2144["maximum"];
const v2196=v2144["failed"];
const v2197=({["nodes"]:v2194,["maximum"]:v2195,["failed"]:v2196});
v2184=v2191;
v2185=v2197;
}
v2178=v2184;
v2179=v2185;
}
const v2199=v2178;
const v2200=v2179;
const v2203=3;
const v2204=1;
let v2205;if((v2203===v2204)){
const v2206=v2199["value"];
const v2207=v2199["value"];
v2205=__bits(__float(v2206) + __float(v2207));}else{
const v2208=2;
let v2209;if((v2203===v2208)){
const v2210=v2199["value"];
const v2211=v2199["value"];
v2209=__bits(__float(v2210) - __float(v2211));}else{
const v2212=3;
let v2213;if((v2203===v2212)){
const v2214=v2199["value"];
const v2215=v2199["value"];
v2213=__bits(__float(v2214) * __float(v2215));}else{
v2213=__bits((__float(v2199["value"]))/(__float(v2199["value"])));}
v2209=v2213;}
v2205=v2209;}
const v2216=v2205;
const v2217=v2199["id"];
const v2218=v2199["id"];
const v2219=v2199["value"];
const v2220=v2199["value"];
const v2222=v2199["id"];
const v2223=4294967295;
const v2224=!(v2222===v2223);
let v2225=v2224;if(!v2225){
const v2226=v2199["id"];
const v2227=4294967295;
v2225=!(v2226===v2227);}
const v2228=v2225;
const v2229=false;
const v2230=(v2228===v2229);
let v2231=v2230;if(!v2231){
v2231=v2200["failed"];}
let v2232;
let v2233;
if(v2231){
const v2234=__fn10(v2216);
v2232=v2234;
v2233=v2200;
}else{
const v2235=v2200["nodes"];
const v2236=(v2235).length;
const v2237=v2200["maximum"];
let v2238;
let v2239;
if(((v2236) >= (v2237))){
const v2240=__fn10(v2216);
const v2241=true;
const v2242=v2200["nodes"];
const v2243=v2200["maximum"];
const v2244=({["nodes"]:v2242,["maximum"]:v2243,["failed"]:v2241});
v2238=v2240;
v2239=v2244;
}else{
const v2245=({["value"]:v2216,["id"]:v2236});
const v2246=v2200["nodes"];
const v2247=({["op"]:v2203,["a"]:v2217,["b"]:v2218,["av"]:v2219,["bv"]:v2220,["value"]:v2216});
const v2248=__tempEdit(v2246,"push",v2247);
const v2249=v2200["maximum"];
const v2250=v2200["failed"];
const v2251=({["nodes"]:v2248,["maximum"]:v2249,["failed"]:v2250});
v2238=v2245;
v2239=v2251;
}
v2232=v2238;
v2233=v2239;
}
const v1984=({["value"]:v2232,["tape"]:v2233});
const v2252=v1984;
const v2253=v2252["tape"];
const v2254=v2253["failed"];
let v2255;if(v2254){
v2255=({Err:"reverse differentiation tape capacity exceeded"});}else{
let v2256;if(v2259&&v2258){v2256=v2257;}else{
const v2260=v1984;
const v2261=v2260["tape"];
const v2262=v2261["nodes"];
const v2263=v2262.freeze();
const v2265=v1984;
const v2266=v2265["value"];
let v2270;if(v2269){if(!v2267){const v2268=__preparedFactories.get(18);v2267=v2268([v2264,v2264,fixed[2]],depth+1);}v2270=v2267(v2263,v2266,v1922);}else{v2270=__fn18(v2263,v2266,v1922);}
v2256=v2270;if(v2259){v2257=v2256;v2258=true;}}
const v2271=v1927;
const v2272=v2271["value"];
const v2273=v2272.length;
const v2274=new Array(v2273);
for(let v2275=0;v2275<v2273;v2275++){
const v2276=v2272[v2275];
const v2277=v2256;
const v2278=v2276["id"];
let v2279;if(v2278<v2277.length){v2279=v2277[v2278];}else{
v2279=0;}
v2274[v2275]=v2279;
}
v2255=({Ok:v2274});}
v1926=v2255;}
return v1926;};}
function __prepareFn22(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[]))))return __fn22;const v2619=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],["features"])&&__preparedStable(fixed[3],["target"]);
let v2618=false,v2617;
const v2624=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[3],["features"])&&__preparedStable(fixed[3],["target"]);
const v2629=depth<15&&__preparedFactories.has(18)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[3],["features"])&&__preparedStable(fixed[3],["target"])));
let v2627;
return function(v2280,v2281,v2282,v2283){const v2284=1000000;
const v2285=((v2281) > (v2284));
let v2286;if(v2285){
v2286=({Err:"reverse differentiation capacity exceeds one million nodes"});}else{
const v2289=new __InkBuffer([]);
const v2290=new __InkBuffer([]);
const v2291=false;
const v2292=({["nodes"]:v2290,["maximum"]:v2281,["failed"]:v2291});
const v2293=0;
let v2294=v2289;
let v2295=v2292;
let v2296=v2293;
for(let v2298=0;v2298<v2280.length;v2298++){
const v2299=v2280[v2298];
const v2300=v2295;
const v2301=0;
const v2302=4294967295;
const v2303=4294967295;
const v2304=0;
const v2305=0;
const v2307=true;
const v2308=false;
const v2309=(v2307===v2308);
let v2310=v2309;if(!v2310){
v2310=v2300["failed"];}
let v2311;
let v2312;
if(v2310){
const v2313=__fn10(v2299);
v2311=v2313;
v2312=v2300;
}else{
const v2314=v2300["nodes"];
const v2315=(v2314).length;
const v2316=v2300["maximum"];
let v2317;
let v2318;
if(((v2315) >= (v2316))){
const v2319=__fn10(v2299);
const v2320=true;
const v2321=v2300["nodes"];
const v2322=v2300["maximum"];
const v2323=({["nodes"]:v2321,["maximum"]:v2322,["failed"]:v2320});
v2317=v2319;
v2318=v2323;
}else{
const v2324=({["value"]:v2299,["id"]:v2315});
const v2325=v2300["nodes"];
const v2326=({["op"]:v2301,["a"]:v2302,["b"]:v2303,["av"]:v2304,["bv"]:v2305,["value"]:v2299});
const v2327=__tempEdit(v2325,"push",v2326);
const v2328=v2300["maximum"];
const v2329=v2300["failed"];
const v2330=({["nodes"]:v2327,["maximum"]:v2328,["failed"]:v2329});
v2317=v2324;
v2318=v2330;
}
v2311=v2317;
v2312=v2318;
}
const v2332=v2294;
const v2333=v2311;
const v2334=__tempEdit(v2332,"push",v2333);
const v2335=v2312;
const v2336=v2296;
const v2337=1;
const v2338=(((v2336) + (v2337)) >>> 0);
v2294=v2334;
v2295=v2335;
v2296=v2338;
}
const v2288=({["values"]:v2294,["tape"]:v2295,["index"]:v2296});
const v2339=v2288;
const v2340=v2339["values"];
const v2341=v2340.freeze();
const v2342=v2288;
const v2343=v2342["tape"];
const v2287=({["value"]:v2341,["tape"]:v2343});
const v2345=v2287;
const v2346=v2345["value"];
const v2347=v2283["features"];
const v2348=v2347.length;
const v2349=new Array(v2348);
for(let v2350=0;v2350<v2348;v2350++){
const v2351=v2347[v2350];
v2349[v2350]=__fn10(v2351);
}
const v2352=v2283["target"];
const v2353=__fn10(v2352);
const v2355=v2287;
const v2356=v2355["tape"];
const v2358=({["features"]:v2349,["target"]:v2353});
const v2362=v2358["features"];
const v2364=Math.min(v2346.length,v2362.length);
const v2365=new Array(v2364);
for(let v2366=0;v2366<v2364;v2366++){
const v2367=v2346[v2366];
const v2368=v2362[v2366];
v2365[v2366]=({["left"]:v2367,["right"]:v2368});
}
const v2369=new __InkBuffer([]);
const v2370=0;
let v2371=v2369;
let v2372=v2356;
let v2373=v2370;
for(let v2375=0;v2375<v2365.length;v2375++){
const v2376=v2365[v2375];
const v2377=v2376["left"];
const v2378=v2376["right"];
const v2379=v2372;
const v2382=3;
const v2383=1;
let v2384;if((v2382===v2383)){
const v2385=v2377["value"];
const v2386=v2378["value"];
v2384=__bits(__float(v2385) + __float(v2386));}else{
const v2387=2;
let v2388;if((v2382===v2387)){
const v2389=v2377["value"];
const v2390=v2378["value"];
v2388=__bits(__float(v2389) - __float(v2390));}else{
const v2391=3;
let v2392;if((v2382===v2391)){
const v2393=v2377["value"];
const v2394=v2378["value"];
v2392=__bits(__float(v2393) * __float(v2394));}else{
v2392=__bits((__float(v2377["value"]))/(__float(v2378["value"])));}
v2388=v2392;}
v2384=v2388;}
const v2395=v2384;
const v2396=v2377["id"];
const v2397=v2378["id"];
const v2398=v2377["value"];
const v2399=v2378["value"];
const v2401=v2377["id"];
const v2402=4294967295;
const v2403=!(v2401===v2402);
let v2404=v2403;if(!v2404){
const v2405=v2378["id"];
const v2406=4294967295;
v2404=!(v2405===v2406);}
const v2407=v2404;
const v2408=false;
const v2409=(v2407===v2408);
let v2410=v2409;if(!v2410){
v2410=v2379["failed"];}
let v2411;
let v2412;
if(v2410){
const v2413=__fn10(v2395);
v2411=v2413;
v2412=v2379;
}else{
const v2414=v2379["nodes"];
const v2415=(v2414).length;
const v2416=v2379["maximum"];
let v2417;
let v2418;
if(((v2415) >= (v2416))){
const v2419=__fn10(v2395);
const v2420=true;
const v2421=v2379["nodes"];
const v2422=v2379["maximum"];
const v2423=({["nodes"]:v2421,["maximum"]:v2422,["failed"]:v2420});
v2417=v2419;
v2418=v2423;
}else{
const v2424=({["value"]:v2395,["id"]:v2415});
const v2425=v2379["nodes"];
const v2426=({["op"]:v2382,["a"]:v2396,["b"]:v2397,["av"]:v2398,["bv"]:v2399,["value"]:v2395});
const v2427=__tempEdit(v2425,"push",v2426);
const v2428=v2379["maximum"];
const v2429=v2379["failed"];
const v2430=({["nodes"]:v2427,["maximum"]:v2428,["failed"]:v2429});
v2417=v2424;
v2418=v2430;
}
v2411=v2417;
v2412=v2418;
}
const v2432=v2371;
const v2433=v2411;
const v2434=__tempEdit(v2432,"push",v2433);
const v2435=v2412;
const v2436=v2373;
const v2437=1;
const v2438=(((v2436) + (v2437)) >>> 0);
v2371=v2434;
v2372=v2435;
v2373=v2438;
}
const v2440=v2371;
const v2441=v2440.freeze();
const v2442=v2372;
const v2444=0;
const v2445=__fn10(v2444);
let v2446=v2445;
let v2447=v2442;
for(let v2449=0;v2449<v2441.length;v2449++){
const v2450=v2441[v2449];
const v2451=1;
const v2452=v2447;
const v2453=v2446;
const v2454=1;
let v2455;if((v2451===v2454)){
const v2456=v2453["value"];
const v2457=v2450["value"];
v2455=__bits(__float(v2456) + __float(v2457));}else{
const v2458=2;
let v2459;if((v2451===v2458)){
const v2460=v2453["value"];
const v2461=v2450["value"];
v2459=__bits(__float(v2460) - __float(v2461));}else{
const v2462=3;
let v2463;if((v2451===v2462)){
const v2464=v2453["value"];
const v2465=v2450["value"];
v2463=__bits(__float(v2464) * __float(v2465));}else{
v2463=__bits((__float(v2453["value"]))/(__float(v2450["value"])));}
v2459=v2463;}
v2455=v2459;}
const v2466=v2455;
const v2467=v2453["id"];
const v2468=v2450["id"];
const v2469=v2453["value"];
const v2470=v2450["value"];
const v2472=v2453["id"];
const v2473=4294967295;
const v2474=!(v2472===v2473);
let v2475=v2474;if(!v2475){
const v2476=v2450["id"];
const v2477=4294967295;
v2475=!(v2476===v2477);}
const v2478=v2475;
const v2479=false;
const v2480=(v2478===v2479);
let v2481=v2480;if(!v2481){
v2481=v2452["failed"];}
let v2482;
let v2483;
if(v2481){
const v2484=__fn10(v2466);
v2482=v2484;
v2483=v2452;
}else{
const v2485=v2452["nodes"];
const v2486=(v2485).length;
const v2487=v2452["maximum"];
let v2488;
let v2489;
if(((v2486) >= (v2487))){
const v2490=__fn10(v2466);
const v2491=true;
const v2492=v2452["nodes"];
const v2493=v2452["maximum"];
const v2494=({["nodes"]:v2492,["maximum"]:v2493,["failed"]:v2491});
v2488=v2490;
v2489=v2494;
}else{
const v2495=({["value"]:v2466,["id"]:v2486});
const v2496=v2452["nodes"];
const v2497=({["op"]:v2451,["a"]:v2467,["b"]:v2468,["av"]:v2469,["bv"]:v2470,["value"]:v2466});
const v2498=__tempEdit(v2496,"push",v2497);
const v2499=v2452["maximum"];
const v2500=v2452["failed"];
const v2501=({["nodes"]:v2498,["maximum"]:v2499,["failed"]:v2500});
v2488=v2495;
v2489=v2501;
}
v2482=v2488;
v2483=v2489;
}
v2446=v2482;
v2447=v2483;
}
const v2503=({["features"]:v2349,["target"]:v2353});
const v2504=v2447;
const v2506=v2503["target"];
const v2508=2;
const v2509=v2446;
const v2510=1;
let v2511;if((v2508===v2510)){
const v2512=v2509["value"];
const v2513=v2506["value"];
v2511=__bits(__float(v2512) + __float(v2513));}else{
const v2514=2;
let v2515;if((v2508===v2514)){
const v2516=v2509["value"];
const v2517=v2506["value"];
v2515=__bits(__float(v2516) - __float(v2517));}else{
const v2518=3;
let v2519;if((v2508===v2518)){
const v2520=v2509["value"];
const v2521=v2506["value"];
v2519=__bits(__float(v2520) * __float(v2521));}else{
v2519=__bits((__float(v2509["value"]))/(__float(v2506["value"])));}
v2515=v2519;}
v2511=v2515;}
const v2522=v2511;
const v2523=v2509["id"];
const v2524=v2506["id"];
const v2525=v2509["value"];
const v2526=v2506["value"];
const v2528=v2509["id"];
const v2529=4294967295;
const v2530=!(v2528===v2529);
let v2531=v2530;if(!v2531){
const v2532=v2506["id"];
const v2533=4294967295;
v2531=!(v2532===v2533);}
const v2534=v2531;
const v2535=false;
const v2536=(v2534===v2535);
let v2537=v2536;if(!v2537){
v2537=v2504["failed"];}
let v2538;
let v2539;
if(v2537){
const v2540=__fn10(v2522);
v2538=v2540;
v2539=v2504;
}else{
const v2541=v2504["nodes"];
const v2542=(v2541).length;
const v2543=v2504["maximum"];
let v2544;
let v2545;
if(((v2542) >= (v2543))){
const v2546=__fn10(v2522);
const v2547=true;
const v2548=v2504["nodes"];
const v2549=v2504["maximum"];
const v2550=({["nodes"]:v2548,["maximum"]:v2549,["failed"]:v2547});
v2544=v2546;
v2545=v2550;
}else{
const v2551=({["value"]:v2522,["id"]:v2542});
const v2552=v2504["nodes"];
const v2553=({["op"]:v2508,["a"]:v2523,["b"]:v2524,["av"]:v2525,["bv"]:v2526,["value"]:v2522});
const v2554=__tempEdit(v2552,"push",v2553);
const v2555=v2504["maximum"];
const v2556=v2504["failed"];
const v2557=({["nodes"]:v2554,["maximum"]:v2555,["failed"]:v2556});
v2544=v2551;
v2545=v2557;
}
v2538=v2544;
v2539=v2545;
}
const v2559=v2538;
const v2560=v2539;
const v2563=3;
const v2564=1;
let v2565;if((v2563===v2564)){
const v2566=v2559["value"];
const v2567=v2559["value"];
v2565=__bits(__float(v2566) + __float(v2567));}else{
const v2568=2;
let v2569;if((v2563===v2568)){
const v2570=v2559["value"];
const v2571=v2559["value"];
v2569=__bits(__float(v2570) - __float(v2571));}else{
const v2572=3;
let v2573;if((v2563===v2572)){
const v2574=v2559["value"];
const v2575=v2559["value"];
v2573=__bits(__float(v2574) * __float(v2575));}else{
v2573=__bits((__float(v2559["value"]))/(__float(v2559["value"])));}
v2569=v2573;}
v2565=v2569;}
const v2576=v2565;
const v2577=v2559["id"];
const v2578=v2559["id"];
const v2579=v2559["value"];
const v2580=v2559["value"];
const v2582=v2559["id"];
const v2583=4294967295;
const v2584=!(v2582===v2583);
let v2585=v2584;if(!v2585){
const v2586=v2559["id"];
const v2587=4294967295;
v2585=!(v2586===v2587);}
const v2588=v2585;
const v2589=false;
const v2590=(v2588===v2589);
let v2591=v2590;if(!v2591){
v2591=v2560["failed"];}
let v2592;
let v2593;
if(v2591){
const v2594=__fn10(v2576);
v2592=v2594;
v2593=v2560;
}else{
const v2595=v2560["nodes"];
const v2596=(v2595).length;
const v2597=v2560["maximum"];
let v2598;
let v2599;
if(((v2596) >= (v2597))){
const v2600=__fn10(v2576);
const v2601=true;
const v2602=v2560["nodes"];
const v2603=v2560["maximum"];
const v2604=({["nodes"]:v2602,["maximum"]:v2603,["failed"]:v2601});
v2598=v2600;
v2599=v2604;
}else{
const v2605=({["value"]:v2576,["id"]:v2596});
const v2606=v2560["nodes"];
const v2607=({["op"]:v2563,["a"]:v2577,["b"]:v2578,["av"]:v2579,["bv"]:v2580,["value"]:v2576});
const v2608=__tempEdit(v2606,"push",v2607);
const v2609=v2560["maximum"];
const v2610=v2560["failed"];
const v2611=({["nodes"]:v2608,["maximum"]:v2609,["failed"]:v2610});
v2598=v2605;
v2599=v2611;
}
v2592=v2598;
v2593=v2599;
}
const v2344=({["value"]:v2592,["tape"]:v2593});
const v2612=v2344;
const v2613=v2612["tape"];
const v2614=v2613["failed"];
let v2615;if(v2614){
v2615=({Err:"reverse differentiation tape capacity exceeded"});}else{
let v2616;if(v2619&&v2618){v2616=v2617;}else{
const v2620=v2344;
const v2621=v2620["tape"];
const v2622=v2621["nodes"];
const v2623=v2622.freeze();
const v2625=v2344;
const v2626=v2625["value"];
let v2630;if(v2629){if(!v2627){const v2628=__preparedFactories.get(18);v2627=v2628([v2624,v2624,fixed[2]],depth+1);}v2630=v2627(v2623,v2626,v2282);}else{v2630=__fn18(v2623,v2626,v2282);}
v2616=v2630;if(v2619){v2617=v2616;v2618=true;}}
const v2631=v2344;
const v2632=v2631["value"];
const v2633=v2632["value"];
const v2634=v2287;
const v2635=v2634["value"];
const v2636=v2635.length;
const v2637=new Array(v2636);
for(let v2638=0;v2638<v2636;v2638++){
const v2639=v2635[v2638];
const v2640=v2616;
const v2641=v2639["id"];
let v2642;if(v2641<v2640.length){v2642=v2640[v2641];}else{
v2642=0;}
v2637[v2638]=v2642;
}
v2615=({Ok:({["value"]:v2633,["gradient"]:v2637})});}
v2286=v2615;}
return v2286;};}
const __preparedFactories=new Map([[2,__prepareFn2],[3,__prepareFn3],[4,__prepareFn4],[21,__prepareFn21],[22,__prepareFn22]]);
