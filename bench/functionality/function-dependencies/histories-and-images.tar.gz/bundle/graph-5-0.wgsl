// Exact wrapping u64 over two storage lanes. No floating point intermediates.
struct InkU64 {lo:u32,hi:u32,}
struct InkDiv64 {quotient:InkU64,remainder:InkU64,}
fn ink_u64_shl(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64(a.lo<<k,(a.hi<<k)|(a.lo>>(32u-k)));}return InkU64(0u,a.lo<<(k-32u));}
fn ink_u64_shr(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64((a.lo>>k)|(a.hi<<(32u-k)),a.hi>>k);}return InkU64(a.hi>>(k-32u),0u);}
fn ink_u64_rol(a:InkU64,count:u32)->InkU64{let k=count&63u;let l=ink_u64_shl(a,k);let r=ink_u64_shr(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_ror(a:InkU64,count:u32)->InkU64{let k=count&63u;let r=ink_u64_shr(a,k);let l=ink_u64_shl(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_eq(a:InkU64,b:InkU64)->bool{return a.lo==b.lo&&a.hi==b.hi;}
fn ink_u64_lt(a:InkU64,b:InkU64)->bool{return a.hi<b.hi||(a.hi==b.hi&&a.lo<b.lo);}
fn ink_u64_add(a:InkU64,b:InkU64)->InkU64{let lo=a.lo+b.lo;return InkU64(lo,a.hi+b.hi+select(0u,1u,lo<a.lo));}
fn ink_u64_sub(a:InkU64,b:InkU64)->InkU64{return InkU64(a.lo-b.lo,a.hi-b.hi-select(0u,1u,a.lo<b.lo));}
fn ink_u64_mul(a:InkU64,b:InkU64)->InkU64{let al=a.lo&65535u;let ah=a.lo>>16u;let bl=b.lo&65535u;let bh=b.lo>>16u;let p=al*bl;let x=ah*bl;let y=al*bh;let mid=(p>>16u)+(x&65535u)+(y&65535u);let high=ah*bh+(x>>16u)+(y>>16u)+(mid>>16u);return InkU64((mid<<16u)|(p&65535u),high+a.lo*b.hi+a.hi*b.lo);}
fn ink_u64_div(a:InkU64,b:InkU64)->InkDiv64{var q=InkU64(0u,0u);var r=InkU64(0u,0u);var cursor=64u;loop{if(cursor==0u){break;}cursor--;var bit=0u;if(cursor>=32u){bit=(a.hi>>(cursor-32u))&1u;}else{bit=(a.lo>>cursor)&1u;}let overflow=r.hi>>31u;r=InkU64((r.lo<<1u)|bit,(r.hi<<1u)|(r.lo>>31u));if(overflow!=0u||!ink_u64_lt(r,b)){r=ink_u64_sub(r,b);if(cursor>=32u){q.hi|=1u<<(cursor-32u);}else{q.lo|=1u<<cursor;}}}return InkDiv64(q,r);}
// Binary32 evaluated with integer lanes: round-to-nearest, ties-to-even,
// gradual underflow, signed zero and canonical arithmetic NaN.
fn ink_f32_nan(x:u32)->bool{return (x&0x7fffffffu)>0x7f800000u;}
fn ink_f32_eq(a:u32,b:u32)->bool{return !ink_f32_nan(a)&&!ink_f32_nan(b)&&(a==b||((a|b)&0x7fffffffu)==0u);}
fn ink_f32_lt(a:u32,b:u32)->bool{
 if(ink_f32_nan(a)||ink_f32_nan(b)||ink_f32_eq(a,b)){return false;}
 if((a^b)&0x80000000u)!=0u{return (a&0x80000000u)!=0u;}
 if((a&0x80000000u)!=0u){return a>b;}return a<b;
}
fn ink_f32_jam(x:u32,n:u32)->u32{if(n==0u){return x;}if(n>=32u){return select(0u,1u,x!=0u);}return (x>>n)|select(0u,1u,(x&((1u<<n)-1u))!=0u);}
fn ink_f32_round(sign:u32,exponent:i32,extended:u32)->u32{
 var e=exponent;var s=extended;
 if(e<1i){s=ink_f32_jam(s,u32(1i-e));e=1i;}
 let tail=s&7u;var sig=s>>3u;
 if(tail>4u||(tail==4u&&(sig&1u)!=0u)){sig++;}
 if(sig>=0x1000000u){sig>>=1u;e++;}
 if(e>=255i){return sign|0x7f800000u;}
 if(sig==0u){return sign;}
 let raw=select(u32(e),0u,e==1i&&sig<0x800000u);
 return sign|(raw<<23u)|(sig&0x7fffffu);
}
fn ink_f32_add(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 var x=a;var y=b;if((x&0x7fffffffu)<(y&0x7fffffffu)){x=b;y=a;}
 let ax=x&0x7fffffffu;let ay=y&0x7fffffffu;let sign=x&0x80000000u;
 if(ax==0x7f800000u){if(ay==ax&&((x^y)&0x80000000u)!=0u){return 0x7fc00000u;}return x;}
 let rx=(x>>23u)&255u;let ry=(y>>23u)&255u;var e=i32(max(rx,1u));
 var sx=((x&0x7fffffu)|select(0u,0x800000u,rx!=0u))<<3u;
 let sy=ink_f32_jam(((y&0x7fffffu)|select(0u,0x800000u,ry!=0u))<<3u,u32(e)-max(ry,1u));
 if(((x^y)&0x80000000u)==0u){sx+=sy;if(sx>=0x8000000u){sx=ink_f32_jam(sx,1u);e++;}}
 else{sx-=sy;if(sx==0u){return 0u;}loop{if(sx>=0x4000000u||e<=1i){break;}sx<<=1u;e--;}}
 return ink_f32_round(sign,e,sx);
}
fn ink_f32_sub(a:u32,b:u32)->u32{return ink_f32_add(a,b^0x80000000u);}
fn ink_f32_mul(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(aa==0x7f800000u||bb==0x7f800000u){if(aa==0u||bb==0u){return 0x7fc00000u;}return sign|0x7f800000u;}
 if(aa==0u||bb==0u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u));var eb=i32(max(rb,1u));
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 let product=ink_u64_mul(InkU64(sa,0u),InkU64(sb,0u));let high=(product.hi&0x8000u)!=0u;
 let shift=select(20u,21u,high);let extended=(product.lo>>shift)|(product.hi<<(32u-shift))|select(0u,1u,(product.lo&((1u<<shift)-1u))!=0u);
 return ink_f32_round(sign,ea+eb-127i+select(0i,1i,high),extended);
}
// Exact sqrt and division use integer significands, independent of WGSL float
// approximation allowances and device flush-to-zero behavior.
fn ink_f32_sqrt(x:u32)->u32{
 let a=x&0x7fffffffu;if(a==0u){return x;}
 if(a>0x7f800000u||(x&0x80000000u)!=0u){return 0x7fc00000u;}
 if(a==0x7f800000u){return x;}
 let raw=(x>>23u)&255u;var m=(x&0x7fffffu)|select(0u,0x800000u,raw!=0u);var e=i32(max(raw,1u))-127i;
 loop{if(m>=0x800000u){break;}m<<=1u;e--;}
 let odd=e&1i;var half=(e-odd)/2i;let shift=23u+u32(odd);
 let n=InkU64(m<<shift,m>>(32u-shift));var lo=0u;var hi=0x1000000u;
 loop{if(lo+1u>=hi){break;}let mid=(lo+hi)>>1u;let sq=ink_u64_mul(InkU64(mid,0u),InkU64(mid,0u));if(!ink_u64_lt(n,sq)){lo=mid;}else{hi=mid;}}
 let sq=ink_u64_mul(InkU64(lo,0u),InkU64(lo,0u));let rem=ink_u64_sub(n,sq);
 if(ink_u64_lt(InkU64(lo,0u),rem)){lo++;}
 if(lo==0x1000000u){lo>>=1u;half++;}
 return (u32(half+127i)<<23u)|(lo&0x7fffffu);
}
fn ink_f32_div(a:u32,b:u32)->u32{
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(ink_f32_nan(a)||ink_f32_nan(b)||(aa==0u&&bb==0u)||(aa==0x7f800000u&&bb==aa)){return 0x7fc00000u;}
 if(aa==0x7f800000u||bb==0u){return sign|0x7f800000u;}
 if(aa==0u||bb==0x7f800000u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u))-127i;var eb=i32(max(rb,1u))-127i;
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 var e=ea-eb;if(sa<sb){sa<<=1u;e--;}
 let division=ink_u64_div(InkU64(sa<<26u,sa>>6u),InkU64(sb,0u));
 let extended=division.quotient.lo|select(0u,1u,!ink_u64_eq(division.remainder,InkU64(0u,0u)));
 return ink_f32_round(sign,e+127i,extended);
}
// mode: 0 trunc, 1 floor, 2 ceil, 3 ties-to-even.
fn ink_f32_integral(x:u32,mode:u32)->u32{
 let a=x&0x7fffffffu;let sign=x&0x80000000u;
 if(a>0x7f800000u){return 0x7fc00000u;}if(a>=0x4b000000u||a==0u){return x;}
 let e=i32((x>>23u)&255u)-127i;
 if(e<0i){var up=false;if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){up=a>0x3f000000u;}return sign|select(0u,0x3f800000u,up);}
 let shift=u32(23i-e);let mask=(1u<<shift)-1u;let fraction=a&mask;var rounded=a&~mask;var up=false;
 if(fraction!=0u){if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){let half=1u<<(shift-1u);up=fraction>half||(fraction==half&&((rounded>>shift)&1u)!=0u);}}
 if(up){rounded+=1u<<shift;}return sign|rounded;
}
fn ink_f32_from_u64(x:InkU64)->u32{
 if(ink_u64_eq(x,InkU64(0u,0u))){return 0u;}
 let leading=select(countLeadingZeros(x.lo)+32u,countLeadingZeros(x.hi),x.hi!=0u);let e=63u-leading;
 if(e<=23u){return ((e+127u)<<23u)|((x.lo<<(23u-e))&0x7fffffu);}
 let shift=e-23u;var sig=0u;var rem=InkU64(0u,0u);var half=InkU64(0u,0u);
 if(shift<32u){sig=(x.lo>>shift)|(x.hi<<(32u-shift));rem=InkU64(x.lo&((1u<<shift)-1u),0u);half=InkU64(1u<<(shift-1u),0u);}
 else if(shift==32u){sig=x.hi;rem=InkU64(x.lo,0u);half=InkU64(0x80000000u,0u);}
 else{sig=x.hi>>(shift-32u);rem=InkU64(x.lo,x.hi&((1u<<(shift-32u))-1u));half=InkU64(0u,1u<<(shift-33u));}
 if(ink_u64_lt(half,rem)||(ink_u64_eq(rem,half)&&(sig&1u)!=0u)){sig++;}
 var exponent=e+127u;if(sig==0x1000000u){sig>>=1u;exponent++;}
 return (exponent<<23u)|(sig&0x7fffffu);
}
fn ink_f32_from_i32(x:i32)->u32{let neg=x<0i;let magnitude=select(u32(x),0u-u32(x),neg);return ink_f32_from_u64(InkU64(magnitude,0u))|select(0u,0x80000000u,neg);}
struct InkBuffer_u32{data:array<u32,64>,length:u32,}
struct InkBuffer_InkU64{data:array<InkU64,64>,length:u32,}
struct InkBuffer_i32{data:array<i32,64>,length:u32,}
struct InkBuffer_bool{data:array<bool,64>,length:u32,}
struct R_Parameter{ink_f_value:u32,ink_f_first:u32,ink_f_second:u32,ink_f_first_power:u32,ink_f_second_power:u32,ink_f_steps:u32,}
@group(0) @binding(0) var<storage,read> a0:array<u32>;
@group(0) @binding(1) var<storage,read> a1:array<u32>;
@group(0) @binding(2) var<storage,read> a2:array<u32>;
@group(0) @binding(3) var<storage,read> a3:array<u32>;
@group(0) @binding(4) var<storage,read> a4:array<u32>;
@group(0) @binding(5) var<storage,read_write> output:array<u32>;
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) gid:vec3<u32>){
let size=6u;let i=gid.x;if(i==0u){output[0]=size;}if(i<size){
switch(i){
case 0u:{
var t0:u32=a0[0u+(0u)*1u+0u];
var t1:u32=a1[0u+(0u)*1u+0u];
var t2:u32=a4[0u+(0u)*1u+0u];
var t3:u32=0u;
var t4:u32=t0;
var t5:u32=t1;
var t6:u32=t3;
var t7:u32=(t6 + 10u);
var t8:u32=t5;
var t9:u32;
if ((t8 == t7)) {
t9=t4;
} else {
var t10:u32=t7;
var t11:R_Parameter;if(t10<a3[0u]){
t11=R_Parameter(a3[1u+(t10)*6u+0u],a3[1u+(t10)*6u+1u],a3[1u+(t10)*6u+2u],a3[1u+(t10)*6u+3u],a3[1u+(t10)*6u+4u],a3[1u+(t10)*6u+5u]);}else{
var t12:u32=0u;
var t13:u32=0u;
var t14:u32=0u;
var t15:u32=1065353216u;
var t16:u32=1065353216u;
var t17:u32=0u;
t11=R_Parameter(t12,t13,t14,t15,t16,t17);}
t9=(t11).ink_f_value;
}
var t18:u32=t9;
var t19:u32=t18;
for(var t20=0u;t20<10u;t20++){
var t21:u32=t19;
var t22:u32=t0;
var t23:u32=t1;
var t24:u32=t3;
var t25:u32=(t24 + t20);
var t26:u32=t23;
var t27:u32;
if ((t26 == t25)) {
t27=t22;
} else {
var t28:u32=t25;
var t29:R_Parameter;if(t28<a3[0u]){
t29=R_Parameter(a3[1u+(t28)*6u+0u],a3[1u+(t28)*6u+1u],a3[1u+(t28)*6u+2u],a3[1u+(t28)*6u+3u],a3[1u+(t28)*6u+4u],a3[1u+(t28)*6u+5u]);}else{
var t30:u32=0u;
var t31:u32=0u;
var t32:u32=0u;
var t33:u32=1065353216u;
var t34:u32=1065353216u;
var t35:u32=0u;
t29=R_Parameter(t30,t31,t32,t33,t34,t35);}
t27=(t29).ink_f_value;
}
var t36:u32=t27;
var t37:u32=t2;
var t38:u32=(t37 * 10u);
var t39:u32=(t38 + t20);
var t40:u32;if(t39<a2[0u]){
t40=a2[1u+(t39)*1u+0u];}else{
t40=0u;}
t19=ink_f32_add(t21,ink_f32_mul(t36,t40));
}
var t41:u32=t19;
var t42:u32=a0[0u+(0u)*1u+0u];
var t43:u32=a1[0u+(0u)*1u+0u];
var t44:u32=a4[0u+(0u)*1u+0u];
var t45:u32=11u;
var t46:u32=t42;
var t47:u32=t43;
var t48:u32=t45;
var t49:u32=(t48 + 10u);
var t50:u32=t47;
var t51:u32;
if ((t50 == t49)) {
t51=t46;
} else {
var t52:u32=t49;
var t53:R_Parameter;if(t52<a3[0u]){
t53=R_Parameter(a3[1u+(t52)*6u+0u],a3[1u+(t52)*6u+1u],a3[1u+(t52)*6u+2u],a3[1u+(t52)*6u+3u],a3[1u+(t52)*6u+4u],a3[1u+(t52)*6u+5u]);}else{
var t54:u32=0u;
var t55:u32=0u;
var t56:u32=0u;
var t57:u32=1065353216u;
var t58:u32=1065353216u;
var t59:u32=0u;
t53=R_Parameter(t54,t55,t56,t57,t58,t59);}
t51=(t53).ink_f_value;
}
var t60:u32=t51;
var t61:u32=t60;
for(var t62=0u;t62<10u;t62++){
var t63:u32=t61;
var t64:u32=t42;
var t65:u32=t43;
var t66:u32=t45;
var t67:u32=(t66 + t62);
var t68:u32=t65;
var t69:u32;
if ((t68 == t67)) {
t69=t64;
} else {
var t70:u32=t67;
var t71:R_Parameter;if(t70<a3[0u]){
t71=R_Parameter(a3[1u+(t70)*6u+0u],a3[1u+(t70)*6u+1u],a3[1u+(t70)*6u+2u],a3[1u+(t70)*6u+3u],a3[1u+(t70)*6u+4u],a3[1u+(t70)*6u+5u]);}else{
var t72:u32=0u;
var t73:u32=0u;
var t74:u32=0u;
var t75:u32=1065353216u;
var t76:u32=1065353216u;
var t77:u32=0u;
t71=R_Parameter(t72,t73,t74,t75,t76,t77);}
t69=(t71).ink_f_value;
}
var t78:u32=t69;
var t79:u32=t44;
var t80:u32=(t79 * 10u);
var t81:u32=(t80 + t62);
var t82:u32;if(t81<a2[0u]){
t82=a2[1u+(t81)*1u+0u];}else{
t82=0u;}
t61=ink_f32_add(t63,ink_f32_mul(t78,t82));
}
var t83:u32=t61;
var t84:u32=t83;
var t85:u32;
if (ink_f32_lt(0u,t84)) {
var t86:u32=t41;
t85=ink_f32_mul(t86,t83);
} else {
t85=0u;
}
var t87:u32=t85;
output[1u+i*1u+0u]=bitcast<u32>(t87);

}
case 1u:{
var t88:u32=a0[0u+(0u)*1u+0u];
var t89:u32=a1[0u+(0u)*1u+0u];
var t90:u32=a4[0u+(0u)*1u+0u];
var t91:u32=22u;
var t92:u32=t88;
var t93:u32=t89;
var t94:u32=t91;
var t95:u32=(t94 + 10u);
var t96:u32=t93;
var t97:u32;
if ((t96 == t95)) {
t97=t92;
} else {
var t98:u32=t95;
var t99:R_Parameter;if(t98<a3[0u]){
t99=R_Parameter(a3[1u+(t98)*6u+0u],a3[1u+(t98)*6u+1u],a3[1u+(t98)*6u+2u],a3[1u+(t98)*6u+3u],a3[1u+(t98)*6u+4u],a3[1u+(t98)*6u+5u]);}else{
var t100:u32=0u;
var t101:u32=0u;
var t102:u32=0u;
var t103:u32=1065353216u;
var t104:u32=1065353216u;
var t105:u32=0u;
t99=R_Parameter(t100,t101,t102,t103,t104,t105);}
t97=(t99).ink_f_value;
}
var t106:u32=t97;
var t107:u32=t106;
for(var t108=0u;t108<10u;t108++){
var t109:u32=t107;
var t110:u32=t88;
var t111:u32=t89;
var t112:u32=t91;
var t113:u32=(t112 + t108);
var t114:u32=t111;
var t115:u32;
if ((t114 == t113)) {
t115=t110;
} else {
var t116:u32=t113;
var t117:R_Parameter;if(t116<a3[0u]){
t117=R_Parameter(a3[1u+(t116)*6u+0u],a3[1u+(t116)*6u+1u],a3[1u+(t116)*6u+2u],a3[1u+(t116)*6u+3u],a3[1u+(t116)*6u+4u],a3[1u+(t116)*6u+5u]);}else{
var t118:u32=0u;
var t119:u32=0u;
var t120:u32=0u;
var t121:u32=1065353216u;
var t122:u32=1065353216u;
var t123:u32=0u;
t117=R_Parameter(t118,t119,t120,t121,t122,t123);}
t115=(t117).ink_f_value;
}
var t124:u32=t115;
var t125:u32=t90;
var t126:u32=(t125 * 10u);
var t127:u32=(t126 + t108);
var t128:u32;if(t127<a2[0u]){
t128=a2[1u+(t127)*1u+0u];}else{
t128=0u;}
t107=ink_f32_add(t109,ink_f32_mul(t124,t128));
}
var t129:u32=t107;
var t130:u32=a0[0u+(0u)*1u+0u];
var t131:u32=a1[0u+(0u)*1u+0u];
var t132:u32=a4[0u+(0u)*1u+0u];
var t133:u32=33u;
var t134:u32=t130;
var t135:u32=t131;
var t136:u32=t133;
var t137:u32=(t136 + 10u);
var t138:u32=t135;
var t139:u32;
if ((t138 == t137)) {
t139=t134;
} else {
var t140:u32=t137;
var t141:R_Parameter;if(t140<a3[0u]){
t141=R_Parameter(a3[1u+(t140)*6u+0u],a3[1u+(t140)*6u+1u],a3[1u+(t140)*6u+2u],a3[1u+(t140)*6u+3u],a3[1u+(t140)*6u+4u],a3[1u+(t140)*6u+5u]);}else{
var t142:u32=0u;
var t143:u32=0u;
var t144:u32=0u;
var t145:u32=1065353216u;
var t146:u32=1065353216u;
var t147:u32=0u;
t141=R_Parameter(t142,t143,t144,t145,t146,t147);}
t139=(t141).ink_f_value;
}
var t148:u32=t139;
var t149:u32=t148;
for(var t150=0u;t150<10u;t150++){
var t151:u32=t149;
var t152:u32=t130;
var t153:u32=t131;
var t154:u32=t133;
var t155:u32=(t154 + t150);
var t156:u32=t153;
var t157:u32;
if ((t156 == t155)) {
t157=t152;
} else {
var t158:u32=t155;
var t159:R_Parameter;if(t158<a3[0u]){
t159=R_Parameter(a3[1u+(t158)*6u+0u],a3[1u+(t158)*6u+1u],a3[1u+(t158)*6u+2u],a3[1u+(t158)*6u+3u],a3[1u+(t158)*6u+4u],a3[1u+(t158)*6u+5u]);}else{
var t160:u32=0u;
var t161:u32=0u;
var t162:u32=0u;
var t163:u32=1065353216u;
var t164:u32=1065353216u;
var t165:u32=0u;
t159=R_Parameter(t160,t161,t162,t163,t164,t165);}
t157=(t159).ink_f_value;
}
var t166:u32=t157;
var t167:u32=t132;
var t168:u32=(t167 * 10u);
var t169:u32=(t168 + t150);
var t170:u32;if(t169<a2[0u]){
t170=a2[1u+(t169)*1u+0u];}else{
t170=0u;}
t149=ink_f32_add(t151,ink_f32_mul(t166,t170));
}
var t171:u32=t149;
var t172:u32=t171;
var t173:u32;
if (ink_f32_lt(0u,t172)) {
var t174:u32=t129;
t173=ink_f32_mul(t174,t171);
} else {
t173=0u;
}
var t175:u32=t173;
output[1u+i*1u+0u]=bitcast<u32>(t175);

}
case 2u:{
var t176:u32=a0[0u+(0u)*1u+0u];
var t177:u32=a1[0u+(0u)*1u+0u];
var t178:u32=a4[0u+(0u)*1u+0u];
var t179:u32=44u;
var t180:u32=t176;
var t181:u32=t177;
var t182:u32=t179;
var t183:u32=(t182 + 10u);
var t184:u32=t181;
var t185:u32;
if ((t184 == t183)) {
t185=t180;
} else {
var t186:u32=t183;
var t187:R_Parameter;if(t186<a3[0u]){
t187=R_Parameter(a3[1u+(t186)*6u+0u],a3[1u+(t186)*6u+1u],a3[1u+(t186)*6u+2u],a3[1u+(t186)*6u+3u],a3[1u+(t186)*6u+4u],a3[1u+(t186)*6u+5u]);}else{
var t188:u32=0u;
var t189:u32=0u;
var t190:u32=0u;
var t191:u32=1065353216u;
var t192:u32=1065353216u;
var t193:u32=0u;
t187=R_Parameter(t188,t189,t190,t191,t192,t193);}
t185=(t187).ink_f_value;
}
var t194:u32=t185;
var t195:u32=t194;
for(var t196=0u;t196<10u;t196++){
var t197:u32=t195;
var t198:u32=t176;
var t199:u32=t177;
var t200:u32=t179;
var t201:u32=(t200 + t196);
var t202:u32=t199;
var t203:u32;
if ((t202 == t201)) {
t203=t198;
} else {
var t204:u32=t201;
var t205:R_Parameter;if(t204<a3[0u]){
t205=R_Parameter(a3[1u+(t204)*6u+0u],a3[1u+(t204)*6u+1u],a3[1u+(t204)*6u+2u],a3[1u+(t204)*6u+3u],a3[1u+(t204)*6u+4u],a3[1u+(t204)*6u+5u]);}else{
var t206:u32=0u;
var t207:u32=0u;
var t208:u32=0u;
var t209:u32=1065353216u;
var t210:u32=1065353216u;
var t211:u32=0u;
t205=R_Parameter(t206,t207,t208,t209,t210,t211);}
t203=(t205).ink_f_value;
}
var t212:u32=t203;
var t213:u32=t178;
var t214:u32=(t213 * 10u);
var t215:u32=(t214 + t196);
var t216:u32;if(t215<a2[0u]){
t216=a2[1u+(t215)*1u+0u];}else{
t216=0u;}
t195=ink_f32_add(t197,ink_f32_mul(t212,t216));
}
var t217:u32=t195;
var t218:u32=a0[0u+(0u)*1u+0u];
var t219:u32=a1[0u+(0u)*1u+0u];
var t220:u32=a4[0u+(0u)*1u+0u];
var t221:u32=55u;
var t222:u32=t218;
var t223:u32=t219;
var t224:u32=t221;
var t225:u32=(t224 + 10u);
var t226:u32=t223;
var t227:u32;
if ((t226 == t225)) {
t227=t222;
} else {
var t228:u32=t225;
var t229:R_Parameter;if(t228<a3[0u]){
t229=R_Parameter(a3[1u+(t228)*6u+0u],a3[1u+(t228)*6u+1u],a3[1u+(t228)*6u+2u],a3[1u+(t228)*6u+3u],a3[1u+(t228)*6u+4u],a3[1u+(t228)*6u+5u]);}else{
var t230:u32=0u;
var t231:u32=0u;
var t232:u32=0u;
var t233:u32=1065353216u;
var t234:u32=1065353216u;
var t235:u32=0u;
t229=R_Parameter(t230,t231,t232,t233,t234,t235);}
t227=(t229).ink_f_value;
}
var t236:u32=t227;
var t237:u32=t236;
for(var t238=0u;t238<10u;t238++){
var t239:u32=t237;
var t240:u32=t218;
var t241:u32=t219;
var t242:u32=t221;
var t243:u32=(t242 + t238);
var t244:u32=t241;
var t245:u32;
if ((t244 == t243)) {
t245=t240;
} else {
var t246:u32=t243;
var t247:R_Parameter;if(t246<a3[0u]){
t247=R_Parameter(a3[1u+(t246)*6u+0u],a3[1u+(t246)*6u+1u],a3[1u+(t246)*6u+2u],a3[1u+(t246)*6u+3u],a3[1u+(t246)*6u+4u],a3[1u+(t246)*6u+5u]);}else{
var t248:u32=0u;
var t249:u32=0u;
var t250:u32=0u;
var t251:u32=1065353216u;
var t252:u32=1065353216u;
var t253:u32=0u;
t247=R_Parameter(t248,t249,t250,t251,t252,t253);}
t245=(t247).ink_f_value;
}
var t254:u32=t245;
var t255:u32=t220;
var t256:u32=(t255 * 10u);
var t257:u32=(t256 + t238);
var t258:u32;if(t257<a2[0u]){
t258=a2[1u+(t257)*1u+0u];}else{
t258=0u;}
t237=ink_f32_add(t239,ink_f32_mul(t254,t258));
}
var t259:u32=t237;
var t260:u32=t259;
var t261:u32;
if (ink_f32_lt(0u,t260)) {
var t262:u32=t217;
t261=ink_f32_mul(t262,t259);
} else {
t261=0u;
}
var t263:u32=t261;
output[1u+i*1u+0u]=bitcast<u32>(t263);

}
case 3u:{
var t264:u32=a0[0u+(0u)*1u+0u];
var t265:u32=a1[0u+(0u)*1u+0u];
var t266:u32=a4[0u+(0u)*1u+0u];
var t267:u32=66u;
var t268:u32=t264;
var t269:u32=t265;
var t270:u32=t267;
var t271:u32=(t270 + 10u);
var t272:u32=t269;
var t273:u32;
if ((t272 == t271)) {
t273=t268;
} else {
var t274:u32=t271;
var t275:R_Parameter;if(t274<a3[0u]){
t275=R_Parameter(a3[1u+(t274)*6u+0u],a3[1u+(t274)*6u+1u],a3[1u+(t274)*6u+2u],a3[1u+(t274)*6u+3u],a3[1u+(t274)*6u+4u],a3[1u+(t274)*6u+5u]);}else{
var t276:u32=0u;
var t277:u32=0u;
var t278:u32=0u;
var t279:u32=1065353216u;
var t280:u32=1065353216u;
var t281:u32=0u;
t275=R_Parameter(t276,t277,t278,t279,t280,t281);}
t273=(t275).ink_f_value;
}
var t282:u32=t273;
var t283:u32=t282;
for(var t284=0u;t284<10u;t284++){
var t285:u32=t283;
var t286:u32=t264;
var t287:u32=t265;
var t288:u32=t267;
var t289:u32=(t288 + t284);
var t290:u32=t287;
var t291:u32;
if ((t290 == t289)) {
t291=t286;
} else {
var t292:u32=t289;
var t293:R_Parameter;if(t292<a3[0u]){
t293=R_Parameter(a3[1u+(t292)*6u+0u],a3[1u+(t292)*6u+1u],a3[1u+(t292)*6u+2u],a3[1u+(t292)*6u+3u],a3[1u+(t292)*6u+4u],a3[1u+(t292)*6u+5u]);}else{
var t294:u32=0u;
var t295:u32=0u;
var t296:u32=0u;
var t297:u32=1065353216u;
var t298:u32=1065353216u;
var t299:u32=0u;
t293=R_Parameter(t294,t295,t296,t297,t298,t299);}
t291=(t293).ink_f_value;
}
var t300:u32=t291;
var t301:u32=t266;
var t302:u32=(t301 * 10u);
var t303:u32=(t302 + t284);
var t304:u32;if(t303<a2[0u]){
t304=a2[1u+(t303)*1u+0u];}else{
t304=0u;}
t283=ink_f32_add(t285,ink_f32_mul(t300,t304));
}
var t305:u32=t283;
var t306:u32=a0[0u+(0u)*1u+0u];
var t307:u32=a1[0u+(0u)*1u+0u];
var t308:u32=a4[0u+(0u)*1u+0u];
var t309:u32=77u;
var t310:u32=t306;
var t311:u32=t307;
var t312:u32=t309;
var t313:u32=(t312 + 10u);
var t314:u32=t311;
var t315:u32;
if ((t314 == t313)) {
t315=t310;
} else {
var t316:u32=t313;
var t317:R_Parameter;if(t316<a3[0u]){
t317=R_Parameter(a3[1u+(t316)*6u+0u],a3[1u+(t316)*6u+1u],a3[1u+(t316)*6u+2u],a3[1u+(t316)*6u+3u],a3[1u+(t316)*6u+4u],a3[1u+(t316)*6u+5u]);}else{
var t318:u32=0u;
var t319:u32=0u;
var t320:u32=0u;
var t321:u32=1065353216u;
var t322:u32=1065353216u;
var t323:u32=0u;
t317=R_Parameter(t318,t319,t320,t321,t322,t323);}
t315=(t317).ink_f_value;
}
var t324:u32=t315;
var t325:u32=t324;
for(var t326=0u;t326<10u;t326++){
var t327:u32=t325;
var t328:u32=t306;
var t329:u32=t307;
var t330:u32=t309;
var t331:u32=(t330 + t326);
var t332:u32=t329;
var t333:u32;
if ((t332 == t331)) {
t333=t328;
} else {
var t334:u32=t331;
var t335:R_Parameter;if(t334<a3[0u]){
t335=R_Parameter(a3[1u+(t334)*6u+0u],a3[1u+(t334)*6u+1u],a3[1u+(t334)*6u+2u],a3[1u+(t334)*6u+3u],a3[1u+(t334)*6u+4u],a3[1u+(t334)*6u+5u]);}else{
var t336:u32=0u;
var t337:u32=0u;
var t338:u32=0u;
var t339:u32=1065353216u;
var t340:u32=1065353216u;
var t341:u32=0u;
t335=R_Parameter(t336,t337,t338,t339,t340,t341);}
t333=(t335).ink_f_value;
}
var t342:u32=t333;
var t343:u32=t308;
var t344:u32=(t343 * 10u);
var t345:u32=(t344 + t326);
var t346:u32;if(t345<a2[0u]){
t346=a2[1u+(t345)*1u+0u];}else{
t346=0u;}
t325=ink_f32_add(t327,ink_f32_mul(t342,t346));
}
var t347:u32=t325;
var t348:u32=t347;
var t349:u32;
if (ink_f32_lt(0u,t348)) {
var t350:u32=t305;
t349=ink_f32_mul(t350,t347);
} else {
t349=0u;
}
var t351:u32=t349;
output[1u+i*1u+0u]=bitcast<u32>(t351);

}
case 4u:{
var t352:u32=a0[0u+(0u)*1u+0u];
var t353:u32=a1[0u+(0u)*1u+0u];
var t354:u32=a4[0u+(0u)*1u+0u];
var t355:u32=88u;
var t356:u32=t352;
var t357:u32=t353;
var t358:u32=t355;
var t359:u32=(t358 + 10u);
var t360:u32=t357;
var t361:u32;
if ((t360 == t359)) {
t361=t356;
} else {
var t362:u32=t359;
var t363:R_Parameter;if(t362<a3[0u]){
t363=R_Parameter(a3[1u+(t362)*6u+0u],a3[1u+(t362)*6u+1u],a3[1u+(t362)*6u+2u],a3[1u+(t362)*6u+3u],a3[1u+(t362)*6u+4u],a3[1u+(t362)*6u+5u]);}else{
var t364:u32=0u;
var t365:u32=0u;
var t366:u32=0u;
var t367:u32=1065353216u;
var t368:u32=1065353216u;
var t369:u32=0u;
t363=R_Parameter(t364,t365,t366,t367,t368,t369);}
t361=(t363).ink_f_value;
}
var t370:u32=t361;
var t371:u32=t370;
for(var t372=0u;t372<10u;t372++){
var t373:u32=t371;
var t374:u32=t352;
var t375:u32=t353;
var t376:u32=t355;
var t377:u32=(t376 + t372);
var t378:u32=t375;
var t379:u32;
if ((t378 == t377)) {
t379=t374;
} else {
var t380:u32=t377;
var t381:R_Parameter;if(t380<a3[0u]){
t381=R_Parameter(a3[1u+(t380)*6u+0u],a3[1u+(t380)*6u+1u],a3[1u+(t380)*6u+2u],a3[1u+(t380)*6u+3u],a3[1u+(t380)*6u+4u],a3[1u+(t380)*6u+5u]);}else{
var t382:u32=0u;
var t383:u32=0u;
var t384:u32=0u;
var t385:u32=1065353216u;
var t386:u32=1065353216u;
var t387:u32=0u;
t381=R_Parameter(t382,t383,t384,t385,t386,t387);}
t379=(t381).ink_f_value;
}
var t388:u32=t379;
var t389:u32=t354;
var t390:u32=(t389 * 10u);
var t391:u32=(t390 + t372);
var t392:u32;if(t391<a2[0u]){
t392=a2[1u+(t391)*1u+0u];}else{
t392=0u;}
t371=ink_f32_add(t373,ink_f32_mul(t388,t392));
}
var t393:u32=t371;
var t394:u32=a0[0u+(0u)*1u+0u];
var t395:u32=a1[0u+(0u)*1u+0u];
var t396:u32=a4[0u+(0u)*1u+0u];
var t397:u32=99u;
var t398:u32=t394;
var t399:u32=t395;
var t400:u32=t397;
var t401:u32=(t400 + 10u);
var t402:u32=t399;
var t403:u32;
if ((t402 == t401)) {
t403=t398;
} else {
var t404:u32=t401;
var t405:R_Parameter;if(t404<a3[0u]){
t405=R_Parameter(a3[1u+(t404)*6u+0u],a3[1u+(t404)*6u+1u],a3[1u+(t404)*6u+2u],a3[1u+(t404)*6u+3u],a3[1u+(t404)*6u+4u],a3[1u+(t404)*6u+5u]);}else{
var t406:u32=0u;
var t407:u32=0u;
var t408:u32=0u;
var t409:u32=1065353216u;
var t410:u32=1065353216u;
var t411:u32=0u;
t405=R_Parameter(t406,t407,t408,t409,t410,t411);}
t403=(t405).ink_f_value;
}
var t412:u32=t403;
var t413:u32=t412;
for(var t414=0u;t414<10u;t414++){
var t415:u32=t413;
var t416:u32=t394;
var t417:u32=t395;
var t418:u32=t397;
var t419:u32=(t418 + t414);
var t420:u32=t417;
var t421:u32;
if ((t420 == t419)) {
t421=t416;
} else {
var t422:u32=t419;
var t423:R_Parameter;if(t422<a3[0u]){
t423=R_Parameter(a3[1u+(t422)*6u+0u],a3[1u+(t422)*6u+1u],a3[1u+(t422)*6u+2u],a3[1u+(t422)*6u+3u],a3[1u+(t422)*6u+4u],a3[1u+(t422)*6u+5u]);}else{
var t424:u32=0u;
var t425:u32=0u;
var t426:u32=0u;
var t427:u32=1065353216u;
var t428:u32=1065353216u;
var t429:u32=0u;
t423=R_Parameter(t424,t425,t426,t427,t428,t429);}
t421=(t423).ink_f_value;
}
var t430:u32=t421;
var t431:u32=t396;
var t432:u32=(t431 * 10u);
var t433:u32=(t432 + t414);
var t434:u32;if(t433<a2[0u]){
t434=a2[1u+(t433)*1u+0u];}else{
t434=0u;}
t413=ink_f32_add(t415,ink_f32_mul(t430,t434));
}
var t435:u32=t413;
var t436:u32=t435;
var t437:u32;
if (ink_f32_lt(0u,t436)) {
var t438:u32=t393;
t437=ink_f32_mul(t438,t435);
} else {
t437=0u;
}
var t439:u32=t437;
output[1u+i*1u+0u]=bitcast<u32>(t439);

}
case 5u:{
var t440:u32=a0[0u+(0u)*1u+0u];
var t441:u32=a1[0u+(0u)*1u+0u];
var t442:u32=a4[0u+(0u)*1u+0u];
var t443:u32=110u;
var t444:u32=t440;
var t445:u32=t441;
var t446:u32=t443;
var t447:u32=(t446 + 10u);
var t448:u32=t445;
var t449:u32;
if ((t448 == t447)) {
t449=t444;
} else {
var t450:u32=t447;
var t451:R_Parameter;if(t450<a3[0u]){
t451=R_Parameter(a3[1u+(t450)*6u+0u],a3[1u+(t450)*6u+1u],a3[1u+(t450)*6u+2u],a3[1u+(t450)*6u+3u],a3[1u+(t450)*6u+4u],a3[1u+(t450)*6u+5u]);}else{
var t452:u32=0u;
var t453:u32=0u;
var t454:u32=0u;
var t455:u32=1065353216u;
var t456:u32=1065353216u;
var t457:u32=0u;
t451=R_Parameter(t452,t453,t454,t455,t456,t457);}
t449=(t451).ink_f_value;
}
var t458:u32=t449;
var t459:u32=t458;
for(var t460=0u;t460<10u;t460++){
var t461:u32=t459;
var t462:u32=t440;
var t463:u32=t441;
var t464:u32=t443;
var t465:u32=(t464 + t460);
var t466:u32=t463;
var t467:u32;
if ((t466 == t465)) {
t467=t462;
} else {
var t468:u32=t465;
var t469:R_Parameter;if(t468<a3[0u]){
t469=R_Parameter(a3[1u+(t468)*6u+0u],a3[1u+(t468)*6u+1u],a3[1u+(t468)*6u+2u],a3[1u+(t468)*6u+3u],a3[1u+(t468)*6u+4u],a3[1u+(t468)*6u+5u]);}else{
var t470:u32=0u;
var t471:u32=0u;
var t472:u32=0u;
var t473:u32=1065353216u;
var t474:u32=1065353216u;
var t475:u32=0u;
t469=R_Parameter(t470,t471,t472,t473,t474,t475);}
t467=(t469).ink_f_value;
}
var t476:u32=t467;
var t477:u32=t442;
var t478:u32=(t477 * 10u);
var t479:u32=(t478 + t460);
var t480:u32;if(t479<a2[0u]){
t480=a2[1u+(t479)*1u+0u];}else{
t480=0u;}
t459=ink_f32_add(t461,ink_f32_mul(t476,t480));
}
var t481:u32=t459;
var t482:u32=a0[0u+(0u)*1u+0u];
var t483:u32=a1[0u+(0u)*1u+0u];
var t484:u32=a4[0u+(0u)*1u+0u];
var t485:u32=121u;
var t486:u32=t482;
var t487:u32=t483;
var t488:u32=t485;
var t489:u32=(t488 + 10u);
var t490:u32=t487;
var t491:u32;
if ((t490 == t489)) {
t491=t486;
} else {
var t492:u32=t489;
var t493:R_Parameter;if(t492<a3[0u]){
t493=R_Parameter(a3[1u+(t492)*6u+0u],a3[1u+(t492)*6u+1u],a3[1u+(t492)*6u+2u],a3[1u+(t492)*6u+3u],a3[1u+(t492)*6u+4u],a3[1u+(t492)*6u+5u]);}else{
var t494:u32=0u;
var t495:u32=0u;
var t496:u32=0u;
var t497:u32=1065353216u;
var t498:u32=1065353216u;
var t499:u32=0u;
t493=R_Parameter(t494,t495,t496,t497,t498,t499);}
t491=(t493).ink_f_value;
}
var t500:u32=t491;
var t501:u32=t500;
for(var t502=0u;t502<10u;t502++){
var t503:u32=t501;
var t504:u32=t482;
var t505:u32=t483;
var t506:u32=t485;
var t507:u32=(t506 + t502);
var t508:u32=t505;
var t509:u32;
if ((t508 == t507)) {
t509=t504;
} else {
var t510:u32=t507;
var t511:R_Parameter;if(t510<a3[0u]){
t511=R_Parameter(a3[1u+(t510)*6u+0u],a3[1u+(t510)*6u+1u],a3[1u+(t510)*6u+2u],a3[1u+(t510)*6u+3u],a3[1u+(t510)*6u+4u],a3[1u+(t510)*6u+5u]);}else{
var t512:u32=0u;
var t513:u32=0u;
var t514:u32=0u;
var t515:u32=1065353216u;
var t516:u32=1065353216u;
var t517:u32=0u;
t511=R_Parameter(t512,t513,t514,t515,t516,t517);}
t509=(t511).ink_f_value;
}
var t518:u32=t509;
var t519:u32=t484;
var t520:u32=(t519 * 10u);
var t521:u32=(t520 + t502);
var t522:u32;if(t521<a2[0u]){
t522=a2[1u+(t521)*1u+0u];}else{
t522=0u;}
t501=ink_f32_add(t503,ink_f32_mul(t518,t522));
}
var t523:u32=t501;
var t524:u32=t523;
var t525:u32;
if (ink_f32_lt(0u,t524)) {
var t526:u32=t481;
t525=ink_f32_mul(t526,t523);
} else {
t525=0u;
}
var t527:u32=t525;
output[1u+i*1u+0u]=bitcast<u32>(t527);

}
default:{} }

}
}