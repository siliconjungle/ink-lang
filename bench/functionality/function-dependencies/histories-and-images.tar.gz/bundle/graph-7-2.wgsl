// Exact wrapping u64 over two storage lanes. No floating point intermediates.
struct InkU64 {lo:u32,hi:u32,}
struct InkDiv64 {quotient:InkU64,remainder:InkU64,}
fn ink_u64_shl(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64(a.lo<<k,(a.hi<<k)|(a.lo>>(32u-k)));}return InkU64(0u,a.lo<<(k-32u));}
fn ink_u64_shr(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64((a.lo>>k)|(a.hi<<(32u-k)),a.hi>>k);}return InkU64(a.hi>>(k-32u),0u);}
fn ink_u64_rol(a:InkU64,count:u32)->InkU64{let k=count&63u;let l=ink_u64_shl(a,k);let r=ink_u64_shr(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_ror(a:InkU64,count:u32)->InkU64{let k=count&63u;let r=ink_u64_shr(a,k);let l=ink_u64_shl(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_eq(a:InkU64,b:InkU64)->bool{return a.lo==b.lo&&a.hi==b.hi;}
fn ink_u64_lt(a:InkU64,b:InkU64)->bool{return a.hi<b.hi||(a.hi==b.hi&&a.lo<b.lo);}
fn ink_u64_add(a:InkU64,b:InkU64)->InkU64{let lo=a.lo+b.lo;return InkU64(lo,a.hi+b.hi+select(0u,1u,lo<a.lo));}
fn ink_u64_sub(a:InkU64,b:InkU64)->InkU64{return InkU64(a.lo-b.lo,a.hi-b.hi-select(0u,1u,a.lo<b.lo));}
fn ink_u64_mul(a:InkU64,b:InkU64)->InkU64{let al=a.lo&65535u;let ah=a.lo>>16u;let bl=b.lo&65535u;let bh=b.lo>>16u;let p=al*bl;let x=ah*bl;let y=al*bh;let mid=(p>>16u)+(x&65535u)+(y&65535u);let high=ah*bh+(x>>16u)+(y>>16u)+(mid>>16u);return InkU64((mid<<16u)|(p&65535u),high+a.lo*b.hi+a.hi*b.lo);}
fn ink_u64_div(a:InkU64,b:InkU64)->InkDiv64{var q=InkU64(0u,0u);var r=InkU64(0u,0u);var cursor=64u;loop{if(cursor==0u){break;}cursor--;var bit=0u;if(cursor>=32u){bit=(a.hi>>(cursor-32u))&1u;}else{bit=(a.lo>>cursor)&1u;}let overflow=r.hi>>31u;r=InkU64((r.lo<<1u)|bit,(r.hi<<1u)|(r.lo>>31u));if(overflow!=0u||!ink_u64_lt(r,b)){r=ink_u64_sub(r,b);if(cursor>=32u){q.hi|=1u<<(cursor-32u);}else{q.lo|=1u<<cursor;}}}return InkDiv64(q,r);}
// Binary32 evaluated with integer lanes: round-to-nearest, ties-to-even,
// gradual underflow, signed zero and canonical arithmetic NaN.
fn ink_f32_nan(x:u32)->bool{return (x&0x7fffffffu)>0x7f800000u;}
fn ink_f32_eq(a:u32,b:u32)->bool{return !ink_f32_nan(a)&&!ink_f32_nan(b)&&(a==b||((a|b)&0x7fffffffu)==0u);}
fn ink_f32_lt(a:u32,b:u32)->bool{
 if(ink_f32_nan(a)||ink_f32_nan(b)||ink_f32_eq(a,b)){return false;}
 if((a^b)&0x80000000u)!=0u{return (a&0x80000000u)!=0u;}
 if((a&0x80000000u)!=0u){return a>b;}return a<b;
}
fn ink_f32_jam(x:u32,n:u32)->u32{if(n==0u){return x;}if(n>=32u){return select(0u,1u,x!=0u);}return (x>>n)|select(0u,1u,(x&((1u<<n)-1u))!=0u);}
fn ink_f32_round(sign:u32,exponent:i32,extended:u32)->u32{
 var e=exponent;var s=extended;
 if(e<1i){s=ink_f32_jam(s,u32(1i-e));e=1i;}
 let tail=s&7u;var sig=s>>3u;
 if(tail>4u||(tail==4u&&(sig&1u)!=0u)){sig++;}
 if(sig>=0x1000000u){sig>>=1u;e++;}
 if(e>=255i){return sign|0x7f800000u;}
 if(sig==0u){return sign;}
 let raw=select(u32(e),0u,e==1i&&sig<0x800000u);
 return sign|(raw<<23u)|(sig&0x7fffffu);
}
fn ink_f32_add(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 var x=a;var y=b;if((x&0x7fffffffu)<(y&0x7fffffffu)){x=b;y=a;}
 let ax=x&0x7fffffffu;let ay=y&0x7fffffffu;let sign=x&0x80000000u;
 if(ax==0x7f800000u){if(ay==ax&&((x^y)&0x80000000u)!=0u){return 0x7fc00000u;}return x;}
 let rx=(x>>23u)&255u;let ry=(y>>23u)&255u;var e=i32(max(rx,1u));
 var sx=((x&0x7fffffu)|select(0u,0x800000u,rx!=0u))<<3u;
 let sy=ink_f32_jam(((y&0x7fffffu)|select(0u,0x800000u,ry!=0u))<<3u,u32(e)-max(ry,1u));
 if(((x^y)&0x80000000u)==0u){sx+=sy;if(sx>=0x8000000u){sx=ink_f32_jam(sx,1u);e++;}}
 else{sx-=sy;if(sx==0u){return 0u;}loop{if(sx>=0x4000000u||e<=1i){break;}sx<<=1u;e--;}}
 return ink_f32_round(sign,e,sx);
}
fn ink_f32_sub(a:u32,b:u32)->u32{return ink_f32_add(a,b^0x80000000u);}
fn ink_f32_mul(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(aa==0x7f800000u||bb==0x7f800000u){if(aa==0u||bb==0u){return 0x7fc00000u;}return sign|0x7f800000u;}
 if(aa==0u||bb==0u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u));var eb=i32(max(rb,1u));
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 let product=ink_u64_mul(InkU64(sa,0u),InkU64(sb,0u));let high=(product.hi&0x8000u)!=0u;
 let shift=select(20u,21u,high);let extended=(product.lo>>shift)|(product.hi<<(32u-shift))|select(0u,1u,(product.lo&((1u<<shift)-1u))!=0u);
 return ink_f32_round(sign,ea+eb-127i+select(0i,1i,high),extended);
}
// Exact sqrt and division use integer significands, independent of WGSL float
// approximation allowances and device flush-to-zero behavior.
fn ink_f32_sqrt(x:u32)->u32{
 let a=x&0x7fffffffu;if(a==0u){return x;}
 if(a>0x7f800000u||(x&0x80000000u)!=0u){return 0x7fc00000u;}
 if(a==0x7f800000u){return x;}
 let raw=(x>>23u)&255u;var m=(x&0x7fffffu)|select(0u,0x800000u,raw!=0u);var e=i32(max(raw,1u))-127i;
 loop{if(m>=0x800000u){break;}m<<=1u;e--;}
 let odd=e&1i;var half=(e-odd)/2i;let shift=23u+u32(odd);
 let n=InkU64(m<<shift,m>>(32u-shift));var lo=0u;var hi=0x1000000u;
 loop{if(lo+1u>=hi){break;}let mid=(lo+hi)>>1u;let sq=ink_u64_mul(InkU64(mid,0u),InkU64(mid,0u));if(!ink_u64_lt(n,sq)){lo=mid;}else{hi=mid;}}
 let sq=ink_u64_mul(InkU64(lo,0u),InkU64(lo,0u));let rem=ink_u64_sub(n,sq);
 if(ink_u64_lt(InkU64(lo,0u),rem)){lo++;}
 if(lo==0x1000000u){lo>>=1u;half++;}
 return (u32(half+127i)<<23u)|(lo&0x7fffffu);
}
fn ink_f32_div(a:u32,b:u32)->u32{
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(ink_f32_nan(a)||ink_f32_nan(b)||(aa==0u&&bb==0u)||(aa==0x7f800000u&&bb==aa)){return 0x7fc00000u;}
 if(aa==0x7f800000u||bb==0u){return sign|0x7f800000u;}
 if(aa==0u||bb==0x7f800000u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u))-127i;var eb=i32(max(rb,1u))-127i;
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 var e=ea-eb;if(sa<sb){sa<<=1u;e--;}
 let division=ink_u64_div(InkU64(sa<<26u,sa>>6u),InkU64(sb,0u));
 let extended=division.quotient.lo|select(0u,1u,!ink_u64_eq(division.remainder,InkU64(0u,0u)));
 return ink_f32_round(sign,e+127i,extended);
}
// mode: 0 trunc, 1 floor, 2 ceil, 3 ties-to-even.
fn ink_f32_integral(x:u32,mode:u32)->u32{
 let a=x&0x7fffffffu;let sign=x&0x80000000u;
 if(a>0x7f800000u){return 0x7fc00000u;}if(a>=0x4b000000u||a==0u){return x;}
 let e=i32((x>>23u)&255u)-127i;
 if(e<0i){var up=false;if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){up=a>0x3f000000u;}return sign|select(0u,0x3f800000u,up);}
 let shift=u32(23i-e);let mask=(1u<<shift)-1u;let fraction=a&mask;var rounded=a&~mask;var up=false;
 if(fraction!=0u){if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){let half=1u<<(shift-1u);up=fraction>half||(fraction==half&&((rounded>>shift)&1u)!=0u);}}
 if(up){rounded+=1u<<shift;}return sign|rounded;
}
fn ink_f32_from_u64(x:InkU64)->u32{
 if(ink_u64_eq(x,InkU64(0u,0u))){return 0u;}
 let leading=select(countLeadingZeros(x.lo)+32u,countLeadingZeros(x.hi),x.hi!=0u);let e=63u-leading;
 if(e<=23u){return ((e+127u)<<23u)|((x.lo<<(23u-e))&0x7fffffu);}
 let shift=e-23u;var sig=0u;var rem=InkU64(0u,0u);var half=InkU64(0u,0u);
 if(shift<32u){sig=(x.lo>>shift)|(x.hi<<(32u-shift));rem=InkU64(x.lo&((1u<<shift)-1u),0u);half=InkU64(1u<<(shift-1u),0u);}
 else if(shift==32u){sig=x.hi;rem=InkU64(x.lo,0u);half=InkU64(0x80000000u,0u);}
 else{sig=x.hi>>(shift-32u);rem=InkU64(x.lo,x.hi&((1u<<(shift-32u))-1u));half=InkU64(0u,1u<<(shift-33u));}
 if(ink_u64_lt(half,rem)||(ink_u64_eq(rem,half)&&(sig&1u)!=0u)){sig++;}
 var exponent=e+127u;if(sig==0x1000000u){sig>>=1u;exponent++;}
 return (exponent<<23u)|(sig&0x7fffffu);
}
fn ink_f32_from_i32(x:i32)->u32{let neg=x<0i;let magnitude=select(u32(x),0u-u32(x),neg);return ink_f32_from_u64(InkU64(magnitude,0u))|select(0u,0x80000000u,neg);}
struct InkBuffer_u32{data:array<u32,64>,length:u32,}
struct InkBuffer_InkU64{data:array<InkU64,64>,length:u32,}
struct InkBuffer_i32{data:array<i32,64>,length:u32,}
struct InkBuffer_bool{data:array<bool,64>,length:u32,}
struct R_Parameter{ink_f_value:u32,ink_f_first:u32,ink_f_second:u32,ink_f_first_power:u32,ink_f_second_power:u32,ink_f_steps:u32,}
@group(0) @binding(0) var<storage,read> a0:array<u32>;
@group(0) @binding(1) var<storage,read> a1:array<u32>;
@group(0) @binding(2) var<storage,read> a2:array<u32>;
@group(0) @binding(3) var<storage,read> a3:array<u32>;
@group(0) @binding(4) var<storage,read_write> output:array<u32>;
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) gid:vec3<u32>){
let size=4u;let i=gid.x;if(i==0u){output[0]=size;}if(i<size){
switch(i){
case 0u:{
var t0:u32=a0[0u+(0u)*1u+0u];
var t1:u32=a1[0u+(0u)*1u+0u];
var t2:u32=216u;
var t3:u32=t0;
var t4:u32=t1;
var t5:u32=t2;
var t6:u32=(t5 + 6u);
var t7:u32=t4;
var t8:u32;
if ((t7 == t6)) {
t8=t3;
} else {
var t9:u32=t6;
var t10:R_Parameter;if(t9<a2[0u]){
t10=R_Parameter(a2[1u+(t9)*6u+0u],a2[1u+(t9)*6u+1u],a2[1u+(t9)*6u+2u],a2[1u+(t9)*6u+3u],a2[1u+(t9)*6u+4u],a2[1u+(t9)*6u+5u]);}else{
var t11:u32=0u;
var t12:u32=0u;
var t13:u32=0u;
var t14:u32=1065353216u;
var t15:u32=1065353216u;
var t16:u32=0u;
t10=R_Parameter(t11,t12,t13,t14,t15,t16);}
t8=(t10).ink_f_value;
}
var t17:u32=t8;
var t18:u32=t17;
for(var t19=0u;t19<6u;t19++){
var t20:u32=t18;
var t21:u32=t0;
var t22:u32=t1;
var t23:u32=t2;
var t24:u32=(t23 + t19);
var t25:u32=t22;
var t26:u32;
if ((t25 == t24)) {
t26=t21;
} else {
var t27:u32=t24;
var t28:R_Parameter;if(t27<a2[0u]){
t28=R_Parameter(a2[1u+(t27)*6u+0u],a2[1u+(t27)*6u+1u],a2[1u+(t27)*6u+2u],a2[1u+(t27)*6u+3u],a2[1u+(t27)*6u+4u],a2[1u+(t27)*6u+5u]);}else{
var t29:u32=0u;
var t30:u32=0u;
var t31:u32=0u;
var t32:u32=1065353216u;
var t33:u32=1065353216u;
var t34:u32=0u;
t28=R_Parameter(t29,t30,t31,t32,t33,t34);}
t26=(t28).ink_f_value;
}
var t35:u32=t26;
var t36:u32=t19;
var t37:u32;if(t36<a3[0u]){
t37=a3[1u+(t36)*1u+0u];}else{
t37=0u;}
t18=ink_f32_add(t20,ink_f32_mul(t35,t37));
}
var t38:u32=t18;
output[1u+i*1u+0u]=bitcast<u32>(t38);

}
case 1u:{
var t39:u32=a0[0u+(0u)*1u+0u];
var t40:u32=a1[0u+(0u)*1u+0u];
var t41:u32=223u;
var t42:u32=t39;
var t43:u32=t40;
var t44:u32=t41;
var t45:u32=(t44 + 6u);
var t46:u32=t43;
var t47:u32;
if ((t46 == t45)) {
t47=t42;
} else {
var t48:u32=t45;
var t49:R_Parameter;if(t48<a2[0u]){
t49=R_Parameter(a2[1u+(t48)*6u+0u],a2[1u+(t48)*6u+1u],a2[1u+(t48)*6u+2u],a2[1u+(t48)*6u+3u],a2[1u+(t48)*6u+4u],a2[1u+(t48)*6u+5u]);}else{
var t50:u32=0u;
var t51:u32=0u;
var t52:u32=0u;
var t53:u32=1065353216u;
var t54:u32=1065353216u;
var t55:u32=0u;
t49=R_Parameter(t50,t51,t52,t53,t54,t55);}
t47=(t49).ink_f_value;
}
var t56:u32=t47;
var t57:u32=t56;
for(var t58=0u;t58<6u;t58++){
var t59:u32=t57;
var t60:u32=t39;
var t61:u32=t40;
var t62:u32=t41;
var t63:u32=(t62 + t58);
var t64:u32=t61;
var t65:u32;
if ((t64 == t63)) {
t65=t60;
} else {
var t66:u32=t63;
var t67:R_Parameter;if(t66<a2[0u]){
t67=R_Parameter(a2[1u+(t66)*6u+0u],a2[1u+(t66)*6u+1u],a2[1u+(t66)*6u+2u],a2[1u+(t66)*6u+3u],a2[1u+(t66)*6u+4u],a2[1u+(t66)*6u+5u]);}else{
var t68:u32=0u;
var t69:u32=0u;
var t70:u32=0u;
var t71:u32=1065353216u;
var t72:u32=1065353216u;
var t73:u32=0u;
t67=R_Parameter(t68,t69,t70,t71,t72,t73);}
t65=(t67).ink_f_value;
}
var t74:u32=t65;
var t75:u32=t58;
var t76:u32;if(t75<a3[0u]){
t76=a3[1u+(t75)*1u+0u];}else{
t76=0u;}
t57=ink_f32_add(t59,ink_f32_mul(t74,t76));
}
var t77:u32=t57;
output[1u+i*1u+0u]=bitcast<u32>(t77);

}
case 2u:{
var t78:u32=a0[0u+(0u)*1u+0u];
var t79:u32=a1[0u+(0u)*1u+0u];
var t80:u32=230u;
var t81:u32=t78;
var t82:u32=t79;
var t83:u32=t80;
var t84:u32=(t83 + 6u);
var t85:u32=t82;
var t86:u32;
if ((t85 == t84)) {
t86=t81;
} else {
var t87:u32=t84;
var t88:R_Parameter;if(t87<a2[0u]){
t88=R_Parameter(a2[1u+(t87)*6u+0u],a2[1u+(t87)*6u+1u],a2[1u+(t87)*6u+2u],a2[1u+(t87)*6u+3u],a2[1u+(t87)*6u+4u],a2[1u+(t87)*6u+5u]);}else{
var t89:u32=0u;
var t90:u32=0u;
var t91:u32=0u;
var t92:u32=1065353216u;
var t93:u32=1065353216u;
var t94:u32=0u;
t88=R_Parameter(t89,t90,t91,t92,t93,t94);}
t86=(t88).ink_f_value;
}
var t95:u32=t86;
var t96:u32=t95;
for(var t97=0u;t97<6u;t97++){
var t98:u32=t96;
var t99:u32=t78;
var t100:u32=t79;
var t101:u32=t80;
var t102:u32=(t101 + t97);
var t103:u32=t100;
var t104:u32;
if ((t103 == t102)) {
t104=t99;
} else {
var t105:u32=t102;
var t106:R_Parameter;if(t105<a2[0u]){
t106=R_Parameter(a2[1u+(t105)*6u+0u],a2[1u+(t105)*6u+1u],a2[1u+(t105)*6u+2u],a2[1u+(t105)*6u+3u],a2[1u+(t105)*6u+4u],a2[1u+(t105)*6u+5u]);}else{
var t107:u32=0u;
var t108:u32=0u;
var t109:u32=0u;
var t110:u32=1065353216u;
var t111:u32=1065353216u;
var t112:u32=0u;
t106=R_Parameter(t107,t108,t109,t110,t111,t112);}
t104=(t106).ink_f_value;
}
var t113:u32=t104;
var t114:u32=t97;
var t115:u32;if(t114<a3[0u]){
t115=a3[1u+(t114)*1u+0u];}else{
t115=0u;}
t96=ink_f32_add(t98,ink_f32_mul(t113,t115));
}
var t116:u32=t96;
output[1u+i*1u+0u]=bitcast<u32>(t116);

}
case 3u:{
var t117:u32=a0[0u+(0u)*1u+0u];
var t118:u32=a1[0u+(0u)*1u+0u];
var t119:u32=237u;
var t120:u32=t117;
var t121:u32=t118;
var t122:u32=t119;
var t123:u32=(t122 + 6u);
var t124:u32=t121;
var t125:u32;
if ((t124 == t123)) {
t125=t120;
} else {
var t126:u32=t123;
var t127:R_Parameter;if(t126<a2[0u]){
t127=R_Parameter(a2[1u+(t126)*6u+0u],a2[1u+(t126)*6u+1u],a2[1u+(t126)*6u+2u],a2[1u+(t126)*6u+3u],a2[1u+(t126)*6u+4u],a2[1u+(t126)*6u+5u]);}else{
var t128:u32=0u;
var t129:u32=0u;
var t130:u32=0u;
var t131:u32=1065353216u;
var t132:u32=1065353216u;
var t133:u32=0u;
t127=R_Parameter(t128,t129,t130,t131,t132,t133);}
t125=(t127).ink_f_value;
}
var t134:u32=t125;
var t135:u32=t134;
for(var t136=0u;t136<6u;t136++){
var t137:u32=t135;
var t138:u32=t117;
var t139:u32=t118;
var t140:u32=t119;
var t141:u32=(t140 + t136);
var t142:u32=t139;
var t143:u32;
if ((t142 == t141)) {
t143=t138;
} else {
var t144:u32=t141;
var t145:R_Parameter;if(t144<a2[0u]){
t145=R_Parameter(a2[1u+(t144)*6u+0u],a2[1u+(t144)*6u+1u],a2[1u+(t144)*6u+2u],a2[1u+(t144)*6u+3u],a2[1u+(t144)*6u+4u],a2[1u+(t144)*6u+5u]);}else{
var t146:u32=0u;
var t147:u32=0u;
var t148:u32=0u;
var t149:u32=1065353216u;
var t150:u32=1065353216u;
var t151:u32=0u;
t145=R_Parameter(t146,t147,t148,t149,t150,t151);}
t143=(t145).ink_f_value;
}
var t152:u32=t143;
var t153:u32=t136;
var t154:u32;if(t153<a3[0u]){
t154=a3[1u+(t153)*1u+0u];}else{
t154=0u;}
t135=ink_f32_add(t137,ink_f32_mul(t152,t154));
}
var t155:u32=t135;
output[1u+i*1u+0u]=bitcast<u32>(t155);

}
default:{} }

}
}