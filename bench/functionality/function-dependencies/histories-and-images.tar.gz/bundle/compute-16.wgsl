// Exact wrapping u64 over two storage lanes. No floating point intermediates.
struct InkU64 {lo:u32,hi:u32,}
struct InkDiv64 {quotient:InkU64,remainder:InkU64,}
fn ink_u64_shl(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64(a.lo<<k,(a.hi<<k)|(a.lo>>(32u-k)));}return InkU64(0u,a.lo<<(k-32u));}
fn ink_u64_shr(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64((a.lo>>k)|(a.hi<<(32u-k)),a.hi>>k);}return InkU64(a.hi>>(k-32u),0u);}
fn ink_u64_rol(a:InkU64,count:u32)->InkU64{let k=count&63u;let l=ink_u64_shl(a,k);let r=ink_u64_shr(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_ror(a:InkU64,count:u32)->InkU64{let k=count&63u;let r=ink_u64_shr(a,k);let l=ink_u64_shl(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_eq(a:InkU64,b:InkU64)->bool{return a.lo==b.lo&&a.hi==b.hi;}
fn ink_u64_lt(a:InkU64,b:InkU64)->bool{return a.hi<b.hi||(a.hi==b.hi&&a.lo<b.lo);}
fn ink_u64_add(a:InkU64,b:InkU64)->InkU64{let lo=a.lo+b.lo;return InkU64(lo,a.hi+b.hi+select(0u,1u,lo<a.lo));}
fn ink_u64_sub(a:InkU64,b:InkU64)->InkU64{return InkU64(a.lo-b.lo,a.hi-b.hi-select(0u,1u,a.lo<b.lo));}
fn ink_u64_mul(a:InkU64,b:InkU64)->InkU64{let al=a.lo&65535u;let ah=a.lo>>16u;let bl=b.lo&65535u;let bh=b.lo>>16u;let p=al*bl;let x=ah*bl;let y=al*bh;let mid=(p>>16u)+(x&65535u)+(y&65535u);let high=ah*bh+(x>>16u)+(y>>16u)+(mid>>16u);return InkU64((mid<<16u)|(p&65535u),high+a.lo*b.hi+a.hi*b.lo);}
fn ink_u64_div(a:InkU64,b:InkU64)->InkDiv64{var q=InkU64(0u,0u);var r=InkU64(0u,0u);var cursor=64u;loop{if(cursor==0u){break;}cursor--;var bit=0u;if(cursor>=32u){bit=(a.hi>>(cursor-32u))&1u;}else{bit=(a.lo>>cursor)&1u;}let overflow=r.hi>>31u;r=InkU64((r.lo<<1u)|bit,(r.hi<<1u)|(r.lo>>31u));if(overflow!=0u||!ink_u64_lt(r,b)){r=ink_u64_sub(r,b);if(cursor>=32u){q.hi|=1u<<(cursor-32u);}else{q.lo|=1u<<cursor;}}}return InkDiv64(q,r);}
// Binary32 evaluated with integer lanes: round-to-nearest, ties-to-even,
// gradual underflow, signed zero and canonical arithmetic NaN.
fn ink_f32_nan(x:u32)->bool{return (x&0x7fffffffu)>0x7f800000u;}
fn ink_f32_eq(a:u32,b:u32)->bool{return !ink_f32_nan(a)&&!ink_f32_nan(b)&&(a==b||((a|b)&0x7fffffffu)==0u);}
fn ink_f32_lt(a:u32,b:u32)->bool{
 if(ink_f32_nan(a)||ink_f32_nan(b)||ink_f32_eq(a,b)){return false;}
 if((a^b)&0x80000000u)!=0u{return (a&0x80000000u)!=0u;}
 if((a&0x80000000u)!=0u){return a>b;}return a<b;
}
fn ink_f32_jam(x:u32,n:u32)->u32{if(n==0u){return x;}if(n>=32u){return select(0u,1u,x!=0u);}return (x>>n)|select(0u,1u,(x&((1u<<n)-1u))!=0u);}
fn ink_f32_round(sign:u32,exponent:i32,extended:u32)->u32{
 var e=exponent;var s=extended;
 if(e<1i){s=ink_f32_jam(s,u32(1i-e));e=1i;}
 let tail=s&7u;var sig=s>>3u;
 if(tail>4u||(tail==4u&&(sig&1u)!=0u)){sig++;}
 if(sig>=0x1000000u){sig>>=1u;e++;}
 if(e>=255i){return sign|0x7f800000u;}
 if(sig==0u){return sign;}
 let raw=select(u32(e),0u,e==1i&&sig<0x800000u);
 return sign|(raw<<23u)|(sig&0x7fffffu);
}
fn ink_f32_add(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 var x=a;var y=b;if((x&0x7fffffffu)<(y&0x7fffffffu)){x=b;y=a;}
 let ax=x&0x7fffffffu;let ay=y&0x7fffffffu;let sign=x&0x80000000u;
 if(ax==0x7f800000u){if(ay==ax&&((x^y)&0x80000000u)!=0u){return 0x7fc00000u;}return x;}
 let rx=(x>>23u)&255u;let ry=(y>>23u)&255u;var e=i32(max(rx,1u));
 var sx=((x&0x7fffffu)|select(0u,0x800000u,rx!=0u))<<3u;
 let sy=ink_f32_jam(((y&0x7fffffu)|select(0u,0x800000u,ry!=0u))<<3u,u32(e)-max(ry,1u));
 if(((x^y)&0x80000000u)==0u){sx+=sy;if(sx>=0x8000000u){sx=ink_f32_jam(sx,1u);e++;}}
 else{sx-=sy;if(sx==0u){return 0u;}loop{if(sx>=0x4000000u||e<=1i){break;}sx<<=1u;e--;}}
 return ink_f32_round(sign,e,sx);
}
fn ink_f32_sub(a:u32,b:u32)->u32{return ink_f32_add(a,b^0x80000000u);}
fn ink_f32_mul(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(aa==0x7f800000u||bb==0x7f800000u){if(aa==0u||bb==0u){return 0x7fc00000u;}return sign|0x7f800000u;}
 if(aa==0u||bb==0u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u));var eb=i32(max(rb,1u));
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 let product=ink_u64_mul(InkU64(sa,0u),InkU64(sb,0u));let high=(product.hi&0x8000u)!=0u;
 let shift=select(20u,21u,high);let extended=(product.lo>>shift)|(product.hi<<(32u-shift))|select(0u,1u,(product.lo&((1u<<shift)-1u))!=0u);
 return ink_f32_round(sign,ea+eb-127i+select(0i,1i,high),extended);
}
// Exact sqrt and division use integer significands, independent of WGSL float
// approximation allowances and device flush-to-zero behavior.
fn ink_f32_sqrt(x:u32)->u32{
 let a=x&0x7fffffffu;if(a==0u){return x;}
 if(a>0x7f800000u||(x&0x80000000u)!=0u){return 0x7fc00000u;}
 if(a==0x7f800000u){return x;}
 let raw=(x>>23u)&255u;var m=(x&0x7fffffu)|select(0u,0x800000u,raw!=0u);var e=i32(max(raw,1u))-127i;
 loop{if(m>=0x800000u){break;}m<<=1u;e--;}
 let odd=e&1i;var half=(e-odd)/2i;let shift=23u+u32(odd);
 let n=InkU64(m<<shift,m>>(32u-shift));var lo=0u;var hi=0x1000000u;
 loop{if(lo+1u>=hi){break;}let mid=(lo+hi)>>1u;let sq=ink_u64_mul(InkU64(mid,0u),InkU64(mid,0u));if(!ink_u64_lt(n,sq)){lo=mid;}else{hi=mid;}}
 let sq=ink_u64_mul(InkU64(lo,0u),InkU64(lo,0u));let rem=ink_u64_sub(n,sq);
 if(ink_u64_lt(InkU64(lo,0u),rem)){lo++;}
 if(lo==0x1000000u){lo>>=1u;half++;}
 return (u32(half+127i)<<23u)|(lo&0x7fffffu);
}
fn ink_f32_div(a:u32,b:u32)->u32{
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(ink_f32_nan(a)||ink_f32_nan(b)||(aa==0u&&bb==0u)||(aa==0x7f800000u&&bb==aa)){return 0x7fc00000u;}
 if(aa==0x7f800000u||bb==0u){return sign|0x7f800000u;}
 if(aa==0u||bb==0x7f800000u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u))-127i;var eb=i32(max(rb,1u))-127i;
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 var e=ea-eb;if(sa<sb){sa<<=1u;e--;}
 let division=ink_u64_div(InkU64(sa<<26u,sa>>6u),InkU64(sb,0u));
 let extended=division.quotient.lo|select(0u,1u,!ink_u64_eq(division.remainder,InkU64(0u,0u)));
 return ink_f32_round(sign,e+127i,extended);
}
// mode: 0 trunc, 1 floor, 2 ceil, 3 ties-to-even.
fn ink_f32_integral(x:u32,mode:u32)->u32{
 let a=x&0x7fffffffu;let sign=x&0x80000000u;
 if(a>0x7f800000u){return 0x7fc00000u;}if(a>=0x4b000000u||a==0u){return x;}
 let e=i32((x>>23u)&255u)-127i;
 if(e<0i){var up=false;if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){up=a>0x3f000000u;}return sign|select(0u,0x3f800000u,up);}
 let shift=u32(23i-e);let mask=(1u<<shift)-1u;let fraction=a&mask;var rounded=a&~mask;var up=false;
 if(fraction!=0u){if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){let half=1u<<(shift-1u);up=fraction>half||(fraction==half&&((rounded>>shift)&1u)!=0u);}}
 if(up){rounded+=1u<<shift;}return sign|rounded;
}
fn ink_f32_from_u64(x:InkU64)->u32{
 if(ink_u64_eq(x,InkU64(0u,0u))){return 0u;}
 let leading=select(countLeadingZeros(x.lo)+32u,countLeadingZeros(x.hi),x.hi!=0u);let e=63u-leading;
 if(e<=23u){return ((e+127u)<<23u)|((x.lo<<(23u-e))&0x7fffffu);}
 let shift=e-23u;var sig=0u;var rem=InkU64(0u,0u);var half=InkU64(0u,0u);
 if(shift<32u){sig=(x.lo>>shift)|(x.hi<<(32u-shift));rem=InkU64(x.lo&((1u<<shift)-1u),0u);half=InkU64(1u<<(shift-1u),0u);}
 else if(shift==32u){sig=x.hi;rem=InkU64(x.lo,0u);half=InkU64(0x80000000u,0u);}
 else{sig=x.hi>>(shift-32u);rem=InkU64(x.lo,x.hi&((1u<<(shift-32u))-1u));half=InkU64(0u,1u<<(shift-33u));}
 if(ink_u64_lt(half,rem)||(ink_u64_eq(rem,half)&&(sig&1u)!=0u)){sig++;}
 var exponent=e+127u;if(sig==0x1000000u){sig>>=1u;exponent++;}
 return (exponent<<23u)|(sig&0x7fffffu);
}
fn ink_f32_from_i32(x:i32)->u32{let neg=x<0i;let magnitude=select(u32(x),0u-u32(x),neg);return ink_f32_from_u64(InkU64(magnitude,0u))|select(0u,0x80000000u,neg);}
struct InkBuffer_u32{data:array<u32,64>,length:u32,}
struct InkBuffer_InkU64{data:array<InkU64,64>,length:u32,}
struct InkBuffer_i32{data:array<i32,64>,length:u32,}
struct InkBuffer_bool{data:array<bool,64>,length:u32,}
struct R_Parameter{ink_f_value:u32,ink_f_first:u32,ink_f_second:u32,ink_f_first_power:u32,ink_f_second_power:u32,ink_f_steps:u32,}
@group(0) @binding(0) var<storage,read> a0:array<u32>;
@group(0) @binding(1) var<storage,read> a1:array<u32>;
@group(0) @binding(2) var<storage,read> a2:array<u32>;
@group(0) @binding(3) var<storage,read> a3:array<u32>;
@group(0) @binding(4) var<storage,read_write> output:array<u32>;
@group(0) @binding(5) var<storage,read> ink_meta:array<u32>;
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) gid:vec3<u32>){let i=gid.x;if(i>=ink_meta[4]){return;}
if(i==0u){output[0u]=a3[0u];}if(i>=a3[0u]){return;}
var t0:u32=a3[1u+(i)*1u+0u];
var t1:u32=0u;
var t2:u32=4294967295u;
var t3:u32=t0;
var t4:u32=t1;
var t5:u32=t2;
var t6:u32=t3;
var t7:u32=t4;
var t8:u32=t5;
var t9:u32=t6;
var t10:array<u32,6>;
var t11:u32=t7;
var t12:u32=t8;
var t13:u32=t9;
var t14:u32=0u;
var t15:u32=t11;
var t16:u32=t12;
var t17:u32=t14;
var t18:u32=(t17 + 10u);
var t19:u32=t16;
var t20:u32;
if ((t19 == t18)) {
t20=t15;
} else {
var t21:u32=t18;
var t22:R_Parameter;if(t21<a0[0u]){
t22=R_Parameter(a0[1u+(t21)*6u+0u],a0[1u+(t21)*6u+1u],a0[1u+(t21)*6u+2u],a0[1u+(t21)*6u+3u],a0[1u+(t21)*6u+4u],a0[1u+(t21)*6u+5u]);}else{
var t23:u32=0u;
var t24:u32=0u;
var t25:u32=0u;
var t26:u32=1065353216u;
var t27:u32=1065353216u;
var t28:u32=0u;
t22=R_Parameter(t23,t24,t25,t26,t27,t28);}
t20=(t22).ink_f_value;
}
var t29:u32=t20;
var t30:u32=t29;
for(var t31=0u;t31<10u;t31++){
var t32:u32=t30;
var t33:u32=t11;
var t34:u32=t12;
var t35:u32=t14;
var t36:u32=(t35 + t31);
var t37:u32=t34;
var t38:u32;
if ((t37 == t36)) {
t38=t33;
} else {
var t39:u32=t36;
var t40:R_Parameter;if(t39<a0[0u]){
t40=R_Parameter(a0[1u+(t39)*6u+0u],a0[1u+(t39)*6u+1u],a0[1u+(t39)*6u+2u],a0[1u+(t39)*6u+3u],a0[1u+(t39)*6u+4u],a0[1u+(t39)*6u+5u]);}else{
var t41:u32=0u;
var t42:u32=0u;
var t43:u32=0u;
var t44:u32=1065353216u;
var t45:u32=1065353216u;
var t46:u32=0u;
t40=R_Parameter(t41,t42,t43,t44,t45,t46);}
t38=(t40).ink_f_value;
}
var t47:u32=t38;
var t48:u32=t13;
var t49:u32=(t48 * 10u);
var t50:u32=(t49 + t31);
var t51:u32;if(t50<a1[0u]){
t51=a1[1u+(t50)*1u+0u];}else{
t51=0u;}
t30=ink_f32_add(t32,ink_f32_mul(t47,t51));
}
var t52:u32=t30;
var t53:u32=t7;
var t54:u32=t8;
var t55:u32=t9;
var t56:u32=11u;
var t57:u32=t53;
var t58:u32=t54;
var t59:u32=t56;
var t60:u32=(t59 + 10u);
var t61:u32=t58;
var t62:u32;
if ((t61 == t60)) {
t62=t57;
} else {
var t63:u32=t60;
var t64:R_Parameter;if(t63<a0[0u]){
t64=R_Parameter(a0[1u+(t63)*6u+0u],a0[1u+(t63)*6u+1u],a0[1u+(t63)*6u+2u],a0[1u+(t63)*6u+3u],a0[1u+(t63)*6u+4u],a0[1u+(t63)*6u+5u]);}else{
var t65:u32=0u;
var t66:u32=0u;
var t67:u32=0u;
var t68:u32=1065353216u;
var t69:u32=1065353216u;
var t70:u32=0u;
t64=R_Parameter(t65,t66,t67,t68,t69,t70);}
t62=(t64).ink_f_value;
}
var t71:u32=t62;
var t72:u32=t71;
for(var t73=0u;t73<10u;t73++){
var t74:u32=t72;
var t75:u32=t53;
var t76:u32=t54;
var t77:u32=t56;
var t78:u32=(t77 + t73);
var t79:u32=t76;
var t80:u32;
if ((t79 == t78)) {
t80=t75;
} else {
var t81:u32=t78;
var t82:R_Parameter;if(t81<a0[0u]){
t82=R_Parameter(a0[1u+(t81)*6u+0u],a0[1u+(t81)*6u+1u],a0[1u+(t81)*6u+2u],a0[1u+(t81)*6u+3u],a0[1u+(t81)*6u+4u],a0[1u+(t81)*6u+5u]);}else{
var t83:u32=0u;
var t84:u32=0u;
var t85:u32=0u;
var t86:u32=1065353216u;
var t87:u32=1065353216u;
var t88:u32=0u;
t82=R_Parameter(t83,t84,t85,t86,t87,t88);}
t80=(t82).ink_f_value;
}
var t89:u32=t80;
var t90:u32=t55;
var t91:u32=(t90 * 10u);
var t92:u32=(t91 + t73);
var t93:u32;if(t92<a1[0u]){
t93=a1[1u+(t92)*1u+0u];}else{
t93=0u;}
t72=ink_f32_add(t74,ink_f32_mul(t89,t93));
}
var t94:u32=t72;
var t95:u32=t94;
var t96:u32;
if (ink_f32_lt(0u,t95)) {
var t97:u32=t52;
t96=ink_f32_mul(t97,t94);
} else {
t96=0u;
}
t10[0u]=t96;
var t98:u32=t7;
var t99:u32=t8;
var t100:u32=t9;
var t101:u32=22u;
var t102:u32=t98;
var t103:u32=t99;
var t104:u32=t101;
var t105:u32=(t104 + 10u);
var t106:u32=t103;
var t107:u32;
if ((t106 == t105)) {
t107=t102;
} else {
var t108:u32=t105;
var t109:R_Parameter;if(t108<a0[0u]){
t109=R_Parameter(a0[1u+(t108)*6u+0u],a0[1u+(t108)*6u+1u],a0[1u+(t108)*6u+2u],a0[1u+(t108)*6u+3u],a0[1u+(t108)*6u+4u],a0[1u+(t108)*6u+5u]);}else{
var t110:u32=0u;
var t111:u32=0u;
var t112:u32=0u;
var t113:u32=1065353216u;
var t114:u32=1065353216u;
var t115:u32=0u;
t109=R_Parameter(t110,t111,t112,t113,t114,t115);}
t107=(t109).ink_f_value;
}
var t116:u32=t107;
var t117:u32=t116;
for(var t118=0u;t118<10u;t118++){
var t119:u32=t117;
var t120:u32=t98;
var t121:u32=t99;
var t122:u32=t101;
var t123:u32=(t122 + t118);
var t124:u32=t121;
var t125:u32;
if ((t124 == t123)) {
t125=t120;
} else {
var t126:u32=t123;
var t127:R_Parameter;if(t126<a0[0u]){
t127=R_Parameter(a0[1u+(t126)*6u+0u],a0[1u+(t126)*6u+1u],a0[1u+(t126)*6u+2u],a0[1u+(t126)*6u+3u],a0[1u+(t126)*6u+4u],a0[1u+(t126)*6u+5u]);}else{
var t128:u32=0u;
var t129:u32=0u;
var t130:u32=0u;
var t131:u32=1065353216u;
var t132:u32=1065353216u;
var t133:u32=0u;
t127=R_Parameter(t128,t129,t130,t131,t132,t133);}
t125=(t127).ink_f_value;
}
var t134:u32=t125;
var t135:u32=t100;
var t136:u32=(t135 * 10u);
var t137:u32=(t136 + t118);
var t138:u32;if(t137<a1[0u]){
t138=a1[1u+(t137)*1u+0u];}else{
t138=0u;}
t117=ink_f32_add(t119,ink_f32_mul(t134,t138));
}
var t139:u32=t117;
var t140:u32=t7;
var t141:u32=t8;
var t142:u32=t9;
var t143:u32=33u;
var t144:u32=t140;
var t145:u32=t141;
var t146:u32=t143;
var t147:u32=(t146 + 10u);
var t148:u32=t145;
var t149:u32;
if ((t148 == t147)) {
t149=t144;
} else {
var t150:u32=t147;
var t151:R_Parameter;if(t150<a0[0u]){
t151=R_Parameter(a0[1u+(t150)*6u+0u],a0[1u+(t150)*6u+1u],a0[1u+(t150)*6u+2u],a0[1u+(t150)*6u+3u],a0[1u+(t150)*6u+4u],a0[1u+(t150)*6u+5u]);}else{
var t152:u32=0u;
var t153:u32=0u;
var t154:u32=0u;
var t155:u32=1065353216u;
var t156:u32=1065353216u;
var t157:u32=0u;
t151=R_Parameter(t152,t153,t154,t155,t156,t157);}
t149=(t151).ink_f_value;
}
var t158:u32=t149;
var t159:u32=t158;
for(var t160=0u;t160<10u;t160++){
var t161:u32=t159;
var t162:u32=t140;
var t163:u32=t141;
var t164:u32=t143;
var t165:u32=(t164 + t160);
var t166:u32=t163;
var t167:u32;
if ((t166 == t165)) {
t167=t162;
} else {
var t168:u32=t165;
var t169:R_Parameter;if(t168<a0[0u]){
t169=R_Parameter(a0[1u+(t168)*6u+0u],a0[1u+(t168)*6u+1u],a0[1u+(t168)*6u+2u],a0[1u+(t168)*6u+3u],a0[1u+(t168)*6u+4u],a0[1u+(t168)*6u+5u]);}else{
var t170:u32=0u;
var t171:u32=0u;
var t172:u32=0u;
var t173:u32=1065353216u;
var t174:u32=1065353216u;
var t175:u32=0u;
t169=R_Parameter(t170,t171,t172,t173,t174,t175);}
t167=(t169).ink_f_value;
}
var t176:u32=t167;
var t177:u32=t142;
var t178:u32=(t177 * 10u);
var t179:u32=(t178 + t160);
var t180:u32;if(t179<a1[0u]){
t180=a1[1u+(t179)*1u+0u];}else{
t180=0u;}
t159=ink_f32_add(t161,ink_f32_mul(t176,t180));
}
var t181:u32=t159;
var t182:u32=t181;
var t183:u32;
if (ink_f32_lt(0u,t182)) {
var t184:u32=t139;
t183=ink_f32_mul(t184,t181);
} else {
t183=0u;
}
t10[1u]=t183;
var t185:u32=t7;
var t186:u32=t8;
var t187:u32=t9;
var t188:u32=44u;
var t189:u32=t185;
var t190:u32=t186;
var t191:u32=t188;
var t192:u32=(t191 + 10u);
var t193:u32=t190;
var t194:u32;
if ((t193 == t192)) {
t194=t189;
} else {
var t195:u32=t192;
var t196:R_Parameter;if(t195<a0[0u]){
t196=R_Parameter(a0[1u+(t195)*6u+0u],a0[1u+(t195)*6u+1u],a0[1u+(t195)*6u+2u],a0[1u+(t195)*6u+3u],a0[1u+(t195)*6u+4u],a0[1u+(t195)*6u+5u]);}else{
var t197:u32=0u;
var t198:u32=0u;
var t199:u32=0u;
var t200:u32=1065353216u;
var t201:u32=1065353216u;
var t202:u32=0u;
t196=R_Parameter(t197,t198,t199,t200,t201,t202);}
t194=(t196).ink_f_value;
}
var t203:u32=t194;
var t204:u32=t203;
for(var t205=0u;t205<10u;t205++){
var t206:u32=t204;
var t207:u32=t185;
var t208:u32=t186;
var t209:u32=t188;
var t210:u32=(t209 + t205);
var t211:u32=t208;
var t212:u32;
if ((t211 == t210)) {
t212=t207;
} else {
var t213:u32=t210;
var t214:R_Parameter;if(t213<a0[0u]){
t214=R_Parameter(a0[1u+(t213)*6u+0u],a0[1u+(t213)*6u+1u],a0[1u+(t213)*6u+2u],a0[1u+(t213)*6u+3u],a0[1u+(t213)*6u+4u],a0[1u+(t213)*6u+5u]);}else{
var t215:u32=0u;
var t216:u32=0u;
var t217:u32=0u;
var t218:u32=1065353216u;
var t219:u32=1065353216u;
var t220:u32=0u;
t214=R_Parameter(t215,t216,t217,t218,t219,t220);}
t212=(t214).ink_f_value;
}
var t221:u32=t212;
var t222:u32=t187;
var t223:u32=(t222 * 10u);
var t224:u32=(t223 + t205);
var t225:u32;if(t224<a1[0u]){
t225=a1[1u+(t224)*1u+0u];}else{
t225=0u;}
t204=ink_f32_add(t206,ink_f32_mul(t221,t225));
}
var t226:u32=t204;
var t227:u32=t7;
var t228:u32=t8;
var t229:u32=t9;
var t230:u32=55u;
var t231:u32=t227;
var t232:u32=t228;
var t233:u32=t230;
var t234:u32=(t233 + 10u);
var t235:u32=t232;
var t236:u32;
if ((t235 == t234)) {
t236=t231;
} else {
var t237:u32=t234;
var t238:R_Parameter;if(t237<a0[0u]){
t238=R_Parameter(a0[1u+(t237)*6u+0u],a0[1u+(t237)*6u+1u],a0[1u+(t237)*6u+2u],a0[1u+(t237)*6u+3u],a0[1u+(t237)*6u+4u],a0[1u+(t237)*6u+5u]);}else{
var t239:u32=0u;
var t240:u32=0u;
var t241:u32=0u;
var t242:u32=1065353216u;
var t243:u32=1065353216u;
var t244:u32=0u;
t238=R_Parameter(t239,t240,t241,t242,t243,t244);}
t236=(t238).ink_f_value;
}
var t245:u32=t236;
var t246:u32=t245;
for(var t247=0u;t247<10u;t247++){
var t248:u32=t246;
var t249:u32=t227;
var t250:u32=t228;
var t251:u32=t230;
var t252:u32=(t251 + t247);
var t253:u32=t250;
var t254:u32;
if ((t253 == t252)) {
t254=t249;
} else {
var t255:u32=t252;
var t256:R_Parameter;if(t255<a0[0u]){
t256=R_Parameter(a0[1u+(t255)*6u+0u],a0[1u+(t255)*6u+1u],a0[1u+(t255)*6u+2u],a0[1u+(t255)*6u+3u],a0[1u+(t255)*6u+4u],a0[1u+(t255)*6u+5u]);}else{
var t257:u32=0u;
var t258:u32=0u;
var t259:u32=0u;
var t260:u32=1065353216u;
var t261:u32=1065353216u;
var t262:u32=0u;
t256=R_Parameter(t257,t258,t259,t260,t261,t262);}
t254=(t256).ink_f_value;
}
var t263:u32=t254;
var t264:u32=t229;
var t265:u32=(t264 * 10u);
var t266:u32=(t265 + t247);
var t267:u32;if(t266<a1[0u]){
t267=a1[1u+(t266)*1u+0u];}else{
t267=0u;}
t246=ink_f32_add(t248,ink_f32_mul(t263,t267));
}
var t268:u32=t246;
var t269:u32=t268;
var t270:u32;
if (ink_f32_lt(0u,t269)) {
var t271:u32=t226;
t270=ink_f32_mul(t271,t268);
} else {
t270=0u;
}
t10[2u]=t270;
var t272:u32=t7;
var t273:u32=t8;
var t274:u32=t9;
var t275:u32=66u;
var t276:u32=t272;
var t277:u32=t273;
var t278:u32=t275;
var t279:u32=(t278 + 10u);
var t280:u32=t277;
var t281:u32;
if ((t280 == t279)) {
t281=t276;
} else {
var t282:u32=t279;
var t283:R_Parameter;if(t282<a0[0u]){
t283=R_Parameter(a0[1u+(t282)*6u+0u],a0[1u+(t282)*6u+1u],a0[1u+(t282)*6u+2u],a0[1u+(t282)*6u+3u],a0[1u+(t282)*6u+4u],a0[1u+(t282)*6u+5u]);}else{
var t284:u32=0u;
var t285:u32=0u;
var t286:u32=0u;
var t287:u32=1065353216u;
var t288:u32=1065353216u;
var t289:u32=0u;
t283=R_Parameter(t284,t285,t286,t287,t288,t289);}
t281=(t283).ink_f_value;
}
var t290:u32=t281;
var t291:u32=t290;
for(var t292=0u;t292<10u;t292++){
var t293:u32=t291;
var t294:u32=t272;
var t295:u32=t273;
var t296:u32=t275;
var t297:u32=(t296 + t292);
var t298:u32=t295;
var t299:u32;
if ((t298 == t297)) {
t299=t294;
} else {
var t300:u32=t297;
var t301:R_Parameter;if(t300<a0[0u]){
t301=R_Parameter(a0[1u+(t300)*6u+0u],a0[1u+(t300)*6u+1u],a0[1u+(t300)*6u+2u],a0[1u+(t300)*6u+3u],a0[1u+(t300)*6u+4u],a0[1u+(t300)*6u+5u]);}else{
var t302:u32=0u;
var t303:u32=0u;
var t304:u32=0u;
var t305:u32=1065353216u;
var t306:u32=1065353216u;
var t307:u32=0u;
t301=R_Parameter(t302,t303,t304,t305,t306,t307);}
t299=(t301).ink_f_value;
}
var t308:u32=t299;
var t309:u32=t274;
var t310:u32=(t309 * 10u);
var t311:u32=(t310 + t292);
var t312:u32;if(t311<a1[0u]){
t312=a1[1u+(t311)*1u+0u];}else{
t312=0u;}
t291=ink_f32_add(t293,ink_f32_mul(t308,t312));
}
var t313:u32=t291;
var t314:u32=t7;
var t315:u32=t8;
var t316:u32=t9;
var t317:u32=77u;
var t318:u32=t314;
var t319:u32=t315;
var t320:u32=t317;
var t321:u32=(t320 + 10u);
var t322:u32=t319;
var t323:u32;
if ((t322 == t321)) {
t323=t318;
} else {
var t324:u32=t321;
var t325:R_Parameter;if(t324<a0[0u]){
t325=R_Parameter(a0[1u+(t324)*6u+0u],a0[1u+(t324)*6u+1u],a0[1u+(t324)*6u+2u],a0[1u+(t324)*6u+3u],a0[1u+(t324)*6u+4u],a0[1u+(t324)*6u+5u]);}else{
var t326:u32=0u;
var t327:u32=0u;
var t328:u32=0u;
var t329:u32=1065353216u;
var t330:u32=1065353216u;
var t331:u32=0u;
t325=R_Parameter(t326,t327,t328,t329,t330,t331);}
t323=(t325).ink_f_value;
}
var t332:u32=t323;
var t333:u32=t332;
for(var t334=0u;t334<10u;t334++){
var t335:u32=t333;
var t336:u32=t314;
var t337:u32=t315;
var t338:u32=t317;
var t339:u32=(t338 + t334);
var t340:u32=t337;
var t341:u32;
if ((t340 == t339)) {
t341=t336;
} else {
var t342:u32=t339;
var t343:R_Parameter;if(t342<a0[0u]){
t343=R_Parameter(a0[1u+(t342)*6u+0u],a0[1u+(t342)*6u+1u],a0[1u+(t342)*6u+2u],a0[1u+(t342)*6u+3u],a0[1u+(t342)*6u+4u],a0[1u+(t342)*6u+5u]);}else{
var t344:u32=0u;
var t345:u32=0u;
var t346:u32=0u;
var t347:u32=1065353216u;
var t348:u32=1065353216u;
var t349:u32=0u;
t343=R_Parameter(t344,t345,t346,t347,t348,t349);}
t341=(t343).ink_f_value;
}
var t350:u32=t341;
var t351:u32=t316;
var t352:u32=(t351 * 10u);
var t353:u32=(t352 + t334);
var t354:u32;if(t353<a1[0u]){
t354=a1[1u+(t353)*1u+0u];}else{
t354=0u;}
t333=ink_f32_add(t335,ink_f32_mul(t350,t354));
}
var t355:u32=t333;
var t356:u32=t355;
var t357:u32;
if (ink_f32_lt(0u,t356)) {
var t358:u32=t313;
t357=ink_f32_mul(t358,t355);
} else {
t357=0u;
}
t10[3u]=t357;
var t359:u32=t7;
var t360:u32=t8;
var t361:u32=t9;
var t362:u32=88u;
var t363:u32=t359;
var t364:u32=t360;
var t365:u32=t362;
var t366:u32=(t365 + 10u);
var t367:u32=t364;
var t368:u32;
if ((t367 == t366)) {
t368=t363;
} else {
var t369:u32=t366;
var t370:R_Parameter;if(t369<a0[0u]){
t370=R_Parameter(a0[1u+(t369)*6u+0u],a0[1u+(t369)*6u+1u],a0[1u+(t369)*6u+2u],a0[1u+(t369)*6u+3u],a0[1u+(t369)*6u+4u],a0[1u+(t369)*6u+5u]);}else{
var t371:u32=0u;
var t372:u32=0u;
var t373:u32=0u;
var t374:u32=1065353216u;
var t375:u32=1065353216u;
var t376:u32=0u;
t370=R_Parameter(t371,t372,t373,t374,t375,t376);}
t368=(t370).ink_f_value;
}
var t377:u32=t368;
var t378:u32=t377;
for(var t379=0u;t379<10u;t379++){
var t380:u32=t378;
var t381:u32=t359;
var t382:u32=t360;
var t383:u32=t362;
var t384:u32=(t383 + t379);
var t385:u32=t382;
var t386:u32;
if ((t385 == t384)) {
t386=t381;
} else {
var t387:u32=t384;
var t388:R_Parameter;if(t387<a0[0u]){
t388=R_Parameter(a0[1u+(t387)*6u+0u],a0[1u+(t387)*6u+1u],a0[1u+(t387)*6u+2u],a0[1u+(t387)*6u+3u],a0[1u+(t387)*6u+4u],a0[1u+(t387)*6u+5u]);}else{
var t389:u32=0u;
var t390:u32=0u;
var t391:u32=0u;
var t392:u32=1065353216u;
var t393:u32=1065353216u;
var t394:u32=0u;
t388=R_Parameter(t389,t390,t391,t392,t393,t394);}
t386=(t388).ink_f_value;
}
var t395:u32=t386;
var t396:u32=t361;
var t397:u32=(t396 * 10u);
var t398:u32=(t397 + t379);
var t399:u32;if(t398<a1[0u]){
t399=a1[1u+(t398)*1u+0u];}else{
t399=0u;}
t378=ink_f32_add(t380,ink_f32_mul(t395,t399));
}
var t400:u32=t378;
var t401:u32=t7;
var t402:u32=t8;
var t403:u32=t9;
var t404:u32=99u;
var t405:u32=t401;
var t406:u32=t402;
var t407:u32=t404;
var t408:u32=(t407 + 10u);
var t409:u32=t406;
var t410:u32;
if ((t409 == t408)) {
t410=t405;
} else {
var t411:u32=t408;
var t412:R_Parameter;if(t411<a0[0u]){
t412=R_Parameter(a0[1u+(t411)*6u+0u],a0[1u+(t411)*6u+1u],a0[1u+(t411)*6u+2u],a0[1u+(t411)*6u+3u],a0[1u+(t411)*6u+4u],a0[1u+(t411)*6u+5u]);}else{
var t413:u32=0u;
var t414:u32=0u;
var t415:u32=0u;
var t416:u32=1065353216u;
var t417:u32=1065353216u;
var t418:u32=0u;
t412=R_Parameter(t413,t414,t415,t416,t417,t418);}
t410=(t412).ink_f_value;
}
var t419:u32=t410;
var t420:u32=t419;
for(var t421=0u;t421<10u;t421++){
var t422:u32=t420;
var t423:u32=t401;
var t424:u32=t402;
var t425:u32=t404;
var t426:u32=(t425 + t421);
var t427:u32=t424;
var t428:u32;
if ((t427 == t426)) {
t428=t423;
} else {
var t429:u32=t426;
var t430:R_Parameter;if(t429<a0[0u]){
t430=R_Parameter(a0[1u+(t429)*6u+0u],a0[1u+(t429)*6u+1u],a0[1u+(t429)*6u+2u],a0[1u+(t429)*6u+3u],a0[1u+(t429)*6u+4u],a0[1u+(t429)*6u+5u]);}else{
var t431:u32=0u;
var t432:u32=0u;
var t433:u32=0u;
var t434:u32=1065353216u;
var t435:u32=1065353216u;
var t436:u32=0u;
t430=R_Parameter(t431,t432,t433,t434,t435,t436);}
t428=(t430).ink_f_value;
}
var t437:u32=t428;
var t438:u32=t403;
var t439:u32=(t438 * 10u);
var t440:u32=(t439 + t421);
var t441:u32;if(t440<a1[0u]){
t441=a1[1u+(t440)*1u+0u];}else{
t441=0u;}
t420=ink_f32_add(t422,ink_f32_mul(t437,t441));
}
var t442:u32=t420;
var t443:u32=t442;
var t444:u32;
if (ink_f32_lt(0u,t443)) {
var t445:u32=t400;
t444=ink_f32_mul(t445,t442);
} else {
t444=0u;
}
t10[4u]=t444;
var t446:u32=t7;
var t447:u32=t8;
var t448:u32=t9;
var t449:u32=110u;
var t450:u32=t446;
var t451:u32=t447;
var t452:u32=t449;
var t453:u32=(t452 + 10u);
var t454:u32=t451;
var t455:u32;
if ((t454 == t453)) {
t455=t450;
} else {
var t456:u32=t453;
var t457:R_Parameter;if(t456<a0[0u]){
t457=R_Parameter(a0[1u+(t456)*6u+0u],a0[1u+(t456)*6u+1u],a0[1u+(t456)*6u+2u],a0[1u+(t456)*6u+3u],a0[1u+(t456)*6u+4u],a0[1u+(t456)*6u+5u]);}else{
var t458:u32=0u;
var t459:u32=0u;
var t460:u32=0u;
var t461:u32=1065353216u;
var t462:u32=1065353216u;
var t463:u32=0u;
t457=R_Parameter(t458,t459,t460,t461,t462,t463);}
t455=(t457).ink_f_value;
}
var t464:u32=t455;
var t465:u32=t464;
for(var t466=0u;t466<10u;t466++){
var t467:u32=t465;
var t468:u32=t446;
var t469:u32=t447;
var t470:u32=t449;
var t471:u32=(t470 + t466);
var t472:u32=t469;
var t473:u32;
if ((t472 == t471)) {
t473=t468;
} else {
var t474:u32=t471;
var t475:R_Parameter;if(t474<a0[0u]){
t475=R_Parameter(a0[1u+(t474)*6u+0u],a0[1u+(t474)*6u+1u],a0[1u+(t474)*6u+2u],a0[1u+(t474)*6u+3u],a0[1u+(t474)*6u+4u],a0[1u+(t474)*6u+5u]);}else{
var t476:u32=0u;
var t477:u32=0u;
var t478:u32=0u;
var t479:u32=1065353216u;
var t480:u32=1065353216u;
var t481:u32=0u;
t475=R_Parameter(t476,t477,t478,t479,t480,t481);}
t473=(t475).ink_f_value;
}
var t482:u32=t473;
var t483:u32=t448;
var t484:u32=(t483 * 10u);
var t485:u32=(t484 + t466);
var t486:u32;if(t485<a1[0u]){
t486=a1[1u+(t485)*1u+0u];}else{
t486=0u;}
t465=ink_f32_add(t467,ink_f32_mul(t482,t486));
}
var t487:u32=t465;
var t488:u32=t7;
var t489:u32=t8;
var t490:u32=t9;
var t491:u32=121u;
var t492:u32=t488;
var t493:u32=t489;
var t494:u32=t491;
var t495:u32=(t494 + 10u);
var t496:u32=t493;
var t497:u32;
if ((t496 == t495)) {
t497=t492;
} else {
var t498:u32=t495;
var t499:R_Parameter;if(t498<a0[0u]){
t499=R_Parameter(a0[1u+(t498)*6u+0u],a0[1u+(t498)*6u+1u],a0[1u+(t498)*6u+2u],a0[1u+(t498)*6u+3u],a0[1u+(t498)*6u+4u],a0[1u+(t498)*6u+5u]);}else{
var t500:u32=0u;
var t501:u32=0u;
var t502:u32=0u;
var t503:u32=1065353216u;
var t504:u32=1065353216u;
var t505:u32=0u;
t499=R_Parameter(t500,t501,t502,t503,t504,t505);}
t497=(t499).ink_f_value;
}
var t506:u32=t497;
var t507:u32=t506;
for(var t508=0u;t508<10u;t508++){
var t509:u32=t507;
var t510:u32=t488;
var t511:u32=t489;
var t512:u32=t491;
var t513:u32=(t512 + t508);
var t514:u32=t511;
var t515:u32;
if ((t514 == t513)) {
t515=t510;
} else {
var t516:u32=t513;
var t517:R_Parameter;if(t516<a0[0u]){
t517=R_Parameter(a0[1u+(t516)*6u+0u],a0[1u+(t516)*6u+1u],a0[1u+(t516)*6u+2u],a0[1u+(t516)*6u+3u],a0[1u+(t516)*6u+4u],a0[1u+(t516)*6u+5u]);}else{
var t518:u32=0u;
var t519:u32=0u;
var t520:u32=0u;
var t521:u32=1065353216u;
var t522:u32=1065353216u;
var t523:u32=0u;
t517=R_Parameter(t518,t519,t520,t521,t522,t523);}
t515=(t517).ink_f_value;
}
var t524:u32=t515;
var t525:u32=t490;
var t526:u32=(t525 * 10u);
var t527:u32=(t526 + t508);
var t528:u32;if(t527<a1[0u]){
t528=a1[1u+(t527)*1u+0u];}else{
t528=0u;}
t507=ink_f32_add(t509,ink_f32_mul(t524,t528));
}
var t529:u32=t507;
var t530:u32=t529;
var t531:u32;
if (ink_f32_lt(0u,t530)) {
var t532:u32=t487;
t531=ink_f32_mul(t532,t529);
} else {
t531=0u;
}
t10[5u]=t531;
var t533:u32=t4;
var t534:u32=t5;
var t535:array<u32,6>;
var t536:u32=t533;
var t537:u32=t534;
var t538:u32=132u;
var t539:u32=t536;
var t540:u32=t537;
var t541:u32=t538;
var t542:u32=(t541 + 6u);
var t543:u32=t540;
var t544:u32;
if ((t543 == t542)) {
t544=t539;
} else {
var t545:u32=t542;
var t546:R_Parameter;if(t545<a0[0u]){
t546=R_Parameter(a0[1u+(t545)*6u+0u],a0[1u+(t545)*6u+1u],a0[1u+(t545)*6u+2u],a0[1u+(t545)*6u+3u],a0[1u+(t545)*6u+4u],a0[1u+(t545)*6u+5u]);}else{
var t547:u32=0u;
var t548:u32=0u;
var t549:u32=0u;
var t550:u32=1065353216u;
var t551:u32=1065353216u;
var t552:u32=0u;
t546=R_Parameter(t547,t548,t549,t550,t551,t552);}
t544=(t546).ink_f_value;
}
var t553:u32=t544;
var t554:u32=t553;
for(var t555=0u;t555<6u;t555++){
var t556:u32=t554;
var t557:u32=t536;
var t558:u32=t537;
var t559:u32=t538;
var t560:u32=(t559 + t555);
var t561:u32=t558;
var t562:u32;
if ((t561 == t560)) {
t562=t557;
} else {
var t563:u32=t560;
var t564:R_Parameter;if(t563<a0[0u]){
t564=R_Parameter(a0[1u+(t563)*6u+0u],a0[1u+(t563)*6u+1u],a0[1u+(t563)*6u+2u],a0[1u+(t563)*6u+3u],a0[1u+(t563)*6u+4u],a0[1u+(t563)*6u+5u]);}else{
var t565:u32=0u;
var t566:u32=0u;
var t567:u32=0u;
var t568:u32=1065353216u;
var t569:u32=1065353216u;
var t570:u32=0u;
t564=R_Parameter(t565,t566,t567,t568,t569,t570);}
t562=(t564).ink_f_value;
}
var t571:u32=t562;
var t572:u32=t555;
var t573:u32;if(t572<6u){
t573=t10[t572];}else{
t573=0u;}
t554=ink_f32_add(t556,ink_f32_mul(t571,t573));
}
var t574:u32=t554;
var t575:u32=t533;
var t576:u32=t534;
var t577:u32=139u;
var t578:u32=t575;
var t579:u32=t576;
var t580:u32=t577;
var t581:u32=(t580 + 6u);
var t582:u32=t579;
var t583:u32;
if ((t582 == t581)) {
t583=t578;
} else {
var t584:u32=t581;
var t585:R_Parameter;if(t584<a0[0u]){
t585=R_Parameter(a0[1u+(t584)*6u+0u],a0[1u+(t584)*6u+1u],a0[1u+(t584)*6u+2u],a0[1u+(t584)*6u+3u],a0[1u+(t584)*6u+4u],a0[1u+(t584)*6u+5u]);}else{
var t586:u32=0u;
var t587:u32=0u;
var t588:u32=0u;
var t589:u32=1065353216u;
var t590:u32=1065353216u;
var t591:u32=0u;
t585=R_Parameter(t586,t587,t588,t589,t590,t591);}
t583=(t585).ink_f_value;
}
var t592:u32=t583;
var t593:u32=t592;
for(var t594=0u;t594<6u;t594++){
var t595:u32=t593;
var t596:u32=t575;
var t597:u32=t576;
var t598:u32=t577;
var t599:u32=(t598 + t594);
var t600:u32=t597;
var t601:u32;
if ((t600 == t599)) {
t601=t596;
} else {
var t602:u32=t599;
var t603:R_Parameter;if(t602<a0[0u]){
t603=R_Parameter(a0[1u+(t602)*6u+0u],a0[1u+(t602)*6u+1u],a0[1u+(t602)*6u+2u],a0[1u+(t602)*6u+3u],a0[1u+(t602)*6u+4u],a0[1u+(t602)*6u+5u]);}else{
var t604:u32=0u;
var t605:u32=0u;
var t606:u32=0u;
var t607:u32=1065353216u;
var t608:u32=1065353216u;
var t609:u32=0u;
t603=R_Parameter(t604,t605,t606,t607,t608,t609);}
t601=(t603).ink_f_value;
}
var t610:u32=t601;
var t611:u32=t594;
var t612:u32;if(t611<6u){
t612=t10[t611];}else{
t612=0u;}
t593=ink_f32_add(t595,ink_f32_mul(t610,t612));
}
var t613:u32=t593;
var t614:u32=t613;
var t615:u32;
if (ink_f32_lt(0u,t614)) {
var t616:u32=t574;
t615=ink_f32_mul(t616,t613);
} else {
t615=0u;
}
t535[0u]=t615;
var t617:u32=t533;
var t618:u32=t534;
var t619:u32=146u;
var t620:u32=t617;
var t621:u32=t618;
var t622:u32=t619;
var t623:u32=(t622 + 6u);
var t624:u32=t621;
var t625:u32;
if ((t624 == t623)) {
t625=t620;
} else {
var t626:u32=t623;
var t627:R_Parameter;if(t626<a0[0u]){
t627=R_Parameter(a0[1u+(t626)*6u+0u],a0[1u+(t626)*6u+1u],a0[1u+(t626)*6u+2u],a0[1u+(t626)*6u+3u],a0[1u+(t626)*6u+4u],a0[1u+(t626)*6u+5u]);}else{
var t628:u32=0u;
var t629:u32=0u;
var t630:u32=0u;
var t631:u32=1065353216u;
var t632:u32=1065353216u;
var t633:u32=0u;
t627=R_Parameter(t628,t629,t630,t631,t632,t633);}
t625=(t627).ink_f_value;
}
var t634:u32=t625;
var t635:u32=t634;
for(var t636=0u;t636<6u;t636++){
var t637:u32=t635;
var t638:u32=t617;
var t639:u32=t618;
var t640:u32=t619;
var t641:u32=(t640 + t636);
var t642:u32=t639;
var t643:u32;
if ((t642 == t641)) {
t643=t638;
} else {
var t644:u32=t641;
var t645:R_Parameter;if(t644<a0[0u]){
t645=R_Parameter(a0[1u+(t644)*6u+0u],a0[1u+(t644)*6u+1u],a0[1u+(t644)*6u+2u],a0[1u+(t644)*6u+3u],a0[1u+(t644)*6u+4u],a0[1u+(t644)*6u+5u]);}else{
var t646:u32=0u;
var t647:u32=0u;
var t648:u32=0u;
var t649:u32=1065353216u;
var t650:u32=1065353216u;
var t651:u32=0u;
t645=R_Parameter(t646,t647,t648,t649,t650,t651);}
t643=(t645).ink_f_value;
}
var t652:u32=t643;
var t653:u32=t636;
var t654:u32;if(t653<6u){
t654=t10[t653];}else{
t654=0u;}
t635=ink_f32_add(t637,ink_f32_mul(t652,t654));
}
var t655:u32=t635;
var t656:u32=t533;
var t657:u32=t534;
var t658:u32=153u;
var t659:u32=t656;
var t660:u32=t657;
var t661:u32=t658;
var t662:u32=(t661 + 6u);
var t663:u32=t660;
var t664:u32;
if ((t663 == t662)) {
t664=t659;
} else {
var t665:u32=t662;
var t666:R_Parameter;if(t665<a0[0u]){
t666=R_Parameter(a0[1u+(t665)*6u+0u],a0[1u+(t665)*6u+1u],a0[1u+(t665)*6u+2u],a0[1u+(t665)*6u+3u],a0[1u+(t665)*6u+4u],a0[1u+(t665)*6u+5u]);}else{
var t667:u32=0u;
var t668:u32=0u;
var t669:u32=0u;
var t670:u32=1065353216u;
var t671:u32=1065353216u;
var t672:u32=0u;
t666=R_Parameter(t667,t668,t669,t670,t671,t672);}
t664=(t666).ink_f_value;
}
var t673:u32=t664;
var t674:u32=t673;
for(var t675=0u;t675<6u;t675++){
var t676:u32=t674;
var t677:u32=t656;
var t678:u32=t657;
var t679:u32=t658;
var t680:u32=(t679 + t675);
var t681:u32=t678;
var t682:u32;
if ((t681 == t680)) {
t682=t677;
} else {
var t683:u32=t680;
var t684:R_Parameter;if(t683<a0[0u]){
t684=R_Parameter(a0[1u+(t683)*6u+0u],a0[1u+(t683)*6u+1u],a0[1u+(t683)*6u+2u],a0[1u+(t683)*6u+3u],a0[1u+(t683)*6u+4u],a0[1u+(t683)*6u+5u]);}else{
var t685:u32=0u;
var t686:u32=0u;
var t687:u32=0u;
var t688:u32=1065353216u;
var t689:u32=1065353216u;
var t690:u32=0u;
t684=R_Parameter(t685,t686,t687,t688,t689,t690);}
t682=(t684).ink_f_value;
}
var t691:u32=t682;
var t692:u32=t675;
var t693:u32;if(t692<6u){
t693=t10[t692];}else{
t693=0u;}
t674=ink_f32_add(t676,ink_f32_mul(t691,t693));
}
var t694:u32=t674;
var t695:u32=t694;
var t696:u32;
if (ink_f32_lt(0u,t695)) {
var t697:u32=t655;
t696=ink_f32_mul(t697,t694);
} else {
t696=0u;
}
t535[1u]=t696;
var t698:u32=t533;
var t699:u32=t534;
var t700:u32=160u;
var t701:u32=t698;
var t702:u32=t699;
var t703:u32=t700;
var t704:u32=(t703 + 6u);
var t705:u32=t702;
var t706:u32;
if ((t705 == t704)) {
t706=t701;
} else {
var t707:u32=t704;
var t708:R_Parameter;if(t707<a0[0u]){
t708=R_Parameter(a0[1u+(t707)*6u+0u],a0[1u+(t707)*6u+1u],a0[1u+(t707)*6u+2u],a0[1u+(t707)*6u+3u],a0[1u+(t707)*6u+4u],a0[1u+(t707)*6u+5u]);}else{
var t709:u32=0u;
var t710:u32=0u;
var t711:u32=0u;
var t712:u32=1065353216u;
var t713:u32=1065353216u;
var t714:u32=0u;
t708=R_Parameter(t709,t710,t711,t712,t713,t714);}
t706=(t708).ink_f_value;
}
var t715:u32=t706;
var t716:u32=t715;
for(var t717=0u;t717<6u;t717++){
var t718:u32=t716;
var t719:u32=t698;
var t720:u32=t699;
var t721:u32=t700;
var t722:u32=(t721 + t717);
var t723:u32=t720;
var t724:u32;
if ((t723 == t722)) {
t724=t719;
} else {
var t725:u32=t722;
var t726:R_Parameter;if(t725<a0[0u]){
t726=R_Parameter(a0[1u+(t725)*6u+0u],a0[1u+(t725)*6u+1u],a0[1u+(t725)*6u+2u],a0[1u+(t725)*6u+3u],a0[1u+(t725)*6u+4u],a0[1u+(t725)*6u+5u]);}else{
var t727:u32=0u;
var t728:u32=0u;
var t729:u32=0u;
var t730:u32=1065353216u;
var t731:u32=1065353216u;
var t732:u32=0u;
t726=R_Parameter(t727,t728,t729,t730,t731,t732);}
t724=(t726).ink_f_value;
}
var t733:u32=t724;
var t734:u32=t717;
var t735:u32;if(t734<6u){
t735=t10[t734];}else{
t735=0u;}
t716=ink_f32_add(t718,ink_f32_mul(t733,t735));
}
var t736:u32=t716;
var t737:u32=t533;
var t738:u32=t534;
var t739:u32=167u;
var t740:u32=t737;
var t741:u32=t738;
var t742:u32=t739;
var t743:u32=(t742 + 6u);
var t744:u32=t741;
var t745:u32;
if ((t744 == t743)) {
t745=t740;
} else {
var t746:u32=t743;
var t747:R_Parameter;if(t746<a0[0u]){
t747=R_Parameter(a0[1u+(t746)*6u+0u],a0[1u+(t746)*6u+1u],a0[1u+(t746)*6u+2u],a0[1u+(t746)*6u+3u],a0[1u+(t746)*6u+4u],a0[1u+(t746)*6u+5u]);}else{
var t748:u32=0u;
var t749:u32=0u;
var t750:u32=0u;
var t751:u32=1065353216u;
var t752:u32=1065353216u;
var t753:u32=0u;
t747=R_Parameter(t748,t749,t750,t751,t752,t753);}
t745=(t747).ink_f_value;
}
var t754:u32=t745;
var t755:u32=t754;
for(var t756=0u;t756<6u;t756++){
var t757:u32=t755;
var t758:u32=t737;
var t759:u32=t738;
var t760:u32=t739;
var t761:u32=(t760 + t756);
var t762:u32=t759;
var t763:u32;
if ((t762 == t761)) {
t763=t758;
} else {
var t764:u32=t761;
var t765:R_Parameter;if(t764<a0[0u]){
t765=R_Parameter(a0[1u+(t764)*6u+0u],a0[1u+(t764)*6u+1u],a0[1u+(t764)*6u+2u],a0[1u+(t764)*6u+3u],a0[1u+(t764)*6u+4u],a0[1u+(t764)*6u+5u]);}else{
var t766:u32=0u;
var t767:u32=0u;
var t768:u32=0u;
var t769:u32=1065353216u;
var t770:u32=1065353216u;
var t771:u32=0u;
t765=R_Parameter(t766,t767,t768,t769,t770,t771);}
t763=(t765).ink_f_value;
}
var t772:u32=t763;
var t773:u32=t756;
var t774:u32;if(t773<6u){
t774=t10[t773];}else{
t774=0u;}
t755=ink_f32_add(t757,ink_f32_mul(t772,t774));
}
var t775:u32=t755;
var t776:u32=t775;
var t777:u32;
if (ink_f32_lt(0u,t776)) {
var t778:u32=t736;
t777=ink_f32_mul(t778,t775);
} else {
t777=0u;
}
t535[2u]=t777;
var t779:u32=t533;
var t780:u32=t534;
var t781:u32=174u;
var t782:u32=t779;
var t783:u32=t780;
var t784:u32=t781;
var t785:u32=(t784 + 6u);
var t786:u32=t783;
var t787:u32;
if ((t786 == t785)) {
t787=t782;
} else {
var t788:u32=t785;
var t789:R_Parameter;if(t788<a0[0u]){
t789=R_Parameter(a0[1u+(t788)*6u+0u],a0[1u+(t788)*6u+1u],a0[1u+(t788)*6u+2u],a0[1u+(t788)*6u+3u],a0[1u+(t788)*6u+4u],a0[1u+(t788)*6u+5u]);}else{
var t790:u32=0u;
var t791:u32=0u;
var t792:u32=0u;
var t793:u32=1065353216u;
var t794:u32=1065353216u;
var t795:u32=0u;
t789=R_Parameter(t790,t791,t792,t793,t794,t795);}
t787=(t789).ink_f_value;
}
var t796:u32=t787;
var t797:u32=t796;
for(var t798=0u;t798<6u;t798++){
var t799:u32=t797;
var t800:u32=t779;
var t801:u32=t780;
var t802:u32=t781;
var t803:u32=(t802 + t798);
var t804:u32=t801;
var t805:u32;
if ((t804 == t803)) {
t805=t800;
} else {
var t806:u32=t803;
var t807:R_Parameter;if(t806<a0[0u]){
t807=R_Parameter(a0[1u+(t806)*6u+0u],a0[1u+(t806)*6u+1u],a0[1u+(t806)*6u+2u],a0[1u+(t806)*6u+3u],a0[1u+(t806)*6u+4u],a0[1u+(t806)*6u+5u]);}else{
var t808:u32=0u;
var t809:u32=0u;
var t810:u32=0u;
var t811:u32=1065353216u;
var t812:u32=1065353216u;
var t813:u32=0u;
t807=R_Parameter(t808,t809,t810,t811,t812,t813);}
t805=(t807).ink_f_value;
}
var t814:u32=t805;
var t815:u32=t798;
var t816:u32;if(t815<6u){
t816=t10[t815];}else{
t816=0u;}
t797=ink_f32_add(t799,ink_f32_mul(t814,t816));
}
var t817:u32=t797;
var t818:u32=t533;
var t819:u32=t534;
var t820:u32=181u;
var t821:u32=t818;
var t822:u32=t819;
var t823:u32=t820;
var t824:u32=(t823 + 6u);
var t825:u32=t822;
var t826:u32;
if ((t825 == t824)) {
t826=t821;
} else {
var t827:u32=t824;
var t828:R_Parameter;if(t827<a0[0u]){
t828=R_Parameter(a0[1u+(t827)*6u+0u],a0[1u+(t827)*6u+1u],a0[1u+(t827)*6u+2u],a0[1u+(t827)*6u+3u],a0[1u+(t827)*6u+4u],a0[1u+(t827)*6u+5u]);}else{
var t829:u32=0u;
var t830:u32=0u;
var t831:u32=0u;
var t832:u32=1065353216u;
var t833:u32=1065353216u;
var t834:u32=0u;
t828=R_Parameter(t829,t830,t831,t832,t833,t834);}
t826=(t828).ink_f_value;
}
var t835:u32=t826;
var t836:u32=t835;
for(var t837=0u;t837<6u;t837++){
var t838:u32=t836;
var t839:u32=t818;
var t840:u32=t819;
var t841:u32=t820;
var t842:u32=(t841 + t837);
var t843:u32=t840;
var t844:u32;
if ((t843 == t842)) {
t844=t839;
} else {
var t845:u32=t842;
var t846:R_Parameter;if(t845<a0[0u]){
t846=R_Parameter(a0[1u+(t845)*6u+0u],a0[1u+(t845)*6u+1u],a0[1u+(t845)*6u+2u],a0[1u+(t845)*6u+3u],a0[1u+(t845)*6u+4u],a0[1u+(t845)*6u+5u]);}else{
var t847:u32=0u;
var t848:u32=0u;
var t849:u32=0u;
var t850:u32=1065353216u;
var t851:u32=1065353216u;
var t852:u32=0u;
t846=R_Parameter(t847,t848,t849,t850,t851,t852);}
t844=(t846).ink_f_value;
}
var t853:u32=t844;
var t854:u32=t837;
var t855:u32;if(t854<6u){
t855=t10[t854];}else{
t855=0u;}
t836=ink_f32_add(t838,ink_f32_mul(t853,t855));
}
var t856:u32=t836;
var t857:u32=t856;
var t858:u32;
if (ink_f32_lt(0u,t857)) {
var t859:u32=t817;
t858=ink_f32_mul(t859,t856);
} else {
t858=0u;
}
t535[3u]=t858;
var t860:u32=t533;
var t861:u32=t534;
var t862:u32=188u;
var t863:u32=t860;
var t864:u32=t861;
var t865:u32=t862;
var t866:u32=(t865 + 6u);
var t867:u32=t864;
var t868:u32;
if ((t867 == t866)) {
t868=t863;
} else {
var t869:u32=t866;
var t870:R_Parameter;if(t869<a0[0u]){
t870=R_Parameter(a0[1u+(t869)*6u+0u],a0[1u+(t869)*6u+1u],a0[1u+(t869)*6u+2u],a0[1u+(t869)*6u+3u],a0[1u+(t869)*6u+4u],a0[1u+(t869)*6u+5u]);}else{
var t871:u32=0u;
var t872:u32=0u;
var t873:u32=0u;
var t874:u32=1065353216u;
var t875:u32=1065353216u;
var t876:u32=0u;
t870=R_Parameter(t871,t872,t873,t874,t875,t876);}
t868=(t870).ink_f_value;
}
var t877:u32=t868;
var t878:u32=t877;
for(var t879=0u;t879<6u;t879++){
var t880:u32=t878;
var t881:u32=t860;
var t882:u32=t861;
var t883:u32=t862;
var t884:u32=(t883 + t879);
var t885:u32=t882;
var t886:u32;
if ((t885 == t884)) {
t886=t881;
} else {
var t887:u32=t884;
var t888:R_Parameter;if(t887<a0[0u]){
t888=R_Parameter(a0[1u+(t887)*6u+0u],a0[1u+(t887)*6u+1u],a0[1u+(t887)*6u+2u],a0[1u+(t887)*6u+3u],a0[1u+(t887)*6u+4u],a0[1u+(t887)*6u+5u]);}else{
var t889:u32=0u;
var t890:u32=0u;
var t891:u32=0u;
var t892:u32=1065353216u;
var t893:u32=1065353216u;
var t894:u32=0u;
t888=R_Parameter(t889,t890,t891,t892,t893,t894);}
t886=(t888).ink_f_value;
}
var t895:u32=t886;
var t896:u32=t879;
var t897:u32;if(t896<6u){
t897=t10[t896];}else{
t897=0u;}
t878=ink_f32_add(t880,ink_f32_mul(t895,t897));
}
var t898:u32=t878;
var t899:u32=t533;
var t900:u32=t534;
var t901:u32=195u;
var t902:u32=t899;
var t903:u32=t900;
var t904:u32=t901;
var t905:u32=(t904 + 6u);
var t906:u32=t903;
var t907:u32;
if ((t906 == t905)) {
t907=t902;
} else {
var t908:u32=t905;
var t909:R_Parameter;if(t908<a0[0u]){
t909=R_Parameter(a0[1u+(t908)*6u+0u],a0[1u+(t908)*6u+1u],a0[1u+(t908)*6u+2u],a0[1u+(t908)*6u+3u],a0[1u+(t908)*6u+4u],a0[1u+(t908)*6u+5u]);}else{
var t910:u32=0u;
var t911:u32=0u;
var t912:u32=0u;
var t913:u32=1065353216u;
var t914:u32=1065353216u;
var t915:u32=0u;
t909=R_Parameter(t910,t911,t912,t913,t914,t915);}
t907=(t909).ink_f_value;
}
var t916:u32=t907;
var t917:u32=t916;
for(var t918=0u;t918<6u;t918++){
var t919:u32=t917;
var t920:u32=t899;
var t921:u32=t900;
var t922:u32=t901;
var t923:u32=(t922 + t918);
var t924:u32=t921;
var t925:u32;
if ((t924 == t923)) {
t925=t920;
} else {
var t926:u32=t923;
var t927:R_Parameter;if(t926<a0[0u]){
t927=R_Parameter(a0[1u+(t926)*6u+0u],a0[1u+(t926)*6u+1u],a0[1u+(t926)*6u+2u],a0[1u+(t926)*6u+3u],a0[1u+(t926)*6u+4u],a0[1u+(t926)*6u+5u]);}else{
var t928:u32=0u;
var t929:u32=0u;
var t930:u32=0u;
var t931:u32=1065353216u;
var t932:u32=1065353216u;
var t933:u32=0u;
t927=R_Parameter(t928,t929,t930,t931,t932,t933);}
t925=(t927).ink_f_value;
}
var t934:u32=t925;
var t935:u32=t918;
var t936:u32;if(t935<6u){
t936=t10[t935];}else{
t936=0u;}
t917=ink_f32_add(t919,ink_f32_mul(t934,t936));
}
var t937:u32=t917;
var t938:u32=t937;
var t939:u32;
if (ink_f32_lt(0u,t938)) {
var t940:u32=t898;
t939=ink_f32_mul(t940,t937);
} else {
t939=0u;
}
t535[4u]=t939;
var t941:u32=t533;
var t942:u32=t534;
var t943:u32=202u;
var t944:u32=t941;
var t945:u32=t942;
var t946:u32=t943;
var t947:u32=(t946 + 6u);
var t948:u32=t945;
var t949:u32;
if ((t948 == t947)) {
t949=t944;
} else {
var t950:u32=t947;
var t951:R_Parameter;if(t950<a0[0u]){
t951=R_Parameter(a0[1u+(t950)*6u+0u],a0[1u+(t950)*6u+1u],a0[1u+(t950)*6u+2u],a0[1u+(t950)*6u+3u],a0[1u+(t950)*6u+4u],a0[1u+(t950)*6u+5u]);}else{
var t952:u32=0u;
var t953:u32=0u;
var t954:u32=0u;
var t955:u32=1065353216u;
var t956:u32=1065353216u;
var t957:u32=0u;
t951=R_Parameter(t952,t953,t954,t955,t956,t957);}
t949=(t951).ink_f_value;
}
var t958:u32=t949;
var t959:u32=t958;
for(var t960=0u;t960<6u;t960++){
var t961:u32=t959;
var t962:u32=t941;
var t963:u32=t942;
var t964:u32=t943;
var t965:u32=(t964 + t960);
var t966:u32=t963;
var t967:u32;
if ((t966 == t965)) {
t967=t962;
} else {
var t968:u32=t965;
var t969:R_Parameter;if(t968<a0[0u]){
t969=R_Parameter(a0[1u+(t968)*6u+0u],a0[1u+(t968)*6u+1u],a0[1u+(t968)*6u+2u],a0[1u+(t968)*6u+3u],a0[1u+(t968)*6u+4u],a0[1u+(t968)*6u+5u]);}else{
var t970:u32=0u;
var t971:u32=0u;
var t972:u32=0u;
var t973:u32=1065353216u;
var t974:u32=1065353216u;
var t975:u32=0u;
t969=R_Parameter(t970,t971,t972,t973,t974,t975);}
t967=(t969).ink_f_value;
}
var t976:u32=t967;
var t977:u32=t960;
var t978:u32;if(t977<6u){
t978=t10[t977];}else{
t978=0u;}
t959=ink_f32_add(t961,ink_f32_mul(t976,t978));
}
var t979:u32=t959;
var t980:u32=t533;
var t981:u32=t534;
var t982:u32=209u;
var t983:u32=t980;
var t984:u32=t981;
var t985:u32=t982;
var t986:u32=(t985 + 6u);
var t987:u32=t984;
var t988:u32;
if ((t987 == t986)) {
t988=t983;
} else {
var t989:u32=t986;
var t990:R_Parameter;if(t989<a0[0u]){
t990=R_Parameter(a0[1u+(t989)*6u+0u],a0[1u+(t989)*6u+1u],a0[1u+(t989)*6u+2u],a0[1u+(t989)*6u+3u],a0[1u+(t989)*6u+4u],a0[1u+(t989)*6u+5u]);}else{
var t991:u32=0u;
var t992:u32=0u;
var t993:u32=0u;
var t994:u32=1065353216u;
var t995:u32=1065353216u;
var t996:u32=0u;
t990=R_Parameter(t991,t992,t993,t994,t995,t996);}
t988=(t990).ink_f_value;
}
var t997:u32=t988;
var t998:u32=t997;
for(var t999=0u;t999<6u;t999++){
var t1000:u32=t998;
var t1001:u32=t980;
var t1002:u32=t981;
var t1003:u32=t982;
var t1004:u32=(t1003 + t999);
var t1005:u32=t1002;
var t1006:u32;
if ((t1005 == t1004)) {
t1006=t1001;
} else {
var t1007:u32=t1004;
var t1008:R_Parameter;if(t1007<a0[0u]){
t1008=R_Parameter(a0[1u+(t1007)*6u+0u],a0[1u+(t1007)*6u+1u],a0[1u+(t1007)*6u+2u],a0[1u+(t1007)*6u+3u],a0[1u+(t1007)*6u+4u],a0[1u+(t1007)*6u+5u]);}else{
var t1009:u32=0u;
var t1010:u32=0u;
var t1011:u32=0u;
var t1012:u32=1065353216u;
var t1013:u32=1065353216u;
var t1014:u32=0u;
t1008=R_Parameter(t1009,t1010,t1011,t1012,t1013,t1014);}
t1006=(t1008).ink_f_value;
}
var t1015:u32=t1006;
var t1016:u32=t999;
var t1017:u32;if(t1016<6u){
t1017=t10[t1016];}else{
t1017=0u;}
t998=ink_f32_add(t1000,ink_f32_mul(t1015,t1017));
}
var t1018:u32=t998;
var t1019:u32=t1018;
var t1020:u32;
if (ink_f32_lt(0u,t1019)) {
var t1021:u32=t979;
t1020=ink_f32_mul(t1021,t1018);
} else {
t1020=0u;
}
t535[5u]=t1020;
var t1022:array<u32,4>;
var t1023:u32=t4;
var t1024:u32=t5;
var t1025:u32=216u;
var t1026:u32=t1023;
var t1027:u32=t1024;
var t1028:u32=t1025;
var t1029:u32=(t1028 + 6u);
var t1030:u32=t1027;
var t1031:u32;
if ((t1030 == t1029)) {
t1031=t1026;
} else {
var t1032:u32=t1029;
var t1033:R_Parameter;if(t1032<a0[0u]){
t1033=R_Parameter(a0[1u+(t1032)*6u+0u],a0[1u+(t1032)*6u+1u],a0[1u+(t1032)*6u+2u],a0[1u+(t1032)*6u+3u],a0[1u+(t1032)*6u+4u],a0[1u+(t1032)*6u+5u]);}else{
var t1034:u32=0u;
var t1035:u32=0u;
var t1036:u32=0u;
var t1037:u32=1065353216u;
var t1038:u32=1065353216u;
var t1039:u32=0u;
t1033=R_Parameter(t1034,t1035,t1036,t1037,t1038,t1039);}
t1031=(t1033).ink_f_value;
}
var t1040:u32=t1031;
var t1041:u32=t1040;
for(var t1042=0u;t1042<6u;t1042++){
var t1043:u32=t1041;
var t1044:u32=t1023;
var t1045:u32=t1024;
var t1046:u32=t1025;
var t1047:u32=(t1046 + t1042);
var t1048:u32=t1045;
var t1049:u32;
if ((t1048 == t1047)) {
t1049=t1044;
} else {
var t1050:u32=t1047;
var t1051:R_Parameter;if(t1050<a0[0u]){
t1051=R_Parameter(a0[1u+(t1050)*6u+0u],a0[1u+(t1050)*6u+1u],a0[1u+(t1050)*6u+2u],a0[1u+(t1050)*6u+3u],a0[1u+(t1050)*6u+4u],a0[1u+(t1050)*6u+5u]);}else{
var t1052:u32=0u;
var t1053:u32=0u;
var t1054:u32=0u;
var t1055:u32=1065353216u;
var t1056:u32=1065353216u;
var t1057:u32=0u;
t1051=R_Parameter(t1052,t1053,t1054,t1055,t1056,t1057);}
t1049=(t1051).ink_f_value;
}
var t1058:u32=t1049;
var t1059:u32=t1042;
var t1060:u32;if(t1059<6u){
t1060=t535[t1059];}else{
t1060=0u;}
t1041=ink_f32_add(t1043,ink_f32_mul(t1058,t1060));
}
t1022[0u]=t1041;
var t1061:u32=t4;
var t1062:u32=t5;
var t1063:u32=223u;
var t1064:u32=t1061;
var t1065:u32=t1062;
var t1066:u32=t1063;
var t1067:u32=(t1066 + 6u);
var t1068:u32=t1065;
var t1069:u32;
if ((t1068 == t1067)) {
t1069=t1064;
} else {
var t1070:u32=t1067;
var t1071:R_Parameter;if(t1070<a0[0u]){
t1071=R_Parameter(a0[1u+(t1070)*6u+0u],a0[1u+(t1070)*6u+1u],a0[1u+(t1070)*6u+2u],a0[1u+(t1070)*6u+3u],a0[1u+(t1070)*6u+4u],a0[1u+(t1070)*6u+5u]);}else{
var t1072:u32=0u;
var t1073:u32=0u;
var t1074:u32=0u;
var t1075:u32=1065353216u;
var t1076:u32=1065353216u;
var t1077:u32=0u;
t1071=R_Parameter(t1072,t1073,t1074,t1075,t1076,t1077);}
t1069=(t1071).ink_f_value;
}
var t1078:u32=t1069;
var t1079:u32=t1078;
for(var t1080=0u;t1080<6u;t1080++){
var t1081:u32=t1079;
var t1082:u32=t1061;
var t1083:u32=t1062;
var t1084:u32=t1063;
var t1085:u32=(t1084 + t1080);
var t1086:u32=t1083;
var t1087:u32;
if ((t1086 == t1085)) {
t1087=t1082;
} else {
var t1088:u32=t1085;
var t1089:R_Parameter;if(t1088<a0[0u]){
t1089=R_Parameter(a0[1u+(t1088)*6u+0u],a0[1u+(t1088)*6u+1u],a0[1u+(t1088)*6u+2u],a0[1u+(t1088)*6u+3u],a0[1u+(t1088)*6u+4u],a0[1u+(t1088)*6u+5u]);}else{
var t1090:u32=0u;
var t1091:u32=0u;
var t1092:u32=0u;
var t1093:u32=1065353216u;
var t1094:u32=1065353216u;
var t1095:u32=0u;
t1089=R_Parameter(t1090,t1091,t1092,t1093,t1094,t1095);}
t1087=(t1089).ink_f_value;
}
var t1096:u32=t1087;
var t1097:u32=t1080;
var t1098:u32;if(t1097<6u){
t1098=t535[t1097];}else{
t1098=0u;}
t1079=ink_f32_add(t1081,ink_f32_mul(t1096,t1098));
}
t1022[1u]=t1079;
var t1099:u32=t4;
var t1100:u32=t5;
var t1101:u32=230u;
var t1102:u32=t1099;
var t1103:u32=t1100;
var t1104:u32=t1101;
var t1105:u32=(t1104 + 6u);
var t1106:u32=t1103;
var t1107:u32;
if ((t1106 == t1105)) {
t1107=t1102;
} else {
var t1108:u32=t1105;
var t1109:R_Parameter;if(t1108<a0[0u]){
t1109=R_Parameter(a0[1u+(t1108)*6u+0u],a0[1u+(t1108)*6u+1u],a0[1u+(t1108)*6u+2u],a0[1u+(t1108)*6u+3u],a0[1u+(t1108)*6u+4u],a0[1u+(t1108)*6u+5u]);}else{
var t1110:u32=0u;
var t1111:u32=0u;
var t1112:u32=0u;
var t1113:u32=1065353216u;
var t1114:u32=1065353216u;
var t1115:u32=0u;
t1109=R_Parameter(t1110,t1111,t1112,t1113,t1114,t1115);}
t1107=(t1109).ink_f_value;
}
var t1116:u32=t1107;
var t1117:u32=t1116;
for(var t1118=0u;t1118<6u;t1118++){
var t1119:u32=t1117;
var t1120:u32=t1099;
var t1121:u32=t1100;
var t1122:u32=t1101;
var t1123:u32=(t1122 + t1118);
var t1124:u32=t1121;
var t1125:u32;
if ((t1124 == t1123)) {
t1125=t1120;
} else {
var t1126:u32=t1123;
var t1127:R_Parameter;if(t1126<a0[0u]){
t1127=R_Parameter(a0[1u+(t1126)*6u+0u],a0[1u+(t1126)*6u+1u],a0[1u+(t1126)*6u+2u],a0[1u+(t1126)*6u+3u],a0[1u+(t1126)*6u+4u],a0[1u+(t1126)*6u+5u]);}else{
var t1128:u32=0u;
var t1129:u32=0u;
var t1130:u32=0u;
var t1131:u32=1065353216u;
var t1132:u32=1065353216u;
var t1133:u32=0u;
t1127=R_Parameter(t1128,t1129,t1130,t1131,t1132,t1133);}
t1125=(t1127).ink_f_value;
}
var t1134:u32=t1125;
var t1135:u32=t1118;
var t1136:u32;if(t1135<6u){
t1136=t535[t1135];}else{
t1136=0u;}
t1117=ink_f32_add(t1119,ink_f32_mul(t1134,t1136));
}
t1022[2u]=t1117;
var t1137:u32=t4;
var t1138:u32=t5;
var t1139:u32=237u;
var t1140:u32=t1137;
var t1141:u32=t1138;
var t1142:u32=t1139;
var t1143:u32=(t1142 + 6u);
var t1144:u32=t1141;
var t1145:u32;
if ((t1144 == t1143)) {
t1145=t1140;
} else {
var t1146:u32=t1143;
var t1147:R_Parameter;if(t1146<a0[0u]){
t1147=R_Parameter(a0[1u+(t1146)*6u+0u],a0[1u+(t1146)*6u+1u],a0[1u+(t1146)*6u+2u],a0[1u+(t1146)*6u+3u],a0[1u+(t1146)*6u+4u],a0[1u+(t1146)*6u+5u]);}else{
var t1148:u32=0u;
var t1149:u32=0u;
var t1150:u32=0u;
var t1151:u32=1065353216u;
var t1152:u32=1065353216u;
var t1153:u32=0u;
t1147=R_Parameter(t1148,t1149,t1150,t1151,t1152,t1153);}
t1145=(t1147).ink_f_value;
}
var t1154:u32=t1145;
var t1155:u32=t1154;
for(var t1156=0u;t1156<6u;t1156++){
var t1157:u32=t1155;
var t1158:u32=t1137;
var t1159:u32=t1138;
var t1160:u32=t1139;
var t1161:u32=(t1160 + t1156);
var t1162:u32=t1159;
var t1163:u32;
if ((t1162 == t1161)) {
t1163=t1158;
} else {
var t1164:u32=t1161;
var t1165:R_Parameter;if(t1164<a0[0u]){
t1165=R_Parameter(a0[1u+(t1164)*6u+0u],a0[1u+(t1164)*6u+1u],a0[1u+(t1164)*6u+2u],a0[1u+(t1164)*6u+3u],a0[1u+(t1164)*6u+4u],a0[1u+(t1164)*6u+5u]);}else{
var t1166:u32=0u;
var t1167:u32=0u;
var t1168:u32=0u;
var t1169:u32=1065353216u;
var t1170:u32=1065353216u;
var t1171:u32=0u;
t1165=R_Parameter(t1166,t1167,t1168,t1169,t1170,t1171);}
t1163=(t1165).ink_f_value;
}
var t1172:u32=t1163;
var t1173:u32=t1156;
var t1174:u32;if(t1173<6u){
t1174=t535[t1173];}else{
t1174=0u;}
t1155=ink_f32_add(t1157,ink_f32_mul(t1172,t1174));
}
t1022[3u]=t1155;
var t1175:u32=0u;
for(var t1176=0u;t1176<4u;t1176++){
var t1177:u32=t1175;
var t1178:u32=t1176;
var t1179:u32;if(t1178<4u){
t1179=t1022[t1178];}else{
t1179=0u;}
var t1180:u32=t1179;
var t1181:u32=t3;
var t1182:u32=(t1181 * 4u);
var t1183:u32=(t1182 + t1176);
var t1184:u32;if(t1183<a2[0u]){
t1184=a2[1u+(t1183)*1u+0u];}else{
t1184=0u;}
var t1185:u32=t1184;
var t1186:u32=t1180;
var t1187:u32=ink_f32_sub(t1186,t1185);
var t1188:u32=t1187;
t1175=ink_f32_add(t1177,ink_f32_mul(t1188,t1187));
}
var t1189:u32=t1175;
var t1190:u32=ink_f32_div(t1189,1082130432u);
output[1u+i*1u+0u]=bitcast<u32>(t1190);


}