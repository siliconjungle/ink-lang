// Exact wrapping u64 over two storage lanes. No floating point intermediates.
struct InkU64 {lo:u32,hi:u32,}
struct InkDiv64 {quotient:InkU64,remainder:InkU64,}
fn ink_u64_shl(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64(a.lo<<k,(a.hi<<k)|(a.lo>>(32u-k)));}return InkU64(0u,a.lo<<(k-32u));}
fn ink_u64_shr(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64((a.lo>>k)|(a.hi<<(32u-k)),a.hi>>k);}return InkU64(a.hi>>(k-32u),0u);}
fn ink_u64_rol(a:InkU64,count:u32)->InkU64{let k=count&63u;let l=ink_u64_shl(a,k);let r=ink_u64_shr(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_ror(a:InkU64,count:u32)->InkU64{let k=count&63u;let r=ink_u64_shr(a,k);let l=ink_u64_shl(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_eq(a:InkU64,b:InkU64)->bool{return a.lo==b.lo&&a.hi==b.hi;}
fn ink_u64_lt(a:InkU64,b:InkU64)->bool{return a.hi<b.hi||(a.hi==b.hi&&a.lo<b.lo);}
fn ink_u64_add(a:InkU64,b:InkU64)->InkU64{let lo=a.lo+b.lo;return InkU64(lo,a.hi+b.hi+select(0u,1u,lo<a.lo));}
fn ink_u64_sub(a:InkU64,b:InkU64)->InkU64{return InkU64(a.lo-b.lo,a.hi-b.hi-select(0u,1u,a.lo<b.lo));}
fn ink_u64_mul(a:InkU64,b:InkU64)->InkU64{let al=a.lo&65535u;let ah=a.lo>>16u;let bl=b.lo&65535u;let bh=b.lo>>16u;let p=al*bl;let x=ah*bl;let y=al*bh;let mid=(p>>16u)+(x&65535u)+(y&65535u);let high=ah*bh+(x>>16u)+(y>>16u)+(mid>>16u);return InkU64((mid<<16u)|(p&65535u),high+a.lo*b.hi+a.hi*b.lo);}
fn ink_u64_div(a:InkU64,b:InkU64)->InkDiv64{var q=InkU64(0u,0u);var r=InkU64(0u,0u);var cursor=64u;loop{if(cursor==0u){break;}cursor--;var bit=0u;if(cursor>=32u){bit=(a.hi>>(cursor-32u))&1u;}else{bit=(a.lo>>cursor)&1u;}let overflow=r.hi>>31u;r=InkU64((r.lo<<1u)|bit,(r.hi<<1u)|(r.lo>>31u));if(overflow!=0u||!ink_u64_lt(r,b)){r=ink_u64_sub(r,b);if(cursor>=32u){q.hi|=1u<<(cursor-32u);}else{q.lo|=1u<<cursor;}}}return InkDiv64(q,r);}
// Binary32 evaluated with integer lanes: round-to-nearest, ties-to-even,
// gradual underflow, signed zero and canonical arithmetic NaN.
fn ink_f32_nan(x:u32)->bool{return (x&0x7fffffffu)>0x7f800000u;}
fn ink_f32_eq(a:u32,b:u32)->bool{return !ink_f32_nan(a)&&!ink_f32_nan(b)&&(a==b||((a|b)&0x7fffffffu)==0u);}
fn ink_f32_lt(a:u32,b:u32)->bool{
 if(ink_f32_nan(a)||ink_f32_nan(b)||ink_f32_eq(a,b)){return false;}
 if((a^b)&0x80000000u)!=0u{return (a&0x80000000u)!=0u;}
 if((a&0x80000000u)!=0u){return a>b;}return a<b;
}
fn ink_f32_jam(x:u32,n:u32)->u32{if(n==0u){return x;}if(n>=32u){return select(0u,1u,x!=0u);}return (x>>n)|select(0u,1u,(x&((1u<<n)-1u))!=0u);}
fn ink_f32_round(sign:u32,exponent:i32,extended:u32)->u32{
 var e=exponent;var s=extended;
 if(e<1i){s=ink_f32_jam(s,u32(1i-e));e=1i;}
 let tail=s&7u;var sig=s>>3u;
 if(tail>4u||(tail==4u&&(sig&1u)!=0u)){sig++;}
 if(sig>=0x1000000u){sig>>=1u;e++;}
 if(e>=255i){return sign|0x7f800000u;}
 if(sig==0u){return sign;}
 let raw=select(u32(e),0u,e==1i&&sig<0x800000u);
 return sign|(raw<<23u)|(sig&0x7fffffu);
}
fn ink_f32_add(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 var x=a;var y=b;if((x&0x7fffffffu)<(y&0x7fffffffu)){x=b;y=a;}
 let ax=x&0x7fffffffu;let ay=y&0x7fffffffu;let sign=x&0x80000000u;
 if(ax==0x7f800000u){if(ay==ax&&((x^y)&0x80000000u)!=0u){return 0x7fc00000u;}return x;}
 let rx=(x>>23u)&255u;let ry=(y>>23u)&255u;var e=i32(max(rx,1u));
 var sx=((x&0x7fffffu)|select(0u,0x800000u,rx!=0u))<<3u;
 let sy=ink_f32_jam(((y&0x7fffffu)|select(0u,0x800000u,ry!=0u))<<3u,u32(e)-max(ry,1u));
 if(((x^y)&0x80000000u)==0u){sx+=sy;if(sx>=0x8000000u){sx=ink_f32_jam(sx,1u);e++;}}
 else{sx-=sy;if(sx==0u){return 0u;}loop{if(sx>=0x4000000u||e<=1i){break;}sx<<=1u;e--;}}
 return ink_f32_round(sign,e,sx);
}
fn ink_f32_sub(a:u32,b:u32)->u32{return ink_f32_add(a,b^0x80000000u);}
fn ink_f32_mul(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(aa==0x7f800000u||bb==0x7f800000u){if(aa==0u||bb==0u){return 0x7fc00000u;}return sign|0x7f800000u;}
 if(aa==0u||bb==0u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u));var eb=i32(max(rb,1u));
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 let product=ink_u64_mul(InkU64(sa,0u),InkU64(sb,0u));let high=(product.hi&0x8000u)!=0u;
 let shift=select(20u,21u,high);let extended=(product.lo>>shift)|(product.hi<<(32u-shift))|select(0u,1u,(product.lo&((1u<<shift)-1u))!=0u);
 return ink_f32_round(sign,ea+eb-127i+select(0i,1i,high),extended);
}
// Exact sqrt and division use integer significands, independent of WGSL float
// approximation allowances and device flush-to-zero behavior.
fn ink_f32_sqrt(x:u32)->u32{
 let a=x&0x7fffffffu;if(a==0u){return x;}
 if(a>0x7f800000u||(x&0x80000000u)!=0u){return 0x7fc00000u;}
 if(a==0x7f800000u){return x;}
 let raw=(x>>23u)&255u;var m=(x&0x7fffffu)|select(0u,0x800000u,raw!=0u);var e=i32(max(raw,1u))-127i;
 loop{if(m>=0x800000u){break;}m<<=1u;e--;}
 let odd=e&1i;var half=(e-odd)/2i;let shift=23u+u32(odd);
 let n=InkU64(m<<shift,m>>(32u-shift));var lo=0u;var hi=0x1000000u;
 loop{if(lo+1u>=hi){break;}let mid=(lo+hi)>>1u;let sq=ink_u64_mul(InkU64(mid,0u),InkU64(mid,0u));if(!ink_u64_lt(n,sq)){lo=mid;}else{hi=mid;}}
 let sq=ink_u64_mul(InkU64(lo,0u),InkU64(lo,0u));let rem=ink_u64_sub(n,sq);
 if(ink_u64_lt(InkU64(lo,0u),rem)){lo++;}
 if(lo==0x1000000u){lo>>=1u;half++;}
 return (u32(half+127i)<<23u)|(lo&0x7fffffu);
}
fn ink_f32_div(a:u32,b:u32)->u32{
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(ink_f32_nan(a)||ink_f32_nan(b)||(aa==0u&&bb==0u)||(aa==0x7f800000u&&bb==aa)){return 0x7fc00000u;}
 if(aa==0x7f800000u||bb==0u){return sign|0x7f800000u;}
 if(aa==0u||bb==0x7f800000u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u))-127i;var eb=i32(max(rb,1u))-127i;
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 var e=ea-eb;if(sa<sb){sa<<=1u;e--;}
 let division=ink_u64_div(InkU64(sa<<26u,sa>>6u),InkU64(sb,0u));
 let extended=division.quotient.lo|select(0u,1u,!ink_u64_eq(division.remainder,InkU64(0u,0u)));
 return ink_f32_round(sign,e+127i,extended);
}
// mode: 0 trunc, 1 floor, 2 ceil, 3 ties-to-even.
fn ink_f32_integral(x:u32,mode:u32)->u32{
 let a=x&0x7fffffffu;let sign=x&0x80000000u;
 if(a>0x7f800000u){return 0x7fc00000u;}if(a>=0x4b000000u||a==0u){return x;}
 let e=i32((x>>23u)&255u)-127i;
 if(e<0i){var up=false;if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){up=a>0x3f000000u;}return sign|select(0u,0x3f800000u,up);}
 let shift=u32(23i-e);let mask=(1u<<shift)-1u;let fraction=a&mask;var rounded=a&~mask;var up=false;
 if(fraction!=0u){if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){let half=1u<<(shift-1u);up=fraction>half||(fraction==half&&((rounded>>shift)&1u)!=0u);}}
 if(up){rounded+=1u<<shift;}return sign|rounded;
}
fn ink_f32_from_u64(x:InkU64)->u32{
 if(ink_u64_eq(x,InkU64(0u,0u))){return 0u;}
 let leading=select(countLeadingZeros(x.lo)+32u,countLeadingZeros(x.hi),x.hi!=0u);let e=63u-leading;
 if(e<=23u){return ((e+127u)<<23u)|((x.lo<<(23u-e))&0x7fffffu);}
 let shift=e-23u;var sig=0u;var rem=InkU64(0u,0u);var half=InkU64(0u,0u);
 if(shift<32u){sig=(x.lo>>shift)|(x.hi<<(32u-shift));rem=InkU64(x.lo&((1u<<shift)-1u),0u);half=InkU64(1u<<(shift-1u),0u);}
 else if(shift==32u){sig=x.hi;rem=InkU64(x.lo,0u);half=InkU64(0x80000000u,0u);}
 else{sig=x.hi>>(shift-32u);rem=InkU64(x.lo,x.hi&((1u<<(shift-32u))-1u));half=InkU64(0u,1u<<(shift-33u));}
 if(ink_u64_lt(half,rem)||(ink_u64_eq(rem,half)&&(sig&1u)!=0u)){sig++;}
 var exponent=e+127u;if(sig==0x1000000u){sig>>=1u;exponent++;}
 return (exponent<<23u)|(sig&0x7fffffu);
}
fn ink_f32_from_i32(x:i32)->u32{let neg=x<0i;let magnitude=select(u32(x),0u-u32(x),neg);return ink_f32_from_u64(InkU64(magnitude,0u))|select(0u,0x80000000u,neg);}
struct InkBuffer_u32{data:array<u32,64>,length:u32,}
struct InkBuffer_InkU64{data:array<InkU64,64>,length:u32,}
struct InkBuffer_i32{data:array<i32,64>,length:u32,}
struct InkBuffer_bool{data:array<bool,64>,length:u32,}
struct R___ink_differential_0{ink_f_value:u32,ink_f_tangent:u32,}
struct R___ink_differential_3{ink_f_value:R___ink_differential_0,ink_f_first:R___ink_differential_0,ink_f_second:R___ink_differential_0,ink_f_first_power:R___ink_differential_0,ink_f_second_power:R___ink_differential_0,ink_f_steps:u32,}
@group(0) @binding(0) var<storage,read> a0:array<u32>;
@group(0) @binding(1) var<storage,read> a1:array<u32>;
@group(0) @binding(2) var<storage,read> a2:array<u32>;
@group(0) @binding(3) var<storage,read> a3:array<u32>;
@group(0) @binding(4) var<storage,read_write> output:array<u32>;
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) gid:vec3<u32>){
let size=6u;let i=gid.x;if(i==0u){output[0]=size;}if(i<size){
switch(i){
case 0u:{
var t0:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t1:u32=a1[0u+(0u)*1u+0u];
var t2:u32=132u;
var t3:R___ink_differential_0=t0;
var t4:u32=t1;
var t5:u32=t2;
var t6:u32=(t5 + 6u);
var t7:u32=t4;
var t8:R___ink_differential_0;
if ((t7 == t6)) {
t8=t3;
} else {
var t9:u32=t6;
var t10:R___ink_differential_3;if(t9<a3[0u]){
t10=R___ink_differential_3(R___ink_differential_0(a3[1u+(t9)*11u+0u],a3[1u+(t9)*11u+1u]),R___ink_differential_0(a3[1u+(t9)*11u+2u],a3[1u+(t9)*11u+3u]),R___ink_differential_0(a3[1u+(t9)*11u+4u],a3[1u+(t9)*11u+5u]),R___ink_differential_0(a3[1u+(t9)*11u+6u],a3[1u+(t9)*11u+7u]),R___ink_differential_0(a3[1u+(t9)*11u+8u],a3[1u+(t9)*11u+9u]),a3[1u+(t9)*11u+10u]);}else{
var t11:u32=0u;
var t12:u32=0u;
var t13:R___ink_differential_0=R___ink_differential_0(t11,t12);
var t14:u32=0u;
var t15:u32=0u;
var t16:R___ink_differential_0=R___ink_differential_0(t14,t15);
var t17:u32=0u;
var t18:u32=0u;
var t19:R___ink_differential_0=R___ink_differential_0(t17,t18);
var t20:u32=1065353216u;
var t21:u32=0u;
var t22:R___ink_differential_0=R___ink_differential_0(t20,t21);
var t23:u32=1065353216u;
var t24:u32=0u;
var t25:R___ink_differential_0=R___ink_differential_0(t23,t24);
var t26:u32=0u;
t10=R___ink_differential_3(t13,t16,t19,t22,t25,t26);}
t8=(t10).ink_f_value;
}
var t27:R___ink_differential_0=t8;
var t28:R___ink_differential_0=t27;
for(var t29=0u;t29<6u;t29++){
var t30:R___ink_differential_0=t28;
var t31:R___ink_differential_0=t0;
var t32:u32=t1;
var t33:u32=t2;
var t34:u32=(t33 + t29);
var t35:u32=t32;
var t36:R___ink_differential_0;
if ((t35 == t34)) {
t36=t31;
} else {
var t37:u32=t34;
var t38:R___ink_differential_3;if(t37<a3[0u]){
t38=R___ink_differential_3(R___ink_differential_0(a3[1u+(t37)*11u+0u],a3[1u+(t37)*11u+1u]),R___ink_differential_0(a3[1u+(t37)*11u+2u],a3[1u+(t37)*11u+3u]),R___ink_differential_0(a3[1u+(t37)*11u+4u],a3[1u+(t37)*11u+5u]),R___ink_differential_0(a3[1u+(t37)*11u+6u],a3[1u+(t37)*11u+7u]),R___ink_differential_0(a3[1u+(t37)*11u+8u],a3[1u+(t37)*11u+9u]),a3[1u+(t37)*11u+10u]);}else{
var t39:u32=0u;
var t40:u32=0u;
var t41:R___ink_differential_0=R___ink_differential_0(t39,t40);
var t42:u32=0u;
var t43:u32=0u;
var t44:R___ink_differential_0=R___ink_differential_0(t42,t43);
var t45:u32=0u;
var t46:u32=0u;
var t47:R___ink_differential_0=R___ink_differential_0(t45,t46);
var t48:u32=1065353216u;
var t49:u32=0u;
var t50:R___ink_differential_0=R___ink_differential_0(t48,t49);
var t51:u32=1065353216u;
var t52:u32=0u;
var t53:R___ink_differential_0=R___ink_differential_0(t51,t52);
var t54:u32=0u;
t38=R___ink_differential_3(t41,t44,t47,t50,t53,t54);}
t36=(t38).ink_f_value;
}
var t55:R___ink_differential_0=t36;
var t56:u32=t29;
var t57:R___ink_differential_0;if(t56<a2[0u]){
t57=R___ink_differential_0(a2[1u+(t56)*2u+0u],a2[1u+(t56)*2u+1u]);}else{
var t58:u32=0u;
var t59:u32=0u;
t57=R___ink_differential_0(t58,t59);}
var t60:R___ink_differential_0=t57;
var t61:u32=(t55).ink_f_value;
var t62:u32=ink_f32_mul(t61,(t60).ink_f_value);
var t63:u32=t62;
var t64:u32=(t55).ink_f_tangent;
var t65:u32=ink_f32_mul(t64,(t60).ink_f_value);
var t66:u32=(t55).ink_f_value;
var t67:u32=ink_f32_add(t65,ink_f32_mul(t66,(t60).ink_f_tangent));
var t68:R___ink_differential_0=R___ink_differential_0(t63,t67);
var t69:u32=(t30).ink_f_value;
var t70:u32=ink_f32_add(t69,(t68).ink_f_value);
var t71:u32=t70;
var t72:u32=(t30).ink_f_tangent;
var t73:u32=ink_f32_add(t72,(t68).ink_f_tangent);
t28=R___ink_differential_0(t71,t73);
}
var t74:R___ink_differential_0=t28;
var t75:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t76:u32=a1[0u+(0u)*1u+0u];
var t77:u32=139u;
var t78:R___ink_differential_0=t75;
var t79:u32=t76;
var t80:u32=t77;
var t81:u32=(t80 + 6u);
var t82:u32=t79;
var t83:R___ink_differential_0;
if ((t82 == t81)) {
t83=t78;
} else {
var t84:u32=t81;
var t85:R___ink_differential_3;if(t84<a3[0u]){
t85=R___ink_differential_3(R___ink_differential_0(a3[1u+(t84)*11u+0u],a3[1u+(t84)*11u+1u]),R___ink_differential_0(a3[1u+(t84)*11u+2u],a3[1u+(t84)*11u+3u]),R___ink_differential_0(a3[1u+(t84)*11u+4u],a3[1u+(t84)*11u+5u]),R___ink_differential_0(a3[1u+(t84)*11u+6u],a3[1u+(t84)*11u+7u]),R___ink_differential_0(a3[1u+(t84)*11u+8u],a3[1u+(t84)*11u+9u]),a3[1u+(t84)*11u+10u]);}else{
var t86:u32=0u;
var t87:u32=0u;
var t88:R___ink_differential_0=R___ink_differential_0(t86,t87);
var t89:u32=0u;
var t90:u32=0u;
var t91:R___ink_differential_0=R___ink_differential_0(t89,t90);
var t92:u32=0u;
var t93:u32=0u;
var t94:R___ink_differential_0=R___ink_differential_0(t92,t93);
var t95:u32=1065353216u;
var t96:u32=0u;
var t97:R___ink_differential_0=R___ink_differential_0(t95,t96);
var t98:u32=1065353216u;
var t99:u32=0u;
var t100:R___ink_differential_0=R___ink_differential_0(t98,t99);
var t101:u32=0u;
t85=R___ink_differential_3(t88,t91,t94,t97,t100,t101);}
t83=(t85).ink_f_value;
}
var t102:R___ink_differential_0=t83;
var t103:R___ink_differential_0=t102;
for(var t104=0u;t104<6u;t104++){
var t105:R___ink_differential_0=t103;
var t106:R___ink_differential_0=t75;
var t107:u32=t76;
var t108:u32=t77;
var t109:u32=(t108 + t104);
var t110:u32=t107;
var t111:R___ink_differential_0;
if ((t110 == t109)) {
t111=t106;
} else {
var t112:u32=t109;
var t113:R___ink_differential_3;if(t112<a3[0u]){
t113=R___ink_differential_3(R___ink_differential_0(a3[1u+(t112)*11u+0u],a3[1u+(t112)*11u+1u]),R___ink_differential_0(a3[1u+(t112)*11u+2u],a3[1u+(t112)*11u+3u]),R___ink_differential_0(a3[1u+(t112)*11u+4u],a3[1u+(t112)*11u+5u]),R___ink_differential_0(a3[1u+(t112)*11u+6u],a3[1u+(t112)*11u+7u]),R___ink_differential_0(a3[1u+(t112)*11u+8u],a3[1u+(t112)*11u+9u]),a3[1u+(t112)*11u+10u]);}else{
var t114:u32=0u;
var t115:u32=0u;
var t116:R___ink_differential_0=R___ink_differential_0(t114,t115);
var t117:u32=0u;
var t118:u32=0u;
var t119:R___ink_differential_0=R___ink_differential_0(t117,t118);
var t120:u32=0u;
var t121:u32=0u;
var t122:R___ink_differential_0=R___ink_differential_0(t120,t121);
var t123:u32=1065353216u;
var t124:u32=0u;
var t125:R___ink_differential_0=R___ink_differential_0(t123,t124);
var t126:u32=1065353216u;
var t127:u32=0u;
var t128:R___ink_differential_0=R___ink_differential_0(t126,t127);
var t129:u32=0u;
t113=R___ink_differential_3(t116,t119,t122,t125,t128,t129);}
t111=(t113).ink_f_value;
}
var t130:R___ink_differential_0=t111;
var t131:u32=t104;
var t132:R___ink_differential_0;if(t131<a2[0u]){
t132=R___ink_differential_0(a2[1u+(t131)*2u+0u],a2[1u+(t131)*2u+1u]);}else{
var t133:u32=0u;
var t134:u32=0u;
t132=R___ink_differential_0(t133,t134);}
var t135:R___ink_differential_0=t132;
var t136:u32=(t130).ink_f_value;
var t137:u32=ink_f32_mul(t136,(t135).ink_f_value);
var t138:u32=t137;
var t139:u32=(t130).ink_f_tangent;
var t140:u32=ink_f32_mul(t139,(t135).ink_f_value);
var t141:u32=(t130).ink_f_value;
var t142:u32=ink_f32_add(t140,ink_f32_mul(t141,(t135).ink_f_tangent));
var t143:R___ink_differential_0=R___ink_differential_0(t138,t142);
var t144:u32=(t105).ink_f_value;
var t145:u32=ink_f32_add(t144,(t143).ink_f_value);
var t146:u32=t145;
var t147:u32=(t105).ink_f_tangent;
var t148:u32=ink_f32_add(t147,(t143).ink_f_tangent);
t103=R___ink_differential_0(t146,t148);
}
var t149:R___ink_differential_0=t103;
var t150:u32=(t149).ink_f_value;
var t151:u32=0u;
var t152:u32=0u;
var t153:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t151,t152)).ink_f_value,t150)) {
var t154:R___ink_differential_0=t74;
var t155:R___ink_differential_0=t149;
var t156:u32=(t154).ink_f_value;
var t157:u32=ink_f32_mul(t156,(t155).ink_f_value);
var t158:u32=t157;
var t159:u32=(t154).ink_f_tangent;
var t160:u32=ink_f32_mul(t159,(t155).ink_f_value);
var t161:u32=(t154).ink_f_value;
var t162:u32=ink_f32_add(t160,ink_f32_mul(t161,(t155).ink_f_tangent));
t153=R___ink_differential_0(t158,t162);
} else {
var t163:u32=0u;
var t164:u32=0u;
t153=R___ink_differential_0(t163,t164);
}
var t165:R___ink_differential_0=t153;
output[1u+i*2u+0u]=bitcast<u32>((t165).ink_f_value);
output[1u+i*2u+1u]=bitcast<u32>((t165).ink_f_tangent);

}
case 1u:{
var t166:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t167:u32=a1[0u+(0u)*1u+0u];
var t168:u32=146u;
var t169:R___ink_differential_0=t166;
var t170:u32=t167;
var t171:u32=t168;
var t172:u32=(t171 + 6u);
var t173:u32=t170;
var t174:R___ink_differential_0;
if ((t173 == t172)) {
t174=t169;
} else {
var t175:u32=t172;
var t176:R___ink_differential_3;if(t175<a3[0u]){
t176=R___ink_differential_3(R___ink_differential_0(a3[1u+(t175)*11u+0u],a3[1u+(t175)*11u+1u]),R___ink_differential_0(a3[1u+(t175)*11u+2u],a3[1u+(t175)*11u+3u]),R___ink_differential_0(a3[1u+(t175)*11u+4u],a3[1u+(t175)*11u+5u]),R___ink_differential_0(a3[1u+(t175)*11u+6u],a3[1u+(t175)*11u+7u]),R___ink_differential_0(a3[1u+(t175)*11u+8u],a3[1u+(t175)*11u+9u]),a3[1u+(t175)*11u+10u]);}else{
var t177:u32=0u;
var t178:u32=0u;
var t179:R___ink_differential_0=R___ink_differential_0(t177,t178);
var t180:u32=0u;
var t181:u32=0u;
var t182:R___ink_differential_0=R___ink_differential_0(t180,t181);
var t183:u32=0u;
var t184:u32=0u;
var t185:R___ink_differential_0=R___ink_differential_0(t183,t184);
var t186:u32=1065353216u;
var t187:u32=0u;
var t188:R___ink_differential_0=R___ink_differential_0(t186,t187);
var t189:u32=1065353216u;
var t190:u32=0u;
var t191:R___ink_differential_0=R___ink_differential_0(t189,t190);
var t192:u32=0u;
t176=R___ink_differential_3(t179,t182,t185,t188,t191,t192);}
t174=(t176).ink_f_value;
}
var t193:R___ink_differential_0=t174;
var t194:R___ink_differential_0=t193;
for(var t195=0u;t195<6u;t195++){
var t196:R___ink_differential_0=t194;
var t197:R___ink_differential_0=t166;
var t198:u32=t167;
var t199:u32=t168;
var t200:u32=(t199 + t195);
var t201:u32=t198;
var t202:R___ink_differential_0;
if ((t201 == t200)) {
t202=t197;
} else {
var t203:u32=t200;
var t204:R___ink_differential_3;if(t203<a3[0u]){
t204=R___ink_differential_3(R___ink_differential_0(a3[1u+(t203)*11u+0u],a3[1u+(t203)*11u+1u]),R___ink_differential_0(a3[1u+(t203)*11u+2u],a3[1u+(t203)*11u+3u]),R___ink_differential_0(a3[1u+(t203)*11u+4u],a3[1u+(t203)*11u+5u]),R___ink_differential_0(a3[1u+(t203)*11u+6u],a3[1u+(t203)*11u+7u]),R___ink_differential_0(a3[1u+(t203)*11u+8u],a3[1u+(t203)*11u+9u]),a3[1u+(t203)*11u+10u]);}else{
var t205:u32=0u;
var t206:u32=0u;
var t207:R___ink_differential_0=R___ink_differential_0(t205,t206);
var t208:u32=0u;
var t209:u32=0u;
var t210:R___ink_differential_0=R___ink_differential_0(t208,t209);
var t211:u32=0u;
var t212:u32=0u;
var t213:R___ink_differential_0=R___ink_differential_0(t211,t212);
var t214:u32=1065353216u;
var t215:u32=0u;
var t216:R___ink_differential_0=R___ink_differential_0(t214,t215);
var t217:u32=1065353216u;
var t218:u32=0u;
var t219:R___ink_differential_0=R___ink_differential_0(t217,t218);
var t220:u32=0u;
t204=R___ink_differential_3(t207,t210,t213,t216,t219,t220);}
t202=(t204).ink_f_value;
}
var t221:R___ink_differential_0=t202;
var t222:u32=t195;
var t223:R___ink_differential_0;if(t222<a2[0u]){
t223=R___ink_differential_0(a2[1u+(t222)*2u+0u],a2[1u+(t222)*2u+1u]);}else{
var t224:u32=0u;
var t225:u32=0u;
t223=R___ink_differential_0(t224,t225);}
var t226:R___ink_differential_0=t223;
var t227:u32=(t221).ink_f_value;
var t228:u32=ink_f32_mul(t227,(t226).ink_f_value);
var t229:u32=t228;
var t230:u32=(t221).ink_f_tangent;
var t231:u32=ink_f32_mul(t230,(t226).ink_f_value);
var t232:u32=(t221).ink_f_value;
var t233:u32=ink_f32_add(t231,ink_f32_mul(t232,(t226).ink_f_tangent));
var t234:R___ink_differential_0=R___ink_differential_0(t229,t233);
var t235:u32=(t196).ink_f_value;
var t236:u32=ink_f32_add(t235,(t234).ink_f_value);
var t237:u32=t236;
var t238:u32=(t196).ink_f_tangent;
var t239:u32=ink_f32_add(t238,(t234).ink_f_tangent);
t194=R___ink_differential_0(t237,t239);
}
var t240:R___ink_differential_0=t194;
var t241:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t242:u32=a1[0u+(0u)*1u+0u];
var t243:u32=153u;
var t244:R___ink_differential_0=t241;
var t245:u32=t242;
var t246:u32=t243;
var t247:u32=(t246 + 6u);
var t248:u32=t245;
var t249:R___ink_differential_0;
if ((t248 == t247)) {
t249=t244;
} else {
var t250:u32=t247;
var t251:R___ink_differential_3;if(t250<a3[0u]){
t251=R___ink_differential_3(R___ink_differential_0(a3[1u+(t250)*11u+0u],a3[1u+(t250)*11u+1u]),R___ink_differential_0(a3[1u+(t250)*11u+2u],a3[1u+(t250)*11u+3u]),R___ink_differential_0(a3[1u+(t250)*11u+4u],a3[1u+(t250)*11u+5u]),R___ink_differential_0(a3[1u+(t250)*11u+6u],a3[1u+(t250)*11u+7u]),R___ink_differential_0(a3[1u+(t250)*11u+8u],a3[1u+(t250)*11u+9u]),a3[1u+(t250)*11u+10u]);}else{
var t252:u32=0u;
var t253:u32=0u;
var t254:R___ink_differential_0=R___ink_differential_0(t252,t253);
var t255:u32=0u;
var t256:u32=0u;
var t257:R___ink_differential_0=R___ink_differential_0(t255,t256);
var t258:u32=0u;
var t259:u32=0u;
var t260:R___ink_differential_0=R___ink_differential_0(t258,t259);
var t261:u32=1065353216u;
var t262:u32=0u;
var t263:R___ink_differential_0=R___ink_differential_0(t261,t262);
var t264:u32=1065353216u;
var t265:u32=0u;
var t266:R___ink_differential_0=R___ink_differential_0(t264,t265);
var t267:u32=0u;
t251=R___ink_differential_3(t254,t257,t260,t263,t266,t267);}
t249=(t251).ink_f_value;
}
var t268:R___ink_differential_0=t249;
var t269:R___ink_differential_0=t268;
for(var t270=0u;t270<6u;t270++){
var t271:R___ink_differential_0=t269;
var t272:R___ink_differential_0=t241;
var t273:u32=t242;
var t274:u32=t243;
var t275:u32=(t274 + t270);
var t276:u32=t273;
var t277:R___ink_differential_0;
if ((t276 == t275)) {
t277=t272;
} else {
var t278:u32=t275;
var t279:R___ink_differential_3;if(t278<a3[0u]){
t279=R___ink_differential_3(R___ink_differential_0(a3[1u+(t278)*11u+0u],a3[1u+(t278)*11u+1u]),R___ink_differential_0(a3[1u+(t278)*11u+2u],a3[1u+(t278)*11u+3u]),R___ink_differential_0(a3[1u+(t278)*11u+4u],a3[1u+(t278)*11u+5u]),R___ink_differential_0(a3[1u+(t278)*11u+6u],a3[1u+(t278)*11u+7u]),R___ink_differential_0(a3[1u+(t278)*11u+8u],a3[1u+(t278)*11u+9u]),a3[1u+(t278)*11u+10u]);}else{
var t280:u32=0u;
var t281:u32=0u;
var t282:R___ink_differential_0=R___ink_differential_0(t280,t281);
var t283:u32=0u;
var t284:u32=0u;
var t285:R___ink_differential_0=R___ink_differential_0(t283,t284);
var t286:u32=0u;
var t287:u32=0u;
var t288:R___ink_differential_0=R___ink_differential_0(t286,t287);
var t289:u32=1065353216u;
var t290:u32=0u;
var t291:R___ink_differential_0=R___ink_differential_0(t289,t290);
var t292:u32=1065353216u;
var t293:u32=0u;
var t294:R___ink_differential_0=R___ink_differential_0(t292,t293);
var t295:u32=0u;
t279=R___ink_differential_3(t282,t285,t288,t291,t294,t295);}
t277=(t279).ink_f_value;
}
var t296:R___ink_differential_0=t277;
var t297:u32=t270;
var t298:R___ink_differential_0;if(t297<a2[0u]){
t298=R___ink_differential_0(a2[1u+(t297)*2u+0u],a2[1u+(t297)*2u+1u]);}else{
var t299:u32=0u;
var t300:u32=0u;
t298=R___ink_differential_0(t299,t300);}
var t301:R___ink_differential_0=t298;
var t302:u32=(t296).ink_f_value;
var t303:u32=ink_f32_mul(t302,(t301).ink_f_value);
var t304:u32=t303;
var t305:u32=(t296).ink_f_tangent;
var t306:u32=ink_f32_mul(t305,(t301).ink_f_value);
var t307:u32=(t296).ink_f_value;
var t308:u32=ink_f32_add(t306,ink_f32_mul(t307,(t301).ink_f_tangent));
var t309:R___ink_differential_0=R___ink_differential_0(t304,t308);
var t310:u32=(t271).ink_f_value;
var t311:u32=ink_f32_add(t310,(t309).ink_f_value);
var t312:u32=t311;
var t313:u32=(t271).ink_f_tangent;
var t314:u32=ink_f32_add(t313,(t309).ink_f_tangent);
t269=R___ink_differential_0(t312,t314);
}
var t315:R___ink_differential_0=t269;
var t316:u32=(t315).ink_f_value;
var t317:u32=0u;
var t318:u32=0u;
var t319:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t317,t318)).ink_f_value,t316)) {
var t320:R___ink_differential_0=t240;
var t321:R___ink_differential_0=t315;
var t322:u32=(t320).ink_f_value;
var t323:u32=ink_f32_mul(t322,(t321).ink_f_value);
var t324:u32=t323;
var t325:u32=(t320).ink_f_tangent;
var t326:u32=ink_f32_mul(t325,(t321).ink_f_value);
var t327:u32=(t320).ink_f_value;
var t328:u32=ink_f32_add(t326,ink_f32_mul(t327,(t321).ink_f_tangent));
t319=R___ink_differential_0(t324,t328);
} else {
var t329:u32=0u;
var t330:u32=0u;
t319=R___ink_differential_0(t329,t330);
}
var t331:R___ink_differential_0=t319;
output[1u+i*2u+0u]=bitcast<u32>((t331).ink_f_value);
output[1u+i*2u+1u]=bitcast<u32>((t331).ink_f_tangent);

}
case 2u:{
var t332:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t333:u32=a1[0u+(0u)*1u+0u];
var t334:u32=160u;
var t335:R___ink_differential_0=t332;
var t336:u32=t333;
var t337:u32=t334;
var t338:u32=(t337 + 6u);
var t339:u32=t336;
var t340:R___ink_differential_0;
if ((t339 == t338)) {
t340=t335;
} else {
var t341:u32=t338;
var t342:R___ink_differential_3;if(t341<a3[0u]){
t342=R___ink_differential_3(R___ink_differential_0(a3[1u+(t341)*11u+0u],a3[1u+(t341)*11u+1u]),R___ink_differential_0(a3[1u+(t341)*11u+2u],a3[1u+(t341)*11u+3u]),R___ink_differential_0(a3[1u+(t341)*11u+4u],a3[1u+(t341)*11u+5u]),R___ink_differential_0(a3[1u+(t341)*11u+6u],a3[1u+(t341)*11u+7u]),R___ink_differential_0(a3[1u+(t341)*11u+8u],a3[1u+(t341)*11u+9u]),a3[1u+(t341)*11u+10u]);}else{
var t343:u32=0u;
var t344:u32=0u;
var t345:R___ink_differential_0=R___ink_differential_0(t343,t344);
var t346:u32=0u;
var t347:u32=0u;
var t348:R___ink_differential_0=R___ink_differential_0(t346,t347);
var t349:u32=0u;
var t350:u32=0u;
var t351:R___ink_differential_0=R___ink_differential_0(t349,t350);
var t352:u32=1065353216u;
var t353:u32=0u;
var t354:R___ink_differential_0=R___ink_differential_0(t352,t353);
var t355:u32=1065353216u;
var t356:u32=0u;
var t357:R___ink_differential_0=R___ink_differential_0(t355,t356);
var t358:u32=0u;
t342=R___ink_differential_3(t345,t348,t351,t354,t357,t358);}
t340=(t342).ink_f_value;
}
var t359:R___ink_differential_0=t340;
var t360:R___ink_differential_0=t359;
for(var t361=0u;t361<6u;t361++){
var t362:R___ink_differential_0=t360;
var t363:R___ink_differential_0=t332;
var t364:u32=t333;
var t365:u32=t334;
var t366:u32=(t365 + t361);
var t367:u32=t364;
var t368:R___ink_differential_0;
if ((t367 == t366)) {
t368=t363;
} else {
var t369:u32=t366;
var t370:R___ink_differential_3;if(t369<a3[0u]){
t370=R___ink_differential_3(R___ink_differential_0(a3[1u+(t369)*11u+0u],a3[1u+(t369)*11u+1u]),R___ink_differential_0(a3[1u+(t369)*11u+2u],a3[1u+(t369)*11u+3u]),R___ink_differential_0(a3[1u+(t369)*11u+4u],a3[1u+(t369)*11u+5u]),R___ink_differential_0(a3[1u+(t369)*11u+6u],a3[1u+(t369)*11u+7u]),R___ink_differential_0(a3[1u+(t369)*11u+8u],a3[1u+(t369)*11u+9u]),a3[1u+(t369)*11u+10u]);}else{
var t371:u32=0u;
var t372:u32=0u;
var t373:R___ink_differential_0=R___ink_differential_0(t371,t372);
var t374:u32=0u;
var t375:u32=0u;
var t376:R___ink_differential_0=R___ink_differential_0(t374,t375);
var t377:u32=0u;
var t378:u32=0u;
var t379:R___ink_differential_0=R___ink_differential_0(t377,t378);
var t380:u32=1065353216u;
var t381:u32=0u;
var t382:R___ink_differential_0=R___ink_differential_0(t380,t381);
var t383:u32=1065353216u;
var t384:u32=0u;
var t385:R___ink_differential_0=R___ink_differential_0(t383,t384);
var t386:u32=0u;
t370=R___ink_differential_3(t373,t376,t379,t382,t385,t386);}
t368=(t370).ink_f_value;
}
var t387:R___ink_differential_0=t368;
var t388:u32=t361;
var t389:R___ink_differential_0;if(t388<a2[0u]){
t389=R___ink_differential_0(a2[1u+(t388)*2u+0u],a2[1u+(t388)*2u+1u]);}else{
var t390:u32=0u;
var t391:u32=0u;
t389=R___ink_differential_0(t390,t391);}
var t392:R___ink_differential_0=t389;
var t393:u32=(t387).ink_f_value;
var t394:u32=ink_f32_mul(t393,(t392).ink_f_value);
var t395:u32=t394;
var t396:u32=(t387).ink_f_tangent;
var t397:u32=ink_f32_mul(t396,(t392).ink_f_value);
var t398:u32=(t387).ink_f_value;
var t399:u32=ink_f32_add(t397,ink_f32_mul(t398,(t392).ink_f_tangent));
var t400:R___ink_differential_0=R___ink_differential_0(t395,t399);
var t401:u32=(t362).ink_f_value;
var t402:u32=ink_f32_add(t401,(t400).ink_f_value);
var t403:u32=t402;
var t404:u32=(t362).ink_f_tangent;
var t405:u32=ink_f32_add(t404,(t400).ink_f_tangent);
t360=R___ink_differential_0(t403,t405);
}
var t406:R___ink_differential_0=t360;
var t407:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t408:u32=a1[0u+(0u)*1u+0u];
var t409:u32=167u;
var t410:R___ink_differential_0=t407;
var t411:u32=t408;
var t412:u32=t409;
var t413:u32=(t412 + 6u);
var t414:u32=t411;
var t415:R___ink_differential_0;
if ((t414 == t413)) {
t415=t410;
} else {
var t416:u32=t413;
var t417:R___ink_differential_3;if(t416<a3[0u]){
t417=R___ink_differential_3(R___ink_differential_0(a3[1u+(t416)*11u+0u],a3[1u+(t416)*11u+1u]),R___ink_differential_0(a3[1u+(t416)*11u+2u],a3[1u+(t416)*11u+3u]),R___ink_differential_0(a3[1u+(t416)*11u+4u],a3[1u+(t416)*11u+5u]),R___ink_differential_0(a3[1u+(t416)*11u+6u],a3[1u+(t416)*11u+7u]),R___ink_differential_0(a3[1u+(t416)*11u+8u],a3[1u+(t416)*11u+9u]),a3[1u+(t416)*11u+10u]);}else{
var t418:u32=0u;
var t419:u32=0u;
var t420:R___ink_differential_0=R___ink_differential_0(t418,t419);
var t421:u32=0u;
var t422:u32=0u;
var t423:R___ink_differential_0=R___ink_differential_0(t421,t422);
var t424:u32=0u;
var t425:u32=0u;
var t426:R___ink_differential_0=R___ink_differential_0(t424,t425);
var t427:u32=1065353216u;
var t428:u32=0u;
var t429:R___ink_differential_0=R___ink_differential_0(t427,t428);
var t430:u32=1065353216u;
var t431:u32=0u;
var t432:R___ink_differential_0=R___ink_differential_0(t430,t431);
var t433:u32=0u;
t417=R___ink_differential_3(t420,t423,t426,t429,t432,t433);}
t415=(t417).ink_f_value;
}
var t434:R___ink_differential_0=t415;
var t435:R___ink_differential_0=t434;
for(var t436=0u;t436<6u;t436++){
var t437:R___ink_differential_0=t435;
var t438:R___ink_differential_0=t407;
var t439:u32=t408;
var t440:u32=t409;
var t441:u32=(t440 + t436);
var t442:u32=t439;
var t443:R___ink_differential_0;
if ((t442 == t441)) {
t443=t438;
} else {
var t444:u32=t441;
var t445:R___ink_differential_3;if(t444<a3[0u]){
t445=R___ink_differential_3(R___ink_differential_0(a3[1u+(t444)*11u+0u],a3[1u+(t444)*11u+1u]),R___ink_differential_0(a3[1u+(t444)*11u+2u],a3[1u+(t444)*11u+3u]),R___ink_differential_0(a3[1u+(t444)*11u+4u],a3[1u+(t444)*11u+5u]),R___ink_differential_0(a3[1u+(t444)*11u+6u],a3[1u+(t444)*11u+7u]),R___ink_differential_0(a3[1u+(t444)*11u+8u],a3[1u+(t444)*11u+9u]),a3[1u+(t444)*11u+10u]);}else{
var t446:u32=0u;
var t447:u32=0u;
var t448:R___ink_differential_0=R___ink_differential_0(t446,t447);
var t449:u32=0u;
var t450:u32=0u;
var t451:R___ink_differential_0=R___ink_differential_0(t449,t450);
var t452:u32=0u;
var t453:u32=0u;
var t454:R___ink_differential_0=R___ink_differential_0(t452,t453);
var t455:u32=1065353216u;
var t456:u32=0u;
var t457:R___ink_differential_0=R___ink_differential_0(t455,t456);
var t458:u32=1065353216u;
var t459:u32=0u;
var t460:R___ink_differential_0=R___ink_differential_0(t458,t459);
var t461:u32=0u;
t445=R___ink_differential_3(t448,t451,t454,t457,t460,t461);}
t443=(t445).ink_f_value;
}
var t462:R___ink_differential_0=t443;
var t463:u32=t436;
var t464:R___ink_differential_0;if(t463<a2[0u]){
t464=R___ink_differential_0(a2[1u+(t463)*2u+0u],a2[1u+(t463)*2u+1u]);}else{
var t465:u32=0u;
var t466:u32=0u;
t464=R___ink_differential_0(t465,t466);}
var t467:R___ink_differential_0=t464;
var t468:u32=(t462).ink_f_value;
var t469:u32=ink_f32_mul(t468,(t467).ink_f_value);
var t470:u32=t469;
var t471:u32=(t462).ink_f_tangent;
var t472:u32=ink_f32_mul(t471,(t467).ink_f_value);
var t473:u32=(t462).ink_f_value;
var t474:u32=ink_f32_add(t472,ink_f32_mul(t473,(t467).ink_f_tangent));
var t475:R___ink_differential_0=R___ink_differential_0(t470,t474);
var t476:u32=(t437).ink_f_value;
var t477:u32=ink_f32_add(t476,(t475).ink_f_value);
var t478:u32=t477;
var t479:u32=(t437).ink_f_tangent;
var t480:u32=ink_f32_add(t479,(t475).ink_f_tangent);
t435=R___ink_differential_0(t478,t480);
}
var t481:R___ink_differential_0=t435;
var t482:u32=(t481).ink_f_value;
var t483:u32=0u;
var t484:u32=0u;
var t485:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t483,t484)).ink_f_value,t482)) {
var t486:R___ink_differential_0=t406;
var t487:R___ink_differential_0=t481;
var t488:u32=(t486).ink_f_value;
var t489:u32=ink_f32_mul(t488,(t487).ink_f_value);
var t490:u32=t489;
var t491:u32=(t486).ink_f_tangent;
var t492:u32=ink_f32_mul(t491,(t487).ink_f_value);
var t493:u32=(t486).ink_f_value;
var t494:u32=ink_f32_add(t492,ink_f32_mul(t493,(t487).ink_f_tangent));
t485=R___ink_differential_0(t490,t494);
} else {
var t495:u32=0u;
var t496:u32=0u;
t485=R___ink_differential_0(t495,t496);
}
var t497:R___ink_differential_0=t485;
output[1u+i*2u+0u]=bitcast<u32>((t497).ink_f_value);
output[1u+i*2u+1u]=bitcast<u32>((t497).ink_f_tangent);

}
case 3u:{
var t498:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t499:u32=a1[0u+(0u)*1u+0u];
var t500:u32=174u;
var t501:R___ink_differential_0=t498;
var t502:u32=t499;
var t503:u32=t500;
var t504:u32=(t503 + 6u);
var t505:u32=t502;
var t506:R___ink_differential_0;
if ((t505 == t504)) {
t506=t501;
} else {
var t507:u32=t504;
var t508:R___ink_differential_3;if(t507<a3[0u]){
t508=R___ink_differential_3(R___ink_differential_0(a3[1u+(t507)*11u+0u],a3[1u+(t507)*11u+1u]),R___ink_differential_0(a3[1u+(t507)*11u+2u],a3[1u+(t507)*11u+3u]),R___ink_differential_0(a3[1u+(t507)*11u+4u],a3[1u+(t507)*11u+5u]),R___ink_differential_0(a3[1u+(t507)*11u+6u],a3[1u+(t507)*11u+7u]),R___ink_differential_0(a3[1u+(t507)*11u+8u],a3[1u+(t507)*11u+9u]),a3[1u+(t507)*11u+10u]);}else{
var t509:u32=0u;
var t510:u32=0u;
var t511:R___ink_differential_0=R___ink_differential_0(t509,t510);
var t512:u32=0u;
var t513:u32=0u;
var t514:R___ink_differential_0=R___ink_differential_0(t512,t513);
var t515:u32=0u;
var t516:u32=0u;
var t517:R___ink_differential_0=R___ink_differential_0(t515,t516);
var t518:u32=1065353216u;
var t519:u32=0u;
var t520:R___ink_differential_0=R___ink_differential_0(t518,t519);
var t521:u32=1065353216u;
var t522:u32=0u;
var t523:R___ink_differential_0=R___ink_differential_0(t521,t522);
var t524:u32=0u;
t508=R___ink_differential_3(t511,t514,t517,t520,t523,t524);}
t506=(t508).ink_f_value;
}
var t525:R___ink_differential_0=t506;
var t526:R___ink_differential_0=t525;
for(var t527=0u;t527<6u;t527++){
var t528:R___ink_differential_0=t526;
var t529:R___ink_differential_0=t498;
var t530:u32=t499;
var t531:u32=t500;
var t532:u32=(t531 + t527);
var t533:u32=t530;
var t534:R___ink_differential_0;
if ((t533 == t532)) {
t534=t529;
} else {
var t535:u32=t532;
var t536:R___ink_differential_3;if(t535<a3[0u]){
t536=R___ink_differential_3(R___ink_differential_0(a3[1u+(t535)*11u+0u],a3[1u+(t535)*11u+1u]),R___ink_differential_0(a3[1u+(t535)*11u+2u],a3[1u+(t535)*11u+3u]),R___ink_differential_0(a3[1u+(t535)*11u+4u],a3[1u+(t535)*11u+5u]),R___ink_differential_0(a3[1u+(t535)*11u+6u],a3[1u+(t535)*11u+7u]),R___ink_differential_0(a3[1u+(t535)*11u+8u],a3[1u+(t535)*11u+9u]),a3[1u+(t535)*11u+10u]);}else{
var t537:u32=0u;
var t538:u32=0u;
var t539:R___ink_differential_0=R___ink_differential_0(t537,t538);
var t540:u32=0u;
var t541:u32=0u;
var t542:R___ink_differential_0=R___ink_differential_0(t540,t541);
var t543:u32=0u;
var t544:u32=0u;
var t545:R___ink_differential_0=R___ink_differential_0(t543,t544);
var t546:u32=1065353216u;
var t547:u32=0u;
var t548:R___ink_differential_0=R___ink_differential_0(t546,t547);
var t549:u32=1065353216u;
var t550:u32=0u;
var t551:R___ink_differential_0=R___ink_differential_0(t549,t550);
var t552:u32=0u;
t536=R___ink_differential_3(t539,t542,t545,t548,t551,t552);}
t534=(t536).ink_f_value;
}
var t553:R___ink_differential_0=t534;
var t554:u32=t527;
var t555:R___ink_differential_0;if(t554<a2[0u]){
t555=R___ink_differential_0(a2[1u+(t554)*2u+0u],a2[1u+(t554)*2u+1u]);}else{
var t556:u32=0u;
var t557:u32=0u;
t555=R___ink_differential_0(t556,t557);}
var t558:R___ink_differential_0=t555;
var t559:u32=(t553).ink_f_value;
var t560:u32=ink_f32_mul(t559,(t558).ink_f_value);
var t561:u32=t560;
var t562:u32=(t553).ink_f_tangent;
var t563:u32=ink_f32_mul(t562,(t558).ink_f_value);
var t564:u32=(t553).ink_f_value;
var t565:u32=ink_f32_add(t563,ink_f32_mul(t564,(t558).ink_f_tangent));
var t566:R___ink_differential_0=R___ink_differential_0(t561,t565);
var t567:u32=(t528).ink_f_value;
var t568:u32=ink_f32_add(t567,(t566).ink_f_value);
var t569:u32=t568;
var t570:u32=(t528).ink_f_tangent;
var t571:u32=ink_f32_add(t570,(t566).ink_f_tangent);
t526=R___ink_differential_0(t569,t571);
}
var t572:R___ink_differential_0=t526;
var t573:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t574:u32=a1[0u+(0u)*1u+0u];
var t575:u32=181u;
var t576:R___ink_differential_0=t573;
var t577:u32=t574;
var t578:u32=t575;
var t579:u32=(t578 + 6u);
var t580:u32=t577;
var t581:R___ink_differential_0;
if ((t580 == t579)) {
t581=t576;
} else {
var t582:u32=t579;
var t583:R___ink_differential_3;if(t582<a3[0u]){
t583=R___ink_differential_3(R___ink_differential_0(a3[1u+(t582)*11u+0u],a3[1u+(t582)*11u+1u]),R___ink_differential_0(a3[1u+(t582)*11u+2u],a3[1u+(t582)*11u+3u]),R___ink_differential_0(a3[1u+(t582)*11u+4u],a3[1u+(t582)*11u+5u]),R___ink_differential_0(a3[1u+(t582)*11u+6u],a3[1u+(t582)*11u+7u]),R___ink_differential_0(a3[1u+(t582)*11u+8u],a3[1u+(t582)*11u+9u]),a3[1u+(t582)*11u+10u]);}else{
var t584:u32=0u;
var t585:u32=0u;
var t586:R___ink_differential_0=R___ink_differential_0(t584,t585);
var t587:u32=0u;
var t588:u32=0u;
var t589:R___ink_differential_0=R___ink_differential_0(t587,t588);
var t590:u32=0u;
var t591:u32=0u;
var t592:R___ink_differential_0=R___ink_differential_0(t590,t591);
var t593:u32=1065353216u;
var t594:u32=0u;
var t595:R___ink_differential_0=R___ink_differential_0(t593,t594);
var t596:u32=1065353216u;
var t597:u32=0u;
var t598:R___ink_differential_0=R___ink_differential_0(t596,t597);
var t599:u32=0u;
t583=R___ink_differential_3(t586,t589,t592,t595,t598,t599);}
t581=(t583).ink_f_value;
}
var t600:R___ink_differential_0=t581;
var t601:R___ink_differential_0=t600;
for(var t602=0u;t602<6u;t602++){
var t603:R___ink_differential_0=t601;
var t604:R___ink_differential_0=t573;
var t605:u32=t574;
var t606:u32=t575;
var t607:u32=(t606 + t602);
var t608:u32=t605;
var t609:R___ink_differential_0;
if ((t608 == t607)) {
t609=t604;
} else {
var t610:u32=t607;
var t611:R___ink_differential_3;if(t610<a3[0u]){
t611=R___ink_differential_3(R___ink_differential_0(a3[1u+(t610)*11u+0u],a3[1u+(t610)*11u+1u]),R___ink_differential_0(a3[1u+(t610)*11u+2u],a3[1u+(t610)*11u+3u]),R___ink_differential_0(a3[1u+(t610)*11u+4u],a3[1u+(t610)*11u+5u]),R___ink_differential_0(a3[1u+(t610)*11u+6u],a3[1u+(t610)*11u+7u]),R___ink_differential_0(a3[1u+(t610)*11u+8u],a3[1u+(t610)*11u+9u]),a3[1u+(t610)*11u+10u]);}else{
var t612:u32=0u;
var t613:u32=0u;
var t614:R___ink_differential_0=R___ink_differential_0(t612,t613);
var t615:u32=0u;
var t616:u32=0u;
var t617:R___ink_differential_0=R___ink_differential_0(t615,t616);
var t618:u32=0u;
var t619:u32=0u;
var t620:R___ink_differential_0=R___ink_differential_0(t618,t619);
var t621:u32=1065353216u;
var t622:u32=0u;
var t623:R___ink_differential_0=R___ink_differential_0(t621,t622);
var t624:u32=1065353216u;
var t625:u32=0u;
var t626:R___ink_differential_0=R___ink_differential_0(t624,t625);
var t627:u32=0u;
t611=R___ink_differential_3(t614,t617,t620,t623,t626,t627);}
t609=(t611).ink_f_value;
}
var t628:R___ink_differential_0=t609;
var t629:u32=t602;
var t630:R___ink_differential_0;if(t629<a2[0u]){
t630=R___ink_differential_0(a2[1u+(t629)*2u+0u],a2[1u+(t629)*2u+1u]);}else{
var t631:u32=0u;
var t632:u32=0u;
t630=R___ink_differential_0(t631,t632);}
var t633:R___ink_differential_0=t630;
var t634:u32=(t628).ink_f_value;
var t635:u32=ink_f32_mul(t634,(t633).ink_f_value);
var t636:u32=t635;
var t637:u32=(t628).ink_f_tangent;
var t638:u32=ink_f32_mul(t637,(t633).ink_f_value);
var t639:u32=(t628).ink_f_value;
var t640:u32=ink_f32_add(t638,ink_f32_mul(t639,(t633).ink_f_tangent));
var t641:R___ink_differential_0=R___ink_differential_0(t636,t640);
var t642:u32=(t603).ink_f_value;
var t643:u32=ink_f32_add(t642,(t641).ink_f_value);
var t644:u32=t643;
var t645:u32=(t603).ink_f_tangent;
var t646:u32=ink_f32_add(t645,(t641).ink_f_tangent);
t601=R___ink_differential_0(t644,t646);
}
var t647:R___ink_differential_0=t601;
var t648:u32=(t647).ink_f_value;
var t649:u32=0u;
var t650:u32=0u;
var t651:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t649,t650)).ink_f_value,t648)) {
var t652:R___ink_differential_0=t572;
var t653:R___ink_differential_0=t647;
var t654:u32=(t652).ink_f_value;
var t655:u32=ink_f32_mul(t654,(t653).ink_f_value);
var t656:u32=t655;
var t657:u32=(t652).ink_f_tangent;
var t658:u32=ink_f32_mul(t657,(t653).ink_f_value);
var t659:u32=(t652).ink_f_value;
var t660:u32=ink_f32_add(t658,ink_f32_mul(t659,(t653).ink_f_tangent));
t651=R___ink_differential_0(t656,t660);
} else {
var t661:u32=0u;
var t662:u32=0u;
t651=R___ink_differential_0(t661,t662);
}
var t663:R___ink_differential_0=t651;
output[1u+i*2u+0u]=bitcast<u32>((t663).ink_f_value);
output[1u+i*2u+1u]=bitcast<u32>((t663).ink_f_tangent);

}
case 4u:{
var t664:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t665:u32=a1[0u+(0u)*1u+0u];
var t666:u32=188u;
var t667:R___ink_differential_0=t664;
var t668:u32=t665;
var t669:u32=t666;
var t670:u32=(t669 + 6u);
var t671:u32=t668;
var t672:R___ink_differential_0;
if ((t671 == t670)) {
t672=t667;
} else {
var t673:u32=t670;
var t674:R___ink_differential_3;if(t673<a3[0u]){
t674=R___ink_differential_3(R___ink_differential_0(a3[1u+(t673)*11u+0u],a3[1u+(t673)*11u+1u]),R___ink_differential_0(a3[1u+(t673)*11u+2u],a3[1u+(t673)*11u+3u]),R___ink_differential_0(a3[1u+(t673)*11u+4u],a3[1u+(t673)*11u+5u]),R___ink_differential_0(a3[1u+(t673)*11u+6u],a3[1u+(t673)*11u+7u]),R___ink_differential_0(a3[1u+(t673)*11u+8u],a3[1u+(t673)*11u+9u]),a3[1u+(t673)*11u+10u]);}else{
var t675:u32=0u;
var t676:u32=0u;
var t677:R___ink_differential_0=R___ink_differential_0(t675,t676);
var t678:u32=0u;
var t679:u32=0u;
var t680:R___ink_differential_0=R___ink_differential_0(t678,t679);
var t681:u32=0u;
var t682:u32=0u;
var t683:R___ink_differential_0=R___ink_differential_0(t681,t682);
var t684:u32=1065353216u;
var t685:u32=0u;
var t686:R___ink_differential_0=R___ink_differential_0(t684,t685);
var t687:u32=1065353216u;
var t688:u32=0u;
var t689:R___ink_differential_0=R___ink_differential_0(t687,t688);
var t690:u32=0u;
t674=R___ink_differential_3(t677,t680,t683,t686,t689,t690);}
t672=(t674).ink_f_value;
}
var t691:R___ink_differential_0=t672;
var t692:R___ink_differential_0=t691;
for(var t693=0u;t693<6u;t693++){
var t694:R___ink_differential_0=t692;
var t695:R___ink_differential_0=t664;
var t696:u32=t665;
var t697:u32=t666;
var t698:u32=(t697 + t693);
var t699:u32=t696;
var t700:R___ink_differential_0;
if ((t699 == t698)) {
t700=t695;
} else {
var t701:u32=t698;
var t702:R___ink_differential_3;if(t701<a3[0u]){
t702=R___ink_differential_3(R___ink_differential_0(a3[1u+(t701)*11u+0u],a3[1u+(t701)*11u+1u]),R___ink_differential_0(a3[1u+(t701)*11u+2u],a3[1u+(t701)*11u+3u]),R___ink_differential_0(a3[1u+(t701)*11u+4u],a3[1u+(t701)*11u+5u]),R___ink_differential_0(a3[1u+(t701)*11u+6u],a3[1u+(t701)*11u+7u]),R___ink_differential_0(a3[1u+(t701)*11u+8u],a3[1u+(t701)*11u+9u]),a3[1u+(t701)*11u+10u]);}else{
var t703:u32=0u;
var t704:u32=0u;
var t705:R___ink_differential_0=R___ink_differential_0(t703,t704);
var t706:u32=0u;
var t707:u32=0u;
var t708:R___ink_differential_0=R___ink_differential_0(t706,t707);
var t709:u32=0u;
var t710:u32=0u;
var t711:R___ink_differential_0=R___ink_differential_0(t709,t710);
var t712:u32=1065353216u;
var t713:u32=0u;
var t714:R___ink_differential_0=R___ink_differential_0(t712,t713);
var t715:u32=1065353216u;
var t716:u32=0u;
var t717:R___ink_differential_0=R___ink_differential_0(t715,t716);
var t718:u32=0u;
t702=R___ink_differential_3(t705,t708,t711,t714,t717,t718);}
t700=(t702).ink_f_value;
}
var t719:R___ink_differential_0=t700;
var t720:u32=t693;
var t721:R___ink_differential_0;if(t720<a2[0u]){
t721=R___ink_differential_0(a2[1u+(t720)*2u+0u],a2[1u+(t720)*2u+1u]);}else{
var t722:u32=0u;
var t723:u32=0u;
t721=R___ink_differential_0(t722,t723);}
var t724:R___ink_differential_0=t721;
var t725:u32=(t719).ink_f_value;
var t726:u32=ink_f32_mul(t725,(t724).ink_f_value);
var t727:u32=t726;
var t728:u32=(t719).ink_f_tangent;
var t729:u32=ink_f32_mul(t728,(t724).ink_f_value);
var t730:u32=(t719).ink_f_value;
var t731:u32=ink_f32_add(t729,ink_f32_mul(t730,(t724).ink_f_tangent));
var t732:R___ink_differential_0=R___ink_differential_0(t727,t731);
var t733:u32=(t694).ink_f_value;
var t734:u32=ink_f32_add(t733,(t732).ink_f_value);
var t735:u32=t734;
var t736:u32=(t694).ink_f_tangent;
var t737:u32=ink_f32_add(t736,(t732).ink_f_tangent);
t692=R___ink_differential_0(t735,t737);
}
var t738:R___ink_differential_0=t692;
var t739:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t740:u32=a1[0u+(0u)*1u+0u];
var t741:u32=195u;
var t742:R___ink_differential_0=t739;
var t743:u32=t740;
var t744:u32=t741;
var t745:u32=(t744 + 6u);
var t746:u32=t743;
var t747:R___ink_differential_0;
if ((t746 == t745)) {
t747=t742;
} else {
var t748:u32=t745;
var t749:R___ink_differential_3;if(t748<a3[0u]){
t749=R___ink_differential_3(R___ink_differential_0(a3[1u+(t748)*11u+0u],a3[1u+(t748)*11u+1u]),R___ink_differential_0(a3[1u+(t748)*11u+2u],a3[1u+(t748)*11u+3u]),R___ink_differential_0(a3[1u+(t748)*11u+4u],a3[1u+(t748)*11u+5u]),R___ink_differential_0(a3[1u+(t748)*11u+6u],a3[1u+(t748)*11u+7u]),R___ink_differential_0(a3[1u+(t748)*11u+8u],a3[1u+(t748)*11u+9u]),a3[1u+(t748)*11u+10u]);}else{
var t750:u32=0u;
var t751:u32=0u;
var t752:R___ink_differential_0=R___ink_differential_0(t750,t751);
var t753:u32=0u;
var t754:u32=0u;
var t755:R___ink_differential_0=R___ink_differential_0(t753,t754);
var t756:u32=0u;
var t757:u32=0u;
var t758:R___ink_differential_0=R___ink_differential_0(t756,t757);
var t759:u32=1065353216u;
var t760:u32=0u;
var t761:R___ink_differential_0=R___ink_differential_0(t759,t760);
var t762:u32=1065353216u;
var t763:u32=0u;
var t764:R___ink_differential_0=R___ink_differential_0(t762,t763);
var t765:u32=0u;
t749=R___ink_differential_3(t752,t755,t758,t761,t764,t765);}
t747=(t749).ink_f_value;
}
var t766:R___ink_differential_0=t747;
var t767:R___ink_differential_0=t766;
for(var t768=0u;t768<6u;t768++){
var t769:R___ink_differential_0=t767;
var t770:R___ink_differential_0=t739;
var t771:u32=t740;
var t772:u32=t741;
var t773:u32=(t772 + t768);
var t774:u32=t771;
var t775:R___ink_differential_0;
if ((t774 == t773)) {
t775=t770;
} else {
var t776:u32=t773;
var t777:R___ink_differential_3;if(t776<a3[0u]){
t777=R___ink_differential_3(R___ink_differential_0(a3[1u+(t776)*11u+0u],a3[1u+(t776)*11u+1u]),R___ink_differential_0(a3[1u+(t776)*11u+2u],a3[1u+(t776)*11u+3u]),R___ink_differential_0(a3[1u+(t776)*11u+4u],a3[1u+(t776)*11u+5u]),R___ink_differential_0(a3[1u+(t776)*11u+6u],a3[1u+(t776)*11u+7u]),R___ink_differential_0(a3[1u+(t776)*11u+8u],a3[1u+(t776)*11u+9u]),a3[1u+(t776)*11u+10u]);}else{
var t778:u32=0u;
var t779:u32=0u;
var t780:R___ink_differential_0=R___ink_differential_0(t778,t779);
var t781:u32=0u;
var t782:u32=0u;
var t783:R___ink_differential_0=R___ink_differential_0(t781,t782);
var t784:u32=0u;
var t785:u32=0u;
var t786:R___ink_differential_0=R___ink_differential_0(t784,t785);
var t787:u32=1065353216u;
var t788:u32=0u;
var t789:R___ink_differential_0=R___ink_differential_0(t787,t788);
var t790:u32=1065353216u;
var t791:u32=0u;
var t792:R___ink_differential_0=R___ink_differential_0(t790,t791);
var t793:u32=0u;
t777=R___ink_differential_3(t780,t783,t786,t789,t792,t793);}
t775=(t777).ink_f_value;
}
var t794:R___ink_differential_0=t775;
var t795:u32=t768;
var t796:R___ink_differential_0;if(t795<a2[0u]){
t796=R___ink_differential_0(a2[1u+(t795)*2u+0u],a2[1u+(t795)*2u+1u]);}else{
var t797:u32=0u;
var t798:u32=0u;
t796=R___ink_differential_0(t797,t798);}
var t799:R___ink_differential_0=t796;
var t800:u32=(t794).ink_f_value;
var t801:u32=ink_f32_mul(t800,(t799).ink_f_value);
var t802:u32=t801;
var t803:u32=(t794).ink_f_tangent;
var t804:u32=ink_f32_mul(t803,(t799).ink_f_value);
var t805:u32=(t794).ink_f_value;
var t806:u32=ink_f32_add(t804,ink_f32_mul(t805,(t799).ink_f_tangent));
var t807:R___ink_differential_0=R___ink_differential_0(t802,t806);
var t808:u32=(t769).ink_f_value;
var t809:u32=ink_f32_add(t808,(t807).ink_f_value);
var t810:u32=t809;
var t811:u32=(t769).ink_f_tangent;
var t812:u32=ink_f32_add(t811,(t807).ink_f_tangent);
t767=R___ink_differential_0(t810,t812);
}
var t813:R___ink_differential_0=t767;
var t814:u32=(t813).ink_f_value;
var t815:u32=0u;
var t816:u32=0u;
var t817:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t815,t816)).ink_f_value,t814)) {
var t818:R___ink_differential_0=t738;
var t819:R___ink_differential_0=t813;
var t820:u32=(t818).ink_f_value;
var t821:u32=ink_f32_mul(t820,(t819).ink_f_value);
var t822:u32=t821;
var t823:u32=(t818).ink_f_tangent;
var t824:u32=ink_f32_mul(t823,(t819).ink_f_value);
var t825:u32=(t818).ink_f_value;
var t826:u32=ink_f32_add(t824,ink_f32_mul(t825,(t819).ink_f_tangent));
t817=R___ink_differential_0(t822,t826);
} else {
var t827:u32=0u;
var t828:u32=0u;
t817=R___ink_differential_0(t827,t828);
}
var t829:R___ink_differential_0=t817;
output[1u+i*2u+0u]=bitcast<u32>((t829).ink_f_value);
output[1u+i*2u+1u]=bitcast<u32>((t829).ink_f_tangent);

}
case 5u:{
var t830:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t831:u32=a1[0u+(0u)*1u+0u];
var t832:u32=202u;
var t833:R___ink_differential_0=t830;
var t834:u32=t831;
var t835:u32=t832;
var t836:u32=(t835 + 6u);
var t837:u32=t834;
var t838:R___ink_differential_0;
if ((t837 == t836)) {
t838=t833;
} else {
var t839:u32=t836;
var t840:R___ink_differential_3;if(t839<a3[0u]){
t840=R___ink_differential_3(R___ink_differential_0(a3[1u+(t839)*11u+0u],a3[1u+(t839)*11u+1u]),R___ink_differential_0(a3[1u+(t839)*11u+2u],a3[1u+(t839)*11u+3u]),R___ink_differential_0(a3[1u+(t839)*11u+4u],a3[1u+(t839)*11u+5u]),R___ink_differential_0(a3[1u+(t839)*11u+6u],a3[1u+(t839)*11u+7u]),R___ink_differential_0(a3[1u+(t839)*11u+8u],a3[1u+(t839)*11u+9u]),a3[1u+(t839)*11u+10u]);}else{
var t841:u32=0u;
var t842:u32=0u;
var t843:R___ink_differential_0=R___ink_differential_0(t841,t842);
var t844:u32=0u;
var t845:u32=0u;
var t846:R___ink_differential_0=R___ink_differential_0(t844,t845);
var t847:u32=0u;
var t848:u32=0u;
var t849:R___ink_differential_0=R___ink_differential_0(t847,t848);
var t850:u32=1065353216u;
var t851:u32=0u;
var t852:R___ink_differential_0=R___ink_differential_0(t850,t851);
var t853:u32=1065353216u;
var t854:u32=0u;
var t855:R___ink_differential_0=R___ink_differential_0(t853,t854);
var t856:u32=0u;
t840=R___ink_differential_3(t843,t846,t849,t852,t855,t856);}
t838=(t840).ink_f_value;
}
var t857:R___ink_differential_0=t838;
var t858:R___ink_differential_0=t857;
for(var t859=0u;t859<6u;t859++){
var t860:R___ink_differential_0=t858;
var t861:R___ink_differential_0=t830;
var t862:u32=t831;
var t863:u32=t832;
var t864:u32=(t863 + t859);
var t865:u32=t862;
var t866:R___ink_differential_0;
if ((t865 == t864)) {
t866=t861;
} else {
var t867:u32=t864;
var t868:R___ink_differential_3;if(t867<a3[0u]){
t868=R___ink_differential_3(R___ink_differential_0(a3[1u+(t867)*11u+0u],a3[1u+(t867)*11u+1u]),R___ink_differential_0(a3[1u+(t867)*11u+2u],a3[1u+(t867)*11u+3u]),R___ink_differential_0(a3[1u+(t867)*11u+4u],a3[1u+(t867)*11u+5u]),R___ink_differential_0(a3[1u+(t867)*11u+6u],a3[1u+(t867)*11u+7u]),R___ink_differential_0(a3[1u+(t867)*11u+8u],a3[1u+(t867)*11u+9u]),a3[1u+(t867)*11u+10u]);}else{
var t869:u32=0u;
var t870:u32=0u;
var t871:R___ink_differential_0=R___ink_differential_0(t869,t870);
var t872:u32=0u;
var t873:u32=0u;
var t874:R___ink_differential_0=R___ink_differential_0(t872,t873);
var t875:u32=0u;
var t876:u32=0u;
var t877:R___ink_differential_0=R___ink_differential_0(t875,t876);
var t878:u32=1065353216u;
var t879:u32=0u;
var t880:R___ink_differential_0=R___ink_differential_0(t878,t879);
var t881:u32=1065353216u;
var t882:u32=0u;
var t883:R___ink_differential_0=R___ink_differential_0(t881,t882);
var t884:u32=0u;
t868=R___ink_differential_3(t871,t874,t877,t880,t883,t884);}
t866=(t868).ink_f_value;
}
var t885:R___ink_differential_0=t866;
var t886:u32=t859;
var t887:R___ink_differential_0;if(t886<a2[0u]){
t887=R___ink_differential_0(a2[1u+(t886)*2u+0u],a2[1u+(t886)*2u+1u]);}else{
var t888:u32=0u;
var t889:u32=0u;
t887=R___ink_differential_0(t888,t889);}
var t890:R___ink_differential_0=t887;
var t891:u32=(t885).ink_f_value;
var t892:u32=ink_f32_mul(t891,(t890).ink_f_value);
var t893:u32=t892;
var t894:u32=(t885).ink_f_tangent;
var t895:u32=ink_f32_mul(t894,(t890).ink_f_value);
var t896:u32=(t885).ink_f_value;
var t897:u32=ink_f32_add(t895,ink_f32_mul(t896,(t890).ink_f_tangent));
var t898:R___ink_differential_0=R___ink_differential_0(t893,t897);
var t899:u32=(t860).ink_f_value;
var t900:u32=ink_f32_add(t899,(t898).ink_f_value);
var t901:u32=t900;
var t902:u32=(t860).ink_f_tangent;
var t903:u32=ink_f32_add(t902,(t898).ink_f_tangent);
t858=R___ink_differential_0(t901,t903);
}
var t904:R___ink_differential_0=t858;
var t905:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t906:u32=a1[0u+(0u)*1u+0u];
var t907:u32=209u;
var t908:R___ink_differential_0=t905;
var t909:u32=t906;
var t910:u32=t907;
var t911:u32=(t910 + 6u);
var t912:u32=t909;
var t913:R___ink_differential_0;
if ((t912 == t911)) {
t913=t908;
} else {
var t914:u32=t911;
var t915:R___ink_differential_3;if(t914<a3[0u]){
t915=R___ink_differential_3(R___ink_differential_0(a3[1u+(t914)*11u+0u],a3[1u+(t914)*11u+1u]),R___ink_differential_0(a3[1u+(t914)*11u+2u],a3[1u+(t914)*11u+3u]),R___ink_differential_0(a3[1u+(t914)*11u+4u],a3[1u+(t914)*11u+5u]),R___ink_differential_0(a3[1u+(t914)*11u+6u],a3[1u+(t914)*11u+7u]),R___ink_differential_0(a3[1u+(t914)*11u+8u],a3[1u+(t914)*11u+9u]),a3[1u+(t914)*11u+10u]);}else{
var t916:u32=0u;
var t917:u32=0u;
var t918:R___ink_differential_0=R___ink_differential_0(t916,t917);
var t919:u32=0u;
var t920:u32=0u;
var t921:R___ink_differential_0=R___ink_differential_0(t919,t920);
var t922:u32=0u;
var t923:u32=0u;
var t924:R___ink_differential_0=R___ink_differential_0(t922,t923);
var t925:u32=1065353216u;
var t926:u32=0u;
var t927:R___ink_differential_0=R___ink_differential_0(t925,t926);
var t928:u32=1065353216u;
var t929:u32=0u;
var t930:R___ink_differential_0=R___ink_differential_0(t928,t929);
var t931:u32=0u;
t915=R___ink_differential_3(t918,t921,t924,t927,t930,t931);}
t913=(t915).ink_f_value;
}
var t932:R___ink_differential_0=t913;
var t933:R___ink_differential_0=t932;
for(var t934=0u;t934<6u;t934++){
var t935:R___ink_differential_0=t933;
var t936:R___ink_differential_0=t905;
var t937:u32=t906;
var t938:u32=t907;
var t939:u32=(t938 + t934);
var t940:u32=t937;
var t941:R___ink_differential_0;
if ((t940 == t939)) {
t941=t936;
} else {
var t942:u32=t939;
var t943:R___ink_differential_3;if(t942<a3[0u]){
t943=R___ink_differential_3(R___ink_differential_0(a3[1u+(t942)*11u+0u],a3[1u+(t942)*11u+1u]),R___ink_differential_0(a3[1u+(t942)*11u+2u],a3[1u+(t942)*11u+3u]),R___ink_differential_0(a3[1u+(t942)*11u+4u],a3[1u+(t942)*11u+5u]),R___ink_differential_0(a3[1u+(t942)*11u+6u],a3[1u+(t942)*11u+7u]),R___ink_differential_0(a3[1u+(t942)*11u+8u],a3[1u+(t942)*11u+9u]),a3[1u+(t942)*11u+10u]);}else{
var t944:u32=0u;
var t945:u32=0u;
var t946:R___ink_differential_0=R___ink_differential_0(t944,t945);
var t947:u32=0u;
var t948:u32=0u;
var t949:R___ink_differential_0=R___ink_differential_0(t947,t948);
var t950:u32=0u;
var t951:u32=0u;
var t952:R___ink_differential_0=R___ink_differential_0(t950,t951);
var t953:u32=1065353216u;
var t954:u32=0u;
var t955:R___ink_differential_0=R___ink_differential_0(t953,t954);
var t956:u32=1065353216u;
var t957:u32=0u;
var t958:R___ink_differential_0=R___ink_differential_0(t956,t957);
var t959:u32=0u;
t943=R___ink_differential_3(t946,t949,t952,t955,t958,t959);}
t941=(t943).ink_f_value;
}
var t960:R___ink_differential_0=t941;
var t961:u32=t934;
var t962:R___ink_differential_0;if(t961<a2[0u]){
t962=R___ink_differential_0(a2[1u+(t961)*2u+0u],a2[1u+(t961)*2u+1u]);}else{
var t963:u32=0u;
var t964:u32=0u;
t962=R___ink_differential_0(t963,t964);}
var t965:R___ink_differential_0=t962;
var t966:u32=(t960).ink_f_value;
var t967:u32=ink_f32_mul(t966,(t965).ink_f_value);
var t968:u32=t967;
var t969:u32=(t960).ink_f_tangent;
var t970:u32=ink_f32_mul(t969,(t965).ink_f_value);
var t971:u32=(t960).ink_f_value;
var t972:u32=ink_f32_add(t970,ink_f32_mul(t971,(t965).ink_f_tangent));
var t973:R___ink_differential_0=R___ink_differential_0(t968,t972);
var t974:u32=(t935).ink_f_value;
var t975:u32=ink_f32_add(t974,(t973).ink_f_value);
var t976:u32=t975;
var t977:u32=(t935).ink_f_tangent;
var t978:u32=ink_f32_add(t977,(t973).ink_f_tangent);
t933=R___ink_differential_0(t976,t978);
}
var t979:R___ink_differential_0=t933;
var t980:u32=(t979).ink_f_value;
var t981:u32=0u;
var t982:u32=0u;
var t983:R___ink_differential_0;
if (ink_f32_lt((R___ink_differential_0(t981,t982)).ink_f_value,t980)) {
var t984:R___ink_differential_0=t904;
var t985:R___ink_differential_0=t979;
var t986:u32=(t984).ink_f_value;
var t987:u32=ink_f32_mul(t986,(t985).ink_f_value);
var t988:u32=t987;
var t989:u32=(t984).ink_f_tangent;
var t990:u32=ink_f32_mul(t989,(t985).ink_f_value);
var t991:u32=(t984).ink_f_value;
var t992:u32=ink_f32_add(t990,ink_f32_mul(t991,(t985).ink_f_tangent));
t983=R___ink_differential_0(t988,t992);
} else {
var t993:u32=0u;
var t994:u32=0u;
t983=R___ink_differential_0(t993,t994);
}
var t995:R___ink_differential_0=t983;
output[1u+i*2u+0u]=bitcast<u32>((t995).ink_f_value);
output[1u+i*2u+1u]=bitcast<u32>((t995).ink_f_tangent);

}
default:{} }

}
}