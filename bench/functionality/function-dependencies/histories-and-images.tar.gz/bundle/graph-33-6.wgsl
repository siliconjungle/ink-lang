// Exact wrapping u64 over two storage lanes. No floating point intermediates.
struct InkU64 {lo:u32,hi:u32,}
struct InkDiv64 {quotient:InkU64,remainder:InkU64,}
fn ink_u64_shl(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64(a.lo<<k,(a.hi<<k)|(a.lo>>(32u-k)));}return InkU64(0u,a.lo<<(k-32u));}
fn ink_u64_shr(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64((a.lo>>k)|(a.hi<<(32u-k)),a.hi>>k);}return InkU64(a.hi>>(k-32u),0u);}
fn ink_u64_rol(a:InkU64,count:u32)->InkU64{let k=count&63u;let l=ink_u64_shl(a,k);let r=ink_u64_shr(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_ror(a:InkU64,count:u32)->InkU64{let k=count&63u;let r=ink_u64_shr(a,k);let l=ink_u64_shl(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_eq(a:InkU64,b:InkU64)->bool{return a.lo==b.lo&&a.hi==b.hi;}
fn ink_u64_lt(a:InkU64,b:InkU64)->bool{return a.hi<b.hi||(a.hi==b.hi&&a.lo<b.lo);}
fn ink_u64_add(a:InkU64,b:InkU64)->InkU64{let lo=a.lo+b.lo;return InkU64(lo,a.hi+b.hi+select(0u,1u,lo<a.lo));}
fn ink_u64_sub(a:InkU64,b:InkU64)->InkU64{return InkU64(a.lo-b.lo,a.hi-b.hi-select(0u,1u,a.lo<b.lo));}
fn ink_u64_mul(a:InkU64,b:InkU64)->InkU64{let al=a.lo&65535u;let ah=a.lo>>16u;let bl=b.lo&65535u;let bh=b.lo>>16u;let p=al*bl;let x=ah*bl;let y=al*bh;let mid=(p>>16u)+(x&65535u)+(y&65535u);let high=ah*bh+(x>>16u)+(y>>16u)+(mid>>16u);return InkU64((mid<<16u)|(p&65535u),high+a.lo*b.hi+a.hi*b.lo);}
fn ink_u64_div(a:InkU64,b:InkU64)->InkDiv64{var q=InkU64(0u,0u);var r=InkU64(0u,0u);var cursor=64u;loop{if(cursor==0u){break;}cursor--;var bit=0u;if(cursor>=32u){bit=(a.hi>>(cursor-32u))&1u;}else{bit=(a.lo>>cursor)&1u;}let overflow=r.hi>>31u;r=InkU64((r.lo<<1u)|bit,(r.hi<<1u)|(r.lo>>31u));if(overflow!=0u||!ink_u64_lt(r,b)){r=ink_u64_sub(r,b);if(cursor>=32u){q.hi|=1u<<(cursor-32u);}else{q.lo|=1u<<cursor;}}}return InkDiv64(q,r);}
// Binary32 evaluated with integer lanes: round-to-nearest, ties-to-even,
// gradual underflow, signed zero and canonical arithmetic NaN.
fn ink_f32_nan(x:u32)->bool{return (x&0x7fffffffu)>0x7f800000u;}
fn ink_f32_eq(a:u32,b:u32)->bool{return !ink_f32_nan(a)&&!ink_f32_nan(b)&&(a==b||((a|b)&0x7fffffffu)==0u);}
fn ink_f32_lt(a:u32,b:u32)->bool{
 if(ink_f32_nan(a)||ink_f32_nan(b)||ink_f32_eq(a,b)){return false;}
 if((a^b)&0x80000000u)!=0u{return (a&0x80000000u)!=0u;}
 if((a&0x80000000u)!=0u){return a>b;}return a<b;
}
fn ink_f32_jam(x:u32,n:u32)->u32{if(n==0u){return x;}if(n>=32u){return select(0u,1u,x!=0u);}return (x>>n)|select(0u,1u,(x&((1u<<n)-1u))!=0u);}
fn ink_f32_round(sign:u32,exponent:i32,extended:u32)->u32{
 var e=exponent;var s=extended;
 if(e<1i){s=ink_f32_jam(s,u32(1i-e));e=1i;}
 let tail=s&7u;var sig=s>>3u;
 if(tail>4u||(tail==4u&&(sig&1u)!=0u)){sig++;}
 if(sig>=0x1000000u){sig>>=1u;e++;}
 if(e>=255i){return sign|0x7f800000u;}
 if(sig==0u){return sign;}
 let raw=select(u32(e),0u,e==1i&&sig<0x800000u);
 return sign|(raw<<23u)|(sig&0x7fffffu);
}
fn ink_f32_add(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 var x=a;var y=b;if((x&0x7fffffffu)<(y&0x7fffffffu)){x=b;y=a;}
 let ax=x&0x7fffffffu;let ay=y&0x7fffffffu;let sign=x&0x80000000u;
 if(ax==0x7f800000u){if(ay==ax&&((x^y)&0x80000000u)!=0u){return 0x7fc00000u;}return x;}
 let rx=(x>>23u)&255u;let ry=(y>>23u)&255u;var e=i32(max(rx,1u));
 var sx=((x&0x7fffffu)|select(0u,0x800000u,rx!=0u))<<3u;
 let sy=ink_f32_jam(((y&0x7fffffu)|select(0u,0x800000u,ry!=0u))<<3u,u32(e)-max(ry,1u));
 if(((x^y)&0x80000000u)==0u){sx+=sy;if(sx>=0x8000000u){sx=ink_f32_jam(sx,1u);e++;}}
 else{sx-=sy;if(sx==0u){return 0u;}loop{if(sx>=0x4000000u||e<=1i){break;}sx<<=1u;e--;}}
 return ink_f32_round(sign,e,sx);
}
fn ink_f32_sub(a:u32,b:u32)->u32{return ink_f32_add(a,b^0x80000000u);}
fn ink_f32_mul(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(aa==0x7f800000u||bb==0x7f800000u){if(aa==0u||bb==0u){return 0x7fc00000u;}return sign|0x7f800000u;}
 if(aa==0u||bb==0u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u));var eb=i32(max(rb,1u));
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 let product=ink_u64_mul(InkU64(sa,0u),InkU64(sb,0u));let high=(product.hi&0x8000u)!=0u;
 let shift=select(20u,21u,high);let extended=(product.lo>>shift)|(product.hi<<(32u-shift))|select(0u,1u,(product.lo&((1u<<shift)-1u))!=0u);
 return ink_f32_round(sign,ea+eb-127i+select(0i,1i,high),extended);
}
// Exact sqrt and division use integer significands, independent of WGSL float
// approximation allowances and device flush-to-zero behavior.
fn ink_f32_sqrt(x:u32)->u32{
 let a=x&0x7fffffffu;if(a==0u){return x;}
 if(a>0x7f800000u||(x&0x80000000u)!=0u){return 0x7fc00000u;}
 if(a==0x7f800000u){return x;}
 let raw=(x>>23u)&255u;var m=(x&0x7fffffu)|select(0u,0x800000u,raw!=0u);var e=i32(max(raw,1u))-127i;
 loop{if(m>=0x800000u){break;}m<<=1u;e--;}
 let odd=e&1i;var half=(e-odd)/2i;let shift=23u+u32(odd);
 let n=InkU64(m<<shift,m>>(32u-shift));var lo=0u;var hi=0x1000000u;
 loop{if(lo+1u>=hi){break;}let mid=(lo+hi)>>1u;let sq=ink_u64_mul(InkU64(mid,0u),InkU64(mid,0u));if(!ink_u64_lt(n,sq)){lo=mid;}else{hi=mid;}}
 let sq=ink_u64_mul(InkU64(lo,0u),InkU64(lo,0u));let rem=ink_u64_sub(n,sq);
 if(ink_u64_lt(InkU64(lo,0u),rem)){lo++;}
 if(lo==0x1000000u){lo>>=1u;half++;}
 return (u32(half+127i)<<23u)|(lo&0x7fffffu);
}
fn ink_f32_div(a:u32,b:u32)->u32{
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(ink_f32_nan(a)||ink_f32_nan(b)||(aa==0u&&bb==0u)||(aa==0x7f800000u&&bb==aa)){return 0x7fc00000u;}
 if(aa==0x7f800000u||bb==0u){return sign|0x7f800000u;}
 if(aa==0u||bb==0x7f800000u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u))-127i;var eb=i32(max(rb,1u))-127i;
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 var e=ea-eb;if(sa<sb){sa<<=1u;e--;}
 let division=ink_u64_div(InkU64(sa<<26u,sa>>6u),InkU64(sb,0u));
 let extended=division.quotient.lo|select(0u,1u,!ink_u64_eq(division.remainder,InkU64(0u,0u)));
 return ink_f32_round(sign,e+127i,extended);
}
// mode: 0 trunc, 1 floor, 2 ceil, 3 ties-to-even.
fn ink_f32_integral(x:u32,mode:u32)->u32{
 let a=x&0x7fffffffu;let sign=x&0x80000000u;
 if(a>0x7f800000u){return 0x7fc00000u;}if(a>=0x4b000000u||a==0u){return x;}
 let e=i32((x>>23u)&255u)-127i;
 if(e<0i){var up=false;if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){up=a>0x3f000000u;}return sign|select(0u,0x3f800000u,up);}
 let shift=u32(23i-e);let mask=(1u<<shift)-1u;let fraction=a&mask;var rounded=a&~mask;var up=false;
 if(fraction!=0u){if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){let half=1u<<(shift-1u);up=fraction>half||(fraction==half&&((rounded>>shift)&1u)!=0u);}}
 if(up){rounded+=1u<<shift;}return sign|rounded;
}
fn ink_f32_from_u64(x:InkU64)->u32{
 if(ink_u64_eq(x,InkU64(0u,0u))){return 0u;}
 let leading=select(countLeadingZeros(x.lo)+32u,countLeadingZeros(x.hi),x.hi!=0u);let e=63u-leading;
 if(e<=23u){return ((e+127u)<<23u)|((x.lo<<(23u-e))&0x7fffffu);}
 let shift=e-23u;var sig=0u;var rem=InkU64(0u,0u);var half=InkU64(0u,0u);
 if(shift<32u){sig=(x.lo>>shift)|(x.hi<<(32u-shift));rem=InkU64(x.lo&((1u<<shift)-1u),0u);half=InkU64(1u<<(shift-1u),0u);}
 else if(shift==32u){sig=x.hi;rem=InkU64(x.lo,0u);half=InkU64(0x80000000u,0u);}
 else{sig=x.hi>>(shift-32u);rem=InkU64(x.lo,x.hi&((1u<<(shift-32u))-1u));half=InkU64(0u,1u<<(shift-33u));}
 if(ink_u64_lt(half,rem)||(ink_u64_eq(rem,half)&&(sig&1u)!=0u)){sig++;}
 var exponent=e+127u;if(sig==0x1000000u){sig>>=1u;exponent++;}
 return (exponent<<23u)|(sig&0x7fffffu);
}
fn ink_f32_from_i32(x:i32)->u32{let neg=x<0i;let magnitude=select(u32(x),0u-u32(x),neg);return ink_f32_from_u64(InkU64(magnitude,0u))|select(0u,0x80000000u,neg);}
struct InkBuffer_u32{data:array<u32,64>,length:u32,}
struct InkBuffer_InkU64{data:array<InkU64,64>,length:u32,}
struct InkBuffer_i32{data:array<i32,64>,length:u32,}
struct InkBuffer_bool{data:array<bool,64>,length:u32,}
struct R_Parameter{ink_f_value:u32,ink_f_first:u32,ink_f_second:u32,ink_f_first_power:u32,ink_f_second_power:u32,ink_f_steps:u32,}
struct R___ink_differential_0{ink_f_value:u32,ink_f_tangent:u32,}
struct R___ink_differential_3{ink_f_value:R___ink_differential_0,ink_f_first:R___ink_differential_0,ink_f_second:R___ink_differential_0,ink_f_first_power:R___ink_differential_0,ink_f_second_power:R___ink_differential_0,ink_f_steps:u32,}
@group(0) @binding(0) var<storage,read> a0:array<u32>;
@group(0) @binding(1) var<storage,read> a1:array<u32>;
@group(0) @binding(2) var<storage,read> a2:array<u32>;
@group(0) @binding(3) var<storage,read> a3:array<u32>;
@group(0) @binding(4) var<storage,read_write> output:array<u32>;
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) gid:vec3<u32>){
let size=4u;let i=gid.x;if(i==0u){output[0]=size;}if(i<size){
switch(i){
case 0u:{
var t0:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t1:u32=a1[0u+(0u)*1u+0u];
var t2:u32=216u;
var t3:R___ink_differential_0=t0;
var t4:u32=t1;
var t5:u32=t2;
var t6:u32=(t5 + 6u);
var t7:u32=t4;
var t8:R___ink_differential_0;
if ((t7 == t6)) {
t8=t3;
} else {
var t9:u32=t6;
var t10:R___ink_differential_3;if(t9<a2[0u]){
t10=R___ink_differential_3(R___ink_differential_0(a2[1u+(t9)*11u+0u],a2[1u+(t9)*11u+1u]),R___ink_differential_0(a2[1u+(t9)*11u+2u],a2[1u+(t9)*11u+3u]),R___ink_differential_0(a2[1u+(t9)*11u+4u],a2[1u+(t9)*11u+5u]),R___ink_differential_0(a2[1u+(t9)*11u+6u],a2[1u+(t9)*11u+7u]),R___ink_differential_0(a2[1u+(t9)*11u+8u],a2[1u+(t9)*11u+9u]),a2[1u+(t9)*11u+10u]);}else{
var t11:u32=0u;
var t12:u32=0u;
var t13:R___ink_differential_0=R___ink_differential_0(t11,t12);
var t14:u32=0u;
var t15:u32=0u;
var t16:R___ink_differential_0=R___ink_differential_0(t14,t15);
var t17:u32=0u;
var t18:u32=0u;
var t19:R___ink_differential_0=R___ink_differential_0(t17,t18);
var t20:u32=1065353216u;
var t21:u32=0u;
var t22:R___ink_differential_0=R___ink_differential_0(t20,t21);
var t23:u32=1065353216u;
var t24:u32=0u;
var t25:R___ink_differential_0=R___ink_differential_0(t23,t24);
var t26:u32=0u;
t10=R___ink_differential_3(t13,t16,t19,t22,t25,t26);}
t8=(t10).ink_f_value;
}
var t27:R___ink_differential_0=t8;
var t28:R___ink_differential_0=t27;
for(var t29=0u;t29<6u;t29++){
var t30:R___ink_differential_0=t28;
var t31:R___ink_differential_0=t0;
var t32:u32=t1;
var t33:u32=t2;
var t34:u32=(t33 + t29);
var t35:u32=t32;
var t36:R___ink_differential_0;
if ((t35 == t34)) {
t36=t31;
} else {
var t37:u32=t34;
var t38:R___ink_differential_3;if(t37<a2[0u]){
t38=R___ink_differential_3(R___ink_differential_0(a2[1u+(t37)*11u+0u],a2[1u+(t37)*11u+1u]),R___ink_differential_0(a2[1u+(t37)*11u+2u],a2[1u+(t37)*11u+3u]),R___ink_differential_0(a2[1u+(t37)*11u+4u],a2[1u+(t37)*11u+5u]),R___ink_differential_0(a2[1u+(t37)*11u+6u],a2[1u+(t37)*11u+7u]),R___ink_differential_0(a2[1u+(t37)*11u+8u],a2[1u+(t37)*11u+9u]),a2[1u+(t37)*11u+10u]);}else{
var t39:u32=0u;
var t40:u32=0u;
var t41:R___ink_differential_0=R___ink_differential_0(t39,t40);
var t42:u32=0u;
var t43:u32=0u;
var t44:R___ink_differential_0=R___ink_differential_0(t42,t43);
var t45:u32=0u;
var t46:u32=0u;
var t47:R___ink_differential_0=R___ink_differential_0(t45,t46);
var t48:u32=1065353216u;
var t49:u32=0u;
var t50:R___ink_differential_0=R___ink_differential_0(t48,t49);
var t51:u32=1065353216u;
var t52:u32=0u;
var t53:R___ink_differential_0=R___ink_differential_0(t51,t52);
var t54:u32=0u;
t38=R___ink_differential_3(t41,t44,t47,t50,t53,t54);}
t36=(t38).ink_f_value;
}
var t55:R___ink_differential_0=t36;
var t56:u32=t29;
var t57:R___ink_differential_0;if(t56<a3[0u]){
t57=R___ink_differential_0(a3[1u+(t56)*2u+0u],a3[1u+(t56)*2u+1u]);}else{
var t58:u32=0u;
var t59:u32=0u;
t57=R___ink_differential_0(t58,t59);}
var t60:R___ink_differential_0=t57;
var t61:u32=(t55).ink_f_value;
var t62:u32=ink_f32_mul(t61,(t60).ink_f_value);
var t63:u32=t62;
var t64:u32=(t55).ink_f_tangent;
var t65:u32=ink_f32_mul(t64,(t60).ink_f_value);
var t66:u32=(t55).ink_f_value;
var t67:u32=ink_f32_add(t65,ink_f32_mul(t66,(t60).ink_f_tangent));
var t68:R___ink_differential_0=R___ink_differential_0(t63,t67);
var t69:u32=(t30).ink_f_value;
var t70:u32=ink_f32_add(t69,(t68).ink_f_value);
var t71:u32=t70;
var t72:u32=(t30).ink_f_tangent;
var t73:u32=ink_f32_add(t72,(t68).ink_f_tangent);
t28=R___ink_differential_0(t71,t73);
}
var t74:R___ink_differential_0=t28;
output[1u+i*2u+0u]=bitcast<u32>((t74).ink_f_value);
output[1u+i*2u+1u]=bitcast<u32>((t74).ink_f_tangent);

}
case 1u:{
var t75:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t76:u32=a1[0u+(0u)*1u+0u];
var t77:u32=223u;
var t78:R___ink_differential_0=t75;
var t79:u32=t76;
var t80:u32=t77;
var t81:u32=(t80 + 6u);
var t82:u32=t79;
var t83:R___ink_differential_0;
if ((t82 == t81)) {
t83=t78;
} else {
var t84:u32=t81;
var t85:R___ink_differential_3;if(t84<a2[0u]){
t85=R___ink_differential_3(R___ink_differential_0(a2[1u+(t84)*11u+0u],a2[1u+(t84)*11u+1u]),R___ink_differential_0(a2[1u+(t84)*11u+2u],a2[1u+(t84)*11u+3u]),R___ink_differential_0(a2[1u+(t84)*11u+4u],a2[1u+(t84)*11u+5u]),R___ink_differential_0(a2[1u+(t84)*11u+6u],a2[1u+(t84)*11u+7u]),R___ink_differential_0(a2[1u+(t84)*11u+8u],a2[1u+(t84)*11u+9u]),a2[1u+(t84)*11u+10u]);}else{
var t86:u32=0u;
var t87:u32=0u;
var t88:R___ink_differential_0=R___ink_differential_0(t86,t87);
var t89:u32=0u;
var t90:u32=0u;
var t91:R___ink_differential_0=R___ink_differential_0(t89,t90);
var t92:u32=0u;
var t93:u32=0u;
var t94:R___ink_differential_0=R___ink_differential_0(t92,t93);
var t95:u32=1065353216u;
var t96:u32=0u;
var t97:R___ink_differential_0=R___ink_differential_0(t95,t96);
var t98:u32=1065353216u;
var t99:u32=0u;
var t100:R___ink_differential_0=R___ink_differential_0(t98,t99);
var t101:u32=0u;
t85=R___ink_differential_3(t88,t91,t94,t97,t100,t101);}
t83=(t85).ink_f_value;
}
var t102:R___ink_differential_0=t83;
var t103:R___ink_differential_0=t102;
for(var t104=0u;t104<6u;t104++){
var t105:R___ink_differential_0=t103;
var t106:R___ink_differential_0=t75;
var t107:u32=t76;
var t108:u32=t77;
var t109:u32=(t108 + t104);
var t110:u32=t107;
var t111:R___ink_differential_0;
if ((t110 == t109)) {
t111=t106;
} else {
var t112:u32=t109;
var t113:R___ink_differential_3;if(t112<a2[0u]){
t113=R___ink_differential_3(R___ink_differential_0(a2[1u+(t112)*11u+0u],a2[1u+(t112)*11u+1u]),R___ink_differential_0(a2[1u+(t112)*11u+2u],a2[1u+(t112)*11u+3u]),R___ink_differential_0(a2[1u+(t112)*11u+4u],a2[1u+(t112)*11u+5u]),R___ink_differential_0(a2[1u+(t112)*11u+6u],a2[1u+(t112)*11u+7u]),R___ink_differential_0(a2[1u+(t112)*11u+8u],a2[1u+(t112)*11u+9u]),a2[1u+(t112)*11u+10u]);}else{
var t114:u32=0u;
var t115:u32=0u;
var t116:R___ink_differential_0=R___ink_differential_0(t114,t115);
var t117:u32=0u;
var t118:u32=0u;
var t119:R___ink_differential_0=R___ink_differential_0(t117,t118);
var t120:u32=0u;
var t121:u32=0u;
var t122:R___ink_differential_0=R___ink_differential_0(t120,t121);
var t123:u32=1065353216u;
var t124:u32=0u;
var t125:R___ink_differential_0=R___ink_differential_0(t123,t124);
var t126:u32=1065353216u;
var t127:u32=0u;
var t128:R___ink_differential_0=R___ink_differential_0(t126,t127);
var t129:u32=0u;
t113=R___ink_differential_3(t116,t119,t122,t125,t128,t129);}
t111=(t113).ink_f_value;
}
var t130:R___ink_differential_0=t111;
var t131:u32=t104;
var t132:R___ink_differential_0;if(t131<a3[0u]){
t132=R___ink_differential_0(a3[1u+(t131)*2u+0u],a3[1u+(t131)*2u+1u]);}else{
var t133:u32=0u;
var t134:u32=0u;
t132=R___ink_differential_0(t133,t134);}
var t135:R___ink_differential_0=t132;
var t136:u32=(t130).ink_f_value;
var t137:u32=ink_f32_mul(t136,(t135).ink_f_value);
var t138:u32=t137;
var t139:u32=(t130).ink_f_tangent;
var t140:u32=ink_f32_mul(t139,(t135).ink_f_value);
var t141:u32=(t130).ink_f_value;
var t142:u32=ink_f32_add(t140,ink_f32_mul(t141,(t135).ink_f_tangent));
var t143:R___ink_differential_0=R___ink_differential_0(t138,t142);
var t144:u32=(t105).ink_f_value;
var t145:u32=ink_f32_add(t144,(t143).ink_f_value);
var t146:u32=t145;
var t147:u32=(t105).ink_f_tangent;
var t148:u32=ink_f32_add(t147,(t143).ink_f_tangent);
t103=R___ink_differential_0(t146,t148);
}
var t149:R___ink_differential_0=t103;
output[1u+i*2u+0u]=bitcast<u32>((t149).ink_f_value);
output[1u+i*2u+1u]=bitcast<u32>((t149).ink_f_tangent);

}
case 2u:{
var t150:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t151:u32=a1[0u+(0u)*1u+0u];
var t152:u32=230u;
var t153:R___ink_differential_0=t150;
var t154:u32=t151;
var t155:u32=t152;
var t156:u32=(t155 + 6u);
var t157:u32=t154;
var t158:R___ink_differential_0;
if ((t157 == t156)) {
t158=t153;
} else {
var t159:u32=t156;
var t160:R___ink_differential_3;if(t159<a2[0u]){
t160=R___ink_differential_3(R___ink_differential_0(a2[1u+(t159)*11u+0u],a2[1u+(t159)*11u+1u]),R___ink_differential_0(a2[1u+(t159)*11u+2u],a2[1u+(t159)*11u+3u]),R___ink_differential_0(a2[1u+(t159)*11u+4u],a2[1u+(t159)*11u+5u]),R___ink_differential_0(a2[1u+(t159)*11u+6u],a2[1u+(t159)*11u+7u]),R___ink_differential_0(a2[1u+(t159)*11u+8u],a2[1u+(t159)*11u+9u]),a2[1u+(t159)*11u+10u]);}else{
var t161:u32=0u;
var t162:u32=0u;
var t163:R___ink_differential_0=R___ink_differential_0(t161,t162);
var t164:u32=0u;
var t165:u32=0u;
var t166:R___ink_differential_0=R___ink_differential_0(t164,t165);
var t167:u32=0u;
var t168:u32=0u;
var t169:R___ink_differential_0=R___ink_differential_0(t167,t168);
var t170:u32=1065353216u;
var t171:u32=0u;
var t172:R___ink_differential_0=R___ink_differential_0(t170,t171);
var t173:u32=1065353216u;
var t174:u32=0u;
var t175:R___ink_differential_0=R___ink_differential_0(t173,t174);
var t176:u32=0u;
t160=R___ink_differential_3(t163,t166,t169,t172,t175,t176);}
t158=(t160).ink_f_value;
}
var t177:R___ink_differential_0=t158;
var t178:R___ink_differential_0=t177;
for(var t179=0u;t179<6u;t179++){
var t180:R___ink_differential_0=t178;
var t181:R___ink_differential_0=t150;
var t182:u32=t151;
var t183:u32=t152;
var t184:u32=(t183 + t179);
var t185:u32=t182;
var t186:R___ink_differential_0;
if ((t185 == t184)) {
t186=t181;
} else {
var t187:u32=t184;
var t188:R___ink_differential_3;if(t187<a2[0u]){
t188=R___ink_differential_3(R___ink_differential_0(a2[1u+(t187)*11u+0u],a2[1u+(t187)*11u+1u]),R___ink_differential_0(a2[1u+(t187)*11u+2u],a2[1u+(t187)*11u+3u]),R___ink_differential_0(a2[1u+(t187)*11u+4u],a2[1u+(t187)*11u+5u]),R___ink_differential_0(a2[1u+(t187)*11u+6u],a2[1u+(t187)*11u+7u]),R___ink_differential_0(a2[1u+(t187)*11u+8u],a2[1u+(t187)*11u+9u]),a2[1u+(t187)*11u+10u]);}else{
var t189:u32=0u;
var t190:u32=0u;
var t191:R___ink_differential_0=R___ink_differential_0(t189,t190);
var t192:u32=0u;
var t193:u32=0u;
var t194:R___ink_differential_0=R___ink_differential_0(t192,t193);
var t195:u32=0u;
var t196:u32=0u;
var t197:R___ink_differential_0=R___ink_differential_0(t195,t196);
var t198:u32=1065353216u;
var t199:u32=0u;
var t200:R___ink_differential_0=R___ink_differential_0(t198,t199);
var t201:u32=1065353216u;
var t202:u32=0u;
var t203:R___ink_differential_0=R___ink_differential_0(t201,t202);
var t204:u32=0u;
t188=R___ink_differential_3(t191,t194,t197,t200,t203,t204);}
t186=(t188).ink_f_value;
}
var t205:R___ink_differential_0=t186;
var t206:u32=t179;
var t207:R___ink_differential_0;if(t206<a3[0u]){
t207=R___ink_differential_0(a3[1u+(t206)*2u+0u],a3[1u+(t206)*2u+1u]);}else{
var t208:u32=0u;
var t209:u32=0u;
t207=R___ink_differential_0(t208,t209);}
var t210:R___ink_differential_0=t207;
var t211:u32=(t205).ink_f_value;
var t212:u32=ink_f32_mul(t211,(t210).ink_f_value);
var t213:u32=t212;
var t214:u32=(t205).ink_f_tangent;
var t215:u32=ink_f32_mul(t214,(t210).ink_f_value);
var t216:u32=(t205).ink_f_value;
var t217:u32=ink_f32_add(t215,ink_f32_mul(t216,(t210).ink_f_tangent));
var t218:R___ink_differential_0=R___ink_differential_0(t213,t217);
var t219:u32=(t180).ink_f_value;
var t220:u32=ink_f32_add(t219,(t218).ink_f_value);
var t221:u32=t220;
var t222:u32=(t180).ink_f_tangent;
var t223:u32=ink_f32_add(t222,(t218).ink_f_tangent);
t178=R___ink_differential_0(t221,t223);
}
var t224:R___ink_differential_0=t178;
output[1u+i*2u+0u]=bitcast<u32>((t224).ink_f_value);
output[1u+i*2u+1u]=bitcast<u32>((t224).ink_f_tangent);

}
case 3u:{
var t225:R___ink_differential_0=R___ink_differential_0(a0[0u+(0u)*2u+0u],a0[0u+(0u)*2u+1u]);
var t226:u32=a1[0u+(0u)*1u+0u];
var t227:u32=237u;
var t228:R___ink_differential_0=t225;
var t229:u32=t226;
var t230:u32=t227;
var t231:u32=(t230 + 6u);
var t232:u32=t229;
var t233:R___ink_differential_0;
if ((t232 == t231)) {
t233=t228;
} else {
var t234:u32=t231;
var t235:R___ink_differential_3;if(t234<a2[0u]){
t235=R___ink_differential_3(R___ink_differential_0(a2[1u+(t234)*11u+0u],a2[1u+(t234)*11u+1u]),R___ink_differential_0(a2[1u+(t234)*11u+2u],a2[1u+(t234)*11u+3u]),R___ink_differential_0(a2[1u+(t234)*11u+4u],a2[1u+(t234)*11u+5u]),R___ink_differential_0(a2[1u+(t234)*11u+6u],a2[1u+(t234)*11u+7u]),R___ink_differential_0(a2[1u+(t234)*11u+8u],a2[1u+(t234)*11u+9u]),a2[1u+(t234)*11u+10u]);}else{
var t236:u32=0u;
var t237:u32=0u;
var t238:R___ink_differential_0=R___ink_differential_0(t236,t237);
var t239:u32=0u;
var t240:u32=0u;
var t241:R___ink_differential_0=R___ink_differential_0(t239,t240);
var t242:u32=0u;
var t243:u32=0u;
var t244:R___ink_differential_0=R___ink_differential_0(t242,t243);
var t245:u32=1065353216u;
var t246:u32=0u;
var t247:R___ink_differential_0=R___ink_differential_0(t245,t246);
var t248:u32=1065353216u;
var t249:u32=0u;
var t250:R___ink_differential_0=R___ink_differential_0(t248,t249);
var t251:u32=0u;
t235=R___ink_differential_3(t238,t241,t244,t247,t250,t251);}
t233=(t235).ink_f_value;
}
var t252:R___ink_differential_0=t233;
var t253:R___ink_differential_0=t252;
for(var t254=0u;t254<6u;t254++){
var t255:R___ink_differential_0=t253;
var t256:R___ink_differential_0=t225;
var t257:u32=t226;
var t258:u32=t227;
var t259:u32=(t258 + t254);
var t260:u32=t257;
var t261:R___ink_differential_0;
if ((t260 == t259)) {
t261=t256;
} else {
var t262:u32=t259;
var t263:R___ink_differential_3;if(t262<a2[0u]){
t263=R___ink_differential_3(R___ink_differential_0(a2[1u+(t262)*11u+0u],a2[1u+(t262)*11u+1u]),R___ink_differential_0(a2[1u+(t262)*11u+2u],a2[1u+(t262)*11u+3u]),R___ink_differential_0(a2[1u+(t262)*11u+4u],a2[1u+(t262)*11u+5u]),R___ink_differential_0(a2[1u+(t262)*11u+6u],a2[1u+(t262)*11u+7u]),R___ink_differential_0(a2[1u+(t262)*11u+8u],a2[1u+(t262)*11u+9u]),a2[1u+(t262)*11u+10u]);}else{
var t264:u32=0u;
var t265:u32=0u;
var t266:R___ink_differential_0=R___ink_differential_0(t264,t265);
var t267:u32=0u;
var t268:u32=0u;
var t269:R___ink_differential_0=R___ink_differential_0(t267,t268);
var t270:u32=0u;
var t271:u32=0u;
var t272:R___ink_differential_0=R___ink_differential_0(t270,t271);
var t273:u32=1065353216u;
var t274:u32=0u;
var t275:R___ink_differential_0=R___ink_differential_0(t273,t274);
var t276:u32=1065353216u;
var t277:u32=0u;
var t278:R___ink_differential_0=R___ink_differential_0(t276,t277);
var t279:u32=0u;
t263=R___ink_differential_3(t266,t269,t272,t275,t278,t279);}
t261=(t263).ink_f_value;
}
var t280:R___ink_differential_0=t261;
var t281:u32=t254;
var t282:R___ink_differential_0;if(t281<a3[0u]){
t282=R___ink_differential_0(a3[1u+(t281)*2u+0u],a3[1u+(t281)*2u+1u]);}else{
var t283:u32=0u;
var t284:u32=0u;
t282=R___ink_differential_0(t283,t284);}
var t285:R___ink_differential_0=t282;
var t286:u32=(t280).ink_f_value;
var t287:u32=ink_f32_mul(t286,(t285).ink_f_value);
var t288:u32=t287;
var t289:u32=(t280).ink_f_tangent;
var t290:u32=ink_f32_mul(t289,(t285).ink_f_value);
var t291:u32=(t280).ink_f_value;
var t292:u32=ink_f32_add(t290,ink_f32_mul(t291,(t285).ink_f_tangent));
var t293:R___ink_differential_0=R___ink_differential_0(t288,t292);
var t294:u32=(t255).ink_f_value;
var t295:u32=ink_f32_add(t294,(t293).ink_f_value);
var t296:u32=t295;
var t297:u32=(t255).ink_f_tangent;
var t298:u32=ink_f32_add(t297,(t293).ink_f_tangent);
t253=R___ink_differential_0(t296,t298);
}
var t299:R___ink_differential_0=t253;
output[1u+i*2u+0u]=bitcast<u32>((t299).ink_f_value);
output[1u+i*2u+1u]=bitcast<u32>((t299).ink_f_tangent);

}
default:{} }

}
}