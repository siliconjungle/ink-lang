const __recordElisions=new Set([]);
const __nativeF32=true;
// Representation conversion only. Callers supply values matching metadata.
const __view = new DataView(new ArrayBuffer(4));
const __float = bits => { __view.setUint32(0, bits, true); return __view.getFloat32(0, true); };
const __bits = number => { if(Number.isNaN(number))return 0x7fc00000; __view.setFloat32(0, number, true); return __view.getUint32(0, true); };
// Binary64 uses native Numbers for finite arithmetic and immutable private
// tags only where a NaN's exact payload must survive non-arithmetic operations.
const __doubleView=new DataView(new ArrayBuffer(8));
const __double=bits=>{__doubleView.setBigUint64(0,bits,true);return __doubleView.getFloat64(0,true);};
const __doubleBits=number=>{if(Number.isNaN(number))return 0x7ff8000000000000n;__doubleView.setFloat64(0,number,true);return __doubleView.getBigUint64(0,true);};
const __dfNumber=value=>typeof value==='number'?value:__double(BigInt(value.F64Bits));
const __dfBits=value=>typeof value==='number'?__doubleBits(value):BigInt(value.F64Bits);
const __dfFromBits=bits=>(bits&0x7fffffffffffffffn)>0x7ff0000000000000n?Object.freeze({F64Bits:bits.toString()}):__double(bits);
const __dfInput=value=>typeof value==='number'?value:__dfFromBits(BigInt(value.F64Bits));
const __dfNeg=value=>typeof value==='number'&&!Number.isNaN(value)?-value:__dfFromBits(__dfBits(value)^0x8000000000000000n);
const __dfOutput=value=>{const n=__dfNumber(value);return Number.isFinite(n)?n:{F64Bits:__dfBits(value).toString()};};
const __dfCapture=value=>{
 if(typeof value==='number'&&Number.isFinite(value))return value;
 if(!value||typeof value!=='object'||Object.keys(value).length!==1||!Object.hasOwn(value,'F64Bits'))throw Error('invalid f64');const text=value.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid f64');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');return __dfFromBits(bits);
};
// Native binary32 lane for pure modules. Explicit NaN payloads remain tagged;
// arithmetic canonicalizes NaNs just as __bits does in the exact-bit lane.
// Host tags are captured once at a typed read. Only private immutable tags
// may pass through normalization without consulting a host property again.
const __nfTagged = new WeakSet();
const __nfValue = value => typeof value === 'number' ? Math.fround(value) : __nfTagged.has(value) ? value : __nfFromBits(value.F32Bits);
// Number operands have already been normalised at their typed read or producer.
const __nfNumber = value => typeof value === 'number' ? value : __float(value.F32Bits);
const __nfBits = value => typeof value === 'number' ? __bits(value) : value.F32Bits;
const __nfFromBits = bits => {
  if((bits & 0x7fffffff)<=0x7f800000)return __float(bits);
  const value=Object.freeze({F32Bits:bits});__nfTagged.add(value);return value;
};
const __nfNeg = value => typeof value === 'number' && !Number.isNaN(value) ? -value : __nfFromBits((__nfBits(value) ^ 0x80000000) >>> 0);
const __nfOutput = value => {const n=typeof value==='number'?Math.fround(value):__float(value.F32Bits);return Number.isFinite(n)?n:{F32Bits:__nfBits(value)};};
const __identity = value => value;
// Intern declared conversion schemas once. An invocation owns one WeakMap per
// schema instead of allocating a Map for every converted record/list node.
const __conversionKeys = new Map();
function __representation(type, output, capture=false) {
  const convert=__representationRaw(type,output,capture);
  if(convert===__identity)return convert;
  // Conversion identity is invocation-local: callers may reuse a mutable host
  // object in a later call. Distinct declared schemas have distinct memo keys.
  const schema=(output?'out:':capture?'capture:':'in:')+JSON.stringify(type);
  let key=__conversionKeys.get(schema);
  if(!key){key={};__conversionKeys.set(schema,key);}
  return (value,context)=>{
    if(!context||!value||typeof value!=='object')return convert(value,context);
    let entries=context.get(key);
    if(!entries){entries=new WeakMap();context.set(key,entries);}
    if(entries.has(value))return entries.get(value);
    const result=convert(value,context);
    entries.set(value,result);return result;
  };
}
function __representationRaw(type, output, capture) {
  switch (type.kind) {
    case 'ref': {
      let resolved;
      return (value,context)=>(resolved??=__representation(__namedTypes[type.name],output,capture))(value,context);
    }
    case 'id': return value=>value.toLowerCase();
    case 'int': return output ? value=>({Int:value.toString()}) : value=>BigInt(value && typeof value==='object' ? value.Int : value);
    case 'option': {
      const item=__representation(type.element,output,capture);
      return item===__identity?__identity:(value,context)=>Object.hasOwn(value,'Some')?{Some:item(value.Some,context)}:{None:null};
    }
    case 'result': {
      const ok=__representation(type.ok,output,capture),err=__representation(type.error,output,capture);
      const key=typeof __sumSpecs==='undefined'?null:__sumKey(type),flat=key!==null&&__sumSpecs.has(key);
      if(flat)return output?(value,context)=>{const v=__sumView(key,value);return Object.hasOwn(v,'Ok')?{Ok:ok(v.Ok,context)}:{Err:err(v.Err,context)};}:(v,context)=>Object.hasOwn(v,'Ok')?__sumMake(key,true,ok(v.Ok,context)):__sumMake(key,false,err(v.Err,context));
      return ok===__identity&&err===__identity?__identity:(value,context)=>Object.hasOwn(value,'Ok')?{Ok:ok(value.Ok,context)}:{Err:err(value.Err,context)};
    }
    case 'f64':return output?__dfOutput:__dfInput;
    case 'f32': if(typeof __nativeF32!=='undefined'&&__nativeF32)return output?__nfOutput:capture?__nfValue:__identity;
      return output ? value => {
      const number = __float(value);
      return Number.isFinite(number) ? number : {F32Bits:value};
    } : value => typeof value === 'number' ? __bits(value) : value.F32Bits;
    case 'list': case 'vector': {
      const element = __representation(type.element, output,capture);
      return element === __identity ? __identity : (value,context) => Array.from(value, item=>element(item,context));
    }
    case 'record': {
      if((typeof __recordElisions!=='undefined'&&__recordElisions.has(type.name))){
        if(!type.fields.length)return ()=>undefined; // lexically unconsumed projected input
        const field=type.fields[0],child=__representation(field.type,output,capture);
        return output?(value,context)=>({[field.name]:child(value,context)}):(value,context)=>child(value[field.name],context);
      }
      const fields = type.fields.map(field => [field.name, __representation(field.type, output,capture)]);
      return fields.every(([,convert]) => convert === __identity) ? __identity :
        (value,context) => {
          const result={};
          for(const [name,convert] of fields){
            const field=convert(value[name],context);
            // Assignment treats __proto__ specially; records require an own
            // ordinary writable data property, as Object.fromEntries supplied.
            if(name==='__proto__')Object.defineProperty(result,name,{value:field,writable:true,enumerable:true,configurable:true});
            else result[name]=field;
          }
          return result;
        };
    }
    default: return __identity;
  }
}
function __fn0(){
const v0=0.0;
const v1=0.0;
const v2=0.0;
const v3=1.0;
const v4=1.0;
const v5=0;
return ({["value"]:v0,["first"]:v1,["second"]:v2,["first_power"]:v3,["second_power"]:v4,["steps"]:v5});}
function __fn1(v6,v7,v8,v9){
v6=__nfValue(v6);
let v10;if((v7===v9)){
v10=v6;}else{
let v11;if(v9<v8.length){v11=v8[v9];}else{
v11=__fn0();}
const v12=v11;
v10=__nfValue(v12["value"]);}
return v10;}
function __fn2(v13,v14){
v13=__nfValue(v13);
v14=__nfValue(v14);
const v15=0.0;
let v16;if(((__nfNumber(v14)) > (__nfNumber(v15)))){
v16=Math.fround(__nfNumber(v13) * __nfNumber(v14));}else{
v16=0.0;}
return v16;}
function __fn3(v17,v18,v19,v20,v21,v22){
v17=__nfValue(v17);
const v23=10;
const v24=(((v22) + (v23)) >>> 0);
const v25=__fn1(v17,v18,v19,v24);
let v26=v25;
for(let v27=0;v27<10;v27++){
const v28=(v27>>>0);
const v29=v26;
const v30=(((v22) + (v28)) >>> 0);
const v31=__fn1(v17,v18,v19,v30);
const v32=10;
const v33=(Math.imul(v21,v32) >>> 0);
const v34=(((v33) + (v28)) >>> 0);
let v35;if(v34<v20.length){v35=v20[v34];}else{
v35=0.0;}
const v36=__nfValue(v35);
const v37=Math.fround(__nfNumber(v31) * __nfNumber(v36));
v26=Math.fround(__nfNumber(v29) + v37);}
return v26;}
function __fn4(v38,v39,v40,v41,v42){
v38=__nfValue(v38);
const v43=6;
const v44=(((v42) + (v43)) >>> 0);
const v45=__fn1(v38,v39,v40,v44);
let v46=v45;
for(let v47=0;v47<6;v47++){
const v48=(v47>>>0);
const v49=v46;
const v50=(((v42) + (v48)) >>> 0);
const v51=__fn1(v38,v39,v40,v50);
let v52;if(v48<v41.length){v52=v41[v48];}else{
v52=0.0;}
const v53=__nfValue(v52);
const v54=Math.fround(__nfNumber(v51) * __nfNumber(v53));
v46=Math.fround(__nfNumber(v49) + v54);}
return v46;}
function __fn5(v55,v56,v57,v58,v59){
v55=__nfValue(v55);
const v60=0;
const v61=__fn3(v55,v56,v57,v58,v59,v60);
const v62=11;
const v63=__fn3(v55,v56,v57,v58,v59,v62);
const v64=__fn2(v61,v63);
const v65=22;
const v66=__fn3(v55,v56,v57,v58,v59,v65);
const v67=33;
const v68=__fn3(v55,v56,v57,v58,v59,v67);
const v69=__fn2(v66,v68);
const v70=44;
const v71=__fn3(v55,v56,v57,v58,v59,v70);
const v72=55;
const v73=__fn3(v55,v56,v57,v58,v59,v72);
const v74=__fn2(v71,v73);
const v75=66;
const v76=__fn3(v55,v56,v57,v58,v59,v75);
const v77=77;
const v78=__fn3(v55,v56,v57,v58,v59,v77);
const v79=__fn2(v76,v78);
const v80=88;
const v81=__fn3(v55,v56,v57,v58,v59,v80);
const v82=99;
const v83=__fn3(v55,v56,v57,v58,v59,v82);
const v84=__fn2(v81,v83);
const v85=110;
const v86=__fn3(v55,v56,v57,v58,v59,v85);
const v87=121;
const v88=__fn3(v55,v56,v57,v58,v59,v87);
const v89=__fn2(v86,v88);
return [v64,v69,v74,v79,v84,v89];}
function __fn6(v90,v91,v92,v93){
v90=__nfValue(v90);
const v94=132;
const v95=__fn4(v90,v91,v92,v93,v94);
const v96=139;
const v97=__fn4(v90,v91,v92,v93,v96);
const v98=__fn2(v95,v97);
const v99=146;
const v100=__fn4(v90,v91,v92,v93,v99);
const v101=153;
const v102=__fn4(v90,v91,v92,v93,v101);
const v103=__fn2(v100,v102);
const v104=160;
const v105=__fn4(v90,v91,v92,v93,v104);
const v106=167;
const v107=__fn4(v90,v91,v92,v93,v106);
const v108=__fn2(v105,v107);
const v109=174;
const v110=__fn4(v90,v91,v92,v93,v109);
const v111=181;
const v112=__fn4(v90,v91,v92,v93,v111);
const v113=__fn2(v110,v112);
const v114=188;
const v115=__fn4(v90,v91,v92,v93,v114);
const v116=195;
const v117=__fn4(v90,v91,v92,v93,v116);
const v118=__fn2(v115,v117);
const v119=202;
const v120=__fn4(v90,v91,v92,v93,v119);
const v121=209;
const v122=__fn4(v90,v91,v92,v93,v121);
const v123=__fn2(v120,v122);
return [v98,v103,v108,v113,v118,v123];}
function __fn7(v124,v125,v126,v127,v128){
v124=__nfValue(v124);
const v129=__fn5(v124,v125,v126,v127,v128);
const v130=__fn6(v124,v125,v126,v129);
const v131=216;
const v132=__fn4(v124,v125,v126,v130,v131);
const v133=223;
const v134=__fn4(v124,v125,v126,v130,v133);
const v135=230;
const v136=__fn4(v124,v125,v126,v130,v135);
const v137=237;
const v138=__fn4(v124,v125,v126,v130,v137);
return [v132,v134,v136,v138];}
function __fn8(v139,v140){
v139=__nfValue(v139);
v140=__nfValue(v140);
const v141=Math.fround(__nfNumber(v139) - __nfNumber(v140));
return Math.fround(v141 * v141);}
function __fn9(v142,v143,v144,v145,v146,v147){
v142=__nfValue(v142);
const v148=__fn7(v142,v143,v144,v145,v147);
let v149=0.0;
for(let v150=0;v150<4;v150++){
const v151=(v150>>>0);
const v152=v149;
let v153;if(v151<v148.length){v153=v148[v151];}else{
v153=0.0;}
const v154=__nfValue(v153);
const v155=4;
const v156=(Math.imul(v147,v155) >>> 0);
const v157=(((v156) + (v151)) >>> 0);
let v158;if(v157<v146.length){v158=v146[v157];}else{
v158=0.0;}
const v159=__nfValue(v158);
const v160=__fn8(v154,v159);
v149=Math.fround(__nfNumber(v152) + __nfNumber(v160));}
const v161=v149;
return Math.fround((__nfNumber(v161))/(__nfNumber(4.0)));}
function __fn10(v162,v163,v164,v165){
const v166=(v165).length;
const v167=0;
let v168;if((v166===v167)){
const v169=v162.length;
const v170=new Array(v169);
for(let v171=0;v171<v169;v171++){
const v172=v162[v171];
v170[v171]=0.0;
}
v168=v170;}else{
const v173=v162.length;
const v174=new Array(v173);
for(let v175=0;v175<v173;v175++){
const v176=v162[v175];
const v177=(v175>>>0);
let v178=0.0;
for(let v179=0;v179<v165.length;v179++){
const v180=(v165[v179]>>>0);
const v181=v178;
const v182=__nfValue(v176["value"]);
const v183=__fn33(v182,v177,v162,v163,v164,v180);
v178=Math.fround(__nfNumber(v181) + __nfNumber(v183));
}
v174[v175]=Math.fround((__nfNumber(v178))/(__nfNumber(Math.fround((v165).length))));
}
v168=v174;}
return v168;}
function __fn11(v184,v185,v186){
v185=__nfValue(v185);
const v187=__nfValue(v184["first_power"]);
const v188=__nfValue(v186["first_decay"]);
const v189=Math.fround(__nfNumber(v187) * __nfNumber(v188));
const v190=__nfValue(v184["second_power"]);
const v191=__nfValue(v186["second_decay"]);
const v192=Math.fround(__nfNumber(v190) * __nfNumber(v191));
const v193=__nfValue(v186["first_decay"]);
const v194=__nfValue(v184["first"]);
const v195=Math.fround(__nfNumber(v193) * __nfNumber(v194));
const v196=1.0;
const v197=__nfValue(v186["first_decay"]);
const v198=Math.fround(v196 - __nfNumber(v197));
const v199=Math.fround(v198 * __nfNumber(v185));
const v200=Math.fround(v195 + v199);
const v201=__nfValue(v186["second_decay"]);
const v202=__nfValue(v184["second"]);
const v203=Math.fround(__nfNumber(v201) * __nfNumber(v202));
const v204=1.0;
const v205=__nfValue(v186["second_decay"]);
const v206=Math.fround(v204 - __nfNumber(v205));
const v207=Math.fround(v206 * __nfNumber(v185));
const v208=Math.fround(v207 * __nfNumber(v185));
const v209=Math.fround(v203 + v208);
const v210=__nfValue(v184["value"]);
const v211=__nfValue(v186["rate"]);
const v212=1.0;
const v213=Math.fround((__nfNumber(v200))/(__nfNumber(Math.fround(v212 - v189))));
const v214=1.0;
const v215=Math.fround(Math.sqrt(__nfNumber(Math.fround((__nfNumber(v209))/(__nfNumber(Math.fround(v214 - v192)))))));
const v216=__nfValue(v186["epsilon"]);
const v217=Math.fround((__nfNumber(Math.fround(__nfNumber(v211) * v213)))/(__nfNumber(Math.fround(v215 + __nfNumber(v216)))));
const v218=Math.fround(__nfNumber(v210) - v217);
const v219=v184["steps"];
const v220=1;
const v221=(((v219) + (v220)) >>> 0);
return ({["value"]:v218,["first"]:v200,["second"]:v209,["first_power"]:v189,["second_power"]:v192,["steps"]:v221});}
function __fn12(v222){
const v223=Number.isFinite(__nfNumber(__nfValue(v222["value"])));
let v224=v223;if(v224){
v224=Number.isFinite(__nfNumber(__nfValue(v222["first"])));}
const v225=v224;
let v226=v225;if(v226){
v226=Number.isFinite(__nfNumber(__nfValue(v222["second"])));}
const v227=v226;
let v228=v227;if(v228){
const v229=__nfValue(v222["second"]);
const v230=0.0;
v228=((__nfNumber(v229)) >= (__nfNumber(v230)));}
const v231=v228;
let v232=v231;if(v232){
const v233=__nfValue(v222["first_power"]);
const v234=0.0;
v232=((__nfNumber(v233)) >= (__nfNumber(v234)));}
const v235=v232;
let v236=v235;if(v236){
const v237=__nfValue(v222["first_power"]);
const v238=1.0;
v236=((__nfNumber(v237)) <= (__nfNumber(v238)));}
const v239=v236;
let v240=v239;if(v240){
const v241=__nfValue(v222["second_power"]);
const v242=0.0;
v240=((__nfNumber(v241)) >= (__nfNumber(v242)));}
const v243=v240;
let v244=v243;if(v244){
const v245=__nfValue(v222["second_power"]);
const v246=1.0;
v244=((__nfNumber(v245)) <= (__nfNumber(v246)));}
const v247=v244;
let v248=v247;if(v248){
const v249=v222["steps"];
const v250=4294967295;
v248=((v249) < (v250));}
return v248;}
function __fn13(v251){
const v252=Number.isFinite(__nfNumber(__nfValue(v251["rate"])));
let v253=v252;if(v253){
const v254=__nfValue(v251["rate"]);
const v255=0.0;
v253=((__nfNumber(v254)) > (__nfNumber(v255)));}
const v256=v253;
let v257=v256;if(v257){
const v258=__nfValue(v251["first_decay"]);
const v259=0.0;
v257=((__nfNumber(v258)) >= (__nfNumber(v259)));}
const v260=v257;
let v261=v260;if(v261){
const v262=__nfValue(v251["first_decay"]);
const v263=1.0;
v261=((__nfNumber(v262)) < (__nfNumber(v263)));}
const v264=v261;
let v265=v264;if(v265){
const v266=__nfValue(v251["second_decay"]);
const v267=0.0;
v265=((__nfNumber(v266)) >= (__nfNumber(v267)));}
const v268=v265;
let v269=v268;if(v269){
const v270=__nfValue(v251["second_decay"]);
const v271=1.0;
v269=((__nfNumber(v270)) < (__nfNumber(v271)));}
const v272=v269;
let v273=v272;if(v273){
v273=Number.isFinite(__nfNumber(__nfValue(v251["epsilon"])));}
const v274=v273;
let v275=v274;if(v275){
const v276=__nfValue(v251["epsilon"]);
const v277=0.0;
v275=((__nfNumber(v276)) > (__nfNumber(v277)));}
return v275;}
function __fn14(v278,v279,v280,v281){
const v282=(v278).length;
const v283=244;
const v284=(v282===v283);
let v285=v284;if(v285){
const v286=(v279).length;
const v287=(v281).length;
const v288=10;
const v289=(Math.imul(v287,v288) >>> 0);
v285=(v286===v289);}
const v290=v285;
let v291=v290;if(v291){
const v292=(v280).length;
const v293=(v281).length;
const v294=4;
const v295=(Math.imul(v293,v294) >>> 0);
v291=(v292===v295);}
const v296=v291;
let v297=v296;if(v297){
const v298=(v281).length;
const v299=0;
v297=((v298) > (v299));}
return v297;}
function __fn15(v300,v301,v302,v303){
const v304=false;
const v305=(v302===v304);
let v306=v305;if(!v306){
const v307=__fn13(v303);
const v308=false;
v306=(v307===v308);}
const v309=v306;
let v310=v309;if(!v310){
const v311=(v301).length;
const v312=(v300).length;
v310=!(v311===v312);}
const v313=v310;
let v314=v313;if(!v314){
let v315=true;
for(let v316=0;v316<v300.length;v316++){
const v317=v300[v316];
const v318=v315;
let v319=v318;if(v319){
v319=__fn12(v317);}
v315=v319;
}
const v320=v315;
const v321=false;
v314=(v320===v321);}
let v322;if(v314){
v322=v300;}else{
const v323=v300.length;
const v324=new Array(v323);
for(let v325=0;v325<v323;v325++){
const v326=v300[v325];
const v327=(v325>>>0);
let v328;if(v327<v301.length){v328=v301[v327];}else{
v328=0.0;}
const v329=__nfValue(v328);
v324[v325]=__fn11(v326,v329,v303);
}
let v330=true;
for(let v331=0;v331<v324.length;v331++){
const v332=v324[v331];
const v333=v330;
let v334=v333;if(v334){
v334=__fn12(v332);}
v330=v334;
}
let v335;if(v330){
v335=v324;}else{
v335=v300;}
v322=v335;}
return v322;}
function __fn16(v336,v337,v338,v339){
const v340=v339.length;
const v341=new Array(v340);
for(let v342=0;v342<v340;v342++){
const v343=(v339[v342]>>>0);
const v344=0.0;
const v345=4294967295;
v341[v342]=__fn9(v344,v345,v336,v337,v338,v343);
}
return v341;}
function __fn17(v346){
return (__dfNumber(v346) * __dfNumber(v346));}
function __fn18(v347){
return __fn36(v347);}
function __fn19(v348,v349){
const v350=__nfValue(v348["value"]);
const v351=__nfValue(v349["value"]);
const v352=Math.fround(__nfNumber(v350) * __nfNumber(v351));
const v353=__nfValue(v348["tangent"]);
const v354=__nfValue(v349["value"]);
const v355=Math.fround(__nfNumber(v353) * __nfNumber(v354));
const v356=__nfValue(v348["value"]);
const v357=__nfValue(v349["tangent"]);
const v358=Math.fround(__nfNumber(v356) * __nfNumber(v357));
const v359=Math.fround(v355 + v358);
return ({["value"]:v352,["tangent"]:v359});}
function __fn20(v360,v361){
const v362=__nfValue(v361["value"]);
const v363=0.0;
const v364=0.0;
const v365=({["value"]:v363,["tangent"]:v364});
const v366=__nfValue(v365["value"]);
let v367;if(((__nfNumber(v362)) > (__nfNumber(v366)))){
v367=__fn19(v360,v361);}else{
const v368=0.0;
const v369=0.0;
v367=({["value"]:v368,["tangent"]:v369});}
return v367;}
function __fn21(){
const v370=0.0;
const v371=0.0;
const v372=({["value"]:v370,["tangent"]:v371});
const v373=0.0;
const v374=0.0;
const v375=({["value"]:v373,["tangent"]:v374});
const v376=0.0;
const v377=0.0;
const v378=({["value"]:v376,["tangent"]:v377});
const v379=1.0;
const v380=0.0;
const v381=({["value"]:v379,["tangent"]:v380});
const v382=1.0;
const v383=0.0;
const v384=({["value"]:v382,["tangent"]:v383});
const v385=0;
return ({["value"]:v372,["first"]:v375,["second"]:v378,["first_power"]:v381,["second_power"]:v384,["steps"]:v385});}
function __fn22(v386,v387,v388,v389){
let v390;if((v387===v389)){
v390=v386;}else{
let v391;if(v389<v388.length){v391=v388[v389];}else{
v391=__fn21();}
const v392=v391;
v390=v392["value"];}
return v390;}
function __fn23(v393,v394){
const v395=__nfValue(v393["value"]);
const v396=__nfValue(v394["value"]);
const v397=Math.fround(__nfNumber(v395) + __nfNumber(v396));
const v398=__nfValue(v393["tangent"]);
const v399=__nfValue(v394["tangent"]);
const v400=Math.fround(__nfNumber(v398) + __nfNumber(v399));
return ({["value"]:v397,["tangent"]:v400});}
function __fn24(v401,v402,v403,v404,v405,v406){
const v407=10;
const v408=(((v406) + (v407)) >>> 0);
const v409=__fn22(v401,v402,v403,v408);
let v410=v409["value"];
let v411=v409["tangent"];
for(let v413=0;v413<10;v413++){
const v414=(v413>>>0);
const v416=(((v406) + (v414)) >>> 0);
const v417=__fn22(v401,v402,v403,v416);
const v418=10;
const v419=(Math.imul(v405,v418) >>> 0);
const v420=(((v419) + (v414)) >>> 0);
let v421;if(v420<v404.length){v421=v404[v420];}else{
const v422=0.0;
const v423=0.0;
v421=({["value"]:v422,["tangent"]:v423});}
const v424=v421;
const v425=__fn19(v417,v424);
const v426=__nfValue(v410);
const v427=__nfValue(v425["value"]);
const v428=Math.fround(__nfNumber(v426) + __nfNumber(v427));
const v429=__nfValue(v411);
const v430=__nfValue(v425["tangent"]);
const v431=Math.fround(__nfNumber(v429) + __nfNumber(v430));
v410=v428;
v411=v431;
}
return ({["value"]:v410,["tangent"]:v411});}
function __fn25(v432,v433,v434,v435,v436){
const v437=0;
const v438=__fn24(v432,v433,v434,v435,v436,v437);
const v439=11;
const v440=__fn24(v432,v433,v434,v435,v436,v439);
const v441=__fn20(v438,v440);
const v442=22;
const v443=__fn24(v432,v433,v434,v435,v436,v442);
const v444=33;
const v445=__fn24(v432,v433,v434,v435,v436,v444);
const v446=__fn20(v443,v445);
const v447=44;
const v448=__fn24(v432,v433,v434,v435,v436,v447);
const v449=55;
const v450=__fn24(v432,v433,v434,v435,v436,v449);
const v451=__fn20(v448,v450);
const v452=66;
const v453=__fn24(v432,v433,v434,v435,v436,v452);
const v454=77;
const v455=__fn24(v432,v433,v434,v435,v436,v454);
const v456=__fn20(v453,v455);
const v457=88;
const v458=__fn24(v432,v433,v434,v435,v436,v457);
const v459=99;
const v460=__fn24(v432,v433,v434,v435,v436,v459);
const v461=__fn20(v458,v460);
const v462=110;
const v463=__fn24(v432,v433,v434,v435,v436,v462);
const v464=121;
const v465=__fn24(v432,v433,v434,v435,v436,v464);
const v466=__fn20(v463,v465);
return [v441,v446,v451,v456,v461,v466];}
function __fn26(v467,v468,v469,v470,v471){
const v472=6;
const v473=(((v471) + (v472)) >>> 0);
const v474=__fn22(v467,v468,v469,v473);
let v475=v474["value"];
let v476=v474["tangent"];
for(let v478=0;v478<6;v478++){
const v479=(v478>>>0);
const v481=(((v471) + (v479)) >>> 0);
const v482=__fn22(v467,v468,v469,v481);
let v483;if(v479<v470.length){v483=v470[v479];}else{
const v484=0.0;
const v485=0.0;
v483=({["value"]:v484,["tangent"]:v485});}
const v486=v483;
const v487=__fn19(v482,v486);
const v488=__nfValue(v475);
const v489=__nfValue(v487["value"]);
const v490=Math.fround(__nfNumber(v488) + __nfNumber(v489));
const v491=__nfValue(v476);
const v492=__nfValue(v487["tangent"]);
const v493=Math.fround(__nfNumber(v491) + __nfNumber(v492));
v475=v490;
v476=v493;
}
return ({["value"]:v475,["tangent"]:v476});}
function __fn27(v494,v495,v496,v497){
const v498=132;
const v499=__fn26(v494,v495,v496,v497,v498);
const v500=139;
const v501=__fn26(v494,v495,v496,v497,v500);
const v502=__fn20(v499,v501);
const v503=146;
const v504=__fn26(v494,v495,v496,v497,v503);
const v505=153;
const v506=__fn26(v494,v495,v496,v497,v505);
const v507=__fn20(v504,v506);
const v508=160;
const v509=__fn26(v494,v495,v496,v497,v508);
const v510=167;
const v511=__fn26(v494,v495,v496,v497,v510);
const v512=__fn20(v509,v511);
const v513=174;
const v514=__fn26(v494,v495,v496,v497,v513);
const v515=181;
const v516=__fn26(v494,v495,v496,v497,v515);
const v517=__fn20(v514,v516);
const v518=188;
const v519=__fn26(v494,v495,v496,v497,v518);
const v520=195;
const v521=__fn26(v494,v495,v496,v497,v520);
const v522=__fn20(v519,v521);
const v523=202;
const v524=__fn26(v494,v495,v496,v497,v523);
const v525=209;
const v526=__fn26(v494,v495,v496,v497,v525);
const v527=__fn20(v524,v526);
return [v502,v507,v512,v517,v522,v527];}
function __fn28(v528,v529,v530,v531,v532){
const v533=__fn25(v528,v529,v530,v531,v532);
const v534=__fn27(v528,v529,v530,v533);
const v535=216;
const v536=__fn26(v528,v529,v530,v534,v535);
const v537=223;
const v538=__fn26(v528,v529,v530,v534,v537);
const v539=230;
const v540=__fn26(v528,v529,v530,v534,v539);
const v541=237;
const v542=__fn26(v528,v529,v530,v534,v541);
return [v536,v538,v540,v542];}
function __fn29(v543,v544){
const v545=__nfValue(v543["value"]);
const v546=__nfValue(v544["value"]);
const v547=Math.fround(__nfNumber(v545) - __nfNumber(v546));
const v548=__nfValue(v543["tangent"]);
const v549=__nfValue(v544["tangent"]);
const v550=Math.fround(__nfNumber(v548) - __nfNumber(v549));
return ({["value"]:v547,["tangent"]:v550});}
function __fn30(v551,v552){
const v553=__fn29(v551,v552);
return __fn19(v553,v553);}
function __fn31(v554,v555){
const v556=Math.fround((__nfNumber(__nfValue(v554["value"])))/(__nfNumber(__nfValue(v555["value"]))));
const v557=__nfValue(v554["tangent"]);
const v558=__nfValue(v555["value"]);
const v559=Math.fround(__nfNumber(v557) * __nfNumber(v558));
const v560=__nfValue(v554["value"]);
const v561=__nfValue(v555["tangent"]);
const v562=Math.fround(__nfNumber(v560) * __nfNumber(v561));
const v563=__nfValue(v555["value"]);
const v564=__nfValue(v555["value"]);
const v565=Math.fround((__nfNumber(Math.fround(v559 - v562)))/(__nfNumber(Math.fround(__nfNumber(v563) * __nfNumber(v564)))));
return ({["value"]:v556,["tangent"]:v565});}
function __fn32(v566,v567,v568,v569,v570,v571){
const v572=__fn28(v566,v567,v568,v569,v571);
const v573=0.0;
const v574=0.0;
let v575=v573;
let v576=v574;
for(let v578=0;v578<4;v578++){
const v579=(v578>>>0);
let v581;if(v579<v572.length){v581=v572[v579];}else{
const v582=0.0;
const v583=0.0;
v581=({["value"]:v582,["tangent"]:v583});}
const v584=v581;
const v585=4;
const v586=(Math.imul(v571,v585) >>> 0);
const v587=(((v586) + (v579)) >>> 0);
let v588;if(v587<v570.length){v588=v570[v587];}else{
const v589=0.0;
const v590=0.0;
v588=({["value"]:v589,["tangent"]:v590});}
const v591=v588;
const v592=__fn30(v584,v591);
const v593=__nfValue(v575);
const v594=__nfValue(v592["value"]);
const v595=Math.fround(__nfNumber(v593) + __nfNumber(v594));
const v596=__nfValue(v576);
const v597=__nfValue(v592["tangent"]);
const v598=Math.fround(__nfNumber(v596) + __nfNumber(v597));
v575=v595;
v576=v598;
}
const v601=4.0;
const v602=0.0;
const v604=Math.fround((__nfNumber(__nfValue(v575)))/(__nfNumber(v601)));
const v605=__nfValue(v576);
const v606=Math.fround(__nfNumber(v605) * v601);
const v607=__nfValue(v575);
const v608=Math.fround(__nfNumber(v607) * v602);
const v609=Math.fround((__nfNumber(Math.fround(v606 - v608)))/(__nfNumber(Math.fround(v601 * v601))));
return ({["value"]:v604,["tangent"]:v609});}
function __fn33(v610,v611,v612,v613,v614,v615){
v610=__nfValue(v610);
const v616=1.0;
const v618=v612.length;
const v619=new Array(v618);
for(let v620=0;v620<v618;v620++){
const v621=v612[v620];
const v622=__nfValue(v621["value"]);
const v623=0.0;
const v624=({["value"]:v622,["tangent"]:v623});
const v625=__nfValue(v621["first"]);
const v626=0.0;
const v627=({["value"]:v625,["tangent"]:v626});
const v628=__nfValue(v621["second"]);
const v629=0.0;
const v630=({["value"]:v628,["tangent"]:v629});
const v631=__nfValue(v621["first_power"]);
const v632=0.0;
const v633=({["value"]:v631,["tangent"]:v632});
const v634=__nfValue(v621["second_power"]);
const v635=0.0;
const v636=({["value"]:v634,["tangent"]:v635});
const v637=v621["steps"];
v619[v620]=({["value"]:v624,["first"]:v627,["second"]:v630,["first_power"]:v633,["second_power"]:v636,["steps"]:v637});
}
const v638=v613.length;
const v639=new Array(v638);
for(let v640=0;v640<v638;v640++){
const v641=v613[v640];
const v642=__nfValue(v641);
const v643=0.0;
v639[v640]=({["value"]:v642,["tangent"]:v643});
}
const v644=v614.length;
const v645=new Array(v644);
for(let v646=0;v646<v644;v646++){
const v647=v614[v646];
const v648=__nfValue(v647);
const v649=0.0;
v645[v646]=({["value"]:v648,["tangent"]:v649});
}
const v653=0;
const v654=({["value"]:v610,["tangent"]:v616});
const v655=10;
const v656=(((v653) + (v655)) >>> 0);
const v657=__fn22(v654,v611,v619,v656);
let v658=v657["value"];
let v659=v657["tangent"];
for(let v661=0;v661<10;v661++){
const v662=(v661>>>0);
const v663=({["value"]:v658,["tangent"]:v659});
const v664=({["value"]:v610,["tangent"]:v616});
const v665=(((v653) + (v662)) >>> 0);
const v666=__fn22(v664,v611,v619,v665);
const v667=10;
const v668=(Math.imul(v615,v667) >>> 0);
const v669=(((v668) + (v662)) >>> 0);
let v670;if(v669<v639.length){v670=v639[v669];}else{
const v671=0.0;
const v672=0.0;
v670=({["value"]:v671,["tangent"]:v672});}
const v673=v670;
const v674=__fn19(v666,v673);
const v675=__fn23(v663,v674);
v658=v675["value"];
v659=v675["tangent"];
}
const v678=11;
const v679=({["value"]:v610,["tangent"]:v616});
const v680=10;
const v681=(((v678) + (v680)) >>> 0);
const v682=__fn22(v679,v611,v619,v681);
let v683=v682["value"];
let v684=v682["tangent"];
for(let v686=0;v686<10;v686++){
const v687=(v686>>>0);
const v688=({["value"]:v683,["tangent"]:v684});
const v689=({["value"]:v610,["tangent"]:v616});
const v690=(((v678) + (v687)) >>> 0);
const v691=__fn22(v689,v611,v619,v690);
const v692=10;
const v693=(Math.imul(v615,v692) >>> 0);
const v694=(((v693) + (v687)) >>> 0);
let v695;if(v694<v639.length){v695=v639[v694];}else{
const v696=0.0;
const v697=0.0;
v695=({["value"]:v696,["tangent"]:v697});}
const v698=v695;
const v699=__fn19(v691,v698);
const v700=__fn23(v688,v699);
v683=v700["value"];
v684=v700["tangent"];
}
const v702=__nfValue(v683);
const v703=0.0;
const v704=0.0;
const v705=({["value"]:v703,["tangent"]:v704});
const v706=__nfValue(v705["value"]);
let v707;
let v708;
if(((__nfNumber(v702)) > (__nfNumber(v706)))){
const v709=({["value"]:v658,["tangent"]:v659});
const v710=({["value"]:v683,["tangent"]:v684});
const v711=__fn19(v709,v710);
v707=v711["value"];
v708=v711["tangent"];
}else{
const v712=0.0;
const v713=0.0;
v707=v712;
v708=v713;
}
const v714=({["value"]:v707,["tangent"]:v708});
const v716=22;
const v717=({["value"]:v610,["tangent"]:v616});
const v718=10;
const v719=(((v716) + (v718)) >>> 0);
const v720=__fn22(v717,v611,v619,v719);
let v721=v720["value"];
let v722=v720["tangent"];
for(let v724=0;v724<10;v724++){
const v725=(v724>>>0);
const v726=({["value"]:v721,["tangent"]:v722});
const v727=({["value"]:v610,["tangent"]:v616});
const v728=(((v716) + (v725)) >>> 0);
const v729=__fn22(v727,v611,v619,v728);
const v730=10;
const v731=(Math.imul(v615,v730) >>> 0);
const v732=(((v731) + (v725)) >>> 0);
let v733;if(v732<v639.length){v733=v639[v732];}else{
const v734=0.0;
const v735=0.0;
v733=({["value"]:v734,["tangent"]:v735});}
const v736=v733;
const v737=__fn19(v729,v736);
const v738=__fn23(v726,v737);
v721=v738["value"];
v722=v738["tangent"];
}
const v741=33;
const v742=({["value"]:v610,["tangent"]:v616});
const v743=10;
const v744=(((v741) + (v743)) >>> 0);
const v745=__fn22(v742,v611,v619,v744);
let v746=v745["value"];
let v747=v745["tangent"];
for(let v749=0;v749<10;v749++){
const v750=(v749>>>0);
const v751=({["value"]:v746,["tangent"]:v747});
const v752=({["value"]:v610,["tangent"]:v616});
const v753=(((v741) + (v750)) >>> 0);
const v754=__fn22(v752,v611,v619,v753);
const v755=10;
const v756=(Math.imul(v615,v755) >>> 0);
const v757=(((v756) + (v750)) >>> 0);
let v758;if(v757<v639.length){v758=v639[v757];}else{
const v759=0.0;
const v760=0.0;
v758=({["value"]:v759,["tangent"]:v760});}
const v761=v758;
const v762=__fn19(v754,v761);
const v763=__fn23(v751,v762);
v746=v763["value"];
v747=v763["tangent"];
}
const v765=__nfValue(v746);
const v766=0.0;
const v767=0.0;
const v768=({["value"]:v766,["tangent"]:v767});
const v769=__nfValue(v768["value"]);
let v770;
let v771;
if(((__nfNumber(v765)) > (__nfNumber(v769)))){
const v772=({["value"]:v721,["tangent"]:v722});
const v773=({["value"]:v746,["tangent"]:v747});
const v774=__fn19(v772,v773);
v770=v774["value"];
v771=v774["tangent"];
}else{
const v775=0.0;
const v776=0.0;
v770=v775;
v771=v776;
}
const v777=({["value"]:v770,["tangent"]:v771});
const v779=44;
const v780=({["value"]:v610,["tangent"]:v616});
const v781=10;
const v782=(((v779) + (v781)) >>> 0);
const v783=__fn22(v780,v611,v619,v782);
let v784=v783["value"];
let v785=v783["tangent"];
for(let v787=0;v787<10;v787++){
const v788=(v787>>>0);
const v789=({["value"]:v784,["tangent"]:v785});
const v790=({["value"]:v610,["tangent"]:v616});
const v791=(((v779) + (v788)) >>> 0);
const v792=__fn22(v790,v611,v619,v791);
const v793=10;
const v794=(Math.imul(v615,v793) >>> 0);
const v795=(((v794) + (v788)) >>> 0);
let v796;if(v795<v639.length){v796=v639[v795];}else{
const v797=0.0;
const v798=0.0;
v796=({["value"]:v797,["tangent"]:v798});}
const v799=v796;
const v800=__fn19(v792,v799);
const v801=__fn23(v789,v800);
v784=v801["value"];
v785=v801["tangent"];
}
const v804=55;
const v805=({["value"]:v610,["tangent"]:v616});
const v806=10;
const v807=(((v804) + (v806)) >>> 0);
const v808=__fn22(v805,v611,v619,v807);
let v809=v808["value"];
let v810=v808["tangent"];
for(let v812=0;v812<10;v812++){
const v813=(v812>>>0);
const v814=({["value"]:v809,["tangent"]:v810});
const v815=({["value"]:v610,["tangent"]:v616});
const v816=(((v804) + (v813)) >>> 0);
const v817=__fn22(v815,v611,v619,v816);
const v818=10;
const v819=(Math.imul(v615,v818) >>> 0);
const v820=(((v819) + (v813)) >>> 0);
let v821;if(v820<v639.length){v821=v639[v820];}else{
const v822=0.0;
const v823=0.0;
v821=({["value"]:v822,["tangent"]:v823});}
const v824=v821;
const v825=__fn19(v817,v824);
const v826=__fn23(v814,v825);
v809=v826["value"];
v810=v826["tangent"];
}
const v828=__nfValue(v809);
const v829=0.0;
const v830=0.0;
const v831=({["value"]:v829,["tangent"]:v830});
const v832=__nfValue(v831["value"]);
let v833;
let v834;
if(((__nfNumber(v828)) > (__nfNumber(v832)))){
const v835=({["value"]:v784,["tangent"]:v785});
const v836=({["value"]:v809,["tangent"]:v810});
const v837=__fn19(v835,v836);
v833=v837["value"];
v834=v837["tangent"];
}else{
const v838=0.0;
const v839=0.0;
v833=v838;
v834=v839;
}
const v840=({["value"]:v833,["tangent"]:v834});
const v842=66;
const v843=({["value"]:v610,["tangent"]:v616});
const v844=10;
const v845=(((v842) + (v844)) >>> 0);
const v846=__fn22(v843,v611,v619,v845);
let v847=v846["value"];
let v848=v846["tangent"];
for(let v850=0;v850<10;v850++){
const v851=(v850>>>0);
const v852=({["value"]:v847,["tangent"]:v848});
const v853=({["value"]:v610,["tangent"]:v616});
const v854=(((v842) + (v851)) >>> 0);
const v855=__fn22(v853,v611,v619,v854);
const v856=10;
const v857=(Math.imul(v615,v856) >>> 0);
const v858=(((v857) + (v851)) >>> 0);
let v859;if(v858<v639.length){v859=v639[v858];}else{
const v860=0.0;
const v861=0.0;
v859=({["value"]:v860,["tangent"]:v861});}
const v862=v859;
const v863=__fn19(v855,v862);
const v864=__fn23(v852,v863);
v847=v864["value"];
v848=v864["tangent"];
}
const v867=77;
const v868=({["value"]:v610,["tangent"]:v616});
const v869=10;
const v870=(((v867) + (v869)) >>> 0);
const v871=__fn22(v868,v611,v619,v870);
let v872=v871["value"];
let v873=v871["tangent"];
for(let v875=0;v875<10;v875++){
const v876=(v875>>>0);
const v877=({["value"]:v872,["tangent"]:v873});
const v878=({["value"]:v610,["tangent"]:v616});
const v879=(((v867) + (v876)) >>> 0);
const v880=__fn22(v878,v611,v619,v879);
const v881=10;
const v882=(Math.imul(v615,v881) >>> 0);
const v883=(((v882) + (v876)) >>> 0);
let v884;if(v883<v639.length){v884=v639[v883];}else{
const v885=0.0;
const v886=0.0;
v884=({["value"]:v885,["tangent"]:v886});}
const v887=v884;
const v888=__fn19(v880,v887);
const v889=__fn23(v877,v888);
v872=v889["value"];
v873=v889["tangent"];
}
const v891=__nfValue(v872);
const v892=0.0;
const v893=0.0;
const v894=({["value"]:v892,["tangent"]:v893});
const v895=__nfValue(v894["value"]);
let v896;
let v897;
if(((__nfNumber(v891)) > (__nfNumber(v895)))){
const v898=({["value"]:v847,["tangent"]:v848});
const v899=({["value"]:v872,["tangent"]:v873});
const v900=__fn19(v898,v899);
v896=v900["value"];
v897=v900["tangent"];
}else{
const v901=0.0;
const v902=0.0;
v896=v901;
v897=v902;
}
const v903=({["value"]:v896,["tangent"]:v897});
const v905=88;
const v906=({["value"]:v610,["tangent"]:v616});
const v907=10;
const v908=(((v905) + (v907)) >>> 0);
const v909=__fn22(v906,v611,v619,v908);
let v910=v909["value"];
let v911=v909["tangent"];
for(let v913=0;v913<10;v913++){
const v914=(v913>>>0);
const v915=({["value"]:v910,["tangent"]:v911});
const v916=({["value"]:v610,["tangent"]:v616});
const v917=(((v905) + (v914)) >>> 0);
const v918=__fn22(v916,v611,v619,v917);
const v919=10;
const v920=(Math.imul(v615,v919) >>> 0);
const v921=(((v920) + (v914)) >>> 0);
let v922;if(v921<v639.length){v922=v639[v921];}else{
const v923=0.0;
const v924=0.0;
v922=({["value"]:v923,["tangent"]:v924});}
const v925=v922;
const v926=__fn19(v918,v925);
const v927=__fn23(v915,v926);
v910=v927["value"];
v911=v927["tangent"];
}
const v930=99;
const v931=({["value"]:v610,["tangent"]:v616});
const v932=10;
const v933=(((v930) + (v932)) >>> 0);
const v934=__fn22(v931,v611,v619,v933);
let v935=v934["value"];
let v936=v934["tangent"];
for(let v938=0;v938<10;v938++){
const v939=(v938>>>0);
const v940=({["value"]:v935,["tangent"]:v936});
const v941=({["value"]:v610,["tangent"]:v616});
const v942=(((v930) + (v939)) >>> 0);
const v943=__fn22(v941,v611,v619,v942);
const v944=10;
const v945=(Math.imul(v615,v944) >>> 0);
const v946=(((v945) + (v939)) >>> 0);
let v947;if(v946<v639.length){v947=v639[v946];}else{
const v948=0.0;
const v949=0.0;
v947=({["value"]:v948,["tangent"]:v949});}
const v950=v947;
const v951=__fn19(v943,v950);
const v952=__fn23(v940,v951);
v935=v952["value"];
v936=v952["tangent"];
}
const v954=__nfValue(v935);
const v955=0.0;
const v956=0.0;
const v957=({["value"]:v955,["tangent"]:v956});
const v958=__nfValue(v957["value"]);
let v959;
let v960;
if(((__nfNumber(v954)) > (__nfNumber(v958)))){
const v961=({["value"]:v910,["tangent"]:v911});
const v962=({["value"]:v935,["tangent"]:v936});
const v963=__fn19(v961,v962);
v959=v963["value"];
v960=v963["tangent"];
}else{
const v964=0.0;
const v965=0.0;
v959=v964;
v960=v965;
}
const v966=({["value"]:v959,["tangent"]:v960});
const v968=110;
const v969=({["value"]:v610,["tangent"]:v616});
const v970=10;
const v971=(((v968) + (v970)) >>> 0);
const v972=__fn22(v969,v611,v619,v971);
let v973=v972["value"];
let v974=v972["tangent"];
for(let v976=0;v976<10;v976++){
const v977=(v976>>>0);
const v978=({["value"]:v973,["tangent"]:v974});
const v979=({["value"]:v610,["tangent"]:v616});
const v980=(((v968) + (v977)) >>> 0);
const v981=__fn22(v979,v611,v619,v980);
const v982=10;
const v983=(Math.imul(v615,v982) >>> 0);
const v984=(((v983) + (v977)) >>> 0);
let v985;if(v984<v639.length){v985=v639[v984];}else{
const v986=0.0;
const v987=0.0;
v985=({["value"]:v986,["tangent"]:v987});}
const v988=v985;
const v989=__fn19(v981,v988);
const v990=__fn23(v978,v989);
v973=v990["value"];
v974=v990["tangent"];
}
const v993=121;
const v994=({["value"]:v610,["tangent"]:v616});
const v995=10;
const v996=(((v993) + (v995)) >>> 0);
const v997=__fn22(v994,v611,v619,v996);
let v998=v997["value"];
let v999=v997["tangent"];
for(let v1001=0;v1001<10;v1001++){
const v1002=(v1001>>>0);
const v1003=({["value"]:v998,["tangent"]:v999});
const v1004=({["value"]:v610,["tangent"]:v616});
const v1005=(((v993) + (v1002)) >>> 0);
const v1006=__fn22(v1004,v611,v619,v1005);
const v1007=10;
const v1008=(Math.imul(v615,v1007) >>> 0);
const v1009=(((v1008) + (v1002)) >>> 0);
let v1010;if(v1009<v639.length){v1010=v639[v1009];}else{
const v1011=0.0;
const v1012=0.0;
v1010=({["value"]:v1011,["tangent"]:v1012});}
const v1013=v1010;
const v1014=__fn19(v1006,v1013);
const v1015=__fn23(v1003,v1014);
v998=v1015["value"];
v999=v1015["tangent"];
}
const v1017=__nfValue(v998);
const v1018=0.0;
const v1019=0.0;
const v1020=({["value"]:v1018,["tangent"]:v1019});
const v1021=__nfValue(v1020["value"]);
let v1022;
let v1023;
if(((__nfNumber(v1017)) > (__nfNumber(v1021)))){
const v1024=({["value"]:v973,["tangent"]:v974});
const v1025=({["value"]:v998,["tangent"]:v999});
const v1026=__fn19(v1024,v1025);
v1022=v1026["value"];
v1023=v1026["tangent"];
}else{
const v1027=0.0;
const v1028=0.0;
v1022=v1027;
v1023=v1028;
}
const v1029=({["value"]:v1022,["tangent"]:v1023});
const v1030=[v714,v777,v840,v903,v966,v1029];
const v1033=132;
const v1034=({["value"]:v610,["tangent"]:v616});
const v1035=6;
const v1036=(((v1033) + (v1035)) >>> 0);
const v1037=__fn22(v1034,v611,v619,v1036);
let v1038=v1037["value"];
let v1039=v1037["tangent"];
for(let v1041=0;v1041<6;v1041++){
const v1042=(v1041>>>0);
const v1043=({["value"]:v1038,["tangent"]:v1039});
const v1044=({["value"]:v610,["tangent"]:v616});
const v1045=(((v1033) + (v1042)) >>> 0);
const v1046=__fn22(v1044,v611,v619,v1045);
let v1047;if(v1042<v1030.length){v1047=v1030[v1042];}else{
const v1048=0.0;
const v1049=0.0;
v1047=({["value"]:v1048,["tangent"]:v1049});}
const v1050=v1047;
const v1051=__fn19(v1046,v1050);
const v1052=__fn23(v1043,v1051);
v1038=v1052["value"];
v1039=v1052["tangent"];
}
const v1055=139;
const v1056=({["value"]:v610,["tangent"]:v616});
const v1057=6;
const v1058=(((v1055) + (v1057)) >>> 0);
const v1059=__fn22(v1056,v611,v619,v1058);
let v1060=v1059["value"];
let v1061=v1059["tangent"];
for(let v1063=0;v1063<6;v1063++){
const v1064=(v1063>>>0);
const v1065=({["value"]:v1060,["tangent"]:v1061});
const v1066=({["value"]:v610,["tangent"]:v616});
const v1067=(((v1055) + (v1064)) >>> 0);
const v1068=__fn22(v1066,v611,v619,v1067);
let v1069;if(v1064<v1030.length){v1069=v1030[v1064];}else{
const v1070=0.0;
const v1071=0.0;
v1069=({["value"]:v1070,["tangent"]:v1071});}
const v1072=v1069;
const v1073=__fn19(v1068,v1072);
const v1074=__fn23(v1065,v1073);
v1060=v1074["value"];
v1061=v1074["tangent"];
}
const v1076=__nfValue(v1060);
const v1077=0.0;
const v1078=0.0;
const v1079=({["value"]:v1077,["tangent"]:v1078});
const v1080=__nfValue(v1079["value"]);
let v1081;
let v1082;
if(((__nfNumber(v1076)) > (__nfNumber(v1080)))){
const v1083=({["value"]:v1038,["tangent"]:v1039});
const v1084=({["value"]:v1060,["tangent"]:v1061});
const v1085=__fn19(v1083,v1084);
v1081=v1085["value"];
v1082=v1085["tangent"];
}else{
const v1086=0.0;
const v1087=0.0;
v1081=v1086;
v1082=v1087;
}
const v1088=({["value"]:v1081,["tangent"]:v1082});
const v1090=146;
const v1091=({["value"]:v610,["tangent"]:v616});
const v1092=6;
const v1093=(((v1090) + (v1092)) >>> 0);
const v1094=__fn22(v1091,v611,v619,v1093);
let v1095=v1094["value"];
let v1096=v1094["tangent"];
for(let v1098=0;v1098<6;v1098++){
const v1099=(v1098>>>0);
const v1100=({["value"]:v1095,["tangent"]:v1096});
const v1101=({["value"]:v610,["tangent"]:v616});
const v1102=(((v1090) + (v1099)) >>> 0);
const v1103=__fn22(v1101,v611,v619,v1102);
let v1104;if(v1099<v1030.length){v1104=v1030[v1099];}else{
const v1105=0.0;
const v1106=0.0;
v1104=({["value"]:v1105,["tangent"]:v1106});}
const v1107=v1104;
const v1108=__fn19(v1103,v1107);
const v1109=__fn23(v1100,v1108);
v1095=v1109["value"];
v1096=v1109["tangent"];
}
const v1112=153;
const v1113=({["value"]:v610,["tangent"]:v616});
const v1114=6;
const v1115=(((v1112) + (v1114)) >>> 0);
const v1116=__fn22(v1113,v611,v619,v1115);
let v1117=v1116["value"];
let v1118=v1116["tangent"];
for(let v1120=0;v1120<6;v1120++){
const v1121=(v1120>>>0);
const v1122=({["value"]:v1117,["tangent"]:v1118});
const v1123=({["value"]:v610,["tangent"]:v616});
const v1124=(((v1112) + (v1121)) >>> 0);
const v1125=__fn22(v1123,v611,v619,v1124);
let v1126;if(v1121<v1030.length){v1126=v1030[v1121];}else{
const v1127=0.0;
const v1128=0.0;
v1126=({["value"]:v1127,["tangent"]:v1128});}
const v1129=v1126;
const v1130=__fn19(v1125,v1129);
const v1131=__fn23(v1122,v1130);
v1117=v1131["value"];
v1118=v1131["tangent"];
}
const v1133=__nfValue(v1117);
const v1134=0.0;
const v1135=0.0;
const v1136=({["value"]:v1134,["tangent"]:v1135});
const v1137=__nfValue(v1136["value"]);
let v1138;
let v1139;
if(((__nfNumber(v1133)) > (__nfNumber(v1137)))){
const v1140=({["value"]:v1095,["tangent"]:v1096});
const v1141=({["value"]:v1117,["tangent"]:v1118});
const v1142=__fn19(v1140,v1141);
v1138=v1142["value"];
v1139=v1142["tangent"];
}else{
const v1143=0.0;
const v1144=0.0;
v1138=v1143;
v1139=v1144;
}
const v1145=({["value"]:v1138,["tangent"]:v1139});
const v1147=160;
const v1148=({["value"]:v610,["tangent"]:v616});
const v1149=6;
const v1150=(((v1147) + (v1149)) >>> 0);
const v1151=__fn22(v1148,v611,v619,v1150);
let v1152=v1151["value"];
let v1153=v1151["tangent"];
for(let v1155=0;v1155<6;v1155++){
const v1156=(v1155>>>0);
const v1157=({["value"]:v1152,["tangent"]:v1153});
const v1158=({["value"]:v610,["tangent"]:v616});
const v1159=(((v1147) + (v1156)) >>> 0);
const v1160=__fn22(v1158,v611,v619,v1159);
let v1161;if(v1156<v1030.length){v1161=v1030[v1156];}else{
const v1162=0.0;
const v1163=0.0;
v1161=({["value"]:v1162,["tangent"]:v1163});}
const v1164=v1161;
const v1165=__fn19(v1160,v1164);
const v1166=__fn23(v1157,v1165);
v1152=v1166["value"];
v1153=v1166["tangent"];
}
const v1169=167;
const v1170=({["value"]:v610,["tangent"]:v616});
const v1171=6;
const v1172=(((v1169) + (v1171)) >>> 0);
const v1173=__fn22(v1170,v611,v619,v1172);
let v1174=v1173["value"];
let v1175=v1173["tangent"];
for(let v1177=0;v1177<6;v1177++){
const v1178=(v1177>>>0);
const v1179=({["value"]:v1174,["tangent"]:v1175});
const v1180=({["value"]:v610,["tangent"]:v616});
const v1181=(((v1169) + (v1178)) >>> 0);
const v1182=__fn22(v1180,v611,v619,v1181);
let v1183;if(v1178<v1030.length){v1183=v1030[v1178];}else{
const v1184=0.0;
const v1185=0.0;
v1183=({["value"]:v1184,["tangent"]:v1185});}
const v1186=v1183;
const v1187=__fn19(v1182,v1186);
const v1188=__fn23(v1179,v1187);
v1174=v1188["value"];
v1175=v1188["tangent"];
}
const v1190=__nfValue(v1174);
const v1191=0.0;
const v1192=0.0;
const v1193=({["value"]:v1191,["tangent"]:v1192});
const v1194=__nfValue(v1193["value"]);
let v1195;
let v1196;
if(((__nfNumber(v1190)) > (__nfNumber(v1194)))){
const v1197=({["value"]:v1152,["tangent"]:v1153});
const v1198=({["value"]:v1174,["tangent"]:v1175});
const v1199=__fn19(v1197,v1198);
v1195=v1199["value"];
v1196=v1199["tangent"];
}else{
const v1200=0.0;
const v1201=0.0;
v1195=v1200;
v1196=v1201;
}
const v1202=({["value"]:v1195,["tangent"]:v1196});
const v1204=174;
const v1205=({["value"]:v610,["tangent"]:v616});
const v1206=6;
const v1207=(((v1204) + (v1206)) >>> 0);
const v1208=__fn22(v1205,v611,v619,v1207);
let v1209=v1208["value"];
let v1210=v1208["tangent"];
for(let v1212=0;v1212<6;v1212++){
const v1213=(v1212>>>0);
const v1214=({["value"]:v1209,["tangent"]:v1210});
const v1215=({["value"]:v610,["tangent"]:v616});
const v1216=(((v1204) + (v1213)) >>> 0);
const v1217=__fn22(v1215,v611,v619,v1216);
let v1218;if(v1213<v1030.length){v1218=v1030[v1213];}else{
const v1219=0.0;
const v1220=0.0;
v1218=({["value"]:v1219,["tangent"]:v1220});}
const v1221=v1218;
const v1222=__fn19(v1217,v1221);
const v1223=__fn23(v1214,v1222);
v1209=v1223["value"];
v1210=v1223["tangent"];
}
const v1226=181;
const v1227=({["value"]:v610,["tangent"]:v616});
const v1228=6;
const v1229=(((v1226) + (v1228)) >>> 0);
const v1230=__fn22(v1227,v611,v619,v1229);
let v1231=v1230["value"];
let v1232=v1230["tangent"];
for(let v1234=0;v1234<6;v1234++){
const v1235=(v1234>>>0);
const v1236=({["value"]:v1231,["tangent"]:v1232});
const v1237=({["value"]:v610,["tangent"]:v616});
const v1238=(((v1226) + (v1235)) >>> 0);
const v1239=__fn22(v1237,v611,v619,v1238);
let v1240;if(v1235<v1030.length){v1240=v1030[v1235];}else{
const v1241=0.0;
const v1242=0.0;
v1240=({["value"]:v1241,["tangent"]:v1242});}
const v1243=v1240;
const v1244=__fn19(v1239,v1243);
const v1245=__fn23(v1236,v1244);
v1231=v1245["value"];
v1232=v1245["tangent"];
}
const v1247=__nfValue(v1231);
const v1248=0.0;
const v1249=0.0;
const v1250=({["value"]:v1248,["tangent"]:v1249});
const v1251=__nfValue(v1250["value"]);
let v1252;
let v1253;
if(((__nfNumber(v1247)) > (__nfNumber(v1251)))){
const v1254=({["value"]:v1209,["tangent"]:v1210});
const v1255=({["value"]:v1231,["tangent"]:v1232});
const v1256=__fn19(v1254,v1255);
v1252=v1256["value"];
v1253=v1256["tangent"];
}else{
const v1257=0.0;
const v1258=0.0;
v1252=v1257;
v1253=v1258;
}
const v1259=({["value"]:v1252,["tangent"]:v1253});
const v1261=188;
const v1262=({["value"]:v610,["tangent"]:v616});
const v1263=6;
const v1264=(((v1261) + (v1263)) >>> 0);
const v1265=__fn22(v1262,v611,v619,v1264);
let v1266=v1265["value"];
let v1267=v1265["tangent"];
for(let v1269=0;v1269<6;v1269++){
const v1270=(v1269>>>0);
const v1271=({["value"]:v1266,["tangent"]:v1267});
const v1272=({["value"]:v610,["tangent"]:v616});
const v1273=(((v1261) + (v1270)) >>> 0);
const v1274=__fn22(v1272,v611,v619,v1273);
let v1275;if(v1270<v1030.length){v1275=v1030[v1270];}else{
const v1276=0.0;
const v1277=0.0;
v1275=({["value"]:v1276,["tangent"]:v1277});}
const v1278=v1275;
const v1279=__fn19(v1274,v1278);
const v1280=__fn23(v1271,v1279);
v1266=v1280["value"];
v1267=v1280["tangent"];
}
const v1283=195;
const v1284=({["value"]:v610,["tangent"]:v616});
const v1285=6;
const v1286=(((v1283) + (v1285)) >>> 0);
const v1287=__fn22(v1284,v611,v619,v1286);
let v1288=v1287["value"];
let v1289=v1287["tangent"];
for(let v1291=0;v1291<6;v1291++){
const v1292=(v1291>>>0);
const v1293=({["value"]:v1288,["tangent"]:v1289});
const v1294=({["value"]:v610,["tangent"]:v616});
const v1295=(((v1283) + (v1292)) >>> 0);
const v1296=__fn22(v1294,v611,v619,v1295);
let v1297;if(v1292<v1030.length){v1297=v1030[v1292];}else{
const v1298=0.0;
const v1299=0.0;
v1297=({["value"]:v1298,["tangent"]:v1299});}
const v1300=v1297;
const v1301=__fn19(v1296,v1300);
const v1302=__fn23(v1293,v1301);
v1288=v1302["value"];
v1289=v1302["tangent"];
}
const v1304=__nfValue(v1288);
const v1305=0.0;
const v1306=0.0;
const v1307=({["value"]:v1305,["tangent"]:v1306});
const v1308=__nfValue(v1307["value"]);
let v1309;
let v1310;
if(((__nfNumber(v1304)) > (__nfNumber(v1308)))){
const v1311=({["value"]:v1266,["tangent"]:v1267});
const v1312=({["value"]:v1288,["tangent"]:v1289});
const v1313=__fn19(v1311,v1312);
v1309=v1313["value"];
v1310=v1313["tangent"];
}else{
const v1314=0.0;
const v1315=0.0;
v1309=v1314;
v1310=v1315;
}
const v1316=({["value"]:v1309,["tangent"]:v1310});
const v1318=202;
const v1319=({["value"]:v610,["tangent"]:v616});
const v1320=6;
const v1321=(((v1318) + (v1320)) >>> 0);
const v1322=__fn22(v1319,v611,v619,v1321);
let v1323=v1322["value"];
let v1324=v1322["tangent"];
for(let v1326=0;v1326<6;v1326++){
const v1327=(v1326>>>0);
const v1328=({["value"]:v1323,["tangent"]:v1324});
const v1329=({["value"]:v610,["tangent"]:v616});
const v1330=(((v1318) + (v1327)) >>> 0);
const v1331=__fn22(v1329,v611,v619,v1330);
let v1332;if(v1327<v1030.length){v1332=v1030[v1327];}else{
const v1333=0.0;
const v1334=0.0;
v1332=({["value"]:v1333,["tangent"]:v1334});}
const v1335=v1332;
const v1336=__fn19(v1331,v1335);
const v1337=__fn23(v1328,v1336);
v1323=v1337["value"];
v1324=v1337["tangent"];
}
const v1340=209;
const v1341=({["value"]:v610,["tangent"]:v616});
const v1342=6;
const v1343=(((v1340) + (v1342)) >>> 0);
const v1344=__fn22(v1341,v611,v619,v1343);
let v1345=v1344["value"];
let v1346=v1344["tangent"];
for(let v1348=0;v1348<6;v1348++){
const v1349=(v1348>>>0);
const v1350=({["value"]:v1345,["tangent"]:v1346});
const v1351=({["value"]:v610,["tangent"]:v616});
const v1352=(((v1340) + (v1349)) >>> 0);
const v1353=__fn22(v1351,v611,v619,v1352);
let v1354;if(v1349<v1030.length){v1354=v1030[v1349];}else{
const v1355=0.0;
const v1356=0.0;
v1354=({["value"]:v1355,["tangent"]:v1356});}
const v1357=v1354;
const v1358=__fn19(v1353,v1357);
const v1359=__fn23(v1350,v1358);
v1345=v1359["value"];
v1346=v1359["tangent"];
}
const v1361=__nfValue(v1345);
const v1362=0.0;
const v1363=0.0;
const v1364=({["value"]:v1362,["tangent"]:v1363});
const v1365=__nfValue(v1364["value"]);
let v1366;
let v1367;
if(((__nfNumber(v1361)) > (__nfNumber(v1365)))){
const v1368=({["value"]:v1323,["tangent"]:v1324});
const v1369=({["value"]:v1345,["tangent"]:v1346});
const v1370=__fn19(v1368,v1369);
v1366=v1370["value"];
v1367=v1370["tangent"];
}else{
const v1371=0.0;
const v1372=0.0;
v1366=v1371;
v1367=v1372;
}
const v1373=({["value"]:v1366,["tangent"]:v1367});
const v1374=[v1088,v1145,v1202,v1259,v1316,v1373];
const v1376=216;
const v1378=6;
const v1379=(((v1376) + (v1378)) >>> 0);
let v1380;
let v1381;
if((v611===v1379)){
v1380=v610;
v1381=v616;
}else{
let v1382;if(v1379<v619.length){v1382=v619[v1379];}else{
v1382=__fn21();}
const v1383=v1382;
const v1384=v1383["value"];
v1380=v1384["value"];
v1381=v1384["tangent"];
}
let v1386=v1380;
let v1387=v1381;
for(let v1389=0;v1389<6;v1389++){
const v1390=(v1389>>>0);
const v1393=(((v1376) + (v1390)) >>> 0);
let v1394;
let v1395;
if((v611===v1393)){
v1394=v610;
v1395=v616;
}else{
let v1396;if(v1393<v619.length){v1396=v619[v1393];}else{
v1396=__fn21();}
const v1397=v1396;
const v1398=v1397["value"];
v1394=v1398["value"];
v1395=v1398["tangent"];
}
let v1400;if(v1390<v1374.length){v1400=v1374[v1390];}else{
const v1401=0.0;
const v1402=0.0;
v1400=({["value"]:v1401,["tangent"]:v1402});}
const v1403=v1400;
const v1404=__nfValue(v1394);
const v1405=__nfValue(v1403["value"]);
const v1406=Math.fround(__nfNumber(v1404) * __nfNumber(v1405));
const v1407=__nfValue(v1395);
const v1408=__nfValue(v1403["value"]);
const v1409=Math.fround(__nfNumber(v1407) * __nfNumber(v1408));
const v1410=__nfValue(v1394);
const v1411=__nfValue(v1403["tangent"]);
const v1412=Math.fround(__nfNumber(v1410) * __nfNumber(v1411));
const v1413=Math.fround(v1409 + v1412);
const v1415=__nfValue(v1386);
const v1416=Math.fround(__nfNumber(v1415) + v1406);
const v1417=__nfValue(v1387);
const v1418=Math.fround(__nfNumber(v1417) + v1413);
v1386=v1416;
v1387=v1418;
}
const v1419=({["value"]:v1386,["tangent"]:v1387});
const v1421=223;
const v1423=6;
const v1424=(((v1421) + (v1423)) >>> 0);
let v1425;
let v1426;
if((v611===v1424)){
v1425=v610;
v1426=v616;
}else{
let v1427;if(v1424<v619.length){v1427=v619[v1424];}else{
v1427=__fn21();}
const v1428=v1427;
const v1429=v1428["value"];
v1425=v1429["value"];
v1426=v1429["tangent"];
}
let v1431=v1425;
let v1432=v1426;
for(let v1434=0;v1434<6;v1434++){
const v1435=(v1434>>>0);
const v1438=(((v1421) + (v1435)) >>> 0);
let v1439;
let v1440;
if((v611===v1438)){
v1439=v610;
v1440=v616;
}else{
let v1441;if(v1438<v619.length){v1441=v619[v1438];}else{
v1441=__fn21();}
const v1442=v1441;
const v1443=v1442["value"];
v1439=v1443["value"];
v1440=v1443["tangent"];
}
let v1445;if(v1435<v1374.length){v1445=v1374[v1435];}else{
const v1446=0.0;
const v1447=0.0;
v1445=({["value"]:v1446,["tangent"]:v1447});}
const v1448=v1445;
const v1449=__nfValue(v1439);
const v1450=__nfValue(v1448["value"]);
const v1451=Math.fround(__nfNumber(v1449) * __nfNumber(v1450));
const v1452=__nfValue(v1440);
const v1453=__nfValue(v1448["value"]);
const v1454=Math.fround(__nfNumber(v1452) * __nfNumber(v1453));
const v1455=__nfValue(v1439);
const v1456=__nfValue(v1448["tangent"]);
const v1457=Math.fround(__nfNumber(v1455) * __nfNumber(v1456));
const v1458=Math.fround(v1454 + v1457);
const v1460=__nfValue(v1431);
const v1461=Math.fround(__nfNumber(v1460) + v1451);
const v1462=__nfValue(v1432);
const v1463=Math.fround(__nfNumber(v1462) + v1458);
v1431=v1461;
v1432=v1463;
}
const v1464=({["value"]:v1431,["tangent"]:v1432});
const v1466=230;
const v1468=6;
const v1469=(((v1466) + (v1468)) >>> 0);
let v1470;
let v1471;
if((v611===v1469)){
v1470=v610;
v1471=v616;
}else{
let v1472;if(v1469<v619.length){v1472=v619[v1469];}else{
v1472=__fn21();}
const v1473=v1472;
const v1474=v1473["value"];
v1470=v1474["value"];
v1471=v1474["tangent"];
}
let v1476=v1470;
let v1477=v1471;
for(let v1479=0;v1479<6;v1479++){
const v1480=(v1479>>>0);
const v1483=(((v1466) + (v1480)) >>> 0);
let v1484;
let v1485;
if((v611===v1483)){
v1484=v610;
v1485=v616;
}else{
let v1486;if(v1483<v619.length){v1486=v619[v1483];}else{
v1486=__fn21();}
const v1487=v1486;
const v1488=v1487["value"];
v1484=v1488["value"];
v1485=v1488["tangent"];
}
let v1490;if(v1480<v1374.length){v1490=v1374[v1480];}else{
const v1491=0.0;
const v1492=0.0;
v1490=({["value"]:v1491,["tangent"]:v1492});}
const v1493=v1490;
const v1494=__nfValue(v1484);
const v1495=__nfValue(v1493["value"]);
const v1496=Math.fround(__nfNumber(v1494) * __nfNumber(v1495));
const v1497=__nfValue(v1485);
const v1498=__nfValue(v1493["value"]);
const v1499=Math.fround(__nfNumber(v1497) * __nfNumber(v1498));
const v1500=__nfValue(v1484);
const v1501=__nfValue(v1493["tangent"]);
const v1502=Math.fround(__nfNumber(v1500) * __nfNumber(v1501));
const v1503=Math.fround(v1499 + v1502);
const v1505=__nfValue(v1476);
const v1506=Math.fround(__nfNumber(v1505) + v1496);
const v1507=__nfValue(v1477);
const v1508=Math.fround(__nfNumber(v1507) + v1503);
v1476=v1506;
v1477=v1508;
}
const v1509=({["value"]:v1476,["tangent"]:v1477});
const v1511=237;
const v1513=6;
const v1514=(((v1511) + (v1513)) >>> 0);
let v1515;
let v1516;
if((v611===v1514)){
v1515=v610;
v1516=v616;
}else{
let v1517;if(v1514<v619.length){v1517=v619[v1514];}else{
v1517=__fn21();}
const v1518=v1517;
const v1519=v1518["value"];
v1515=v1519["value"];
v1516=v1519["tangent"];
}
let v1521=v1515;
let v1522=v1516;
for(let v1524=0;v1524<6;v1524++){
const v1525=(v1524>>>0);
const v1528=(((v1511) + (v1525)) >>> 0);
let v1529;
let v1530;
if((v611===v1528)){
v1529=v610;
v1530=v616;
}else{
let v1531;if(v1528<v619.length){v1531=v619[v1528];}else{
v1531=__fn21();}
const v1532=v1531;
const v1533=v1532["value"];
v1529=v1533["value"];
v1530=v1533["tangent"];
}
let v1535;if(v1525<v1374.length){v1535=v1374[v1525];}else{
const v1536=0.0;
const v1537=0.0;
v1535=({["value"]:v1536,["tangent"]:v1537});}
const v1538=v1535;
const v1539=__nfValue(v1529);
const v1540=__nfValue(v1538["value"]);
const v1541=Math.fround(__nfNumber(v1539) * __nfNumber(v1540));
const v1542=__nfValue(v1530);
const v1543=__nfValue(v1538["value"]);
const v1544=Math.fround(__nfNumber(v1542) * __nfNumber(v1543));
const v1545=__nfValue(v1529);
const v1546=__nfValue(v1538["tangent"]);
const v1547=Math.fround(__nfNumber(v1545) * __nfNumber(v1546));
const v1548=Math.fround(v1544 + v1547);
const v1550=__nfValue(v1521);
const v1551=Math.fround(__nfNumber(v1550) + v1541);
const v1552=__nfValue(v1522);
const v1553=Math.fround(__nfNumber(v1552) + v1548);
v1521=v1551;
v1522=v1553;
}
const v1554=({["value"]:v1521,["tangent"]:v1522});
const v1555=[v1419,v1464,v1509,v1554];
const v1556=0.0;
const v1557=0.0;
let v1558=v1556;
let v1559=v1557;
for(let v1561=0;v1561<4;v1561++){
const v1562=(v1561>>>0);
let v1564;if(v1562<v1555.length){v1564=v1555[v1562];}else{
const v1565=0.0;
const v1566=0.0;
v1564=({["value"]:v1565,["tangent"]:v1566});}
const v1567=v1564;
const v1568=4;
const v1569=(Math.imul(v615,v1568) >>> 0);
const v1570=(((v1569) + (v1562)) >>> 0);
let v1571;if(v1570<v645.length){v1571=v645[v1570];}else{
const v1572=0.0;
const v1573=0.0;
v1571=({["value"]:v1572,["tangent"]:v1573});}
const v1574=v1571;
const v1575=__fn30(v1567,v1574);
const v1576=__nfValue(v1558);
const v1577=__nfValue(v1575["value"]);
const v1578=Math.fround(__nfNumber(v1576) + __nfNumber(v1577));
const v1579=__nfValue(v1559);
const v1580=__nfValue(v1575["tangent"]);
const v1581=Math.fround(__nfNumber(v1579) + __nfNumber(v1580));
v1558=v1578;
v1559=v1581;
}
const v1584=4.0;
const v1585=0.0;
const v1587=Math.fround((__nfNumber(__nfValue(v1558)))/(__nfNumber(v1584)));
const v1588=__nfValue(v1559);
const v1589=Math.fround(__nfNumber(v1588) * v1584);
const v1590=__nfValue(v1558);
const v1591=Math.fround(__nfNumber(v1590) * v1585);
const v1592=Math.fround((__nfNumber(Math.fround(v1589 - v1591)))/(__nfNumber(Math.fround(v1584 * v1584))));
return v1592;}
function __fn34(v1594,v1595){
const v1596=v1594["value"];
const v1597=v1595["value"];
const v1598=(__dfNumber(v1596) * __dfNumber(v1597));
const v1599=v1594["tangent"];
const v1600=v1595["value"];
const v1601=(__dfNumber(v1599) * __dfNumber(v1600));
const v1602=v1594["value"];
const v1603=v1595["tangent"];
const v1604=(__dfNumber(v1602) * __dfNumber(v1603));
const v1605=(__dfNumber(v1601) + __dfNumber(v1604));
return ({["value"]:v1598,["tangent"]:v1605});}
function __fn35(v1606){
return __fn34(v1606,v1606);}
function __fn36(v1607){
const v1608=1.0;
const v1612=(__dfNumber(v1607) * __dfNumber(v1607));
const v1613=(__dfNumber(v1608) * __dfNumber(v1607));
const v1614=(__dfNumber(v1607) * __dfNumber(v1608));
const v1615=(__dfNumber(v1613) + __dfNumber(v1614));
return v1615;}
function __into5(v1617,v1618,v1619,v1620,v1621,v1622){
v1617=__nfValue(v1617);
const v1623=0;
const v1624=__fn3(v1617,v1618,v1619,v1620,v1621,v1623);
const v1625=11;
const v1626=__fn3(v1617,v1618,v1619,v1620,v1621,v1625);
const v1627=__fn2(v1624,v1626);
const v1628=22;
const v1629=__fn3(v1617,v1618,v1619,v1620,v1621,v1628);
const v1630=33;
const v1631=__fn3(v1617,v1618,v1619,v1620,v1621,v1630);
const v1632=__fn2(v1629,v1631);
const v1633=44;
const v1634=__fn3(v1617,v1618,v1619,v1620,v1621,v1633);
const v1635=55;
const v1636=__fn3(v1617,v1618,v1619,v1620,v1621,v1635);
const v1637=__fn2(v1634,v1636);
const v1638=66;
const v1639=__fn3(v1617,v1618,v1619,v1620,v1621,v1638);
const v1640=77;
const v1641=__fn3(v1617,v1618,v1619,v1620,v1621,v1640);
const v1642=__fn2(v1639,v1641);
const v1643=88;
const v1644=__fn3(v1617,v1618,v1619,v1620,v1621,v1643);
const v1645=99;
const v1646=__fn3(v1617,v1618,v1619,v1620,v1621,v1645);
const v1647=__fn2(v1644,v1646);
const v1648=110;
const v1649=__fn3(v1617,v1618,v1619,v1620,v1621,v1648);
const v1650=121;
const v1651=__fn3(v1617,v1618,v1619,v1620,v1621,v1650);
const v1652=__fn2(v1649,v1651);
const v1653=[v1627,v1632,v1637,v1642,v1647,v1652];
const v1654=v1653.length;
for(let v1655=0;v1655<v1654;v1655++){
v1622[v1655]=__intoOutput5(v1653[v1655]);
}
return v1654;}
function __into6(v1656,v1657,v1658,v1659,v1660){
v1656=__nfValue(v1656);
const v1661=132;
const v1662=__fn4(v1656,v1657,v1658,v1659,v1661);
const v1663=139;
const v1664=__fn4(v1656,v1657,v1658,v1659,v1663);
const v1665=__fn2(v1662,v1664);
const v1666=146;
const v1667=__fn4(v1656,v1657,v1658,v1659,v1666);
const v1668=153;
const v1669=__fn4(v1656,v1657,v1658,v1659,v1668);
const v1670=__fn2(v1667,v1669);
const v1671=160;
const v1672=__fn4(v1656,v1657,v1658,v1659,v1671);
const v1673=167;
const v1674=__fn4(v1656,v1657,v1658,v1659,v1673);
const v1675=__fn2(v1672,v1674);
const v1676=174;
const v1677=__fn4(v1656,v1657,v1658,v1659,v1676);
const v1678=181;
const v1679=__fn4(v1656,v1657,v1658,v1659,v1678);
const v1680=__fn2(v1677,v1679);
const v1681=188;
const v1682=__fn4(v1656,v1657,v1658,v1659,v1681);
const v1683=195;
const v1684=__fn4(v1656,v1657,v1658,v1659,v1683);
const v1685=__fn2(v1682,v1684);
const v1686=202;
const v1687=__fn4(v1656,v1657,v1658,v1659,v1686);
const v1688=209;
const v1689=__fn4(v1656,v1657,v1658,v1659,v1688);
const v1690=__fn2(v1687,v1689);
const v1691=[v1665,v1670,v1675,v1680,v1685,v1690];
const v1692=v1691.length;
for(let v1693=0;v1693<v1692;v1693++){
v1660[v1693]=__intoOutput6(v1691[v1693]);
}
return v1692;}
function __into7(v1694,v1695,v1696,v1697,v1698,v1699){
v1694=__nfValue(v1694);
const v1700=__fn5(v1694,v1695,v1696,v1697,v1698);
const v1701=__fn6(v1694,v1695,v1696,v1700);
const v1702=216;
const v1703=__fn4(v1694,v1695,v1696,v1701,v1702);
const v1704=223;
const v1705=__fn4(v1694,v1695,v1696,v1701,v1704);
const v1706=230;
const v1707=__fn4(v1694,v1695,v1696,v1701,v1706);
const v1708=237;
const v1709=__fn4(v1694,v1695,v1696,v1701,v1708);
const v1710=[v1703,v1705,v1707,v1709];
const v1711=v1710.length;
for(let v1712=0;v1712<v1711;v1712++){
v1699[v1712]=__intoOutput7(v1710[v1712]);
}
return v1711;}
function __into10(v1713,v1714,v1715,v1716,v1717){
const v1718=(v1716).length;
const v1719=0;
let v1720;if((v1718===v1719)){
const v1721=v1713.length;
for(let v1723=0;v1723<v1721;v1723++){
const v1724=v1713[v1723];
v1717[v1723]=__intoOutput10(0.0);
}
v1720=v1721;}else{
const v1725=v1713.length;
for(let v1727=0;v1727<v1725;v1727++){
const v1728=v1713[v1727];
const v1729=(v1727>>>0);
let v1730=0.0;
for(let v1731=0;v1731<v1716.length;v1731++){
const v1732=(v1716[v1731]>>>0);
const v1733=v1730;
const v1734=__nfValue(v1728["value"]);
const v1735=__fn33(v1734,v1729,v1713,v1714,v1715,v1732);
v1730=Math.fround(__nfNumber(v1733) + __nfNumber(v1735));
}
v1717[v1727]=__intoOutput10(Math.fround((__nfNumber(v1730))/(__nfNumber(Math.fround((v1716).length)))));
}
v1720=v1725;}
return v1720;}
function __into15(v1736,v1737,v1738,v1739,v1740){
const v1741=false;
const v1742=(v1738===v1741);
let v1743=v1742;if(!v1743){
const v1744=__fn13(v1739);
const v1745=false;
v1743=(v1744===v1745);}
const v1746=v1743;
let v1747=v1746;if(!v1747){
const v1748=(v1737).length;
const v1749=(v1736).length;
v1747=!(v1748===v1749);}
const v1750=v1747;
let v1751=v1750;if(!v1751){
let v1752=true;
for(let v1753=0;v1753<v1736.length;v1753++){
const v1754=v1736[v1753];
const v1755=v1752;
let v1756=v1755;if(v1756){
v1756=__fn12(v1754);}
v1752=v1756;
}
const v1757=v1752;
const v1758=false;
v1751=(v1757===v1758);}
let v1759;if(v1751){
const v1760=v1736.length;
for(let v1761=0;v1761<v1760;v1761++){
v1740[v1761]=__intoOutput15(v1736[v1761]);
}
v1759=v1760;}else{
const v1762=v1736.length;
const v1763=new Array(v1762);
for(let v1764=0;v1764<v1762;v1764++){
const v1765=v1736[v1764];
const v1766=(v1764>>>0);
let v1767;if(v1766<v1737.length){v1767=v1737[v1766];}else{
v1767=0.0;}
const v1768=__nfValue(v1767);
v1763[v1764]=__fn11(v1765,v1768,v1739);
}
let v1769=true;
for(let v1770=0;v1770<v1763.length;v1770++){
const v1771=v1763[v1770];
const v1772=v1769;
let v1773=v1772;if(v1773){
v1773=__fn12(v1771);}
v1769=v1773;
}
let v1774;if(v1769){
const v1775=v1763.length;
for(let v1776=0;v1776<v1775;v1776++){
v1740[v1776]=__intoOutput15(v1763[v1776]);
}
v1774=v1775;}else{
const v1777=v1736.length;
for(let v1778=0;v1778<v1777;v1778++){
v1740[v1778]=__intoOutput15(v1736[v1778]);
}
v1774=v1777;}
v1759=v1774;}
return v1759;}
function __into16(v1779,v1780,v1781,v1782,v1783){
const v1784=v1782.length;
for(let v1786=0;v1786<v1784;v1786++){
const v1787=(v1782[v1786]>>>0);
const v1788=0.0;
const v1789=4294967295;
v1783[v1786]=__intoOutput16(__fn9(v1788,v1789,v1779,v1780,v1781,v1787));
}
return v1784;}
function __into25(v1790,v1791,v1792,v1793,v1794,v1795){
const v1796=0;
const v1797=__fn24(v1790,v1791,v1792,v1793,v1794,v1796);
const v1798=11;
const v1799=__fn24(v1790,v1791,v1792,v1793,v1794,v1798);
const v1800=__fn20(v1797,v1799);
const v1801=22;
const v1802=__fn24(v1790,v1791,v1792,v1793,v1794,v1801);
const v1803=33;
const v1804=__fn24(v1790,v1791,v1792,v1793,v1794,v1803);
const v1805=__fn20(v1802,v1804);
const v1806=44;
const v1807=__fn24(v1790,v1791,v1792,v1793,v1794,v1806);
const v1808=55;
const v1809=__fn24(v1790,v1791,v1792,v1793,v1794,v1808);
const v1810=__fn20(v1807,v1809);
const v1811=66;
const v1812=__fn24(v1790,v1791,v1792,v1793,v1794,v1811);
const v1813=77;
const v1814=__fn24(v1790,v1791,v1792,v1793,v1794,v1813);
const v1815=__fn20(v1812,v1814);
const v1816=88;
const v1817=__fn24(v1790,v1791,v1792,v1793,v1794,v1816);
const v1818=99;
const v1819=__fn24(v1790,v1791,v1792,v1793,v1794,v1818);
const v1820=__fn20(v1817,v1819);
const v1821=110;
const v1822=__fn24(v1790,v1791,v1792,v1793,v1794,v1821);
const v1823=121;
const v1824=__fn24(v1790,v1791,v1792,v1793,v1794,v1823);
const v1825=__fn20(v1822,v1824);
const v1826=[v1800,v1805,v1810,v1815,v1820,v1825];
const v1827=v1826.length;
for(let v1828=0;v1828<v1827;v1828++){
v1795[v1828]=__intoOutput25(v1826[v1828]);
}
return v1827;}
function __into27(v1829,v1830,v1831,v1832,v1833){
const v1834=132;
const v1835=__fn26(v1829,v1830,v1831,v1832,v1834);
const v1836=139;
const v1837=__fn26(v1829,v1830,v1831,v1832,v1836);
const v1838=__fn20(v1835,v1837);
const v1839=146;
const v1840=__fn26(v1829,v1830,v1831,v1832,v1839);
const v1841=153;
const v1842=__fn26(v1829,v1830,v1831,v1832,v1841);
const v1843=__fn20(v1840,v1842);
const v1844=160;
const v1845=__fn26(v1829,v1830,v1831,v1832,v1844);
const v1846=167;
const v1847=__fn26(v1829,v1830,v1831,v1832,v1846);
const v1848=__fn20(v1845,v1847);
const v1849=174;
const v1850=__fn26(v1829,v1830,v1831,v1832,v1849);
const v1851=181;
const v1852=__fn26(v1829,v1830,v1831,v1832,v1851);
const v1853=__fn20(v1850,v1852);
const v1854=188;
const v1855=__fn26(v1829,v1830,v1831,v1832,v1854);
const v1856=195;
const v1857=__fn26(v1829,v1830,v1831,v1832,v1856);
const v1858=__fn20(v1855,v1857);
const v1859=202;
const v1860=__fn26(v1829,v1830,v1831,v1832,v1859);
const v1861=209;
const v1862=__fn26(v1829,v1830,v1831,v1832,v1861);
const v1863=__fn20(v1860,v1862);
const v1864=[v1838,v1843,v1848,v1853,v1858,v1863];
const v1865=v1864.length;
for(let v1866=0;v1866<v1865;v1866++){
v1833[v1866]=__intoOutput27(v1864[v1866]);
}
return v1865;}
function __into28(v1867,v1868,v1869,v1870,v1871,v1872){
const v1873=__fn25(v1867,v1868,v1869,v1870,v1871);
const v1874=__fn27(v1867,v1868,v1869,v1873);
const v1875=216;
const v1876=__fn26(v1867,v1868,v1869,v1874,v1875);
const v1877=223;
const v1878=__fn26(v1867,v1868,v1869,v1874,v1877);
const v1879=230;
const v1880=__fn26(v1867,v1868,v1869,v1874,v1879);
const v1881=237;
const v1882=__fn26(v1867,v1868,v1869,v1874,v1881);
const v1883=[v1876,v1878,v1880,v1882];
const v1884=v1883.length;
for(let v1885=0;v1885<v1884;v1885++){
v1872[v1885]=__intoOutput28(v1883[v1885]);
}
return v1884;}
const __namedTypes={"Config":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"},"HostObservations":{"fields":[{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"HostObservations"},"Parameter":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"__ink_differential64_0":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"},"__ink_differential_0":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"__ink_differential_3":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"}};
export const metadata = {"abi":"ink-javascript-trusted-values-v2","backend":"javascript","core_semantics":"ink-executable-core-v15","core_sha256":"4f82a7ca1752c02dc087d0be59fb96bde9b83c5ad1354a265b9b057000fbdeb3","destination_abi":{"aliasing":"destination-disjoint-from-all-reachable-inputs","capacity":"trusted","count_unit":"elements","name":"ink-javascript-into-v1","ownership":"caller-owned","tail":"unwritten"},"f32_storage":"native-number-with-exact-nonfinite-tags","functions":[{"destination":null,"index":0,"internal":false,"name":"empty_parameter","parallel":false,"params":[],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}},{"destination":null,"index":1,"internal":false,"name":"parameter","parallel":false,"params":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"index","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":2,"internal":false,"name":"reglu","parallel":false,"params":[{"name":"value","type":{"kind":"f32"}},{"name":"gate","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":3,"internal":false,"name":"dot10","parallel":false,"params":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}},{"name":"base","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":4,"internal":false,"name":"dot6","parallel":false,"params":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"inputs","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"base","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":5,"internal":false,"name":"first_layer","parallel":false,"params":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":6,"internal":false,"name":"second_layer","parallel":false,"params":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"inputs","type":{"element":{"kind":"f32"},"kind":"list"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":7,"internal":false,"name":"outputs","parallel":false,"params":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":8,"internal":false,"name":"squared_error","parallel":false,"params":[{"name":"prediction","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":9,"internal":false,"name":"objective","parallel":false,"params":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":10,"internal":false,"name":"gradients","parallel":false,"params":[{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"rows","type":{"element":{"kind":"u32"},"kind":"list"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":11,"internal":false,"name":"candidate","parallel":false,"params":[{"name":"p","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}},{"name":"g","type":{"kind":"f32"}},{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}},{"destination":null,"index":12,"internal":false,"name":"valid","parallel":false,"params":[{"name":"p","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":null,"index":13,"internal":false,"name":"configuration","parallel":false,"params":[{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":null,"index":14,"internal":false,"name":"shape","parallel":false,"params":[{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"rows","type":{"element":{"kind":"u32"},"kind":"list"}}],"precondition":null,"result":{"kind":"bool"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":15,"internal":false,"name":"update","parallel":false,"params":[{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"admissible","type":{"kind":"bool"}},{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}}],"precondition":null,"result":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":16,"internal":false,"name":"losses","parallel":false,"params":[{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"rows","type":{"element":{"kind":"u32"},"kind":"list"}}],"precondition":null,"result":{"element":{"kind":"f32"},"kind":"list"}},{"destination":null,"index":17,"internal":false,"name":"precise_square","parallel":false,"params":[{"name":"x","type":{"kind":"f64"}}],"precondition":null,"result":{"kind":"f64"}},{"destination":null,"index":18,"internal":false,"name":"precise_gradient","parallel":false,"params":[{"name":"x","type":{"kind":"f64"}}],"precondition":null,"result":{"kind":"f64"}},{"destination":null,"index":19,"internal":false,"name":"__ink_differential_7","parallel":false,"params":[{"name":"__ink_differential_8","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_9","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":20,"internal":false,"name":"__ink_differential_6","parallel":false,"params":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"gate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":21,"internal":false,"name":"__ink_differential_13","parallel":false,"params":[],"precondition":null,"result":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"}},{"destination":null,"index":22,"internal":false,"name":"__ink_differential_12","parallel":false,"params":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"index","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":23,"internal":false,"name":"__ink_differential_14","parallel":false,"params":[{"name":"__ink_differential_15","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_16","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":24,"internal":false,"name":"__ink_differential_11","parallel":false,"params":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}},{"name":"base","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":25,"internal":false,"name":"__ink_differential_5","parallel":false,"params":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"destination":null,"index":26,"internal":false,"name":"__ink_differential_19","parallel":false,"params":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"inputs","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"base","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":27,"internal":false,"name":"__ink_differential_18","parallel":false,"params":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"inputs","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}}],"precondition":null,"result":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"destination":{"abi":"ink-javascript-into-v1","count_unit":"elements","ownership":"caller-owned"},"index":28,"internal":false,"name":"__ink_differential_4","parallel":false,"params":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"precondition":null,"result":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"destination":null,"index":29,"internal":false,"name":"__ink_differential_21","parallel":false,"params":[{"name":"__ink_differential_22","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_23","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":30,"internal":false,"name":"__ink_differential_20","parallel":false,"params":[{"name":"prediction","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":31,"internal":false,"name":"__ink_differential_25","parallel":false,"params":[{"name":"__ink_differential_26","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_27","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":32,"internal":false,"name":"__ink_differential_2","parallel":false,"params":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"targets","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"destination":null,"index":33,"internal":false,"name":"__ink_differential_1","parallel":false,"params":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"precondition":null,"result":{"kind":"f32"}},{"destination":null,"index":34,"internal":false,"name":"__ink_differential64_3","parallel":false,"params":[{"name":"__ink_differential64_4","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"__ink_differential64_5","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"destination":null,"index":35,"internal":false,"name":"__ink_differential64_2","parallel":false,"params":[{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"precondition":null,"result":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"destination":null,"index":36,"internal":false,"name":"__ink_differential64_1","parallel":false,"params":[{"name":"x","type":{"kind":"f64"}}],"precondition":null,"result":{"kind":"f64"}}],"named_types":{"Config":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"},"HostObservations":{"fields":[{"name":"values","type":{"element":{"kind":"f64"},"kind":"list"}}],"kind":"record","name":"HostObservations"},"Parameter":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"__ink_differential64_0":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"},"__ink_differential_0":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"__ink_differential_3":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"}},"prepared_compiled":{"evaluation":"lazy source-order; successful bindings only","functions":[{"factory":false,"function":"empty_parameter","reason":"no reusable captured work"},{"factory":false,"function":"parameter","reason":"no reusable captured work"},{"factory":false,"function":"reglu","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"dot10","retained_bindings":1},{"delegated_calls":0,"factory":true,"function":"dot6","retained_bindings":1},{"delegated_calls":12,"factory":true,"function":"first_layer","retained_bindings":0},{"delegated_calls":12,"factory":true,"function":"second_layer","retained_bindings":0},{"delegated_calls":6,"factory":true,"function":"outputs","retained_bindings":2},{"factory":false,"function":"squared_error","reason":"no reusable captured work"},{"delegated_calls":1,"factory":true,"function":"objective","retained_bindings":1},{"factory":false,"function":"gradients","reason":"no reusable captured work"},{"factory":false,"function":"candidate","reason":"no reusable captured work"},{"factory":false,"function":"valid","reason":"no reusable captured work"},{"factory":false,"function":"configuration","reason":"no reusable captured work"},{"factory":false,"function":"shape","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"update","retained_bindings":3},{"delegated_calls":1,"factory":true,"function":"losses","retained_bindings":0},{"factory":false,"function":"precise_square","reason":"no reusable captured work"},{"factory":false,"function":"precise_gradient","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_7","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_6","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_13","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_12","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_14","reason":"no reusable captured work"},{"delegated_calls":0,"factory":true,"function":"__ink_differential_11","retained_bindings":1},{"delegated_calls":12,"factory":true,"function":"__ink_differential_5","retained_bindings":0},{"delegated_calls":0,"factory":true,"function":"__ink_differential_19","retained_bindings":1},{"delegated_calls":12,"factory":true,"function":"__ink_differential_18","retained_bindings":0},{"delegated_calls":6,"factory":true,"function":"__ink_differential_4","retained_bindings":2},{"factory":false,"function":"__ink_differential_21","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_20","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential_25","reason":"no reusable captured work"},{"delegated_calls":1,"factory":true,"function":"__ink_differential_2","retained_bindings":2},{"delegated_calls":1,"factory":true,"function":"__ink_differential_1","retained_bindings":1},{"factory":false,"function":"__ink_differential64_3","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential64_2","reason":"no reusable captured work"},{"factory":false,"function":"__ink_differential64_1","reason":"no reusable captured work"}],"lifetime":"prepared token","semantics":"sealed-value-residual-v1"},"private_record_elisions":[],"private_sum_spines":[],"schema":1,"state":null,"wire":{"format":"ink-value-wire-v1","functions":{"__ink_differential64_1":{"arguments":{"format":"ink-value-wire-v1","identity":"472d19f2127f1316b16f49e96065b408f4e7270c1da4072dd74ece88bf21dcd6","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":{},"root":{"kind":"f64"}}},"__ink_differential64_2":{"arguments":{"format":"ink-value-wire-v1","identity":"61b0de2f6e13a2dbc5e313b56f648195866aff178300fc17ada733dd5189c6fe","named":{},"root":{"fields":[{"name":"x","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0e35873fe4e2836a793d1cccc5c47875def75fd4336b47c5bfa790354746fbe1","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}},"__ink_differential64_3":{"arguments":{"format":"ink-value-wire-v1","identity":"4e91ee00326078c7953c9c868963e2578a1ba76152e92023c06135de4801f055","named":{},"root":{"fields":[{"name":"__ink_differential64_4","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},{"name":"__ink_differential64_5","type":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0e35873fe4e2836a793d1cccc5c47875def75fd4336b47c5bfa790354746fbe1","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}}},"__ink_differential_1":{"arguments":{"format":"ink-value-wire-v1","identity":"22549eae89e0dc6316436e0086e5bf18d8959fd0c3fae94f619a6d27d0451f7f","named":{},"root":{"fields":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"__ink_differential_11":{"arguments":{"format":"ink-value-wire-v1","identity":"d6cab0f5cb7ee4bfb3440531dbaa56b0fdc4937073092e6dbbbd1cdd7c4aa382","named":{},"root":{"fields":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}},{"name":"base","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_12":{"arguments":{"format":"ink-value-wire-v1","identity":"1f550c24187c484474301a9e9a869fd2214630de75d7c1d53b22de3f9683ac3d","named":{},"root":{"fields":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_13":{"arguments":{"format":"ink-value-wire-v1","identity":"3720cf83cb9a672c0c70e7f80cfe0abe0bf9b7df73d40a9def0c7436234026b2","named":{},"root":{"fields":[],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"bb1fd39ad8ae6c174bdc7c93bf326cea4848e5d07efb08ff6da1bad448ba9329","named":{},"root":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"}}},"__ink_differential_14":{"arguments":{"format":"ink-value-wire-v1","identity":"3ba898a3cfaf4bc347ed15914a0766b4d76b969b40e2173c5351b46e94344461","named":{},"root":{"fields":[{"name":"__ink_differential_15","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_16","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_18":{"arguments":{"format":"ink-value-wire-v1","identity":"f768b881f418ca4aaa3928806d68fb02afa1bc64fa779cad824441037ae17641","named":{},"root":{"fields":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"inputs","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"cdde982e98b457eca63f0b1f56713939bdd8ddf70f5be35e930642c404861714","named":{},"root":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}}},"__ink_differential_19":{"arguments":{"format":"ink-value-wire-v1","identity":"6f1f9ac7741dd39eaf4ffa402ac9ae4ee58f36e37f9554fefbb185516bf18592","named":{},"root":{"fields":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"inputs","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"base","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_2":{"arguments":{"format":"ink-value-wire-v1","identity":"9d8ff03a45c20596c31cd938ac529b84f7f68fc613f25f8986fb0a25b611fba1","named":{},"root":{"fields":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"targets","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_20":{"arguments":{"format":"ink-value-wire-v1","identity":"9fab172cda7ff8145656b68899c181a5f43d946e6bb3deda6393f520a7ff7847","named":{},"root":{"fields":[{"name":"prediction","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"target","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_21":{"arguments":{"format":"ink-value-wire-v1","identity":"05ad0fe40601b6501e611c63f42a4841be5e43468e274dc39e5865c5171ac268","named":{},"root":{"fields":[{"name":"__ink_differential_22","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_23","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_25":{"arguments":{"format":"ink-value-wire-v1","identity":"e9791254e476381294f0219e6a0102c02981994d8e2edc2d559be81a98c49caa","named":{},"root":{"fields":[{"name":"__ink_differential_26","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_27","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_4":{"arguments":{"format":"ink-value-wire-v1","identity":"4091e45a7ea55260f67482329c9b6b85d96a301a6b8ae619bb8f6a5ad8cd26f9","named":{},"root":{"fields":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"cdde982e98b457eca63f0b1f56713939bdd8ddf70f5be35e930642c404861714","named":{},"root":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}}},"__ink_differential_5":{"arguments":{"format":"ink-value-wire-v1","identity":"4091e45a7ea55260f67482329c9b6b85d96a301a6b8ae619bb8f6a5ad8cd26f9","named":{},"root":{"fields":[{"name":"candidate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},{"name":"features","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"cdde982e98b457eca63f0b1f56713939bdd8ddf70f5be35e930642c404861714","named":{},"root":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}}},"__ink_differential_6":{"arguments":{"format":"ink-value-wire-v1","identity":"31592dc92aec2c480ff896f14b6def755843fa745eda7741873860057a2e9c0d","named":{},"root":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"gate","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"__ink_differential_7":{"arguments":{"format":"ink-value-wire-v1","identity":"1eee11e978b643d01feacaa43d96c81a89b8bcb7d8406e53ac85d2a94730a633","named":{},"root":{"fields":[{"name":"__ink_differential_8","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"__ink_differential_9","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}}},"candidate":{"arguments":{"format":"ink-value-wire-v1","identity":"ccc16ee8f5974f4f8e95049e37b2e3bd4fbe769f0192c9a1a33745a7c1a6ebfe","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}},{"name":"g","type":{"kind":"f32"}},{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"7cd0db7bd067c6137d0451073ecc71755d81ac9dbc8526c5cda3a6cf0de894c3","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}}},"configuration":{"arguments":{"format":"ink-value-wire-v1","identity":"a0c1fcff287124f49ca5e0fa774ca7390e0c8ea561b4c2d377dbd09ba79e6309","named":{},"root":{"fields":[{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"dot10":{"arguments":{"format":"ink-value-wire-v1","identity":"37e273723f3f82d49a92eb9306a0319a0f80297ddaf4548f114502ec0b6cf6a6","named":{},"root":{"fields":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}},{"name":"base","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"dot6":{"arguments":{"format":"ink-value-wire-v1","identity":"feb8924860204cd016023b0b40f7ae444ddc86740d3a32cd79ecd1232c68d2f5","named":{},"root":{"fields":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"inputs","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"base","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"empty_parameter":{"arguments":{"format":"ink-value-wire-v1","identity":"3720cf83cb9a672c0c70e7f80cfe0abe0bf9b7df73d40a9def0c7436234026b2","named":{},"root":{"fields":[],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"7cd0db7bd067c6137d0451073ecc71755d81ac9dbc8526c5cda3a6cf0de894c3","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}}},"first_layer":{"arguments":{"format":"ink-value-wire-v1","identity":"dd445f0589a3aa37b6d0fb5f263058865bb606fbf648bd847d6a1e16d6bb3658","named":{},"root":{"fields":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"gradients":{"arguments":{"format":"ink-value-wire-v1","identity":"4f2033b1c433af3e1d797ea676ba7f9862c85cd25823d51f04e6335071354ff5","named":{},"root":{"fields":[{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"rows","type":{"element":{"kind":"u32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"losses":{"arguments":{"format":"ink-value-wire-v1","identity":"4f2033b1c433af3e1d797ea676ba7f9862c85cd25823d51f04e6335071354ff5","named":{},"root":{"fields":[{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"rows","type":{"element":{"kind":"u32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"objective":{"arguments":{"format":"ink-value-wire-v1","identity":"22549eae89e0dc6316436e0086e5bf18d8959fd0c3fae94f619a6d27d0451f7f","named":{},"root":{"fields":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"outputs":{"arguments":{"format":"ink-value-wire-v1","identity":"dd445f0589a3aa37b6d0fb5f263058865bb606fbf648bd847d6a1e16d6bb3658","named":{},"root":{"fields":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"row","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"parameter":{"arguments":{"format":"ink-value-wire-v1","identity":"278c77c1195ee8c9d8b1f990134b6cbb5a9552b5520fcc68351753085dc4c2ed","named":{},"root":{"fields":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"index","type":{"kind":"u32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"precise_gradient":{"arguments":{"format":"ink-value-wire-v1","identity":"472d19f2127f1316b16f49e96065b408f4e7270c1da4072dd74ece88bf21dcd6","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":{},"root":{"kind":"f64"}}},"precise_square":{"arguments":{"format":"ink-value-wire-v1","identity":"472d19f2127f1316b16f49e96065b408f4e7270c1da4072dd74ece88bf21dcd6","named":{},"root":{"fields":[{"name":"x","type":{"kind":"f64"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":{},"root":{"kind":"f64"}}},"reglu":{"arguments":{"format":"ink-value-wire-v1","identity":"1fecec1fcd8fb7dce915abd77b22d39ebc89b17fc857eb01fd5abbbb2593cbfe","named":{},"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"gate","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"second_layer":{"arguments":{"format":"ink-value-wire-v1","identity":"582f9d9827718e12d6d47d61704695df375964b86cd9573316bd558e8a1bf99a","named":{},"root":{"fields":[{"name":"candidate","type":{"kind":"f32"}},{"name":"coordinate","type":{"kind":"u32"}},{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"inputs","type":{"element":{"kind":"f32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":{},"root":{"element":{"kind":"f32"},"kind":"list"}}},"shape":{"arguments":{"format":"ink-value-wire-v1","identity":"4f2033b1c433af3e1d797ea676ba7f9862c85cd25823d51f04e6335071354ff5","named":{},"root":{"fields":[{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"features","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"targets","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"rows","type":{"element":{"kind":"u32"},"kind":"list"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}},"squared_error":{"arguments":{"format":"ink-value-wire-v1","identity":"643d934f13c916ac9fbe2b60b256ecabdb3dd59f0991c057d7366ad268222129","named":{},"root":{"fields":[{"name":"prediction","type":{"kind":"f32"}},{"name":"target","type":{"kind":"f32"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":{},"root":{"kind":"f32"}}},"update":{"arguments":{"format":"ink-value-wire-v1","identity":"047325bab4732f3d0e00788b69015b016a512e9ebe7b4a3ef5389eee5b84ef8b","named":{},"root":{"fields":[{"name":"parameters","type":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},{"name":"gradient","type":{"element":{"kind":"f32"},"kind":"list"}},{"name":"admissible","type":{"kind":"bool"}},{"name":"c","type":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"7e4dba74ea4a212e87b655db607b4b675c6150a5e6af015142def3ed7d7aa96c","named":{},"root":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}}},"valid":{"arguments":{"format":"ink-value-wire-v1","identity":"a611151880c9e23a958765b0cefc48481684963d56a3d7a8d388c827f6396d40","named":{},"root":{"fields":[{"name":"p","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}}],"kind":"record","name":"arguments"}},"result":{"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":{},"root":{"kind":"bool"}}}}}};
const __implementations=[__fn0,__fn1,__fn2,__fn3,__fn4,__fn5,__fn6,__fn7,__fn8,__fn9,__fn10,__fn11,__fn12,__fn13,__fn14,__fn15,__fn16,__fn17,__fn18,__fn19,__fn20,__fn21,__fn22,__fn23,__fn24,__fn25,__fn26,__fn27,__fn28,__fn29,__fn30,__fn31,__fn32,__fn33,__fn34,__fn35,__fn36];

function __freeze(v) { if(v && typeof v==='object') {Object.values(v).forEach(__freeze);Object.freeze(v);} return v; }
__freeze(metadata);
const __inputTypes=[{"capture":[],"types":[]},{"capture":[true,true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"kind":"u32"}]},{"capture":[true,true],"types":[{"kind":"f32"},{"kind":"f32"}]},{"capture":[true,true,true,true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"kind":"u32"},{"kind":"u32"}]},{"capture":[true,true,true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"kind":"u32"}]},{"capture":[true,true,true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"kind":"u32"}]},{"capture":[true,true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"}]},{"capture":[true,true,true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"kind":"u32"}]},{"capture":[true,true],"types":[{"kind":"f32"},{"kind":"f32"}]},{"capture":[true,true,true,true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"kind":"u32"}]},{"capture":[false,true,true,true],"types":[{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"u32"},"kind":"list"}]},{"capture":[false,true,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},{"kind":"f32"},{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}]},{"capture":[false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}]},{"capture":[false],"types":[{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}]},{"capture":[false,true,true,true],"types":[{"element":{"fields":[],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"u32"},"kind":"list"}]},{"capture":[true,true,true,false],"types":[{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"kind":"bool"},{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}]},{"capture":[true,true,true,true],"types":[{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"u32"},"kind":"list"}]},{"capture":[true],"types":[{"kind":"f64"}]},{"capture":[true],"types":[{"kind":"f64"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[],"types":[]},{"capture":[true,true,true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"},{"kind":"u32"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[true,true,true,true,true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"},{"kind":"u32"},{"kind":"u32"}]},{"capture":[true,true,true,true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"},{"kind":"u32"}]},{"capture":[true,true,true,true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"},{"kind":"u32"}]},{"capture":[true,true,true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}]},{"capture":[true,true,true,true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"},{"kind":"u32"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}]},{"capture":[true,true,true,true,true,true],"types":[{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"},{"kind":"u32"}]},{"capture":[true,true,false,true,true,true],"types":[{"kind":"f32"},{"kind":"u32"},{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"element":{"kind":"f32"},"kind":"list"},{"kind":"u32"}]},{"capture":[false,false],"types":[{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"},{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}]},{"capture":[false],"types":[{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}]},{"capture":[true],"types":[{"kind":"f64"}]}];

// Descriptor work occurs once at module initialisation, never per word-list call.
export const functions = Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=> {
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const output=__representation(f.result,true);
  const body=__implementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
  const needsInput=input.some(c=>c!==__identity);
  const entry=!needsInput && output===__identity ? implementation :
    (...args)=>{const context=new WeakMap();return output(implementation(...(needsInput ? args.map((v,i)=>input[i](v,context)) : args)),context);};
  return [f.name,entry];
})));
export function call(name,args) { return functions[name](...args); }
// Shared bounded binary codec; generated code supplies exact descriptors.
export const valueWireFormat='ink-value-wire-v1';
// A connection agrees on the complete value schema before using this format.
// Version byte + schema-directed fields; schema identity is out of band.
export const compactValueWireFormat='ink-value-session-v1';
const wireMagic=Uint8Array.of(73,78,75,86,65,76,0,1);
const wireEncoder=new TextEncoder(),wireDecoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
const wireDefaults=Object.freeze({bytes:16777216,nodes:1000000,depth:128}),wireDefaultOptions=Object.freeze({});
const wireDecimal=s=>typeof s==='string'&&/^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(s);
function wireLimits(options){if(options===wireDefaultOptions||options===wireDefaults)return wireDefaults;const l={...wireDefaults,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>wireDefaults[k])throw Error('wire hard resource limit');return l;}
const wireFloat=new DataView(new ArrayBuffer(4));
function wireDecodeText(bytes,start,end){
 if(end-start<=16){let text='';for(let i=start;i<end;i++){const byte=bytes[i];if(byte>=128)return wireDecoder.decode(bytes.subarray(start,end));text+=String.fromCharCode(byte);}return text;}
 return wireDecoder.decode(bytes.subarray(start,end));
}
function wireUtf8Length(text){let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const wireOwn=(v,k)=>v!==null&&typeof v==='object'&&Object.hasOwn(v,k);
const wireTagged=(v,k)=>wireOwn(v,k)&&Object.keys(v).length===1;
const wireDouble=new DataView(new ArrayBuffer(8));
function wireF64Bits(v){
 if(typeof v==='number'&&Number.isFinite(v)){wireDouble.setFloat64(0,v,true);return wireDouble.getBigUint64(0,true);}
 if(!wireTagged(v,'F64Bits'))wireInvalidValue();const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))wireInvalidValue();
 const bits=BigInt(text);if(bits>18446744073709551615n)wireInvalidValue();return bits;
}
const wireCanonical=v=>Array.isArray(v)?'['+v.map(wireCanonical).join(',')+']':v&&typeof v==='object'?'{'+Object.keys(v).sort((a,b)=>{const x=Array.from(a,c=>c.codePointAt(0)),y=Array.from(b,c=>c.codePointAt(0));for(let i=0;i<Math.min(x.length,y.length);i++)if(x[i]!==y[i])return x[i]-y[i];return x.length-y.length;}).map(k=>JSON.stringify(k)+':'+wireCanonical(v[k])).join(',')+'}':JSON.stringify(v);
export async function createValueCodec(root,named={}){
 const used=new Set(),budget={nodes:100000};
 function check(t,d=0){
  if(d>64||--budget.nodes<0)throw Error('wire descriptor limit');
  const keys={u32:['kind'],u64:['kind'],i32:['kind'],f32:['kind'],f64:['kind'],bool:['kind'],unit:['kind'],string:['kind'],int:['kind'],id:['kind','name'],ref:['kind','name'],enum:['kind','name','variants'],record:['kind','name','fields'],list:['kind','element'],option:['kind','element'],vector:['kind','element','size'],result:['kind','ok','error']}[t?.kind];
  if(!keys||Object.keys(t).length!==keys.length||keys.some(k=>!Object.hasOwn(t,k)))throw Error('invalid wire descriptor');
  if(keys.includes('name')&&(typeof t.name!=='string'||!t.name.isWellFormed()))throw Error('invalid descriptor name');
  if(t.kind==='ref'){if(!used.has(t.name)){used.add(t.name);if(named[t.name]?.kind!=='record'||named[t.name].name!==t.name)throw Error('unresolved wire reference');check(named[t.name],d+1);}}
  if(t.kind==='record'){if(!Array.isArray(t.fields))throw Error('wire fields');const names=new Set();for(const f of t.fields){if(Object.keys(f).length!==2||typeof f.name!=='string'||!f.name.isWellFormed()||names.has(f.name))throw Error('duplicate wire field');names.add(f.name);check(f.type,d+1);}}
  if(t.kind==='enum'&&(!Array.isArray(t.variants)||!t.variants.length||t.variants.length>64||t.variants.some(v=>typeof v!=='string'||!v.isWellFormed())||new Set(t.variants).size!==t.variants.length))throw Error('wire enum');
  if(['list','vector','option'].includes(t.kind)){if(t.kind==='vector'&&(!Number.isInteger(t.size)||t.size<1||t.size>64))throw Error('wire vector');check(t.element,d+1);}
  if(t.kind==='result'){check(t.ok,d+1);check(t.error,d+1);}
 }
 check(root);const names=Object.fromEntries([...used].sort().map(k=>[k,named[k]]));
 const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',wireEncoder.encode(wireCanonical({format:valueWireFormat,root,named:names}))));
 return new ValueCodec({format:valueWireFormat,root,named:names,identity:Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('')});
}
// Resolve immutable descriptor edges once. Logical validation traverses the
// literal schema; single-child nodes use a loop rather than recursive closures.
function wireValuePlan(codec){
 const seen=new WeakMap();let remaining=100000;
 const build=type=>{
  const t=codec.resolve(type);if(seen.has(t))return seen.get(t);
  if(--remaining<0)throw Error('wire descriptor limit');const p={kind:t.kind,type:t,decode:null,decodeCompact:null};seen.set(t,p);
  if(t.kind==='record')p.fields=t.fields.map(f=>({name:f.name,plan:build(f.type)}));
  if(t.kind==='list'||t.kind==='vector'||t.kind==='option')p.element=build(t.element);
  if(t.kind==='result'){p.ok=build(t.ok);p.error=build(t.error);}
  return p;
 };return build(codec.descriptor.root);
}
function wireBindDecodePlan(root,compact=false){
 const seen=new Set(),pending=[root];let flags=0;
 while(pending.length){
  const p=pending.pop();if(seen.has(p))continue;seen.add(p);if(compact)p.decodeCompact=compactDecodeOperation(p);else p.decode=wireDecodeOperation(p);
  if(p.fields?.length>4)flags|=1;
  if(p.kind==='u32'||p.kind==='i32'||p.kind==='u64'||p.kind==='f32'||p.kind==='f64')flags|=2;
  if(p.fields)for(const f of p.fields)pending.push(f.plan);
  if(p.element)pending.push(p.element);
  if(p.ok){pending.push(p.ok);pending.push(p.error);}
 }
 return flags|4;
}
// Select literal descriptor operations once, without runtime source generation
// or eval. Recursive edges call the completed plan. The generic scanner remains
// the visitor/validation path and an independent materialisation implementation.
function wireReadOperation(p){
 const t=p.type;
 let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':read=(r,end)=>{r.size(end,4);const value={F32Bits:r.view.getUint32(r.cursor,true)};r.cursor=end;return value;};break;
  case 'f64':read=(r,end)=>{r.size(end,8);const value={F64Bits:r.view.getBigUint64(r.cursor,true).toString()};r.cursor=end;return value;};break;
  case 'u64':read=(r,end)=>{r.size(end,8);const value=r.view.getBigUint64(r.cursor,true);r.cursor=end;return value;};break;
  case 'string':read=(r,end)=>r.text(end);break;
  case 'int':read=(r,end)=>{const text=r.text(end);if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=(r,end)=>{const text=r.text(end);if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=(r,end)=>{const text=r.text(end);if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{
    if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;
    if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');
    const values=new Array(n);for(let i=0;i<n;i++)values[i]=element.decode(r,end,d+1);return values;
   };break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1)});break;
    case 2:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1)});break;
    case 3:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1)});break;
    case 4:read=(r,end,d)=>({[fs[0].name]:fs[0].plan.decode(r,end,d+1),[fs[1].name]:fs[1].plan.decode(r,end,d+1),[fs[2].name]:fs[2].plan.decode(r,end,d+1),[fs[3].name]:fs[3].plan.decode(r,end,d+1)});break;
    default:read=(r,end,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decode(r,end,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,end,d)=>{const tag=r.tag(end);return tag?{Some:p.element.decode(r,end,d+1)}:{None:null};};break;
  case 'result':read=(r,end,d)=>r.tag(end)?{Err:p.error.decode(r,end,d+1)}:{Ok:p.ok.decode(r,end,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function wireDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=wireReadOperation(field.plan),name=field.name;
  return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),childEnd=r.enter(end,d+1),item=read(r,childEnd,d+1);if(r.cursor!==childEnd)throw Error('trailing wire frame bytes');const value={[name]:item};if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
 }
 const read=wireReadOperation(p);
 return (r,parentEnd,d)=>{const end=r.enter(parentEnd,d),value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');return value;};
}
class WireDecodeCursor{
 constructor(bytes,view,limits){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
// Bind literal validation and postorder visitation once for every descriptor.
// No logical carriers are allocated; projection still validates every child.
function wireScanPlan(root){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,scan:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.scan=wireScanOperation(p);return p;
 };
 return build(root);
}
function wireScanOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=(r,end)=>{r.size(end,0);return null;};break;
  case 'bool':read=(r,end)=>{r.size(end,1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':read=(r,end)=>{r.size(end,4);const n=r.view.getUint32(r.cursor,true);r.cursor=end;return n;};break;
  case 'i32':read=(r,end)=>{r.size(end,4);const n=r.view.getInt32(r.cursor,true);r.cursor=end;return n;};break;
  case 'f32':case 'f64':case 'u64':{const size=p.kind==='f32'?4:8;read=(r,end)=>{r.size(end,size);r.cursor=end;};break;}
  case 'string':read=(r,end)=>{let i=r.cursor;while(i<end&&r.bytes[i]<128)i++;if(i<end)wireDecoder.decode(r.bytes.subarray(r.cursor,end));r.cursor=end;};break;
  case 'int':case 'id':case 'enum':read=(r,end)=>{const text=r.text(end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   read=(r,end,d)=>{if(r.cursor+4>end)throw Error('wire list count');const n=r.view.getUint32(r.cursor,true);r.cursor+=4;if(n>r.remaining||n>Math.floor((end-r.cursor)/4)||size!==null&&n!==size)throw Error('wire sequence size');for(let i=0;i<n;i++)element.scan(r,end,d+1);};break;
  }
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>{};break;
    case 1:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);};break;
    case 2:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);};break;
    case 3:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);};break;
    case 4:read=(r,end,d)=>{fs[0].plan.scan(r,end,d+1);fs[1].plan.scan(r,end,d+1);fs[2].plan.scan(r,end,d+1);fs[3].plan.scan(r,end,d+1);};break;
    default:read=(r,end,d)=>{for(const f of fs)f.plan.scan(r,end,d+1);};
   }break;
  }
  case 'option':read=(r,end,d)=>{if(r.tag(end))p.element.scan(r,end,d+1);};break;
  case 'result':read=(r,end,d)=>{(r.tag(end)?p.error:p.ok).scan(r,end,d+1);};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return (r,parentEnd,d)=>{
  const end=r.enter(parentEnd,d),start=r.cursor,value=read(r,end,d);if(r.cursor!==end)throw Error('trailing wire frame bytes');
  const visitor=r.visitor;if(visitor&&(!r.selected||r.selected.has(t.name))){if(r.spans)visitor(t,r.bytes,start,end,d);else visitor(t,r.bytes.subarray(start,end),d);}
  return value;
 };
}
// Separate methods keep decoding's cursor callsites monomorphic. Both cursors
// are checked against the independent generic scanner and malformed fixtures.
class WireScanCursor{
 constructor(bytes,view,limits,visitor,selected,spans){this.bytes=bytes;this.view=view;this.cursor=40;this.remaining=limits.nodes;this.depth=limits.depth;this.visitor=visitor;this.selected=selected;this.spans=spans;}
 enter(parentEnd,d){
  if(d>this.depth||--this.remaining<0||this.cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const start=this.cursor+4,end=start+this.view.getUint32(this.cursor,true);if(end>parentEnd)throw Error('truncated wire frame');this.cursor=start;return end;
 }
 size(end,n){if(end-this.cursor!==n)throw Error('malformed wire scalar');}
 tag(end){if(this.cursor===end||this.bytes[this.cursor]>1)throw Error('wire sum tag');return this.bytes[this.cursor++];}
 text(end){const text=wireDecodeText(this.bytes,this.cursor,end);this.cursor=end;return text;}
}
function compactReadOperation(p){
 const t=p.type;let read;
 switch(p.kind){
  case 'unit':read=()=>null;break;
  case 'bool':read=r=>{r.require(1);const b=r.bytes[r.cursor++];if(b>1)throw Error('invalid wire Bool');return !!b;};break;
  case 'u32':case 'i32':read=r=>{r.require(4);const n=p.kind==='u32'?r.view.getUint32(r.cursor,true):r.view.getInt32(r.cursor,true);r.cursor+=4;return n;};break;
  case 'f32':read=r=>{r.require(4);const n=r.view.getUint32(r.cursor,true);r.cursor+=4;return {F32Bits:n};};break;
  case 'f64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return {F64Bits:n.toString()};};break;
  case 'u64':read=r=>{r.require(8);const n=r.view.getBigUint64(r.cursor,true);r.cursor+=8;return n;};break;
  case 'string':read=r=>r.text();break;
  case 'int':read=r=>{const text=r.text();if(!wireDecimal(text))throw Error('malformed wire text');return {Int:text};};break;
  case 'id':read=r=>{const text=r.text();if(!/^[0-9a-f]{32}$/.test(text))throw Error('malformed wire text');return text;};break;
  case 'enum':read=r=>{const text=r.text();if(!t.variants.includes(text))throw Error('malformed wire text');return text;};break;
  case 'list':case 'vector':read=(r,d)=>{const n=r.count();if(n>r.remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');const values=new Array(n);for(let i=0;i<n;i++)values[i]=p.element.decodeCompact(r,d+1);return values;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:read=()=>({});break;
    case 1:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1)});break;
    case 2:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1)});break;
    case 3:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1)});break;
    case 4:read=(r,d)=>({[fs[0].name]:fs[0].plan.decodeCompact(r,d+1),[fs[1].name]:fs[1].plan.decodeCompact(r,d+1),[fs[2].name]:fs[2].plan.decodeCompact(r,d+1),[fs[3].name]:fs[3].plan.decodeCompact(r,d+1)});break;
    default:read=(r,d)=>{const value={};for(const f of fs){r.property.value=f.plan.decodeCompact(r,d+1);Object.defineProperty(value,f.name,r.property);}return value;};
   }break;
  }
  case 'option':read=(r,d)=>r.tag()?{Some:p.element.decodeCompact(r,d+1)}:{None:null};break;
  case 'result':read=(r,d)=>r.tag()?{Err:p.error.decodeCompact(r,d+1)}:{Ok:p.ok.decodeCompact(r,d+1)};break;
  default:read=()=>{throw Error('unsupported wire kind');};
 }
 return read;
}
function compactDecodeOperation(p){
 if(p.kind==='record'&&p.fields.length===1){
  const field=p.fields[0],read=compactReadOperation(field.plan),name=field.name;
  return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');if(d+1>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return {[name]:read(r,d+1)};};
 }
 const read=compactReadOperation(p);
 return (r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');return read(r,d);};
}
class CompactDecodeCursor{
 constructor(bytes,limits,flags){this.bytes=bytes;this.view=flags&2?new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength):null;this.cursor=1;this.remaining=limits.nodes;this.depth=limits.depth;this.property=null;}
 require(n){if(n>this.bytes.length-this.cursor)throw Error('truncated compact value');}
 count(){
  if(this.cursor>=this.bytes.length)throw Error('truncated compact value');
  const first=this.bytes[this.cursor++];if(first<128)return first;
  let value=first&127,scale=128;
  for(let i=1;i<5;i++){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const byte=this.bytes[this.cursor++];if(i===4&&byte>15)throw Error('compact count overflow');value+=(byte&127)*scale;if(byte<128){if(byte===0)throw Error('noncanonical compact count');return value;}scale*=128;}throw Error('compact count overflow');
 }
 tag(){if(this.cursor>=this.bytes.length)throw Error('truncated compact value');const tag=this.bytes[this.cursor++];if(tag>1)throw Error('wire sum tag');return tag;}
 text(){const n=this.count();this.require(n);const start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
function wireInvalidValue(){throw Error('invalid value for wire schema');}
// Capture has the canonical logical meaning of decode(encode(value)), without
// allocating wire bytes. A separate plan leaves validation/decoder hot shapes
// unchanged and never retains host input containers between calls.
function wireCapturePlan(root,checked=true){
 const seen=new WeakMap();
 const build=source=>{
  if(seen.has(source))return seen.get(source);
  const p={kind:source.kind,type:source.type,capture:null};seen.set(source,p);
  if(source.fields)p.fields=source.fields.map(f=>({name:f.name,plan:build(f.plan)}));
  if(source.element)p.element=build(source.element);
  if(source.ok){p.ok=build(source.ok);p.error=build(source.error);}
  p.capture=checked?wireCaptureOperation(p):wireCopyOperation(p);return p;
 };return build(root);
}
function wireCaptureOperation(p){
 const t=p.type;let copy;
 switch(p.kind){
  case 'unit':copy=v=>{if(v!==null)wireInvalidValue();return null;};break;
  case 'bool':copy=(v,r)=>{if(typeof v!=='boolean')wireInvalidValue();r.add(1);return v;};break;
  case 'u32':case 'i32':{
   const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
   copy=(v,r)=>{if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();r.add(4);return v===0?0:v;};break;
  }
  case 'u64':copy=(v,r)=>{const kind=typeof v;if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();r.add(8);return n;};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'int':case 'id':case 'enum':copy=(v,r)=>{const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;if(typeof text!=='string'||!text.isWellFormed()||text.length>r.limit)wireInvalidValue();if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();r.add(wireUtf8Length(text));return p.kind==='int'?{Int:text}:text;};break;
  case 'list':case 'vector':{
   const element=p.element,size=p.kind==='vector'?t.size:null;
   copy=(v,r,d)=>{if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();const n=v.length;if(n>r.remaining||size!==null&&n!==size)wireInvalidValue();r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=element.capture(v[i],r,d+1);return out;};break;
  }
  case 'record':{
   const fs=p.fields;let fields;
   switch(fs.length){
    case 0:fields=()=>({});break;
    case 1:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:fields=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:fields=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }
   copy=(v,r,d)=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();for(const f of fs)if(!wireOwn(v,f.name))wireInvalidValue();return fields(v,r,d);};break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'None')&&v.None===null)return {None:null};if(wireTagged(v,'Some'))return {Some:p.element.capture(v.Some,r,d+1)};wireInvalidValue();};break;
  case 'result':copy=(v,r,d)=>{r.add(1);if(wireTagged(v,'Ok'))return {Ok:p.ok.capture(v.Ok,r,d+1)};if(wireTagged(v,'Err'))return {Err:p.error.capture(v.Err,r,d+1)};wireInvalidValue();};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
class WireCaptureCursor{
 constructor(limits){this.remaining=limits.nodes;this.depth=limits.depth;this.limit=limits.bytes;this.bytes=40;this.add(0);}
 add(n){this.bytes+=n;if(this.bytes>this.limit)throw Error('wire byte limit');}
 enter(depth,bytes){if(depth>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.add(bytes);}
 text(value){if(value.length>this.limit)throw Error('wire byte limit');this.add(wireUtf8Length(value));}
}
// Literal lowerers share this fixed resource policy with logical capture.
export function createValueCaptureBudget(options=wireDefaultOptions){return new WireCaptureCursor(wireLimits(options));}
// The trusted-value API has the same canonical copy and ownership semantics.
// Its caller supplies a stable value accepted by validateValue. Shape/range
// checks remain at external capture boundaries; resource limits still apply.
function wireCopyOperation(p){
 let copy;
 switch(p.kind){
  case 'unit':copy=()=>null;break;
  case 'bool':copy=(v,r)=>{r.add(1);return v;};break;
  case 'u32':copy=(v,r)=>{r.add(4);return v>>>0;};break;
  case 'i32':copy=(v,r)=>{r.add(4);return v|0;};break;
  case 'u64':copy=(v,r)=>{r.add(8);return BigInt(v);};break;
  case 'f32':copy=(v,r)=>{let bits;if(typeof v==='number'){wireFloat.setFloat32(0,v,true);bits=wireFloat.getUint32(0,true);}else bits=v.F32Bits;r.add(4);return {F32Bits:bits===0?0:bits};};break;
  case 'f64':copy=(v,r)=>{const bits=wireF64Bits(v);r.add(8);return {F64Bits:bits.toString()};};break;
  case 'string':case 'id':case 'enum':copy=(v,r)=>{r.add(wireUtf8Length(v));return v;};break;
  case 'int':copy=(v,r)=>{const text=typeof v==='bigint'?v.toString():v.Int;r.add(wireUtf8Length(text));return {Int:text};};break;
  case 'list':case 'vector':copy=(v,r,d)=>{const n=v.length;if(n>r.remaining)throw Error('wire sequence size');r.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=p.element.capture(v[i],r,d+1);return out;};break;
  case 'record':{
   const fs=p.fields;
   switch(fs.length){
    case 0:copy=()=>({});break;
    case 1:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1)});break;
    case 2:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1)});break;
    case 3:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1)});break;
    case 4:copy=(v,r,d)=>({[fs[0].name]:fs[0].plan.capture(v[fs[0].name],r,d+1),[fs[1].name]:fs[1].plan.capture(v[fs[1].name],r,d+1),[fs[2].name]:fs[2].plan.capture(v[fs[2].name],r,d+1),[fs[3].name]:fs[3].plan.capture(v[fs[3].name],r,d+1)});break;
    default:copy=(v,r,d)=>{const out={};for(const f of fs){const value=f.plan.capture(v[f.name],r,d+1);Object.defineProperty(out,f.name,{value,enumerable:true,writable:true,configurable:true});}return out;};
   }break;
  }
  case 'option':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'None')&&v.None===null?{None:null}:{Some:p.element.capture(v.Some,r,d+1)};};break;
  case 'result':copy=(v,r,d)=>{r.add(1);return Object.hasOwn(v,'Ok')?{Ok:p.ok.capture(v.Ok,r,d+1)}:{Err:p.error.capture(v.Err,r,d+1)};};break;
  default:copy=()=>{throw Error('unsupported wire kind');};
 }
 return (v,r,d)=>{if(d>r.depth||--r.remaining<0)throw Error('wire node or depth limit');r.add(4);return copy(v,r,d);};
}
// Emit the cached literal schema with one forward writer. Each value is checked
// where it is consumed; byte bounds belong to the writer, not a second size walk.
function wireEncodeValue(root,value,l,w){
 let remaining=l.nodes;const depthLimit=l.depth;
 const node=(p,v,d)=>{
  if(d>depthLimit||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type,start=w.beginNode();
  switch(p.kind){
   case 'unit':if(v!==null)wireInvalidValue();break;
   case 'bool':if(typeof v!=='boolean')wireInvalidValue();w.byte(+v);break;
   case 'u32':case 'i32':{
    const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
    if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();w.word(v>>>0);break;
   }
   case 'u64':{
    const kind=typeof v;
    if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
    const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();w.wide(n);break;
   }
   case 'f64':w.wide(wireF64Bits(v));break;
   case 'f32':{
    let bits;
    if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();bits=wireFloat.getUint32(0,true);}
    else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
    w.word(bits);break;
   }
   case 'string':case 'int':case 'id':case 'enum':{
    const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
    if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&(typeof text!=='string'||!/^[0-9a-f]{32}$/.test(text))||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
    w.text(text);break;
   }
   case 'list':case 'vector':{
    if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
    if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
    w.count(v.length);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);break;
   }
   case 'record':{
    const fs=p.fields;
    if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
    for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
    for(let i=0;i<fs.length;i++){const f=fs[i];node(f.plan,v[f.name],d+1);}break;
   }
   case 'option':{
    if(wireTagged(v,'None')&&v.None===null)w.byte(0);
    else if(wireTagged(v,'Some')){w.byte(1);node(p.element,v.Some,d+1);}else wireInvalidValue();break;
   }
   case 'result':{
    if(wireTagged(v,'Ok')){w.byte(0);node(p.ok,v.Ok,d+1);}
    else if(wireTagged(v,'Err')){w.byte(1);node(p.error,v.Err,d+1);}else wireInvalidValue();break;
   }
   default:throw Error('unsupported wire kind');
  }
  w.endNode(start);
 };
 node(root,value,0);
}
function wireCheckValue(root,value,l){
 let remaining=l.nodes,total=40;
 const add=n=>{total+=n;if(total>l.bytes)throw Error('wire byte limit');};
 const node=(p,v,d)=>{
  while(true){
   if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
   const t=p.type;
   switch(p.kind){
    case 'unit':if(v!==null)wireInvalidValue();add(4);return;
    case 'bool':if(typeof v!=='boolean')wireInvalidValue();add(5);return;
    case 'u32':case 'i32':{
     const min=p.kind==='u32'?0:-2147483648,max=p.kind==='u32'?4294967295:2147483647;
     if(typeof v!=='number'||!Number.isInteger(v)||v<min||v>max)wireInvalidValue();add(8);return;
    }
    case 'u64':{
     const kind=typeof v;
     if(kind==='number'&&!Number.isSafeInteger(v)||kind!=='bigint'&&kind!=='number'&&kind!=='string'||kind==='string'&&(!wireDecimal(v)||v.startsWith('-')))wireInvalidValue();
     const n=BigInt(v);if(n<0n||n>18446744073709551615n)wireInvalidValue();add(12);return;
    }
    case 'f64':wireF64Bits(v);add(12);return;
    case 'f32':{
     if(typeof v==='number'&&Number.isFinite(v)){wireFloat.setFloat32(0,v,true);if(!Number.isFinite(wireFloat.getFloat32(0,true)))wireInvalidValue();}
     else{if(!wireTagged(v,'F32Bits'))wireInvalidValue();const bits=v.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295)wireInvalidValue();}
     add(8);return;
    }
    case 'string':case 'int':case 'id':case 'enum':{
     const text=p.kind==='int'?(typeof v==='bigint'?v.toString():wireTagged(v,'Int')?v.Int:null):v;
     if(typeof text!=='string'||!text.isWellFormed()||text.length>l.bytes)wireInvalidValue();
     if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))wireInvalidValue();
     add(4+wireUtf8Length(text));return;
    }
    case 'list':case 'vector':{
     if(!Array.isArray(v)&&!(ArrayBuffer.isView(v)&&!(v instanceof DataView)))wireInvalidValue();
     if(v.length>remaining||p.kind==='vector'&&v.length!==t.size)wireInvalidValue();
     add(8);for(let i=0;i<v.length;i++)node(p.element,v[i],d+1);return;
    }
    case 'record':{
     const fs=p.fields;
     if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).length!==fs.length)wireInvalidValue();
     for(let i=0;i<fs.length;i++)if(!wireOwn(v,fs[i].name))wireInvalidValue();
     add(4);if(!fs.length)return;
     for(let i=0;i<fs.length-1;i++)node(fs[i].plan,v[fs[i].name],d+1);
     const f=fs[fs.length-1];p=f.plan;v=v[f.name];d++;continue;
    }
    case 'option':{
     if(wireTagged(v,'None')&&v.None===null){add(5);return;}
     if(!wireTagged(v,'Some'))wireInvalidValue();add(5);p=p.element;v=v.Some;d++;continue;
    }
    case 'result':{
     if(wireTagged(v,'Ok')){add(5);p=p.ok;v=v.Ok;}
     else if(wireTagged(v,'Err')){add(5);p=p.error;v=v.Err;}else wireInvalidValue();
     d++;continue;
    }
    default:throw Error('unsupported wire kind');
   }
  }
 };
 node(root,value,0);if(total>l.bytes)throw Error('wire byte limit');
}
// A single cursor replaces per-node child closures and {end,value} temporaries.
// Projection filters limit callback materialisation, never schema validation.
function wireScanValue(root,bytes,view,l,materialize,visitor,selected,spans){
 let cursor=40,remaining=l.nodes;
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,parentEnd,d)=>{
  if(d>l.depth||--remaining<0||cursor+4>parentEnd)throw Error('wire node, depth or length limit');
  const t=p.type,start=cursor+4,end=start+view.getUint32(cursor,true);if(end>parentEnd)throw Error('truncated wire frame');cursor=start;let value;
  switch(p.kind){
   case 'unit':if(end-start!==0)throw Error('malformed wire scalar');value=null;break;
   case 'bool':if(end-start!==1)throw Error('malformed wire scalar');if(bytes[start]>1)throw Error('invalid wire Bool');value=!!bytes[start];cursor=end;break;
   case 'u32':case 'i32':if(end-start!==4)throw Error('malformed wire scalar');value=p.kind==='u32'?view.getUint32(start,true):view.getInt32(start,true);cursor=end;break;
   case 'f32':if(end-start!==4)throw Error('malformed wire scalar');if(materialize)value={F32Bits:view.getUint32(start,true)};cursor=end;break;
   case 'f64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value={F64Bits:view.getBigUint64(start,true).toString()};cursor=end;break;
   case 'u64':if(end-start!==8)throw Error('malformed wire scalar');if(materialize)value=view.getBigUint64(start,true);cursor=end;break;
   case 'string':case 'int':case 'id':case 'enum':{
    if(p.kind==='string'&&!materialize){let i=start;while(i<end&&bytes[i]<128)i++;if(i<end)wireDecoder.decode(bytes.subarray(start,end));}
    else{const text=wireDecodeText(bytes,start,end);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    cursor=end;break;
   }
   case 'list':case 'vector':{
    if(start+4>end)throw Error('wire list count');const n=view.getUint32(start,true);cursor+=4;
    if(n>remaining||n>Math.floor((end-cursor)/4)||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,end,d+1);if(materialize)value.push(child);}break;
   }
   case 'record':{
    const fs=p.fields;
    // Computed literal keys create own data properties even for __proto__ or
    // prototype setters. Common small records need no descriptor allocations.
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:value={};break;case 1:value={[fs[0].name]:node(fs[0].plan,end,d+1)};break;case 2:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1)};break;case 3:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1)};break;case 4:value={[fs[0].name]:node(fs[0].plan,end,d+1),[fs[1].name]:node(fs[1].plan,end,d+1),[fs[2].name]:node(fs[2].plan,end,d+1),[fs[3].name]:node(fs[3].plan,end,d+1)};break;}
    }else{if(materialize)value={};for(const f of fs){const child=node(f.plan,end,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}}break;
   }
   case 'option':case 'result':{
    if(start===end||bytes[cursor]>1)throw Error('wire sum tag');const tag=bytes[cursor++];
    if(p.kind==='option'&&tag===0){if(materialize)value={None:null};}
    else{const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,end,d+1);if(materialize)value={[label]:child};}break;
   }
   default:throw Error('unsupported wire kind');
  }
  if(cursor!==end)throw Error('trailing wire frame bytes');
  if(visitor&&(!selected||selected.has(t.name))){if(spans)visitor(t,bytes,start,end,d);else visitor(t,bytes.subarray(start,end),d);}
  return value;
 };
 const result=node(root,bytes.length,0);if(cursor!==bytes.length)throw Error('trailing wire bytes');return result;
}
export class ValueCodec{
 #hash;
 #header;
 #headerWords;
 #descriptor;
 #valuePlan;
 #compactCodec;
 #encoder;
 #decodeBound=0;
 #scanPlan=null;
 #capturePlan=null;
 #copyPlan=null;
 get descriptor(){return this.#descriptor;}
 constructor(descriptor){
  // This synchronous path is for compiler-generated immutable metadata. For
  // untrusted descriptors use createValueCodec and compare the computed identity.
  if(descriptor?.format!==valueWireFormat||!/^[0-9a-f]{64}$/.test(descriptor.identity))throw Error('invalid wire schema');
  this.#descriptor=structuredClone(descriptor);this.#hash=Uint8Array.from(descriptor.identity.match(/../g),s=>parseInt(s,16));
  this.#header=new Uint8Array(40);this.#header.set(wireMagic);this.#header.set(this.#hash,8);
  const headerView=new DataView(this.#header.buffer);this.#headerWords=Array.from({length:10},(_,i)=>headerView.getUint32(i*4,true));
  const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}};freeze(this.descriptor);this.#valuePlan=wireValuePlan(this);
 }
 resolve(t){for(let i=0;i<64;i++){if(t.kind!=='ref')return t;t=this.descriptor.named[t.name];if(!t)throw Error('wire reference');}throw Error('wire reference cycle');}
 validateValue(value,options=wireDefaultOptions){wireCheckValue(this.#valuePlan,value,wireLimits(options));return true;}
 capture(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#capturePlan??=wireCapturePlan(this.#valuePlan);return this.#capturePlan.capture(value,new WireCaptureCursor(limits),0);}
 copy(value,options=wireDefaultOptions){const limits=wireLimits(options);this.#copyPlan??=wireCapturePlan(this.#valuePlan,false);return this.#copyPlan.capture(value,new WireCaptureCursor(limits),0);}
 compact(){return this.#compactCodec??=new CompactValueCodec(this);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new WireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.bytes(this.#header);wireEncodeValue(this.#valuePlan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new WireEncoder(options);w.bytes(wireMagic);w.bytes(this.#hash);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 scan(bytes,options=wireDefaultOptions,materialize=false,visitor=null,names=null,spans=false){
  const l=wireLimits(options);if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<44||bytes.length>l.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==this.#headerWords[i])throw Error('wire format or schema mismatch');
  if(names!==null&&(!Array.isArray(names)||names.length>100000||names.some(n=>typeof n!=='string')))throw Error('wire visitor names');
  if(materialize&&!visitor){this.#decodeBound||=wireBindDecodePlan(this.#valuePlan);const cursor=new WireDecodeCursor(bytes,view,l);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#valuePlan.decode(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  if(!materialize){this.#scanPlan??=wireScanPlan(this.#valuePlan);const cursor=new WireScanCursor(bytes,view,l,visitor,names===null?null:new Set(names),spans),value=this.#scanPlan.scan(cursor,bytes.length,0);if(cursor.cursor!==bytes.length)throw Error('trailing wire bytes');return value;}
  return wireScanValue(this.#valuePlan,bytes,view,l,materialize,visitor,names===null?null:new Set(names),spans);
 }
 visit(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names);}
 visitSpans(bytes,visitor,options=wireDefaultOptions,names=null){if(typeof visitor!=='function')throw Error('wire visitor required');this.scan(bytes,options,false,visitor,names,true);}
 validate(bytes,options=wireDefaultOptions){this.scan(bytes,options,false);return true;}
 decode(bytes,options=wireDefaultOptions){return this.scan(bytes,options,true);}
}

// Bounded forward emission avoids building and repeatedly joining child buffers.
class WireEncoder{
 #data=new Uint8Array(256);#view=new DataView(this.#data.buffer);#at=0;#remaining;#depth=0;#byteLimit;#depthLimit;
 active=false;
 constructor(options){this.reset(options);}
 reset(options){const limits=wireLimits(options);this.#byteLimit=limits.bytes;this.#depthLimit=limits.depth;this.#remaining=limits.nodes;this.#depth=0;this.#at=0;this.active=true;}
 get capacity(){return this.#data.length;}
 get position(){return this.#at;}
 beginNode(){const at=this.#at;this.word(0);return at;}
 endNode(at){this.patchWord(at,this.#at-at-4);}
 count(n){this.word(n);}
 beginCount(){const at=this.position;this.count(0);return at;}
 endCount(at,n){this.patchWord(at,n);}
 #reserve(size){
  const end=this.#at+size;if(end>this.#byteLimit)throw Error('wire byte limit');
  if(end>this.#data.length){const next=new Uint8Array(Math.min(this.#byteLimit,Math.max(end,this.#data.length*2)));next.set(this.#data.subarray(0,this.#at));this.#data=next;this.#view=new DataView(next.buffer);}
  return end;
 }
 bytes(bytes){const end=this.#reserve(bytes.length);this.#data.set(bytes,this.#at);this.#at=end;}
 byte(n){if(!Number.isInteger(n)||n<0||n>255)throw Error('wire byte range');this.#reserve(1);this.#data[this.#at++]=n;}
 word(n){if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire word range');const end=this.#reserve(4);this.#view.setUint32(this.#at,n,true);this.#at=end;}
 wide(n){if(typeof n!=='bigint'||n<0n||n>18446744073709551615n)throw Error('wire wide range');const end=this.#reserve(8);this.#view.setBigUint64(this.#at,n,true);this.#at=end;}
 text(text,count=false){
  if(typeof text!=='string')throw Error('wire Unicode');
  if(text.length<=16){
   let ascii=true;for(let i=0;i<text.length;i++)if(text.charCodeAt(i)>=128){ascii=false;break;}
   if(ascii){if(count)this.count(text.length);const end=this.#reserve(text.length);for(let i=0;i<text.length;i++)this.#data[this.#at+i]=text.charCodeAt(i);this.#at=end;return;}
  }
  if(!text.isWellFormed())throw Error('wire Unicode');const size=wireUtf8Length(text);if(count)this.count(size);
  const end=this.#reserve(size),r=wireEncoder.encodeInto(text,this.#data.subarray(this.#at,end));if(r.read!==text.length||r.written!==size)throw Error('wire UTF-8 size');this.#at=end;
 }
 patchWord(at,n){if(!Number.isInteger(at)||at<0||at+4>this.#at||!Number.isInteger(n)||n<0||n>4294967295)throw Error('wire patch offset');this.#view.setUint32(at,n,true);}
 patchByte(at,n){if(!Number.isInteger(at)||at<0||at>=this.#at||!Number.isInteger(n)||n<0||n>255)throw Error('wire patch offset');this.#data[at]=n;}
 replace(at,removed,bytes){
  if(!Number.isInteger(at)||!Number.isInteger(removed)||at<0||removed<0||at+removed>this.#at||!(bytes instanceof Uint8Array))throw Error('wire replacement range');
  const extra=bytes.length-removed,end=extra>0?this.#reserve(extra):this.#at+extra;
  this.#data.copyWithin(at+bytes.length,at+removed,this.#at);this.#data.set(bytes,at);this.#at=end;
 }
 // Literal generated writers use balanced frames without per-node callbacks.
 // An exception abandons this invocation; encodeWith never reuses its writer.
 openFrame(){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;return at;}
 closeFrame(at){if(this.#depth===0)throw Error('wire frame boundary');this.#depth--;this.endNode(at);}
 frame(emit){if(this.#depth>this.#depthLimit||--this.#remaining<0)throw Error('wire node or depth limit');const at=this.beginNode();this.#depth++;try{emit(this);}finally{this.#depth--;}this.endNode(at);}
 reorder(start,spans){
  const sorted=spans.slice().sort((a,b)=>a[0]-b[0]);let at=start;
  for(const [a,b] of sorted){if(!Number.isInteger(a)||!Number.isInteger(b)||a!==at||b<a)throw Error('wire span permutation');at=b;}
  if(start<0||start>this.#at||at!==this.#at)throw Error('wire span permutation');
  if(spans.every((s,i)=>s===sorted[i]))return;
  const copy=this.#data.slice(start,this.#at);at=start;for(const [a,b] of spans){this.#data.set(copy.subarray(a-start,b-start),at);at+=b-a;}
 }
 finish(){if(this.#depth!==0)throw Error('wire frame boundary');return this.#data.slice(0,this.#at);}
}

class CompactWireEncoder extends WireEncoder{
 beginNode(){return 0;}
 endNode(){}
 endCount(at,n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  if(n<128){this.patchByte(at,n);return;}
  const bytes=[];while(n>=128){bytes.push(n%128+128);n=Math.floor(n/128);}bytes.push(n);this.replace(at,1,Uint8Array.from(bytes));
 }
 count(n){
  if(!Number.isInteger(n)||n<0||n>4294967295)throw Error('compact count range');
  while(n>=128){this.byte(n%128+128);n=Math.floor(n/128);}this.byte(n);
 }
 text(text){super.text(text,true);}
}

function compactScanValue(root,bytes,l,materialize){
 const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);let cursor=1,remaining=l.nodes;
 const require=n=>{if(n>bytes.length-cursor)throw Error('truncated compact value');};
 const count=()=>{
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   require(1);const byte=bytes[cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }throw Error('compact count overflow');
 };
 const property={value:null,enumerable:true,writable:true,configurable:true};
 const node=(p,d)=>{
  if(d>l.depth||--remaining<0)throw Error('wire node or depth limit');
  const t=p.type;let value;
  switch(p.kind){
   case 'unit':return null;
   case 'bool':require(1);if(bytes[cursor]>1)throw Error('invalid wire Bool');return !!bytes[cursor++];
   case 'u32':case 'i32':require(4);value=p.kind==='u32'?view.getUint32(cursor,true):view.getInt32(cursor,true);cursor+=4;return value;
   case 'f32':require(4);if(materialize)value={F32Bits:view.getUint32(cursor,true)};cursor+=4;return value;
   case 'f64':require(8);if(materialize)value={F64Bits:view.getBigUint64(cursor,true).toString()};cursor+=8;return value;
   case 'u64':require(8);if(materialize)value=view.getBigUint64(cursor,true);cursor+=8;return value;
   case 'string':case 'int':case 'id':case 'enum':{
    const n=count();require(n);const start=cursor;cursor+=n;
    if(p.kind==='string'&&!materialize){let i=start;while(i<cursor&&bytes[i]<128)i++;if(i<cursor)wireDecoder.decode(bytes.subarray(start,cursor));}
    else{const text=wireDecodeText(bytes,start,cursor);if(p.kind==='int'&&!wireDecimal(text)||p.kind==='id'&&!/^[0-9a-f]{32}$/.test(text)||p.kind==='enum'&&!t.variants.includes(text))throw Error('malformed wire text');if(materialize)value=p.kind==='int'?{Int:text}:text;}
    return value;
   }
   case 'list':case 'vector':{
    const n=count();if(n>remaining||p.kind==='vector'&&n!==t.size)throw Error('wire sequence size');
    if(materialize)value=[];for(let i=0;i<n;i++){const child=node(p.element,d+1);if(materialize)value.push(child);}return value;
   }
   case 'record':{
    const fs=p.fields;
    if(materialize&&fs.length<=4){
     switch(fs.length){case 0:return {};case 1:return {[fs[0].name]:node(fs[0].plan,d+1)};case 2:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1)};case 3:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1)};case 4:return {[fs[0].name]:node(fs[0].plan,d+1),[fs[1].name]:node(fs[1].plan,d+1),[fs[2].name]:node(fs[2].plan,d+1),[fs[3].name]:node(fs[3].plan,d+1)};}
    }
    if(materialize)value={};for(const f of fs){const child=node(f.plan,d+1);if(materialize){property.value=child;Object.defineProperty(value,f.name,property);}}return value;
   }
   case 'option':case 'result':{
    require(1);const tag=bytes[cursor++];if(tag>1)throw Error('wire sum tag');
    if(p.kind==='option'&&tag===0)return materialize?{None:null}:undefined;
    const label=p.kind==='option'?'Some':tag===0?'Ok':'Err',child=node(p.kind==='option'?p.element:tag===0?p.ok:p.error,d+1);
    return materialize?{[label]:child}:undefined;
   }
   default:throw Error('unsupported wire kind');
  }
 };
 const value=node(root,0);if(cursor!==bytes.length)throw Error('trailing compact bytes');return value;
}

// General transport codec, independent of source rewrites and checkpoints.
// The sender/receiver must negotiate this exact identity and format. There is
// deliberately no claim that the bytes themselves identify their schema.
export class CompactValueCodec{
 #source;#plan;#encoder;#decodeBound=0;
 get format(){return compactValueWireFormat;}
 get identity(){return this.#source.descriptor.identity;}
 constructor(valueCodec){if(!(valueCodec instanceof ValueCodec))throw Error('compact codec requires a checked value codec');this.#source=valueCodec;this.#plan=wireValuePlan(valueCodec);}
 encode(value,options=wireDefaultOptions){
  const l=wireLimits(options),w=this.#encoder&&!this.#encoder.active?this.#encoder:new CompactWireEncoder(l);
  this.#encoder??=w;w.reset(l);
  try{w.byte(1);wireEncodeValue(this.#plan,value,l,w);return w.finish();}
  finally{w.active=false;if(w.capacity>4096&&this.#encoder===w)this.#encoder=undefined;}
 }
 encodeWith(emit,options=wireDefaultOptions){
  const w=new CompactWireEncoder(options);w.byte(1);emit(w);const bytes=w.finish();this.validate(bytes,options);return bytes;
 }
 #scan(bytes,options,materialize){
  const l=wireLimits(options);
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<1||bytes.length>l.bytes)throw Error('wire byte limit or header');
  if(bytes[0]!==1)throw Error('compact format mismatch');
  if(materialize){this.#decodeBound||=wireBindDecodePlan(this.#plan,true);const cursor=new CompactDecodeCursor(bytes,l,this.#decodeBound);if(this.#decodeBound&1)cursor.property={value:null,enumerable:true,writable:true,configurable:true};const value=this.#plan.decodeCompact(cursor,0);if(cursor.cursor!==bytes.length)throw Error('trailing compact bytes');return value;}
  return compactScanValue(this.#plan,bytes,l,materialize);
 }
 decode(bytes,options=wireDefaultOptions){return this.#scan(bytes,options,true);}
 validate(bytes,options=wireDefaultOptions){this.#scan(bytes,options,false);return true;}
}

// Compiler materialisers consume already validated bytes synchronously. This
// factory is for trusted emitted code, not untrusted descriptor/callback data.
// The complete generic validator runs before any compiler reader is invoked.
class ValidatedValueReader{
 constructor(bytes,compact){this.bytes=bytes;this.view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);this.cursor=compact?1:40;this.compact=compact;}
 frame(){if(this.compact)return 0;const end=this.cursor+4+this.view.getUint32(this.cursor,true);this.cursor+=4;return end;}
 finish(end){if(!this.compact&&this.cursor!==end)throw Error('compiled reader frame mismatch');}
 byte(){return this.bytes[this.cursor++];}
 word(){const n=this.view.getUint32(this.cursor,true);this.cursor+=4;return n;}
 signed(){const n=this.view.getInt32(this.cursor,true);this.cursor+=4;return n;}
 wide(){const n=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return n;}
 count(){if(!this.compact)return this.word();let n=0,scale=1,byte;do{byte=this.byte();n+=(byte&127)*scale;scale*=128;}while(byte>=128);return n;}
 text(end){const n=this.compact?this.count():end-this.cursor,start=this.cursor;this.cursor+=n;return wireDecodeText(this.bytes,start,this.cursor);}
}
class CompiledCompactValueCodec extends CompactValueCodec{
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,true),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
}
class CompiledValueCodec extends ValueCodec{
 #read;#compiledCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){super.validate(bytes,options);const reader=new ValidatedValueReader(bytes,false),value=this.#read(reader);if(reader.cursor!==bytes.length)throw Error('compiled reader trailing bytes');return value;}
 compact(){return this.#compiledCompact??=new CompiledCompactValueCodec(this,this.#read);}
}
export function createCompiledValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new CompiledValueCodec(descriptor,read);}

// Trusted literal materialisers may use this checked reader to validate and
// construct in one traversal. The emitter must use frame/finish at every source
// node, typed text reads and counted sequence reads; arbitrary callbacks do not
// establish a schema correspondence proof. The independent scanner remains the
// validation oracle and the original factory retains its pre-validation path.
function literalValueHeader(identity){
 const bytes=new Uint8Array(40);bytes.set(wireMagic);
 for(let i=0;i<32;i++)bytes[i+8]=parseInt(identity.slice(i*2,i*2+2),16);
 const view=new DataView(bytes.buffer),words=new Uint32Array(10);
 for(let i=0;i<10;i++)words[i]=view.getUint32(i*4,true);
 return words;
}
class CheckedLiteralValueReader {
 constructor(bytes,header,compact,limits){
  if(!(bytes instanceof Uint8Array)||typeof SharedArrayBuffer==='function'&&bytes.buffer instanceof SharedArrayBuffer||bytes.length<(compact?1:44)||bytes.length>limits.bytes)throw Error('wire byte limit or header');
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  if(compact){if(bytes[0]!==1)throw Error('compact format mismatch');}
  else for(let i=0;i<10;i++)if(view.getUint32(i*4,true)!==header[i])throw Error('wire format or schema mismatch');
  this.bytes=bytes;this.view=view;
  this.cursor=compact?1:40;this.compact=compact;this.remaining=limits.nodes;this.depth=limits.depth;this.ends=[];
 }
 require(n){if(this.cursor+n>(this.ends.at(-1)??this.bytes.length))throw Error('truncated wire frame');}
 frame(){
  if(this.ends.length>this.depth||--this.remaining<0)throw Error('wire node or depth limit');
  let end=this.bytes.length;
  if(!this.compact){this.require(4);end=this.cursor+4+this.view.getUint32(this.cursor,true);this.require(end-this.cursor);this.cursor+=4;}
  this.ends.push(end);return this.compact?0:end;
 }
 finish(end){
  if(!this.ends.length||!this.compact&&(this.ends.at(-1)!==end||this.cursor!==end))throw Error('compiled reader frame mismatch');
  this.ends.pop();
 }
 byte(){this.require(1);const value=this.bytes[this.cursor++];if(value>1)throw Error('wire sum tag or Bool');return value;}
 word(){this.require(4);const value=this.view.getUint32(this.cursor,true);this.cursor+=4;return value;}
 signed(){this.require(4);const value=this.view.getInt32(this.cursor,true);this.cursor+=4;return value;}
 wide(){this.require(8);const value=this.view.getBigUint64(this.cursor,true);this.cursor+=8;return value;}
 rawCount(){
  if(!this.compact)return this.word();
  let value=0,scale=1;
  for(let i=0;i<5;i++){
   this.require(1);const byte=this.bytes[this.cursor++];
   if(i===4&&byte>15)throw Error('compact count overflow');
   value+=(byte&127)*scale;
   if(byte<128){if(i>0&&byte===0)throw Error('noncanonical compact count');return value;}
   scale*=128;
  }
  throw Error('compact count overflow');
 }
 count(size){
  const value=this.rawCount();
  if(value>this.remaining||size!==undefined&&value!==size)throw Error('wire sequence size');
  return value;
 }
 text(end,kind='string',variants){
  const size=this.compact?this.rawCount():end-this.cursor;
  this.require(size);const start=this.cursor;this.cursor+=size;
  const value=wireDecodeText(this.bytes,start,this.cursor);
  if(kind==='int'&&!wireDecimal(value)||kind==='id'&&!/^[0-9a-f]{32}$/.test(value)||kind==='enum'&&!variants.includes(value))throw Error('malformed wire text');
  return value;
 }
 complete(){if(this.ends.length||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
// Compact source nodes have no individual frame ends: retain the same checked
// depth/node order using a counter, with bounds against the complete buffer.
class CheckedCompactLiteralValueReader extends CheckedLiteralValueReader {
 constructor(bytes,limits){super(bytes,null,true,limits);this.level=0;}
 require(n){if(this.cursor+n>this.bytes.length)throw Error('truncated wire frame');}
 frame(){if(this.level>this.depth||--this.remaining<0)throw Error('wire node or depth limit');this.level++;return 0;}
 finish(_end){if(!this.level)throw Error('compiled reader frame mismatch');this.level--;}
 complete(){if(this.level||this.cursor!==this.bytes.length)throw Error('compiled reader trailing bytes');}
}
class FusedCompactValueCodec extends CompactValueCodec {
 #read;
 constructor(source,read){super(source);this.#read=read;}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedCompactLiteralValueReader(bytes,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
}
class FusedValueCodec extends ValueCodec {
 #read;#header;#fusedCompact=null;
 constructor(descriptor,read){super(descriptor);this.#read=read;this.#header=literalValueHeader(this.descriptor.identity);}
 decode(bytes,options=wireDefaultOptions){
  const limits=wireLimits(options);
  try{const reader=new CheckedLiteralValueReader(bytes,this.#header,false,limits),value=this.#read(reader);reader.complete();return value;}
  catch(error){super.validate(bytes,limits);throw error;}
 }
 compact(){return this.#fusedCompact??=new FusedCompactValueCodec(this,this.#read);}
}
export function createFusedValueCodec(descriptor,read){if(typeof read!=='function')throw Error('compiled value reader required');return new FusedValueCodec(descriptor,read);}
// JSON text is a boundary adapter to an ordinary recursive Ink datatype.
// No JavaScript Number conversion occurs for JSON numeric tokens.
export function jsonNumberToken(s){return typeof s==='string'&&/^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$/.test(s);}
// JSON numeric tokens have an ASCII grammar. Check validated UTF-8 spans
// directly, preserving exact lexemes without allocating a decoded String.
function jsonNumberSpan(bytes,lo,hi){
 let at=lo;if(bytes[at]===45)at++;
 if(at>=hi)return false;
 if(bytes[at]===48)at++;
 else{if(bytes[at]<49||bytes[at]>57)return false;do{at++;}while(at<hi&&bytes[at]>=48&&bytes[at]<=57);}
 if(at<hi&&bytes[at]===46){const start=++at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 if(at<hi&&(bytes[at]===69||bytes[at]===101)){at++;if(at<hi&&(bytes[at]===43||bytes[at]===45))at++;const start=at;while(at<hi&&bytes[at]>=48&&bytes[at]<=57)at++;if(at===start)return false;}
 return at===hi;
}
const jsonWireEncoder=new TextEncoder();
// Scalar conversion completes before writer callbacks; no per-value byte array.
const jsonFloatScratch=new DataView(new ArrayBuffer(4));
function jsonUtf8Length(text){if(text.length>16&&!/[^\x00-\x7f]/.test(text))return text.length;let bytes=0;for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);if(c<128)bytes++;else if(c<2048)bytes+=2;else if(c>=0xd800&&c<=0xdbff){bytes+=4;i++;}else bytes+=3;}return bytes;}
const jsonLimits={bytes:16777216,nodes:1000000,depth:128};
const jsonQuoters=new WeakSet();
/** Explicit, bounded reuse of immutable JSON string quotes. Cache payload bytes
 * are UTF-16 storage estimates; entry caps bound separate Map/object overhead.
 * Logical output budgets are charged again on every use, including cache hits.
 */
export function createJsonQuoter({maxEntries=1024,maxBytes=131072}={}){
 if(!Number.isSafeInteger(maxEntries)||maxEntries<0||maxEntries>65536||!Number.isSafeInteger(maxBytes)||maxBytes<0||maxBytes>16777216)throw Error('JSON quote cache budget');
 const entries=new Map();let bytes=0,hits=0,misses=0;
 const token=value=>{
  const prior=entries.get(value);if(prior!==undefined){hits++;return prior;}
  if(typeof value!=='string'||!value.isWellFormed())throw Error('invalid JSON String');
  misses++;const text=JSON.stringify(value),size=2*(value.length+text.length),quoted=Object.freeze({text,utf8Bytes:jsonUtf8Length(text)});
  if(maxEntries&&size<=maxBytes){
   while(entries.size&&(entries.size>=maxEntries||bytes+size>maxBytes)){const key=entries.keys().next().value;bytes-=2*(key.length+entries.get(key).text.length);entries.delete(key);}
   entries.set(value,quoted);bytes+=size;
  }
  return quoted;
 };
 const quoter=Object.freeze({
  token,
  quote(value){return token(value).text;},
  clear(){entries.clear();bytes=0;},
  stats(){return {entries:entries.size,payload_bytes:bytes,hits,misses};},
 });jsonQuoters.add(quoter);return quoter;
}
function checkedJsonLimits(options){const l={...jsonLimits,...options};for(const k of ['bytes','nodes','depth'])if(!Number.isSafeInteger(l[k])||l[k]<0||l[k]>jsonLimits[k])throw Error('JSON hard resource limit');return l;}
function jsonVariant(index,item){let payload=index===0?{}:{item0:item};if(index<5)payload={Ok:payload};for(let i=0;i<index;i++)payload={Err:payload};return {payload};}
export function parseJson(text,options={}){return parseJsonValue(text,options,null);}
function parseJsonValue(text,options,boundary){
 const p=new JsonWireReader(text,options);
 const value=(d,wireDepth=0)=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){boundary?.node(0,wireDepth);p.at+=4;return jsonVariant(0,null);}if(c==='t'&&text.startsWith('true',p.at)){boundary?.node(1,wireDepth);p.at+=4;return jsonVariant(1,true);}if(c==='f'&&text.startsWith('false',p.at)){boundary?.node(1,wireDepth);p.at+=5;return jsonVariant(1,false);}
  if(c==='"'){boundary?.node(3,wireDepth);const item=p.string();boundary?.text(item);return jsonVariant(3,item);}
  if(c==='['){boundary?.node(4,wireDepth);p.at++;const xs=[];if(!p.eat(']'))while(true){xs.push(value(d+1,wireDepth+8));if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}return jsonVariant(4,xs);}
  if(c==='{'){boundary?.node(5,wireDepth);p.at++;const xs=[],seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary?.member(key,wireDepth);if(!p.eat(':'))throw Error('JSON object colon');xs.push({key,value:value(d+1,wireDepth+9)});if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}return jsonVariant(5,xs);}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();boundary?.node(2,wireDepth);boundary?.text(token);return jsonVariant(2,token);}
  throw Error('invalid JSON value');
 };
 const out=value(0);p.finish();return out;
}
export function stringifyJson(value,options={}){return stringifyJsonValue(value,options,null);}
function stringifyJsonValue(value,options,boundary){
 const l=checkedJsonLimits(options);let remaining=l.nodes,bytes=0,output='';
 const emit=s=>{bytes+=jsonUtf8Length(s);if(bytes>l.bytes)throw Error('JSON byte limit');output+=s;};
 const write=(v,d,wireDepth=0)=>{
  if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');if(!v||Object.keys(v).length!==1||!Object.hasOwn(v,'payload'))throw Error('invalid JSON record');let p=v.payload,index=0;
  while(index<5&&p&&Object.hasOwn(p,'Err')){if(Object.keys(p).length!==1||boundary&&Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Err;index++;}
  if(index<5){if(!p||Object.keys(p).length!==1||!Object.hasOwn(p,'Ok'))throw Error('invalid JSON sum');p=p.Ok;}
  if(!p||Object.keys(p).length!==(index===0?0:1)||index>0&&!Object.hasOwn(p,'item0'))throw Error('invalid JSON payload');const item=p.item0;boundary?.node(index,wireDepth);
  switch(index){
   case 0:emit('null');break;
   case 1:if(typeof item!=='boolean')throw Error('invalid JSON Boolean');emit(item?'true':'false');break;
   case 2:if(!jsonNumberToken(item))throw Error('invalid JSON number');boundary?.text(item);emit(item);break;
   case 3:if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary?.text(item);emit(JSON.stringify(item));break;
   case 4:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Array');const count=item.length;let visited=0;emit('[');item.forEach((x,i)=>{visited++;if(i)emit(',');write(x,d+1,wireDepth+8);});if(visited!==count)throw Error('invalid JSON Array');emit(']');break;}
   case 5:{if(!Array.isArray(item)||item.length>remaining)throw Error('invalid JSON Object');const count=item.length,seen=new Set();let visited=0;emit('{');item.forEach((m,i)=>{visited++;if(!m||Object.keys(m).length!==2||typeof m.key!=='string'||!m.key.isWellFormed()||!Object.hasOwn(m,'value')||boundary&&!Object.hasOwn(m,'key'))throw Error('invalid JSON member');if(seen.has(m.key))throw Error('duplicate JSON object key');seen.add(m.key);boundary?.member(m.key,wireDepth);if(i)emit(',');emit(JSON.stringify(m.key));emit(':');write(m.value,d+1,wireDepth+9);});if(visited!==count)throw Error('invalid JSON Object');emit('}');break;}
  }
 };write(value,0);return output;
}
// The adapter's schema is the fixed recursive JSON library shape checked by
// JsonCodec. Charge its ordinary record/sum/list wire nodes while parsing or
// rendering, rather than interpreting and walking the completed tree again.
function jsonBoundaryBudget(options){
 const l=checkedJsonLimits(options);let remaining=l.nodes,total=40;
 const charge=(nodes,bytes,depth)=>{remaining-=nodes;total+=bytes;if(remaining<0||depth>l.depth)throw Error('wire node or depth limit');if(total>l.bytes)throw Error('wire byte limit');};
 return {
  node(index,depth){charge(index===0?3:index<4?index+4:8,index===0?13:index===1?23:index===2?27:index===3?32:41,depth+(index===0?2:index<4?index+3:7));},
  text(text){charge(0,jsonUtf8Length(text),0);},
  member(key,depth){charge(2,8+jsonUtf8Length(key),depth+9);},
 };
}
function jsonSameSchema(a,b){
 if(a===b)return true;if(!a||!b||typeof a!=='object'||typeof b!=='object'||Array.isArray(a)!==Array.isArray(b))return false;
 const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>Object.hasOwn(b,k)&&jsonSameSchema(a[k],b[k]));
}
// Host-object conversion is opt-in and JavaScript-only. Inspect data properties
// rather than invoking getters/toJSON; reflection is not a sandbox for proxies.
function jsonJSKeys(value){
 if(!value||typeof value!=='object')throw Error('expected a plain JavaScript object');
 const prototype=Object.getPrototypeOf(value);
 if(prototype!==Object.prototype&&prototype!==null)throw Error('expected a plain JavaScript object');
 const keys=Reflect.ownKeys(value);
 if(keys.some(k=>typeof k!=='string'))throw Error('JavaScript symbol keys are unsupported');
 return keys;
}
function jsonJSData(value,key){
 const property=Object.getOwnPropertyDescriptor(value,key);
 if(!property||!property.enumerable||!Object.hasOwn(property,'value'))throw Error('expected an enumerable own data property');
 return property.value;
}
function jsonJSRecord(value,names){
 const keys=jsonJSKeys(value);
 if(keys.length!==names.length||keys.some(k=>!names.includes(k)))throw Error('invalid JSON record or variant');
}
function jsonJSArray(value,remaining){
 if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype)throw Error('expected a plain JavaScript array');
 const length=value.length;
 if(length>remaining)throw Error('JSON node limit');
 const keys=Reflect.ownKeys(value);
 if(keys.length!==length+1||keys.some(k=>typeof k!=='string'||k!=='length'&&(!/^(0|[1-9][0-9]*)$/.test(k)||Number(k)>=length)))throw Error('sparse or decorated JavaScript arrays are unsupported');
 return length;
}
function jsonFromJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),active=new WeakSet();let remaining=limits.nodes;
 const text=value=>{if(!value.isWellFormed())throw Error('invalid JSON Unicode');boundary.text(value);return value;};
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  if(value===null){boundary.node(0,wireDepth);return jsonVariant(0);}
  switch(typeof value){
   case 'boolean':boundary.node(1,wireDepth);return jsonVariant(1,value);
   case 'string':boundary.node(3,wireDepth);return jsonVariant(3,text(value));
   case 'number':
    if(!Number.isFinite(value))throw Error('non-finite JavaScript numbers are unsupported');
    boundary.node(2,wireDepth);return jsonVariant(2,text(Object.is(value,-0)?'-0':String(value)));
   case 'bigint':boundary.node(2,wireDepth);return jsonVariant(2,text(String(value)));
   case 'object':break;
   default:throw Error('unsupported JavaScript value');
  }
  if(active.has(value))throw Error('cyclic JavaScript value');
  active.add(value);
  try{
   if(Array.isArray(value)){
    boundary.node(4,wireDepth);const count=jsonJSArray(value,remaining),items=[];
    for(let i=0;i<count;i++)items.push(visit(jsonJSData(value,String(i)),depth+1,wireDepth+8));
    return jsonVariant(4,items);
   }
   boundary.node(5,wireDepth);const keys=jsonJSKeys(value),members=[];
   if(keys.length>remaining)throw Error('JSON node limit');
   for(const key of keys){
    if(!key.isWellFormed())throw Error('invalid JSON Unicode');
    boundary.member(key,wireDepth);
    members.push({key,value:visit(jsonJSData(value,key),depth+1,wireDepth+9)});
   }
   return jsonVariant(5,members);
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
function jsonDecimalKey(token){
 const [,sign,whole,fraction='',exponent='0']=/^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(token);
 const digits=(whole+fraction).replace(/^0+/,'');
 if(!digits)return '0';
 const trimmed=digits.replace(/0+$/,'');
 return sign+trimmed+'e'+(Number(exponent)-fraction.length+digits.length-trimmed.length);
}
function jsonToJS(value,options){
 const limits=checkedJsonLimits(options),boundary=jsonBoundaryBudget(limits),mode=options?.numbers??'number',active=new WeakSet();let remaining=limits.nodes;
 if(!['number','bigint','string'].includes(mode))throw Error('unknown JavaScript number policy');
 const number=token=>{
  if(!jsonNumberToken(token))throw Error('invalid JSON number');
  boundary.text(token);
  if(mode==='string')return token;
  if(mode==='bigint')return BigInt(jsonInteger(token,4096));
  const result=Number(token);
  if(!Number.isFinite(result)||jsonDecimalKey(token)!==jsonDecimalKey(String(result)))throw Error('JSON number loses precision as JavaScript Number; choose numbers: bigint or string');
  return result;
 };
 const visit=(value,depth,wireDepth)=>{
  if(depth>limits.depth||--remaining<0)throw Error('JSON node or depth limit');
  jsonJSRecord(value,['payload']);
  if(active.has(value))throw Error('cyclic JSON value');
  active.add(value);
  try{
   let payload=jsonJSData(value,'payload'),index=0;
   while(index<5&&Object.hasOwn(payload,'Err')){jsonJSRecord(payload,['Err']);payload=jsonJSData(payload,'Err');index++;}
   if(index<5){jsonJSRecord(payload,['Ok']);payload=jsonJSData(payload,'Ok');}
   jsonJSRecord(payload,index===0?[]:['item0']);boundary.node(index,wireDepth);
   const item=index===0?null:jsonJSData(payload,'item0');
   if(index===0)return null;
   if(index===1){if(typeof item!=='boolean')throw Error('invalid JSON Boolean');return item;}
   if(index===2)return number(item);
   if(index===3){if(typeof item!=='string'||!item.isWellFormed())throw Error('invalid JSON String');boundary.text(item);return item;}
   const count=jsonJSArray(item,remaining);
   if(index===4){const out=[];for(let i=0;i<count;i++)out.push(visit(jsonJSData(item,String(i)),depth+1,wireDepth+8));return out;}
   const out={},seen=new Set();
   for(let i=0;i<count;i++){
    const member=jsonJSData(item,String(i));jsonJSRecord(member,['key','value']);const key=jsonJSData(member,'key');
    if(typeof key!=='string'||!key.isWellFormed())throw Error('invalid JSON member key');
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);boundary.member(key,wireDepth);
    Object.defineProperty(out,key,{value:visit(jsonJSData(member,'value'),depth+1,wireDepth+9),enumerable:true,writable:true,configurable:true});
   }
   return out;
  }finally{active.delete(value);}
 };
 return visit(value,0,0);
}
const jsonConstructionPaths=Object.freeze(Array.from({length:6},(_,index)=>Object.freeze([0,...Array(index).fill(1),...(index<5?[0]:[]),0])));
function parseJsonConstructed(text,options,builder){
 const p=new JsonWireReader(text,options);
 const paths=jsonConstructionPaths;
 const fused=typeof builder.openPath==='function';
 const begin=index=>{if(fused){builder.openPath(paths[index]);return;}for(const choice of paths[index])builder.open(choice);};
 const end=index=>{for(let i=0;i<(fused?1:index<5?index+3:7);i++)builder.close();};
 const leaf=(index,item)=>{if(typeof builder.scalarPath==='function'){builder.scalarPath(paths[index],item);return;}begin(index);builder.scalar(item);end(index);};
 const value=d=>{
  p.node(d);const c=p.peek();
  if(c==='n'&&text.startsWith('null',p.at)){p.at+=4;if(typeof builder.emptyPath==='function')builder.emptyPath(paths[0]);else{begin(0);end(0);}return;}
  if(c==='t'&&text.startsWith('true',p.at)){p.at+=4;leaf(1,true);return;}
  if(c==='f'&&text.startsWith('false',p.at)){p.at+=5;leaf(1,false);return;}
  if(c==='"'){leaf(3,p.string());return;}
  if(c==='['){begin(4);builder.open(0);p.at++;if(!p.eat(']'))while(true){value(d+1);if(p.eat(']'))break;if(!p.eat(','))throw Error('JSON array separator');}builder.close();end(4);return;}
  if(c==='{'){begin(5);builder.open(0);p.at++;const seen=new Set();if(!p.eat('}'))while(true){const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');builder.open(0);builder.scalar(key);value(d+1);builder.close();if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON object separator');}builder.close();end(5);return;}
  if(c==='-'||c>='0'&&c<='9'){const token=p.number();leaf(2,token);return;}
  throw Error('invalid JSON value');
 };
 value(0);p.finish();return builder.finish();
}
const jsonCompiledRenderers=new WeakMap();
function compiledJsonRenderer(json,codec,unwrap){
 if(typeof codec?.reducer!=='function')throw Error('compiled JSON reduction unavailable');
 const source=codec.resolve(codec.descriptor.root),root=json.values.descriptor.root;
 const selected=unwrap&&source.kind==='result'?codec.resolve(source.ok):source;
 if(!jsonSameSchema(root,selected)||unwrap&&source.kind!=='result')throw Error('compiled JSON schema mismatch');
 let variants=root.fields[0].type;const roles=new Map([[root.name,'root']]);
 let member;
 for(let index=0;index<6;index++){
  const branch=index<5?variants.ok:variants;roles.set(branch.name,index);
  if(index===5){member=branch.fields[0].type.element.name;roles.set(member,'member');}
  if(index<5)variants=variants.error;
 }
 const nodeRoles=new Map();
 return codec.reducer((node,index)=>{
  const role=roles.get(node.name);nodeRoles.set(index,role);
  if(node.kind==='record'){
   if(role==='root')return value=>value;
   if(role==='member')return (key,value,context)=>{
    const text=(context.quoter?context.quote(key,true):context.add(JSON.stringify(key)+':'))+value,seen=context.members;
    if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);return text;
   };
   if(role===0)return context=>context.add('null');
   if(role===1)return (value,context)=>context.add(value?'true':'false');
   if(role===2)return (token,context)=>{if(!jsonNumberToken(token))throw Error('invalid JSON number');return context.add(token);};
   if(role===3)return (value,context)=>context.quoter?context.quote(value,false):context.add(JSON.stringify(value));
   if(role===4)return (value,context)=>{context.add('[]');return '['+value+']';};
   if(role===5)return (value,context)=>{context.add('{}');return '{'+value+'}';};
   return ()=>null;
  }
  if(node.kind==='list'||node.kind==='vector'){
   const members=nodeRoles.get(node.children[0])==='member';
   return {
    start:(_length,context)=>{
     const out={text:'',parent:members?context.members:null};
     if(members)context.members=new Set();return out;
    },
    step:(out,value,index,context)=>{out.text+=(index?context.add(','):'')+value;return out;},
    finish:(out,context)=>{if(members)context.members=out.parent;return out.text;},
   };
  }
  if(node.kind==='result'){
   // A Result<Json,E> boundary is explicitly requested by the caller. Ordinary
   // JSON's own sums only propagate an already rendered branch.
   if(unwrap&&nodeRoles.get(node.children[0])==='root')return (tag,value)=>{if(tag)throw Error('JSON result is Err');return value;};
   return (_tag,value)=>value;
  }
  if(node.kind==='string')return value=>{if(!value.isWellFormed())throw Error('invalid JSON String');return value;};
  return value=>value;
 });
}
export class JsonCodec{
 constructor(valueCodec){
  const root=valueCodec.descriptor.root,fields=root.fields;if(root.kind!=='record'||!Array.isArray(fields)||fields.length!==1||fields[0].name!=='payload')throw Error('JSON schema payload');let sum=fields[0].type;
  for(let i=0;i<6;i++){
   if(i<5&&sum.kind!=='result')throw Error('JSON schema sum');const branch=i<5?sum.ok:sum,fs=branch.fields;
   if(branch.kind!=='record'||!Array.isArray(fs)||fs.length!==(i?1:0)||i&&fs[0].name!=='item0')throw Error('JSON schema branch');
   if(i){const t=fs[0].type;if(i===1&&t.kind!=='bool'||(i===2||i===3)&&t.kind!=='string'||i===4&&(t.kind!=='list'||t.element.kind!=='ref'||t.element.name!==root.name))throw Error('JSON schema variant');if(i===5){const mf=t.element?.fields;if(t.kind!=='list'||t.element?.kind!=='record'||!Array.isArray(mf)||mf.length!==2||mf[0].name!=='key'||mf[0].type.kind!=='string'||mf[1].name!=='value'||mf[1].type.kind!=='ref'||mf[1].type.name!==root.name)throw Error('JSON schema member');}}
   if(i===2)this.numberBranch=branch.name;if(i===5)this.objectBranch=branch.name;
   if(i<5)sum=sum.error;
  }if(!jsonSameSchema(root,valueCodec.resolve({kind:'ref',name:root.name})))throw Error('JSON recursive schema mismatch');this.values=valueCodec;
 }
 parse(text,options={}){return parseJsonValue(text,options,jsonBoundaryBudget(options));}
 parseCompiled(codec,text,options={}){
  if(codec?.identity!==this.values.descriptor.identity||typeof codec.builder!=='function')throw Error('compiled JSON schema mismatch');
  const builder=codec.builder(options);try{return parseJsonConstructed(text,options,builder);}catch(error){builder.abort();throw error;}
 }
 stringify(value,options={}){return stringifyJsonValue(value,options,jsonBoundaryBudget(options));}
 stringifyCompiled(codec,handle,options={}){
  const limits=checkedJsonLimits(options),unwrap=options.unwrapResult===true;
  const quoter=options.quoter;if(quoter!==undefined&&!jsonQuoters.has(quoter))throw Error('JSON quote cache owner mismatch');
  let codecs=jsonCompiledRenderers.get(this);if(!codecs)jsonCompiledRenderers.set(this,codecs=new WeakMap());
  let renderers=codecs.get(codec);if(!renderers)codecs.set(codec,renderers=new Map());
  let render=renderers.get(unwrap);if(!render)renderers.set(unwrap,render=compiledJsonRenderer(this,codec,unwrap));
  let bytes=0;const context={
   quoter,
   add(text){bytes+=jsonUtf8Length(text);if(bytes>limits.bytes)throw Error('JSON byte limit');return text;},
   quote(value,colon){
    if(!quoter)return this.add(JSON.stringify(value)+(colon?':':''));
    const token=quoter.token(value);bytes+=token.utf8Bytes+(colon?1:0);if(bytes>limits.bytes)throw Error('JSON byte limit');return token.text+(colon?':':'');
   },
  };
  const text=render(handle,context,limits);
  return text;
 }
 fromJS(value,options={}){return jsonFromJS(value,options);}
 toJS(value,options={}){return jsonToJS(value,options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,false);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,false,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,true);}
 validateBinary(bytes,options={}){
  const decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});let view;
  this.values.visitSpans(bytes,(type,data,start,end)=>{
   view??=new DataView(data.buffer,data.byteOffset,data.byteLength);
   if(type.name===this.numberBranch){const length=view.getUint32(start,true);if(!jsonNumberSpan(data,start+4,start+4+length))throw Error('invalid JSON number token');}
   if(type.name===this.objectBranch){const listEnd=start+4+view.getUint32(start,true),count=view.getUint32(start+4,true),seen=new Set();let at=start+8;for(let i=0;i<count;i++){const memberEnd=at+4+view.getUint32(at,true),keyStart=at+8,keyEnd=keyStart+view.getUint32(at+4,true),key=decoder.decode(data.subarray(keyStart,keyEnd));if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);at=memberEnd;}if(at!==listEnd)throw Error('invalid JSON object frame');}
  },options,[this.numberBranch,this.objectBranch]);return true;

 }
}
function jsonUnpack(value){let p=value.payload,i=0;while(i<5&&Object.hasOwn(p,'Err')){p=p.Err;i++;}return [i,(i<5?p.Ok:p).item0];}
function jsonInteger(token,limit){
 if(!jsonNumberToken(token))throw Error('invalid JSON number');const negative=token[0]==='-',raw=negative?token.slice(1):token,[mantissa,exp='0']=raw.split(/[eE]/);let digits=mantissa.replace('.','');if(/^0+$/.test(digits))return '0';const exponent=Number(exp),fraction=mantissa.includes('.')?mantissa.length-mantissa.indexOf('.')-1:0,shift=exponent-fraction;
 if(!Number.isSafeInteger(exponent)||!Number.isSafeInteger(shift))throw Error('JSON integer exponent limit');
 if(shift<0){const cut=-shift;if(cut>=digits.length||!/^[0]+$/.test(digits.slice(-cut)))throw Error('JSON number is not an integer');digits=digits.slice(0,-cut);}else{if(digits.length+shift>limit)throw Error('JSON integer magnitude limit');digits+='0'.repeat(shift);}
 digits=digits.replace(/^0+/,'');if(digits.length>limit)throw Error('JSON integer magnitude limit');return (negative?'-':'')+digits;
}
function jsonBinary64Value(v){
 if(typeof v==='number')return v;
 const text=v.F64Bits;
 if(typeof text!=='string'||text.length>20||!/^(0|[1-9][0-9]*)$/.test(text))throw Error('invalid F64Bits');
 const bits=BigInt(text);if(bits>18446744073709551615n)throw Error('invalid F64Bits');
 const b=new DataView(new ArrayBuffer(8));b.setBigUint64(0,bits,true);return b.getFloat64(0,true);
}
export class TypedJsonCodec{
 constructor(valueCodec){this.values=valueCodec;}
 decode(document,options={}){
  // Validate JSON-specific invariants before interpreting any tagged/record
  // shape, including duplicated names and malformed numeric tokens.
  stringifyJson(document,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const read=(type,value,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type),[kind,item]=jsonUnpack(value);const fail=()=>{throw Error('JSON does not match '+t.kind);};
   switch(t.kind){
    case 'unit':if(kind!==0)fail();return null;
    case 'bool':if(kind!==1)fail();return item;
    case 'u32':case 'u64':case 'i32':case 'int':{if(kind!==2)fail();const text=jsonInteger(item,t.kind==='int'?4096:t.kind==='u64'?20:10);return t.kind==='int'?{Int:text}:t.kind==='u64'?BigInt(text):Number(text);}
    case 'f64':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(8));if(!Number.isFinite(n))throw Error('JSON f64 overflow');b.setFloat64(0,n,true);return {F64Bits:b.getBigUint64(0,true).toString()};}
    case 'f32':{if(kind!==2)fail();const n=Number(item),b=new DataView(new ArrayBuffer(4));b.setFloat32(0,n,true);if(!Number.isFinite(b.getFloat32(0,true)))throw Error('JSON f32 overflow');return {F32Bits:b.getUint32(0,true)};}
    case 'string':case 'enum':case 'id':if(kind!==3)fail();return item;
    case 'list':case 'vector':if(kind!==4)fail();return item.map(x=>read(t.element,x,d+1));
    case 'record':{if(kind!==5||item.length!==t.fields.length)throw Error('unknown or missing JSON record field');const fields=new Map(item.map(m=>[m.key,m.value])),out={};for(const f of t.fields){if(!fields.has(f.name))throw Error('missing JSON record field');Object.defineProperty(out,f.name,{value:read(f.type,fields.get(f.name),d+1),writable:true,enumerable:true,configurable:true});}return out;}
    case 'option':case 'result':{if(kind!==5||item.length!==1)fail();const m=item[0];if(t.kind==='option'&&m.key==='None'&&jsonUnpack(m.value)[0]===0)return {None:null};const child=t.kind==='option'&&m.key==='Some'?t.element:t.kind==='result'&&m.key==='Ok'?t.ok:t.kind==='result'&&m.key==='Err'?t.error:null;if(!child)fail();return {[m.key]:read(child,m.value,d+1)};}
    default:fail();
   }
  };
  const out=read(this.values.descriptor.root,document,0);this.values.validateValue(out,options);return out;
 }
 encode(value,options={}){
  this.values.validateValue(value,options);const l=checkedJsonLimits(options);let remaining=l.nodes;
  const write=(type,v,d)=>{
   if(d>l.depth||--remaining<0)throw Error('typed JSON resource limit');const t=this.values.resolve(type);
   switch(t.kind){
    case 'unit':return jsonVariant(0);
    case 'bool':return jsonVariant(1,v);
    case 'u32':case 'u64':case 'i32':return jsonVariant(2,String(v));
    case 'int':return jsonVariant(2,typeof v==='bigint'?String(v):v.Int);
    case 'f64':{const n=jsonBinary64Value(v);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'f32':{let n;if(typeof v==='number')n=Math.fround(v);else{const b=new DataView(new ArrayBuffer(4));b.setUint32(0,v.F32Bits,true);n=b.getFloat32(0,true);}if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');return jsonVariant(2,Object.is(n,-0)?'-0':String(n));}
    case 'string':case 'id':case 'enum':return jsonVariant(3,v);
    case 'list':case 'vector':return jsonVariant(4,Array.from(v,x=>write(t.element,x,d+1)));
    case 'record':return jsonVariant(5,t.fields.map(f=>({key:f.name,value:write(f.type,v[f.name],d+1)})));
    case 'option':return jsonVariant(5,[Object.hasOwn(v,'Some')?{key:'Some',value:write(t.element,v.Some,d+1)}:{key:'None',value:jsonVariant(0)}]);
    case 'result':return jsonVariant(5,[Object.hasOwn(v,'Ok')?{key:'Ok',value:write(t.ok,v.Ok,d+1)}:{key:'Err',value:write(t.error,v.Err,d+1)}]);
    default:throw Error('unsupported typed JSON descriptor');
   }
  };return write(this.values.descriptor.root,value,0);
 }
 parse(text,options={}){return this.decode(parseJson(text,options),options);}
 stringify(value,options={}){return stringifyJson(this.encode(value,options),options);}
 parseBinary(text,options={}){return streamJsonBinary(this.values,text,options,true);}
 parseCompact(text,options={}){return streamJsonBinary(this.values,text,options,true,true);}
 stringifyBinary(bytes,options={}){return streamWireJsonText(this.values,bytes,options,false);}
}

// Token reader shared by schema-directed and arbitrary-JSON wire emission.
class JsonWireReader{
 constructor(text,options){this.l=checkedJsonLimits(options);if(typeof text!=='string'||!text.isWellFormed()||text.length>this.l.bytes||jsonUtf8Length(text)>this.l.bytes)throw Error('JSON byte or Unicode limit');this.text=text;this.at=0;this.remaining=this.l.nodes;}
 ws(){while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(c!==32&&c!==9&&c!==10&&c!==13)break;this.at++;}}
 peek(){this.ws();return this.text[this.at];}
 eat(c){this.ws();if(this.text[this.at]===c){this.at++;return true;}return false;}
 node(d){if(d>this.l.depth||--this.remaining<0)throw Error('JSON node or depth limit');}
 string(){
  this.ws();const start=this.at;if(this.text[start]!=='"')throw Error('expected JSON string');
  const end=this.text.indexOf('"',start+1);if(end<0)throw Error('unterminated JSON string');
  const raw=this.text.slice(start+1,end);
  if(!raw.includes('\\')&&!/[\x00-\x1f]/.test(raw)){this.at=end+1;return raw;}
  this.at=start+1;while(this.at<this.text.length){if(this.text[this.at]==='"'){this.at++;const v=JSON.parse(this.text.slice(start,this.at));if(!v.isWellFormed())throw Error('invalid JSON Unicode');return v;}if(this.text[this.at]==='\\')this.at+=2;else this.at++;}throw Error('unterminated JSON string');
 }
 number(){const start=this.at;while(this.at<this.text.length){const c=this.text.charCodeAt(this.at);if(!(c>=48&&c<=57||c===45||c===43||c===46||c===101||c===69))break;this.at++;}const token=this.text.slice(start,this.at);if(!jsonNumberToken(token))throw Error('invalid JSON number');return token;}
 leaf(d){this.node(d);const c=this.peek();if(c==='n'&&this.text.startsWith('null',this.at)){this.at+=4;return null;}if(c==='t'&&this.text.startsWith('true',this.at)){this.at+=4;return true;}if(c==='f'&&this.text.startsWith('false',this.at)){this.at+=5;return false;}if(c==='"')return this.string();if(c==='-'||c>='0'&&c<='9')return this.number();throw Error('invalid JSON scalar');}
 finish(){this.ws();if(this.at!==this.text.length)throw Error('trailing JSON text');}
}
function streamJsonBinary(values,text,options,typed,compact=false){
 const p=new JsonWireReader(text,options),utf8=jsonWireEncoder;
 const list=(w,open,close,item)=>{if(!p.eat(open))throw Error('JSON container shape');const at=w.beginCount();let count=0;if(!p.eat(close))while(true){item(w);count++;if(p.eat(close))break;if(!p.eat(','))throw Error('JSON container separator');}w.endCount(at,count);};
 const variant=(w,index,level,emit)=>{if(level<index)w.frame(w=>{w.byte(1);variant(w,index,level+1,emit);});else if(index<5)w.frame(w=>{w.byte(0);w.frame(emit);});else w.frame(emit);};
 const json=(w,d)=>{
  const ch=p.peek(),index=ch==='n'?0:ch==='t'||ch==='f'?1:ch==='-'||ch>='0'&&ch<='9'?2:ch==='"'?3:ch==='['?4:ch==='{'?5:-1;if(index<0)throw Error('invalid JSON value');
  const leaf=index<4?p.leaf(d):null;if(index>=4)p.node(d);
  w.frame(w=>variant(w,index,0,w=>{
   if(index===0)return;if(index===1){w.frame(w=>w.byte(+leaf));return;}
   if(index===2||index===3){w.frame(w=>w.text(leaf));return;}
   w.frame(w=>{if(index===4)list(w,'[',']',w=>json(w,d+1));else{const seen=new Set();list(w,'{','}',w=>{const key=p.string();if(seen.has(key))throw Error('duplicate JSON object key');seen.add(key);if(!p.eat(':'))throw Error('JSON object colon');w.frame(w=>{w.frame(w=>w.text(key));json(w,d+1);});});}});
  }));
 };
 const read=(type,w,d)=>{
  const t=values.resolve(type);w.frame(w=>{
   if(t.kind==='list'||t.kind==='vector'){p.node(d);list(w,'[',']',w=>read(t.element,w,d+1));return;}
   if(t.kind==='record'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON record');const start=w.position,spans=new Array(t.fields.length).fill(null);
    if(!p.eat('}'))while(true){const key=p.string(),i=t.fields.findIndex(f=>f.name===key);if(i<0)throw Error('unknown JSON record field');if(spans[i])throw Error('duplicate JSON record field');if(!p.eat(':'))throw Error('JSON record colon');const at=w.position;read(t.fields[i].type,w,d+1);spans[i]=[at,w.position];if(p.eat('}'))break;if(!p.eat(','))throw Error('JSON record separator');}
    if(spans.some(s=>s===null))throw Error('missing JSON record field');w.reorder(start,spans);return;
   }
   if(t.kind==='option'||t.kind==='result'){
    p.node(d);if(!p.eat('{'))throw Error('expected JSON tagged value');const key=p.string();if(!p.eat(':'))throw Error('JSON tag colon');
    if(t.kind==='option'&&key==='None'){if(p.leaf(d+1)!==null)throw Error('JSON None payload');w.byte(0);}
    else{const child=t.kind==='option'&&key==='Some'?t.element:t.kind==='result'&&key==='Ok'?t.ok:t.kind==='result'&&key==='Err'?t.error:null;if(!child)throw Error('invalid JSON tag');w.byte(key==='Ok'?0:1);read(child,w,d+1);}
    if(!p.eat('}'))throw Error('expected exactly one JSON tag');return;
   }
   const ch=p.peek(),v=p.leaf(d),bad=()=>{throw Error('JSON does not match '+t.kind);};
   if(t.kind==='unit'){if(v!==null)bad();return;}
   if(t.kind==='bool'){if(typeof v!=='boolean')bad();w.byte(+v);return;}
   if(['string','id','enum'].includes(t.kind)){if(ch!=='"')bad();w.text(v);return;}
   if(ch!=='-'&&!(ch>='0'&&ch<='9'))bad();
   if(t.kind==='int'){w.text(jsonInteger(v,4096));return;}
   if(t.kind==='f64'){const n=Number(v);if(!Number.isFinite(n))throw Error('JSON f64 overflow');const b=new DataView(new ArrayBuffer(8));b.setFloat64(0,n,true);w.wide(b.getBigUint64(0,true));}
   else if(t.kind==='f32'){jsonFloatScratch.setFloat32(0,Number(v),true);if(!Number.isFinite(jsonFloatScratch.getFloat32(0,true)))throw Error('JSON f32 overflow');w.word(jsonFloatScratch.getUint32(0,true));}
   else{const n=BigInt(jsonInteger(v,t.kind==='u64'?20:10));if(t.kind==='u64'){if(n<0n||n>18446744073709551615n)bad();w.wide(n);}else if(t.kind==='u32'){if(n<0n||n>4294967295n)bad();w.word(Number(n));}else if(t.kind==='i32'){if(n< -2147483648n||n>2147483647n)bad();w.word(Number(n)>>>0);}else bad();}
  });
 };
 return (compact?values.compact():values).encodeWith(w=>{if(typed)read(values.descriptor.root,w,0);else json(w,0);p.finish();},options);
}

// Render validated bytes in a single traversal; only the final text is owned.
function streamWireJsonText(values,bytes,options,library){
 values.validate(bytes,options);const l=checkedJsonLimits(options),parts=[];let size=0,remaining=l.nodes;const dv=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),decoder=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true});
 const emit=s=>{size+=jsonUtf8Length(s);if(size>l.bytes)throw Error('JSON byte limit');parts.push(s);};
 const string=s=>emit(JSON.stringify(s));const node=d=>{if(d>l.depth||--remaining<0)throw Error('JSON node or depth limit');};
 const frame=(type,at)=>{const t=values.resolve(type),start=at+4,end=start+dv.getUint32(at,true);return{t,start,end};};
 const json=(type,at,d)=>{
  node(d);let root=frame(type,at),sum=frame(root.t.fields[0].type,root.start),index=0;
  while(index<5){const err=bytes[sum.start];sum=frame(err?sum.t.error:sum.t.ok,sum.start+1);if(!err)break;index++;}
  if(index===0){emit('null');return root.end;}
  const item=frame(sum.t.fields[0].type,sum.start);
  if(index===1)emit(bytes[item.start]?'true':'false');
  else if(index===2){const token=decoder.decode(bytes.subarray(item.start,item.end));if(!jsonNumberToken(token))throw Error('invalid JSON number token');emit(token);}
  else if(index===3)string(decoder.decode(bytes.subarray(item.start,item.end)));
  else{const count=dv.getUint32(item.start,true);let p=item.start+4;emit(index===4?'[':'{');const seen=new Set();for(let i=0;i<count;i++){if(i)emit(',');if(index===4)p=json(item.t.element,p,d+1);else{const member=frame(item.t.element,p),key=frame(member.t.fields[0].type,member.start),name=decoder.decode(bytes.subarray(key.start,key.end));if(seen.has(name))throw Error('duplicate JSON object key');seen.add(name);string(name);emit(':');json(member.t.fields[1].type,key.end,d+1);p=member.end;}}emit(index===4?']':'}');}
  return root.end;
 };
 const typed=(type,at,d)=>{
  node(d);const f=frame(type,at),t=f.t;let p=f.start;
  switch(t.kind){
   case 'unit':emit('null');break;
   case 'bool':emit(bytes[p]?'true':'false');break;
   case 'u32':emit(String(dv.getUint32(p,true)));break;
   case 'u64':emit(String(dv.getBigUint64(p,true)));break;
   case 'i32':emit(String(dv.getInt32(p,true)));break;
   case 'f64':{const n=dv.getFloat64(p,true);if(!Number.isFinite(n))throw Error('non-finite f64 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'f32':{const n=dv.getFloat32(p,true);if(!Number.isFinite(n))throw Error('non-finite f32 cannot encode as JSON');emit(Object.is(n,-0)?'-0':String(n));break;}
   case 'int':emit(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'string':case 'id':case 'enum':string(decoder.decode(bytes.subarray(p,f.end)));break;
   case 'list':case 'vector':{const n=dv.getUint32(p,true);p+=4;emit('[');for(let i=0;i<n;i++){if(i)emit(',');p=typed(t.element,p,d+1);}emit(']');break;}
   case 'record':emit('{');for(let i=0;i<t.fields.length;i++){if(i)emit(',');const field=t.fields[i];string(field.name);emit(':');p=typed(field.type,p,d+1);}emit('}');break;
   case 'option':case 'result':{const tag=bytes[p++],key=t.kind==='option'?(tag?'Some':'None'):tag?'Err':'Ok';emit('{');string(key);emit(':');if(t.kind==='option'&&!tag){node(d+1);emit('null');}else typed(t.kind==='option'?t.element:tag?t.error:t.ok,p,d+1);emit('}');break;}
   default:throw Error('unsupported typed JSON descriptor');
  }return f.end;
 };
 if(library)json(values.descriptor.root,40,0);else typed(values.descriptor.root,40,0);return parts.join('');
}

/** Owned, optional read view of arbitrary JSON. Auxiliary indexes contain member
 * offsets only. Logical order, exact number tokens and missing/null remain intact.
 * This does not transparently replace any compiled Ink action or its state.
 */
export function createJsonLookup(text,{stepEntries=16,minReads=4,maxEntries=4096,maxObjects=64,maxIndexBytes=262144,...limits}={}){
 for(const [v,max]of [[stepEntries,4096],[minReads,1000000],[maxEntries,1000000],[maxObjects,256],[maxIndexBytes,16777216]])if(!Number.isSafeInteger(v)||v<0||v>max)throw Error('JSON index budget');
 let root=parseJson(text,limits),indexes=new Map(),entries=0,indexBytes=0;
 const stats={reads:0,writes:0,scanned_members:0,index_hits:0,built_entries:0,invalidations:0};
 function parts(path){
  if(!Array.isArray(path))throw Error('JSON lookup path');const n=path.length;if(n>128)throw Error('JSON lookup path');
  const owned=[];for(let i=0;i<n;i++){const d=Object.getOwnPropertyDescriptor(path,String(i));if(!d||!Object.hasOwn(d,'value'))throw Error('JSON lookup path');const p=d.value;if(!(typeof p==='string'&&p.isWellFormed()&&p.length<=4096)&&!(Number.isSafeInteger(p)&&p>=0))throw Error('JSON lookup path');owned.push(p);}return owned;
 }
 function variant(value){let p=value.payload,index=0;while(index<5&&Object.hasOwn(p,'Err')){p=p.Err;index++;}return {index,item:(index<5?p.Ok:p).item0};}
 function resolve(document,path,indexed){
  let value=document,budget=stepEntries;
  for(let depth=0;depth<path.length;depth++){
   const part=path[depth],v=variant(value);
   if(typeof part==='number'){
    if(v.index!==4)throw Error('expected JSON array');if(part>=v.item.length)return {found:false};value=v.item[part];continue;
   }
   if(v.index!==5)throw Error('expected JSON object');
   const prefix=path.slice(0,depth),key=JSON.stringify(prefix),overhead=128+prefix.reduce((n,p)=>n+(typeof p==='string'?16+p.length*2:8),0);let idx=indexed?indexes.get(key):null;
   if(indexed&&!idx&&indexes.size<maxObjects&&indexBytes+overhead<=maxIndexBytes){idx={path:prefix,reads:0,cursor:0,keys:new Map(),bytes:overhead};indexes.set(key,idx);indexBytes+=overhead;}
   if(idx){
    idx.reads++;
    if(idx.reads>=minReads)while(budget>0&&idx.cursor<v.item.length&&entries<maxEntries){
     const member=v.item[idx.cursor],bytes=64+member.key.length*2;
     if(indexBytes+bytes>maxIndexBytes)break;
     idx.keys.set(member.key,idx.cursor++);idx.bytes+=bytes;indexBytes+=bytes;entries++;stats.built_entries++;budget--;
    }
    if(idx.keys.has(part)){stats.index_hits++;value=v.item[idx.keys.get(part)].value;continue;}
   }
   let found=false;
   for(let i=idx?.cursor??0;i<v.item.length;i++){if(indexed)stats.scanned_members++;if(v.item[i].key===part){value=v.item[i].value;found=true;break;}}
   if(!found)return {found:false};
  }
  return {found:true,value};
 }
 return {
  lookup(path){stats.reads++;const r=resolve(root,parts(path),true);return r.found?{found:true,value:structuredClone(r.value)}:r;},
  set(path,key,text){
   path=parts(path);if(typeof key!=='string'||!key.isWellFormed())throw Error('JSON object key');
   const replacement=parseJson(text,limits),next=structuredClone(root),r=resolve(next,path,false);
   if(!r.found)throw Error('JSON update path missing');const object=variant(r.value);if(object.index!==5)throw Error('expected JSON object');
   const members=[{key,value:replacement},...object.item.filter(m=>m.key!==key)];
   // Validate the complete resulting document before publishing a write.
   let payload=r.value.payload;for(let i=0;i<5;i++)payload=payload.Err;payload.item0=members;
   stringifyJson(next,limits);root=next;stats.writes++;
   for(const [id,idx]of indexes)if(idx.path.length>=path.length&&path.every((p,i)=>p===idx.path[i])){entries-=idx.keys.size;indexBytes-=idx.bytes;indexes.delete(id);stats.invalidations++;}
  },
  replace(text){const next=parseJson(text,limits);root=next;stats.writes++;stats.invalidations+=indexes.size;indexes.clear();entries=0;indexBytes=0;},
  stringify(){return stringifyJson(root,limits);},
  stats(){return {...stats,index_entries:entries,index_objects:indexes.size,index_bytes:indexBytes};}
 };
}
function __ownedValue5(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue0(value[i],budget,depth+1);return out;}
function __ownedValue9(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue7(value[i],budget,depth+1);return out;}
function __ownedValue3(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__ownedValue1(value[i],budget,depth+1);return out;}
function __ownedValue8(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue7(value["value"],budget,depth+1),["first"]:__ownedValue7(value["first"],budget,depth+1),["second"]:__ownedValue7(value["second"],budget,depth+1),["first_power"]:__ownedValue7(value["first_power"],budget,depth+1),["second_power"]:__ownedValue7(value["second_power"],budget,depth+1),["steps"]:__ownedValue2(value["steps"],budget,depth+1)};}
function __ownedValue0(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue1(value["value"],budget,depth+1),["first"]:__ownedValue1(value["first"],budget,depth+1),["second"]:__ownedValue1(value["second"],budget,depth+1),["first_power"]:__ownedValue1(value["first_power"],budget,depth+1),["second_power"]:__ownedValue1(value["second_power"],budget,depth+1),["steps"]:__ownedValue2(value["steps"],budget,depth+1)};}
function __ownedValue7(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue1(value["value"],budget,depth+1),["tangent"]:__ownedValue1(value["tangent"],budget,depth+1)};}
function __ownedValue10(value,budget,depth){budget.enter(depth,4);return {["value"]:__ownedValue6(value["value"],budget,depth+1),["tangent"]:__ownedValue6(value["tangent"],budget,depth+1)};}
function __ownedValue4(value,budget,depth){budget.enter(depth,5);return value;}
function __ownedValue1(value,budget,depth){budget.enter(depth,8);const bits=typeof value==='number'?__bits(value):value.F32Bits;return {F32Bits:bits===0?0:bits};}
function __ownedValue6(value,budget,depth){budget.enter(depth,12);return {F64Bits:__dfBits(value).toString()};}
function __ownedValue2(value,budget,depth){budget.enter(depth,8);return value>>>0;}
const __ownedFunctions=Object.freeze(Object.fromEntries([["empty_parameter",__ownedValue0],["parameter",__ownedValue1],["reglu",__ownedValue1],["dot10",__ownedValue1],["dot6",__ownedValue1],["first_layer",__ownedValue3],["second_layer",__ownedValue3],["outputs",__ownedValue3],["squared_error",__ownedValue1],["objective",__ownedValue1],["gradients",__ownedValue3],["candidate",__ownedValue0],["valid",__ownedValue4],["configuration",__ownedValue4],["shape",__ownedValue4],["update",__ownedValue5],["losses",__ownedValue3],["precise_square",__ownedValue6],["precise_gradient",__ownedValue6],["__ink_differential_7",__ownedValue7],["__ink_differential_6",__ownedValue7],["__ink_differential_13",__ownedValue8],["__ink_differential_12",__ownedValue7],["__ink_differential_14",__ownedValue7],["__ink_differential_11",__ownedValue7],["__ink_differential_5",__ownedValue9],["__ink_differential_19",__ownedValue7],["__ink_differential_18",__ownedValue9],["__ink_differential_4",__ownedValue9],["__ink_differential_21",__ownedValue7],["__ink_differential_20",__ownedValue7],["__ink_differential_25",__ownedValue7],["__ink_differential_2",__ownedValue7],["__ink_differential_1",__ownedValue1],["__ink_differential64_3",__ownedValue10],["__ink_differential64_2",__ownedValue10],["__ink_differential64_1",__ownedValue6]]));
function __wireValue13(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue14(reader);reader.finish(end);return value;}
function __wireValue8(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue9(reader);reader.finish(end);return value;}
function __wireValue15(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue12(reader);reader.finish(end);return value;}
function __wireValue10(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue6(reader);reader.finish(end);return value;}
function __wireValue36(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__wireValue7(reader);reader.finish(end);return value;}
function __wireValue17(reader){const end=reader.frame();const value={};reader.finish(end);return value;}
function __wireValue4(reader){const end=reader.frame();const value={["__ink_differential64_4"]:__wireValue3(reader),["__ink_differential64_5"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue18(reader){const end=reader.frame();const value={["__ink_differential_15"]:__wireValue12(reader),["__ink_differential_16"]:__wireValue12(reader)};reader.finish(end);return value;}
function __wireValue23(reader){const end=reader.frame();const value={["__ink_differential_22"]:__wireValue12(reader),["__ink_differential_23"]:__wireValue12(reader)};reader.finish(end);return value;}
function __wireValue24(reader){const end=reader.frame();const value={["__ink_differential_26"]:__wireValue12(reader),["__ink_differential_27"]:__wireValue12(reader)};reader.finish(end);return value;}
function __wireValue27(reader){const end=reader.frame();const value={["__ink_differential_8"]:__wireValue12(reader),["__ink_differential_9"]:__wireValue12(reader)};reader.finish(end);return value;}
function __wireValue30(reader){const end=reader.frame();const value={["c"]:__wireValue29(reader)};reader.finish(end);return value;}
function __wireValue11(reader){const end=reader.frame();const value={["candidate"]:__wireValue12(reader),["coordinate"]:__wireValue7(reader),["parameters"]:__wireValue13(reader),["features"]:__wireValue15(reader),["row"]:__wireValue7(reader),["base"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue25(reader){const end=reader.frame();const value={["candidate"]:__wireValue12(reader),["coordinate"]:__wireValue7(reader),["parameters"]:__wireValue13(reader),["features"]:__wireValue15(reader),["row"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue21(reader){const end=reader.frame();const value={["candidate"]:__wireValue12(reader),["coordinate"]:__wireValue7(reader),["parameters"]:__wireValue13(reader),["features"]:__wireValue15(reader),["targets"]:__wireValue15(reader),["row"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue16(reader){const end=reader.frame();const value={["candidate"]:__wireValue12(reader),["coordinate"]:__wireValue7(reader),["parameters"]:__wireValue13(reader),["index"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue20(reader){const end=reader.frame();const value={["candidate"]:__wireValue12(reader),["coordinate"]:__wireValue7(reader),["parameters"]:__wireValue13(reader),["inputs"]:__wireValue15(reader),["base"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue19(reader){const end=reader.frame();const value={["candidate"]:__wireValue12(reader),["coordinate"]:__wireValue7(reader),["parameters"]:__wireValue13(reader),["inputs"]:__wireValue15(reader)};reader.finish(end);return value;}
function __wireValue32(reader){const end=reader.frame();const value={["candidate"]:__wireValue6(reader),["coordinate"]:__wireValue7(reader),["parameters"]:__wireValue8(reader),["features"]:__wireValue10(reader),["row"]:__wireValue7(reader),["base"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue34(reader){const end=reader.frame();const value={["candidate"]:__wireValue6(reader),["coordinate"]:__wireValue7(reader),["parameters"]:__wireValue8(reader),["features"]:__wireValue10(reader),["row"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue5(reader){const end=reader.frame();const value={["candidate"]:__wireValue6(reader),["coordinate"]:__wireValue7(reader),["parameters"]:__wireValue8(reader),["features"]:__wireValue10(reader),["targets"]:__wireValue10(reader),["row"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue37(reader){const end=reader.frame();const value={["candidate"]:__wireValue6(reader),["coordinate"]:__wireValue7(reader),["parameters"]:__wireValue8(reader),["index"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue33(reader){const end=reader.frame();const value={["candidate"]:__wireValue6(reader),["coordinate"]:__wireValue7(reader),["parameters"]:__wireValue8(reader),["inputs"]:__wireValue10(reader),["base"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue39(reader){const end=reader.frame();const value={["candidate"]:__wireValue6(reader),["coordinate"]:__wireValue7(reader),["parameters"]:__wireValue8(reader),["inputs"]:__wireValue10(reader)};reader.finish(end);return value;}
function __wireValue28(reader){const end=reader.frame();const value={["p"]:__wireValue9(reader),["g"]:__wireValue6(reader),["c"]:__wireValue29(reader)};reader.finish(end);return value;}
function __wireValue42(reader){const end=reader.frame();const value={["p"]:__wireValue9(reader)};reader.finish(end);return value;}
function __wireValue35(reader){const end=reader.frame();const value={["parameters"]:__wireValue8(reader),["features"]:__wireValue10(reader),["targets"]:__wireValue10(reader),["rows"]:__wireValue36(reader)};reader.finish(end);return value;}
function __wireValue41(reader){const end=reader.frame();const value={["parameters"]:__wireValue8(reader),["gradient"]:__wireValue10(reader),["admissible"]:__wireValue31(reader),["c"]:__wireValue29(reader)};reader.finish(end);return value;}
function __wireValue22(reader){const end=reader.frame();const value={["prediction"]:__wireValue12(reader),["target"]:__wireValue12(reader)};reader.finish(end);return value;}
function __wireValue40(reader){const end=reader.frame();const value={["prediction"]:__wireValue6(reader),["target"]:__wireValue6(reader)};reader.finish(end);return value;}
function __wireValue29(reader){const end=reader.frame();const value={["rate"]:__wireValue6(reader),["first_decay"]:__wireValue6(reader),["second_decay"]:__wireValue6(reader),["epsilon"]:__wireValue6(reader)};reader.finish(end);return value;}
function __wireValue14(reader){const end=reader.frame();const value={["value"]:__wireValue12(reader),["first"]:__wireValue12(reader),["second"]:__wireValue12(reader),["first_power"]:__wireValue12(reader),["second_power"]:__wireValue12(reader),["steps"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue26(reader){const end=reader.frame();const value={["value"]:__wireValue12(reader),["gate"]:__wireValue12(reader)};reader.finish(end);return value;}
function __wireValue9(reader){const end=reader.frame();const value={["value"]:__wireValue6(reader),["first"]:__wireValue6(reader),["second"]:__wireValue6(reader),["first_power"]:__wireValue6(reader),["second_power"]:__wireValue6(reader),["steps"]:__wireValue7(reader)};reader.finish(end);return value;}
function __wireValue38(reader){const end=reader.frame();const value={["value"]:__wireValue6(reader),["gate"]:__wireValue6(reader)};reader.finish(end);return value;}
function __wireValue12(reader){const end=reader.frame();const value={["value"]:__wireValue6(reader),["tangent"]:__wireValue6(reader)};reader.finish(end);return value;}
function __wireValue3(reader){const end=reader.frame();const value={["value"]:__wireValue1(reader),["tangent"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue2(reader){const end=reader.frame();const value={["x"]:__wireValue3(reader)};reader.finish(end);return value;}
function __wireValue0(reader){const end=reader.frame();const value={["x"]:__wireValue1(reader)};reader.finish(end);return value;}
function __wireValue31(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __wireValue6(reader){const end=reader.frame();const value={F32Bits:reader.word()};reader.finish(end);return value;}
function __wireValue1(reader){const end=reader.frame();const value={F64Bits:reader.wide().toString()};reader.finish(end);return value;}
function __wireValue7(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
const __wireReaders=Object.freeze(Object.fromEntries([["__ink_differential64_1",[__wireValue0,__wireValue1]],["__ink_differential64_2",[__wireValue2,__wireValue3]],["__ink_differential64_3",[__wireValue4,__wireValue3]],["__ink_differential_1",[__wireValue5,__wireValue6]],["__ink_differential_11",[__wireValue11,__wireValue12]],["__ink_differential_12",[__wireValue16,__wireValue12]],["__ink_differential_13",[__wireValue17,__wireValue14]],["__ink_differential_14",[__wireValue18,__wireValue12]],["__ink_differential_18",[__wireValue19,__wireValue15]],["__ink_differential_19",[__wireValue20,__wireValue12]],["__ink_differential_2",[__wireValue21,__wireValue12]],["__ink_differential_20",[__wireValue22,__wireValue12]],["__ink_differential_21",[__wireValue23,__wireValue12]],["__ink_differential_25",[__wireValue24,__wireValue12]],["__ink_differential_4",[__wireValue25,__wireValue15]],["__ink_differential_5",[__wireValue25,__wireValue15]],["__ink_differential_6",[__wireValue26,__wireValue12]],["__ink_differential_7",[__wireValue27,__wireValue12]],["candidate",[__wireValue28,__wireValue9]],["configuration",[__wireValue30,__wireValue31]],["dot10",[__wireValue32,__wireValue6]],["dot6",[__wireValue33,__wireValue6]],["empty_parameter",[__wireValue17,__wireValue9]],["first_layer",[__wireValue34,__wireValue10]],["gradients",[__wireValue35,__wireValue10]],["losses",[__wireValue35,__wireValue10]],["objective",[__wireValue5,__wireValue6]],["outputs",[__wireValue34,__wireValue10]],["parameter",[__wireValue37,__wireValue6]],["precise_gradient",[__wireValue0,__wireValue1]],["precise_square",[__wireValue0,__wireValue1]],["reglu",[__wireValue38,__wireValue6]],["second_layer",[__wireValue39,__wireValue10]],["shape",[__wireValue35,__wireValue31]],["squared_error",[__wireValue40,__wireValue6]],["update",[__wireValue41,__wireValue8]],["valid",[__wireValue42,__wireValue31]]]));

const __ownedImplementations=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal).map(f=>{
 const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
 const body=__implementations[f.index];
 const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args)!==true)throw Error('contract precondition failed');return body(...args);};
 return [f.name,input.every(c=>c===__identity)?implementation:(...args)=>{const context=new WeakMap();return implementation(...args.map((v,i)=>input[i](v,context)));}];
})));

export const valueCodecs=(()=>{const codecs={};for(const [name,s] of Object.entries(metadata.wire.functions)){if(s.unsupported)continue;let value;Object.defineProperty(codecs,name,{enumerable:true,get:()=>value??=(Object.freeze(Object.hasOwn(__wireReaders,name)?{arguments:createCompiledValueCodec(s.arguments,__wireReaders[name][0]),result:createCompiledValueCodec(s.result,__wireReaders[name][1])}:{arguments:new ValueCodec(s.arguments),result:new ValueCodec(s.result)}))});}return Object.freeze(codecs);})();
function __callEncoded(name,bytes,limits,compact){
 const f=metadata.functions.find(f=>f.name===name&&!f.internal),codecs=valueCodecs[name];
 if(!f||!codecs)throw Error('unsupported binary function');
 const input=compact?codecs.arguments.compact():codecs.arguments,output=compact?codecs.result.compact():codecs.result;
 const entry=__compiledEntries.get(name);
 if(entry){
  const slot=compact?1:0;
  entry.argumentCodecs[slot]??=(entry.boundaryReaders[slot]?createFusedValueCodec:createCompiledValueCodec)(metadata.wire.functions[name].arguments,entry.arguments);
  const decoder=entry.argumentCodecs[slot];
  const values=(compact?decoder.compact():decoder).decode(bytes,limits),args=f.params.map(p=>values[p.name]);
  if(entry.precondition!==null&&__implementations[entry.precondition](...args)!==true)throw Error('contract precondition failed');
  return __compiledEncodeResult(entry,__implementations[entry.index](...args),limits,compact);
 }
 const values=input.decode(bytes,limits);
 const result=call(name,f.params.map(p=>values[p.name]));
 return output.encode(result,limits);
}
export function callBinary(name,bytes,limits={}){return __callEncoded(name,bytes,limits,false);}
export function callCompact(name,bytes,limits={}){return __callEncoded(name,bytes,limits,true);}
// Same stable, well-typed caller inputs as call; the result owns every container.
// The checked source return type justifies trusted copying, not arbitrary input.
export function callOwned(name,args,limits={}){
 if(!Object.hasOwn(__ownedFunctions,name)||!Object.hasOwn(functions,name))throw Error('unsupported owned function');
 const result=__ownedImplementations[name](...args);return __ownedFunctions[name](result,createValueCaptureBudget(limits),0);
}
function __privateCapture11(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture10(value[i],budget,depth+1);return out;}
function __privateCapture3(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture0(value[i],budget,depth+1);return out;}
function __privateCapture12(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture9(value[i],budget,depth+1);return out;}
function __privateCapture4(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture1(value[i],budget,depth+1);return out;}
function __privateCapture5(value,budget,depth=0){budget.enter(depth,4);if(!Array.isArray(value)&&!(ArrayBuffer.isView(value)&&!(value instanceof DataView))){throw Error('invalid value for wire schema');}const n=value.length;if(n>budget.remaining){throw Error('invalid value for wire schema');}budget.add(4);const out=new Array(n);for(let i=0;i<n;i++)out[i]=__privateCapture2(value[i],budget,depth+1);return out;}
function __privateCapture6(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==4){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"rate")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"first_decay")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"second_decay")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"epsilon")){throw Error('invalid value for wire schema');}return {["rate"]:__privateCapture1(value["rate"],budget,depth+1),["first_decay"]:__privateCapture1(value["first_decay"],budget,depth+1),["second_decay"]:__privateCapture1(value["second_decay"],budget,depth+1),["epsilon"]:__privateCapture1(value["epsilon"],budget,depth+1)};}
function __privateCapture10(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"first")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"second")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"first_power")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"second_power")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"steps")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture9(value["value"],budget,depth+1),["first"]:__privateCapture9(value["first"],budget,depth+1),["second"]:__privateCapture9(value["second"],budget,depth+1),["first_power"]:__privateCapture9(value["first_power"],budget,depth+1),["second_power"]:__privateCapture9(value["second_power"],budget,depth+1),["steps"]:__privateCapture2(value["steps"],budget,depth+1)};}
function __privateCapture0(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==6){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"first")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"second")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"first_power")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"second_power")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"steps")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["first"]:__privateCapture1(value["first"],budget,depth+1),["second"]:__privateCapture1(value["second"],budget,depth+1),["first_power"]:__privateCapture1(value["first_power"],budget,depth+1),["second_power"]:__privateCapture1(value["second_power"],budget,depth+1),["steps"]:__privateCapture2(value["steps"],budget,depth+1)};}
function __privateCapture9(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture1(value["value"],budget,depth+1),["tangent"]:__privateCapture1(value["tangent"],budget,depth+1)};}
function __privateCapture13(value,budget,depth=0){budget.enter(depth,4);if(!value||typeof value!=='object'||Array.isArray(value)||Object.keys(value).length!==2){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"value")){throw Error('invalid value for wire schema');}if(!Object.hasOwn(value,"tangent")){throw Error('invalid value for wire schema');}return {["value"]:__privateCapture8(value["value"],budget,depth+1),["tangent"]:__privateCapture8(value["tangent"],budget,depth+1)};}
function __privateCapture7(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='boolean'){throw Error('invalid value for wire schema');}budget.add(1);return value;}
function __privateCapture1(value,budget,depth=0){budget.enter(depth,4);let bits;if(typeof value==='number'&&Number.isFinite(value)){bits=__bits(value);if(!Number.isFinite(__float(bits))){throw Error('invalid value for wire schema');}}else{if(!(value!==null&&typeof value==='object'&&Object.hasOwn(value,'F32Bits')&&Object.keys(value).length===1)){throw Error('invalid value for wire schema');}bits=value.F32Bits;if(!Number.isInteger(bits)||bits<0||bits>4294967295){throw Error('invalid value for wire schema');}}budget.add(4);return __nfFromBits(bits);}
function __privateCapture8(value,budget,depth=0){budget.enter(depth,4);const result=__dfCapture(value);budget.add(8);return result;}
function __privateCapture2(value,budget,depth=0){budget.enter(depth,4);if(typeof value!=='number'||!Number.isInteger(value)||value<0||value>4294967295){throw Error('invalid value for wire schema');}budget.add(4);return value===0?0:value;}
function __privateWireValue28(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue27(reader);reader.finish(end);return value;}
function __privateWireValue4(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue0(reader);reader.finish(end);return value;}
function __privateWireValue31(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue24(reader);reader.finish(end);return value;}
function __privateWireValue7(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue1(reader);reader.finish(end);return value;}
function __privateWireValue14(reader){const end=reader.frame();const n=reader.count(),value=new Array(n);for(let i=0;i<n;i++)value[i]=__privateWireValue2(reader);reader.finish(end);return value;}
function __privateWireValue3(reader){const end=reader.frame();const value={};reader.finish(end);return value;}
function __privateWireValue41(reader){const end=reader.frame();const value={["__ink_differential64_4"]:__privateWireValue40(reader),["__ink_differential64_5"]:__privateWireValue40(reader)};reader.finish(end);return value;}
function __privateWireValue30(reader){const end=reader.frame();const value={["__ink_differential_15"]:__privateWireValue24(reader),["__ink_differential_16"]:__privateWireValue24(reader)};reader.finish(end);return value;}
function __privateWireValue36(reader){const end=reader.frame();const value={["__ink_differential_22"]:__privateWireValue24(reader),["__ink_differential_23"]:__privateWireValue24(reader)};reader.finish(end);return value;}
function __privateWireValue38(reader){const end=reader.frame();const value={["__ink_differential_26"]:__privateWireValue24(reader),["__ink_differential_27"]:__privateWireValue24(reader)};reader.finish(end);return value;}
function __privateWireValue25(reader){const end=reader.frame();const value={["__ink_differential_8"]:__privateWireValue24(reader),["__ink_differential_9"]:__privateWireValue24(reader)};reader.finish(end);return value;}
function __privateWireValue20(reader){const end=reader.frame();const value={["c"]:__privateWireValue16(reader)};reader.finish(end);return value;}
function __privateWireValue32(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue24(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue28(reader),["features"]:__privateWireValue31(reader),["row"]:__privateWireValue2(reader),["base"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue33(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue24(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue28(reader),["features"]:__privateWireValue31(reader),["row"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue39(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue24(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue28(reader),["features"]:__privateWireValue31(reader),["targets"]:__privateWireValue31(reader),["row"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue29(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue24(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue28(reader),["index"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue34(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue24(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue28(reader),["inputs"]:__privateWireValue31(reader),["base"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue35(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue24(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue28(reader),["inputs"]:__privateWireValue31(reader)};reader.finish(end);return value;}
function __privateWireValue8(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue1(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue4(reader),["features"]:__privateWireValue7(reader),["row"]:__privateWireValue2(reader),["base"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue10(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue1(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue4(reader),["features"]:__privateWireValue7(reader),["row"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue13(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue1(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue4(reader),["features"]:__privateWireValue7(reader),["targets"]:__privateWireValue7(reader),["row"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue5(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue1(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue4(reader),["index"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue9(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue1(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue4(reader),["inputs"]:__privateWireValue7(reader),["base"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue11(reader){const end=reader.frame();const value={["candidate"]:__privateWireValue1(reader),["coordinate"]:__privateWireValue2(reader),["parameters"]:__privateWireValue4(reader),["inputs"]:__privateWireValue7(reader)};reader.finish(end);return value;}
function __privateWireValue17(reader){const end=reader.frame();const value={["p"]:__privateWireValue0(reader),["g"]:__privateWireValue1(reader),["c"]:__privateWireValue16(reader)};reader.finish(end);return value;}
function __privateWireValue19(reader){const end=reader.frame();const value={["p"]:__privateWireValue0(reader)};reader.finish(end);return value;}
function __privateWireValue15(reader){const end=reader.frame();const value={["parameters"]:__privateWireValue4(reader),["features"]:__privateWireValue7(reader),["targets"]:__privateWireValue7(reader),["rows"]:__privateWireValue14(reader)};reader.finish(end);return value;}
function __privateWireValue21(reader){const end=reader.frame();const value={["parameters"]:__privateWireValue4(reader),["gradient"]:__privateWireValue7(reader),["admissible"]:__privateWireValue18(reader),["c"]:__privateWireValue16(reader)};reader.finish(end);return value;}
function __privateWireValue37(reader){const end=reader.frame();const value={["prediction"]:__privateWireValue24(reader),["target"]:__privateWireValue24(reader)};reader.finish(end);return value;}
function __privateWireValue12(reader){const end=reader.frame();const value={["prediction"]:__privateWireValue1(reader),["target"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue16(reader){const end=reader.frame();const value={["rate"]:__privateWireValue1(reader),["first_decay"]:__privateWireValue1(reader),["second_decay"]:__privateWireValue1(reader),["epsilon"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue27(reader){const end=reader.frame();const value={["value"]:__privateWireValue24(reader),["first"]:__privateWireValue24(reader),["second"]:__privateWireValue24(reader),["first_power"]:__privateWireValue24(reader),["second_power"]:__privateWireValue24(reader),["steps"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue26(reader){const end=reader.frame();const value={["value"]:__privateWireValue24(reader),["gate"]:__privateWireValue24(reader)};reader.finish(end);return value;}
function __privateWireValue0(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["first"]:__privateWireValue1(reader),["second"]:__privateWireValue1(reader),["first_power"]:__privateWireValue1(reader),["second_power"]:__privateWireValue1(reader),["steps"]:__privateWireValue2(reader)};reader.finish(end);return value;}
function __privateWireValue6(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["gate"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue24(reader){const end=reader.frame();const value={["value"]:__privateWireValue1(reader),["tangent"]:__privateWireValue1(reader)};reader.finish(end);return value;}
function __privateWireValue40(reader){const end=reader.frame();const value={["value"]:__privateWireValue22(reader),["tangent"]:__privateWireValue22(reader)};reader.finish(end);return value;}
function __privateWireValue42(reader){const end=reader.frame();const value={["x"]:__privateWireValue40(reader)};reader.finish(end);return value;}
function __privateWireValue23(reader){const end=reader.frame();const value={["x"]:__privateWireValue22(reader)};reader.finish(end);return value;}
function __privateWireValue18(reader){const end=reader.frame();const value=!!reader.byte();reader.finish(end);return value;}
function __privateWireValue1(reader){const end=reader.frame();const value=__nfFromBits(reader.word());reader.finish(end);return value;}
function __privateWireValue22(reader){const end=reader.frame();const value=__dfFromBits(reader.wide());reader.finish(end);return value;}
function __privateWireValue2(reader){const end=reader.frame();const value=reader.word();reader.finish(end);return value;}
function __compiledOwnedValue11(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue10(value[i],budget,depth+1);return out;}
function __compiledOwnedValue3(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue0(value[i],budget,depth+1);return out;}
function __compiledOwnedValue12(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue9(value[i],budget,depth+1);return out;}
function __compiledOwnedValue4(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue1(value[i],budget,depth+1);return out;}
function __compiledOwnedValue5(value,budget,depth){budget.enter(depth,8);const n=value.length;if(n>budget.remaining)throw Error('wire sequence size');const out=new Array(n);for(let i=0;i<n;i++)out[i]=__compiledOwnedValue2(value[i],budget,depth+1);return out;}
function __compiledOwnedValue6(value,budget,depth){budget.enter(depth,4);return {["rate"]:__compiledOwnedValue1(value["rate"],budget,depth+1),["first_decay"]:__compiledOwnedValue1(value["first_decay"],budget,depth+1),["second_decay"]:__compiledOwnedValue1(value["second_decay"],budget,depth+1),["epsilon"]:__compiledOwnedValue1(value["epsilon"],budget,depth+1)};}
function __compiledOwnedValue10(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue9(value["value"],budget,depth+1),["first"]:__compiledOwnedValue9(value["first"],budget,depth+1),["second"]:__compiledOwnedValue9(value["second"],budget,depth+1),["first_power"]:__compiledOwnedValue9(value["first_power"],budget,depth+1),["second_power"]:__compiledOwnedValue9(value["second_power"],budget,depth+1),["steps"]:__compiledOwnedValue2(value["steps"],budget,depth+1)};}
function __compiledOwnedValue0(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["first"]:__compiledOwnedValue1(value["first"],budget,depth+1),["second"]:__compiledOwnedValue1(value["second"],budget,depth+1),["first_power"]:__compiledOwnedValue1(value["first_power"],budget,depth+1),["second_power"]:__compiledOwnedValue1(value["second_power"],budget,depth+1),["steps"]:__compiledOwnedValue2(value["steps"],budget,depth+1)};}
function __compiledOwnedValue9(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue1(value["value"],budget,depth+1),["tangent"]:__compiledOwnedValue1(value["tangent"],budget,depth+1)};}
function __compiledOwnedValue13(value,budget,depth){budget.enter(depth,4);return {["value"]:__compiledOwnedValue8(value["value"],budget,depth+1),["tangent"]:__compiledOwnedValue8(value["tangent"],budget,depth+1)};}
function __compiledOwnedValue7(value,budget,depth){budget.enter(depth,5);return value;}
function __compiledOwnedValue1(value,budget,depth){budget.enter(depth,8);const bits=typeof value==='number'?__bits(value):value.F32Bits;return {F32Bits:bits===0?0:bits};}
function __compiledOwnedValue8(value,budget,depth){budget.enter(depth,12);return {F64Bits:__dfBits(value).toString()};}
function __compiledOwnedValue2(value,budget,depth){budget.enter(depth,8);return value>>>0;}
function __privateWireWrite11(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite10(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite3(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite0(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite12(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite9(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite4(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite1(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite5(writer,value,compact){const frame=writer.openFrame();writer.count(value.length);for(let i=0;i<value.length;i++)__privateWireWrite2(writer,value[i],compact);writer.closeFrame(frame);}
function __privateWireWrite6(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["rate"],compact);__privateWireWrite1(writer,value["first_decay"],compact);__privateWireWrite1(writer,value["second_decay"],compact);__privateWireWrite1(writer,value["epsilon"],compact);writer.closeFrame(frame);}
function __privateWireWrite10(writer,value,compact){const frame=writer.openFrame();__privateWireWrite9(writer,value["value"],compact);__privateWireWrite9(writer,value["first"],compact);__privateWireWrite9(writer,value["second"],compact);__privateWireWrite9(writer,value["first_power"],compact);__privateWireWrite9(writer,value["second_power"],compact);__privateWireWrite2(writer,value["steps"],compact);writer.closeFrame(frame);}
function __privateWireWrite0(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite1(writer,value["first"],compact);__privateWireWrite1(writer,value["second"],compact);__privateWireWrite1(writer,value["first_power"],compact);__privateWireWrite1(writer,value["second_power"],compact);__privateWireWrite2(writer,value["steps"],compact);writer.closeFrame(frame);}
function __privateWireWrite9(writer,value,compact){const frame=writer.openFrame();__privateWireWrite1(writer,value["value"],compact);__privateWireWrite1(writer,value["tangent"],compact);writer.closeFrame(frame);}
function __privateWireWrite13(writer,value,compact){const frame=writer.openFrame();__privateWireWrite8(writer,value["value"],compact);__privateWireWrite8(writer,value["tangent"],compact);writer.closeFrame(frame);}
function __privateWireWrite7(writer,value,compact){const frame=writer.openFrame();writer.byte(value?1:0);writer.closeFrame(frame);}
function __privateWireWrite1(writer,value,compact){const frame=writer.openFrame();writer.word(__nfBits(value));writer.closeFrame(frame);}
function __privateWireWrite8(writer,value,compact){const frame=writer.openFrame();writer.wide(__dfBits(value));writer.closeFrame(frame);}
function __privateWireWrite2(writer,value,compact){const frame=writer.openFrame();writer.word(value);writer.closeFrame(frame);}
// Handles have no mutable private payload surface. Membership and type identity
// are checked by this module's closure; copied/foreign objects cannot forge them.
const __compiledHandles=new WeakMap();
const __compiledBindings=new WeakMap();
function __compiledHandle(identity,value,guaranteed=false){
 const handle=Object.freeze(Object.create(null));
 __compiledHandles.set(handle,{identity,value,guaranteed});return handle;
}
function __compiledEntry(handle,identity){
 const entry=__compiledHandles.get(handle);
 if(!entry||entry.identity!==identity)throw Error('compiled value type or owner mismatch');
 return entry;
}
function __compiledUnwrap(handle,identity){return __compiledEntry(handle,identity).value;}
// Emit the portable schema's framing/scalar events without creating a buffer
// or exposing private composite nodes. Only this wrapper receives callbacks
// from the literal writer; host visitors never receive those closures.
function __compiledValueEvents(sink,limits){
 const methods=['begin','end','byte','word','wide','text','count'];
 for(const name of methods)if(typeof sink?.[name]!=='function')throw Error('compiled value visitor method: '+name);
 const budget=createValueCaptureBudget(limits);let depth=0,closed=false;
 const active=()=>{if(closed)throw Error('compiled value visitor is closed');};
 const writer=Object.freeze({
  openFrame(){active();budget.enter(depth,4);depth++;sink.begin();return 0;}
  ,closeFrame(){active();if(depth===0)throw Error('wire frame boundary');try{sink.end();}finally{depth--;}}
  ,frame(emit){active();budget.enter(depth,4);depth++;sink.begin();try{emit();sink.end();}finally{depth--;}}
  ,byte(value){active();budget.add(1);sink.byte(value);}
  ,word(value){active();budget.add(4);sink.word(value);}
  ,wide(value){active();budget.add(8);sink.wide(value);}
  ,text(value){active();budget.text(value);sink.text(value);}
  ,count(value){active();budget.add(4);if(value>budget.remaining)throw Error('wire sequence size');sink.count(value);}
 });
 return {writer,close(){closed=true;}};
}
function __compiledReduction(factory,root,reduce,identity){
 if(typeof factory!=='function')throw Error('compiled reduction factory');
 const reducers=[],seen=new Set(),nodes=__reductionNodes();
 const prepare=index=>{
  if(seen.has(index))return;seen.add(index);
  const node=nodes[index];
  for(const child of node.children)prepare(child);
  const reducer=factory(node,index);
  if(node.kind==='list'||node.kind==='vector'){
   const start=reducer?.start,step=reducer?.step,finish=reducer?.finish;
   if(typeof start!=='function'||typeof step!=='function'||typeof finish!=='function')throw Error('compiled collection reduction');
   reducers[index]=Object.freeze({start,step,finish});
  }else{
   if(typeof reducer!=='function')throw Error('compiled value reduction');
   reducers[index]=reducer;
  }
 };
 prepare(root);Object.freeze(reducers);
 return Object.freeze(function(handle,context,limits={}){
  const value=__compiledUnwrap(handle,identity),budget=createValueCaptureBudget(limits);
  return reduce(value,reducers,budget,0,context);
 });
}
function __compiledCodec(schema,capture,read,write,copy,constructorRoot,reductionRoot,reduce,portableFused=false,compactFused=false){
 const privateCodec=createCompiledValueCodec(schema,read),publicCodec=privateCodec;
 let fusedCodec;const fused=()=>fusedCodec??=createFusedValueCodec(schema,read);
 const identity=schema.identity;
 const codec=Object.freeze({
  identity,
  descriptor:publicCodec.descriptor,
  resolve(type){return publicCodec.resolve(type);},
  capture(value,limits={}){
   return __compiledHandle(identity,capture(value,createValueCaptureBudget(limits),0));
  },
  decode(bytes,limits={}){return __compiledHandle(identity,(portableFused?fused():privateCodec).decode(bytes,limits));},
  decodeCompact(bytes,limits={}){return __compiledHandle(identity,(compactFused?fused():privateCodec).compact().decode(bytes,limits));},
  decodeFused(bytes,limits={}){return __compiledHandle(identity,fused().decode(bytes,limits));},
  decodeCompactFused(bytes,limits={}){return __compiledHandle(identity,fused().compact().decode(bytes,limits));},
  encode(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.encodeWith(writer=>write(writer,value,false),limits);},
  encodeCompact(handle,limits={}){const value=__compiledUnwrap(handle,identity);return publicCodec.compact().encodeWith(writer=>write(writer,value,true),limits);},
  materialize(handle,limits={}){return copy(__compiledUnwrap(handle,identity),createValueCaptureBudget(limits),0);},
  builder(limits={}){return __valueBuilder(__constructorNodes(),constructorRoot,identity,limits);},
  reducer(factory){return __compiledReduction(factory,reductionRoot,reduce,identity);},
  visit(handle,sink,limits={}){
   const value=__compiledUnwrap(handle,identity),events=__compiledValueEvents(sink,limits);
   try{write(events.writer,value,false);}finally{events.close();}
  },
 });
 __compiledBindings.set(codec,{publicCodec,write,capture});return codec;
}

function __compiledEncodeResult(entry,value,limits,compact){
 const {publicCodec,write}=__compiledBindings.get(entry.result());
 return (compact?publicCodec.compact():publicCodec).encodeWith(writer=>write(writer,value,compact),limits);
}
let __constructorNodesValue;function __constructorNodes(){return __constructorNodesValue??=[{kind:'record',fields:["value","first","second","first_power","second_power","steps"],patterns:[{bytes:4,label:"record",children:[1,1,1,1,1,2],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["first"]:values[1],["second"]:values[2],["first_power"]:values[3],["second_power"]:values[4],["steps"]:values[5]})}]},{kind:"f32",scalar:__privateCapture1},{kind:"u32",scalar:__privateCapture2},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[0],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[1],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[2],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["rate","first_decay","second_decay","epsilon"],patterns:[{bytes:4,label:"record",children:[1,1,1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["rate"]:values[0],["first_decay"]:values[1],["second_decay"]:values[2],["epsilon"]:values[3]})}]},{kind:"bool",scalar:__privateCapture7},{kind:"f64",scalar:__privateCapture8},{kind:'record',fields:["value","tangent"],patterns:[{bytes:4,label:"record",children:[1,1],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["tangent"]:values[1]})}]},{kind:'record',fields:["value","first","second","first_power","second_power","steps"],patterns:[{bytes:4,label:"record",children:[9,9,9,9,9,2],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["first"]:values[1],["second"]:values[2],["first_power"]:values[3],["second_power"]:values[4],["steps"]:values[5]})}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[10],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:"list",patterns:[{bytes:8,label:"sequence",children:[9],childDepth:1,sequence:true,charge:(budget,depth)=>{budget.enter(depth,8);},make:values=>(values)}]},{kind:'record',fields:["value","tangent"],patterns:[{bytes:4,label:"record",children:[8,8],childDepth:1,charge:(budget,depth)=>{budget.enter(depth,4);},make:values=>({["value"]:values[0],["tangent"]:values[1]})}]}];}
// Typed input construction only: plans contain literal constructor/capture
// functions emitted from source schemas. No source expression evaluator.
// All frames and private values remain in this closure; callers receive only
// an owned opaque handle after one complete, well-typed root is constructed.
const __constructorPaths=new WeakMap();
function __valueBuilder(nodes,root,identity,limits){
 const budget=createValueCaptureBudget(limits),frames=[];
 let result,targetNode,targetDepth,complete=false,closed=false,failed=false,busy=false;
 const fail=message=>{failed=true;frames.length=0;result=undefined;throw Error(message);};
 const active=()=>{if(failed||closed)throw Error('value builder is closed');};
 const expected=()=>{
  if(!frames.length){if(complete)fail('value builder root already complete');targetNode=root;targetDepth=0;return;}
  const frame=frames.at(-1),position=frame.values.length;
  if(!frame.pattern.sequence&&position>=frame.pattern.children.length)fail('value builder constructor is full');
  targetNode=frame.pattern.sequence?frame.pattern.children[0]:frame.pattern.children[position];targetDepth=frame.depth+frame.pattern.childDepth;
 };
 const accept=value=>{
  if(frames.length)frames.at(-1).values.push(value);
  else{result=value;complete=true;}
 };
 const execute=(operation,first,second)=>{
  active();if(busy)throw Error('value builder operation already active');busy=true;
  try{return operation(first,second);}catch(error){failed=true;frames.length=0;result=undefined;throw error;}finally{busy=false;}
 };
 // Compile and cache constructor paths independently of the session's values.
 const pathPlan=(choices,startNode,startDepth)=>{
   if(!Array.isArray(choices)||choices.length===0||choices.length>128)fail('invalid value builder path');
   let cache=__constructorPaths.get(nodes);if(!cache){cache=new WeakMap();__constructorPaths.set(nodes,cache);}
   let entries=cache.get(choices),saved=entries?.get(startNode);
   if(saved)return saved;
   const path=[],charges=[];let node=startNode,depth=startDepth;
   for(let i=0;i<choices.length;i++){
    const choice=choices[i],patterns=nodes[node].patterns;
    if(!Number.isSafeInteger(choice)||choice<0||!patterns||choice>=patterns.length)fail('invalid value builder constructor');
    const pattern=patterns[choice];charges.push([pattern,depth-startDepth]);path.push({pattern,node:nodes[node]});
    if(i+1<choices.length){if(pattern.sequence||pattern.children.length!==1)fail('value builder path is not unary');node=pattern.children[0];depth+=pattern.childDepth;}
   }
   const terminal=path.at(-1).pattern;
   // Compose literal constructor functions once per path, instead of
   // allocating and interpreting another recursive closure for every value.
   const compose=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=args=>args[0];
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=args=>p.make([inner(args)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?compose(last+1):args=>args[0]):compose(last);
     return args=>node.flat(index,payload(args));
    }
    const inner=at+1<path.length?compose(at+1):null;
    if(pattern.transparent)return inner??(args=>args[0]);
    return inner?args=>pattern.make([inner(args)]):pattern.make;
   };
   const make=compose(0);
   // Scalar paths use the same literal constructors, but pass the leaf
   // directly through erased records and flat sums. No temporary argument
   // array is needed at those edges. Ordinary constructors keep their array
   // calling convention; no private value reaches the public builder API.
   const composeScalar=at=>{
    const {pattern,node}=path[at];
    if(node.flat){
     let index=0,last=at;
     while(last<path.length&&path[last].node.kind==='result'){
      if(path[last].pattern.sumBranch===0)break;
      index++;last++;
     }
     if(last===path.length){
      let make=value=>value;
      for(let i=path.length-1;i>=at;i--){const inner=make,p=path[i].pattern;make=value=>p.make([inner(value)]);}
      return make;
     }
     const payload=path[last].node.kind==='result'?(last+1<path.length?composeScalar(last+1):value=>value):composeScalar(last);
     return value=>node.flat(index,payload(value));
    }
    const inner=at+1<path.length?composeScalar(at+1):null;
    if(pattern.transparent)return inner??(value=>value);
    return inner?value=>pattern.make([inner(value)]):value=>pattern.make([value]);
   };
   const scalar=composeScalar(0);
   const pattern={...terminal,make};
   // Only frozen arrays of ordinary data properties can key reusable plans.
   // Mutable arrays and frozen accessor arrays retain checked per-call paths.
   const fixed=charges.every(([p])=>Number.isSafeInteger(p.bytes)&&p.bytes>=4);
   const plan={pattern,scalar,charges,offset:depth-startDepth,bytes:fixed?charges.reduce((n,[p])=>n+p.bytes,0):null};
   let reusable=Object.isFrozen(choices);
   for(let i=0;reusable&&i<choices.length;i++){const field=Object.getOwnPropertyDescriptor(choices,String(i));reusable=!!field&&Object.hasOwn(field,'value');}
   if(reusable){
    if(!entries){entries=new Map();cache.set(choices,entries);}entries.set(startNode,plan);
   }
   return plan;
 };
 const chargePath=(plan,depth)=>{
  // Each emitted constructor consumes one node and a fixed frame/tag cost.
  // Only take the combined charge when every original check would succeed.
  // Replaying the original order retains the exact first failure otherwise.
  if(plan.bytes!==null&&depth+plan.offset<=budget.depth&&plan.charges.length<=budget.remaining&&budget.bytes+plan.bytes<=budget.limit){
   budget.remaining-=plan.charges.length;budget.bytes+=plan.bytes;return;
  }
  for(const [pattern,offset]of plan.charges)pattern.charge(budget,depth+offset);
 };
 // Operations are allocated once per session, and share expected-node
 // scratch only while the existing reentrancy guard is held.
 const openOperation=(choice)=>{
   expected();const node=nodes[targetNode];
   if(!Number.isSafeInteger(choice)||choice<0||!node.patterns||choice>=node.patterns.length)fail('invalid value builder constructor');
   const pattern=node.patterns[choice];pattern.charge(budget,targetDepth);
   frames.push({pattern,depth:targetDepth,values:[]});
 };
 const openPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth);
   chargePath(plan,targetDepth);
   frames.push({pattern:plan.pattern,depth:targetDepth+plan.offset,values:[]});
 };
 const scalarPathOperation=(choices,value)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==1)fail('value builder path has no scalar leaf');
   const capture=nodes[pattern.children[0]].scalar;
   if(typeof capture!=='function')fail('value builder path has no scalar leaf');
   chargePath(plan,targetDepth);
   const leaf=capture(value,budget,targetDepth+plan.offset+pattern.childDepth);
   accept(plan.scalar(leaf));
 };
 const emptyPathOperation=(choices)=>{
   expected();const plan=pathPlan(choices,targetNode,targetDepth),pattern=plan.pattern;
   if(pattern.sequence||pattern.children.length!==0)fail('value builder path is not empty');
   chargePath(plan,targetDepth);accept(pattern.make([]));
 };
 const scalarOperation=(value)=>{
   expected();const capture=nodes[targetNode].scalar;
   if(typeof capture!=='function')fail('value builder expects a constructor');
   accept(capture(value,budget,targetDepth));
 };
 const closeOperation=()=>{
   if(!frames.length)fail('value builder has no open constructor');
   const frame=frames.at(-1),pattern=frame.pattern,count=frame.values.length;
   if(!pattern.sequence&&count!==pattern.children.length||pattern.size!==undefined&&count!==pattern.size)fail('value builder constructor arity');
   if(pattern.sequence&&count>budget.limit)fail('wire sequence size');
   const value=pattern.make(frame.values);
   frames.pop();accept(value);
 };
 const finishOperation=()=>{
   if(frames.length||!complete)fail('value builder root is incomplete');
   closed=true;const handle=__compiledHandle(identity,result);result=undefined;return handle;
 };
 const api=Object.freeze({
  open(choice){return execute(openOperation,choice);},
  // Charge every source constructor even when unary paths share one frame.
  openPath(choices){return execute(openPathOperation,choices);},
  // Complete the path and leaf without intermediate session frames.
  scalarPath(choices,value){return execute(scalarPathOperation,choices,value);},
  emptyPath(choices){return execute(emptyPathOperation,choices);},
  scalar(value){return execute(scalarOperation,value);},
  close(){return execute(closeOperation);},
  finish(){return execute(finishOperation);},
  abort(){if(busy)throw Error('value builder operation already active');failed=true;frames.length=0;result=undefined;},
 });
 return api;
}
function __reduceValue0(value,r,b,d,c){b.enter(d,4);return r[0](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue1(value["first"],r,b,d+1,c),__reduceValue1(value["second"],r,b,d+1,c),__reduceValue1(value["first_power"],r,b,d+1,c),__reduceValue1(value["second_power"],r,b,d+1,c),__reduceValue2(value["steps"],r,b,d+1,c),c);}
function __reduceValue1(value,r,b,d,c){b.enter(d,8);return r[1]({F32Bits:__nfBits(value)},c);}
function __reduceValue2(value,r,b,d,c){b.enter(d,8);return r[2](value,c);}
function __reduceValue3(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[3];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue0(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue4(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[4];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue1(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue5(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[5];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue2(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue6(value,r,b,d,c){b.enter(d,4);return r[6](__reduceValue1(value["rate"],r,b,d+1,c),__reduceValue1(value["first_decay"],r,b,d+1,c),__reduceValue1(value["second_decay"],r,b,d+1,c),__reduceValue1(value["epsilon"],r,b,d+1,c),c);}
function __reduceValue7(value,r,b,d,c){b.enter(d,5);return r[7](value,c);}
function __reduceValue8(value,r,b,d,c){b.enter(d,12);return r[8]({F64Bits:__dfBits(value).toString()},c);}
function __reduceValue9(value,r,b,d,c){b.enter(d,4);return r[9](__reduceValue1(value["value"],r,b,d+1,c),__reduceValue1(value["tangent"],r,b,d+1,c),c);}
function __reduceValue10(value,r,b,d,c){b.enter(d,4);return r[10](__reduceValue9(value["value"],r,b,d+1,c),__reduceValue9(value["first"],r,b,d+1,c),__reduceValue9(value["second"],r,b,d+1,c),__reduceValue9(value["first_power"],r,b,d+1,c),__reduceValue9(value["second_power"],r,b,d+1,c),__reduceValue2(value["steps"],r,b,d+1,c),c);}
function __reduceValue11(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[11];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue10(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue12(value,r,b,d,c){b.enter(d,8);const n=value.length;if(n>b.remaining)throw Error('wire sequence size');const a=r[12];let out=a.start(n,c);for(let i=0;i<n;i++)out=a.step(out,__reduceValue9(value[i],r,b,d+1,c),i,c);return a.finish(out,c);}
function __reduceValue13(value,r,b,d,c){b.enter(d,4);return r[13](__reduceValue8(value["value"],r,b,d+1,c),__reduceValue8(value["tangent"],r,b,d+1,c),c);}
let __reductionNodeCache;function __reductionNodes(){return __reductionNodeCache??=Object.freeze([Object.freeze({"children":Object.freeze([1,1,1,1,1,2]),"fields":Object.freeze(["value","first","second","first_power","second_power","steps"]),"kind":"record","name":"Parameter"}),Object.freeze({"children":Object.freeze([]),"kind":"f32"}),Object.freeze({"children":Object.freeze([]),"kind":"u32"}),Object.freeze({"children":Object.freeze([0]),"kind":"list"}),Object.freeze({"children":Object.freeze([1]),"kind":"list"}),Object.freeze({"children":Object.freeze([2]),"kind":"list"}),Object.freeze({"children":Object.freeze([1,1,1,1]),"fields":Object.freeze(["rate","first_decay","second_decay","epsilon"]),"kind":"record","name":"Config"}),Object.freeze({"children":Object.freeze([]),"kind":"bool"}),Object.freeze({"children":Object.freeze([]),"kind":"f64"}),Object.freeze({"children":Object.freeze([1,1]),"fields":Object.freeze(["value","tangent"]),"kind":"record","name":"__ink_differential_0"}),Object.freeze({"children":Object.freeze([9,9,9,9,9,2]),"fields":Object.freeze(["value","first","second","first_power","second_power","steps"]),"kind":"record","name":"__ink_differential_3"}),Object.freeze({"children":Object.freeze([10]),"kind":"list"}),Object.freeze({"children":Object.freeze([9]),"kind":"list"}),Object.freeze({"children":Object.freeze([8,8]),"fields":Object.freeze(["value","tangent"]),"kind":"record","name":"__ink_differential64_0"})]);}
function __compiledNamed0(){return {};}
let __compiledCodec0Value;function __compiledCodec0(){return __compiledCodec0Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"7cd0db7bd067c6137d0451073ecc71755d81ac9dbc8526c5cda3a6cf0de894c3","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"}},__privateCapture0,__privateWireValue0,__privateWireWrite0,__compiledOwnedValue0,0,0,__reduceValue0,false,false);}
let __compiledCodec1Value;function __compiledCodec1(){return __compiledCodec1Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fde3b27ba939906c22dbea906c407580e89648dd4d5a55c4f4001e45157ebe45","named":__compiledNamed0(),"root":{"kind":"f32"}},__privateCapture1,__privateWireValue1,__privateWireWrite1,__compiledOwnedValue1,1,1,__reduceValue1,false,false);}
let __compiledCodec2Value;function __compiledCodec2(){return __compiledCodec2Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"51f75af7953a9d922f9ada927ffd8d0c8c476597ed69294f0a0425f75b052cff","named":__compiledNamed0(),"root":{"kind":"u32"}},__privateCapture2,__privateWireValue2,__privateWireWrite2,__compiledOwnedValue2,2,2,__reduceValue2,false,false);}
let __compiledCodec3Value;function __compiledCodec3(){return __compiledCodec3Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"7e4dba74ea4a212e87b655db607b4b675c6150a5e6af015142def3ed7d7aa96c","named":__compiledNamed0(),"root":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"first","type":{"kind":"f32"}},{"name":"second","type":{"kind":"f32"}},{"name":"first_power","type":{"kind":"f32"}},{"name":"second_power","type":{"kind":"f32"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"Parameter"},"kind":"list"}},__privateCapture3,__privateWireValue4,__privateWireWrite3,__compiledOwnedValue3,3,3,__reduceValue3,false,false);}
let __compiledCodec4Value;function __compiledCodec4(){return __compiledCodec4Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"0cbb9d1ff6b72318080ea11a6297b384d97178624f821e3901cca51ec8ad4477","named":__compiledNamed0(),"root":{"element":{"kind":"f32"},"kind":"list"}},__privateCapture4,__privateWireValue7,__privateWireWrite4,__compiledOwnedValue4,4,4,__reduceValue4,false,false);}
let __compiledCodec5Value;function __compiledCodec5(){return __compiledCodec5Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"69ebf947aa59a2546656d1976b0baa6e56e7182d989425379b31e3bff74168ca","named":__compiledNamed0(),"root":{"element":{"kind":"u32"},"kind":"list"}},__privateCapture5,__privateWireValue14,__privateWireWrite5,__compiledOwnedValue5,5,5,__reduceValue5,false,false);}
let __compiledCodec6Value;function __compiledCodec6(){return __compiledCodec6Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"5c8fe4541f6e6c7176cad3a2fe6f317eae7cccf5413e86bb30ef5fa039ae35ca","named":__compiledNamed0(),"root":{"fields":[{"name":"rate","type":{"kind":"f32"}},{"name":"first_decay","type":{"kind":"f32"}},{"name":"second_decay","type":{"kind":"f32"}},{"name":"epsilon","type":{"kind":"f32"}}],"kind":"record","name":"Config"}},__privateCapture6,__privateWireValue16,__privateWireWrite6,__compiledOwnedValue6,6,6,__reduceValue6,false,false);}
let __compiledCodec7Value;function __compiledCodec7(){return __compiledCodec7Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"32f3d3b2f14a1a5d5ed940c0f1126e8a0b1b1f76ff20ac48fac23528d7033176","named":__compiledNamed0(),"root":{"kind":"bool"}},__privateCapture7,__privateWireValue18,__privateWireWrite7,__compiledOwnedValue7,7,7,__reduceValue7,false,false);}
let __compiledCodec8Value;function __compiledCodec8(){return __compiledCodec8Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"081b7ebb8399381d2b15563997bcd9e2a9bfe2aa069502c6663cbda217b039d2","named":__compiledNamed0(),"root":{"kind":"f64"}},__privateCapture8,__privateWireValue22,__privateWireWrite8,__compiledOwnedValue8,8,8,__reduceValue8,false,false);}
let __compiledCodec9Value;function __compiledCodec9(){return __compiledCodec9Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"fb1465d2bf2aae832dbd68a166c25f4a18b427453a0bc64ba5fad98fda8334f2","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},__privateCapture9,__privateWireValue24,__privateWireWrite9,__compiledOwnedValue9,9,9,__reduceValue9,false,false);}
let __compiledCodec10Value;function __compiledCodec10(){return __compiledCodec10Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"bb1fd39ad8ae6c174bdc7c93bf326cea4848e5d07efb08ff6da1bad448ba9329","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"}},__privateCapture10,__privateWireValue27,__privateWireWrite10,__compiledOwnedValue10,10,10,__reduceValue10,false,false);}
let __compiledCodec11Value;function __compiledCodec11(){return __compiledCodec11Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"c686b1c555370cd2072b8991eb3bd930522c291627d0145fea1087bcba45e9f3","named":__compiledNamed0(),"root":{"element":{"fields":[{"name":"value","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"first_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"second_power","type":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"}},{"name":"steps","type":{"kind":"u32"}}],"kind":"record","name":"__ink_differential_3"},"kind":"list"}},__privateCapture11,__privateWireValue28,__privateWireWrite11,__compiledOwnedValue11,11,11,__reduceValue11,false,false);}
let __compiledCodec12Value;function __compiledCodec12(){return __compiledCodec12Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"cdde982e98b457eca63f0b1f56713939bdd8ddf70f5be35e930642c404861714","named":__compiledNamed0(),"root":{"element":{"fields":[{"name":"value","type":{"kind":"f32"}},{"name":"tangent","type":{"kind":"f32"}}],"kind":"record","name":"__ink_differential_0"},"kind":"list"}},__privateCapture12,__privateWireValue31,__privateWireWrite12,__compiledOwnedValue12,12,12,__reduceValue12,false,false);}
let __compiledCodec13Value;function __compiledCodec13(){return __compiledCodec13Value??=__compiledCodec({"format":"ink-value-wire-v1","identity":"0e35873fe4e2836a793d1cccc5c47875def75fd4336b47c5bfa790354746fbe1","named":__compiledNamed0(),"root":{"fields":[{"name":"value","type":{"kind":"f64"}},{"name":"tangent","type":{"kind":"f64"}}],"kind":"record","name":"__ink_differential64_0"}},__privateCapture13,__privateWireValue40,__privateWireWrite13,__compiledOwnedValue13,13,13,__reduceValue13,false,false);}
const __compiledEntries=new Map([["empty_parameter",{index:0,params:[],result:__compiledCodec0,arguments:__privateWireValue3,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[],precondition:null}],["parameter",{index:1,params:[__compiledCodec1,__compiledCodec2,__compiledCodec3,__compiledCodec2],result:__compiledCodec1,arguments:__privateWireValue5,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["reglu",{index:2,params:[__compiledCodec1,__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue6,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["dot10",{index:3,params:[__compiledCodec1,__compiledCodec2,__compiledCodec3,__compiledCodec4,__compiledCodec2,__compiledCodec2],result:__compiledCodec1,arguments:__privateWireValue8,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false,false],precondition:null}],["dot6",{index:4,params:[__compiledCodec1,__compiledCodec2,__compiledCodec3,__compiledCodec4,__compiledCodec2],result:__compiledCodec1,arguments:__privateWireValue9,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false],precondition:null}],["first_layer",{index:5,params:[__compiledCodec1,__compiledCodec2,__compiledCodec3,__compiledCodec4,__compiledCodec2],result:__compiledCodec4,arguments:__privateWireValue10,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false],precondition:null}],["second_layer",{index:6,params:[__compiledCodec1,__compiledCodec2,__compiledCodec3,__compiledCodec4],result:__compiledCodec4,arguments:__privateWireValue11,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["outputs",{index:7,params:[__compiledCodec1,__compiledCodec2,__compiledCodec3,__compiledCodec4,__compiledCodec2],result:__compiledCodec4,arguments:__privateWireValue10,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false],precondition:null}],["squared_error",{index:8,params:[__compiledCodec1,__compiledCodec1],result:__compiledCodec1,arguments:__privateWireValue12,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["objective",{index:9,params:[__compiledCodec1,__compiledCodec2,__compiledCodec3,__compiledCodec4,__compiledCodec4,__compiledCodec2],result:__compiledCodec1,arguments:__privateWireValue13,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false,false],precondition:null}],["gradients",{index:10,params:[__compiledCodec3,__compiledCodec4,__compiledCodec4,__compiledCodec5],result:__compiledCodec4,arguments:__privateWireValue15,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["candidate",{index:11,params:[__compiledCodec0,__compiledCodec1,__compiledCodec6],result:__compiledCodec0,arguments:__privateWireValue17,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false],precondition:null}],["valid",{index:12,params:[__compiledCodec0],result:__compiledCodec7,arguments:__privateWireValue19,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["configuration",{index:13,params:[__compiledCodec6],result:__compiledCodec7,arguments:__privateWireValue20,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["shape",{index:14,params:[__compiledCodec3,__compiledCodec4,__compiledCodec4,__compiledCodec5],result:__compiledCodec7,arguments:__privateWireValue15,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["update",{index:15,params:[__compiledCodec3,__compiledCodec4,__compiledCodec7,__compiledCodec6],result:__compiledCodec3,arguments:__privateWireValue21,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["losses",{index:16,params:[__compiledCodec3,__compiledCodec4,__compiledCodec4,__compiledCodec5],result:__compiledCodec4,arguments:__privateWireValue15,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["precise_square",{index:17,params:[__compiledCodec8],result:__compiledCodec8,arguments:__privateWireValue23,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["precise_gradient",{index:18,params:[__compiledCodec8],result:__compiledCodec8,arguments:__privateWireValue23,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["__ink_differential_7",{index:19,params:[__compiledCodec9,__compiledCodec9],result:__compiledCodec9,arguments:__privateWireValue25,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_6",{index:20,params:[__compiledCodec9,__compiledCodec9],result:__compiledCodec9,arguments:__privateWireValue26,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_13",{index:21,params:[],result:__compiledCodec10,arguments:__privateWireValue3,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[],precondition:null}],["__ink_differential_12",{index:22,params:[__compiledCodec9,__compiledCodec2,__compiledCodec11,__compiledCodec2],result:__compiledCodec9,arguments:__privateWireValue29,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["__ink_differential_14",{index:23,params:[__compiledCodec9,__compiledCodec9],result:__compiledCodec9,arguments:__privateWireValue30,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_11",{index:24,params:[__compiledCodec9,__compiledCodec2,__compiledCodec11,__compiledCodec12,__compiledCodec2,__compiledCodec2],result:__compiledCodec9,arguments:__privateWireValue32,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false,false],precondition:null}],["__ink_differential_5",{index:25,params:[__compiledCodec9,__compiledCodec2,__compiledCodec11,__compiledCodec12,__compiledCodec2],result:__compiledCodec12,arguments:__privateWireValue33,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false],precondition:null}],["__ink_differential_19",{index:26,params:[__compiledCodec9,__compiledCodec2,__compiledCodec11,__compiledCodec12,__compiledCodec2],result:__compiledCodec9,arguments:__privateWireValue34,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false],precondition:null}],["__ink_differential_18",{index:27,params:[__compiledCodec9,__compiledCodec2,__compiledCodec11,__compiledCodec12],result:__compiledCodec12,arguments:__privateWireValue35,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false],precondition:null}],["__ink_differential_4",{index:28,params:[__compiledCodec9,__compiledCodec2,__compiledCodec11,__compiledCodec12,__compiledCodec2],result:__compiledCodec12,arguments:__privateWireValue33,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false],precondition:null}],["__ink_differential_21",{index:29,params:[__compiledCodec9,__compiledCodec9],result:__compiledCodec9,arguments:__privateWireValue36,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_20",{index:30,params:[__compiledCodec9,__compiledCodec9],result:__compiledCodec9,arguments:__privateWireValue37,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_25",{index:31,params:[__compiledCodec9,__compiledCodec9],result:__compiledCodec9,arguments:__privateWireValue38,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential_2",{index:32,params:[__compiledCodec9,__compiledCodec2,__compiledCodec11,__compiledCodec12,__compiledCodec12,__compiledCodec2],result:__compiledCodec9,arguments:__privateWireValue39,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false,false],precondition:null}],["__ink_differential_1",{index:33,params:[__compiledCodec1,__compiledCodec2,__compiledCodec3,__compiledCodec4,__compiledCodec4,__compiledCodec2],result:__compiledCodec1,arguments:__privateWireValue13,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false,false,false,false,false],precondition:null}],["__ink_differential64_3",{index:34,params:[__compiledCodec13,__compiledCodec13],result:__compiledCodec13,arguments:__privateWireValue41,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false,false],precondition:null}],["__ink_differential64_2",{index:35,params:[__compiledCodec13],result:__compiledCodec13,arguments:__privateWireValue42,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}],["__ink_differential64_1",{index:36,params:[__compiledCodec8],result:__compiledCodec8,arguments:__privateWireValue23,argumentCodecs:[null,null],boundaryReaders:[false,false],onlyTypeGuards:false,needsInvariants:[false],precondition:null}]]);

export const compiledValues=Object.freeze(Object.fromEntries([...__compiledEntries].map(([name,entry])=>[name,Object.freeze({get params(){return Object.freeze(entry.params.map(codec=>codec()));},get result(){return entry.result();}})])));
function __compiledValidate(entry,owned){
 const values=owned.map(v=>v.value);
 const established=entry.onlyTypeGuards&&entry.needsInvariants.every((needed,i)=>!needed||owned[i].guaranteed);
 if(entry.precondition!==null&&!established){
  if(__implementations[entry.precondition](...values)!==true)throw Error('contract precondition failed');
  for(let i=0;i<owned.length;i++)if(entry.needsInvariants[i])owned[i].guaranteed=true;
 }
 return values;
}
export function callCompiled(name,args){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(args)||args.length!==entry.params.length)throw Error('unsupported compiled call');
 const owned=entry.params.map((codec,i)=>__compiledEntry(args[i],codec().identity)),values=__compiledValidate(entry,owned);
 // Checked source outputs satisfy their declared value interfaces. Private
 // handles expose only detached copies and never retain mutable host inputs.
 return __compiledHandle(entry.result().identity,__implementations[entry.index](...values),true);
}

// Explicit sealed-value partial application. Each token owns a bounded set of
// lexical caches; no mutable host object, global memo table or error is retained.
const __preparedCompiled=new WeakMap();
export function prepareCompiled(name,bindings){
 const entry=__compiledEntries.get(name);
 if(!entry||!Array.isArray(bindings)||bindings.length>entry.params.length)throw Error('unsupported prepared compiled call');
 const captured=new Array(entry.params.length),fixed=new Array(entry.params.length).fill(false);
 for(const binding of bindings){
  if(!Array.isArray(binding)||binding.length!==2)throw Error('prepared compiled binding');
  const [index,handle]=binding;
  if(!Number.isInteger(index)||index<0||index>=fixed.length||fixed[index])throw Error('prepared compiled parameter');
  captured[index]=__compiledEntry(handle,entry.params[index]().identity);fixed[index]=true;
 }
 const remaining=fixed.flatMap((yes,i)=>yes?[]:[i]);
 const factory=__preparedFactories.get(entry.index);
 const run=factory?factory(fixed):__implementations[entry.index];
 const token=Object.freeze(Object.create(null));
 __preparedCompiled.set(token,{entry,captured,remaining,run});return token;
}
export function callPreparedCompiled(token,args){
 const prepared=__preparedCompiled.get(token);
 if(!prepared||!Array.isArray(args)||args.length!==prepared.remaining.length)throw Error('invalid prepared compiled call');
 const {entry,captured,remaining,run}=prepared,owned=captured.slice();
 for(let i=0;i<remaining.length;i++){const at=remaining[i];owned[at]=__compiledEntry(args[i],entry.params[at]().identity);}
 const values=__compiledValidate(entry,owned);
 return __compiledHandle(entry.result().identity,run(...values),true);
}
const __intoOutput5=__representation(metadata.functions[5].result.element,true);
const __intoOutput6=__representation(metadata.functions[6].result.element,true);
const __intoOutput7=__representation(metadata.functions[7].result.element,true);
const __intoOutput10=__representation(metadata.functions[10].result.element,true);
const __intoOutput15=__representation(metadata.functions[15].result.element,true);
const __intoOutput16=__representation(metadata.functions[16].result.element,true);
const __intoOutput25=__representation(metadata.functions[25].result.element,true);
const __intoOutput27=__representation(metadata.functions[27].result.element,true);
const __intoOutput28=__representation(metadata.functions[28].result.element,true);
const __intoImplementations=[null,null,null,null,null,__into5,__into6,__into7,null,null,__into10,null,null,null,null,__into15,__into16,null,null,null,null,null,null,null,null,__into25,null,__into27,__into28,null,null,null,null,null,null,null,null];

export const functionsInto=Object.freeze(Object.fromEntries(metadata.functions.filter(f=>!f.internal&&f.result.kind==='list').map(f=>{
  const input=__inputTypes[f.index].types.map((t,i)=>__representation(t,false,__inputTypes[f.index].capture[i]));
  const body=__intoImplementations[f.index];
  const implementation=f.precondition==null?body:(...args)=>{if(__implementations[f.precondition](...args.slice(0,f.params.length))!==true)throw Error('contract precondition failed');return body(...args);};
  const entry=input.every(c=>c===__identity)?implementation:(...values)=>{const context=new WeakMap();return implementation(...input.map((convert,i)=>convert(values[i],context)),values[f.params.length]);};
  return [f.name,entry];
})));
export function callInto(name,args,destination){return functionsInto[name](...args,destination);}

function __preparedPart(mask,path){
 for(const field of path){
  if(mask===true)return true;
  if(!mask || typeof mask!=="object")return false;
  mask=Object.hasOwn(mask.fields,field)?mask.fields[field]:false;
 }
 return mask;
}
function __preparedStable(mask,path){const part=__preparedPart(mask,path);return part===true || (!!part && part.all===true);}
function __prepareFn3(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[5],[]))))return __fn3;const v1901=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[5],[]);
let v1900=false,v1899;
return function(v1892,v1893,v1894,v1895,v1896,v1897){v1892=__nfValue(v1892);
let v1898;if(v1901&&v1900){v1898=v1899;}else{
const v1902=10;
const v1903=(((v1897) + (v1902)) >>> 0);
v1898=__fn1(v1892,v1893,v1894,v1903);if(v1901){v1899=v1898;v1900=true;}}
let v1904=__nfValue(v1898);
for(let v1905=0;v1905<10;v1905++){
const v1906=(v1905>>>0);
const v1907=v1904;
const v1908=(((v1897) + (v1906)) >>> 0);
const v1909=__fn1(v1892,v1893,v1894,v1908);
const v1910=10;
const v1911=(Math.imul(v1896,v1910) >>> 0);
const v1912=(((v1911) + (v1906)) >>> 0);
let v1913;if(v1912<v1895.length){v1913=v1895[v1912];}else{
v1913=0.0;}
const v1914=__nfValue(v1913);
const v1915=Math.fround(__nfNumber(v1909) * __nfNumber(v1914));
v1904=Math.fround(__nfNumber(v1907) + v1915);}
return v1904;};}
function __prepareFn4(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[4],[]))))return __fn4;const v1924=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[4],[]);
let v1923=false,v1922;
return function(v1916,v1917,v1918,v1919,v1920){v1916=__nfValue(v1916);
let v1921;if(v1924&&v1923){v1921=v1922;}else{
const v1925=6;
const v1926=(((v1920) + (v1925)) >>> 0);
v1921=__fn1(v1916,v1917,v1918,v1926);if(v1924){v1922=v1921;v1923=true;}}
let v1927=__nfValue(v1921);
for(let v1928=0;v1928<6;v1928++){
const v1929=(v1928>>>0);
const v1930=v1927;
const v1931=(((v1920) + (v1929)) >>> 0);
const v1932=__fn1(v1916,v1917,v1918,v1931);
let v1933;if(v1929<v1919.length){v1933=v1919[v1929];}else{
v1933=0.0;}
const v1934=__nfValue(v1933);
const v1935=Math.fround(__nfNumber(v1932) * __nfNumber(v1934));
v1927=Math.fround(__nfNumber(v1930) + v1935);}
return v1927;};}
function __prepareFn5(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn5;const v1944=depth<15&&__preparedFactories.has(3)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v1942;
let v1949;
let v1959;
let v1965;
let v1975;
let v1981;
let v1991;
let v1997;
let v2007;
let v2013;
let v2023;
let v2029;
return function(v1936,v1937,v1938,v1939,v1940){v1936=__nfValue(v1936);
const v1941=0;
let v1945;if(v1944){if(!v1942){const v1943=__preparedFactories.get(3);v1942=v1943([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1945=v1942(v1936,v1937,v1938,v1939,v1940,v1941);}else{v1945=__fn3(v1936,v1937,v1938,v1939,v1940,v1941);}
const v1946=v1945;
const v1948=11;
let v1951;if(v1944){if(!v1949){const v1950=__preparedFactories.get(3);v1949=v1950([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1951=v1949(v1936,v1937,v1938,v1939,v1940,v1948);}else{v1951=__fn3(v1936,v1937,v1938,v1939,v1940,v1948);}
const v1952=v1951;
const v1954=__nfValue(v1946);
const v1955=__nfValue(v1952);
const v1956=__fn2(v1954,v1955);
const v1958=22;
let v1961;if(v1944){if(!v1959){const v1960=__preparedFactories.get(3);v1959=v1960([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1961=v1959(v1936,v1937,v1938,v1939,v1940,v1958);}else{v1961=__fn3(v1936,v1937,v1938,v1939,v1940,v1958);}
const v1962=v1961;
const v1964=33;
let v1967;if(v1944){if(!v1965){const v1966=__preparedFactories.get(3);v1965=v1966([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1967=v1965(v1936,v1937,v1938,v1939,v1940,v1964);}else{v1967=__fn3(v1936,v1937,v1938,v1939,v1940,v1964);}
const v1968=v1967;
const v1970=__nfValue(v1962);
const v1971=__nfValue(v1968);
const v1972=__fn2(v1970,v1971);
const v1974=44;
let v1977;if(v1944){if(!v1975){const v1976=__preparedFactories.get(3);v1975=v1976([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1977=v1975(v1936,v1937,v1938,v1939,v1940,v1974);}else{v1977=__fn3(v1936,v1937,v1938,v1939,v1940,v1974);}
const v1978=v1977;
const v1980=55;
let v1983;if(v1944){if(!v1981){const v1982=__preparedFactories.get(3);v1981=v1982([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1983=v1981(v1936,v1937,v1938,v1939,v1940,v1980);}else{v1983=__fn3(v1936,v1937,v1938,v1939,v1940,v1980);}
const v1984=v1983;
const v1986=__nfValue(v1978);
const v1987=__nfValue(v1984);
const v1988=__fn2(v1986,v1987);
const v1990=66;
let v1993;if(v1944){if(!v1991){const v1992=__preparedFactories.get(3);v1991=v1992([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1993=v1991(v1936,v1937,v1938,v1939,v1940,v1990);}else{v1993=__fn3(v1936,v1937,v1938,v1939,v1940,v1990);}
const v1994=v1993;
const v1996=77;
let v1999;if(v1944){if(!v1997){const v1998=__preparedFactories.get(3);v1997=v1998([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v1999=v1997(v1936,v1937,v1938,v1939,v1940,v1996);}else{v1999=__fn3(v1936,v1937,v1938,v1939,v1940,v1996);}
const v2000=v1999;
const v2002=__nfValue(v1994);
const v2003=__nfValue(v2000);
const v2004=__fn2(v2002,v2003);
const v2006=88;
let v2009;if(v1944){if(!v2007){const v2008=__preparedFactories.get(3);v2007=v2008([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2009=v2007(v1936,v1937,v1938,v1939,v1940,v2006);}else{v2009=__fn3(v1936,v1937,v1938,v1939,v1940,v2006);}
const v2010=v2009;
const v2012=99;
let v2015;if(v1944){if(!v2013){const v2014=__preparedFactories.get(3);v2013=v2014([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2015=v2013(v1936,v1937,v1938,v1939,v1940,v2012);}else{v2015=__fn3(v1936,v1937,v1938,v1939,v1940,v2012);}
const v2016=v2015;
const v2018=__nfValue(v2010);
const v2019=__nfValue(v2016);
const v2020=__fn2(v2018,v2019);
const v2022=110;
let v2025;if(v1944){if(!v2023){const v2024=__preparedFactories.get(3);v2023=v2024([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2025=v2023(v1936,v1937,v1938,v1939,v1940,v2022);}else{v2025=__fn3(v1936,v1937,v1938,v1939,v1940,v2022);}
const v2026=v2025;
const v2028=121;
let v2031;if(v1944){if(!v2029){const v2030=__preparedFactories.get(3);v2029=v2030([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2031=v2029(v1936,v1937,v1938,v1939,v1940,v2028);}else{v2031=__fn3(v1936,v1937,v1938,v1939,v1940,v2028);}
const v2032=v2031;
const v2034=__nfValue(v2026);
const v2035=__nfValue(v2032);
const v2036=__fn2(v2034,v2035);
return [v1956,v1972,v1988,v2004,v2020,v2036];};}
function __prepareFn6(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn6;const v2045=depth<15&&__preparedFactories.has(4)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2043;
let v2050;
let v2060;
let v2066;
let v2076;
let v2082;
let v2092;
let v2098;
let v2108;
let v2114;
let v2124;
let v2130;
return function(v2038,v2039,v2040,v2041){v2038=__nfValue(v2038);
const v2042=132;
let v2046;if(v2045){if(!v2043){const v2044=__preparedFactories.get(4);v2043=v2044([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2046=v2043(v2038,v2039,v2040,v2041,v2042);}else{v2046=__fn4(v2038,v2039,v2040,v2041,v2042);}
const v2047=v2046;
const v2049=139;
let v2052;if(v2045){if(!v2050){const v2051=__preparedFactories.get(4);v2050=v2051([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2052=v2050(v2038,v2039,v2040,v2041,v2049);}else{v2052=__fn4(v2038,v2039,v2040,v2041,v2049);}
const v2053=v2052;
const v2055=__nfValue(v2047);
const v2056=__nfValue(v2053);
const v2057=__fn2(v2055,v2056);
const v2059=146;
let v2062;if(v2045){if(!v2060){const v2061=__preparedFactories.get(4);v2060=v2061([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2062=v2060(v2038,v2039,v2040,v2041,v2059);}else{v2062=__fn4(v2038,v2039,v2040,v2041,v2059);}
const v2063=v2062;
const v2065=153;
let v2068;if(v2045){if(!v2066){const v2067=__preparedFactories.get(4);v2066=v2067([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2068=v2066(v2038,v2039,v2040,v2041,v2065);}else{v2068=__fn4(v2038,v2039,v2040,v2041,v2065);}
const v2069=v2068;
const v2071=__nfValue(v2063);
const v2072=__nfValue(v2069);
const v2073=__fn2(v2071,v2072);
const v2075=160;
let v2078;if(v2045){if(!v2076){const v2077=__preparedFactories.get(4);v2076=v2077([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2078=v2076(v2038,v2039,v2040,v2041,v2075);}else{v2078=__fn4(v2038,v2039,v2040,v2041,v2075);}
const v2079=v2078;
const v2081=167;
let v2084;if(v2045){if(!v2082){const v2083=__preparedFactories.get(4);v2082=v2083([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2084=v2082(v2038,v2039,v2040,v2041,v2081);}else{v2084=__fn4(v2038,v2039,v2040,v2041,v2081);}
const v2085=v2084;
const v2087=__nfValue(v2079);
const v2088=__nfValue(v2085);
const v2089=__fn2(v2087,v2088);
const v2091=174;
let v2094;if(v2045){if(!v2092){const v2093=__preparedFactories.get(4);v2092=v2093([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2094=v2092(v2038,v2039,v2040,v2041,v2091);}else{v2094=__fn4(v2038,v2039,v2040,v2041,v2091);}
const v2095=v2094;
const v2097=181;
let v2100;if(v2045){if(!v2098){const v2099=__preparedFactories.get(4);v2098=v2099([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2100=v2098(v2038,v2039,v2040,v2041,v2097);}else{v2100=__fn4(v2038,v2039,v2040,v2041,v2097);}
const v2101=v2100;
const v2103=__nfValue(v2095);
const v2104=__nfValue(v2101);
const v2105=__fn2(v2103,v2104);
const v2107=188;
let v2110;if(v2045){if(!v2108){const v2109=__preparedFactories.get(4);v2108=v2109([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2110=v2108(v2038,v2039,v2040,v2041,v2107);}else{v2110=__fn4(v2038,v2039,v2040,v2041,v2107);}
const v2111=v2110;
const v2113=195;
let v2116;if(v2045){if(!v2114){const v2115=__preparedFactories.get(4);v2114=v2115([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2116=v2114(v2038,v2039,v2040,v2041,v2113);}else{v2116=__fn4(v2038,v2039,v2040,v2041,v2113);}
const v2117=v2116;
const v2119=__nfValue(v2111);
const v2120=__nfValue(v2117);
const v2121=__fn2(v2119,v2120);
const v2123=202;
let v2126;if(v2045){if(!v2124){const v2125=__preparedFactories.get(4);v2124=v2125([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2126=v2124(v2038,v2039,v2040,v2041,v2123);}else{v2126=__fn4(v2038,v2039,v2040,v2041,v2123);}
const v2127=v2126;
const v2129=209;
let v2132;if(v2045){if(!v2130){const v2131=__preparedFactories.get(4);v2130=v2131([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2132=v2130(v2038,v2039,v2040,v2041,v2129);}else{v2132=__fn4(v2038,v2039,v2040,v2041,v2129);}
const v2133=v2132;
const v2135=__nfValue(v2127);
const v2136=__nfValue(v2133);
const v2137=__fn2(v2135,v2136);
return [v2057,v2073,v2089,v2105,v2121,v2137];};}
function __prepareFn7(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn7;const v2147=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[])&&__preparedStable(fixed[4],[]);
let v2146=false,v2145;
const v2150=depth<15&&__preparedFactories.has(5)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2148;
let v2154=false,v2153;
const v2158=depth<15&&__preparedFactories.has(6)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2156;
const v2164=depth<15&&__preparedFactories.has(4)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2162;
let v2170;
let v2177;
let v2184;
return function(v2139,v2140,v2141,v2142,v2143){v2139=__nfValue(v2139);
let v2144;if(v2147&&v2146){v2144=v2145;}else{
let v2151;if(v2150){if(!v2148){const v2149=__preparedFactories.get(5);v2148=v2149([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4]],depth+1);}v2151=v2148(v2139,v2140,v2141,v2142,v2143);}else{v2151=__fn5(v2139,v2140,v2141,v2142,v2143);}
v2144=v2151;if(v2147){v2145=v2144;v2146=true;}}
let v2152;if(v2147&&v2154){v2152=v2153;}else{
const v2155=v2144;
let v2159;if(v2158){if(!v2156){const v2157=__preparedFactories.get(6);v2156=v2157([fixed[0],fixed[1],fixed[2],v2147],depth+1);}v2159=v2156(v2139,v2140,v2141,v2155);}else{v2159=__fn6(v2139,v2140,v2141,v2155);}
v2152=v2159;if(v2147){v2153=v2152;v2154=true;}}
const v2160=v2152;
const v2161=216;
let v2165;if(v2164){if(!v2162){const v2163=__preparedFactories.get(4);v2162=v2163([fixed[0],fixed[1],fixed[2],v2147,true],depth+1);}v2165=v2162(v2139,v2140,v2141,v2160,v2161);}else{v2165=__fn4(v2139,v2140,v2141,v2160,v2161);}
const v2166=v2165;
const v2168=v2152;
const v2169=223;
let v2172;if(v2164){if(!v2170){const v2171=__preparedFactories.get(4);v2170=v2171([fixed[0],fixed[1],fixed[2],v2147,true],depth+1);}v2172=v2170(v2139,v2140,v2141,v2168,v2169);}else{v2172=__fn4(v2139,v2140,v2141,v2168,v2169);}
const v2173=v2172;
const v2175=v2152;
const v2176=230;
let v2179;if(v2164){if(!v2177){const v2178=__preparedFactories.get(4);v2177=v2178([fixed[0],fixed[1],fixed[2],v2147,true],depth+1);}v2179=v2177(v2139,v2140,v2141,v2175,v2176);}else{v2179=__fn4(v2139,v2140,v2141,v2175,v2176);}
const v2180=v2179;
const v2182=v2152;
const v2183=237;
let v2186;if(v2164){if(!v2184){const v2185=__preparedFactories.get(4);v2184=v2185([fixed[0],fixed[1],fixed[2],v2147,true],depth+1);}v2186=v2184(v2139,v2140,v2141,v2182,v2183);}else{v2186=__fn4(v2139,v2140,v2141,v2182,v2183);}
const v2187=v2186;
const v2189=__nfValue(v2166);
const v2190=__nfValue(v2173);
const v2191=__nfValue(v2180);
const v2192=__nfValue(v2187);
return [v2189,v2190,v2191,v2192];};}
function __prepareFn9(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn9;const v2204=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[])&&__preparedStable(fixed[5],[]);
let v2203=false,v2202;
const v2207=depth<15&&__preparedFactories.has(7)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2205;
return function(v2195,v2196,v2197,v2198,v2199,v2200){v2195=__nfValue(v2195);
let v2201;if(v2204&&v2203){v2201=v2202;}else{
let v2208;if(v2207){if(!v2205){const v2206=__preparedFactories.get(7);v2205=v2206([fixed[0],fixed[1],fixed[2],fixed[3],fixed[5]],depth+1);}v2208=v2205(v2195,v2196,v2197,v2198,v2200);}else{v2208=__fn7(v2195,v2196,v2197,v2198,v2200);}
v2201=v2208;if(v2204){v2202=v2201;v2203=true;}}
let v2210=0.0;
for(let v2211=0;v2211<4;v2211++){
const v2212=(v2211>>>0);
const v2213=v2210;
const v2214=v2201;
let v2215;if(v2212<v2214.length){v2215=v2214[v2212];}else{
v2215=0.0;}
const v2216=__nfValue(v2215);
const v2217=4;
const v2218=(Math.imul(v2200,v2217) >>> 0);
const v2219=(((v2218) + (v2212)) >>> 0);
let v2220;if(v2219<v2199.length){v2220=v2199[v2219];}else{
v2220=0.0;}
const v2221=__nfValue(v2220);
const v2222=__fn8(v2216,v2221);
v2210=Math.fround(__nfNumber(v2213) + __nfNumber(v2222));}
const v2209=v2210;
return Math.fround((__nfNumber(__nfValue(v2209)))/(__nfNumber(4.0)));};}
function __prepareFn15(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[3],[]))))return __fn15;const v2243=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[]);
let v2242=false,v2241;
const v2266=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[3],[]);
let v2265=false,v2264;
let v2275=false,v2274;
return function(v2236,v2237,v2238,v2239){let v2240;if(v2243&&v2242){v2240=v2241;}else{
const v2244=false;
const v2245=(v2238===v2244);
let v2246=v2245;if(!v2246){
const v2247=__fn13(v2239);
const v2248=false;
v2246=(v2247===v2248);}
const v2249=v2246;
let v2250=v2249;if(!v2250){
const v2251=(v2237).length;
const v2252=(v2236).length;
v2250=!(v2251===v2252);}
const v2253=v2250;
let v2254=v2253;if(!v2254){
let v2255=true;
for(let v2256=0;v2256<v2236.length;v2256++){
const v2257=v2236[v2256];
const v2258=v2255;
let v2259=v2258;if(v2259){
v2259=__fn12(v2257);}
v2255=v2259;
}
const v2260=v2255;
const v2261=false;
v2254=(v2260===v2261);}
v2240=v2254;if(v2243){v2241=v2240;v2242=true;}}
let v2262;if(v2240){
v2262=v2236;}else{
let v2263;if(v2266&&v2265){v2263=v2264;}else{
const v2267=[];for(let v2268=0;v2268<v2236.length;v2268++){
const v2269=v2236[v2268];
const v2270=(v2268>>>0);
let v2271;if(v2270<v2237.length){v2271=v2237[v2270];}else{
v2271=0.0;}
const v2272=__nfValue(v2271);
v2267.push(__fn11(v2269,v2272,v2239));}
v2263=v2267;if(v2266){v2264=v2263;v2265=true;}}
let v2273;if(v2266&&v2275){v2273=v2274;}else{
const v2276=v2263;
let v2277=true;
for(let v2278=0;v2278<v2276.length;v2278++){
const v2279=v2276[v2278];
const v2280=v2277;
let v2281=v2280;if(v2281){
v2281=__fn12(v2279);}
v2277=v2281;
}
v2273=v2277;if(v2266){v2274=v2273;v2275=true;}}
let v2282;if(v2273){
v2282=v2263;}else{
v2282=v2236;}
v2262=v2282;}
return v2262;};}
function __prepareFn16(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[]))))return __fn16;const v2294=depth<15&&__preparedFactories.has(9)&&((__preparedStable(fixed[0],[])));
let v2292;
return function(v2283,v2284,v2285,v2286){const v2287=[];for(let v2288=0;v2288<v2286.length;v2288++){
const v2289=(v2286[v2288]>>>0);
const v2290=0.0;
const v2291=4294967295;
let v2295;if(v2294){if(!v2292){const v2293=__preparedFactories.get(9);v2292=v2293([true,true,fixed[0],fixed[1],fixed[2],false],depth+1);}v2295=v2292(v2290,v2291,v2283,v2284,v2285,v2289);}else{v2295=__fn9(v2290,v2291,v2283,v2284,v2285,v2289);}
v2287.push(v2295);}
return v2287;};}
function __prepareFn24(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[5],[]))))return __fn24;const v2317=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[5],[]);
let v2316=false,v2315;
return function(v2308,v2309,v2310,v2311,v2312,v2313){let v2314;if(v2317&&v2316){v2314=v2315;}else{
const v2318=10;
const v2319=(((v2313) + (v2318)) >>> 0);
v2314=__fn22(v2308,v2309,v2310,v2319);if(v2317){v2315=v2314;v2316=true;}}
const v2320=v2314;
let v2321=v2320["value"];
let v2322=v2320["tangent"];
for(let v2324=0;v2324<10;v2324++){
const v2325=(v2324>>>0);
const v2327=(((v2313) + (v2325)) >>> 0);
const v2328=__fn22(v2308,v2309,v2310,v2327);
const v2329=10;
const v2330=(Math.imul(v2312,v2329) >>> 0);
const v2331=(((v2330) + (v2325)) >>> 0);
let v2332;if(v2331<v2311.length){v2332=v2311[v2331];}else{
const v2333=0.0;
const v2334=0.0;
v2332=({["value"]:v2333,["tangent"]:v2334});}
const v2335=v2332;
const v2336=__fn19(v2328,v2335);
const v2337=__nfValue(v2321);
const v2338=__nfValue(v2336["value"]);
const v2339=Math.fround(__nfNumber(v2337) + __nfNumber(v2338));
const v2340=__nfValue(v2322);
const v2341=__nfValue(v2336["tangent"]);
const v2342=Math.fround(__nfNumber(v2340) + __nfNumber(v2341));
v2321=v2339;
v2322=v2342;
}
return ({["value"]:v2321,["tangent"]:v2322});};}
function __prepareFn25(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn25;const v2351=depth<15&&__preparedFactories.has(24)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2349;
let v2356;
let v2364;
let v2370;
let v2378;
let v2384;
let v2392;
let v2398;
let v2406;
let v2412;
let v2420;
let v2426;
return function(v2343,v2344,v2345,v2346,v2347){const v2348=0;
let v2352;if(v2351){if(!v2349){const v2350=__preparedFactories.get(24);v2349=v2350([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2352=v2349(v2343,v2344,v2345,v2346,v2347,v2348);}else{v2352=__fn24(v2343,v2344,v2345,v2346,v2347,v2348);}
const v2353=v2352;
const v2355=11;
let v2358;if(v2351){if(!v2356){const v2357=__preparedFactories.get(24);v2356=v2357([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2358=v2356(v2343,v2344,v2345,v2346,v2347,v2355);}else{v2358=__fn24(v2343,v2344,v2345,v2346,v2347,v2355);}
const v2359=v2358;
const v2361=__fn20(v2353,v2359);
const v2363=22;
let v2366;if(v2351){if(!v2364){const v2365=__preparedFactories.get(24);v2364=v2365([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2366=v2364(v2343,v2344,v2345,v2346,v2347,v2363);}else{v2366=__fn24(v2343,v2344,v2345,v2346,v2347,v2363);}
const v2367=v2366;
const v2369=33;
let v2372;if(v2351){if(!v2370){const v2371=__preparedFactories.get(24);v2370=v2371([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2372=v2370(v2343,v2344,v2345,v2346,v2347,v2369);}else{v2372=__fn24(v2343,v2344,v2345,v2346,v2347,v2369);}
const v2373=v2372;
const v2375=__fn20(v2367,v2373);
const v2377=44;
let v2380;if(v2351){if(!v2378){const v2379=__preparedFactories.get(24);v2378=v2379([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2380=v2378(v2343,v2344,v2345,v2346,v2347,v2377);}else{v2380=__fn24(v2343,v2344,v2345,v2346,v2347,v2377);}
const v2381=v2380;
const v2383=55;
let v2386;if(v2351){if(!v2384){const v2385=__preparedFactories.get(24);v2384=v2385([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2386=v2384(v2343,v2344,v2345,v2346,v2347,v2383);}else{v2386=__fn24(v2343,v2344,v2345,v2346,v2347,v2383);}
const v2387=v2386;
const v2389=__fn20(v2381,v2387);
const v2391=66;
let v2394;if(v2351){if(!v2392){const v2393=__preparedFactories.get(24);v2392=v2393([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2394=v2392(v2343,v2344,v2345,v2346,v2347,v2391);}else{v2394=__fn24(v2343,v2344,v2345,v2346,v2347,v2391);}
const v2395=v2394;
const v2397=77;
let v2400;if(v2351){if(!v2398){const v2399=__preparedFactories.get(24);v2398=v2399([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2400=v2398(v2343,v2344,v2345,v2346,v2347,v2397);}else{v2400=__fn24(v2343,v2344,v2345,v2346,v2347,v2397);}
const v2401=v2400;
const v2403=__fn20(v2395,v2401);
const v2405=88;
let v2408;if(v2351){if(!v2406){const v2407=__preparedFactories.get(24);v2406=v2407([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2408=v2406(v2343,v2344,v2345,v2346,v2347,v2405);}else{v2408=__fn24(v2343,v2344,v2345,v2346,v2347,v2405);}
const v2409=v2408;
const v2411=99;
let v2414;if(v2351){if(!v2412){const v2413=__preparedFactories.get(24);v2412=v2413([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2414=v2412(v2343,v2344,v2345,v2346,v2347,v2411);}else{v2414=__fn24(v2343,v2344,v2345,v2346,v2347,v2411);}
const v2415=v2414;
const v2417=__fn20(v2409,v2415);
const v2419=110;
let v2422;if(v2351){if(!v2420){const v2421=__preparedFactories.get(24);v2420=v2421([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2422=v2420(v2343,v2344,v2345,v2346,v2347,v2419);}else{v2422=__fn24(v2343,v2344,v2345,v2346,v2347,v2419);}
const v2423=v2422;
const v2425=121;
let v2428;if(v2351){if(!v2426){const v2427=__preparedFactories.get(24);v2426=v2427([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4],true],depth+1);}v2428=v2426(v2343,v2344,v2345,v2346,v2347,v2425);}else{v2428=__fn24(v2343,v2344,v2345,v2346,v2347,v2425);}
const v2429=v2428;
const v2431=__fn20(v2423,v2429);
return [v2361,v2375,v2389,v2403,v2417,v2431];};}
function __prepareFn26(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[4],[]))))return __fn26;const v2441=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[4],[]);
let v2440=false,v2439;
return function(v2433,v2434,v2435,v2436,v2437){let v2438;if(v2441&&v2440){v2438=v2439;}else{
const v2442=6;
const v2443=(((v2437) + (v2442)) >>> 0);
v2438=__fn22(v2433,v2434,v2435,v2443);if(v2441){v2439=v2438;v2440=true;}}
const v2444=v2438;
let v2445=v2444["value"];
let v2446=v2444["tangent"];
for(let v2448=0;v2448<6;v2448++){
const v2449=(v2448>>>0);
const v2451=(((v2437) + (v2449)) >>> 0);
const v2452=__fn22(v2433,v2434,v2435,v2451);
let v2453;if(v2449<v2436.length){v2453=v2436[v2449];}else{
const v2454=0.0;
const v2455=0.0;
v2453=({["value"]:v2454,["tangent"]:v2455});}
const v2456=v2453;
const v2457=__fn19(v2452,v2456);
const v2458=__nfValue(v2445);
const v2459=__nfValue(v2457["value"]);
const v2460=Math.fround(__nfNumber(v2458) + __nfNumber(v2459));
const v2461=__nfValue(v2446);
const v2462=__nfValue(v2457["tangent"]);
const v2463=Math.fround(__nfNumber(v2461) + __nfNumber(v2462));
v2445=v2460;
v2446=v2463;
}
return ({["value"]:v2445,["tangent"]:v2446});};}
function __prepareFn27(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn27;const v2471=depth<15&&__preparedFactories.has(26)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2469;
let v2476;
let v2484;
let v2490;
let v2498;
let v2504;
let v2512;
let v2518;
let v2526;
let v2532;
let v2540;
let v2546;
return function(v2464,v2465,v2466,v2467){const v2468=132;
let v2472;if(v2471){if(!v2469){const v2470=__preparedFactories.get(26);v2469=v2470([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2472=v2469(v2464,v2465,v2466,v2467,v2468);}else{v2472=__fn26(v2464,v2465,v2466,v2467,v2468);}
const v2473=v2472;
const v2475=139;
let v2478;if(v2471){if(!v2476){const v2477=__preparedFactories.get(26);v2476=v2477([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2478=v2476(v2464,v2465,v2466,v2467,v2475);}else{v2478=__fn26(v2464,v2465,v2466,v2467,v2475);}
const v2479=v2478;
const v2481=__fn20(v2473,v2479);
const v2483=146;
let v2486;if(v2471){if(!v2484){const v2485=__preparedFactories.get(26);v2484=v2485([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2486=v2484(v2464,v2465,v2466,v2467,v2483);}else{v2486=__fn26(v2464,v2465,v2466,v2467,v2483);}
const v2487=v2486;
const v2489=153;
let v2492;if(v2471){if(!v2490){const v2491=__preparedFactories.get(26);v2490=v2491([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2492=v2490(v2464,v2465,v2466,v2467,v2489);}else{v2492=__fn26(v2464,v2465,v2466,v2467,v2489);}
const v2493=v2492;
const v2495=__fn20(v2487,v2493);
const v2497=160;
let v2500;if(v2471){if(!v2498){const v2499=__preparedFactories.get(26);v2498=v2499([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2500=v2498(v2464,v2465,v2466,v2467,v2497);}else{v2500=__fn26(v2464,v2465,v2466,v2467,v2497);}
const v2501=v2500;
const v2503=167;
let v2506;if(v2471){if(!v2504){const v2505=__preparedFactories.get(26);v2504=v2505([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2506=v2504(v2464,v2465,v2466,v2467,v2503);}else{v2506=__fn26(v2464,v2465,v2466,v2467,v2503);}
const v2507=v2506;
const v2509=__fn20(v2501,v2507);
const v2511=174;
let v2514;if(v2471){if(!v2512){const v2513=__preparedFactories.get(26);v2512=v2513([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2514=v2512(v2464,v2465,v2466,v2467,v2511);}else{v2514=__fn26(v2464,v2465,v2466,v2467,v2511);}
const v2515=v2514;
const v2517=181;
let v2520;if(v2471){if(!v2518){const v2519=__preparedFactories.get(26);v2518=v2519([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2520=v2518(v2464,v2465,v2466,v2467,v2517);}else{v2520=__fn26(v2464,v2465,v2466,v2467,v2517);}
const v2521=v2520;
const v2523=__fn20(v2515,v2521);
const v2525=188;
let v2528;if(v2471){if(!v2526){const v2527=__preparedFactories.get(26);v2526=v2527([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2528=v2526(v2464,v2465,v2466,v2467,v2525);}else{v2528=__fn26(v2464,v2465,v2466,v2467,v2525);}
const v2529=v2528;
const v2531=195;
let v2534;if(v2471){if(!v2532){const v2533=__preparedFactories.get(26);v2532=v2533([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2534=v2532(v2464,v2465,v2466,v2467,v2531);}else{v2534=__fn26(v2464,v2465,v2466,v2467,v2531);}
const v2535=v2534;
const v2537=__fn20(v2529,v2535);
const v2539=202;
let v2542;if(v2471){if(!v2540){const v2541=__preparedFactories.get(26);v2540=v2541([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2542=v2540(v2464,v2465,v2466,v2467,v2539);}else{v2542=__fn26(v2464,v2465,v2466,v2467,v2539);}
const v2543=v2542;
const v2545=209;
let v2548;if(v2471){if(!v2546){const v2547=__preparedFactories.get(26);v2546=v2547([fixed[0],fixed[1],fixed[2],fixed[3],true],depth+1);}v2548=v2546(v2464,v2465,v2466,v2467,v2545);}else{v2548=__fn26(v2464,v2465,v2466,v2467,v2545);}
const v2549=v2548;
const v2551=__fn20(v2543,v2549);
return [v2481,v2495,v2509,v2523,v2537,v2551];};}
function __prepareFn28(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn28;const v2561=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[])&&__preparedStable(fixed[4],[]);
let v2560=false,v2559;
const v2564=depth<15&&__preparedFactories.has(25)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2562;
let v2568=false,v2567;
const v2572=depth<15&&__preparedFactories.has(27)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2570;
const v2578=depth<15&&__preparedFactories.has(26)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2576;
let v2584;
let v2591;
let v2598;
return function(v2553,v2554,v2555,v2556,v2557){let v2558;if(v2561&&v2560){v2558=v2559;}else{
let v2565;if(v2564){if(!v2562){const v2563=__preparedFactories.get(25);v2562=v2563([fixed[0],fixed[1],fixed[2],fixed[3],fixed[4]],depth+1);}v2565=v2562(v2553,v2554,v2555,v2556,v2557);}else{v2565=__fn25(v2553,v2554,v2555,v2556,v2557);}
v2558=v2565;if(v2561){v2559=v2558;v2560=true;}}
let v2566;if(v2561&&v2568){v2566=v2567;}else{
const v2569=v2558;
let v2573;if(v2572){if(!v2570){const v2571=__preparedFactories.get(27);v2570=v2571([fixed[0],fixed[1],fixed[2],v2561],depth+1);}v2573=v2570(v2553,v2554,v2555,v2569);}else{v2573=__fn27(v2553,v2554,v2555,v2569);}
v2566=v2573;if(v2561){v2567=v2566;v2568=true;}}
const v2574=v2566;
const v2575=216;
let v2579;if(v2578){if(!v2576){const v2577=__preparedFactories.get(26);v2576=v2577([fixed[0],fixed[1],fixed[2],v2561,true],depth+1);}v2579=v2576(v2553,v2554,v2555,v2574,v2575);}else{v2579=__fn26(v2553,v2554,v2555,v2574,v2575);}
const v2580=v2579;
const v2582=v2566;
const v2583=223;
let v2586;if(v2578){if(!v2584){const v2585=__preparedFactories.get(26);v2584=v2585([fixed[0],fixed[1],fixed[2],v2561,true],depth+1);}v2586=v2584(v2553,v2554,v2555,v2582,v2583);}else{v2586=__fn26(v2553,v2554,v2555,v2582,v2583);}
const v2587=v2586;
const v2589=v2566;
const v2590=230;
let v2593;if(v2578){if(!v2591){const v2592=__preparedFactories.get(26);v2591=v2592([fixed[0],fixed[1],fixed[2],v2561,true],depth+1);}v2593=v2591(v2553,v2554,v2555,v2589,v2590);}else{v2593=__fn26(v2553,v2554,v2555,v2589,v2590);}
const v2594=v2593;
const v2596=v2566;
const v2597=237;
let v2600;if(v2578){if(!v2598){const v2599=__preparedFactories.get(26);v2598=v2599([fixed[0],fixed[1],fixed[2],v2561,true],depth+1);}v2600=v2598(v2553,v2554,v2555,v2596,v2597);}else{v2600=__fn26(v2553,v2554,v2555,v2596,v2597);}
const v2601=v2600;
return [v2580,v2587,v2594,v2601];};}
function __prepareFn32(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn32;const v2618=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[])&&__preparedStable(fixed[5],[]);
let v2617=false,v2616;
const v2621=depth<15&&__preparedFactories.has(28)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2619;
const v2626=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[])&&__preparedStable(fixed[4],[])&&__preparedStable(fixed[5],[]);
let v2625=false,v2624;
return function(v2609,v2610,v2611,v2612,v2613,v2614){let v2615;if(v2618&&v2617){v2615=v2616;}else{
let v2622;if(v2621){if(!v2619){const v2620=__preparedFactories.get(28);v2619=v2620([fixed[0],fixed[1],fixed[2],fixed[3],fixed[5]],depth+1);}v2622=v2619(v2609,v2610,v2611,v2612,v2614);}else{v2622=__fn28(v2609,v2610,v2611,v2612,v2614);}
v2615=v2622;if(v2618){v2616=v2615;v2617=true;}}
let v2623;if(v2626&&v2625){v2623=v2624;}else{
const v2627=0.0;
const v2628=0.0;
let v2629=v2627;
let v2630=v2628;
for(let v2632=0;v2632<4;v2632++){
const v2633=(v2632>>>0);
const v2635=v2615;
let v2636;if(v2633<v2635.length){v2636=v2635[v2633];}else{
const v2637=0.0;
const v2638=0.0;
v2636=({["value"]:v2637,["tangent"]:v2638});}
const v2639=v2636;
const v2640=4;
const v2641=(Math.imul(v2614,v2640) >>> 0);
const v2642=(((v2641) + (v2633)) >>> 0);
let v2643;if(v2642<v2613.length){v2643=v2613[v2642];}else{
const v2644=0.0;
const v2645=0.0;
v2643=({["value"]:v2644,["tangent"]:v2645});}
const v2646=v2643;
const v2647=__fn30(v2639,v2646);
const v2648=__nfValue(v2629);
const v2649=__nfValue(v2647["value"]);
const v2650=Math.fround(__nfNumber(v2648) + __nfNumber(v2649));
const v2651=__nfValue(v2630);
const v2652=__nfValue(v2647["tangent"]);
const v2653=Math.fround(__nfNumber(v2651) + __nfNumber(v2652));
v2629=v2650;
v2630=v2653;
}
v2623=({["value"]:v2629,["tangent"]:v2630});if(v2626){v2624=v2623;v2625=true;}}
const v2654=v2623;
const v2655=4.0;
const v2656=0.0;
const v2658=Math.fround((__nfNumber(__nfValue(v2654["value"])))/(__nfNumber(v2655)));
const v2659=__nfValue(v2654["tangent"]);
const v2660=Math.fround(__nfNumber(v2659) * v2655);
const v2661=__nfValue(v2654["value"]);
const v2662=Math.fround(__nfNumber(v2661) * v2656);
const v2663=Math.fround((__nfNumber(Math.fround(v2660 - v2662)))/(__nfNumber(Math.fround(v2655 * v2655))));
return ({["value"]:v2658,["tangent"]:v2663});};}
function __prepareFn33(fixed,depth=0){if(depth>=16||!((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[]))))return __fn33;const v2673=__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])&&__preparedStable(fixed[3],[])&&__preparedStable(fixed[4],[])&&__preparedStable(fixed[5],[]);
let v2672=false,v2671;
const v2676={all:__preparedStable(fixed[0],[]),fields:{["tangent"]:true,["value"]:fixed[0]}};
const v2697=__preparedStable(fixed[2],[]);
const v2704=__preparedStable(fixed[3],[]);
const v2711=__preparedStable(fixed[4],[]);
const v2714=depth<15&&__preparedFactories.has(32)&&((__preparedStable(fixed[0],[])&&__preparedStable(fixed[1],[])&&__preparedStable(fixed[2],[])));
let v2712;
return function(v2664,v2665,v2666,v2667,v2668,v2669){v2664=__nfValue(v2664);
let v2670;if(v2673&&v2672){v2670=v2671;}else{
const v2674=1.0;
const v2675=({["value"]:v2664,["tangent"]:v2674});
const v2677=[];for(let v2678=0;v2678<v2666.length;v2678++){
const v2679=v2666[v2678];
const v2680=__nfValue(v2679["value"]);
const v2681=0.0;
const v2682=({["value"]:v2680,["tangent"]:v2681});
const v2683=__nfValue(v2679["first"]);
const v2684=0.0;
const v2685=({["value"]:v2683,["tangent"]:v2684});
const v2686=__nfValue(v2679["second"]);
const v2687=0.0;
const v2688=({["value"]:v2686,["tangent"]:v2687});
const v2689=__nfValue(v2679["first_power"]);
const v2690=0.0;
const v2691=({["value"]:v2689,["tangent"]:v2690});
const v2692=__nfValue(v2679["second_power"]);
const v2693=0.0;
const v2694=({["value"]:v2692,["tangent"]:v2693});
const v2695=v2679["steps"];
v2677.push(({["value"]:v2682,["first"]:v2685,["second"]:v2688,["first_power"]:v2691,["second_power"]:v2694,["steps"]:v2695}));}
const v2696=v2677;
const v2698=[];for(let v2699=0;v2699<v2667.length;v2699++){
const v2700=v2667[v2699];
const v2701=__nfValue(v2700);
const v2702=0.0;
v2698.push(({["value"]:v2701,["tangent"]:v2702}));}
const v2703=v2698;
const v2705=[];for(let v2706=0;v2706<v2668.length;v2706++){
const v2707=v2668[v2706];
const v2708=__nfValue(v2707);
const v2709=0.0;
v2705.push(({["value"]:v2708,["tangent"]:v2709}));}
const v2710=v2705;
let v2715;if(v2714){if(!v2712){const v2713=__preparedFactories.get(32);v2712=v2713([v2676,fixed[1],v2697,v2704,v2711,fixed[5]],depth+1);}v2715=v2712(v2675,v2665,v2696,v2703,v2710,v2669);}else{v2715=__fn32(v2675,v2665,v2696,v2703,v2710,v2669);}
v2670=v2715;if(v2673){v2671=v2670;v2672=true;}}
const v2716=v2670;
return __nfValue(v2716["tangent"]);};}
const __preparedFactories=new Map([[3,__prepareFn3],[4,__prepareFn4],[5,__prepareFn5],[6,__prepareFn6],[7,__prepareFn7],[9,__prepareFn9],[15,__prepareFn15],[16,__prepareFn16],[24,__prepareFn24],[25,__prepareFn25],[26,__prepareFn26],[27,__prepareFn27],[28,__prepareFn28],[32,__prepareFn32],[33,__prepareFn33]]);
