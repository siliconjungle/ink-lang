// Exact wrapping u64 over two storage lanes. No floating point intermediates.
struct InkU64 {lo:u32,hi:u32,}
struct InkDiv64 {quotient:InkU64,remainder:InkU64,}
fn ink_u64_shl(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64(a.lo<<k,(a.hi<<k)|(a.lo>>(32u-k)));}return InkU64(0u,a.lo<<(k-32u));}
fn ink_u64_shr(a:InkU64,count:u32)->InkU64{let k=count&63u;if(k==0u){return a;}if(k<32u){return InkU64((a.lo>>k)|(a.hi<<(32u-k)),a.hi>>k);}return InkU64(a.hi>>(k-32u),0u);}
fn ink_u64_rol(a:InkU64,count:u32)->InkU64{let k=count&63u;let l=ink_u64_shl(a,k);let r=ink_u64_shr(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_ror(a:InkU64,count:u32)->InkU64{let k=count&63u;let r=ink_u64_shr(a,k);let l=ink_u64_shl(a,(0u-k)&63u);return InkU64(l.lo|r.lo,l.hi|r.hi);}
fn ink_u64_eq(a:InkU64,b:InkU64)->bool{return a.lo==b.lo&&a.hi==b.hi;}
fn ink_u64_lt(a:InkU64,b:InkU64)->bool{return a.hi<b.hi||(a.hi==b.hi&&a.lo<b.lo);}
fn ink_u64_add(a:InkU64,b:InkU64)->InkU64{let lo=a.lo+b.lo;return InkU64(lo,a.hi+b.hi+select(0u,1u,lo<a.lo));}
fn ink_u64_sub(a:InkU64,b:InkU64)->InkU64{return InkU64(a.lo-b.lo,a.hi-b.hi-select(0u,1u,a.lo<b.lo));}
fn ink_u64_mul(a:InkU64,b:InkU64)->InkU64{let al=a.lo&65535u;let ah=a.lo>>16u;let bl=b.lo&65535u;let bh=b.lo>>16u;let p=al*bl;let x=ah*bl;let y=al*bh;let mid=(p>>16u)+(x&65535u)+(y&65535u);let high=ah*bh+(x>>16u)+(y>>16u)+(mid>>16u);return InkU64((mid<<16u)|(p&65535u),high+a.lo*b.hi+a.hi*b.lo);}
fn ink_u64_div(a:InkU64,b:InkU64)->InkDiv64{var q=InkU64(0u,0u);var r=InkU64(0u,0u);var cursor=64u;loop{if(cursor==0u){break;}cursor--;var bit=0u;if(cursor>=32u){bit=(a.hi>>(cursor-32u))&1u;}else{bit=(a.lo>>cursor)&1u;}let overflow=r.hi>>31u;r=InkU64((r.lo<<1u)|bit,(r.hi<<1u)|(r.lo>>31u));if(overflow!=0u||!ink_u64_lt(r,b)){r=ink_u64_sub(r,b);if(cursor>=32u){q.hi|=1u<<(cursor-32u);}else{q.lo|=1u<<cursor;}}}return InkDiv64(q,r);}
// Binary32 evaluated with integer lanes: round-to-nearest, ties-to-even,
// gradual underflow, signed zero and canonical arithmetic NaN.
fn ink_f32_nan(x:u32)->bool{return (x&0x7fffffffu)>0x7f800000u;}
fn ink_f32_eq(a:u32,b:u32)->bool{return !ink_f32_nan(a)&&!ink_f32_nan(b)&&(a==b||((a|b)&0x7fffffffu)==0u);}
fn ink_f32_lt(a:u32,b:u32)->bool{
 if(ink_f32_nan(a)||ink_f32_nan(b)||ink_f32_eq(a,b)){return false;}
 if((a^b)&0x80000000u)!=0u{return (a&0x80000000u)!=0u;}
 if((a&0x80000000u)!=0u){return a>b;}return a<b;
}
fn ink_f32_jam(x:u32,n:u32)->u32{if(n==0u){return x;}if(n>=32u){return select(0u,1u,x!=0u);}return (x>>n)|select(0u,1u,(x&((1u<<n)-1u))!=0u);}
fn ink_f32_round(sign:u32,exponent:i32,extended:u32)->u32{
 var e=exponent;var s=extended;
 if(e<1i){s=ink_f32_jam(s,u32(1i-e));e=1i;}
 let tail=s&7u;var sig=s>>3u;
 if(tail>4u||(tail==4u&&(sig&1u)!=0u)){sig++;}
 if(sig>=0x1000000u){sig>>=1u;e++;}
 if(e>=255i){return sign|0x7f800000u;}
 if(sig==0u){return sign;}
 let raw=select(u32(e),0u,e==1i&&sig<0x800000u);
 return sign|(raw<<23u)|(sig&0x7fffffu);
}
fn ink_f32_add(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 var x=a;var y=b;if((x&0x7fffffffu)<(y&0x7fffffffu)){x=b;y=a;}
 let ax=x&0x7fffffffu;let ay=y&0x7fffffffu;let sign=x&0x80000000u;
 if(ax==0x7f800000u){if(ay==ax&&((x^y)&0x80000000u)!=0u){return 0x7fc00000u;}return x;}
 let rx=(x>>23u)&255u;let ry=(y>>23u)&255u;var e=i32(max(rx,1u));
 var sx=((x&0x7fffffu)|select(0u,0x800000u,rx!=0u))<<3u;
 let sy=ink_f32_jam(((y&0x7fffffu)|select(0u,0x800000u,ry!=0u))<<3u,u32(e)-max(ry,1u));
 if(((x^y)&0x80000000u)==0u){sx+=sy;if(sx>=0x8000000u){sx=ink_f32_jam(sx,1u);e++;}}
 else{sx-=sy;if(sx==0u){return 0u;}loop{if(sx>=0x4000000u||e<=1i){break;}sx<<=1u;e--;}}
 return ink_f32_round(sign,e,sx);
}
fn ink_f32_sub(a:u32,b:u32)->u32{return ink_f32_add(a,b^0x80000000u);}
fn ink_f32_mul(a:u32,b:u32)->u32{
 if(ink_f32_nan(a)||ink_f32_nan(b)){return 0x7fc00000u;}
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(aa==0x7f800000u||bb==0x7f800000u){if(aa==0u||bb==0u){return 0x7fc00000u;}return sign|0x7f800000u;}
 if(aa==0u||bb==0u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u));var eb=i32(max(rb,1u));
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 let product=ink_u64_mul(InkU64(sa,0u),InkU64(sb,0u));let high=(product.hi&0x8000u)!=0u;
 let shift=select(20u,21u,high);let extended=(product.lo>>shift)|(product.hi<<(32u-shift))|select(0u,1u,(product.lo&((1u<<shift)-1u))!=0u);
 return ink_f32_round(sign,ea+eb-127i+select(0i,1i,high),extended);
}
// Exact sqrt and division use integer significands, independent of WGSL float
// approximation allowances and device flush-to-zero behavior.
fn ink_f32_sqrt(x:u32)->u32{
 let a=x&0x7fffffffu;if(a==0u){return x;}
 if(a>0x7f800000u||(x&0x80000000u)!=0u){return 0x7fc00000u;}
 if(a==0x7f800000u){return x;}
 let raw=(x>>23u)&255u;var m=(x&0x7fffffu)|select(0u,0x800000u,raw!=0u);var e=i32(max(raw,1u))-127i;
 loop{if(m>=0x800000u){break;}m<<=1u;e--;}
 let odd=e&1i;var half=(e-odd)/2i;let shift=23u+u32(odd);
 let n=InkU64(m<<shift,m>>(32u-shift));var lo=0u;var hi=0x1000000u;
 loop{if(lo+1u>=hi){break;}let mid=(lo+hi)>>1u;let sq=ink_u64_mul(InkU64(mid,0u),InkU64(mid,0u));if(!ink_u64_lt(n,sq)){lo=mid;}else{hi=mid;}}
 let sq=ink_u64_mul(InkU64(lo,0u),InkU64(lo,0u));let rem=ink_u64_sub(n,sq);
 if(ink_u64_lt(InkU64(lo,0u),rem)){lo++;}
 if(lo==0x1000000u){lo>>=1u;half++;}
 return (u32(half+127i)<<23u)|(lo&0x7fffffu);
}
fn ink_f32_div(a:u32,b:u32)->u32{
 let aa=a&0x7fffffffu;let bb=b&0x7fffffffu;let sign=(a^b)&0x80000000u;
 if(ink_f32_nan(a)||ink_f32_nan(b)||(aa==0u&&bb==0u)||(aa==0x7f800000u&&bb==aa)){return 0x7fc00000u;}
 if(aa==0x7f800000u||bb==0u){return sign|0x7f800000u;}
 if(aa==0u||bb==0x7f800000u){return sign;}
 let ra=(a>>23u)&255u;let rb=(b>>23u)&255u;var ea=i32(max(ra,1u))-127i;var eb=i32(max(rb,1u))-127i;
 var sa=(a&0x7fffffu)|select(0u,0x800000u,ra!=0u);var sb=(b&0x7fffffu)|select(0u,0x800000u,rb!=0u);
 loop{if(sa>=0x800000u){break;}sa<<=1u;ea--;}
 loop{if(sb>=0x800000u){break;}sb<<=1u;eb--;}
 var e=ea-eb;if(sa<sb){sa<<=1u;e--;}
 let division=ink_u64_div(InkU64(sa<<26u,sa>>6u),InkU64(sb,0u));
 let extended=division.quotient.lo|select(0u,1u,!ink_u64_eq(division.remainder,InkU64(0u,0u)));
 return ink_f32_round(sign,e+127i,extended);
}
// mode: 0 trunc, 1 floor, 2 ceil, 3 ties-to-even.
fn ink_f32_integral(x:u32,mode:u32)->u32{
 let a=x&0x7fffffffu;let sign=x&0x80000000u;
 if(a>0x7f800000u){return 0x7fc00000u;}if(a>=0x4b000000u||a==0u){return x;}
 let e=i32((x>>23u)&255u)-127i;
 if(e<0i){var up=false;if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){up=a>0x3f000000u;}return sign|select(0u,0x3f800000u,up);}
 let shift=u32(23i-e);let mask=(1u<<shift)-1u;let fraction=a&mask;var rounded=a&~mask;var up=false;
 if(fraction!=0u){if(mode==1u){up=sign!=0u;}else if(mode==2u){up=sign==0u;}else if(mode==3u){let half=1u<<(shift-1u);up=fraction>half||(fraction==half&&((rounded>>shift)&1u)!=0u);}}
 if(up){rounded+=1u<<shift;}return sign|rounded;
}
fn ink_f32_from_u64(x:InkU64)->u32{
 if(ink_u64_eq(x,InkU64(0u,0u))){return 0u;}
 let leading=select(countLeadingZeros(x.lo)+32u,countLeadingZeros(x.hi),x.hi!=0u);let e=63u-leading;
 if(e<=23u){return ((e+127u)<<23u)|((x.lo<<(23u-e))&0x7fffffu);}
 let shift=e-23u;var sig=0u;var rem=InkU64(0u,0u);var half=InkU64(0u,0u);
 if(shift<32u){sig=(x.lo>>shift)|(x.hi<<(32u-shift));rem=InkU64(x.lo&((1u<<shift)-1u),0u);half=InkU64(1u<<(shift-1u),0u);}
 else if(shift==32u){sig=x.hi;rem=InkU64(x.lo,0u);half=InkU64(0x80000000u,0u);}
 else{sig=x.hi>>(shift-32u);rem=InkU64(x.lo,x.hi&((1u<<(shift-32u))-1u));half=InkU64(0u,1u<<(shift-33u));}
 if(ink_u64_lt(half,rem)||(ink_u64_eq(rem,half)&&(sig&1u)!=0u)){sig++;}
 var exponent=e+127u;if(sig==0x1000000u){sig>>=1u;exponent++;}
 return (exponent<<23u)|(sig&0x7fffffu);
}
fn ink_f32_from_i32(x:i32)->u32{let neg=x<0i;let magnitude=select(u32(x),0u-u32(x),neg);return ink_f32_from_u64(InkU64(magnitude,0u))|select(0u,0x80000000u,neg);}
struct InkBuffer_u32{data:array<u32,64>,length:u32,}
struct InkBuffer_InkU64{data:array<InkU64,64>,length:u32,}
struct InkBuffer_i32{data:array<i32,64>,length:u32,}
struct InkBuffer_bool{data:array<bool,64>,length:u32,}
struct R_Parameter{ink_f_value:u32,ink_f_first:u32,ink_f_second:u32,ink_f_first_power:u32,ink_f_second_power:u32,ink_f_steps:u32,}
@group(0) @binding(0) var<storage,read> a0:array<u32>;
@group(0) @binding(1) var<storage,read> a1:array<u32>;
@group(0) @binding(2) var<storage,read> a2:array<u32>;
@group(0) @binding(3) var<storage,read> a3:array<u32>;
@group(0) @binding(4) var<storage,read_write> output:array<u32>;
@compute @workgroup_size(64) fn main(@builtin(global_invocation_id) gid:vec3<u32>){
let size=6u;let i=gid.x;if(i==0u){output[0]=size;}if(i<size){
switch(i){
case 0u:{
var t0:u32=a0[0u+(0u)*1u+0u];
var t1:u32=a1[0u+(0u)*1u+0u];
var t2:u32=132u;
var t3:u32=t0;
var t4:u32=t1;
var t5:u32=t2;
var t6:u32=(t5 + 6u);
var t7:u32=t4;
var t8:u32;
if ((t7 == t6)) {
t8=t3;
} else {
var t9:u32=t6;
var t10:R_Parameter;if(t9<a3[0u]){
t10=R_Parameter(a3[1u+(t9)*6u+0u],a3[1u+(t9)*6u+1u],a3[1u+(t9)*6u+2u],a3[1u+(t9)*6u+3u],a3[1u+(t9)*6u+4u],a3[1u+(t9)*6u+5u]);}else{
var t11:u32=0u;
var t12:u32=0u;
var t13:u32=0u;
var t14:u32=1065353216u;
var t15:u32=1065353216u;
var t16:u32=0u;
t10=R_Parameter(t11,t12,t13,t14,t15,t16);}
t8=(t10).ink_f_value;
}
var t17:u32=t8;
var t18:u32=t17;
for(var t19=0u;t19<6u;t19++){
var t20:u32=t18;
var t21:u32=t0;
var t22:u32=t1;
var t23:u32=t2;
var t24:u32=(t23 + t19);
var t25:u32=t22;
var t26:u32;
if ((t25 == t24)) {
t26=t21;
} else {
var t27:u32=t24;
var t28:R_Parameter;if(t27<a3[0u]){
t28=R_Parameter(a3[1u+(t27)*6u+0u],a3[1u+(t27)*6u+1u],a3[1u+(t27)*6u+2u],a3[1u+(t27)*6u+3u],a3[1u+(t27)*6u+4u],a3[1u+(t27)*6u+5u]);}else{
var t29:u32=0u;
var t30:u32=0u;
var t31:u32=0u;
var t32:u32=1065353216u;
var t33:u32=1065353216u;
var t34:u32=0u;
t28=R_Parameter(t29,t30,t31,t32,t33,t34);}
t26=(t28).ink_f_value;
}
var t35:u32=t26;
var t36:u32=t19;
var t37:u32;if(t36<a2[0u]){
t37=a2[1u+(t36)*1u+0u];}else{
t37=0u;}
t18=ink_f32_add(t20,ink_f32_mul(t35,t37));
}
var t38:u32=t18;
var t39:u32=a0[0u+(0u)*1u+0u];
var t40:u32=a1[0u+(0u)*1u+0u];
var t41:u32=139u;
var t42:u32=t39;
var t43:u32=t40;
var t44:u32=t41;
var t45:u32=(t44 + 6u);
var t46:u32=t43;
var t47:u32;
if ((t46 == t45)) {
t47=t42;
} else {
var t48:u32=t45;
var t49:R_Parameter;if(t48<a3[0u]){
t49=R_Parameter(a3[1u+(t48)*6u+0u],a3[1u+(t48)*6u+1u],a3[1u+(t48)*6u+2u],a3[1u+(t48)*6u+3u],a3[1u+(t48)*6u+4u],a3[1u+(t48)*6u+5u]);}else{
var t50:u32=0u;
var t51:u32=0u;
var t52:u32=0u;
var t53:u32=1065353216u;
var t54:u32=1065353216u;
var t55:u32=0u;
t49=R_Parameter(t50,t51,t52,t53,t54,t55);}
t47=(t49).ink_f_value;
}
var t56:u32=t47;
var t57:u32=t56;
for(var t58=0u;t58<6u;t58++){
var t59:u32=t57;
var t60:u32=t39;
var t61:u32=t40;
var t62:u32=t41;
var t63:u32=(t62 + t58);
var t64:u32=t61;
var t65:u32;
if ((t64 == t63)) {
t65=t60;
} else {
var t66:u32=t63;
var t67:R_Parameter;if(t66<a3[0u]){
t67=R_Parameter(a3[1u+(t66)*6u+0u],a3[1u+(t66)*6u+1u],a3[1u+(t66)*6u+2u],a3[1u+(t66)*6u+3u],a3[1u+(t66)*6u+4u],a3[1u+(t66)*6u+5u]);}else{
var t68:u32=0u;
var t69:u32=0u;
var t70:u32=0u;
var t71:u32=1065353216u;
var t72:u32=1065353216u;
var t73:u32=0u;
t67=R_Parameter(t68,t69,t70,t71,t72,t73);}
t65=(t67).ink_f_value;
}
var t74:u32=t65;
var t75:u32=t58;
var t76:u32;if(t75<a2[0u]){
t76=a2[1u+(t75)*1u+0u];}else{
t76=0u;}
t57=ink_f32_add(t59,ink_f32_mul(t74,t76));
}
var t77:u32=t57;
var t78:u32=t77;
var t79:u32;
if (ink_f32_lt(0u,t78)) {
var t80:u32=t38;
t79=ink_f32_mul(t80,t77);
} else {
t79=0u;
}
var t81:u32=t79;
output[1u+i*1u+0u]=bitcast<u32>(t81);

}
case 1u:{
var t82:u32=a0[0u+(0u)*1u+0u];
var t83:u32=a1[0u+(0u)*1u+0u];
var t84:u32=146u;
var t85:u32=t82;
var t86:u32=t83;
var t87:u32=t84;
var t88:u32=(t87 + 6u);
var t89:u32=t86;
var t90:u32;
if ((t89 == t88)) {
t90=t85;
} else {
var t91:u32=t88;
var t92:R_Parameter;if(t91<a3[0u]){
t92=R_Parameter(a3[1u+(t91)*6u+0u],a3[1u+(t91)*6u+1u],a3[1u+(t91)*6u+2u],a3[1u+(t91)*6u+3u],a3[1u+(t91)*6u+4u],a3[1u+(t91)*6u+5u]);}else{
var t93:u32=0u;
var t94:u32=0u;
var t95:u32=0u;
var t96:u32=1065353216u;
var t97:u32=1065353216u;
var t98:u32=0u;
t92=R_Parameter(t93,t94,t95,t96,t97,t98);}
t90=(t92).ink_f_value;
}
var t99:u32=t90;
var t100:u32=t99;
for(var t101=0u;t101<6u;t101++){
var t102:u32=t100;
var t103:u32=t82;
var t104:u32=t83;
var t105:u32=t84;
var t106:u32=(t105 + t101);
var t107:u32=t104;
var t108:u32;
if ((t107 == t106)) {
t108=t103;
} else {
var t109:u32=t106;
var t110:R_Parameter;if(t109<a3[0u]){
t110=R_Parameter(a3[1u+(t109)*6u+0u],a3[1u+(t109)*6u+1u],a3[1u+(t109)*6u+2u],a3[1u+(t109)*6u+3u],a3[1u+(t109)*6u+4u],a3[1u+(t109)*6u+5u]);}else{
var t111:u32=0u;
var t112:u32=0u;
var t113:u32=0u;
var t114:u32=1065353216u;
var t115:u32=1065353216u;
var t116:u32=0u;
t110=R_Parameter(t111,t112,t113,t114,t115,t116);}
t108=(t110).ink_f_value;
}
var t117:u32=t108;
var t118:u32=t101;
var t119:u32;if(t118<a2[0u]){
t119=a2[1u+(t118)*1u+0u];}else{
t119=0u;}
t100=ink_f32_add(t102,ink_f32_mul(t117,t119));
}
var t120:u32=t100;
var t121:u32=a0[0u+(0u)*1u+0u];
var t122:u32=a1[0u+(0u)*1u+0u];
var t123:u32=153u;
var t124:u32=t121;
var t125:u32=t122;
var t126:u32=t123;
var t127:u32=(t126 + 6u);
var t128:u32=t125;
var t129:u32;
if ((t128 == t127)) {
t129=t124;
} else {
var t130:u32=t127;
var t131:R_Parameter;if(t130<a3[0u]){
t131=R_Parameter(a3[1u+(t130)*6u+0u],a3[1u+(t130)*6u+1u],a3[1u+(t130)*6u+2u],a3[1u+(t130)*6u+3u],a3[1u+(t130)*6u+4u],a3[1u+(t130)*6u+5u]);}else{
var t132:u32=0u;
var t133:u32=0u;
var t134:u32=0u;
var t135:u32=1065353216u;
var t136:u32=1065353216u;
var t137:u32=0u;
t131=R_Parameter(t132,t133,t134,t135,t136,t137);}
t129=(t131).ink_f_value;
}
var t138:u32=t129;
var t139:u32=t138;
for(var t140=0u;t140<6u;t140++){
var t141:u32=t139;
var t142:u32=t121;
var t143:u32=t122;
var t144:u32=t123;
var t145:u32=(t144 + t140);
var t146:u32=t143;
var t147:u32;
if ((t146 == t145)) {
t147=t142;
} else {
var t148:u32=t145;
var t149:R_Parameter;if(t148<a3[0u]){
t149=R_Parameter(a3[1u+(t148)*6u+0u],a3[1u+(t148)*6u+1u],a3[1u+(t148)*6u+2u],a3[1u+(t148)*6u+3u],a3[1u+(t148)*6u+4u],a3[1u+(t148)*6u+5u]);}else{
var t150:u32=0u;
var t151:u32=0u;
var t152:u32=0u;
var t153:u32=1065353216u;
var t154:u32=1065353216u;
var t155:u32=0u;
t149=R_Parameter(t150,t151,t152,t153,t154,t155);}
t147=(t149).ink_f_value;
}
var t156:u32=t147;
var t157:u32=t140;
var t158:u32;if(t157<a2[0u]){
t158=a2[1u+(t157)*1u+0u];}else{
t158=0u;}
t139=ink_f32_add(t141,ink_f32_mul(t156,t158));
}
var t159:u32=t139;
var t160:u32=t159;
var t161:u32;
if (ink_f32_lt(0u,t160)) {
var t162:u32=t120;
t161=ink_f32_mul(t162,t159);
} else {
t161=0u;
}
var t163:u32=t161;
output[1u+i*1u+0u]=bitcast<u32>(t163);

}
case 2u:{
var t164:u32=a0[0u+(0u)*1u+0u];
var t165:u32=a1[0u+(0u)*1u+0u];
var t166:u32=160u;
var t167:u32=t164;
var t168:u32=t165;
var t169:u32=t166;
var t170:u32=(t169 + 6u);
var t171:u32=t168;
var t172:u32;
if ((t171 == t170)) {
t172=t167;
} else {
var t173:u32=t170;
var t174:R_Parameter;if(t173<a3[0u]){
t174=R_Parameter(a3[1u+(t173)*6u+0u],a3[1u+(t173)*6u+1u],a3[1u+(t173)*6u+2u],a3[1u+(t173)*6u+3u],a3[1u+(t173)*6u+4u],a3[1u+(t173)*6u+5u]);}else{
var t175:u32=0u;
var t176:u32=0u;
var t177:u32=0u;
var t178:u32=1065353216u;
var t179:u32=1065353216u;
var t180:u32=0u;
t174=R_Parameter(t175,t176,t177,t178,t179,t180);}
t172=(t174).ink_f_value;
}
var t181:u32=t172;
var t182:u32=t181;
for(var t183=0u;t183<6u;t183++){
var t184:u32=t182;
var t185:u32=t164;
var t186:u32=t165;
var t187:u32=t166;
var t188:u32=(t187 + t183);
var t189:u32=t186;
var t190:u32;
if ((t189 == t188)) {
t190=t185;
} else {
var t191:u32=t188;
var t192:R_Parameter;if(t191<a3[0u]){
t192=R_Parameter(a3[1u+(t191)*6u+0u],a3[1u+(t191)*6u+1u],a3[1u+(t191)*6u+2u],a3[1u+(t191)*6u+3u],a3[1u+(t191)*6u+4u],a3[1u+(t191)*6u+5u]);}else{
var t193:u32=0u;
var t194:u32=0u;
var t195:u32=0u;
var t196:u32=1065353216u;
var t197:u32=1065353216u;
var t198:u32=0u;
t192=R_Parameter(t193,t194,t195,t196,t197,t198);}
t190=(t192).ink_f_value;
}
var t199:u32=t190;
var t200:u32=t183;
var t201:u32;if(t200<a2[0u]){
t201=a2[1u+(t200)*1u+0u];}else{
t201=0u;}
t182=ink_f32_add(t184,ink_f32_mul(t199,t201));
}
var t202:u32=t182;
var t203:u32=a0[0u+(0u)*1u+0u];
var t204:u32=a1[0u+(0u)*1u+0u];
var t205:u32=167u;
var t206:u32=t203;
var t207:u32=t204;
var t208:u32=t205;
var t209:u32=(t208 + 6u);
var t210:u32=t207;
var t211:u32;
if ((t210 == t209)) {
t211=t206;
} else {
var t212:u32=t209;
var t213:R_Parameter;if(t212<a3[0u]){
t213=R_Parameter(a3[1u+(t212)*6u+0u],a3[1u+(t212)*6u+1u],a3[1u+(t212)*6u+2u],a3[1u+(t212)*6u+3u],a3[1u+(t212)*6u+4u],a3[1u+(t212)*6u+5u]);}else{
var t214:u32=0u;
var t215:u32=0u;
var t216:u32=0u;
var t217:u32=1065353216u;
var t218:u32=1065353216u;
var t219:u32=0u;
t213=R_Parameter(t214,t215,t216,t217,t218,t219);}
t211=(t213).ink_f_value;
}
var t220:u32=t211;
var t221:u32=t220;
for(var t222=0u;t222<6u;t222++){
var t223:u32=t221;
var t224:u32=t203;
var t225:u32=t204;
var t226:u32=t205;
var t227:u32=(t226 + t222);
var t228:u32=t225;
var t229:u32;
if ((t228 == t227)) {
t229=t224;
} else {
var t230:u32=t227;
var t231:R_Parameter;if(t230<a3[0u]){
t231=R_Parameter(a3[1u+(t230)*6u+0u],a3[1u+(t230)*6u+1u],a3[1u+(t230)*6u+2u],a3[1u+(t230)*6u+3u],a3[1u+(t230)*6u+4u],a3[1u+(t230)*6u+5u]);}else{
var t232:u32=0u;
var t233:u32=0u;
var t234:u32=0u;
var t235:u32=1065353216u;
var t236:u32=1065353216u;
var t237:u32=0u;
t231=R_Parameter(t232,t233,t234,t235,t236,t237);}
t229=(t231).ink_f_value;
}
var t238:u32=t229;
var t239:u32=t222;
var t240:u32;if(t239<a2[0u]){
t240=a2[1u+(t239)*1u+0u];}else{
t240=0u;}
t221=ink_f32_add(t223,ink_f32_mul(t238,t240));
}
var t241:u32=t221;
var t242:u32=t241;
var t243:u32;
if (ink_f32_lt(0u,t242)) {
var t244:u32=t202;
t243=ink_f32_mul(t244,t241);
} else {
t243=0u;
}
var t245:u32=t243;
output[1u+i*1u+0u]=bitcast<u32>(t245);

}
case 3u:{
var t246:u32=a0[0u+(0u)*1u+0u];
var t247:u32=a1[0u+(0u)*1u+0u];
var t248:u32=174u;
var t249:u32=t246;
var t250:u32=t247;
var t251:u32=t248;
var t252:u32=(t251 + 6u);
var t253:u32=t250;
var t254:u32;
if ((t253 == t252)) {
t254=t249;
} else {
var t255:u32=t252;
var t256:R_Parameter;if(t255<a3[0u]){
t256=R_Parameter(a3[1u+(t255)*6u+0u],a3[1u+(t255)*6u+1u],a3[1u+(t255)*6u+2u],a3[1u+(t255)*6u+3u],a3[1u+(t255)*6u+4u],a3[1u+(t255)*6u+5u]);}else{
var t257:u32=0u;
var t258:u32=0u;
var t259:u32=0u;
var t260:u32=1065353216u;
var t261:u32=1065353216u;
var t262:u32=0u;
t256=R_Parameter(t257,t258,t259,t260,t261,t262);}
t254=(t256).ink_f_value;
}
var t263:u32=t254;
var t264:u32=t263;
for(var t265=0u;t265<6u;t265++){
var t266:u32=t264;
var t267:u32=t246;
var t268:u32=t247;
var t269:u32=t248;
var t270:u32=(t269 + t265);
var t271:u32=t268;
var t272:u32;
if ((t271 == t270)) {
t272=t267;
} else {
var t273:u32=t270;
var t274:R_Parameter;if(t273<a3[0u]){
t274=R_Parameter(a3[1u+(t273)*6u+0u],a3[1u+(t273)*6u+1u],a3[1u+(t273)*6u+2u],a3[1u+(t273)*6u+3u],a3[1u+(t273)*6u+4u],a3[1u+(t273)*6u+5u]);}else{
var t275:u32=0u;
var t276:u32=0u;
var t277:u32=0u;
var t278:u32=1065353216u;
var t279:u32=1065353216u;
var t280:u32=0u;
t274=R_Parameter(t275,t276,t277,t278,t279,t280);}
t272=(t274).ink_f_value;
}
var t281:u32=t272;
var t282:u32=t265;
var t283:u32;if(t282<a2[0u]){
t283=a2[1u+(t282)*1u+0u];}else{
t283=0u;}
t264=ink_f32_add(t266,ink_f32_mul(t281,t283));
}
var t284:u32=t264;
var t285:u32=a0[0u+(0u)*1u+0u];
var t286:u32=a1[0u+(0u)*1u+0u];
var t287:u32=181u;
var t288:u32=t285;
var t289:u32=t286;
var t290:u32=t287;
var t291:u32=(t290 + 6u);
var t292:u32=t289;
var t293:u32;
if ((t292 == t291)) {
t293=t288;
} else {
var t294:u32=t291;
var t295:R_Parameter;if(t294<a3[0u]){
t295=R_Parameter(a3[1u+(t294)*6u+0u],a3[1u+(t294)*6u+1u],a3[1u+(t294)*6u+2u],a3[1u+(t294)*6u+3u],a3[1u+(t294)*6u+4u],a3[1u+(t294)*6u+5u]);}else{
var t296:u32=0u;
var t297:u32=0u;
var t298:u32=0u;
var t299:u32=1065353216u;
var t300:u32=1065353216u;
var t301:u32=0u;
t295=R_Parameter(t296,t297,t298,t299,t300,t301);}
t293=(t295).ink_f_value;
}
var t302:u32=t293;
var t303:u32=t302;
for(var t304=0u;t304<6u;t304++){
var t305:u32=t303;
var t306:u32=t285;
var t307:u32=t286;
var t308:u32=t287;
var t309:u32=(t308 + t304);
var t310:u32=t307;
var t311:u32;
if ((t310 == t309)) {
t311=t306;
} else {
var t312:u32=t309;
var t313:R_Parameter;if(t312<a3[0u]){
t313=R_Parameter(a3[1u+(t312)*6u+0u],a3[1u+(t312)*6u+1u],a3[1u+(t312)*6u+2u],a3[1u+(t312)*6u+3u],a3[1u+(t312)*6u+4u],a3[1u+(t312)*6u+5u]);}else{
var t314:u32=0u;
var t315:u32=0u;
var t316:u32=0u;
var t317:u32=1065353216u;
var t318:u32=1065353216u;
var t319:u32=0u;
t313=R_Parameter(t314,t315,t316,t317,t318,t319);}
t311=(t313).ink_f_value;
}
var t320:u32=t311;
var t321:u32=t304;
var t322:u32;if(t321<a2[0u]){
t322=a2[1u+(t321)*1u+0u];}else{
t322=0u;}
t303=ink_f32_add(t305,ink_f32_mul(t320,t322));
}
var t323:u32=t303;
var t324:u32=t323;
var t325:u32;
if (ink_f32_lt(0u,t324)) {
var t326:u32=t284;
t325=ink_f32_mul(t326,t323);
} else {
t325=0u;
}
var t327:u32=t325;
output[1u+i*1u+0u]=bitcast<u32>(t327);

}
case 4u:{
var t328:u32=a0[0u+(0u)*1u+0u];
var t329:u32=a1[0u+(0u)*1u+0u];
var t330:u32=188u;
var t331:u32=t328;
var t332:u32=t329;
var t333:u32=t330;
var t334:u32=(t333 + 6u);
var t335:u32=t332;
var t336:u32;
if ((t335 == t334)) {
t336=t331;
} else {
var t337:u32=t334;
var t338:R_Parameter;if(t337<a3[0u]){
t338=R_Parameter(a3[1u+(t337)*6u+0u],a3[1u+(t337)*6u+1u],a3[1u+(t337)*6u+2u],a3[1u+(t337)*6u+3u],a3[1u+(t337)*6u+4u],a3[1u+(t337)*6u+5u]);}else{
var t339:u32=0u;
var t340:u32=0u;
var t341:u32=0u;
var t342:u32=1065353216u;
var t343:u32=1065353216u;
var t344:u32=0u;
t338=R_Parameter(t339,t340,t341,t342,t343,t344);}
t336=(t338).ink_f_value;
}
var t345:u32=t336;
var t346:u32=t345;
for(var t347=0u;t347<6u;t347++){
var t348:u32=t346;
var t349:u32=t328;
var t350:u32=t329;
var t351:u32=t330;
var t352:u32=(t351 + t347);
var t353:u32=t350;
var t354:u32;
if ((t353 == t352)) {
t354=t349;
} else {
var t355:u32=t352;
var t356:R_Parameter;if(t355<a3[0u]){
t356=R_Parameter(a3[1u+(t355)*6u+0u],a3[1u+(t355)*6u+1u],a3[1u+(t355)*6u+2u],a3[1u+(t355)*6u+3u],a3[1u+(t355)*6u+4u],a3[1u+(t355)*6u+5u]);}else{
var t357:u32=0u;
var t358:u32=0u;
var t359:u32=0u;
var t360:u32=1065353216u;
var t361:u32=1065353216u;
var t362:u32=0u;
t356=R_Parameter(t357,t358,t359,t360,t361,t362);}
t354=(t356).ink_f_value;
}
var t363:u32=t354;
var t364:u32=t347;
var t365:u32;if(t364<a2[0u]){
t365=a2[1u+(t364)*1u+0u];}else{
t365=0u;}
t346=ink_f32_add(t348,ink_f32_mul(t363,t365));
}
var t366:u32=t346;
var t367:u32=a0[0u+(0u)*1u+0u];
var t368:u32=a1[0u+(0u)*1u+0u];
var t369:u32=195u;
var t370:u32=t367;
var t371:u32=t368;
var t372:u32=t369;
var t373:u32=(t372 + 6u);
var t374:u32=t371;
var t375:u32;
if ((t374 == t373)) {
t375=t370;
} else {
var t376:u32=t373;
var t377:R_Parameter;if(t376<a3[0u]){
t377=R_Parameter(a3[1u+(t376)*6u+0u],a3[1u+(t376)*6u+1u],a3[1u+(t376)*6u+2u],a3[1u+(t376)*6u+3u],a3[1u+(t376)*6u+4u],a3[1u+(t376)*6u+5u]);}else{
var t378:u32=0u;
var t379:u32=0u;
var t380:u32=0u;
var t381:u32=1065353216u;
var t382:u32=1065353216u;
var t383:u32=0u;
t377=R_Parameter(t378,t379,t380,t381,t382,t383);}
t375=(t377).ink_f_value;
}
var t384:u32=t375;
var t385:u32=t384;
for(var t386=0u;t386<6u;t386++){
var t387:u32=t385;
var t388:u32=t367;
var t389:u32=t368;
var t390:u32=t369;
var t391:u32=(t390 + t386);
var t392:u32=t389;
var t393:u32;
if ((t392 == t391)) {
t393=t388;
} else {
var t394:u32=t391;
var t395:R_Parameter;if(t394<a3[0u]){
t395=R_Parameter(a3[1u+(t394)*6u+0u],a3[1u+(t394)*6u+1u],a3[1u+(t394)*6u+2u],a3[1u+(t394)*6u+3u],a3[1u+(t394)*6u+4u],a3[1u+(t394)*6u+5u]);}else{
var t396:u32=0u;
var t397:u32=0u;
var t398:u32=0u;
var t399:u32=1065353216u;
var t400:u32=1065353216u;
var t401:u32=0u;
t395=R_Parameter(t396,t397,t398,t399,t400,t401);}
t393=(t395).ink_f_value;
}
var t402:u32=t393;
var t403:u32=t386;
var t404:u32;if(t403<a2[0u]){
t404=a2[1u+(t403)*1u+0u];}else{
t404=0u;}
t385=ink_f32_add(t387,ink_f32_mul(t402,t404));
}
var t405:u32=t385;
var t406:u32=t405;
var t407:u32;
if (ink_f32_lt(0u,t406)) {
var t408:u32=t366;
t407=ink_f32_mul(t408,t405);
} else {
t407=0u;
}
var t409:u32=t407;
output[1u+i*1u+0u]=bitcast<u32>(t409);

}
case 5u:{
var t410:u32=a0[0u+(0u)*1u+0u];
var t411:u32=a1[0u+(0u)*1u+0u];
var t412:u32=202u;
var t413:u32=t410;
var t414:u32=t411;
var t415:u32=t412;
var t416:u32=(t415 + 6u);
var t417:u32=t414;
var t418:u32;
if ((t417 == t416)) {
t418=t413;
} else {
var t419:u32=t416;
var t420:R_Parameter;if(t419<a3[0u]){
t420=R_Parameter(a3[1u+(t419)*6u+0u],a3[1u+(t419)*6u+1u],a3[1u+(t419)*6u+2u],a3[1u+(t419)*6u+3u],a3[1u+(t419)*6u+4u],a3[1u+(t419)*6u+5u]);}else{
var t421:u32=0u;
var t422:u32=0u;
var t423:u32=0u;
var t424:u32=1065353216u;
var t425:u32=1065353216u;
var t426:u32=0u;
t420=R_Parameter(t421,t422,t423,t424,t425,t426);}
t418=(t420).ink_f_value;
}
var t427:u32=t418;
var t428:u32=t427;
for(var t429=0u;t429<6u;t429++){
var t430:u32=t428;
var t431:u32=t410;
var t432:u32=t411;
var t433:u32=t412;
var t434:u32=(t433 + t429);
var t435:u32=t432;
var t436:u32;
if ((t435 == t434)) {
t436=t431;
} else {
var t437:u32=t434;
var t438:R_Parameter;if(t437<a3[0u]){
t438=R_Parameter(a3[1u+(t437)*6u+0u],a3[1u+(t437)*6u+1u],a3[1u+(t437)*6u+2u],a3[1u+(t437)*6u+3u],a3[1u+(t437)*6u+4u],a3[1u+(t437)*6u+5u]);}else{
var t439:u32=0u;
var t440:u32=0u;
var t441:u32=0u;
var t442:u32=1065353216u;
var t443:u32=1065353216u;
var t444:u32=0u;
t438=R_Parameter(t439,t440,t441,t442,t443,t444);}
t436=(t438).ink_f_value;
}
var t445:u32=t436;
var t446:u32=t429;
var t447:u32;if(t446<a2[0u]){
t447=a2[1u+(t446)*1u+0u];}else{
t447=0u;}
t428=ink_f32_add(t430,ink_f32_mul(t445,t447));
}
var t448:u32=t428;
var t449:u32=a0[0u+(0u)*1u+0u];
var t450:u32=a1[0u+(0u)*1u+0u];
var t451:u32=209u;
var t452:u32=t449;
var t453:u32=t450;
var t454:u32=t451;
var t455:u32=(t454 + 6u);
var t456:u32=t453;
var t457:u32;
if ((t456 == t455)) {
t457=t452;
} else {
var t458:u32=t455;
var t459:R_Parameter;if(t458<a3[0u]){
t459=R_Parameter(a3[1u+(t458)*6u+0u],a3[1u+(t458)*6u+1u],a3[1u+(t458)*6u+2u],a3[1u+(t458)*6u+3u],a3[1u+(t458)*6u+4u],a3[1u+(t458)*6u+5u]);}else{
var t460:u32=0u;
var t461:u32=0u;
var t462:u32=0u;
var t463:u32=1065353216u;
var t464:u32=1065353216u;
var t465:u32=0u;
t459=R_Parameter(t460,t461,t462,t463,t464,t465);}
t457=(t459).ink_f_value;
}
var t466:u32=t457;
var t467:u32=t466;
for(var t468=0u;t468<6u;t468++){
var t469:u32=t467;
var t470:u32=t449;
var t471:u32=t450;
var t472:u32=t451;
var t473:u32=(t472 + t468);
var t474:u32=t471;
var t475:u32;
if ((t474 == t473)) {
t475=t470;
} else {
var t476:u32=t473;
var t477:R_Parameter;if(t476<a3[0u]){
t477=R_Parameter(a3[1u+(t476)*6u+0u],a3[1u+(t476)*6u+1u],a3[1u+(t476)*6u+2u],a3[1u+(t476)*6u+3u],a3[1u+(t476)*6u+4u],a3[1u+(t476)*6u+5u]);}else{
var t478:u32=0u;
var t479:u32=0u;
var t480:u32=0u;
var t481:u32=1065353216u;
var t482:u32=1065353216u;
var t483:u32=0u;
t477=R_Parameter(t478,t479,t480,t481,t482,t483);}
t475=(t477).ink_f_value;
}
var t484:u32=t475;
var t485:u32=t468;
var t486:u32;if(t485<a2[0u]){
t486=a2[1u+(t485)*1u+0u];}else{
t486=0u;}
t467=ink_f32_add(t469,ink_f32_mul(t484,t486));
}
var t487:u32=t467;
var t488:u32=t487;
var t489:u32;
if (ink_f32_lt(0u,t488)) {
var t490:u32=t448;
t489=ink_f32_mul(t490,t487);
} else {
t489=0u;
}
var t491:u32=t489;
output[1u+i*1u+0u]=bitcast<u32>(t491);

}
default:{} }

}
}